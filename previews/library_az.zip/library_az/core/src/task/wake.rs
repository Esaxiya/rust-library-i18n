#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker`, tapşırıq icraçısının icraçısına xüsusi uyanış davranışı təmin edən bir [`Waker`] yaratmağa imkan verir.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Bu, bir məlumat göstəricisindən və `RawWaker` davranışını fərdiləşdirən bir [virtual function pointer table (vtable)][vtable]-dən ibarətdir.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// İcraçı tərəfindən tələb olunduğu kimi təsadüfi məlumatları saxlamaq üçün istifadə edilə bilən bir məlumat göstəricisi.
    /// Bu məsələn ola bilər
    /// tapşırıqla əlaqəli bir `Arc` üçün tip silinmiş bir göstərici.
    /// Bu sahənin dəyəri ilk parametr olaraq vtable-ın bir hissəsi olan bütün funksiyalara ötürülür.
    ///
    data: *const (),
    /// Bu oynatıcının davranışını fərdiləşdirən virtual funksiya göstəricisi cədvəli.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Təqdim olunan `data` göstəricisindən və `vtable`-dən yeni bir `RawWaker` yaradır.
    ///
    /// `data` göstəricisi icraçının tələb etdiyi kimi təsadüfi məlumatları saxlamaq üçün istifadə edilə bilər.Bu məsələn ola bilər
    /// tapşırıqla əlaqəli bir `Arc` üçün tip silinmiş bir göstərici.
    /// Bu göstəricinin dəyəri ilk parametr olaraq `vtable`-in bir hissəsi olan bütün funksiyalara keçəcəkdir.
    ///
    /// `vtable`, `RawWaker`-dən yaradılan bir `Waker` davranışını özelleştirir.
    /// `Waker`-də hər bir əməliyyat üçün, əsas `RawWaker`-in `vtable`-də əlaqəli funksiya çağırılacaqdır.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Bir [`RawWaker`] davranışını göstərən bir virtual funksiya göstəricisi cədvəli (vtable).
///
/// Vtable içərisindəki bütün funksiyalara ötürülən işarə, əhatə edən [`RawWaker`] obyektindən `data` göstəricisidir.
///
/// Bu strukturun içindəki funksiyalar yalnız [`RawWaker`] tətbiqinin içərisindən düzgün qurulmuş bir [`RawWaker`] obyektinin `data` göstəricisinə çağırılması üçün nəzərdə tutulmuşdur.
/// Daxil olan funksiyalardan birinə başqa hər hansı bir `data` göstəricisindən istifadə etmək, təyin olunmamış davranışa səbəb olacaqdır.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Bu funksiya [`RawWaker`] klonlandıqda, məsələn [`RawWaker`]-in saxlanıldığı [`Waker`] klonlandıqda çağırılacaq.
    ///
    /// Bu funksiyanın tətbiqi, [`RawWaker`] və əlaqəli tapşırığın bu əlavə nümunəsi üçün tələb olunan bütün mənbələri saxlamalıdır.
    /// Yaranan [`RawWaker`]-də `wake`-in çağırılması orijinal [`RawWaker`] tərəfindən oyanmış olan eyni tapşırığın oyanması ilə nəticələnməlidir.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Bu funksiya [`Waker`]-də `wake` çağırıldıqda çağırılacaqdır.
    /// Bu [`RawWaker`] ilə əlaqəli vəzifəni oyatmalıdır.
    ///
    /// Bu funksiyanın tətbiqi, bir [`RawWaker`] nümunəsi və əlaqəli tapşırıqla əlaqəli olan hər hansı bir mənbəyi buraxdığından əmin olmalıdır.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Bu funksiya [`Waker`]-də `wake_by_ref` çağırıldıqda çağırılacaqdır.
    /// Bu [`RawWaker`] ilə əlaqəli vəzifəni oyatmalıdır.
    ///
    /// Bu funksiya `wake`-ə bənzəyir, lakin verilən məlumat göstəricisini istehlak etməməlidir.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Bu funksiya bir [`RawWaker`] düşdükdə çağırılır.
    ///
    /// Bu funksiyanın tətbiqi, bir [`RawWaker`] nümunəsi və əlaqəli tapşırıqla əlaqəli olan hər hansı bir mənbəyi buraxdığından əmin olmalıdır.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Təqdim olunan `clone`, `wake`, `wake_by_ref` və `drop` funksiyalarından yeni bir `RawWakerVTable` yaradır.
    ///
    /// # `clone`
    ///
    /// Bu funksiya [`RawWaker`] klonlandıqda, məsələn [`RawWaker`]-in saxlanıldığı [`Waker`] klonlandıqda çağırılacaq.
    ///
    /// Bu funksiyanın tətbiqi, [`RawWaker`] və əlaqəli tapşırığın bu əlavə nümunəsi üçün tələb olunan bütün mənbələri saxlamalıdır.
    /// Yaranan [`RawWaker`]-də `wake`-in çağırılması orijinal [`RawWaker`] tərəfindən oyanmış olan eyni tapşırığın oyanması ilə nəticələnməlidir.
    ///
    /// # `wake`
    ///
    /// Bu funksiya [`Waker`]-də `wake` çağırıldıqda çağırılacaqdır.
    /// Bu [`RawWaker`] ilə əlaqəli vəzifəni oyatmalıdır.
    ///
    /// Bu funksiyanın tətbiqi, bir [`RawWaker`] nümunəsi və əlaqəli tapşırıqla əlaqəli olan hər hansı bir mənbəyi buraxdığından əmin olmalıdır.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Bu funksiya [`Waker`]-də `wake_by_ref` çağırıldıqda çağırılacaqdır.
    /// Bu [`RawWaker`] ilə əlaqəli vəzifəni oyatmalıdır.
    ///
    /// Bu funksiya `wake`-ə bənzəyir, lakin verilən məlumat göstəricisini istehlak etməməlidir.
    ///
    /// # `drop`
    ///
    /// Bu funksiya bir [`RawWaker`] düşdükdə çağırılır.
    ///
    /// Bu funksiyanın tətbiqi, bir [`RawWaker`] nümunəsi və əlaqəli tapşırıqla əlaqəli olan hər hansı bir mənbəyi buraxdığından əmin olmalıdır.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Asinxron tapşırığın `Context`.
///
/// Hal-hazırda, `Context` yalnız cari tapşırığı oyatmaq üçün istifadə edilə bilən bir `&Waker`-ə giriş təmin edir.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Ömrünü dəyişməz olmağa məcbur edərək varyans dəyişikliklərinə qarşı future-yə davamlı olduğumuzu təmin edin (mübahisəli mövqe ömrü ziddiyyətlidir, geri dönmə mövqeyi ömrü isə dəyişkəndir).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// `&Waker`-dən yeni bir `Context` yaradın.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Cari tapşırıq üçün `Waker`-ə bir istinad qaytarır.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker`, icraçısını işə hazır olduğunu bildirərək tapşırığı oyatmaq üçün bir işdir.
///
/// Bu sap, icraçıya xas uyanış davranışını təyin edən bir [`RawWaker`] nümunəsini əhatə edir.
///
///
/// [`Clone`], [`Send`] və [`Sync`] tətbiq edir.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Bu `Waker` ilə əlaqəli işi oyadın.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Həqiqi oyanma çağırışı, virtual funksiya çağırışı ilə icraçı tərəfindən təyin olunan həyata keçirilməyə həvalə olunur.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop`-ə zəng etməyin-oynatıcı `wake` tərəfindən tükənəcəkdir.
        crate::mem::forget(self);

        // TƏHLÜKƏSİZLİK: Bu təhlükəsizdir, çünki `Waker::from_raw` yeganə yoldur
        // istifadəçinin `RawWaker` müqaviləsinin təmin olunduğunu qəbul etməsini tələb edən `wake` və `data`-i işə salmaq.
        //
        unsafe { (wake)(data) };
    }

    /// `Waker` istehlak etmədən bu `Waker` ilə əlaqəli tapşırığı oyadın.
    ///
    /// Bu, `wake`-ə bənzəyir, lakin sahib olduğu bir `Waker`-in mövcud olduğu vəziyyətdə bir az daha az effektiv ola bilər.
    /// Bu metod `waker.clone().wake()`-ə zəng etməkdən üstün olmalıdır.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Həqiqi oyanma çağırışı, virtual funksiya çağırışı ilə icraçı tərəfindən təyin olunan həyata keçirilməyə həvalə olunur.
        //

        // TƏHLÜKƏSİZLİK: bax `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Bu `Waker` və başqa bir `Waker` eyni işi oyatmışsa `true` qaytarır.
    ///
    /// Bu funksiya ən yaxşı səylər əsasında işləyir və Waker-lər eyni tapşırığı oyatdıqda belə yanlış ola bilər.
    /// Bununla birlikdə, bu funksiya `true` qaytararsa, Waker-in eyni tapşırığı oyatacağına zəmanət verilir.
    ///
    /// Bu funksiya əsasən optimallaşdırma məqsədləri üçün istifadə olunur.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`]-dən yeni bir `Waker` yaradır.
    ///
    /// [`RawWaker`] və [`RawWakerVTable`] sənədlərində müəyyən edilmiş müqavilə təmin edilmədiyi təqdirdə, qaytarılmış `Waker`-in davranışı müəyyənləşdirilmir.
    ///
    /// Bu səbəbdən bu metod təhlükəlidir.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // TƏHLÜKƏSİZLİK: Bu təhlükəsizdir, çünki `Waker::from_raw` yeganə yoldur
            // istifadəçinin [`RawWaker`] müqaviləsinin təmin olunduğunu qəbul etməsini tələb edən `clone` və `data`-i işə salmaq.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // TƏHLÜKƏSİZLİK: Bu təhlükəsizdir, çünki `Waker::from_raw` yeganə yoldur
        // istifadəçinin `RawWaker` müqaviləsinin təmin olunduğunu qəbul etməsini tələb edən `drop` və `data`-i işə salmaq.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}