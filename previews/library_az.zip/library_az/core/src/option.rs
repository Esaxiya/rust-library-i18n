//! İstəyə uyğun dəyərlər.
//!
//! [`Option`] növü isteğe bağlı bir dəyəri təmsil edir: hər [`Option`] ya [`Some`] dir və bir dəyər ya da [`None`] ehtiva edir və vermir.
//! [`Option`] növləri Rust kodunda çox yayılmışdır, çünki bunların bir sıra istifadəsi var:
//!
//! * İlkin dəyərlər
//! * Bütün giriş aralığında (qismən funksiyalar) təyin olunmayan funksiyalar üçün qayıdış dəyərləri
//! * [`None`]-in səhvlə qaytarıldığı sadə səhvləri başqa cür hesabat üçün qayıdış dəyəri
//! * Könüllü struktur sahələri
//! * Borc verilən və ya "taken" sahələri qurun
//! * Könüllü funksiya arqumentləri
//! * Boş göstəricilər
//! * Çətin vəziyyətlərdən şeyləri dəyişdirmək
//!
//! [`Seçim '] lər ümumiyyətlə bir dəyərin mövcudluğunu soruşmaq və hərəkətə keçmək üçün hər zaman [`None`] halını hesablamaq üçün nümunə ilə uyğunlaşdırılır.
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // Funksiyanın qaytarma dəyəri bir seçimdir
//! let result = divide(2.0, 3.0);
//!
//! // Dəyəri almaq üçün naxış uyğunluğu
//! match result {
//!     // Bölmə etibarlı idi
//!     Some(x) => println!("Result: {}", x),
//!     // Bölmə etibarsız idi
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: `Option`-in praktikada çox metodlarla necə istifadə edildiyini göstərin
//
//! # Seçimlər və göstəricilər ("nullable" göstəriciləri)
//!
//! Rust göstərici növləri həmişə etibarlı bir yerə işarə etməlidir;"null" istinadları yoxdur.Bunun əvəzinə, Rust, isteğe bağlı qutu kimi *isteğe bağlı* göstəricilərə malikdir, [`Seçim`]`<`[`Qutu<T>"]">".
//!
//! Aşağıdakı misal, isteğe bağlı bir [`i32`] qutusu yaratmaq üçün [`Option`] istifadə edir.
//! Diqqət yetirin ki, əvvəlcə daxili [`i32`] dəyərindən istifadə etmək üçün `check_optional` funksiyası, qutunun bir qiymətə sahib olub olmadığını (yəni [`Some(...)`][`Some`]) olduğunu və ya ([`None`]) olmadığını) təyin etmək üçün nümunə uyğunluğu istifadə etməlidir.
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust, [`Option<T>`]-in `T` ilə eyni ölçüyə sahib olması üçün aşağıdakı `T` növlərini optimallaşdırmağa zəmanət verir:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` Bu siyahıda olan növlərdən biri ətrafında struct.
//!
//! Yuxarıda göstərilən hallar üçün `T`-dan `Option<T>`-ə və `Some::<T>(_)`-dən `T`-ə qədər olan bütün etibarlı dəyərlərdən [`mem::transmute`] edə biləcəyinə daha çox zəmanət verilir (lakin `None::<T>`-dən `T`-ə keçmək, təyin olunmamış davranışdır).
//!
//! # Examples
//!
//! [`Option`]-də əsas model uyğunluğu:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // İçindəki sətrə istinad edin
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // Seçimi məhv edərək içəridə olan sətri silin
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! Bir döngədən əvvəl [`None`] nəticəsini başladın:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // Axtarış üçün verilənlərin siyahısı.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // Ən böyük heyvanın adını axtaracağıq, ancaq `None`-i əldə etdiyimizə başlamaq üçün.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // İndi böyük bir heyvanın adını tapdıq
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` növü.Daha çox məlumat üçün [the module level documentation](self)-ə baxın.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// Dəyər yoxdur
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// Bəzi dəyərlər `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// Növ tətbiqetmə
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // Daxil olan dəyərlərin sorğusu
    /////////////////////////////////////////////////////////////////////////

    /// Seçim [`Some`] dəyəridirsə `true` qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// Seçim [`None`] dəyəridirsə `true` qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// Seçim verilmiş dəyəri ehtiva edən bir [`Some`] dəyəridirsə, `true` qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // İstinadlarla işləmək üçün adapter
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>`-dən `Option<&T>`-ə çevirir.
    ///
    /// # Examples
    ///
    /// Orijinalı qorumaqla bir `Seçim <` [`String`]`>`bir Seçimə <`[`usize`]`> `çevirir.
    /// [`map`] metodu, orijinalı istehlak edən `self` arqumentini dəyərinə görə alır, beləliklə bu texnika `as_ref`-dən əvvəl orijinalın içindəki dəyərə istinad etmək üçün `Option` istifadə edir.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // Əvvəlcə `as_ref` ilə `Option<String>`-i `Option<&String>`-ə atın, sonra `map` ilə *that* istehlak edin, yığında `text` qoyun.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>`-dən `Option<&mut T>`-ə çevirir.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`Pin ']` <&Seçimdən çevirir<T>> `seçiminə <` [Pin '] `<&T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // TƏHLÜKƏSİZLİK: `x`-in `self`-dən gəldiyi üçün sabitlənməsinə zəmanət verilir
        // sancılıb.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`Pin ']` <&mut Option-dan çevirir<T>> `seçiminə <` [Pin '] `<&mut T>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // TƏHLÜKƏSİZLİK: `get_unchecked_mut` heç vaxt `self` içərisində `Option`-i hərəkət etdirmək üçün istifadə olunmur.
        // `x` sabitləndiyinə zəmanət verilir, çünki bu, sancılan `self`-dən gəlir.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // İçəridə olan dəyərlərə çatmaq
    /////////////////////////////////////////////////////////////////////////

    /// `self` dəyərini istehlak edən [`Some`] dəyərini qaytarır.
    ///
    /// # Panics
    ///
    /// Panics, dəyər `msg` tərəfindən təmin edilmiş xüsusi bir panic mesajı ilə bir [`None`] olarsa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// `self` dəyərini istehlak edən [`Some`] dəyərini qaytarır.
    ///
    /// Bu funksiya panic ola biləcəyi üçün istifadəsi ümumiyyətlə dayandırılır.
    /// Bunun əvəzinə, naxış uyğunluğundan istifadə etməyi və [`None`] işini açıq şəkildə idarə etməyi və ya [`unwrap_or`], [`unwrap_or_else`] və ya [`unwrap_or_default`]-i axtarmağı üstün tutun.
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics, əgər öz dəyəri [`None`]-ə bərabərdirsə.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// Daxil olan [`Some`] dəyərini və ya təmin edilmiş bir standartı qaytarır.
    ///
    /// `unwrap_or`-ə verilən mübahisələr maraqla qiymətləndirilir;bir funksiya çağırışının nəticəsini ötürürsənsə, tənbəlliklə qiymətləndirilən [`unwrap_or_else`] istifadə etməyiniz tövsiyə olunur.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// İçəridə olan [`Some`] dəyərini qaytarır və ya bir bağlanmadan hesablayır.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// Dəyərin [`None`] olmadığını yoxlamadan `self` dəyərini istehlak edən [`Some`] dəyərini qaytarır.
    ///
    ///
    /// # Safety
    ///
    /// Bu metodu [`None`]-də çağırmaq *[təyin olunmamış davranış]* dır.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // Tərifsiz davranış!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // TƏHLÜKƏSİZLİK: təhlükəsizlik müqaviləsi axtaran tərəfindən təmin edilməlidir.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Dəyərləri dəyişdirmək
    /////////////////////////////////////////////////////////////////////////

    /// Yerləşmiş bir dəyərə bir funksiya tətbiq edərək `Option<T>` ilə `Option<U>` arasında xəritələr.
    ///
    /// # Examples
    ///
    /// Orijini istehlak edərək bir `Seçim <` [`String`]`>`bir Seçimə <`[`usize`]`> `çevirir:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` özünü *dəyərinə görə* alır, `maybe_some_string` istehlak edir
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// Əldə olunan dəyərə (varsa) bir funksiya tətbiq edir və ya təmin edilmiş borcunu qaytarır (yoxsa).
    ///
    /// `map_or`-ə verilən mübahisələr maraqla qiymətləndirilir;bir funksiya çağırışının nəticəsini ötürürsənsə, tənbəlliklə qiymətləndirilən [`map_or_else`] istifadə etməyiniz tövsiyə olunur.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// Əldə olunan dəyərə bir funksiya tətbiq edir (varsa) və ya bir borc hesablayır (yoxsa).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>`-i [`Result<T, E>`]-ə çevirir, [`Some(v)`]-dən [`Ok(v)`]-ə və [`None`]-dən [`Err(err)`]-yə uyğunlaşdırır.
    ///
    /// `ok_or`-ə verilən mübahisələr maraqla qiymətləndirilir;bir funksiya çağırışının nəticəsini ötürürsənsə, tənbəlliklə qiymətləndirilən [`ok_or_else`] istifadə etməyiniz tövsiyə olunur.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>`-i [`Result<T, E>`]-ə çevirir, [`Some(v)`]-dən [`Ok(v)`]-ə və [`None`]-dən [`Err(err())`]-yə uyğunlaşdırır.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// Seçimə `value` əlavə edir, sonra dəyişdirilə bilən bir istinad gətirir.
    ///
    /// Seçimdə artıq bir dəyər varsa, köhnə dəyər atılır.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // TƏHLÜKƏSİZLİK: yuxarıdakı kod sadəcə seçimi doldurdu
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Təkrarlayıcı konstruktorlar
    /////////////////////////////////////////////////////////////////////////

    /// Ehtimal olunan dəyər üzərində təkrarlayıcı qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// Ehtimal olunan dəyər üzərində dəyişdirilə bilən təkrarlayıcı qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // Dəyərlər üzərində məntiqi əməliyyatlar, istəkli və tənbəl
    /////////////////////////////////////////////////////////////////////////

    /// Seçim [`None`] olarsa [`None`] qaytarır, əks halda `optb` verir.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// Seçim [`None`] olarsa [`None`] qaytarır, əks halda bükülmüş dəyərlə `f` çağırır və nəticəni qaytarır.
    ///
    ///
    /// Bəzi dillər bu əməliyyatı flatmap adlandırır.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// Seçim [`None`] olarsa [`None`] qaytarır, əks halda bükülmüş dəyərlə `predicate` çağırır və qaytarır:
    ///
    ///
    /// - [`Some(t)`] `predicate` `true` qaytararsa (burada `t` bükülmüş dəyərdir) və
    /// - [`None`] `predicate` `false` qaytararsa.
    ///
    /// Bu funksiya [`Iterator::filter()`]-ə bənzər işləyir.
    /// `Option<T>`-in bir və ya sıfır element üzərində təkrarlayıcı olduğunu təsəvvür edə bilərsiniz.
    /// `filter()` hansı elementləri saxlamağınıza qərar verməyinizə imkan verir.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// Dəyəri varsa seçimi qaytarır, əks halda `optb` qaytarır.
    ///
    /// `or`-ə verilən mübahisələr maraqla qiymətləndirilir;bir funksiya çağırışının nəticəsini ötürürsənsə, tənbəlliklə qiymətləndirilən [`or_else`] istifadə etməyiniz tövsiyə olunur.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// Dəyəri varsa seçimi qaytarır, əks halda `f` çağırır və nəticəni qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// `self`, `optb`-dən tam biri [`Some`] olarsa [`Some`] qaytarır, əks halda [`None`] verir.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Yoxdursa daxil etmək və istinad gətirmək üçün girişə bənzər əməliyyatlar
    /////////////////////////////////////////////////////////////////////////

    /// [`None`] olduqda `value` seçiminə əlavə edir, sonra ehtiva olunan dəyərə dəyişdirilə bilən bir istinad gətirir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// Varsayılan dəyəri [`None`] olduqda seçimə əlavə edir, sonra ehtiva olunan dəyərə dəyişdirilə bilən bir istinad gətirir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// [`None`] olduğu təqdirdə `f`-dən hesablanmış bir dəyəri seçkiyə əlavə edir, sonra ehtiva olunan dəyərə dəyişkən bir istinad gətirir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // TƏHLÜKƏSİZLİK: `self` üçün `None` variantı `Some` ilə əvəz ediləcəkdi
            // yuxarıdakı koddakı variant.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// Dəyəri seçimdən kənarlaşdırır, yerinə [`None`] qoyur.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// Seçimdəki həqiqi dəyəri parametrdə verilmiş dəyərlə əvəz edir, mövcud olduqda köhnə dəyəri qaytarır və heç birini deinisallaşdırmadan yerinə bir [`Some`] qoyur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// `self`-i başqa bir `Option` ilə sıxışdırır.
    ///
    /// `self` `Some(s)` və `other` `Some(o)` olarsa, bu metod `Some((s, o))` qaytarır.
    /// Əks təqdirdə, `None` qaytarılır.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// `self` və `f` funksiyasına sahib başqa bir `Option` fermuar.
    ///
    /// `self` `Some(s)` və `other` `Some(o)` olarsa, bu metod `Some(f(s, o))` qaytarır.
    /// Əks təqdirdə, `None` qaytarılır.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// Seçimin məzmununu kopyalayaraq bir `Option<&T>`-dən `Option<T>`-ə qədər xəritələr.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// Seçimin məzmununu kopyalayaraq bir `Option<&mut T>`-dən `Option<T>`-ə qədər xəritələr.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// Seçimin tərkibini klonlayaraq `Option<&T>`-dən `Option<T>`-ə xəritələr.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// Seçimin tərkibini klonlayaraq `Option<&mut T>`-dən `Option<T>`-ə xəritələr.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// [`None`] gözləyərkən və heç bir şey vermədən `self` istehlak edir.
    ///
    /// # Panics
    ///
    /// Panics, dəyər bir [`Some`] olarsa, ötürülən mesaj daxil olmaqla panic mesajı və [`Some`] məzmunu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Bütün düymələr unikal olduğundan bu, panic olmayacaq.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// [`None`] gözləyərkən və heç bir şey vermədən `self` istehlak edir.
    ///
    /// # Panics
    ///
    /// Dəyəri bir [`Some`] olduqda Panics, [[Bəzi]] nin dəyəri ilə təmin edilmiş xüsusi bir panic mesajı ilə.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // Bütün düymələr unikal olduğundan bu, panic olmayacaq.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// İçəridə olan [`Some`] dəyərini və ya bir standartı qaytarır
    ///
    /// `self` arqumentini istehlak edir, sonra [`Some`] varsa, ehtiva olunan dəyəri qaytarır, əks halda [`None`] varsa, bu tip üçün [default value]-i qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// Sətri tam ədədə çevirir, zəif əmələ gələn simləri 0-a çevirir (tam ədədlər üçün standart dəyər).
    /// [`parse`] bir simli [`FromStr`]-i həyata keçirən hər hansı digər növə çevirir, səhvən [`None`]-i qaytarır.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>`-dən (və ya `&Option<T>`) `Option<&T::Target>`-ə çevirir.
    ///
    /// Orijinal variantı yerində saxlayır, orijinalına istinad edərək yenisini yaradır və əlavə olaraq məzmunu [`Deref`] vasitəsilə məcbur edir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>`-dən (və ya `&mut Option<T>`) `Option<&mut T::Target>`-ə çevirir.
    ///
    /// Orijinal `Option`-i yerində saxlayır, daxili tipin `Deref::Target` tipinə dəyişdirilə bilən bir istinad ehtiva edən yenisini yaradır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// [`Result`]-in `Option`-in `Option`-in [`Result`]-ə çevrilir.
    ///
    /// [`None`] [`Ok`]`(`[`None`] `) '' ilə eşlenecektir.
    /// [`Some`]`(`[`Ok`] `(_))` və [`Some`]`(`[`Err`] `(_))` [[Ok`] '(`[`Some`] `(_))` və [`Err`]`(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// Bu, .expect()-in özünün kod ölçüsünü azaltmaq üçün ayrıca bir funksiyadır.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// Bu, .expect_none()-in özünün kod ölçüsünü azaltmaq üçün ayrıca bir funksiyadır.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait tətbiqetmələri
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Ehtimal olunan dəyər üzərində istehlakçı təkrarlayıcı qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// `val`-i yeni `Some`-ə köçürür.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>`-dən `Option<&T>`-ə çevirir.
    ///
    /// # Examples
    ///
    /// Orijinalı qorumaqla bir `Seçim <` [`String`]`>`bir Seçimə <`[`usize`]`> `çevirir.
    /// [`map`] metodu, orijinalı istehlak edən `self` arqumentini dəyərinə görə alır, beləliklə bu texnika `as_ref`-dən əvvəl orijinalın içindəki dəyərə istinad etmək üçün `Option` istifadə edir.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>`-dən `Option<&mut T>`-ə çevirir
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// Seçim təkrarlayıcılar
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// Bir [`Option`]-in [`Some`] variantına istinad edən təkrarlayıcı.
///
/// [`Option`] bir [`Some`], əks halda heç biri olduqda təkrarlayıcı bir dəyər verir.
///
/// Bu `struct`, [`Option::iter`] funksiyası tərəfindən yaradılmışdır.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// Bir [`Option`]-in [`Some`] variantına dəyişdirilə bilən bir istinad üzərində bir iterator.
///
/// [`Option`] bir [`Some`], əks halda heç biri olduqda təkrarlayıcı bir dəyər verir.
///
/// Bu `struct`, [`Option::iter_mut`] funksiyası tərəfindən yaradılmışdır.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Option`]-in [`Some`] variantındakı dəyər üzərində təkrarlayıcı.
///
/// [`Option`] bir [`Some`], əks halda heç biri olduqda təkrarlayıcı bir dəyər verir.
///
/// Bu `struct`, [`Option::into_iter`] funksiyası tərəfindən yaradılmışdır.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// Hər bir elementi [`Iterator`]-də götürür: [`None`][Option::None] olarsa, başqa element alınmaz və [`None`][Option::None] qaytarılır.
    /// [`None`][Option::None] olmaması halında, hər [`Option`] dəyərinə sahib bir qab qaytarılır.
    ///
    /// # Examples
    ///
    /// vector-də hər bir ədədi artıran bir nümunə.
    /// Hesablamanın daşması ilə nəticələnəcəyi zaman `None` qaytaran `add`-in yoxlanılmış variantını istifadə edirik.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// Gördüyünüz kimi, bu gözlənilən, etibarlı maddələri qaytaracaqdır.
    ///
    /// Budur, başqa bir tam ədədi siyahısından çıxartmağa çalışan başqa bir nümunə, bu dəfə axının olduğunu yoxlayırıq:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// Son element sıfır olduğundan, altına axacaqdı.Beləliklə, ortaya çıxan dəyər `None`-dir.
    ///
    /// İlk `None`-dən sonra `iter`-dən başqa heç bir element götürülmədiyini göstərən əvvəlki nümunədəki bir dəyişiklik.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// Üçüncü element bir aşığa səbəb olduğundan başqa heç bir element alınmadı, buna görə `shared`-in son dəyəri 16 deyil, 6 (= `3 + 2 + 1`)-dir.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): Bu performans hatası bağlandıqda bu Iterator::scan ilə əvəz edilə bilər.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// (`?`) operatorunu `None` dəyərinə tətbiq etməklə nəticələnən səhv növü.
/// `x?` (burada `x` bir `Option<T>` olduğu) üçün səhv tipinizə çevrilməsinə icazə vermək istəyirsinizsə, `YourErrorType` üçün `impl From<NoneError>` tətbiq edə bilərsiniz.
///
/// Bu vəziyyətdə `Result<_, YourErrorType>` qaytaran bir funksiya içərisində `x?`, `None` dəyərini `Err` nəticəsinə çevirəcəkdir.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>`-dən `Option<T>`-ə çevirir
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// Düzəltmə hər dəfə yalnız bir yuvalama səviyyəsini aradan qaldırır:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}