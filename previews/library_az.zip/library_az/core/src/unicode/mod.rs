#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// `char` və `str` metodlarının Unicode hissələrinin əsas götürdüyü [Unicode](http://www.unicode.org/) versiyası.
///
/// Unicode-un yeni versiyaları müntəzəm olaraq yayımlanır və daha sonra Unicode-dan asılı olaraq standart kitabxanadakı bütün metodlar yenilənir.
/// Buna görə bəzi `char` və `str` metodlarının davranışı və bu sabitin dəyəri zamanla dəyişir.
/// Bu qırılma bir dəyişiklik olaraq qəbul edilmir.
///
/// Versiya nömrələmə sxemi [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4)-də izah olunur.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Liballoc-da istifadə üçün, libstd-də yenidən ixrac edilmir.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;