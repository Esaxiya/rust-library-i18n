#![stable(feature = "core_hint", since = "1.27.0")]

//! Kodun necə buraxılmasını və ya optimallaşdırılmasını təsir edən tərtibçiyə göstərişlər.
//! Göstərişlər vaxt və ya işləmə vaxtı ola bilər.

use crate::intrinsics;

/// Koddakı bu nöqtənin əlçatmaz olduğunu və daha da optimallaşdırılmasını təmin edən tərtibçiyə məlumat verir.
///
/// # Safety
///
/// Bu funksiyaya çatmaq tamamilə *təyin olunmamış davranışdır*(UB).Xüsusilə, tərtibçi, bütün UB-nin heç vaxt olmaması lazım olduğunu və bu səbəbdən `unreachable_unchecked()`-ə zəng edən bütün filialları aradan qaldıracağını düşünür.
///
/// Bütün UB nümunələri kimi, bu fərziyyənin səhv olduğu, yəni `unreachable_unchecked()` çağırışının mümkün olan bütün idarəetmə axını arasında əlçatan olduğu təqdirdə, tərtibçi səhv optimallaşdırma strategiyasını tətbiq edəcək və bəzən əlaqəsi olmayan görünən kodu pozaraq çətinləşməsinə səbəb ola bilər. ayıklama problemləri.
///
///
/// Bu funksiyanı yalnız kodun heç vaxt çağırmayacağını sübut edə bildiyiniz zaman istifadə edin.
/// Əks təqdirdə, optimallaşdırmalara imkan verməyən, lakin icra edildikdə panic olacaq [`unreachable!`] makrosundan istifadə etməyi düşünün.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` həmişə pozitivdir (sıfır deyil), bu səbəbdən `checked_div` heç vaxt `None`-ə dönməyəcəkdir.
/////
///     // Bu səbəbdən başqa branch ilə əlaqə qurula bilməz.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // TƏHLÜKƏSİZLİK: `intrinsics::unreachable` üçün təhlükəsizlik müqaviləsi olmalıdır
    // zəng edən tərəfindən dəstəklənsin.
    unsafe { intrinsics::unreachable() }
}

/// İşlemciyə sıx bir gözləmə ilə dönmə döngəsində ("fırlanma kilidi") işlədiyini bildirən bir maşın təlimatı buraxır.
///
/// Spin-loop siqnalını aldıqdan sonra prosessor, məsələn, gücə qənaət etmək və ya hyper-saplarını dəyişdirməklə davranışını optimallaşdırır.
///
/// Bu funksiya, sistemin planlaşdırıcısına birbaşa təsir göstərən [`thread::yield_now`]-dən fərqlənir, `spin_loop` isə əməliyyat sistemi ilə qarşılıqlı əlaqədə olmur.
///
/// `spin_loop` üçün ümumi istifadə vəziyyəti, sinxronizasiya primitivlərində CAS döngəsində məhdud optimist əyirmə tətbiq edir.
/// Prioritet inversiya kimi problemlərdən qaçınmaq üçün sonlu miqdarda təkrarlamadan və müvafiq bir bloklayıcı syscall edildikdən sonra spin döngəsinin sonlandırılması şiddətlə tövsiyə olunur.
///
///
/// **Qeyd**: Spin-loop işarələrini qəbul etməyi dəstəkləməyən platformalarda bu funksiya heç bir şey etmir.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Mövzular əlaqələndirmək üçün istifadə edəcəyi paylaşılan bir atom dəyəri
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Arxa fonda sonda dəyəri təyin edəcəyik
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Bir az işləyin, sonra dəyərini yaşadın
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Mövcud mövzuya qayıdıb dəyərin təyin olunmasını gözləyirik
/// while !live.load(Ordering::Acquire) {
///     // Spin loop CPU üçün gözlədiyimiz bir işarədir, lakin çox güman ki deyil
/////
///     hint::spin_loop();
/// }
///
/// // Dəyər indi təyin edilmişdir
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // TƏHLÜKƏSİZLİK: `cfg` attr bunu yalnız x86 hədəflərində icra etməyimizi təmin edir.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // TƏHLÜKƏSİZLİK: `cfg` attr bunu yalnız x86_64 hədəflərində icra etməyimizi təmin edir.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // TƏHLÜKƏSİZLİK: `cfg` attr bunu yalnız aarch64 hədəflərində icra etməyimizi təmin edir.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // TƏHLÜKƏSİZLİK: `cfg` attr bunu yalnız qol hədəflərində həyata keçirməyimizi təmin edir
            // v6 xüsusiyyətinin dəstəyi ilə.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// *__, `black_box`-in edə biləcəyi şeylərdən maksimum dərəcədə bədbin olması üçün tərtibçiyə __* işarəsi verən bir şəxsiyyət funksiyası.
///
/// [`std::convert::identity`]-dən fərqli olaraq, bir Rust tərtibçisi, `black_box`-in Rust kodunun zəng kodunda təyin olunmamış davranış tətbiq etmədən icazə verilən hər hansı bir şəkildə `dummy` istifadə edə biləcəyini düşünməyə təşviq olunur.
///
/// Bu xüsusiyyət, `black_box`-ni müəyyən optimallaşdırmaların istənilmədiyi, məsələn, standartlar kimi kod yazmaq üçün faydalı edir.
///
/// Bununla birlikdə `black_box`-in yalnız "best-effort" əsasında təmin edildiyini (və yalnız verilə biləcəyini) unutmayın.Optimizasiyanı nə dərəcədə bloklaya biləcəyi, istifadə olunan platforma və kod-gen arxa hissəsinə görə dəyişə bilər.
/// Proqramlar heç bir şəkildə *düzgünlük* üçün `black_box`-a etibar edə bilməz.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Arqumenti bir şəkildə LLVM-nin nəzərdən keçirə bilməməsi üçün "use" etməliyik və bunu dəstəkləyən hədəflərdə bunu etmək üçün adətən daxili montajdan istifadə edə bilərik.
    // LLVM-nin satır içi montajın təfsiri, qara qutu olmasıdır.
    // Bu, ən böyük tətbiq deyil, çünki ehtimal ki, istədiyimizdən daha çoxunu optimallaşdırır, amma bu günə qədər kifayət qədər yaxşıdır.
    //
    //

    #[cfg(not(miri))] // Bu sadəcə bir işarədir, ona görə də Miri ilə keçmək yaxşıdır.
    // TƏHLÜKƏSİZLİK: satır içi montaj bir seçimdir.
    unsafe {
        // FIXME: `asm!` və digər arxitekturaları dəstəkləmədiyi üçün `asm!` istifadə edilə bilməz.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}