//! Libcore prelude
//!
//! Bu modul, libstd ilə əlaqəsi olmayan libcore istifadəçiləri üçün nəzərdə tutulmuşdur.
//! Bu modul, standart kitabxananın prelude ilə eyni qaydada `#![no_std]` istifadə edildikdə, standart olaraq idxal olunur.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Əsas prelude-nin 2015-ci il versiyası.
///
/// Daha çox məlumat üçün [module-level documentation](self)-ə baxın.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Əsas prelude-nin 2018 versiyası.
///
/// Daha çox məlumat üçün [module-level documentation](self)-ə baxın.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Əsas prelude-nin 2021 versiyası.
///
/// Daha çox məlumat üçün [module-level documentation](self)-ə baxın.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Daha çox şey əlavə edin.
}