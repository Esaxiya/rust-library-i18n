//! Diziler üçün `IntoIter` məxsus iteratoru təyin edir.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Əlavə dəyər [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Bu, təkrarladığımız bir sıra.
    ///
    /// `alive.start <= i < alive.end`-in hələ verilmədiyi və etibarlı bir sıra girişləri olduğu indeks `i` olan elementlər.
    /// `i < alive.start` və ya `i >= alive.end` indeksləri olan elementlər artıq verilmişdir və artıq əldə edilməməlidir!Bu ölü elementlər hətta tamamilə başlanğıcsız vəziyyətdə ola bilər!
    ///
    ///
    /// Yəni invariantlar bunlardır:
    /// - `data[alive]` canlıdır (yəni etibarlı elementləri ehtiva edir)
    /// - `data[..alive.start]` və `data[alive.end..]` ölmüşdür (yəni elementlər artıq oxunmuşdur və artıq toxunulmamalıdır!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data`-də hələ verilməmiş elementlər.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Verilən `array` üzərində yeni bir iterator yaradır.
    ///
    /// *Qeyd*: bu metod [`IntoIterator` is implemented for arrays][array-into-iter]-dən sonra future-də ləğv edilə bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` növü burada `&i32` əvəzinə `i32`-dir
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // TƏHLÜKƏSİZLİK: Buradakı dəyişdirmə əslində təhlükəsizdir.`MaybeUninit` sənədləri
        // promise:
        //
        // > `MaybeUninit<T>` eyni ölçüyə və düzəldilməsinə zəmanət verilir
        // > `T` olaraq.
        //
        // Sənədlər hətta `MaybeUninit<T>` massivindən `T` massivinə ötürülmə göstərir.
        //
        //
        // Bununla, bu başlanğıc invariantları təmin edir.

        // FIXME(LukasKalbertodt): const generics ilə işlədikdən sonra həqiqətən `mem::transmute`-dən burada istifadə edin:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // O vaxta qədər fərqli bir növ olaraq bitlik surəti yaratmaq üçün `mem::transmute_copy`-dən istifadə edə bilərik, sonra `array`-i unudulmaması üçün unuda bilərik.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Hələ verilməmiş bütün elementlərin dəyişməz dilimini qaytarır.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // TƏHLÜKƏSİZLİK: `alive` içərisindəki bütün elementlərin düzgün bir şəkildə başlatıldığını bilirik.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Hələ verilməmiş bütün elementlərin dəyişkən dilimini qaytarır.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // TƏHLÜKƏSİZLİK: `alive` içərisindəki bütün elementlərin düzgün bir şəkildə başlatıldığını bilirik.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Növbəti indeksi ön tərəfdən əldə edin.
        //
        // `alive.start`-i 1 artırmaq `alive` ilə bağlı dəyişməzliyi qoruyur.
        // Lakin bu dəyişiklikdən ötəri, qısa müddət ərzində canlı zona artıq `data[alive]` deyil, `data[idx..alive.end]`-dir.
        //
        self.alive.next().map(|idx| {
            // Dizini elementdən oxuyun.
            // TƏHLÜKƏSİZLİK: `idx`, keçmiş "alive" bölgəsinə daxil olan bir indeksdir
            // massiv.Bu elementi oxumaq deməkdir ki, `data[idx]` artıq ölmüş sayılır (yəni toxunmayın).
            // `idx` canlı zonanın başlanğıcı olduğundan, canlı bölgə yenidən `data[alive]` olur və bütün dəyişməzləri bərpa edir.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Növbəti indeksi arxadan alın.
        //
        // `alive.end`-i 1-ə endirmək, `alive` ilə bağlı dəyişməzliyi qoruyur.
        // Lakin bu dəyişiklikdən ötəri, qısa müddət ərzində canlı zona artıq `data[alive]` deyil, `data[alive.start..=idx]`-dir.
        //
        self.alive.next_back().map(|idx| {
            // Dizini elementdən oxuyun.
            // TƏHLÜKƏSİZLİK: `idx`, keçmiş "alive" bölgəsinə daxil olan bir indeksdir
            // massiv.Bu elementi oxumaq deməkdir ki, `data[idx]` artıq ölmüş sayılır (yəni toxunmayın).
            // `idx` canlı zonanın sonu olduğundan, canlı bölgə yenidən `data[alive]` olur və bütün dəyişməzləri bərpa edir.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // TƏHLÜKƏSİZLİK: Bu təhlükəsizdir: `as_mut_slice` tam alt dilimi qaytarır
        // hələ köçürülməmiş və atılmağa davam edən elementlərdən.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // 'Live.start <=dəyişməzliyi səbəbindən heç vaxt daşmayacaq
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// İterator həqiqətən doğru uzunluğu bildirir.
// "alive" elementlərinin sayı (hələ veriləcək) `alive` aralığının uzunluğudur.
// Bu aralığın uzunluğu `next` və ya `next_back`-də azalır.
// Bu metodlarda həmişə 1 azalır, ancaq `Some(_)` qaytarılacağı təqdirdə.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Qeyd edək ki, həqiqətən eyni canlı aralığa uyğun gəlməyimizə ehtiyac yoxdur, buna görə `self`-nin harada olmasından asılı olmayaraq 0 ofsetinə klonlaya bilərik.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Bütün canlı elementləri klonlaşdırın.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Yeni massivə bir klon yazın, sonra canlı aralığını yeniləyin.
            // panics-ni klonlaşdırsanız, əvvəlki maddələri düzgün şəkildə atacağıq.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Yalnız hələ verilməmiş elementləri yazdırın: verilmiş elementlərə daha çox daxil ola bilmərik.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}