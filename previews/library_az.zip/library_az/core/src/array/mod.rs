//! Müəyyən uzunluğa qədər sabit uzunluqlu massivlər üçün `Eq` kimi şeylərin tətbiqi.
//! Nəhayət, hər boyda ümumiləşdirməyi bacarmalıyıq.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T`-a istinadı 1 uzunluqlu bir sıra referansına çevirir (kopyalamadan).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // TƏHLÜKƏSİZLİK: `&T`-i `&[T; 1]`-ə çevirmək səsdir.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// Dəyişdirilə bilən bir referansı `T`-ə 1 uzunluqlu bir sıra üçün dəyişdirilə bilən bir referansa çevirir (kopyalamadan).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // TƏHLÜKƏSİZLİK: `&mut T`-i `&mut [T; 1]`-ə çevirmək səsdir.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// Utility trait yalnız sabit ölçülü massivlərdə tətbiq olunur
///
/// Bu trait, çoxlu metadata şişkinliyinə səbəb olmadan sabit ölçülü massivlərdə digər traits tətbiq etmək üçün istifadə edilə bilər.
///
/// İcazəçiləri sabit ölçülü massivlərlə məhdudlaşdırmaq üçün trait təhlükəli olaraq qeyd olunur.
/// Bu trait istifadəçisi, tətbiqedicilərin sabit ölçülü bir sıra yaddaşında dəqiq tərtibata sahib olduğunu düşünə bilər (məsələn, təhlükəli başlanğıc üçün).
///
///
/// Qeyd edək ki, traits [`AsRef`] və [`AsMut`] sabit ölçülü massivlər ola bilməyən növlər üçün oxşar metodlar təqdim edirlər.
/// İcraçılar əvəzinə həmin traits-yə üstünlük verməlidirlər.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// Dizini dəyişməz dilimə çevirir
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// Dizini dəyişdirilə bilən dilimə çevirir
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// Bir dilimdən bir massivə çevrilmə baş vermədikdə, səhv növü döndü.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // TƏHLÜKƏSİZ: tamam, çünki sadəcə uzunluğun uyğun olduğunu yoxladıq
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // TƏHLÜKƏSİZ: tamam, çünki sadəcə uzunluğun uyğun olduğunu yoxladıq
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: kod şişkinliyini azaltmaq üçün daha az əhəmiyyətli impllar buraxılır
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// [lexicographically](Ord#lexicographical-comparison) massivlərinin müqayisəsini həyata keçirir.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// Varsayılan impls const generics ilə edilə bilməz, çünki `[T; 0]` Varsayılanın tətbiq olunmasını tələb etmir və fərqli nömrələr üçün fərqli impl bloklarına sahib olmaq hələ dəstəklənmir.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// `self` ilə eyni ölçüdə, hər bir elementə sırasıyla `f` funksiyası tətbiq olunan bir sıra qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // TƏHLÜKƏSİZLİK: bu iteratorun tam olaraq `N` verəcəyini dəqiq bilirik
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// İki massivi tək cütlüklər sırasına daxil edin.
    ///
    /// `zip()` hər elementin birinci elementin birinci massivdən, ikinci elementin isə ikinci massivdən gəldiyi bir topl olduğu yeni bir sıra qaytarır.
    ///
    /// Başqa sözlə, iki silsiləni bir-birinə yığaraq tək birinə çevirir.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // TƏHLÜKƏSİZLİK: bu iteratorun tam olaraq `N` verəcəyini dəqiq bilirik
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// Bütün massivi ehtiva edən bir dilim qaytarır.`&s[..]`-ə bərabərdir.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Bütün serialı ehtiva edən dəyişdirilə bilən dilimi qaytarır.
    /// `&mut s[..]`-ə bərabərdir.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Hər bir elementi borc alır və `self` ilə eyni ölçüdə bir sıra istinadlar qaytarır.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// Bu metod, [`map`](#method.map) kimi digər metodlarla birləşdirildikdə xüsusilə faydalıdır.
    /// Bu yolla, elementləri `Copy` deyilsə, orijinal massivi hərəkət etdirməkdən qaçınmaq olar.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // Hələ də orijinal massivə daxil ola bilərik: köçürülməyib.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // TƏHLÜKƏSİZLİK: bu iteratorun tam olaraq `N` verəcəyini dəqiq bilirik
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// Hər bir elementi mütəmadi olaraq borc alır və `self` ilə eyni ölçülü bir sıra dəyişdirilə bilən istinadları qaytarır.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // TƏHLÜKƏSİZLİK: bu iteratorun tam olaraq `N` verəcəyini dəqiq bilirik
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `N` elementlərini `iter`-dən çəkir və onları bir sıra kimi qaytarır.
/// Təkrarlayıcı `N`-dən az məhsul verərsə, bu funksiya təyin olunmamış davranış nümayiş etdirir.
///
///
/// Daha çox məlumat üçün [`collect_into_array`]-ə baxın.
///
/// # Safety
///
/// `iter`-in ən az `N` məhsul verəcəyinə zəmanət vermək zəng edənə aiddir.
/// Bu vəziyyəti pozmaq, müəyyən edilməmiş davranışa səbəb olur.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: `TrustedLen` burada bir qədər təcrübədir.Bu yalnız bir
    // daxili funksiya, buna görə də bu əlaqənin pis bir fikir olduğu ortaya çıxdıqda çıxartmaqdan çəkinməyin.
    // Bu vəziyyətdə, altdakı `debug_assert!` sərhədini də götürməyi unutmayın!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // TƏHLÜKƏSİZLİK: funksiya müqaviləsi əhatə edir.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `N` elementlərini `iter`-dən çəkir və onları bir sıra kimi qaytarır.Təkrarlayıcı `N` məhsulundan daha az məhsul verərsə, `None` qaytarılır və artıq verilmiş bütün maddələr atılır.
///
/// Yineleyicinin dəyişdirilə bilən bir referans olaraq qəbul edildiyi və bu funksiya ən çox `N` dəfə `next` çağırdığı üçün, yineleyicidən sonra qalan elementləri almaq üçün istifadə edilə bilər.
///
///
/// `iter.next()` çaxnaşma halında, təkrarlayıcı tərəfindən verilmiş bütün maddələr atılır.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // TƏHLÜKƏSİZLİK: Boş bir sıra həmişə yaşayır və heç bir keçid dəyişkənliyi yoxdur.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // TƏHLÜKƏSİZLİK: bu xam dilim yalnız başlanğıc edilmiş obyektləri ehtiva edəcəkdir.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // TƏHLÜKƏSİZLİK: `guard.initialized` 0-da başlayır, birində bir artır
        // loop və loop N-ə çatdıqdan sonra ləğv edilir (bu, `array.len()`)-dir).
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // Bütün serialın başlanğıc olub olmadığını yoxlayın.
        if guard.initialized == N {
            mem::forget(guard);

            // TƏHLÜKƏSİZLİK: yuxarıdakı şərt bütün elementlərin olduğunu iddia edir
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // Buna yalnız iterator `guard.initialized` `N`-ə çatmadan tükənmiş olarsa çatır.
    //
    // Həm də `guard`-in artıq başlanğıc edilmiş bütün elementləri ataraq buraya atıldığını unutmayın.
    None
}