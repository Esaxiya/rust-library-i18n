#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Tərtibçi daxili tiplərinin tərtibatı üçün struktur təriflərini ehtiva edir.
//!
//! Xam nümayəndəlikləri birbaşa manipulyasiya etmək üçün təhlükəli kodda transmutes hədəfləri kimi istifadə edilə bilər.
//!
//!
//! Onların tərifi həmişə `rustc_middle::ty::layout`-də müəyyən edilmiş ABI ilə uyğun olmalıdır.
//!

/// `&dyn SomeTrait` kimi bir trait obyektinin təsviri.
///
/// Bu struktur `&dyn SomeTrait` və `Box<dyn AnotherTrait>` kimi tiplərlə eyni düzənə malikdir.
///
/// `TraitObject` layouts ilə uyğunlaşması təmin edilir, lakin trait obyektlərinin tipi deyil (məsələn, sahələrə `&dyn SomeTrait`-də birbaşa daxil olmaq mümkün deyil) və ya bu plana nəzarət etmir (tərifin dəyişdirilməsi `&dyn SomeTrait`-in tərtibatını dəyişdirməyəcəkdir).
///
/// Yalnız aşağı səviyyəli detalları idarə etməsi lazım olan təhlükəli kod tərəfindən istifadə üçün nəzərdə tutulmuşdur.
///
/// Bütün trait obyektlərinə ümumiyyətlə müraciət etməyin bir yolu yoxdur, buna görə də bu tip dəyərlər yaratmağın yeganə yolu [`std::mem::transmute`][transmute] kimi funksiyalardır.
/// Eynilə, `TraitObject` dəyərindən həqiqi bir trait obyekti yaratmağın yeganə yolu `transmute`-dir.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Bir trait obyektini uyğun olmayan tiplərlə sintez etmək-vtablın məlumat göstəricisinin göstərdiyi dəyərin tipinə uyğun gəlməməsi-müəyyən edilməmiş davranışa səbəb olması ehtimalı yüksəkdir.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // bir nümunə trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // tərtibçinin bir trait obyekti etməsinə icazə verin
/// let object: &dyn Foo = &value;
///
/// // xam təmsilçiliyə baxın
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // məlumat göstəricisi `value` adresidir
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // fərqli bir `i32`-yə işarə edərək, `object`-dən `i32` vtable istifadə etmək üçün diqqətli olmaqla, yeni bir obyekt qurun
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // sanki birbaşa `other_value`-dən bir trait obyekti tikmişik kimi işləməlidir
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}