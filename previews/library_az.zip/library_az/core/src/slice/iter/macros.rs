//! Dilim təkrarlayıcıları tərəfindən istifadə olunan makrolar.

// Boş və len daxilində çox böyük bir performans fərqi yaradır
macro_rules! is_empty {
    // Bir ZST iteratorunun uzunluğunu kodlaşdırma üsulumuz, bu həm ZST, həm də ZST üçün işləyir.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Bəzi məhdudiyyətlərdən xilas olmaq üçün (bax `position`) uzunluğu bir qədər gözlənilməz şəkildə hesablayırıq.
// (`Codegen/slice-position-bounds-check 'tərəfindən test edilmişdir.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // bəzən təhlükəli bir blokda istifadə olunuruq

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Bu _cannot_ `unchecked_sub` istifadə edir, çünki uzun ZST dilim təkrarlayıcılarının uzunluğunu təmsil etmək üçün bükülmədən asılıyıq.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // `start <= end` olduğunu bilirik, buna görə imzalanması lazım olan `offset_from`-dən daha yaxşı iş görə bilərik.
            // Müvafiq bayraqları burada quraşdıraraq LLVM-ə bunu deyə bilərik ki, bu da sərhəd yoxlamalarını aradan qaldırmağa kömək edir.
            // TƏHLÜKƏSİZLİK: Müxtəlif növə görə, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // LLVM-ə göstəricilərin tip ölçüsünün dəqiq bir çoxluğu ilə ayrı olduğunu söyləyərək `len() == 0`-i `(end - start) < size` əvəzinə `start == end`-ə endirə bilər.
            //
            // TƏHLÜKƏSİZLİK: Növü dəyişməz olaraq, göstəricilər elə hizalanır
            //         aralarındakı məsafə pointee ölçüsü qat olmalıdır
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` və `IterMut` təkrarlayıcılarının paylaşılan tərifi
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // İlk elementi qaytarır və iteratorun başlanğıcını 1-ə doğru irəliləyir.
        // Çizilmiş bir funksiyaya nisbətən performansı çox yaxşılaşdırır.
        // Təkrarlayıcı boş olmamalıdır.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Son elementi qaytarır və yineleyicinin ucunu 1 geri qaytarır.
        // Çizilmiş bir funksiyaya nisbətən performansı çox yaxşılaşdırır.
        // Təkrarlayıcı boş olmamalıdır.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // T bir ZST olduqda, iteratorun ucunu `n` ilə geriyə doğru hərəkət etdirərək iteratoru kiçirir.
        // `n` `self.len()`-dən çox olmamalıdır.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // İteratordan bir dilim yaratmaq üçün köməkçi funksiyası.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // TƏHLÜKƏSİZLİK: iterator göstərici ilə bir dilimdən yaradıldı
                // `self.ptr` və uzunluğu `len!(self)`.
                // Bu, `from_raw_parts` üçün bütün şərtlərin yerinə yetirilməsini təmin edir.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // İteratorun başlanğıcını `offset` elementləri ilə irəli sürmək və köhnə başlanğıcı geri qaytarmaq üçün köməkçi funksiyası.
            //
            // Təhlükəsiz deyil, çünki ofset `self.len()`-dən çox olmamalıdır.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // TƏHLÜKƏSİZLİK: zəng edən `offset`-in `self.len()`-dən çox olmamasına zəmanət verir,
                    // beləliklə bu yeni göstərici `self` içərisindədir və bununla da sıfır olmamasına zəmanət verilir.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // İteratorun ucunu `offset` elementləri ilə geriyə doğru hərəkət etdirmək və yeni ucunu geri qaytarmaq üçün köməkçi funksiyası.
            //
            // Təhlükəsiz deyil, çünki ofset `self.len()`-dən çox olmamalıdır.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // TƏHLÜKƏSİZLİK: zəng edən `offset`-in `self.len()`-dən çox olmamasına zəmanət verir,
                    // bir `isize`-i aşmamasına zəmanət verir.
                    // Bundan əlavə, yaranan göstərici `offset` üçün digər tələbləri yerinə yetirən `slice` sərhədindədir.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // dilimlərlə həyata keçirilə bilər, lakin bu, məhdudiyyətlərin qarşısını alır

                // TƏHLÜKƏSİZLİK: Bir dilimin başlanğıc göstəricisindən `assume` zəngləri təhlükəsizdir
                // sıfır olmamalıdır və ZST-lərin üstündəki dilimlərin də sıfır olmayan bir son göstəricisi olmalıdır.
                // Əvvəlcə təkrarlayıcının boş olub olmadığını yoxladığımızdan `next_unchecked!`-ə edilən zəng təhlükəsizdir.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Bu iterator artıq boşdur.
                    if mem::size_of::<T>() == 0 {
                        // Bunu belə etməliyik, çünki `ptr` heç vaxt 0 ola bilməz, ancaq `end` ola bilər (sarma səbəbindən).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // TƏHLÜKƏSİZLİK: T 0 ZST deyilsə son 0 ola bilməz, çünki ptr 0 deyil və end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // TƏHLÜKƏSİZLİK: Sərhəddəyik.`post_inc_start` hətta ZST-lər üçün də doğru şeyi edir.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // `try_fold` istifadə edən standart tətbiqetməni ləğv edirik, çünki bu sadə tətbiq daha az LLVM IR yaradır və tərtib etmək daha sürətli olur.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // `try_fold` istifadə edən standart tətbiqetməni ləğv edirik, çünki bu sadə tətbiq daha az LLVM IR yaradır və tərtib etmək daha sürətli olur.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // `try_fold` istifadə edən standart tətbiqetməni ləğv edirik, çünki bu sadə tətbiq daha az LLVM IR yaradır və tərtib etmək daha sürətli olur.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // `try_fold` istifadə edən standart tətbiqetməni ləğv edirik, çünki bu sadə tətbiq daha az LLVM IR yaradır və tərtib etmək daha sürətli olur.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // `try_fold` istifadə edən standart tətbiqetməni ləğv edirik, çünki bu sadə tətbiq daha az LLVM IR yaradır və tərtib etmək daha sürətli olur.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // `try_fold` istifadə edən standart tətbiqetməni ləğv edirik, çünki bu sadə tətbiq daha az LLVM IR yaradır və tərtib etmək daha sürətli olur.
            // Ayrıca, `assume` sərhəd yoxlanışından yayınır.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // TƏHLÜKƏSİZLİK: dövr dəyişməzliyi ilə sərhəddə olmağımıza zəmanət verilir:
                        // `i >= n`, `self.next()` `None` qaytarır və döngə pozulur.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // `try_fold` istifadə edən standart tətbiqetməni ləğv edirik, çünki bu sadə tətbiq daha az LLVM IR yaradır və tərtib etmək daha sürətli olur.
            // Ayrıca, `assume` sərhəd yoxlanışından yayınır.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // TƏHLÜKƏSİZLİK: `i`, `n`-də başladığı üçün `n`-dən aşağı olmalıdır
                        // və yalnız azalır.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // TƏHLÜKƏSİZLİK: zəng edən `i`-in hüdudlarında olduğuna zəmanət verməlidir
                // əsas dilimdir, buna görə `i` bir `isize`-i aşa bilməz və qaytarılmış istinadların dilim elementinə istinad etməsi və bununla da etibarlı olmasına zəmanət verilir.
                //
                // Ayrıca arayanın bir daha eyni indekslə çağrılmamağımızı və bu sublice daxil olacaq başqa metodların çağrılmadığına zəmanət verdiyini, buna görə qaytarılmış referansın dəyişdirilə biləcəyi halında etibarlı olduğunu unutmayın.
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // dilimlərlə həyata keçirilə bilər, lakin bu, məhdudiyyətlərin qarşısını alır

                // TƏHLÜKƏSİZLİK: `assume` zəngləri təhlükəsizdir, çünki bir dilimin başlanğıc göstəricisi sıfır olmalıdır,
                // və ZST olmayan dilimlərin də boş olmayan bir göstəricisi olmalıdır.
                // Əvvəlcə təkrarlayıcının boş olub olmadığını yoxladığımızdan `next_back_unchecked!`-ə edilən zəng təhlükəsizdir.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Bu iterator artıq boşdur.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // TƏHLÜKƏSİZLİK: Sərhəddəyik.`pre_dec_end` hətta ZST-lər üçün də doğru şeyi edir.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}