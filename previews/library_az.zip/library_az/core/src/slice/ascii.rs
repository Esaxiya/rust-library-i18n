//! ASCII `[u8]` üzərində əməliyyatlar.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Bu dilimdəki bütün baytların ASCII aralığında olub olmadığını yoxlayır.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// İki dilimin ASCII halda həssas olmayan bir uyğunluq olduğunu yoxlayır.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ilə eyni, ancaq müvəqqəti olaraq ayrılmadan və kopyalanmadan.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Bu dilimi yerindəki ASCII böyük hərfinə bərabərləşdirir.
    ///
    /// 'a'-'z' arasında ASCII hərfləri 'A'-'Z' arasında eşleştirilir, lakin ASCII olmayan hərflər dəyişdirilmir.
    ///
    /// Mövcud dəyərini dəyişdirmədən yeni bir üst səviyyəli dəyəri qaytarmaq üçün [`to_ascii_uppercase`] istifadə edin.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Bu dilimi yerindəki ASCII kiçik hərfinə bərabərləşdirir.
    ///
    /// 'A'-'Z' arasında ASCII hərfləri 'a'-'z' arasında eşleştirilir, lakin ASCII olmayan hərflər dəyişdirilmir.
    ///
    /// Mövcud dəyərini dəyişdirmədən yeni kiçik bir dəyər qaytarmaq üçün [`to_ascii_lowercase`] istifadə edin.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` sözündə hər hansı bir bayt nonascii (>=128) olduqda `true` qaytarır.
/// utf8 doğrulaması üçün oxşar bir şey edən `../str/mod.rs`-dən Snarfed.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Bayt-a-time əməliyyatlar əvəzinə vaxtında istifadə əməliyyatları (mümkün olduqda) istifadə edəcək optimal ASCII testi.
///
/// Burada istifadə etdiyimiz alqoritm olduqca sadədir.`s` çox qısadırsa, yalnız hər baytı yoxlayırıq və bununla da bitərik.Əks təqdirdə:
///
/// - Hələliksiz bir yüklə ilk sözü oxuyun.
/// - İşarəni düzəldin, sonrakı sözləri hizalanmış yüklərlə sona qədər oxuyun.
/// - `s`-dən son `usize`-i düzəldilməmiş bir yüklə oxuyun.
///
/// Bu yüklərdən hər hansı biri üçün `contains_nonascii` (above)-nin doğru olduğu bir şey çıxarsa, cavabın yalan olduğunu bilirik.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Hər dəfə bir-bir həyata keçirməkdən bir şey əldə etməyəcəyiksə, yenidən skaler döngəsinə qayıdın.
    //
    // Bunu, `size_of::<usize>()` in `usize` üçün kifayət qədər uyğunlaşmadığı arxitekturalar üçün də edirik, çünki bu qəribə bir edge davasıdır.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Həmişə ilk sözü düzəldilməmiş oxuyuruq, yəni `align_offset`-dir
    // 0, hizalanmış oxu üçün eyni dəyəri yenidən oxuduq.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // TƏHLÜKƏSİZLİK: `len < USIZE_SIZE`-i yuxarıda təsdiq edirik.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Yuxarıda bir qədər dolayısı ilə yoxladıq.
    // `offset_to_aligned` in ya `align_offset` ya da `USIZE_SIZE` olduğunu unutmayın, hər ikisi də yuxarıda açıq şəkildə yoxlanılmışdır.
    //
    debug_assert!(offset_to_aligned <= len);

    // TƏHLÜKƏSİZLİK: word_ptr oxumaq üçün istifadə etdiyimiz (düzgün şəkildə hizalanmış) usize ptr-dir
    // dilimin orta parçası.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` loop sonu yoxlamaları üçün istifadə olunan `word_ptr`-in bayt indeksidir.
    let mut byte_pos = offset_to_aligned;

    // Paranoia, hizalanma haqqında yoxlayın, çünki bir dəstə hizalanmamış yük edəcəyik.
    // Təcrübədə `align_offset`-də bir səhvin qarşısını almaq qeyri-mümkün olmalıdır.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Kuyruğun həmişə əlavə olaraq branch `byte_pos == len`-ə qədər ən çox `usize` olmasını təmin etmək üçün sonradan quyruq yoxlanışında ediləcək son hizalanmış söz xaric olmaqla, son hizalanmış sözə qədər sonrakı sözləri oxuyun.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Oxunuşun sərhəddə olduğunu ağılla yoxlayın
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Və `byte_pos` ilə bağlı fərziyyələrimizi saxlayır.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // TƏHLÜKƏSİZLİK: `word_ptr`-in düzgün bir şəkildə hizalandığını bilirik (çünki
        // `align_offset`) və `word_ptr` ilə son arasında kifayət qədər bayt olduğumuzu bilirik
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // TƏHLÜKƏSİZLİK: `byte_pos <= len - USIZE_SIZE` olduğunu bilirik, yəni o deməkdir
        // bu `add`-dən sonra `word_ptr` ən çox sona çatacaq.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Həqiqətən yalnız bir `usize` qaldığına əmin olmaq üçün sağlamlığı yoxlayın.
    // Buna döngü şərtimiz zəmanət verməlidir.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // TƏHLÜKƏSİZLİK: Bu, başlanğıcda yoxladığımız `len >= USIZE_SIZE`-yə əsaslanır.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}