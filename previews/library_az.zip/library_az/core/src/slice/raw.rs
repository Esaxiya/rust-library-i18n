//! `&[T]` və `&mut [T]` yaratmaq üçün pulsuz funksiyalar.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Bir göstəricidən və bir uzunluqdan bir dilim meydana gətirir.
///
/// `len` arqumenti, bayt sayı deyil,**element** sayıdır.
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `data` `len * mem::size_of::<T>()` çox bayt üçün oxunması üçün [valid] olmalıdır və düzgün hizalanmalıdır.Bu xüsusən:
///
///     * Bu dilimin bütün yaddaş aralığı ayrılmış bir obyekt daxilində olmalıdır!
///       Dilimlər heç vaxt ayrılmış bir çox obyekt arasında yayıla bilməz.Bunu nəzərə almamaq üçün səhv bir nümunə üçün [below](#incorrect-usage)-ə baxın.
///     * `data` sıfır uzunluqlu dilimlər üçün də sıfır olmamalıdır.
///     Bunun bir səbəbi, enum layout optimallaşdırmalarının digər məlumatlardan fərqləndirmək üçün hizalanmış və boş olmayan istinadlara (istənilən uzunluqdakı dilimlər daxil olmaqla) etibar edə bilməsi.
///     [`NonNull::dangling()`] istifadə edərək sıfır uzunluqlu dilimlər üçün `data` kimi istifadə edilə bilən bir göstərici əldə edə bilərsiniz.
///
/// * `data` `T` tipli ardıcıl düzgün başlanğıc edilmiş dəyərlərə işarə etməlidir.
///
/// * Döndürülmüş dilimin istinad etdiyi yaddaş, `UnsafeCell` içərisi xaricində `'a` ömrü boyu mutasiya edilməməlidir.
///
/// * Dilimin ümumi ölçüsü `len * mem::size_of::<T>()`, `isize::MAX`-dən böyük olmamalıdır.
///   [`pointer::offset`] təhlükəsizlik sənədlərinə baxın.
///
/// # Caveat
///
/// Geri qaytarılan dilim üçün istifadə müddəti açıqlanır.
/// Təsadüfən sui-istifadənin qarşısını almaq üçün, dilim üçün bir ana dəyərin ömrünü götürən bir köməkçi funksiyası təmin etmək və ya açıq bir açıqlama ilə ömrünü hansı mənbə ömrünün etibarlı olduğu ilə bağlamaq təklif olunur.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // bir element üçün bir dilim göstərin
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Yanlış istifadə
///
/// Aşağıdakı `join_slices` funksiyası **səssiz** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Yuxarıdakı iddia `fst` və `snd`-in bitişik olmasını təmin edir, lakin bunlar hələ də _different allocated objects_ içərisində ola bilər, bu halda bu dilimin yaradılması qeyri-müəyyən davranışdır.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` və `b` fərqli ayrılmış obyektlərdir ...
///     let a = 42;
///     let b = 27;
///     // ... buna baxmayaraq yaddaşda ardıcıl olaraq yerləşdirilə bilər: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // TƏHLÜKƏSİZLİK: zəng edən `from_raw_parts` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Dəyişdirilə bilən bir dilimin qaytarılması istisna olmaqla, [`from_raw_parts`] ilə eyni funksiyanı yerinə yetirir.
///
/// # Safety
///
/// Aşağıdakı şərtlərdən biri pozulduqda davranış müəyyənləşdirilmir:
///
/// * `data` həm oxumaq, həm də `len * mem::size_of::<T>()` çox bayt üçün yazmaq üçün [valid] olmalıdır və düzgün hizalanmalıdır.Bu xüsusən:
///
///     * Bu dilimin bütün yaddaş aralığı ayrılmış bir obyekt daxilində olmalıdır!
///       Dilimlər heç vaxt bir çox ayrılmış obyekt arasında yayıla bilməz.
///     * `data` sıfır uzunluqlu dilimlər üçün də sıfır olmamalıdır.
///     Bunun bir səbəbi, enum layout optimallaşdırmalarının digər məlumatlardan fərqləndirmək üçün hizalanmış və boş olmayan istinadlara (istənilən uzunluqdakı dilimlər daxil olmaqla) etibar edə bilməsi.
///
///     [`NonNull::dangling()`] istifadə edərək sıfır uzunluqlu dilimlər üçün `data` kimi istifadə edilə bilən bir göstərici əldə edə bilərsiniz.
///
/// * `data` `T` tipli ardıcıl düzgün başlanğıc edilmiş dəyərlərə işarə etməlidir.
///
/// * Geri qaytarılan dilimin istinad etdiyi yaddaşa, `'a` ömrü boyu başqa bir göstərici vasitəsi ilə (qaytarma dəyərindən alınmayan) daxil edilməməlidir.
///   Həm oxumaq, həm də yazmaq qadağandır.
///
/// * Dilimin ümumi ölçüsü `len * mem::size_of::<T>()`, `isize::MAX`-dən böyük olmamalıdır.
///   [`pointer::offset`] təhlükəsizlik sənədlərinə baxın.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // TƏHLÜKƏSİZLİK: zəng edən `from_raw_parts_mut` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// T-ə istinadı 1 uzunluqlu bir dilimə çevirir (kopyalamadan).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// T-ə istinadı 1 uzunluqlu bir dilimə çevirir (kopyalamadan).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}