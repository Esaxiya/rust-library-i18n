//! Dilim çeşidlənməsi
//!
//! Bu modul, Orson Peters 'in nümunəsini məğlub edən sürətli döyüşə əsaslanan bir çeşidləmə alqoritmini ehtiva edir: <https://github.com/orlp/pdqsort>
//!
//!
//! Qeyri-sabit çeşidləmə libcore ilə uyğundur, çünki sabit çeşidləmə tətbiqimizdən fərqli olaraq yaddaş ayırmır.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Düşdükdə, `src`-dən `dest`-ə kopyalanır.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // TƏHLÜKƏSİZLİK: Bu köməkçi sinifdir.
        //          Xahiş edirəm düzgünlüyü üçün istifadəsinə baxın.
        //          Yəni, `src` və `dst` in `ptr::copy_nonoverlapping`-in tələb etdiyi kimi üst-üstə düşməməsinə əmin olmaq lazımdır.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// İlk elementi daha böyük və ya bərabər bir elementlə qarşılaşana qədər sağa keçir.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // TƏHLÜKƏSİZLİK: Aşağıdakı təhlükəli əməliyyatlar əlaqəli yoxlama olmadan indeksləşdirməyi əhatə edir (`get_unchecked` və `get_unchecked_mut`)
    // və (`ptr::copy_nonoverlapping`) yaddaşının kopyalanması.
    //
    // a.İndeksləşdirmə:
    //  1. Dizinin ölçüsünü>=2 olaraq yoxladıq.
    //  2. Etəcəyimiz bütün indekslər həmişə ən çox {0 <= index < len} arasındadır.
    //
    // b.Yaddaşın surəti
    //  1. Etibarlı olmasına zəmanət verilən istinadlara istinadlar əldə edirik.
    //  2. Bunlar üst-üstə düşə bilməzlər, çünki dilimin indekslərinin fərqli göstəricilərini əldə edirik.
    //     Yəni `i` və `i-1`.
    //  3. Dilim düzgün bir şəkildə hizalanırsa, elementlər düzgün bir şəkildə hizalanır.
    //     Dilimin düzgün bir şəkildə hizalandığından əmin olmaq zəng edənin məsuliyyətidir.
    //
    // Daha ətraflı məlumat üçün aşağıdakı şərhlərə baxın.
    unsafe {
        // İlk iki element sıradan çıxıbsa ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // İlk elementi yığın ayrılmış dəyişənə oxuyun.
            // Aşağıdakı bir müqayisə əməliyyatı panics olarsa, `hole` düşər və elementi yenidən dilimə yazar.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // 'İ`-ci elementi bir yerə sola aparın, beləliklə dəliyi sağa keçirin.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` düşür və beləliklə `tmp`-i `v`-də qalan çuxura köçürür.
        }
    }
}

/// Kiçik və ya bərabər bir elementlə qarşılaşana qədər son elementi sola keçir.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // TƏHLÜKƏSİZLİK: Aşağıdakı təhlükəli əməliyyatlar əlaqəli yoxlama olmadan indeksləşdirməyi əhatə edir (`get_unchecked` və `get_unchecked_mut`)
    // və (`ptr::copy_nonoverlapping`) yaddaşının kopyalanması.
    //
    // a.İndeksləşdirmə:
    //  1. Dizinin ölçüsünü>=2 olaraq yoxladıq.
    //  2. Etəcəyimiz bütün indekslər həmişə ən çox `0 <= index < len-1` arasındadır.
    //
    // b.Yaddaşın surəti
    //  1. Etibarlı olmasına zəmanət verilən istinadlara istinadlar əldə edirik.
    //  2. Bunlar üst-üstə düşə bilməzlər, çünki dilimin indekslərinin fərqli göstəricilərini əldə edirik.
    //     Yəni `i` və `i+1`.
    //  3. Dilim düzgün bir şəkildə hizalanırsa, elementlər düzgün bir şəkildə hizalanır.
    //     Dilimin düzgün bir şəkildə hizalandığından əmin olmaq zəng edənin məsuliyyətidir.
    //
    // Daha ətraflı məlumat üçün aşağıdakı şərhlərə baxın.
    unsafe {
        // Son iki element sıradan çıxıbsa ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Son elementi yığın ayrılmış dəyişənə oxuyun.
            // Aşağıdakı bir müqayisə əməliyyatı panics olarsa, `hole` düşər və elementi yenidən dilimə yazar.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // 'İ`-ci elementi bir yerə sağa aparın, beləliklə dəliyi sola çevirin.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` düşür və beləliklə `tmp`-i `v`-də qalan çuxura köçürür.
        }
    }
}

/// Sifarişdən kənar olan bir neçə elementi ətrafa dəyişərək bir dilimi qismən sıralayır.
///
/// Dilim sonunda sıralanırsa `true` qaytarır.Bu funksiya *O*(*n*) ən pis vəziyyətdədir.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Sürüşəcək bitişik sıradan kənar cütlərin maksimum sayı.
    const MAX_STEPS: usize = 5;
    // Dilim bundan daha qısadırsa, heç bir element dəyişdirməyin.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // TƏHLÜKƏSİZLİK: Artıq açıq şəkildə `i < len` ilə əlaqəli yoxlama aparmışıq.
        // Bütün sonrakı indekslərimiz yalnız `0 <= index < len` aralığındadır
        unsafe {
            // Qonşu sıradan kənar elementlərin növbəti cütünü tapın.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Bitirdikmi?
        if i == len {
            return true;
        }

        // Performans dəyəri olan elementləri qısa massivlərə keçirməyin.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Tapılan cüt elementi dəyişdirin.Bu onları düzgün sıraya qoyur.
        v.swap(i - 1, i);

        // Kiçik elementi sola sürüşdürün.
        shift_tail(&mut v[..i], is_less);
        // Daha böyük elementi sağa sürüşdürün.
        shift_head(&mut v[i..], is_less);
    }

    // Məhdud sayda pillədə dilimi sıralamağı bacarmadım.
    false
}

/// Ən pis vəziyyətdə olan *O*(*n*^ 2) olan yerləşdirmə növündən istifadə edərək bir dilimi sıralayır.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// *O*(*n*\*log(* n*)) ən pis vəziyyətdə olmasını təmin edən yığın limanından istifadə edərək `v`-i sıralayır.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Bu ikili yığın dəyişməz `parent >= child`-yə hörmət edir.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` uşaqları:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Böyük uşağı seçin.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // İnvariant `node`-də saxlayırsa dayandırın.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // `node`-i daha böyük uşaqla dəyişdirin, bir addım aşağı hərəkət edin və ələkləməyə davam edin.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Xətti vaxtda yığın.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Yığandan maksimum elementləri açın.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v`-i `pivot`-dən kiçik elementlərə ayırır, ardından `pivot`-dən böyük və ya bərabər olan elementləri izləyir.
///
///
/// `pivot`-dən kiçik element sayını qaytarır.
///
/// Bölmə bölmə əməliyyatlarının dəyərini minimuma endirmək üçün blok-blok həyata keçirilir.
/// Bu fikir [BlockQuicksort][pdf] sənədində təqdim olunur.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Tipik bir blokdakı elementlərin sayı.
    const BLOCK: usize = 128;

    // Bölmə alqoritmi tamamlanana qədər aşağıdakı addımları təkrarlayır:
    //
    // 1. Pivotdan daha böyük və ya bərabər elementləri təyin etmək üçün sol tərəfdən bir blok izi çəkin.
    // 2. Pivotdan kiçik elementləri təyin etmək üçün sağ tərəfdən bir blok izi çəkin.
    // 3. Müəyyən edilmiş elementləri sol və sağ tərəf arasında dəyişdirin.
    //
    // Bir element elementi üçün aşağıdakı dəyişənləri saxlayırıq:
    //
    // 1. `block` - Blokdakı elementlərin sayı.
    // 2. `start` - `offsets` massivinə göstəriciyə başlayın.
    // 3. `end` - Göstəricini `offsets` massivinə daxil edin.
    // 4. `ofset, blok içərisindəki sıradan çıxmış elementlərin göstəriciləri.

    // Sol tərəfdəki cari blok (`l`-dən `l.add(block_l)`)-ə qədər.
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Sağ tərəfdəki mövcud blok (`r.sub(block_r)` to `r`)-dən.
    // TƏHLÜKƏSİZLİK: .add() sənədlərində `vec.as_ptr().add(vec.len())`-in hər zaman təhlükəsiz olduğu xüsusi qeyd edilir
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: VLA aldığımızda `min(v.len() uzunluğunda bir sıra yaratmağa çalışın, 2 * BLOCK) "daha çox
    // `BLOCK` uzunluğunda iki sabit ölçülü massivdən daha çox.VLA'lar daha önbelleğe qənaətli ola bilər.

    // `l` (inclusive) və `r` (exclusive) göstəriciləri arasındakı element sayını qaytarır.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // `l` və `r` çox yaxınlaşdıqda blok-blok bölmə ilə işimiz bitdi.
        // Arada qalan elementləri bölmək üçün biraz yamaq işləri edirik.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Qalan elementlərin sayı (hələ də pivotla müqayisə olunmur).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Blok ölçülərini sol və sağ blokun üst-üstə düşməməsi üçün tənzimləyin, lakin qalan boşluğu örtmək üçün mükəmməl bir şəkildə düzəldin.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // `block_l` elementlərini sol tərəfdən izləyin.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // TƏHLÜKƏSİZLİK: Aşağıdakı təhlükəsizlik əməliyyatları `offset`-in istifadəsini əhatə edir.
                //         Funksiyanın tələb etdiyi şərtlərə görə onları təmin edirik, çünki:
                //         1. `offsets_l` yığın ayrılmış və beləliklə ayrı ayrılmış obyekt hesab olunur.
                //         2. `is_less` funksiyası bir `bool` qaytarır.
                //            `bool` tökmə heç vaxt `isize`-i aşmayacaq.
                //         3. `block_l`-in `<= BLOCK` olacağına zəmanət verdik.
                //            Üstəlik, `end_l` əvvəlcə yığında elan edilmiş `offsets_` başlanğıc göstəricisinə qoyulmuşdu.
                //            Beləliklə, ən pis vəziyyətdə də (`is_less`-in bütün çağırışları yalan olur) bilirik ki, sonu ən çox 1 bayt keçəcəyik.
                //        Buradakı bir başqa təhlükəsizlik əməliyyatı `elem`-dən imtina etməkdir.
                //        Bununla birlikdə, `elem` əvvəlcə hər zaman etibarlı olan dilim üçün başlanğıc göstəricisi idi.
                unsafe {
                    // Budaqsız müqayisə.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // `block_r` elementlərini sağ tərəfdən izləyin.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // TƏHLÜKƏSİZLİK: Aşağıdakı təhlükəsizlik əməliyyatları `offset`-in istifadəsini əhatə edir.
                //         Funksiyanın tələb etdiyi şərtlərə görə onları təmin edirik, çünki:
                //         1. `offsets_r` yığın ayrılmış və beləliklə ayrı ayrılmış obyekt hesab olunur.
                //         2. `is_less` funksiyası bir `bool` qaytarır.
                //            `bool` tökmə heç vaxt `isize`-i aşmayacaq.
                //         3. `block_r`-in `<= BLOCK` olacağına zəmanət verdik.
                //            Üstəlik, `end_r` əvvəlcə yığında elan edilmiş `offsets_` başlanğıc göstəricisinə qoyulmuşdu.
                //            Beləliklə, ən pis vəziyyətdə də (`is_less`-in bütün çağırışları doğru olur) bilirik ki, sonu ən çox 1 bayt keçəcəyik.
                //        Buradakı bir başqa təhlükəsizlik əməliyyatı `elem`-dən imtina etməkdir.
                //        Bununla birlikdə, `elem` əvvəlcə `1 *sizeof(T)` sonundan keçdi və biz ona çatmadan `1* sizeof(T)` ilə azaldıq.
                //        Üstəlik, `block_r`-in `BLOCK`-dən az olduğu iddia edildi və bu səbəbdən `elem` dilimin əvvəlinə işarə edəcək.
                unsafe {
                    // Budaqsız müqayisə.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Sol və sağ tərəfi dəyişdirmək üçün sıradan çıxmış elementlərin sayı.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // O vaxt bir cütü dəyişdirmək əvəzinə, periklik permütasiya etmək daha səmərəlidir.
            // Bu, dəyişdirmə ilə qətiliklə ekvivalent deyil, daha az yaddaş əməliyyatlarından istifadə edərək oxşar nəticə verir.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Sol blokdakı bütün sıradan çıxmış elementlər köçürüldü.Növbəti bloka keçin.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Sağ blokdakı bütün sıradan çıxmış elementlər köçürüldü.Əvvəlki bloka keçin.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // İndi qalanı, dəyişdirilməli, sıradan çıxmış elementləri olan ən çox bir blokdur (ya solda, ya da sağda).
    // Bu cür qalan elementlər öz blokları içərisində sona qədər dəyişdirilə bilər.
    //

    if start_l < end_l {
        // Sol blok qalır.
        // Qalan sıradan çıxmış elementləri ən sağa aparın.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Sağ blok qalır.
        // Qalan sıradan çıxmış elementləri ən sola aparın.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Başqa bir iş görməyəcəyik.
        width(v.as_mut_ptr(), l)
    }
}

/// `v`-i `v[pivot]`-dən kiçik elementlərə ayırır, ardından `v[pivot]`-dən böyük və ya bərabər olan elementləri izləyir.
///
///
/// Bir nişanı qaytarır:
///
/// 1. `v[pivot]`-dən kiçik elementlərin sayı.
/// 2. `v` artıq bölünmüşsə doğrudur.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Pivotu dilimin əvvəlinə qoyun.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Səmərəlilik üçün pivotu bir yığın ayrılmış dəyişənə oxuyun.
        // Aşağıdakı bir müqayisə əməliyyatı panics olarsa, pivot avtomatik olaraq dilimə yazılacaqdır.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // İlk sıradan çıxmış elementləri tapın.
        let mut l = 0;
        let mut r = v.len();

        // TƏHLÜKƏSİZLİK: Aşağıdakı təhlükəsizlik, bir dizinin indeksləşdirilməsini əhatə edir.
        // Birincisi üçün: Artıq burada `l < r` ilə sərhədləri yoxlayırıq.
        // İkincisi üçün: Başlanğıcda `l == 0` və `r == v.len()` var və hər indeksləmə əməliyyatında `l < r`-i yoxladıq.
        //                     Buradan bilirik ki, `r` birincisindən etibarlı olduğu göstərilən ən az `r == l` olmalıdır.
        unsafe {
            // Pivotdan böyük və ya bərabər olan ilk elementi tapın.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Pivotdan kiçik olan son elementi tapın.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` əhatə dairəsindən çıxır və pivotu (yığın ayrılmış dəyişəndir) yenidən əvvəlki dilimə yazır.
        // Bu addım təhlükəsizliyin təmin edilməsində vacibdir!
        //
    };

    // Pivotu iki bölmə arasına qoyun.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// `v`-i `v[pivot]`-ə bərabər elementlərə ayırın və ardından `v[pivot]`-dən böyük elementlər.
///
/// Pivota bərabər element sayını qaytarır.
/// `v`-də pivotdan kiçik elementlərin olmadığı ehtimal olunur.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Pivotu dilimin əvvəlinə qoyun.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Səmərəlilik üçün pivotu bir yığın ayrılmış dəyişənə oxuyun.
    // Aşağıdakı bir müqayisə əməliyyatı panics olarsa, pivot avtomatik olaraq dilimə yazılacaqdır.
    // TƏHLÜKƏSİZLİK: Buradakı göstərici bir dilimə istinaddan əldə edildiyi üçün etibarlıdır.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // İndi dilimi bölün.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // TƏHLÜKƏSİZLİK: Aşağıdakı təhlükəsizlik, bir dizinin indeksləşdirilməsini əhatə edir.
        // Birincisi üçün: Artıq burada `l < r` ilə sərhədləri yoxlayırıq.
        // İkincisi üçün: Başlanğıcda `l == 0` və `r == v.len()` var və hər indeksləmə əməliyyatında `l < r`-i yoxladıq.
        //                     Buradan bilirik ki, `r` birincisindən etibarlı olduğu göstərilən ən az `r == l` olmalıdır.
        unsafe {
            // Pivotdan böyük olan ilk elementi tapın.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Pivona bərabər olan son elementi tapın.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Bitirdikmi?
            if l >= r {
                break;
            }

            // Tapılan sıradan çıxmış cüt elementi dəyişdirin.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Pivota bərabər `l` elementləri tapdıq.Pivotun özü üçün hesaba 1 əlavə edin.
    l + 1

    // `_pivot_guard` əhatə dairəsindən çıxır və pivotu (yığın ayrılmış dəyişəndir) yenidən əvvəlki dilimə yazır.
    // Bu addım təhlükəsizliyin təmin edilməsində vacibdir!
}

/// Quicksort-da balanssız arakəsmələrə səbəb ola biləcək naxışları qırmaq üçün bəzi elementləri ətrafa səpələyir.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // George Marsaglia tərəfindən hazırlanan "Xorshift RNGs" kağızından yalançı təsadüfi say generatoru.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Bu ədədi modulla təsadüfi ədədləri götürün.
        // `len` `isize::MAX`-dən böyük olmadığı üçün nömrə `usize`-ə uyğundur.
        let modulus = len.next_power_of_two();

        // Bəzi əsas namizədlər bu indeksin yaxınlığında olacaq.Gəlin onları randomizə edək.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Təsadüfi bir sayda `len` modulu yaradın.
            // Bununla birlikdə, bahalı əməliyyatlardan qaçmaq üçün əvvəlcə iki güclü bir modul alırıq və sonra `[0, len - 1]` aralığına sığana qədər `len` azalırıq.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len`-dən az olmasına zəmanət verilir.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v`-də bir pivot seçir və dilim çox güman ki, çeşidlənibsə indeks və `true`-i qaytarır.
///
/// `v`-dəki elementlər prosesdə yenidən sıralana bilər.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Median-of-median metodu seçmək üçün minimum uzunluq.
    // Daha qısa dilimlər üçdə ortalama metoddan istifadə edir.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Bu funksiyada yerinə yetirilə bilən maksimum svop sayı.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Bir yaxınlıq seçəcəyimiz üç indeks.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // İndeksləri çeşidləyərkən yerinə yetirəcəyimiz svopların ümumi sayını hesablayır.
    let mut swaps = 0;

    if len >= 8 {
        // `v[a] <= v[b]` göstəricilərini dəyişdirir.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // `v[a] <= v[b] <= v[c]` göstəricilərini dəyişdirir.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` ortalamasını tapır və indeksi `a`-ə saxlayır.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a`, `b` və `c` məhəllələrində medianları tapın.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a`, `b` və `c` arasındakı medianı tapın.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Maksimum svop sayı yerinə yetirildi.
        // Dilim azalan və ya əsasən azalan şanslardır, buna görə də geri dönmək, daha sürətli sıralamağa kömək edəcəkdir.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v`-i rekursiv olaraq sıralayır.
///
/// Dilimin orijinal massivdə sələfi varsa, `pred` olaraq təyin olunur.
///
/// `limit` `heapsort`-ə keçmədən əvvəl icazə verilən balanssız bölmələrin sayıdır.
/// Sıfır olarsa, bu funksiya dərhal yığın mərkəzinə keçir.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Bu uzunluğa qədər dilimlər yerləşdirmə növündən istifadə edərək çeşidlənir.
    const MAX_INSERTION: usize = 20;

    // Son bölmə məqbul dərəcədə balanslı olsaydı doğrudur.
    let mut was_balanced = true;
    // Son bölüşdürmə elementləri qarışdırmırsa doğrudur (dilim artıq bölünmüşdür).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Çox qısa dilimlər yerləşdirmə növündən istifadə edərək çeşidlənir.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Çox pis pivot seçimi edildikdə, ən pis vəziyyətdə olan `O(n * log(n))`-yə zəmanət vermək üçün sadəcə yığma sıraya qayıt.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Son bölüşdürmə balanssız idisə, ətrafdakı bəzi elementləri qarışdıraraq dilimdəki qəlibləri qırmağa çalışın.
        // İnşallah bu dəfə daha yaxşı bir dönüş seçəcəyik.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Bir pivot seçin və dilimin artıq çeşidləndiyini təxmin etməyə çalışın.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Son bölmə düzgün bir şəkildə balanslaşdırılıb və elementləri qarışdırmırsa və pivot seçimi proqnozlaşdırırsa, dilim artıq sıralanır ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Sifarişdən çıxmış bir neçə elementi müəyyənləşdirməyə və onları düz mövqelərə dəyişdirməyə çalışın.
            // Dilim tamamilə sıralanırsa, işimiz bitdi.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Seçilmiş pivot sələfə bərabərdirsə, dilimdəki ən kiçik elementdir.
        // Dilimi pivotdan daha böyük elementlərə bölün.
        // Bu hal ümumiyyətlə dilimdə bir çox təkrarlanan element olduqda vurulur.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Pivotdan daha böyük elementləri sıralamağa davam edin.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Dilimi bölün.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Dilimi `left`, `pivot` və `right`-ə bölün.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Yalnız rekursiv zənglərin sayını minimuma endirmək və daha az yığın boşluğu istehlak etmək üçün daha qısa tərəfə qayıdın.
        // Sonra daha uzun tərəfə davam edin (bu, quyruq rekürsiyasına oxşayır).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// *O*(*n*\*log(* n*)) ən pis halda) olan model məğlub quicksort istifadə edərək `v` sıralayır.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sıralamanın sıfır ölçülü növlərdə mənalı davranışı yoxdur.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Balanssız bölmələrin sayını `floor(log2(len)) + 1` ilə məhdudlaşdırın.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Bu uzunluğa qədər olan dilimlər üçün sadəcə onları çeşidləmək daha sürətli olur.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Pivot seçin
        let (pivot, _) = choose_pivot(v, is_less);

        // Seçilmiş pivot sələfə bərabərdirsə, dilimdəki ən kiçik elementdir.
        // Dilimi pivotdan daha böyük elementlərə bölün.
        // Bu hal ümumiyyətlə dilimdə bir çox təkrarlanan element olduqda vurulur.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // İndeksimizi keçmişiksə, deməli yaxşıyıq.
                if mid > index {
                    return;
                }

                // Əks təqdirdə, pivotdan daha böyük elementləri sıralamağa davam edin.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Dilimi `left`, `pivot` və `right`-ə bölün.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Əgər orta==indeksdirsə, işimiz bitdi, çünki partition() ortadan sonra bütün elementlərin ortadan böyük və ya bərabər olduğuna zəmanət verdi.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sıralamanın sıfır ölçülü növlərdə mənalı davranışı yoxdur.Heçnə etmə.
    } else if index == v.len() - 1 {
        // Maksimum elementi tapın və massivin son vəziyyətinə qoyun.
        // V-nin boş olmamasını bildiyimiz üçün burada `unwrap()` istifadə etməkdə sərbəstik.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Min elementi tapın və onu massivin birinci vəziyyətinə qoyun.
        // V-nin boş olmamasını bildiyimiz üçün burada `unwrap()` istifadə etməkdə sərbəstik.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}