// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` aralığını elə çevirir ki, `mid`-dəki element ilk element olsun.Eyni şəkildə, aralıq `left` elementlərini sola və ya `right` elementlərini sağa çevirir.
///
/// # Safety
///
/// Müəyyən edilmiş sıra oxumaq və yazmaq üçün etibarlı olmalıdır.
///
/// # Algorithm
///
/// Alqoritm 1 kiçik `left + right` dəyərləri və ya böyük `T` üçün istifadə olunur.
/// Elementlər `mid - left`-dən başlayaraq X002 modulu ilə `right` addımları ilə irəliləyərək `mid - left`-dən başlayaraq bir-bir son vəziyyətlərinə köçürülür, belə ki, yalnız bir müvəqqəti lazımdır.
/// Nəhayət, `mid - left`-ə qayıtdıq.
/// Bununla birlikdə, `gcd(left + right, right)` 1 deyilsə, yuxarıdakı addımlar elementlərin üzərinə atlandı.
/// Misal üçün:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Xoşbəxtlikdən, sona çatmış elementlər arasındakı atlanan elementlərin sayı həmişə bərabərdir, buna görə başlanğıc mövqeyimizi əvəzləşdirə və daha çox dövr edə bilərik (ümumi tur sayı `gcd(left + right, right)` value)-dir.
///
/// Nəticə budur ki, bütün elementlər bir dəfə və yalnız bir dəfə yekunlaşdırılır.
///
/// Alqoritm 2, `left + right` böyükdür, lakin `min(left, right)` yığın tamponuna sığacaq qədər kiçik olduqda istifadə olunur.
/// `min(left, right)` elementləri buferə kopyalanır, digərlərinə `memmove` tətbiq edilir və buferdəki olanlar yenidən yarandıqları yerin əks tərəfindəki çuxura köçürülür.
///
/// Vektorlaşdırıla bilən alqoritmlər `left + right` kifayət qədər böyük olduqda yuxarıdakıları üstələyir.
/// Alqoritm 1 birdən çox dövrə vurub yerinə yetirməklə vektorlaşdırıla bilər, lakin `left + right` böyük oluncaya qədər orta hesabla çox az dövrə var və tək turun ən pis vəziyyəti həmişə orada olur.
/// Bunun əvəzinə, alqoritm 3, daha kiçik bir dönüş problemi qalana qədər `min(left, right)` elementlərinin təkrar dəyişdirilməsindən istifadə edir.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` dəyişdirmə əvəzinə soldan baş verir.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. bu hallar yoxlanılmasa aşağıdakı alqoritmlər uğursuz ola bilər
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Alqoritm 1 Microbenchmarks, təsadüfi keçidlər üçün ortalama performansın təxminən `left + right == 32`-ə qədər daha yaxşı olduğunu göstərir, lakin ən pis vəziyyət 16 ətrafında da pozulur.
            // 24 orta yol olaraq seçildi.
            // `T` ölçüsü 4 `usize`-dən böyükdürsə, bu alqoritm digər alqoritmləri də üstələyir.
            //
            //
            let x = unsafe { mid.sub(left) };
            // ilk turun başlanğıcı
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` hesablayaraq əldən əvvəl tapıla bilər, ancaq gcd-ni yan təsir kimi hesablayan bir döngə etmək daha sürətli və daha sonra hissənin qalan hissəsini etmək
            //
            //
            let mut gcd = right;
            // kriteriyalar göstərir ki, müvəqqəti bir dəfə oxumaq, geriyə kopyalamaq və ən sonunda bu müvəqqəti yazmaq əvəzinə müvəqqəti dəyişdirmək daha sürətli olur.
            // Bu, ehtimal ki, müvəqqəti dəyişdirmə və ya dəyişdirmə, ikisini idarə etmək lazım deyil, döngədə yalnız bir yaddaş ünvanı istifadə edir.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i`-i artırmaq və sərhədlərin xaricində olub olmadığını yoxlamaq əvəzinə, `i`-nin növbəti artımda hüdudlardan kənara çıxıb çıxmayacağını yoxlayırıq.
                // Bu, göstəricilərin və ya `usize`-nin hər hansı bir qablaşdırılmasının qarşısını alır.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // ilk turun sonu
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // bu şərti `left + right >= 15` varsa burada olmalıdır
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // yığını daha çox dəyirmi ilə tamamlayın
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` sıfır ölçülü bir növ deyil, buna görə də ölçüsünə bölmək yaxşıdır.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Alqoritm 2 Buradakı `[T; 0]`, bunun T üçün uyğun bir şəkildə uyğunlaşdırılmasını təmin edir
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Alqoritm 3 Bu alqoritmin son dəyişdirilməsinin harada olacağını və bu alqoritm kimi bitişik parçaları dəyişdirmək əvəzinə bu son hissəni istifadə edərək dəyişdirməyi həyata keçirən alternativ bir mübadilə yolu var, lakin bu yol hələ də daha sürətlidir.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Alqoritm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}