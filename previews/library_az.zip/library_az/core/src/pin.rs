//! Yaddaşdakı məlumatları yerləşdiyi yerə bağlayan növlər.
//!
//! Bəzən hərəkət etməməsinə zəmanət verilmiş obyektlərin yaddaşda yerləşdirilməsinin dəyişməyəcəyi və bununla etibar edilə biləcəyi mənada faydalı olur.
//! Belə bir ssenarinin ən yaxşı nümunəsi, özünə istinad edən quruluşların qurulması ola bilər, çünki bir obyektin göstəriciləri ilə özünə doğru hərəkət etməsi onları etibarsız hala gətirəcək və bu da təyin olunmamış davranışa səbəb ola bilər.
//!
//! Yüksək səviyyədə bir [`Pin<P>`], hər hansı bir `P` tipli pointein yaddaşda sabit bir yerə sahib olmasını təmin edir, yəni başqa yerə köçürülə bilməz və yıxılana qədər yaddaşını ayırmaq olmaz.Pointee'nin "pinned" olduğunu söyləyirik.Bağlanmayan məlumatlarla birləşdirilən növləri müzakirə edərkən işlər daha incə olur;Daha ətraflı məlumat üçün [see below](#projections-and-structural-pinning).
//!
//! Varsayılan olaraq, Rust-dəki bütün növlər hərəkətə gəlir.
//! Rust, hər növ dəyərdən keçməyə imkan verir və [`Box<T>`] və `&mut T` kimi ümumi ağıllı göstərici növləri, ehtiva etdiyi dəyərləri dəyişdirməyə və hərəkət etdirməyə imkan verir: [`Box<T>`]-dən çıxa və ya [`mem::swap`]-dən istifadə edə bilərsiniz.
//! [`Pin<P>`] `P` tipli bir göstəricini sarar, buna görə [`Pin`]`<`[`Box`] `<T>>"normal fəaliyyət göstərir
//!
//! [`Box<T>`]: when a [`Pin ']` <`[` Box'] `<T>>`düşər, məzmunu da edər və yaddaş da olar
//!
//! ayrıldı.Eynilə, [`Pin`]`<&mut T>`da `&mut T` kimi bir şeydir.Bununla birlikdə, [`Pin<P>`], müştərilərin həqiqətən sabitlənmiş məlumatlara [`Box<T>`] və ya `&mut T` əldə etməsinə icazə vermir, bu da [`mem::swap`] kimi əməliyyatlardan istifadə edə bilməyəcəyinizi nəzərdə tutur:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` `&mut T` lazımdır, amma ala bilmirik.
//!     // Zorlandıq, bu istinadların məzmununu dəyişdirə bilmərik.
//!     // `Pin::get_unchecked_mut` istifadə edə bilərik, amma bunun səbəbi etibarsızdır:
//!     // şeyləri `Pin`-dən çıxarmaq üçün istifadə etməyimizə icazə verilmir.
//! }
//! ```
//!
//! [`Pin<P>`]-in bir Rust kompilyatorunun bütün növləri daşınar hesab etdiyini dəyişdirmədiyini təkrarlamağa dəyər.[`mem::swap`] hər hansı bir `T` üçün zəng edilə bilər.Bunun əvəzinə, [`Pin<P>`] müəyyən *dəyərlərin*([`Pin<P>`]-ə bükülmüş göstəricilər tərəfindən göstərildiyi) üzərində `&mut T` tələb edən metodları ([`mem::swap`] kimi) çağırmağı mümkünsüz hala gətirərək hərəkət etməsini maneə törədir.
//!
//! [`Pin<P>`] hər hansı bir `P` tipli göstəricini bağlamaq üçün istifadə edilə bilər və bu səbəbdən [`Deref`] və [`DerefMut`] ilə qarşılıqlı əlaqədədir.`P: Deref`-in sancaqlı `P::Target`-ə "`P`-style pointer" kimi baxılması lazım olan bir [`Pin<P>`]-belə ki, bir [`Pin`]`<`[`Box`] "<T>>`sabitlənmiş `T`-ə məxsus bir göstəricidir və [`Pin ']`<`[`Rc`]`<T>> `sabitlənmiş `T`-ə istinad sayılan bir göstəricidir.
//! Düzgünlük üçün [`Pin<P>`] [`Deref`] və [`DerefMut`] tətbiqetmələrinə, `self` parametrlərindən kənara çıxmamağa və sabitlənmiş bir göstəriciyə çağırıldıqda yalnız bir göstəricini sabitlənmiş məlumatlara qaytarmağa etibar edir.
//!
//! # `Unpin`
//!
//! Bir çox növ sabit bir ünvana güvənmədikləri üçün, sabitlənsə də, hər zaman sərbəst hərəkət edə bilər.Buraya bütün əsas növlər ([`bool`], [`i32`] və istinadlar kimi) və yalnız bu növlərdən ibarət olan növlər daxildir.Sıxlaşdırma ilə maraqlanmayan tiplər, [`Pin<P>`] təsirini ləğv edən [`Unpin`] auto-trait tətbiq edir.
//! `T: Unpin` üçün [`Pin ']` <`[` Box`]`<T>> `və [`Box<T>`] eyni şəkildə işləyir, [[Pin`]`<&mut T>`və `&mut T` kimi.
//!
//! Diqqət yetirin və [`Unpin`], [`Pin<P>`]-ə bükülmüş `P` göstəricisini deyil, yalnız sivri tipli `P::Target` tipini təsir etdiyini unutmayın.Məsələn, [`Box<T>`] in [`Unpin`] olub-olmamasının [`Pin ']` <`[` Box`]`nin davranışına heç bir təsiri yoxdur.<T>> `(burada, `T` sivri tipdir).
//!
//! # Nümunə: özünə istinad quruluşu
//!
//! `Pin<T>` ilə əlaqəli zəmanətləri və seçimləri izah etmək üçün daha ətraflı məlumat verməzdən əvvəl bunun necə istifadə olunacağına dair bəzi nümunələri müzakirə edirik.
//! [skip to where the theoretical discussion continues](#drop-guarantee) üçün çekinmeyin.
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Dilim sahəsi məlumat sahəsini göstərdiyi üçün bu özünə istinad edən bir quruluşdur.
//! // Bu barədə adi bir istinadla tərtibçiyə məlumat verə bilmərik, çünki bu model adi borc alma qaydaları ilə təsvir edilə bilməz.
//! //
//! // Bunun əvəzinə xama göstəricisindən istifadə edirik, baxmayaraq ki, null olmadığı bilinir, çünki sətrə işarə etdiyini bilirik.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Funksiya qayıtdıqda məlumatların tərpənməməsini təmin etmək üçün onu obyektin ömrü boyu qalacağı yığın yerə yerləşdiririk və ona çatmağın yeganə yolu ona işarə edən bir göstəricidən keçir.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // göstəricini yalnız məlumatlar yerində olduqda yaradırıq, əks halda hələ başlamamışdan əvvəl hərəkət etmiş olar
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // bunun təhlükəsiz olduğunu bilirik, çünki bir sahəni dəyişdirmək bütün strukturu hərəkətə gətirmir
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // İşarədəki struktur hərəkət etmədiyi müddətcə düzgün yeri göstərməlidir.
//! //
//! // Bu vaxt göstəricini ətrafında gəzdirməkdə sərbəstik.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Tipimiz Unpin tətbiq etmədiyi üçün bu tərtib edilə bilməz:
//! // qoy mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Misal: müdaxilə edən ikiqat əlaqəli siyahı
//!
//! Müdaxilə edən ikiqat əlaqəli bir siyahıda, kolleksiya faktiki olaraq elementlərin özü üçün yaddaş ayırmır.
//! Ayrılma müştərilər tərəfindən idarə olunur və elementlər kolleksiyadan daha qısa ömür sürən bir yığın çərçivədə yaşaya bilər.
//!
//! Bu işi həyata keçirmək üçün hər elementin siyahıda sələfinə və varisinə göstəriciləri var.Elementlər yalnız sabitləndikdə əlavə edilə bilər, çünki elementlərin ətrafında hərəkət etmək göstəriciləri etibarsız sayacaqdır.Üstəlik, əlaqəli bir siyahı elementinin [`Drop`] tətbiqi, özünü siyahıdan çıxarmaq üçün sələfinin və varisin göstəricilərini yamaqlayacaqdır.
//!
//! Ən əsası [`drop`]-in çağırılacağına etibar edə bilməliyik.Bir element [`drop`]-yə zəng vurmadan ayrılmaq və ya başqa bir şəkildə etibarsız hala gətirilə bilsə, qonşu elementlərdən daxil olan göstəricilər etibarsız olacaq və bu da məlumat quruluşunu pozacaqdır.
//!
//! Buna görə də pinning ['damla'] ilə əlaqəli bir zəmanətlə gəlir.
//!
//! # `Drop` guarantee
//!
//! Sıxlaşdırmanın məqsədi bəzi məlumatların yaddaşa yerləşdirilməsinə etibar etməkdir.
//! Bu işi görmək üçün yalnız məlumatların köçürülməsi məhdudlaşdırılmır;məlumatların saxlanılması üçün istifadə olunan yaddaşın bölüşdürülməsi, dəyişdirilməsi və ya başqa bir şəkildə ləğv edilməsi də məhduddur.
//! Konkret olaraq, sabitlənmiş məlumatlar üçün *yaddaşının bağlandığı andan etibarən [`drop`] adlandırılana qədər* etibarsız olmayacağını və ya dəyişməyəcəyini dəyişməz olaraq saxlamalısınız.Yalnız [`drop`] döndükdən və ya panics olduqda, yaddaş yenidən istifadə edilə bilər.
//!
//! Yaddaş ayırma yolu ilə "invalidated" ola bilər, eyni zamanda [`Some(v)`]-i [`None`]-ə dəyişdirməklə və ya vector-dən bəzi elementləri [`Vec::set_len`]-dən "kill"-ə çağırmaqla "invalidated" ola bilər.Əvvəlcə destruktoru çağırmadan onun üzərinə yazmaq üçün [`ptr::write`] istifadə edərək yenidən təyin edilə bilər.[`drop`]-ə zəng etmədən sabitlənmiş məlumatlar üçün bunların heç birinə icazə verilmir.
//!
//! Bu, əvvəlki hissədəki müdaxilə əlaqəli siyahının düzgün işləməsi üçün lazımlı bir zəmanətdir.
//!
//! Diqqət yetirin ki, bu zəmanət *yaddaşın sızmadığını göstərmir![`drop`]-i sabitlənmiş bir elementə çağırmamaq hələ tamamilə yaxşıdır (məsələn, hələ də [`mem::forget`] i [`Pin`]"<`[`Box`] "<T>>`).İkili əlaqəli siyahının timsalında həmin element sadəcə siyahıda qalacaq.Bununla birlikdə, ['drop`]* zəng etmədən * saxlaya bilərsiniz və ya yenidən istifadə edə bilməzsiniz.
//!
//! # `Drop` implementation
//!
//! Tipiniz pininq istifadə edirsə (yuxarıdakı iki nümunə kimi), [`Drop`] tətbiq edərkən diqqətli olmalısınız.[`drop`] funksiyası `&mut self` alır, ancaq buna tipiniz əvvəllər sancılmış olsa da * deyilir!Elə bil tərtibçi avtomatik olaraq [`Pin::get_unchecked_mut`] adlandırdı.
//!
//! Bu, heç vaxt təhlükəsiz kodda problem yarada bilməz, çünki sabitləməyə əsaslanan bir növü tətbiq etmək təhlükəli kod tələb edir, lakin unutmayın ki, tipinizdə sancaqdan istifadə etmək qərarına gəlin (məsələn, bəzi əməliyyatlar [[Pin`]"<&Self> `və ya [` Pin '] `<&mut Self>`), [`Drop`] tətbiqiniz üçün də nəticələrə səbəb olur: tipinizdəki bir element sabitlənmiş ola bilərsə, [`Drop`]-ə [[Pin`]"<&mut Öz> ".
//!
//!
//! Məsələn, `Drop`-i aşağıdakı kimi tətbiq edə bilərsiniz:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` yaxşıdır, çünki bilirik ki, bu dəyər düşdükdən sonra bir daha istifadə olunmur.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Həqiqi düşmə kodu buraya gedir.
//!         }
//!     }
//! }
//! ```
//!
//! `inner_drop` funksiyası, [`drop`]*olmalıdır* tipinə malikdir, beləliklə təsadüfən `self`/`this`-i sancma ilə ziddiyyət təşkil edən bir şəkildə istifadə etməməyinizə imkan verir.
//!
//! Üstəlik, tipiniz `#[repr(packed)]`-dirsə, kompilyator onları boşaltmaq üçün avtomatik olaraq ətrafı hərəkət etdirəcəkdir.Hətta kifayət qədər hizalanmış olan sahələr üçün bunu edə bilər.Nəticə olaraq, `#[repr(packed)]` tipli sancaqdan istifadə edə bilməzsiniz.
//!
//! # Proqnozlar və Struktur Pinning
//!
//! Qapalı konstruksiyalarla işləyərkən, yalnız [`Pin`]`<&mut Struct>`alan bir metodla bu strukturun sahələrinə necə daxil ola biləcəyiniz sual yaranır.
//! Adi yanaşma, köməkçi metodlar yazmaqdır (*proqnozlar* deyilir), ['Pin`]`<&mut Struct>`-ni sahəyə istinad halına gətirən, ancaq bu istinad hansı növə sahib olmalıdır?['Pin`] `<&mut Field>` yoxsa `&mut Field`?
//! Eyni sual bir `enum` sahələri ilə, həmçinin [`Vec<T>`], [`Box<T>`] və ya [`RefCell<T>`] kimi container/wrapper növlərini nəzərdən keçirərkən ortaya çıxır.
//! (Bu sual həm dəyişdirilə bilən, həm də paylaşılan istinadlara aiddir, sadəcə nümunə üçün burada daha çox yayılmış dəyişdirilə bilən istinadları istifadə edirik.)
//!
//! Məlum bir sahə üçün sabitlənmiş proyeksiyanın [`Pin`]`<&mut Struct>`in [`Pin`] `<&mut Field>` ya çevrilməsinə qərar vermək, həqiqətən, veri quruluşunun müəllifinə aiddir. `&mut Field`.Bəzi məhdudiyyətlər var və ən vacib məhdudiyyət *tutarlılıqdır*:
//! hər sahə bir sancaqlı istinad üçün proqnozlaşdırıla bilər və ya * proqnozun bir hissəsi olaraq səthdən çıxarıla bilər.
//! Hər ikisi eyni sahə üçün edilsə, bu çox güman ki, əsassız olacaq!
//!
//! Bir məlumat quruluşunun müəllifi olaraq hər sahə üçün "propagates"-in bu sahəyə sabitlənib-bağlanmamasına qərar verəcəksiniz.
//! Yayılan piminqə "structural" də deyilir, çünki növün quruluşunu izləyir.
//! Aşağıdakı alt hissələrdə hər iki seçim üçün edilməli olan mülahizələri təsvir edirik.
//!
//! ## Pinning *`field` üçün* struktur deyil
//!
//! Bağlanmış bir strukturun sahəsinin sancılmaması əks-intuitiv görünə bilər, amma bu, ən asan seçimdir: əgər bir [`Pin`]` <&mut Field> 'heç yaradılmasa, heç bir səhv ola bilməz!Beləliklə, bəzi sahələrdə struktur sancaqların olmadığına qərar verdiyiniz təqdirdə, yalnız bu sahəyə sabitlənmiş bir istinad yaratmamağınızdır.
//!
//! Struktur sancağı olmayan sahələrdə [`Pin`]` <&mut Struct> 'ı `&mut Field`-ə çevirən proyeksiya metodu ola bilər:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Bu yaxşıdır, çünki `field` heç vaxt sabitlənmiş sayılmır.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! `field` tipi [`Unpin`] olmasa da `impl Unpin for Struct` * edə bilərsiniz.Bu tipin sancma haqqında düşündüyü heç ["Pin`]"<&mut Field>"yaradılmadığı zaman əlaqəli deyil.
//!
//! ## Pinning *`field` üçün* strukturdur
//!
//! Digər seçim, pinnin `field` üçün "structural" olduğuna qərar verməkdir, yəni struktur sancılıbsa, sahə də o deməkdir.
//!
//! Bu ['Pin`]`<&mut Field>' yaradan bir proyeksiya yazmağa imkan verir, beləliklə sahənin sancıldığına şahid oluruq:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Bu yaxşıdır, çünki `field` `self` olduqda sabitlənir.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Bununla birlikdə, struktur pinleme bir neçə əlavə tələblə gəlir:
//!
//! 1. Struktur yalnız bütün struktur sahələr [`Unpin`] olduqda [`Unpin`] olmalıdır.Bu, standartdır, lakin [`Unpin`] etibarlı bir trait'dir, buna görə strukturun müəllifi olaraq `impl<T> Unpin for Struct<T>` kimi bir şey əlavə etmək sizin üçün *deyil*.
//! (Diqqət yetirin ki, bir proyeksiya əməliyyatı əlavə etmək üçün təhlükəli kod tələb olunur, bu səbəbdən [`Unpin`]-in etibarlı bir trait olması, yalnız 'təhlükəli' istifadə etdiyiniz təqdirdə bunlardan hər hansı birinə görə narahat olmağınız prinsipini pozmur.)
//! 2. Strukturun dağıdıcısı struktur sahələri mübahisəsindən kənarlaşdırmamalıdır.Bu, [previous section][drop-impl]-də qaldırılan dəqiq məqamdır: `drop` `&mut self` alır, lakin struktur (və dolayısı ilə sahələri) əvvəllər bağlanmış ola bilər.
//!     [`Drop`] tətbiqinizin içərisində bir sahə daşımadığınıza zəmanət verməlisiniz.
//!     Xüsusilə, əvvəllər izah edildiyi kimi, bu, strukturunuzun `#[repr(packed)]` olmaması * deməkdir.
//!     [`drop`]-in kompilyatorun təsadüfən sancmanı pozmamağınıza kömək edə biləcəyi şəkildə necə yazılacağına dair bölməyə baxın.
//! 3. [`Drop` guarantee][drop-guarantee]-i dəstəklədiyinizə əmin olmalısınız:
//!     quruluşunuz sabitləndikdən sonra, məzmunu ehtiva edən yaddaş, məzmunun dağıdıcılarını çağırmadan yazılmır və bölüşdürülmür.
//!     Bu, [`VecDeque<T>`]-in şahidi olduğu kimi çətin ola bilər: [`VecDeque<T>`] destruktoru, panics destruktorlarından biri olduqda bütün elementlərdə [`drop`]-i axtara bilmir.Bu, [`Drop`] zəmanətini pozur, çünki elementlərin dağıdıcısı çağırılmadan ayrılmasına səbəb ola bilər.([`VecDeque<T>`]-də sabitləmə proqnozu yoxdur, bu səbəbdən əsassızlığa səbəb olmur.)
//! 4. Tipiniz sabitləndikdə, məlumatların struktur sahələrdən kənarlaşdırılmasına səbəb ola biləcək başqa əməliyyatlar təklif etməməlisiniz.Məsələn, struktur bir [`Option<T>`] ehtiva edirsə və `fn(Pin<&mut Struct<T>>) -> Option<T>` tipli bir "götürmə" kimi bir əməliyyat varsa, bu əməliyyat `T`-i sancaqlı `Struct<T>`-dən çıxarmaq üçün istifadə edilə bilər-bu, sabitləmə onu saxlayan sahə üçün struktur ola bilməz deməkdir. məlumat.
//!
//!     Verilənləri sabitlənmiş bir növdən çıxarmaq üçün daha mürəkkəb bir nümunə üçün [`RefCell<T>`]-də bir `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>` metodunun olub olmadığını təsəvvür edin.
//!     Sonra aşağıdakıları edə bildik:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Bu fəlakətlidir, yəni əvvəlcə [`RefCell<T>`]-in tərkibini (`RefCell::get_pin_mut` istifadə edərək) bağlaya bilərik və daha sonra əldə etdiyimiz dəyişkən istinaddan istifadə edərək həmin məzmunu köçürə bilərik.
//!
//! ## Examples
//!
//! [`Vec<T>`] kimi bir növ üçün hər iki ehtimal (struktur sabitləmə və ya yox) məna daşıyır.
//! Struktur sancaqlı bir [`Vec<T>`], elementlərə sabitlənmiş istinadlar əldə etmək üçün `get_pin`/`get_pin_mut` metodlarına sahib ola bilər.Bununla birlikdə, [`pop`][Vec::pop]-i sancaqlı bir [`Vec<T>`]-də axtarmağa icazə verə bilməzdi, çünki bu (struktur olaraq bağlanmış) məzmunu hərəkətə gətirəcəkdir!Yenidən yerləşə bilən və bununla da məzmunu hərəkətə gətirən [`push`][Vec::push]-ə icazə verə bilməzdi.
//!
//! Struktur sabitləmə olmadan bir [`Vec<T>`] `impl<T> Unpin for Vec<T>` edə bilər, çünki məzmunu heç vaxt sabitlənmir və [`Vec<T>`] özü də köçürülməklə yaxşıdır.
//! Bu nöqtədə sancağın vector üzərində heç bir təsiri yoxdur.
//!
//! Standart kitabxanada göstərici tiplərində ümumiyyətlə struktur sancaq yoxdur və bu səbəblə də sabitləmə proyeksiyaları təklif edilmir.Bu səbəbdən `Box<T>: Unpin` bütün `T`-lərə sahibdir.
//! Bunu göstərici növləri üçün etmək mantiqidir, çünki `Box<T>`-in hərəkəti `T`-i hərəkətə gətirmir: `T` olmasa da [`Box<T>`] sərbəst hərəkət edə bilər (aka `Unpin`).Əslində, hətta [`Pin ']` <`[` Box'] `<T>>`və [`Pin ']`<&mut T>` həmişə eyni səbəbdən [`Unpin`]-dir: məzmunu (`T`) sabitlənir, lakin göstəricilərin özləri sabitlənmiş məlumatları hərəkət etdirmədən köçürülə bilər.
//! Həm [`Box<T>`], həm də [`Pin ']` <`[` Box`]`üçün<T>> `, məzmunun sabitlənib-bağlanmaması, göstəricinin sabitlənib-bağlanmamasından tamamilə asılıdır, yəni sabitləmə *struktur* deyil.
//!
//! Bir [`Future`] kombinatorunu tətbiq edərkən, [`poll`]-yə zəng etmək üçün onlara istinad edilmiş istinadlar almalı olduğunuz üçün, adətən, iç içə futures üçün struktur sancağa ehtiyacınız olacaq.
//! Ancaq kombinatorunuzda sabitlənməyə ehtiyac duyulmayan başqa bir məlumat varsa, bu sahələri struktur olmayan vəziyyətə gətirə bilərsiniz və bu səbəbdən yalnız ['Pin`]`<&mut Self>" (belə öz [`poll`] tətbiqində olduğu kimi).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Sancaqlı göstərici.
///
/// Bu, "pin" göstəricisini yerinə yetirən və bu göstəricinin istinad etdiyi dəyərin [`Unpin`] tətbiq etmədiyi müddətdə daşınmasının qarşısını alan bir növ göstəricinin ətrafındakı bir sarğıdır.
///
///
/// *Sızdırmazlığın izahı üçün [`pin` module] sənədlərinə baxın.*
///
/// [`pin` module]: self
///
// Note: həyata keçirmək mümkün olduğu üçün aşağıdakı `Clone` çıxışı əsassızlığa səbəb olur
// `Clone` dəyişdirilə bilən istinadlar üçün.
// Daha ətraflı məlumat üçün <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>-ə baxın.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Sağlamlıq problemlərinin qarşısını almaq üçün aşağıdakı tətbiqetmələr alınmır.
// `&self.pointer` etibarsız trait tətbiqetmələri üçün əlçatan olmamalıdır.
//
// Daha ətraflı məlumat üçün <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>-ə baxın.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// [`Unpin`] tətbiq edən bəzi tip məlumatlara bir göstərici ətrafında yeni bir `Pin<P>` düzəldin.
    ///
    /// `Pin::new_unchecked`-dən fərqli olaraq, bu metod təhlükəsizdir, çünki `P` göstəricisi sabitləmə zəmanətlərini ləğv edən [`Unpin`] tipinə istinad edir.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // TƏHLÜKƏSİZLİK: göstərilən dəyər `Unpin`-dir və buna görə heç bir tələb yoxdur
        // sancma ətrafında.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Əsas Xətti qaytaran bu `Pin<P>`-in açarını açır.
    ///
    /// Bunun üçün bu `Pin` içərisindəki məlumatların [`Unpin`] olması lazımdır ki, açarkən bağlama dəyişməzlərinə məhəl qoymayaq.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// `Unpin` tətbiq edə bilən və ya tətbiq edə bilməyəcək bir növ bəzi məlumatlara istinad ətrafında yeni bir `Pin<P>` qurun.
    ///
    /// `Unpin` tipinə `pointer` istinadları varsa, bunun yerinə `Pin::new` istifadə edilməlidir.
    ///
    /// # Safety
    ///
    /// Bu konstruktor təhlükəlidir, çünki `pointer` tərəfindən göstərilən məlumatların bağlandığına zəmanət verə bilmərik, yəni məlumatlar taşınmayacaq və ya saxlanılan yerə düşənə qədər etibarsız olacaq.
    /// Əgər inşa edilmiş `Pin<P>`, `P`-nin göstərdiyi məlumatların sabitləndiyinə zəmanət vermirsə, bu API müqaviləsinin pozulmasıdır və sonrakı (safe) əməliyyatlarında qeyri-müəyyən davranışa səbəb ola bilər.
    ///
    /// Bu metodu istifadə edərək `P::Deref` və `P::DerefMut` tətbiqetmələri barədə bir promise hazırlayırsınız.
    /// Ən əsası, `self` arqumentlərindən kənara çıxmamalıdırlar: `Pin::as_mut` və `Pin::as_ref` x03X və `Deref::deref`*işarələnmiş işarədə* çağıracaq və bu metodların sabitləmə dəyişməzlərini dəstəkləməsini gözləyəcəklər.
    /// Üstəlik, bu metodu çağıraraq, `P` istinadlarının yenidən çıxarılmayacağını promise;xüsusən, bir `&mut P::Target` əldə etmək və sonra həmin referansdan çıxmaq mümkün olmamalıdır (məsələn [`mem::swap`] istifadə edərək).
    ///
    ///
    /// Məsələn, bir `&'a mut T`-də `Pin::new_unchecked`-yə zəng etmək təhlükəlidir, çünki `'a`-i müəyyən bir ömür boyu bağlaya bildiyiniz halda, `'a` bitdikdən sonra sabitlənib saxlanılmayacağına nəzarət etmirsiniz:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Bu, pointee `a`-in bir daha əsla hərəkət edə bilməyəcəyi anlamına gəlməlidir.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // `a`-in ünvanı `b`-in yığın yuvası olaraq dəyişdirildi, buna görə `a` əvvəlcədən sabitlədiyimizə baxmayaraq hərəkət etdi!Sazlama API müqaviləsini pozduq.
    /////
    /// }
    /// ```
    ///
    /// Bir dəfə sabitlənmiş bir dəyər sonsuza qədər sabitlənmiş qalmalıdır (növü `Unpin` tətbiq etmədikdə).
    ///
    /// Eynilə, `Rc<T>`-də `Pin::new_unchecked`-i çağırmaq təhlükəlidir, çünki eyni məlumatların bağlama məhdudiyyətlərinə tabe olmayan takma adlar ola bilər:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Bu, quşçunun bir daha əsla hərəkət edə bilməyəcəyi anlamına gəlməlidir.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // İndi `x` tək istinad olsaydı, əvvəlki nümunədə gördüyümüz kimi köçürmək üçün istifadə edə biləcəyimiz yuxarıda bağladığımız məlumatlara dəyişkən bir istinad var.
    ///     // Sazlama API müqaviləsini pozduq.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Bu sabitlənmiş göstəricidən sabitlənmiş paylaşılan bir istinad əldə edir.
    ///
    /// Bu, `&Pin<Pointer<T>>`-dən `Pin<&T>`-ə keçmək üçün ümumi bir üsuldur.
    /// Təhlükəsizdir, çünki `Pin::new_unchecked` müqaviləsinin bir hissəsi olaraq, xallı `Pin<Pointer<T>>` yaradıldıqdan sonra hərəkət edə bilməz.
    ///
    /// "Malicious" `Pointer::Deref` tətbiqləri də `Pin::new_unchecked` müqaviləsi ilə istisna olunur.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // TƏHLÜKƏSİZLİK: bu funksiyaya dair sənədlərə baxın
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Əsas Xətti qaytaran bu `Pin<P>`-in açarını açır.
    ///
    /// # Safety
    ///
    /// Bu funksiya təhlükəlidir.Bu funksiyanı çağırdıqdan sonra `P` göstəricisini sabitlənmiş kimi qəbul etməyə davam edəcəyinizə zəmanət verməlisiniz ki, `Pin` tipindəki dəyişməzlər dəstəklənsin.
    /// Nəticədə `P` istifadə edən kod, API müqaviləsinin pozulması və sonrakı (safe) əməliyyatlarında təyin olunmayan davranışa səbəb ola bilən sabitləmə dəyişməzliyini qorumağa davam etmirsə.
    ///
    ///
    /// Əsas məlumat [`Unpin`]-dirsə, bunun yerinə [`Pin::into_inner`] istifadə olunmalıdır.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Bu sabitlənmiş göstəricidən sabitlənmiş dəyişkən bir istinad əldə edir.
    ///
    /// Bu, `&mut Pin<Pointer<T>>`-dən `Pin<&mut T>`-ə keçmək üçün ümumi bir üsuldur.
    /// Təhlükəsizdir, çünki `Pin::new_unchecked` müqaviləsinin bir hissəsi olaraq, xallı `Pin<Pointer<T>>` yaradıldıqdan sonra hərəkət edə bilməz.
    ///
    /// "Malicious" `Pointer::DerefMut` tətbiqləri də `Pin::new_unchecked` müqaviləsi ilə istisna olunur.
    ///
    /// Bu metod, sabitlənmiş növü istehlak edən funksiyalara birdən çox zəng edərkən faydalıdır.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // nəsə et
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` `self` istehlak edir, buna görə `Pin<&mut Self>` i `as_mut` vasitəsilə yenidən böyüdün.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // TƏHLÜKƏSİZLİK: bu funksiyaya dair sənədlərə baxın
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Bağlanan istinadın arxasındakı yaddaşa yeni bir dəyər təyin edir.
    ///
    /// Bu sabitlənmiş məlumatların üzərinə yazır, amma bu yaxşıdır: onun məhvçisi yazılmadan əvvəl işə düşür, buna görə də heç bir sabitləmə zəmanəti pozulmur.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Daxili dəyəri eşleyerek yeni bir pin qurur.
    ///
    /// Məsələn, bir şeyin bir sahəsindən `Pin` almaq istəsəniz, bu kodu bir sətirdə həmin sahəyə giriş əldə etmək üçün istifadə edə bilərsiniz.
    /// Bununla birlikdə, bu "pinning projections" ilə bir neçə gotcha var;
    /// bu mövzu ilə əlaqədar daha ətraflı məlumat üçün [`pin` module] sənədlərinə baxın.
    ///
    /// # Safety
    ///
    /// Bu funksiya təhlükəlidir.
    /// Arqument dəyəri hərəkət etmədiyi müddətdə qaytardığınız məlumatların hərəkət etməyəcəyinə zəmanət verməlisiniz (məsələn, bu dəyərin sahələrindən biri olduğu üçün) və aldığınız arqumentdən kənara çıxmamağınız lazımdır. daxili funksiya.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // TƏHLÜKƏSİZLİK: `new_unchecked` üçün təhlükəsizlik müqaviləsi olmalıdır
        // zəng edən tərəfindən dəstəkləndi.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Bir sancaqdan paylaşılan bir istinad əldə edir.
    ///
    /// Bu təhlükəsizdir, çünki paylaşılan bir istinaddan çıxmaq mümkün deyil.
    /// Burada daxili dəyişkənliklə bağlı bir problem olduğu görünə bilər: əslində, `T`-i `&RefCell<T>`-dən çıxarmaq * mümkündür.
    /// Bununla birlikdə, eyni məlumatları göstərən bir `Pin<&T>` olmadığı və `RefCell<T>` içindəkilərə sabitlənmiş bir istinad yaratmağınıza icazə verməyincə bu problem deyil.
    ///
    /// Daha ətraflı məlumat üçün ["pinning projections"]-dəki müzakirəyə baxın.
    ///
    /// Note: `Pin`, daxili dəyərə çatmaq üçün istifadə edilə bilən hədəfə `Deref` tətbiq edir.
    /// Bununla birlikdə, `Deref`, `Pin`-in ömrü deyil, yalnız `Pin`-in borcu olduğu müddətdə yaşayan bir istinad təmin edir.
    /// Bu metod, `Pin`-i orijinal `Pin` ilə eyni ömür boyu bir referansa çevirməyə imkan verir.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Bu `Pin<&mut T>`-i eyni ömür müddəti ilə `Pin<&T>`-ə çevirir.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Bu `Pin` içərisindəki məlumatlara dəyişkən bir istinad əldə edir.
    ///
    /// Bunun üçün bu `Pin` içərisindəki məlumatların `Unpin` olması lazımdır.
    ///
    /// Note: `Pin`, daxili dəyərə çatmaq üçün istifadə edilə bilən məlumatlara `DerefMut` tətbiq edir.
    /// Bununla birlikdə, `DerefMut`, `Pin`-in ömrü deyil, yalnız `Pin`-in borcu olduğu müddətdə yaşayan bir istinad təmin edir.
    ///
    /// Bu metod, `Pin`-i orijinal `Pin` ilə eyni ömür boyu bir referansa çevirməyə imkan verir.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Bu `Pin` içərisindəki məlumatlara dəyişkən bir istinad əldə edir.
    ///
    /// # Safety
    ///
    /// Bu funksiya təhlükəlidir.
    /// Bu funksiyanı çağırdığınız zaman məlumatları heç vaxt dəyişdirilə bilən istinaddan çıxarmayacağınıza zəmanət verməlisiniz ki, `Pin` tipindəki dəyişməzlər təmin edilsin.
    ///
    ///
    /// Əsas məlumat `Unpin`-dirsə, bunun yerinə `Pin::get_mut` istifadə olunmalıdır.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Daxili dəyəri eşleyerek yeni bir pin qurun.
    ///
    /// Məsələn, bir şeyin bir sahəsindən `Pin` almaq istəsəniz, bu kodu bir sətirdə həmin sahəyə giriş əldə etmək üçün istifadə edə bilərsiniz.
    /// Bununla birlikdə, bu "pinning projections" ilə bir neçə gotcha var;
    /// bu mövzu ilə əlaqədar daha ətraflı məlumat üçün [`pin` module] sənədlərinə baxın.
    ///
    /// # Safety
    ///
    /// Bu funksiya təhlükəlidir.
    /// Arqument dəyəri hərəkət etmədiyi müddətdə qaytardığınız məlumatların hərəkət etməyəcəyinə zəmanət verməlisiniz (məsələn, bu dəyərin sahələrindən biri olduğu üçün) və aldığınız arqumentdən kənara çıxmamağınız lazımdır. daxili funksiya.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // TƏHLÜKƏSİZLİK: zəng edən şəxsin hərəkət etməməsindən məsuldur
        // bu arayışdan dəyər.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // TƏHLÜKƏSİZLİK: `this` dəyərinin olmamasına zəmanət verilir
        // köçürüldü, `new_unchecked`-ə edilən zəng təhlükəsizdir.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Statik bir istinaddan sabitlənmiş bir istinad alın.
    ///
    /// Bu təhlükəsizdir, çünki `T`, `'static` ömrü üçün borcludur, heç bitməz.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // TƏHLÜKƏSİZLİK: 'Statik borc, məlumatların olmayacağına zəmanət verir
        // moved/invalidated düşənə qədər (bu heç olmaz).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Statik dəyişdirilə bilən bir istinaddan sabitlənmiş dəyişkən bir istinad alın.
    ///
    /// Bu təhlükəsizdir, çünki `T`, `'static` ömrü üçün borcludur, heç bitməz.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // TƏHLÜKƏSİZLİK: 'Statik borc, məlumatların olmayacağına zəmanət verir
        // moved/invalidated düşənə qədər (bu heç olmaz).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: bu, məcbur etməyə imkan verən hər hansı bir `CoerceUnsized` impl-ı deməkdir
// `Deref<Target=impl !Unpin>`-i `Deref<Target=Unpin>`-i bağlayan bir tipə uyğun olmayan bir növ səssizdir.
// Bu cür hər hansı bir ehtimal başqa səbəblərə görə əsassız ola bilər, buna görə də belə fikirlərin std ərazisinə düşməməsinə diqqət yetirməliyik.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}