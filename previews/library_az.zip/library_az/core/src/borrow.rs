//! Alınan məlumatlarla işləmək üçün bir modul.

#![stable(feature = "rust1", since = "1.0.0")]

/// Məlumat almaq üçün bir trait.
///
/// Rust-də, fərqli istifadə halları üçün bir növün fərqli təsvirlərini təqdim etmək yaygındır.
/// Məsələn, bir dəyər üçün saxlama yeri və idarə edilməsi, [`Box<T>`] və ya [`Rc<T>`] kimi göstərici növləri vasitəsilə müəyyən bir istifadəyə uyğun olaraq xüsusi olaraq seçilə bilər.
/// Hər hansı bir növdə istifadə edilə bilən bu ümumi sarmalların xaricində, bəzi növlər potensial baha başa gələn funksionallığı təmin edən isteğe bağlı cəhətlər təqdim edir.
/// Belə bir növ üçün bir nümunə əsas [`str`]-ə bir simli uzatma qabiliyyəti əlavə edən [`String`]-dir.
/// Bunun üçün sadə, dəyişməz simli üçün əlavə məlumatların lazımsız saxlanılması tələb olunur.
///
/// Bu növlər, bu məlumatların tipinə istinadlar vasitəsilə əsas məlumatlara giriş təmin edir.Onların bu tipə 'borc' verildiyi deyilir.
/// Məsələn, [`Box<T>`], `T`, [`String`] isə `str` kimi götürülə bilər.
///
/// Növlər, trait-nin [`borrow`] metodunda bir `T`-ə istinad edərək `Borrow<T>` tətbiq edərək bəzi `T` tipləri kimi borc götürülə bildiklərini ifadə edirlər.Bir növ bir neçə fərqli növ olaraq borc almaqda sərbəstdir.
/// Əsas məlumatların dəyişdirilməsinə imkan verən növ olaraq qarşılıqlı olaraq borc almaq istəyirsə, əlavə olaraq [`BorrowMut<T>`] tətbiq edə bilər.
///
/// Bundan əlavə, əlavə traits üçün tətbiqetmələr təmin edərkən, bu əsas növün təmsilçiliyi kimi fəaliyyət göstərməsinin nəticəsi olaraq, əsas tiplə eyni davranacaqları düşünülməlidir.
/// Ümumi kod, bu əlavə trait tətbiqetmələrinin eyni davranışına güvəndiyi zaman tipik olaraq `Borrow<T>` istifadə edir.
/// Bu traits, ehtimal ki, əlavə trait bounds kimi görünəcəkdir.
///
/// Xüsusilə `Eq`, `Ord` və `Hash` borc və sahib olan dəyərlər üçün ekvivalent olmalıdır: `x.borrow() == y.borrow()`, `x == y` ilə eyni nəticə verməlidir.
///
/// Ümumi kodun yalnız əlaqədar `T` tipinə istinad təmin edə biləcək bütün növlər üçün işləməsi lazımdırsa, [`AsRef<T>`] istifadə etmək daha yaxşıdır, çünki daha çox növ onu təhlükəsiz şəkildə tətbiq edə bilər.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Məlumat toplusu olaraq [`HashMap<K, V>`] həm açarlara, həm də dəyərlərə sahibdir.Açarın həqiqi məlumatları bir növ idarəetmə növünə bükülmüşsə, yenə də açarın məlumatlarına istinad edərək bir dəyər axtarmaq mümkündür.
/// Məsələn, açar bir sətirdirsə, ehtimal ki, bir [`String`] olaraq hash xəritəsi ilə saxlanılır, [`&str`][`str`] istifadə edərək axtarış etmək mümkün olmalıdır.
/// Beləliklə, `insert` bir `String` üzərində işləməli, `get` bir `&str` istifadə edə bilməli.
///
/// Biraz sadələşdirilmiş, `HashMap<K, V>`-in müvafiq hissələri belə görünür:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // sahələr buraxılmışdır
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Bütün hash xəritəsi, əsas bir `K` növü üzərində ümumidir.Bu düymələr hash xəritəsi ilə saxlanıldığı üçün bu tip açarın məlumatlarına sahib olmalıdır.
/// Bir açar dəyər cütü daxil edərkən xəritəyə belə bir `K` verilir və düzgün hash qutusunu tapmalı və açarın həmin `K`-ə əsasən mövcud olub olmadığını yoxlamalıdır.Buna görə `K: Hash + Eq` tələb edir.
///
/// Xəritədə bir dəyər axtararkən, axtarış üçün açar kimi bir `K`-ə istinad edilməsi həmişə belə bir dəyər yaratmağı tələb edəcəkdir.
/// Simli düymələr üçün bu, yalnız `str`-nin mövcud olduğu hallarda axtarış üçün `String` dəyərinin yaradılması lazım olduğu deməkdir.
///
/// Bunun əvəzinə, `get` metodu yuxarıdakı metod imzasında `Q` adlanan əsas açar məlumat növü üzərində ümumidır.`K` in, `K: Borrow<Q>` tələb edərək bir `Q` olaraq borc aldığı bildirilir.
/// Əlavə olaraq `Q: Hash + Eq` tələb etməklə, `K` və `Q`-in eyni nəticələr verən `Hash` və `Eq` traits tətbiqetmələrinin olması tələbini göstərir.
///
/// `get`-in tətbiqi, `K` dəyərindən hesablanan hash dəyərinə əsaslanaraq daxil edilmiş olsa da, `Q` dəyərinə `Hash::hash` çağıraraq açarın hash xanasını təyin edərək `Hash`-in eyni tətbiqlərinə əsaslanır.
///
///
/// Nəticə olaraq, bir `Q` dəyərini saran bir `K`, `Q`-dən fərqli bir hash əmələ gətirirsə, hash xəritəsi pozulur.Məsələn, bir simli saran, lakin onların hallarını nəzərə almadan ASCII hərflərini müqayisə edən bir növünüz olduğunu düşünün:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// İki bərabər dəyərin eyni hash dəyərini yaratması lazım olduğundan, `Hash` tətbiqinin ASCII vəziyyətini də görməməzliyə vurması lazımdır:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` `Borrow<str>` tətbiq edə bilər?Əlbətdə olan simli bir sətir diliminə istinad təmin edə bilər.
/// Lakin `Hash` tətbiqi fərqli olduğundan `str`-dən fərqli davranır və bu səbəbdən `Borrow<str>` tətbiq etməməlidir.
/// Başqalarının altındakı `str`-ə girişinə icazə vermək istəyirsə, əlavə tələblər daşımayan `AsRef<str>` vasitəsilə bunu edə bilər.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Mülkiyyətində olan dəyərdən dəyişməz dərəcədə borc alır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Verilənləri qarşılıqlı borc almaq üçün bir trait.
///
/// [`Borrow<T>`]-in yoldaşı olaraq, bu trait, bir növün dəyişdirilə bilən bir istinad təmin edərək əsas bir növ kimi borc almasına imkan verir.
/// Başqa bir növ kimi borc alma haqqında daha çox məlumat üçün [`Borrow<T>`]-ə baxın.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Müvafiq olaraq məxsus olan dəyərdən borc alır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}