//! Bu ifmt tərəfindən istifadə edilən daxili bir moduldur!işləmə müddəti.Bu strukturlar əvvəlcədən format sətirlərini yığmaq üçün statik massivlərə yayılır.
//!
//! Bu təriflər `ct` ekvivalentlərinə bənzəyir, lakin bunların statik olaraq ayrılması və işləmə müddəti üçün bir qədər optimallaşdırılması ilə fərqlənir.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Biçimləmə direktivinin bir hissəsi olaraq istənilə bilən uyğunlaşmalar.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Məzmunun sola uyğunlaşdırılması lazım olduğuna işarə.
    Left,
    /// Məzmunun sağa uyğunlaşdırılması lazım olduğuna işarə.
    Right,
    /// Məzmunun mərkəzə uyğunlaşdırılması lazım olduğuna işarə.
    Center,
    /// Hizalama tələb olunmadı.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) və [precision](https://doc.rust-lang.org/std/fmt/#precision) göstəriciləri tərəfindən istifadə olunur.
#[derive(Copy, Clone)]
pub enum Count {
    /// Hərfi rəqəmlə göstərilən dəyəri saxlayır
    Is(usize),
    /// `$` və `*` sintaksislərindən istifadə edərək göstərilən indeksləri `args`-ə saxlayır
    Param(usize),
    /// Qeyd edilməmişdir
    Implied,
}