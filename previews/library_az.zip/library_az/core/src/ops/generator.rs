use crate::marker::Unpin;
use crate::pin::Pin;

/// Bir generatorun bərpasının nəticəsi.
///
/// Bu enum `Generator::resume` metodundan qaytarılır və generatorun mümkün qaytarılma dəyərlərini göstərir.
/// Hal-hazırda bu, bir dayandırma nöqtəsinə və ya (`Complete`) sona çatma nöqtəsinə cavab verir.
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Jeneratör bir dəyərlə dayandırıldı.
    ///
    /// Bu vəziyyət bir generatorun dayandırıldığını göstərir və ümumiyyətlə bir `yield` ifadəsinə uyğundur.
    /// Bu variantda verilən dəyər `yield`-ə ötürülmüş ifadəyə uyğundur və generatorlara hər məhsul verdikdə bir dəyər vermələrini təmin edir.
    ///
    ///
    Yielded(Y),

    /// Jeneratör bir geri dönüş dəyəri ilə tamamlandı.
    ///
    /// Bu vəziyyət, bir generatorun təmin edilmiş dəyəri ilə icrası başa çatdırdığını göstərir.
    /// Bir generator `Complete`-i qaytardıqdan sonra yenidən `resume`-ə zəng etmək bir proqramçı xətası hesab olunur.
    ///
    Complete(R),
}

/// Yerləşdirilmiş generator növləri tərəfindən həyata keçirilən trait.
///
/// Ümumiyyətlə koroutinlər olaraq da adlandırılan generatorlar, hazırda Rust-də eksperimental bir dil xüsusiyyətidir.
/// [RFC 2033] generatorlarında əlavə edilənlər hazırda async/await sözdizimi üçün bir bina bloku təmin etməyi düşünürlər, lakin yəqin ki, təkrarlayıcılar və digər ibtidailər üçün erqonomik tərif də verəcəkdir.
///
///
/// Generatorlar üçün sintaksis və semantik qeyri-sabitdir və sabitləşmə üçün daha çox RFC tələb edəcəkdir.Bu anda, sintaksis bağlanma kimidir:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Generatorların daha çox sənədləri qeyri-sabit kitabda tapıla bilər.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Bu generatorun verdiyi dəyər növü.
    ///
    /// Bu əlaqəli tip `yield` ifadəsinə və generatorun hər dəfə məhsul verdikdə qaytarılmasına icazə verilən dəyərlərə cavab verir.
    ///
    /// Məsələn, bir generator kimi bir iterator, ehtimal ki, `T` kimi bir növə sahib olacaqdır və bu tip təkrarlanır.
    ///
    type Yield;

    /// Bu generatorun qaytardığı dəyər növü.
    ///
    /// Bu, bir generatordan ya `return` ifadəsi ilə, ya da birbaşa olaraq bir generatorun sözün son ifadəsi kimi qaytarılmış növə cavab verir.
    /// Məsələn futures, tamamlanmış bir future'yi təmsil etdiyi üçün bunu `Result<T, E>` olaraq istifadə edər.
    ///
    ///
    type Return;

    /// Bu generatorun icrasını davam etdirir.
    ///
    /// Bu funksiya generatorun icrasını davam etdirəcək və ya hələ başlamamışsa icrasına başlayacaq.
    /// Bu zəng yenidən generatorun son dayandırma nöqtəsinə qayıdacaq və son `yield`-dən icrasını davam etdirəcəkdir.
    /// Jeneratör ya məhsul verənə, ya da qayıdana qədər icra etməyə davam edəcək və bu nöqtədə bu funksiya geri dönəcəkdir.
    ///
    /// # Qaytarma dəyəri
    ///
    /// Bu funksiyadan qayıdan `GeneratorState` enum, generatorun qayıtdıqdan sonra hansı vəziyyətdə olduğunu göstərir.
    /// `Yielded` variantı qaytarılırsa, generator bir dayandırılma nöqtəsinə çatmış və bir dəyər verilmişdir.
    /// Bu vəziyyətdə olan generatorlar daha sonra yenidən bərpa edilə bilər.
    ///
    /// `Complete` qaytarılırsa, generator verilən qiymətlə tamamilə başa çatmışdır.Jeneratörün yenidən bərpa edilməsi etibarsızdır.
    ///
    /// # Panics
    ///
    /// `Complete` variantı əvvəllər qaytarıldıqdan sonra çağırılırsa, bu funksiya panic ola bilər.
    /// Dildəki generator əlifbalarına `Complete`-dən sonra yenidən başlamağa panic zəmanət verilsə də, `Generator` trait-in bütün tətbiqləri üçün bu zəmanət verilmir.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}