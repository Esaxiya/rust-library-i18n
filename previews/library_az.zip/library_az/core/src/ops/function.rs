/// Dəyişməz alıcı götürən zəng operatorunun versiyası.
///
/// `Fn` nümunələri mutasiya vəziyyəti olmadan dəfələrlə çağırıla bilər.
///
/// *Bu trait (`Fn`), [function pointers] (`fn`) ilə qarışdırılmamalıdır.*
///
/// `Fn` avtomatik olaraq yalnız tutulmuş dəyişənlərə dəyişməz istinadlar edən və ya heç bir şey çəkməyən bağlamalar, həmçinin (safe) [function pointers] (bəzi xəbərdarlıqları ilə, daha ətraflı məlumat üçün sənədlərinə baxın) tərəfindən avtomatik olaraq həyata keçirilir.
///
/// Əlavə olaraq, `Fn` tətbiq edən hər hansı bir `F` növü üçün `&F` də `Fn` tətbiq edir.
///
/// Həm [`FnMut`], həm də [`FnOnce`] `Fn`-nin supertraitləri olduğundan `Fn`-in hər hansı bir nümunəsi [`FnMut`] və ya [`FnOnce`]-in gözlənildiyi bir parametr kimi istifadə edilə bilər.
///
/// Funksiya tipli bir parametri qəbul etmək istədiyiniz və mütəmadi olaraq mutasiya etmədən (məsələn, eyni vaxtda çağırarkən) zəng etməyiniz lazım olduqda, `Fn`-i bir bağlayıcı olaraq istifadə edin.
/// Bu cür ciddi tələblərə ehtiyacınız yoxdursa, [`FnMut`] və ya [`FnOnce`]-lərdən istifadə edin.
///
/// Bu mövzuda daha çox məlumat üçün [chapter on closures in *The Rust Programming Language*][book]-ə baxın.
///
/// `Fn` traits üçün xüsusi sintaksis də qeyd olunur (məsələn
/// `Fn(usize, bool) -> istifadə edin)).Bunun texniki detalları ilə maraqlananlar [the relevant section in the *Rustonomicon*][nomicon]-ə müraciət edə bilərlər.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Bağlanmağa çağırırıq
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` parametri istifadə olunur
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // belə ki regex həmin `&str: !FnMut`-ə etibar edə bilər
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Zəng əməliyyatını həyata keçirir.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Dəyişdirilə bilən bir alıcı götürən zəng operatorunun versiyası.
///
/// `FnMut` nümunələri dəfələrlə çağırıla bilər və vəziyyəti dəyişdirə bilər.
///
/// `FnMut` tutulan dəyişənlərə, həmçinin [`Fn`] tətbiq edən bütün növlərə, məsələn, (safe) [function pointers]-ə dəyişdirilə bilən istinadları alan bağlamalarla avtomatik olaraq həyata keçirilir (`FnMut`, [`Fn`]-in supertrait olduğundan).
/// Əlavə olaraq, `FnMut` tətbiq edən hər hansı bir `F` növü üçün `&mut F` də `FnMut` tətbiq edir.
///
/// [`FnOnce`], `FnMut`-nin supertrait olduğundan [`FnOnce`]-in istənilən bir nümunəsi, [`FnOnce`]-in gözlənildiyi yerdə istifadə edilə bilər və [`Fn`]-in `FnMut`-nin alt boğazı olduğu üçün, `FnMut`-in gözlənildiyi yerdə istənilən [`Fn`]-dən istifadə edilə bilər.
///
/// Funksiyaya bənzər bir növ parametrini qəbul etmək istədiyiniz və vəziyyəti mutasiya etməsinə icazə verərkən dəfələrlə zəng etməyiniz lazım olduqda, `FnMut`-i bir bağlayıcı olaraq istifadə edin.
/// Parametrin vəziyyəti mutasiya etməsini istəmirsinizsə, [`Fn`]-i bir bağlama olaraq istifadə edin;dəfələrlə zəng etmək lazım deyilsə, [`FnOnce`] istifadə edin.
///
/// Bu mövzuda daha çox məlumat üçün [chapter on closures in *The Rust Programming Language*][book]-ə baxın.
///
/// `Fn` traits üçün xüsusi sintaksis də qeyd olunur (məsələn
/// `Fn(usize, bool) -> istifadə edin)).Bunun texniki detalları ilə maraqlananlar [the relevant section in the *Rustonomicon*][nomicon]-ə müraciət edə bilərlər.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Dəyişkən bir şəkildə tutulan bir bağlanma çağırırıq
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` parametri istifadə olunur
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // belə ki regex həmin `&str: !FnMut`-ə etibar edə bilər
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Zəng əməliyyatını həyata keçirir.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Çağırış operatorunun əlavə dəyər qəbuledicisi qəbul edən versiyası.
///
/// `FnOnce` nümunələri çağırıla bilər, ancaq bir neçə dəfə zəng edilə bilməz.Bu səbəbdən bir növ haqqında bilinən tək şey `FnOnce` tətbiq etməsidirsə, yalnız bir dəfə adlandırıla bilər.
///
/// `FnOnce` tutulan dəyişənləri istehlak edə bilən qapanmalar və [`FnMut`] tətbiq edən bütün növlər, məsələn, (safe) [function pointers] (`FnOnce`, [`FnMut`]-in supertrait olduğundan) tərəfindən avtomatik olaraq həyata keçirilir.
///
///
/// Həm [`Fn`], həm də [`FnMut`] `FnOnce` alt yazıları olduğundan `FnOnce` və ya [`FnMut`] nümunələri `FnOnce`-in gözlənildiyi yerdə istifadə edilə bilər.
///
/// Funksiya tipli bir parametr qəbul etmək istədiyiniz zaman və yalnız bir dəfə zəng etməyiniz lazım olduqda, `FnOnce`-i bir bağlayıcı olaraq istifadə edin.
/// Parametrə təkrar-təkrar zəng etməyiniz lazımdırsa, [`FnMut`]-i bağlı olaraq istifadə edin;vəziyyəti mutasiya etməməyinizə ehtiyacınız varsa, [`Fn`] istifadə edin.
///
/// Bu mövzuda daha çox məlumat üçün [chapter on closures in *The Rust Programming Language*][book]-ə baxın.
///
/// `Fn` traits üçün xüsusi sintaksis də qeyd olunur (məsələn
/// `Fn(usize, bool) -> istifadə edin)).Bunun texniki detalları ilə maraqlananlar [the relevant section in the *Rustonomicon*][nomicon]-ə müraciət edə bilərlər.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` parametri istifadə olunur
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ələ keçirdiyi dəyişənləri istehlak edir, buna görə dəfədən çox işlədilə bilməz.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()`-i yenidən çağırmağa cəhd etmək, `func` üçün `use of moved value` səhvini atacaq.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` artıq bu nöqtədə çağırıla bilməz
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // belə ki regex həmin `&str: !FnMut`-ə etibar edə bilər
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Çağırış operatoru istifadə edildikdən sonra qaytarılmış növ.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Zəng əməliyyatını həyata keçirir.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}