use crate::marker::Unsize;

/// Trait, bunun pointee ölçüsünün dəyişdirilə biləcəyi bir göstərici və ya bir bükücü olduğunu göstərir.
///
/// Daha ətraflı məlumat üçün [DST coercion RFC][dst-coerce] və [the nomicon entry on coercion][nomicon-coerce]-ə baxın.
///
/// Yerləşdirilmiş göstərici növləri üçün `T` göstəriciləri, `T: Unsize<U>` nazik bir göstəricidən yağ göstəricisinə çevrilərsə `U` göstəricilərinə məcbur ediləcəkdir.
///
/// Xüsusi növlər üçün buradakı məcburetmə, `CoerceUnsized<Foo<U>> for Foo<T>`-in bir təsiri olduğu təqdirdə `Foo<T>`-dən `Foo<U>`-ə məcbur etməklə işləyir.
/// Belə bir təsəvvür yalnız `Foo<T>`-də `T`-i əhatə edən yalnız bir fantomdata olmayan sahəyə sahib olduqda yazıla bilər.
/// Bu sahənin növü `Bar<T>`-dirsə, `CoerceUnsized<Bar<U>> for Bar<T>`-in tətbiqi mövcud olmalıdır.
/// Zorlama, `Bar<T>` sahəsini `Bar<U>`-ə məcbur etmək və `Foo<T>`-dən qalan sahələri dolduraraq `Foo<U>` yaratmaqla işləyəcəkdir.
/// Bu, bir göstərici sahəsinə effektiv şəkildə gedəcək və bunu məcbur edəcəkdir.
///
/// Ümumiyyətlə, ağıllı göstəricilər üçün, `T`-in özünə bağlı bir isteğe bağlı `?Sized` ilə `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` tətbiq edəcəksiniz.
/// `T` və `RefCell<T>` kimi birbaşa `T` yerləşdirən sarmal tipləri üçün birbaşa `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` tətbiq edə bilərsiniz.
///
/// Bu, `Cell<Box<T>>` kimi növlərin məcburiyyətinin işləməsinə imkan verəcəkdir.
///
/// [`Unsize`][unsize] göstəricilərin arxasında olduqda DST-lərə məcbur edilə bilən növləri qeyd etmək üçün istifadə olunur.Tərtibçi tərəfindən avtomatik olaraq həyata keçirilir.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Bu, metodun qəbuledici növünün göndərilə biləcəyini yoxlamaq üçün obyekt təhlükəsizliyi üçün istifadə olunur.
///
/// trait tətbiqetmə nümunəsi:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}