//! Həddindən artıq yüklənən operatorlar.
//!
//! Bu traits-nin tətbiqi müəyyən operatorları həddindən artıq yükləməyə imkan verir.
//!
//! Bu traits-dan bəziləri prelude tərəfindən idxal olunur, buna görə hər Rust proqramında mövcuddur.Yalnız traits tərəfindən dəstəklənən operatorlar həddindən artıq yüklənə bilər.
//! Məsələn, (`+`) əlavə operatoru [`Add`] trait vasitəsilə həddindən artıq yüklənə bilər, lakin (`=`) təyinat operatorunun trait arxası olmadığı üçün onun semantikasını çox yükləmək üçün bir yol yoxdur.
//! Əlavə olaraq, bu modul yeni operatorlar yaratmaq üçün heç bir mexanizm təmin etmir.
//! Xassəsiz həddindən artıq yükləmə və ya xüsusi operatorlar tələb olunursa, Rust sintaksisini genişləndirmək üçün makrolara və ya kompilyator plaginlərinə baxmalısınız.
//!
//! Operator traits-nin tətbiqləri, adi mənalarını və [operator precedence]-ni nəzərə alaraq, müvafiq kontekstlərdə təəccüblü olmamalıdır.
//! Məsələn, [`Mul`] tətbiq edərkən əməliyyatın vurma ilə bir bənzərliyi olmalıdır (və assosiativlik kimi gözlənilən xüsusiyyətləri bölüşmək lazımdır).
//!
//! Qeyd edək ki, `&&` və `||` operatorları qısaqapanma, yəni yalnız ikinci əmrini nəticəyə töhfə verərsə qiymətləndirirlər.Bu davranış traits tərəfindən tətbiq olunmadığından, `&&` və `||` həddindən artıq yüklənən operatorlar kimi dəstəklənmir.
//!
//! Operatorların çoxu operandlarını dəyərinə görə götürürlər.Daxili tipləri əhatə edən qeyri-ümumi kontekstlərdə bu ümumiyyətlə problem deyil.
//! Bununla birlikdə, bu operatorlardan ümumi kodda istifadə etmək, operatorların onları istehlak etməsinə icazə vermək əvəzinə dəyərlərin yenidən istifadə edilməsi lazım olduqda bir az diqqət tələb edir.Bir seçim bəzən [`clone`] istifadə etməkdir.
//! Başqa bir seçim, istinadlar üçün əlavə operator tətbiqetmələrini təmin edən növlərə etibar etməkdir.
//! Məsələn, əlavə etməyi dəstəkləməsi lazım olan istifadəçi tərəfindən təyin olunan `T` tipi üçün, ehtimal ki, `T` və `&T`-in traits [`Add<T>`][`Add`] və [`Add<&T>`][`Add`] tətbiq etmələri yaxşı bir fikirdir ki, ümumi kod lazımsız klonlama olmadan yazıla bilər.
//!
//!
//! # Examples
//!
//! Bu misal, [`Add`] və [`Sub`] tətbiq edən bir `Point` quruluşu yaradır və sonra iki 'Nöqtənin əlavə və çıxılmasını nümayiş etdirir.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Bir nümunə tətbiqi üçün hər trait sənədlərinə baxın.
//!
//! [`Fn`], [`FnMut`] və [`FnOnce`] traits, funksiyalar kimi çağırıla bilən növlər tərəfindən həyata keçirilir.Qeyd edək ki, [`Fn`] `&self`, [`FnMut`] `&mut self` və [`FnOnce`] `self` alır.
//! Bunlar bir nümunədə çağırıla bilən üç növ üsula uyğundur: istinadla çağırış, dəyişdirilə bilən istinad və çağırışla dəyər.
//! Bu traits-nin ən geniş yayılmış istifadəsi funksiyaları və ya bağlamaları arqument kimi qəbul edən daha yüksək səviyyəli funksiyaların sərhədləri kimi çıxış etməkdir.
//!
//! Parametr olaraq [`Fn`] götürmək:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Parametr olaraq [`FnMut`] götürmək:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Parametr olaraq [`FnOnce`] götürmək:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ələ keçirdiyi dəyişənləri istehlak edir, buna görə dəfədən çox işlədilə bilməz
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()`-i yenidən çağırmağa cəhd etmək, `func` üçün `use of moved value` səhvini atacaq
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` artıq bu nöqtədə çağırıla bilməz
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;