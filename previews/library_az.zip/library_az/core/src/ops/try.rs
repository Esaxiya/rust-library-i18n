/// `?` operatorunun davranışını fərdiləşdirmək üçün bir trait.
///
/// `Try` tətbiq edən bir növ, onu success/failure ikilemesi baxımından izləmək üçün kanonik bir yoldur.
/// Bu trait həm bu müvəffəqiyyət və ya uğursuzluq dəyərlərini mövcud bir nümunədən çıxarmağa, həm də bir müvəffəqiyyət və ya uğursuzluq dəyərindən yeni bir nümunə yaratmağa imkan verir.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Uğurlu göründüyü zaman bu dəyərin növü.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Uğursuz hesab edildikdə bu dəyərin növü.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" operatorunu tətbiq edir.`Ok(t)`-in qaytarılması icrağın normal davam etməsi və `?`-nin nəticəsi `t` dəyəridir.
    /// `Err(e)`-in qaytarılması, branch-nin `catch`-i əhatə edən daxili hissəyə və ya funksiyadan qayıtması deməkdir.
    ///
    /// Bir `Err(e)` nəticəsi qaytarılırsa, `e` dəyəri əhatə dairəsinin qaytarma növündə "wrapped" olacaqdır (özü də `Try` tətbiq etməlidir).
    ///
    /// Xüsusilə, `X::from_error(From::from(e))` dəyəri qaytarılır, burada `X`, əhatə etmə funksiyasının qayıtma növüdür.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Kompozit nəticəni yaratmaq üçün bir səhv dəyərini sarın.
    /// Məsələn, `Result::Err(x)` və `Result::from_error(x)` bərabərdir.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Kompozit nəticəni yaratmaq üçün OK dəyərini sarın.
    /// Məsələn, `Result::Ok(x)` və `Result::from_ok(x)` bərabərdir.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}