/// Dağıdıcıda xüsusi kod.
///
/// Artıq bir dəyərə ehtiyac qalmadığında, Rust bu dəyər üzərində bir "destructor" işlədəcəkdir.
/// Dəyərin artıq tələb olunmamasının ən ümumi yolu, əhatə dairəsindən çıxdıqda.Dağıdıcılar hələ də başqa şərtlərdə qaça bilər, amma burada nümunələrin əhatə dairəsinə diqqət yetirəcəyik.
/// Bu digər hallardan bəziləri haqqında məlumat əldə etmək üçün lütfən [the reference] bölməsinə baxın.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Bu dağıdıcı iki komponentdən ibarətdir:
/// - Bu xüsusi `Drop` trait növü üçün tətbiq olunarsa, bu dəyər üçün `Drop::drop`-ə bir zəng.
/// - Avtomatik olaraq yaradılan "drop glue", bu dəyərin bütün sahələrinin dağıdıcılarını təkrarən çağırır.
///
/// Rust avtomatik olaraq bütün mövcud sahələrin destruktorlarını axtardığından, əksər hallarda `Drop` tətbiq etmək lazım deyil.
/// Ancaq faydalı olduğu bəzi hallar var, məsələn bir mənbəyi birbaşa idarə edən növlər üçün.
/// Bu qaynaq yaddaş ola bilər, fayl təsvir edici ola bilər, şəbəkə yuvası ola bilər.
/// Bu tip bir dəyər artıq istifadə olunmayandan sonra, yaddaşını boşaltaraq və ya faylı və ya yuvanı bağlayaraq öz mənbəyini "clean up" etməlidir.
/// Bu, bir dağıdıcı işidir və bu səbəbdən `Drop::drop`-in işi.
///
/// ## Examples
///
/// Dağıdıcıları fəaliyyətdə görmək üçün aşağıdakı proqrama nəzər salaq:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust, əvvəlcə `_x` üçün `Drop::drop` i, daha sonra həm `_x.one` həm də `_x.two` üçün zəng edəcək, yəni bunun işə salınması yazdırılacaq
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// `HasTwoDrop` üçün `Drop` tətbiqini götürsək də, sahələrinin destruktorları hələ də çağırılır.
/// Bu nəticələnəcəkdir
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## `Drop::drop`-ə özünüz zəng edə bilməzsiniz
///
/// `Drop::drop` bir dəyəri təmizləmək üçün istifadə olunduğundan, metod çağırıldıqdan sonra bu dəyəri istifadə etmək təhlükəli ola bilər.
/// `Drop::drop` girişinə sahiblik etmədiyi üçün Rust, birbaşa `Drop::drop`-ə zəng etməyinizə icazə verməyərək sui-istifadənin qarşısını alır.
///
/// Başqa sözlə, yuxarıdakı nümunədə `Drop::drop`-ə açıq şəkildə zəng etməyə çalışsanız, bir kompilyator səhvini alacaqsınız.
///
/// Açıqca bir dəyərin dağıdıcısını çağırmaq istəsəniz, bunun əvəzinə [`mem::drop`] istifadə edilə bilər.
///
/// [`mem::drop`]: drop
///
/// ## Sifarişi buraxın
///
/// Hərçənd əvvəlki iki `HasDrop`-dən hansı düşər?Quruluşlar üçün elan olunduqları sırayla eyni: əvvəlcə `one`, sonra `two`.
/// Bunu özünüz sınamaq istəsəniz, yuxarıdakı `HasDrop`-i bir tam olaraq bəzi məlumatlar ehtiva etmək üçün dəyişdirə və sonra `Drop` daxilindəki `println!`-də istifadə edə bilərsiniz.
/// Bu davranış dil tərəfindən təmin edilir.
///
/// Konstruksiyalardan fərqli olaraq yerli dəyişənlər tərs qaydada buraxılır:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Bu yazdıracaq
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Xahiş edirəm tam qaydalar üçün [the reference]-ə baxın.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` və `Drop` eksklüzivdir
///
/// Həm [`Copy`], həm də `Drop`-i eyni tipdə tətbiq edə bilməzsiniz.`Copy` olan növlər kompilyator tərəfindən dolayısı ilə çoxalır və məhv edənlərin nə vaxt və nə qədər edam ediləcəyini proqnozlaşdırmaq çox çətindir.
///
/// Beləliklə, bu növlərin destruktorları ola bilməz.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Bu növ üçün destruktoru icra edir.
    ///
    /// Bu metod, dəyər əhatə dairəsindən çıxdıqda dolayı olaraq çağırılır və açıq şəkildə çağırıla bilməz (bu [E0040] kompilyator səhvidir).
    /// Bununla birlikdə, prelude-dəki [`mem::drop`] funksiyası arqumentin `Drop` tətbiqini çağırmaq üçün istifadə edilə bilər.
    ///
    /// Bu metod çağırıldıqda, `self` hələ ayrılmamışdır.
    /// Bu yalnız metod bitdikdən sonra baş verir.
    /// Bu belə olmasaydı, `self` asılmış bir istinad olardı.
    ///
    /// # Panics
    ///
    /// Bir [`panic!`]-in açıldığı zaman `drop`-ə zəng edəcəyini nəzərə alsaq, `drop` tətbiqindəki hər hansı bir [`panic!`]-ni ləğv edəcək.
    ///
    /// Qeyd edək ki, bu panics olsa belə, dəyər düşmüş hesab olunur;
    /// `drop`-in yenidən çağırılmasına səbəb olmamalısınız.
    /// Bu normal olaraq kompilyator tərəfindən avtomatik olaraq işlənir, lakin təhlükəli kod istifadə edilərkən bəzən istəmədən, xüsusən də [`ptr::drop_in_place`] istifadə edərkən baş verə bilər.
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}