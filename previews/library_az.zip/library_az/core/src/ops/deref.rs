/// `*v` kimi dəyişməz tərifləmə əməliyyatları üçün istifadə olunur.
///
/// X001, dəyişməz kontekstlərdə (unary) `*` operatoru ilə açıq-aşkar bir tərifləmə əməliyyatları üçün istifadə edilməsinə əlavə olaraq, `Deref` bir çox vəziyyətdə də tərtibçi tərəfindən dolayısı ilə istifadə olunur.
/// Bu mexanizmə ['`Deref` coercion'][more] deyilir.
/// Dəyişdirilə bilən kontekstlərdə [`DerefMut`] istifadə olunur.
///
/// Ağıllı göstəricilər üçün `Deref` tətbiq etmək, arxalarındakı məlumatlara girişin rahatlığını təmin edir, buna görə də `Deref` tətbiq edirlər.
/// Digər tərəfdən, `Deref` və [`DerefMut`] ilə əlaqəli qaydalar xüsusi olaraq ağıllı göstəriciləri yerləşdirmək üçün hazırlanmışdır.
/// Bu səbəbdən qarışıqlığı qarşısını almaq üçün **`Deref` yalnız ağıllı göstəricilər** üçün tətbiq olunmalıdır.
///
/// Bənzər səbəblərə görə **bu trait heç vaxt uğursuz olmamalıdır**.`Deref` dolayısı ilə çağrıldıqda ayrılma zamanı baş verən uğursuzluq son dərəcə qarışıq ola bilər.
///
/// # `Deref` məcburiyyəti haqqında daha çox məlumat
///
/// `T` `Deref<Target = U>` tətbiq edirsə və `x` `T` tipli bir dəyərdirsə, o zaman:
///
/// * Dəyişilməz kontekstlərdə `*x` (burada `T` nə bir istinad, nə də bir işarədir) `* Deref::deref(&x)`-ə bərabərdir.
/// * `&T` tipli dəyərlər `&U` tipli dəyərlərə məcbur edilir
/// * `T` `U` tipli bütün (immutable) metodlarını dolayısı ilə həyata keçirir.
///
/// Daha ətraflı məlumat üçün [the chapter in *The Rust Programming Language*][book], həmçinin [the dereference operator][ref-deref-op], [method resolution] və [type coercions] istinad hissələrini ziyarət edin.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Strukturdan ayrılmaqla əldə edilə bilən tək bir sahəyə sahib bir struktur.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Ayrılmadan sonra yaranan növ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Dəyəri izah edin.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;`-də olduğu kimi dəyişdirilə bilən təxirə salma əməliyyatları üçün istifadə olunur.
///
/// Dəyişilə bilən kontekstlərdə (unary) `*` operatoru ilə açıq tərifləmə əməliyyatları üçün istifadə edilməklə yanaşı, `DerefMut` də bir çox vəziyyətdə tərtibçi tərəfindən dolayısı ilə istifadə olunur.
/// Bu mexanizmə ['`Deref` coercion'][more] deyilir.
/// Dəyişilməz kontekstlərdə [`Deref`] istifadə olunur.
///
/// Ağıllı göstəricilər üçün `DerefMut` tətbiq etmək, arxalarındakı məlumatların mutasiyasını əlverişli edir, buna görə də `DerefMut` tətbiq edirlər.
/// Digər tərəfdən, [`Deref`] və `DerefMut` ilə əlaqəli qaydalar xüsusi olaraq ağıllı göstəriciləri yerləşdirmək üçün hazırlanmışdır.
/// Bu səbəbdən qarışıqlığı qarşısını almaq üçün **`DerefMut` yalnız ağıllı göstəricilər** üçün tətbiq olunmalıdır.
///
/// Bənzər səbəblərə görə **bu trait heç vaxt uğursuz olmamalıdır**.`DerefMut` dolayısı ilə çağrıldıqda ayrılma zamanı baş verən uğursuzluq son dərəcə qarışıq ola bilər.
///
/// # `Deref` məcburiyyəti haqqında daha çox məlumat
///
/// `T` `DerefMut<Target = U>` tətbiq edirsə və `x` `T` tipli bir dəyərdirsə, o zaman:
///
/// * Dəyişdirilə bilən kontekstlərdə `*x` (burada `T` nə bir istinaddır, nə də bir işarədir) `* DerefMut::deref_mut(&mut x)`-ə bərabərdir.
/// * `&mut T` tipli dəyərlər `&mut U` tipli dəyərlərə məcbur edilir
/// * `T` `U` tipli bütün (mutable) metodlarını dolayısı ilə həyata keçirir.
///
/// Daha ətraflı məlumat üçün [the chapter in *The Rust Programming Language*][book], həmçinin [the dereference operator][ref-deref-op], [method resolution] və [type coercions] istinad hissələrini ziyarət edin.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Strukturdan ayrılmaqla dəyişdirilə bilən tək bir sahəyə sahib bir quruluş.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Dəyəri mütəmadi olaraq ifadə edir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Bir quruluşun `arbitrary_self_types` xüsusiyyəti olmadan metod qəbuledicisi kimi istifadə edilə biləcəyini göstərir.
///
/// Bu, `Box<T>`, `Rc<T>`, `&T` və `Pin<P>` kimi stdlib göstərici növləri tərəfindən həyata keçirilir.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}