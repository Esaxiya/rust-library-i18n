//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char`-in sahib ola biləcəyi ən yüksək etibarlı kod nöqtəsi.
    ///
    /// `char` bir [Unicode Scalar Value], yəni bir [Code Point] olduğu deməkdir, ancaq yalnız müəyyən bir sıra içərisindədir.
    /// `MAX` etibarlı bir [Unicode Scalar Value] olan ən yüksək etibarlı kod nöqtəsidir.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` (), kod açma səhvini təmsil etmək üçün Unicode-da istifadə olunur.
    ///
    /// Məsələn, [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy)-ə düzgün olmayan UTF-8 bayt verərkən baş verə bilər.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// `char` və `str` metodlarının Unicode hissələrinin əsas götürdüyü [Unicode](http://www.unicode.org/) versiyası.
    ///
    /// Unicode-un yeni versiyaları müntəzəm olaraq yayımlanır və daha sonra Unicode-dan asılı olaraq standart kitabxanadakı bütün metodlar yenilənir.
    /// Buna görə bəzi `char` və `str` metodlarının davranışı və bu sabitin dəyəri zamanla dəyişir.
    /// Bu qırılma bir dəyişiklik olaraq qəbul edilmir.
    ///
    /// Versiya nömrələmə sxemi [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4)-də izah olunur.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter`-də UTF-16 kodlanmış kod nöqtələrinin üstündə bir iterator yaradır, cütləşdirilməmiş surroqatları "Err" lərə qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` nəticələrini əvəzetmə xarakteri ilə əvəz etməklə kayıplı bir dekoder əldə etmək olar:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32`-i `char`-ə çevirir.
    ///
    /// Diqqət yetirin ki, bütün char'lar etibarlıdır ['u32'] və birinə atıla bilər
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Lakin bunun tərsi doğru deyil: bütün etibarlı [`u32`] 'lər etibarlı deyil.
    /// `from_u32()` giriş bir `char` üçün etibarlı bir dəyər deyilsə `None` qaytaracaq.
    ///
    /// Bu çekləri laqeyd edən bu funksiyanın təhlükəli versiyası üçün [`from_u32_unchecked`]-ə baxın.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Giriş etibarlı bir `char` olmadığı zaman `None` qaytarılması:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// `u32`-i etibarlılığa məhəl qoymadan `char`-ə çevirir.
    ///
    /// Diqqət yetirin ki, bütün char'lar etibarlıdır ['u32'] və birinə atıla bilər
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Lakin bunun tərsi doğru deyil: bütün etibarlı [`u32`] 'lər etibarlı deyil.
    /// `from_u32_unchecked()` buna məhəl qoymayacaq və kor-koranə `char`-ə atacaq, ehtimal ki, etibarsız birini yaradır.
    ///
    ///
    /// # Safety
    ///
    /// Bu funksiya etibarsızdır, çünki etibarsız `char` dəyərləri yarada bilər.
    ///
    /// Bu funksiyanın etibarlı bir versiyası üçün [`from_u32`] funksiyasına baxın.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // TƏHLÜKƏSİZLİK: təhlükəsizlik müqaviləsi axtaran tərəfindən təmin edilməlidir.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Verilən radixdakı bir rəqəmi `char`-ə çevirir.
    ///
    /// Burada bir 'radix' bəzən 'base' də adlandırılır.
    /// İki ortalama radius ikili ədədi, on radiusunu onluğa və on altılıq onaltılıq radiusa bənzər ümumi dəyərlər göstərir.
    ///
    /// Təsadüfi radikallar dəstəklənir.
    ///
    /// `from_digit()` giriş verilən radiusda bir rəqəm deyilsə `None` qaytaracaq.
    ///
    /// # Panics
    ///
    /// 36-dan böyük bir radius verildiyi təqdirdə Panics.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Ondalık 11 baza 16-da tək rəqəmdir
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Giriş rəqəmi olmadıqda `None`-in qaytarılması:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// panic-yə səbəb olan böyük bir radius keçmək:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// `char`-nin verilmiş radiusdakı bir rəqəm olub olmadığını yoxlayır.
    ///
    /// Burada bir 'radix' bəzən 'base' də adlandırılır.
    /// İki ortalama radius ikili ədədi, on radiusunu onluğa və on altılıq onaltılıq radiusa bənzər ümumi dəyərlər göstərir.
    ///
    /// Təsadüfi radikallar dəstəklənir.
    ///
    /// [`is_numeric()`] ilə müqayisədə bu funksiya yalnız `0-9`, `a-z` və `A-Z` simvollarını tanıyır.
    ///
    /// 'Digit' yalnız aşağıdakı simvol olduğu müəyyən edilmişdir:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' haqqında daha geniş bir anlayış üçün [`is_numeric()`]-ə baxın.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// 36-dan böyük bir radius verildiyi təqdirdə Panics.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// panic-yə səbəb olan böyük bir radius keçmək:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char`-i verilmiş radiusdakı rəqəmə çevirir.
    ///
    /// Burada bir 'radix' bəzən 'base' də adlandırılır.
    /// İki ortalama radius ikili ədədi, on radiusunu onluğa və on altılıq onaltılıq radiusa bənzər ümumi dəyərlər göstərir.
    ///
    /// Təsadüfi radikallar dəstəklənir.
    ///
    /// 'Digit' yalnız aşağıdakı simvol olduğu müəyyən edilmişdir:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// `char` verilmiş radiusdakı bir rəqəmə istinad etmirsə `None` qaytarır.
    ///
    /// # Panics
    ///
    /// 36-dan böyük bir radius verildiyi təqdirdə Panics.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Rəqəmsiz keçid uğursuzluqla nəticələnir:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// panic-yə səbəb olan böyük bir radius keçmək:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kod `radix` sabit və 10 və ya daha kiçik olduğu hallarda icra sürətini yaxşılaşdırmaq üçün burada bölünür
        //
        let val = if likely(radix <= 10) {
            // Rəqəm olmasa, radixdən böyük bir rəqəm yaradılacaqdır.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Bir xarakterin onaltılıq Unicode qaçışını `char`s olaraq verən bir iteratoru qaytarır.
    ///
    /// Bu, `\u{NNNNNN}` formasının onaltılıq bir təmsil olduğu `\u{NNNNNN}` formasının Rust sintaksisinə malik simvollardan qaçacaqdır.
    ///
    ///
    /// # Examples
    ///
    /// Bir iterator kimi:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Birbaşa `println!` istifadə:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Hər ikisi bərabərdir:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` istifadə:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // və ya 1-in verilməsi c==0 üçün kodun bir rəqəmin yazılmasını və (eynidır)(31, 32) altından qaçmağın qarşısını aldığını hesablayır.
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ən əhəmiyyətli hex rəqəminin indeksi
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// İsteğe bağlı olaraq Genişləndirilmiş Grapheme kod nöqtələrindən qaçmağa icazə verən genişləndirilmiş `escape_debug` versiyası.
    /// Bu, bir simlin başlanğıcında olduqda boşluq işarələri kimi simvolları daha yaxşı formatlaşdırmağımıza imkan verir.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Bir xarakterin hərfi qaçma kodunu `char`s olaraq verən bir iteratoru qaytarır.
    ///
    /// Bu, `str` və ya `char`-in `Debug` tətbiqetmələrinə bənzər simvollardan qaçacaqdır.
    ///
    ///
    /// # Examples
    ///
    /// Bir iterator kimi:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Birbaşa `println!` istifadə:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Hər ikisi bərabərdir:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` istifadə:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Bir xarakterin hərfi qaçma kodunu `char`s olaraq verən bir iteratoru qaytarır.
    ///
    /// Varsayılan, C++ 11 və bənzər C ailəsi dilləri daxil olmaqla, müxtəlif dillərdə qanuni olan ədəbiyyat istehsalına qarşı qərəzli olaraq seçilir.
    /// Tam qaydalar bunlardır:
    ///
    /// * Tab `\t` olaraq qaçdı.
    /// * Daşıma qayıtması `\r` olaraq qaçdı.
    /// * Xətt yemi `\n` olaraq qaçdı.
    /// * Tək təklif `\'` olaraq qaçdı.
    /// * `\"` olaraq ikiqat sitat qaçdı.
    /// * Ters eğik `\\` olaraq qaçdı.
    /// * 'Yazdırılabilir ASCII' aralığındakı `0x20` .. `0x7e` daxil hər hansı bir xarakter qaçmadı.
    /// * Bütün digər simvollara onaltılıq Unicode qaçışları verilir;bax [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Bir iterator kimi:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Birbaşa `println!` istifadə:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Hər ikisi bərabərdir:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` istifadə:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8-də kodlandığı halda bu `char`-in ehtiyac duyduğu bayt sayını qaytarır.
    ///
    /// Bu bayt sayı həmişə daxil olmaqla 1 ilə 4 arasındadır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` tipi onun məzmununun UTF-8 olmasına zəmanət verir və beləliklə hər bir kod nöqtəsinin `&str`-in özündə `char` olaraq göstərildiyi təqdirdə çəkəcəyi uzunluğu müqayisə edə bilərik:
    ///
    ///
    /// ```
    /// // charlar kimi
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // hər ikisi üç bayt şəklində təmsil edilə bilər
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // bir &str olaraq, bu ikisi UTF-8-də kodlanır
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // cəmi altı bayt götürdüklərini görə bilərik ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... eynən &str kimi
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16-də kodlandığı təqdirdə `char`-in ehtiyac duyduğu 16 bit kod vahidlərinin sayını qaytarır.
    ///
    ///
    /// Bu konsepsiyanın daha çox izahı üçün [`len_utf8()`] sənədlərinə baxın.
    /// Bu funksiya bir güzgüdür, lakin UTF-8 əvəzinə UTF-16 üçün.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Bu xarakteri UTF-8 olaraq verilən bayt tamponuna kodlayır və sonra kodlanmış simvol olan buferin sublice-sini qaytarır.
    ///
    ///
    /// # Panics
    ///
    /// Tampon kifayət qədər böyük deyilsə Panics.
    /// Dörd uzunluqlu bir tampon istənilən `char` kodlaşdırmaq üçün kifayət qədər böyükdür.
    ///
    /// # Examples
    ///
    /// Bu nümunələrin hər ikisində 'ß' kodlaşdırmaq üçün iki bayt çəkir.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Çox kiçik bir tampon:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // TƏHLÜKƏSİZLİK: `char` vəkil deyildir, buna görə də bu UTF-8 etibarlıdır.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Bu simvolu UTF-16 olaraq verilən `u16` tamponuna kodlayır və sonra kodlanmış simvol olan buferin sublice-sini qaytarır.
    ///
    ///
    /// # Panics
    ///
    /// Tampon kifayət qədər böyük deyilsə Panics.
    /// 2 uzunluğunda bir tampon istənilən `char` kodlaşdırmaq üçün kifayət qədər böyükdür.
    ///
    /// # Examples
    ///
    /// Bu nümunələrin hər ikisində '𝕊' kodlaşdırmaq üçün iki u16 alır.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Çox kiçik bir tampon:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Bu `char` `Alphabetic` xüsusiyyətinə sahibdirsə `true` qaytarır.
    ///
    /// `Alphabetic` [Unicode Standard]-in Fəsil 4-də (Character Properties) təsvir edilmiş və [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-də göstərilmişdir.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // sevgi çox şeydir, amma əlifba deyil
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Bu `char` `Lowercase` xüsusiyyətinə sahibdirsə `true` qaytarır.
    ///
    /// `Lowercase` [Unicode Standard]-in Fəsil 4-də (Character Properties) təsvir edilmiş və [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-də göstərilmişdir.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Müxtəlif Çin yazılarının və punktuasiyalarının vəziyyəti yoxdur və buna görə:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Bu `char` `Uppercase` xüsusiyyətinə sahibdirsə `true` qaytarır.
    ///
    /// `Uppercase` [Unicode Standard]-in Fəsil 4-də (Character Properties) təsvir edilmiş və [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-də göstərilmişdir.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Müxtəlif Çin yazılarının və punktuasiyalarının vəziyyəti yoxdur və buna görə:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Bu `char` `White_Space` xüsusiyyətinə sahibdirsə `true` qaytarır.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`]-də göstərilmişdir.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // qırılmayan bir yer
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Bu `char` ya [`is_alphabetic()`], ya da [`is_numeric()`]-ni təmin edərsə `true` qaytarır.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Bu `char` nəzarət kodları üçün ümumi kateqoriyaya sahibdirsə, `true` qaytarır.
    ///
    /// İdarəetmə kodları (`Cc`-in ümumi kateqoriyası olan kod nöqtələri) [Unicode Standard]-in Fəsil 4-də (Character Properties) təsvir edilir və [Unicode Character Database][ucd] [`UnicodeData.txt`]-də göstərilir.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATORU
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Bu `char` `Grapheme_Extend` xüsusiyyətinə sahibdirsə `true` qaytarır.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29]-də təsvir edilir və [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-də göstərilir.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Bu `char` nömrələr üçün ümumi kateqoriyalardan birinə sahibdirsə, `true` qaytarır.
    ///
    /// Nömrələr üçün ümumi kateqoriyalar (onluq rəqəmlər üçün `Nd`, hərf kimi ədədi simvollar üçün `Nl` və digər ədədi simvollar üçün `No`) [Unicode Character Database][ucd] [`UnicodeData.txt`]-də göstərilmişdir.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Bu `char`-in kiçik hərflənməsini bir və ya daha çox olaraq verən bir iteratoru qaytarır
    /// `char`s.
    ///
    /// Bu `char`-də kiçik bir xəritə yoxdursa, təkrarlayıcı eyni `char` verir.
    ///
    /// Bu `char`, [Unicode Character Database][ucd] [`UnicodeData.txt`] tərəfindən verilmiş birə bir kiçik hərfləməyə sahibdirsə, iterator `char` verir.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Bu `char` xüsusi mülahizələr tələb edərsə (məs. Birdən çox '), iterator [`SpecialCasing.txt`] tərəfindən verilən `char' (lər) i verir.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Bu əməliyyat dərzisiz qeyd-şərtsiz bir xəritəçəkmə həyata keçirir.Yəni konversiya kontekstdən və dildən asılı deyil.
    ///
    /// [Unicode Standard]-də Fəsil 4 (Character Properties) ümumiyyətlə case mapping və Chapter 3 (Conformance) case dönüşümü üçün default alqoritmdən bəhs edir.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Bir iterator kimi:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Birbaşa `println!` istifadə:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Hər ikisi bərabərdir:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` istifadə:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Bəzən nəticə birdən çox simvol olur:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Həm böyük, həm də kiçik olmayan simvollar özlərinə çevrilir.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Bu `char`-in böyük və ya daha çox xəritəsini göstərən bir iteratoru qaytarır
    /// `char`s.
    ///
    /// Bu `char`-də böyük hərfləmə yoxdursa, təkrarlayıcı eyni `char` verir.
    ///
    /// Bu `char`-də [Unicode Character Database][ucd] [`UnicodeData.txt`] tərəfindən verilən birdən birə böyük hərfləşmə varsa, təkrarlayan `char` verir.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Bu `char` xüsusi mülahizələr tələb edərsə (məs. Birdən çox '), iterator [`SpecialCasing.txt`] tərəfindən verilən `char' (lər) i verir.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Bu əməliyyat dərzisiz qeyd-şərtsiz bir xəritəçəkmə həyata keçirir.Yəni konversiya kontekstdən və dildən asılı deyil.
    ///
    /// [Unicode Standard]-də Fəsil 4 (Character Properties) ümumiyyətlə case mapping və Chapter 3 (Conformance) case dönüşümü üçün default alqoritmdən bəhs edir.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Bir iterator kimi:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Birbaşa `println!` istifadə:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Hər ikisi bərabərdir:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` istifadə:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Bəzən nəticə birdən çox simvol olur:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Həm böyük, həm də kiçik olmayan simvollar özlərinə çevrilir.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Yerli qeyd
    ///
    /// Türk dilində 'i'-in Latın dilindəki qarşılığı iki əvəzinə beş formaya malikdir:
    ///
    /// * 'Dotless': I/ı, bəzən ï yazılır
    /// * 'Dotted': İ/i
    ///
    /// Qeyd edək ki, kiçik nöqtəli 'i' Latın dilində olduğu kimidir.Buna görə:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Buradakı `upper_i` dəyəri mətnin dilinə əsaslanır: `en-US`-də olsaq `"I"`, `tr_TR`-də olsaq `"İ"` olmalıdır.
    /// `to_uppercase()` bunu nəzərə almır və buna görə:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// dillər arasında tutur.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Dəyərin ASCII aralığında olub olmadığını yoxlayır.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Dəyərin ASCII böyük hərfinə bərabər bir surətini çıxarır.
    ///
    /// 'a'-'z' arasında ASCII hərfləri 'A'-'Z' arasında eşleştirilir, lakin ASCII olmayan hərflər dəyişdirilmir.
    ///
    /// Yerdəki dəyəri böyük göstərmək üçün [`make_ascii_uppercase()`] istifadə edin.
    ///
    /// ASCII olmayan simvollara əlavə olaraq ASCII simvollarını böyütmək üçün [`to_uppercase()`] istifadə edin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Dəyərin ASCII kiçik hərfinə bərabər bir surətini çıxarır.
    ///
    /// 'A'-'Z' arasında ASCII hərfləri 'a'-'z' arasında eşleştirilir, lakin ASCII olmayan hərflər dəyişdirilmir.
    ///
    /// Yerindəki dəyəri azaltmaq üçün [`make_ascii_lowercase()`] istifadə edin.
    ///
    /// ASCII olmayan simvollara əlavə olaraq ASCII simvollarını kiçikləşdirmək üçün [`to_lowercase()`] istifadə edin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// İki dəyərin ASCII halda həssas bir uyğunluq olduğunu yoxlayır.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)`-ə bərabərdir.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Bu növü yerindəki ASCII böyük hərfinə bərabərləşdirir.
    ///
    /// 'a'-'z' arasında ASCII hərfləri 'A'-'Z' arasında eşleştirilir, lakin ASCII olmayan hərflər dəyişdirilmir.
    ///
    /// Mövcud dəyərini dəyişdirmədən yeni bir üst səviyyəli dəyəri qaytarmaq üçün [`to_ascii_uppercase()`] istifadə edin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Bu növü yerindəki ASCII kiçik hərfinə bərabərləşdirir.
    ///
    /// 'A'-'Z' arasında ASCII hərfləri 'a'-'z' arasında eşleştirilir, lakin ASCII olmayan hərflər dəyişdirilmir.
    ///
    /// Mövcud dəyərini dəyişdirmədən yeni kiçik bir dəyər qaytarmaq üçün [`to_ascii_lowercase()`] istifadə edin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Dəyərin ASCII əlifba işarəsi olub olmadığını yoxlayır:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', və ya
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Dəyərin ASCII böyük hərfli olub olmadığını yoxlayır:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Dəyərin ASCII kiçik işarəli olub olmadığını yoxlayır:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Dəyərin ASCII alfasayısal bir simvol olub olmadığını yoxlayır:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', və ya
    /// - U + 0061 'a' ..=U + 007A 'z', və ya
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Dəyərin ASCII ondalık rəqəm olub olmadığını yoxlayır:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Dəyərin ASCII onaltılı rəqəm olub olmadığını yoxlayır:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', və ya
    /// - U + 0041 'A' ..=U + 0046 'F', və ya
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Dəyərin ASCII durğu işarəsi olub olmadığını yoxlayır:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, və ya
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, və ya
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, və ya
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Dəyərin ASCII qrafik xarakterli olub olmadığını yoxlayır:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Dəyərin ASCII boşluq işarəsi olub olmadığını yoxlayır:
    /// U + 0020 SPACE, U + 0009 ÜFİQİ TAB, U + 000A XƏTT YEMİ, U + 000C FORM YEMƏSİ və ya U + 000D DƏYİŞİQ QAYDASI.
    ///
    /// Rust, WhatWG Infra Standardın [definition of ASCII whitespace][infra-aw]-dən istifadə edir.Geniş istifadə olunan bir neçə başqa tərif var.
    /// Məsələn, [the POSIX locale][pct], yuxarıda göstərilən bütün simvolların yanında U + 000B VERTICAL TAB'ı da ehtiva edir, lakin-eyni spesifikasiyadan-[Bourne shell'daki "field splitting" üçün standart qayda][bfs]*only* SPACE, HORIZONTAL TAB və Boşluq kimi xətt Bəsləyin.
    ///
    ///
    /// Mövcud bir fayl formatını işləyəcək bir proqram yazırsınızsa, bu funksiyanı istifadə etməzdən əvvəl bu boşluğun boşluq tərifinin nə olduğunu yoxlayın.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Dəyərin ASCII nəzarət xarakteri olub olmadığını yoxlayır:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR və ya U + 007F DELETE.
    /// Qeyd edək ki, ASCII boşluq simvollarının əksəriyyəti idarəetmə simvollarıdır, lakin SPACE belə deyil.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Xam bir u32 dəyərini UTF-8 olaraq verilən bayt tamponuna kodlayır və sonra kodlanmış simvol ehtiva edən tamponun sublice qaytarır.
///
///
/// `char::encode_utf8`-dən fərqli olaraq, bu metod surroqat aralığındakı kod nöqtələrini də idarə edir.
/// (Vəkil aralığında bir `char` yaratmaq UB-dir.) Nəticə etibarlı [generalized UTF-8], lakin UTF-8 etibarlı deyil.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Tampon kifayət qədər böyük deyilsə Panics.
/// Dörd uzunluqlu bir tampon istənilən `char` kodlaşdırmaq üçün kifayət qədər böyükdür.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Çiy u32 dəyərini UTF-16 olaraq verilən `u16` tamponuna kodlayır və sonra kodlanmış simvol olan tamponun sublice qaytarır.
///
///
/// `char::encode_utf16`-dən fərqli olaraq, bu metod surroqat aralığındakı kod nöqtələrini də idarə edir.
/// (Surroqat aralığında bir `char` yaratmaq UB-dir.)
///
/// # Panics
///
/// Tampon kifayət qədər böyük deyilsə Panics.
/// 2 uzunluğunda bir tampon istənilən `char` kodlaşdırmaq üçün kifayət qədər böyükdür.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // TƏHLÜKƏSİZLİK: hər qol yazmaq üçün kifayət qədər bit olub olmadığını yoxlayır
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP düşür
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Əlavə təyyarələr surroqatlara girir.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}