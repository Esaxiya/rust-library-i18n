//! Xarakter çevrilmələri.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32`-i `char`-ə çevirir.
///
/// Diqqət yetirin ki, bütün [`char`] lər etibarlıdır ['u32'] və birinə atıla bilər
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Lakin bunun tərsi doğru deyil: bütün etibarlı [`u32`] s etibarlı [`char`] lər deyil.
/// `from_u32()` giriş bir [`char`] üçün etibarlı bir dəyər deyilsə `None` qaytaracaq.
///
/// Bu çekləri laqeyd edən bu funksiyanın təhlükəli versiyası üçün [`from_u32_unchecked`]-ə baxın.
///
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Giriş etibarlı bir [`char`] olmadığı zaman `None` qaytarılması:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// `u32`-i etibarlılığa məhəl qoymadan `char`-ə çevirir.
///
/// Diqqət yetirin ki, bütün [`char`] lər etibarlıdır ['u32'] və birinə atıla bilər
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Lakin bunun tərsi doğru deyil: bütün etibarlı [`u32`] s etibarlı [`char`] lər deyil.
/// `from_u32_unchecked()` buna məhəl qoymayacaq və kor-koranə [`char`]-ə atacaq, ehtimal ki, etibarsız birini yaradır.
///
///
/// # Safety
///
/// Bu funksiya etibarsızdır, çünki etibarsız `char` dəyərləri yarada bilər.
///
/// Bu funksiyanın etibarlı bir versiyası üçün [`from_u32`] funksiyasına baxın.
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // TƏHLÜKƏSİZLİK: zəng edən `i`-nin etibarlı bir char dəyəri olduğuna zəmanət verməlidir.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`]-i [`u32`]-ə çevirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`]-i [`u64`]-ə çevirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char kod nöqtəsinin dəyərinə atılır, sonra sıfırla 64 bitə qədər artırılır.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]-ə baxın
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`]-i [`u128`]-ə çevirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Char kod nöqtəsinin dəyərinə atılır, sonra 128 bitə qədər sıfır uzadılır.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]-ə baxın
        c as u128
    }
}

/// Kod nöqtəsi eyni dəyərə sahib olan `char`-ə bir baytı 0x00 ..=0xFF ilə U + 0000 ..=U + 00FF ilə xəritələyir.
///
/// Unicode, IANA-nın ISO-8859-1 adlandırdığı kodlaşdırma ilə baytları effektiv şəkildə dekodlaşdıracaq şəkildə hazırlanmışdır.
/// Bu kodlaşdırma ASCII ilə uyğundur.
///
/// Bunun ISO/IEC 8859-1 aka-dan fərqli olduğunu unutmayın
/// Hər hansı bir xarakterə təyin olunmayan "blanks", bayt dəyərləri qoyan ISO 8859-1 (daha az tire ilə).
/// ISO-8859-1 (IANA biri) onları C0 və C1 nəzarət kodlarına verir.
///
/// Bunun Windows-1252 aka-dan *eyni* fərqli olduğunu unutmayın
/// kod səhifəsi 1252, nöqtə işarələrinə və müxtəlif Latın işarələrinə bəzi (hamısı deyil!) boşluqlar atan bir super set ISO/IEC 8859-1-dir.
///
/// İşləri daha da qarışdırmaq üçün [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` və `windows-1252`, qalan boşluqları müvafiq C0 və C1 nəzarət kodları ilə dolduran Windows-1252-nin üst dəsti üçün təxəllüllərdir.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`]-i [`char`]-ə çevirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Char-nu təhlil edərkən qaytarıla bilən bir səhv.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // TƏHLÜKƏSİZLİK: qanuni bir unikod dəyəri olduğunu yoxladı
            Ok(unsafe { transmute(i) })
        }
    }
}

/// u32-dan char-a çevrilmədikdə səhv növü geri döndü.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Verilən radixdakı bir rəqəmi `char`-ə çevirir.
///
/// Burada bir 'radix' bəzən 'base' də adlandırılır.
/// İki ortalama radius ikili ədədi, on radiusunu onluğa və on altılıq onaltılıq radiusa bənzər ümumi dəyərlər göstərir.
///
/// Təsadüfi radikallar dəstəklənir.
///
/// `from_digit()` giriş verilən radiusda bir rəqəm deyilsə `None` qaytaracaq.
///
/// # Panics
///
/// 36-dan böyük bir radius verildiyi təqdirdə Panics.
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Ondalık 11 baza 16-da tək rəqəmdir
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Giriş rəqəmi olmadıqda `None`-in qaytarılması:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// panic-yə səbəb olan böyük bir radius keçmək:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}