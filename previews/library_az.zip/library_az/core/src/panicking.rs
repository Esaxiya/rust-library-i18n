//! Libcore üçün Panic dəstəyi
//!
//! Əsas kitabxana çaxnaşma tərif edə bilmir, ancaq *çaxnaşma elan edir*.
//! Bu o deməkdir ki, libcore daxilindəki funksiyaların panic-yə icazə verildiyi, lakin faydalı bir crate olması üçün libcore-un istifadə etməsi üçün panikanı təyin etməlidir.
//! Panik üçün cari interfeys:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Bu tərif hər hansı bir ümumi mesajla çaxnaşmaya imkan verir, lakin `Box<Any>` dəyəri ilə uğursuzluğa imkan vermir.
//! (`PanicInfo` yalnız bir `&(dyn Any + Send)` ehtiva edir, bunun üçün `PanicInfo: : internal_constructor`da saxta bir dəyər doldururuq.) Bunun səbəbi libcore'un ayrılmasına icazə verilməməsidir.
//!
//!
//! Bu modulda bir neçə başqa panikasiya funksiyası var, lakin bunlar yalnız kompilyator üçün lazım olan lang maddələridir.Bütün panics bu bir funksiya vasitəsilə həyata keçirilir.
//! Həqiqi simvol `#[panic_handler]` atributu vasitəsilə elan olunur.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Heç bir format istifadə edilmədikdə libcore-un `panic!` makrosunun əsas tətbiqi.
#[cold]
// zəng saytlarında mümkün qədər kod şişməməsi üçün panic_immediate_abort olmadığı müddətdə heç vaxt satır içərisində olmayın
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // daşqın və digər `Assert` MIR terminatorlarında panic üçün codegen tərəfindən tələb olunur
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Potensial olaraq yükü azaltmaq üçün format_args yerinə Arguments::new_v1 istifadə edin! ("{}", Expr).
    // Format_args!makro, strr-nin Display trait-dən expr yazmaq üçün istifadə edir və Formatter::pad-yə zəng vurur, burada simli kəsmə və dolğu yerləşdirilə bilər (heç biri burada istifadə olunmasa da).
    //
    // Arguments::new_v1 istifadə edərək, tərtibçinin Formatter::pad-ni çıxış ikili sistemindən buraxmasına və bir neçə kilobayta qənaət etməsinə imkan verə bilər.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // konstruksiyalı panics üçün lazımdır
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice girişində panic üçün codegen tərəfindən tələb olunur
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Formatlaşdırma zamanı libcore-un `panic!` makrosunun əsas tətbiqetməsindən istifadə olunur.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // DİQQƏT Bu funksiya heç vaxt FFI sərhədini keçmir;`#[panic_handler]` funksiyasını həll edən bir Rust-Rust zəngidir.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // TƏHLÜKƏSİZLİK: `panic_impl` təhlükəsiz Rust kodunda müəyyənləşdirilib və beləliklə zəng etmək təhlükəsizdir.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` və `assert_ne!` makroları üçün daxili funksiya
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}