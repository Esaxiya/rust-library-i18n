//! Atom növləri
//!
//! Atom tipləri, iplər arasında ibtidai paylaşılan yaddaş əlaqəsini təmin edir və digər paralel növlərin təməl daşlarıdır.
//!
//! Bu modul, [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] vs. daxil olmaqla, müəyyən sayda ibtidai növün atom versiyasını müəyyənləşdirir.
//! Atom tipləri düzgün istifadə edildikdə mövzuları arasında yeniləmələri sinxronlaşdıran əməliyyatları təqdim edir.
//!
//! Hər bir metod bu əməliyyat üçün yaddaş baryerinin gücünü təmsil edən [`Ordering`] alır.Bu sifarişlər [C++20 atomic orderings][1] ilə eynidir.Daha çox məlumat üçün [nomicon][2]-ə baxın.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atom dəyişkənləri mövzuları arasında bölüşmək üçün təhlükəsizdir (onlar [`Sync`] tətbiq edirlər), lakin özləri Rust-nin [threading model](../../../std/thread/index.html#the-threading-model)-ni paylaşma mexanizmini təmin etmirlər.
//!
//! Bir atom dəyişənini bölüşməyin ən ümumi yolu onu [`Arc`][arc]-ə (atomik-istinadla sayılan paylaşılan bir göstəriciyə) qoymaqdır.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atom növləri, statik dəyişənlərdə saxlanıla bilər, [`AtomicBool::new`] kimi sabit başlanğıclardan istifadə edərək başlanğıc edilir.Atom statikası tez-tez tənbəl qlobal başlanğıc üçün istifadə olunur.
//!
//! # Portability
//!
//! Bu moduldakı bütün atom tiplərinin mövcud olduqda [lock-free] olmasına zəmanət verilir.Bu, daxili olaraq qlobal bir muteks əldə etmədikləri deməkdir.Atom növləri və əməliyyatlarının gözləmə pulsuz olmasına zəmanət verilmir.
//! Bu o deməkdir ki, `fetch_or` kimi əməliyyatlar müqayisə və dəyişdirmə dövrü ilə həyata keçirilə bilər.
//!
//! Atom əməliyyatları təlimat qatında daha böyük ölçülü atomlarla həyata keçirilə bilər.Məsələn bəzi platformalarda `AtomicI8` tətbiq etmək üçün 4 baytlıq atom təlimatları istifadə olunur.
//! Qeyd edək ki, bu emulyasiya kodun düzgünlüyünə təsir göstərməməlidir, sadəcə xəbərdar olmağınız lazımdır.
//!
//! Bu moduldakı atom növləri bütün platformalarda mövcud olmaya bilər.Buradakı atom tiplərinin hamısı geniş yayılmışdır və ümumiyyətlə mövcud olduğuna etibar edilə bilər.Bəzi diqqətəlayiq istisnalar bunlardır:
//!
//! * PowerPC və 32 bit göstəriciləri olan MIPS platformalarında `AtomicU64` və ya `AtomicI64` tipləri yoxdur.
//! * ARM Linux üçün olmayan `armv5te` kimi platformalar yalnız `load` və `store` əməliyyatlarını təmin edir və `swap`, `fetch_add`, və s. kimi (CAS) müqayisə və dəyişdirmə əməliyyatlarını dəstəkləmir.
//! Əlavə olaraq Linux-də bu CAS əməliyyatları performans cəriməsi ilə gələ biləcək [operating system support] vasitəsilə həyata keçirilir.
//! * ARM `thumbv6m` ilə hədəflər yalnız `load` və `store` əməliyyatları təmin edir və `swap`, `fetch_add` vs. kimi (CAS) müqayisə və dəyişdirmə əməliyyatlarını dəstəkləmir.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Bəzi atom əməliyyatları üçün dəstəyi olmayan future platformalarının əlavə edilə biləcəyini unutmayın.Maksimum dərəcədə portativ kod, hansı atom növlərindən istifadə olunduğuna diqqət yetirmək istəyir.
//! `AtomicUsize` və `AtomicIsize` ümumiyyətlə ən portativdir, lakin o zaman belə hər yerdə mövcud deyillər.
//! Məlumat üçün `std` kitabxanası göstərici ölçülü atomik tələb edir, baxmayaraq ki `core` tələb etmir.
//!
//! Hal-hazırda `#[cfg(target_arch)]`-dən ilk növbədə şərti olaraq atom ilə kod yığmaq üçün istifadə etməlisiniz.future-də sabitləşə bilən qeyri-sabit bir `#[cfg(target_has_atomic)]` də var.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Sadə spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Digər ipin kilidini buraxmasını gözləyin
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Canlı mövzuların qlobal sayını saxlayın:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Mövzular arasında təhlükəsiz şəkildə paylaşıla bilən bir boole növü.
///
/// Bu tip [`bool`] ilə eyni yaddaşda təmsilçiliyə malikdir.
///
/// **Qeyd**: Bu tip yalnız `u8` atom yüklərini və mağazalarını dəstəkləyən platformalarda mövcuddur.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` üçün başlatılmış bir `AtomicBool` yaradır.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Göndərmə gizli şəkildə AtomicBool üçün tətbiq olunur.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Mövzular arasında təhlükəsiz şəkildə paylaşıla bilən xam bir göstərici növü.
///
/// Bu tip `*mut T` ilə eyni yaddaşda təmsilçiliyə malikdir.
///
/// **Qeyd**: Bu tip yalnız atom yüklərini və göstəricilərin mağazalarını dəstəkləyən platformalarda mövcuddur.
/// Onun ölçüsü hədəf göstəricisinin ölçüsündən asılıdır.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Sıfır bir `AtomicPtr<T>` yaradır.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atom yaddaşı sifarişləri
///
/// Yaddaş sifarişləri atom əməliyyatları ilə yaddaşın sinxronlaşdırılması üsulunu göstərir.
/// Ən zəif [`Ordering::Relaxed`]-də yalnız əməliyyatın birbaşa toxunduğu yaddaş sinxronlaşdırılır.
/// Digər tərəfdən, [`Ordering::SeqCst`] əməliyyatlarının bir yükləmə cütü, digər yaddaşları sinxronizasiya edərkən bütün əməliyyatlarda bu cür əməliyyatların ümumi qaydasını qoruyub saxlayır.
///
///
/// Rust-nin yaddaş sifarişləri [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order)-dir.
///
/// Daha çox məlumat üçün [nomicon]-ə baxın.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Sifariş məhdudiyyəti yoxdur, yalnız atom əməliyyatları.
    ///
    /// C ++ 20-də [`memory_order_relaxed`]-yə uyğundur.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Bir mağaza ilə birləşdirildikdə, əvvəlki bütün əməliyyatlar [`Acquire`] (və ya daha güclü) sifariş ilə bu dəyərin hər hansı bir yükündən əvvəl sifariş edilir.
    ///
    /// Xüsusilə, əvvəlki bütün yazılar, bu dəyərin [`Acquire`] (və ya daha güclü) yükünü yerinə yetirən bütün mövzularda görünə bilər.
    ///
    /// Diqqət yetirin ki, yükləri və dükanları birləşdirən əməliyyat üçün bu sifarişdən istifadə [`Relaxed`] yük əməliyyatına gətirib çıxarır!
    ///
    /// Bu sifariş yalnız bir mağaza həyata keçirə biləcək əməliyyatlar üçün tətbiq olunur.
    ///
    /// C ++ 20-də [`memory_order_release`]-yə uyğundur.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Yüklə birləşdirildikdə, yüklənmiş dəyər [`Release`] (və ya daha güclü) sifarişli bir mağaza əməliyyatı ilə yazılmışsa, bütün sonrakı əməliyyatlar həmin mağazadan sonra sifariş edilir.
    /// Xüsusilə, bütün sonrakı yüklər mağazadan əvvəl yazılmış məlumatları görəcəkdir.
    ///
    /// Diqqət yetirin ki, yükləri və dükanları birləşdirən əməliyyat üçün bu sifarişdən istifadə [`Relaxed`] dükan əməliyyatına gətirib çıxarır!
    ///
    /// Bu sifariş yalnız bir yükü yerinə yetirə bilən əməliyyatlar üçün tətbiq olunur.
    ///
    /// C ++ 20-də [`memory_order_acquire`]-yə uyğundur.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Həm [`Acquire`], həm də [`Release`] təsirlərini birlikdə göstərir:
    /// Yüklər üçün [`Acquire`] sifarişindən istifadə olunur.Mağazalarda [`Release`] sifarişini istifadə edir.
    ///
    /// Diqqət yetirin ki, `compare_and_swap` vəziyyətində əməliyyatın heç bir mağazanı yerinə yetirməməsi və bunun üçün yalnız [`Acquire`] sifarişinə sahib olması mümkündür.
    ///
    /// Bununla birlikdə, `AcqRel` heç vaxt [`Relaxed`] girişlərini yerinə yetirməyəcəkdir.
    ///
    /// Bu sifariş yalnız yükləri və dükanları birləşdirən əməliyyatlar üçün tətbiq olunur.
    ///
    /// C ++ 20-də [`memory_order_acq_rel`]-yə uyğundur.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Bütün mövzuların bütün ardıcıl ardıcıl əməliyyatları eyni ardıcıllıqla görməsinin əlavə zəmanəti ilə [sırasıyla yükləmə, saxlama və mağaza ilə yükləmə əməliyyatları üçün] kimi [`Alın ']/[` Release`]/[`AcqRel`] kimi. .
    ///
    ///
    /// C ++ 20-də [`memory_order_seq_cst`]-yə uyğundur.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Bir [`AtomicBool`] `false`-ə başlandı.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Yeni `AtomicBool` yaradır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Əsas [`bool`]-ə dəyişdirilə bilən bir istinad qaytarır.
    ///
    /// Bu təhlükəsizdir, çünki dəyişdirilə bilən istinad, başqa heç bir mövzu ilə eyni vaxtda atom məlumatlarına giriş etməməsini təmin edir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // TƏHLÜKƏSİZLİK: dəyişdirilə bilən istinad unikal sahibliyi təmin edir.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool`-ə atom çıxışı əldə edin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // TƏHLÜKƏSİZLİK: dəyişdirilə bilən istinad unikal sahibliyi təmin edir və
        // həm `bool` həm də `Self` hizalaması 1-dir.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Atomu istehlak edir və içindəki dəyəri qaytarır.
    ///
    /// Bu təhlükəsizdir, çünki `self`-i dəyərdən keçirtmək, başqa heç bir mövzu ilə eyni vaxtda atom məlumatlarına giriş etməməsini təmin edir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool-dən bir dəyər yükləyir.
    ///
    /// `load` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.
    /// Mümkün dəyərlər [`SeqCst`], [`Acquire`] və [`Relaxed`]-dir.
    ///
    /// # Panics
    ///
    /// `order` [`Release`] və ya [`AcqRel`] olarsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // TƏHLÜKƏSİZLİK: hər hansı bir məlumat yarışının qarşısını atom və daxili maddələr alır
        // ötürülən göstərici etibarlıdır, çünki istinaddan əldə etdik.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool-də bir dəyər saxlayır.
    ///
    /// `store` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.
    /// Mümkün dəyərlər [`SeqCst`], [`Release`] və [`Relaxed`]-dir.
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] və ya [`AcqRel`] olarsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // TƏHLÜKƏSİZLİK: hər hansı bir məlumat yarışının qarşısını atom və daxili maddələr alır
        // ötürülən göstərici etibarlıdır, çünki istinaddan əldə etdik.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Əvvəlki dəyəri qaytararaq bool-də bir dəyər saxlayır.
    ///
    /// `swap` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
    /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
    ///
    ///
    /// **Note:** Bu metod yalnız `u8`-də atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Cari dəyər `current` dəyəri ilə eynidirsə, bir dəyəri [`bool`]-də saxlayır.
    ///
    /// Qaytarma dəyəri həmişə əvvəlki dəyərdir.`current`-ə bərabərdirsə, dəyər yeniləndi.
    ///
    /// `compare_and_swap` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.
    /// [`AcqRel`] istifadə edərkən belə əməliyyatın uğursuz ola biləcəyinə və bu səbəbdən `Acquire` yükünü yerinə yetirdiyinə, lakin `Release` semantikasına sahib olmadığına diqqət yetirin.
    /// [`Acquire`] istifadə etmək olarsa bu əməliyyatın mağaza hissəsini [`Relaxed`] edir və [`Release`] istifadə yük hissəsini [`Relaxed`] edir.
    ///
    /// **Note:** Bu metod yalnız `u8`-də atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # `compare_exchange` və `compare_exchange_weak`-ə köçmək
    ///
    /// `compare_and_swap` yaddaş sifarişləri üçün aşağıdakı xəritə ilə `compare_exchange`-ə bərabərdir:
    ///
    /// Orijinal |Uğur |Uğursuzluq
    /// -------- | ------- | -------
    /// Rahat |Rahat |Rahat əldə edinAlın |Sərbəst buraxın |Buraxılış |Rahat AcqRel |AcqRel |SeqCst əldə edin.SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` müqayisə müvəffəq olduqda belə saxtakarlıqla uğursuz olmasına icazə verilir, bu da müqayisə və dəyişdirmə bir döngədə istifadə edildikdə tərtibçinin daha yaxşı montaj kodu yaratmasına imkan verir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Cari dəyər `current` dəyəri ilə eynidirsə, bir dəyəri [`bool`]-də saxlayır.
    ///
    /// Qaytarma dəyəri, yeni dəyərin yazılıb yazılmadığını və əvvəlki dəyəri ehtiva etdiyini göstərən bir nəticədir.
    /// Uğurda bu dəyərin `current`-ə bərabər olmasına zəmanət verilir.
    ///
    /// `compare_exchange` bu əməliyyatın yaddaş sırasını təsvir etmək üçün iki [`Ordering`] arqumenti alır.
    /// `success` `current` ilə müqayisə uğurla baş verərsə baş verən oxuma-dəyişdirmə-yazma əməliyyatı üçün tələb olunan sifarişləri təsvir edir.
    /// `failure` müqayisə uğursuz olduqda baş verən yük əməliyyatı üçün tələb olunan sifarişləri təsvir edir.
    /// [`Acquire`]-i uğurlu sifariş olaraq istifadə etmək mağazanı bu əməliyyatın [`Relaxed`] hissəsinə çevirir və [`Release`] istifadə edərək [`Relaxed`] yükünü uğurlu edir.
    ///
    /// Hata sıralaması yalnız [`SeqCst`], [`Acquire`] və ya [`Relaxed`] ola bilər və müvəffəqiyyət sifarişinə bərabər və ya zəif olmalıdır.
    ///
    /// **Note:** Bu metod yalnız `u8`-də atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Cari dəyər `current` dəyəri ilə eynidirsə, bir dəyəri [`bool`]-də saxlayır.
    ///
    /// [`AtomicBool::compare_exchange`]-dən fərqli olaraq, müqayisə müvəffəq olduqda belə bu funksiyanın saxtakarlıqla sıradan çıxmasına icazə verilir və bu, bəzi platformalarda daha səmərəli kodla nəticələnə bilər.
    ///
    /// Qaytarma dəyəri, yeni dəyərin yazılıb yazılmadığını və əvvəlki dəyəri ehtiva etdiyini göstərən bir nəticədir.
    ///
    /// `compare_exchange_weak` bu əməliyyatın yaddaş sırasını təsvir etmək üçün iki [`Ordering`] arqumenti alır.
    /// `success` `current` ilə müqayisə uğurla baş verərsə baş verən oxuma-dəyişdirmə-yazma əməliyyatı üçün tələb olunan sifarişləri təsvir edir.
    /// `failure` müqayisə uğursuz olduqda baş verən yük əməliyyatı üçün tələb olunan sifarişləri təsvir edir.
    /// [`Acquire`]-i uğurlu sifariş olaraq istifadə etmək mağazanı bu əməliyyatın [`Relaxed`] hissəsinə çevirir və [`Release`] istifadə edərək [`Relaxed`] yükünü uğurlu edir.
    /// Hata sıralaması yalnız [`SeqCst`], [`Acquire`] və ya [`Relaxed`] ola bilər və müvəffəqiyyət sifarişinə bərabər və ya zəif olmalıdır.
    ///
    /// **Note:** Bu metod yalnız `u8`-də atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Məntiqi dəyəri olan məntiqi "and".
    ///
    /// Cari dəyər və `val` arqumenti üzərində məntiqi bir "and" əməliyyatı həyata keçirir və nəticəni yeni dəyəri təyin edir.
    ///
    /// Əvvəlki dəyəri qaytarır.
    ///
    /// `fetch_and` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
    /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
    ///
    ///
    /// **Note:** Bu metod yalnız `u8`-də atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Məntiqi dəyəri olan məntiqi "nand".
    ///
    /// Cari dəyər və `val` arqumenti üzərində məntiqi bir "nand" əməliyyatı həyata keçirir və nəticəni yeni dəyəri təyin edir.
    ///
    /// Əvvəlki dəyəri qaytarır.
    ///
    /// `fetch_nand` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
    /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
    ///
    ///
    /// **Note:** Bu metod yalnız `u8`-də atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Burada atomic_nand istifadə edə bilmərik, çünki etibarsız bir dəyərlə bool ilə nəticələnə bilər.
        // Bu, atom əməliyyatı içəridə 8 bitlik bir tam rəqəmlə həyata keçirildiyi üçün baş verir, bu da üst 7 biti təyin edəcəkdir.
        //
        // Beləliklə, bunun əvəzinə yalnız fetch_xor və ya dəyişdirmə istifadə edirik.
        if val {
            // ! (x&true)== !x bool-ni tərs çevirməliyik.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true bool'yi true olarak ayarlamalıyıq.
            //
            self.swap(true, order)
        }
    }

    /// Məntiqi dəyəri olan məntiqi "or".
    ///
    /// Cari dəyər və `val` arqumenti üzərində məntiqi bir "or" əməliyyatı həyata keçirir və nəticəni yeni dəyəri təyin edir.
    ///
    /// Əvvəlki dəyəri qaytarır.
    ///
    /// `fetch_or` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
    /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
    ///
    ///
    /// **Note:** Bu metod yalnız `u8`-də atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Məntiqi dəyəri olan məntiqi "xor".
    ///
    /// Cari dəyər və `val` arqumenti üzərində məntiqi bir "xor" əməliyyatı həyata keçirir və nəticəni yeni dəyəri təyin edir.
    ///
    /// Əvvəlki dəyəri qaytarır.
    ///
    /// `fetch_xor` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
    /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
    ///
    ///
    /// **Note:** Bu metod yalnız `u8`-də atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Dəyişdirilə bilən bir göstəricini əsas [`bool`]-ə qaytarır.
    ///
    /// Nəticədə çıxan tam ədədi atomik olmayan oxumaq və yazmaq bir məlumat yarışı ola bilər.
    /// Bu metod əsasən FFI üçün faydalıdır, burada funksiya imzası `&AtomicBool` əvəzinə `*mut bool` istifadə edə bilər.
    ///
    /// Bir `*mut` göstəricisini bu atoma paylaşılan bir istinaddan geri qaytarmaq təhlükəsizdir, çünki atom növləri daxili dəyişkənliklə işləyir.
    /// Bir atomun bütün modifikasiyaları, paylaşılan bir istinad vasitəsi ilə dəyəri dəyişdirir və atom əməliyyatlarından istifadə etdikləri müddətcə bunu etibarlı bir şəkildə edə bilərlər.
    /// Geri qaytarılmış xammal göstəricisindən hər hansı bir istifadə üçün bir `unsafe` bloku tələb olunur və yenə də eyni məhdudiyyəti təmin etməlidir: üzərində əməliyyatlar atom olmalıdır.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Dəyəri alır və ona isteğe bağlı yeni bir dəyər qaytaran bir funksiya tətbiq edir.Funksiya `Some(_)`, başqa bir şəkildə `Err(previous_value)` qaytardısa, `Ok(previous_value)`-dən `Result` qaytarır.
    ///
    /// Note: Bu müddət ərzində funksiya `Some(_)`-yə qayıdarkən dəyər digər mövzulardan dəyişdirilibsə, funksiya saxlanılan dəyərə yalnız bir dəfə tətbiq olunarsa, bu funksiyanı dəfələrlə çağıra bilər.
    ///
    ///
    /// `fetch_update` bu əməliyyatın yaddaş sırasını təsvir etmək üçün iki [`Ordering`] arqumenti alır.
    /// Birincisi, əməliyyat nəhayət uğurla başa çatdıqda, ikincisi yüklər üçün lazımlı sifarişləri təsvir edir.
    /// Bunlar sırasıyla [`AtomicBool::compare_exchange`] in müvəffəqiyyət və uğursuzluq sifarişlərinə uyğundur.
    ///
    /// [`Acquire`]-i uğurlu sifariş kimi istifadə etmək mağazanı bu əməliyyatın [`Relaxed`] hissəsinə çevirir və [`Release`] istifadə edərək son uğurlu yükü [`Relaxed`] edir.
    /// (failed) yük sifarişi yalnız [`SeqCst`], [`Acquire`] və ya [`Relaxed`] ola bilər və müvəffəqiyyət sifarişinə bərabər və ya zəif olmalıdır.
    ///
    /// **Note:** Bu metod yalnız `u8`-də atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Yeni `AtomicPtr` yaradır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Əsas göstəriciyə dəyişdirilə bilən bir istinad qaytarır.
    ///
    /// Bu təhlükəsizdir, çünki dəyişdirilə bilən istinad, başqa heç bir mövzu ilə eyni vaxtda atom məlumatlarına giriş etməməsini təmin edir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Bir göstəriciyə atomik giriş əldə edin.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - dəyişdirilə bilən istinad unikal mülkiyyəti təmin edir.
        //  - `*mut T` və `Self` hizalaması, yuxarıda doğrulandığı kimi rust tərəfindən dəstəklənən bütün platformalarda eynidır.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Atomu istehlak edir və içindəki dəyəri qaytarır.
    ///
    /// Bu təhlükəsizdir, çünki `self`-i dəyərdən keçirtmək, başqa heç bir mövzu ilə eyni vaxtda atom məlumatlarına giriş etməməsini təmin edir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Göstəricidən bir dəyər yükləyir.
    ///
    /// `load` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.
    /// Mümkün dəyərlər [`SeqCst`], [`Acquire`] və [`Relaxed`]-dir.
    ///
    /// # Panics
    ///
    /// `order` [`Release`] və ya [`AcqRel`] olarsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Göstəriciyə bir dəyər saxlayır.
    ///
    /// `store` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.
    /// Mümkün dəyərlər [`SeqCst`], [`Release`] və [`Relaxed`]-dir.
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] və ya [`AcqRel`] olarsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Əvvəlki dəyəri qaytararaq göstəriciyə bir dəyər saxlayır.
    ///
    /// `swap` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
    /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
    ///
    ///
    /// **Note:** Bu metod yalnız göstəricilərdəki atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Cari dəyər `current` dəyəri ilə eynidirsə, göstəriciyə bir dəyər saxlayır.
    ///
    /// Qaytarma dəyəri həmişə əvvəlki dəyərdir.`current`-ə bərabərdirsə, dəyər yeniləndi.
    ///
    /// `compare_and_swap` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.
    /// [`AcqRel`] istifadə edərkən belə əməliyyatın uğursuz ola biləcəyinə və bu səbəbdən `Acquire` yükünü yerinə yetirdiyinə, lakin `Release` semantikasına sahib olmadığına diqqət yetirin.
    /// [`Acquire`] istifadə etmək olarsa bu əməliyyatın mağaza hissəsini [`Relaxed`] edir və [`Release`] istifadə yük hissəsini [`Relaxed`] edir.
    ///
    /// **Note:** Bu metod yalnız göstəricilərdəki atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # `compare_exchange` və `compare_exchange_weak`-ə köçmək
    ///
    /// `compare_and_swap` yaddaş sifarişləri üçün aşağıdakı xəritə ilə `compare_exchange`-ə bərabərdir:
    ///
    /// Orijinal |Uğur |Uğursuzluq
    /// -------- | ------- | -------
    /// Rahat |Rahat |Rahat əldə edinAlın |Sərbəst buraxın |Buraxılış |Rahat AcqRel |AcqRel |SeqCst əldə edin.SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` müqayisə müvəffəq olduqda belə saxtakarlıqla uğursuz olmasına icazə verilir, bu da müqayisə və dəyişdirmə bir döngədə istifadə edildikdə tərtibçinin daha yaxşı montaj kodu yaratmasına imkan verir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Cari dəyər `current` dəyəri ilə eynidirsə, göstəriciyə bir dəyər saxlayır.
    ///
    /// Qaytarma dəyəri, yeni dəyərin yazılıb yazılmadığını və əvvəlki dəyəri ehtiva etdiyini göstərən bir nəticədir.
    /// Uğurda bu dəyərin `current`-ə bərabər olmasına zəmanət verilir.
    ///
    /// `compare_exchange` bu əməliyyatın yaddaş sırasını təsvir etmək üçün iki [`Ordering`] arqumenti alır.
    /// `success` `current` ilə müqayisə uğurla baş verərsə baş verən oxuma-dəyişdirmə-yazma əməliyyatı üçün tələb olunan sifarişləri təsvir edir.
    /// `failure` müqayisə uğursuz olduqda baş verən yük əməliyyatı üçün tələb olunan sifarişləri təsvir edir.
    /// [`Acquire`]-i uğurlu sifariş olaraq istifadə etmək mağazanı bu əməliyyatın [`Relaxed`] hissəsinə çevirir və [`Release`] istifadə edərək [`Relaxed`] yükünü uğurlu edir.
    ///
    /// Hata sıralaması yalnız [`SeqCst`], [`Acquire`] və ya [`Relaxed`] ola bilər və müvəffəqiyyət sifarişinə bərabər və ya zəif olmalıdır.
    ///
    /// **Note:** Bu metod yalnız göstəricilərdəki atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Cari dəyər `current` dəyəri ilə eynidirsə, göstəriciyə bir dəyər saxlayır.
    ///
    /// [`AtomicPtr::compare_exchange`]-dən fərqli olaraq, müqayisə müvəffəq olduqda belə, bu funksiyanın saxtakarlıqla sıradan çıxmasına icazə verilir və bu, bəzi platformalarda daha səmərəli kodla nəticələnə bilər.
    ///
    /// Qaytarma dəyəri, yeni dəyərin yazılıb yazılmadığını və əvvəlki dəyəri ehtiva etdiyini göstərən bir nəticədir.
    ///
    /// `compare_exchange_weak` bu əməliyyatın yaddaş sırasını təsvir etmək üçün iki [`Ordering`] arqumenti alır.
    /// `success` `current` ilə müqayisə uğurla baş verərsə baş verən oxuma-dəyişdirmə-yazma əməliyyatı üçün tələb olunan sifarişləri təsvir edir.
    /// `failure` müqayisə uğursuz olduqda baş verən yük əməliyyatı üçün tələb olunan sifarişləri təsvir edir.
    /// [`Acquire`]-i uğurlu sifariş olaraq istifadə etmək mağazanı bu əməliyyatın [`Relaxed`] hissəsinə çevirir və [`Release`] istifadə edərək [`Relaxed`] yükünü uğurlu edir.
    /// Hata sıralaması yalnız [`SeqCst`], [`Acquire`] və ya [`Relaxed`] ola bilər və müvəffəqiyyət sifarişinə bərabər və ya zəif olmalıdır.
    ///
    /// **Note:** Bu metod yalnız göstəricilərdəki atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // TƏHLÜKƏSİZLİK: Çirkli bir göstərici üzərində işləyən bu daxili təhlükəlidir
        // lakin göstəricinin etibarlı olduğunu dəqiq bilirik (onu yalnız istinad etdiyimiz bir `UnsafeCell`-dən almışıq) və atom əməliyyatının özü də `UnsafeCell` məzmununun təhlükəsiz şəkildə mutasiya edilməsinə imkan verir.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Dəyəri alır və ona isteğe bağlı yeni bir dəyər qaytaran bir funksiya tətbiq edir.Funksiya `Some(_)`, başqa bir şəkildə `Err(previous_value)` qaytardısa, `Ok(previous_value)`-dən `Result` qaytarır.
    ///
    /// Note: Bu müddət ərzində funksiya `Some(_)`-yə qayıdarkən dəyər digər mövzulardan dəyişdirilibsə, funksiya saxlanılan dəyərə yalnız bir dəfə tətbiq olunarsa, bu funksiyanı dəfələrlə çağıra bilər.
    ///
    ///
    /// `fetch_update` bu əməliyyatın yaddaş sırasını təsvir etmək üçün iki [`Ordering`] arqumenti alır.
    /// Birincisi, əməliyyat nəhayət uğurla başa çatdıqda, ikincisi yüklər üçün lazımlı sifarişləri təsvir edir.
    /// Bunlar sırasıyla [`AtomicPtr::compare_exchange`] in müvəffəqiyyət və uğursuzluq sifarişlərinə uyğundur.
    ///
    /// [`Acquire`]-i uğurlu sifariş kimi istifadə etmək mağazanı bu əməliyyatın [`Relaxed`] hissəsinə çevirir və [`Release`] istifadə edərək son uğurlu yükü [`Relaxed`] edir.
    /// (failed) yük sifarişi yalnız [`SeqCst`], [`Acquire`] və ya [`Relaxed`] ola bilər və müvəffəqiyyət sifarişinə bərabər və ya zəif olmalıdır.
    ///
    /// **Note:** Bu metod yalnız göstəricilərdəki atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool`-i `AtomicBool`-ə çevirir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Bu makro bəzi arxitekturalarda istifadə olunmur.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Mövzular arasında təhlükəsiz şəkildə paylaşıla bilən tam bir növ.
        ///
        /// Bu tip, altdakı tam ədəd növü ilə eyni yaddaşda təmsilçiliyə malikdir [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Atom tipləri ilə atom olmayan tiplər arasındakı fərqlər və bu tipin daşınabilirliyi haqqında məlumat üçün [module-level documentation]-ə baxın.
        ///
        ///
        /// **Note:** Bu tip yalnız atom yüklərini və mağazalarını dəstəkləyən platformalarda mövcuddur ['
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Bir atom tamlığı `0`-ə başlanıldı.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Göndərmə dolayı şəkildə həyata keçirilir.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Yeni bir atom tamı yaradır.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Əsas ədədi dəyişdirilə bilən bir istinad qaytarır.
            ///
            /// Bu təhlükəsizdir, çünki dəyişdirilə bilən istinad, başqa heç bir mövzu ilə eyni vaxtda atom məlumatlarına giriş etməməsini təmin edir.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// qoy mut bəzi_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - dəyişdirilə bilən istinad unikal mülkiyyəti təmin edir.
                //  - `$int_type` və `Self` hizalaması, $cfg_align tərəfindən vəd edildiyi və yuxarıda təsdiqlənən ilə eynidır.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Atomu istehlak edir və içindəki dəyəri qaytarır.
            ///
            /// Bu təhlükəsizdir, çünki `self`-i dəyərdən keçirtmək, başqa heç bir mövzu ilə eyni vaxtda atom məlumatlarına giriş etməməsini təmin edir.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Atom tamlığından bir dəyər yükləyir.
            ///
            /// `load` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.
            /// Mümkün dəyərlər [`SeqCst`], [`Acquire`] və [`Relaxed`]-dir.
            ///
            /// # Panics
            ///
            /// `order` [`Release`] və ya [`AcqRel`] olarsa Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Atom tam ədədi bir dəyər saxlayır.
            ///
            /// `store` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.
            ///  Mümkün dəyərlər [`SeqCst`], [`Release`] və [`Relaxed`]-dir.
            ///
            /// # Panics
            ///
            /// `order` [`Acquire`] və ya [`AcqRel`] olarsa Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Əvvəlki dəyəri qaytararaq, bir atom atomuna bir dəyər saxlayır.
            ///
            /// `swap` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
            /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
            ///
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Cari dəyər `current` dəyəri ilə eynidirsə, bir atom atomuna bir dəyər saxlayır.
            ///
            /// Qaytarma dəyəri həmişə əvvəlki dəyərdir.`current`-ə bərabərdirsə, dəyər yeniləndi.
            ///
            /// `compare_and_swap` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.
            /// [`AcqRel`] istifadə edərkən belə əməliyyatın uğursuz ola biləcəyinə və bu səbəbdən `Acquire` yükünü yerinə yetirdiyinə, lakin `Release` semantikasına sahib olmadığına diqqət yetirin.
            ///
            /// [`Acquire`] istifadə etmək olarsa bu əməliyyatın mağaza hissəsini [`Relaxed`] edir və [`Release`] istifadə yük hissəsini [`Relaxed`] edir.
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` və `compare_exchange_weak`-ə köçmək
            ///
            /// `compare_and_swap` yaddaş sifarişləri üçün aşağıdakı xəritə ilə `compare_exchange`-ə bərabərdir:
            ///
            /// Orijinal |Uğur |Uğursuzluq
            /// -------- | ------- | -------
            /// Rahat |Rahat |Rahat əldə edinAlın |Sərbəst buraxın |Buraxılış |Rahat AcqRel |AcqRel |SeqCst əldə edin.SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` müqayisə müvəffəq olduqda belə saxtakarlıqla uğursuz olmasına icazə verilir, bu da müqayisə və dəyişdirmə bir döngədə istifadə edildikdə tərtibçinin daha yaxşı montaj kodu yaratmasına imkan verir.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Cari dəyər `current` dəyəri ilə eynidirsə, bir atom atomuna bir dəyər saxlayır.
            ///
            /// Qaytarma dəyəri, yeni dəyərin yazılıb yazılmadığını və əvvəlki dəyəri ehtiva etdiyini göstərən bir nəticədir.
            /// Uğurda bu dəyərin `current`-ə bərabər olmasına zəmanət verilir.
            ///
            /// `compare_exchange` bu əməliyyatın yaddaş sırasını təsvir etmək üçün iki [`Ordering`] arqumenti alır.
            /// `success` `current` ilə müqayisə uğurla baş verərsə baş verən oxuma-dəyişdirmə-yazma əməliyyatı üçün tələb olunan sifarişləri təsvir edir.
            /// `failure` müqayisə uğursuz olduqda baş verən yük əməliyyatı üçün tələb olunan sifarişləri təsvir edir.
            /// [`Acquire`]-i uğurlu sifariş olaraq istifadə etmək mağazanı bu əməliyyatın [`Relaxed`] hissəsinə çevirir və [`Release`] istifadə edərək [`Relaxed`] yükünü uğurlu edir.
            ///
            /// Hata sıralaması yalnız [`SeqCst`], [`Acquire`] və ya [`Relaxed`] ola bilər və müvəffəqiyyət sifarişinə bərabər və ya zəif olmalıdır.
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Cari dəyər `current` dəyəri ilə eynidirsə, bir atom atomuna bir dəyər saxlayır.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// müqayisə müvəffəq olduqda belə bu funksiyanın saxtakarlıqla uğursuz olmasına icazə verilir ki, bu da bəzi platformalarda daha səmərəli kodla nəticələnə bilər.
            /// Qaytarma dəyəri, yeni dəyərin yazılıb yazılmadığını və əvvəlki dəyəri ehtiva etdiyini göstərən bir nəticədir.
            ///
            /// `compare_exchange_weak` bu əməliyyatın yaddaş sırasını təsvir etmək üçün iki [`Ordering`] arqumenti alır.
            /// `success` `current` ilə müqayisə uğurla baş verərsə baş verən oxuma-dəyişdirmə-yazma əməliyyatı üçün tələb olunan sifarişləri təsvir edir.
            /// `failure` müqayisə uğursuz olduqda baş verən yük əməliyyatı üçün tələb olunan sifarişləri təsvir edir.
            /// [`Acquire`]-i uğurlu sifariş olaraq istifadə etmək mağazanı bu əməliyyatın [`Relaxed`] hissəsinə çevirir və [`Release`] istifadə edərək [`Relaxed`] yükünü uğurlu edir.
            ///
            /// Hata sıralaması yalnız [`SeqCst`], [`Acquire`] və ya [`Relaxed`] ola bilər və müvəffəqiyyət sifarişinə bərabər və ya zəif olmalıdır.
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// köhnə olsun= val.load(Ordering::Relaxed);
            /// loop {let new=köhnə * 2;
            ///     matç val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Əvvəlki dəyəri qaytararaq cari dəyərə əlavə olunur.
            ///
            /// Bu əməliyyat daşqın ətrafında dolaşır.
            ///
            /// `fetch_add` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
            /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
            ///
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Əvvəlki dəyəri qaytararaq cari dəyərdən çıxarın.
            ///
            /// Bu əməliyyat daşqın ətrafında dolaşır.
            ///
            /// `fetch_sub` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
            /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
            ///
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Cari dəyərlə Bitwise "and".
            ///
            /// Cari dəyər və `val` arqumenti üzərində bir bitli "and" əməliyyatı həyata keçirir və nəticəni yeni dəyəri təyin edir.
            ///
            /// Əvvəlki dəyəri qaytarır.
            ///
            /// `fetch_and` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
            /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
            ///
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Cari dəyərlə Bitwise "nand".
            ///
            /// Cari dəyər və `val` arqumenti üzərində bir bitli "nand" əməliyyatı həyata keçirir və nəticəni yeni dəyəri təyin edir.
            ///
            /// Əvvəlki dəyəri qaytarır.
            ///
            /// `fetch_nand` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
            /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
            ///
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Cari dəyərlə Bitwise "or".
            ///
            /// Cari dəyər və `val` arqumenti üzərində bir bitli "or" əməliyyatı həyata keçirir və nəticəni yeni dəyəri təyin edir.
            ///
            /// Əvvəlki dəyəri qaytarır.
            ///
            /// `fetch_or` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
            /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
            ///
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Cari dəyərlə Bitwise "xor".
            ///
            /// Cari dəyər və `val` arqumenti üzərində bir bitli "xor" əməliyyatı həyata keçirir və nəticəni yeni dəyəri təyin edir.
            ///
            /// Əvvəlki dəyəri qaytarır.
            ///
            /// `fetch_xor` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
            /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
            ///
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Dəyəri alır və ona isteğe bağlı yeni bir dəyər qaytaran bir funksiya tətbiq edir.Funksiya `Some(_)`, başqa bir şəkildə `Err(previous_value)` qaytardısa, `Ok(previous_value)`-dən `Result` qaytarır.
            ///
            /// Note: Bu müddət ərzində funksiya `Some(_)`-yə qayıdarkən dəyər digər mövzulardan dəyişdirilibsə, funksiya saxlanılan dəyərə yalnız bir dəfə tətbiq olunarsa, bu funksiyanı dəfələrlə çağıra bilər.
            ///
            ///
            /// `fetch_update` bu əməliyyatın yaddaş sırasını təsvir etmək üçün iki [`Ordering`] arqumenti alır.
            /// Birincisi, əməliyyat nəhayət uğurla başa çatdıqda, ikincisi yüklər üçün lazımlı sifarişləri təsvir edir.Bunlar müvəffəqiyyət və uğursuzluq sifarişlərinə uyğundur
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`]-i uğurlu sifariş kimi istifadə etmək mağazanı bu əməliyyatın [`Relaxed`] hissəsinə çevirir və [`Release`] istifadə edərək son uğurlu yükü [`Relaxed`] edir.
            /// (failed) yük sifarişi yalnız [`SeqCst`], [`Acquire`] və ya [`Relaxed`] ola bilər və müvəffəqiyyət sifarişinə bərabər və ya zəif olmalıdır.
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Sifariş: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Sifariş: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Cari dəyər ilə maksimum.
            ///
            /// Cari dəyərin maksimumunu və `val` arqumentini tapır və nəticəni yeni dəyəri təyin edir.
            ///
            /// Əvvəlki dəyəri qaytarır.
            ///
            /// `fetch_max` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
            /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
            ///
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// bar=42;
            /// max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// təsdiq! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Cari dəyərlə minimum.
            ///
            /// Cari dəyərin minimumunu və `val` arqumentini tapır və nəticəni yeni dəyəri təyin edir.
            ///
            /// Əvvəlki dəyəri qaytarır.
            ///
            /// `fetch_min` bu əməliyyatın yaddaş sırasını təsvir edən bir [`Ordering`] arqumenti alır.Bütün sifariş rejimi mümkündür.
            /// [`Acquire`] istifadə edərək bu əməliyyatın mağaza hissəsini [`Relaxed`], [`Release`] istifadə edərək yük hissəsini [`Relaxed`] etdiyini unutmayın.
            ///
            ///
            /// **Qeyd**: Bu metod yalnız atom əməliyyatlarını dəstəkləyən platformalarda mövcuddur
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// bar=12 olsun;
            /// min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // TƏHLÜKƏSİZLİK: məlumat yarışlarının qarşısını atomik daxili maddələr alır.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Dəyişdirilə bilən bir göstəricini altdakı tam ədədə qaytarır.
            ///
            /// Nəticədə çıxan tam ədədi atomik olmayan oxumaq və yazmaq bir məlumat yarışı ola bilər.
            /// Bu metod daha çox funksiya imzasının istifadə edə biləcəyi FFI üçün faydalıdır
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Bir `*mut` göstəricisini bu atoma paylaşılan bir istinaddan geri qaytarmaq təhlükəsizdir, çünki atom növləri daxili dəyişkənliklə işləyir.
            /// Bir atomun bütün modifikasiyaları, paylaşılan bir istinad vasitəsi ilə dəyəri dəyişdirir və atom əməliyyatlarından istifadə etdikləri müddətcə bunu etibarlı bir şəkildə edə bilərlər.
            /// Geri qaytarılmış xammal göstəricisindən hər hansı bir istifadə üçün bir `unsafe` bloku tələb olunur və yenə də eyni məhdudiyyəti təmin etməlidir: üzərində əməliyyatlar atom olmalıdır.
            ///
            ///
            /// # Examples
            ///
            /// "" (extern-declaration) yi görməməzlikdən gəlin
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// xarici "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // TƏHLÜKƏSİZLİK: `my_atomic_op` atomik olduğu müddətdə təhlükəsizdir.
            /// təhlükəli {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_store` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_load` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_swap` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Əvvəlki dəyəri qaytarır (__sync_fetch_and_add kimi).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_add` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Əvvəlki dəyəri qaytarır (__sync_fetch_and_sub kimi).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_sub` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_compare_exchange` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_compare_exchange_weak` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_and` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_nand` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_or` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_xor` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// maksimum dəyəri qaytarır (imzalanmış müqayisə)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_max` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// minimum dəyəri qaytarır (imzalanmış müqayisə)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_min` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// maksimum dəyəri qaytarır (imzasız müqayisə)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_umax` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// minimum dəyəri qaytarır (imzasız müqayisə)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // TƏHLÜKƏSİZLİK: zəng edən `atomic_umin` üçün təhlükəsizlik müqaviləsini qüvvədə saxlamalıdır
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Atom çəpəri.
///
/// Müəyyən edilmiş qaydadan asılı olaraq hasar, tərtibçinin və CPU-nun ətrafındakı bəzi yaddaş əməliyyatlarının yenidən sıralanmasına mane olur.
/// Bu, digər əməliyyatlardakı atom əməliyyatları və çəpərlər ilə əlaqələr yaradır.
///
/// (Ən azı) [`Release`] semantikasına sifariş verən bir 'A' hasarı, hər ikisi də bəzi atom obyekti 'M' üzərində işləyən X və Y əməliyyatları varsa, ən azı [`Acquire`] semantikası ilə bir 'B' hasarı ilə sinxronlaşdırır, A əvvəl sıralanır. X, Y B-dən əvvəl sinxronlaşdırılır və Y, M-ə dəyişikliyi müşahidə edir.
/// Bu, A ilə B arasındakı bir asılılıq təmin edir.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] və ya [`Acquire`] semantikası ilə atom əməliyyatları da hasarla sinxronizasiya edə bilər.
///
/// [`SeqCst`] sifarişinə sahib olan bir çit, həm [`Acquire`], həm də [`Release`] semantikasına sahib olmaqla yanaşı, digər [`SeqCst`] əməliyyatlarının və/və ya çəpərlərinin qlobal proqram qaydasında iştirak edir.
///
/// [`Acquire`], [`Release`], [`AcqRel`] və [`SeqCst`] sifarişlərini qəbul edir.
///
/// # Panics
///
/// `order` [`Relaxed`] olarsa Panics.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Spinlocka əsaslanan qarşılıqlı istisna ibtidai.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Köhnə dəyər `false` olana qədər gözləyin.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Bu çit `unlock`-də mağaza ilə sinxronizasiya olunur.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // TƏHLÜKƏSİZLİK: atomik bir çit istifadə etmək təhlükəsizdir.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Bir kompilyator yaddaş çəpəri.
///
/// `compiler_fence` heç bir maşın kodu buraxmır, ancaq yaddaş növlərini məhdudlaşdırır, kompilyatorun yenidən sifariş etməsinə icazə verilir.Konkret olaraq, verilmiş [`Ordering`] semantikasından asılı olaraq, tərtibçi `compiler_fence`-ə zəngin digər tərəfinə zəngdən əvvəl və ya sonra oxumaq və ya yazmağı qadağan edə bilər.Diqqət yetirin ki,**aparatın* belə yenidən sifariş etməsinə mane olmur.
///
/// Bu, tək yivli, icra kontekstində bir problem deyil, ancaq digər mövzuların eyni zamanda yaddaşı dəyişdirə biləcəyi zaman, [`fence`] kimi daha güclü sinxronizasiya primitivləri tələb olunur.
///
/// Fərqli sifariş semantikasının qarşısını almış yenidən sifariş aşağıdakılardır:
///
///  - [`SeqCst`] ilə bu nöqtədə oxumaq və yazmaq üçün yenidən sifariş verilməsinə icazə verilmir.
///  - [`Release`] ilə əvvəlki oxumaq və yazmaq sonrakı yazılardan keçmiş ola bilməz.
///  - [`Acquire`] ilə sonrakı oxu və yazılar əvvəlki oxumalardan qabağa köçürülə bilməz.
///  - [`AcqRel`] ilə yuxarıdakı hər iki qaydalar tətbiq olunur.
///
/// `compiler_fence` ümumiyyətlə yalnız bir ipin *özü ilə* yarışmasının qarşısını almaq üçün faydalıdır.Yəni, verilən bir mövzu bir kod parçasını icra edirsə və sonra kəsilirsə və başqa bir yerdə (hələ də eyni mövzuda və konseptual olaraq yenə eyni nüvədə) kodu icra etməyə başlayırsa.Ənənəvi proqramlarda bu yalnız bir siqnal işləyicisi qeydiyyata alındıqda baş verə bilər.
/// Daha aşağı səviyyəli kodda, kəsilmələrə baxarkən, yaşıl ipləri əvvəlcədən boşaltma ilə tətbiq edərkən və s.
/// Maraqlı oxuculara Linux kernelinin [memory barriers] ilə bağlı müzakirəsini oxumaq tövsiyə olunur.
///
/// # Panics
///
/// `order` [`Relaxed`] olarsa Panics.
///
/// # Examples
///
/// `compiler_fence` olmadan, aşağıdakı koddakı `assert_eq!`, hər şeyin tək bir mövzuda olmasına baxmayaraq müvəffəq olmasına * zəmanət verilmir.
/// Səbəbini görmək üçün, tərtibçinin mağazaları `IMPORTANT_VARIABLE` və `IS_READ`-ə dəyişdirmək üçün pulsuz olduğunu unutmayın, çünki hər ikisi də `Ordering::Relaxed`-dir.Bunu edərsə və `IS_READY` yeniləndikdən dərhal sonra siqnal işləyicisi işə salınarsa, siqnal işləyicisi `IS_READY=1`-i görəcək, lakin `IMPORTANT_VARIABLE=0`.
/// `compiler_fence` istifadə edərək bu vəziyyəti düzəldir.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // əvvəlki yazıların bu nöqtədən kənara çıxarılmasının qarşısını almaq
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // TƏHLÜKƏSİZLİK: atomik bir çit istifadə etmək təhlükəsizdir.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// İşlemciyə sıx bir gözləmə ilə dönmə döngəsinin ("fırlanma kilidi") içərisində olduğunu bildirir.
///
/// Bu funksiya [`hint::spin_loop`] lehinə ləğv edilmişdir.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}