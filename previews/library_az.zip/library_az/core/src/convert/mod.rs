//! Traits növlər arasındakı dönüşümlər üçün.
//!
//! Bu moduldakı traits, bir növdən digər növə çevrilmənin bir yolunu təmin edir.
//! Hər trait fərqli bir məqsədə xidmət edir:
//!
//! - [`AsRef`] trait-i ucuz istinad-istinad dönüşümləri üçün tətbiq edin
//! - Ucuz dəyişdirilə bilən dəyişdirilə bilən dönüşümlər üçün [`AsMut`] trait tətbiq edin
//! - Dəyərdən dəyərə çevirmələri istehlak etmək üçün [`From`] trait tətbiq edin
//! - Mövcud crate xaricindəki növlərə dəyərdən dəyərə çevirmələri istehlak etmək üçün [`Into`] trait tətbiq edin
//! - [`TryFrom`] və [`TryInto`] traits, [`From`] və [`Into`] kimi davranırlar, lakin dönüşüm uğursuz ola biləcəyi zaman tətbiq edilməlidir.
//!
//! Bu moduldakı traits tez-tez ümumi funksiyalar üçün trait bounds kimi istifadə olunur, belə ki çoxsaylı tip arqumentlərə dəstək verilir.Nümunələr üçün hər trait sənədlərinə baxın.
//!
//! Bir kitabxana müəllifi olaraq, hər zaman [`Into<U>`][`Into`] və ya [`TryInto<U>`][`TryInto`] əvəzinə [`From<T>`][`From`] və ya [`TryFrom<T>`][`TryFrom`] tətbiq etməyi üstün tutmalısınız, çünki [`From`] və [`TryFrom`] daha çox rahatlıq təmin edir və standart kitabxanada yorğan tətbiqi sayəsində bərabər [`Into`] və ya [`TryInto`] tətbiqetmələrini pulsuz təqdim edir.
//! Rust 1.41-dən əvvəl bir versiyanı hədəfləyərkən, mövcud crate xaricində bir növə çevrilərkən birbaşa [`Into`] və ya [`TryInto`] tətbiq etmək lazım ola bilər.
//!
//! # Ümumi tətbiqetmələr
//!
//! - [`AsRef`] və daxili tip bir istinaddırsa, [`AsMut`] avtomatik ayırma
//! - [`From`]`<U>üçün T`, [`Into`]"deməkdir</u><T><U>U` üçün</u>
//! - T`<U>üçün [`TryFrom`]` [`TryInto`]"deməkdir</u><T><U>U` üçün</u>
//! - [`From`] və [`Into`] reflekslidir, yəni bütün növlər özləri və `from` özləri `into` edə bilər
//!
//! İstifadəyə dair nümunələr üçün hər trait-ə baxın.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Şəxsiyyət funksiyası.
///
/// Bu funksiya ilə bağlı iki şeyi qeyd etmək vacibdir:
///
/// - Həmişə `|x| x` kimi bir bağlanmaya bərabər deyil, çünki bağlanma `x`-i fərqli bir növə məcbur edə bilər.
///
/// - `x` girişini funksiyaya keçirir.
///
/// Girişi geri qaytaran bir funksiyanın olması qəribə görünsə də, bəzi maraqlı məqamlar var.
///
///
/// # Examples
///
/// `identity`-dən başqa, maraqlı, maraqlı funksiyalar ardıcıllığında heç bir şey etməmək üçün istifadə etmək:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Birinin əlavə edilməsinin maraqlı bir funksiya olduğunu iddia edək.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// `identity`-dən şərti olaraq "do nothing" əsas vəziyyət kimi istifadə etmək:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Daha maraqlı şeylər edin ...
///
/// let _results = do_stuff(42);
/// ```
///
/// `Option<T>` bir iteratorun `Some` variantlarını saxlamaq üçün `identity` istifadə:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Referansdan referansa ucuz bir dönüşüm etmək üçün istifadə olunur.
///
/// Bu trait, dəyişdirilə bilən istinadlar arasında konvertasiya üçün istifadə olunan [`AsMut`]-ə bənzəyir.
/// Bahalı bir dönüşüm etməyiniz lazımdırsa, [`From`] tipini `&T` ilə tətbiq etmək və ya xüsusi bir funksiya yazmaq daha yaxşıdır.
///
/// `AsRef` [`Borrow`] ilə eyni imzaya sahibdir, lakin [`Borrow`] bir neçə cəhətdən fərqlidir:
///
/// - `AsRef`-dən fərqli olaraq, [`Borrow`] hər hansı bir `T` üçün örtük örtüklüdür və ya istinad, ya da dəyər qəbul etmək üçün istifadə edilə bilər.
/// - [`Borrow`] borc alınan dəyər üçün [`Hash`], [`Eq`] və [`Ord`]-nin sahib olduqları dəyərlə bərabər olmasını da tələb edir.
/// Bu səbəbdən, yalnız bir struktur sahəsindən borc almaq istəyirsinizsə, `AsRef` tətbiq edə bilərsiniz, lakin [`Borrow`] deyil.
///
/// **Note: Bu trait uğursuz olmamalıdır **.Dönüşüm uğursuz olarsa, [`Option<T>`] və ya [`Result<T, E>`] qaytaran xüsusi bir metoddan istifadə edin.
///
/// # Ümumi tətbiqetmələr
///
/// - `AsRef` daxili tip bir istinad və ya dəyişdirilə bilən bir referansdırsa avtomatik sazlamalar (məsələn: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds istifadə edərək, müəyyən edilmiş `T` tipinə çevrilə bildikləri müddətcə müxtəlif növ arqumentləri qəbul edə bilərik.
///
/// Məsələn: `AsRef<str>` götürən ümumi bir funksiya yaradaraq [`&str`]-ə çevrilə bilən bütün istinadları arqument kimi qəbul etmək istədiyimizi ifadə edirik.
/// Həm [`String`], həm də [`&str`] `AsRef<str>` tətbiq etdikləri üçün hər ikisini giriş arqumenti kimi qəbul edə bilərik.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Konversiyanı həyata keçirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Ucuz dəyişdirilə bilən-dəyişdirilə bilən bir istinad dönüşümü etmək üçün istifadə olunur.
///
/// Bu trait, [`AsRef`]-ə bənzəyir, lakin dəyişdirilə bilən istinadlar arasında konvertasiya üçün istifadə olunur.
/// Bahalı bir dönüşüm etməyiniz lazımdırsa, `&mut T` tipli [`From`] tətbiq etmək və ya xüsusi bir funksiya yazmaq daha yaxşıdır.
///
/// **Note: Bu trait uğursuz olmamalıdır **.Dönüşüm uğursuz olarsa, [`Option<T>`] və ya [`Result<T, E>`] qaytaran xüsusi bir metoddan istifadə edin.
///
/// # Ümumi tətbiqetmələr
///
/// - `AsMut` daxili tip dəyişdirilə bilən bir referansdırsa avtomatik dereferences (məsələn: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// `AsMut`-i ümumi bir funksiya üçün trait bound olaraq istifadə edərək `&mut T` tipinə çevrilə bilən bütün dəyişkən istinadları qəbul edə bilərik.
/// [`Box<T>`] `AsMut<T>` tətbiq etdiyi üçün `&mut u64`-ə çevrilə bilən bütün arqumentləri qəbul edən bir `add_one` funksiyası yaza bilərik.
/// [`Box<T>`] `AsMut<T>` tətbiq etdiyi üçün `add_one` `&mut Box<u64>` tipli arqumentləri də qəbul edir:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Konversiyanı həyata keçirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Giriş dəyərini istehlak edən bir dəyərdən bir dəyərə çevrilmə.[`From`]-in əksi.
///
/// [`Into`] tətbiq edilməməli və bunun yerinə [`From`] tətbiq edilməlidir.
/// [`From`]-in tətbiqi, standart kitabxanadakı yorğan tətbiqi sayəsində avtomatik olaraq [`Into`] tətbiqini təmin edir.
///
/// Yalnızca [`Into`] tətbiq edən növlərin də istifadə olunmasını təmin etmək üçün ümumi bir funksiyada trait bounds təyin edərkən [`From`]-dən [`Into`] istifadə etməyə üstünlük verin.
///
/// **Note: Bu trait uğursuz olmamalıdır **.Dönüşüm uğursuz olarsa, [`TryInto`] istifadə edin.
///
/// # Ümumi tətbiqetmələr
///
/// - [`From`]"<T>U` üçün `Into<U> for T` nəzərdə tutulur
/// - [`Into`] refleksivdir, yəni `Into<T> for T` tətbiq olunur
///
/// # Rust-nin köhnə versiyalarında xarici növlərə çevrilmələr üçün [`Into`] tətbiq olunur
///
/// Rust 1.41-dən əvvəl, təyinat növü mövcud crate-nin bir hissəsi deyildisə, [`From`]-i birbaşa tətbiq edə bilməzsiniz.
/// Məsələn, bu kodu götürün:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Bu dilin köhnə versiyalarında tərtib edilə bilməyəcək, çünki Rust-nin yetimləmə qaydaları əvvəllər bir az daha sərt idi.
/// Bunu atlamaq üçün birbaşa [`Into`] tətbiq edə bilərsiniz:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// [`Into`]-in [`From`] tətbiq etmədiyini başa düşmək vacibdir ([`From`] [`Into`] ilə olduğu kimi).
/// Buna görə hər zaman [`From`] tətbiq etməyə çalışmalı və [`From`] tətbiq edilə bilmədikdə yenidən [`Into`]-ə düşməlisiniz.
///
/// # Examples
///
/// [`String`] tətbiq edir [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Ümumi bir funksiyanın müəyyən bir `T` tipinə çevrilə bilən bütün arqumentləri götürməsini istədiyimizi ifadə etmək üçün [`Into`] 'a trait bound istifadə edə bilərik.<T>".
///
/// Məsələn: `is_hello` funksiyası [[Vec`]`<`[`u8`]`> `'ə çevrilə bilən bütün arqumentləri alır.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Konversiyanı həyata keçirir.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Giriş dəyərini istehlak edərkən dəyərdən dəyərə çevirmə etmək üçün istifadə olunur.[`Into`]-in qarşılıqlı əlaqəsidir.
///
/// Hər zaman `From`-i [`Into`]-dən üstün tutmağı üstün tutmalısınız, çünki `From`-in tətbiqi standart kitabxanadakı yorğan tətbiqi sayəsində avtomatik olaraq [`Into`] tətbiqini təmin edir.
///
///
/// [`Into`]-i yalnız Rust 1.41-dən əvvəlki bir versiyanı hədəf alarkən və mövcud crate xaricindəki bir növə çevirərkən tətbiq edin.
/// `From` Rust-nin yetim qalma qaydaları səbəbindən bu tip dönüşümləri əvvəlki versiyalarda edə bilmədi.
/// Daha ətraflı məlumat üçün [`Into`]-ə baxın.
///
/// Ümumi bir funksiyada trait bounds təyin edərkən [`Into`] istifadə etmədən `From` istifadə etməyə üstünlük verin.
/// Bu şəkildə birbaşa [`Into`] tətbiq edən növlər arqument kimi də istifadə edilə bilər.
///
/// `From` də səhv işləmə apararkən çox faydalıdır.Uğursuz ola biləcək bir funksiya qurarkən, qayıtma növü ümumiyyətlə `Result<T, E>` şəklində olacaqdır.
/// `From` trait, bir funksiyanın birdən çox səhv növünü əhatə edən tək bir səhv növü qaytarmasına icazə verərək səhvləri idarə etməyi asanlaşdırır.Daha çox məlumat üçün "Examples" bölməsinə və [the book][book]-ə baxın.
///
/// **Note: Bu trait uğursuz olmamalıdır **.Dönüşüm uğursuz olarsa, [`TryFrom`] istifadə edin.
///
/// # Ümumi tətbiqetmələr
///
/// - `From<T> for U` T`<U>üçün</u> [`Into`]" <U>mənasını verir</u>
/// - `From` refleksivdir, yəni `From<T> for T` tətbiq olunur
///
/// # Examples
///
/// [`String`] `From<&str>` tətbiq edir:
///
/// `&str`-dən Stringə açıq bir dönüşüm aşağıdakı kimi edilir:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Xəta baxışı həyata keçirərkən, `From`-i öz səhv tipiniz üçün tətbiq etmək çox vaxt faydalıdır.
/// Əsas xəta növlərini əsas səhv növünü əhatə edən öz xüsusi səhv tipimizə çevirərək, əsas səbəb barədə məlumat itirmədən tək bir səhv tipini qaytara bilərik.
/// '?' operatoru, `From` tətbiq edilərkən avtomatik olaraq təmin edilən `Into<CliError>::into`-i axtararaq əsas səhv növünü avtomatik olaraq xüsusi səhv tipimizə çevirir.
/// Daha sonra kompilyator `Into`-nin hansı tətbiqetməsindən istifadə edilməli olduğunu göstərir.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Konversiyanı həyata keçirir.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// `self` istehlak edən və bahalı ola bilən və ya olmaya bilən bir çevrilməyə cəhd.
///
/// Kitabxana müəllifləri ümumiyyətlə bu trait-ni birbaşa tətbiq etməməli, daha çox elastiklik təklif edən və standart kitabxanadakı yorğan tətbiqi sayəsində ekvivalent bir `TryInto` tətbiqini təmin edən [`TryFrom`] trait tətbiqini seçməlidirlər.
/// Bu barədə daha çox məlumat üçün [`Into`] sənədlərinə baxın.
///
/// # `TryInto` tətbiq olunur
///
/// Bu, [`Into`] tətbiq etməklə eyni məhdudiyyətlərə və əsaslara səbəb olur, ətraflı məlumat üçün orada baxın.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Dönüşüm xətası olduqda növü geri qaytardı.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Konversiyanı həyata keçirir.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Bəzi şərtlərdə nəzarət altında bir şəkildə uğursuz ola biləcək sadə və təhlükəsiz tipli dönüşümlər.[`TryInto`]-in qarşılıqlı əlaqəsidir.
///
/// Bu, cüzi dərəcədə müvəffəq ola biləcək, həm də xüsusi işləmə tələb oluna bilən bir növ çevirmə edərkən faydalıdır.
/// Məsələn, [`i64`]-i [`From`] trait istifadə edərək [`i32`]-ə çevirməyin bir yolu yoxdur, çünki [`i64`]-də [`i32`]-in təmsil edə bilməyəcəyi bir dəyər ola bilər və bu səbəbdən konversiya məlumatı itirəcəkdir.
///
/// Bu, [`i64`]-dən [`i32`]-ə qədər kəsilməklə (mahiyyətcə [i64`]-in dəyəri [`i32::MAX`] modulu verilərək) və ya sadəcə [`i32::MAX`]-in qaytarılması ilə və ya başqa bir üsulla həll edilə bilər.
/// [`From`] trait, mükəmməl dönüşümlər üçün nəzərdə tutulmuşdur, beləliklə `TryFrom` trait, proqramçıya bir tip dönüşümün pisləşə biləcəyi zaman məlumat verir və bunun necə işlənəcəyinə qərar vermələrinə imkan verir.
///
/// # Ümumi tətbiqetmələr
///
/// - `TryFrom<T> for U` T`<U>üçün</u> [`TryInto`]" <U>mənasını verir</u>
/// - [`try_from`] refleksivdir, yəni `TryFrom<T> for T` tətbiq olunur və uğursuz ola bilməz-`T` tipli bir qiymətə `T::try_from()` çağırmaq üçün əlaqəli `Error` növü [`Infallible`]-dir.
/// [`!`] tipi sabitləşdikdə [`Infallible`] və [`!`] bərabər olacaqdır.
///
/// `TryFrom<T>` aşağıdakı kimi həyata keçirilə bilər:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Təsvir edildiyi kimi, [`i32`] `TryFrom <` [`i64`]`>`'tətbiq edir:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // `big_number`-i səssizcə kəsir, faktdan sonra kəsilmənin aşkarlanması və işlənməsi tələb olunur.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // `big_number` bir `i32`-ə sığmaq üçün çox böyük olduğundan bir səhv qaytarır.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` qaytarır.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Dönüşüm xətası olduqda növü geri qaytardı.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Konversiyanı həyata keçirir.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERIC IMPLS
////////////////////////////////////////////////////////////////////////////////

// Qaldıran kimi&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// &mut-dən yuxarı qaldırıcılar kimi
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): &/&mut üçün yuxarıdakı implilləri aşağıdakı daha ümumi ilə əvəz edin:
// // Derefin üstünə qalxan kimi
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Ölçülü> <U>D {fn as_ref(&self)-> &U {üçün AsRef</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut &mut üzərində qaldırır
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): &mut üçün yuxarıdakı ifadəni aşağıdakı daha ümumi ilə əvəz edin:
// // AsMut, DerefMut üzərində qaldırır
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Ölçülü> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// İçəridən deməkdir
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (və beləliklə Into) refleksivdir
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Sabitlik qeyd:** Bu ifadə hələ mövcud deyil, lakin biz onu future-də əlavə etmək üçün "reserving space" ik.
/// Ətraflı məlumat üçün [rust-lang/rust#64715][#64715]-ə baxın.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): əvəzinə prinsipial bir düzəliş et.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom, TryInto-nu nəzərdə tutur
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Yanılmaz dönüşümlər, mənası baxımından məskun olmayan bir səhv növü ilə səhv dönüşümlərə bərabərdir.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETON İMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// XATASIZ XATA NÖVÜ
////////////////////////////////////////////////////////////////////////////////

/// Heç vaxt ola bilməyəcək səhvlər üçün səhv növü.
///
/// Bu enumun bir variantı olmadığından, bu tip bir dəyər əsla mövcud ola bilməz.
/// Bu, nəticənin həmişə [`Ok`] olduğunu göstərmək üçün [`Result`] istifadə edən və səhv tipini parametrləşdirən ümumi API üçün faydalı ola bilər.
///
/// Məsələn, [`TryFrom`] trait ([`Result`] qaytaran dönüşüm) tərs [`Into`] tətbiqetməsinin mövcud olduğu bütün növlər üçün yorğan tətbiqinə malikdir.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future uyğunluğu
///
/// Bu enum, Rust-nin bu versiyasında qeyri-sabit olan [the `!`“never”type][never] ilə eyni rola malikdir.
/// `!` sabitləşdikdə, `Infallible`-i ona bir növ təxəllüs etməyi planlaşdırırıq:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... və nəticədə `Infallible` yi ləğv et.
///
/// Lakin `!` sintaksisinin `!`-in tam hüquqlu bir növ kimi sabitləşmədən əvvəl istifadə edilə biləcəyi bir vəziyyət var: bir funksiyanın qayıdış növü vəziyyətində.
/// Xüsusilə, iki fərqli funksiya göstəricisi növü üçün tətbiqetmələr mümkündür:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` bir enum olduğu üçün bu kod etibarlıdır.
/// Lakin `Infallible`, never type üçün bir təxəllü halına gəldikdə, iki impl`s üst-üstə düşməyə başlayacaq və bu səbəbdən dilin trait uyğunluq qaydaları ilə icazə verilməyəcəkdir.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}