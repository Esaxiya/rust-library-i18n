#![stable(feature = "futures_api", since = "1.36.0")]

//! Asenkron dəyərlər.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Bu növə ehtiyac var, çünki:
///
/// a) Generatorlar `for<'a, 'b> Generator<&'a mut Context<'b>>` tətbiq edə bilmirlər, buna görə xam bir göstəricini keçməliyik (bax <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Xam göstəricilər və `NonNull` `Send` və ya `Sync` deyil, buna görə hər future non-Send/Sync-ni də düzəldə bilər və bunu istəmirik.
///
/// Həm də `.await`-in HIR endirilməsini asanlaşdırır.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Bir generatoru future-yə sarın.
///
/// Bu funksiya altındakı bir `GenFuture` qaytarır, lakin daha yaxşı səhv mesajları vermək üçün `impl Trait`-də gizlədir (`GenFuture<[closure.....]>` əvəzinə `impl Future`).
///
// `const async fn`-dən bərpa etdikdən sonra əlavə səhvlərin qarşısını almaq üçün bu `const`-dir
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Əsas generatorda öz-özünə istinad borcları yaratmaq üçün async/await futures-nin daşınmaz olduğuna inanırıq.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // TƏHLÜKƏSİZLİK: Təhlükəsiz olduğundan !Unpin + !Drop edirik və bu yalnız sahə proyeksiyasıdır.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // `&mut Context`-i `NonNull` xammal göstəricisinə çevirərək generatoru davam etdirin.
            // `.await` endirməsi təhlükəsiz bir şəkildə `&mut Context`-ə qayıdır.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // TƏHLÜKƏSİZLİK: zəng edən `cx.0`-nin etibarlı bir göstərici olduğuna zəmanət verməlidir
    // dəyişdirilə bilən bir istinad üçün bütün tələbləri yerinə yetirir.
    unsafe { &mut *cx.0.as_ptr().cast() }
}