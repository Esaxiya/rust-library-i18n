#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future asenkron hesablamanı təmsil edir.
///
/// future hələ hesablamağı bitirməmiş bir dəyərdir.
/// Bu cür "asynchronous value", dəyərin mövcud olmasını gözləyərkən bir iş parçasının faydalı işə davam etməsini mümkün edir.
///
///
/// # `poll` metodu
///
/// future, `poll` əsas metodu, * future-ni son dəyərə həll etməyə çalışır.
/// Qiymət hazır deyilsə, bu üsul bloklanmaz.
/// Bunun əvəzinə, cari tapşırığın təkrar sorğu ilə daha da irəliləməsi mümkün olduqda oyanması planlaşdırılır.
/// `poll` metoduna keçən `context`, cari tapşırığı oyandırmaq üçün bir qol olan bir [`Waker`] təmin edə bilər.
///
/// Bir future istifadə edərkən, ümumiyyətlə `poll`-yə birbaşa zəng etməyəcəksiniz, əksinə dəyəri `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Tamamlandıqda istehsal olunan dəyər növü.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// future-ni son bir dəyərə həll etməyə çalışın, dəyər hələ mövcud deyilsə oyanmaq üçün cari tapşırığı qeyd edin.
    ///
    /// # Qaytarma dəyəri
    ///
    /// Bu funksiya qayıdır:
    ///
    /// - [`Poll::Pending`] future hələ hazır deyilsə
    /// - [`Poll::Ready(val)`] uğurla başa çatmışsa bu future-nin `val` nəticəsi ilə.
    ///
    /// Bir future bitdikdən sonra müştərilər bir daha `poll` etməməlidirlər.
    ///
    /// Bir future hələ hazır olmadıqda, `poll` `Poll::Pending` qaytarır və mövcud [`Context`]-dən kopyalanan [`Waker`] klonunu saxlayır.
    /// future irəliləyə bildikdən sonra bu [`Waker`] oyanır.
    /// Məsələn, bir yuvanın oxunaqlı olmasını gözləyən bir future, [`Waker`]-də `.clone()`-ə zəng edib saxlayacaq.
    /// Soketin oxunaqlı olduğunu göstərən başqa bir siqnal gələndə [`Waker::wake`] çağırılır və yuva future-nin vəzifəsi oyanır.
    /// Bir tapşırıq oyandıqdan sonra, future-ı yenidən `poll`-yə cəhd etməlidir ki, bu da son dəyər verə bilər və ya göstərə bilməz.
    ///
    /// Qeyd edək ki, `poll`-ə çoxsaylı zənglərdə, yalnız [`Context`]-dən ən son zəngə ötürülən [`Waker`]-in oyanması planlaşdırılmalıdır.
    ///
    /// # İş vaxtının xüsusiyyətləri
    ///
    /// Yalnız Futures *inert*;irəliləməyə nail olmaq üçün *aktiv* şəkildə sorğu-suala tutulmalıdırlar, yəni cari tapşırıq hər dəfə oyandıqda, hələ maraqlandığı futures-ni yenidən aktivləşdirərək yenidən "poll" etməlidir.
    ///
    /// `poll` funksiyası sıx bir döngədə dəfələrlə çağırılmır-bunun əvəzinə yalnız future irəliləməyə hazır olduğunu göstərdikdə (`wake()`) çağıraraq) çağırılmalıdır.
    /// Unix-də `poll(2)` və ya `select(2)` syscallları ilə tanışsınızsa, futures-nin "all wakeups must poll all events"-in eyni problemlərinə məruz qalmadığını qeyd etmək lazımdır;daha çox `epoll(4)`-ə bənzəyirlər.
    ///
    /// `poll` tətbiqi sürətlə qayıtmağa çalışmalı və qarşısını almamalıdır.Sürətlə qayıtmaq, mövzuları və ya hadisə döngələrini lazımsız şəkildə tıxanmağın qarşısını alır.
    /// Əgər əvvəlcədən `poll`-ə edilən bir zəngin bir müddət çəkə biləcəyi bilinirsə, `poll`-in tez bir zamanda geri dönməsini təmin etmək üçün iş bir mövzu hovuzuna (və ya oxşar bir şeyə) yüklənməlidir.
    ///
    /// # Panics
    ///
    /// Bir future tamamlandıqdan sonra (`poll`-dən `Ready`-i qaytardı), yenidən `poll` metodunu çağıraraq panic, həmişəlik blok ola bilər və ya digər problemlərə səbəb ola bilər;`Future` trait, belə bir çağırışın təsirlərinə heç bir tələb qoymur.
    /// Bununla birlikdə, `poll` metodu `unsafe` olaraq qeyd olunmadığından, Rust-nin adi qaydaları tətbiq olunur: future vəziyyətindən asılı olmayaraq, zənglər heç vaxt təyin olunmayan davranışa (yaddaş pozulması, `unsafe` funksiyalarının səhv istifadəsi və ya bu kimi) səbəb olmamalıdır.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}