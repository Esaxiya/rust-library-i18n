//! İbtidai traits və növlərin əsas xüsusiyyətlərini əks etdirən növlər.
//!
//! Rust növləri daxili xüsusiyyətlərinə görə müxtəlif faydalı yollarla təsnif edilə bilər.
//! Bu təsnifatlar traits kimi təmsil olunur.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Mövzu sərhədləri arasında ötürülə bilən növlər.
///
/// Bu trait, kompilyator uyğun olduğunu təyin etdikdə avtomatik olaraq tətbiq olunur.
///
/// Göndərməyən bir növə nümunə [`rc::Rc`][`Rc`] istinad sayma göstəricisidir.
/// İki mövzu eyni referans sayılan dəyərə işarə edən [`Rc`] lərin klonlanmasına cəhd edərsə, eyni zamanda referans sayını da yeniləməyə çalışa bilərlər, bu da [undefined behavior][ub], çünki [`Rc`] atom əməliyyatlarından istifadə etmir.
///
/// [`sync::Arc`][arc] əmisi oğlu atom əməliyyatlarından istifadə edir (bəzi yüklər də daxil olmaqla) və beləliklə `Send`-dir.
///
/// Daha ətraflı məlumat üçün [the Nomicon](../../nomicon/send-and-sync.html)-ə baxın.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tərtib zamanı bilinən sabit ölçülü tiplər.
///
/// Bütün növ parametrlərin gizli bir `Sized` sərhədləri vardır.Xüsusi sintaksis `?Sized` uyğun olmadığı təqdirdə bu hüququ aradan qaldırmaq üçün istifadə edilə bilər.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//səhv: [i32] üçün ölçülü tətbiq edilmir
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// İstisnalardan biri, trait-nin gizli `Self` tipidir.
/// trait-in, trait-in bütün mümkün icraçılarla işləməsi lazım olduğu və bununla da istənilən ölçüdə ola biləcəyi [trait obyekti] ilə uyğun olmadığına görə trait-in gizli bir `Sized` əlaqəsi yoxdur.
///
///
/// Rust, `Sized` yi trait ilə bağlamağınıza icazə versə də, sonradan trait obyekti yaratmaq üçün istifadə edə bilməyəcəksiniz:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // qoy y: &dyn Bar= &Impl;//səhv: trait `Bar` bir obyekt halına gətirilə bilməz
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // məsələn, `[T]: !Default`-in qiymətləndirilə biləcəyini tələb edən Varsayılan üçün
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Dinamik ölçüdə bir tipə "unsized" ola biləcək növlər.
///
/// Məsələn, `[i8; 2]` ölçülü massiv növü `Unsize<[i8]>` və `Unsize<dyn fmt::Debug>` tətbiq edir.
///
/// `Unsize`-in bütün tətbiqləri kompilyator tərəfindən avtomatik təmin olunur.
///
/// `Unsize` üçün həyata keçirilir:
///
/// - `[T; N]` `Unsize<[T]>`-dir
/// - `T` `T: Trait` olduqda `Unsize<dyn Trait>` olur
/// - `Foo<..., T, ...>` əgər `Unsize<Foo<..., U, ...>>` olarsa:
///   - `T: Unsize<U>`
///   - Foo bir quruluşdur
///   - Yalnız son `Foo` sahəsi, `T`-i əhatə edən bir növə malikdir
///   - `T` digər sahələrin tipinə daxil deyil
///   - `Bar<T>: Unsize<Bar<U>>`, son `Foo` sahəsinin `Bar<T>` növü varsa
///
/// `Unsize` [`ops::CoerceUnsized`] ilə birlikdə [`Rc`] kimi "user-defined" konteynerlərin dinamik olaraq ölçülü növlərə sahib olmasına imkan vermək üçün istifadə olunur.
/// Daha ətraflı məlumat üçün [DST coercion RFC][RFC982] və [the nomicon entry on coercion][nomicon-coerce]-ə baxın.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Nümunə matçlarında istifadə olunan sabitlər üçün trait tələb olunur.
///
/// `PartialEq` əldə edən hər hansı bir növ, avtomatik olaraq bu trait-i tətbiq edir,*onun parametr parametrlərinin `Eq` tətbiq etməsindən asılı olmayaraq*.
///
/// Bir `const` maddəsində bu trait-ni tətbiq etməyən bir növ varsa, o tip ya (1.) `PartialEq`-i tətbiq etmir (yəni sabit kod istehsalının mövcud olduğunu düşünən bu müqayisə metodunu təmin etməyəcəkdir) və ya (2.)*öz tətbiq edir*`PartialEq` versiyası (struktur-bərabərlik müqayisəsinə uyğun gəlmir).
///
///
/// Yuxarıdakı iki ssenarinin hər hansı birində belə bir sabitin bir model uyğunluğunda istifadəsini rədd edirik.
///
/// Atribut əsaslı dizayndan bu trait-yə köçməyi motivasiya edən [structural match RFC][RFC1445] və [issue 63438]-ə də baxın.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Nümunə matçlarında istifadə olunan sabitlər üçün trait tələb olunur.
///
/// `Eq` əldə edən hər hansı bir növ, bu parametrin `Eq` tətbiq edib etməməsindən asılı olmayaraq * trait-i avtomatik olaraq tətbiq edir.
///
/// Bu tip sistemimizdəki bir məhdudiyyət ətrafında işləmək üçün bir hackdir.
///
/// # Background
///
/// Nümunə matçlarında istifadə olunan konst tiplərinin `#[derive(PartialEq, Eq)]` atributuna sahib olmasını tələb etmək istəyirik.
///
/// Daha ideal bir dünyada bu tələbin yalnız `StructuralPartialEq` trait *və*`Eq` trait'yi tətbiq etdiyini yoxlayaraq yoxlaya bilərik.
/// Bununla birlikdə,*do*`derive(PartialEq, Eq)` olan ADT-lərə sahib ola bilərsiniz və kompilyatorun qəbul etməsini istədiyimiz bir hal ola bilərik, buna baxmayaraq sabit tipi `Eq` tətbiq edə bilmir.
///
/// Məhz buna bənzər bir iş:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Yuxarıdakı koddakı problem `Wrap<fn(&())>`-in `PartialEq` və ya `Eq` tətbiq etməməsidir, çünki "üçün <'a> fn(&'a _)` does not implement those traits.)
///
/// Bu səbəbdən `StructuralPartialEq` və sadəcə `Eq` üçün sadəlövh bir çekə etibar edə bilmərik.
///
/// Bunun ətrafında işləmək üçün bir hack olaraq, (`#[derive(PartialEq)]` və `#[derive(Eq)]`) türevlərinin hər biri tərəfindən enjekte edilmiş iki ayrı traits istifadə edirik və hər ikisinin də struktur uyğunluğu yoxlanışının bir hissəsi olaraq mövcud olduğunu yoxlayırıq.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Dəyərləri, sadəcə bitlərin kopyalanması ilə çoxaldıla bilən növlər.
///
/// Varsayılan olaraq, dəyişkən bağlamalar 'hərəkət semantikasına' malikdir.Başqa sözlə:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y`-ə keçdi və belə istifadə edilə bilməz
///
/// // println! ("{: ?}", x);//səhv: köçürülmüş dəyərin istifadəsi
/// ```
///
/// Ancaq bir növ `Copy` tətbiq edərsə, bunun əvəzinə 'kopyalama semantikası' vardır:
///
/// ```
/// // Bir `Copy` tətbiqi əldə edə bilərik.
/// // `Clone` `Copy` supertrait olduğundan da tələb olunur.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x`-nin bir nüsxəsidir
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Qeyd etmək vacibdir ki, bu iki nümunədə, fərq yalnız tapşırıqdan sonra `x`-ə daxil olmağınızın olub-olmamasıdır.
/// Başlıq altında həm nüsxə, həm də hərəkət yaddaşda bitlərin kopyalanmasına səbəb ola bilər, baxmayaraq ki bu bəzən uzaqlaşdırılır.
///
/// ## `Copy`-i necə tətbiq edə bilərəm?
///
/// `Copy`-i növünüzə tətbiq etməyin iki yolu var.Ən sadə `derive` istifadə etməkdir:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// `Copy` və `Clone`-i əl ilə də tətbiq edə bilərsiniz:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Bu ikisi arasında kiçik bir fərq var: `derive` strategiyası, həmişə istənilməyən tip parametrlərinə bağlı bir `Copy` yerləşdirəcəkdir.
///
/// ## `Copy` ilə `Clone` arasındakı fərq nədir?
///
/// Nüsxələr dolayı şəkildə, məsələn `y = x` tapşırığının bir hissəsi kimi baş verir.`Copy` davranışı həddindən artıq yüklənmir;həmişə sadə bir müdrik surətdir.
///
/// Klonlaşdırma açıq bir hərəkətdir, `x.clone()`.[`Clone`]-in tətbiqi, dəyərlərin təhlükəsiz şəkildə çoxaldılması üçün lazım olan hər hansı bir tipik davranışı təmin edə bilər.
/// Məsələn, [`String`] üçün [`Clone`]-nin tətbiqi, yığındakı işarəli simli buferi kopyalamalıdır.
/// [`String`] dəyərlərinin sadə bir bit-kopiya nüsxəsi sadəcə göstəricini kopyalayaraq xəttin altındakı ikiqat sərbəstliyə gətirib çıxaracaqdır.
/// Bu səbəbdən [`String`] [`Clone`], `Copy` deyil.
///
/// [`Clone`] `Copy` supertraitidir, buna görə `Copy` olan hər şey [`Clone`]-i də tətbiq etməlidir.
/// Bir növ `Copy`-dirsə, onun [`Clone`] tətbiqetməsi yalnız `*self`-i qaytarmalıdır (yuxarıdakı nümunəyə baxın).
///
/// ## Nə vaxt `Copy` ola bilər?
///
/// Bir növ, bütün komponentləri `Copy` tətbiq edərsə `Copy` tətbiq edə bilər.Məsələn, bu struktur `Copy` ola bilər:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Bir quruluş `Copy` ola bilər və [`i32`] `Copy` dir, bu səbəbdən `Point` `Copy` olmaq hüququna malikdir.
/// Əksinə, düşünün
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` strukturu `Copy` tətbiq edə bilmir, çünki [`Vec<T>`] `Copy` deyil.Bir `Copy` tətbiqetməsini əldə etməyə çalışsaq, bir səhv alacağıq:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Paylaşılan istinadlar (`&T`) eyni zamanda `Copy`-dir, buna görə də *`Copy` olmayan*`T` tipli paylaşılan istinadları saxlasa belə, bir növ `Copy` ola bilər.
/// `Copy`-i tətbiq edə bilən aşağıdakı quruluşu nəzərdən keçirin, çünki yalnız yuxarıdan `Copy 'olmayan `PointList` tipimizə *paylaşılan bir istinad* edir:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Nə zaman * mənim tipim `Copy` ola bilməz?
///
/// Bəzi növlər təhlükəsiz şəkildə kopyalanamaz.Məsələn, `&mut T`-ni kopyalamaq, dəyişdirilə bilən bir referans yaradacaq.
/// [`String`]-ni kopyalamaq ['String`]' in tamponunu idarə etmək üçün məsuliyyəti təkrarlayaraq ikiqat pulsuzluğa səbəb olardı.
///
/// Son vəziyyəti ümumiləşdirərək, [`Drop`] tətbiq edən hər hansı bir növ `Copy` ola bilməz, çünki öz [`size_of::<T>`] baytından başqa bəzi mənbələri idarə edir.
///
/// `Copy`-i `Copy 'olmayan məlumatları olan bir struct və ya enumda tətbiq etməyə çalışarsanız, [E0204] səhvini alacaqsınız.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Nə vaxt * mənim tipim `Copy` olmalıdır?
///
/// Ümumiyyətlə, _can_ tipiniz `Copy` tətbiq edərsə, etməlidir.
/// Bununla birlikdə `Copy` tətbiqetmənin tipinizin ümumi API-sinin bir hissəsi olduğunu unutmayın.
/// Növ future-də "Kopyalanmayan" ola bilərsə, API dəyişməsinin pozulmasının qarşısını almaq üçün `Copy` tətbiqetməsini indi buraxmaq məqsədəuyğun ola bilər.
///
/// ## Əlavə icraçılar
///
/// [implementors listed below][impls] ilə yanaşı, aşağıdakı növlər də `Copy` tətbiq edir:
///
/// * Funksiya növü (yəni, hər bir funksiya üçün müəyyən edilmiş növlər)
/// * Funksiya göstəricisi növləri (məsələn, `fn() -> i32`)
/// * Maddə növü `Copy` tətbiq edərsə (məsələn, `[i32; 123456]`), bütün ölçülər üçün massiv növləri.
/// * Tuple növləri, əgər hər bir komponent `Copy` tətbiq edərsə (məsələn, `()`, `(i32, bool)`)
/// * Bağlanma növləri, ətraf mühitdən heç bir dəyər əldə etmədikləri təqdirdə və ya alınan bütün bu dəyərlər `Copy`-i özləri tətbiq edirlər.
///   Nəzərə alın ki, paylaşılan istinadla tutulan dəyişənlər hər zaman `Copy` tətbiq edir (referent olmasa belə), dəyişkən referansla tutulan dəyişənlər heç vaxt `Copy` tətbiq etmir.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Bu, ömür boyu həddini təmin etmədiyi üçün `Copy` tətbiq etməyən bir növü kopyalamağa imkan verir (yalnız `A<'static>: Copy` və `A<'_>: Clone` olduqda `A<'_>` kopyalayırıq).
// Hələlik burada bu xüsusiyyətə sahibik, çünki standart kitabxanada onsuz da mövcud olan `Copy`-də mövcud olan bir neçə ixtisas var və bu davranışı təhlükəsiz bir şəkildə qurmağın bir yolu yoxdur.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy`-in bir görünüşünü yaradan makro əldə edin.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Mövzular arasında istinadları bölüşmək üçün etibarlı olan növlər.
///
/// Bu trait, kompilyator uyğun olduğunu təyin etdikdə avtomatik olaraq tətbiq olunur.
///
/// Dəqiq tərif belədir: `T` növü [`Sync`] və yalnız `&T` [`Send`] olduqda.
/// Başqa sözlə, mövzuları arasında `&T` istinadlarını ötürərkən [undefined behavior][ub] (məlumat yarışları daxil olmaqla) ehtimalı yoxdursa.
///
/// Gözlənildiyi kimi, [`u8`] və [`f64`] kimi ibtidai növlərin hamısı [`Sync`]-dir və bunları özündə cəmləşdirən, quruluş və enum kimi sadə məcmu tiplər də var.
/// Əsas [`Sync`] tiplərinə daha çox nümunə arasında `&T` kimi "immutable" növləri və [`Box<T>`][box], [`Vec<T>`][vec] və digər çox kolleksiya növləri kimi sadə irsi dəyişkənliyə sahib olanlar daxildir.
///
/// (Konteynerlərinin [`Sync`] olması üçün ümumi parametrlərin [`Sync`] olması lazımdır.)
///
/// Tərifin bir qədər təəccüblü bir nəticəsi, `&mut T`-in `Sync` olmasıdır (`T` `Sync` olarsa), belə görünsə də, sinxronlaşdırılmamış mutasiya təmin edə bilər.
/// Hiylə budur ki, paylaşılan bir istinadın (yəni `& &mut T`) arxasındakı dəyişkən bir istinad, sanki bir `& &T` kimi oxunaqlı olur.
/// Bu səbəbdən bir məlumat yarışı riski yoxdur.
///
/// `Sync` olmayan tiplər, [`Cell`][cell] və [`RefCell`][refcell] kimi iplik təhlükəsiz olmayan formada "interior mutability" olanlardır.
/// Bu növlər, dəyişməz, paylaşılan bir istinad vasitəsi ilə də məzmununun mutasiyasına imkan verir.
/// Məsələn [`Cell<T>`][cell]-də `set` metodu `&self`-i alır, buna görə yalnız paylaşılan bir [`&Cell<T>`][cell] istinadına ehtiyac var.
/// Metod heç bir sinxronizasiya etmir, beləliklə [`Cell`][cell] `Sync` ola bilməz.
///
/// "Sync" olmayan bir növün başqa bir nümunəsi, [`Rc`][rc] istinad sayma göstəricisidir.
/// Hər hansı bir [`&Rc<T>`][rc] istinadını nəzərə alaraq, istinad sayımlarını atomik olmayan bir şəkildə dəyişdirərək yeni bir [`Rc<T>`][rc] klonlaya bilərsiniz.
///
/// Birinin iplikdən təhlükəsiz daxili dəyişkənliyə ehtiyacı olduğu hallarda, Rust, [atomic data types] və [`sync::Mutex`][mutex] və [`sync::RwLock`][rwlock] vasitəsilə açıq kilidlə təmin edir.
/// Bu tiplər hər hansı bir mutasiyanın məlumat yarışlarına səbəb ola bilməməsini təmin edir, bu səbəbdən də növləri `Sync`-dir.
/// Eynilə, [`sync::Arc`][arc], [`Rc`][rc]-in iplikdən təhlükəsiz bir analoqu təmin edir.
///
/// Daxili dəyişkənliyə sahib olan hər hansı bir növ, value(s) ətrafında [`cell::UnsafeCell`][unsafecell] sarğı istifadə etməli və paylaşılan bir istinad yolu ilə mutasiya edilə bilər.
/// Bunu etməmək [undefined behavior][ub]-dir.
/// Məsələn, `&T`-dən `&mut T`-ə [`transmute`][transmute]-ing etibarsızdır.
///
/// `Sync` haqqında daha ətraflı məlumat üçün [the Nomicon][nomicon-send-and-sync]-ə baxın.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): bir dəfə beta olaraq `rustc_on_unimplemented`-də qeydlər əlavə etmək üçün bir dəstək və bir bağlanmanın tələb zəncirinin hər hansı bir yerində olub olmadığını yoxlamaq üçün uzadıldı, onu (#48534) kimi uzatın:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Sıfır ölçülü tip "act like"-in `T`-ə sahib olduğunu qeyd etmək üçün istifadə olunur.
///
/// Tipinizə bir `PhantomData<T>` sahəsi əlavə etmək, tərtibçiyə tipinizin `T` tipli bir dəyəri saxladığı kimi fəaliyyət göstərdiyini söyləyir, baxmayaraq ki, əslində belə deyil.
/// Bu məlumatlar müəyyən təhlükəsizlik xüsusiyyətlərini hesablayarkən istifadə olunur.
///
/// `PhantomData<T>`-in necə istifadə ediləcəyinə dair daha dərin bir izahat üçün [the Nomicon](../../nomicon/phantom-data.html)-ə baxın.
///
/// # Dəhşətli bir qeyd 👻👻👻
///
/// Hər ikisinin də qorxunc adları olmasına baxmayaraq, `PhantomData` və 'fantom növləri' bir-birinə aiddir, lakin eyni deyil.Xəyal növü parametri sadəcə heç istifadə olunmayan bir tip parametridir.
/// Rust-də bu çox vaxt tərtibçinin şikayət etməsinə səbəb olur və həll yolu `PhantomData` yolu ilə "dummy" istifadəsi əlavə etməkdir.
///
/// # Examples
///
/// ## İstifadə olunmamış ömür parametrləri
///
/// `PhantomData` üçün bəlkə də ən çox istifadə olunan hal, ümumiyyətlə bəzi təhlükəli kodların bir hissəsi kimi istifadə edilməmiş ömür parametrinə sahib bir quruluşdur.
/// Məsələn, burada `*const T` tipli iki göstəriciyə sahib, ehtimal ki, bir yerə bir massivə işarə edən bir struktur `Slice`:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Niyyət budur ki, əsas məlumatlar yalnız `'a` ömrü üçün etibarlıdır, buna görə `Slice` `'a`-dən çox olmamalıdır.
/// Bununla birlikdə, bu niyyət kodda ifadə edilmir, çünki `'a` ömrü boyu istifadəsi yoxdur və bu səbəbdən hansı məlumatlara aid olduğu aydın deyil.
/// Tərtibçiyə *sanki*`Slice` strukturunda bir `&'a T` istinadı olduğu kimi hərəkət etməsini söyləyərək düzəldə bilərik:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Bu da öz növbəsində `T`-dəki hər hansı bir istinadın ömür boyu `'a` boyunca etibarlı olduğunu göstərən `T: 'a` izahatını tələb edir.
///
/// Bir `Slice`-i işə salarkən, `phantom` sahəsi üçün `PhantomData` dəyərini verirsiniz:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## İstifadə olunmayan tip parametrləri
///
/// Bəzən olur ki, bir strukturun "tied" hansı məlumat növü olduğunu göstərən istifadə olunmamış tip parametrləriniz olur, baxmayaraq ki, bu məlumat strukturun özündə yoxdur.
/// Budur bunun [FFI] ilə ortaya çıxdığı bir nümunə.
/// Xarici interfeys, müxtəlif növlərin Rust dəyərlərinə istinad etmək üçün `*mut ()` tipli tutacaqlardan istifadə edir.
/// Rust tipini bir sapı saran `ExternalResource` struct üzərində bir xəyal növü parametrindən istifadə edərək izləyirik.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Mülkiyyət və açılan yoxlama
///
/// `PhantomData<T>` tipli bir sahə əlavə etmək, tipinizin `T` tipli məlumatlara sahib olduğunu göstərir.Bu da öz növbəsində tipiniz düşdükdə, `T` tipli bir və ya daha çox nümunəni ata biləcəyini nəzərdə tutur.
/// Bu, Rust kompilyatorunun [drop check] analizinə təsir göstərir.
///
/// Quruluşunuz əslində `T` tipli məlumatlara *sahib deyilsə, mülkiyyəti göstərməmək üçün `PhantomData<&'a T>` (ideally) və ya `PhantomData<* const T>` (ömür boyu keçməzsə) kimi bir istinad növündən istifadə etmək daha yaxşıdır.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Enum ayrı-seçkilik növünü göstərmək üçün istifadə olunan kompilyator daxili trait.
///
/// Bu trait avtomatik olaraq hər növ üçün tətbiq olunur və [`mem::Discriminant`]-ə heç bir zəmanət vermir.
/// `DiscriminantKind::Discriminant` və `mem::Discriminant` arasında transmute etmək **təyin olunmamış davranışdır**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// `mem::Discriminant` tərəfindən tələb olunan trait bounds-ni ödəməli olan ayrı-seçkilik növü.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Kompilyator daxili trait bir növün daxildə hər hansı bir `UnsafeCell` ehtiva etdiyini təyin etmək üçün istifadə olunur, lakin dolayı yolla deyil.
///
/// Bu, məsələn, bu tip bir `static`-nin yalnız oxunaqlı statik yaddaşa və ya yazılabilir statik yaddaşa yerləşdirilməsinə təsir göstərir.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Sıxıldıqdan sonra təhlükəsiz şəkildə köçürülə bilən növlər.
///
/// Rust-nin özündə daşınmaz növlər barədə heç bir təsəvvür yoxdur və hərəkətləri (məsələn, tapşırıq və ya [`mem::replace`] yolu ilə) həmişə təhlükəsiz hesab edir.
///
/// [`Pin`][Pin] tipi, sistem sistemindəki hərəkətlərin qarşısını almaq üçün istifadə olunur.[`Pin<P<T>>`][Pin] bükücüyə bükülmüş `P<T>` göstəriciləri xaricə çıxarıla bilməz.
/// Bağlama haqqında daha çox məlumat üçün [`pin` module] sənədlərinə baxın.
///
/// `T` üçün `Unpin` trait-nin tətbiqi, X0 [`mem::replace`] kimi funksiyalarla `T`-dən [`Pin<P<T>>`][Pin]-dən kənara çıxmağa imkan verən tipi bağlamaq məhdudiyyətlərini qaldırır.
///
///
/// `Unpin` sabitlənməmiş məlumatlar üçün heç bir nəticə yoxdur.
/// Xüsusilə, [`mem::replace`] məmnuniyyətlə `!Unpin` məlumatlarını hərəkətə gətirir (yalnız `T: Unpin` olduqda deyil, hər hansı bir `&mut T` üçün işləyir).
/// Bununla birlikdə, [`Pin<P<T>>`][Pin]-in içərisinə bükülmüş məlumatlarda [`mem::replace`] istifadə edə bilməzsiniz, çünki bunun üçün lazım olan `&mut T`-i əldə edə bilməzsiniz və *bu* bu sistemin işləməsini təmin edir.
///
/// Beləliklə, bu, yalnız `Unpin` tətbiq edən növlərdə edilə bilər:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace`-ə zəng etmək üçün dəyişdirilə bilən bir referansa ehtiyacımız var.
/// // `Pin::deref_mut`-i çağıraraq (implicitly) tərəfindən belə bir istinad əldə edə bilərik, ancaq bu, yalnız `String`-in `Unpin` tətbiq etdiyi üçün mümkündür.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Bu trait demək olar ki, hər növ üçün avtomatik olaraq tətbiq olunur.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` tətbiq etməyən marker növü.
///
/// Bir növ `PhantomPinned` ehtiva edərsə, `Unpin`-i varsayılan olaraq tətbiq etməz.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// İbtidai tiplər üçün `Copy` tətbiqləri.
///
/// Rust-də təsvir edilə bilməyən tətbiqetmələr `rustc_trait_selection`-də `traits::SelectionContext::copy_clone_conditions()`-də həyata keçirilir.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Paylaşılan istinadlar kopyalana bilər, ancaq dəyişdirilə bilən istinadlar *mümkün deyil*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}