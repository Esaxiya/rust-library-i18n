//! Paylaşıla bilən dəyişdirilə bilən qablar.
//!
//! Rust yaddaş təhlükəsizliyi bu qaydaya əsaslanır: `T` obyekti nəzərə alınmaqla aşağıdakılardan yalnız biri mümkündür:
//!
//! - (`&T`) obyektinə bir neçə dəyişməz müraciətə sahib olmaq (**aliasing** kimi də tanınır).
//! - Obyektə bir dəyişdirilə bilən referansın (`&mut T`) olması (**dəyişkənlik** olaraq da bilinir).
//!
//! Bu Rust tərtibçisi tərəfindən tətbiq olunur.Ancaq bu qaydanın kifayət qədər çevik olmadığı vəziyyətlər var.Bəzən bir obyektə birdən çox müraciət etmək və onu dəyişdirmək tələb olunur.
//!
//! Paylaşıla bilən dəyişkən konteynerlər, dəyişdirmə mövcud olduğu təqdirdə də, dəyişkənliyə nəzarət altında bir şəkildə icazə vermək üçün mövcuddur.Həm [`Cell<T>`], həm də [`RefCell<T>`] bunu tək yivli bir şəkildə etməyə imkan verir.
//! Bununla birlikdə, nə `Cell<T>`, nə də `RefCell<T>` təhlükəsizdir ([`Sync`] tətbiq etmirlər).
//! Birdən çox mövzu arasında yumuşatma və mutasiya etmək lazımdırsa, [`Mutex<T>`], [`RwLock<T>`] və ya [`atomic`] tiplərindən istifadə etmək mümkündür.
//!
//! `Cell<T>` və `RefCell<T>` tiplərinin dəyərləri paylaşılan istinadlar vasitəsilə mutasiya edilə bilər (yəni
//! ümumi `&T` növü), əksər Rust növləri isə yalnız unikal (`&mut T`) istinadlarla mutasiya edilə bilər.
//! `Cell<T>` və `RefCell<T>` 'irsi dəyişkənlik' nümayiş etdirən tipik Rust tiplərindən fərqli olaraq 'daxili dəyişkənlik' təmin etdiyini söyləyirik.
//!
//! Hüceyrə növləri iki tatlardan ibarətdir: `Cell<T>` və `RefCell<T>`.`Cell<T>`, dəyərləri `Cell<T>`-də və xaricində hərəkət etdirərək daxili dəyişkənliyi həyata keçirir.
//! Dəyərlər yerinə istinadlar istifadə etmək üçün mutasiyaya başlamazdan əvvəl yazma kilidi əldə edərək `RefCell<T>` tipini istifadə etmək lazımdır.`Cell<T>`, mövcud daxili dəyəri almaq və dəyişdirmək üçün metodlar təqdim edir:
//!
//!  - [`Copy`] tətbiq edən növlər üçün [`get`](Cell::get) metodu cari daxili dəyəri alır.
//!  - [`Default`] tətbiq edən növlər üçün [`take`](Cell::take) metodu mövcud daxili dəyəri [`Default::default()`] ilə əvəz edir və dəyişdirilmiş dəyəri qaytarır.
//!  - Bütün növlər üçün [`replace`](Cell::replace) metodu mövcud daxili dəyəri əvəz edir və dəyişdirilmiş dəyəri qaytarır və [`into_inner`](Cell::into_inner) metodu `Cell<T>`-i istehlak edir və daxili dəyəri qaytarır.
//!  Əlavə olaraq, [`set`](Cell::set) metodu daxili dəyəri əvəz edir və dəyişdirilmiş dəyəri azaldır.
//!
//! `RefCell<T>` daxili dinamikaya müvəqqəti, müstəsna, dəyişkən giriş tələb edə biləcəyi bir müddət olan 'dinamik borc' tətbiq etmək üçün Rust-nin ömrünü istifadə edir.
//! RefCell üçün borc alır<T>Rust-nin tərtibat zamanı tamamilə statik olaraq izlənilən yerli istinad növlərindən fərqli olaraq 'iş vaxtında' izlənilir.
//! `RefCell<T>` borcları dinamik olduğundan onsuz da qarşılıqlı olaraq dəyişdirilə bilən bir dəyəri götürməyə cəhd etmək mümkündür;bu baş verdikdə panic ipliyi ilə nəticələnir.
//!
//! # Daxili dəyişkənliyi nə vaxt seçmək lazımdır
//!
//! Bir dəyərə mutasiya etmək üçün unikal bir girişə sahib olması lazım olan daha çox yayılmış irsi dəyişkənlik, Rust-nin göstəricinin yüngülləşdirilməsi ilə bağlı ciddi fikirləşməsinə və qəza səhvlərinin statik olaraq qarşısını almasına imkan verən əsas dil elementlərindən biridir.
//! Bu səbəbdən irsi dəyişkənliyə üstünlük verilir və daxili dəyişkənlik son çarədir.
//! Hüceyrə növləri, əks halda icazə verilmədiyi yerdə mutasiyaya imkan verdiyindən, daxili dəyişkənliyin uyğun ola biləcəyi və ya hətta * istifadə edilməli olduğu hallar var;
//!
//! * Dəyişilməz bir şeyin dəyişkənliyi 'inside' təqdim olunur
//! * Məntiqi dəyişməz metodların tətbiq detalları.
//! * [`Clone`] tətbiqetmələrinin mutasiya edilməsi.
//!
//! ## Dəyişilməz bir şeyin dəyişkənliyi 'inside' təqdim olunur
//!
//! [`Rc<T>`] və [`Arc<T>`] daxil olmaqla bir çox paylaşılan ağıllı göstərici növləri, bir çox tərəf arasında klonlana və paylaşıla bilən qablar təmin edir.
//! İçəridə olan dəyərlər çox takma ola biləcəyi üçün, `&mut` deyil, yalnız `&` ilə borc götürülə bilər.
//! Hüceyrəsiz bu ağıllı göstəricilərin içindəki məlumatları mutasiya etmək ümumiyyətlə mümkün deyildi.
//!
//! Daha sonra dəyişkənliyi bərpa etmək üçün paylaşılan göstərici növlərinin içinə `RefCell<T>` qoymaq çox yaygındır:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Dinamik borcun əhatə dairəsini məhdudlaşdırmaq üçün yeni bir blok yaradın
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Diqqət yetirin ki, önbelleğin əvvəlki borcunun əhatə dairəsindən çıxmasına icazə verməsəydik, sonrakı borc panic dinamik bir mövzuya səbəb olardı.
//!     //
//!     // Bu, `RefCell` istifadəsinin əsas təhlükəsidir.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Qeyd edək ki, bu nümunə `Arc<T>` deyil, `Rc<T>` istifadə edir."RefCell<T>'lar tək yivli ssenarilər üçündür.Çox yivli vəziyyətdə paylaşılan dəyişkənliyə ehtiyacınız varsa, [`RwLock<T>`] və ya [`Mutex<T>`] istifadə etməyi düşünün.
//!
//! ## Məntiqi dəyişməz metodların tətbiq detalları
//!
//! Bəzən bir API-də "under the hood"-də baş verən mutasiyanın olduğunu açıqlamamaq istənə bilər.
//! Bunun səbəbi məntiqi olaraq əməliyyatın dəyişməz olmasıdır, lakin məsələn, önbelleğe alma tətbiqetməni mutasiya etməyə məcbur edir;ya da əvvəlcə `&self` qəbul etməsi üçün təyin olunmuş bir trait metodunu tətbiq etmək üçün mutasiya tətbiq etməlisiniz.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Bahalı hesablama buraya gedir
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` tətbiqetmələrinin mutasiya edilməsi
//!
//! Bu, sadəcə əvvəlki hadisənin xüsusi, lakin ümumi bir vəziyyətidir: dəyişməz görünən əməliyyatlar üçün dəyişkənliyi gizlətmək.
//! [`clone`](Clone::clone) metodunun mənbə dəyərini dəyişdirməyəcəyi gözlənilir və `&mut self` deyil, `&self` alacağı bildirilir.
//! Buna görə `clone` metodunda baş verən hər hansı bir mutasiya hüceyrə tiplərindən istifadə etməlidir.
//! Məsələn, [`Rc<T>`], referans sayımlarını bir `Cell<T>` içərisində saxlayır.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Dəyişdirilə bilən yaddaş yeri.
///
/// # Examples
///
/// Bu nümunədə `Cell<T>`-in dəyişməz bir quruluş içindəki mutasiyaya imkan verdiyini görə bilərsiniz.
/// Başqa sözlə, "interior mutability"-ə imkan verir.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // XATA: `my_struct` dəyişməzdir
/// // my_struct.regular_field =new_value;
///
/// // İŞLƏR: `my_struct` dəyişməz olsa da, `special_field` bir `Cell`,
/// // hər zaman mutasiya edilə bilər
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Daha çox məlumat üçün [module-level documentation](self)-ə baxın.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// T üçün `Default` dəyəri ilə bir `Cell<T>` yaradır.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Verilən dəyəri ehtiva edən yeni bir `Cell` yaradır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// İçindəki dəyəri təyin edir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// İki Hüceyrənin dəyərlərini dəyişdirir.
    /// `std::mem::swap` ilə fərq bu funksiyanın `&mut` istinadına ehtiyac duymamasıdır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // TƏHLÜKƏSİZLİK: Ayrı mövzulardan çağırılsa, bu riskli ola bilər, ancaq `Cell`
        // `!Sync` olduğundan bu olmaz.
        // Bu da heç bir göstəricini ləğv etməyəcəkdir, çünki `Cell` başqa bir şeyin bu `` Hüceyrə '' nin hər hansı birinə yönəlməyəcəyindən əmin olur.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// İçəridəki dəyəri `val` ilə əvəz edir və köhnə olan dəyəri qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // TƏHLÜKƏSİZLİK: Ayrı bir mövzudan çağırılsa, bu məlumat yarışlarına səbəb ola bilər,
        // lakin `Cell` `!Sync` dir, buna görə bu olmaz.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Dəyəri açar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// İçindəki dəyərin bir nüsxəsini qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // TƏHLÜKƏSİZLİK: Ayrı bir mövzudan çağırılsa, bu məlumat yarışlarına səbəb ola bilər,
        // lakin `Cell` `!Sync` dir, buna görə bu olmaz.
        unsafe { *self.value.get() }
    }

    /// Əməliyyatdan istifadə edərək dəyərini yeniləyir və yeni dəyəri qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Xam göstəricini bu hüceyrədəki əsas məlumatlara qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Əsas məlumatlara dəyişdirilə bilən bir istinad qaytarır.
    ///
    /// Bu zəng, `Cell`-i mütləq borcludur (tərtib zamanı), yalnız arayışa sahib olduğumuzu təmin edir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&mut T`-dən `&Cell<T>` qaytarır
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // TƏHLÜKƏSİZLİK: `&mut` unikal giriş təmin edir.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// `Default::default()`-ni yerinə qoyaraq hüceyrənin dəyərini alır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&Cell<[T]>`-dən `&[Cell<T>]` qaytarır
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // TƏHLÜKƏSİZLİK: `Cell<T>`, `T` ilə eyni yaddaş düzəninə malikdir.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Dinamik olaraq yoxlanılmış borc qaydalarına malik dəyişkən yaddaş yeri
///
/// Daha çox məlumat üçün [module-level documentation](self)-ə baxın.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] tərəfindən qaytarılmış bir səhv.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] tərəfindən qaytarılmış bir səhv.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Müsbət dəyərlər `Ref` aktiv sayını təmsil edir.Mənfi dəyərlər `RefMut` aktiv sayını təmsil edir.
// Birdən çox `RefMut` yalnız bir `RefCell`-nin fərqli, üst-üstə düşməyən komponentlərinə (məsələn, bir dilimin müxtəlif aralıklarına) istinad etdikdə aktiv ola bilər.
//
// `Ref` və `RefMut` hər ikisi də iki sözdür və buna görə də `usize` aralığının yarısını aşmaq üçün mövcud olan Ref və ya RefMut'lar heç vaxt olmayacaqdır.
// Beləliklə, bir `BorrowFlag`, ehtimal ki, heç vaxt daşmayacaq və ya daşmayacaq.
// Bununla birlikdə, bu bir zəmanət deyil, çünki bir patoloji proqramı dəfələrlə mem::forget `Ref`s və ya RefMut`s yarada bilər.
// Beləliklə, təhlükəsizliyin qarşısını almaq və ya heç olmasa daşma və ya aşma hadisəsi baş verdiyi təqdirdə düzgün davranmaq üçün bütün kodlar açıq şəkildə daşma və axma olub olmadığını yoxlamalıdır (məsələn, BorrowRef::new-ə baxın).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` ehtiva edən yeni bir `RefCell` yaradır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Sarılmış dəyəri qaytararaq `RefCell`-i istehlak edir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Bu funksiya dəyərinə görə `self` (`RefCell`) aldığından, tərtibçi statistik olaraq hal-hazırda götürülmədiyini təsdiqləyir.
        //
        self.value.into_inner()
    }

    /// Sarılmış dəyəri yenisini dəyişdirir, köhnə dəyəri qaytarır, ikisini deinisallaşdırmadan.
    ///
    ///
    /// Bu funksiya [`std::mem::replace`](../mem/fn.replace.html)-ə uyğundur.
    ///
    /// # Panics
    ///
    /// Panics, dəyər hazırda alınmışsa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Sarılmış dəyəri, ikisini deinisallaşdırmadan köhnə dəyəri qaytararaq `f`-dən hesablanan yenisi ilə əvəz edir.
    ///
    ///
    /// # Panics
    ///
    /// Panics, dəyər hazırda alınmışsa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `self` bükülmüş dəyərini `other` bükülmüş dəyəri ilə dəyişdirir, heç birini deinisallaşdırmadan.
    ///
    ///
    /// Bu funksiya [`std::mem::swap`](../mem/fn.swap.html)-ə uyğundur.
    ///
    /// # Panics
    ///
    /// Hər iki `RefCell` dəyərində hal-hazırda borc varsa Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Sarılmış dəyəri dəyişməz şəkildə borc alır.
    ///
    /// Borc qaytarılan `Ref` əhatə dairəsindən çıxana qədər davam edir.
    /// Eyni zamanda birdən çox dəyişməz borc götürülə bilər.
    ///
    /// # Panics
    ///
    /// Panics, dəyər hazırda dəyişdirilə bilər.
    /// Çaxnaşma olmayan bir variant üçün [`try_borrow`](#method.try_borrow) istifadə edin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic nümunəsi:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Dəyişdirilə bilən borc alındığı təqdirdə bir səhv qaytararaq bükülmüş dəyəri borcludur.
    ///
    ///
    /// Borc qaytarılan `Ref` əhatə dairəsindən çıxana qədər davam edir.
    /// Eyni zamanda birdən çox dəyişməz borc götürülə bilər.
    ///
    /// Bu, [`borrow`](#method.borrow)-in çaxnaşmayan variantıdır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // TƏHLÜKƏSİZLİK: `BorrowRef` yalnız dəyişməz girişin olmasını təmin edir
            // borc alarkən dəyərinə.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Sarılmış dəyəri borcludur.
    ///
    /// Borc qaytarılan `RefMut`-ə və ya ondan çıxarılan bütün RefMut-lara qədər davam edir.
    ///
    /// Bu borc aktiv olduqda dəyər götürülə bilməz.
    ///
    /// # Panics
    ///
    /// Panics, dəyər hazırda alınmışsa.
    /// Çaxnaşma olmayan bir variant üçün [`try_borrow_mut`](#method.try_borrow_mut) istifadə edin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic nümunəsi:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Dəyişik olaraq bükülmüş dəyəri borc götürür, dəyər hazırda borc alındıqda bir səhv qaytarır.
    ///
    ///
    /// Borc qaytarılan `RefMut`-ə və ya ondan çıxarılan bütün RefMut-lara qədər davam edir.
    /// Bu borc aktiv olduqda dəyər götürülə bilməz.
    ///
    /// Bu, [`borrow_mut`](#method.borrow_mut)-in çaxnaşmayan variantıdır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // TƏHLÜKƏSİZLİK: `BorrowRef` unikal girişi təmin edir.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Xam göstəricini bu hüceyrədəki əsas məlumatlara qaytarır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Əsas məlumatlara dəyişdirilə bilən bir istinad qaytarır.
    ///
    /// Bu zəng `RefCell`-i mütəmadi olaraq borc alır (tərtib zamanı), beləliklə dinamik çeklərə ehtiyac qalmır.
    ///
    /// Lakin ehtiyatlı olun: bu metod `self`-in dəyişkən olmasını gözləyir, bu ümumiyyətlə `RefCell` istifadə edərkən belə deyil.
    ///
    /// `self` dəyişkən deyilsə, bunun əvəzinə [`borrow_mut`] metoduna nəzər yetirin.
    ///
    /// Xahiş edirəm unutmayın ki, bu metod yalnız xüsusi şərtlər üçündür və ümumiyyətlə istədiyiniz kimi deyil.
    /// Şübhə yaranarsa, bunun əvəzinə [`borrow_mut`] istifadə edin.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Sızan mühafizəçilərin `RefCell` borc vəziyyəti üzərindəki təsirini ləğv edin.
    ///
    /// Bu zəng [`get_mut`]-ə bənzəyir, lakin daha ixtisaslaşdırılmışdır.
    /// Borcların olmamasını təmin etmək üçün `RefCell`-i mütləq borc alır və sonra dövlət izləmə paylaşılan borclarını sıfırlayır.
    /// Bəzi `Ref` və ya `RefMut` borcları sızdırılıbsa, bu aktualdır.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Dəyişdirilə bilən borc alındığı təqdirdə bir səhv qaytararaq bükülmüş dəyəri borcludur.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow`-dən fərqli olaraq bu metod təhlükəlidir, çünki bir `Ref` qaytarmır, beləliklə borc bayrağını toxunulmaz qoyur.
    /// Bu metodla qaytarılmış istinad sağ ikən `RefCell`-i mütəmadi olaraq borc almaq, təyin olunmamış davranışdır.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // TƏHLÜKƏSİZLİK: İndi heç kimin aktiv yazmadığını yoxlayırıq, amma yazır
            // zəng edən şəxsin qaytarılmış arayışın artıq istifadə olunmayana qədər heç kimin yazmamasını təmin etmək məsuliyyəti.
            // Ayrıca, `self.value.get()`, `self`-in sahib olduğu dəyərə istinad edir və beləliklə, `self`-nin ömrü boyu etibarlıdır.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// `Default::default()`-ni yerinə qoyaraq bükülmüş dəyəri alır.
    ///
    /// # Panics
    ///
    /// Panics, dəyər hazırda alınmışsa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, dəyər hazırda dəyişdirilə bilər.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// T üçün `Default` dəyəri ilə bir `RefCell<T>` yaradır.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Hər iki `RefCell` dəyərində hal-hazırda borc varsa Panics.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Hər iki `RefCell` dəyərində hal-hazırda borc varsa Panics.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Hər iki `RefCell` dəyərində hal-hazırda borc varsa Panics.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Hər iki `RefCell` dəyərində hal-hazırda borc varsa Panics.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Hər iki `RefCell` dəyərində hal-hazırda borc varsa Panics.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Hər iki `RefCell` dəyərində hal-hazırda borc varsa Panics.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Hər iki `RefCell` dəyərində hal-hazırda borc varsa Panics.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Borc borcunun artırılması aşağıdakı hallarda oxunmayan dəyərlə nəticələnə bilər (<=0):
            // 1. <0 idi, yəni yazılı borclar var, buna görə Rust-nin istinad təxəlləsi qaydalarına görə oxunan borclara icazə verə bilmərik
            // 2.
            // isize::MAX (oxu borclarının maksimum miqdarı) idi və isize::MIN-ə (yazılı borcların maksimum miqdarı) düşdü, buna görə əlavə oxunma borcuna icazə verə bilmərik, çünki isize bu qədər oxunmuş borcları təmsil edə bilməz (bu yalnız ola bilər mem::forget-dən kiçik bir sabit miqdardan daha yaxşıdır, bu yaxşı təcrübə deyil)
            //
            //
            //
            //
            None
        } else {
            // Artan borc aşağıdakı hallarda oxu dəyərinə (> 0) səbəb ola bilər:
            // 1. =0 idi, yəni borc alınmadı və ilk oxunan borcu götürürük
            // 2. > 0 və <isize::MAX idi, yəni
            // oxunan borclar var idi və daha çox oxunan borcun olmasını təmsil edəcək qədər böyükdür
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Bu Ref mövcud olduğundan, borc bayrağının oxu borcu olduğunu bilirik.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Borc sayğacının yazılı borc içərisinə keçməsinin qarşısını alın.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Borc götürülmüş bir referansı `RefCell` qutusundakı bir dəyərə sarar.
/// `RefCell<T>`-dən dəyişməz borc dəyəri üçün bir sarğı növü.
///
/// Daha çox məlumat üçün [module-level documentation](self)-ə baxın.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// `Ref`-i kopyalayır.
    ///
    /// `RefCell` onsuz da dəyişilməz şəkildə götürülmüşdür, buna görə də bu uğursuz ola bilməz.
    ///
    /// Bu, `Ref::clone(...)` olaraq istifadə edilməsi lazım olan əlaqəli bir funksiyadır.
    /// Bir `Clone` tətbiqi və ya bir metod bir `RefCell`-in tərkibini klonlaşdırmaq üçün `r.borrow().clone()`-in geniş istifadəsinə müdaxilə edə bilər.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Borc verilənlərinin bir hissəsi üçün yeni bir `Ref` hazırlayır.
    ///
    /// `RefCell` onsuz da dəyişilməz şəkildə götürülmüşdür, buna görə də bu uğursuz ola bilməz.
    ///
    /// Bu, `Ref::map(...)` olaraq istifadə edilməsi lazım olan əlaqəli bir funksiyadır.
    /// Bir metod, `Deref` vasitəsilə istifadə edilən bir `RefCell` məzmununun eyni adlı metodlarına müdaxilə edə bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Borc verilənlərinin isteğe bağlı bir komponenti üçün yeni bir `Ref` hazırlayır.
    /// Bağlanma `None`-yə qayıdırsa, orijinal qoruyucu `Err(..)` olaraq qaytarılır.
    ///
    /// `RefCell` onsuz da dəyişilməz şəkildə götürülmüşdür, buna görə də bu uğursuz ola bilməz.
    ///
    /// Bu, `Ref::filter_map(...)` olaraq istifadə edilməsi lazım olan əlaqəli bir funksiyadır.
    /// Bir metod, `Deref` vasitəsilə istifadə edilən bir `RefCell` məzmununun eyni adlı metodlarına müdaxilə edə bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Alınan məlumatların müxtəlif komponentləri üçün bir `Ref`-i birdən çox `Ref`-ə bölür.
    ///
    /// `RefCell` onsuz da dəyişilməz şəkildə götürülmüşdür, buna görə də bu uğursuz ola bilməz.
    ///
    /// Bu, `Ref::map_split(...)` olaraq istifadə edilməsi lazım olan əlaqəli bir funksiyadır.
    /// Bir metod, `Deref` vasitəsilə istifadə edilən bir `RefCell` məzmununun eyni adlı metodlarına müdaxilə edə bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Əsas məlumatlara istinad halına gətirin.
    ///
    /// Əsas `RefCell` heç vaxt yenidən dəyişdirilə bilməz və həmişə dəyişilməz borc kimi görünəcəkdir.
    ///
    /// Daimi bir sıra istinadlardan daha çox məlumat sızdırmaq yaxşı deyil.
    /// Cəmi daha az sayda sızma baş vermişsə, `RefCell` yenidən dəyişilməz şəkildə götürülə bilər.
    ///
    /// Bu, `Ref::leak(...)` olaraq istifadə edilməsi lazım olan əlaqəli bir funksiyadır.
    /// Bir metod, `Deref` vasitəsilə istifadə edilən bir `RefCell` məzmununun eyni adlı metodlarına müdaxilə edə bilər.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Bu Ref-i unutmaqla RefCell-dəki borc sayğacının ömür boyu `'b` müddətində İSTİFADƏSİZƏ qayıda bilməyəcəyini təmin edirik.
        // Referans izləmə vəziyyətinin sıfırlanması üçün borc götürülmüş RefCell-ə bənzərsiz bir istinad lazımdır.
        // Orijinal hücrədən başqa dəyişdirilə bilən istinadlar yaradıla bilməz.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Alınan məlumatların bir komponenti üçün yeni bir `RefMut` hazırlayır, məsələn, bir enum variantı.
    ///
    /// `RefCell` onsuz da dəyişdirilə bilər, buna görə bu uğursuz ola bilməz.
    ///
    /// Bu, `RefMut::map(...)` olaraq istifadə edilməsi lazım olan əlaqəli bir funksiyadır.
    /// Bir metod, `Deref` vasitəsilə istifadə edilən bir `RefCell` məzmununun eyni adlı metodlarına müdaxilə edə bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): borc çekini düzəlt
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Borc verilənlərinin isteğe bağlı bir komponenti üçün yeni bir `RefMut` hazırlayır.
    /// Bağlanma `None`-yə qayıdırsa, orijinal qoruyucu `Err(..)` olaraq qaytarılır.
    ///
    /// `RefCell` onsuz da dəyişdirilə bilər, buna görə bu uğursuz ola bilməz.
    ///
    /// Bu, `RefMut::filter_map(...)` olaraq istifadə edilməsi lazım olan əlaqəli bir funksiyadır.
    /// Bir metod, `Deref` vasitəsilə istifadə edilən bir `RefCell` məzmununun eyni adlı metodlarına müdaxilə edə bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): borc çekini düzəlt
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // TƏHLÜKƏSİZLİK: funksiya müddət ərzində müstəsna bir istinad üzərində saxlanılır
        // `orig` vasitəsilə göstərilən zəng və göstərici yalnız funksional çağırışın içərisində istinad edilmir, müstəsna istinadın qaçmasına imkan verməz.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // TƏHLÜKƏSİZLİK: yuxarıdakı kimi.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Borc verilən məlumatların fərqli komponentləri üçün bir `RefMut`-i birdən çox `RefMut`-a bölür.
    ///
    /// Əsas `RefCell`, hər iki qaytarılmış RefMut'un əhatə dairəsindən çıxana qədər qarşılıqlı olaraq borc alacaqdır.
    ///
    /// `RefCell` onsuz da dəyişdirilə bilər, buna görə bu uğursuz ola bilməz.
    ///
    /// Bu, `RefMut::map_split(...)` olaraq istifadə edilməsi lazım olan əlaqəli bir funksiyadır.
    /// Bir metod, `Deref` vasitəsilə istifadə edilən bir `RefCell` məzmununun eyni adlı metodlarına müdaxilə edə bilər.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Əsas məlumatlara dəyişdirilə bilən bir referansa çevirin.
    ///
    /// Əsas `RefCell` yenidən götürülə bilməz və hər zaman əvvəlcədən dəyişdirilə bilən kimi görünəcək və geri qaytarılmış referansı yalnız interyerə çevirir.
    ///
    ///
    /// Bu, `RefMut::leak(...)` olaraq istifadə edilməsi lazım olan əlaqəli bir funksiyadır.
    /// Bir metod, `Deref` vasitəsilə istifadə edilən bir `RefCell` məzmununun eyni adlı metodlarına müdaxilə edə bilər.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Bu BorrowRefMut'u unudaraq RefCell-dəki borc sayğacının `'b` ömrü boyu İSTİFADƏSİNDƏ geri dönə bilməməsini təmin edirik.
        // Referans izləmə vəziyyətinin sıfırlanması üçün borc götürülmüş RefCell-ə bənzərsiz bir istinad lazımdır.
        // Bu ömür boyu orijinal hücrədən başqa heç bir istinad yaradıla bilməz, beləliklə cari borc qalan ömür üçün yeganə istinaddır.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone-dən fərqli olaraq, yeni başlanğıc yaratmaq üçün çağırılır
        // dəyişdirilə bilən bir referans və buna görə hazırda mövcud istinadlar olmamalıdır.
        // Beləliklə, klon dəyişdirilə bilən yenidən saymanı artırsa da, burada açıq şəkildə yalnız İSTİFADƏSİZDƏN İSTİFADƏSİZƏ keçməyə icazə veririk.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut` klonlaşdırır.
    //
    // Bu, yalnız hər bir `BorrowRefMut` orijinal obyektin fərqli, üst-üstə düşməyən aralığına dəyişkən bir istinadın izlənməsi üçün istifadə edildikdə etibarlıdır.
    //
    // Kod Clone'u dolayısı ilə çağırmaması üçün bu bir Clone örtükündə deyil.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Borc sayğacının aşağı düşməsinin qarşısını alın.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>`-dən dəyişdirilə bilən borc dəyəri üçün bir sarğı növü.
///
/// Daha çox məlumat üçün [module-level documentation](self)-ə baxın.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust-də daxili dəyişkənlik üçün əsas ibtidai.
///
/// Bir referans `&T` varsa, normal olaraq Rust-də tərtibçi `&T`-in dəyişməz məlumatlara işarə etdiyi biliyinə əsasən optimallaşdırma aparır.Bu məlumatların dəyişdirilməsi, məsələn bir təxəllüs və ya `&T`-i `&mut T`-ə çevirmək, təyin olunmamış davranış hesab olunur.
/// `UnsafeCell<T>` `&T` üçün dəyişməzlik zəmanətindən imtina edildi: paylaşılan bir referans `&UnsafeCell<T>` mutasiyaya uğrayan məlumatları göstərə bilər.Buna "interior mutability" deyilir.
///
/// `Cell<T>` və `RefCell<T>` kimi daxili dəyişkənliyə imkan verən bütün digər növlər, məlumatlarını bağlamaq üçün daxili olaraq `UnsafeCell` istifadə edirlər.
///
/// `UnsafeCell`-dən yalnız paylaşılan istinadlar üçün dəyişməzlik zəmanətinin təsir etdiyini unutmayın.Dəyişdirilə bilən istinadlar üçün unikallıq zəmanəti təsir etmir.`UnsafeCell<T>`-lə belə, `&mut`-yə başqa ad vermək üçün * qanuni bir yol yoxdur.
///
/// `UnsafeCell` API özü texniki cəhətdən çox sadədir: [`.get()`] sizə məzmununa görə `*mut T` xam göstəricisini verir.Bu xam göstəricidən düzgün istifadə etmək abstraksiya dizayneri olaraq _you_-ə qədərdir.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Dəqiq Rust takma qaydaları bir qədər axındadır, lakin əsas məqamlar mübahisəli deyil:
///
/// - Ömür boyu `'a` ilə (ya da `&T` və ya `&mut T` istinadları ilə) etibarlı bir kodla (məsələn, geri qaytardığınız üçün) əldə edilə bilən etibarlı bir istinad yaradırsınızsa, o zaman qalanlara istinadla zidd olan hər hansı bir şəkildə məlumat əldə etməməlisiniz. `'a`.
/// Məsələn, bu o deməkdir ki, `*mut T`-i `UnsafeCell<T>`-dən götürüb `&T`-ə atarsanız, `T`-dəki məlumatlar dəyişməz olaraq qalmalıdır (əlbəttə ki, `T` daxilində olan hər hansı bir `UnsafeCell` məlumatının modulu) həmin istinad ömrü bitənə qədər.
/// Eynilə, təhlükəsiz bir kod üçün buraxılmış bir `&mut T` referansı yaradırsınızsa, bu referansın müddəti bitənə qədər `UnsafeCell` içərisindəki məlumatlara girməməlisiniz.
///
/// - Hər zaman məlumat yarışlarından çəkinməlisiniz.Birdən çox mövzu eyni `UnsafeCell`-yə çıxış əldə edirsə, hər hansı bir yazının bütün digər girişlərlə (və ya atomiklərdən istifadə ilə) əvvəl bir əlaqəsi olmalıdır.
///
/// Müvafiq dizaynla kömək etmək üçün aşağıdakı ssenarilər tək yivli kod üçün açıq şəkildə qanuniləşdirilir:
///
/// 1. Bir `&T` referansı təhlükəsiz koda buraxıla bilər və orada digər `&T` istinadları ilə birlikdə mövcud ola bilər, lakin bir `&mut T` ilə deyil
///
/// 2. Nə digər `&mut T`, nə də `&T` onunla birlikdə mövcud olduğu təqdirdə bir `&mut T` referansı təhlükəsiz koda göndərilə bilər.`&mut T` həmişə bənzərsiz olmalıdır.
///
/// Bir `&UnsafeCell<T>`-in (digər `&UnsafeCell<T>` hüceyrə ləqəbinə istinad etdiyi halda da) məzmununun dəyişdirilməsi yaxşı olduğu halda (yuxarıdakı dəyişməzləri başqa bir şəkildə tətbiq etməyiniz şərti ilə) yaxşı olmasına baxmayaraq, birdən çox `&mut UnsafeCell<T>` təxəllüsünə sahib olmağınız hələ də müəyyən edilməmiş bir davranış olduğunu unutmayın.
/// Yəni `UnsafeCell`, `&UnsafeCell<_>` referansı vasitəsilə _shared_ accesses (_i.e._ ilə xüsusi bir qarşılıqlı əlaqəyə sahib olmaq üçün hazırlanmış bir sarıcıdır);_exclusive_ accesses (_e.g._ ilə işləyərkən bir `&mut UnsafeCell<_>` vasitəsilə heç bir sehr yoxdur): nə `&mut` borc müddəti ərzində nə hücrə, nə də bükülmüş dəyər yüngülləşdirilə bilməz.
///
/// Bu, `&mut T` verən _safe_ getter olan [`.get_mut()`] accessor tərəfindən nümayiş olunur.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Budur, hüceyrəni yüngülləşdirən bir çox istinad olmasına baxmayaraq bir `UnsafeCell<_>`-in məzmununun necə səssiz bir şəkildə dəyişdiriləcəyini göstərən bir nümunə:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Eyni `x`-ə birdən çox/paylaşılan müraciət edin.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // TƏHLÜKƏSİZLİK: bu çərçivədə `x`in məzmununa dair başqa heç bir istinad yoxdur,
///     // beləliklə bizimki effektiv şəkildə bənzərsizdir.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- borc-+
///     *p1_exclusive += 27; // |
/// } // <---------- bu nöqtədən kənara çıxa bilməz -------------------+
///
/// unsafe {
///     // TƏHLÜKƏSİZLİK: bu əhatədə heç kimin "x" in məzmununa müstəsna girişi gözləməz,
///     // eyni zamanda birdən çox paylaşılan giriş əldə edə bilərik.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Aşağıdakı nümunə, bir `UnsafeCell<T>`-ə eksklüziv girişin onun `T`-ə eksklüziv girişi nəzərdə tutduğunu göstərir:
///
/// ```rust
/// #![forbid(unsafe_code)] // eksklüziv girişləri ilə,
///                         // `UnsafeCell` şəffaf bir op-paketdir, buna görə burada `unsafe`-ə ehtiyac yoxdur.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x`-ə bir tərtib zamanı yoxlanılmış unikal istinad alın.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Xüsusi bir istinadla, məzmunu pulsuz olaraq dəyişdirə bilərik.
/// *p_unique.get_mut() = 0;
/// // Və ya ekvivalent olaraq:
/// x = UnsafeCell::new(0);
///
/// // Dəyər sahibi olduğumuz zaman məzmunu pulsuz olaraq çıxara bilərik.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Müəyyən edilmiş dəyəri saracaq yeni bir `UnsafeCell` nümunəsi qurur.
    ///
    ///
    /// Metodlar vasitəsilə daxili dəyərə bütün giriş `unsafe`-dir.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Dəyəri açar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Sarılmış dəyərə dəyişdirilə bilən bir göstərici alır.
    ///
    /// Bu, hər cür bir göstəriciyə atıla bilər.
    /// `&mut T`-yə yayımlayarkən girişin unikal olmasını təmin edin (aktiv istinadlar yoxdur, dəyişilə bilər və ya olmaz) və `&T`-ə yayımlanarkən mutasiyaların və dəyişkən takma adların olmadığından əmin olun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] olduğundan göstəricini `UnsafeCell<T>`-dən `T`-ə sala bilərik.
        // Bu, libstd-nin xüsusi statusundan istifadə edir, istifadəçi kodu üçün kompilyatorun future versiyalarında işləyəcəyinə zəmanət yoxdur!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Əsas məlumatlara dəyişdirilə bilən bir istinad qaytarır.
    ///
    /// Bu zəng, `UnsafeCell`-i mütləq borcludur (tərtib vaxtında), yalnız arayışa sahib olduğumuza zəmanət verir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Sarılmış dəyərə dəyişdirilə bilən bir göstərici alır.
    /// [`get`]-dən fərq ondadır ki, bu funksiya müvəqqəti istinadların yaradılmasının qarşısını almaq üçün faydalı olan xam göstəricini qəbul edir.
    ///
    /// Nəticə hər cür bir göstəriciyə atıla bilər.
    /// `&mut T`-yə yayımlanarkən girişin unikal olmasını təmin edin (aktiv istinadlar yoxdur, dəyişilə bilər və ya olmur) və `&T`-ə yayımlanarkən mutasiyaların və dəyişkən takma adların olmadığından əmin olun.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Bir `UnsafeCell`-in tədricən işə salınması `raw_get`-yə ehtiyac duyur, çünki `get`-in çağrılması başlanmamış məlumatlara istinad yaratmağı tələb edir:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] olduğundan göstəricini `UnsafeCell<T>`-dən `T`-ə sala bilərik.
        // Bu, libstd-nin xüsusi statusundan istifadə edir, istifadəçi kodu üçün kompilyatorun future versiyalarında işləyəcəyinə zəmanət yoxdur!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// T üçün `Default` dəyəri olan bir `UnsafeCell` yaradır.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}