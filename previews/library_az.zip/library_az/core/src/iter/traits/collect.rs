/// [`Iterator`]-dən konversiya.
///
/// Bir növ üçün `FromIterator` tətbiq edərək, bir iteratordan necə yaradılacağını təyin edirsiniz.
/// Bu, bir növ kolleksiyanı təsvir edən növlər üçün yaygındır.
///
/// [`FromIterator::from_iter()`] nadir hallarda açıq şəkildə adlandırılır və bunun əvəzinə [`Iterator::collect()`] metodu ilə istifadə olunur.
///
/// Daha çox nümunə üçün [`Iterator::collect()`]'s sənədlərinə baxın.
///
/// Həmçinin bax: [`IntoIterator`].
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator`-i dolğun şəkildə istifadə etmək üçün [`Iterator::collect()`] istifadə:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Tipiniz üçün `FromIterator` tətbiq olunur:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Nümunə kolleksiya, bu yalnız Vec üzərində bir sarğıdır<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Gəlin ona bir neçə metod verək ki, birini yarada bilək və əlavə edək.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // və FromIterator tətbiq edəcəyik
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // İndi yeni bir iterator edə bilərik ...
/// let iter = (0..5).into_iter();
///
/// // ... və ondan bir MyCollection hazırlayın
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // əsərləri də topla!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Bir iteratordan dəyər yaradır.
    ///
    /// Daha çox məlumat üçün [module-level documentation]-ə baxın.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`]-ə çevrilmə.
///
/// Bir növ üçün `IntoIterator` tətbiq edərək, bir iteratora necə çevriləcəyini təyin edirsiniz.
/// Bu, bir növ kolleksiyanı təsvir edən növlər üçün yaygındır.
///
/// `IntoIterator` tətbiqinin bir faydası, tipinizin [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) olacağıdır.
///
///
/// Həmçinin bax: [`FromIterator`].
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Tipiniz üçün `IntoIterator` tətbiq olunur:
///
/// ```
/// // Nümunə kolleksiya, bu yalnız Vec üzərində bir sarğıdır<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Gəlin ona bir neçə metod verək ki, birini yarada bilək və əlavə edək.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // və biz IntoIterator tətbiq edəcəyik
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // İndi yeni bir kolleksiya edə bilərik ...
/// let mut c = MyCollection::new();
///
/// // ... ona bir şey əlavə edin ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... və sonra onu təkrarlayıcıya çevirin:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator`-dən trait bound kimi istifadə etmək adi haldır.Bu, hələ də təkrarlayıcı olduğu müddətcə giriş toplama növünün dəyişdirilməsinə imkan verir.
/// Məhdudlaşdırmaqla əlavə sərhədlər təyin edilə bilər
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Təkrarlanan elementlərin növü.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Bunu hansı iteratora çeviririk?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Dəyərdən iterator yaradır.
    ///
    /// Daha çox məlumat üçün [module-level documentation]-ə baxın.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Bir iteratorun məzmunu ilə bir kolleksiyanı genişləndirin.
///
/// Təkrarlayıcılar bir sıra dəyərlər yaradır və koleksiyonlar da bir sıra dəyərlər kimi qəbul edilə bilər.
/// `Extend` trait, bu boşluğu birləşdirir və bu iteratorun tərkibini daxil edərək kolleksiyanı genişləndirməyə imkan verir.
/// Zaten mövcud olan bir açarı olan bir kolleksiyanı genişləndirərkən, bu giriş yenilənir və ya bərabər düymələrlə birdən çox girişə icazə verən kolleksiyalar halında, bu giriş daxil edilir.
///
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// // Bir simli bəzi işarələrlə genişləndirə bilərsiniz:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` tətbiq:
///
/// ```
/// // Nümunə kolleksiya, bu yalnız Vec üzərində bir sarğıdır<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Gəlin ona bir neçə metod verək ki, birini yarada bilək və əlavə edək.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection'da i32s siyahısı olduğu üçün i32 üçün Extend tətbiq edirik
/// impl Extend<i32> for MyCollection {
///
///     // Bu konkret tipli imza ilə bir az daha asandır: bizə i32s verən bir Iteratora çevrilə bilən hər hansı bir şeyə genişlənməyə zəng edə bilərik.
///     // Çünki MyCollection'a qoymaq üçün i32'lərə ehtiyacımız var.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Tətbiq çox sadədir: təkrarlayıcıdan keçin və hər elementi özümüzə add().
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // kolleksiyamızı daha üç nömrə ilə genişləndirək
/// c.extend(vec![1, 2, 3]);
///
/// // bu elementləri sonuna əlavə etdik
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Bir iteratorun məzmunu ilə bir kolleksiyanı genişləndirir.
    ///
    /// Bu trait üçün tələb olunan yeganə metod olduğundan [trait-level] sənədləri daha çox məlumat ehtiva edir.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // Bir simli bəzi işarələrlə genişləndirə bilərsiniz:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Tam bir elementi olan bir kolleksiyanı genişləndirir.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Verilən sayda əlavə element üçün kolleksiyada ehtiyat tutumu.
    ///
    /// Varsayılan tətbiq heç bir şey etmir.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}