// ignore-tidy-filelength Bu fayl demək olar ki, yalnız `Iterator` tərifindən ibarətdir.
// Bunu birdən çox fayla bölə bilmərik.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// İteratorlarla işləmək üçün bir interfeys.
///
/// Bu əsas iterator trait.
/// Ümumiyyətlə təkrarlayıcıların konsepsiyası haqqında daha çox məlumat üçün [module-level documentation]-ə baxın.
/// Xüsusilə, [implement `Iterator`][impl] necə edəcəyinizi bilmək istəyə bilərsiniz.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Təkrarlanan elementlərin növü.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Təkrarlayıcıya irəliləyir və növbəti dəyəri qaytarır.
    ///
    /// Yineleme bitdikdə [`None`] qaytarır.
    /// Fərdi təkrarlayıcı tətbiqetmələr təkrarlamaya davam etməyi seçə bilər və buna görə də `next()`-ə yenidən zəng etmək [`Some(Item)`]-i yenidən bir nöqtəyə qaytarmağa başlaya bilər və ya başlamaya bilər.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next()-ə edilən zəng növbəti dəyəri qaytarır ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... və sonra bitdikdən sonra Yoxdur.
    /// assert_eq!(None, iter.next());
    ///
    /// // Daha çox zəng `None`-i qaytara bilər və ya verməyəcək.Burada həmişə olacaqlar.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// İteratorun qalan uzunluğundakı sərhədləri qaytarır.
    ///
    /// Xüsusi olaraq, `size_hint()`, birinci elementin alt sərhəd, ikinci elementin isə yuxarı sərhəd olduğu bir qayıq qaytarır.
    ///
    /// Döndürülən bağlamanın ikinci yarısı [`Seçim`]`<`[`usize`] `>` dir.
    /// Buradakı [`None`], bilinən bir yuxarı sərhəd olmadığı və ya yuxarı sərhədin [`usize`]-dən daha böyük olduğu anlamına gəlir.
    ///
    /// # Tətbiq qeydləri
    ///
    /// Bir təkrarlayıcı tətbiqetmənin elan edilmiş sayda element verməsi məcbur edilmir.Bir arabalı iterator elementlərin alt sərhədlərindən az və ya yuxarı sərhədlərindən daha çox məhsul verə bilər.
    ///
    /// `size_hint()` ilk növbədə iterator elementləri üçün yer ayırmaq kimi optimallaşdırma üçün istifadə edilmək üçün nəzərdə tutulur, lakin etibarlı olmayan kodda məhdudiyyətləri yoxlamaq üçün etibar edilməməlidir.
    /// `size_hint()`-in səhv tətbiqi yaddaş təhlükəsizliyi pozuntularına səbəb olmamalıdır.
    ///
    /// Yəni tətbiq düzgün bir qiymətləndirmə təmin etməlidir, çünki əks halda trait protokolunun pozulması olardı.
    ///
    /// Varsayılan tətbiq, hər hansı bir təkrarlayıcı üçün düzgün olan "(0," [`None`]")"qayıdır.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Daha mürəkkəb bir nümunə:
    ///
    /// ```
    /// // Cütlər sıfırdan ona qədərdir.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Sıfırdan on dəfə təkrarlaya bilərik.
    /// // Tam beş olduğunu bilmək filter()-i icra etmədən mümkün olmayacaqdır.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // chain() ilə beş ədəd daha əlavə edək
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // indi hər iki sərhəd beş artırıldı
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Üst sərhəd üçün `None` qaytarılması:
    ///
    /// ```
    /// // sonsuz iteratorun yuxarı həddi və mümkün maksimum alt sərhədi yoxdur
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Təkrar sayını hesablayaraq geri qaytararaq təkrarlayıcıyı istehlak edir.
    ///
    /// Bu metod [`None`]-ə rast gəlinənə qədər dəfələrlə [`next`]-yə zəng vurur və [`Some`]-i gördüyü sayını qaytarır.
    /// Xatırladaq ki, təkrarlayıcıda heç bir element olmasa da, [`next`] ən azı bir dəfə çağırılmalıdır.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Daşqın davranışı
    ///
    /// Metod daşqınlara qarşı heç bir qorunma yaratmır, buna görə [`usize::MAX`]-dən çox elementi olan bir iteratorun elementlərini saymaq ya səhv nəticə verir, ya da panics.
    ///
    /// Hata düzəltmə iddiaları aktivdirsə, panic-yə zəmanət verilir.
    ///
    /// # Panics
    ///
    /// İteratorun [`usize::MAX`]-dən çox elementi varsa, bu funksiya panic ola bilər.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Son elementi qaytararaq təkrarlayıcı istehlak edir.
    ///
    /// Bu metod, [`None`] qaytarana qədər iteratoru qiymətləndirəcəkdir.
    /// Bunu edərkən mövcud elementi izləyir.
    /// [`None`] qaytarıldıqdan sonra `last()` gördüyü son elementi qaytaracaq.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` elementləri ilə iteratoru irəliləyir.
    ///
    /// Bu metod, [`None`] qarşılaşana qədər [`next`]-dən `n`-ə qədər zəng edərək `n` elementlərini həvəslə atlayacaqdır.
    ///
    /// `advance_by(n)` iterator `n` elementləri ilə uğurla irəliləyirsə [`Ok(())`][Ok] və ya [`None`] ilə qarşılaşdıqda [`Err(k)`][Err], burada `k`, iteratorun elementləri tükənmədən əvvəl inkişaf etdirilən elementlərin sayıdır (yəni
    /// iteratorun uzunluğu).
    /// `k`-in həmişə `n`-dən az olduğunu unutmayın.
    ///
    /// `advance_by(0)`-ə zəng etmək heç bir element istehlak etmir və həmişə [`Ok(())`][Ok]-i qaytarır.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // yalnız `&4` atlandı
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// İteratorun `n` elementini qaytarır.
    ///
    /// Əksər indeksləmə əməliyyatları kimi, sayma sıfırdan başlayır, beləliklə `nth(0)` birinci dəyəri, `nth(1)` ikinci və s. Qaytarır.
    ///
    /// Bütün əvvəlki elementlərin və qaytarılmış elementin təkrarlayıcıdan istehlak ediləcəyini unutmayın.
    /// Bu, əvvəlki elementlərin atılacağı və eyni təkrarlayıcıda `nth(0)`-i bir neçə dəfə axtarmağın fərqli elementləri qaytarması deməkdir.
    ///
    ///
    /// `nth()` `n` təkrarlayıcının uzunluğundan böyük və ya bərabər olarsa [`None`] qaytaracaqdır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()`-ə bir neçə dəfə zəng etmək təkrarlayıcıyı geri qaytarmır:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1`-dən az element varsa `None`-i qaytarır:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Eyni nöqtədən başlayan, lakin hər təkrarlanmada verilən miqdarı addımlayaraq bir iterator yaradır.
    ///
    /// Qeyd 1: Verilən addımdan asılı olmayaraq təkrarlayıcının ilk elementi hər zaman geri qaytarılacaqdır.
    ///
    /// Qeyd 2: Laqeyd elementlərin çəkildiyi vaxt sabit deyil.
    /// `StepBy` `next(), nth(step-1), nth(step-1),…` ardıcıllığı kimi davranır, eyni zamanda ardıcıllıq kimi davranmaqda sərbəstdir
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Hansı yol istifadə olunur, bəzi təkrarlayıcılar üçün performans səbəbi ilə dəyişə bilər.
    /// İkinci yol iteratoru əvvəllər irəliləyəcək və daha çox məhsul istehlak edə bilər.
    ///
    /// `advance_n_and_return_first` bərabərdir:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Verilən addım `0` olduqda metod panic olacaqdır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// İki təkrarlayıcı götürür və hər ikisində ardıcıllıqla yeni iterator yaradır.
    ///
    /// `chain()` əvvəlcə birinci iteratordan sonra ikinci iteratordan alınan dəyərlər üzərində təkrarlanan yeni bir təkrarlayıcı qaytaracaq.
    ///
    /// Başqa sözlə, iki təkrarlayıcıyı bir zəncirdə birləşdirir.🔗
    ///
    /// [`once`] adətən tək bir dəyəri digər təkrarlama zəncirinə uyğunlaşdırmaq üçün istifadə olunur.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()`-in mübahisəsi [`IntoIterator`]-dən istifadə etdiyindən, [`Iterator`]-in özünə deyil, [`Iterator`]-ə çevrilə bilən hər şeyi ötürə bilərik.
    /// Məsələn, (`&[T]`) dilimləri [`IntoIterator`] tətbiq edir və beləliklə birbaşa `chain()`-ə ötürülə bilər:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Windows API ilə işləyirsinizsə, [`OsStr`]-i `Vec<u16>`-ə çevirmək istəyə bilərsiniz:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// İki təkrarlayıcıları cüt tək bir təkrarlayıcıya 'sıxışdırın'.
    ///
    /// `zip()` birinci elementin birinci iteratordan, ikinci elementin isə ikinci iteratordan gəldiyi bir topl qayıdaraq, iki digər təkrarlayıcı üzərində təkrarlanacaq yeni bir təkrarlayıcı qaytarır.
    ///
    ///
    /// Başqa sözlə, iki təkrarlayıcıyı birinə birləşdirir.
    ///
    /// Hər iki iterator [`None`] qaytararsa, fermuar iteratordan [`next`] [`None`]-i qaytaracaqdır.
    /// Birinci təkrarlayıcı [`None`] qaytararsa, `zip` qısa qapanacaq və ikinci iteratorda `next` çağırılmayacaq.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()`-in mübahisəsi [`IntoIterator`]-dən istifadə etdiyindən, yalnız [`Iterator`]-in özünə deyil, [`Iterator`]-ə çevrilə bilən hər şeyi ötürə bilərik.
    /// Məsələn, (`&[T]`) dilimləri [`IntoIterator`] tətbiq edir və beləliklə birbaşa `zip()`-ə ötürülə bilər:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` tez-tez sonsuz bir iteratoru sonluya çevirmək üçün istifadə olunur.
    /// Bu işləyir, çünki sonlu iterator sonda fermuarı bitirərək [`None`] qaytaracaq.`(0..)` ilə fermuar [`enumerate`] kimi çox görünə bilər:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Orijinal iteratorun bitişik elementləri arasında `separator` nüsxəsini yerləşdirən yeni bir iterator yaradır.
    ///
    /// `separator` in [`Clone`] tətbiq etməməsi və ya hər dəfə hesablanması lazım olduqda, [`intersperse_with`] istifadə edin.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a`-dən ilk element.
    /// assert_eq!(a.next(), Some(&100)); // Ayırıcı.
    /// assert_eq!(a.next(), Some(&1));   // `a`-dən növbəti element.
    /// assert_eq!(a.next(), Some(&100)); // Ayırıcı.
    /// assert_eq!(a.next(), Some(&2));   // `a`-dən son element.
    /// assert_eq!(a.next(), None);       // İterator tamamlandı.
    /// ```
    ///
    /// `intersperse` ümumi bir elementdən istifadə edərək iterator maddələrinə qoşulmaq çox faydalı ola bilər:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// `separator` tərəfindən yaradılan bir elementi orijinal iteratorun bitişik elementləri arasında yerləşdirən yeni bir iterator yaradır.
    ///
    /// Bağlama, hər bir element əsas iteratordan iki bitişik maddə arasına qoyulduqda tam olaraq bir dəfə çağırılacaq;
    /// konkret olaraq, əsas iterator iki elementdən az məhsul verərsə və son maddə verildikdən sonra bağlanma deyilmir.
    ///
    ///
    /// İteratorun maddəsi [`Clone`] tətbiq edərsə, [`intersperse`] istifadə etmək daha asan ola bilər.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v`-dən ilk element.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ayırıcı.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v`-dən növbəti element.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ayırıcı.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v`-dən son element.
    /// assert_eq!(it.next(), None);               // İterator tamamlandı.
    /// ```
    ///
    /// `intersperse_with` ayırıcının hesablanması lazım olan hallarda istifadə edilə bilər:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Bağlama, bir maddə yaratmaq üçün kontekstini dəyişkən şəkildə borclandırır.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Bir bağlama aparır və hər bir elementdə bu bağlanmanı çağıran bir iterator yaradır.
    ///
    /// `map()` arqumenti ilə bir iteratoru digərinə çevirir:
    /// [`FnMut`] tətbiq edən bir şey.Orijinal iteratorun hər bir elementində bu bağlanmanı adlandıran yeni bir iterator istehsal edir.
    ///
    /// Türlərdə düşünməyi yaxşı bilirsinizsə, `map()` haqqında belə düşünə bilərsiniz:
    /// Sizə bir növ `A` elementləri verən bir iterator varsa və başqa bir `B` tipli bir iterator istəsəniz, `A` götürüb bir `B` qaytaran bir qapanmadan keçərək `map()` istifadə edə bilərsiniz.
    ///
    ///
    /// `map()` konseptual olaraq [`for`] döngəsinə bənzəyir.Bununla birlikdə, `map()` tənbəl olduğundan, ən yaxşısı onsuz da digər təkrarlayıcılarla işləyərkən istifadə olunur.
    /// Yan təsir üçün bir növ ilmə edirsinizsə, [`for`]-i `map()`-dən istifadə etmək daha idiomatik hesab olunur.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bir növ yan təsir göstərirsinizsə, [`for`]-dən `map()`-ə üstünlük verin:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // bunu etmə:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // hətta tənbəl olduğu üçün icra olunmayacaq.Rust bu barədə sizi xəbərdar edəcəkdir.
    ///
    /// // Bunun əvəzinə aşağıdakılardan istifadə edin:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Bir iteratorun hər bir elementinə bağlanma çağırır.
    ///
    /// Bu, `break` və `continue`-nin bağlanmasından mümkün olmasa da, təkrarlayıcıda [`for`] döngəsinin istifadəsinə bərabərdir.
    /// `for` döngəsini istifadə etmək ümumiyyətlə daha idiomatikdir, lakin `for_each` daha uzun iterator zəncirlərinin sonunda maddələr işləyərkən daha aydın ola bilər.
    ///
    /// Bəzi hallarda `for_each` bir döngüdən daha sürətli ola bilər, çünki `Chain` kimi adapterlərdə daxili iterasiya istifadə edəcəkdir.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Belə kiçik bir nümunə üçün bir `for` döngəsi daha təmiz ola bilər, lakin `for_each` daha uzun təkrarlayıcılarla funksional bir stil saxlamağa üstünlük verə bilər:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Bir elementin veriləcəyini təyin etmək üçün bir qapanmadan istifadə edən bir iterator yaradır.
    ///
    /// Bir element verildikdə, bağlanma `true` və ya `false`-ni qaytarmalıdır.Geri dönən təkrarlayıcı yalnız bağlanmanın doğru olduğu elementləri verəcəkdir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `filter()`-ə ötürülən bağlanma bir istinad aldığından və bir çox təkrarlayıcılar istinadlar üzərində təkrarlandığından, bu bağlanma növünün ikiqat bir istinad olduğu ehtimal edilən qarışıq bir vəziyyətə səbəb olur:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // iki * s lazımdır!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Bunun əvəzinə birini dağıtmaq üçün arqumentdə dağıdıcılığı istifadə etmək yaygındır:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // həm&həm *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// və ya hər ikisi:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // iki &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// bu təbəqələrdən.
    ///
    /// `iter.filter(f).next()`-in `iter.find(f)`-ə bərabər olduğunu unutmayın.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Həm süzgəcləri, həm də xəritələri bir iterator yaradır.
    ///
    /// Geri qaytarılmış təkrarlayıcı yalnız təchiz edilmiş bağlanmanın `Some(value)`-ni qaytardığı "dəyər" verir.
    ///
    /// `filter_map` [`filter`] və [`map`] zəncirlərini daha qısa etmək üçün istifadə edilə bilər.
    /// Aşağıdakı nümunə, `map().filter().map()`-in `filter_map`-ə tək bir zəngə necə qısaldılacağını göstərir.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Budur eyni nümunə, lakin [`filter`] və [`map`] ilə:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Cari təkrar sayını və növbəti dəyəri verən bir iterator yaradır.
    ///
    /// Geri qaytarılan `(i, val)` cütlüyünü verir, burada `i` indiki iterasiya indeksidir və `val` təkrarlayıcının qaytardığı dəyərdir.
    ///
    ///
    /// `enumerate()` sayını [`usize`] olaraq saxlayır.
    /// Fərqli ölçülü bir tam saymaq istəyirsinizsə, [`zip`] funksiyası oxşar funksiyanı təmin edir.
    ///
    /// # Daşqın davranışı
    ///
    /// Metod daşqınlara qarşı heç bir qorunma yaratmır, buna görə [`usize::MAX`] elementlərindən çoxunu sadalamaq ya səhv nəticə verir, ya da panics.
    /// Hata düzəltmə iddiaları aktivdirsə, panic-yə zəmanət verilir.
    ///
    /// # Panics
    ///
    /// Geri qaytarılmalı olan indeks bir [`usize`]-dən çox olsaydı, qaytarılmış iterator panic ola bilər.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// [`peek`]-dən istifadə edərək təkrarlayıcı elementə istehlak etmədən baxa bilən təkrarlayıcı yaradır.
    ///
    /// Bir iteratora [`peek`] üsulu əlavə edir.Daha çox məlumat üçün sənədlərinə baxın.
    ///
    /// [`peek`] ilk dəfə çağrıldıqda, əsas təkrarlayıcının hələ də inkişaf etdiyini unutmayın: Növbəti elementi əldə etmək üçün [`next`], əsas iteratora çağırılır, buna görə hər hansı bir yan təsir (yəni
    ///
    /// [`next`] metodunun növbəti dəyərini almaqdan başqa bir şey meydana gələcək.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() bizə future-ni görməyimizə imkan verir
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // bir neçə dəfə peek() edə bilərik, təkrarlayıcı irəliləməyəcək
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // iterator bitdikdən sonra peek() də başa çatır
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Bir predikat əsasında elementləri [`atla]] bir iterator yaradır.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` bağlamağı mübahisə olaraq qəbul edir.Bu bağlanmanı təkrarlayıcının hər bir elementinə çağıracaq və `false` qaytarana qədər elementləri görməməzlikdən gəlməyəcəkdir.
    ///
    /// `false` qaytarıldıqdan sonra `skip_while()`'s işi bitdi və qalan elementlər verildi.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `skip_while()`-ə ötürülən bağlanma bir istinad aldığından və bir çox təkrarlayıcılar istinadlar üzərində təkrarlandığından, bağlanma arqumentinin növünün ikiqat bir istinad olduğu ehtimal edilən qarışıq bir vəziyyətə gətirib çıxarır:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // iki * s lazımdır!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// İlkin `false`-dən sonra dayanma:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // bu yalan olardı, çünki yalnış aldığımız üçün skip_while() artıq istifadə olunmur
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Bir predikat əsasında elementlər verən bir iterator yaradır.
    ///
    /// `take_while()` bağlamağı mübahisə olaraq qəbul edir.Bu bağlanmanı təkrarlayıcının hər bir elementində adlandıracaq və `true` qaytararkən elementləri verəcəkdir.
    ///
    /// `false` qaytarıldıqdan sonra `take_while()`'s işi bitdi və qalan elementlər nəzərə alınmadı.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()`-ə ötürülən bağlanma bir istinad aldığından və bir çox təkrarlayıcılar istinadlar üzərində təkrarlandığından, bu bağlanma növünün ikiqat bir istinad olduğu ehtimal edilən qarışıq bir vəziyyətə səbəb olur:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // iki * s lazımdır!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// İlkin `false`-dən sonra dayanma:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Sıfırdan az olan daha çox elementimiz var, ancaq yalan olduğumuz üçün take_while() artıq istifadə edilmir
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()`-in daxil olub-olmamasını görmək üçün dəyərinə baxması lazım olduğundan, təkrarlayıcıları istehlak edənlər silindiyini görəcəklər:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` artıq orada deyil, çünki təkrarlamanın dayanıb dayanmayacağını görmək üçün istehlak edildi, ancaq təkrarlayıcıya yerləşdirilmədi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Hər iki predikat və xəritələrə əsaslanan elementlər verən bir iterator yaradır.
    ///
    /// `map_while()` bağlamağı mübahisə olaraq qəbul edir.
    /// Bu bağlanmanı təkrarlayıcının hər bir elementində adlandıracaq və [`Some(_)`][`Some`] qaytararkən elementləri verəcəkdir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Budur eyni nümunə, lakin [`take_while`] və [`map`] ilə:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// İlkin [`None`]-dən sonra dayanma:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // u32-ə (4, 5) sığa biləcək daha çox elementimiz var, lakin `map_while` `-3` üçün `None`-i qaytardı (`predicate` `None`-i döndüyü kimi) və ilk `None`-də `collect` dayanır.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// `map_while()`-in daxil olub-olmamasını görmək üçün dəyərə baxması lazım olduğundan, təkrarlayıcıları istehlak edənlər silindiyini görəcəklər:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` artıq orada deyil, çünki təkrarlamanın dayanıb dayanmayacağını görmək üçün istehlak edildi, ancaq təkrarlayıcıya yerləşdirilmədi.
    ///
    /// [`take_while`]-dən fərqli olaraq bu iteratorun ** əridilmədiyini unutmayın.
    /// İlk [`None`] qaytarıldıqdan sonra bu iteratorun nəyi qaytaracağı da göstərilməyib.
    /// Birləşdirilmiş iteratora ehtiyacınız varsa, [`fuse`] istifadə edin.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// İlk `n` elementlərini atlayan bir iterator yaradır.
    ///
    /// İstehlak edildikdən sonra, qalan elementlər verilir.
    /// Bu metodu birbaşa ləğv etmək əvəzinə `nth` metodunu ləğv edin.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// İlk `n` elementlərini verən bir iterator yaradır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` tez-tez sonlu etmək üçün sonsuz bir iterator ilə istifadə olunur:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `n`-dən az element varsa, `take` özünü əsas iteratorun ölçüsü ilə məhdudlaşdıracaq:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Daxili vəziyyəti saxlayan və yeni iterator istehsal edən [`fold`]-ə bənzər bir iterator adapteri.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` iki arqument götürür: daxili vəziyyəti toxumlayan ilkin dəyər və iki arqumentlə bağlanma, birincisi daxili vəziyyətə dəyişkən bir istinad, ikincisi təkrarlayıcı element.
    ///
    /// Bağlama təkrarlamalar arasında vəziyyəti bölüşmək üçün daxili vəziyyətə təyin edilə bilər.
    ///
    /// Yinelemede, bağlanma iteratorun hər bir elementinə tətbiq ediləcək və qapanmadan geri qaytarma dəyəri, bir [`Option`], iterator tərəfindən verilir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // hər təkrar, vəziyyəti elementə vuracağıq
    ///     *state = *state * x;
    ///
    ///     // o zaman dövlətin inkarını verəcəyik
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Xəritə kimi işləyən, lakin iç içə quruluşu düzəldən bir iterator yaradır.
    ///
    /// [`map`] adapteri çox faydalıdır, ancaq bağlanma arqumenti dəyərlər yaratdıqda.
    /// Bunun əvəzinə bir iterator istehsal edərsə, əlavə bir dolayı qat var.
    /// `flat_map()` bu əlavə təbəqəni təkbaşına qaldıracaq.
    ///
    /// `flat_map(f)`-i [`map`] ping-in semantik ekvivalenti, sonra da `map(f).flatten()`-dəki kimi [` düzəltmək] kimi düşünə bilərsiniz.
    ///
    /// `flat_map()` haqqında düşünməyin başqa bir yolu: [`map`] 'in bağlanması hər element üçün bir maddə, `flat_map()`'s bağlanması isə hər element üçün təkrarlayıcıdır.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iteratoru qaytarır
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// İç içə quruluşu düzləşdirən bir iterator yaradır.
    ///
    /// Bu təkrarlayıcı bir iterator və ya təkrarlayıcıya çevrilə bilən şeylərin təkrarlayıcısı olduqda və bir səviyyədə dolayı silmək istədiyiniz zaman faydalıdır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Xəritəçəkmə və sonra düzəltmə:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iteratoru qaytarır
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Bunu [`flat_map()`] baxımından da yenidən yaza bilərsiniz, bu halda niyyəti daha aydın ifadə etdiyi üçün üstünlük verilir:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() iteratoru qaytarır
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Düzəltmə hər dəfə yalnız bir yuvalama səviyyəsini aradan qaldırır:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Burada `flatten()`-in "deep" düzəldilməsini həyata keçirmədiyini görürük.
    /// Bunun əvəzinə, yalnız bir yuvalama səviyyəsi silinir.Yəni üç ölçülü bir sıra `flatten()` etsəniz, nəticə bir ölçülü deyil, iki ölçülü olacaqdır.
    /// Tək ölçülü bir quruluş əldə etmək üçün yenidən `flatten()` etməlisiniz.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// İlk [`None`]-dən sonra bitən bir iterator yaradır.
    ///
    /// Bir iterator [`None`] qaytardıqdan sonra future zəngləri yenidən [`Some(T)`] verə bilər və ya verməyəcəkdir.
    /// `fuse()` bir iteratoru uyğunlaşdırır və [`None`] verildikdən sonra daima [`None`]-ə dönəcəyini təmin edir.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // Bəziləri və Heç biri arasında dəyişən bir iterator
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // bərabərdirsə, Some(i32), başqa Yoxdur
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // iteratorumuzun irəli-geri getdiyini görə bilərik
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // Lakin, bir dəfə onu birləşdirdikdə ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ilk dəfə sonra həmişə `None` qaytaracaq.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Bir iteratorun hər bir elementi ilə dəyəri ötürərək bir şey edir.
    ///
    /// Təkrarlayıcılardan istifadə edərkən tez-tez onlardan bir neçəsini birləşdirirsiniz.
    /// Belə bir kod üzərində işləyərkən boru kəmərinin müxtəlif hissələrində nələrin baş verdiyini yoxlamaq istəyə bilərsiniz.Bunu etmək üçün `inspect()`-ə bir zəng daxil edin.
    ///
    /// `inspect()`-nin son kodunuzda mövcud olmaqdan daha çox, bir ayıklama vasitəsi olaraq istifadə edilməsi daha yaygındır, ancaq tətbiqlər səhvlər atılmadan əvvəl qeyd edilməli olduqda müəyyən vəziyyətlərdə faydalı ola bilər.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // bu iterator ardıcıllığı mürəkkəbdir.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // baş verənləri araşdırmaq üçün bəzi inspect() zəngləri əlavə edək
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Bu yazdıracaq:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Xətaları atmadan əvvəl qeyd etmə səhvləri:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Bu yazdıracaq:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Bir iteratoru istehlak etmək əvəzinə borc götürür.
    ///
    /// Hələ də orijinal iteratorun sahibliyini qoruyarkən iterator adapterlərinin tətbiqinə icazə vermək faydalıdır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // təkrar istifadə etməyə çalışsaq, nəticə verməyəcək.
    /// // Aşağıdakı sətirdə "səhv: köçürülmüş dəyərin istifadəsi" verilir. `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // gəlin bunu bir daha sınayaq
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // əvəzinə bir .by_ref() əlavə edirik
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // indi bu yaxşıdır:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Bir iteratoru kolleksiyaya çevirir.
    ///
    /// `collect()` təkrarlana bilən hər şeyi götürə bilər və müvafiq kolleksiyaya çevirə bilər.
    /// Bu, standart kitabxanada müxtəlif kontekstlərdə istifadə olunan daha güclü metodlardan biridir.
    ///
    /// `collect()`-in istifadə olunduğu ən əsas model bir kolleksiyanı digərinə çevirməkdir.
    /// Bir kolleksiya götürürsünüz, üzərində [`iter`]-i axtarırsınız, bir dəstə transformasiya edirsiniz, sonra da `collect()`.
    ///
    /// `collect()` tipik kolleksiyalar olmayan növ nümunələri də yarada bilər.
    /// Məsələn, bir [`String`] ['char`] s-dən inşa edilə bilər və [`Result<T, E>`][`Result`] maddələrinin təkrarlayıcısı `Result<Collection<T>, E>`-ə toplana bilər.
    ///
    /// Daha çox məlumat üçün aşağıdakı nümunələrə baxın.
    ///
    /// `collect()` çox ümumi olduğundan tip çıxarma ilə problem yarada bilər.
    /// Beləliklə, `collect()`, 'turbofish' olaraq sevilən sintaksisini görəcəyiniz bir neçə dəfə biridir: `::<>`.
    /// Bu, nəticə alqoritminin konkret olaraq hansı kolleksiyanı toplamağa çalışdığınızı anlamasına kömək edir.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Sol tərəfdəki `: Vec<i32>`-ə ehtiyacımız olduğunu unutmayın.Bunun əvəzinə, məsələn, bir [`VecDeque<T>`]-yə yığa bildiyimiz üçündir:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled`-yə izahat vermək əvəzinə 'turbofish'-dən istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` yalnız topladığınız şeylə maraqlandığından, turbofish ilə birlikdə qismən `_` tipli bir ipucu istifadə edə bilərsiniz:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// [`String`] etmək üçün `collect()` istifadə:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Bir siyahınız varsa [`Nəticə<T, E>`][` Nəticə '] lər, `collect()` istifadə edərək onlardan hər hansı birinin uğursuz olub olmadığını öyrənə bilərsiniz:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // bizə ilk səhvi verir
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // cavabların siyahısını bizə verir
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Bir iterator istehlak edir, ondan iki kolleksiya yaradır.
    ///
    /// `partition()`-ə verilən predikat `true` və ya `false`-i qaytara bilər.
    /// `partition()` `true`-i qaytardığı bütün elementləri və `false`-i qaytardığı bütün elementləri qaytarır.
    ///
    ///
    /// [`is_partitioned()`] və [`partition_in_place()`]-ə də baxın.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Bu iteratorun elementlərini *yerində* verilmiş predikata görə yenidən sıralayır ki, `true` qaytaranların hamısı `false` qaytaranların hamısından əvvəldir.
    ///
    /// Tapılan `true` elementlərinin sayını qaytarır.
    ///
    /// Bölünmüş maddələrin nisbi qaydası qorunmur.
    ///
    /// [`is_partitioned()`] və [`partition()`]-ə də baxın.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Eşlər və əmsallar arasında yerində bölünmə
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: sayın aşıb-daşmamasından narahat olmalıyıq?Daha çoxuna sahib olmağın yeganə yolu
        // `usize::MAX` dəyişdirilə bilən istinadlar bölmə üçün faydalı olmayan ZST-lərlədir ...

        // Bu bağlanma "factory" funksiyaları, `Self`-də cömertliyin qarşısını almaq üçün mövcuddur.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // İlk `false`-i dəfələrlə tapın və son `true` ilə dəyişdirin.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Bu iteratorun elementlərinin verilmiş predikata görə bölündüyünü yoxlayır, belə ki `true` qaytaranların hamısı `false` qaytaranların hamısından əvvəldir.
    ///
    ///
    /// [`partition()`] və [`partition_in_place()`]-ə də baxın.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Ya bütün maddələr `true` test edir, ya da birinci bənd `false`-də dayanır və bundan sonra `true` maddəsinin olmadığını yoxlayırıq.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Uğurla döndüyü müddətdə bir funksiyanı tətbiq edən tək və son bir dəyər yaradan təkrarlayıcı metod.
    ///
    /// `try_fold()` iki arqument tələb edir: ilkin dəyər və iki arqumentlə bağlanma: 'accumulator' və element.
    /// Bağlanma ya akkumulyatorun növbəti təkrarlama üçün sahib olması lazım olan dəyərlə ya müvəffəqiyyətlə geri dönər, ya da dərhal (short-circuiting) arayana yayılan bir səhv dəyəri ilə uğursuzluğu qaytarır.
    ///
    ///
    /// İlkin dəyər, akkumulyatorun ilk zəngdə əldə edəcəyi dəyərdir.Bağlamanın tətbiq edilməsi iteratorun hər bir elementinə qarşı uğurlu olduqda, `try_fold()` son akkumulyatoru uğur kimi qaytarır.
    ///
    /// Katlama, hər hansı bir şey topladığınız zaman faydalıdır və ondan tək bir dəyər çıxarmaq istəyirsiniz.
    ///
    /// # İcraçılara qeyd
    ///
    /// Digər (forward) metodlarından bir neçəsinin bu baxımdan standart tətbiqetmələri var, buna görə standart `for` loop tətbiqindən daha yaxşı bir şey edə biləcəyi təqdirdə bunu açıq şəkildə tətbiq etməyə çalışın.
    ///
    /// Xüsusilə, `try_fold()` çağırışının bu iteratorun meydana gəldiyi daxili hissələrdə olmasına çalışın.
    /// Birdən çox zəngə ehtiyac varsa, `?` operatoru akkumulyator dəyərini zəncirləmə üçün əlverişli ola bilər, lakin bu erkən qaytarılmadan əvvəl dəstəklənməsi lazım olan hər hansı bir dəyişməzdən ehtiyat edin.
    /// Bu bir `&mut self` metodudur, buna görə də burada bir səhv olduqdan sonra təkrarlanmanın davam etdirilməsi lazımdır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // massivin bütün elementlərinin yoxlanılan cəmi
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // 100 cəmi əlavə edilərkən bu cəm axır
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Qısa qapalı olduğundan, qalan elementlər hələ də təkrarlayıcı vasitəsilə mövcuddur.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Yineleyicidəki hər bir maddəyə səhv bir funksiya tətbiq edən, ilk səhvdə dayanan və bu xətanı qaytaran bir iterator metodu.
    ///
    ///
    /// Bunu [`for_each()`]-in səhv forması və ya [`try_fold()`]-in vətəndaşlığı olmayan versiyası kimi də düşünmək olar.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Qısa qapanmış, buna görə qalan maddələr hələ də təkrarlayıcıda:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Bir əməliyyatı tətbiq edərək, son nəticəni qaytararaq hər elementi akkumulyatora qatlayır.
    ///
    /// `fold()` iki arqument tələb edir: ilkin dəyər və iki arqumentlə bağlanma: 'accumulator' və element.
    /// Bağlama, akkumulyatorun növbəti təkrarlanması üçün lazım olan dəyəri qaytarır.
    ///
    /// İlkin dəyər, akkumulyatorun ilk zəngdə əldə edəcəyi dəyərdir.
    ///
    /// Bu bağlanmanı iteratorun hər bir elementinə tətbiq etdikdən sonra `fold()` akkumulyatoru qaytarır.
    ///
    /// Bu əməliyyata bəzən 'reduce' və ya 'inject' də deyilir.
    ///
    /// Katlama, hər hansı bir şey topladığınız zaman faydalıdır və ondan tək bir dəyər çıxarmaq istəyirsiniz.
    ///
    /// Note: `fold()` və bütün təkrarlayıcıdan keçən oxşar metodlar, nəticənin sonlu müddətdə təyin olunduğu traits-də də sonsuz təkrarlayıcılar üçün sona çatmaya bilər.
    ///
    /// Note: Akkumulyator növü və maddə növü eynidirsə, ilk elementi ilkin dəyər kimi istifadə etmək üçün [`reduce()`] istifadə edilə bilər.
    ///
    /// # İcraçılara qeyd
    ///
    /// Digər (forward) metodlarından bir neçəsinin bu baxımdan standart tətbiqetmələri var, buna görə standart `for` loop tətbiqindən daha yaxşı bir şey edə biləcəyi təqdirdə bunu açıq şəkildə tətbiq etməyə çalışın.
    ///
    ///
    /// Xüsusilə, `fold()` çağırışının bu iteratorun meydana gəldiyi daxili hissələrdə olmasına çalışın.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // massivin bütün elementlərinin cəmi
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Buradakı təkrarlamanın hər addımından keçək:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Beləliklə, son nəticəmiz, `6`.
    ///
    /// Təkrarlayıcıları çox istifadə etməyən insanların bir nəticə əldə etmək üçün bir şey siyahısı ilə bir `for` döngəsindən istifadə etməsi adi haldır.Bunlar `fold()`s-ə çevrilə bilər:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // loop üçün:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // eynidirlər
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Bir neçə dəfə bir azaltma əməliyyatı tətbiq edərək elementləri tək birinə endirir.
    ///
    /// Təkrarlayıcı boşdursa, [`None`] qaytarır;əks halda, azalmanın nəticəsini qaytarır.
    ///
    /// Ən azı bir elementi olan təkrarlayıcılar üçün bu, hər bir sonrakı elementi qatlayaraq, başlanğıc dəyəri kimi iteratorun ilk elementi ilə [`fold()`] ilə eynidir.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Maksimum dəyəri tapın:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// İteratorun hər bir elementi bir predikatla uyğunlaşdığını yoxlayır.
    ///
    /// `all()` `true` və ya `false` qaytaran bir bağlanma alır.Bu bağlanmanı iteratorun hər bir elementinə tətbiq edir və hamısı `true`-yə qayıdırsa, o zaman `all()` də olur.
    /// Onlardan hər hansı biri `false` qaytararsa, `false` qaytarar.
    ///
    /// `all()` qısa qapanma;başqa sözlə, başqa bir şey olmasına baxmayaraq nəticənin `false` olacağını nəzərə alsaq, bir `false` tapan kimi işləmə dayandıracaq.
    ///
    ///
    /// Boş bir iterator `true` qaytarır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// İlk `false`-də dayanma:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // daha çox element olduğu üçün hələ də `iter` istifadə edə bilərik.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// İteratorun hər hansı bir elementinin bir predikatla uyğunlaşdığını yoxlayır.
    ///
    /// `any()` `true` və ya `false` qaytaran bir bağlanma alır.Bu bağlanmanı iteratorun hər bir elementinə tətbiq edir və onlardan hər hansı biri `true`-yə qayıdırsa, o zaman `any()` də olur.
    /// Hamısı `false` qaytararsa, `false` qaytarar.
    ///
    /// `any()` qısa qapanma;başqa sözlə, başqa bir şey olmasına baxmayaraq nəticənin `true` olacağını nəzərə alsaq, bir `true` tapan kimi işləmə dayandıracaq.
    ///
    ///
    /// Boş bir iterator `false` qaytarır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// İlk `true`-də dayanma:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // daha çox element olduğu üçün hələ də `iter` istifadə edə bilərik.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Bir predikat təmin edən bir iteratorun elementini axtarır.
    ///
    /// `find()` `true` və ya `false` qaytaran bir bağlanma alır.
    /// Bu bağlanmanı iteratorun hər bir elementinə tətbiq edir və bunlardan hər hansı biri `true`-yə qayıdırsa, `find()` [`Some(element)`]-i qaytarır.
    /// Hamısı `false` qaytararsa, [`None`] qaytarar.
    ///
    /// `find()` qısa qapanma;başqa sözlə, bağlanma `true`-yə qayıdan kimi emalını dayandıracaq.
    ///
    /// `find()` bir istinad aldığından və bir çox təkrarlayıcılar istinadlar üzərində təkrarladığından, bu mübahisənin ikiqat bir istinad olduğu ehtimal edilən qarışıq bir vəziyyətə gətirib çıxarır.
    ///
    /// Bu təsiri `&&x` ilə aşağıdakı nümunələrdə görə bilərsiniz.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// İlk `true`-də dayanma:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // daha çox element olduğu üçün hələ də `iter` istifadə edə bilərik.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// `iter.find(f)`-in `iter.filter(f).next()`-ə bərabər olduğunu unutmayın.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Fəaliyyəti təkrarlayıcı elementlərinə tətbiq edir və ilk olmayan nəticəni qaytarır.
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()`-ə bərabərdir.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Təkrarlayıcı elementlərinə funksiyanı tətbiq edir və ilk həqiqi nəticəni və ya ilk səhvi qaytarır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Bir iteratorda bir element axtarır, indeksini qaytarır.
    ///
    /// `position()` `true` və ya `false` qaytaran bir bağlanma alır.
    /// Bu bağlanmanı iteratorun hər bir elementinə tətbiq edir və onlardan biri `true` qaytararsa, `position()` [`Some(index)`] qaytarır.
    /// Hamısı `false` qaytararsa, [`None`] qaytarar.
    ///
    /// `position()` qısa qapanma;başqa sözlə, bir `true` tapan kimi emalını dayandıracaq.
    ///
    /// # Daşqın davranışı
    ///
    /// Metod daşqınlara qarşı heç bir qorunma yaratmır, buna görə [`usize::MAX`]-dən çox uyğun olmayan element varsa, ya səhv nəticə verir, ya da panics.
    ///
    /// Hata düzəltmə iddiaları aktivdirsə, panic-yə zəmanət verilir.
    ///
    /// # Panics
    ///
    /// Təkrarlayıcıda `usize::MAX`-dən çox uyğun olmayan element varsa, bu funksiya panic ola bilər.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// İlk `true`-də dayanma:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // daha çox element olduğu üçün hələ də `iter` istifadə edə bilərik.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Geri qaytarılan indeks iterator vəziyyətindən asılıdır
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Sağdan iteratorda bir element axtarır, indeksini qaytarır.
    ///
    /// `rposition()` `true` və ya `false` qaytaran bir bağlanma alır.
    /// Bu bağlanmanı sondan başlayaraq iteratorun hər bir elementinə tətbiq edir və onlardan biri `true` qaytararsa, `rposition()` [`Some(index)`] qaytarır.
    ///
    /// Hamısı `false` qaytararsa, [`None`] qaytarar.
    ///
    /// `rposition()` qısa qapanma;başqa sözlə, bir `true` tapan kimi emalını dayandıracaq.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// İlk `true`-də dayanma:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // daha çox element olduğu üçün hələ də `iter` istifadə edə bilərik.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Burada daşqın yoxlamasına ehtiyac yoxdur, çünki `ExactSizeIterator` element sayının `usize`-ə uyğun olduğunu nəzərdə tutur.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Bir iteratorun maksimum elementini qaytarır.
    ///
    /// Bir neçə element eyni dərəcədə maksimumdursa, son element qaytarılır.
    /// Təkrarlayıcı boşdursa, [`None`] qaytarılır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Bir iteratorun minimum elementini qaytarır.
    ///
    /// Bir neçə element eyni dərəcədə minimumdursa, ilk element qaytarılır.
    /// Təkrarlayıcı boşdursa, [`None`] qaytarılır.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Müəyyən edilmiş funksiyadan maksimum dəyər verən elementi qaytarır.
    ///
    ///
    /// Bir neçə element eyni dərəcədə maksimumdursa, son element qaytarılır.
    /// Təkrarlayıcı boşdursa, [`None`] qaytarılır.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Göstərilən müqayisə funksiyasına görə maksimum dəyər verən elementi qaytarır.
    ///
    ///
    /// Bir neçə element eyni dərəcədə maksimumdursa, son element qaytarılır.
    /// Təkrarlayıcı boşdursa, [`None`] qaytarılır.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Göstərilən funksiyadan minimum dəyər verən elementi qaytarır.
    ///
    ///
    /// Bir neçə element eyni dərəcədə minimumdursa, ilk element qaytarılır.
    /// Təkrarlayıcı boşdursa, [`None`] qaytarılır.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Müəyyən edilmiş müqayisə funksiyasına görə minimum dəyər verən elementi qaytarır.
    ///
    ///
    /// Bir neçə element eyni dərəcədə minimumdursa, ilk element qaytarılır.
    /// Təkrarlayıcı boşdursa, [`None`] qaytarılır.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Bir iteratorun istiqamətini dəyişdirir.
    ///
    /// Ümumiyyətlə, təkrarlayıcılar soldan sağa təkrarlanır.
    /// `rev()` istifadə etdikdən sonra bir iterator əvəzinə sağdan sola təkrarlayır.
    ///
    /// Bu yalnız təkrarlayıcının bir sonu olduğu təqdirdə mümkündür, buna görə `rev()` yalnız [`DoubleEndedIterator`] s-də işləyir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Bir cüt iteratoru bir cüt qaba çevirir.
    ///
    /// `unzip()` iki koleksiyon istehsal edən bütün cüt təkrarlayıcıları istehlak edir: biri cütlərin sol elementlərindən, digəri isə sağ elementlərdən.
    ///
    ///
    /// Bu funksiya müəyyən mənada [`zip`]-in əksidir.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Bütün elementlərini kopyalayan bir iterator yaradır.
    ///
    /// Bu, `&T`-dən çox bir iterator olduğunda faydalıdır, ancaq `T`-dən çox bir iterator lazımdır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopyalanan .map(|&x| x) ilə eynidir
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Bütün elementlərini ["klonlaşdıran"] bir iterator yaradır.
    ///
    /// Bu, `&T`-dən çox bir iterator olduğunda faydalıdır, ancaq `T`-dən çox bir iterator lazımdır.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // klonlaşdırılmış, tam ədədlər üçün .map(|&x| x) ilə eynidir
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Bir iteratoru sonsuzca təkrarlayır.
    ///
    /// [`None`]-də dayanmaq əvəzinə təkrarlayıcı əvvəldən yenidən başlayacaq.Yenidən təkrarlandıqdan sonra yenidən başlanğıcda başlayacaq.Və yenidən.
    /// Və yenidən.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Bir iteratorun elementlərini cəmləşdirir.
    ///
    /// Hər bir elementi götürür, onları bir-birinə əlavə edir və nəticəni qaytarır.
    ///
    /// Boş bir iterator növün sıfır dəyərini qaytarır.
    ///
    /// # Panics
    ///
    /// `sum()` çağırıldıqda və ibtidai bir tamsayı növü qaytarılır, hesablama daşqınları və debaq iddiaları aktivləşdirildikdə bu metod panic olacaqdır.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Bütün iterator üzərində təkrarlanır, bütün elementləri vurur
    ///
    /// Boş bir iterator növün bir dəyərini qaytarır.
    ///
    /// # Panics
    ///
    /// `product()` çağırıldıqda və ibtidai bir tamsayı növü qaytarılır, hesablama daşqınları və debaq iddiaları aktivləşdirildikdə metod panic olacaqdır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) bu [`Iterator`] elementlərini başqası ilə müqayisə edir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) göstərilən müqayisə funksiyasına görə bu [`Iterator`] elementlərini digərləri ilə müqayisə edir.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) bu [`Iterator`] elementlərini başqası ilə müqayisə edir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) göstərilən müqayisə funksiyasına görə bu [`Iterator`] elementlərini digərləri ilə müqayisə edir.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Bu [`Iterator`] elementlərinin başqasının elementlərinə bərabər olub olmadığını müəyyənləşdirir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Göstərilən bərabərlik funksiyasına görə bu [`Iterator`] elementlərinin başqalarına bərabər olub olmadığını müəyyənləşdirir.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Bu [`Iterator`] elementlərinin başqasının elementlərinə bərabər olmadığını müəyyənləşdirir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Bu [`Iterator`] elementlərinin başqalarından [lexicographically](Ord#lexicographical-comparison) az olub olmadığını təyin edir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Bu [`Iterator`] elementlərinin [lexicographically](Ord#lexicographical-comparison) az və ya digərinə bərabər olduğunu təyin edir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Bu [`Iterator`] elementlərinin başqalarından [lexicographically](Ord#lexicographical-comparison) çox olduğunu müəyyənləşdirir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Bu [`Iterator`]-in elementlərinin [lexicographically](Ord#lexicographical-comparison)-in digərindən daha çox və ya bərabər olduğunu müəyyənləşdirir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Bu iteratorun elementlərinin çeşidləndiyini yoxlayır.
    ///
    /// Yəni hər bir `a` elementi və aşağıdakı `b` elementi üçün `a <= b` olmalıdır.Təkrarlayıcı tam sıfır və ya bir element verirsə, `true` qaytarılır.
    ///
    /// Qeyd edək ki, `Self::Item` yalnız `PartialOrd`-dirsə, `Ord` deyilsə, yuxarıdakı tərif, ardıcıl iki maddə müqayisə olunmazsa, bu funksiyanın `false`-yə döndüyünü nəzərdə tutur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Verilən müqayisə funksiyasından istifadə edərək bu iteratorun elementlərinin çeşidləndiyini yoxlayır.
    ///
    /// `PartialOrd::partial_cmp` istifadə etmək əvəzinə, bu funksiya iki elementin sıralanmasını təyin etmək üçün verilən `compare` funksiyasından istifadə edir.
    /// Bunun xaricində [`is_sorted`]-ə bərabərdir;daha çox məlumat üçün sənədlərinə baxın.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Verilən açar çıxarma funksiyasından istifadə edərək bu iteratorun elementlərinin çeşidləndiyini yoxlayır.
    ///
    /// İteratorun elementlərini birbaşa müqayisə etmək əvəzinə, bu funksiya `f` tərəfindən təyin olunduğu kimi elementlərin düymələrini müqayisə edir.
    /// Bunun xaricində [`is_sorted`]-ə bərabərdir;daha çox məlumat üçün sənədlərinə baxın.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess]-ə baxın
    // Qeyri-adi ad, metod həllində ad toqquşmalarının qarşısını almaqdır, bax #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}