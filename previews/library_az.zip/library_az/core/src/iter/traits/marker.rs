/// Hər zaman tükənəndə `None` verməyə davam edən bir iterator.
///
/// `None`-i bir dəfə qaytaran əridilmiş bir iteratorun yanına zəng etmək, yenidən [`None`]-ə qayıtmaq üçün təmin edilir.
/// Bu trait, bu şəkildə davranan bütün təkrarlayıcılar tərəfindən həyata keçirilməlidir, çünki [`Iterator::fuse()`]-i optimallaşdırmağa imkan verir.
///
///
/// Note: Ümumiyyətlə, əridilmiş bir iteratora ehtiyacınız varsa, `FusedIterator`-i ümumi sərhədlərdə istifadə etməməlisiniz.
/// Bunun əvəzinə təkrarlayıcıda [`Iterator::fuse()`]-yə zəng vurmalısınız.
/// Təkrarlayıcı artıq əridilibsə, əlavə [`Fuse`] bükücü heç bir performans cəzası verilməyən bir seçim olacaq.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Size_hint istifadə edərək dəqiq bir uzunluğu bildirən bir iterator.
///
/// Yineleyicinin ya dəqiq olduğu (aşağı sərhəd yuxarı sərhədə bərabərdir), ya da yuxarı sərhədin [`None`] olduğu bir ölçü işarəsi verilir.
///
/// Üst sərhəd yalnız faktiki iterator uzunluğu [`usize::MAX`]-dən böyük olduqda [`None`] olmalıdır.
/// Bu vəziyyətdə alt sərhəd [`usize::MAX`] olmalıdır, nəticədə X002 X 00X olur.
///
/// İterator, sona çatmadan bildirdiyi elementlərin tam sayını istehsal etməli və ya ayrılmalıdır.
///
/// # Safety
///
/// Bu trait yalnız müqavilə təmin edildikdə həyata keçirilməlidir.
/// Bu trait istehlakçıları [`Iterator::size_hint()`]’s yuxarı sərhədini yoxlamalıdırlar.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Bir maddə verilərkən əsas [`SourceIter`]-dən ən azı bir element götürmüş bir iterator.
///
/// İteratoru inkişaf etdirən istənilən metodu çağırmaq, məsələn
/// [`next()`] və ya [`try_fold()`], hər addım üçün təkrarlayıcının əsas mənbəyinin ən azı bir dəyərinin köçürüldüyünə və mənbənin struktur məhdudiyyətlərinin belə bir girişə imkan verdiyini düşünərək təkrarlayıcı zəncirinin nəticəsinin yerinə yerləşdirilə biləcəyinə zəmanət verir.
///
/// Başqa sözlə, bu trait təkrarlayıcı boru kəmərinin yerində toplana biləcəyini göstərir.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}