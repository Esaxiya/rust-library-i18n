/// Uzunluğunu dəqiq bilən bir iterator.
///
/// Bir çox [təkrarlayıcı] neçə dəfə təkrarlayacaqlarını bilmir, bəziləri də bilir.
/// Bir iterator neçə dəfə təkrarlaya biləcəyini bilirsə, bu məlumatlara girişin təmin edilməsi faydalı ola bilər.
/// Məsələn, geriyə doğru təkrarlamaq istəyirsinizsə, yaxşı bir başlanğıc sonun harada olduğunu bilməkdir.
///
/// `ExactSizeIterator` tətbiq edərkən [`Iterator`] tətbiq etməlisiniz.
/// Bunu edərkən, [`Iterator::size_hint`]*tətbiqi* təkrarlayıcı ölçüsünü dəqiq şəkildə qaytarmalıdır.
///
/// [`len`] metodunun varsayılan bir tətbiqi var, buna görə ümumiyyətlə tətbiq etməməlisiniz.
/// Bununla birlikdə, varsayılan göstəricidən daha çox performanslı bir tətbiq təmin edə bilərsiniz, buna görə bu vəziyyətdə onu əvəz etmək mantiqidir.
///
///
/// Qeyd edək ki, bu trait etibarlı bir trait olduğundan geri qaytarılmış uzunluğun doğruluğuna *zəmanət vermir* və * təmin edə bilməz.
/// Bu o deməkdir ki, `unsafe` kodu ** [`Iterator::size_hint`]-nin düzgünlüyünə etibar etməməlidir.
/// Qeyri-sabit və təhlükəli [`TrustedLen`](super::marker::TrustedLen) trait bu əlavə zəmanəti verir.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// // sonlu bir sıra neçə dəfə təkrarlanacağını dəqiq bilir
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs]-də bir [`Iterator`] tətbiq etdik, `Counter`.
/// Bunun üçün `ExactSizeIterator` tətbiq edək:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Qalan təkrar sayını asanlıqla hesablaya bilərik.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // İndi də istifadə edə bilərik!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// İteratorun dəqiq uzunluğunu qaytarır.
    ///
    /// Tətbiq, iteratorun [`None`]-i qaytarmadan əvvəl [`Some(T)`] dəyərindən `len()`-dən daha çox qayıtmasını təmin edir.
    ///
    /// Bu metodun varsayılan bir tətbiqi var, buna görə ümumiyyətlə birbaşa tətbiq etməməlisiniz.
    /// Ancaq daha səmərəli bir tətbiq təmin edə bilsəniz, bunu edə bilərsiniz.
    /// Bir nümunə üçün [trait-level] sənədlərinə baxın.
    ///
    /// Bu funksiya, [`Iterator::size_hint`] funksiyası ilə eyni təhlükəsizlik zəmanətlərinə malikdir.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// // sonlu bir sıra neçə dəfə təkrarlanacağını dəqiq bilir
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Bu iddia həddindən artıq müdafiəlidir, lakin dəyişməzliyi yoxlayır
        // trait tərəfindən zəmanət verilir.
        // Bu trait rust daxili olsaydı, debug_assert istifadə edə bilərik !;assert_eq!bütün Rust istifadəçi tətbiqlərini də yoxlayacaq.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// İterator boş olduqda `true` qaytarır.
    ///
    /// Bu metod [`ExactSizeIterator::len()`] istifadə edərək standart bir tətbiqə sahibdir, buna görə özünüz tətbiq etməyinizə ehtiyac yoxdur.
    ///
    ///
    /// # Examples
    ///
    /// Əsas istifadə:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}