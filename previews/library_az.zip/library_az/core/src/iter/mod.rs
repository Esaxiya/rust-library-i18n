//! Birləşən xarici təkrarlama.
//!
//! Əgər özünüzü bir növ kolleksiya ilə qarşıladıysanız və bu kolleksiyanın elementləri üzərində bir əməliyyat yerinə yetirmək üçün ehtiyacınız varsa, tez bir zamanda 'iterators'-ə girəcəksiniz.
//! Təkrarlayıcılar idiomatik Rust kodunda çox istifadə olunur, buna görə onlarla tanış olmağa dəyər.
//!
//! Daha çox izah etməzdən əvvəl bu modulun necə qurulduğu barədə danışaq:
//!
//! # Organization
//!
//! Bu modul əsasən növə görə təşkil edilmişdir:
//!
//! * [Traits] əsas hissə bunlardır: bu traits, hansı növ təkrarlayıcıların mövcud olduğunu və onlarla nə edə biləcəyinizi müəyyənləşdirir.Bu traits metodları əlavə iş vaxtı sərf etməyə dəyər.
//! * [Functions] bəzi əsas iteratorlar yaratmaq üçün faydalı yollar təqdim edin.
//! * [Structs] tez-tez bu modulun traits-dəki müxtəlif metodların qaytarma növləri olur.Ümumiyyətlə `struct`-nin özünə deyil, `struct`-i yaradan metoda baxmaq istəyəcəksiniz.
//! Səbəbi haqqında daha ətraflı məlumat üçün '[Tətbiqedici İterator](#həyata keçirici-iterator)' a baxın.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Bu belədir!Gəlin təkrarlayıcıları araşdıraq.
//!
//! # Iterator
//!
//! Bu modulun ürəyi və ruhu [`Iterator`] trait-dir.[`Iterator`] nüvəsi belə görünür:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Bir təkrarlayıcının [`next`] metodu var, çağırıldığı zaman bir ['Seçim'] 'qaytarır<Item>".
//! [`next`] elementlər olduğu müddətdə [`Some(Item)`]-i qaytaracaq və hamısı bitdikdən sonra təkrarlamanın bitdiyini bildirmək üçün `None`-i qaytaracaqdır.
//! Ayrı-ayrı təkrarlayıcılar təkrarlamaya davam etməyi seçə bilər və buna görə yenidən [`next`]-i axtararaq bir nöqtədə yenidən [`Some(Item)`]-ə dönməyə başlaya bilər və ya başlamaya bilər (məsələn, bax [`TryIter`]).
//!
//!
//! [`Iterator`]-ın tam tərifi bir sıra digər metodları da əhatə edir, lakin bunlar [`next`]-in üstündə qurulmuş standart metodlardır və beləliklə onları pulsuz əldə edirsiniz.
//!
//! Təkrarlayıcılar da bəstələnə biləndir və daha mürəkkəb emal formaları etmək üçün onları bir-birinə bağlamaq adi haldır.Daha ətraflı məlumat üçün aşağıdakı [Adapters](#adapters) hissəsinə baxın.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Təkrarlamanın üç forması
//!
//! Bir kolleksiyadan təkrarlayıcılar yarada biləcək üç ümumi metod var:
//!
//! * `iter()`, bu, `&T` üzərində təkrarlanır.
//! * `iter_mut()`, bu, `&mut T` üzərində təkrarlanır.
//! * `into_iter()`, bu, `T` üzərində təkrarlanır.
//!
//! Standart kitabxanadakı müxtəlif şeylər, uyğun olduğu yerlərdə üçündən birini və ya bir neçəsini tətbiq edə bilər.
//!
//! # İteratorun tətbiqi
//!
//! Özünüzə məxsus bir təkrarlayıcı yaratmaq iki mərhələdən ibarətdir: təkrarlayıcı vəziyyətini saxlamaq üçün bir `struct` yaratmaq və sonra o `struct` üçün [`Iterator`] tətbiq etmək.
//! Bu səbəbdən bu modulda bir çox `struct` var: hər iterator və iterator adapter üçün bir var.
//!
//! `1`-dən `5`-ə qədər sayan `Counter` adlı bir iterator edək:
//!
//! ```
//! // Birincisi, struktur:
//!
//! /// Birdən beşə qədər sayan bir iterator
//! struct Counter {
//!     count: usize,
//! }
//!
//! // saymamızın birdən başlamasını istəyirik, buna görə kömək üçün bir new() metodu əlavə edək.
//! // Bu qətiliklə lazım deyil, ancaq əlverişlidir.
//! // `count`-i sıfırdan başladığımızı nəzərə alsaq, bunun səbəbini aşağıda `next()`'s tətbiqində görəcəyik.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Sonra `Counter` üçün `Iterator` tətbiq edirik:
//!
//! impl Iterator for Counter {
//!     // usize ilə hesablayacağıq
//!     type Item = usize;
//!
//!     // next() yeganə tələb olunan metoddur
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Sayımızı artırın.Buna görə sıfırdan başladıq.
//!         self.count += 1;
//!
//!         // Saymağı bitirib bitmədiyimizi yoxlayın.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // İndi də istifadə edə bilərik!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! [`next`]-ə bu şəkildə zəng etmək təkrarlanır.Rust, `None`-ə çatana qədər təkrarlayıcınızda [`next`] zəng edə bilən bir konstruksiyaya malikdir.Gəlin bundan sonra gedək.
//!
//! `Iterator`-in `next`-i daxili çağıran `nth` və `fold` kimi metodların standart tətbiqini təmin etdiyini də unutmayın.
//! Bununla birlikdə, bir iterator `next`-ə zəng etmədən onları daha səmərəli hesablaya bilsə, `nth` və `fold` kimi metodların xüsusi tətbiqini yazmaq da mümkündür.
//!
//! # `for` ilmələr və `IntoIterator`
//!
//! Rust-in `for` loop sintaksisi, təkrarlayıcılar üçün əslində şəkərdir.Budur `for`-in əsas nümunəsi:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Bu, hər biri öz xəttində birdən beşə qədər olan rəqəmləri çap edəcəkdir.Ancaq burada bir şey görəcəksən: heç vaxt vector-da bir iterator istehsal etmək üçün heç bir şey çağırmamışıq.Nə verir?
//!
//! Standart kitabxanada bir şeyin iteratora çevrilməsi üçün bir trait var: [`IntoIterator`].
//! Bu trait, [`IntoIterator`] tətbiq edən şeyi təkrarlayıcıya çevirən [`into_iter`] metoduna malikdir.
//! Yenidən həmin `for` döngəsinə və tərtibçinin onu nəyə çevirdiyini nəzərdən keçirək:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust şəkərsizləşdirir:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Əvvəlcə dəyər üzərində `into_iter()` çağırırıq.Sonra, bir `None` görənə qədər dəfələrlə [`next`] çağıraraq geri dönən təkrarlayıcıda uyğunlaşırıq.
//! O nöqtədə biz `break`-lərdən çıxdıq və təkrarlama işini bitirdik.
//!
//! Burada daha bir incə məqam var: standart kitabxana maraqlı bir [`IntoIterator`] tətbiqini ehtiva edir:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Başqa sözlə, bütün [`Iterator`] [`IntoIterator`]-i yalnız özlərini qaytarmaqla tətbiq edirlər.Bu, iki şey deməkdir:
//!
//! 1. Bir [`Iterator`] yazırsınızsa, onu `for` döngəsi ilə istifadə edə bilərsiniz.
//! 2. Bir kolleksiya yaradırsınızsa, bunun üçün [`IntoIterator`] tətbiq etmək, kolleksiyanızın `for` dövrü ilə istifadə olunmasına imkan verəcəkdir.
//!
//! # İstinadla təkrarlanır
//!
//! [`into_iter()`] `self`-i dəyərinə görə götürdüyündən, bir koleksiyon üzərində təkrarlamaq üçün `for` döngəsindən istifadə edərək həmin kolleksiyanı istehlak edir.Çox vaxt, bir kolleksiyanı istehlak etmədən təkrarlamaq istəyə bilərsiniz.
//! Bir çox kolleksiyada şərti olaraq `iter()` və `iter_mut()` adlanan istinadlar üzərində təkrarlayıcıları təmin edən metodlar təklif olunur:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` hələ də bu funksiyaya məxsusdur.
//! ```
//!
//! `C` bir kolleksiya növü `iter()` təmin edərsə, ümumiyyətlə `&C` üçün `IntoIterator` tətbiq edir və yalnız `iter()` çağıran bir tətbiq ilə.
//! Eynilə, `iter_mut()` təmin edən bir `C` kolleksiyası ümumiyyətlə `iter_mut()`-yə səlahiyyət verərək `&mut C` üçün `IntoIterator` tətbiq edir.Bu, əlverişli bir stenoqra imkan verir:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // `values.iter_mut()` ilə eyni
//!     *x += 1;
//! }
//! for x in &values { // `values.iter()` ilə eyni
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Bir çox kolleksiya `iter()` təklif etsə də, hamısı `iter_mut()` təklif etmir.
//! Məsələn, bir [`HashSet<T>`] və ya [`HashMap<K, V>`] düymələrinin mutasiyası, açar boşluqları dəyişərsə, kolleksiyanı uyğunsuz bir vəziyyətə gətirə bilər, buna görə bu kolleksiyalar yalnız `iter()` təklif edir.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Bir [`Iterator`] götürüb başqa bir [`Iterator`] qaytaran funksiyalara 'adapterin bir forması olduğu üçün tez-tez' iterator adapterləri 'deyilir.
//! pattern'.
//!
//! Ümumi iterator adapterlərinə [`map`], [`take`] və [`filter`] daxildir.
//! Daha çox məlumat üçün sənədlərinə baxın.
//!
//! Bir iterator adapteri panics olarsa, iterator dəqiqləşdirilməmiş (lakin yaddaş təhlükəsiz) vəziyyətdə olacaqdır.
//! Bu vəziyyətin Rust versiyaları ilə eyni qalması da zəmanət verilmir, buna görə panerator olan bir iterator tərəfindən qaytarılmış dəqiq dəyərlərə etibar etməməlisiniz.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Təkrarlayıcılar (və [adapters](#adapters)) iteratoru *tənbəldir*. Bu o deməkdir ki, təkrarlayıcı yaratmaq çox _do_ etmir. [`next`]-yə zəng vurana qədər heç bir şey olmur.
//! Yalnız bəzən yan təsirləri üçün bir iterator yaratarkən bəzən qarışıqlıq mənbəyidir.
//! Məsələn, [`map`] metodu, təkrarladığı hər bir elementə bir bağlanma çağırır:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Bunu istifadə etmək əvəzinə yalnız bir təkrarlayıcı yaratdığımız üçün bu heç bir dəyər yazdırmayacaq.Tərtibçi bu cür davranışlar barədə bizi xəbərdar edəcək:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Yan təsirləri üçün [`map`] yazmağın idiomatik yolu, `for` döngəsindən istifadə etmək və ya [`for_each`] metodunu çağırmaqdır:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Bir iteratoru qiymətləndirməyin başqa bir ümumi yolu, yeni bir kolleksiya istehsal etmək üçün [`collect`] metodundan istifadə etməkdir.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Təkrarlayıcıların sonlu olmasına ehtiyac yoxdur.Nümunə olaraq, açıq uclu bir sıra sonsuz iteratordur:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Sonsuz iteratoru sonluya çevirmək üçün [`take`] iterator adapterindən istifadə etmək çox yaygındır:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Bu, `0`-dən `4`-ə qədər olan rəqəmləri hər biri öz xəttində çap edəcəkdir.
//!
//! Unutmayın ki, sonsuz təkrarlayıcılardakı metodlar, nəticədə sonlu bir müddətdə riyazi olaraq təyin edilə bilənlər belə sona çatmayacaq.
//! Konkret olaraq, ümumiyyətlə iteratordakı hər elementi keçməyi tələb edən [`min`] kimi metodlar, sonsuz təkrarlayıcılar üçün uğurla qayıtmayacaqdır.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh yox!Sonsuz bir döngə!
//! // `ones.min()` sonsuz bir döngəyə səbəb olur, buna görə bu nöqtəyə çatmayacağıq!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;