use crate::fmt;

/// Hər təkrarlamanın təmin edilmiş `F: FnMut() -> Option<T>` bağlanmasını çağırdığı yeni bir iterator yaradır.
///
/// Bu, xüsusi bir növ yaratmaq və bunun üçün [`Iterator`] trait tətbiq etmək üçün daha geniş sintaksis istifadə etmədən hər hansı bir davranışla xüsusi bir iterator yaratmağa imkan verir.
///
/// `FromFn` təkrarlayıcısının bağlanma davranışı ilə bağlı fərziyyələr irəli sürmədiyini və buna görə mühafizəkar olaraq [`FusedIterator`] tətbiq etmədiyini və ya [`Iterator::size_hint()`]-i standart `(0, None)`-dən ləğv etdiyini unutmayın.
///
///
/// Bağlama, təkrarlamalardakı vəziyyəti izləmək üçün çəkmələrdən və ətraf mühitdən istifadə edə bilər.İteratorun necə istifadə edildiyinə görə, bunun bağlanması barədə [`move`] açar sözünün göstərilməsi tələb oluna bilər.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// [module-level documentation]-dən sayğac yineleyicisini yenidən tətbiq edək:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Sayımızı artırın.Buna görə sıfırdan başladıq.
///     count += 1;
///
///     // Saymağı bitirib bitmədiyimizi yoxlayın.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Hər təkrarlamanın təmin edilmiş bağlanmanı `F: FnMut() -> Option<T>` adlandırdığı bir iterator.
///
/// Bu `struct`, [`iter::from_fn()`] funksiyası tərəfindən yaradılmışdır.
/// Daha çox məlumat üçün sənədlərinə baxın.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}