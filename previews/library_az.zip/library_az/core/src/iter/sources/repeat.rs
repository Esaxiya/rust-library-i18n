use crate::iter::{FusedIterator, TrustedLen};

/// Tək bir elementi sonsuz təkrarlayan yeni bir iterator yaradır.
///
/// `repeat()` funksiyası tək bir dəyəri təkrarlayır.
///
/// `repeat()` kimi sonsuz təkrarlayıcılar onları sonlu etmək üçün tez-tez [`Iterator::take()`] kimi adapterlərdə istifadə olunur.
///
/// Lazım olan təkrarlayıcının element növü `Clone` tətbiq etmirsə və ya təkrarlanan elementi yaddaşda saxlamaq istəmirsinizsə, bunun əvəzinə [`repeat_with()`] funksiyasından istifadə edə bilərsiniz.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Əsas istifadə:
///
/// ```
/// use std::iter;
///
/// // dördüncü rəqəm 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // bəli, hələ dörd
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] ilə sonlu getmək:
///
/// ```
/// use std::iter;
///
/// // bu son nümunə çox çox idi.Gəlin yalnız dörd ayağımız olsun.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... və indi işimiz bitdi
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Bir elementi sonsuzca təkrarlayan bir iterator.
///
/// Bu `struct`, [`repeat()`] funksiyası tərəfindən yaradılmışdır.Daha çox məlumat üçün sənədlərinə baxın.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}