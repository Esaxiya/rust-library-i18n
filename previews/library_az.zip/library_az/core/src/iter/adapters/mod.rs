use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Bu trait, şərtlər daxilində interator-adapter boru kəmərində mənbə mərhələsinə keçid imkanı verir
/// * iterator mənbəyi `S` özü `SourceIter<Source = S>` tətbiq edir
/// * mənbəylə boru kəməri istehlakçısı arasındakı boru kəmərindəki hər bir adapter üçün bu trait-nin nümayəndəlik tətbiqi mövcuddur.
///
/// Mənbə sahib iterator strukturu olduqda (ümumiyyətlə `IntoIter` adlanır) bu, [`FromIterator`] tətbiqetmələrini ixtisaslaşdırmaq və ya iteratorun qismən tükənməsindən sonra qalan elementləri bərpa etmək üçün faydalı ola bilər.
///
///
/// Diqqət yetirin ki, tətbiqetmələr bir boru kəmərinin ən daxili mənbəyinə giriş təmin etməlidir.Vəziyyətli bir orta adapter, boru kəmərinin bir hissəsini həvəslə qiymətləndirə bilər və daxili yaddaşını mənbə kimi göstərə bilər.
///
/// trait təhlükəlidir, çünki tətbiqçilər əlavə təhlükəsizlik xüsusiyyətlərini dəstəkləməlidirlər.
/// Ətraflı məlumat üçün [`as_inner`]-ə baxın.
///
/// # Examples
///
/// Qismən istehlak edilmiş bir mənbənin alınması:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Bir iterator boru kəmərində bir mənbə mərhələsi.
    type Source: Iterator;

    /// Bir iterator boru kəmərinin mənbəyini alın.
    ///
    /// # Safety
    ///
    /// Tətbiqləri, zəng edənin əvəz etmədiyi müddətcə ömrü boyu eyni dəyişə bilən referansı qaytarmalıdır.
    /// Zəng edənlər referansı yalnız təkrarlamanı dayandırdıqda əvəz edə bilər və mənbəyi çıxardıqdan sonra təkrarlayıcı boru kəmərini atırlar.
    ///
    /// Bu o deməkdir ki, iterator adapterləri təkrarlama zamanı dəyişməyən mənbəyə etibar edə bilər, lakin Drop tətbiqlərində ona etibar edə bilməzlər.
    ///
    /// Bu metodun tətbiqi adapterlərin mənbəyinə yalnız xüsusi girişdən imtina etməsi və yalnız metod qəbuledici növlərinə əsaslanan zəmanətlərə etibar edə bilməsi deməkdir.
    /// Qadağan edilmiş girişin olmaması, adapterlərin daxili cihazlarına çıxışı olduqda belə mənbənin ümumi API-sini dəstəkləməsini tələb edir.
    ///
    /// Zəng edənlər öz növbəsində mənbənin açıq API ilə uyğun olan hər hansı bir vəziyyətdə olmasını gözləməlidirlər, çünki onunla mənbə arasında oturan adapterlər eyni girişə malikdirlər.
    /// Xüsusilə bir adapter ciddi ehtiyacdan daha çox element istehlak etmiş ola bilər.
    ///
    /// Bu tələblərin ümumi məqsədi bir boru kəməri istehlakçısının istifadəsinə icazə verməkdir
    /// * iterasiya dayandıqdan sonra mənbədə nə varsa
    /// * istehlakçı bir iterator inkişaf edərək istifadə olunmayan hala gələn yaddaş
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Əsas iterator `Result::Ok` dəyərləri istehsal etdiyi müddətdə nəticə çıxaran təkrarlayıcı adapter.
///
///
/// Bir səhvlə qarşılaşdıqda, təkrarlayıcı dayanır və səhv saxlanılır.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Verilən iteratoru `Result<T, _>` əvəzinə `T` vermiş kimi işləyin.
/// Hər hansı bir səhv daxili iteratoru dayandıracaq və ümumi nəticə bir səhv olacaq.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}