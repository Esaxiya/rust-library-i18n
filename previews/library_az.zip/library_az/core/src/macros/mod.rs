#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Arayanın nəşrinə görə `$crate::panic::panic_2015` və ya `$crate::panic::panic_2021`-ə qədər genişlənir.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// İki ifadənin bir-birinə bərabər olduğunu iddia edir ([`PartialEq`] istifadə edərək).
///
/// panic-də bu makro ifadələrin dəyərlərini ayıklama təmsilçiləri ilə çap edəcəkdir.
///
///
/// [`assert!`] kimi, bu makronun da xüsusi bir panic mesajının verilə biləcəyi ikinci bir forması var.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Aşağıdakı yenidən doğma qəsdəndir.
                    // Bunlar olmadan, borc üçün yığın yuvası dəyərlər müqayisə olunmadan əvvəl başlanğıc edilir və nəzərəçarpacaq dərəcədə yavaşlamağa səbəb olur.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Aşağıdakı yenidən doğma qəsdəndir.
                    // Bunlar olmadan, borc üçün yığın yuvası dəyərlər müqayisə olunmadan əvvəl başlanğıc edilir və nəzərəçarpacaq dərəcədə yavaşlamağa səbəb olur.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// İki ifadənin bir-birinə bərabər olmadığını iddia edir ([`PartialEq`] istifadə edərək).
///
/// panic-də bu makro ifadələrin dəyərlərini ayıklama təmsilçiləri ilə çap edəcəkdir.
///
///
/// [`assert!`] kimi, bu makronun da xüsusi bir panic mesajının verilə biləcəyi ikinci bir forması var.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Aşağıdakı yenidən doğma qəsdəndir.
                    // Bunlar olmadan, borc üçün yığın yuvası dəyərlər müqayisə olunmadan əvvəl başlanğıc edilir və nəzərəçarpacaq dərəcədə yavaşlamağa səbəb olur.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Aşağıdakı yenidən doğma qəsdəndir.
                    // Bunlar olmadan, borc üçün yığın yuvası dəyərlər müqayisə olunmadan əvvəl başlanğıc edilir və nəzərəçarpacaq dərəcədə yavaşlamağa səbəb olur.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Mantı ifadəsinin iş zamanı `true` olduğunu iddia edir.
///
/// Təqdim olunan ifadə iş zamanı `true`-ə qiymətləndirilə bilmirsə, bu [`panic!`] makrosunu çağıracaqdır.
///
/// [`assert!`] kimi, bu makronun da xüsusi bir panic mesajının verilə biləcəyi ikinci bir versiyası var.
///
/// # Uses
///
/// [`assert!`]-dən fərqli olaraq, `debug_assert!` ifadələri yalnız default olaraq optimallaşdırılmamış quruluşlarda aktivləşdirilir.
/// Optimize edilmiş quruluş, `-C debug-assertions` kompilyatora ötürülməyincə `debug_assert!` ifadələrini icra etməyəcəkdir.
/// Bu, `debug_assert!`-i sərbəst buraxılışda iştirak etmək üçün çox bahalı olan, lakin inkişaf zamanı faydalı ola biləcək çeklər üçün faydalı edir.
/// `debug_assert!`-in genişləndirilməsinin nəticəsi hər zaman yoxlanılır.
///
/// Yoxlanılmamış bir iddia, uyğunsuz bir vəziyyətdə olan bir proqramın işini davam etdirməsinə imkan verir ki, bu da gözlənilməz nəticələrə səbəb ola bilər, ancaq bu yalnız təhlükəsiz kodda olduğu müddətdə təhlükəsizliyi tətbiq etmir.
///
/// İddiaların performans dəyəri, ümumiyyətlə, ölçülə bilməz.
/// Beləliklə [`assert!`]-in `debug_assert!` ilə dəyişdirilməsi yalnız hərtərəfli profil verildikdən sonra daha da əhəmiyyətlisi yalnız təhlükəsiz kodda təşviq olunur!
///
/// # Examples
///
/// ```
/// // bu iddialar üçün panic mesajı verilən ifadənin simli dəyəridir.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // çox sadə bir funksiya
/// debug_assert!(some_expensive_computation());
///
/// // xüsusi bir mesajla təsdiq edin
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// İki ifadənin bir-birinə bərabər olduğunu iddia edir.
///
/// panic-də bu makro ifadələrin dəyərlərini ayıklama təmsilçiləri ilə çap edəcəkdir.
///
/// [`assert_eq!`]-dən fərqli olaraq, `debug_assert_eq!` ifadələri yalnız default olaraq optimallaşdırılmamış quruluşlarda aktivləşdirilir.
/// Optimize edilmiş quruluş, `-C debug-assertions` kompilyatora ötürülməyincə `debug_assert_eq!` ifadələrini icra etməyəcəkdir.
/// Bu, `debug_assert_eq!`-i sərbəst buraxılışda iştirak etmək üçün çox bahalı olan, lakin inkişaf zamanı faydalı ola biləcək çeklər üçün faydalı edir.
///
/// `debug_assert_eq!`-in genişləndirilməsinin nəticəsi hər zaman yoxlanılır.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// İki ifadənin bir-birinə bərabər olmadığını iddia edir.
///
/// panic-də bu makro ifadələrin dəyərlərini ayıklama təmsilçiləri ilə çap edəcəkdir.
///
/// [`assert_ne!`]-dən fərqli olaraq, `debug_assert_ne!` ifadələri yalnız default olaraq optimallaşdırılmamış quruluşlarda aktivləşdirilir.
/// Optimize edilmiş quruluş, `-C debug-assertions` kompilyatora ötürülməyincə `debug_assert_ne!` ifadələrini icra etməyəcəkdir.
/// Bu, `debug_assert_ne!`-i sərbəst buraxılışda iştirak etmək üçün çox bahalı olan, lakin inkişaf zamanı faydalı ola biləcək çeklər üçün faydalı edir.
///
/// `debug_assert_ne!`-in genişləndirilməsinin nəticəsi hər zaman yoxlanılır.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Verilən ifadənin verilmiş nümunələrdən hər hansı birinə uyğun olub-olmadığını qaytarır.
///
/// Bir `match` ifadəsində olduğu kimi, naxışı isteğe bağlı olaraq `if` və naxışla əlaqəli adlara çıxışı olan bir mühafizə ifadəsi izləyə bilər.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Nəticəni açır və ya səhvini yayır.
///
/// `?` operatoru `try!`-in yerinə əlavə edildi və əvəzinə istifadə olunmalıdır.
/// Bundan əlavə, `try`, Rust 2018-də qorunan bir sözdür, buna görə istifadə etməlisinizsə, [raw-identifier syntax][ris]-dən istifadə etməlisiniz: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` verilmiş [`Result`] ilə uyğun gəlir.`Ok` variantının ifadəsi bükülmüş dəyərin dəyərinə malikdir.
///
/// `Err` variantının olması halında daxili xətanı götürür.`try!` daha sonra `From` istifadə edərək dönüşüm həyata keçirir.
/// Bu, ixtisaslaşmış səhvlər və daha ümumi səhvlər arasında avtomatik dönüşüm təmin edir.
/// Yaranan səhv dərhal geri qaytarılır.
///
/// Erkən qayıtma səbəbindən `try!` yalnız [`Result`] qaytaran funksiyalarda istifadə edilə bilər.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Tez qayıdan səhvlərin üstünlük verilən üsulu
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Əvvəlki sürətli qayıtma səhvləri üsulu
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Bu bərabərdir:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Formatlaşdırılmış məlumatları buferə yazır.
///
/// Bu makro 'writer', format sətri və arqumentlərin siyahısını qəbul edir.
/// Mübahisələr göstərilən format sətrinə görə formatlanacaq və nəticə yazıçıya ötürüləcəkdir.
/// Yazıçı bir `write_fmt` metodu ilə hər hansı bir dəyər ola bilər;ümumiyyətlə bu [`fmt::Write`] ya da [`io::Write`] trait tətbiqindən qaynaqlanır.
/// Makro, `write_fmt` metodunun nə qaytaracağını qaytarır;ümumiyyətlə [`fmt::Result`] və ya [`io::Result`].
///
/// Format sintaksis haqqında daha çox məlumat üçün [`std::fmt`]-ə baxın.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Bir modul həm `std::fmt::Write` həm də `std::io::Write` idxal edə bilər və ya obyektləri ümumiyyətlə tətbiq etmədiyi üçün ya həyata keçirən obyektlərə `write!` çağırır.
///
/// Bununla birlikdə, modul traits keyfiyyətini idxal etməlidir ki, adları zidd olmasın:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt istifadə edir
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt istifadə edir
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Bu makro `no_std` quraşdırmalarında da istifadə edilə bilər.
/// `no_std` quraşdırılmasında, komponentlərin tətbiq detallarına cavabdehsiniz.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Formatlaşdırılmış məlumatları yeni bir sətir əlavə olunaraq buferə yazın.
///
/// Bütün platformalarda yeni xətt təkcə XATT QAZDIRMA (`\n`/`U+000A`) xarakterlidir (əlavə CARRIAGE RETURN (`\r`/`U+000D`) yoxdur).
///
/// Daha çox məlumat üçün [`write!`]-ə baxın.Format sintaksisinə dair məlumat üçün [`std::fmt`]-ə baxın.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Bir modul həm `std::fmt::Write` həm də `std::io::Write` idxal edə bilər və ya obyektləri ümumiyyətlə tətbiq etmədiyi üçün ya həyata keçirən obyektlərə `write!` çağırır.
/// Bununla birlikdə, modul traits keyfiyyətini idxal etməlidir ki, adları zidd olmasın:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt istifadə edir
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt istifadə edir
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Əlçatmaz kodu göstərir.
///
/// Bu, kompilyatorun bəzi kodların əlçatmaz olduğunu müəyyənləşdirə bilmədiyi hər zaman faydalıdır.Misal üçün:
///
/// * Qolları mühafizə şərtləri ilə uyğunlaşdırın.
/// * Dinamik olaraq sona çatan döngələr.
/// * Dinamik olaraq sonlandıran təkrarlayıcılar.
///
/// Kodun əlçatmaz olduğu təyini səhv olduğu təqdirdə, proqram dərhal [`panic!`] ilə sona çatır.
///
/// Bu makronun təhlükəli həmkarı, [`unreachable_unchecked`] funksiyasındadır ki, kodu əldə etdikdə təyin olunmayan davranışa səbəb olacaqdır.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Bu həmişə [`panic!`] olacaq.
///
/// # Examples
///
/// Matç qolları:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // şərh edildiyi təqdirdə səhv tərtib edin
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3-in ən kasıb tətbiqlərindən biridir
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" mesajı ilə çaxnaşma edərək yerinə yetirilməmiş kodu göstərir.
///
/// Bu, kodunuzun növünü yoxlamağa imkan verir, bu da hamısını istifadə etməyi planlaşdırmadığınız birdən çox metod tələb edən bir trait prototipi hazırlayır və ya tətbiq edirsinizsə faydalıdır.
///
/// `unimplemented!` və [`todo!`] arasındakı fərq ondadır ki, `todo!` daha sonra funksionallığı həyata keçirmək niyyətini ifadə edərkən və mesaj "not yet implemented" olsa da, `unimplemented!` belə bir iddia irəli sürmür.
/// Mesajı "not implemented".
/// Bəzi IDE-lər "todo!" İşarəsini də yazacaq.
///
/// # Panics
///
/// Bu həmişə [`panic!`] olacaq, çünki `unimplemented!` sabit, spesifik bir mesajla `panic!` üçün stenoqrafiyadır.
///
/// `panic!` kimi, bu makronun da xüsusi dəyərləri göstərmək üçün ikinci bir forması var.
///
/// # Examples
///
/// Bir trait `Foo` olduğumuzu söyləyin:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// 'MyStruct' üçün `Foo` tətbiq etmək istəyirik, amma nədənsə yalnız `bar()` funksiyasını tətbiq etmək məntiqlidir.
/// `baz()` və `qux()`, `Foo` tətbiqimizdə hələ müəyyənləşdirilməlidir, lakin kodumuzun tərtib edilməsinə imkan vermək üçün `unimplemented!`-i təriflərində istifadə edə bilərik.
///
/// Hələ də tətbiq olunmamış metodlara nail olunarsa proqramımızın dayandırılmasını istəyirik.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` bir `MyStruct` üçün heç bir mənası yoxdur, buna görə burada heç bir məntiqimiz yoxdur.
/////
///         // Bu "thread 'main' panicked at 'not implemented'" göstərəcək.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Burada bəzi məntiqimiz var, yerinə yetirilməyənlərə bir mesaj əlavə edə bilərik!buraxmamağımızı göstərmək.
///         // Bu göstərilir: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Bitməmiş kodu göstərir.
///
/// Prototip hazırlayırsınızsa və yalnız kodunuzun mətnini yoxlamağa çalışırsınızsa, bu faydalı ola bilər.
///
/// [`unimplemented!`] və `todo!` arasındakı fərq ondadır ki, `todo!` daha sonra funksionallığı həyata keçirmək niyyətini ifadə edərkən və mesaj "not yet implemented" olsa da, `unimplemented!` belə bir iddia irəli sürmür.
/// Mesajı "not implemented".
/// Bəzi IDE-lər "todo!" İşarəsini də yazacaq.
///
/// # Panics
///
/// Bu həmişə [`panic!`] olacaq.
///
/// # Examples
///
/// Budur bəzi davam edən kodların bir nümunəsi.Bir trait `Foo` var:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// `Foo` i növlərimizdən birində tətbiq etmək istəyirik, eyni zamanda əvvəlcə yalnız `bar()` üzərində işləmək istəyirik.Kodumuzun tərtib edilməsi üçün `baz()` tətbiq etməliyik, buna görə `todo!` istifadə edə bilərik:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // tətbiq bura gedir
///     }
///
///     fn baz(&self) {
///         // indiyə qədər baz() tətbiq etməkdən narahat olmayaq
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // baz() istifadə etmirik, buna görə də yaxşıdır.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Yerləşdirilmiş makroların tərifləri.
///
/// Makro xassələrin çoxu (stabillik, görünürlük və s.) Buradakı mənbə kodundan götürülür, genişlənmə funksiyaları istisna olmaqla, makro girişləri nəticələrə çevirir, bu funksiyalar tərtibçi tərəfindən təmin olunur.
///
///
pub(crate) mod builtin {

    /// Qarşılaşdıqda verilmiş səhv mesajı ilə tərtibin uğursuz olmasına səbəb olur.
    ///
    /// Bu makro, crate səhv şərtlər üçün daha yaxşı səhv mesajları təmin etmək üçün şərti bir tərtib strategiyasından istifadə etdikdə istifadə olunmalıdır.
    ///
    /// Bu [`panic!`]-nin tərtibçi səviyyəli formasıdır, ancaq *iş zamanı* deyil,*tərtib* zamanı səhv buraxır.
    ///
    /// # Examples
    ///
    /// Bu cür iki nümunə makrolar və `#[cfg]` mühitləridir.
    ///
    /// Bir makro etibarsız dəyərlər ötürülürsə, daha yaxşı kompilyator səhvini buraxın.
    /// Son branch olmasa, tərtibçi yenə də bir səhv buraxacaq, lakin səhv mesajında iki etibarlı dəyərdən bəhs edilməyəcəkdir.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Bir sıra xüsusiyyətlərdən biri mövcud deyilsə, kompilyator səhvini buraxın.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Digər simli formatlaşdırma makroları üçün parametrlər qurur.
    ///
    /// Bu makro, hər bir əlavə arqument üçün `{}` ehtiva edən bir formatlama sətri alaraq işləyir.
    /// `format_args!` Çıxışın bir sətir kimi təfsir olunmasını təmin etmək üçün əlavə parametrlər hazırlayır və arqumentləri tək bir növə kanonikləşdirir.
    /// [`Display`] trait-ni tətbiq edən hər hansı bir dəyər `format_args!`-ə ötürülə bilər, hər hansı bir [`Debug`] tətbiqi formatlama sətri içərisində bir `{:?}`-ə ötürülə bilər.
    ///
    ///
    /// Bu makro [`fmt::Arguments`] tipli bir dəyər yaradır.Bu dəyər faydalı yönləndirmə həyata keçirmək üçün [`std::fmt`] içindəki makrolara ötürülə bilər.
    /// Bütün digər formatlaşdırma makroları (["format!"], [`write!`], [`println!`], və s.) Bu vasitə ilə təqdim olunur.
    /// `format_args!`, çıxarılan makrolardan fərqli olaraq, yığın ayırmalarının qarşısını alır.
    ///
    /// Aşağıdan göründüyü kimi `format_args!`-in `Debug` və `Display` kontekstində qaytardığı [`fmt::Arguments`] dəyərini istifadə edə bilərsiniz.
    /// Nümunə də göstərir ki, `Debug` və `Display` eyni şeyi formatlaşdırır: `format_args!`-də interpolyasiya edilmiş format sətri.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Daha çox məlumat üçün [`std::fmt`] sənədlərinə baxın.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` ilə eyni, lakin sonunda yeni bir xətt əlavə edir.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Tərtib zamanı mühit dəyişənini yoxlayır.
    ///
    /// Bu makro, `&'static str` tipli bir ifadə verərək tərtib zamanı adlandırılan mühit dəyişəninin dəyərinə qədər genişlənəcəkdir.
    ///
    ///
    /// Əgər mühit dəyişənliyi müəyyən edilməyibsə, onda tərtib xətası çıxarılacaqdır.
    /// Kompilyasiya xətası buraxmamaq üçün [`option_env!`] makrosunu istifadə edin.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Bir xətti ikinci parametr olaraq ötürərək səhv mesajını fərdiləşdirə bilərsiniz:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// `documentation` mühit dəyişəni təyin edilməyibsə, aşağıdakı xətanı alacaqsınız:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// İstəyə görə tərtib zamanı bir mühit dəyişənini yoxlayır.
    ///
    /// Tərtib olunan vaxtda adlanan mühit dəyişəni varsa, bu, ətraf mühit dəyişəninin dəyərinin `Some` olan `Option<&'static str>` tipli bir ifadəyə qədər genişlənəcəkdir.
    /// Əgər mühit dəyişən yoxdursa, bu `None`-ə qədər genişlənəcəkdir.
    /// Bu növ haqqında daha çox məlumat üçün [`Option<T>`][Option]-ə baxın.
    ///
    /// Bu makrosu istifadə edərkən mühit dəyişəninin olub-olmamasından asılı olmayaraq tərtib vaxtı xətası heç vaxt buraxılmaz.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Tanımlayıcıları bir identifikatora birləşdirir.
    ///
    /// Bu makro istənilən sayda virgüllə ayrılmış identifikator götürür və hamısını bir yerə birləşdirir və yeni bir identifikator olan bir ifadə verir.
    /// Diqqət yetirin ki, gigiyena bu makronun yerli dəyişənləri tuta bilməməsini təmin edir.
    /// Ayrıca, ümumi bir qayda olaraq, makrolara yalnız maddə, ifadə və ya ifadə mövqeyində icazə verilir.
    /// Bu o deməkdir ki, bu makrosu mövcud dəyişənlərə, funksiyalara və ya modullara istinad etmək üçün istifadə edə bilərsiniz, bununla yenisini müəyyən edə bilməzsiniz.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (yeni, əyləncəli, ad) { }//bu şəkildə istifadə edilə bilməz!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ədəbiyyatını statik bir simli dilimə birləşdirir.
    ///
    /// Bu makro hər hansı bir sayda vergüllə ayrılmış ədədi alır və soldan sağa birləşdirilmiş bütün ədəbiyyatları təmsil edən `&'static str` tipli bir ifadə verir.
    ///
    ///
    /// Tam və üzən nöqtə ədəbiyyatları birləşdirilmək üçün sıralanır.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Çağırıldığı sətir nömrəsini genişləndirir.
    ///
    /// [`column!`] və [`file!`] ilə bu makrolar, inkişaf etdiricilər üçün mənbədəki yer haqqında hata ayıklama məlumatları təmin edir.
    ///
    /// Genişləndirilmiş ifadə `u32` tipinə malikdir və 1 əsaslıdır, buna görə hər fayldakı birinci sətir 1, ikincisi 2 və s.
    /// Bu, ümumi kompilyatorların və ya populyar redaktorların səhv mesajları ilə uyğundur.
    /// Qaytarılmış sətir *mütləq*`line!` çağırışının xətti deyil, əksinə `line!` makrosunun çağırışına aparan ilk makro çağırışıdır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Çağırıldığı sütun nömrəsinə genişlənir.
    ///
    /// [`line!`] və [`file!`] ilə bu makrolar, inkişaf etdiricilər üçün mənbədəki yer haqqında hata ayıklama məlumatları təmin edir.
    ///
    /// Genişləndirilmiş ifadə `u32` tipinə malikdir və 1 əsaslıdır, buna görə hər sətirdə birinci sütun 1, ikincisi 2 və s.
    /// Bu, ümumi kompilyatorların və ya populyar redaktorların səhv mesajları ilə uyğundur.
    /// Döndürülmüş sütun *mütləq*`column!` çağırışının xətti deyil, əksinə `column!` makrosunun çağırılmasına qədər gedən ilk makro çağırışdır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Çağırıldığı fayl adını genişləndirir.
    ///
    /// [`line!`] və [`column!`] ilə bu makrolar, inkişaf etdiricilər üçün mənbədəki yer haqqında hata ayıklama məlumatları təmin edir.
    ///
    /// Genişləndirilmiş ifadə `&'static str` tipinə malikdir və qaytarılmış fayl `file!` makrosunun özünün deyil, əksinə `file!` makrosunun çağırışına aparan ilk makro çağırışıdır.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Arqumentlərini dilə gətirir.
    ///
    /// Bu makro, makroya ötürülən bütün tokens-nin dizilişi olan `&'static str` tipli bir ifadə verəcəkdir.
    /// Makro çağırışın özünün sintaksisinə heç bir məhdudiyyət qoyulmur.
    ///
    /// tokens girişinin genişləndirilmiş nəticələrinin future-də dəyişə biləcəyini unutmayın.Çıxışa güvənirsinizsə ehtiyatlı olmalısınız.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Bir UTF-8 kodlanmış bir faylı bir simli daxil edir.
    ///
    /// Fayl cari fayla nisbətən yerləşir (modulların tapılmasına bənzər).
    /// Təqdim olunan yol, tərtib zamanı platformaya xas bir şəkildə şərh olunur.
    /// Beləliklə, məsələn, `\` ters əyikləri olan bir Windows yolu olan bir çağırış Unix-də düzgün tərtib edilməyəcəkdir.
    ///
    ///
    /// Bu makro, sənədin məzmunu olan `&'static str` tipli bir ifadə verəcəkdir.
    ///
    /// # Examples
    ///
    /// Eyni qovluqda aşağıdakı məzmunu olan iki fayl olduğunu düşünək:
    ///
    /// 'spanish.in' faylı:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' faylı:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs'-in tərtib edilməsi və nəticədə yaranan ikili sistemin işlənməsi "adiós"-i çap edəcəkdir.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Bir faylı bayt massivinə istinad kimi daxil edir.
    ///
    /// Fayl cari fayla nisbətən yerləşir (modulların tapılmasına bənzər).
    /// Təqdim olunan yol, tərtib zamanı platformaya xas bir şəkildə şərh olunur.
    /// Beləliklə, məsələn, `\` ters əyikləri olan bir Windows yolu olan bir çağırış Unix-də düzgün tərtib edilməyəcəkdir.
    ///
    ///
    /// Bu makro, sənədin məzmunu olan `&'static [u8; N]` tipli bir ifadə verəcəkdir.
    ///
    /// # Examples
    ///
    /// Eyni qovluqda aşağıdakı məzmunu olan iki fayl olduğunu düşünək:
    ///
    /// 'spanish.in' faylı:
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// 'main.rs' faylı:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs'-in tərtib edilməsi və nəticədə yaranan ikili sistemin işlənməsi "adiós"-i çap edəcəkdir.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Mövcud modul yolunu təmsil edən bir simli genişləndirir.
    ///
    /// Mövcud modul yolu, crate root-ə qayıdan modulların iyerarxiyası kimi qəbul edilə bilər.
    /// Geri qaytarılmış yolun ilk komponenti hazırda tərtib olunan crate-nin adıdır.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Tərtib zamanı konfiqurasiya bayraqlarının boole birləşmələrini qiymətləndirir.
    ///
    /// `#[cfg]` atributuna əlavə olaraq bu makro, konfiqurasiya bayraqlarının boole ifadəsinin qiymətləndirilməsinə imkan vermək üçün təmin edilmişdir.
    /// Bu tez-tez daha az təkrarlanan kod gətirib çıxarır.
    ///
    /// Bu makroya verilən sintaksis, [`cfg`] atributu ilə eyni sintaksisdir.
    ///
    /// `cfg!`, `#[cfg]`-dən fərqli olaraq heç bir kodu silmir və yalnız doğru və ya yalan kimi qiymətləndirir.
    /// Məsələn,if/else-nin qiymətləndirməsindən asılı olmayaraq, şərt üçün `cfg!` istifadə edildikdə, if/else ifadəsindəki bütün blokların etibarlı olması lazımdır.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Bir məzmuna görə bir ifadə və ya bir maddə olaraq bir faylı ayırır.
    ///
    /// Fayl cari fayla nisbətən yerləşir (modulların tapılmasına bənzər).Təqdim olunan yol, tərtib zamanı platformaya xas bir şəkildə şərh olunur.
    /// Beləliklə, məsələn, `\` ters əyikləri olan bir Windows yolu olan bir çağırış Unix-də düzgün tərtib edilməyəcəkdir.
    ///
    /// Bu makronu istifadə etmək çox vaxt pis bir fikirdir, çünki fayl bir ifadə olaraq təhlil edilərsə, ətrafdakı kodda gigiyenik olaraq yerləşdiriləcəkdir.
    /// Bu, cari faylda eyni adda olan dəyişənlər və ya funksiyalar olduqda dəyişənlərin və ya funksiyaların gözləniləndən fərqli olmasına səbəb ola bilər.
    ///
    ///
    /// # Examples
    ///
    /// Eyni qovluqda aşağıdakı məzmunu olan iki fayl olduğunu düşünək:
    ///
    /// 'monkeys.in' faylı:
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// 'main.rs' faylı:
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs'-in tərtib edilməsi və nəticədə yaranan ikili sistemin işlənməsi "🙈🙊🙉🙈🙊🙉"-i çap edəcəkdir.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Mantı ifadəsinin iş zamanı `true` olduğunu iddia edir.
    ///
    /// Təqdim olunan ifadə iş zamanı `true`-ə qiymətləndirilə bilmirsə, bu [`panic!`] makrosunu çağıracaqdır.
    ///
    /// # Uses
    ///
    /// İddialar hər zaman həm debaqda, həm də buraxılışda yoxlanılır və aradan qaldırıla bilməz.
    /// Varsayılan olaraq buraxılış quruluşlarında aktiv edilməyən iddialar üçün [`debug_assert!`]-ə baxın.
    ///
    /// Təhlükəli kod, iş vaxtı dəyişməzlərini tətbiq etmək üçün `assert!`-a etibar edə bilər, əgər pozulsa təhlükəsizliyə səbəb ola bilər.
    ///
    /// `assert!`-in digər istifadə hallarına, iş vaxtı dəyişməzlərinin təhlükəsiz kodda sınanması və tətbiq edilməsi daxildir (pozulması təhlükəsizliyə səbəb ola bilməz).
    ///
    ///
    /// # Xüsusi mesajlar
    ///
    /// Bu makronun xüsusi bir panic mesajının formatlaşdırma üçün arqumentlərlə və ya olmadan təmin edilə biləcəyi ikinci bir forması var.
    /// Bu forma üçün sintaksis üçün [`std::fmt`]-ə baxın.
    /// Format arqumentləri kimi istifadə edilən ifadələr yalnız iddia uğursuz olduqda qiymətləndiriləcəkdir.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // bu iddialar üçün panic mesajı verilən ifadənin simli dəyəridir.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // çox sadə bir funksiya
    ///
    /// assert!(some_computation());
    ///
    /// // xüsusi bir mesajla təsdiq edin
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// İnline montaj.
    ///
    /// İstifadə üçün [unstable book] oxuyun.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM üslubunda daxili montaj.
    ///
    /// İstifadə üçün [unstable book] oxuyun.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Modul səviyyəsində satır içi montaj.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Basqılar tokens-ni standart çıxışa keçirdi.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Digər makroların səhvlərini düzəltmək üçün istifadə edilən axtarış funksiyasını aktivləşdirir və ya söndürür.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Törəmə makrolarını tətbiq etmək üçün istifadə olunan atribut makrosu.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Funksiyanı vahid testinə çevirmək üçün tətbiq olunan atribut makrosu.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Bir etalon testinə çevirmək üçün bir funksiyaya tətbiq olunan atribut makrosu.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` və `#[bench]` makrolarının tətbiq detalı.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Atribut makrosu qlobal bir ayırıcı kimi qeyd etmək üçün statikə tətbiq olunur.
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html)-ə də baxın.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Keçən yola əlçatan olduqda tətbiq olunan elementi saxlayır və əks halda onu silir.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Tətbiq olunan kod parçasındakı bütün `#[cfg]` və `#[cfg_attr]` xüsusiyyətlərini genişləndirir.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` kompilyatorunun qeyri-sabit tətbiq detalı, istifadə etməyin.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` kompilyatorunun qeyri-sabit tətbiq detalı, istifadə etməyin.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}