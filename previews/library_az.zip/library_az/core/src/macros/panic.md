Cari mövzu Panics.

Bu, bir proqramın dərhal ləğv edilməsinə və proqramı axtarana geri bildirim verilməsinə imkan verir.
`panic!` bir proqram bərpa olunmayan bir vəziyyətə çatdıqda istifadə edilməlidir.

Bu makro, nümunə kodunda və testlərdə şərtləri təsdiqləmək üçün mükəmməl bir yoldur.
`panic!` həm [`Option`][ounwrap], həm də [`Result`][runwrap] enumlarının `unwrap` metodu ilə sıx bağlıdır.
Hər iki tətbiq də [`None`] və ya [`Err`] variantlarına ayarlandıqda `panic!` çağırır.

`panic!()` istifadə edərkən [`format!`] sintaksisindən istifadə edərək qurulmuş bir sətir yükü təyin edə bilərsiniz.
Bu faydalı yük, panic-ni çağıran Rust ipliyinə vurarkən istifadə olunur və bu da tamamilə panic-yə səbəb olur.

Varsayılan `std` hook davranışı, yəni
birbaşa panic çağırıldıqdan sonra işləyən kod, `panic!()` zənginin file/line/column məlumatı ilə birlikdə `stderr`-ə mesaj yükünü yazdırmaqdır.

[`std::panic::set_hook()`] istifadə edərək panic hook-ni ləğv edə bilərsiniz.
hook içərisində bir panic-yə normal `panic!()` çağırışları üçün ya `&str` ya da `String` olan bir `&dyn Any + Send` kimi daxil olmaq olar.
Başqa bir növün dəyəri olan panic üçün [`panic_any`] istifadə edilə bilər.

[`Result`] enum tez-tez səhvlərdən qurtarmaq üçün `panic!` makrosundan istifadə etməkdən daha yaxşı bir həlldir.
Bu makro xarici mənbələrdən olduğu kimi səhv dəyərlərdən istifadə etməmək üçün istifadə olunmalıdır.
Xəta işləmə haqqında ətraflı məlumat [book]-də tapılmışdır.

Tərtib zamanı səhvlərin artması üçün makro [`compile_error!`]-ə də baxın.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Cari tətbiq

Əsas mövzu panics olarsa, bütün mövzularınızı ləğv edəcək və proqramınızı `101` kodu ilə bitirəcəkdir.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





