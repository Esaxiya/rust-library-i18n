# Stdarch-a töhfə verir

`stdarch` crate töhfələri qəbul etməkdən daha çox istəklidir!Əvvəlcə ehtimal ki, anbarı yoxlamaq və testlərin sizin üçün keçdiyindən əmin olmaq lazımdır:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

`<your-target-arch>`, `rustup` tərəfindən istifadə edilən hədəf üçlüdür, məsələn `x86_x64-unknown-linux-gnu` (əvvəlki `nightly-` və ya bənzəri olmadan).
Həm də unutmayın ki, bu depo Rust-nin gecə kanalını tələb edir!
Yuxarıda göstərilən testlər əslində gecə rust-nin `rustup default nightly` (və geri qaytarmaq üçün `rustup default stable`) istifadə etməsini təyin etmək üçün sisteminizdə standart olmalıdır.

Yuxarıdakı addımlardan hər hansı biri nəticə vermirsə, [please let us know][new]!

Bundan sonra kömək etmək üçün [find an issue][issues] edə bilərsiniz, xüsusən də bəzi köməklərdən istifadə edə biləcək [`help wanted`][help] və [`impl-period`][impl] etiketləri ilə bir neçəsini seçdik. 
Ən çox [#40][vendor] ilə maraqlana bilərsiniz, x86-də bütün satıcı daxili məhsullarını tətbiq edin.Bu məsələnin harada başlamağınıza dair yaxşı göstəriciləri var!

Ümumi suallarınız varsa, [join us on gitter][gitter]-dən çəkin və soruşun!Suallarınızla ya@BurntSushi ya da@alexcrichton ping çəkməkdən çəkinməyin.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Stdarch intrinsics üçün nümunələr necə yazılır

Verilən daxili xüsusiyyətin düzgün işləməsi üçün aktivləşdirilməli bir neçə xüsusiyyət var və bu xüsusiyyət yalnız CPU tərəfindən dəstəkləndikdə `cargo test --doc` tərəfindən idarə olunmalıdır.

Nəticədə, `rustdoc` tərəfindən yaradılan standart `fn main` işləməyəcəkdir (əksər hallarda).
Nümunənizin gözlənildiyi kimi işləməsini təmin etmək üçün aşağıdakıları rəhbər kimi istifadə etməyi düşünün.

```rust
/// # // Nümunənin yalnız olmasını təmin etmək üçün cfg_target_feature lazımdır
/// # // CPU xüsusiyyəti dəstəklədikdə `cargo test --doc` tərəfindən idarə olunur
/// # #![feature(cfg_target_feature)]
/// # // Yerli işləmək üçün target_feature lazımdır
/// # #![feature(target_feature)]
/// #
/// # // rustdoc standart olaraq `extern crate stdarch` istifadə edir, amma buna ehtiyacımız var
/// # // `#[macro_use]`
/// # # [makro_istifadə] xarici crate stdarch;
/// #
/// # // Əsl əsas funksiya
/// # fn main() {
/// #     // Bunu yalnız `<target feature>` dəstəklənirsə çalıştırın
/// #     cfg_feature_enabled! ("<target feature>"){
/// #         // Yalnız hədəf xüsusiyyəti olduqda işlədiləcək bir `worker` funksiyası yaradın
/// #         // dəstəklənir və işçiniz üçün `target_feature`-nin aktiv olmasını təmin edir
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         təhlükəli fn worker() {
/// // Nümunənizi buraya yazın.Xüsusiyyətə xas xüsusiyyətlər burada işləyəcək!Vəhşi ol!
///
/// #         }
///
/// #         təhlükəli { worker(); }
/// #     }
/// # }
```

Yuxarıdakı sintaksislərdən bəziləri tanış görünmürsə, [Rust Book]-in [Documentation as tests] bölməsi `rustdoc` sintaksisini kifayət qədər yaxşı təsvir edir.
Həmişə olduğu kimi, [join us on gitter][gitter]-dən çəkinməyin və hər hansı bir qırıq-qırıq vurduğunuzu soruşun və `stdarch` sənədlərini yaxşılaşdırmağa kömək etdiyiniz üçün təşəkkür edirik!

# Alternativ Test Təlimatları

Testləri aparmaq üçün ümumiyyətlə `ci/run.sh` istifadə etməyiniz tövsiyə olunur.
Lakin bu sizin üçün işləməyə bilər, məsələn Windows-də olsanız.

Bu halda kod istehsalını sınamaq üçün `cargo +nightly test` və `cargo +nightly test --release -p core_arch`-lərin işinə qayıda bilərsiniz.
Qeyd edək ki, bunlar gecə alət zəncirinin quraşdırılmasını və `rustc`-nin hədəfinizin üçlüyü və onun prosessoru haqqında məlumat əldə etməsini tələb edir.
Xüsusilə X001 üçün olduğu kimi `TARGET` mühit dəyişənini təyin etməlisiniz.
Əlavə olaraq hədəf xüsusiyyətlərini göstərmək üçün `RUSTCFLAGS` (`C`-ə ehtiyacınız var) təyin etməlisiniz `RUSTCFLAGS="-C -target-features=+avx2"`.
Cari CPU-ya qarşı inkişaf edən "just" edirsinizsə, `-C -target-cpu=native`-i də təyin edə bilərsiniz.

Bu alternativ təlimatları istifadə edərkən [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], məsələn, xəbərdar olun
təlimat yaratmaq testləri uğursuz ola bilər, çünki sökücü onları fərqli adlandırdı, məsələn
eyni davranmasına baxmayaraq `aesenc` təlimatları yerinə `vaesenc` yarada bilər.
Həm də bu təlimatlar normal olaraq olduğundan daha az testlər həyata keçirir, buna görə də sonda çəkib soruşduğunuz zaman burada göstərilməyən testlərdə bəzi səhvlərin görünə biləcəyinə təəccüblənməyin.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






