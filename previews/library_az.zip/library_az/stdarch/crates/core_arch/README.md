`core::arch` - Rust-nin əsas kitabxana arxitekturasına xas daxili
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` modulu arxitekturadan asılı daxili (məsələn, SIMD) tətbiq edir.

# Usage 

`core::arch` `libcore` hissəsi olaraq mövcuddur və `libstd` tərəfindən yenidən ixrac olunur.Bu crate-dən daha çox `core::arch` və ya `std::arch` vasitəsilə istifadə etməyi üstün tutun.
Qeyri-sabit xüsusiyyətlər tez-tez gecə Rust-də `feature(stdsimd)` vasitəsilə mövcuddur.

Bu crate vasitəsi ilə `core::arch` istifadə etmək gecə Rust tələb edir və tez-tez pozula bilər (və olur).Bu crate vasitəsilə istifadə etməyi düşünməyiniz lazım olan yeganə hallar bunlardır:

* `core::arch`-i özünüz yenidən tərtib etməlisinizsə, məsələn, `libcore`/`libstd` üçün aktiv olmayan xüsusi hədəf xüsusiyyətləri aktivləşdirildikdə.
Note: standart olmayan bir hədəf üçün yenidən tərtib etməlisinizsə, xahiş edirəm bu crate istifadə etmək əvəzinə `xargo` istifadə etməyi və `libcore`/`libstd`-i uyğunlaşdırmağı üstün tutun.
  
* qeyri-sabit Rust xüsusiyyətlərinin arxasında belə mövcud olmaya biləcək bəzi xüsusiyyətlərdən istifadə etmək.Bunları minimuma endirməyə çalışırıq.
Bu xüsusiyyətlərdən bəzilərini istifadə etməyiniz lazımdırsa, xahiş edirəm bir problemi açın ki, onları gecə Rust-də ifşa edə bilək və oradan istifadə edə bilərsiniz.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` əsasən MIT lisenziyası və Apache Lisenziyası (Versiya 2.0) şərtləri altında paylanır, hissələri müxtəlif BSD kimi lisenziyalarla əhatə olunur.

Ətraflı məlumat üçün LİSENSİYA-APACHE və LİSENSİYA-MİT-ə baxın.

# Contribution

Başqa bir şəkildə açıq şəkildə ifadə etmədiyiniz təqdirdə, Apache-2.0 lisenziyasında müəyyənləşdirildiyi kimi sizin tərəfinizdən `core_arch`-ə daxil olmaq üçün qəsdən təqdim olunan hər hansı bir töhfə, əlavə şərt və şərtlər olmadan yuxarıdakı kimi ikili lisenziyalaşdırılacaqdır.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












