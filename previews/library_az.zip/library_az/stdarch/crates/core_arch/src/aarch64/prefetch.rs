#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html)-ə baxın.
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html)-ə baxın.
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html)-ə baxın.
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html)-ə baxın.
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html)-ə baxın.
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html)-ə baxın.
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Verilmiş `rw` və `locality` istifadə edərək `p` ünvanı olan önbellek sətrini götürün.
///
/// `rw` aşağıdakılardan biri olmalıdır:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): prefetch oxumağa hazırlaşır.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): prefetch yazmağa hazırlaşır.
///
/// `locality` aşağıdakılardan biri olmalıdır:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Yalnız bir dəfə istifadə edilən məlumatlar üçün axın və ya müvəqqəti olmayan prefet.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Səviyyə 3 önbelleğine daxil olun.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Səviyyə 2 önbelleğe daxil olun.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Səviyyə 1 önbelleğe daxil olun.
///
/// Əvvəlcədən götürülmüş yaddaş təlimatları yaddaş sisteminə müəyyən bir ünvandan yaddaşın daxil olmasının future yaxınlığında baş verə biləcəyini bildirir.
/// Yaddaş sistemi, baş verdikdə yaddaşa girişin sürətləndirilməsi gözlənilən hərəkətləri, məsələn, göstərilən ünvanın bir və ya daha çox önbelleğe əvvəlcədən yüklənməsi kimi tədbirlər görərək cavab verə bilər.
///
/// Bu siqnallar yalnız göstərişlər olduğundan, müəyyən bir CPU üçün hər hansı bir və ya bütün əvvəlcədən göndərmə təlimatlarını NOP kimi qəbul etməsi etibarlıdır.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // `llvm.prefetch` instrinsicini `cache type` =1 (data cache) ilə istifadə edirik.
    // `rw` və `strategy` funksiya parametrlərinə əsaslanır.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}