use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // `#[assert_instr]` qeydlərimizə bütün simd daxili maddələrin kodgenlərini sınamaq üçün mövcud olduğunu söyləmək üçün istifadə olunur, çünki bəziləri hazırda `#[target_feature]`-də heç bir ekvivalenti olmayan əlavə `-Ctarget-feature=+unimplemented-simd128` arxasında dayanır.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}