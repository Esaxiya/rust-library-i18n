# `rustc-std-workspace-core` crate

Ky crate është një crate i dobët dhe i zbrazët, i cili thjesht varet nga `libcore` dhe rieksporton të gjithë përmbajtjen e tij.
crate është thelbi i fuqizimit të bibliotekës standarde që të varet nga crates nga crates.io

Crates në crates.io që biblioteka standarde varet nga nevoja që të varet nga `rustc-std-workspace-core` crate nga crates.io, e cila është bosh.

Ne përdorim `[patch]` për ta tejkaluar atë në këtë crate në këtë depo.
Si rezultat, crates në crates.io do të tërheqë një varësi edge në `libcore`, versioni i përcaktuar në këtë depo.
Kjo duhet të tërheqë të gjitha skajet e varësisë për të siguruar që Cargo ndërton crates me sukses!

Vini re se crates në crates.io duhet të varet nga kjo crate me emrin `core` që gjithçka të funksionojë si duhet.Për ta bërë këtë ata mund të përdorin:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Përmes përdorimit të tastit `package` crate riemërohet në `core`, që do të thotë se do të duket si

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

kur Cargo thërret përpiluesin, duke kënaqur direktivën e nënkuptuar `extern crate core` të injektuar nga përpiluesi.




