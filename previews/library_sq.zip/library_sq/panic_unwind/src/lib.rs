//! Zbatimi i panics përmes zgjidhjes së pirgut
//!
//! Ky crate është një zbatim i panics në Rust duke përdorur mekanizmin e zgjidhjes së pirgjeve "most native" të platformës për të cilën po përpilohet.
//! Kjo në thelb kategorizohet në tre kova aktualisht:
//!
//! 1. Synimet MSVC përdorin SEH në skedarin `seh.rs`.
//! 2. Emscripten përdor përjashtime C++ në skedarin `emcc.rs`.
//! 3. Të gjithë synimet e tjera përdorin libunwind/libgcc në skedarin `gcc.rs`.
//!
//! Më shumë dokumente për secilin zbatim mund të gjenden në modulin përkatës.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` është i papërdorur me Miri, kështu që paralajmërimet e heshtjes.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // Rust objektet e fillimit të ekzekutimit varen nga këto simbole, prandaj bëjini ato publike.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // Synimet që nuk mbështesin zgjidhjen.
        // - arch=wasm32
        // - os=asnjë (synimet "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // Përdorni kohën e ekzekutimit të Miri.
        // Ne ende duhet të ngarkojmë edhe kohën e duhur të ekzekutimit më sipër, pasi rustc pret që artikuj të caktuar të gjuhës të përcaktohen nga atje.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // Përdorni kohën e duhur të ekzekutimit.
        use real_imp as imp;
    }
}

extern "C" {
    /// Kontrolluesi në libstd thirret kur një objekt panic bie jashtë `catch_unwind`.
    ///
    fn __rust_drop_panic() -> !;

    /// Trajtuesi në libstd quhet kur kapet një përjashtim i huaj.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// Pika hyrëse për ngritjen e një përjashtimi, thjesht delegon në zbatimin specifik të platformës.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}