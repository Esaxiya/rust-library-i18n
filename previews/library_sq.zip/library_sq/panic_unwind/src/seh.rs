//! Windows SEH
//!
//! Në Windows (aktualisht vetëm në MSVC), mekanizmi i parazgjedhur i trajtimit të përjashtimeve është Strukturimi i Përjashtimeve të Strukturuara (SEH).
//! Kjo është krejt ndryshe nga trajtimi i përjashtimeve të bazuara në Xhuxh (p.sh., çfarë përdorin platformat e tjera unix) për sa i përket përbërësve të brendshëm, kështu që LLVM kërkohet të ketë një mbështetje të mirë shtesë për SEH.
//!
//! Me pak fjalë, ajo që ndodh këtu është:
//!
//! 1. Funksioni `panic` e quan funksionin standard Windows `_CxxThrowException` për të hedhur një C++ -si përjashtim, duke shkaktuar procesin e zgjidhjes.
//! 2.
//! Të gjitha jastëkët e zbarkimit të gjeneruara nga përpiluesi përdorin funksionin e personalitetit `__CxxFrameHandler3`, një funksion në KRRT-në dhe kodin e zgjidhjes në Windows do ta përdorin këtë funksion të personalitetit për të ekzekutuar të gjithë kodin e pastrimit në pirg.
//!
//! 3. Të gjitha thirrjet e krijuara nga përpiluesit për në `invoke` kanë një bllok ulje të vendosur si një udhëzim `cleanuppad` LLVM, i cili tregon fillimin e rutinës së pastrimit.
//! Personaliteti (në hapin 2, të përcaktuar në KRRT) është përgjegjës për drejtimin e rutinave të pastrimit.
//! 4. Përfundimisht ekzekutohet kodi "catch" në brendësinë `try` (i krijuar nga përpiluesi) dhe tregon që kontrolli duhet të kthehet përsëri në Rust.
//! Kjo bëhet përmes një udhëzimi `catchswitch` plus një udhëzimi `catchpad` në terma IR LLVM, duke i kthyer përfundimisht kontrollin normal programit me një udhëzim `catchret`.
//!
//! Disa ndryshime specifike nga trajtimi i përjashtimeve të bazuara në gcc janë:
//!
//! * Rust nuk ka asnjë funksion personal të personalitetit, por është *gjithmonë*`__CxxFrameHandler3`.Për më tepër, nuk kryhet asnjë filtrim shtesë, kështu që ne përfundojmë duke kapur ndonjë përjashtim të C++ që ndodh të duket si lloji që hedhim.
//! Vini re se hedhja e një përjashtimi në Rust është sjellje e papërcaktuar sidoqoftë, kështu që kjo duhet të jetë mirë.
//! * Kemi disa të dhëna për të transmetuar përtej kufirit të zgjidhjes, specifikisht një `Box<dyn Any + Send>`.Ashtu si me përjashtimet e Xhuxhit, këto dy tregues ruhen si ngarkesë në vetë përjashtimin.
//! Sidoqoftë, në MSVC nuk ka nevojë për një alokim ekstra grumbulli sepse grumbulli i thirrjeve ruhet ndërsa funksionet e filtrit ekzekutohen.
//! Kjo do të thotë që treguesit kalojnë drejtpërdrejt në `_CxxThrowException` të cilët më pas rikuperohen në funksionin e filtrit për t'u shkruar në kornizën e pirgut të `try` të brendshme.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Kjo duhet të jetë një Opsion sepse ne kapim përjashtimin duke iu referuar dhe shkatërruesi i tij ekzekutohet nga koha e ekzekutimit të C++ .
    // Kur marrim Kutinë nga përjashtimi, duhet të lëmë përjashtimin në një gjendje të vlefshme që shkatërruesi i saj të funksionojë pa e hedhur dy herë Kutinë.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Së pari, një bandë e tërë e përkufizimeve të tipit.Ka disa çudira të veçanta për platformën këtu, dhe shumë që thjesht kopjohen qartë nga LLVM.Qëllimi i gjithë kësaj është të zbatojë funksionin `panic` më poshtë përmes një thirrjeje për `_CxxThrowException`.
//
// Ky funksion merr dy argumente.E para është një tregues i të dhënave që po kalojmë, i cili në këtë rast është objekti ynë trait.Shumë e lehtë për tu gjetur!Tjetra, megjithatë, është më e ndërlikuar.
// Ky është një tregues për një strukturë `_ThrowInfo`, dhe zakonisht ka për qëllim vetëm të përshkruajë përjashtimin që hidhet.
//
// Aktualisht përkufizimi i këtij lloji [1] është pak me flokë, dhe çudia kryesore (dhe ndryshimi nga artikulli në internet) është se në 32-bit treguesit janë tregues, por në 64-bit treguesit shprehen si 32-bit offsets nga Simbol `__ImageBase`.
//
// Makroja `ptr_t` dhe `ptr!` në modulet më poshtë janë përdorur për të shprehur këtë.
//
// Labirinti i përkufizimeve të tipit gjithashtu ndjek nga afër atë që LLVM lëshon për këtë lloj operacioni.Për shembull, nëse përpiloni këtë kod C++ në MSVC dhe lëshoni IRL LLVM:
//
//      #include <stdint.h>
//
//      struktura e ndryshkut {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      i pavlefshëm foo() { rust_panic a = {0, 1};
//          hedh një;}
//
// Kjo është në thelb ajo që ne po përpiqemi të imitojmë.Shumica e vlerave konstante më poshtë u kopjuan vetëm nga LLVM,
//
// Në çdo rast, këto struktura janë ndërtuar të gjitha në një mënyrë të ngjashme, dhe është thjesht disi e shprehur për ne.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Vini re se ne qëllimisht i injorojmë rregullat e mangulimit të emrave këtu: ne nuk duam që C++ të jetë në gjendje të kapë Rust panics duke deklaruar thjesht një `struct rust_panic`.
//
//
// Kur modifikoni, sigurohuni që vargu i emrit të tipit përputhet saktësisht me atë të përdorur në `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Bajti kryesor `\x01` këtu është në të vërtetë një sinjal magjik për LLVM që *të mos* zbatojë ndonjë manipulim tjetër si parashtesa me karakter `_`.
    //
    //
    // Ky simbol është tryeza e përdorur nga `std::type_info` e C++ .
    // Objektet e tipit `std::type_info`, përshkruesit e tipit, kanë një tregues në këtë tabelë.
    // Përshkruesit e tipit referohen nga strukturat C++ EH të përcaktuara më sipër dhe që ne i ndërtojmë më poshtë.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Ky përshkrues i tipit përdoret vetëm kur hedh një përjashtim.
// Pjesa e kapjes trajtohet nga prova e brendshme, e cila gjeneron TypeDescriptor-in e vet.
//
// Kjo është në rregull pasi që koha e ekzekutimit të MSVC përdor krahasimin e vargjeve në emrin e llojit që të përputhet me TypeDescriptors sesa barazinë e treguesit.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Shkatërruesi përdoret nëse kodi C++ vendos të kapë përjashtimin dhe ta lëshojë atë pa e përhapur atë.
// Pjesa kapëse e provës së brendshme do ta vendosë fjalën e parë të objektit të përjashtimit në 0 në mënyrë që të anashkalohet nga shkatërruesi.
//
// Vini re se x86 Windows përdor konventën e thirrjeve "thiscall" për funksionet e anëtarëve C++ në vend të konventës së paracaktuar të thirrjeve "C".
//
// Funksioniception_copy është pak i veçantë këtu: ai thirret nga koha e ekzekutimit të MSVC nën një bllok try/catch dhe panic që ne krijojmë këtu do të përdoret si rezultat i kopjes së përjashtimit.
//
// Kjo përdoret nga koha e ekzekutimit të C++ për të mbështetur përjashtimet e kapjes me std::exception_ptr, të cilat nuk mund t'i mbështesim sepse Box<dyn Any>nuk është i klonueshëm
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException ekzekutohet tërësisht në këtë kornizë pirgu, kështu që nuk ka nevojë të transferohet ndryshe `data` në grumbull.
    // Ne thjesht kalojmë një tregues pirgu në këtë funksion.
    //
    // ManualDrop është i nevojshëm këtu pasi nuk duam që Përjashtimi të hiqet kur zgjidhet.
    // Në vend të kësaj, ajo do të bjerë nga përjashtimi_pastrim i cili thirret nga koha e ekzekutimit të C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Kjo ... mund të duket e habitshme, dhe me të drejtë po.Në MSVC 32-bitësh, treguesit midis këtyre strukturës janë pikërisht ai, treguesit.
    // Sidoqoftë, në MSVC 64-bitësh, treguesit ndërmjet strukturave shprehen më tepër si kompensime 32-bitëshe nga `__ImageBase`.
    //
    // Si pasojë, në MSVC 32-bitësh mund të deklarojmë të gjithë këta tregues në `statik` më lart.
    // Në MSVC 64-bitësh, do të na duhet të shprehim zbritjen e treguesve në statikë, gjë që Rust aktualisht nuk i lejon, kështu që nuk mund ta bëjmë atë.
    //
    // Gjëja tjetër më e mirë, atëherë është të plotësoni këto struktura gjatë kohës së ekzekutimit (paniku tashmë është "slow path" gjithsesi).
    // Kështu që këtu ne i interpretojmë të gjitha këto fusha të treguesit si integrues 32-bit dhe më pas ruajmë vlerën përkatëse në të (atomikisht, pasi mund të ndodhë panics njëkohësisht).
    //
    // Teknikisht koha e ekzekutimit ndoshta do të bëjë një lexim joatomik të këtyre fushave, por në teori ato kurrë nuk lexojnë vlerën *e gabuar* kështu që nuk duhet të jetë shumë keq ...
    //
    // Në çdo rast, ne në thelb duhet të bëjmë diçka të tillë derisa të mund të shprehim më shumë operacione në statikë (dhe mund të mos jemi në gjendje kurrë).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Një ngarkesë NULL këtu do të thotë që kemi arritur këtu nga kapja (...) e __rust_try.
    // Kjo ndodh kur kapet një përjashtim i huaj jo-Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Kjo kërkohet nga përpiluesi që të ekzistojë (p.sh., është një element i gjuhës), por nuk quhet kurrë nga përpiluesi sepse __C_specific_handler ose_except_handler3 është funksioni i personalitetit që përdoret gjithmonë.
//
// Prandaj ky është vetëm një cung aborti.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}