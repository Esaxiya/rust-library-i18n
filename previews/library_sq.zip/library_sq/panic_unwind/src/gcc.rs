//! Zbatimi i panics mbështetur nga libgcc/libunwind (në një formë).
//!
//! Për sfond mbi trajtimin e përjashtimeve dhe zgjidhjen e pirgut, ju lutemi shihni "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) dhe dokumentet e lidhura prej tij.
//! Këto janë edhe lexime të mira:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## Një përmbledhje e shkurtër
//!
//! Trajtimi i përjashtimeve ndodh në dy faza: një fazë kërkimi dhe një fazë pastrimi.
//!
//! Në të dy fazat, zhbllokimi ecën në kornizat e pirgut nga lart poshtë duke përdorur informacionin nga korniza e pirgit, lëshoj pjesët e moduleve të procesit aktual ("module" këtu i referohet një moduli OS, dmth., Një bibliotekë e ekzekutueshme ose një dinamike).
//!
//!
//! Për secilën kornizë pirgu, ai thirr "personality routine" të lidhur, adresa e të cilit është ruajtur gjithashtu në seksionin e informacionit të lëshimit.
//!
//! Në fazën e kërkimit, detyra e një rutine të personalitetit është të shqyrtojë objektin e përjashtimit që hidhet dhe të vendosë nëse duhet të kapet në atë kornizë pirgu.Pasi të jetë identifikuar korniza e mbajtësit, fillon faza e pastrimit.
//!
//! Në fazën e pastrimit, paqartësimi thirret përsëri në çdo rutinë të personalitetit.
//! Këtë herë ajo vendos se cili (nëse ka) kod pastrimi duhet të ekzekutohet për kornizën aktuale të pirgut.Nëse është kështu, kontrolli transferohet në një branch të veçantë në trupin e funksionit, "landing pad", i cili thërret destruktorët, çliron kujtesën, etj.
//! Në fund të jastëkut të uljes, kontrolli transferohet përsëri në rinisjet e palëvizshme dhe zhbllokuese.
//!
//! Sapo pirgu të jetë zhbllokuar deri në nivelin e kornizës së mbajtësit, ndalesat e heqjes dhe rutina e fundit e personalitetit transferon kontrollin në bllokun e kapjes.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Identifikuesi i klasës së përjashtimit të Rust.
// Kjo përdoret nga rutinat e personalitetit për të përcaktuar nëse përjashtimi është hedhur nga koha e tyre e ekzekutimit.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-shitësi, gjuha
    0x4d4f5a_00_52555354
}

// Id-të e regjistrit u hoqën nga LLVM's TargetLowering::getExceptionPointerRegister() dhe TargetLowering::getExceptionSelectorRegister() për secilën arkitekturë, pastaj u hodhën në numrat e regjistrit DWARF përmes tabelave të përcaktimit të regjistrit (zakonisht<arch>RegisterInfo.td, kërkoni për "DwarfRegNum").
//
// Shihni gjithashtu http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// Kodi i mëposhtëm bazohet në rutinat e personalitetit të GCC dhe C + C++ .Për referencë, shihni:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM Rutina e personalitetit EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS përdor rutinën e paracaktuar në vend që përdor zbërthimin e SjLj.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Gjurmët e kthyera në ARM do ta quajnë personalitetin rutinë me gjendje==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // Në ato raste, ne duam të vazhdojmë të zgjidhim pirgun, përndryshe të gjitha kthimet tona do të përfundonin në __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF zhvendos supozon se_Unwind_Context mban gjëra të tilla si funksionin dhe treguesit LSDA, megjithatë ARM EHABI i vendos ato në objektin e përjashtimit.
            // Për të ruajtur nënshkrimet e funksioneve si _Unwind_GetLanguageSpecificData(), të cilat marrin vetëm treguesin e kontekstit, rutinat e personalitetit GCC vendosin një tregues në objekt_përjashtim në kontekst, duke përdorur vendndodhjen e rezervuar për ARM's "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... Një qasje më parimore do të ishte të jepnit përkufizimin e plotë të kontekstit_Unwind_të ARM në lidhjet tona në libunwind dhe të merrni të dhënat e kërkuara nga atje drejtpërdrejt, duke anashkaluar funksionet e pajtueshmërisë DWARF.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI kërkon rutinën e personalitetit për të azhurnuar vlerën SP në memorjen e fshehtë të objektit të përjashtimit.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // Në ARM EHABI rutina e personalitetit është përgjegjëse për zgjidhjen e një kornize të vetme pirgu para se të ktheheni (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // të përcaktuara në libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // Rutina e paracaktuar e personalitetit, e cila përdoret drejtpërdrejt në shumicën e objektivave dhe indirekt në Windows x86_64 përmes SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // Në objektivat x86_64 MinGW, mekanizmi i zhbllokimit është SEH megjithatë të dhënat e mbajtësit të lëshimit (aka LSDA) përdor kodimin e pajtueshëm me GCC.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // Rutina e personalitetit për shumicën e synimeve tona.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // Adresa e kthimit tregon 1 bajt pas udhëzimit të thirrjes, i cili mund të jetë në intervalin tjetër IP në tabelën e intervalit LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// Frame lëshoj regjistrimin e informacionit
//
// Imazhi i secilit modul përmban një seksion informacioni për kornizën (zakonisht ".eh_frame").Kur një modul është loaded/unloaded në proces, padëshiruesi duhet të informohet për vendndodhjen e këtij seksioni në memorje.Metodat e arritjes ndryshojnë nga platforma.
// Në disa (p.sh., Linux), padëshiruesi mund të zbulojë seksione informacioni të zhbllokuar më vete (duke numëruar në mënyrë dinamike modulet e ngarkuara aktualisht përmes dl_iterate_phdr() API and finding their ".eh_frame" sections); Të tjerët, si Windows, u kërkojnë module për të regjistruar në mënyrë aktive seksionet e informacionit të tyre të lëshuar përmes API të zhbllokuar.
//
//
// Ky modul përcakton dy simbole të cilave u referohen dhe thirren nga rsbegin.rs për të regjistruar informacionin tonë me kohën e ekzekutimit të GCC.
// Zbatimi i zbërthimit të pirgut (tani për tani) është shtyrë në libgcc_eh, megjithatë Rust crates përdor këto pika hyrëse specifike për Rust për të shmangur përplasjet e mundshme me çdo kohë GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}