//! Po zgjidh panics për Miri.
use alloc::boxed::Box;
use core::any::Any;

// Lloji i ngarkesës së ngarkesës që motori Miri përhapet përmes zgjidhjes për ne.
// Duhet të jetë me madhësi të treguesit.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Funksioni i jashtëm i siguruar nga Miri për të filluar zgjidhjen.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Ngarkesa që ne i kalojmë `miri_start_panic` do të jetë saktësisht argumenti që marrim në `cleanup` më poshtë.
    // Pra, ne vetëm e kuti atë një herë, për të marrë diçka me madhësi të treguesit.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Rikuperoni `Box` themelor.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}