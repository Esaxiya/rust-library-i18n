//! Zbatimi i Rust panics përmes ndërprerjeve të procesit
//!
//! Kur krahasohet me zbatimin përmes zgjidhjes, ky crate është *shumë* më i thjeshtë!Kjo u tha, nuk është aq e shkathët, por këtu shkon!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" ngarkesën dhe shim në ndërprerjen përkatëse në platformën në fjalë.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // telefononi std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Në Windows, përdorni mekanizmin specifik të procesorit __fastfail.Në Windows 8 dhe më vonë, kjo do të përfundojë procesin menjëherë pa ekzekutuar ndonjë mbajtës të përjashtimeve në proces.
            // Në versionet e mëparshme të Windows, kjo sekuencë udhëzimesh do të trajtohet si një shkelje e hyrjes, duke përfunduar procesin, por pa anashkaluar domosdoshmërisht të gjithë mbajtësit e përjashtimeve.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ky është i njëjti zbatim si në `abort_internal` të libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Kjo ... është paksa e çuditshme.Tl; dr;është se kjo kërkohet për të lidhur drejt, shpjegimi më i gjatë është më poshtë.
//
// Tani për tani binaret e libcore/libstd që dërgojmë janë të gjitha të përpiluara me `-C panic=unwind`.Kjo është bërë për të siguruar që binarët të jenë maksimalisht të përputhshëm me sa më shumë situata të jetë e mundur.
// Sidoqoftë, përpiluesi kërkon një "personality function" për të gjitha funksionet e përpiluara me `-C panic=unwind`.Ky funksion i personalitetit është i koduar në simbolin `rust_eh_personality` dhe përcaktohet nga artikulli i gjuhës `eh_personality`.
//
// So...
// pse jo vetëm ta përcaktojmë atë artikull gjuhësor këtu?Pyetje e mirë!Mënyra se si lidhen kohëzgjatjet e panic është në të vërtetë pak delikate pasi që ato janë "sort of" në dyqanin crate të përpiluesit, por lidhen vetëm nëse një tjetër nuk është i lidhur në të vërtetë.
//
// Kjo përfundon duke nënkuptuar që të dyja këto crate dhe panic_unwind crate mund të shfaqen në dyqanin crate të përpiluesit, dhe nëse të dy përcaktojnë artikullin e gjuhës `eh_personality`, atëherë do të ndodhë një gabim.
//
// Për të trajtuar këtë, përpiluesi kërkon vetëm që `eh_personality` të përcaktohet nëse koha e ekzekutimit të panic që lidhet është koha e ndërprerjes, dhe përndryshe nuk kërkohet të përcaktohet (me të drejtë).
// Sidoqoftë, në këtë rast, kjo bibliotekë vetëm e përcakton këtë simbol kështu që ka të paktën diku ndonjë personalitet.
//
// Në thelb, ky simbol është përcaktuar thjesht për tu lidhur me binarë libcore/libstd, por ai kurrë nuk duhet të thirret pasi nuk lidhemi fare në një kohë pa ndërprerje.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Në x86_64-pc-windows-gnu ne përdorim funksionin tonë të personalitetit që duhet të kthejë `ExceptionContinueSearch` ndërsa po kalojmë të gjitha kornizat tona.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Ngjashëm me lart, kjo korrespondon me artikullin e gjuhës `eh_catch_typeinfo` që përdoret vetëm në Emscripten aktualisht.
    //
    // Meqenëse panics nuk gjeneron përjashtime dhe përjashtimet e huaja janë aktualisht UB me -C panic=abort (edhe pse kjo mund të jetë subjekt i ndryshimit), çdo thirrje catch_unwind nuk do ta përdorë kurrë këtë lloj informacioni.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Këta të dy thirren nga objektet tona të fillimit në i686-pc-windows-gnu, por ata nuk kanë nevojë të bëjnë asgjë, në mënyrë që trupat të mos jenë.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}