#![feature(no_core)]
#![no_core]

// Shikoni rustc-std-workspace-core për arsyen pse nevojitet ky crate.

// Riemërtoni crate për të shmangur konfliktin me modulin alokues në liballoc.
extern crate alloc as foo;

pub use foo::*;