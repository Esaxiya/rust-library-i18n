use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Kjo nuk është sipërfaqe e qëndrueshme, por ndihmon në mbajtjen e `?` të lirë mes tyre, edhe nëse LLVM nuk mund ta përfitojë gjithmonë tani.
    //
    // (Mjerisht Rezultati dhe Opsioni nuk janë në përputhje, kështu që ControlFlow nuk mund të përputhet me të dyja.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}