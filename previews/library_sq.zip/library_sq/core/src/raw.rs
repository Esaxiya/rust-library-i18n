#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Përmban përkufizime strukturore për paraqitjen e llojeve të integruara të përpiluesit.
//!
//! Ato mund të përdoren si shënjestra të ndërruesve në kodin e pasigurt për të manipuluar drejtpërdrejt përfaqësimet e papërpunuara.
//!
//!
//! Përkufizimi i tyre duhet të përputhet gjithmonë me ABI të përcaktuar në `rustc_middle::ty::layout`.
//!

/// Paraqitja e një objekti trait si `&dyn SomeTrait`.
///
/// Kjo strukturë ka të njëjtën paraqitje si llojet si `&dyn SomeTrait` dhe `Box<dyn AnotherTrait>`.
///
/// `TraitObject` është e garantuar që të përputhet me paraqitjet, por nuk është lloji i objekteve trait (p.sh., fushat nuk janë të arritshme drejtpërdrejt në një `&dyn SomeTrait`) dhe as nuk kontrollon atë paraqitje (ndryshimi i përkufizimit nuk do të ndryshojë paraqitjen e një `&dyn SomeTrait`).
///
/// Isshtë krijuar vetëm për t'u përdorur nga kodi i pasigurt që duhet të manipulojë detajet e nivelit të ulët.
///
/// Nuk ka asnjë mënyrë për t'iu referuar të gjitha objekteve trait në mënyrë gjenerike, kështu që mënyra e vetme për të krijuar vlera të këtij lloji është me funksione si [`std::mem::transmute`][transmute].
/// Në mënyrë të ngjashme, mënyra e vetme për të krijuar një objekt të vërtetë trait nga një vlerë `TraitObject` është me `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sintetizimi i një objekti trait me lloje të papërshtatshme-ai ku tabela nuk korrespondon me llojin e vlerës në të cilën tregon treguesi i të dhënave-ka shumë të ngjarë të çojë në një sjellje të papërcaktuar.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // një shembull trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // lëreni përpiluesin të bëjë një objekt trait
/// let object: &dyn Foo = &value;
///
/// // shikoni përfaqësimin e papërpunuar
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // treguesi i të dhënave është adresa e `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // ndërtoni një objekt të ri, duke treguar një `i32` tjetër, duke qenë të kujdesshëm për të përdorur tabelën `i32` nga `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // duhet të funksionojë ashtu sikur të kishim ndërtuar një objekt trait direkt nga `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}