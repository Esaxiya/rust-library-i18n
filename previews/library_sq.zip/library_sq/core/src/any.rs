//! Ky modul zbaton `Any` trait, i cili mundëson shtypjen dinamike të çdo lloji `'static` përmes reflektimit të kohës së ekzekutimit.
//!
//! `Any` vetë mund të përdoret për të marrë një `TypeId`, dhe ka më shumë karakteristika kur përdoret si objekt trait.
//! Si `&dyn Any` (një objekt i huazuar trait), ai ka metodat `is` dhe `downcast_ref`, për të provuar nëse vlera e përmbajtur është e një lloji të caktuar, dhe për të marrë një referencë në vlerën e brendshme si një lloj.
//! Si `&mut dyn Any`, ekziston edhe metoda `downcast_mut`, për të marrë një referencë të ndryshueshme ndaj vlerës së brendshme.
//! `Box<dyn Any>` shton metodën `downcast`, e cila përpiqet të shndërrohet në `Box<T>`.
//! Shihni dokumentacionin [`Box`] për detajet e plota.
//!
//! Vini re se `&dyn Any` është e kufizuar në testimin nëse një vlerë është e një lloji të specifikuar betoni dhe nuk mund të përdoret për të provuar nëse një lloj zbaton një trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Tregues të zgjuar dhe `dyn Any`
//!
//! Një sjellje që duhet mbajtur parasysh kur përdorni `Any` si objekt trait, veçanërisht me lloje si `Box<dyn Any>` ose `Arc<dyn Any>`, është se thjesht thirrja e `.type_id()` në vlerë do të prodhojë `TypeId` të kontejnerit *, jo objektit themelor trait.
//!
//! Kjo mund të shmanget duke shndërruar treguesin inteligjent në një `&dyn Any` në vend, i cili do të kthejë `TypeId` të objektit.
//! Për shembull:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Ka më shumë të ngjarë ta dëshironi këtë:
//! let actual_id = (&*boxed).type_id();
//! // ... se kjo:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Konsideroni një situatë ku ne duam të identifikojmë një vlerë të kaluar në një funksion.
//! Ne e dimë vlerën për të cilën po punojmë zbaton Debug, por nuk e dimë llojin e tij konkret.Ne duam t'i japim trajtim të veçantë llojeve të caktuara: në këtë rast shtypja e gjatësisë së vlerave të Vargut para vlerës së tyre.
//! Ne nuk e dimë llojin konkret të vlerës tonë në kohën e përpilimit, prandaj duhet të përdorim reflektimin e kohës së ekzekutimit.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Funksioni logger për çdo lloj që zbaton Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Mundohuni të shndërroni vlerën tonë në një `String`.
//!     // Nëse është i suksesshëm, ne duam të nxjerrim gjatësinë e Vargut si dhe vlerën e tij.
//!     // Nëse jo, është një lloj tjetër: thjesht shtypeni atë pa zbukurim.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ky funksion dëshiron të regjistrojë parametrin e tij para se të bëjë punë me të.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... bëj ndonjë punë tjetër
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Çdo trait
///////////////////////////////////////////////////////////////////////////////

/// Një trait për të imituar shtypjen dinamike.
///
/// Shumica e llojeve implementojnë `Any`.Sidoqoftë, çdo lloj tipi që përmban një referencë jo-'' statike '' nuk përmban.
/// Shihni [module-level documentation][mod] për më shumë detaje.
///
/// [mod]: crate::any
// Ky trait nuk është i pasigurt, megjithëse ne mbështetemi në specifikat e funksionit `type_id` të implikimit të tij të vetëm në kodin e pasigurt (p.sh., `downcast`).Normalisht, ky do të ishte një problem, por për shkak se implikimi i vetëm i `Any` është një zbatim batanije, asnjë kod tjetër nuk mund të zbatojë `Any`.
//
// Ne mund ta bëjmë me siguri këtë trait të pasigurt-nuk do të shkaktojë prishje, pasi ne kontrollojmë të gjitha implementimet-por ne zgjedhim të mos bëjmë pasi që të dyja nuk janë me të vërtetë të nevojshme dhe mund të ngatërrojnë përdoruesit për dallimin e metodave të pasigurta traits dhe të pasigurta (dmth., `type_id` do të ishte akoma i sigurt për t'u thirrur, por ne me siguri do të dëshironim të tregonim si të tillë në dokumentacion).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Merr `TypeId` të `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Metodat e zgjatjes për çdo objekt trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Sigurohuni që rezultati i p.sh., bashkimi i një fije mund të shtypet dhe kështu të përdoret me `unwrap`.
// Në fund të fundit mund të mos jetë më e nevojshme nëse dërgimi funksionon me ngritjen.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Kthen `true` nëse lloji me kuti është i njëjtë me `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Merrni `TypeId` të llojit me të cilin kryhet ky funksion.
        let t = TypeId::of::<T>();

        // Merrni `TypeId` të llojit në objektin trait (`self`).
        let concrete = self.type_id();

        // Krahasoni të dy `TypeId` për barazinë.
        t == concrete
    }

    /// Kthen disa referenca në vlerën e kutive nëse është e llojit `T`, ose `None` nëse nuk është.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SIGURIA: sapo kemi kontrolluar nëse po tregojmë për llojin e saktë dhe mund të mbështetemi
            // që kontrollojnë sigurinë e kujtesës sepse kemi zbatuar ndonjë për të gjitha llojet;asnjë implikim tjetër nuk mund të ekzistojë pasi ato do të binin ndesh me ndikimin tonë.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Kthen disa referenca të ndryshueshme në vlerën e kutisë nëse është e llojit `T`, ose `None` nëse nuk është.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SIGURIA: sapo kemi kontrolluar nëse po tregojmë për llojin e saktë dhe mund të mbështetemi
            // që kontrollojnë sigurinë e kujtesës sepse kemi zbatuar ndonjë për të gjitha llojet;asnjë implikim tjetër nuk mund të ekzistojë pasi ato do të binin ndesh me ndikimin tonë.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Përcjell te metoda e përcaktuar në llojin `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Përcjell te metoda e përcaktuar në llojin `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Përcjell te metoda e përcaktuar në llojin `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Përcjell te metoda e përcaktuar në llojin `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Përcjell te metoda e përcaktuar në llojin `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Përcjell te metoda e përcaktuar në llojin `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID dhe metodat e tij
///////////////////////////////////////////////////////////////////////////////

/// Një `TypeId` përfaqëson një identifikues unik global për një lloj.
///
/// Çdo `TypeId` është një objekt i errët i cili nuk lejon inspektimin e asaj që është brenda, por lejon operacione themelore të tilla si klonimi, krahasimi, shtypja dhe shfaqja.
///
///
/// Një `TypeId` aktualisht është i disponueshëm vetëm për llojet që përshkruajnë `'static`, por ky kufizim mund të hiqet në future.
///
/// Ndërsa `TypeId` zbaton `Hash`, `PartialOrd` dhe `Ord`, vlen të përmendet se hashes dhe renditja do të ndryshojnë midis lëshimeve të Rust.
/// Kini kujdes të mbështeteni tek ata brenda kodit tuaj!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Kthen `TypeId` të llojit me të cilin është instancuar funksioni gjenerik.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Kthen emrin e një lloji si një fetë vargu.
///
/// # Note
///
/// Kjo është menduar për përdorim diagnostikues.
/// Përmbajtja e saktë dhe formati i vargut të kthyer nuk specifikohen, përveç të qenit një përshkrim më i mirë i llojit.
/// Për shembull, midis vargjeve që `type_name::<Option<String>>()` mund të kthejë janë `"Option<String>"` dhe `"std::option::Option<std::string::String>"`.
///
///
/// Vargu i kthyer nuk duhet të konsiderohet të jetë një identifikues unik i një lloji pasi shumë lloje mund të hartojnë në të njëjtin emër tipi.
/// Në mënyrë të ngjashme, nuk ka asnjë garanci se të gjitha pjesët e një lloji do të shfaqen në vargun e kthyer: për shembull, specifikuesit e jetës aktualisht nuk përfshihen.
/// Përveç kësaj, rezultati mund të ndryshojë midis versioneve të përpiluesit.
///
/// Implementimi aktual përdor të njëjtën infrastrukturë si diagnostifikimi i përpiluesit dhe debuginfo, por kjo nuk është e garantuar.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Kthen emrin e llojit të vlerës me majë si një fetë vargu.
/// Kjo është e njëjtë me `type_name::<T>()`, por mund të përdoret kur lloji i një ndryshoreje nuk është lehtësisht i disponueshëm.
///
/// # Note
///
/// Kjo është menduar për përdorim diagnostikues.Përmbajtja e saktë dhe formati i vargut nuk janë të specifikuara, përveç të qenit një përshkrim me llojin më të mirë.
/// Për shembull, `type_name_of_val::<Option<String>>(None)` mund të kthejë `"Option<String>"` ose `"std::option::Option<std::string::String>"`, por jo `"foobar"`.
///
/// Përveç kësaj, rezultati mund të ndryshojë midis versioneve të përpiluesit.
///
/// Ky funksion nuk zgjidh objektet trait, që do të thotë se `type_name_of_val(&7u32 as &dyn Debug)` mund të kthejë `"dyn Debug"`, por jo `"u32"`.
///
/// Emri i llojit nuk duhet të konsiderohet një identifikues unik i një lloji;
/// shumë lloje mund të ndajnë të njëjtin emër tipi.
///
/// Implementimi aktual përdor të njëjtën infrastrukturë si diagnostifikimi i përpiluesit dhe debuginfo, por kjo nuk është e garantuar.
///
/// # Examples
///
/// Shtyp llojet e parazgjedhura të integritetit dhe notave.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}