//! traits primitive dhe llojet që përfaqësojnë vetitë themelore të llojeve.
//!
//! Llojet Rust mund të klasifikohen në mënyra të ndryshme të dobishme sipas vetive të tyre të brendshme.
//! Këto klasifikime përfaqësohen si traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Llojet që mund të transferohen përtej kufijve të fijeve.
///
/// Ky trait zbatohet automatikisht kur përpiluesi përcakton se është i përshtatshëm.
///
/// Një shembull i një tipi jo "Dërgoni" është treguesi numërues i referencës [`rc::Rc`][`Rc`].
/// Nëse dy fije përpiqen të klonojnë ['Rc`] ato që tregojnë për të njëjtën vlerë të numëruar si referencë, ata mund të përpiqen të azhurnojnë numërimin e referencës në të njëjtën kohë, e cila është [undefined behavior][ub] sepse [`Rc`] nuk përdor operacione atomike.
///
/// Kushëriri i tij [`sync::Arc`][arc] përdor operacione atomike (duke shkaktuar ca lartësi) dhe kështu është `Send`.
///
/// Shihni [the Nomicon](../../nomicon/send-and-sync.html) për më shumë detaje.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Llojet me një madhësi konstante të njohur në kohën e përpilimit.
///
/// Të gjithë parametrat e tipit kanë një lidhje të nënkuptuar të `Sized`.Sintaksa speciale `?Sized` mund të përdoret për të hequr këtë të lidhur nëse nuk është e përshtatshme.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // strukturë FooUse(Foo<[i32]>);//gabim: Madhësia nuk është implementuar për [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Një përjashtim është lloji i nënkuptuar `Self` i një trait.
/// Një trait nuk ka një `Sized` nënkuptuar të nënkuptuar pasi kjo është e papajtueshme me [objektin trait] ku, sipas përkufizimit, trait duhet të punojë me të gjithë implementuesit e mundshëm, dhe kështu mund të jetë me çdo madhësi.
///
///
/// Edhe pse Rust do t'ju lejojë të lidhni `Sized` me një trait, nuk do të jeni në gjendje ta përdorni atë për të formuar një objekt trait më vonë:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // le y: &dyn Bar= &Impl;//gabim: trait `Bar` nuk mund të bëhet objekt
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // për Default, për shembull, i cili kërkon që `[T]: !Default` të vlerësohet
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Llojet që mund të jenë "unsized" në një lloj me madhësi dinamike.
///
/// Për shembull, lloji i madhësisë me madhësi `[i8; 2]` zbaton `Unsize<[i8]>` dhe `Unsize<dyn fmt::Debug>`.
///
/// Të gjitha implementimet e `Unsize` sigurohen automatikisht nga përpiluesi.
///
/// `Unsize` zbatohet për:
///
/// - `[T; N]` është `Unsize<[T]>`
/// - `T` është `Unsize<dyn Trait>` kur `T: Trait`
/// - `Foo<..., T, ...>` është `Unsize<Foo<..., U, ...>>` nëse:
///   - `T: Unsize<U>`
///   - Foo është një strukturë
///   - Vetëm fusha e fundit e `Foo` ka një lloj që përfshin `T`
///   - `T` nuk është pjesë e llojit të ndonjë fushe tjetër
///   - `Bar<T>: Unsize<Bar<U>>`, nëse fusha e fundit e `Foo` ka llojin `Bar<T>`
///
/// `Unsize` përdoret së bashku me [`ops::CoerceUnsized`] për të lejuar kontejnerët "user-defined" siç është [`Rc`] të përmbajnë lloje me madhësi dinamike.
/// Shihni [DST coercion RFC][RFC982] dhe [the nomicon entry on coercion][nomicon-coerce] për më shumë detaje.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Kërkohet trait për konstante të përdorura në përputhjet e modelit.
///
/// Çdo lloj që nxjerr `PartialEq` zbaton automatikisht këtë trait,*pavarësisht* nëse parametrat e tij të tipit zbatojnë `Eq`.
///
/// Nëse një artikull `const` përmban një lloj që nuk e zbaton këtë trait, atëherë ai tip ose (1.) nuk zbaton `PartialEq` (që do të thotë se konstanta nuk do të sigurojë atë metodë krahasimi, e cila gjenerimi i kodit supozon se është në dispozicion), ose (2.) ajo zbaton *të vetën* Versioni i `PartialEq` (i cili supozojmë se nuk përputhet me një krahasim të barazisë strukturore).
///
///
/// Në secilin nga dy skenarët e mësipërm, ne refuzojmë përdorimin e një konstante të tillë në një përputhje të modelit.
///
/// Shikoni gjithashtu [structural match RFC][RFC1445] dhe [issue 63438] të cilat motivuan migrimin nga modeli i bazuar në atribut në këtë trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Kërkohet trait për konstante të përdorura në përputhjet e modelit.
///
/// Çdo lloj që nxjerr `Eq` zbaton automatikisht këtë trait,*pavarësisht* nëse parametrat e tipit të tij zbatojnë `Eq`.
///
/// Ky është një hak për të funksionuar rreth një kufizimi në sistemin tonë të tipit.
///
/// # Background
///
/// Ne duam të kërkojmë që llojet e përbërjeve të përdorura në përputhjet e modelit të kenë atributin `#[derive(PartialEq, Eq)]`.
///
/// Në një botë më ideale, ne mund ta kontrollojmë atë kërkesë duke kontrolluar vetëm që lloji i dhënë zbaton si `StructuralPartialEq` trait *dhe*`Eq` trait.
/// Sidoqoftë, mund të keni ADT që *bëjnë*`derive(PartialEq, Eq)`, dhe të jeni një rast që duam ta pranojë përpiluesi, e megjithatë lloji i konstantës nuk arrin të implementojë `Eq`.
///
/// Gjegjësisht, një rast si ky:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Problemi në kodin e mësipërm është se `Wrap<fn(&())>` nuk implementon `PartialEq`, as `Eq`, sepse "për <" a> fn(&'a _)` does not implement those traits.)
///
/// Prandaj, ne nuk mund të mbështetemi në kontrollin naiv për `StructuralPartialEq` dhe thjesht `Eq`.
///
/// Si një hak për të funksionuar rreth kësaj, ne përdorim dy traits të veçantë të injektuar nga secila prej dy prejardhjeve (`#[derive(PartialEq)]` dhe `#[derive(Eq)]`) dhe kontrollojmë që të dy ata të jenë të pranishëm si pjesë e kontrollit të përputhjes strukturore.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Llojet vlerat e të cilave mund të kopjohen thjesht duke kopjuar bit.
///
/// Si parazgjedhje, lidhjet e ndryshueshme kanë 'lëviz semantikën'.Me fjale te tjera:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` është zhvendosur në `y` dhe kështu nuk mund të përdoret
///
/// // println! ("{: ?}", x);//gabim: përdorimi i vlerës së lëvizur
/// ```
///
/// Sidoqoftë, nëse një lloj zbaton `Copy`, ai në vend të kësaj ka 'kopjoni semantikë':
///
/// ```
/// // Ne mund të nxjerrim një implementim `Copy`.
/// // `Clone` kërkohet gjithashtu, pasi është një supertrait i `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` është një kopje e `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Importantshtë e rëndësishme të theksohet se në këto dy shembuj, i vetmi ndryshim është nëse ju lejohet të përdorni `x` pas caktimit.
/// Nën kapuç, si një kopje ashtu edhe një lëvizje mund të rezultojë në copëza që kopjohen në kujtesë, edhe pse kjo ndonjëherë optimizohet larg.
///
/// ## Si mund ta implementoj `Copy`?
///
/// Ekzistojnë dy mënyra për të zbatuar `Copy` në llojin tuaj.Më e thjeshtë është përdorimi i `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Ju gjithashtu mund të implementoni `Copy` dhe `Clone` manualisht:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Ekziston një ndryshim i vogël midis të dyve: strategjia `derive` gjithashtu do të vendosë një `Copy` të lidhur me parametrat e tipit, i cili nuk është gjithmonë i dëshiruar.
///
/// ## Cili është ndryshimi midis `Copy` dhe `Clone`?
///
/// Kopjet ndodhin në mënyrë implicite, për shembull si pjesë e një detyre `y = x`.Sjellja e `Copy` nuk është e mbingarkuar;është gjithmonë një kopje e thjeshtë pak e mençur.
///
/// Klonimi është një veprim i qartë, `x.clone()`.Zbatimi i [`Clone`] mund të sigurojë çdo sjellje specifike të tipit e nevojshme për të kopjuar vlerat në mënyrë të sigurt.
/// Për shembull, implementimi i [`Clone`] për [`String`] duhet të kopjojë buffer-in e vargut me majë në tog.
/// Një kopje e thjeshtë me bit e vlerave [`String`] thjesht do të kopjonte treguesin, duke çuar në një të dyfishtë të lirë poshtë vijës.
/// Për këtë arsye, [`String`] është [`Clone`] por jo `Copy`.
///
/// [`Clone`] është një supertrait i `Copy`, kështu që gjithçka që është `Copy` duhet gjithashtu të zbatojë [`Clone`].
/// Nëse një lloj është `Copy`, atëherë implementimi i tij [`Clone`] duhet vetëm të kthejë `*self` (shih shembullin e mësipërm).
///
/// ## Kur lloji im mund të jetë `Copy`?
///
/// Një lloj mund të implementojë `Copy` nëse të gjithë përbërësit e tij implementojnë `Copy`.Për shembull, kjo strukturë mund të jetë `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Një strukturë mund të jetë `Copy`, dhe [`i32`] është `Copy`, prandaj `Point` ka të drejtë të jetë `Copy`.
/// Në të kundërt, merrni parasysh
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struktura `PointList` nuk mund të implementojë `Copy`, sepse [`Vec<T>`] nuk është `Copy`.Nëse përpiqemi të nxjerrim një zbatim `Copy`, do të kemi një gabim:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Referencat e përbashkëta (`&T`) janë gjithashtu `Copy`, kështu që një lloj mund të jetë `Copy`, edhe kur mban referenca të përbashkëta të llojeve `T` që *nuk janë*`Copy`.
/// Merrni parasysh strukturën e mëposhtme, e cila mund të zbatojë `Copy`, sepse mban vetëm një *referencë të përbashkët* për llojin tonë jo-"Kopjoni" `PointList` nga lart:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kur *nuk mund* lloji im të jetë `Copy`?
///
/// Disa lloje nuk mund të kopjohen në mënyrë të sigurt.Për shembull, kopjimi i `&mut T` do të krijonte një referencë aliazme të ndryshueshme.
/// Kopjimi i [`String`] do të kopjonte përgjegjësinë për menaxhimin e buffer-it ["String"], duke çuar në një të dyfishtë falas.
///
/// Përgjithësimi i rastit të fundit, çdo lloj që zbaton [`Drop`] nuk mund të jetë `Copy`, sepse po menaxhon disa burime përveç bajteve të tij [`size_of::<T>`].
///
/// Nëse përpiqeni të implementoni `Copy` në një strukturë ose enum që përmban të dhëna jo "Kopjoni", do të merrni gabimin [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kur *duhet* lloji im të jetë `Copy`?
///
/// Në përgjithësi, nëse lloji juaj _can_ zbaton `Copy`, duhet.
/// Mbani në mend, sidoqoftë, që implementimi i `Copy` është pjesë e API-ve publike të llojit tuaj.
/// Nëse lloji mund të bëhet jo "Kopjimi" në future, do të ishte e kujdesshme të hiqet zbatimi `Copy` tani, për të shmangur një ndryshim të prishur të API.
///
/// ## Zbatuesit shtesë
///
/// Përveç [implementors listed below][impls], llojet e mëposhtme gjithashtu implementojnë `Copy`:
///
/// * Llojet e artikujve të funksioneve (d.m.th., llojet e dallueshme të përcaktuara për secilin funksion)
/// * Llojet e treguesit të funksionit (p.sh., `fn() -> i32`)
/// * Llojet e grupeve, për të gjitha madhësitë, nëse lloji i artikullit zbaton gjithashtu `Copy` (p.sh., `[i32; 123456]`)
/// * Llojet e dyfishta, nëse secili komponent zbaton gjithashtu `Copy` (p.sh., `()`, `(i32, bool)`)
/// * Llojet e mbylljes, nëse nuk kapin asnjë vlerë nga mjedisi ose nëse të gjitha vlerat e tilla të kapura zbatojnë vetë `Copy`.
///   Vini re se variablat e kapur nga referenca e përbashkët gjithmonë zbatojnë `Copy` (edhe nëse referenca nuk e bën), ndërsa ndryshoret e kapura nga referenca e ndryshueshme kurrë nuk zbatojnë `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Kjo lejon kopjimin e një lloji që nuk zbaton `Copy` për shkak të kufijve të pakënaqur të jetës (kopjimi i `A<'_>` kur vetëm `A<'static>: Copy` dhe `A<'_>: Clone`).
// Këtë tipar e kemi tani për tani vetëm sepse ekzistojnë mjaft specializime ekzistuese në `Copy` që ekzistojnë tashmë në bibliotekën standarde dhe nuk ka asnjë mënyrë për ta pasur këtë sjellje të sigurt tani.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Nxjerr makro që gjeneron një impl të trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Llojet për të cilat është e sigurt të ndahen referencat midis fijeve.
///
/// Ky trait zbatohet automatikisht kur përpiluesi përcakton se është i përshtatshëm.
///
/// Përkufizimi i saktë është: një lloj `T` është [`Sync`] nëse dhe vetëm nëse `&T` është [`Send`].
/// Me fjalë të tjera, nëse nuk ka mundësi të [undefined behavior][ub] (përfshirë garat e të dhënave) kur kaloni referencat `&T` midis fijeve.
///
/// Siç mund të pritej, tipat primitivë si [`u8`] dhe [`f64`] janë të gjithë [`Sync`], dhe kështu janë llojet e thjeshta agregate që i përmbajnë ato, si tupla, strofa dhe enum.
/// Më shumë shembuj të llojeve themelore [`Sync`] përfshijnë lloje "immutable" si `&T`, dhe ato me ndryshueshmëri të thjeshtë të trashëguar, të tilla si [`Box<T>`][box], [`Vec<T>`][vec] dhe shumica e llojeve të tjerë të koleksionit.
///
/// (Parametrat gjenerikë duhet të jenë [`Sync`] që kontejnerët e tyre të jenë ["Sinkronizo"].)
///
/// Një pasojë disi e habitshme e përkufizimit është që `&mut T` është `Sync` (nëse `T` është `Sync`) edhe pse duket sikur kjo mund të sigurojë mutacion të painkronizuar.
/// Qëllimi është që një referencë e paqëndrueshme prapa një reference të përbashkët (domethënë `& &mut T`) bëhet vetëm për lexim, sikur të ishte një `& &T`.
/// Prandaj nuk ka rrezik të një gare të dhënash.
///
/// Llojet që nuk janë `Sync` janë ato që kanë "interior mutability" në një formë jo-fije të sigurt, të tilla si [`Cell`][cell] dhe [`RefCell`][refcell].
/// Këto lloje lejojnë mutacionin e përmbajtjes së tyre edhe përmes një reference të pandryshueshme, të përbashkët.
/// Për shembull, metoda `set` në [`Cell<T>`][cell] merr `&self`, kështu që kërkon vetëm një referencë të përbashkët [`&Cell<T>`][cell].
/// Metoda nuk kryen asnjë sinkronizim, kështu që [`Cell`][cell] nuk mund të jetë `Sync`.
///
/// Një shembull tjetër i një lloji jo "Sync" është treguesi [`Rc`][rc] i numërimit të referencave.
/// Duke pasur parasysh çdo referencë [`&Rc<T>`][rc], ju mund të klononi një [`Rc<T>`][rc] të ri, duke modifikuar numrin e referencave në një mënyrë jo-atomike.
///
/// Për rastet kur dikush ka nevojë për ndryshueshmëri të brendshme të sigurt me fije, Rust siguron [atomic data types], si dhe mbyllje të qartë përmes [`sync::Mutex`][mutex] dhe [`sync::RwLock`][rwlock].
/// Këto lloje sigurojnë që çdo mutacion nuk mund të shkaktojë gara të dhënash, prandaj llojet janë `Sync`.
/// Po kështu, [`sync::Arc`][arc] siguron një analog të fijeve të [`Rc`][rc].
///
/// Çdo tip me ndryshueshmëri të brendshme duhet të përdorë gjithashtu mbështjellësin [`cell::UnsafeCell`][unsafecell] rreth value(s) i cili mund të shndërrohet përmes një reference të përbashkët.
/// Dështimi për ta bërë këtë është [undefined behavior][ub].
/// Për shembull, [`transmute`][transmute]-ing nga `&T` në `&mut T` është e pavlefshme.
///
/// Shihni [the Nomicon][nomicon-send-and-sync] për më shumë detaje në lidhje me `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): një herë mbështetje për të shtuar shënime në vendet `rustc_on_unimplemented` në beta, dhe është zgjeruar për të kontrolluar nëse një mbyllje është diku në zinxhirin e kërkesave, zgjaseni atë si të tillë (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Lloji me madhësi zero përdoret për të shënuar gjërat që "act like" kanë në pronësi një `T`.
///
/// Shtimi i një fushe `PhantomData<T>` në llojin tuaj i tregon përpiluesit se lloji juaj vepron sikur ruan një vlerë të tipit `T`, edhe pse në të vërtetë nuk ndodh.
/// Ky informacion përdoret kur llogaritni veti të caktuara të sigurisë.
///
/// Për një shpjegim më të thelluar se si të përdorni `PhantomData<T>`, ju lutemi shikoni [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Një shënim i kobshëm
///
/// Megjithëse të dy kanë emra të frikshëm, `PhantomData` dhe 'llojet fantazmë' janë të lidhura, por jo identike.Një parametër i tipit fantazmë është thjesht një parametër tipi që nuk përdoret kurrë.
/// Në Rust, kjo shpesh bën që ankesa të përpilohet, dhe zgjidhja është të shtoni një përdorim "dummy" përmes `PhantomData`.
///
/// # Examples
///
/// ## Parametrat e jetës së papërdorur
///
/// Ndoshta rasti më i zakonshëm i përdorimit për `PhantomData` është një strukturë që ka një parametër të papërdorur të jetës, zakonisht si pjesë e disa kodeve të pasigurta.
/// Për shembull, këtu është një strukturë `Slice` që ka dy tregues të tipit `*const T`, me sa duket duke drejtuar në një grup diku:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Qëllimi është që të dhënat themelore të jenë të vlefshme vetëm për jetën `'a`, kështu që `Slice` nuk duhet të mbijetojë më shumë se `'a`.
/// Sidoqoftë, ky synim nuk shprehet në kod, pasi që nuk ka përdorime të jetës `'a` dhe prandaj nuk është e qartë se për çfarë të dhënash zbatohet.
/// Ne mund ta korrigjojmë këtë duke i thënë përpiluesit që të veprojë *sikur* struktura `Slice` të përmbajë një referencë `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Kjo gjithashtu nga ana tjetër kërkon shënimin `T: 'a`, duke treguar që çdo referencë në `T` është e vlefshme gjatë gjithë jetës `'a`.
///
/// Kur inicializoni një `Slice` thjesht siguroni vlerën `PhantomData` për fushën `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Parametrat e tipit të papërdorur
///
/// Ndonjëherë ndodh që të keni parametra të tipit të papërdorur, të cilët tregojnë se në çfarë lloji të të dhënave është një strukturë "tied", edhe pse ato të dhëna nuk gjenden në të vërtetë në vetë strukturën.
/// Këtu është një shembull ku kjo lind me [FFI].
/// Ndërfaqja e huaj përdor dorezat e tipit `*mut ()` për t'iu referuar vlerave Rust të llojeve të ndryshme.
/// Ne ndjekim llojin Rust duke përdorur një parametër të tipit fantazmë në strukturën `ExternalResource` e cila mbështjell një dorezë.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Pronësia dhe kontrolli i rënies
///
/// Shtimi i një fushe të tipit `PhantomData<T>` tregon që lloji juaj zotëron të dhëna të tipit `T`.Kjo nga ana tjetër nënkupton që kur lloji juaj bie, ai mund të bjerë një ose më shumë shembuj të llojit `T`.
/// Kjo ka ndikim në analizën [drop check] të përpiluesit Rust.
///
/// Nëse struktura juaj nuk i zotëron *të dhënat e tipit `T`, është më mirë të përdorni një lloj reference, si `PhantomData<&'a T>` (ideally) ose `PhantomData<* const T>` (nëse nuk zbatohet jetëgjatësi), në mënyrë që të mos tregoni pronësinë.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Përpiluesi i brendshëm trait përdoret për të treguar llojin e diskriminuesve të enumit.
///
/// Ky trait zbatohet automatikisht për çdo lloj dhe nuk shton asnjë garanci për [`mem::Discriminant`].
/// **Shtë** sjellje e papërcaktuar ** për të transmutuar midis `DiscriminantKind::Discriminant` dhe `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Lloji i diskriminuesit, i cili duhet të plotësojë trait bounds të kërkuara nga `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Përpiluesi i brendshëm trait përdoret për të përcaktuar nëse një lloj përmban ndonjë `UnsafeCell` brenda, por jo përmes një indirekte.
///
/// Kjo ndikon, për shembull, nëse një `static` i këtij lloji vendoset në memorje statike vetëm për lexim ose memorje statike të shkruajtshme.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Llojet që mund të zhvendosen në mënyrë të sigurt pasi të mbërthehen.
///
/// Vetë Rust nuk ka nocion për lloje të paluajtshme dhe i konsideron lëvizjet (p.sh. përmes caktimit ose [`mem::replace`]) të jenë gjithmonë të sigurta.
///
/// Lloji [`Pin`][Pin] përdoret në vend të kësaj për të parandaluar lëvizjet përmes sistemit të tipit.Treguesit `P<T>` të mbështjellë me mbështjellësin [`Pin<P<T>>`][Pin] nuk mund të zhvendosen nga.
/// Shihni dokumentacionin [`pin` module] për më shumë informacion mbi afishimin.
///
/// Zbatimi i `Unpin` trait për `T` heq kufizimet e fiksimit të llojit, i cili më pas lejon lëvizjen e `T` nga [`Pin<P<T>>`][Pin] me funksione të tilla si [`mem::replace`].
///
///
/// `Unpin` nuk ka aspak pasoja për të dhënat jo të fiksuara.
/// Në veçanti, [`mem::replace`] lëviz me gëzim të dhëna `!Unpin` (punon për çdo `&mut T`, jo vetëm kur `T: Unpin`).
/// Sidoqoftë, nuk mund të përdorni [`mem::replace`] në të dhëna të mbështjellura brenda një [`Pin<P<T>>`][Pin] sepse nuk mund të merrni `&mut T` që ju nevojitet për këtë, dhe *kjo* është ajo që e bën këtë sistem të funksionojë.
///
/// Kështu që, për shembull, mund të bëhet vetëm në llojet që zbatojnë `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Na duhet një referencë e ndryshueshme për të thirrur `mem::replace`.
/// // Ne mund të marrim një referencë të tillë duke (implicitly) duke u thirrur në `Pin::deref_mut`, por kjo është e mundur vetëm sepse `String` zbaton `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Ky trait zbatohet automatikisht për pothuajse çdo lloj.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Një tip shënues i cili nuk implementon `Unpin`.
///
/// Nëse një lloj përmban një `PhantomPinned`, ai nuk do të zbatojë `Unpin` si parazgjedhje.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Zbatimet e `Copy` për llojet primitive.
///
/// Zbatimet që nuk mund të përshkruhen në Rust zbatohen në `traits::SelectionContext::copy_clone_conditions()` në `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Referencat e ndara mund të kopjohen, por referencat e ndryshueshme *nuk munden*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}