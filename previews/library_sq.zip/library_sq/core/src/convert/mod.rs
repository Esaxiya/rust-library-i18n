//! Traits për shndërrimet midis llojeve.
//!
//! traits në këtë modul ofrojnë një mënyrë për të kthyer nga një lloj në një lloj tjetër.
//! Çdo trait shërben për një qëllim të ndryshëm:
//!
//! - Zbatoni [`AsRef`] trait për shndërrime të lira referimi-në-referencë
//! - Zbatoni [`AsMut`] trait për shndërrime të lira të ndryshueshme nga të ndryshueshme
//! - Zbatoni [`From`] trait për konsumimin e shndërrimeve nga vlera në vlerë
//! - Zbatoni [`Into`] trait për të konsumuar shndërrime vlera në vlerë në lloje jashtë crate aktuale
//! - [`TryFrom`] dhe [`TryInto`] traits sillen si [`From`] dhe [`Into`], por duhet të zbatohen kur shndërrimi mund të dështojë.
//!
//! traits në këtë modul shpesh përdoren si trait bounds për funksione gjenerike të tilla që argumentet e llojeve të shumta mbështeten.Shihni dokumentacionin e secilës trait për shembuj.
//!
//! Si autor i bibliotekës, gjithmonë duhet të preferoni zbatimin e [`From<T>`][`From`] ose [`TryFrom<T>`][`TryFrom`] sesa [`Into<U>`][`Into`] ose [`TryInto<U>`][`TryInto`], pasi [`From`] dhe [`TryFrom`] sigurojnë një fleksibilitet më të madh dhe ofrojnë zbatime ekuivalente [`Into`] ose [`TryInto`] falas, falë një zbatimi batanije në bibliotekën standarde.
//! Kur synoni një version para Rust 1.41, mund të jetë e nevojshme të zbatoni [`Into`] ose [`TryInto`] direkt kur konvertoheni në një lloj jashtë crate aktual.
//!
//! # Zbatimet e përgjithshme
//!
//! - [`AsRef`] dhe auto-riferencimi [`AsMut`] nëse lloji i brendshëm është referencë
//! - [`Nga`]`<U>për T` nënkupton [`Në``)``</u><T><U>për U`</u>
//! - [`TryFrom`]`<U>për T` nënkupton [`TryInto`] '</u><T><U>për U`</u>
//! - [`From`] dhe [`Into`] janë reflektive, që do të thotë se të gjitha llojet mund të `into` vetë dhe `from` vetë
//!
//! Shihni secilin trait për shembuj të përdorimit.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Funksioni i identitetit.
///
/// Dy gjëra janë të rëndësishme të theksohen në lidhje me këtë funksion:
///
/// - Nuk është gjithmonë ekuivalente me një mbyllje si `|x| x`, pasi mbyllja mund të detyrojë `x` në një lloj tjetër.
///
/// - Ai zhvendos hyrjen `x` të kaluar në funksion.
///
/// Ndërsa mund të duket e çuditshme të kesh një funksion që thjesht kthen inputin, ka disa përdorime interesante.
///
///
/// # Examples
///
/// Përdorimi i `identity` për të mos bërë asgjë në një sekuencë funksionesh të tjera, interesante:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Le të pretendojmë se shtimi i një është një funksion interesant.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Përdorimi i `identity` si një rast bazë "do nothing" në një kusht:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Bëni gjëra më interesante ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Përdorimi i `identity` për të mbajtur variantet `Some` të një iteratori të `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Përdoret për të bërë një shndërrim të lirë referimi në referencë.
///
/// Ky trait është i ngjashëm me [`AsMut`] i cili përdoret për konvertimin midis referencave të ndryshueshme.
/// Nëse keni nevojë të bëni një shndërrim të kushtueshëm është më mirë të zbatoni [`From`] me llojin `&T` ose të shkruani një funksion të personalizuar.
///
/// `AsRef` ka të njëjtën nënshkrim si [`Borrow`], por [`Borrow`] është i ndryshëm në disa aspekte:
///
/// - Ndryshe nga `AsRef`, [`Borrow`] ka një batanije për çdo `T` dhe mund të përdoret për të pranuar ose një referencë ose një vlerë.
/// - [`Borrow`] gjithashtu kërkon që [`Hash`], [`Eq`] dhe [`Ord`] për vlerën e huazuar të jenë ekuivalente me ato të vlerës së zotëruar.
/// Për këtë arsye, nëse dëshironi të merrni hua vetëm një fushë të vetme të një strukture, ju mund të implementoni `AsRef`, por jo [`Borrow`].
///
/// **Note: Ky trait nuk duhet të dështojë **.Nëse konvertimi mund të dështojë, përdorni një metodë të dedikuar e cila kthen një [`Option<T>`] ose një [`Result<T, E>`].
///
/// # Zbatimet e përgjithshme
///
/// - `AsRef` rivendosjet automatike nëse lloji i brendshëm është një referencë ose një referencë e ndryshueshme (p.sh .: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Duke përdorur trait bounds ne mund të pranojmë argumente të llojeve të ndryshme për sa kohë që ato mund të shndërrohen në llojin e specifikuar `T`.
///
/// Për shembull: Duke krijuar një funksion të përgjithshëm që merr një `AsRef<str>` ne shprehim se duam të pranojmë të gjitha referencat që mund të shndërrohen në [`&str`] si argument.
/// Meqenëse të dy [`String`] dhe [`&str`] implementojnë `AsRef<str>` ne mund t'i pranojmë të dyja si argument hyrës.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Kryen shndërrimin.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Përdoret për të bërë një shndërrim të lirë të referencës të ndryshueshme nga të ndryshueshme.
///
/// Ky trait është i ngjashëm me [`AsRef`] por përdoret për shndërrimin midis referencave të ndryshueshme.
/// Nëse keni nevojë të bëni një shndërrim të kushtueshëm është më mirë të zbatoni [`From`] me llojin `&mut T` ose të shkruani një funksion të personalizuar.
///
/// **Note: Ky trait nuk duhet të dështojë **.Nëse konvertimi mund të dështojë, përdorni një metodë të dedikuar e cila kthen një [`Option<T>`] ose një [`Result<T, E>`].
///
/// # Zbatimet e përgjithshme
///
/// - `AsMut` rivendosjet automatike nëse lloji i brendshëm është një referencë e ndryshueshme (p.sh.: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Duke përdorur `AsMut` si trait bound për një funksion gjenerik mund të pranojmë të gjitha referencat e ndryshueshme që mund të shndërrohen në llojin `&mut T`.
/// Për shkak se [`Box<T>`] zbaton `AsMut<T>` ne mund të shkruajmë një funksion `add_one` që merr të gjitha argumentet që mund të shndërrohen në `&mut u64`.
/// Për shkak se [`Box<T>`] zbaton `AsMut<T>`, `add_one` gjithashtu pranon argumente të tipit `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Kryen shndërrimin.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Një shndërrim vlera në vlerë që konsumon vlerën e hyrjes.E kundërta e [`From`].
///
/// Duhet shmangur implementimi i [`Into`] dhe në vend të tij të zbatohet [`From`].
/// Implementimi i [`From`] automatikisht siguron një me një implementim të [`Into`] falë implementimit të batanijes në bibliotekën standarde.
///
/// Preferoni të përdorni [`Into`] mbi [`From`] kur specifikoni trait bounds në një funksion të përgjithshëm për të siguruar që llojet që zbatojnë vetëm [`Into`] të mund të përdoren gjithashtu.
///
/// **Note: Ky trait nuk duhet të dështojë **.Nëse konvertimi mund të dështojë, përdorni [`TryInto`].
///
/// # Zbatimet e përgjithshme
///
/// - ["Nga"] "<T>për U` nënkupton `Into<U> for T`
/// - [`Into`] është refleksiv, që do të thotë se `Into<T> for T` është implementuar
///
/// # Zbatimi i [`Into`] për shndërrimet në lloje të jashtëm në versionet e vjetra të Rust
///
/// Para Rust 1.41, nëse lloji i destinacionit nuk ishte pjesë e crate aktual, atëherë nuk mund të zbatonit [`From`] direkt.
/// Për shembull, merrni këtë kod:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Kjo do të dështojë të përpilohet në versionet e vjetra të gjuhës, sepse rregullat e jetimit të Rust kanë qenë pak më të rrepta.
/// Për ta anashkaluar këtë, mund të implementoni [`Into`] drejtpërdrejt:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Importantshtë e rëndësishme të kuptohet që [`Into`] nuk siguron një zbatim [`From`] (siç bën [`From`] me [`Into`]).
/// Prandaj, gjithmonë duhet të përpiqeni të zbatoni [`From`] dhe pastaj të riktheheni përsëri në [`Into`] nëse [`From`] nuk mund të implementohet.
///
/// # Examples
///
/// [`String`] zbaton ["Në"] "<" ["Vec"] "<" ["u8"] ">>":
///
/// Në mënyrë që të shprehim se duam një funksion të përgjithshëm për të marrë të gjitha argumentet që mund të shndërrohen në një lloj të specifikuar `T`, ne mund të përdorim një trait bound të ["Into"]<T>`
///
/// Për shembull: Funksioni `is_hello` merr të gjitha argumentet që mund të shndërrohen në një ["Vec"] "<" ["u8"] ">".
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Kryen shndërrimin.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Përdoret për të bërë shndërrime vlera në vlerë gjatë konsumimit të vlerës së hyrjes.Isshtë reciproke e [`Into`].
///
/// Gjithmonë duhet të preferohet implementimi i `From` sesa [`Into`] sepse implementimi i `From` automatikisht i siguron një zbatim të [`Into`] falë implementimit të batanijes në bibliotekën standarde.
///
///
/// Zbatoni [`Into`] vetëm kur synoni një version para Rust 1.41 dhe konvertimin në një lloj jashtë crate aktual.
/// `From` nuk ishte në gjendje të bënte këto lloj shndërrimesh në versionet e mëparshme për shkak të rregullave të jetimit të Rust.
/// Shihni [`Into`] për më shumë detaje.
///
/// Preferoni përdorimin e [`Into`] sesa përdorimin e `From` kur specifikoni trait bounds në një funksion të përgjithshëm.
/// Në këtë mënyrë, llojet që implementojnë drejtpërdrejt [`Into`] mund të përdoren gjithashtu si argumente.
///
/// `From` është gjithashtu shumë i dobishëm kur kryeni trajtimin e gabimeve.Kur ndërtohet një funksion që është i aftë të dështojë, tipi i kthimit zakonisht do të jetë i formës `Result<T, E>`.
/// `From` trait thjeshton trajtimin e gabimeve duke lejuar një funksion të kthejë një tip të vetëm gabimi që përmbledh lloje të shumta gabimesh.Shihni seksionin "Examples" dhe [the book][book] për më shumë detaje.
///
/// **Note: Ky trait nuk duhet të dështojë **.Nëse konvertimi mund të dështojë, përdorni [`TryFrom`].
///
/// # Zbatimet e përgjithshme
///
/// - `From<T> for U` nënkupton [`Into`]`<U>për T`</u>
/// - `From` është refleksiv, që do të thotë se `From<T> for T` është implementuar
///
/// # Examples
///
/// [`String`] zbaton `From<&str>`:
///
/// Një shndërrim i qartë nga një `&str` në një Varg bëhet si më poshtë:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Ndërsa kryeni trajtimin e gabimeve, shpesh është e dobishme të zbatoni `From` për llojin tuaj të gabimit.
/// Duke konvertuar llojet e gabimeve themelore në llojin tonë personal të gabimit që përmbledh llojin e gabimit themelor, ne mund të kthejmë një tip të vetëm gabimi pa humbur informacionin për shkakun themelor.
/// Operatori '?' automatikisht shndërron llojin themelor të gabimit në llojin tonë të personalizuar të gabimit duke telefonuar `Into<CliError>::into` i cili sigurohet automatikisht kur implementon `From`.
/// Përpiluesi pastaj nxjerr përfundimin se cili implementim i `Into` duhet të përdoret.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Kryen shndërrimin.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Një tentim shndërrimi që konsumon `self`, i cili mund të jetë i kushtueshëm ose jo.
///
/// Autorët e bibliotekës zakonisht nuk duhet ta zbatojnë drejtpërdrejt këtë trait, por duhet të preferojnë zbatimin e [`TryFrom`] trait, i cili ofron një fleksibilitet më të madh dhe siguron një zbatim ekuivalent `TryInto` falas, falë një zbatimi batanije në bibliotekën standarde.
/// Për më shumë informacion mbi këtë, shihni dokumentacionin për [`Into`].
///
/// # Zbatimi i `TryInto`
///
/// Kjo vuan të njëjtat kufizime dhe arsyetime si zbatimi i [`Into`], shih atje për detaje.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Lloji i kthyer në rast të një gabimi konvertimi.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Kryen shndërrimin.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Konvertime të tipit të thjeshtë dhe të sigurt që mund të dështojnë në një mënyrë të kontrolluar në disa rrethana.Isshtë reciproke e [`TryInto`].
///
/// Kjo është e dobishme kur jeni duke bërë një konvertim tipi që mund të ketë sukses të parëndësishëm, por gjithashtu mund të ketë nevojë për trajtim të veçantë.
/// Për shembull, nuk ka asnjë mënyrë për të kthyer një [`i64`] në një [`i32`] duke përdorur [`From`] trait, sepse një [`i64`] mund të përmbajë një vlerë që një [`i32`] nuk mund ta përfaqësojë dhe kështu konvertimi do të humbte të dhëna.
///
/// Kjo mund të trajtohet duke shkurtuar [`i64`] në një [`i32`] (në thelb duke i dhënë modulit me vlerë [i64 "] [`i32::MAX`]) ose thjesht duke kthyer [`i32::MAX`], ose me ndonjë metodë tjetër.
/// [`From`] trait është menduar për shndërrime perfekte, kështu që `TryFrom` trait informon programuesin kur një konvertim i tipit mund të shkojë keq dhe i lejon ata të vendosin se si ta trajtojnë atë.
///
/// # Zbatimet e përgjithshme
///
/// - `TryFrom<T> for U` nënkupton [`TryInto`]`<U>për T`</u>
/// - [`try_from`] është refleksiv, që do të thotë se `TryFrom<T> for T` është implementuar dhe nuk mund të dështojë-lloji `Error` i shoqëruar për thirrjen `T::try_from()` në një vlerë të tipit `T` është [`Infallible`].
/// Kur lloji [`!`] të stabilizohet, [`Infallible`] dhe [`!`] do të jenë ekuivalente.
///
/// `TryFrom<T>` mund të zbatohet si më poshtë:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Siç përshkruhet, [`i32`] zbaton "TryFrom <" ["i64"] ">:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Në heshtje shkurton `big_number`, kërkon zbulimin dhe trajtimin e cungimit pas faktit.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Kthen një gabim sepse `big_number` është shumë i madh për t'u futur në një `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Kthen `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Lloji i kthyer në rast të një gabimi konvertimi.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Kryen shndërrimin.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// NDIKIMET GJENERIKE
////////////////////////////////////////////////////////////////////////////////

// Ndërsa heq mbi&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Ndërsa heq mbi &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): zëvendësoni nënkuptimet e mësipërme për&/&mut me atë më të përgjithshme të mëposhtme:
// // Ndërsa ashensorët mbi Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Me madhësi> AsRef <U>për D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut heq mbi &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): zëvendësoni nënkuptimin e mësipërm për &mut me atë më të përgjithshme të mëposhtme:
// // AsMut heq mbi DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Me madhësi> AsMut <U>për D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Nga nënkupton në
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Nga (dhe kështu në) është refleksiv
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Shënim i stabilitetit:** Ky implikim ende nuk ekziston, por ne jemi "reserving space" për ta shtuar atë në future.
/// Shihni [rust-lang/rust#64715][#64715] për detaje.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): në vend të kësaj bëni një rregullim parimor.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom nënkupton TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Konvertimet e pagabueshme janë semantikisht ekuivalente me konvertimet e gabueshme me një lloj gabimi të pabanuar.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS BETONI
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// LLOJI I GABIMIT JO-GABIM
////////////////////////////////////////////////////////////////////////////////

/// Lloji i gabimit për gabimet që nuk mund të ndodhin kurrë.
///
/// Meqenëse ky numër nuk ka asnjë variant, një vlerë e këtij lloji nuk mund të ekzistojë kurrë.
/// Kjo mund të jetë e dobishme për API-të gjenerike që përdorin [`Result`] dhe parametrizojnë llojin e gabimit, për të treguar që rezultati është gjithmonë [`Ok`].
///
/// Për shembull, [`TryFrom`] trait (shndërrimi që kthen një [`Result`]) ka një zbatim batanije për të gjitha llojet ku ekziston një zbatim i kundërt [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Përputhshmëria Future
///
/// Ky enum ka të njëjtin rol si [the `!`“never”type][never], i cili është i paqëndrueshëm në këtë version të Rust.
/// Kur `!` të stabilizohet, ne planifikojmë ta bëjmë `Infallible` një lloj pseudonimi për të:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Dhe përfundimisht zhvlerësoni `Infallible`.
///
/// Sidoqoftë ekziston një rast kur sintaksa `!` mund të përdoret para se të stabilizohet `!` si një lloj i plotë: në pozicionin e tipit të kthimit të një funksioni.
/// Konkretisht, është i mundur implementimi për dy lloje të ndryshme të treguesit të funksioneve:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Me `Infallible` që është një enum, ky kod është i vlefshëm.
/// Sidoqoftë, kur `Infallible` bëhet një pseudonim për never type, të dy implikimet do të fillojnë të mbivendosen dhe për këtë arsye nuk do të lejohen nga rregullat e koherencës së gjuhës trait.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}