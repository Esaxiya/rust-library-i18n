//! Llojet atomike
//!
//! Llojet atomike ofrojnë komunikim primitiv të kujtesës së përbashkët midis fijeve, dhe janë blloqet ndërtimore të llojeve të tjerë të njëkohshëm.
//!
//! Ky modul përcakton versionet atomike të një numri të zgjedhur të llojeve primitive, duke përfshirë [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], etj.
//! Llojet atomike paraqesin operacione që, kur përdoren si duhet, sinkronizojnë azhurnimet ndërmjet fijeve.
//!
//! Secila metodë merr një [`Ordering`] e cila paraqet fuqinë e barrierës së kujtesës për atë operacion.Këto porosi janë të njëjta me [C++20 atomic orderings][1].Për më shumë informacion shikoni [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Variablat atomike janë të sigurta për t'u ndarë midis fijeve (ato implementojnë [`Sync`]) por ato nuk sigurojnë vetë mekanizmin për ndarjen dhe ndjekin [threading model](../../../std/thread/index.html#the-threading-model) të Rust.
//!
//! Mënyra më e zakonshme për të ndarë një ndryshore atomike është ta vendosni atë në një [`Arc`][arc] (një tregues i përbashkët i numëruar me referencë atomike).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Llojet atomike mund të ruhen në ndryshore statike, të iniciuara duke përdorur inicializuesit konstant si [`AtomicBool::new`].Statika atomike përdoret shpesh për inicializimin dembel global.
//!
//! # Portability
//!
//! Të gjithë llojet atomike në këtë modul janë të garantuara të jenë [lock-free] nëse janë në dispozicion.Kjo do të thotë që ata nuk fitojnë brenda një mutex global.Llojet dhe operacionet atomike nuk janë të garantuara të jenë pa pritje.
//! Kjo do të thotë që operacione si `fetch_or` mund të zbatohen me një lak krahasimi dhe shkëmbimi.
//!
//! Operacionet atomike mund të zbatohen në shtresën e udhëzimeve me atomikë me madhësi më të madhe.Për shembull, disa platforma përdorin udhëzime atomike me 4 bajte për të zbatuar `AtomicI8`.
//! Vini re se kjo imitim nuk duhet të ketë ndikim në korrektësinë e kodit, është thjesht diçka për të cilën duhet të keni kujdes.
//!
//! Llojet atomike në këtë modul mund të mos jenë të disponueshëm në të gjitha platformat.Llojet atomike këtu janë të gjitha gjerësisht të disponueshme, megjithatë, dhe zakonisht mund të mbështeten në ekzistueset.Disa përjashtime të dukshme janë:
//!
//! * PowerPC dhe platformat MIPS me tregues 32-bit nuk kanë lloje `AtomicU64` ose `AtomicI64`.
//! * ARM platforma si `armv5te` që nuk janë për Linux ofrojnë vetëm operacione `load` dhe `store` dhe nuk mbështesin operacionet Krahasoni dhe Ndërroni (CAS), të tilla si `swap`, `fetch_add`, etj.
//! Për më tepër në Linux, këto operacione CAS zbatohen përmes [operating system support], i cili mund të vijë me një dënim të performancës.
//! * ARM objektivat me `thumbv6m` ofrojnë vetëm operacione `load` dhe `store` dhe nuk mbështesin operacionet Krahasoni dhe Ndërroni (CAS), të tilla si `swap`, `fetch_add`, etj.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Vini re se platformat future mund të shtohen që gjithashtu nuk kanë mbështetje për disa operacione atomike.Kodi maksimal i lëvizshëm do të dëshirojë të ketë kujdes se cilat lloje atomike përdoren.
//! `AtomicUsize` dhe `AtomicIsize` janë zakonisht më të lëvizshmet, por edhe atëherë ato nuk janë të disponueshme kudo.
//! Për referencë, biblioteka `std` kërkon atomikë me madhësi të treguesit, megjithëse `core` nuk e kërkon.
//!
//! Aktualisht do të duhet të përdorni `#[cfg(target_arch)]` kryesisht për të përpiluar me kusht kodin me atomikë.Ekziston edhe një `#[cfg(target_has_atomic)]` e paqëndrueshme, e cila mund të stabilizohet në future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Një spinlock i thjeshtë:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Prisni që fija tjetër të lëshojë bllokimin
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Mbani një numër global të temave të drejtpërdrejta:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Një tip boolean i cili mund të ndahet në mënyrë të sigurt midis fijeve.
///
/// Ky lloj ka të njëjtën paraqitje në memorje si një [`bool`].
///
/// **Shënim**: Ky lloj është i disponueshëm vetëm në platformat që mbështesin ngarkesat atomike dhe dyqanet e `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Krijon një `AtomicBool` të iniciuar në `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Dërgimi zbatohet në mënyrë implicite për AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Një lloj treguesi i papërpunuar i cili mund të ndahet në mënyrë të sigurt midis fijeve.
///
/// Ky lloj ka të njëjtën paraqitje në memorje si një `*mut T`.
///
/// **Shënim**: Ky lloj është i disponueshëm vetëm në platformat që mbështesin ngarkesat atomike dhe depozitat e treguesve.
/// Madhësia e tij varet nga madhësia e treguesit të synuar.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Krijon një `AtomicPtr<T>` nul.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Renditjet e kujtesës atomike
///
/// Renditjet e kujtesës specifikojnë mënyrën sesi operacionet atomike sinkronizojnë kujtesën.
/// Në [`Ordering::Relaxed`] më të dobët, sinkronizohet vetëm memoria e prekur drejtpërdrejt nga operacioni.
/// Nga ana tjetër, një palë e ngarkuar në dyqan e operacioneve [`Ordering::SeqCst`] sinkronizojnë memorien tjetër duke ruajtur gjithashtu një renditje totale të operacioneve të tilla në të gjitha fijet.
///
///
/// Renditjet e kujtesës së Rust janë [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Për më shumë informacion shikoni [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Pa kufizime renditëse, vetëm operacione atomike.
    ///
    /// Korrespondon me [`memory_order_relaxed`] në C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Kur shoqërohet me një dyqan, të gjitha operacionet e mëparshme bëhen të porositura para çdo ngarkese të kësaj vlere me porosinë [`Acquire`] (ose më të fortë).
    ///
    /// Në veçanti, të gjitha shkrimet e mëparshme bëhen të dukshme për të gjitha fijet që kryejnë një ngarkesë [`Acquire`] (ose më të fortë) të kësaj vlere.
    ///
    /// Vini re se përdorimi i kësaj porosie për një operacion që ndërthur ngarkesat dhe depozitat çon në një operacion të ngarkesës [`Relaxed`]!
    ///
    /// Ky porosi është i zbatueshëm vetëm për operacionet që mund të kryejnë një dyqan.
    ///
    /// Korrespondon me [`memory_order_release`] në C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Kur shoqërohet me një ngarkesë, nëse vlera e ngarkuar është shkruar nga një operacion dyqani me porosi [`Release`] (ose më i fortë), atëherë të gjitha operacionet pasuese bëhen të porositura pas atij dyqani.
    /// Në veçanti, të gjitha ngarkesat pasuese do të shohin të dhëna të shkruara para dyqanit.
    ///
    /// Vini re se përdorimi i kësaj porosie për një operacion që ndërthur ngarkesat dhe depozitat çon në një operacion të dyqanit [`Relaxed`]!
    ///
    /// Ky porosi është i zbatueshëm vetëm për operacionet që mund të kryejnë një ngarkesë.
    ///
    /// Korrespondon me [`memory_order_acquire`] në C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Ka efektet e të dy [`Acquire`] dhe [`Release`] së bashku:
    /// Për ngarkesa përdor renditjen [`Acquire`].Për dyqanet përdor porosinë [`Release`].
    ///
    /// Vini re se në rastin e `compare_and_swap`, është e mundur që operacioni të përfundojë duke mos kryer asnjë dyqan dhe kështu ai ka vetëm porosinë [`Acquire`].
    ///
    /// Sidoqoftë, `AcqRel` nuk do të kryejë kurrë hyrje në [`Relaxed`].
    ///
    /// Ky porosi është i zbatueshëm vetëm për operacione që kombinojnë ngarkesat dhe magazinat.
    ///
    /// Korrespondon me [`memory_order_acq_rel`] në C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Si ["Blerja"]/["Lirimi"]/["AcqRel"](përkatësisht për operacionet e ngarkesës, magazinimit dhe ngarkesës me dyqanin) me garancinë shtesë që të gjitha fijet të shohin të gjitha operacionet e njëpasnjëshme në të njëjtën mënyrë .
    ///
    ///
    /// Korrespondon me [`memory_order_seq_cst`] në C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// Një [`AtomicBool`] inicializuar në `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Krijon një `AtomicBool` të ri.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Kthen një referencë të ndryshueshme në [`bool`] themelor.
    ///
    /// Kjo është e sigurt sepse referenca e ndryshueshme garanton që asnjë fije tjetër nuk po hyjnë në të njëjtën kohë në të dhënat atomike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SIGURIA: referenca e ndryshueshme garanton pronësinë unike.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Merrni qasje atomike në një `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SIGURIA: referenca e ndryshueshme garanton pronësinë unike, dhe
        // përafrimi i `bool` dhe `Self` është 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Konsumon atomike dhe kthen vlerën e përmbajtur.
    ///
    /// Kjo është e sigurt sepse kalimi i `self` me vlerë garanton që asnjë fije tjetër nuk po hyjnë në të njëjtën kohë në të dhënat atomike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Ngarkon një vlerë nga bool.
    ///
    /// `load` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.
    /// Vlerat e mundshme janë [`SeqCst`], [`Acquire`] dhe [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics nëse `order` është [`Release`] ose [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SIGURIA: çdo garë e të dhënave parandalohet nga brendësia atomike dhe e para
        // treguesi i kaluar është i vlefshëm sepse e kemi marrë nga një referencë.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Ruan një vlerë në bool.
    ///
    /// `store` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.
    /// Vlerat e mundshme janë [`SeqCst`], [`Release`] dhe [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics nëse `order` është [`Acquire`] ose [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SIGURIA: çdo garë e të dhënave parandalohet nga brendësia atomike dhe e para
        // treguesi i kaluar është i vlefshëm sepse e kemi marrë nga një referencë.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Ruan një vlerë në bool, duke kthyer vlerën e mëparshme.
    ///
    /// `swap` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
    /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
    ///
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Ruan një vlerë në [`bool`] nëse vlera aktuale është e njëjtë me vlerën `current`.
    ///
    /// Vlera e kthimit është gjithmonë vlera e mëparshme.Nëse është e barabartë me `current`, atëherë vlera u azhurnua.
    ///
    /// `compare_and_swap` gjithashtu merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.
    /// Vini re se edhe kur përdorni [`AcqRel`], operacioni mund të dështojë dhe kështu thjesht të kryeni një ngarkesë `Acquire`, por të mos keni semantikë `Release`.
    /// Përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`] nëse ndodh, dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në `u8`.
    ///
    /// # Migrimi në `compare_exchange` dhe `compare_exchange_weak`
    ///
    /// `compare_and_swap` është ekuivalente me `compare_exchange` me hartën vijuese për renditjet e kujtesës:
    ///
    /// Origjinale |Suksese |Dështimi
    /// -------- | ------- | -------
    /// Të relaksuar |Të relaksuar |Bleni Relaksuar |Bleni |Bleni Lirimin |Lirimi |AcqRel i relaksuar |AcqRel |Bleni SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` lejohet të dështojë në mënyrë të rreme edhe kur krahasimi ka sukses, gjë që lejon përpiluesin të gjenerojë një kod më të mirë të montimit kur krahasimi dhe shkëmbimi përdoret në një lak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Ruan një vlerë në [`bool`] nëse vlera aktuale është e njëjtë me vlerën `current`.
    ///
    /// Vlera e kthimit është një rezultat që tregon nëse vlera e re është shkruar dhe përmban vlerën e mëparshme.
    /// Në sukses, kjo vlerë është e garantuar të jetë e barabartë me `current`.
    ///
    /// `compare_exchange` merr dy argumente [`Ordering`] për të përshkruar renditjen e kujtesës të këtij operacioni.
    /// `success` përshkruan renditjen e kërkuar për operacionin lexo-modifiko-shkruaj që ndodh nëse krahasimi me `current` ka sukses.
    /// `failure` përshkruan renditjen e kërkuar për operacionin e ngarkesës që ndodh kur dështon krahasimi.
    /// Përdorimi i [`Acquire`] si porosi e suksesit e bën dyqanin pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën ngarkesën e suksesshme [`Relaxed`].
    ///
    /// Renditja e dështimit mund të jetë vetëm [`SeqCst`], [`Acquire`] ose [`Relaxed`] dhe duhet të jetë ekuivalente ose më e dobët se renditja e suksesit.
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Ruan një vlerë në [`bool`] nëse vlera aktuale është e njëjtë me vlerën `current`.
    ///
    /// Ndryshe nga [`AtomicBool::compare_exchange`], ky funksion lejohet të dështojë në mënyrë të rreme edhe kur krahasimi ka sukses, gjë që mund të rezultojë në një kod më efikas në disa platforma.
    ///
    /// Vlera e kthimit është një rezultat që tregon nëse vlera e re është shkruar dhe përmban vlerën e mëparshme.
    ///
    /// `compare_exchange_weak` merr dy argumente [`Ordering`] për të përshkruar renditjen e kujtesës të këtij operacioni.
    /// `success` përshkruan renditjen e kërkuar për operacionin lexo-modifiko-shkruaj që ndodh nëse krahasimi me `current` ka sukses.
    /// `failure` përshkruan renditjen e kërkuar për operacionin e ngarkesës që ndodh kur dështon krahasimi.
    /// Përdorimi i [`Acquire`] si porosi e suksesit e bën dyqanin pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën ngarkesën e suksesshme [`Relaxed`].
    /// Renditja e dështimit mund të jetë vetëm [`SeqCst`], [`Acquire`] ose [`Relaxed`] dhe duhet të jetë ekuivalente ose më e dobët se renditja e suksesit.
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logjike "and" me një vlerë boolean.
    ///
    /// Kryen një veprim logjik "and" në vlerën aktuale dhe argumentin `val`, dhe vendos vlerën e re në rezultat.
    ///
    /// Kthen vlerën e mëparshme.
    ///
    /// `fetch_and` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
    /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
    ///
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logjike "nand" me një vlerë boolean.
    ///
    /// Kryen një veprim logjik "nand" në vlerën aktuale dhe argumentin `val`, dhe vendos vlerën e re në rezultat.
    ///
    /// Kthen vlerën e mëparshme.
    ///
    /// `fetch_nand` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
    /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
    ///
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Ne nuk mund ta përdorim atomin_dhe këtu sepse mund të rezultojë në një bool me një vlerë të pavlefshme.
        // Kjo ndodh sepse operacioni atomik bëhet me një numër të plotë 8-bit brenda, i cili do të vendoste 7 bitët e sipërm.
        //
        // Pra, ne thjesht përdorim fetch_xor ose swap në vend.
        if val {
            // ! (x&e vërtetë)== !x Ne duhet ta kthejmë bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==e vërtetë Ne duhet ta vendosim bool në true.
            //
            self.swap(true, order)
        }
    }

    /// Logjike "or" me një vlerë boolean.
    ///
    /// Kryen një veprim logjik "or" në vlerën aktuale dhe argumentin `val`, dhe vendos vlerën e re në rezultat.
    ///
    /// Kthen vlerën e mëparshme.
    ///
    /// `fetch_or` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
    /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
    ///
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logjike "xor" me një vlerë boolean.
    ///
    /// Kryen një veprim logjik "xor" në vlerën aktuale dhe argumentin `val`, dhe vendos vlerën e re në rezultat.
    ///
    /// Kthen vlerën e mëparshme.
    ///
    /// `fetch_xor` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
    /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
    ///
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Kthen një tregues të ndryshueshëm në [`bool`] themelor.
    ///
    /// Bërja e leximeve dhe shkrimeve jo-atomike në numrin e plotë që rezulton mund të jetë një garë e të dhënave.
    /// Kjo metodë është kryesisht e dobishme për FFI, ku nënshkrimi i funksionit mund të përdorë `*mut bool` në vend të `&AtomicBool`.
    ///
    /// Kthimi i një treguesi `*mut` nga një referencë e përbashkët për këtë atomik është i sigurt sepse llojet atomike punojnë me ndryshueshmëri të brendshme.
    /// Të gjitha modifikimet e një atomike ndryshojnë vlerën përmes një reference të përbashkët dhe mund ta bëjnë këtë në mënyrë të sigurt për sa kohë që ata përdorin operacione atomike.
    /// Çdo përdorim i treguesit të papërpunuar të kthyer kërkon një bllok `unsafe` dhe akoma duhet të mbajë të njëjtin kufizim: veprimet në të duhet të jenë atomike.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Merr vlerën dhe zbaton një funksion në të që kthen një vlerë të re opsionale.Kthen një `Result` të `Ok(previous_value)` nëse funksioni kthehet `Some(_)`, përndryshe `Err(previous_value)`.
    ///
    /// Note: Kjo mund ta thërrasë funksionin shumë herë nëse vlera është ndryshuar nga fijet e tjera ndërkohë, për sa kohë që funksioni kthen `Some(_)`, por funksioni do të jetë aplikuar vetëm një herë në vlerën e ruajtur.
    ///
    ///
    /// `fetch_update` merr dy argumente [`Ordering`] për të përshkruar renditjen e kujtesës të këtij operacioni.
    /// E para përshkruan renditjen e kërkuar për kur operacioni më në fund ka sukses ndërsa e dyta përshkruan renditjen e kërkuar për ngarkesat.
    /// Këto korrespondojnë me porositë e suksesit dhe dështimit të [`AtomicBool::compare_exchange`] përkatësisht.
    ///
    /// Përdorimi i [`Acquire`] si porosi e suksesit e bën dyqanin pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën ngarkesën përfundimtare të suksesshme [`Relaxed`].
    /// Renditja e ngarkesës (failed) mund të jetë vetëm [`SeqCst`], [`Acquire`] ose [`Relaxed`] dhe duhet të jetë ekuivalente ose më e dobët se renditja e suksesit.
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Krijon një `AtomicPtr` të ri.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Kthen një referencë të ndryshueshme në treguesin themelor.
    ///
    /// Kjo është e sigurt sepse referenca e ndryshueshme garanton që asnjë fije tjetër nuk po hyjnë në të njëjtën kohë në të dhënat atomike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Merrni qasje atomike në një tregues.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - referenca e ndryshueshme garanton pronësinë unike.
        //  - rreshtimi i `*mut T` dhe `Self` është i njëjtë në të gjitha platformat e mbështetura nga rust, siç është verifikuar më sipër.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Konsumon atomike dhe kthen vlerën e përmbajtur.
    ///
    /// Kjo është e sigurt sepse kalimi i `self` me vlerë garanton që asnjë fije tjetër nuk po hyjnë në të njëjtën kohë në të dhënat atomike.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Ngarkon një vlerë nga treguesi.
    ///
    /// `load` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.
    /// Vlerat e mundshme janë [`SeqCst`], [`Acquire`] dhe [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics nëse `order` është [`Release`] ose [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Ruan një vlerë në treguesin.
    ///
    /// `store` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.
    /// Vlerat e mundshme janë [`SeqCst`], [`Release`] dhe [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics nëse `order` është [`Acquire`] ose [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Ruan një vlerë në tregues, duke kthyer vlerën e mëparshme.
    ///
    /// `swap` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
    /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
    ///
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në tregues.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Ruan një vlerë në tregues nëse vlera aktuale është e njëjtë me vlerën `current`.
    ///
    /// Vlera e kthimit është gjithmonë vlera e mëparshme.Nëse është e barabartë me `current`, atëherë vlera u azhurnua.
    ///
    /// `compare_and_swap` gjithashtu merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.
    /// Vini re se edhe kur përdorni [`AcqRel`], operacioni mund të dështojë dhe kështu thjesht të kryeni një ngarkesë `Acquire`, por të mos keni semantikë `Release`.
    /// Përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`] nëse ndodh, dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në tregues.
    ///
    /// # Migrimi në `compare_exchange` dhe `compare_exchange_weak`
    ///
    /// `compare_and_swap` është ekuivalente me `compare_exchange` me hartën vijuese për renditjet e kujtesës:
    ///
    /// Origjinale |Suksese |Dështimi
    /// -------- | ------- | -------
    /// Të relaksuar |Të relaksuar |Bleni Relaksuar |Bleni |Bleni Lirimin |Lirimi |AcqRel i relaksuar |AcqRel |Bleni SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` lejohet të dështojë në mënyrë të rreme edhe kur krahasimi ka sukses, gjë që lejon përpiluesin të gjenerojë një kod më të mirë të montimit kur krahasimi dhe shkëmbimi përdoret në një lak.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Ruan një vlerë në tregues nëse vlera aktuale është e njëjtë me vlerën `current`.
    ///
    /// Vlera e kthimit është një rezultat që tregon nëse vlera e re është shkruar dhe përmban vlerën e mëparshme.
    /// Në sukses, kjo vlerë është e garantuar të jetë e barabartë me `current`.
    ///
    /// `compare_exchange` merr dy argumente [`Ordering`] për të përshkruar renditjen e kujtesës të këtij operacioni.
    /// `success` përshkruan renditjen e kërkuar për operacionin lexo-modifiko-shkruaj që ndodh nëse krahasimi me `current` ka sukses.
    /// `failure` përshkruan renditjen e kërkuar për operacionin e ngarkesës që ndodh kur dështon krahasimi.
    /// Përdorimi i [`Acquire`] si porosi e suksesit e bën dyqanin pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën ngarkesën e suksesshme [`Relaxed`].
    ///
    /// Renditja e dështimit mund të jetë vetëm [`SeqCst`], [`Acquire`] ose [`Relaxed`] dhe duhet të jetë ekuivalente ose më e dobët se renditja e suksesit.
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në tregues.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Ruan një vlerë në tregues nëse vlera aktuale është e njëjtë me vlerën `current`.
    ///
    /// Ndryshe nga [`AtomicPtr::compare_exchange`], ky funksion lejohet të dështojë në mënyrë të rreme edhe kur krahasimi ka sukses, gjë që mund të rezultojë në një kod më efikas në disa platforma.
    ///
    /// Vlera e kthimit është një rezultat që tregon nëse vlera e re është shkruar dhe përmban vlerën e mëparshme.
    ///
    /// `compare_exchange_weak` merr dy argumente [`Ordering`] për të përshkruar renditjen e kujtesës të këtij operacioni.
    /// `success` përshkruan renditjen e kërkuar për operacionin lexo-modifiko-shkruaj që ndodh nëse krahasimi me `current` ka sukses.
    /// `failure` përshkruan renditjen e kërkuar për operacionin e ngarkesës që ndodh kur dështon krahasimi.
    /// Përdorimi i [`Acquire`] si porosi e suksesit e bën dyqanin pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën ngarkesën e suksesshme [`Relaxed`].
    /// Renditja e dështimit mund të jetë vetëm [`SeqCst`], [`Acquire`] ose [`Relaxed`] dhe duhet të jetë ekuivalente ose më e dobët se renditja e suksesit.
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në tregues.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SIGURIA: Kjo e brendshme është e pasigurt sepse operon me një tregues të papërpunuar
        // por ne e dimë me siguri që treguesi është i vlefshëm (sapo e morëm atë nga një `UnsafeCell` që e kemi me referencë) dhe vetë veprimi atomik na lejon të mutojmë në mënyrë të sigurt përmbajtjen `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Merr vlerën dhe zbaton një funksion në të që kthen një vlerë të re opsionale.Kthen një `Result` të `Ok(previous_value)` nëse funksioni kthehet `Some(_)`, përndryshe `Err(previous_value)`.
    ///
    /// Note: Kjo mund ta thërrasë funksionin shumë herë nëse vlera është ndryshuar nga fijet e tjera ndërkohë, për sa kohë që funksioni kthen `Some(_)`, por funksioni do të jetë aplikuar vetëm një herë në vlerën e ruajtur.
    ///
    ///
    /// `fetch_update` merr dy argumente [`Ordering`] për të përshkruar renditjen e kujtesës të këtij operacioni.
    /// E para përshkruan renditjen e kërkuar për kur operacioni më në fund ka sukses ndërsa e dyta përshkruan renditjen e kërkuar për ngarkesat.
    /// Këto korrespondojnë me porositë e suksesit dhe dështimit të [`AtomicPtr::compare_exchange`] përkatësisht.
    ///
    /// Përdorimi i [`Acquire`] si porosi e suksesit e bën dyqanin pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën ngarkesën përfundimtare të suksesshme [`Relaxed`].
    /// Renditja e ngarkesës (failed) mund të jetë vetëm [`SeqCst`], [`Acquire`] ose [`Relaxed`] dhe duhet të jetë ekuivalente ose më e dobët se renditja e suksesit.
    ///
    /// **Note:** Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në tregues.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Shndërron një `bool` në një `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Kjo makro përfundon e papërdorur në disa arkitekturë.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Një tip i plotë i cili mund të ndahet në mënyrë të sigurt midis fijeve.
        ///
        /// Ky lloj ka të njëjtën paraqitje në memorje si lloji themelor i plotë, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Për më shumë rreth ndryshimeve midis llojeve atomike dhe atyre jo atomike, si dhe informacionit në lidhje me transportueshmërinë e këtij lloji, ju lutemi shikoni [module-level documentation].
        ///
        ///
        /// **Note:** Ky lloj është i disponueshëm vetëm në platformat që mbështesin ngarkesat atomike dhe dyqanet e [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Një numër i plotë atomik i iniciuar në `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Dërgimi zbatohet në mënyrë implicite.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Krijon një numër të plotë atomik të ri.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Kthen një referencë të ndryshueshme në numrin e plotë themelor.
            ///
            /// Kjo është e sigurt sepse referenca e ndryshueshme garanton që asnjë fije tjetër nuk po hyjnë në të njëjtën kohë në të dhënat atomike.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// le të mut disa_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// poho_eq! (ca_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - referenca e ndryshueshme garanton pronësinë unike.
                //  - përafrimi i `$int_type` dhe `Self` është i njëjtë, siç premtohet nga $cfg_align dhe verifikuar më lart.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Konsumon atomike dhe kthen vlerën e përmbajtur.
            ///
            /// Kjo është e sigurt sepse kalimi i `self` me vlerë garanton që asnjë fije tjetër nuk po hyjnë në të njëjtën kohë në të dhënat atomike.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Ngarkon një vlerë nga numri i plotë atomik.
            ///
            /// `load` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.
            /// Vlerat e mundshme janë [`SeqCst`], [`Acquire`] dhe [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics nëse `order` është [`Release`] ose [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Ruan një vlerë në numrin e plotë atomik.
            ///
            /// `store` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.
            ///  Vlerat e mundshme janë [`SeqCst`], [`Release`] dhe [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics nëse `order` është [`Acquire`] ose [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Ruan një vlerë në numrin e plotë atomik, duke kthyer vlerën e mëparshme.
            ///
            /// `swap` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
            /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
            ///
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Ruan një vlerë në numrin e plotë atomik nëse vlera aktuale është e njëjtë me vlerën `current`.
            ///
            /// Vlera e kthimit është gjithmonë vlera e mëparshme.Nëse është e barabartë me `current`, atëherë vlera u azhurnua.
            ///
            /// `compare_and_swap` gjithashtu merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.
            /// Vini re se edhe kur përdorni [`AcqRel`], operacioni mund të dështojë dhe kështu thjesht të kryeni një ngarkesë `Acquire`, por të mos keni semantikë `Release`.
            ///
            /// Përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`] nëse ndodh, dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migrimi në `compare_exchange` dhe `compare_exchange_weak`
            ///
            /// `compare_and_swap` është ekuivalente me `compare_exchange` me hartën vijuese për renditjet e kujtesës:
            ///
            /// Origjinale |Suksese |Dështimi
            /// -------- | ------- | -------
            /// Të relaksuar |Të relaksuar |Bleni Relaksuar |Bleni |Bleni Lirimin |Lirimi |AcqRel i relaksuar |AcqRel |Bleni SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` lejohet të dështojë në mënyrë të rreme edhe kur krahasimi ka sukses, gjë që lejon përpiluesin të gjenerojë një kod më të mirë të montimit kur krahasimi dhe shkëmbimi përdoret në një lak.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Ruan një vlerë në numrin e plotë atomik nëse vlera aktuale është e njëjtë me vlerën `current`.
            ///
            /// Vlera e kthimit është një rezultat që tregon nëse vlera e re është shkruar dhe përmban vlerën e mëparshme.
            /// Në sukses, kjo vlerë është e garantuar të jetë e barabartë me `current`.
            ///
            /// `compare_exchange` merr dy argumente [`Ordering`] për të përshkruar renditjen e kujtesës të këtij operacioni.
            /// `success` përshkruan renditjen e kërkuar për operacionin lexo-modifiko-shkruaj që ndodh nëse krahasimi me `current` ka sukses.
            /// `failure` përshkruan renditjen e kërkuar për operacionin e ngarkesës që ndodh kur dështon krahasimi.
            /// Përdorimi i [`Acquire`] si porosi e suksesit e bën dyqanin pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën ngarkesën e suksesshme [`Relaxed`].
            ///
            /// Renditja e dështimit mund të jetë vetëm [`SeqCst`], [`Acquire`] ose [`Relaxed`] dhe duhet të jetë ekuivalente ose më e dobët se renditja e suksesit.
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Ruan një vlerë në numrin e plotë atomik nëse vlera aktuale është e njëjtë me vlerën `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ky funksion lejohet të dështojë në mënyrë të rreme edhe kur krahasimi ka sukses, gjë që mund të rezultojë në një kod më efikas në disa platforma.
            /// Vlera e kthimit është një rezultat që tregon nëse vlera e re është shkruar dhe përmban vlerën e mëparshme.
            ///
            /// `compare_exchange_weak` merr dy argumente [`Ordering`] për të përshkruar renditjen e kujtesës të këtij operacioni.
            /// `success` përshkruan renditjen e kërkuar për operacionin lexo-modifiko-shkruaj që ndodh nëse krahasimi me `current` ka sukses.
            /// `failure` përshkruan renditjen e kërkuar për operacionin e ngarkesës që ndodh kur dështon krahasimi.
            /// Përdorimi i [`Acquire`] si porosi e suksesit e bën dyqanin pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën ngarkesën e suksesshme [`Relaxed`].
            ///
            /// Renditja e dështimit mund të jetë vetëm [`SeqCst`], [`Acquire`] ose [`Relaxed`] dhe duhet të jetë ekuivalente ose më e dobët se renditja e suksesit.
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// le të vjetër mut= val.load(Ordering::Relaxed);
            /// lak {le të ri=i vjetër * 2;
            ///     ndeshje val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Shton vlerën aktuale, duke kthyer vlerën e mëparshme.
            ///
            /// Ky operacion përfundon rreth mbingarkesës.
            ///
            /// `fetch_add` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
            /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
            ///
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Zbritet nga vlera aktuale, duke kthyer vlerën e mëparshme.
            ///
            /// Ky operacion përfundon rreth mbingarkesës.
            ///
            /// `fetch_sub` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
            /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
            ///
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" me vlerën aktuale.
            ///
            /// Kryen një veprim "and" në mënyrë bit bit në vlerën aktuale dhe argumentin `val`, dhe vendos vlerën e re në rezultat.
            ///
            /// Kthen vlerën e mëparshme.
            ///
            /// `fetch_and` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
            /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
            ///
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" me vlerën aktuale.
            ///
            /// Kryen një veprim "nand" në mënyrë bit bit në vlerën aktuale dhe argumentin `val`, dhe vendos vlerën e re në rezultat.
            ///
            /// Kthen vlerën e mëparshme.
            ///
            /// `fetch_nand` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
            /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
            ///
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" me vlerën aktuale.
            ///
            /// Kryen një veprim "or" në mënyrë bit bit në vlerën aktuale dhe argumentin `val`, dhe vendos vlerën e re në rezultat.
            ///
            /// Kthen vlerën e mëparshme.
            ///
            /// `fetch_or` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
            /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
            ///
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" me vlerën aktuale.
            ///
            /// Kryen një veprim "xor" në mënyrë bit bit në vlerën aktuale dhe argumentin `val`, dhe vendos vlerën e re në rezultat.
            ///
            /// Kthen vlerën e mëparshme.
            ///
            /// `fetch_xor` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
            /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
            ///
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Merr vlerën dhe zbaton një funksion në të që kthen një vlerë të re opsionale.Kthen një `Result` të `Ok(previous_value)` nëse funksioni kthehet `Some(_)`, përndryshe `Err(previous_value)`.
            ///
            /// Note: Kjo mund ta thërrasë funksionin shumë herë nëse vlera është ndryshuar nga fijet e tjera ndërkohë, për sa kohë që funksioni kthen `Some(_)`, por funksioni do të jetë aplikuar vetëm një herë në vlerën e ruajtur.
            ///
            ///
            /// `fetch_update` merr dy argumente [`Ordering`] për të përshkruar renditjen e kujtesës të këtij operacioni.
            /// E para përshkruan renditjen e kërkuar për kur operacioni më në fund ka sukses ndërsa e dyta përshkruan renditjen e kërkuar për ngarkesat.Këto korrespondojnë me porositë e suksesit dhe dështimit të
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Përdorimi i [`Acquire`] si porosi e suksesit e bën dyqanin pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën ngarkesën përfundimtare të suksesshme [`Relaxed`].
            /// Renditja e ngarkesës (failed) mund të jetë vetëm [`SeqCst`], [`Acquire`] ose [`Relaxed`] dhe duhet të jetë ekuivalente ose më e dobët se renditja e suksesit.
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Renditja: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Renditja: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maksimumi me vlerën aktuale.
            ///
            /// Gjen maksimumin e vlerës aktuale dhe argumentin `val`, dhe vendos vlerën e re në rezultat.
            ///
            /// Kthen vlerën e mëparshme.
            ///
            /// `fetch_max` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
            /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
            ///
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// le shirit=42;
            /// le max_foo=foo.fetch_max (shirit, Ordering::SeqCst).max(bar);
            /// pohoj! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimumi me vlerën aktuale.
            ///
            /// Gjen minimumin e vlerës aktuale dhe argumentin `val`, dhe vendos vlerën e re në rezultat.
            ///
            /// Kthen vlerën e mëparshme.
            ///
            /// `fetch_min` merr një argument [`Ordering`] i cili përshkruan renditjen e kujtesës të këtij operacioni.Të gjitha mënyrat e porositjes janë të mundshme.
            /// Vini re se përdorimi i [`Acquire`] e bën ruajtjen pjesë të këtij operacioni [`Relaxed`], dhe përdorimi i [`Release`] e bën pjesën e ngarkesës [`Relaxed`].
            ///
            ///
            /// **Shënim**: Kjo metodë është e disponueshme vetëm në platformat që mbështesin operacionet atomike në
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// le shirit=12;
            /// le min_foo=foo.fetch_min (shirit, Ordering::SeqCst).min(bar);
            /// pohoj_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURIA: garat e të dhënave parandalohen nga brendësia atomike.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Kthen një tregues të ndryshueshëm në numrin e plotë themelor.
            ///
            /// Bërja e leximeve dhe shkrimeve jo-atomike në numrin e plotë që rezulton mund të jetë një garë e të dhënave.
            /// Kjo metodë është kryesisht e dobishme për FFI, ku mund të përdoret nënshkrimi i funksionit
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Kthimi i një treguesi `*mut` nga një referencë e përbashkët për këtë atomik është i sigurt sepse llojet atomike punojnë me ndryshueshmëri të brendshme.
            /// Të gjitha modifikimet e një atomike ndryshojnë vlerën përmes një reference të përbashkët dhe mund ta bëjnë këtë në mënyrë të sigurt për sa kohë që ata përdorin operacione atomike.
            /// Çdo përdorim i treguesit të papërpunuar të kthyer kërkon një bllok `unsafe` dhe akoma duhet të mbajë të njëjtin kufizim: veprimet në të duhet të jenë atomike.
            ///
            ///
            /// # Examples
            ///
            /// "injoroni (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// e jashtme "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SIGURIA: E sigurt për sa kohë që `my_atomic_op` është atomike.
            /// i pasigurt {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Kthen vlerën e mëparshme (si __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Kthen vlerën e mëparshme (si __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// kthen vlerën maksimale (krahasimi i nënshkruar)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// kthen vlerën minimale (krahasimi i nënshkruar)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// kthen vlerën maksimale (krahasimi i nënshkruar)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// kthen vlerën minimale (krahasimi i nënshkruar)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Një gardh atomik.
///
/// Në varësi të renditjes së specifikuar, një gardh parandalon përpiluesin dhe CPU-në që të renditin disa lloje të caktuara të veprimeve të kujtesës rreth tij.
/// Kjo krijon marrëdhënie të sinkronizuara midis tij dhe operacioneve atomike ose gardheve në fijet e tjera.
///
/// Një gardh 'A' i cili ka (të paktën) semantikë të renditjes [`Release`], sinkronizohet me një gardh 'B' me (të paktën) semantikë [`Acquire`], nëse dhe vetëm nëse ekzistojnë operacione X dhe Y, që të dy veprojnë në ndonjë objekt atomik 'M' të tillë që A të renditet më parë X, Y është sinkronizuar para se B dhe Y të vëzhgojë ndryshimin në M.
/// Kjo siguron një varësi para-ndodhjes midis A dhe B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Operacionet atomike me semantikën [`Release`] ose [`Acquire`] gjithashtu mund të sinkronizohen me një gardh.
///
/// Një gardh i cili ka renditje [`SeqCst`], përveç që ka të dyja semantikën [`Acquire`] dhe [`Release`], merr pjesë në rendin global të programit të operacioneve dhe/ose gardheve të tjerë [`SeqCst`].
///
/// Pranon porositë [`Acquire`], [`Release`], [`AcqRel`] dhe [`SeqCst`].
///
/// # Panics
///
/// Panics nëse `order` është [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Një primitiv i përjashtimit reciprok bazuar në spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Prisni derisa vlera e vjetër të jetë `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Kjo gardh sinkronizohet-me dyqanin në `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SIGURIA: përdorimi i një gardhi atomik është i sigurt.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Një gardh memorie përpilues.
///
/// `compiler_fence` nuk lëshon ndonjë kod makinerie, por kufizon llojet e kujtesës duke ri-renditur përpiluesin lejohet të bëjë.Në mënyrë të veçantë, në varësi të semantikës së dhënë [`Ordering`], përpiluesit mund t'i ndalohet lëvizja e leximeve ose shkrimeve nga para ose pas thirrjes në anën tjetër të thirrjes në `compiler_fence`.Vini re se **nuk** e parandalon pajisjen * që të bëjë një porositje të tillë.
///
/// Ky nuk është një problem në një kontekst ekzekutimi me një fije, por kur fijet e tjera mund të modifikojnë memorjen në të njëjtën kohë, kërkohen primitivë më të fortë sinkronizimi si [`fence`].
///
/// Renditja e parandaluar nga semantika e ndryshme e renditjes janë:
///
///  - me [`SeqCst`], nuk lejohet asnjë rregullim i leximeve dhe shkrimeve në të gjithë këtë pikë.
///  - me [`Release`], leximet paraprake dhe shkrimet nuk mund të lëvizen pas shkrimeve pasuese.
///  - me [`Acquire`], leximet dhe shkrimet pasuese nuk mund të zhvendosen përpara leximeve paraardhëse.
///  - me [`AcqRel`], të dy rregullat e mësipërme zbatohen.
///
/// `compiler_fence` është përgjithësisht i dobishëm vetëm për të parandaluar që një fije të mos garojë *me vetveten*.Kjo do të thotë, nëse një fije e caktuar po ekzekuton një pjesë të kodit, dhe pastaj ndërpritet, dhe fillon të ekzekutojë kodin diku tjetër (ndërsa është akoma në të njëjtën fije, dhe konceptualisht akoma në të njëjtën bërthamë).Në programet tradicionale, kjo mund të ndodhë vetëm kur regjistrohet një mbajtës sinjali.
/// Në një kod më të nivelit të ulët, situata të tilla mund të lindin edhe kur trajtohen ndërprerjet, kur zbatohen fijet e gjelbra me parablerje, etj.
/// Lexuesit kuriozë inkurajohen të lexojnë diskutimin e kernelit Linux për [memory barriers].
///
/// # Panics
///
/// Panics nëse `order` është [`Relaxed`].
///
/// # Examples
///
/// Pa `compiler_fence`, `assert_eq!` në kodin vijues *nuk është* e garantuar që të ketë sukses, pavarësisht se gjithçka ndodh në një fije të vetme.
/// Për të parë pse, mos harroni se përpiluesi është i lirë të ndërrojë dyqanet në `IMPORTANT_VARIABLE` dhe `IS_READ` pasi që të dy janë `Ordering::Relaxed`.Nëse ndodh, dhe mbajtësi i sinjalit thirret menjëherë pasi të jetë azhurnuar `IS_READY`, atëherë mbajtësi i sinjalit do të shohë `IS_READY=1`, por `IMPORTANT_VARIABLE=0`.
/// Duke përdorur një mjet shërimi `compiler_fence`, kjo situatë.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // parandaloni që shkrimet e mëparshme të zhvendosen përtej kësaj pike
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SIGURIA: përdorimi i një gardhi atomik është i sigurt.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Sinjalizon procesorin se është brenda një loje spin-pritje të zënë ("bllokimi i rrotullimit").
///
/// Ky funksion është i amortizuar në favor të [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}