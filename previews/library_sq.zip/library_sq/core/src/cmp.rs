//! Funksionaliteti për renditjen dhe krahasimin.
//!
//! Ky modul përmban mjete të ndryshme për renditjen dhe krahasimin e vlerave.Në përmbledhje:
//!
//! * [`Eq`] dhe [`PartialEq`] janë traits që ju lejojnë të përcaktoni barazinë totale dhe të pjesshme midis vlerave, përkatësisht.
//! Zbatimi i tyre mbingarkon operatorët `==` dhe `!=`.
//! * [`Ord`] dhe [`PartialOrd`] janë traits që ju lejojnë të përcaktoni renditjet totale dhe të pjesshme ndërmjet vlerave, përkatësisht.
//!
//! Zbatimi i tyre mbingarkon operatorët `<`, `<=`, `>` dhe `>=`.
//! * [`Ordering`] është një enum i kthyer nga funksionet kryesore të [`Ord`] dhe [`PartialOrd`], dhe përshkruan një renditje.
//! * [`Reverse`] është një strukturë që ju lejon të ktheni lehtë një renditje.
//! * [`max`] dhe [`min`] janë funksione që ndërtohen nga [`Ord`] dhe ju lejojnë të gjeni maksimumin ose minimumin e dy vlerave.
//!
//! Për më shumë detaje, shihni dokumentacionin përkatës të secilit artikull në listë.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait për krahasime të barazisë të cilat janë [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Ky trait lejon barazi të pjesshme, për llojet që nuk kanë një lidhje të plotë të ekuivalencës.
/// Për shembull, në numrat e pikave lundruese `NaN != NaN`, kështu që llojet e pikave lundruese zbatojnë `PartialEq` por jo [`trait@Eq`].
///
/// Formalisht, barazia duhet të jetë (për të gjithë `a`, `b`, `c` të tipit `A`, `B`, `C`):
///
/// - **Simetrike**: nëse `A: PartialEq<B>` dhe `B: PartialEq<A>`, atëherë **`a==b` nënkupton`b==a`**;dhe
///
/// - **Kalimtar**: nëse `A: PartialEq<B>` dhe `B: PartialEq<C>` dhe `A:
///   E pjesshmeEq<C>`, atëherë **` a==b`dhe `b == c` nënkupton`a==c`**.
///
/// Vini re se implikimet `B: PartialEq<A>` (symmetric) dhe `A: PartialEq<C>` (transitive) nuk detyrohen të ekzistojnë, por këto kërkesa zbatohen sa herë që ekzistojnë.
///
/// ## Derivable
///
/// Ky trait mund të përdoret me `#[derive]`.Kur `derivojmë`d në struktura, dy instanca janë të barabarta nëse të gjitha fushat janë të barabarta, dhe jo të barabarta nëse ndonjë fushë nuk janë të barabarta.Kur `nxirret`d nga enumet, secili variant është i barabartë me vetveten dhe jo i barabartë me variantet e tjera.
///
/// ## Si mund ta implementoj `PartialEq`?
///
/// `PartialEq` kërkon vetëm që të zbatohet metoda [`eq`];[`ne`] përcaktohet në terma të tij si parazgjedhje.Çdo zbatim manual i [`ne`]*duhet* të respektojë rregullin që [`eq`] është një anasjelltas i rreptë i [`ne`];domethënë `!(a == b)` nëse dhe vetëm nëse `a != b`.
///
/// Zbatimet e `PartialEq`, [`PartialOrd`] dhe [`Ord`]*duhet* të bien dakord me njëri-tjetrin.Easyshtë e lehtë t`i bësh aksidentalisht që të mos pajtohen duke nxjerrë disa nga traits dhe duke zbatuar manualisht të tjerët.
///
/// Një shembull i zbatimit për një domen në të cilin dy libra konsiderohen i njëjti libër nëse përputhet ISBN e tyre, edhe nëse formatet ndryshojnë:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Si mund të krahasoj dy lloje të ndryshme?
///
/// Lloji me të cilin mund të krahasoni kontrollohet nga parametri i tipit `PartialEq`.
/// Për shembull, le të rregullojmë pak kodin tonë të mëparshëm:
///
/// ```
/// // Nxjerr zbaton<BookFormat>==<BookFormat>krahasimet
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Zbatoni<Book>==<BookFormat>krahasimet
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Zbatoni<BookFormat>==<Book>krahasimet
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Duke ndryshuar `impl PartialEq for Book` në `impl PartialEq<BookFormat> for Book`, ne lejojmë që `BookFormat` të krahasohet me` Book's.
///
/// Një krahasim si ai më sipër, i cili injoron disa fusha të strukturës, mund të jetë i rrezikshëm.Kjo lehtë mund të çojë në një shkelje të paqëllimshme të kërkesave për një lidhje të pjesshme të ekuivalencës.
/// Për shembull, nëse do të mbanim zbatimin e mësipërm të `PartialEq<Book>` për `BookFormat` dhe do të shtonim një implementim të `PartialEq<Book>` për `Book` (ose përmes një `#[derive]` ose përmes zbatimit manual nga shembulli i parë), atëherë rezultati do të shkelte transitivitetin:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Kjo metodë teston që vlerat `self` dhe `other` të jenë të barabarta, dhe përdoret nga `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Kjo metodë provon për `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Nxjerr makro që gjeneron një impl të trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait për krahasime të barazisë të cilat janë [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Kjo do të thotë, që përveç që `a == b` dhe `a != b` janë anasjellta të rrepta, barazia duhet të jetë (për të gjithë `a`, `b` dhe `c`):
///
/// - reflexive: `a == a`;
/// - simetrike: `a == b` nënkupton `b == a`;dhe
/// - kalimtare: `a == b` dhe `b == c` nënkupton `a == c`.
///
/// Kjo pronë nuk mund të kontrollohet nga përpiluesi, dhe për këtë arsye `Eq` nënkupton [`PartialEq`], dhe nuk ka metoda shtesë.
///
/// ## Derivable
///
/// Ky trait mund të përdoret me `#[derive]`.
/// Kur `nxirret`d, sepse `Eq` nuk ka metoda shtesë, ai vetëm informon përpiluesin se kjo është një lidhje ekuivalence sesa një lidhje e pjesshme e ekuivalencës.
///
/// Vini re se strategjia `derive` kërkon që të gjitha fushat të jenë `Eq`, gjë që nuk është gjithmonë e dëshiruar.
///
/// ## Si mund ta implementoj `Eq`?
///
/// Nëse nuk mund të përdorni strategjinë `derive`, specifikoni që lloji juaj zbaton `Eq`, i cili nuk ka metoda:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // kjo metodë përdoret vetëm nga#[derivimi] për të pohuar se çdo përbërës i një lloji zbaton#[rrjedh] vetë, infrastruktura rrjedhëse aktuale do të thotë të bësh këtë pohim pa përdorur një metodë në këtë trait është gati e pamundur.
    //
    //
    // Kjo nuk duhet të zbatohet kurrë me dorë.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Nxjerr makro që gjeneron një impl të trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: kjo strukturë përdoret vetëm nga#[derivoj] tek
// pohoni se çdo përbërës i një lloji zbaton Eq.
//
// Ky struktur nuk duhet të shfaqet kurrë në kodin e përdoruesit.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Një `Ordering` është rezultat i një krahasimi midis dy vlerave.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Një renditje kur një vlerë e krahasuar është më e vogël se një tjetër.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Një renditje kur një vlerë e krahasuar është e barabartë me një tjetër.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Një renditje kur një vlerë e krahasuar është më e madhe se një tjetër.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Kthen `true` nëse renditja është variant `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Kthen `true` nëse porositja nuk është variant `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Kthen `true` nëse renditja është variant `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Kthen `true` nëse renditja është variant `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Kthen `true` nëse renditja është ose varianti `Less` ose `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Kthen `true` nëse renditja është ose varianti `Greater` ose `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Ndryshon `Ordering`.
    ///
    /// * `Less` bëhet `Greater`.
    /// * `Greater` bëhet `Less`.
    /// * `Equal` bëhet `Equal`.
    ///
    /// # Examples
    ///
    /// Sjellja themelore:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Kjo metodë mund të përdoret për të kthyer një krahasim:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // rendit grupin nga më i madhi te më i vogli.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Zinxhirët dy renditje.
    ///
    /// Kthen `self` kur nuk është `Equal`.Përndryshe kthen `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Zinxhiron renditjen me funksionin e dhënë.
    ///
    /// Kthen `self` kur nuk është `Equal`.
    /// Përndryshe telefonon `f` dhe kthen rezultatin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Një strukturë ndihmëse për renditjen e kundërt.
///
/// Ky struktur është një ndihmës që do të përdoret me funksione si [`Vec::sort_by_key`] dhe mund të përdoret për të renditur në mënyrë të kundërt një pjesë të një çelësi.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait për llojet që formojnë një [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Një porosi është një porosi totale nëse është (për të gjithë `a`, `b` dhe `c`):
///
/// - total dhe asimetrik: saktësisht një nga `a < b`, `a == b` ose `a > b` është i vërtetë;dhe
/// - kalimtare, `a < b` dhe `b < c` nënkupton `a < c`.E njëjta gjë duhet të vlejë si për `==` ashtu edhe për `>`.
///
/// ## Derivable
///
/// Ky trait mund të përdoret me `#[derive]`.
/// Kur `nxirret`d nga strukturat, ai do të prodhojë një renditje [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) bazuar në rendin e deklarimit nga lart-poshtë për anëtarët e strukturës.
///
/// Kur `nxirren`d nga enumet, variantet renditen sipas renditjes së tyre diskriminuese nga lart-poshtë.
///
/// ## Krahasimi leksikografik
///
/// Krahasimi leksikografik është një veprim me vetitë e mëposhtme:
///  - Dy sekuenca krahasohen element për element.
///  - Elementi i parë i mospërputhjes përcakton se cila sekuencë është leksikografikisht më pak ose më e madhe se tjetra.
///  - Nëse një sekuencë është një parashtesë e një tjetre, sekuenca më e shkurtër është leksikografikisht më e vogël se tjetra.
///  - Nëse dy sekuenca kanë elemente ekuivalente dhe kanë të njëjtën gjatësi, atëherë sekuencat janë leksikografikisht të barabarta.
///  - Një sekuencë bosh është leksikografikisht më pak se çdo sekuencë jo-boshe.
///  - Dy sekuenca boshe janë leksikografikisht të barabarta.
///
/// ## Si mund ta implementoj `Ord`?
///
/// `Ord` kërkon që lloji të jetë gjithashtu [`PartialOrd`] dhe [`Eq`] (që kërkon [`PartialEq`]).
///
/// Atëherë duhet të përcaktoni një implementim për [`cmp`].Ju mund ta gjeni të dobishme të përdorni [`cmp`] në fushat e llojit tuaj.
///
/// Zbatimet e [`PartialEq`], [`PartialOrd`] dhe `Ord`*duhet* të bien dakord me njëri-tjetrin.
/// Kjo është, `a.cmp(b) == Ordering::Equal` nëse dhe vetëm nëse `a == b` dhe `Some(a.cmp(b)) == a.partial_cmp(b)` për të gjithë `a` dhe `b`.
/// Easyshtë e lehtë t`i bësh aksidentalisht që të mos pajtohen duke nxjerrë disa nga traits dhe duke zbatuar manualisht të tjerët.
///
/// Këtu keni një shembull ku dëshironi të renditni njerëzit vetëm sipas gjatësisë, duke mos marrë parasysh `id` dhe `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Kjo metodë kthen një [`Ordering`] ndërmjet `self` dhe `other`.
    ///
    /// Sipas konventës, `self.cmp(&other)` kthen renditjen që përputhet me shprehjen `self <operator> other` nëse është e vërtetë.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Krahason dhe kthen maksimumin e dy vlerave.
    ///
    /// Kthen argumentin e dytë nëse krahasimi i përcakton ata të jenë të barabartë.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Krahason dhe kthen minimumin e dy vlerave.
    ///
    /// Kthen argumentin e parë nëse krahasimi i përcakton ata të jenë të barabartë.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Kufizoni një vlerë në një interval të caktuar.
    ///
    /// Kthen `max` nëse `self` është më i madh se `max` dhe `min` nëse `self` është më i vogël se `min`.
    /// Përndryshe kjo kthen `self`.
    ///
    /// # Panics
    ///
    /// Panics nëse `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Nxjerr makro që gjeneron një impl të trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait për vlerat që mund të krahasohen për një renditje të renditjes.
///
/// Krahasimi duhet të kënaqë, për të gjithë `a`, `b` dhe `c`:
///
/// - asimetria: nëse `a < b` atëherë `!(a > b)`, si dhe `a > b` nënkuptohet `!(a < b)`;dhe
/// - tranzitiviteti: `a < b` dhe `b < c` nënkupton `a < c`.E njëjta gjë duhet të vlejë si për `==` ashtu edhe për `>`.
///
/// Vini re se këto kërkesa nënkuptojnë që vetë trait duhet të zbatohet në mënyrë simetrike dhe kalimtare: nëse `T: PartialOrd<U>` dhe `U: PartialOrd<V>` atëherë `U: PartialOrd<T>` dhe `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Ky trait mund të përdoret me `#[derive]`.Kur `nxirret`d nga strukturat, ai do të prodhojë një renditje leksikografike bazuar në rendin e deklarimit nga lart-poshtë për anëtarët e strukturës.
/// Kur `nxirren`d nga enumet, variantet renditen sipas renditjes së tyre diskriminuese nga lart-poshtë.
///
/// ## Si mund ta implementoj `PartialOrd`?
///
/// `PartialOrd` kërkon vetëm implementimin e metodës [`partial_cmp`], me të tjerat të krijuara nga implementimet e parazgjedhura.
///
/// Sidoqoftë mbetet e mundur të zbatohen të tjerët veçmas për llojet që nuk kanë një renditje totale.
/// Për shembull, për numrat e pikave lundruese, `NaN < 0 == false` dhe `NaN >= 0 == false` (shih.
/// Seksioni IEEE 754-2008 5.11).
///
/// `PartialOrd` kërkon që lloji juaj të jetë [`PartialEq`].
///
/// Zbatimet e [`PartialEq`], `PartialOrd` dhe [`Ord`]*duhet* të bien dakord me njëri-tjetrin.
/// Easyshtë e lehtë t`i bësh aksidentalisht që të mos pajtohen duke nxjerrë disa nga traits dhe duke zbatuar manualisht të tjerët.
///
/// Nëse lloji juaj është [`Ord`], ju mund të implementoni [`partial_cmp`] duke përdorur [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Ju gjithashtu mund të gjeni të dobishme të përdorni [`partial_cmp`] në fushat e llojit tuaj.
/// Këtu është një shembull i llojeve `Person` të cilët kanë një fushë `height` me pikë lundruese që është fusha e vetme që përdoret për klasifikimin:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Kjo metodë kthen një renditje ndërmjet vlerave `self` dhe `other` nëse ekziston.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Kur krahasimi është i pamundur:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Kjo metodë teston më pak se (për `self` dhe `other`) dhe përdoret nga operatori `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Kjo metodë teston më pak ose e barabartë me (për `self` dhe `other`) dhe përdoret nga operatori `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Kjo metodë teston më shumë se (për `self` dhe `other`) dhe përdoret nga operatori `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Kjo metodë testohet më e madhe ose e barabartë me (për `self` dhe `other`) dhe përdoret nga operatori `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Nxjerr makro që gjeneron një impl të trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Krahason dhe kthen minimumin e dy vlerave.
///
/// Kthen argumentin e parë nëse krahasimi i përcakton ata të jenë të barabartë.
///
/// Brenda saj përdor një pseudonim për [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Kthen minimumin e dy vlerave në lidhje me funksionin e specifikuar të krahasimit.
///
/// Kthen argumentin e parë nëse krahasimi i përcakton ata të jenë të barabartë.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Kthen elementin që jep vlerën minimale nga funksioni i specifikuar.
///
/// Kthen argumentin e parë nëse krahasimi i përcakton ata të jenë të barabartë.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Krahason dhe kthen maksimumin e dy vlerave.
///
/// Kthen argumentin e dytë nëse krahasimi i përcakton ata të jenë të barabartë.
///
/// Brenda saj përdor një pseudonim për [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Kthen maksimumin e dy vlerave në lidhje me funksionin e specifikuar të krahasimit.
///
/// Kthen argumentin e dytë nëse krahasimi i përcakton ata të jenë të barabartë.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Kthen elementin që jep vlerën maksimale nga funksioni i specifikuar.
///
/// Kthen argumentin e dytë nëse krahasimi i përcakton ata të jenë të barabartë.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Zbatimi i PartialEq, Eq, PartialOrd dhe Ord për llojet primitive
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Rendi këtu është i rëndësishëm për të gjeneruar një montim më optimal.
                    // Shihni <https://github.com/rust-lang/rust/issues/63758> për më shumë informacion.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Hedhja në i8 dhe shndërrimi i ndryshimit në një Renditje gjeneron një montim më optimal.
            //
            // Shihni <https://github.com/rust-lang/rust/issues/66780> për më shumë informacion.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SIGURIA: bool pasi i8 kthen 0 ose 1, kështu që ndryshimi nuk mund të jetë asgjë tjetër
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &tregues

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}