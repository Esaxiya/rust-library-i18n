//! Kontejnerë të ndryshueshëm.
//!
//! Siguria e kujtesës Rust bazohet në këtë rregull: Duke pasur parasysh një objekt `T`, është e mundur të keni vetëm një nga sa vijon:
//!
//! - Duke pasur disa referenca të pandryshueshme (`&T`) për objektin (i njohur gjithashtu si **aliasing**).
//! - Duke pasur një referencë të ndryshueshme (`&mut T`) për objektin (i njohur gjithashtu si **ndryshueshmëri**).
//!
//! Kjo zbatohet nga përpiluesi Rust.Sidoqoftë, ka situata kur ky rregull nuk është mjaft fleksibël.Ndonjëherë kërkohet që të ketë referenca të shumëfishta për një objekt dhe prapëseprapë ta shndërrosh atë.
//!
//! Ekzistojnë kontejnerë të ndryshueshëm të ndryshueshëm për të lejuar ndryshueshmërinë në një mënyrë të kontrolluar, madje edhe në prani të aliasing.Të dy [`Cell<T>`] dhe [`RefCell<T>`] lejojnë ta bëjnë këtë në një mënyrë të vetme.
//! Sidoqoftë, as `Cell<T>` dhe as `RefCell<T>` nuk janë të sigurt për fije (nuk zbatojnë [`Sync`]).
//! Nëse keni nevojë të bëni aliasing dhe mutacion midis fijeve të shumta është e mundur të përdorni lloje [`Mutex<T>`], [`RwLock<T>`] ose [`atomic`].
//!
//! Vlerat e llojeve `Cell<T>` dhe `RefCell<T>` mund të ndryshohen përmes referencave të ndara (dmth.)
//! tipi i zakonshëm `&T`), ndërsa shumica e llojeve Rust mund të mutohen vetëm përmes referencave unike (`&mut T`).
//! Ne themi që `Cell<T>` dhe `RefCell<T>` sigurojnë 'ndryshueshmëri të brendshme', në kontrast me llojet tipike Rust që shfaqin 'ndryshueshmëri të trashëguar'.
//!
//! Llojet e qelizave vijnë në dy aromë: `Cell<T>` dhe `RefCell<T>`.`Cell<T>` zbaton ndryshueshmërinë e brendshme duke lëvizur vlerat brenda dhe jashtë `Cell<T>`.
//! Për të përdorur referenca në vend të vlerave, duhet të përdorni llojin `RefCell<T>`, duke marrë një bllokim shkrimi përpara se të mutoni.`Cell<T>` ofron metoda për të marrë dhe ndryshuar vlerën aktuale të brendshme:
//!
//!  - Për llojet që implementojnë [`Copy`], metoda [`get`](Cell::get) rimerr vlerën aktuale të brendshme.
//!  - Për llojet që implementojnë [`Default`], metoda [`take`](Cell::take) zëvendëson vlerën aktuale të brendshme me [`Default::default()`] dhe kthen vlerën e zëvendësuar.
//!  - Për të gjitha llojet, metoda [`replace`](Cell::replace) zëvendëson vlerën aktuale të brendshme dhe kthen vlerën e zëvendësuar dhe metoda [`into_inner`](Cell::into_inner) konsumon `Cell<T>` dhe kthen vlerën e brendshme.
//!  Për më tepër, metoda [`set`](Cell::set) zëvendëson vlerën e brendshme, duke ulur vlerën e zëvendësuar.
//!
//! `RefCell<T>` përdor jetën e Rust për të zbatuar 'huazimin dinamik', një proces ku dikush mund të pretendojë qasje të përkohshme, ekskluzive, të paqëndrueshme në vlerën e brendshme.
//! Borrows për `RefCell<T>`s gjurmohen 'gjatë ekzekutimit', ndryshe nga llojet e referencës vendase të Rust të cilat gjurmohen tërësisht në mënyrë statike, në kohën e përpilimit.
//! Për shkak se huatë `RefCell<T>` janë dinamike është e mundur të përpiqesh të huazosh një vlerë që tashmë është huazuar në mënyrë të paqëndrueshme;kur kjo ndodh rezulton në fillin panic.
//!
//! # Kur të zgjidhni ndryshueshmërinë e brendshme
//!
//! Ndryshueshmëria e trashëguar më e zakonshme, ku dikush duhet të ketë qasje unike për të ndryshuar një vlerë, është një nga elementët kryesorë të gjuhës që i mundëson Rust të arsyetojë fort rreth aliasing të treguesit, duke parandaluar në mënyrë statike gabimet e ndërprerjes.
//! Për shkak të kësaj, paqëndrueshmëria e trashëguar preferohet, dhe paqëndrueshmëria e brendshme është diçka si një mundësi e fundit.
//! Meqenëse llojet e qelizave mundësojnë mutacionin nëse përndryshe nuk do të lejohej, ka raste kur mutacioni i brendshëm mund të jetë i përshtatshëm, ose madje *duhet* të përdoret, p.sh.
//!
//! * Futja e ndryshueshmërisë 'inside' të diçkaje të pandryshueshme
//! * Detajet e zbatimit të metodave logjikisht të pandryshueshme.
//! * Zbatimi i mutacionit të [`Clone`].
//!
//! ## Futja e ndryshueshmërisë 'inside' të diçkaje të pandryshueshme
//!
//! Shumë lloje të treguesve inteligjentë të përbashkët, përfshirë [`Rc<T>`] dhe [`Arc<T>`], ofrojnë kontejnerë që mund të klonohen dhe ndahen midis palëve të shumta.
//! Meqenëse vlerat e përmbajtura mund të jenë aliasive të shumëzimit, ato mund të huazohen vetëm me `&`, jo `&mut`.
//! Pa qeliza do të ishte e pamundur mutacioni i të dhënave brenda këtyre treguesve inteligjentë fare.
//!
//! Veryshtë shumë e zakonshme të vendosësh një `RefCell<T>` brenda llojeve të treguesve të përbashkët për të rivendosur ndryshueshmërinë:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Krijoni një bllok të ri për të kufizuar fushën e huazimit dinamik
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Vini re se nëse nuk do të kishim lejuar huazimin e mëparshëm të cache-it të binte jashtë fushës, huazimi pasues do të shkaktonte një fije dinamike panic.
//!     //
//!     // Ky është rreziku kryesor i përdorimit të `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Vini re se ky shembull përdor `Rc<T>` dhe jo `Arc<T>`.`RefCell<T>`s janë për skenarë me një fije.Konsideroni përdorimin e [`RwLock<T>`] ose [`Mutex<T>`] nëse keni nevojë për ndryshueshmëri të përbashkët në një situatë me shumë fije.
//!
//! ## Detajet e zbatimit të metodave logjikisht të pandryshueshme
//!
//! Ndonjëherë mund të jetë e dëshirueshme që të mos ekspozohet në një API që ka mutacion "under the hood".
//! Kjo mund të jetë sepse logjikisht operacioni është i pandryshueshëm, por p.sh., caching detyron zbatimin për të kryer mutacion;ose sepse duhet të përdorni mutacion për të zbatuar një metodë trait që fillimisht ishte përcaktuar për të marrë `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Llogaritja e shtrenjtë shkon këtu
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Zbatimi i mutacionit të `Clone`
//!
//! Ky është thjesht një rast i veçantë, por i zakonshëm, i mëparshëm: fshehja e ndryshueshmërisë për operacionet që duken të jenë të pandryshueshme.
//! Metoda [`clone`](Clone::clone) pritet të mos ndryshojë vlerën e burimit dhe deklarohet të marrë `&self`, jo `&mut self`.
//! Prandaj, çdo mutacion që ndodh në metodën `clone` duhet të përdorë llojet e qelizave.
//! Për shembull, [`Rc<T>`] mban numrin e referencës brenda një `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Një vendndodhje memorie e ndryshueshme.
///
/// # Examples
///
/// Në këtë shembull, ju mund të shihni se `Cell<T>` mundëson mutacionin brenda një strukture të pandryshueshme.
/// Me fjalë të tjera, ai mundëson "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // GABIMI: `my_struct` është i pandryshueshëm
/// // my_struct.regular_field =vlera e re;
///
/// // PUNT: megjithëse `my_struct` është i pandryshueshëm, `special_field` është një `Cell`,
/// // e cila gjithmonë mund të shndërrohet
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Shihni [module-level documentation](self) për më shumë.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Krijon një `Cell<T>`, me vlerën `Default` për T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Krijon një `Cell` të ri që përmban vlerën e dhënë.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Vendos vlerën e përmbajtur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Ndërron vlerat e dy qelizave.
    /// Dallimi me `std::mem::swap` është se ky funksion nuk kërkon referencë `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SIGURIA: Kjo mund të jetë e rrezikshme nëse thirret nga fije të veçanta, por `Cell`
        // është `!Sync` kështu që kjo nuk do të ndodhë.
        // Kjo gjithashtu nuk do të zhvlerësojë asnjë tregues pasi `Cell` sigurohet që asgjë tjetër nuk do të tregojë në asnjërën nga këto `Qeliza`.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Zëvendëson vlerën e përmbajtur me `val` dhe kthen vlerën e vjetër të përmbajtur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SIGURIA: Kjo mund të shkaktojë gara të dhënash nëse thirret nga një fije e veçantë,
        // por `Cell` është `!Sync` kështu që kjo nuk do të ndodhë.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Zbulon vlerën.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Kthen një kopje të vlerës së përmbajtur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SIGURIA: Kjo mund të shkaktojë gara të dhënash nëse thirret nga një fije e veçantë,
        // por `Cell` është `!Sync` kështu që kjo nuk do të ndodhë.
        unsafe { *self.value.get() }
    }

    /// Përditëson vlerën e përmbajtur duke përdorur një funksion dhe kthen vlerën e re.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Kthen një tregues të papërpunuar te të dhënat themelore në këtë qelizë.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Kthen një referencë të ndryshueshme në të dhënat themelore.
    ///
    /// Kjo thirrje merr hua `Cell` në mënyrë të pandryshueshme (në kohën e përpilimit) e cila garanton që ne të kemi referencën e vetme.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Kthen një `&Cell<T>` nga një `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SIGURIA: `&mut` siguron qasje unike.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Merr vlerën e qelizës, duke e lënë `Default::default()` në vendin e saj.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Kthen një `&[Cell<T>]` nga një `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SIGURIA: `Cell<T>` ka të njëjtën paraqitje të kujtesës si `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Një vendndodhje memorje e ndryshueshme me rregulla huazimi të kontrolluara dinamikisht
///
/// Shihni [module-level documentation](self) për më shumë.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Një gabim i kthyer nga [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Një gabim i kthyer nga [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Vlerat pozitive paraqesin numrin e `Ref` aktiv.Vlerat negative paraqesin numrin e `RefMut` aktiv.
// RefMut-të e shumëfishta mund të jenë aktive në të njëjtën kohë nëse ato u referohen përbërësve të veçantë, jo mbivendosës të një `RefCell` (p.sh., diapazone të ndryshme të një fete).
//
// `Ref` dhe `RefMut` janë të dyja me madhësi të dyja, dhe kështu që ka të ngjarë të mos ketë kurrë `Ref` ose`RefMut` në ekzistencë për të tejkaluar gjysmën e gamës `usize`.
// Kështu, një `BorrowFlag` ndoshta nuk do të mbingarkojë ose mbingarkojë kurrë.
// Sidoqoftë, kjo nuk është një garanci, pasi një program patologjik mund të krijojë në mënyrë të përsëritur dhe më pas mem::forget `Ref` s ose `RefMut` s.
// Kështu, i gjithë kodi duhet të kontrollojë në mënyrë të qartë për mbingarkesë dhe mbingarkesë në mënyrë që të shmangë pasigurinë, ose të paktën të sillet si duhet në rast se ndodh mbingarkesa ose mbingarkesa (p.sh., shiko BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Krijon një `RefCell` të ri që përmban `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Konsumon `RefCell`, duke kthyer vlerën e mbështjellur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Meqenëse ky funksion merr `self` (`RefCell`) me vlerë, përpiluesi verifikon statistikisht se nuk është huazuar aktualisht.
        //
        self.value.into_inner()
    }

    /// Zëvendëson vlerën e mbështjellë me një të re, duke kthyer vlerën e vjetër, pa deinitializuar as njërën.
    ///
    ///
    /// Ky funksion korrespondon me [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics nëse vlera është huazuar aktualisht.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Zëvendëson vlerën e mbështjellë me një të re të llogaritur nga `f`, duke kthyer vlerën e vjetër, pa deinitializuar as njërën.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse vlera është huazuar aktualisht.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Ndërron vlerën e mbështjellë të `self` me vlerën e mbështjellë të `other`, pa deinitializuar as njërën.
    ///
    ///
    /// Ky funksion korrespondon me [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics nëse vlera ose në `RefCell` është aktualisht e huazuar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Huazon në mënyrë të pandryshueshme vlerën e mbështjellë.
    ///
    /// Huamarrja zgjat derisa `Ref` i kthyer të dalë nga fushëveprimi.
    /// Huazime të shumta të pandryshueshme mund të merren në të njëjtën kohë.
    ///
    /// # Panics
    ///
    /// Panics nëse vlera aktualisht është huazuar në mënyrë të paqëndrueshme.
    /// Për një variant pa panik, përdorni [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Një shembull i panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Huazon në mënyrë të pandryshueshme vlerën e mbështjellë, duke kthyer një gabim nëse vlera aktualisht është huazuar në mënyrë të paqëndrueshme.
    ///
    ///
    /// Huamarrja zgjat derisa `Ref` i kthyer të dalë nga fushëveprimi.
    /// Huazime të shumta të pandryshueshme mund të merren në të njëjtën kohë.
    ///
    /// Ky është varianti jo-panik i [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SIGURIA: `BorrowRef` siguron që ka vetëm qasje të pandryshueshme
            // te vlera ndërsa është huazuar.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Huazon në mënyrë të pandryshueshme vlerën e mbështjellë.
    ///
    /// Huamarrja zgjat derisa `RefMut` i kthyer ose i gjithë `RefMut` i prejardhur prej tij të dalë nga fushëveprimi.
    ///
    /// Vlera nuk mund të huazohet ndërsa kjo hua është aktive.
    ///
    /// # Panics
    ///
    /// Panics nëse vlera është huazuar aktualisht.
    /// Për një variant pa panik, përdorni [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Një shembull i panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Huazon në mënyrë të pandryshueshme vlerën e mbështjellë, duke kthyer një gabim nëse vlera është huazuar aktualisht.
    ///
    ///
    /// Huamarrja zgjat derisa `RefMut` i kthyer ose i gjithë `RefMut` i prejardhur prej tij të dalë nga fushëveprimi.
    /// Vlera nuk mund të huazohet ndërsa kjo hua është aktive.
    ///
    /// Ky është varianti jo-panik i [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SIGURIA: `BorrowRef` garanton qasje unike.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Kthen një tregues të papërpunuar te të dhënat themelore në këtë qelizë.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Kthen një referencë të ndryshueshme në të dhënat themelore.
    ///
    /// Kjo thirrje merr hua `RefCell` në mënyrë të pandryshueshme (në kohën e përpilimit) kështu që nuk ka nevojë për kontrolle dinamike.
    ///
    /// Sidoqoftë jini të kujdesshëm: kjo metodë pret që `self` të jetë e paqëndrueshme, gjë që zakonisht nuk ndodh kur përdorni `RefCell`.
    ///
    /// Shikoni metodën [`borrow_mut`] në vend të kësaj nëse `self` nuk është i ndryshueshëm.
    ///
    /// Gjithashtu, ju lutem kini kujdes se kjo metodë është vetëm për rrethana të veçanta dhe zakonisht nuk është ajo që dëshironi.
    /// Në rast dyshimi, përdorni [`borrow_mut`] në vend.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Zhbëj efektin e rojeve të rrjedhura në gjendjen e huazimit të `RefCell`.
    ///
    /// Kjo thirrje është e ngjashme me [`get_mut`] por më e specializuar.
    /// Huazon `RefCell` në mënyrë të pandryshueshme për të siguruar që nuk ekzistojnë hua dhe më pas rivendos gjendjen që ndjek huazimet e ndara.
    /// Kjo është e rëndësishme nëse disa hua `Ref` ose `RefMut` janë zbuluar.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Huazon në mënyrë të pandryshueshme vlerën e mbështjellë, duke kthyer një gabim nëse vlera aktualisht është huazuar në mënyrë të paqëndrueshme.
    ///
    /// # Safety
    ///
    /// Ndryshe nga `RefCell::borrow`, kjo metodë është e pasigurt sepse nuk kthen një `Ref`, duke lënë kështu flamurin e huazimit të paprekur.
    /// Huazimi i pandryshueshëm i `RefCell` ndërsa referenca e kthyer nga kjo metodë është e gjallë është një sjellje e papërcaktuar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SIGURIA: Ne kontrollojmë që askush nuk po shkruan në mënyrë aktive tani, por po
            // përgjegjësia e thirrësit për të siguruar që askush të mos shkruajë derisa referenca e kthyer të mos përdoret më.
            // Gjithashtu, `self.value.get()` i referohet vlerës që zotëron `self` dhe kështu garantohet të jetë e vlefshme për jetëgjatësinë e `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Merr vlerën e mbështjellë, duke e lënë `Default::default()` në vendin e vet.
    ///
    /// # Panics
    ///
    /// Panics nëse vlera është huazuar aktualisht.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics nëse vlera aktualisht është huazuar në mënyrë të paqëndrueshme.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Krijon një `RefCell<T>`, me vlerën `Default` për T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics nëse vlera ose në `RefCell` është aktualisht e huazuar.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics nëse vlera ose në `RefCell` është aktualisht e huazuar.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics nëse vlera ose në `RefCell` është aktualisht e huazuar.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics nëse vlera ose në `RefCell` është aktualisht e huazuar.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics nëse vlera ose në `RefCell` është aktualisht e huazuar.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics nëse vlera ose në `RefCell` është aktualisht e huazuar.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics nëse vlera ose në `RefCell` është aktualisht e huazuar.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Rritja e huasë mund të rezultojë në një vlerë jo-lexuese (<=0) në këto raste:
            // 1. Ishte <0, dmth ka huazime me shkrim, kështu që ne nuk mund të lejojmë një hua të lexuar për shkak të rregullave aliasing të Rust
            // 2.
            // Ishte isize::MAX (shuma maksimale e huazimeve të leximit) dhe u tejmbush në isize::MIN (shuma maksimale e huazimeve të shkrimit) kështu që nuk mund të lejojmë një hua shtesë leximi sepse izizimi nuk përfaqëson kaq shumë hua të lexuara (kjo mund të ndodhë vetëm nëse ju mem::forget më shumë se një sasi e vogël konstante e `Ref`, e cila nuk është praktikë e mirë)
            //
            //
            //
            //
            None
        } else {
            // Rritja e huasë mund të rezultojë në një vlerë leximi (> 0) në këto raste:
            // 1. Ishte=0, dmth nuk ishte huazuar, dhe ne po marrim huazimin e parë të lexuar
            // 2. Ishte> 0 dhe <isize::MAX, dmth
            // kishte huazime të lexuara, dhe izizimi është mjaft i madh për të përfaqësuar të paturit e një huazimi më të lexuar
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Meqenëse kjo Ref ekziston, ne e dimë që flamuri i huazimit është një hua e lexuar.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Parandaloni që counter-i i huazimit të tejkalohet në një hua me shkrim.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Përfundon një referencë të huazuar për një vlerë në një kuti `RefCell`.
/// Një tip mbështjellës për një vlerë të huazuar në mënyrë të pandryshueshme nga një `RefCell<T>`.
///
/// Shihni [module-level documentation](self) për më shumë.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopjon një `Ref`.
    ///
    /// `RefCell` tashmë është huazuar në mënyrë të pandryshueshme, kështu që kjo nuk mund të dështojë.
    ///
    /// Ky është një funksion i lidhur që duhet të përdoret si `Ref::clone(...)`.
    /// Një zbatim `Clone` ose një metodë do të ndërhynte në përdorimin e gjerë të `r.borrow().clone()` për të klonuar përmbajtjen e një `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Bën një `Ref` të ri për një përbërës të të dhënave të huazuara.
    ///
    /// `RefCell` tashmë është huazuar në mënyrë të pandryshueshme, kështu që kjo nuk mund të dështojë.
    ///
    /// Ky është një funksion i lidhur që duhet të përdoret si `Ref::map(...)`.
    /// Një metodë do të ndërhynte me metodat me të njëjtin emër në përmbajtjen e një `RefCell` të përdorur përmes `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Bën një `Ref` të ri për një përbërës opsional të të dhënave të huazuara.
    /// Garda origjinale kthehet si `Err(..)` nëse mbyllja kthen `None`.
    ///
    /// `RefCell` tashmë është huazuar në mënyrë të pandryshueshme, kështu që kjo nuk mund të dështojë.
    ///
    /// Ky është një funksion i lidhur që duhet të përdoret si `Ref::filter_map(...)`.
    /// Një metodë do të ndërhynte me metodat me të njëjtin emër në përmbajtjen e një `RefCell` të përdorur përmes `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Ndan një `Ref` në Ref `të shumëfishtë për përbërës të ndryshëm të të dhënave të huazuara.
    ///
    /// `RefCell` tashmë është huazuar në mënyrë të pandryshueshme, kështu që kjo nuk mund të dështojë.
    ///
    /// Ky është një funksion i lidhur që duhet të përdoret si `Ref::map_split(...)`.
    /// Një metodë do të ndërhynte me metodat me të njëjtin emër në përmbajtjen e një `RefCell` të përdorur përmes `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Shndërroni në një referencë në të dhënat themelore.
    ///
    /// `RefCell` themelor kurrë nuk mund të huazohet në mënyrë të pandryshueshme dhe do të shfaqet gjithmonë i huazuar në mënyrë të pandryshueshme.
    ///
    /// Nuk është ide e mirë të dilni më shumë sesa një numër konstant i referencave.
    /// `RefCell` mund të huazohet në mënyrë të pandryshueshme përsëri nëse vetëm një numër më i vogël i rrjedhjeve kanë ndodhur.
    ///
    /// Ky është një funksion i lidhur që duhet të përdoret si `Ref::leak(...)`.
    /// Një metodë do të ndërhynte me metodat me të njëjtin emër në përmbajtjen e një `RefCell` të përdorur përmes `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Duke harruar këtë Ref, ne sigurojmë që banaku i huazimit në RefCell nuk mund të kthehet te PUSRDORUR brenda jetës `'b`.
        // Rivendosja e gjendjes së ndjekjes së referencës do të kërkonte një referencë unike për RefCell të huazuar.
        // Asnjë referencë e mëtejshme e paqëndrueshme nuk mund të krijohet nga qeliza origjinale.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Bën një `RefMut` të ri për një përbërës të të dhënave të huazuara, p.sh., një variant enum.
    ///
    /// `RefCell` tashmë është huazuar në mënyrë të paqëndrueshme, kështu që kjo nuk mund të dështojë.
    ///
    /// Ky është një funksion i lidhur që duhet të përdoret si `RefMut::map(...)`.
    /// Një metodë do të ndërhynte me metodat me të njëjtin emër në përmbajtjen e një `RefCell` të përdorur përmes `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): rregulloj kontrollin e huazimit
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Bën një `RefMut` të ri për një përbërës opsional të të dhënave të huazuara.
    /// Garda origjinale kthehet si `Err(..)` nëse mbyllja kthen `None`.
    ///
    /// `RefCell` tashmë është huazuar në mënyrë të paqëndrueshme, kështu që kjo nuk mund të dështojë.
    ///
    /// Ky është një funksion i lidhur që duhet të përdoret si `RefMut::filter_map(...)`.
    /// Një metodë do të ndërhynte me metodat me të njëjtin emër në përmbajtjen e një `RefCell` të përdorur përmes `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): rregulloj kontrollin e huazimit
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SIGURIA: funksioni mban një referencë ekskluzive për kohëzgjatjen
        // të thirrjes së tij përmes `orig`, dhe treguesi de-referohet vetëm brenda thirrjes së funksionit, duke mos lejuar kurrë që referenca ekskluzive të shpëtojë.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SIGURIA: njësoj si më sipër.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Ndan një `RefMut` në `RefMut` të shumëfishtë për përbërës të ndryshëm të të dhënave të huazuara.
    ///
    /// `RefCell` themelor do të mbetet i huazuar në mënyrë të paqëndrueshme derisa të dy `RefMut` e kthyer nuk dalin nga fusha e veprimit.
    ///
    /// `RefCell` tashmë është huazuar në mënyrë të paqëndrueshme, kështu që kjo nuk mund të dështojë.
    ///
    /// Ky është një funksion i lidhur që duhet të përdoret si `RefMut::map_split(...)`.
    /// Një metodë do të ndërhynte me metodat me të njëjtin emër në përmbajtjen e një `RefCell` të përdorur përmes `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Shndërroni në një referencë të ndryshueshme për të dhënat themelore.
    ///
    /// `RefCell` themelor nuk mund të merret hua përsëri dhe do të shfaqet gjithmonë i huazuar në mënyrë të paqëndrueshme, duke e bërë referencën e kthyer të vetmen në pjesën e brendshme.
    ///
    ///
    /// Ky është një funksion i lidhur që duhet të përdoret si `RefMut::leak(...)`.
    /// Një metodë do të ndërhynte me metodat me të njëjtin emër në përmbajtjen e një `RefCell` të përdorur përmes `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Duke harruar këtë BorrowRefMut ne sigurojmë që banaku i huazimit në RefCell nuk mund të kthehet te PUSRDORUR brenda jetës `'b`.
        // Rivendosja e gjendjes së ndjekjes së referencës do të kërkonte një referencë unike për RefCell të huazuar.
        // Asnjë referencë e mëtejshme nuk mund të krijohet nga qeliza origjinale brenda asaj jete, duke e bërë huazimin aktual të vetmen referencë për jetën e mbetur.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Ndryshe nga BorrowRefMut::clone, i ri thirret për të krijuar fillestarin
        // referencë e ndryshueshme, dhe kështu që aktualisht nuk duhet të ketë referenca ekzistuese.
        // Kështu, ndërsa kloni rrit zbritjen e paqëndrueshme, këtu ne në mënyrë të qartë lejojmë vetëm kalimin nga të PUSRDORUR në të papërdorur, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klonon një `BorrowRefMut`.
    //
    // Kjo është e vlefshme vetëm nëse çdo `BorrowRefMut` përdoret për të gjurmuar një referencë të ndryshueshme në një gamë të veçantë, pa mbivendosje të objektit origjinal.
    //
    // Kjo nuk është në një nënkuptim të Klonit, kështu që kodi nuk e quan këtë në mënyrë të nënkuptuar.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Parandalon numëruesin e huazimit nga mbingarkesa.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Një tip mbështjellës për një vlerë të huazuar në mënyrë të paqëndrueshme nga një `RefCell<T>`.
///
/// Shihni [module-level documentation](self) për më shumë.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Primitivi kryesor për ndryshueshmërinë e brendshme në Rust.
///
/// Nëse keni një referencë `&T`, atëherë normalisht në Rust përpiluesi kryen optimizime bazuar në njohuritë që `&T` tregon për të dhëna të pandryshueshme.Ndryshimi i atyre të dhënave, për shembull përmes një pseudonimi ose duke shndërruar një `&T` në një `&mut T`, konsiderohet sjellje e papërcaktuar.
/// `UnsafeCell<T>` përjashton garancinë e pandryshueshmërisë për `&T`: një referencë e përbashkët `&UnsafeCell<T>` mund të tregojë në të dhëna që janë mutuar.Kjo quhet "interior mutability".
///
/// Të gjithë llojet e tjerë që lejojnë ndryshueshmërinë e brendshme, të tilla si `Cell<T>` dhe `RefCell<T>`, përdorin përbrenda `UnsafeCell` për të mbështjellë të dhënat e tyre.
///
/// Vini re se vetëm garancia e pandryshueshmërisë për referencat e ndara ndikohet nga `UnsafeCell`.Garancia unike për referencat e ndryshueshme nuk preket.Nuk ka * asnjë mënyrë ligjore për të marrë aliasing `&mut`, madje as me `UnsafeCell<T>`.
///
/// Vetë `UnsafeCell` API është teknikisht shumë e thjeshtë: [`.get()`] ju jep një tregues të papërpunuar `*mut T` për përmbajtjen e tij.Varet nga _you_ si krijuesi i abstraksionit që ta përdorë atë tregues të papërpunuar në mënyrë korrekte.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Rregullat e sakta aliasing të Rust janë disi në fluks, por pikat kryesore nuk janë të diskutueshme:
///
/// - Nëse krijoni një referencë të sigurt me jetëgjatësinë `'a` (qoftë një referencë `&T` ose `&mut T`) që është e arritshme nga një kod i sigurt (për shembull, sepse e keni kthyer atë), atëherë nuk duhet të përdorni të dhënat në asnjë mënyrë që bie në kundërshtim me atë referencë për pjesën e mbetur të `'a`.
/// Për shembull, kjo do të thotë që nëse merrni `*mut T` nga një `UnsafeCell<T>` dhe e hidhni në një `&T`, atëherë të dhënat në `T` duhet të mbeten të pandryshueshme (modulo çdo të dhënë `UnsafeCell` e gjetur brenda `T`, natyrisht) derisa të mbarojë jeta e kësaj reference.
/// Në mënyrë të ngjashme, nëse krijoni një referencë `&mut T` që lëshohet në kod të sigurt, atëherë nuk duhet të përdorni të dhënat brenda `UnsafeCell` derisa të skadojë ajo referencë.
///
/// - Në çdo kohë, duhet të shmangni garën e të dhënave.Nëse shumë fije kanë qasje në të njëjtën `UnsafeCell`, atëherë çdo shkrim duhet të ketë një lidhje të duhur-ndodh para se të gjitha hyrjet e tjera (ose të përdorin atomikën).
///
/// Për të ndihmuar në hartimin e duhur, skenarët e mëposhtëm deklarohen shprehimisht të ligjshëm për kodin me një fije:
///
/// 1. Një referencë `&T` mund të lëshohet në një kod të sigurt dhe atje mund të bashkëjetojë me referenca të tjera `&T`, por jo me një `&mut T`
///
/// 2. Një referencë `&mut T` mund të lëshohet në kodin e sigurt me kusht që as `&mut T` e as `&T` tjetër të mos ekzistojnë me të.Një `&mut T` duhet të jetë gjithnjë unik.
///
/// Vini re se ndërsa mutimi i përmbajtjes së një `&UnsafeCell<T>` (edhe pse referencat e tjera `&UnsafeCell<T>` alias qeliza) është në rregull (me kusht që të zbatoni invariancat e mësipërme në një mënyrë tjetër), është akoma sjellje e papërcaktuar që të keni pseudonime të shumta `&mut UnsafeCell<T>`.
/// Kjo është, `UnsafeCell` është një mbështjellës i krijuar për të pasur një bashkëveprim të veçantë me _shared_ accesses (_i.e._, përmes një referencë `&UnsafeCell<_>`);nuk ka asnjë magji kur kemi të bëjmë me _exclusive_ accesses (_e.g._, përmes një `&mut UnsafeCell<_>`): as qeliza dhe as vlera e mbështjellur nuk mund të tjetërsohen për kohëzgjatjen e asaj huazimi `&mut`.
///
/// Kjo shfaqet nga aksesori [`.get_mut()`], i cili është një _safe_ getter që jep një `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Këtu është një shembull që tregon se si të shndërrosh në mënyrë të shëndoshë përmbajtjen e një `UnsafeCell<_>` pavarësisht se ka referenca të shumta që aliasing qelizë:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Merrni referenca të shumëfishta/njëkohësisht/të ndara për të njëjtën `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SIGURIA: brenda këtij qëllimi nuk ka referenca të tjera për përmbajtjen e `x`,
///     // kështu që jona është efektivisht unike.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- huazoni-+
///     *p1_exclusive += 27; // |
/// } // <---------- nuk mund të shkojë përtej kësaj pike -------------------+
///
/// unsafe {
///     // SIGURIA: brenda këtij qëllimi askush nuk pret të ketë qasje ekskluzive në përmbajtjen e `x`,
///     // kështu që ne mund të kemi qasje të shumëfishta të përbashkëta njëkohësisht.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Shembulli i mëposhtëm tregon faktin se hyrja ekskluzive në një `UnsafeCell<T>` nënkupton qasje ekskluzive në `T` të saj:
///
/// ```rust
/// #![forbid(unsafe_code)] // me hyrje ekskluzive,
///                         // `UnsafeCell` është një mbështjellës transparent pa opsione, prandaj nuk ka nevojë për `unsafe` këtu.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Merrni një referencë unike të kontrolluar nga koha e përpilimit për `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Me një referencë ekskluzive, ne mund t'i mutojmë falas përmbajtjet.
/// *p_unique.get_mut() = 0;
/// // Ose, në mënyrë ekuivalente:
/// x = UnsafeCell::new(0);
///
/// // Kur zotërojmë vlerën, mund t'i nxjerrim përmbajtjet falas.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Ndërton një shembull të ri të `UnsafeCell` i cili do të mbështjellë vlerën e specifikuar.
    ///
    ///
    /// E gjithë qasja në vlerën e brendshme përmes metodave është `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Zbulon vlerën.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Merr një tregues të ndryshueshëm në vlerën e mbështjellur.
    ///
    /// Kjo mund të hidhet në një tregues të çdo lloji.
    /// Sigurohuni që hyrja të jetë unike (pa referenca aktive, të ndryshueshme ose jo) kur hidhet në `&mut T` dhe sigurohuni që të mos ketë mutacione ose pseudonime të paqëndrueshme kur hidhni në `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Thjesht mund ta hedhim treguesin nga `UnsafeCell<T>` në `T` për shkak të #[repr(transparent)].
        // Kjo shfrytëzon statusin special të libstd, nuk ka asnjë garanci për kodin e përdoruesit se kjo do të funksionojë në versionet future të përpiluesit!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Kthen një referencë të ndryshueshme në të dhënat themelore.
    ///
    /// Kjo thirrje merr hua `UnsafeCell` në mënyrë të pandryshueshme (në kohën e përpilimit) e cila garanton që ne të kemi referencën e vetme.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Merr një tregues të ndryshueshëm në vlerën e mbështjellur.
    /// Dallimi për [`get`] është se ky funksion pranon një tregues të papërpunuar, i cili është i dobishëm për të shmangur krijimin e referencave të përkohshme.
    ///
    /// Rezultati mund të hidhet në një tregues të çdo lloji.
    /// Sigurohuni që hyrja të jetë unike (pa referenca aktive, të ndryshueshme ose jo) kur hidhet në `&mut T` dhe sigurohuni që të mos ketë mutacione ose pseudonime të paqëndrueshme kur hidhni në `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Inicializimi gradual i një `UnsafeCell` kërkon `raw_get`, pasi thirrja e `get` do të kërkonte krijimin e një reference për të dhënat e pa iniciale:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Thjesht mund ta hedhim treguesin nga `UnsafeCell<T>` në `T` për shkak të #[repr(transparent)].
        // Kjo shfrytëzon statusin special të libstd, nuk ka asnjë garanci për kodin e përdoruesit se kjo do të funksionojë në versionet future të përpiluesit!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Krijon një `UnsafeCell`, me vlerën `Default` për T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}