use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Kthen `true` nëse treguesi është nul.
    ///
    /// Vini re se llojet pa madhësi kanë shumë tregues të mundshëm null, pasi merret parasysh vetëm treguesi i të dhënave të papërpunuara, jo gjatësia e tyre, tabela, etj.
    /// Prandaj, dy tregues që janë nul ende nuk mund të krahasohen të barabartë me njëri-tjetrin.
    ///
    /// ## Sjellja gjatë vlerësimit të konst
    ///
    /// Kur ky funksion përdoret gjatë vlerësimit të konstitimit, ai mund të kthejë `false` për treguesit që rezultojnë të jenë nul gjatë kohës së ekzekutimit.
    /// Në mënyrë të veçantë, kur një tregues në ndonjë memorje kompensohet përtej kufijve të tij në një mënyrë të tillë që treguesi që rezulton të jetë nul, funksioni përsëri do të kthejë `false`.
    ///
    /// Nuk ka asnjë mënyrë që CTFE të dijë pozicionin absolut të asaj memorjeje, kështu që ne nuk mund të themi nëse treguesi është nul ose jo.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Krahasoni përmes një gize me një tregues të hollë, kështu që treguesit e yndyrës po konsiderojnë vetëm pjesën e tyre "data" për nul.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Hedh në një tregues të një lloji tjetër.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Zbërthehet një tregues (ndoshta i gjerë) në përbërësit e adresës dhe të meta të dhënave.
    ///
    /// Treguesi mund të rindërtohet më vonë me [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Kthen `None` nëse treguesi është null, ose përndryshe kthen një referencë të përbashkët për vlerën e mbështjellë me `Some`.Nëse vlera mund të mos inicializohet, duhet të përdoret [`as_uninit_ref`] në vend të kësaj.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Kur telefononi këtë metodë, duhet të siguroheni që *ose* treguesi është NULL *ose* të gjitha sa më poshtë janë të vërteta:
    ///
    /// * Treguesi duhet të rreshtohet siç duhet.
    ///
    /// * Duhet të jetë "dereferencable" në kuptimin e përcaktuar në [the module documentation].
    ///
    /// * Treguesi duhet të tregojë në një rast të iniciuar të `T`.
    ///
    /// * Ju duhet të zbatoni rregullat aliasing të Rust, pasi jeta e kthyer `'a` zgjidhet në mënyrë arbitrare dhe nuk pasqyron domosdoshmërisht jetën e vërtetë të të dhënave.
    ///   Veçanërisht, gjatë kohëzgjatjes së kësaj jete, kujtesa në të cilën treguesi tregon nuk duhet të ndryshohet (përveç brenda `UnsafeCell`).
    ///
    /// Kjo vlen edhe nëse rezultati i kësaj metode është i papërdorur!
    /// (Pjesa për inicimin nuk është vendosur ende plotësisht, por derisa të bëhet, e vetmja mënyrë e sigurt është të sigurohet që ato të iniciohen me të vërtetë.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Version i pazgjedhur
    ///
    /// Nëse jeni i sigurt që treguesi nuk mund të jetë kurrë nul dhe po kërkoni një lloj `as_ref_unchecked` që kthen `&T` në vend të `Option<&T>`, dijeni që mund ta zhvendosni direkt treguesin.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SIGURIA: thirrësi duhet të garantojë se `self` është i vlefshëm
        // për një referencë nëse nuk është nul.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Kthen `None` nëse treguesi është null, ose përndryshe kthen një referencë të përbashkët për vlerën e mbështjellë me `Some`.
    /// Në kontrast me [`as_ref`], kjo nuk kërkon që vlera të iniciohet.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Kur telefononi këtë metodë, duhet të siguroheni që *ose* treguesi është NULL *ose* të gjitha sa më poshtë janë të vërteta:
    ///
    /// * Treguesi duhet të rreshtohet siç duhet.
    ///
    /// * Duhet të jetë "dereferencable" në kuptimin e përcaktuar në [the module documentation].
    ///
    /// * Ju duhet të zbatoni rregullat aliasing të Rust, pasi jeta e kthyer `'a` zgjidhet në mënyrë arbitrare dhe nuk pasqyron domosdoshmërisht jetën e vërtetë të të dhënave.
    ///
    ///   Veçanërisht, gjatë kohëzgjatjes së kësaj jete, kujtesa në të cilën treguesi tregon nuk duhet të ndryshohet (përveç brenda `UnsafeCell`).
    ///
    /// Kjo vlen edhe nëse rezultati i kësaj metode është i papërdorur!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SIGURIA: thirrësi duhet të garantojë që `self` plotëson të gjitha pajisjet
        // kërkesat për një referencë.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Llogarit kompensimin nga një tregues.
    ///
    /// `count` është në njësi të T;p.sh., një `count` prej 3 përfaqëson një tregues të zhvendosur nga `3 * size_of::<T>()` bajte.
    ///
    /// # Safety
    ///
    /// Nëse ndonjë nga kushtet e mëposhtme shkelet, rezultati është Sjellja e Padefinuar:
    ///
    /// * Si treguesi fillestar, ashtu edhe rezultati, duhet të jenë ose në kufij ose një bajt pas fundit të të njëjtit objekt të caktuar.
    /// Vini re se në Rust, çdo ndryshore (stack-allocated) konsiderohet një objekt i ndarë i ndarë.
    ///
    /// * Kompensimi i llogaritur,**në bajte**, nuk mund të tejkalojë një `isize`.
    ///
    /// * Kompensimi që është në kufij nuk mund të mbështetet në "wrapping around" hapësirën e adresës.Kjo është, shuma me saktësi të pafund,**në bajte** duhet të përshtatet në një përdorim.
    ///
    /// Përpiluesi dhe biblioteka standarde në përgjithësi përpiqen të sigurojnë që alokimet kurrë të mos arrijnë një madhësi kur një kompensim është shqetësues.
    /// Për shembull, `Vec` dhe `Box` sigurojnë që ata kurrë nuk ndajnë më shumë se `isize::MAX` bajte, kështu që `vec.as_ptr().add(vec.len())` është gjithmonë i sigurt.
    ///
    /// Shumica e platformave në thelb as nuk mund të ndërtojnë një alokim të tillë.
    /// Për shembull, asnjë platformë e njohur 64-bit nuk mund të shërbejë kurrë një kërkesë për 2 <sup>63</sup> bajte për shkak të kufizimeve të faqes-tryezë ose ndarjes së hapësirës së adresës.
    /// Sidoqoftë, disa platforma 32-bit dhe 16-bit mund të shërbejnë me sukses një kërkesë për më shumë se `isize::MAX` bajte me gjëra të tilla si Zgjerimi i Adresës Fizike.
    ///
    /// Si e tillë, kujtesa e marrë direkt nga shpërndarësit ose skedarët e shënuar të kujtesës *mund të jetë* shumë e madhe për t'u trajtuar me këtë funksion.
    ///
    /// Merrni parasysh përdorimin e [`wrapping_offset`] në vend se këto kufizime janë të vështira për t'u kënaqur.
    /// Përparësia e vetme e kësaj metode është se ajo mundëson optimizime më agresive të përpiluesit.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Llogarit kompensimin nga një tregues duke përdorur aritmetikën mbështjellëse.
    ///
    /// `count` është në njësi të T;p.sh., një `count` prej 3 përfaqëson një tregues të zhvendosur nga `3 * size_of::<T>()` bajte.
    ///
    /// # Safety
    ///
    /// Ky operacion në vetvete është gjithmonë i sigurt, por përdorimi i treguesit që rezulton nuk është.
    ///
    /// Treguesi që rezulton mbetet i bashkangjitur në të njëjtin objekt të caktuar për të cilin tregon `self`.
    /// Mund të *mos* përdoret për të hyrë në një objekt tjetër të caktuar.Vini re se në Rust, çdo ndryshore (stack-allocated) konsiderohet një objekt i ndarë i ndarë.
    ///
    /// Me fjalë të tjera, `let z = x.wrapping_offset((y as isize) - (x as isize))`*nuk* e bën `z` njësoj si `y` edhe nëse supozojmë se `T` ka madhësi `1` dhe nuk ka tejkalim: `z` është akoma e bashkangjitur në objektin që i është bashkangjitur `x` dhe referimi i tij është Sjellje e Padefinuar përveç nëse `x` dhe `y` drejtohet në të njëjtin objekt të caktuar.
    ///
    /// Krahasuar me [`offset`], kjo metodë në thelb vonon kërkesën për të qëndruar brenda të njëjtit objekt të caktuar: [`offset`] është sjellje e menjëhershme e papërcaktuar kur kalon kufijtë e objektit;`wrapping_offset` prodhon një tregues por prapë çon në Sjellje të Padefinuar nëse një pointer është referuar kur nuk është në kufijtë e objektit në të cilin është bashkangjitur.
    /// [`offset`] mund të optimizohet më mirë dhe kështu preferohet në kodin e ndjeshëm ndaj performancës.
    ///
    /// Kontrolli i vonuar konsideron vetëm vlerën e treguesit që është referuar, jo vlerat e ndërmjetme të përdorura gjatë llogaritjes së rezultatit përfundimtar.
    /// Për shembull, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` është gjithmonë e njëjtë me `x`.Me fjalë të tjera, lejohet lënia e objektit të caktuar dhe pastaj hyrja e tij më vonë.
    ///
    /// Nëse keni nevojë të kaloni kufijtë e objektit, hidhni treguesin në një numër të plotë dhe bëni aritmetikën atje.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // Përsërisni duke përdorur një tregues të papërpunuar në rritje të dy elementeve
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Ky lak shtyp "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SIGURIA: brendësia `arith_offset` nuk ka parakushte për t'u thirrur.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Llogarit distancën midis dy treguesve.Vlera e kthyer është në njësi të T: distanca në bajt ndahet me `mem::size_of::<T>()`.
    ///
    /// Ky funksion është anasjelltas i [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Nëse ndonjë nga kushtet e mëposhtme shkelet, rezultati është Sjellja e Padefinuar:
    ///
    /// * Si treguesi fillestar, ashtu edhe treguesi tjetër duhet të jenë në kufij ose një bajt pas fundit të të njëjtit objekt të caktuar.
    /// Vini re se në Rust, çdo ndryshore (stack-allocated) konsiderohet një objekt i ndarë i ndarë.
    ///
    /// * Të dy treguesit duhet të rrjedhin nga * një tregues në të njëjtin objekt.
    ///   (Shikoni më poshtë për një shembull.)
    ///
    /// * Distanca midis treguesve, në bajte, duhet të jetë një shumëfish i saktë i madhësisë së `T`.
    ///
    /// * Distanca midis treguesve,**në bajte**, nuk mund të tejkalojë një `isize`.
    ///
    /// * Distanca duke qenë në kufij nuk mund të mbështetet në "wrapping around" hapësirën e adresës.
    ///
    /// Llojet e Rust nuk janë kurrë më të mëdha se ndarjet `isize::MAX` dhe Rust nuk mbështillen kurrë në hapësirën e adresës, kështu që dy tregues brenda një vlere të çdo lloji Rust të llojit `T` gjithmonë do të plotësojnë dy kushtet e fundit.
    ///
    /// Biblioteka standarde gjithashtu përgjithësisht siguron që alokimet asnjëherë të mos arrijnë një madhësi kur një kompensim është shqetësues.
    /// Për shembull, `Vec` dhe `Box` sigurojnë që ata kurrë të mos ndajnë më shumë se `isize::MAX` bajte, kështu që `ptr_into_vec.offset_from(vec.as_ptr())` gjithmonë plotëson dy kushtet e fundit.
    ///
    /// Shumica e platformave në thelb as nuk mund të ndërtojnë një alokim kaq të madh.
    /// Për shembull, asnjë platformë e njohur 64-bit nuk mund të shërbejë kurrë një kërkesë për 2 <sup>63</sup> bajte për shkak të kufizimeve të faqes-tryezë ose ndarjes së hapësirës së adresës.
    /// Sidoqoftë, disa platforma 32-bit dhe 16-bit mund të shërbejnë me sukses një kërkesë për më shumë se `isize::MAX` bajte me gjëra të tilla si Zgjerimi i Adresës Fizike.
    /// Si e tillë, kujtesa e marrë direkt nga shpërndarësit ose skedarët e shënuar të kujtesës *mund të jetë* shumë e madhe për t'u trajtuar me këtë funksion.
    /// (Vini re se [`offset`] dhe [`add`] gjithashtu kanë një kufizim të ngjashëm dhe prandaj nuk mund të përdoren as në shpërndarje kaq të mëdha.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ky funksion panics nëse `T` është një tip ("ZST") me madhësi zero.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Përdorimi i pasaktë*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Bëni ptr2_ tjetër një "alias" të ptr2, por që rrjedh nga ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Meqenëse ptr2_other dhe ptr2 rrjedhin nga treguesit në objekte të ndryshme, llogaritja e kompensimit të tyre është sjellje e papërcaktuar, edhe pse tregojnë për të njëjtën adresë!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Sjellja e papërcaktuar
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Kthen nëse dy tregues janë të garantuar të barabartë.
    ///
    /// Në kohën e ekzekutimit ky funksion sillet si `self == other`.
    /// Sidoqoftë, në disa kontekste (p.sh., vlerësimi i kohës së përpilimit), nuk është gjithmonë e mundur të përcaktohet barazia e dy treguesve, kështu që ky funksion mund të kthejë në mënyrë të gabuar `false` për treguesit që më vonë në të vërtetë rezultojnë të barabartë.
    ///
    /// Por kur kthen `true`, treguesit garantohen të jenë të barabartë.
    ///
    /// Ky funksion është pasqyra e [`guaranteed_ne`], por jo e anasjellta e tij.Ekzistojnë krahasime të treguesve për të cilët të dy funksionet kthejnë `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Vlera e kthimit mund të ndryshojë në varësi të versionit të përpiluesit dhe kodi i pasigurt mund të mos mbështetet në rezultatin e këtij funksioni për qëndrueshmërinë.
    /// Sugjerohet që ky funksion të përdoret vetëm për optimizime të performancës kur vlerat false të kthimit `false` nga ky funksion nuk ndikojnë në rezultat, por vetëm në performancë.
    /// Pasojat e përdorimit të kësaj metode për të bërë kohën e duhur dhe kodin e përpilimit të sillen ndryshe nuk janë hulumtuar.
    /// Kjo metodë nuk duhet të përdoret për të futur ndryshime të tilla, dhe gjithashtu nuk duhet të stabilizohet para se të kemi një kuptim më të mirë të kësaj çështje.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Kthen nëse dy tregues janë të garantuar të jenë të pabarabartë.
    ///
    /// Në kohën e ekzekutimit ky funksion sillet si `self != other`.
    /// Sidoqoftë, në disa kontekste (p.sh., vlerësimi i kohës së përpilimit), nuk është gjithmonë e mundur të përcaktohet pabarazia e dy treguesve, kështu që ky funksion mund të kthejë me mashtrim `false` për treguesit që më vonë në të vërtetë rezultojnë të pabarabartë.
    ///
    /// Por kur kthen `true`, treguesit garantohen të jenë të pabarabartë.
    ///
    /// Ky funksion është pasqyra e [`guaranteed_eq`], por jo e anasjellta e tij.Ekzistojnë krahasime të treguesve për të cilët të dy funksionet kthejnë `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Vlera e kthimit mund të ndryshojë në varësi të versionit të përpiluesit dhe kodi i pasigurt mund të mos mbështetet në rezultatin e këtij funksioni për qëndrueshmërinë.
    /// Sugjerohet që ky funksion të përdoret vetëm për optimizime të performancës kur vlerat false të kthimit `false` nga ky funksion nuk ndikojnë në rezultat, por vetëm në performancë.
    /// Pasojat e përdorimit të kësaj metode për të bërë kohën e duhur dhe kodin e përpilimit të sillen ndryshe nuk janë hulumtuar.
    /// Kjo metodë nuk duhet të përdoret për të futur ndryshime të tilla, dhe gjithashtu nuk duhet të stabilizohet para se të kemi një kuptim më të mirë të kësaj çështje.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Llogarit kompensimin nga një tregues (komoditet për `.offset(count as isize)`).
    ///
    /// `count` është në njësi të T;p.sh., një `count` prej 3 përfaqëson një tregues të zhvendosur nga `3 * size_of::<T>()` bajte.
    ///
    /// # Safety
    ///
    /// Nëse ndonjë nga kushtet e mëposhtme shkelet, rezultati është Sjellja e Padefinuar:
    ///
    /// * Si treguesi fillestar, ashtu edhe rezultati, duhet të jenë ose në kufij ose një bajt pas fundit të të njëjtit objekt të caktuar.
    /// Vini re se në Rust, çdo ndryshore (stack-allocated) konsiderohet një objekt i ndarë i ndarë.
    ///
    /// * Kompensimi i llogaritur,**në bajte**, nuk mund të tejkalojë një `isize`.
    ///
    /// * Kompensimi që është në kufij nuk mund të mbështetet në "wrapping around" hapësirën e adresës.Kjo është, shuma me saktësi të pafund duhet të përshtatet në një `usize`.
    ///
    /// Përpiluesi dhe biblioteka standarde në përgjithësi përpiqen të sigurojnë që alokimet kurrë të mos arrijnë një madhësi kur një kompensim është shqetësues.
    /// Për shembull, `Vec` dhe `Box` sigurojnë që ata kurrë nuk ndajnë më shumë se `isize::MAX` bajte, kështu që `vec.as_ptr().add(vec.len())` është gjithmonë i sigurt.
    ///
    /// Shumica e platformave në thelb as nuk mund të ndërtojnë një alokim të tillë.
    /// Për shembull, asnjë platformë e njohur 64-bit nuk mund të shërbejë kurrë një kërkesë për 2 <sup>63</sup> bajte për shkak të kufizimeve të faqes-tryezë ose ndarjes së hapësirës së adresës.
    /// Sidoqoftë, disa platforma 32-bit dhe 16-bit mund të shërbejnë me sukses një kërkesë për më shumë se `isize::MAX` bajte me gjëra të tilla si Zgjerimi i Adresës Fizike.
    ///
    /// Si e tillë, kujtesa e marrë direkt nga shpërndarësit ose skedarët e shënuar të kujtesës *mund të jetë* shumë e madhe për t'u trajtuar me këtë funksion.
    ///
    /// Merrni parasysh përdorimin e [`wrapping_add`] në vend se këto kufizime janë të vështira për t'u kënaqur.
    /// Përparësia e vetme e kësaj metode është se ajo mundëson optimizime më agresive të përpiluesit.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Llogarit kompensimin nga një tregues (komoditet për `. Kompensim ((llogaritni si isize).wrapping_neg())`)).
    ///
    /// `count` është në njësi të T;p.sh., një `count` prej 3 përfaqëson një tregues të zhvendosur nga `3 * size_of::<T>()` bajte.
    ///
    /// # Safety
    ///
    /// Nëse ndonjë nga kushtet e mëposhtme shkelet, rezultati është Sjellja e Padefinuar:
    ///
    /// * Si treguesi fillestar, ashtu edhe rezultati, duhet të jenë ose në kufij ose një bajt pas fundit të të njëjtit objekt të caktuar.
    /// Vini re se në Rust, çdo ndryshore (stack-allocated) konsiderohet një objekt i ndarë i ndarë.
    ///
    /// * Kompensimi i llogaritur nuk mund të tejkalojë `isize::MAX`**bajte**.
    ///
    /// * Kompensimi që është në kufij nuk mund të mbështetet në "wrapping around" hapësirën e adresës.Kjo është, shuma me saktësi të pafund duhet të futet në një përdorim.
    ///
    /// Përpiluesi dhe biblioteka standarde në përgjithësi përpiqen të sigurojnë që alokimet kurrë të mos arrijnë një madhësi kur një kompensim është shqetësues.
    /// Për shembull, `Vec` dhe `Box` sigurojnë që ata kurrë nuk ndajnë më shumë se `isize::MAX` bajte, kështu që `vec.as_ptr().add(vec.len()).sub(vec.len())` është gjithmonë i sigurt.
    ///
    /// Shumica e platformave në thelb as nuk mund të ndërtojnë një alokim të tillë.
    /// Për shembull, asnjë platformë e njohur 64-bit nuk mund të shërbejë kurrë një kërkesë për 2 <sup>63</sup> bajte për shkak të kufizimeve të faqes-tryezë ose ndarjes së hapësirës së adresës.
    /// Sidoqoftë, disa platforma 32-bit dhe 16-bit mund të shërbejnë me sukses një kërkesë për më shumë se `isize::MAX` bajte me gjëra të tilla si Zgjerimi i Adresës Fizike.
    ///
    /// Si e tillë, kujtesa e marrë direkt nga shpërndarësit ose skedarët e shënuar të kujtesës *mund të jetë* shumë e madhe për t'u trajtuar me këtë funksion.
    ///
    /// Merrni parasysh përdorimin e [`wrapping_sub`] në vend se këto kufizime janë të vështira për t'u kënaqur.
    /// Përparësia e vetme e kësaj metode është se ajo mundëson optimizime më agresive të përpiluesit.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Llogarit kompensimin nga një tregues duke përdorur aritmetikën mbështjellëse.
    /// (komoditet për `.wrapping_offset(count as isize)`)
    ///
    /// `count` është në njësi të T;p.sh., një `count` prej 3 përfaqëson një tregues të zhvendosur nga `3 * size_of::<T>()` bajte.
    ///
    /// # Safety
    ///
    /// Ky operacion në vetvete është gjithmonë i sigurt, por përdorimi i treguesit që rezulton nuk është.
    ///
    /// Treguesi që rezulton mbetet i bashkangjitur në të njëjtin objekt të caktuar për të cilin tregon `self`.
    /// Mund të *mos* përdoret për të hyrë në një objekt tjetër të caktuar.Vini re se në Rust, çdo ndryshore (stack-allocated) konsiderohet një objekt i ndarë i ndarë.
    ///
    /// Me fjalë të tjera, `let z = x.wrapping_add((y as usize) - (x as usize))`*nuk* e bën `z` njësoj si `y` edhe nëse supozojmë se `T` ka madhësi `1` dhe nuk ka tejkalim: `z` është akoma e bashkangjitur në objektin që i është bashkangjitur `x` dhe referimi i tij është Sjellje e Padefinuar përveç nëse `x` dhe `y` drejtohet në të njëjtin objekt të caktuar.
    ///
    /// Krahasuar me [`add`], kjo metodë në thelb vonon kërkesën për të qëndruar brenda të njëjtit objekt të caktuar: [`add`] është sjellje e menjëhershme e papërcaktuar kur kalon kufijtë e objektit;`wrapping_add` prodhon një tregues por prapë çon në Sjellje të Padefinuar nëse një pointer është referuar kur nuk është në kufijtë e objektit në të cilin është bashkangjitur.
    /// [`add`] mund të optimizohet më mirë dhe kështu preferohet në kodin e ndjeshëm ndaj performancës.
    ///
    /// Kontrolli i vonuar konsideron vetëm vlerën e treguesit që është referuar, jo vlerat e ndërmjetme të përdorura gjatë llogaritjes së rezultatit përfundimtar.
    /// Për shembull, `x.wrapping_add(o).wrapping_sub(o)` është gjithmonë e njëjtë me `x`.Me fjalë të tjera, lejohet lënia e objektit të caktuar dhe pastaj hyrja e tij më vonë.
    ///
    /// Nëse keni nevojë të kaloni kufijtë e objektit, hidhni treguesin në një numër të plotë dhe bëni aritmetikën atje.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // Përsërisni duke përdorur një tregues të papërpunuar në rritje të dy elementeve
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ky lak shtyp "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Llogarit kompensimin nga një tregues duke përdorur aritmetikën mbështjellëse.
    /// (komoditet për `. mbështjelljen_ofset ((llogaritni si isize).wrapping_neg())`)
    ///
    /// `count` është në njësi të T;p.sh., një `count` prej 3 përfaqëson një tregues të zhvendosur nga `3 * size_of::<T>()` bajte.
    ///
    /// # Safety
    ///
    /// Ky operacion në vetvete është gjithmonë i sigurt, por përdorimi i treguesit që rezulton nuk është.
    ///
    /// Treguesi që rezulton mbetet i bashkangjitur në të njëjtin objekt të caktuar për të cilin tregon `self`.
    /// Mund të *mos* përdoret për të hyrë në një objekt tjetër të caktuar.Vini re se në Rust, çdo ndryshore (stack-allocated) konsiderohet një objekt i ndarë i ndarë.
    ///
    /// Me fjalë të tjera, `let z = x.wrapping_sub((x as usize) - (y as usize))`*nuk* e bën `z` njësoj si `y` edhe nëse supozojmë se `T` ka madhësi `1` dhe nuk ka tejmbushje: `z` është akoma e bashkangjitur në objektin që i është bashkangjitur `x` dhe referimi i tij është Sjellje e Padefinuar përveç nëse `x` dhe `y` drejtohet në të njëjtin objekt të caktuar.
    ///
    /// Krahasuar me [`sub`], kjo metodë në thelb vonon kërkesën për të qëndruar brenda të njëjtit objekt të caktuar: [`sub`] është sjellje e menjëhershme e papërcaktuar kur kalon kufijtë e objektit;`wrapping_sub` prodhon një tregues por prapë çon në Sjellje të Padefinuar nëse një pointer është referuar kur nuk është në kufijtë e objektit në të cilin është bashkangjitur.
    /// [`sub`] mund të optimizohet më mirë dhe kështu preferohet në kodin e ndjeshëm ndaj performancës.
    ///
    /// Kontrolli i vonuar konsideron vetëm vlerën e treguesit që është referuar, jo vlerat e ndërmjetme të përdorura gjatë llogaritjes së rezultatit përfundimtar.
    /// Për shembull, `x.wrapping_add(o).wrapping_sub(o)` është gjithmonë e njëjtë me `x`.Me fjalë të tjera, lejohet lënia e objektit të caktuar dhe pastaj hyrja e tij më vonë.
    ///
    /// Nëse keni nevojë të kaloni kufijtë e objektit, hidhni treguesin në një numër të plotë dhe bëni aritmetikën atje.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // Përsërisni duke përdorur një tregues të papërpunuar në rritje të dy elementeve (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ky lak shtyp "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Vendos vlerën e treguesit në `ptr`.
    ///
    /// Në rast se `self` është një tregues (fat) për një lloj të pa madhësisë, ky operacion do të ndikojë vetëm në pjesën e treguesit, ndërsa për treguesit (thin) për llojet me madhësi, ky ka të njëjtin efekt si një detyrë e thjeshtë.
    ///
    /// Treguesi që rezulton do të ketë prejardhje prej `val`, dmth., Për një tregues të yndyrës, ky operacion është semantikisht i njëjtë me krijimin e një treguesi të ri dhjami me vlerën e treguesit të të dhënave `val` por të meta të dhënave të `self`.
    ///
    ///
    /// # Examples
    ///
    /// Ky funksion është kryesisht i dobishëm për lejimin e aritmetikës së treguesit bajt në treguesit potencialisht të yndyrës:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // do të shtypë "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SIGURIA: Në rast të një treguesi të hollë, këto operacione janë identike
        // në një detyrë të thjeshtë.
        // Në rast të një treguesi dhjami, me zbatimin aktual të paraqitjes së treguesit të yndyrës, fusha e parë e një treguesi të tillë është gjithmonë treguesi i të dhënave, i cili është caktuar gjithashtu.
        //
        unsafe { *thin = val };
        self
    }

    /// Lexon vlerën nga `self` pa e lëvizur.
    /// Kjo e lë memorjen në `self` të pandryshuar.
    ///
    /// Shihni [`ptr::read`] për shqetësime dhe shembuj të sigurisë.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `read`.
        unsafe { read(self) }
    }

    /// Kryen një lexim të paqëndrueshëm të vlerës nga `self` pa e lëvizur atë.Kjo e lë memorjen në `self` të pandryshuar.
    ///
    /// Operacionet e paqëndrueshme kanë për qëllim të veprojnë në kujtesën I/O dhe janë të garantuara që të mos eleminohen ose renditen nga përpiluesi nëpër operacionet e tjera të paqëndrueshme.
    ///
    ///
    /// Shihni [`ptr::read_volatile`] për shqetësime dhe shembuj të sigurisë.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Lexon vlerën nga `self` pa e lëvizur.
    /// Kjo e lë memorjen në `self` të pandryshuar.
    ///
    /// Ndryshe nga `read`, treguesi mund të jetë i pavendosur.
    ///
    /// Shihni [`ptr::read_unaligned`] për shqetësime dhe shembuj të sigurisë.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopjon bajthat `count * size_of<T>` nga `self` në `dest`.
    /// Burimi dhe destinacioni mund të mbivendosen.
    ///
    /// NOTE: kjo ka rendin *e njëjtë* të argumentit si [`ptr::copy`].
    ///
    /// Shihni [`ptr::copy`] për shqetësime dhe shembuj të sigurisë.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopjon bajthat `count * size_of<T>` nga `self` në `dest`.
    /// Burimi dhe destinacioni mund të *mos* përputhen.
    ///
    /// NOTE: kjo ka rendin *e njëjtë* të argumentit si [`ptr::copy_nonoverlapping`].
    ///
    /// Shihni [`ptr::copy_nonoverlapping`] për shqetësime dhe shembuj të sigurisë.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Llogarit kompensimin që duhet të zbatohet në tregues në mënyrë që ta vendosë atë në linjë me `align`.
    ///
    /// Nëse nuk është e mundur të rreshtoni treguesin, implementimi kthen `usize::MAX`.
    /// Pershtë e lejueshme që zbatimi *gjithmonë* të kthejë `usize::MAX`.
    /// Vetëm performanca e algoritmit tuaj mund të varet nga marrja e një kompensimi të përdorshëm këtu, dhe jo nga korrektësia e tij.
    ///
    /// Kompensimi shprehet në numër të elementeve `T`, dhe jo bajtësh.Vlera e kthyer mund të përdoret me metodën `wrapping_add`.
    ///
    /// Nuk ka asnjë garanci se kompensimi i treguesit nuk do të tejkalojë ose do të shkojë përtej alokimit në të cilin tregon treguesi.
    ///
    /// Varet nga thirrësi që të sigurojë që kompensimi i kthyer është i saktë në të gjitha termat përveç rreshtimit.
    ///
    /// # Panics
    ///
    /// Funksioni panics nëse `align` nuk është fuqi-e-dy.
    ///
    /// # Examples
    ///
    /// Hyrja në `u8` ngjitur si `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // ndërsa treguesi mund të rreshtohet përmes `offset`, ai do të tregonte jashtë alokimit
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SIGURIA: `align` është kontrolluar të jetë një fuqi prej 2 më lart
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Kthen gjatësinë e një fete të papërpunuar.
    ///
    /// Vlera e kthyer është numri i **elementeve**, jo numri i bajteve.
    ///
    /// Ky funksion është i sigurt, edhe kur feta e papërpunuar nuk mund të hidhet në një referencë të fetë sepse treguesi është nul ose i pa rreshtuar.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SIGURIA: kjo është e sigurt sepse `*const [T]` dhe `FatPtr<T>` kanë të njëjtën paraqitje.
            // Vetëm `std` mund ta bëjë këtë garanci.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Kthen një tregues të papërpunuar në buffer-in e fetë-s.
    ///
    /// Kjo është ekuivalente me hedhjen `self` në `*const T`, por më e sigurt për llojin.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Kthen një tregues të papërpunuar në një element ose nënfushë, pa bërë kontrollin e kufijve.
    ///
    /// Thirrja e kësaj metode me një indeks jashtë kufijve ose kur `self` nuk është i paqëndrueshëm është *[sjellje e papërcaktuar]* edhe nëse treguesi që rezulton nuk përdoret.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SIGURIA: thirrësi siguron që `self` të jetë i referueshëm dhe `index` në kufij.
        unsafe { index.get_unchecked(self) }
    }

    /// Kthen `None` nëse treguesi është null, ose përndryshe kthen një fetë të ndarë në vlerën e mbështjellë me `Some`.
    /// Në kontrast me [`as_ref`], kjo nuk kërkon që vlera të iniciohet.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Kur telefononi këtë metodë, duhet të siguroheni që *ose* treguesi është NULL *ose* të gjitha sa më poshtë janë të vërteta:
    ///
    /// * Treguesi duhet të jetë [valid] për lexime për `ptr.len() * mem::size_of::<T>()` shumë bajte, dhe duhet të jetë i rreshtuar siç duhet.Kjo do të thotë në veçanti:
    ///
    ///     * E gjithë diapazoni i kujtesës së kësaj flete duhet të përmbahet në një objekt të vetëm të alokuar!
    ///       Fetë nuk mund të shtrihen kurrë nëpër objekte të shumta të alokuara.
    ///
    ///     * Treguesi duhet të rreshtohet edhe për feta me gjatësi zero.
    ///     Një arsye për këtë është që optimizimet e paraqitjes së enumit mund të mbështeten në referencat (përfshirë feta të çdo gjatësi) që janë në një linjë dhe jo null për t'i dalluar ato nga të dhënat e tjera.
    ///
    ///     Ju mund të merrni një tregues që është i përdorshëm si `data` për feta me gjatësi zero duke përdorur [`NonNull::dangling()`].
    ///
    /// * Madhësia totale `ptr.len() * mem::size_of::<T>()` e fetë nuk duhet të jetë më e madhe se `isize::MAX`.
    ///   Shihni dokumentacionin e sigurisë së [`pointer::offset`].
    ///
    /// * Ju duhet të zbatoni rregullat aliasing të Rust, pasi jeta e kthyer `'a` zgjidhet në mënyrë arbitrare dhe nuk pasqyron domosdoshmërisht jetën e vërtetë të të dhënave.
    ///   Veçanërisht, gjatë kohëzgjatjes së kësaj jete, kujtesa në të cilën treguesi tregon nuk duhet të ndryshohet (përveç brenda `UnsafeCell`).
    ///
    /// Kjo vlen edhe nëse rezultati i kësaj metode është i papërdorur!
    ///
    /// Shihni gjithashtu [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Barazia për treguesit
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Krahasimi për pointerët
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}