use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Një mbështjellës rreth një `*mut T` të papërpunuar jo-null që tregon se poseduesi i kësaj mbështjellësi zotëron referencën.
/// E dobishme për ndërtimin e abstraksioneve si `Box<T>`, `Vec<T>`, `String` dhe `HashMap<K, V>`.
///
/// Ndryshe nga `*mut T`, `Unique<T>` sillet "as if" ishte një shembull i `T`.
/// Zbaton `Send`/`Sync` nëse `T` është `Send`/`Sync`.
/// Kjo gjithashtu nënkupton llojin e garancive të forta aliasing që një shembull i `T` mund të presë:
/// referenca e pointerit nuk duhet të modifikohet pa një rrugë unike për të poseduarin e tij Unik.
///
/// Nëse nuk jeni të sigurt nëse është e saktë të përdorni `Unique` për qëllimet tuaja, merrni parasysh përdorimin e `NonNull`, i cili ka semantikë më të dobët.
///
///
/// Ndryshe nga `*mut T`, treguesi duhet të jetë gjithnjë jo nul, edhe nëse treguesi nuk referohet kurrë.
/// Kjo është në mënyrë që enumet të përdorin këtë vlerë të ndaluar si një diskriminues-`Option<Unique<T>>` ka të njëjtën madhësi si `Unique<T>`.
/// Sidoqoftë, treguesi mund të tund ende nëse nuk referohet.
///
/// Ndryshe nga `*mut T`, `Unique<T>` është kovariant mbi `T`.
/// Kjo duhet të jetë gjithmonë e saktë për çdo lloj që mbështet kërkesat aliasing të Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ky shënues nuk ka pasoja për ndryshimin, por është i domosdoshëm
    // që dropck të kuptojë se ne logjikisht kemi një `T`.
    //
    // Për detaje, shih:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` treguesit janë `Send` nëse `T` është `Send` sepse të dhënat që ata referojnë janë të paanshme.
/// Vini re se kjo pa ndryshim aliasing është e pazbatuar nga sistemi i tipit;abstraksioni duke përdorur `Unique` duhet ta zbatojë atë.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` treguesit janë `Sync` nëse `T` është `Sync` sepse të dhënat që ata referojnë janë të paanshme.
/// Vini re se kjo pa ndryshim aliasing është e pazbatuar nga sistemi i tipit;abstraksioni duke përdorur `Unique` duhet ta zbatojë atë.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Krijon një `Unique` të ri që është i varur, por i rreshtuar mirë.
    ///
    /// Kjo është e dobishme për inicializimin e llojeve që alokojnë me përtesë, siç bën `Vec::new`.
    ///
    /// Vini re se vlera e treguesit mund të përfaqësojë potencialisht një tregues të vlefshëm për një `T`, që do të thotë se kjo nuk duhet të përdoret si një vlerë roje "not yet initialized".
    /// Llojet që caktojnë me përtesë duhet të ndjekin inicializimin me disa mjete të tjera.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SIGURIA: mem::align_of() kthen një tregues të vlefshëm, jo nul.
        // kushtet për të thirrur new_unchecked() respektohen kështu.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Krijon një `Unique` të ri.
    ///
    /// # Safety
    ///
    /// `ptr` duhet të jetë jo nul.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SIGURIA: thirrësi duhet të garantojë që `ptr` nuk është i pavlefshëm.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Krijon një `Unique` të ri nëse `ptr` nuk është nul.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SIGURIA: Treguesi tashmë është kontrolluar dhe nuk është nul.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Blen treguesin themelor `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Dereferencon përmbajtjen.
    ///
    /// Jetëgjatësia që rezulton është e detyruar të vetvetes, kështu që kjo sillet "as if" në të vërtetë ka qenë një shembull i T që po huazohet.
    /// Nëse nevojitet një jetë më e gjatë (unbound), përdorni `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SIGURIA: thirrësi duhet të garantojë që `self` plotëson të gjitha pajisjet
        // kërkesat për një referencë.
        unsafe { &*self.as_ptr() }
    }

    /// Në mënyrë të pandryshueshme deferencon përmbajtjen.
    ///
    /// Jetëgjatësia që rezulton është e detyruar të vetvetes, kështu që kjo sillet "as if" në të vërtetë ka qenë një shembull i T që po huazohet.
    /// Nëse nevojitet një jetë më e gjatë (unbound), përdorni `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SIGURIA: thirrësi duhet të garantojë që `self` plotëson të gjitha pajisjet
        // kërkesat për një referencë të ndryshueshme.
        unsafe { &mut *self.as_ptr() }
    }

    /// Hedh në një tregues të një lloji tjetër.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SIGURIA: Unique::new_unchecked() krijon një unike dhe nevoja të reja
        // treguesi i dhënë të mos jetë nul.
        // Meqenëse po e kalojmë veten si një tregues, ai nuk mund të jetë nul.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SIGURIA: Një referencë e ndryshueshme nuk mund të jetë e pavlefshme
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}