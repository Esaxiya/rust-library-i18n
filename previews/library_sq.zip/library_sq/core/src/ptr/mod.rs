//! Menaxhoni manualisht kujtesën përmes treguesve të papërpunuar.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Shumë funksione në këtë modul marrin treguesit e papërpunuar si argumente dhe u lexojnë ose shkruajnë atyre.Që kjo të jetë e sigurt, këta tregues duhet të jenë *të vlefshëm*.
//! Nëse një tregues është i vlefshëm varet nga operacioni për të cilin është përdorur (lexo ose shkruaj) dhe sasia e kujtesës në të cilën arrihet (dmth., Sa bajt janë read/written).
//! Shumica e funksioneve përdorin `*mut T` dhe `* const T` për të hyrë vetëm në një vlerë të vetme, në këtë rast dokumentacioni heq madhësinë dhe në mënyrë implicite supozon të jetë X02 bajte.
//!
//! Rregullat e sakta për vlefshmërinë nuk janë përcaktuar ende.Garancitë që ofrohen në këtë pikë janë shumë minimale:
//!
//! * Një tregues [null] nuk është * asnjëherë i vlefshëm, madje as për akseset e [size zero][zst].
//! * Që një tregues të jetë i vlefshëm, është e nevojshme, por jo gjithmonë e mjaftueshme, që treguesi të jetë *i referueshëm*: diapazoni i kujtesës i madhësisë së dhënë që fillon nga treguesi, të gjithë duhet të jenë brenda kufijve të një objekti të vetëm të alokuar.
//!
//! Vini re se në Rust, çdo ndryshore (stack-allocated) konsiderohet një objekt i ndarë i ndarë.
//! * Edhe për operacionet e [size zero][zst], treguesi nuk duhet të tregojë kujtesën e shpërndarë, dmth. Shpërndarja i bën treguesit të pavlefshëm edhe për operacione me madhësi zero.
//! Sidoqoftë, hedhja e një integer *zero* drejtpërdrejtë në një tregues është e vlefshme për hyrjet me madhësi zero, edhe nëse ndonjë memorie ndodh që të ekzistojë në atë adresë dhe të shpërndahet.
//! Kjo korrespondon me shkrimin e alokuesit tuaj: alokimi i objekteve me madhësi zero nuk është shumë i vështirë.
//! Mënyra kanonike për të marrë një tregues që është i vlefshëm për hyrjet me madhësi zero është [`NonNull::dangling`].
//! * Të gjitha hyrjet e kryera nga funksionet në këtë modul janë *jo-atomike* në kuptimin e [atomic operations] të përdorura për të sinkronizuar midis fijeve.
//! Kjo do të thotë se është një sjellje e papërcaktuar për të kryer dy qasje të njëkohshme në të njëjtin vend nga fije të ndryshme përveç nëse të dy akseset lexohen vetëm nga memoria.
//! Vini re se kjo në mënyrë eksplicite përfshin [`read_volatile`] dhe [`write_volatile`]: Hyrjet e paqëndrueshme nuk mund të përdoren për sinkronizimin ndër-fije.
//! * Rezultati i hedhjes së një referimi në një tregues është i vlefshëm për sa kohë që objekti themelor është i drejtpërdrejtë dhe nuk përdoret asnjë referencë (vetëm tregues të papërpunuar) për të hyrë në të njëjtën memorie.
//!
//! Këto aksioma, së bashku me përdorimin e kujdesshëm të [`offset`] për aritmetikën e treguesit, janë të mjaftueshme për të zbatuar në mënyrë korrekte shumë gjëra të dobishme në kodin e pasigurt.
//! Garanci më të forta do të sigurohen përfundimisht, pasi rregullat [aliasing] janë duke u përcaktuar.
//! Për më shumë informacion, shihni [book] si dhe seksionin në referencën kushtuar [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Treguesit e vlefshëm të papërpunuar siç përcaktohet më sipër nuk janë të rreshtuar domosdoshmërisht siç duhet (ku rreshtimi "proper" përcaktohet nga lloji i bashkuar, dmth. `*const T` duhet të rreshtohet me `mem::align_of::<T>()`).
//! Sidoqoftë, shumica e funksioneve kërkojnë që argumentet e tyre të rreshtohen siç duhet, dhe do të shprehin qartë këtë kërkesë në dokumentacionin e tyre.
//! Përjashtime të dukshme për këtë janë [`read_unaligned`] dhe [`write_unaligned`].
//!
//! Kur një funksion kërkon shtrirjen e duhur, kjo e bën edhe nëse hyrja ka madhësinë 0, dmth., Edhe nëse memoria nuk është prekur në të vërtetë.Merrni parasysh përdorimin e [`NonNull::dangling`] në raste të tilla.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Ekzekuton shkatërruesin (nëse ka) të vlerës së theksuar.
///
/// Kjo është semantikisht e barabartë me thirrjen [`ptr::read`] dhe hedhjen poshtë të rezultatit, por ka përparësitë e mëposhtme:
///
/// * *Kërkohet* që të përdoret `drop_in_place` për të lëshuar lloje të papërmasa si objektet trait, sepse ato nuk mund të lexohen në pirg dhe bien normalisht.
///
/// * Friendshtë më miqësore me optimizuesin që ta bëjë këtë mbi [`ptr::read`] kur lëshon memorjen e alokuar manualisht (p.sh., në implementimet e `Box`/`Rc`/`Vec`), pasi përpiluesi nuk ka nevojë të provojë se është i shëndoshë për të hequr kopjen.
///
///
/// * Mund të përdoret për të hedhur të dhëna [pinned] kur `T` nuk është `repr(packed)` (të dhënat e fiksuara nuk duhet të zhvendosen para se të hidhen).
///
/// Vlerat e palidhura nuk mund të lëshohen në vend, ato duhet të kopjohen së pari në një vend të rreshtuar duke përdorur [`ptr::read_unaligned`].Për strukturat e mbushura, kjo lëvizje bëhet automatikisht nga përpiluesi.
/// Kjo do të thotë që fushat e strukturave të paketuara nuk bien në vend.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `to_drop` duhet të jetë [valid] si për leximin ashtu edhe për shkrimin.
///
/// * `to_drop` duhet të rreshtohet siç duhet.
///
/// * Vlera `to_drop` pikë për të duhet të jetë e vlefshme për rënie, që mund të thotë se duhet të mbajë invariante shtesë, kjo është e varur nga lloji.
///
/// Për më tepër, nëse `T` nuk është [`Copy`], përdorimi i vlerës së theksuar pas thirrjes `drop_in_place` mund të shkaktojë sjellje të papërcaktuar.Vini re se `*to_drop = foo` llogaritet si përdorim sepse do të bëjë që vlera të bjerë përsëri.
/// [`write()`] mund të përdoret për të mbishkruar të dhëna pa shkaktuar që ato të bien.
///
/// Vini re se edhe nëse `T` ka madhësinë `0`, treguesi duhet të mos jetë NULL dhe i rreshtuar siç duhet.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Hiqni manualisht artikullin e fundit nga një vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Merrni një tregues të papërpunuar tek elementi i fundit në `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Shkurtoni `v` për të parandaluar hedhjen e artikullit të fundit.
///     // Ne e bëjmë atë së pari, për të parandaluar çështjet nëse `drop_in_place` poshtë panics.
///     v.set_len(1);
///     // Pa një telefonatë `drop_in_place`, artikulli i fundit nuk do të bjerë kurrë, dhe kujtesa që ajo administron do të rrjedhë.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Sigurohuni që artikulli i fundit të jetë hedhur.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Vini re që përpiluesi e kryen këtë kopje automatikisht kur i bie stektet e paketuara, dmth., Zakonisht nuk duhet të shqetësoheni për çështje të tilla nëse nuk telefononi manualisht `drop_in_place`.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kodi këtu nuk ka rëndësi, kjo zëvendësohet nga ngjitësi real i rënies nga përpiluesi.
    //

    // SIGURIA: shikoni komentin më lart
    unsafe { drop_in_place(to_drop) }
}

/// Krijon një tregues të papërpunuar zero.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Krijon një tregues të papërpunueshëm të pa ndryshueshëm.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Kërkohet manual manual për të shmangur lidhjen `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Kërkohet manual manual për të shmangur lidhjen `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Formon një fetë të papërpunuar nga një tregues dhe një gjatësi.
///
/// Argumenti `len` është numri i **elementeve**, jo numri i bajteve.
///
/// Ky funksion është i sigurt, por në të vërtetë përdorimi i vlerës kthyese është i pasigurt.
/// Shihni dokumentacionin e [`slice::from_raw_parts`] për kërkesat e sigurisë në feta.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // krijoni një tregues me feta kur filloni me një tregues te elementi i parë
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SIGURIA: Hyrja në vlerën nga bashkimi `Repr` është e sigurt që nga * const [T]
        //
        // dhe FatPtr kanë të njëjtat paraqitje të kujtesës.Vetëm std mund ta bëjë këtë garanci.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Kryen të njëjtën funksionalitet si [`slice_from_raw_parts`], përveç që një fetë e papërpunueshme e pandryshueshme kthehet, në krahasim me një fetë të pandryshueshme të papërpunuar.
///
///
/// Shihni dokumentacionin e [`slice_from_raw_parts`] për më shumë detaje.
///
/// Ky funksion është i sigurt, por në të vërtetë përdorimi i vlerës kthyese është i pasigurt.
/// Shihni dokumentacionin e [`slice::from_raw_parts_mut`] për kërkesat e sigurisë në feta.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // caktojë një vlerë në një indeks në fetë
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SIGURIA: Hyrja në vlerën nga bashkimi `Repr` është e sigurt që nga * mut [T]
        // dhe FatPtr kanë të njëjtat paraqitje të kujtesës
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Ndërron vlerat në dy vendndodhje të ndryshueshme të të njëjtit lloj, pa deinitializuar as njërën, as tjetrën.
///
/// Por për dy përjashtimet e mëposhtme, ky funksion është semantikisht i barabartë me [`mem::swap`]:
///
///
/// * Ajo operon në tregues të papërpunuar në vend të referencave.
/// Kur referencat janë të disponueshme, [`mem::swap`] duhet të preferohet.
///
/// * Dy vlerat e theksuara mund të mbivendosen.
/// Nëse vlerat mbivendosen, atëherë do të përdoret rajoni i mbivendosur i kujtesës nga `x`.
/// Kjo demonstrohet në shembullin e dytë më poshtë.
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * Si `x` ashtu edhe `y` duhet të jenë [valid] për leximin dhe shkrimin.
///
/// * Si `x` ashtu edhe `y` duhet të rreshtohen siç duhet.
///
/// Vini re se edhe nëse `T` ka madhësinë `0`, treguesit duhet të jenë jo NULL dhe të rreshtuar siç duhet.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Shkëmbimi i dy rajoneve që nuk mbivendosen:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // kjo është `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // kjo është `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Shkëmbimi i dy rajoneve të mbivendosura:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // kjo është `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // kjo është `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indekset `1..3` të pjesës mbivendosen midis `x` dhe `y`.
///     // Rezultatet e arsyeshme do të ishin që ata të ishin `[2, 3]`, në mënyrë që indekset `0..3` të jenë `[1, 2, 3]` (përputhen `y` para `swap`);ose që ato të jenë `[0, 1]` në mënyrë që indekset `1..4` të jenë `[0, 1, 2]` (që përputhen me `x` para `swap`).
/////
///     // Ky zbatim është përcaktuar për të bërë zgjedhjen e fundit.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Jepini vetes pak hapësirë gërvishtëse për të punuar.
    // Ne nuk duhet të shqetësohemi për pikat: `MaybeUninit` nuk bën asgjë kur bie.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Kryeni SIGURIN e ndërrimit: thirrësi duhet të garantojë që `x` dhe `y` janë të vlefshme për shkrime dhe të rreshtuar siç duhet.
    // `tmp` nuk mund të mbivendoset as `x` dhe `y` sepse `tmp` u caktua vetëm në pirg si një objekt i ndarë i ndarë.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` dhe `y` mund të mbivendosen
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Ndërron bajthat `count * size_of::<T>()` midis dy rajoneve të kujtesës duke filluar nga `x` dhe `y`.
/// Të dy rajonet nuk duhet * të mbivendosen.
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * Të dy `x` dhe `y` duhet të jenë [valid] për të dy leximet dhe shkrimet e `count *
///   madhësia_e: :<T>() `bajte.
///
/// * Si `x` ashtu edhe `y` duhet të rreshtohen siç duhet.
///
/// * Rajoni i kujtesës që fillon në `x` me një madhësi të `numërimit *
///   madhësia_e: :<T>() `bajtët *nuk duhet* të mbivendosen me rajonin e kujtesës që fillon nga `y` me të njëjtën madhësi.
///
/// Vini re se edhe nëse madhësia e kopjuar në mënyrë efektive (`numëroni * madhësinë e:::<T>()") është `0`, treguesit duhet të jenë jo-NULL dhe të rreshtuar siç duhet.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SIGURIA: thirrësi duhet të garantojë që `x` dhe `y` janë
    // e vlefshme për shkrime dhe e rreshtuar si duhet.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Për llojet më të vogla se optimizimi i bllokut më poshtë, thjesht ndërroni drejtpërdrejt për të shmangur pesimizimin e kodgjenit.
    //
    if mem::size_of::<T>() < 32 {
        // SIGURIA: thirrësi duhet të garantojë që `x` dhe `y` janë të vlefshme
        // për shkrime, të rreshtuara si duhet dhe jo të mbivendosura.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Qasja këtu është përdorimi i SIMD për të ndërruar x&y në mënyrë efikase.
    // Testimi zbulon se shkëmbimi ose 32 bajt ose 64 bajt në të njëjtën kohë është më efikasi për procesorët Intel Haswell E.
    // LLVM është më e aftë të optimizojë nëse i japim një strukturë #[repr(simd)], edhe nëse nuk e përdorim drejtpërdrejt këtë strukturë.
    //
    //
    // FIXME repr(simd) e prishur në emscript dhe redoks
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Kaloni nëpër x&y, duke kopjuar ato `Block` në të njëjtën kohë Optimizuesi duhet të heq unazën plotësisht për shumicën e llojeve NB
    // Ne nuk mund të përdorim një lak for për siç e bën thirrja `range` `mem::swap` në mënyrë rekursive
    //
    let mut i = 0;
    while i + block_size <= len {
        // Krijoni pak memorje të pa iniciale si hapësirë për zeroja Deklarimi `t` këtu shmang përafrimin e pirgut kur ky lak është i papërdorur
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SIGURIA: Si `i < len`, dhe pasi thirrësi duhet të garantojë që `x` dhe `y` janë të vlefshme
        // për bajthet `len`, `x + i` dhe `y + i` duhet të jenë adresa të vlefshme, që përmbush kontratën e sigurisë për `add`.
        //
        // Gjithashtu, thirrësi duhet të garantojë që `x` dhe `y` janë të vlefshme për shkrime, të rreshtuara si duhet dhe jo të mbivendosura, gjë që përmbush kontratën e sigurisë për `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Ndërroni një bllok bajtesh nga x&y, duke përdorur t si një buffer të përkohshëm Kjo duhet të optimizohet në operacione efikase SIMD aty ku është e disponueshme
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Ndërroni çdo bajt të mbetur
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SIGURIA: shihni komentin e mëparshëm të sigurisë.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Lëviz `src` në `dst` me majë, duke kthyer vlerën e mëparshme `dst`.
///
/// Asnjëra vlerë nuk është rënë.
///
/// Ky funksion është semantikisht i barazvlefshëm me [`mem::replace`] përveç se ai operon në tregues të papërpunuar në vend të referencave.
/// Kur referencat janë të disponueshme, [`mem::replace`] duhet të preferohet.
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `dst` duhet të jetë [valid] si për leximin ashtu edhe për shkrimin.
///
/// * `dst` duhet të rreshtohet siç duhet.
///
/// * `dst` duhet të tregojë në një vlerë të iniciuar siç duhet të tipit `T`.
///
/// Vini re se edhe nëse `T` ka madhësinë `0`, treguesi duhet të mos jetë NULL dhe i rreshtuar siç duhet.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` do të kishte të njëjtin efekt pa kërkuar bllokun e pasigurt.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SIGURIA: thirrësi duhet të garantojë që `dst` të jetë e vlefshme
    // hedhur në një referencë të ndryshueshme (e vlefshme për shkrime, rreshtuar, iniciuar), dhe nuk mund të mbivendoset `src` pasi `dst` duhet të tregojë në një objekt të veçantë të alokuar.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // nuk mund të mbivendoset
    }
    src
}

/// Lexon vlerën nga `src` pa e lëvizur.Kjo e lë memorjen në `src` të pandryshuar.
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `src` duhet të jetë [valid] për lexime.
///
/// * `src` duhet të rreshtohet siç duhet.Përdorni [`read_unaligned`] nëse nuk është kështu.
///
/// * `src` duhet të tregojë në një vlerë të iniciuar siç duhet të tipit `T`.
///
/// Vini re se edhe nëse `T` ka madhësinë `0`, treguesi duhet të mos jetë NULL dhe i rreshtuar siç duhet.
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Zbatoni manualisht [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Krijoni një kopje bit bit të vlerës në `a` në `tmp`.
///         let tmp = ptr::read(a);
///
///         // Dalja në këtë pikë (ose duke u kthyer në mënyrë të qartë ose duke thirrur një funksion të cilin panics) do të bënte që vlera në `tmp` të bjerë ndërsa e njëjta vlerë referohet ende nga `a`.
///         // Kjo mund të shkaktojë sjellje të padefinuar nëse `T` nuk është `Copy`.
/////
/////
///
///         // Krijoni një kopje bit bit të vlerës në `b` në `a`.
///         // Kjo është e sigurt sepse referencat e ndryshueshme nuk mund të jenë alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Si më sipër, dalja këtu mund të shkaktojë sjellje të padefinuar, sepse e njëjta vlerë referohet nga `a` dhe `b`.
/////
///
///         // Zhvendosni `tmp` në `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` është zhvendosur (`write` merr në pronësi argumentin e tij të dytë), kështu që asgjë nuk bie nënkuptuar këtu.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Pronësia e vlerës së kthyer
///
/// `read` krijon një kopje bitwise të `T`, pavarësisht nëse `T` është [`Copy`].
/// Nëse `T` nuk është [`Copy`], përdorimi i vlerës së kthyer dhe vlerës në `*src` mund të shkelë sigurinë e kujtesës.
/// Vini re se caktimi i `*src` llogaritet si përdorim sepse do të përpiqet të heqë vlerën në `* src`.
///
/// [`write()`] mund të përdoret për të mbishkruar të dhëna pa shkaktuar që ato të bien.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` tani tregon për të njëjtën memorie themelore si `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Caktimi në `s2` bën që vlera e tij origjinale të bjerë.
///     // Përtej kësaj pike, `s` nuk duhet të përdoret më, pasi kujtesa themelore është çliruar.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Caktimi në `s` do të bënte që vlera e vjetër të binte përsëri, duke rezultuar në një sjellje të papërcaktuar.
/////
///     // s= String::from("bar");//GABIMI
///
///     // `ptr::write` mund të përdoret për të mbishkruar një vlerë pa e rënë.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SIGURIA: thirrësi duhet të garantojë që `src` është i vlefshëm për leximet.
    // `src` nuk mund të mbivendoset `tmp` sepse `tmp` u caktua vetëm në pirg si një objekt i ndarë i ndarë.
    //
    //
    // Gjithashtu, meqenëse sapo kemi shkruar një vlerë të vlefshme në `tmp`, është e garantuar që të iniciohet siç duhet.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Lexon vlerën nga `src` pa e lëvizur.Kjo e lë memorjen në `src` të pandryshuar.
///
/// Ndryshe nga [`read`], `read_unaligned` punon me tregues të pa rreshtuar.
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `src` duhet të jetë [valid] për lexime.
///
/// * `src` duhet të tregojë në një vlerë të iniciuar siç duhet të tipit `T`.
///
/// Ashtu si [`read`], `read_unaligned` krijon një kopje bitwise të `T`, pavarësisht nëse `T` është [`Copy`].
/// Nëse `T` nuk është [`Copy`], duke përdorur si vlerën e kthyer ashtu edhe vlerën në `*src` mund [violate memory safety][read-ownership].
///
/// Vini re se edhe nëse `T` ka madhësinë `0`, treguesi duhet të mos jetë NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Në goditjet `packed`
///
/// Aktualisht është e pamundur të krijohen tregues të papërpunuar në fusha të pa rreshtuara të një strukture të mbushur.
///
/// Përpjekja për të krijuar një tregues të papërpunuar në një fushë strukturë `unaligned` me një shprehje të tillë si `&packed.unaligned as *const FieldType` krijon një referencë të ndërmjetme të pavendosur përpara se ta shndërroni atë në një tregues të papërpunuar.
///
/// Që kjo referencë të jetë e përkohshme dhe e hedhur menjëherë është e pakonceptueshme pasi përpiluesi gjithmonë pret që referencat të rreshtohen siç duhet.
/// Si rezultat, përdorimi i `&packed.unaligned as *const FieldType` shkakton sjellje të menjëhershme* të papërcaktuar * në programin tuaj.
///
/// Një shembull i asaj që nuk duhet bërë dhe si lidhet kjo me `read_unaligned` është:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Këtu përpiqemi të marrim adresën e një numri të plotë 32-bit i cili nuk është i rreshtuar.
///     let unaligned =
///         // Këtu krijohet një referencë e përkohshme e pavendosur e cila rezulton në sjellje të papërcaktuar pavarësisht nëse referenca është përdorur apo jo.
/////
///         &packed.unaligned
///         // Hedhja në një tregues të papërpunuar nuk ndihmon;gabimi tashmë ka ndodhur.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Sidoqoftë, hyrja në fusha të pa rreshtuara me p.sh. `packed.unaligned` është e sigurt.
///
///
///
///
///
///
// FIXME: Azhurnoni dokumentet bazuar në rezultatin e RFC #2582 dhe miqtë.
/// # Examples
///
/// Lexoni një vlerë përdorimi nga një buffer bajt:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SIGURIA: thirrësi duhet të garantojë që `src` është i vlefshëm për leximet.
    // `src` nuk mund të mbivendoset `tmp` sepse `tmp` u caktua vetëm në pirg si një objekt i ndarë i ndarë.
    //
    //
    // Gjithashtu, meqenëse sapo kemi shkruar një vlerë të vlefshme në `tmp`, është e garantuar që të iniciohet siç duhet.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Mbishkruan një vendndodhje kujtese me vlerën e dhënë pa lexuar ose lëshuar vlerën e vjetër.
///
/// `write` nuk e lëshon përmbajtjen e `dst`.
/// Kjo është e sigurt, por mund të rrjedhë alokime ose burime, prandaj duhet pasur kujdes që të mos mbishkruhet një objekt që duhet të hidhet.
///
///
/// Për më tepër, ajo nuk bie `src`.Semantikisht, `src` zhvendoset në vendin e treguar nga `dst`.
///
/// Kjo është e përshtatshme për inicializimin e kujtesës së pa iniciale, ose mbivendosjen e kujtesës që ka qenë më parë nga [`read`].
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `dst` duhet të jetë [valid] për shkrime.
///
/// * `dst` duhet të rreshtohet siç duhet.Përdorni [`write_unaligned`] nëse nuk është kështu.
///
/// Vini re se edhe nëse `T` ka madhësinë `0`, treguesi duhet të mos jetë NULL dhe i rreshtuar siç duhet.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Zbatoni manualisht [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Krijoni një kopje bit bit të vlerës në `a` në `tmp`.
///         let tmp = ptr::read(a);
///
///         // Dalja në këtë pikë (ose duke u kthyer në mënyrë të qartë ose duke thirrur një funksion të cilin panics) do të bënte që vlera në `tmp` të bjerë ndërsa e njëjta vlerë referohet ende nga `a`.
///         // Kjo mund të shkaktojë sjellje të padefinuar nëse `T` nuk është `Copy`.
/////
/////
///
///         // Krijoni një kopje bit bit të vlerës në `b` në `a`.
///         // Kjo është e sigurt sepse referencat e ndryshueshme nuk mund të jenë alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Si më sipër, dalja këtu mund të shkaktojë sjellje të padefinuar, sepse e njëjta vlerë referohet nga `a` dhe `b`.
/////
///
///         // Zhvendosni `tmp` në `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` është zhvendosur (`write` merr në pronësi argumentin e tij të dytë), kështu që asgjë nuk bie nënkuptuar këtu.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Ne po i telefonojmë intrinsikët drejtpërdrejt për të shmangur thirrjet e funksioneve në kodin e krijuar pasi `intrinsics::copy_nonoverlapping` është një funksion mbështjellës.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SIGURIA: thirrësi duhet të garantojë që `dst` është i vlefshëm për shkrimet.
    // `dst` nuk mund të mbivendoset `src` sepse thirrësi ka qasje të ndryshueshme në `dst` ndërsa `src` është në pronësi të këtij funksioni.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Mbishkruan një vendndodhje kujtese me vlerën e dhënë pa lexuar ose lëshuar vlerën e vjetër.
///
/// Ndryshe nga [`write()`], treguesi mund të jetë i pavendosur.
///
/// `write_unaligned` nuk e lëshon përmbajtjen e `dst`.Kjo është e sigurt, por mund të rrjedhë alokime ose burime, prandaj duhet pasur kujdes që të mos mbishkruhet një objekt që duhet të hidhet.
///
/// Për më tepër, ajo nuk bie `src`.Semantikisht, `src` zhvendoset në vendin e treguar nga `dst`.
///
/// Kjo është e përshtatshme për inicializimin e kujtesës së pa iniciale, ose mbishkrimin e kujtesës që është lexuar më parë me [`read_unaligned`].
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `dst` duhet të jetë [valid] për shkrime.
///
/// Vini re se edhe nëse `T` ka madhësinë `0`, treguesi duhet të mos jetë NULL.
///
/// [valid]: self#safety
///
/// ## Në goditjet `packed`
///
/// Aktualisht është e pamundur të krijohen tregues të papërpunuar në fusha të pa rreshtuara të një strukture të mbushur.
///
/// Përpjekja për të krijuar një tregues të papërpunuar në një fushë strukturë `unaligned` me një shprehje të tillë si `&packed.unaligned as *const FieldType` krijon një referencë të ndërmjetme të pavendosur përpara se ta shndërroni atë në një tregues të papërpunuar.
///
/// Që kjo referencë të jetë e përkohshme dhe e hedhur menjëherë është e pakonceptueshme pasi përpiluesi gjithmonë pret që referencat të rreshtohen siç duhet.
/// Si rezultat, përdorimi i `&packed.unaligned as *const FieldType` shkakton sjellje të menjëhershme* të papërcaktuar * në programin tuaj.
///
/// Një shembull i asaj që nuk duhet bërë dhe si lidhet kjo me `write_unaligned` është:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Këtu përpiqemi të marrim adresën e një numri të plotë 32-bit i cili nuk është i rreshtuar.
///     let unaligned =
///         // Këtu krijohet një referencë e përkohshme e pavendosur e cila rezulton në sjellje të papërcaktuar pavarësisht nëse referenca është përdorur apo jo.
/////
///         &mut packed.unaligned
///         // Hedhja në një tregues të papërpunuar nuk ndihmon;gabimi tashmë ka ndodhur.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Sidoqoftë, hyrja në fusha të pa rreshtuara me p.sh. `packed.unaligned` është e sigurt.
///
///
///
///
///
///
///
///
///
// FIXME: Azhurnoni dokumentet bazuar në rezultatin e RFC #2582 dhe miqtë.
/// # Examples
///
/// Shkruani një vlerë përdorimi në një buffer bajt:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SIGURIA: thirrësi duhet të garantojë që `dst` është i vlefshëm për shkrimet.
    // `dst` nuk mund të mbivendoset `src` sepse thirrësi ka qasje të ndryshueshme në `dst` ndërsa `src` është në pronësi të këtij funksioni.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Ne jemi duke e thirrur të brendshmen direkt për të shmangur thirrjet e funksioneve në kodin e gjeneruar.
        intrinsics::forget(src);
    }
}

/// Kryen një lexim të paqëndrueshëm të vlerës nga `src` pa e lëvizur atë.Kjo e lë memorjen në `src` të pandryshuar.
///
/// Operacionet e paqëndrueshme kanë për qëllim të veprojnë në kujtesën I/O dhe janë të garantuara që të mos eleminohen ose renditen nga përpiluesi nëpër operacionet e tjera të paqëndrueshme.
///
/// # Notes
///
/// Rust aktualisht nuk ka një model memorie të përcaktuar në mënyrë rigoroze dhe zyrtare, kështu që semantika e saktë e asaj që do të thotë "volatile" këtu mund të ndryshojë me kalimin e kohës.
/// Thënë këtë, semantika pothuajse gjithmonë do të përfundojë shumë e ngjashme me [C11's definition of volatile][c11].
///
/// Përpiluesi nuk duhet të ndryshojë rendin relativ ose numrin e operacioneve të paqëndrueshme të kujtesës.
/// Sidoqoftë, operacionet e paqëndrueshme të kujtesës në llojet me madhësi zero (p.sh., nëse një tip me përmasa zero i kalohet `read_volatile`) nuk janë noops dhe mund të injorohen.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `src` duhet të jetë [valid] për lexime.
///
/// * `src` duhet të rreshtohet siç duhet.
///
/// * `src` duhet të tregojë në një vlerë të iniciuar siç duhet të tipit `T`.
///
/// Ashtu si [`read`], `read_volatile` krijon një kopje bitwise të `T`, pavarësisht nëse `T` është [`Copy`].
/// Nëse `T` nuk është [`Copy`], duke përdorur si vlerën e kthyer ashtu edhe vlerën në `*src` mund [violate memory safety][read-ownership].
/// Sidoqoftë, ruajtja e llojeve jo [[Kopjo]] në kujtesën e paqëndrueshme është pothuajse me siguri e pasaktë.
///
/// Vini re se edhe nëse `T` ka madhësinë `0`, treguesi duhet të mos jetë NULL dhe i rreshtuar siç duhet.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Ashtu si në C, nëse një operacion është i paqëndrueshëm nuk ka asnjë ndikim në pyetjet që përfshijnë hyrjen e njëkohshme nga fijet e shumta.Hyrjet e paqëndrueshme sillen saktësisht si akseset jo-atomike në atë drejtim.
///
/// Në veçanti, një garë midis një `read_volatile` dhe çdo operacioni shkrimi në të njëjtin vend është një sjellje e papërcaktuar.
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Jo në panik për të mbajtur më të vogël ndikimin e kodegjenit.
        abort();
    }
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Kryen një shkrim të paqëndrueshëm të një vendi memorie me vlerën e dhënë pa lexuar ose rënë vlerën e vjetër.
///
/// Operacionet e paqëndrueshme kanë për qëllim të veprojnë në kujtesën I/O dhe janë të garantuara që të mos eleminohen ose renditen nga përpiluesi nëpër operacionet e tjera të paqëndrueshme.
///
/// `write_volatile` nuk e lëshon përmbajtjen e `dst`.Kjo është e sigurt, por mund të rrjedhë alokime ose burime, prandaj duhet pasur kujdes që të mos mbishkruhet një objekt që duhet të hidhet.
///
/// Për më tepër, ajo nuk bie `src`.Semantikisht, `src` zhvendoset në vendin e treguar nga `dst`.
///
/// # Notes
///
/// Rust aktualisht nuk ka një model memorie të përcaktuar në mënyrë rigoroze dhe zyrtare, kështu që semantika e saktë e asaj që do të thotë "volatile" këtu mund të ndryshojë me kalimin e kohës.
/// Thënë këtë, semantika pothuajse gjithmonë do të përfundojë shumë e ngjashme me [C11's definition of volatile][c11].
///
/// Përpiluesi nuk duhet të ndryshojë rendin relativ ose numrin e operacioneve të paqëndrueshme të kujtesës.
/// Sidoqoftë, operacionet e paqëndrueshme të kujtesës në llojet me madhësi zero (p.sh., nëse një tip me përmasa zero i kalohet `write_volatile`) nuk janë noops dhe mund të injorohen.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `dst` duhet të jetë [valid] për shkrime.
///
/// * `dst` duhet të rreshtohet siç duhet.
///
/// Vini re se edhe nëse `T` ka madhësinë `0`, treguesi duhet të mos jetë NULL dhe i rreshtuar siç duhet.
///
/// [valid]: self#safety
///
/// Ashtu si në C, nëse një operacion është i paqëndrueshëm nuk ka asnjë ndikim në pyetjet që përfshijnë hyrjen e njëkohshme nga fijet e shumta.Hyrjet e paqëndrueshme sillen saktësisht si akseset jo-atomike në atë drejtim.
///
/// Në veçanti, një garë midis një `write_volatile` dhe çdo operacioni tjetër (leximi ose shkrimi) në të njëjtin vend është një sjellje e papërcaktuar.
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Jo në panik për të mbajtur më të vogël ndikimin e kodegjenit.
        abort();
    }
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Rreshtoni treguesin `p`.
///
/// Llogaritni kompensimin (për sa i përket elementeve të hapit `stride`) që duhet të zbatohet në treguesin `p` në mënyrë që treguesi `p` të rreshtohet në `a`.
///
/// Note: Ky zbatim është përshtatur me kujdes për të mos qenë panic.Ushtë UB për këtë në panic.
/// Ndryshimi i vetëm i vërtetë që mund të bëhet këtu është ndryshimi i `INV_TABLE_MOD_16` dhe konstanteve shoqëruese.
///
/// Nëse ndonjëherë vendosim të bëjmë të mundur që të thërrasim thelbin me `a` që nuk është një fuqi e dy, ndoshta do të jetë më e mençur të ndryshojmë thjesht në një zbatim naiv sesa të përpiqemi ta përshtatim atë për të akomoduar atë ndryshim.
///
///
/// Çdo pyetje shkoni në@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Përdorimi i drejtpërdrejtë i këtyre elementeve të brendshme e përmirëson kodin në mënyrë të konsiderueshme në nivelin e zgjedhjes <=
    // 1, ku versionet e metodave të këtyre operacioneve nuk janë të nënvizuara.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Llogarit anasjelltën modulare shumëzuese të modulit `x` `m`.
    ///
    /// Ky zbatim është përshtatur për `align_offset` dhe ka parakushtet e mëposhtme:
    ///
    /// * `m` është një fuqi-e-dy;
    /// * `x < m`; (nëse `x ≥ m`, kalo në `x % m` në vend)
    ///
    /// Zbatimi i këtij funksioni nuk do të panic.Gjithnjë
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Moduli i tabelës së anasjellë modulare shumëzuese 2⁴=16.
        ///
        /// Vini re, se kjo tabelë nuk përmban vlera ku nuk ekziston inversi (p.sh., për `0⁻¹ mod 16`, `2⁻¹ mod 16`, etj.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modul për të cilin është menduar `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SIGURIA: `m` kërkohet të jetë një fuqi-e-dy, pra jo-zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Ne përsërisim "up" duke përdorur formulën e mëposhtme:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // deri në 2²ⁿ ≥ m.Atëherë ne mund të zvogëlohemi në `m` të dëshiruar duke marrë rezultatin `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Vini re, që ne përdorim operacione ambalazhi këtu qëllimisht-formula origjinale përdor p.sh., zbritjen `mod n`.
                // Entirelyshtë plotësisht mirë t'i bëjmë ato `mod usize::MAX` në vend të tyre, sepse gjithsesi ne e marrim rezultatin `mod n` në fund.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SIGURIA: `a` është një fuqi-e-dy, prandaj jo-zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` rasti mund të llogaritet më thjesht përmes `-p (mod a)`, por duke bërë kështu pengon aftësinë e LLVM për të zgjedhur udhëzime si `lea`.Në vend të kësaj ne llogarisim
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // i cili shpërndan operacionet rreth mbajtjes së ngarkesës, por duke pesimizuar `and` mjaftueshëm që LLVM të jetë në gjendje të shfrytëzojë optimizimet e ndryshme për të cilat di.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Rreshtuar tashmë.Po!
        return 0;
    } else if stride == 0 {
        // Nëse treguesi nuk është i rreshtuar, dhe elementi është me madhësi zero, atëherë asnjë sasi e elementeve nuk do të rreshtojë kurrë treguesin.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SIGURIA: a është fuqia e dy, pra jo-zero.hap i madh==0 çështje trajtohet më lart.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SIGURIA: gcdpow ka një kufizim të sipërm që është më së shumti numri i bitëve në një përdorim.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SIGURIA: gcd është gjithmonë më e madhe ose e barabartë me 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Ky branch zgjidh për ekuacionin vijues linear të kongruencës:
        //
        // ` p + so = 0 mod a `
        //
        // `p` këtu është vlera e treguesit, `s`, hapi i `T`, `o` i kompensuar në `T` dhe `a`, shtrirja e kërkuar.
        //
        // Me `g = gcd(a, s)`, dhe kushti i mësipërm që pohon se `p` është gjithashtu i ndashëm me `g`, ne mund të shënojmë `a' = a/g`, `s' = s/g`, `p' = p/g`, atëherë kjo bëhet ekuivalente me:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Termi i parë është "the relative alignment of `p` to `a`" (i ndarë nga `g`), termi i dytë është "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (përsëri i ndarë me `g`).
        //
        // Ndarja sipas `g` është e nevojshme për të bërë anasjelltën të formuar mirë nëse `a` dhe `s` nuk janë bashkë-kryeministër.
        //
        // Për më tepër, rezultati i prodhuar nga kjo zgjidhje nuk është "minimal", prandaj është e nevojshme të merret rezultati `o mod lcm(s, a)`.Ne mund ta zëvendësojmë `lcm(s, a)` me vetëm një `a'`.
        //
        //
        //
        //
        //

        // SIGURIA: `gcdpow` ka një kufij të sipërm, jo më të madh se numri i 0-bitëve zvarritës në `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SIGURIA: `a2` nuk është zero.Zhvendosja `a` nga `gcdpow` nuk mund të zhvendosë asnjë nga bitët e caktuar
        // në `a` (nga të cilat ka saktësisht një).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SIGURIA: `gcdpow` ka një kufij të sipërm, jo më të madh se numri i 0-bitëve zvarritës në `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SIGURIA: `gcdpow` ka një kufij të sipërm jo më të madh se numri i 0-bitëve zvarritës në
        // `a`.
        // Për më tepër, zbritja nuk mund të vërshojë, sepse `a2 = a >> gcdpow` do të jetë gjithmonë rreptësisht më e madhe se `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SIGURIA: `a2` është një fuqi e të dyve, siç është provuar më lart.`s2` është rreptësisht më pak se `a2`
        // sepse `(s % a) >> gcdpow` është rreptësisht më pak se `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Nuk mund të rreshtohet fare.
    usize::MAX
}

/// Krahason treguesit e papërpunuar për barazinë.
///
/// Kjo është e njëjtë me përdorimin e operatorit `==`, por më pak gjenerike:
/// argumentet duhet të jenë tregues të papërpunuar `*const T`, jo ndonjë gjë që zbaton `PartialEq`.
///
/// Kjo mund të përdoret për të krahasuar referencat `&T` (të cilat imponohen në mënyrë të nënkuptuar me `*const T`) nga adresa e tyre në vend se të krahasohen vlerat për të cilat tregojnë (gjë që bën implementimi `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Fetë krahasohen gjithashtu nga gjatësia e tyre (tregues dhjami):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits krahasohen gjithashtu nga zbatimi i tyre:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Treguesit kanë adresa të barabarta.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objektet kanë adresa të barabarta, por `Trait` ka implementime të ndryshme.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Konvertimi i referencës në një `*const u8` krahason sipas adresës.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash një tregues të papërpunuar.
///
/// Kjo mund të përdoret për të hash një referencë `&T` (e cila detyron `*const T` në mënyrë implicite) nga adresa e saj sesa nga vlera që tregon (e cila është ajo që bën implementimi `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Nënkupton për treguesit e funksioneve
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Cast-i i ndërmjetëm si përdorim kërkohet për AVR
                // në mënyrë që hapësira e adresës së treguesit të funksionit burimor të ruhet në treguesin e funksionit përfundimtar.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Cast-i i ndërmjetëm si përdorim kërkohet për AVR
                // në mënyrë që hapësira e adresës së treguesit të funksionit burimor të ruhet në treguesin e funksionit përfundimtar.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Asnjë funksion variadik me 0 parametra
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Krijoni një tregues të papërpunuar `const` në një vend, pa krijuar një referencë të ndërmjetme.
///
/// Krijimi i një referencë me `&`/`&mut` lejohet vetëm nëse treguesi është rreshtuar siç duhet dhe tregon të dhënat e iniciuara.
/// Për rastet kur ato kërkesa nuk përmbajnë, duhet të përdoren tregues të papërpunuar.
/// Sidoqoftë, `&expr as *const _` krijon një referencë përpara se ta hedhë në një tregues të papërpunuar dhe kjo referencë u nënshtrohet të njëjtave rregulla si të gjitha referencat e tjera.
///
/// Kjo makro mund të krijojë një tregues të papërpunuar *pa* krijuar më parë një referencë.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` do të krijonte një referencë të palidhur, dhe kështu do të ishte Sjellje e Padefinuar!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Krijoni një tregues të papërpunuar `mut` në një vend, pa krijuar një referencë të ndërmjetme.
///
/// Krijimi i një referencë me `&`/`&mut` lejohet vetëm nëse treguesi është rreshtuar siç duhet dhe tregon të dhënat e iniciuara.
/// Për rastet kur ato kërkesa nuk përmbajnë, duhet të përdoren tregues të papërpunuar.
/// Sidoqoftë, `&mut expr as *mut _` krijon një referencë përpara se ta hedhë në një tregues të papërpunuar dhe kjo referencë u nënshtrohet të njëjtave rregulla si të gjitha referencat e tjera.
///
/// Kjo makro mund të krijojë një tregues të papërpunuar *pa* krijuar më parë një referencë.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` do të krijonte një referencë të palidhur, dhe kështu do të ishte Sjellje e Padefinuar!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` detyron kopjimin e fushës në vend që të krijojë një referencë.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}