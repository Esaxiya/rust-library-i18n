use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` por jo zero dhe kovariante.
///
/// Kjo është shpesh gjëja e duhur për t'u përdorur kur ndërtohen struktura të të dhënave duke përdorur tregues të papërpunuar, por në fund të fundit është më e rrezikshme për t'u përdorur për shkak të vetive të saj shtesë.Nëse nuk jeni i sigurt nëse duhet të përdorni `NonNull<T>`, thjesht përdorni `*mut T`!
///
/// Ndryshe nga `*mut T`, treguesi duhet të jetë gjithnjë jo nul, edhe nëse treguesi nuk referohet kurrë.Kjo është kështu që enumet mund ta përdorin këtë vlerë të ndaluar si një diskriminues-`Option<NonNull<T>>` ka të njëjtën madhësi si `* mut T`.
/// Sidoqoftë, treguesi mund të tund ende nëse nuk referohet.
///
/// Ndryshe nga `*mut T`, `NonNull<T>` u zgjodh të ishte kovariant ndaj `T`.Kjo bën të mundur përdorimin e `NonNull<T>` kur ndërtohen lloje kovariante, por paraqet rrezikun e paqëndrueshmërisë nëse përdoret në një tip që në të vërtetë nuk duhet të jetë kovariant.
/// (Zgjedhja e kundërt është bërë për `*mut T` edhe pse teknikisht paqëndrueshmëria mund të shkaktohet vetëm nga thirrja e funksioneve të pasigurta.)
///
/// Kovarianca është e saktë për shumicën e abstraksioneve të sigurta, të tilla si `Box`, `Rc`, `Arc`, `Vec` dhe `LinkedList`.Ky është rasti sepse ato ofrojnë një API publik që ndjek rregullat normale të përbashkëta XOR të ndryshueshme të Rust.
///
/// Nëse lloji juaj nuk mund të jetë kovariant në mënyrë të sigurt, duhet të siguroheni që përmban disa fusha shtesë për të siguruar pandryshueshmëri.Shpesh kjo fushë do të jetë një lloj [`PhantomData`] si `PhantomData<Cell<T>>` ose `PhantomData<&'a mut T>`.
///
/// Vini re se `NonNull<T>` ka një shembull `From` për `&T`.Sidoqoftë, kjo nuk e ndryshon faktin se mutacioni përmes një (treguesi që rrjedh nga a) referencë e përbashkët është një sjellje e papërcaktuar nëse mutacioni nuk ndodh brenda një [`UnsafeCell<T>`].E njëjta gjë vlen edhe për krijimin e një reference të ndryshueshme nga një referencë e përbashkët.
///
/// Kur përdorni këtë shembull `From` pa `UnsafeCell<T>`, është përgjegjësia juaj të siguroheni që `as_mut` të mos thirret kurrë, dhe `as_ptr` të mos përdoret kurrë për mutacion.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` treguesit nuk janë `Send` sepse të dhënat që ata referojnë mund të jenë alias.
// NB, ky nënkuptim është i panevojshëm, por duhet të ofrojë mesazhe më të mira gabimi.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` treguesit nuk janë `Sync` sepse të dhënat që ata referojnë mund të jenë alias.
// NB, ky nënkuptim është i panevojshëm, por duhet të ofrojë mesazhe më të mira gabimi.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Krijon një `NonNull` të ri që është i varur, por i rreshtuar mirë.
    ///
    /// Kjo është e dobishme për inicializimin e llojeve që alokojnë me përtesë, siç bën `Vec::new`.
    ///
    /// Vini re se vlera e treguesit mund të përfaqësojë potencialisht një tregues të vlefshëm për një `T`, që do të thotë se kjo nuk duhet të përdoret si një vlerë roje "not yet initialized".
    /// Llojet që caktojnë me përtesë duhet të ndjekin inicializimin me disa mjete të tjera.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SIGURIA: mem::align_of() kthen një përdorim jo-zero i cili më pas shtrihet
        // te një * mut T.
        // Prandaj, `ptr` nuk është i pavlefshëm dhe kushtet për të thirrur new_unchecked() respektohen.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Kthen një referencë të përbashkët për vlerën.Në kontrast me [`as_ref`], kjo nuk kërkon që vlera të iniciohet.
    ///
    /// Për homologun e ndryshueshëm shih [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Kur telefononi këtë metodë, duhet të siguroheni që të gjitha sa më poshtë janë të vërteta:
    ///
    /// * Treguesi duhet të rreshtohet siç duhet.
    ///
    /// * Duhet të jetë "dereferencable" në kuptimin e përcaktuar në [the module documentation].
    ///
    /// * Ju duhet të zbatoni rregullat aliasing të Rust, pasi jeta e kthyer `'a` zgjidhet në mënyrë arbitrare dhe nuk pasqyron domosdoshmërisht jetën e vërtetë të të dhënave.
    ///
    ///   Veçanërisht, gjatë kohëzgjatjes së kësaj jete, kujtesa në të cilën treguesi tregon nuk duhet të ndryshohet (përveç brenda `UnsafeCell`).
    ///
    /// Kjo vlen edhe nëse rezultati i kësaj metode është i papërdorur!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SIGURIA: thirrësi duhet të garantojë që `self` plotëson të gjitha pajisjet
        // kërkesat për një referencë.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Kthen një referencë unike në vlerë.Në kontrast me [`as_mut`], kjo nuk kërkon që vlera të iniciohet.
    ///
    /// Për homologun e përbashkët shih [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Kur telefononi këtë metodë, duhet të siguroheni që të gjitha sa më poshtë janë të vërteta:
    ///
    /// * Treguesi duhet të rreshtohet siç duhet.
    ///
    /// * Duhet të jetë "dereferencable" në kuptimin e përcaktuar në [the module documentation].
    ///
    /// * Ju duhet të zbatoni rregullat aliasing të Rust, pasi jeta e kthyer `'a` zgjidhet në mënyrë arbitrare dhe nuk pasqyron domosdoshmërisht jetën e vërtetë të të dhënave.
    ///
    ///   Në veçanti, gjatë kohëzgjatjes së kësaj jete, kujtesa në të cilën treguesi tregon nuk duhet të arrihet (lexohet ose shkruhet) përmes ndonjë treguesi tjetër.
    ///
    /// Kjo vlen edhe nëse rezultati i kësaj metode është i papërdorur!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SIGURIA: thirrësi duhet të garantojë që `self` plotëson të gjitha pajisjet
        // kërkesat për një referencë.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Krijon një `NonNull` të ri.
    ///
    /// # Safety
    ///
    /// `ptr` duhet të jetë jo nul.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SIGURIA: thirrësi duhet të garantojë që `ptr` nuk është i pavlefshëm.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Krijon një `NonNull` të ri nëse `ptr` nuk është nul.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SIGURIA: Treguesi është kontrolluar tashmë dhe nuk është nul
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Kryen të njëjtën funksionalitet si [`std::ptr::from_raw_parts`], përveç që një tregues `NonNull` kthehet, në krahasim me një tregues të papërpunuar `*const`.
    ///
    ///
    /// Shihni dokumentacionin e [`std::ptr::from_raw_parts`] për më shumë detaje.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SIGURIA: Rezultati i `ptr::from::raw_parts_mut` nuk është i pavlefshëm sepse `data_address` është.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Zbërthehet një tregues (ndoshta i gjerë) në përbërësit e adresës dhe të meta të dhënave.
    ///
    /// Treguesi mund të rindërtohet më vonë me [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Blen treguesin themelor `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Kthen një referencë të përbashkët për vlerën.Nëse vlera mund të mos inicializohet, në vend të kësaj duhet të përdoret [`as_uninit_ref`].
    ///
    /// Për homologun e ndryshueshëm shih [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Kur telefononi këtë metodë, duhet të siguroheni që të gjitha sa më poshtë janë të vërteta:
    ///
    /// * Treguesi duhet të rreshtohet siç duhet.
    ///
    /// * Duhet të jetë "dereferencable" në kuptimin e përcaktuar në [the module documentation].
    ///
    /// * Treguesi duhet të tregojë në një rast të iniciuar të `T`.
    ///
    /// * Ju duhet të zbatoni rregullat aliasing të Rust, pasi jeta e kthyer `'a` zgjidhet në mënyrë arbitrare dhe nuk pasqyron domosdoshmërisht jetën e vërtetë të të dhënave.
    ///
    ///   Veçanërisht, gjatë kohëzgjatjes së kësaj jete, kujtesa në të cilën treguesi tregon nuk duhet të ndryshohet (përveç brenda `UnsafeCell`).
    ///
    /// Kjo vlen edhe nëse rezultati i kësaj metode është i papërdorur!
    /// (Pjesa për inicimin nuk është vendosur ende plotësisht, por derisa të bëhet, e vetmja mënyrë e sigurt është të sigurohet që ato të iniciohen me të vërtetë.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SIGURIA: thirrësi duhet të garantojë që `self` plotëson të gjitha pajisjet
        // kërkesat për një referencë.
        unsafe { &*self.as_ptr() }
    }

    /// Kthen një referencë unike në vlerë.Nëse vlera mund të mos inicializohet, në vend të kësaj duhet të përdoret [`as_uninit_mut`].
    ///
    /// Për homologun e përbashkët shih [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Kur telefononi këtë metodë, duhet të siguroheni që të gjitha sa më poshtë janë të vërteta:
    ///
    /// * Treguesi duhet të rreshtohet siç duhet.
    ///
    /// * Duhet të jetë "dereferencable" në kuptimin e përcaktuar në [the module documentation].
    ///
    /// * Treguesi duhet të tregojë në një rast të iniciuar të `T`.
    ///
    /// * Ju duhet të zbatoni rregullat aliasing të Rust, pasi jeta e kthyer `'a` zgjidhet në mënyrë arbitrare dhe nuk pasqyron domosdoshmërisht jetën e vërtetë të të dhënave.
    ///
    ///   Në veçanti, gjatë kohëzgjatjes së kësaj jete, kujtesa në të cilën treguesi tregon nuk duhet të arrihet (lexohet ose shkruhet) përmes ndonjë treguesi tjetër.
    ///
    /// Kjo vlen edhe nëse rezultati i kësaj metode është i papërdorur!
    /// (Pjesa për inicimin nuk është vendosur ende plotësisht, por derisa të bëhet, e vetmja mënyrë e sigurt është të sigurohet që ato të iniciohen me të vërtetë.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SIGURIA: thirrësi duhet të garantojë që `self` plotëson të gjitha pajisjet
        // kërkesat për një referencë të ndryshueshme.
        unsafe { &mut *self.as_ptr() }
    }

    /// Hedh në një tregues të një lloji tjetër.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SIGURIA: `self` është një tregues `NonNull` i cili domosdoshmërisht nuk është i pavlefshëm
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Krijon një fetë të papërpunuar jo-null nga një tregues i hollë dhe një gjatësi.
    ///
    /// Argumenti `len` është numri i **elementeve**, jo numri i bajteve.
    ///
    /// Ky funksion është i sigurt, por referimi i vlerës së kthimit është i pasigurt.
    /// Shihni dokumentacionin e [`slice::from_raw_parts`] për kërkesat e sigurisë në feta.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // krijoni një tregues me feta kur filloni me një tregues te elementi i parë
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Vini re se ky shembull demonstron artificialisht një përdorim të kësaj metode, por `le fetë= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SIGURIA: `data` është një tregues `NonNull` i cili domosdoshmërisht nuk është i pavlefshëm
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Kthen gjatësinë e një fete të papërpunuar jo null.
    ///
    /// Vlera e kthyer është numri i **elementeve**, jo numri i bajteve.
    ///
    /// Ky funksion është i sigurt, edhe kur feta e papërpunuar jo null nuk mund të referohet në një fetë sepse treguesi nuk ka një adresë të vlefshme.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Kthen një tregues jo null në bufferin e fetë.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SIGURIA: Ne e dimë që `self` nuk është nul.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Kthen një tregues të papërpunuar në buffer-in e fetë-s.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Kthen një referencë të përbashkët në një pjesë të vlerave të mundshme të pa iniciale.Në kontrast me [`as_ref`], kjo nuk kërkon që vlera të iniciohet.
    ///
    /// Për homologun e ndryshueshëm shih [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Kur telefononi këtë metodë, duhet të siguroheni që të gjitha sa më poshtë janë të vërteta:
    ///
    /// * Treguesi duhet të jetë [valid] për lexime për `ptr.len() * mem::size_of::<T>()` shumë bajte, dhe duhet të jetë i rreshtuar siç duhet.Kjo do të thotë në veçanti:
    ///
    ///     * E gjithë diapazoni i kujtesës së kësaj flete duhet të përmbahet në një objekt të vetëm të alokuar!
    ///       Fetë nuk mund të shtrihen kurrë nëpër objekte të shumta të alokuara.
    ///
    ///     * Treguesi duhet të rreshtohet edhe për feta me gjatësi zero.
    ///     Një arsye për këtë është që optimizimet e paraqitjes së enumit mund të mbështeten në referencat (përfshirë feta të çdo gjatësi) që janë në një linjë dhe jo null për t'i dalluar ato nga të dhënat e tjera.
    ///
    ///     Ju mund të merrni një tregues që është i përdorshëm si `data` për feta me gjatësi zero duke përdorur [`NonNull::dangling()`].
    ///
    /// * Madhësia totale `ptr.len() * mem::size_of::<T>()` e fetë nuk duhet të jetë më e madhe se `isize::MAX`.
    ///   Shihni dokumentacionin e sigurisë së [`pointer::offset`].
    ///
    /// * Ju duhet të zbatoni rregullat aliasing të Rust, pasi jeta e kthyer `'a` zgjidhet në mënyrë arbitrare dhe nuk pasqyron domosdoshmërisht jetën e vërtetë të të dhënave.
    ///   Veçanërisht, gjatë kohëzgjatjes së kësaj jete, kujtesa në të cilën treguesi tregon nuk duhet të ndryshohet (përveç brenda `UnsafeCell`).
    ///
    /// Kjo vlen edhe nëse rezultati i kësaj metode është i papërdorur!
    ///
    /// Shihni gjithashtu [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Kthen një referencë unike në një pjesë të vlerave të mundshme të pa iniciale.Në kontrast me [`as_mut`], kjo nuk kërkon që vlera të iniciohet.
    ///
    /// Për homologun e përbashkët shih [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Kur telefononi këtë metodë, duhet të siguroheni që të gjitha sa më poshtë janë të vërteta:
    ///
    /// * Treguesi duhet të jetë [valid] për lexime dhe shkrime për `ptr.len() * mem::size_of::<T>()` shumë bajte, dhe duhet të jetë i rreshtuar siç duhet.Kjo do të thotë në veçanti:
    ///
    ///     * E gjithë diapazoni i kujtesës së kësaj flete duhet të përmbahet në një objekt të vetëm të alokuar!
    ///       Fetë nuk mund të shtrihen kurrë nëpër objekte të shumta të alokuara.
    ///
    ///     * Treguesi duhet të rreshtohet edhe për feta me gjatësi zero.
    ///     Një arsye për këtë është që optimizimet e paraqitjes së enumit mund të mbështeten në referencat (përfshirë feta të çdo gjatësi) që janë në një linjë dhe jo null për t'i dalluar ato nga të dhënat e tjera.
    ///
    ///     Ju mund të merrni një tregues që është i përdorshëm si `data` për feta me gjatësi zero duke përdorur [`NonNull::dangling()`].
    ///
    /// * Madhësia totale `ptr.len() * mem::size_of::<T>()` e fetë nuk duhet të jetë më e madhe se `isize::MAX`.
    ///   Shihni dokumentacionin e sigurisë së [`pointer::offset`].
    ///
    /// * Ju duhet të zbatoni rregullat aliasing të Rust, pasi jeta e kthyer `'a` zgjidhet në mënyrë arbitrare dhe nuk pasqyron domosdoshmërisht jetën e vërtetë të të dhënave.
    ///   Në veçanti, gjatë kohëzgjatjes së kësaj jete, kujtesa në të cilën treguesi tregon nuk duhet të arrihet (lexohet ose shkruhet) përmes ndonjë treguesi tjetër.
    ///
    /// Kjo vlen edhe nëse rezultati i kësaj metode është i papërdorur!
    ///
    /// Shihni gjithashtu [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Kjo është e sigurt pasi `memory` është e vlefshme për lexime dhe shkrime për `memory.len()` shumë bajte.
    /// // Vini re se thirrja `memory.as_mut()` nuk lejohet këtu pasi përmbajtja mund të jetë e pa iniciale.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Kthen një tregues të papërpunuar në një element ose nënfushë, pa bërë kontrollin e kufijve.
    ///
    /// Thirrja e kësaj metode me një indeks jashtë kufijve ose kur `self` nuk është i paqëndrueshëm është *[sjellje e papërcaktuar]* edhe nëse treguesi që rezulton nuk përdoret.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SIGURIA: thirrësi siguron që `self` të jetë i referueshëm dhe `index` në kufij.
        // Si pasojë, treguesi që rezulton nuk mund të jetë NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SIGURIA: Një tregues unik nuk mund të jetë i pavlefshëm, kështu që kushtet për
        // new_unchecked() respektohen
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SIGURIA: Një referencë e ndryshueshme nuk mund të jetë e pavlefshme.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SIGURIA: Një referencë nuk mund të jetë nul, kështu që kushtet për
        // new_unchecked() respektohen
        unsafe { NonNull { pointer: reference as *const T } }
    }
}