#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Siguron llojin e meta të dhënave të treguesit të çdo lloji drejtues.
///
/// # Të dhënat meta të treguesit
///
/// Llojet e treguesve të papërpunuar dhe llojet e referencës në Rust mund të mendohen se janë bërë nga dy pjesë:
/// një tregues i të dhënave që përmban adresën e kujtesës së vlerës, dhe disa meta të dhëna.
///
/// Për llojet me madhësi statike (që implementojnë `Sized` traits) si dhe për llojet `extern`, treguesit thuhet se janë "të hollë": meta të dhënat janë me madhësi zero dhe lloji i tyre është `()`.
///
///
/// Treguesit për [dynamically-sized types][dst] thuhet se janë "të gjerë" ose "yndyrë", ata kanë meta të dhëna me madhësi jo zero:
///
/// * Për strukturat, fusha e fundit e të cilave është një DST, meta të dhënat janë meta të dhënat për fushën e fundit
/// * Për llojin `str`, metadata është gjatësia në bajt si `usize`
/// * Për llojet e feta si `[T]`, metadata është gjatësia në artikuj si `usize`
/// * Për objektet trait si `dyn SomeTrait`, metadata është [`DynMetadata<Self>`][DynMetadata] (p.sh. `DynMetadata<dyn SomeTrait>`)
///
/// Në future, gjuha Rust mund të fitojë lloje të reja të llojeve që kanë meta të dhëna të ndryshme të treguesit.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Pika e këtij trait është lloji i tij i lidhur me `Metadata`, i cili është `()` ose `usize` ose `DynMetadata<_>` siç përshkruhet më sipër.
/// Zbatohet automatikisht për çdo lloj.
/// Mund të supozohet se do të zbatohet në një kontekst gjenerik, edhe pa ndonjë lidhje përkatëse.
///
/// # Usage
///
/// Treguesit e papërpunuar mund të zbërthehen në adresën e të dhënave dhe përbërësit e meta të dhënave me metodën e tyre [`to_raw_parts`].
///
/// Përndryshe, vetëm meta të dhënat mund të nxirren me funksionin [`metadata`].
/// Një referencë mund t'i kalohet [`metadata`] dhe të imponohet në mënyrë implicite.
///
/// Një tregues (possibly-wide) mund të vendoset përsëri nga adresa dhe meta të dhënat e tij me [`from_raw_parts`] ose [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Lloji për meta të dhëna në tregues dhe referenca për `Self`.
    #[lang = "metadata_type"]
    // NOTE: Mbani trait bounds në `static_assert_expected_bounds_for_metadata`
    //
    // në `library/core/src/ptr/metadata.rs` në sinkron me ato këtu:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Treguesit për llojet që zbatojnë këtë pseudonim trait janë "të hollë".
///
/// Kjo përfshin lloje me madhësi statike dhe lloje `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: mos e stabilizoni këtë para se pseudonimet trait të jenë të qëndrueshme në gjuhë?
pub trait Thin = Pointee<Metadata = ()>;

/// Nxirrni përbërësin e meta të dhënave të një treguesi.
///
/// Vlerat e tipit `*mut T`, `&T` ose `&mut T` mund t'i kalohen drejtpërdrejt këtij funksioni pasi ato imponohen në mënyrë implicite për `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SIGURIA: Hyrja në vlerën nga bashkimi `PtrRepr` është e sigurt pasi * const T
    // dhe PtrComponents<T>kanë paraqitjet e njëjta të kujtesës.
    // Vetëm std mund ta bëjë këtë garanci.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Formon një tregues të papërpunuar (possibly-wide) nga një adresë e të dhënave dhe meta të dhënave.
///
/// Ky funksion është i sigurt, por treguesi i kthyer nuk është domosdoshmërisht i sigurt për t'u rivendosur.
/// Për feta, shihni dokumentacionin e [`slice::from_raw_parts`] për kërkesat e sigurisë.
/// Për objektet trait, metadata duhet të vijë nga një tregues në të njëjtin tip themelor të ngritur.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SIGURIA: Hyrja në vlerën nga bashkimi `PtrRepr` është e sigurt pasi * const T
    // dhe PtrComponents<T>kanë paraqitjet e njëjta të kujtesës.
    // Vetëm std mund ta bëjë këtë garanci.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Kryen të njëjtën funksionalitet si [`from_raw_parts`], përveç që një tregues i papërpunuar `*mut` kthehet, në krahasim me një tregues të papërpunuar `* const`.
///
///
/// Shihni dokumentacionin e [`from_raw_parts`] për më shumë detaje.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SIGURIA: Hyrja në vlerën nga bashkimi `PtrRepr` është e sigurt pasi * const T
    // dhe PtrComponents<T>kanë paraqitjet e njëjta të kujtesës.
    // Vetëm std mund ta bëjë këtë garanci.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Kërkohet manual manual për të shmangur lidhjen `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Kërkohet manual manual për të shmangur lidhjen `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Të dhënat meta për një tip objekt `Dyn = dyn SomeTrait` trait.
///
/// Shtë një tregues i një tryeze vtable (tabela e thirrjeve virtuale) që përfaqëson të gjithë informacionin e nevojshëm për të manipuluar llojin e betonit të ruajtur brenda një objekti trait.
/// Tabela e posaçme përmban:
///
/// * madhësia e tipit
/// * shtrirja e tipit
/// * një tregues për tipin `drop_in_place` të tipit (mund të jetë një ndalim opsioni për të dhëna të vjetra)
/// * tregues për të gjitha metodat për zbatimin e llojit të trait
///
/// Vini re se tre të parat janë të veçanta sepse ato janë të nevojshme për të alokuar, hedhur dhe shpërndarë çdo objekt trait.
///
/// Possibleshtë e mundur të emërtohet kjo strukturë me një parametër tipi që nuk është objekt `dyn` trait (për shembull `DynMetadata<u64>`) por jo të merret një vlerë kuptimplotë e asaj strukture.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Parashtesa e përbashkët e të gjitha tryezave.Ajo ndiqet nga treguesit e funksioneve për metodat trait.
///
/// Detaje private të implementimit të `DynMetadata::size_of` etj.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Kthen madhësinë e llojit të shoqëruar me këtë tryezë.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Kthen shtrirjen e tipit të shoqëruar me këtë tryezë.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Kthen madhësinë dhe përafrimin së bashku si `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SIGURIA: përpiluesi ka emetuar këtë tryezë për një lloj betoni Rust i cili
        // dihet që ka një paraqitje të vlefshme.I njëjti arsyetim si në `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Nënkupton manualin që nevojitet për të shmangur kufijtë `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}