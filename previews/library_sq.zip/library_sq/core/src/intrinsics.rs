//! Përbërësit e brendshëm.
//!
//! Përkufizimet përkatëse janë në `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Zbatimet përkatëse të konstituimeve janë në `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Të brendshmet konst
//!
//! Note: çdo ndryshim në qëndrueshmërinë e personave të brendshëm duhet të diskutohet me ekipin e gjuhës.
//! Kjo përfshin ndryshime në qëndrueshmërinë e qëndrueshmërisë.
//!
//! Në mënyrë që të bëhet një i brendshëm i përdorshëm në kohën e përpilimit, duhet të kopjoni zbatimin nga <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> në `compiler/rustc_mir/src/interpret/intrinsics.rs` dhe të shtoni një `#[rustc_const_unstable(feature = "foo", issue = "01234")]` në të brendshme.
//!
//!
//! Nëse një i brendshëm supozohet të përdoret nga një `const fn` me një atribut `rustc_const_stable`, atributi i brendshëm duhet të jetë `rustc_const_stable`, gjithashtu.
//! Një ndryshim i tillë nuk duhet të bëhet pa konsultimin e T-lang, sepse ai krijon një tipar në gjuhë që nuk mund të kopjohet në kodin e përdoruesit pa mbështetjen e përpiluesit.
//!
//! # Volatiles
//!
//! Të brendshme të paqëndrueshme sigurojnë operacione të destinuara për të vepruar në kujtesën I/O, të cilat janë të garantuara që të mos renditen nga përpiluesi në brendësi të tjera të paqëndrueshme.Shihni dokumentacionin LLVM në [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Të brendshmet atomike ofrojnë veprime të zakonshme atomike në fjalët e makinës, me renditje të shumta të mundshme të kujtesës.Ata i binden të njëjtës semantikë si C++ 11.Shihni dokumentacionin LLVM në [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Një rifreskim i shpejtë i porositjes së kujtesës:
//!
//! * Bleni, një pengesë për blerjen e një bravë.Leximet dhe shkrimet e mëvonshme zhvillohen pas pengesës.
//! * Lirimi, një pengesë për lëshimin e një bravë.Parashkrimet e leximeve dhe shkrimeve zhvillohen para pengesës.
//! * Operacionet në vazhdimësi të qëndrueshme, të njëpasnjëshme janë të garantuara të ndodhin në rregull.Kjo është mënyra standarde për të punuar me llojet atomike dhe është ekuivalente me `volatile` e Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Këto importe përdoren për thjeshtimin e lidhjeve brenda-dok
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SIGURIA: shih `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, këta të brendshëm marrin indikatorë të papërpunuar sepse mutojnë memorien aliased, e cila nuk është e vlefshme as për `&` dhe as për `&mut`.
    //

    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojet [`atomic`] përmes metodës `compare_exchange` duke kaluar [`Ordering::SeqCst`] si parametrat `success` dhe `failure`.
    ///
    /// Për shembull, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojet [`atomic`] përmes metodës `compare_exchange` duke kaluar [`Ordering::Acquire`] si parametrat `success` dhe `failure`.
    ///
    /// Për shembull, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është në dispozicion në llojet [`atomic`] përmes metodës `compare_exchange` duke kaluar [`Ordering::Release`] si `success` dhe [`Ordering::Relaxed`] si parametrat `failure`.
    /// Për shembull, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është në dispozicion në llojet [`atomic`] përmes metodës `compare_exchange` duke kaluar [`Ordering::AcqRel`] si `success` dhe [`Ordering::Acquire`] si parametrat `failure`.
    /// Për shembull, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojet [`atomic`] përmes metodës `compare_exchange` duke kaluar [`Ordering::Relaxed`] si parametrat `success` dhe `failure`.
    ///
    /// Për shembull, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është në dispozicion në llojet [`atomic`] përmes metodës `compare_exchange` duke kaluar [`Ordering::SeqCst`] si `success` dhe [`Ordering::Relaxed`] si parametrat `failure`.
    /// Për shembull, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është në dispozicion në llojet [`atomic`] përmes metodës `compare_exchange` duke kaluar [`Ordering::SeqCst`] si `success` dhe [`Ordering::Acquire`] si parametrat `failure`.
    /// Për shembull, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është në dispozicion në llojet [`atomic`] përmes metodës `compare_exchange` duke kaluar [`Ordering::Acquire`] si `success` dhe [`Ordering::Relaxed`] si parametrat `failure`.
    /// Për shembull, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është në dispozicion në llojet [`atomic`] përmes metodës `compare_exchange` duke kaluar [`Ordering::AcqRel`] si `success` dhe [`Ordering::Relaxed`] si parametrat `failure`.
    /// Për shembull, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojet [`atomic`] përmes metodës `compare_exchange_weak` duke kaluar [`Ordering::SeqCst`] si parametrat `success` dhe `failure`.
    ///
    /// Për shembull, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojet [`atomic`] përmes metodës `compare_exchange_weak` duke kaluar [`Ordering::Acquire`] si parametrat `success` dhe `failure`.
    ///
    /// Për shembull, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është në dispozicion në llojet [`atomic`] përmes metodës `compare_exchange_weak` duke kaluar [`Ordering::Release`] si `success` dhe [`Ordering::Relaxed`] si parametrat `failure`.
    /// Për shembull, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është në dispozicion në llojet [`atomic`] përmes metodës `compare_exchange_weak` duke kaluar [`Ordering::AcqRel`] si `success` dhe [`Ordering::Acquire`] si parametrat `failure`.
    /// Për shembull, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojet [`atomic`] përmes metodës `compare_exchange_weak` duke kaluar [`Ordering::Relaxed`] si parametrat `success` dhe `failure`.
    ///
    /// Për shembull, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është në dispozicion në llojet [`atomic`] përmes metodës `compare_exchange_weak` duke kaluar [`Ordering::SeqCst`] si `success` dhe [`Ordering::Relaxed`] si parametrat `failure`.
    /// Për shembull, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është në dispozicion në llojet [`atomic`] përmes metodës `compare_exchange_weak` duke kaluar [`Ordering::SeqCst`] si `success` dhe [`Ordering::Acquire`] si parametrat `failure`.
    /// Për shembull, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është në dispozicion në llojet [`atomic`] përmes metodës `compare_exchange_weak` duke kaluar [`Ordering::Acquire`] si `success` dhe [`Ordering::Relaxed`] si parametrat `failure`.
    /// Për shembull, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Ruan një vlerë nëse vlera aktuale është e njëjtë me vlerën `old`.
    ///
    /// Versioni i stabilizuar i këtij brendësia është në dispozicion në llojet [`atomic`] përmes metodës `compare_exchange_weak` duke kaluar [`Ordering::AcqRel`] si `success` dhe [`Ordering::Relaxed`] si parametrat `failure`.
    /// Për shembull, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Ngarkon vlerën aktuale të treguesit.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `load` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Ngarkon vlerën aktuale të treguesit.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `load` duke kaluar [`Ordering::Acquire`] si `order`.
    /// Për shembull, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Ngarkon vlerën aktuale të treguesit.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `load` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Ruan vlerën në vendin e caktuar të kujtesës.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `store` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Ruan vlerën në vendin e caktuar të kujtesës.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `store` duke kaluar [`Ordering::Release`] si `order`.
    /// Për shembull, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Ruan vlerën në vendin e caktuar të kujtesës.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `store` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Ruan vlerën në vendin e caktuar të kujtesës, duke kthyer vlerën e vjetër.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `swap` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ruan vlerën në vendin e caktuar të kujtesës, duke kthyer vlerën e vjetër.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `swap` duke kaluar [`Ordering::Acquire`] si `order`.
    /// Për shembull, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ruan vlerën në vendin e caktuar të kujtesës, duke kthyer vlerën e vjetër.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojet [`atomic`] përmes metodës `swap` duke kaluar [`Ordering::Release`] si `order`.
    /// Për shembull, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ruan vlerën në vendin e caktuar të kujtesës, duke kthyer vlerën e vjetër.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `swap` duke kaluar [`Ordering::AcqRel`] si `order`.
    /// Për shembull, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Ruan vlerën në vendin e caktuar të kujtesës, duke kthyer vlerën e vjetër.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `swap` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Shton vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_add` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Shton vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_add` duke kaluar [`Ordering::Acquire`] si `order`.
    /// Për shembull, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Shton vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_add` duke kaluar [`Ordering::Release`] si `order`.
    /// Për shembull, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Shton vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_add` duke kaluar [`Ordering::AcqRel`] si `order`.
    /// Për shembull, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Shton vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_add` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Zbrit nga vlera aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_sub` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zbrit nga vlera aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_sub` duke kaluar [`Ordering::Acquire`] si `order`.
    /// Për shembull, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zbrit nga vlera aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_sub` duke kaluar [`Ordering::Release`] si `order`.
    /// Për shembull, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zbrit nga vlera aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_sub` duke kaluar [`Ordering::AcqRel`] si `order`.
    /// Për shembull, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zbrit nga vlera aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_sub` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise dhe me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_and` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise dhe me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_and` duke kaluar [`Ordering::Acquire`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise dhe me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_and` duke kaluar [`Ordering::Release`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise dhe me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_and` duke kaluar [`Ordering::AcqRel`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise dhe me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_and` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise dhe me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojin [`AtomicBool`] përmes metodës `fetch_nand` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise dhe me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojin [`AtomicBool`] përmes metodës `fetch_nand` duke kaluar [`Ordering::Acquire`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise dhe me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojin [`AtomicBool`] përmes metodës `fetch_nand` duke kaluar [`Ordering::Release`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise dhe me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është i disponueshëm në llojin [`AtomicBool`] përmes metodës `fetch_nand` duke kaluar [`Ordering::AcqRel`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise dhe me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësia është i disponueshëm në llojin [`AtomicBool`] përmes metodës `fetch_nand` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise ose me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_or` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ose me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_or` duke kaluar [`Ordering::Acquire`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ose me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_or` duke kaluar [`Ordering::Release`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ose me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_or` duke kaluar [`Ordering::AcqRel`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ose me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_or` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_xor` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_xor` duke kaluar [`Ordering::Acquire`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_xor` duke kaluar [`Ordering::Release`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_xor` duke kaluar [`Ordering::AcqRel`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor me vlerën aktuale, duke kthyer vlerën e mëparshme.
    ///
    /// Versioni i stabilizuar i këtij brendësi është i disponueshëm në llojet [`atomic`] përmes metodës `fetch_xor` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të nënshkruara përmes metodës `fetch_max` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të nënshkruara përmes metodës `fetch_max` duke kaluar [`Ordering::Acquire`] si `order`.
    /// Për shembull, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të nënshkruara përmes metodës `fetch_max` duke kaluar [`Ordering::Release`] si `order`.
    /// Për shembull, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të nënshkruara përmes metodës `fetch_max` duke kaluar [`Ordering::AcqRel`] si `order`.
    /// Për shembull, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumi me vlerën aktuale.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të nënshkruara përmes metodës `fetch_max` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të nënshkruara përmes metodës `fetch_min` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të nënshkruara përmes metodës `fetch_min` duke kaluar [`Ordering::Acquire`] si `order`.
    /// Për shembull, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të nënshkruara përmes metodës `fetch_min` duke kaluar [`Ordering::Release`] si `order`.
    /// Për shembull, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të nënshkruara përmes metodës `fetch_min` duke kaluar [`Ordering::AcqRel`] si `order`.
    /// Për shembull, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të nënshkruara përmes metodës `fetch_min` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të pa nënshkruara përmes metodës `fetch_min` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të pa nënshkruara përmes metodës `fetch_min` duke kaluar [`Ordering::Acquire`] si `order`.
    /// Për shembull, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të pa nënshkruara përmes metodës `fetch_min` duke kaluar [`Ordering::Release`] si `order`.
    /// Për shembull, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të pa nënshkruara përmes metodës `fetch_min` duke kaluar [`Ordering::AcqRel`] si `order`.
    /// Për shembull, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të pa nënshkruara përmes metodës `fetch_min` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të pa nënshkruara përmes metodës `fetch_max` duke kaluar [`Ordering::SeqCst`] si `order`.
    /// Për shembull, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të pa nënshkruara përmes metodës `fetch_max` duke kaluar [`Ordering::Acquire`] si `order`.
    /// Për shembull, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të pa nënshkruara përmes metodës `fetch_max` duke kaluar [`Ordering::Release`] si `order`.
    /// Për shembull, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të pa nënshkruara përmes metodës `fetch_max` duke kaluar [`Ordering::AcqRel`] si `order`.
    /// Për shembull, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimumi me vlerën aktuale duke përdorur një krahasim të nënshkruar.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është i disponueshëm në llojet e plota [`atomic`] të pa nënshkruara përmes metodës `fetch_max` duke kaluar [`Ordering::Relaxed`] si `order`.
    /// Për shembull, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// E brendshme `prefetch` është një aluzion për gjeneratorin e kodit për të futur një udhëzim paraprak nëse është i mbështetur;përndryshe, është një no-op.
    /// Prefetches nuk kanë asnjë efekt në sjelljen e programit, por mund të ndryshojnë karakteristikat e tij të performancës.
    ///
    /// Argumenti `locality` duhet të jetë një numër i plotë konstant dhe është një specifikues i lokalitetit të përkohshëm që varion nga (0), pa lokalitet, në (3), jashtëzakonisht lokal i mbajtur në cache.
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// E brendshme `prefetch` është një aluzion për gjeneratorin e kodit për të futur një udhëzim paraprak nëse është i mbështetur;përndryshe, është një no-op.
    /// Prefetches nuk kanë asnjë efekt në sjelljen e programit, por mund të ndryshojnë karakteristikat e tij të performancës.
    ///
    /// Argumenti `locality` duhet të jetë një numër i plotë konstant dhe është një specifikues i lokalitetit të përkohshëm që varion nga (0), pa lokalitet, në (3), jashtëzakonisht lokal i mbajtur në cache.
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// E brendshme `prefetch` është një aluzion për gjeneratorin e kodit për të futur një udhëzim paraprak nëse është i mbështetur;përndryshe, është një no-op.
    /// Prefetches nuk kanë asnjë efekt në sjelljen e programit, por mund të ndryshojnë karakteristikat e tij të performancës.
    ///
    /// Argumenti `locality` duhet të jetë një numër i plotë konstant dhe është një specifikues i lokalitetit të përkohshëm që varion nga (0), pa lokalitet, në (3), jashtëzakonisht lokal i mbajtur në cache.
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// E brendshme `prefetch` është një aluzion për gjeneratorin e kodit për të futur një udhëzim paraprak nëse është i mbështetur;përndryshe, është një no-op.
    /// Prefetches nuk kanë asnjë efekt në sjelljen e programit, por mund të ndryshojnë karakteristikat e tij të performancës.
    ///
    /// Argumenti `locality` duhet të jetë një numër i plotë konstant dhe është një specifikues i lokalitetit të përkohshëm që varion nga (0), pa lokalitet, në (3), jashtëzakonisht lokal i mbajtur në cache.
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Një gardh atomik.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është i disponueshëm në [`atomic::fence`] duke kaluar [`Ordering::SeqCst`] si `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Një gardh atomik.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është i disponueshëm në [`atomic::fence`] duke kaluar [`Ordering::Acquire`] si `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Një gardh atomik.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është i disponueshëm në [`atomic::fence`] duke kaluar [`Ordering::Release`] si `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Një gardh atomik.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është i disponueshëm në [`atomic::fence`] duke kaluar [`Ordering::AcqRel`] si `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Një pengesë memorie vetëm përpiluese.
    ///
    /// Hyrjet në kujtesë nuk do të rirenditen në të gjithë këtë pengesë nga përpiluesi, por asnjë udhëzim nuk do të lëshohet për të.
    /// Kjo është e përshtatshme për operacionet në të njëjtën fije që mund të paraprihen, të tilla si kur bashkëveproni me mbajtësit e sinjalit.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është i disponueshëm në [`atomic::compiler_fence`] duke kaluar [`Ordering::SeqCst`] si `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Një pengesë memorie vetëm përpiluese.
    ///
    /// Hyrjet në kujtesë nuk do të rirenditen në të gjithë këtë pengesë nga përpiluesi, por asnjë udhëzim nuk do të lëshohet për të.
    /// Kjo është e përshtatshme për operacionet në të njëjtën fije që mund të paraprihen, të tilla si kur bashkëveproni me mbajtësit e sinjalit.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është i disponueshëm në [`atomic::compiler_fence`] duke kaluar [`Ordering::Acquire`] si `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Një pengesë memorie vetëm përpiluese.
    ///
    /// Hyrjet në kujtesë nuk do të rirenditen në të gjithë këtë pengesë nga përpiluesi, por asnjë udhëzim nuk do të lëshohet për të.
    /// Kjo është e përshtatshme për operacionet në të njëjtën fije që mund të paraprihen, të tilla si kur bashkëveproni me mbajtësit e sinjalit.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është i disponueshëm në [`atomic::compiler_fence`] duke kaluar [`Ordering::Release`] si `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Një pengesë memorie vetëm përpiluese.
    ///
    /// Hyrjet në kujtesë nuk do të rirenditen në të gjithë këtë pengesë nga përpiluesi, por asnjë udhëzim nuk do të lëshohet për të.
    /// Kjo është e përshtatshme për operacionet në të njëjtën fije që mund të paraprihen, të tilla si kur bashkëveproni me mbajtësit e sinjalit.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është i disponueshëm në [`atomic::compiler_fence`] duke kaluar [`Ordering::AcqRel`] si `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magjike e brendshme që kuptimin e saj e merr nga atributet e bashkangjitura në funksion.
    ///
    /// Për shembull, rrjedha e të dhënave e përdor këtë për të injektuar pohime statike në mënyrë që `rustc_peek(potentially_uninitialized)` në të vërtetë të kontrollojë dy herë nëse rrjedha e të dhënave ka llogaritur vërtet se është e pa iniciale në atë pikë në rrjedhën e kontrollit.
    ///
    ///
    /// Kjo e brendshme nuk duhet të përdoret jashtë përpiluesit.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Aborton ekzekutimin e procesit.
    ///
    /// Një version më miqësor dhe i qëndrueshëm i përdorimit i këtij operacioni është [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informon optimizuesin se kjo pikë në kod nuk është e arritshme, duke mundësuar optimizime të mëtejshme.
    ///
    /// NB, kjo është shumë ndryshe nga makroja `unreachable!()`: Ndryshe nga makroja, e cila panics kur ekzekutohet, është *sjellje e papërcaktuar* për të arritur kodin e shënuar me këtë funksion.
    ///
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informon optimizuesin se një gjendje është gjithmonë e vërtetë.
    /// Nëse kushti është i rremë, sjellja është e papërcaktuar.
    ///
    /// Asnjë kod nuk gjenerohet për këtë element të brendshëm, por optimizuesi do të përpiqet ta ruajë atë (dhe gjendjen e tij) midis kalimeve, të cilat mund të ndërhyjnë në optimizimin e kodit përreth dhe të zvogëlojnë performancën.
    /// Nuk duhet të përdoret nëse invariati mund të zbulohet nga optimizatori më vete, ose nëse nuk mundëson ndonjë optimizim të rëndësishëm.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Lë të kuptohet për përpiluesin se gjendja branch ka të ngjarë të jetë e vërtetë.
    /// Kthen vlerën e kaluar në të.
    ///
    /// Çdo përdorim tjetër përveç deklaratave `if` ndoshta nuk do të ketë efekt.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Lë të kuptohet për përpiluesit se gjendja branch ka të ngjarë të jetë e gabuar.
    /// Kthen vlerën e kaluar në të.
    ///
    /// Çdo përdorim tjetër përveç deklaratave `if` ndoshta nuk do të ketë efekt.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Ekzekuton një kurth pikë-pikë, për inspektim nga një korrigjues.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn breakpoint();

    /// Madhësia e një lloji në bajte.
    ///
    /// Më konkretisht, ky është kompensimi në bajte midis artikujve të njëpasnjëshëm të të njëjtit lloj, duke përfshirë mbushjen e shtrirjes.
    ///
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Shtrirja minimale e një lloji.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Rreshtimi i preferuar i një lloji.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Madhësia e vlerës së referuar në bajte.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Rreshtimi i kërkuar i vlerës së referuar.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Merr një fetë vargu statike që përmban emrin e një lloji.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Merr një identifikues i cili është globalisht unik për llojin e specifikuar.
    /// Ky funksion do të kthejë të njëjtën vlerë për një lloj, pavarësisht se në cilin crate thirret.
    ///
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Një roje për funksione të pasigurta që nuk mund të ekzekutohet kurrë nëse `T` është i pabanuar:
    /// Kjo do të bëjë ose panic, ose nuk do të bëjë asgjë.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Një roje për funksione të pasigurta që nuk mund të ekzekutohet kurrë nëse `T` nuk lejon inicializimin zero: Kjo do të bëjë ose panic, ose nuk do të bëjë asgjë.
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn assert_zero_valid<T>();

    /// Një roje për funksione të pasigurta që nuk mund të ekzekutohet kurrë nëse `T` ka modele bit të pavlefshme: Kjo do të bëjë ose panic, ose nuk do të bëjë asgjë.
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn assert_uninit_valid<T>();

    /// Merr një referencë për një `Location` statike duke treguar se ku është thirrur.
    ///
    /// Konsideroni përdorimin e [`core::panic::Location::caller`](crate::panic::Location::caller) në vend të kësaj.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Lëviz një vlerë jashtë fushës së veprimit pa lëshuar ngjitësin e pikave.
    ///
    /// Kjo ekziston vetëm për [`mem::forget_unsized`];normal `forget` përdor `ManuallyDrop` në vend.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Riinterpreton bitët e një vlere të një lloji si një lloj tjetër.
    ///
    /// Të dy llojet duhet të kenë të njëjtën madhësi.
    /// As origjinali, as rezultati, nuk mund të jenë një [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` është semantikisht e barabartë me një lëvizje bitwise të një lloji në një tjetër.Kopjon bitët nga vlera e burimit në vlerën e destinacionit, pastaj harron origjinalin.
    /// Equivalentshtë ekuivalente me C's `memcpy` nën kapuç, ashtu si `transmute_copy`.
    ///
    /// Për shkak se `transmute` është një veprim me vlerë, përafrimi i vetë vlerave * të shndërruara nuk është shqetësues.
    /// Si me çdo funksion tjetër, përpiluesi tashmë siguron që të dy `T` dhe `U` janë të rreshtuar siç duhet.
    /// Sidoqoftë, gjatë transferimit të vlerave që * drejtohen diku tjetër (të tilla si treguesit, referencat, kutitë ...), thirrësi duhet të sigurojë përafrimin e duhur të vlerave të drejtuara.
    ///
    /// `transmute` është **tepër** i pasigurt.Ekziston një numër i madh mënyrash për të shkaktuar [undefined behavior][ub] me këtë funksion.`transmute` duhet të jetë alternativa e fundit absolute.
    ///
    /// [nomicon](../../nomicon/transmutes.html) ka dokumentacion shtesë.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Ka disa gjëra për të cilat `transmute` është vërtet e dobishme.
    ///
    /// Kthimi i një treguesi në një tregues funksioni.Kjo *nuk është* e lëvizshme për makineritë ku treguesit e funksioneve dhe treguesit e të dhënave kanë madhësi të ndryshme.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Zgjatja e një jete, ose shkurtimi i një jete të pandryshueshme.Ky është i përparuar, shumë i pasigurt Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Mos e humbni shpresën: shumë përdorime të `transmute` mund të arrihen me mjete të tjera.
    /// Më poshtë janë aplikacionet e zakonshme të `transmute` të cilat mund të zëvendësohen me konstrukte më të sigurta.
    ///
    /// Kthimi i bytes(`&[u8]`) i papërpunuar në `u32`, `f64`, etj .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // përdorni `u32::from_ne_bytes` në vend
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ose përdorni `u32::from_le_bytes` ose `u32::from_be_bytes` për të përcaktuar fundin
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Shndërrimi i një treguesi në `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Në vend të kësaj përdorni një cast `as`
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Kthimi i një `*mut T` në një `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Në vend të kësaj përdorni një reborrow
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Shndërrimi i një `&mut T` në një `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Tani, bashkoni `as` dhe rishfaqjen, vini re se zinxhiri i `as` `as` nuk është kalimtar
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Shndërrimi i një `&str` në një `&[u8]`:
    ///
    /// ```
    /// // kjo nuk është një mënyrë e mirë për ta bërë këtë.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ju mund të përdorni `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ose, thjesht përdorni një varg bajtesh, nëse keni kontroll mbi vargun fjalë për fjalë
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Kthimi i një `Vec<&T>` në një `Vec<Option<&T>>`.
    ///
    /// Për të shndërruar llojin e brendshëm të përmbajtjes së një kontejner, duhet të siguroheni që të mos shkelni asnjë nga gjërat e pandryshueshme të kontejnerit.
    /// Për `Vec`, kjo do të thotë që madhësia *dhe shtrirja* e llojeve të brendshëm duhet të përputhen.
    /// Kontejnerët e tjerë mund të mbështeten në madhësinë e llojit, shtrirjes, apo edhe `TypeId`, në këtë rast transmutimi nuk do të ishte aspak i mundur pa shkelur gjërat e pandryshueshme të kontejnerëve.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klononi vector pasi do t'i ripërdorim më vonë
    /// let v_clone = v_orig.clone();
    ///
    /// // Përdorimi i transmutit: kjo mbështetet në paraqitjen e paspecifikuar të të dhënave `Vec`, e cila është një ide e keqe dhe mund të shkaktojë një sjellje të papërcaktuar.
    /////
    /// // Megjithatë, nuk është e kopjuar.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Kjo është mënyra e sugjeruar, e sigurt.
    /// // Megjithatë, kopjon të gjithë vector, në një grup të ri.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Kjo është mënyra e duhur pa kopje, e pasigurt e "transmuting" a `Vec`, pa u mbështetur në paraqitjen e të dhënave.
    /// // Në vend që të thërrasim fjalë për fjalë `transmute`, ne kryejmë një cast tregues, por përsa i përket konvertimit të llojit origjinal (`&i32`) në atë të ri (`Option<&i32>`), kjo ka të njëjtat paralajmërime.
    /////
    /// // Përveç informacionit të dhënë më sipër, këshillohuni edhe me dokumentacionin [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Përditësoni këtë kur stabilizohet vec_into_raw_part.
    ///     // Sigurohuni që vector origjinal të mos bjerë.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Zbatimi i `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Ka shumë mënyra për ta bërë këtë dhe ka shumë probleme me mënyrën e mëposhtme (transmute).
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // së pari: transmute nuk është i sigurt nga lloji;gjithçka që kontrollon është se T dhe
    ///         // U janë të së njëjtës madhësi.
    ///         // Së dyti, pikërisht këtu, ju keni dy referenca të ndryshueshme që tregojnë të njëjtën kujtesë.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Kjo heq qafe problemet e sigurisë së tipit;`&mut *`* vetëm *do t'ju japë një `&mut T` nga një `&mut T` ose `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // megjithatë, ju ende keni dy referenca të ndryshueshme që tregojnë të njëjtën kujtesë.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Kështu e bën biblioteka standarde.
    /// // Kjo është metoda më e mirë, nëse keni nevojë të bëni diçka të tillë
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Kjo tani ka tre referenca të ndryshueshme që tregojnë në të njëjtën memorie.`slice`, vlera x02X dhe vlera ret.1.
    ///         // `slice` nuk përdoret kurrë pas `let ptr = ...`, dhe kështu dikush mund ta trajtojë atë si "dead", dhe për këtë arsye, ju keni vetëm dy feta të vërteta të ndryshueshme.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Ndërsa kjo e bën përbërjen e brendshme të qëndrueshme, ne kemi disa kod të personalizuar në konst. Fn
    // kontrolle që parandalojnë përdorimin e tij brenda `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Kthen `true` nëse lloji aktual i dhënë si `T` kërkon ngjitës;kthen `false` nëse lloji aktual i dhënë për `T` zbaton `Copy`.
    ///
    ///
    /// Nëse lloji aktual as nuk kërkon ngjitës ose nuk zbaton `Copy`, atëherë vlera e kthimit e këtij funksioni është e paspecifikuar.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Llogarit kompensimin nga një tregues.
    ///
    /// Kjo është zbatuar si e brendshme për të shmangur konvertimin në dhe nga një numër i plotë, pasi që konvertimi do të hidhte larg informacionin aliasing.
    ///
    /// # Safety
    ///
    /// Treguesi fillestar dhe rezultues duhet të jenë ose në kufij ose një bajt pas fundit të një objekti të caktuar.
    /// Nëse ndonjëri tregues është jashtë kufijve ose ndodh tejkalimi aritmetik, atëherë çdo përdorim i mëtejshëm i vlerës së kthyer do të rezultojë në sjellje të papërcaktuar.
    ///
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Llogarit kompensimin nga një tregues, potencialisht mbështjellës.
    ///
    /// Kjo është zbatuar si një e brendshme për të shmangur konvertimin në dhe nga një numër i plotë, pasi që konvertimi pengon optimizime të caktuara.
    ///
    /// # Safety
    ///
    /// Ndryshe nga `offset` e brendshme, kjo e brendshme nuk e kufizon treguesin që rezulton të tregojë në ose një bajt pas fundit të një objekti të caktuar, dhe ai mbështjell me aritmetikën plotësuese të dyve.
    /// Vlera që rezulton nuk është domosdoshmërisht e vlefshme për t'u përdorur për të hyrë në të vërtetë në memorje.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ekuivalente me `llvm.memcpy.p0i8.0i8.*` e duhur të brendshme, me një madhësi prej `count`*`size_of::<T>()` dhe një rreshtim të
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parametri i paqëndrueshëm është vendosur në `true`, kështu që nuk do të optimizohet nëse madhësia nuk është e barabartë me zero.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekuivalente me `llvm.memmove.p0i8.0i8.*` e duhur të brendshme, me një madhësi prej `count* size_of::<T>()` dhe një shtrirje të
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parametri i paqëndrueshëm është vendosur në `true`, kështu që nuk do të optimizohet nëse madhësia nuk është e barabartë me zero.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekuivalente me `llvm.memset.p0i8.*` përkatëse e brendshme, me një madhësi të `count* size_of::<T>()` dhe një shtrirje të `min_align_of::<T>()`.
    ///
    ///
    /// Parametri i paqëndrueshëm është vendosur në `true`, kështu që nuk do të optimizohet nëse madhësia nuk është e barabartë me zero.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Kryen një ngarkesë të paqëndrueshme nga treguesi `src`.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Kryen një depo të paqëndrueshme në treguesin `dst`.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Kryen një ngarkesë të paqëndrueshme nga treguesi `src` Treguesi nuk kërkohet të rreshtohet.
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Kryen një depo të paqëndrueshme në treguesin `dst`.
    /// Treguesi nuk kërkohet të rreshtohet.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Kthen rrënjën katrore të një `f32`
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Kthen rrënjën katrore të një `f64`
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Ngre një `f32` në një fuqi të plotë.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Ngre një `f64` në një fuqi të plotë.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Kthen sinusin e një `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Kthen sinusin e një `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Kthen kosinusin e një `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Kthen kosinusin e një `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Ngre një `f32` në një fuqi `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Ngre një `f64` në një fuqi `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Kthen eksponencialin e një `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Kthen eksponencialin e një `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Kthen 2 të ngritur në fuqinë e një `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Kthen 2 të ngritur në fuqinë e një `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Kthen logaritmin natyror të një `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Kthen logaritmin natyror të një `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Kthen logaritmin bazë 10 të një `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Kthen logaritmin bazë 10 të një `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Kthen logaritmin bazë 2 të një `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Kthen logaritmin bazë 2 të një `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Kthen `a * b + c` për vlerat `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Kthen `a * b + c` për vlerat `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Kthen vlerën absolute të një `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Kthen vlerën absolute të një `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Kthen minimumin e dy vlerave `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Kthen minimumin e dy vlerave `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Kthen maksimumin e dy vlerave `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Kthen maksimumin e dy vlerave `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopjon shenjën nga `y` në `x` për vlerat `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopjon shenjën nga `y` në `x` për vlerat `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Kthen numrin e plotë më të madh më të vogël ose të barabartë me një `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Kthen numrin e plotë më të madh më të vogël ose të barabartë me një `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Kthen numrin më të vogël më të madh se ose të barabartë me një `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Kthen numrin më të vogël më të madh se ose të barabartë me një `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Kthen pjesën e plotë të një `f32`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Kthen pjesën e plotë të një `f64`.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Kthen numrin e plotë më të afërt në një `f32`.
    /// Mund të ngrejë një përjashtim të pasaktë të pikës lundruese nëse argumenti nuk është një numër i plotë.
    pub fn rintf32(x: f32) -> f32;
    /// Kthen numrin e plotë më të afërt në një `f64`.
    /// Mund të ngrejë një përjashtim të pasaktë të pikës lundruese nëse argumenti nuk është një numër i plotë.
    pub fn rintf64(x: f64) -> f64;

    /// Kthen numrin e plotë më të afërt në një `f32`.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Kthen numrin e plotë më të afërt në një `f64`.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Kthen numrin e plotë më të afërt në një `f32`.Raundet e rasteve në gjysmë të rrugës larg nga zero.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Kthen numrin e plotë më të afërt në një `f64`.Raundet e rasteve në gjysmë të rrugës larg nga zero.
    ///
    /// Versioni i stabilizuar i kësaj të brendshme është
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Shtesë pluskimi që lejon optimizime të bazuara në rregulla algjebrike.
    /// Mund të supozojmë se inputet janë të fundme.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Zbritja e notave që lejon optimizime të bazuara në rregulla algjebrike.
    /// Mund të supozojmë se inputet janë të fundme.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Shumëzimi i notave që lejon optimizime të bazuara në rregulla algjebrike.
    /// Mund të supozojmë se inputet janë të fundme.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Ndarja e notave që lejon optimizime të bazuara në rregulla algjebrike.
    /// Mund të supozojmë se inputet janë të fundme.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Pjesa tjetër e notave që lejon optimizime të bazuara në rregulla algjebrike.
    /// Mund të supozojmë se inputet janë të fundme.
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konvertoni me fptoui/fptosi të LLVM, i cili mund të kthehet i padepërtueshëm për vlera jashtë rrezes
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilizuar si [`f32::to_int_unchecked`] dhe [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Kthen numrin e bitëve të vendosur në një numër të plotë `T`
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `count_ones`.
    /// Për shembull,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Kthen numrin e bitëve kryesorë të pavendosur (zeroes) në një numër të plotë `T`.
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `leading_zeros`.
    /// Për shembull,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// Një `x` me vlerë `0` do të kthejë gjerësinë e bitit të `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Ashtu si `ctlz`, por tepër i pasigurt pasi kthen `undef` kur i jepet një `x` me vlerë `0`.
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Kthen numrin e bitëve të pavendosura (zeroes) në një numër të plotë `T`.
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `trailing_zeros`.
    /// Për shembull,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// Një `x` me vlerë `0` do të kthejë gjerësinë e bitit të `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Ashtu si `cttz`, por tepër i pasigurt pasi kthen `undef` kur i jepet një `x` me vlerë `0`.
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Kthen bajtët në një numër të plotë `T`.
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `swap_bytes`.
    /// Për shembull,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Ndryshon bitët në një numër të plotë `T`.
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `reverse_bits`.
    /// Për shembull,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Kryen mbledhjen e kontrolluar të plotë.
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `overflowing_add`.
    /// Për shembull,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Kryen zbritjen e kontrolluar të plotë
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `overflowing_sub`.
    /// Për shembull,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Kryen shumëzimin e kontrolluar të plotë
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `overflowing_mul`.
    /// Për shembull,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Kryen një ndarje të saktë, duke rezultuar në një sjellje të papërcaktuar kur `x % y != 0` ose `y == 0` ose `x == T::MIN && y == -1`
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Kryen një ndarje të pakontrolluar, duke rezultuar në një sjellje të papërcaktuar kur `y == 0` ose `x == T::MIN && y == -1`
    ///
    ///
    /// Mbështjellësit e sigurt për këtë element të brendshëm janë në dispozicion në primitivët e plotë me anë të metodës `checked_div`.
    /// Për shembull,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Kthen pjesën e mbetur të një ndarjeje të pakontrolluar, duke rezultuar në sjellje të papërcaktuar kur `y == 0` ose `x == T::MIN && y == -1`
    ///
    ///
    /// Mbështjellësit e sigurt për këtë element të brendshëm janë në dispozicion në primitivët e plotë me anë të metodës `checked_rem`.
    /// Për shembull,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Kryen një ndërrim të majtë të pakontrolluar, duke rezultuar në sjellje të papërcaktuar kur `y < 0` ose `y >= N`, ku N është gjerësia e T në bit.
    ///
    ///
    /// Mbështjellësit e sigurt për këtë element të brendshëm janë në dispozicion në primitivët e plotë me anë të metodës `checked_shl`.
    /// Për shembull,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Kryen një zhvendosje të djathtë të pakontrolluar, duke rezultuar në sjellje të papërcaktuar kur `y < 0` ose `y >= N`, ku N është gjerësia e T në bit.
    ///
    ///
    /// Mbështjellësit e sigurt për këtë element të brendshëm janë në dispozicion në primitivët e plotë me anë të metodës `checked_shr`.
    /// Për shembull,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Kthen rezultatin e një shtese të pakontrolluar, duke rezultuar në sjellje të papërcaktuar kur `x + y > T::MAX` ose `x + y < T::MIN`.
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Kthen rezultatin e një zbritjeje të pakontrolluar, duke rezultuar në sjellje të papërcaktuar kur `x - y > T::MAX` ose `x - y < T::MIN`.
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Kthen rezultatin e një shumëzimi të pakontrolluar, duke rezultuar në sjellje të papërcaktuar kur `x *y > T::MAX` ose `x* y < T::MIN`.
    ///
    ///
    /// Ky i brendshëm nuk ka një homolog të qëndrueshëm.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Kryen rrotullohen majtas.
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `rotate_left`.
    /// Për shembull,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Kryen rotacionin djathtas.
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `rotate_right`.
    /// Për shembull,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Kthen (a + b) mod 2 <sup>N</sup>, ku N është gjerësia e T në bit.
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `wrapping_add`.
    /// Për shembull,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Kthen (a, b) mod 2 <sup>N</sup>, ku N është gjerësia e T në bit.
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `wrapping_sub`.
    /// Për shembull,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Kthen (a * b) mod 2 <sup>N</sup>, ku N është gjerësia e T në bit.
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `wrapping_mul`.
    /// Për shembull,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Llogarit `a + b`, duke ngopur në kufijtë numerikë.
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `saturating_add`.
    /// Për shembull,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Llogarit `a - b`, duke ngopur në kufijtë numerikë.
    ///
    /// Versionet e stabilizuara të kësaj natyre janë të disponueshme në primitivët e plotë me metodën `saturating_sub`.
    /// Për shembull,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Kthen vlerën e diskriminuesit për variantin në 'v';
    /// nëse `T` nuk ka asnjë diskriminues, kthen `0`.
    ///
    /// Versioni i stabilizuar i kësaj brendësie është [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Kthen numrin e varianteve të tipit `T` të hedhur në një `usize`;
    /// nëse `T` nuk ka variante, kthen `0`.Variantet e pabanuara do të numërohen.
    ///
    /// Versioni që duhet të stabilizohet i këtij i brendshmi është [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Ndërtimi "try catch" i Rust i cili thërret treguesin e funksionit `try_fn` me treguesin e të dhënave `data`.
    ///
    /// Argumenti i tretë është një funksion i quajtur nëse ndodh një panic.
    /// Ky funksion e çon treguesin e të dhënave dhe një tregues te objekti i përjashtimit specifik të synuar që u kap.
    ///
    /// Për më shumë informacion shikoni burimin e përpiluesit, si dhe implementimin e kapur të std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Lëshon një dyqan `!nontemporal` sipas LLVM (shih dokumentet e tyre).
    /// Ndoshta nuk do të bëhet kurrë e qëndrueshme.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Shihni dokumentacionin e `<*const T>::offset_from` për detaje.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Shihni dokumentacionin e `<*const T>::guaranteed_eq` për detaje.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Shihni dokumentacionin e `<*const T>::guaranteed_ne` për detaje.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Alokoni në kohën e përpilimit.Nuk duhet të thirret në kohën e ekzekutimit.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Disa funksione janë përcaktuar këtu sepse ato aksidentalisht janë bërë të disponueshme në këtë modul mbi stallën.
// Shihni <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` gjithashtu hyn në këtë kategori, por nuk mund të mbështillet për shkak të kontrollit që `T` dhe `U` kanë të njëjtën madhësi.)
//

/// Kontrollon nëse `ptr` është rreshtuar si duhet në lidhje me `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopjon bajthat `count *size_of::<T>()` nga `src` në `dst`.Burimi dhe destinacioni nuk duhet* të mbivendosen.
///
/// Për rajonet e kujtesës të cilat mund të mbivendosen, përdorni [`copy`] në vend.
///
/// `copy_nonoverlapping` semantikisht është ekuivalente me C's [`memcpy`], por me rendin e argumentit të ndërruar.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `src` duhet të jetë [valid] për leximin e bajtave `count * size_of::<T>()`.
///
/// * `dst` duhet të jetë [valid] për shkrime të bajtëve `count * size_of::<T>()`.
///
/// * Si `src` ashtu edhe `dst` duhet të rreshtohen siç duhet.
///
/// * Rajoni i kujtesës që fillon në `src` me një madhësi të `numërimit *
///   madhësia_e: :<T>() `bajtët *nuk duhet* të mbivendosen me rajonin e kujtesës që fillon nga `dst` me të njëjtën madhësi.
///
/// Ashtu si [`read`], `copy_nonoverlapping` krijon një kopje bitwise të `T`, pavarësisht nëse `T` është [`Copy`].
/// Nëse `T` nuk është [`Copy`], duke përdorur *të dy* vlerat në rajon duke filluar nga `*src` dhe rajonin që fillon në `* dst` mund [violate memory safety][read-ownership].
///
///
/// Vini re se edhe nëse madhësia e kopjuar në mënyrë efektive (`numëroni * madhësinë e:::<T>()") është `0`, treguesit duhet të jenë jo-NULL dhe të rreshtuar siç duhet.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Zbatoni manualisht [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Lëviz të gjithë elementët e `src` në `dst`, duke e lënë `src` bosh.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Sigurohuni që `dst` ka kapacitet të mjaftueshëm për të mbajtur të gjithë `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Thirrja për të kompensuar është gjithmonë e sigurt sepse `Vec` nuk do të ndajë kurrë më shumë se `isize::MAX` bajte.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Shkurtoni `src` pa rënë në përmbajtje.
///         // Ne e bëjmë këtë së pari, për të shmangur problemet në rast se diçka më poshtë panics.
///         src.set_len(0);
///
///         // Të dy rajonet nuk mund të mbivendosen sepse referencat e ndryshueshme nuk janë pseudonime, dhe dy vektorë të ndryshëm nuk mund të zotërojnë të njëjtën kujtesë.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Njoftoni `dst` që tani mban përmbajtjen e `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Kryeni këto kontrolle vetëm në kohën e ekzekutimit
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Jo në panik për të mbajtur më të vogël ndikimin e kodegjenit.
        abort();
    }*/

    // SIGURIA: kontrata e sigurisë për `copy_nonoverlapping` duhet të jetë
    // mbështetur nga thirrësi.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopjon bajthat `count * size_of::<T>()` nga `src` në `dst`.Burimi dhe destinacioni mund të mbivendosen.
///
/// Nëse burimi dhe destinacioni nuk do të mbivendosen kurrë *, në vend të tij mund të përdoret [`copy_nonoverlapping`].
///
/// `copy` semantikisht është ekuivalente me C's [`memmove`], por me rendin e argumentit të ndërruar.
/// Kopjimi zhvillohet sikur bajtet të kopjoheshin nga `src` në një grup të përkohshëm dhe më pas të kopjoheshin nga vargu në `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `src` duhet të jetë [valid] për leximin e bajtave `count * size_of::<T>()`.
///
/// * `dst` duhet të jetë [valid] për shkrime të bajtëve `count * size_of::<T>()`.
///
/// * Si `src` ashtu edhe `dst` duhet të rreshtohen siç duhet.
///
/// Ashtu si [`read`], `copy` krijon një kopje bitwise të `T`, pavarësisht nëse `T` është [`Copy`].
/// Nëse `T` nuk është [`Copy`], duke përdorur të dy vlerat në rajon duke filluar nga `*src` dhe rajonin që fillon në `* dst` mund [violate memory safety][read-ownership].
///
///
/// Vini re se edhe nëse madhësia e kopjuar në mënyrë efektive (`numëroni * madhësinë e:::<T>()") është `0`, treguesit duhet të jenë jo-NULL dhe të rreshtuar siç duhet.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Krijoni në mënyrë efikase një Rust vector nga një tampon i pasigurt:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` duhet të rreshtohet saktë për llojin e tij dhe jo-zero.
/// /// * `ptr` duhet të jetë e vlefshme për leximin e elementeve të afërta `elts` të tipit `T`.
/// /// * Ata elementë nuk duhet të përdoren pas thirrjes së këtij funksioni përveç nëse `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SIGURIA: Parakushti ynë siguron që burimi të jetë në një linjë dhe të vlefshëm,
///     // dhe `Vec::with_capacity` siguron që të kemi hapësirë të dobishme për t'i shkruar ato.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SIGURIA: Ne e krijuam atë me këtë kapacitet shumë më herët,
///     // dhe `copy` e mëparshme i ka iniciuar këto elemente.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Kryeni këto kontrolle vetëm në kohën e ekzekutimit
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Jo në panik për të mbajtur më të vogël ndikimin e kodegjenit.
        abort();
    }*/

    // SIGURIA: kontrata e sigurisë për `copy` duhet të mbahet nga thirrësi.
    unsafe { copy(src, dst, count) }
}

/// Vendos `count * size_of::<T>()` bajte memorie duke filluar nga `dst` në `val`.
///
/// `write_bytes` është e ngjashme me C's [`memset`], por vendos `count * size_of::<T>()` bajte në `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `dst` duhet të jetë [valid] për shkrime të bajtëve `count * size_of::<T>()`.
///
/// * `dst` duhet të rreshtohet siç duhet.
///
/// Për më tepër, thirrësi duhet të sigurojë që shkrimi i bajtave `count * size_of::<T>()` në rajonin e caktuar të kujtesës rezulton në një vlerë të vlefshme prej `T`.
/// Përdorimi i një rajoni të kujtesës të shtypur si `T` që përmban një vlerë të pavlefshme të `T` është sjellje e papërcaktuar.
///
/// Vini re se edhe nëse madhësia e kopjuar në mënyrë efektive (`numëroni * madhësinë e:::<T>()") është `0`, treguesi duhet të jetë jo-NULL dhe i rreshtuar siç duhet.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Krijimi i një vlere të pavlefshme:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Rrjedh vlerën e mbajtur më parë duke mbishkruar `Box<T>` me një tregues nul.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Në këtë pikë, përdorimi ose rënia e `v` sjell sjellje të papërcaktuar.
/// // drop(v); // ERROR
///
/// // Edhe rrjedhja `v` "uses" e tij, dhe kështu është një sjellje e papërcaktuar.
/// // mem::forget(v); // ERROR
///
/// // Në fakt, `v` është i pavlefshëm sipas pandryshueshmërisë së paraqitjes së tipit bazë, kështu që *çdo* operacion që e prek atë është një sjellje e papërcaktuar.
/////
/// // le v2 =v;//GABIMI
///
/// unsafe {
///     // Le të vendosim një vlerë të vlefshme
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Tani kutia është në rregull
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SIGURIA: kontrata e sigurisë për `write_bytes` duhet të mbahet nga thirrësi.
    unsafe { write_bytes(dst, val, count) }
}