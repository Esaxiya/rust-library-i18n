Panics filli aktual.

Kjo lejon që një program të përfundojë menjëherë dhe të sigurojë reagime për thirrësin e programit.
`panic!` duhet të përdoret kur një program arrin një gjendje të pariparueshme.

Kjo makro është mënyra perfekte për të pohuar kushtet në shembullin e kodit dhe në teste.
`panic!` është i lidhur ngushtë me metodën `unwrap` të të dy enumeve [`Option`][ounwrap] dhe [`Result`][runwrap].
Të dy implementimet telefonojnë `panic!` kur vendosen në variante [`None`] ose [`Err`].

Kur përdorni `panic!()` mund të specifikoni një ngarkesë të vargut, e cila është ndërtuar duke përdorur sintaksën [`format!`].
Kjo ngarkesë përdoret kur injektohet panic në fijen thirrëse Rust, duke shkaktuar fijen në panic tërësisht.

Sjellja e `std` hook të parazgjedhur, dmth
kodi që ekzekutohet direkt pasi të thirret panic, është për të shtypur ngarkesën e mesazhit në `stderr` së bashku me informacionin file/line/column të thirrjes `panic!()`.

Ju mund të anuloni panic hook duke përdorur [`std::panic::set_hook()`].
Brenda hook një panic mund të arrihet si `&dyn Any + Send`, i cili përmban ose `&str` ose `String` për thirrje të rregullta `panic!()`.
Për panic me një vlerë të një lloji tjetër, mund të përdoret [`panic_any`].

[`Result`] enum shpesh është një zgjidhje më e mirë për rikuperimin e gabimeve sesa përdorimi i makros `panic!`.
Kjo makro duhet të përdoret për të shmangur procedimin duke përdorur vlera të pasakta, të tilla si nga burime të jashtme.
Informacione të hollësishme rreth trajtimit të gabimeve gjenden në [book].

Shihni gjithashtu makro [`compile_error!`], për ngritjen e gabimeve gjatë përpilimit.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Zbatimi aktual

Nëse filli kryesor panics do të përfundojë të gjitha fijet tuaja dhe do ta përfundojë programin tuaj me kodin `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





