#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Zgjerohet ose në `$crate::panic::panic_2015` ose `$crate::panic::panic_2021` në varësi të botimit të telefonuesit.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Pretendon se dy shprehje janë të barabarta me njëra-tjetrën (duke përdorur [`PartialEq`]).
///
/// Në panic, kjo makro do të shtypë vlerat e shprehjeve me paraqitjet e tyre të korrigjimit.
///
///
/// Ashtu si [`assert!`], kjo makro ka një formë të dytë, ku mund të sigurohet një mesazh panic me porosi.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Reborrows më poshtë janë të qëllimshme.
                    // Pa to, sloti i stackut për huazim inicializohet edhe para se të krahasohen vlerat, duke çuar në një ngadalësim të dukshëm.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Reborrows më poshtë janë të qëllimshme.
                    // Pa to, sloti i stackut për huazim inicializohet edhe para se të krahasohen vlerat, duke çuar në një ngadalësim të dukshëm.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Pretendon se dy shprehje nuk janë të barabarta me njëra-tjetrën (duke përdorur [`PartialEq`]).
///
/// Në panic, kjo makro do të shtypë vlerat e shprehjeve me paraqitjet e tyre të korrigjimit.
///
///
/// Ashtu si [`assert!`], kjo makro ka një formë të dytë, ku mund të sigurohet një mesazh panic me porosi.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Reborrows më poshtë janë të qëllimshme.
                    // Pa to, sloti i stackut për huazim inicializohet edhe para se të krahasohen vlerat, duke çuar në një ngadalësim të dukshëm.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Reborrows më poshtë janë të qëllimshme.
                    // Pa to, sloti i stackut për huazim inicializohet edhe para se të krahasohen vlerat, duke çuar në një ngadalësim të dukshëm.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Pohon që një shprehje boolean është `true` gjatë kohës së ekzekutimit.
///
/// Kjo do të thërrasë makron [`panic!`] nëse shprehja e dhënë nuk mund të vlerësohet në `true` gjatë kohës së ekzekutimit.
///
/// Ashtu si [`assert!`], kjo makro gjithashtu ka një version të dytë, ku mund të sigurohet një mesazh me porosi panic.
///
/// # Uses
///
/// Ndryshe nga [`assert!`], deklaratat `debug_assert!` aktivizohen vetëm në ndërtime jo të optimizuara si parazgjedhje.
/// Një ndërtim i optimizuar nuk do të ekzekutojë deklaratat `debug_assert!` nëse `-C debug-assertions` nuk i kalohet përpiluesit.
/// Kjo e bën `debug_assert!` të dobishëm për kontrolle që janë shumë të shtrenjta për të qenë të pranishme në një ndërtim të lëshimit, por mund të jenë të dobishëm gjatë zhvillimit.
/// Rezultati i zgjerimit të `debug_assert!` është gjithmonë i kontrolluar nga lloji.
///
/// Një pohim i pakontrolluar lejon që një program në një gjendje jo konsistente të vazhdojë të funksionojë, gjë që mund të ketë pasoja të papritura por nuk paraqet pasiguri për sa kohë që kjo ndodh vetëm në kodin e sigurt.
///
/// Kostoja e performancës së pohimeve, megjithatë, nuk është e matshme në përgjithësi.
/// Zëvendësimi i [`assert!`] me `debug_assert!` inkurajohet kështu vetëm pas profilizimit të plotë, dhe më e rëndësishmja, vetëm në kod të sigurt!
///
/// # Examples
///
/// ```
/// // mesazhi panic për këto pohime është vlera e vargëzuar e shprehjes së dhënë.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // një funksion shumë i thjeshtë
/// debug_assert!(some_expensive_computation());
///
/// // pohoni me një mesazh të personalizuar
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Pohon se dy shprehje janë të barabarta me njëra-tjetrën.
///
/// Në panic, kjo makro do të shtypë vlerat e shprehjeve me paraqitjet e tyre të korrigjimit.
///
/// Ndryshe nga [`assert_eq!`], deklaratat `debug_assert_eq!` aktivizohen vetëm në ndërtime jo të optimizuara si parazgjedhje.
/// Një ndërtim i optimizuar nuk do të ekzekutojë deklaratat `debug_assert_eq!` nëse `-C debug-assertions` nuk i kalohet përpiluesit.
/// Kjo e bën `debug_assert_eq!` të dobishëm për kontrolle që janë shumë të shtrenjta për të qenë të pranishme në një ndërtim të lëshimit, por mund të jenë të dobishëm gjatë zhvillimit.
///
/// Rezultati i zgjerimit të `debug_assert_eq!` është gjithmonë i kontrolluar nga lloji.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Pohon se dy shprehje nuk janë të barabarta me njëra-tjetrën.
///
/// Në panic, kjo makro do të shtypë vlerat e shprehjeve me paraqitjet e tyre të korrigjimit.
///
/// Ndryshe nga [`assert_ne!`], deklaratat `debug_assert_ne!` aktivizohen vetëm në ndërtime jo të optimizuara si parazgjedhje.
/// Një ndërtim i optimizuar nuk do të ekzekutojë deklaratat `debug_assert_ne!` nëse `-C debug-assertions` nuk i kalohet përpiluesit.
/// Kjo e bën `debug_assert_ne!` të dobishëm për kontrolle që janë shumë të shtrenjta për të qenë të pranishme në një ndërtim të lëshimit, por mund të jenë të dobishëm gjatë zhvillimit.
///
/// Rezultati i zgjerimit të `debug_assert_ne!` është gjithmonë i kontrolluar nga lloji.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Kthen nëse shprehja e dhënë përputhet me ndonjë nga modelet e dhëna.
///
/// Ashtu si në një shprehje `match`, modeli mund të ndiqet opsionalisht nga `if` dhe një shprehje mbrojtëse që ka qasje në emrat e lidhur nga modeli.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Zhbllokon një rezultat ose përhap gabimin e tij.
///
/// Operatori `?` u shtua për të zëvendësuar `try!` dhe duhet të përdoret në vend.
/// Për më tepër, `try` është një fjalë e rezervuar në Rust 2018, kështu që nëse duhet ta përdorni, do t'ju duhet të përdorni [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` përputhet me [`Result`] të dhënë.Në rastin e variantit `Ok`, shprehja ka vlerën e vlerës së mbështjellë.
///
/// Në rastin e variantit `Err`, ai rikthen gabimin e brendshëm.`try!` pastaj kryen shndërrim duke përdorur `From`.
/// Kjo siguron shndërrim automatik midis gabimeve të specializuara dhe atyre më të përgjithshme.
/// Gabimi që rezulton kthehet menjëherë.
///
/// Për shkak të kthimit të hershëm, `try!` mund të përdoret vetëm në funksionet që kthejnë [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Metoda e preferuar e kthimit të shpejtë të gabimeve
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Metoda e mëparshme e kthimit të shpejtë të gabimeve
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Kjo është ekuivalente me:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Shkruan të dhënat e formatuara në një tampon.
///
/// Kjo makro pranon një 'writer', një varg formati dhe një listë të argumenteve.
/// Argumentet do të formatohen në përputhje me vargun e formatit të specifikuar dhe rezultati do t'i kalohet shkrimtarit.
/// Shkruesi mund të jetë çdo vlerë me një metodë `write_fmt`;në përgjithësi kjo vjen nga një zbatim i [`fmt::Write`] ose [`io::Write`] trait.
/// Makroja kthen çdo gjë që metoda `write_fmt` kthen;zakonisht një [`fmt::Result`], ose një [`io::Result`].
///
/// Shihni [`std::fmt`] për më shumë informacion mbi sintaksën e vargut të formatit.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Një modul mund të importojë të dy `std::fmt::Write` dhe `std::io::Write` dhe të telefonojë `write!` në objektet që zbatojnë njërën, pasi objektet zakonisht nuk i implementojnë të dyja.
///
/// Sidoqoftë, moduli duhet të importojë traits të kualifikuar në mënyrë që emrat e tyre të mos bien ndesh:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // përdor fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // përdor io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Kjo makro mund të përdoret edhe në konfigurimet `no_std`.
/// Në një konfigurim `no_std` ju jeni përgjegjës për detajet e implementimit të përbërësve.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Shkruani të dhëna të formatuara në një buffer, me një linjë të re të bashkangjitur.
///
/// Në të gjitha platformat, linja e re është karakteri LINE FEED (`\n`/`U+000A`) (pa asnjë shtesë CARRIAGE RETURN (`\r`/`U+000D`)).
///
/// Për më shumë informacion, shihni [`write!`].Për informacion mbi sintaksën e vargut të formatit, shihni [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Një modul mund të importojë të dy `std::fmt::Write` dhe `std::io::Write` dhe të telefonojë `write!` në objektet që zbatojnë njërën, pasi objektet zakonisht nuk i implementojnë të dyja.
/// Sidoqoftë, moduli duhet të importojë traits të kualifikuar në mënyrë që emrat e tyre të mos bien ndesh:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // përdor fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // përdor io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Tregon kodin e paarritshëm.
///
/// Kjo është e dobishme çdo herë që përpiluesi nuk mund të përcaktojë se ndonjë kod është i paarritshëm.Për shembull:
///
/// * Ndeshni krahët me kushtet e mbrojtjes.
/// * Sythe që përfundojnë në mënyrë dinamike.
/// * Iteratorët që përfundojnë në mënyrë dinamike.
///
/// Nëse përcaktimi se kodi është i paarritshëm rezulton i pasaktë, programi menjëherë mbaron me një [`panic!`].
///
/// Homologu i pasigurt i kësaj makro është funksioni [`unreachable_unchecked`], i cili do të shkaktojë sjellje të papërcaktuar nëse arrihet kodi.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Kjo do të jetë gjithmonë [`panic!`].
///
/// # Examples
///
/// Krahët e ndeshjes:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // përpiloni gabim nëse komentohet
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // një nga implementimet më të varfra të x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Tregon kodin e pazbatuar duke u kapur nga paniku me një mesazh të "not implemented".
///
/// Kjo lejon që kodi juaj të kontrollojë llojin, i cili është i dobishëm nëse jeni duke prototipizuar ose zbatuar një trait që kërkon metoda të shumta të cilat nuk planifikoni t'i përdorni të gjitha.
///
/// Dallimi midis `unimplemented!` dhe [`todo!`] është se ndërsa `todo!` përcjell një qëllim të implementimit të funksionalitetit më vonë dhe mesazhi është "not yet implemented", `unimplemented!` nuk bën pretendime të tilla.
/// Mesazhi i tij është "not implemented".
/// Gjithashtu disa IDE do të shënojnë `todo!` S.
///
/// # Panics
///
/// Kjo do të jetë gjithmonë [`panic!`] sepse `unimplemented!` është thjesht një stenografi për `panic!` me një mesazh fiks, specifik.
///
/// Ashtu si `panic!`, kjo makro ka një formë të dytë për shfaqjen e vlerave të personalizuara.
///
/// # Examples
///
/// Thuaj se kemi një trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Ne duam të implementojmë `Foo` për 'MyStruct', por për disa arsye ka kuptim vetëm të zbatojmë funksionin `bar()`.
/// `baz()` dhe `qux()` do të duhet ende të përcaktohen në implementimin tonë të `Foo`, por ne mund të përdorim `unimplemented!` në përkufizimet e tyre për të lejuar përpilimin e kodit tonë.
///
/// Ne ende duam që programi ynë të ndalojë së funksionuari nëse arrihen metodat e pazbatuara.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Nuk ka kuptim për `baz` një `MyStruct`, kështu që këtu nuk kemi aspak logjikë.
/////
///         // Kjo do të shfaqë "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Ne kemi një logjikë këtu, Ne mund t'i shtojmë një mesazh të pazbatuarve!për të shfaqur lëshimin tonë.
///         // Kjo do të shfaqë: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Tregon kodin e papërfunduar.
///
/// Kjo mund të jetë e dobishme nëse jeni duke prototipizuar dhe thjesht po kërkoni të kontrolloni llojin e kodit tuaj.
///
/// Dallimi midis [`unimplemented!`] dhe `todo!` është se ndërsa `todo!` përcjell një qëllim të implementimit të funksionalitetit më vonë dhe mesazhi është "not yet implemented", `unimplemented!` nuk bën pretendime të tilla.
/// Mesazhi i tij është "not implemented".
/// Gjithashtu disa IDE do të shënojnë `todo!` S.
///
/// # Panics
///
/// Kjo do të jetë gjithmonë [`panic!`].
///
/// # Examples
///
/// Këtu keni një shembull të disa kodeve në proces.Ne kemi një trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Ne duam të implementojmë `Foo` në një nga llojet tona, por gjithashtu duam të punojmë së pari vetëm në `bar()`.Në mënyrë që kodi ynë të përpilohet, ne duhet të implementojmë `baz()`, kështu që mund të përdorim `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implementimi shkon këtu
///     }
///
///     fn baz(&self) {
///         // le të mos shqetësohemi për implementimin e baz() tani për tani
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ne nuk po përdorim as baz(), kështu që kjo është mirë.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Përkufizimet e makrove të integruara.
///
/// Shumica e vetive makro (qëndrueshmëria, shikueshmëria, etj.) Merren nga kodi burimor këtu, me përjashtim të funksioneve të zgjerimit që transformojnë makro inputet në rezultate, ato funksione sigurohen nga përpiluesi.
///
///
pub(crate) mod builtin {

    /// Shkakton dështimin e përpilimit me mesazhin e dhënë të gabimit kur haset.
    ///
    /// Kjo makro duhet të përdoret kur një crate përdor një strategji të përpilimit të kushtëzuar për të siguruar mesazhe më të mira gabimi për kushte të gabuara.
    ///
    /// Theshtë forma e nivelit të përpiluesit të [`panic!`], por lëshon një gabim gjatë *përpilimit* sesa në *kohën e ekzekutimit*.
    ///
    /// # Examples
    ///
    /// Dy shembuj të tillë janë makrot dhe mjediset `#[cfg]`.
    ///
    /// Emetoni gabim më të mirë të përpiluesit nëse një makro kalon vlera të pavlefshme.
    /// Pa branch përfundimtar, përpiluesi përsëri lëshon një gabim, por mesazhi i gabimit nuk përmend dy vlerat e vlefshme.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Lëshoni gabimin e përpiluesit nëse një nga një numër karakteristikash nuk është i disponueshëm.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Ndërton parametra për makrot e tjera të formatimit të vargjeve.
    ///
    /// Kjo makro funksionon duke marrë një varg formatimi që përmban `{}` për çdo argument shtesë të kaluar.
    /// `format_args!` përgatit parametrat shtesë për të siguruar që rezultati mund të interpretohet si një varg dhe kanonikizon argumentet në një lloj të vetëm.
    /// Çdo vlerë që zbaton [`Display`] trait mund t'i kalohet `format_args!`, ashtu si çdo zbatim [`Debug`] mund t'i kalohet një `{:?}` brenda vargut të formatimit.
    ///
    ///
    /// Kjo makro prodhon një vlerë të tipit [`fmt::Arguments`].Kjo vlerë mund të kalojë në makrot brenda [`std::fmt`] për kryerjen e ridrejtimit të dobishëm.
    /// Të gjitha makrot e tjera të formatimit (["format!"], [`write!`], [`println!`], etj.) Përfaqësohen përmes kësaj.
    /// `format_args!`, ndryshe nga makrot e tij të prejardhura, shmang alokimet e grumbujve.
    ///
    /// Ju mund të përdorni vlerën [`fmt::Arguments`] që `format_args!` kthen në kontekste `Debug` dhe `Display` siç shihet më poshtë.
    /// Shembulli gjithashtu tregon që formati `Debug` dhe `Display` për të njëjtën gjë: vargu i formatit të ndërfutur në `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Për më shumë informacion, shihni dokumentacionin në [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Njësoj si `format_args`, por në fund shton një linjë të re.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspekton një ndryshore të mjedisit në kohën e përpilimit.
    ///
    /// Kjo makro do të zgjerohet në vlerën e ndryshores së emrit të mjedisit në kohën e përpilimit, duke dhënë një shprehje të tipit `&'static str`.
    ///
    ///
    /// Nëse variabli i mjedisit nuk përcaktohet, atëherë do të lëshohet një gabim i përpilimit.
    /// Për të mos lëshuar një gabim përpilimi, përdorni makron [`option_env!`] në vend të kësaj.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Ju mund ta personalizoni mesazhin e gabimit duke kaluar një varg si parametri i dytë:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Nëse variabli i mjedisit `documentation` nuk është përcaktuar, do të merrni gabimin e mëposhtëm:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Opsionale inspekton një ndryshore të mjedisit në kohën e përpilimit.
    ///
    /// Nëse ndryshorja e emëruar e mjedisit është e pranishme në kohën e përpilimit, kjo do të zgjerohet në një shprehje të tipit `Option<&'static str>` vlera e së cilës është `Some` e vlerës së ndryshores së mjedisit.
    /// Nëse ndryshorja e mjedisit nuk është e pranishme, atëherë kjo do të zgjerohet në `None`.
    /// Shihni [`Option<T>`][Option] për më shumë informacion mbi këtë lloj.
    ///
    /// Një gabim i kohës së përpilimit nuk emetohet kurrë kur përdorni këtë makro pavarësisht nëse ndryshorja e mjedisit është e pranishme apo jo.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Bashkon identifikuesit në një identifikues.
    ///
    /// Kjo makro merr çdo numër të identifikuesve të ndarë me presje, dhe i bashkon të gjithë në një, duke dhënë një shprehje që është një identifikues i ri.
    /// Vini re se higjiena e bën atë të tillë që kjo makro nuk mund të kapë variablat lokalë.
    /// Gjithashtu, si rregull i përgjithshëm, makrot lejohen vetëm në artikull, deklaratë ose pozicion shprehjeje.
    /// Kjo do të thotë që ndërsa mund ta përdorni këtë makro për t'iu referuar ndryshoreve ekzistuese, funksioneve ose moduleve, nuk mund të përcaktoni një të re me të.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_aksidente! (i ri, argëtues, emër) { }//nuk përdoret në këtë mënyrë!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Bashkon fjalë për fjalë në një fetë vargu statik.
    ///
    /// Kjo makro merr çdo numër të shkronjave të ndara me presje, duke dhënë një shprehje të tipit `&'static str` e cila përfaqëson të gjitha fjalët e bashkuara majtas-djathtas.
    ///
    ///
    /// Fjalë për fjalë integer dhe pikë lundruese janë të vargëzuara në mënyrë që të bashkohen.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Zgjerohet në numrin e rreshtit në të cilin është thirrur.
    ///
    /// Me [`column!`] dhe [`file!`], këto makro sigurojnë informacionin e korrigjimit të gabimeve për zhvilluesit në lidhje me vendndodhjen brenda burimit.
    ///
    /// Shprehja e zgjeruar ka tip `u32` dhe është e bazuar në 1, kështu që rreshti i parë në secilën skedar vlerëson në 1, e dyta në 2, etj.
    /// Kjo është në përputhje me mesazhet e gabimit nga përpiluesit e zakonshëm ose redaktorët e njohur.
    /// Linja e kthyer nuk është domosdoshmërisht * linja e vetë thirrjes `line!`, por më tepër thirrja e parë makro që çon në thirrjen e makros `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Zgjerohet në numrin e kolonës në të cilën është thirrur.
    ///
    /// Me [`line!`] dhe [`file!`], këto makro sigurojnë informacionin e korrigjimit të gabimeve për zhvilluesit në lidhje me vendndodhjen brenda burimit.
    ///
    /// Shprehja e zgjeruar ka tip `u32` dhe është e bazuar në 1, kështu që kolona e parë në secilën rresht vlerëson në 1, e dyta në 2, etj.
    /// Kjo është në përputhje me mesazhet e gabimit nga përpiluesit e zakonshëm ose redaktorët e njohur.
    /// Kolona e kthyer nuk është domosdoshmërisht * vija e vetë thirrjes `column!`, por më tepër thirrja e parë makro që çon në thirrjen e makros `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Zgjerohet në emrin e skedarit në të cilin është thirrur.
    ///
    /// Me [`line!`] dhe [`column!`], këto makro sigurojnë informacionin e korrigjimit të gabimeve për zhvilluesit në lidhje me vendndodhjen brenda burimit.
    ///
    /// Shprehja e zgjeruar ka llojin `&'static str`, dhe skedari i kthyer nuk është thirrja e makros `file!` në vetvete, por përkundrazi thirrja e parë makro që çon në thirrjen e makros `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifikon argumentet e saj.
    ///
    /// Kjo makro do të japë një shprehje të tipit `&'static str` e cila është vargëzimi i të gjitha tokens të kaluara në makro.
    /// Asnjë kufizim nuk vendoset në sintaksën e vetë thirrjes makro.
    ///
    /// Vini re se rezultatet e zgjeruara të hyrjes tokens mund të ndryshojnë në future.Duhet të jeni të kujdesshëm nëse mbështeteni te rezultati.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Përfshin një skedar të koduar UTF-8 si një varg.
    ///
    /// Skedari është i vendosur në raport me skedarin aktual (në mënyrë të ngjashme me mënyrën se si gjenden modulet).
    /// Rruga e dhënë interpretohet në një mënyrë specifike të platformës në kohën e përpilimit.
    /// Kështu, për shembull, një thirrje me një rrugë Windows që përmban blaslashes `\` nuk do të përpilohet si duhet në Unix.
    ///
    ///
    /// Kjo makro do të japë një shprehje të tipit `&'static str` e cila është përmbajtja e skedarit.
    ///
    /// # Examples
    ///
    /// Supozoni se ka dy skedarë në të njëjtin direktori me përmbajtjen e mëposhtme:
    ///
    /// Skedari 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Skedari 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Hartimi i 'main.rs' dhe ekzekutimi i binarit që rezulton do të shtypë "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Përfshin një skedar si referencë në një grup bajtesh.
    ///
    /// Skedari është i vendosur në raport me skedarin aktual (në mënyrë të ngjashme me mënyrën se si gjenden modulet).
    /// Rruga e dhënë interpretohet në një mënyrë specifike të platformës në kohën e përpilimit.
    /// Kështu, për shembull, një thirrje me një rrugë Windows që përmban blaslashes `\` nuk do të përpilohet si duhet në Unix.
    ///
    ///
    /// Kjo makro do të japë një shprehje të tipit `&'static [u8; N]` e cila është përmbajtja e skedarit.
    ///
    /// # Examples
    ///
    /// Supozoni se ka dy skedarë në të njëjtin direktori me përmbajtjen e mëposhtme:
    ///
    /// Skedari 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Skedari 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Hartimi i 'main.rs' dhe ekzekutimi i binarit që rezulton do të shtypë "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Zgjerohet në një varg që përfaqëson shtegun aktual të modulit.
    ///
    /// Rruga aktuale e modulit mund të mendohet si hierarki e moduleve që çojnë përsëri deri te crate root.
    /// Komponenti i parë i shtegut të kthyer është emri i crate që aktualisht po përpilohet.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Vlerëson kombinimet boolean të flamujve të konfigurimit në kohën e përpilimit.
    ///
    /// Përveç atributit `#[cfg]`, kjo makro është dhënë për të lejuar vlerësimin e shprehjes boolean të flamujve të konfigurimit.
    /// Kjo shpesh çon në një kod më pak të kopjuar.
    ///
    /// Sintaksa e dhënë kësaj makro është e njëjta sintaksë me atributin [`cfg`].
    ///
    /// `cfg!`, ndryshe nga `#[cfg]`, nuk heq ndonjë kod dhe vlerëson vetëm të vërtetë ose të gabuar.
    /// Për shembull, të gjithë blloqet në një shprehje if/else duhet të jenë të vlefshme kur përdoret `cfg!` për gjendjen, pavarësisht se çfarë vlerëson `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analizon një skedar si një shprehje ose një artikull sipas kontekstit.
    ///
    /// Skedari është i vendosur në raport me skedarin aktual (në mënyrë të ngjashme me mënyrën se si gjenden modulet).Rruga e dhënë interpretohet në një mënyrë specifike të platformës në kohën e përpilimit.
    /// Kështu, për shembull, një thirrje me një rrugë Windows që përmban blaslashes `\` nuk do të përpilohet si duhet në Unix.
    ///
    /// Përdorimi i kësaj makro është shpesh një ide e keqe, sepse nëse skedari analizohet si shprehje, ajo do të vendoset në kodin përreth jo higjienikisht.
    /// Kjo mund të rezultojë në ndryshore ose funksione të ndryshme nga ato që skedari priste nëse ekzistojnë variabla ose funksione që kanë të njëjtin emër në skedarin aktual.
    ///
    ///
    /// # Examples
    ///
    /// Supozoni se ka dy skedarë në të njëjtin direktori me përmbajtjen e mëposhtme:
    ///
    /// Skedari 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Skedari 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Hartimi i 'main.rs' dhe ekzekutimi i binarit që rezulton do të shtypë "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Pohon që një shprehje boolean është `true` gjatë kohës së ekzekutimit.
    ///
    /// Kjo do të thërrasë makron [`panic!`] nëse shprehja e dhënë nuk mund të vlerësohet në `true` gjatë kohës së ekzekutimit.
    ///
    /// # Uses
    ///
    /// Pohimet gjithmonë kontrollohen si në ndërtimin e korrigjimeve të gabimeve ashtu edhe në ato të lëshimit dhe nuk mund të çaktivizohen.
    /// Shihni [`debug_assert!`] për pohimet që nuk janë aktivizuar në ndërtimet e lëshimeve si parazgjedhje.
    ///
    /// Kodi i pasigurt mund të mbështetet në `assert!` për të zbatuar invariants në kohë që nuk mund të çojë në pasiguri.
    ///
    /// Rastet e tjera të përdorimit të `assert!` përfshijnë testimin dhe zbatimin e pandryshimeve në kohë të ekzekutuar në kodin e sigurt (shkelja e të cilit nuk mund të rezultojë në pasiguri).
    ///
    ///
    /// # Mesazhet e personalizuara
    ///
    /// Kjo makro ka një formë të dytë, ku një mesazh me porosi panic mund të sigurohet me ose pa argumente për formatimin.
    /// Shihni [`std::fmt`] për sintaksë për këtë formë.
    /// Shprehjet e përdorura si argumente të formatit do të vlerësohen vetëm nëse pohimi dështon.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // mesazhi panic për këto pohime është vlera e vargëzuar e shprehjes së dhënë.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // një funksion shumë i thjeshtë
    ///
    /// assert!(some_computation());
    ///
    /// // pohoni me një mesazh të personalizuar
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Montimi i rreshtuar.
    ///
    /// Lexoni [unstable book] për përdorimin.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Asambleja inline e stilit LLVM.
    ///
    /// Lexoni [unstable book] për përdorimin.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Montimi inline i nivelit të modulit.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Printimet kaluan tokens në daljen standarde.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Mundëson ose çaktivizon funksionalitetin e gjurmimit të përdorur për korrigjimin e gabimeve të makrove të tjera.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Atributi makro që përdoret për të aplikuar makrot rrjedhëse.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Atributi makro i aplikuar në një funksion për ta kthyer atë në një test njësie.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Atributi makro i aplikuar në një funksion për ta kthyer atë në një provë referimi.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Një detaj i implementimit të makrove `#[test]` dhe `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Atributi makro i aplikuar në një statike për ta regjistruar atë si një shpërndarës global.
    ///
    /// Shihni gjithashtu [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Mban artikullin ku është aplikuar nëse rruga e kaluar është e arritshme dhe e heq ndryshe.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Zgjeron të gjitha atributet `#[cfg]` dhe `#[cfg_attr]` në fragmentin e kodit ku është aplikuar.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Mos përdorni detaje të paqëndrueshme të implementimit të përpiluesit `rustc`.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Mos përdorni detaje të paqëndrueshme të implementimit të përpiluesit `rustc`.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}