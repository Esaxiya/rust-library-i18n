use crate::iter::FromIterator;

/// Kolaps të gjithë njësitë e njësive nga një iterator në një.
///
/// Kjo është më e dobishme kur kombinohet me abstraksione të nivelit më të lartë, si mbledhja në një `Result<(), E>` ku kujdeseni vetëm për gabimet:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}