//! Shndërrimet e personazheve.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Konverton një `u32` në një `char`.
///
/// Vini re se të gjithë [`char`]-ët janë të vlefshëm [`u32`] s, dhe mund të vendosen në një me një
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Sidoqoftë, e kundërta nuk është e vërtetë: jo të gjitha vlerat [`u32`] janë të vlefshme [`char`] s.
/// `from_u32()` do të kthejë `None` nëse hyrja nuk është një vlerë e vlefshme për një [`char`].
///
/// Për një version të pasigurt të këtij funksioni i cili injoron këto kontrolle, shihni [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Kthimi i `None` kur hyrja nuk është e vlefshme [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Konverton një `u32` në `char`, duke injoruar vlefshmërinë.
///
/// Vini re se të gjithë [`char`]-ët janë të vlefshëm [`u32`] s, dhe mund të vendosen në një me një
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Sidoqoftë, e kundërta nuk është e vërtetë: jo të gjitha vlerat [`u32`] janë të vlefshme [`char`] s.
/// `from_u32_unchecked()` do ta injorojë këtë dhe do të hedhë verbërisht në [`char`], duke krijuar ndoshta një të pavlefshëm.
///
///
/// # Safety
///
/// Ky funksion është i pasigurt, pasi mund të ndërtojë vlera të pavlefshme `char`.
///
/// Për një version të sigurt të këtij funksioni, shihni funksionin [`from_u32`].
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SIGURIA: thirrësi duhet të garantojë që `i` është një vlerë e vlefshme e karbonit.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Shndërron një [`char`] në një [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Shndërron një [`char`] në një [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Karakteristika hidhet në vlerën e pikës së kodit, pastaj zgjerohet zero në 64 bit.
        // Shihni [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Shndërron një [`char`] në një [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Karakteristika hidhet në vlerën e pikës së kodit, pastaj zgjerohet zero në 128 bit.
        // Shihni [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Harton një bajt në 0x00 ..=0xFF në një `char` pika e kodit e së cilës ka të njëjtën vlerë, në U + 0000 ..=U + 00FF.
///
/// Unicode është krijuar ashtu që kjo dekodon në mënyrë efektive bajtët me kodifikimin e karakterit që IANA e quan ISO-8859-1.
/// Ky kodim është i pajtueshëm me ASCII.
///
/// Vini re se kjo është e ndryshme nga ISO/IEC 8859-1 aka
/// ISO 8859-1 (me një vizë më pak), i cili lë disa vlera "blanks", bajt që nuk i janë caktuar asnjë karakteri.
/// ISO-8859-1 (ai IANA) i cakton ato në kodet e kontrollit C0 dhe C1.
///
/// Vini re se kjo është *gjithashtu* e ndryshme nga Windows-1252 aka
/// faqe me kod 1252, e cila është një super e vendosur ISO/IEC 8859-1 që cakton disa (jo të gjitha!) boshllëqe në pikësim dhe karaktere të ndryshme latine.
///
/// Për t'i hutuar gjërat më tej, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` dhe `windows-1252` janë të gjitha pseudonime për një super-sistem të Windows-1252 që plotëson vendet bosh me kodet përkatëse të kontrollit C0 dhe C1.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Shndërron një [`u8`] në një [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Një gabim i cili mund të kthehet kur analizon një karikim.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SIGURIA: kontrolluar që është një vlerë ligjore e unikodit
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Lloji i gabimit u kthye kur një konvertim nga u32 në karikim dështon.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Shndërron një shifër në rrezen e dhënë në një `char`.
///
/// Një 'radix' këtu nganjëherë quhet edhe 'base'.
/// Një radiks prej dy tregon një numër binar, një radiks prej dhjetë, dhjetore dhe një radiks prej gjashtëmbëdhjetë, heksadecimal, për të dhënë disa vlera të përbashkëta.
///
/// Rrezet arbitrare mbështeten.
///
/// `from_digit()` do të kthejë `None` nëse hyrja nuk është një shifër në rrezen e dhënë.
///
/// # Panics
///
/// Panics nëse i jepet një radiks më i madh se 36.
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Dhjetori 11 është një shifër e vetme në bazën 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Kthimi i `None` kur hyrja nuk është shifër:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Kalimi i një radiksi të madh, duke shkaktuar një panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}