//! implikohem {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Pika më e lartë e vlefshme e kodit që mund të ketë një `char`.
    ///
    /// Një `char` është një [Unicode Scalar Value], që do të thotë se është një [Code Point], por vetëm ato brenda një diapazoni të caktuar.
    /// `MAX` është pika më e lartë e vlefshme e kodit që është [Unicode Scalar Value] e vlefshme.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () përdoret në Unicode për të përfaqësuar një gabim dekodimi.
    ///
    /// Mund të ndodhë, për shembull, kur i jepni [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) bajte të formuar keq UTF-8.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Versioni i [Unicode](http://www.unicode.org/) në të cilin bazohen pjesët Unicode të metodave `char` dhe `str`.
    ///
    /// Versione të reja të Unicode lëshohen rregullisht dhe më pas azhurnohen të gjitha metodat në bibliotekën standarde në varësi të Unicode.
    /// Prandaj sjellja e disa metodave `char` dhe `str` dhe vlera e kësaj konstante ndryshon me kalimin e kohës.
    /// Ky *nuk* konsiderohet të jetë një ndryshim thelbësor.
    ///
    /// Skema e numërimit të versioneve shpjegohet në [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Krijon një përsëritës mbi pikat e koduara të koduara UTF-16 në `iter`, duke kthyer zëvendësuesit e pa çiftuar si `Err`.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Një dekoder me humbje mund të merret duke zëvendësuar rezultatet `Err` me karakterin zëvendësues:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Konverton një `u32` në një `char`.
    ///
    /// Vini re se të gjitha `char`-ët janë të vlefshme [`u32`] s, dhe mund të vendosen në një me një
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Sidoqoftë, e kundërta nuk është e vërtetë: jo të gjitha vlerat e vlefshme [`u32`] janë të vlefshme.
    /// `from_u32()` do të kthejë `None` nëse hyrja nuk është një vlerë e vlefshme për një `char`.
    ///
    /// Për një version të pasigurt të këtij funksioni i cili injoron këto kontrolle, shihni [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Kthimi i `None` kur hyrja nuk është e vlefshme `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Konverton një `u32` në `char`, duke injoruar vlefshmërinë.
    ///
    /// Vini re se të gjitha `char`-ët janë të vlefshme [`u32`] s, dhe mund të vendosen në një me një
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Sidoqoftë, e kundërta nuk është e vërtetë: jo të gjitha vlerat e vlefshme [`u32`] janë të vlefshme.
    /// `from_u32_unchecked()` do ta injorojë këtë dhe do të hedhë verbërisht në `char`, duke krijuar ndoshta një të pavlefshëm.
    ///
    ///
    /// # Safety
    ///
    /// Ky funksion është i pasigurt, pasi mund të ndërtojë vlera të pavlefshme `char`.
    ///
    /// Për një version të sigurt të këtij funksioni, shihni funksionin [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SIGURIA: kontrata e sigurisë duhet të mbahet nga thirrësi.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Shndërron një shifër në rrezen e dhënë në një `char`.
    ///
    /// Një 'radix' këtu nganjëherë quhet edhe 'base'.
    /// Një radiks prej dy tregon një numër binar, një radiks prej dhjetë, dhjetore dhe një radiks prej gjashtëmbëdhjetë, heksadecimal, për të dhënë disa vlera të përbashkëta.
    ///
    /// Rrezet arbitrare mbështeten.
    ///
    /// `from_digit()` do të kthejë `None` nëse hyrja nuk është një shifër në rrezen e dhënë.
    ///
    /// # Panics
    ///
    /// Panics nëse i jepet një radiks më i madh se 36.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Dhjetori 11 është një shifër e vetme në bazën 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Kthimi i `None` kur hyrja nuk është shifër:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Kalimi i një radiksi të madh, duke shkaktuar një panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Kontrollon nëse një `char` është një shifër në radiksin e dhënë.
    ///
    /// Një 'radix' këtu nganjëherë quhet edhe 'base'.
    /// Një radiks prej dy tregon një numër binar, një radiks prej dhjetë, dhjetore dhe një radiks prej gjashtëmbëdhjetë, heksadecimal, për të dhënë disa vlera të përbashkëta.
    ///
    /// Rrezet arbitrare mbështeten.
    ///
    /// Krahasuar me [`is_numeric()`], ky funksion njeh vetëm karakteret `0-9`, `a-z` dhe `A-Z`.
    ///
    /// 'Digit' përcaktohet të jetë vetëm personazhet e mëposhtëm:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Për një kuptim më gjithëpërfshirës të 'digit', shihni [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics nëse i jepet një radiks më i madh se 36.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Kalimi i një radiksi të madh, duke shkaktuar një panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Shndërron një `char` në një shifër në radiksin e dhënë.
    ///
    /// Një 'radix' këtu nganjëherë quhet edhe 'base'.
    /// Një radiks prej dy tregon një numër binar, një radiks prej dhjetë, dhjetore dhe një radiks prej gjashtëmbëdhjetë, heksadecimal, për të dhënë disa vlera të përbashkëta.
    ///
    /// Rrezet arbitrare mbështeten.
    ///
    /// 'Digit' përcaktohet të jetë vetëm personazhet e mëposhtëm:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Kthen `None` nëse `char` nuk i referohet një shifre në rrezen e dhënë.
    ///
    /// # Panics
    ///
    /// Panics nëse i jepet një radiks më i madh se 36.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Kalimi i një rezultati jo-shifror në dështim:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Kalimi i një radiksi të madh, duke shkaktuar një panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // kodi ndahet këtu për të përmirësuar shpejtësinë e ekzekutimit për rastet kur `radix` është konstant dhe 10 ose më i vogël
        //
        let val = if likely(radix <= 10) {
            // Nëse jo një shifër, do të krijohet një numër më i madh se radiksi.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Kthen një iterator që jep ikjen hexadecimal Unicode të një karakteri si `char`.
    ///
    /// Kjo do t'u shpëtojë karaktereve me sintaksën Rust të formës `\u{NNNNNN}` ku `NNNNNN` është një paraqitje heksadecimale.
    ///
    ///
    /// # Examples
    ///
    /// Si përsëritës:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Përdorimi i `println!` direkt:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Të dyja janë ekuivalente me:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Përdorimi i `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // ose-1 siguron që për c==0 kodi llogarit që një shifër duhet të shtypet dhe (e cila është e njëjtë) shmang nën-rrjedhjen (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // indeksi i shifrës magjike më të rëndësishme
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Një version i zgjeruar i `escape_debug` që lejon opsionalisht të shpëtojë nga kodet e zgjeruara të Grafemës.
    /// Kjo na lejon të formatojmë karaktere si shenja jo-hapësinore më mirë kur ato janë në fillim të një vargu.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Kthen një iterator që jep kodin fjalë për fjalë të ikjes së një karakteri si `char`.
    ///
    /// Kjo do t'u shpëtojë karaktereve të ngjashme me implementimet `Debug` të `str` ose `char`.
    ///
    ///
    /// # Examples
    ///
    /// Si përsëritës:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Përdorimi i `println!` direkt:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Të dyja janë ekuivalente me:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Përdorimi i `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Kthen një iterator që jep kodin fjalë për fjalë të ikjes së një karakteri si `char`.
    ///
    /// Parazgjedhja zgjidhet me një paragjykim për prodhimin e teksteve që janë të ligjshme në një larmi gjuhësh, duke përfshirë C++ 11 dhe gjuhë të ngjashme të familjes C.
    /// Rregullat e sakta janë:
    ///
    /// * Skeda është ikur si `\t`.
    /// * Kthimi i karrocës shpëtohet si `\r`.
    /// * Ushqimi i linjës është shpëtuar si `\n`.
    /// * Kuota e vetme është shpëtuar si `\'`.
    /// * Citimi i dyfishtë është shpëtuar si `\"`.
    /// * Backslash është shpëtuar si `\\`.
    /// * Çdo karakter në gamën 'e shtypshme ASCII' `0x20` .. `0x7e` përfshirëse nuk shpëtohet.
    /// * Të gjithë personazheve të tjerë u jepen ikje heksadecimale të Unikodit;shih [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Si përsëritës:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Përdorimi i `println!` direkt:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Të dyja janë ekuivalente me:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Përdorimi i `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Kthen numrin e bajteve që do t'i duhen këtij `char` nëse kodohen në UTF-8.
    ///
    /// Ky numër bajtesh është gjithmonë midis 1 dhe 4, përfshirë.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Lloji `&str` garanton që përmbajtja e tij është UTF-8, dhe kështu mund të krahasojmë gjatësinë që do të duhej nëse secila pikë kodi përfaqësohej si `char` vs në vetë `&str`:
    ///
    ///
    /// ```
    /// // si karaktere
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // të dy mund të paraqiten si tre bajt
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // si &str, këto dy janë të koduara në UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // ne mund të shohim se ata marrin gjashtë bajt gjithsej ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... ashtu si &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Kthen numrin e njësive të kodit 16-bit që do t'i duhen këtij `char` nëse kodifikohet në UTF-16.
    ///
    ///
    /// Shihni dokumentacionin për [`len_utf8()`] për më shumë shpjegime të këtij koncepti.
    /// Ky funksion është një pasqyrë, por për UTF-16 në vend të UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Kodifikon këtë karakter si UTF-8 në buffer-in e dhënë nga bajtët, dhe më pas kthen nënfushën e buffer-it që përmban karakterin e koduar.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse bufferi nuk është mjaft i madh.
    /// Një buffer me gjatësi katër është mjaft i madh për të koduar çdo `char`.
    ///
    /// # Examples
    ///
    /// Në të dy këta shembuj, 'ß' merr dy bajt për të kodifikuar.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Një tampon që është shumë i vogël:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SIGURIA: `char` nuk është zëvendësues, kështu që kjo është e vlefshme UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Kodifikon këtë karakter si UTF-16 në buffer-in e dhënë `u16` dhe më pas kthen nënfushën e buffer-it që përmban karakterin e koduar.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse bufferi nuk është mjaft i madh.
    /// Një buffer me gjatësi 2 është mjaft i madh për të kodifikuar çdo `char`.
    ///
    /// # Examples
    ///
    /// Në të dy këta shembuj, '𝕊' merr dy `u16 për të koduar.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Një tampon që është shumë i vogël:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Kthen `true` nëse ky `char` ka vetinë `Alphabetic`.
    ///
    /// `Alphabetic` është përshkruar në Kapitullin 4 (Karakteristikat e Karakterit) të [Unicode Standard] dhe specifikuar në [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // dashuria është shumë gjëra, por nuk është alfabetike
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Kthen `true` nëse ky `char` ka vetinë `Lowercase`.
    ///
    /// `Lowercase` është përshkruar në Kapitullin 4 (Karakteristikat e Karakterit) të [Unicode Standard] dhe specifikuar në [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Shkrimet dhe pikësimet e ndryshme kineze nuk kanë shkronja të mëdha, dhe kështu:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Kthen `true` nëse ky `char` ka vetinë `Uppercase`.
    ///
    /// `Uppercase` është përshkruar në Kapitullin 4 (Karakteristikat e Karakterit) të [Unicode Standard] dhe specifikuar në [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Shkrimet dhe pikësimet e ndryshme kineze nuk kanë shkronja të mëdha, dhe kështu:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Kthen `true` nëse ky `char` ka vetinë `White_Space`.
    ///
    /// `White_Space` specifikohet në [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // një hapësirë që nuk prishet
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Kthen `true` nëse ky `char` kënaq [`is_alphabetic()`] ose [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Kthen `true` nëse ky `char` ka kategorinë e përgjithshme për kodet e kontrollit.
    ///
    /// Kodet e kontrollit (pikat e kodit me kategorinë e përgjithshme të `Cc`) përshkruhen në Kapitullin 4 (Karakteristikat e Karakterit) të [Unicode Standard] dhe specifikuar në [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // U + 009C, TERMINATORI I STRING-it
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Kthen `true` nëse ky `char` ka vetinë `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` është përshkruar në [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] dhe specifikuar në [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Kthen `true` nëse ky `char` ka një nga kategoritë e përgjithshme për numrat.
    ///
    /// Kategoritë e përgjithshme për numrat (`Nd` për shifrat dhjetore, `Nl` për shkronjat numerike të ngjashme me shkronjat dhe `No` për karakteret e tjerë numerikë) specifikohen në [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Kthen një iterator që jep hartën e shkronjave të vogla të këtij `char` si një ose më shumë
    /// `char`s.
    ///
    /// Nëse ky `char` nuk ka një hartëzim të shkronjave të vogla, iteratori jep të njëjtën `char`.
    ///
    /// Nëse ky `char` ka një hartëzim të shkronjave të vogla një-për-një të dhënë nga [Unicode Character Database][ucd] [`UnicodeData.txt`], iteratori jep atë `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Nëse ky `char` kërkon konsiderata të veçanta (p.sh. `char` i shumëfishtë) iteratori jep`char` (et) e dhëna nga [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ky operacion kryen një hartëzim të pakushtëzuar pa rrobaqepësi.Kjo është, konvertimi është i pavarur nga konteksti dhe gjuha.
    ///
    /// Në [Unicode Standard], Kapitulli 4 (Karakteristikat e Karakterit) diskuton hartëzimin e rasteve në përgjithësi dhe Kapitulli 3 (Conformance) diskuton algoritmin e parazgjedhur për shndërrimin e shkronjave.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Si përsëritës:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Përdorimi i `println!` direkt:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Të dyja janë ekuivalente me:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Përdorimi i `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Ndonjëherë rezultati është më shumë se një karakter:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Karakteret që nuk kanë të dy të mëdha dhe të vogla shndërrohen në vetvete.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Kthen një iterator që jep hartën e madhe të këtij `char` si një ose më shumë
    /// `char`s.
    ///
    /// Nëse ky `char` nuk ka një hartë të madhe, iteratori jep të njëjtën `char`.
    ///
    /// Nëse ky `char` ka një hartë një-për-një të madhe të dhënë nga [Unicode Character Database][ucd] [`UnicodeData.txt`], iteratori jep atë `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Nëse ky `char` kërkon konsiderata të veçanta (p.sh. `char` i shumëfishtë) iteratori jep`char` (et) e dhëna nga [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ky operacion kryen një hartëzim të pakushtëzuar pa rrobaqepësi.Kjo është, konvertimi është i pavarur nga konteksti dhe gjuha.
    ///
    /// Në [Unicode Standard], Kapitulli 4 (Karakteristikat e Karakterit) diskuton hartëzimin e rasteve në përgjithësi dhe Kapitulli 3 (Conformance) diskuton algoritmin e parazgjedhur për shndërrimin e shkronjave.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Si përsëritës:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Përdorimi i `println!` direkt:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Të dyja janë ekuivalente me:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Përdorimi i `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Ndonjëherë rezultati është më shumë se një karakter:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Karakteret që nuk kanë të dy të mëdha dhe të vogla shndërrohen në vetvete.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Shënim për vendndodhjen
    ///
    /// Në turqisht, ekuivalenti i 'i' në latinisht ka pesë forma në vend të dy:
    ///
    /// * 'Dotless': Unë/ı, ndonjëherë i shkruar
    /// * 'Dotted': İ/i
    ///
    /// Vini re se 'i' me shkronja të vogla është e njëjtë me latinishten.Prandaj:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Vlera e `upper_i` këtu mbështetet në gjuhën e tekstit: nëse jemi në `en-US`, duhet të jetë `"I"`, por nëse jemi në `tr_TR`, duhet të jetë `"İ"`.
    /// `to_uppercase()` nuk e merr parasysh këtë, dhe kështu:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// mban nëpër gjuhë.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Kontrollon nëse vlera është brenda intervalit ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Bën një kopje të vlerës në ekuivalentin e saj me shkronja të mëdha ASCII.
    ///
    /// Shkronjat ASCII 'a' në 'z' janë të shënuara në 'A' në 'Z', por shkronjat jo ASCII janë të pandryshuara.
    ///
    /// Për të shkruar më të madhe vlerën në vend, përdorni [`make_ascii_uppercase()`].
    ///
    /// Për karaktere të mëdha ASCII përveç karaktereve jo-ASCII, përdorni [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Bën një kopje të vlerës në ekuivalentin e saj të vogël ASCII.
    ///
    /// Shkronjat ASCII 'A' në 'Z' janë të shënuara në 'a' në 'z', por shkronjat jo-ASCII janë të pandryshuara.
    ///
    /// Për të zvogëluar vlerën në vend, përdorni [`make_ascii_lowercase()`].
    ///
    /// Për të përdorur shkronjat e vogla ASCII përveç karaktereve jo-ASCII, përdorni [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Kontrollon që dy vlera janë një përputhje e pandjeshme e ASCII.
    ///
    /// Ekuivalente me `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Konverton këtë lloj në ekuivalentin e tij me shkronja të mëdha ASCII në vend.
    ///
    /// Shkronjat ASCII 'a' në 'z' janë të shënuara në 'A' në 'Z', por shkronjat jo ASCII janë të pandryshuara.
    ///
    /// Për të kthyer një vlerë të re me shkronja të mëdha pa modifikuar atë ekzistuese, përdorni [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Konverton këtë lloj në ekuivalentin e tij me shkronja të vogla ASCII në vend.
    ///
    /// Shkronjat ASCII 'A' në 'Z' janë të shënuara në 'a' në 'z', por shkronjat jo-ASCII janë të pandryshuara.
    ///
    /// Për të kthyer një vlerë të re të vogël, pa modifikuar atë ekzistuese, përdorni [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Kontrollon nëse vlera është një karakter alfabetik ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ose
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Kontrollon nëse vlera është një karakter i madh ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Kontrollon nëse vlera është një karakter i vogël ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Kontrollon nëse vlera është një karakter alfanumerik ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', ose
    /// - U + 0061 'a' ..=U + 007A 'z', ose
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Kontrollon nëse vlera është një shifër dhjetore ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Kontrollon nëse vlera është një shifër heksadecimale ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', ose
    /// - U + 0041 'A' ..=U + 0046 'F', ose
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Kontrollon nëse vlera është karakter i pikësimit ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, ose
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, ose
    /// - U + 005B ..=U + 0060 "[\] ^ _" ``, ose
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Kontrollon nëse vlera është karakter grafik ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Kontrollon nëse vlera është një karakter i hapësirës së bardhë ASCII:
    /// U + 0020 HAP 00SIRAB, U + 0009 TAB HORIZONTAL, U + 000A LIDHJE E LINJS, U + 000C FORME FEED, ose U + 000D KTHIMI I KARGJIKUT.
    ///
    /// Rust përdor WhatWG Infra Standard's [definition of ASCII whitespace][infra-aw].Ekzistojnë disa përkufizime të tjera në përdorim të gjerë.
    /// Për shembull, [the POSIX locale][pct] përfshin U + 000B TAB VERTICAL, si dhe të gjithë personazhet e mësipërm, por-nga specifikimi i njëjtë-[rregulli i paracaktuar për "field splitting" në Bourne shell][bfs] konsideron *vetëm* HAPACESIRN, TAB HORIZONTAL, dhe LINE FEED si hapësirë e bardhë.
    ///
    ///
    /// Nëse jeni duke shkruar një program që do të përpunojë një format ekzistues të skedarit, kontrolloni se cili është përkufizimi i këtij formati për hapësirën e bardhë përpara se të përdorni këtë funksion.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Kontrollon nëse vlera është një karakter kontrolli ASCII:
    /// U + 0000 NUL ..=U + 001F NDARSI I NJITSIS, ose U + 007F Fshije.
    /// Vini re se shumica e karaktereve të hapësirës së bardhë ASCII janë karaktere kontrolli, por SPACE nuk është.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Kodifikon një vlerë të papërpunuar u32 si UTF-8 në buffer-in e parashikuar të bajtit dhe më pas kthen nën-pjesën e buffer-it që përmban karakterin e koduar.
///
///
/// Ndryshe nga `char::encode_utf8`, kjo metodë gjithashtu trajton pikat e kodit në intervalin zëvendësues.
/// (Krijimi i një `char` në intervalin zëvendësues është UB.) Rezultati është i vlefshëm [generalized UTF-8] por jo i vlefshëm UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics nëse bufferi nuk është mjaft i madh.
/// Një buffer me gjatësi katër është mjaft i madh për të koduar çdo `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Kodifikon një vlerë të papërpunuar u32 si UTF-16 në buffer-in e dhënë `u16` dhe më pas kthen nën-pjesën e buffer-it që përmban karakterin e koduar.
///
///
/// Ndryshe nga `char::encode_utf16`, kjo metodë gjithashtu trajton pikat e kodit në intervalin zëvendësues.
/// (Krijimi i një `char` në intervalin zëvendësues është UB.)
///
/// # Panics
///
/// Panics nëse bufferi nuk është mjaft i madh.
/// Një buffer me gjatësi 2 është mjaft i madh për të kodifikuar çdo `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SIGURIA: secili krah kontrollon nëse ka bit të mjaftueshëm për të shkruar
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // PKM bie
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Avionët shtesë plotësohen në zëvendësime.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}