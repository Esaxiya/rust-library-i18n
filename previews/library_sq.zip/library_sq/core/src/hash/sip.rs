//! Një zbatim i SipHash.

#![allow(deprecated)] // llojet në këtë modul janë të amortizuara

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// Një zbatim i SipHash 1-3.
///
/// Ky është aktualisht funksioni i paracaktuar i heshimit i përdorur nga biblioteka standarde (p.sh., `collections::HashMap` e përdor atë si parazgjedhje).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// Një zbatim i SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// Një zbatim i SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash është një funksion hashed i qëllimit të përgjithshëm: funksionon me një shpejtësi të mirë (konkurrues me Spooky dhe City) dhe lejon tërheqje të fortë _keyed_.
///
/// Kjo ju lejon të mbyllni tabelat tuaja të hashit nga një RNG i fortë, siç është [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// Edhe pse algoritmi SipHash konsiderohet të jetë përgjithësisht i fortë, ai nuk është menduar për qëllime kriptografike.
/// Si e tillë, të gjitha përdorimet kriptografike të këtij implementimi janë _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // sa bajte kemi përpunuar
    state: State,  // shteti hash
    tail: u64,     // bajte të papërpunuara le
    ntail: usize,  // sa bajte në bisht janë të vlefshme
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 dhe v1, v3 shfaqen në çifte në algoritëm dhe zbatimet simd të SipHash do të përdorin vectors të v02 dhe v13.
    //
    // Duke i vendosur ato në këtë renditje në strukturë, përpiluesi mund të marrë vetëm disa optimizime simd vetvetiu.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Ngarkon një numër të plotë të llojit të dëshiruar nga një rrjedhë bajtësh, në rendin LE.
/// Përdor `copy_nonoverlapping` për të lejuar përpiluesin të gjenerojë mënyrën më efikase për ta ngarkuar atë nga një adresë e pavendosur.
///
///
/// E pasigurt sepse: indeksimi i pakontrolluar në i..i+size_of(int_ty)
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// Ngarkon një u64 duke përdorur deri në 7 bajte të një fete bajtesh.
/// Duket e ngathët, por thirrjet `copy_nonoverlapping` që ndodhin (përmes `load_int_le!`) të gjitha kanë madhësi fikse dhe shmangin thirrjen `memcpy`, e cila është e mirë për shpejtësinë.
///
///
/// E pasigurt sepse: indeksimi i pakontrolluar në fillim..filloni + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // indeksi i bajtit aktual (nga LSB) në daljen u64
    let mut out = 0;
    if i + 3 < len {
        // SIGURIA: `i` nuk mund të jetë më e madhe se `len`, dhe thirrësi duhet të garantojë
        // që indeksi të fillojë..filloni + len është në kufij.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // SIGURIA: njësoj si më sipër.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // SIGURIA: njësoj si më sipër.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Krijon një `SipHasher` të ri me dy çelësat fillestarë të vendosur në 0.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Krijon një `SipHasher` që mbyllet nga çelësat e dhënë.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Krijon një `SipHasher13` të ri me dy çelësat fillestarë të vendosur në 0.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Krijon një `SipHasher13` që mbyllet nga çelësat e dhënë.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: nuk janë përcaktuar metodat e integrimit të plotë (`shkruaj_u *`, `write_i*`)
    // për këtë lloj.
    // Ne mund t'i shtojmë ato, të kopjojmë zbatimin `short_write` në librustc_data_structures/sip128.rs dhe të shtojmë metodat `write_u *`/`write_i*` në `SipHasher`, `SipHasher13` dhe `DefaultHasher`.
    //
    // Kjo do të përshpejtojë shumë shkrirjen e plotë nga ato hashers, me koston e ngadalësimit pak të shpejtësisë së përpilimit në disa standarde.
    // Shihni #69152 për detaje.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // SIGURIA: `cmp::min(length, needed)` është e garantuar të mos jetë mbi `length`
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Bishti i tamponuar tani është skuqur, përpunoni inputin e ri.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // SIGURIA: sepse `len - left` është shumica më e madhe e 8 nën
            // `len`, dhe për shkak se `i` fillon me `needed` ku `len` është `length - needed`, `i + 8` është e garantuar të jetë më e vogël ose e barabartë me `length`.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // SIGURIA: `i` tani është `needed + len.div_euclid(8) * 8`,
        // pra `i + left` = `needed + len` = `length`, që sipas përkufizimit është e barabartë me `msg.len()`.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// Krijon një `Hasher<S>` me dy çelësat fillestarë të vendosur në 0.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}