//! Mbështetje Panic për libcore
//!
//! Biblioteka kryesore nuk mund të përcaktojë panik, por *deklaron* panik.
//! Kjo do të thotë që funksionet brenda libcore lejohen të panic, por për të qenë i dobishëm një crate në rrjedhën e sipërme duhet të përcaktojë panik për përdorimin e libcore.
//! Ndërfaqja aktuale për panik është:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Ky përkufizim lejon panikimin me çdo mesazh të përgjithshëm, por nuk lejon dështimin me një vlerë `Box<Any>`.
//! (`PanicInfo` thjesht përmban një `&(dyn Any + Send)`, për të cilin ne plotësojmë një vlerë bedel në `PanicInfo: : internal_constructor`.) Arsyeja për këtë është që libcore nuk lejohet të caktohet.
//!
//!
//! Ky modul përmban disa funksione të tjera paniku, por këto janë vetëm artikujt e nevojshëm për përpiluesin.Të gjithë panics drejtohen përmes këtij funksioni.
//! Simboli aktual deklarohet përmes atributit `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Zbatimi themelor i makros `panic!` të libcore kur nuk përdoret formatimi.
#[cold]
// asnjëherë mos rreshto nëse paniku_immediate_abort për të shmangur fryrjen e kodit në vendet e thirrjes sa më shumë që të jetë e mundur
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // e nevojshme nga codegen për panic në mbingarkesë dhe terminatorë të tjerë `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Përdorni Arguments::new_v1 në vend të formatit_argëve! ("{}", Expr) për të zvogëluar potencialisht lartësinë e madhësisë.
    // Formatet_argje!makro përdor Display trait të str për të shkruar expr, i cili bën thirrje Formatter::pad, i cili duhet të akomodojë shkurtimin dhe mbushjen e vargut (edhe pse nuk përdoret asnjë këtu).
    //
    // Përdorimi i Arguments::new_v1 mund të lejojë që përpiluesi të heqë Formatter::pad nga binari i daljes, duke kursyer deri në disa kilobajt.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // e nevojshme për panics të vlerësuara nga konstatimi
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // e nevojshme nga codegen për panic në qasjen OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Zbatimi themelor i makros `panic!` libcore kur përdoret formatimi.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // SHENIM Ky funksion nuk kalon kurrë kufirin e FFI;është një thirrje Rust-to-Rust që zgjidhet në funksionin `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SIGURIA: `panic_impl` përcaktohet në kodin e sigurt Rust dhe kështu është i sigurt për t`u thirrur.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Funksioni i brendshëm për makrot `assert_eq!` dhe `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}