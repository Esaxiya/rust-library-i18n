/// Përdoret për indeksimin e operacioneve (`container[index]`) në kontekste të pandryshueshme.
///
/// `container[index]` në të vërtetë është sheqer sintaksor për `*container.index(index)`, por vetëm kur përdoret si një vlerë e pandryshueshme.
/// Nëse kërkohet një vlerë e ndryshueshme, në vend të tij përdoret [`IndexMut`].
/// Kjo lejon gjëra të këndshme të tilla si `let value = v[index]` nëse lloji i `value` zbaton [`Copy`].
///
/// # Examples
///
/// Shembulli i mëposhtëm zbaton `Index` në një kontejner `NucleotideCount` vetëm për lexim, duke bërë të mundur që numërat individualë të merren me sintaksën e indeksit.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Lloji i kthyer pas indeksimit.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Kryen veprimin e indeksimit (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Përdoret për indeksimin e operacioneve (`container[index]`) në kontekste të ndryshueshme.
///
/// `container[index]` në të vërtetë është sheqer sintaksor për `*container.index_mut(index)`, por vetëm kur përdoret si një vlerë e ndryshueshme.
/// Nëse kërkohet një vlerë e pandryshueshme, në vend të tij përdoret [`Index`] trait.
/// Kjo lejon gjëra të këndshme të tilla si `v[index] = value`.
///
/// # Examples
///
/// Një zbatim shumë i thjeshtë i një strukture `Balance` që ka dy anë, ku secila mund të indeksohet në mënyrë të pandryshueshme dhe të pandryshueshme.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // Në këtë rast, `balance[Side::Right]` është sheqer për `*balance.index(Side::Right)`, pasi që ne vetëm po lexojmë*`balance[Side::Right]`, jo duke e shkruar atë.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Sidoqoftë, në këtë rast `balance[Side::Left]` është sheqer për `*balance.index_mut(Side::Left)`, pasi që po shkruajmë `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Kryen operacionin indeksues të ndryshueshëm (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}