/// Një trait për personalizimin e sjelljes së operatorit `?`.
///
/// Një lloj që zbaton `Try` është ai që ka një mënyrë kanonike për ta parë atë në kushtet e një dikotomie success/failure.
/// Ky trait lejon si nxjerrjen e atyre vlerave të suksesit ose dështimit nga një instancë ekzistuese ashtu edhe krijimin e një instance të re nga vlera e suksesit ose dështimit.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Lloji i kësaj vlere kur shikohet si i suksesshëm.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Lloji i kësaj vlere kur shikohet si i dështuar.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Zbaton operatorin "?".Një kthim i `Ok(t)` do të thotë që ekzekutimi duhet të vazhdojë normalisht, dhe rezultati i `?` është vlera `t`.
    /// Një kthim i `Err(e)` do të thotë që ekzekutimi duhet të branch në `catch` më të brendshëm, ose të kthehet nga funksioni.
    ///
    /// Nëse një rezultat `Err(e)` kthehet, vlera `e` do të jetë "wrapped" në llojin e kthimit të fushës së mbylljes (e cila duhet të zbatojë vetë `Try`).
    ///
    /// Në mënyrë të veçantë, vlera `X::from_error(From::from(e))` kthehet, ku `X` është lloji i kthimit i funksionit mbyllës.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Përfundoni një vlerë gabimi për të ndërtuar rezultatin e përbërë.
    /// Për shembull, `Result::Err(x)` dhe `Result::from_error(x)` janë ekuivalente.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Përfundoni një vlerë të rregullt për të ndërtuar rezultatin e përbërë.
    /// Për shembull, `Result::Ok(x)` dhe `Result::from_ok(x)` janë ekuivalente.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}