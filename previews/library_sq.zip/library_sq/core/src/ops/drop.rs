/// Kod i personalizuar brenda destruktorit.
///
/// Kur një vlerë nuk është më e nevojshme, Rust do të ekzekutojë një "destructor" në atë vlerë.
/// Mënyra më e zakonshme se një vlerë nuk është më e nevojshme është kur ajo del jashtë fushës së veprimit.Shkatërruesit mund të vazhdojnë të vrapojnë në rrethana të tjera, por ne do të përqendrohemi në fushën e shembujve këtu.
/// Për të mësuar në lidhje me disa nga ato raste të tjera, ju lutemi shikoni pjesën [the reference] mbi shkatërruesit.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Ky shkatërrues përbëhet nga dy përbërës:
/// - Një thirrje në `Drop::drop` për atë vlerë, nëse kjo `Drop` trait speciale zbatohet për llojin e tij.
/// - "drop glue" i krijuar automatikisht i cili në mënyrë rekursive thërret shkatërruesit e të gjitha fushave të kësaj vlere.
///
/// Ndërsa Rust i quan automatikisht shkatërruesit e të gjitha fushave të përfshira, ju nuk keni pse të zbatoni `Drop` në shumicën e rasteve.
/// Por ka disa raste kur është i dobishëm, për shembull për llojet që drejtojnë drejtpërdrejt një burim.
/// Ky burim mund të jetë memorie, mund të jetë një përshkrues skedari, mund të jetë një fole rrjeti.
/// Pasi që një vlerë e këtij lloji nuk do të përdoret më, ajo duhet të "clean up" burimin e saj duke liruar kujtesën ose duke mbyllur skedarin ose prizën.
/// Kjo është puna e një shkatërruesi, dhe për këtë arsye puna e `Drop::drop`.
///
/// ## Examples
///
/// Për të parë shkatërruesit në veprim, le të hedhim një vështrim në programin vijues:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust së pari do të telefonojë `Drop::drop` për `_x` dhe më pas për të dy `_x.one` dhe `_x.two`, që do të thotë se ekzekutimi i kësaj do të shtypet
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Edhe nëse heqim zbatimin e `Drop` për `HasTwoDrop`, shkatërruesit e fushave të tij ende quhen.
/// Kjo do të rezultojë në
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Ju nuk mund ta telefononi vetë `Drop::drop`
///
/// Për shkak se `Drop::drop` përdoret për të pastruar një vlerë, mund të jetë e rrezikshme të përdoret kjo vlerë pasi të jetë thirrur metoda.
/// Ndërsa `Drop::drop` nuk merr në pronësi inputin e tij, Rust parandalon keqpërdorimin duke mos ju lejuar të telefononi `Drop::drop` direkt.
///
/// Me fjalë të tjera, nëse jeni përpjekur të thërrisni në mënyrë të qartë `Drop::drop` në shembullin e mësipërm, do të merrni një gabim përpilues.
///
/// Nëse dëshironi të thërrisni në mënyrë të qartë shkatërruesin e një vlere, në vend të tij mund të përdoret [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Renditja e hedhjes
///
/// Sidoqoftë, cili nga dy `HasDrop` tanë bie?Për strukturat, është i njëjti urdhër që deklarohen: së pari `one`, pastaj `two`.
/// Nëse dëshironi ta provoni vetë, mund të modifikoni `HasDrop` më lart për të përmbajtur disa të dhëna, si një numër të plotë, dhe më pas t'i përdorni në `println!` brenda `Drop`.
/// Kjo sjellje është e garantuar nga gjuha.
///
/// Ndryshe nga strukturat, ndryshoret lokale bien në rend të kundërt:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Kjo do të shtypet
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Ju lutemi shikoni [the reference] për rregullat e plota.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` dhe `Drop` janë ekskluzive
///
/// Ju nuk mund të zbatoni të dy [`Copy`] dhe `Drop` në të njëjtin lloj.Llojet që janë `Copy` dyfishohen në mënyrë implicite nga përpiluesi, duke e bërë shumë të vështirë të parashikosh se kur dhe sa shpesh shkatërruesit do të ekzekutohen.
///
/// Si të tillë, këto lloje nuk mund të kenë shkatërrues.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Ekzekuton destruktorin për këtë lloj.
    ///
    /// Kjo metodë quhet në mënyrë implicite kur vlera del jashtë fushës së veprimit dhe nuk mund të thirret në mënyrë të qartë (kjo është gabimi i përpiluesit [E0040]).
    /// Sidoqoftë, funksioni [`mem::drop`] në prelude mund të përdoret për të thirrur zbatimin `Drop` të argumentit.
    ///
    /// Kur është thirrur kjo metodë, `self` nuk është zhvendosur ende.
    /// Kjo ndodh vetëm pasi të mbarojë metoda.
    /// Nëse nuk do të ishte ky rasti, `self` do të ishte një referencë e varur.
    ///
    /// # Panics
    ///
    /// Duke pasur parasysh që një [`panic!`] do të thërrasë `drop` pasi lëshohet, çdo [`panic!`] në një zbatim `drop` ka të ngjarë të abortojë.
    ///
    /// Vini re se edhe nëse kjo panics, vlera konsiderohet të bjerë;
    /// ju nuk duhet të bëni që `drop` të thirret përsëri.
    /// Kjo zakonisht trajtohet automatikisht nga përpiluesi, por kur përdorni një kod të pasigurt, ndonjëherë mund të ndodhë pa dashje, veçanërisht kur përdorni [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}