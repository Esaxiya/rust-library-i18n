use crate::marker::Unsize;

/// Trait që tregon se ky është një tregues ose një mbështjellës për një, ku mund të kryhet pabarazimi në pointee.
///
/// Shihni [DST coercion RFC][dst-coerce] dhe [the nomicon entry on coercion][nomicon-coerce] për më shumë detaje.
///
/// Për llojet e treguesve të integruar, treguesit në `T` do të detyrohen në treguesit në `U` nëse `T: Unsize<U>` duke u kthyer nga një tregues i hollë në një tregues të yndyrës.
///
/// Për llojet e personalizuara, detyrimi këtu funksionon duke detyruar `Foo<T>` në `Foo<U>` me kusht që të ekzistojë një impuls i `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Një impl i tillë mund të shkruhet vetëm nëse `Foo<T>` ka vetëm një fushë të vetme jo-fantomdata që përfshin `T`.
/// Nëse lloji i asaj fushe është `Bar<T>`, duhet të ekzistojë një implementim i `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Shtrëngimi do të funksionojë duke detyruar fushën `Bar<T>` në `Bar<U>` dhe duke plotësuar pjesën tjetër të fushave nga `Foo<T>` për të krijuar një `Foo<U>`.
/// Kjo do të stërvitet në mënyrë efektive në një fushë treguesi dhe do ta detyrojë atë.
///
/// Në përgjithësi, për treguesit inteligjentë ju do të implementoni `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, me një `?Sized` opsional të lidhur në vetë `T`.
/// Për llojet e mbështjellësve që ngulitin drejtpërdrejt `T` si `Cell<T>` dhe `RefCell<T>`, ju mund të implementoni direkt `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Kjo do të lejojë që detyrimet e llojeve si `Cell<Box<T>>` të funksionojnë.
///
/// [`Unsize`][unsize] përdoret për të shënuar llojet të cilat mund të detyrohen në DST nëse qëndrojnë prapa treguesve.Zbatohet automatikisht nga përpiluesi.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * përbën U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* përbën U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Kjo përdoret për sigurinë e objektit, për të kontrolluar që lloji i marrësit të një metode mund të dërgohet.
///
/// Një shembull i zbatimit të trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}