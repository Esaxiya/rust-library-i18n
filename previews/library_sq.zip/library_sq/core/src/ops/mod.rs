//! Operatorët e mbingarkuar.
//!
//! Zbatimi i këtyre traits ju lejon të mbingarkoni operatorë të caktuar.
//!
//! Disa nga këto traits importohen nga prelude, kështu që ato janë të disponueshme në çdo program Rust.Vetëm operatorët e mbështetur nga traits mund të mbingarkohen.
//! Për shembull, operatori shtesë (`+`) mund të mbingarkohet përmes [`Add`] trait, por meqenëse operatori i caktimit (`=`) nuk ka mbështetje trait, nuk ka asnjë mënyrë për të mbingarkuar semantikën e tij.
//! Për më tepër, ky modul nuk ofron ndonjë mekanizëm për krijimin e operatorëve të rinj.
//! Nëse kërkohet mbingarkesë pa karakter ose operatorë të personalizuar, duhet të shikoni drejt makrove ose shtojcave të përpiluesit për të zgjeruar sintaksën e Rust.
//!
//! Zbatimet e operatorit traits duhet të jenë të papritura në kontekstet e tyre përkatëse, duke mbajtur parasysh kuptimet e tyre të zakonshme dhe [operator precedence].
//! Për shembull, gjatë implementimit të [`Mul`], operacioni duhet të ketë ngjashmëri me shumëzimin (dhe të ndajë vetitë e pritura si shoqërimi).
//!
//! Vini re se operatorët `&&` dhe `||` lidhin shkurt, dmth., Ata vlerësojnë operandin e tyre të dytë vetëm nëse kontribuon në rezultat.Meqenëse kjo sjellje nuk është e zbatueshme nga traits, `&&` dhe `||` nuk mbështeten si operatorë të mbingarkueshëm.
//!
//! Shumë prej operatorëve marrin operandët e tyre sipas vlerës.Në kontekste jo gjenerike që përfshijnë lloje të integruara, kjo zakonisht nuk është problem.
//! Sidoqoftë, përdorimi i këtyre operatorëve në kodin gjenerik, kërkon pak vëmendje nëse vlerat duhet të ripërdoren në krahasim me lejimin e operatorëve që t'i konsumojnë ato.Një opsion është që të përdorni herë pas here [`clone`].
//! Një opsion tjetër është të mbështeteni në llojet e përfshira duke siguruar zbatime shtesë të operatorit për referenca.
//! Për shembull, për një tip të përcaktuar nga përdoruesi `T` i cili supozohet se mbështet shtimin, është ndoshta një ide e mirë që të dy `T` dhe `&T` të zbatojnë traits [`Add<T>`][`Add`] dhe [`Add<&T>`][`Add`] në mënyrë që kodi gjenerik të mund të shkruhet pa klonim të panevojshëm.
//!
//!
//! # Examples
//!
//! Ky shembull krijon një strukturë `Point` që zbaton [`Add`] dhe [`Sub`], dhe pastaj demonstron mbledhjen dhe zbritjen e dy Pikave `.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Shihni dokumentacionin për secilin trait për një zbatim shembull.
//!
//! [`Fn`], [`FnMut`] dhe [`FnOnce`] traits implementohen nga lloje që mund të thirren si funksione.Vini re se [`Fn`] merr `&self`, [`FnMut`] merr `&mut self` dhe [`FnOnce`] merr `self`.
//! Këto korrespondojnë me tre llojet e metodave që mund të thirren në një rast: thirrje për referim, thirrje për referim të ndryshueshëm dhe thirrje për vlerë.
//! Përdorimi më i zakonshëm i këtyre traits është të veprojnë si kufij të funksioneve të nivelit më të lartë që marrin funksione ose mbyllje si argumente.
//!
//! Marrja e një [`Fn`] si një parametër:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Marrja e një [`FnMut`] si një parametër:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Marrja e një [`FnOnce`] si një parametër:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` konsumon variablat e kapur, kështu që nuk mund të ekzekutohet më shumë se një herë
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Përpjekja për të thirrur `func()` përsëri do të hedhë një gabim `use of moved value` për `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` nuk mund të thirret më në këtë pikë
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;