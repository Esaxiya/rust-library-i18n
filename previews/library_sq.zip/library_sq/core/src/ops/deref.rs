/// Përdoret për operacione të palëvizshme të referimit, si `*v`.
///
/// Përveç që përdoret për operacione të qarta deferencimi me operatorin (unary) `*` në kontekste të pandryshueshme, `Deref` përdoret gjithashtu në mënyrë implicite nga përpiluesi në shumë rrethana.
/// Ky mekanizëm quhet ['`Deref` coercion'][more].
/// Në kontekste të ndryshueshme, përdoret [`DerefMut`].
///
/// Zbatimi i `Deref` për treguesit inteligjentë e bën të përshtatshëm hyrjen në të dhënat prapa tyre, për këtë arsye ata implementojnë `Deref`.
/// Nga ana tjetër, rregullat në lidhje me `Deref` dhe [`DerefMut`] janë krijuar posaçërisht për të akomoduar treguesit inteligjentë.
/// Për shkak të kësaj,**`Deref` duhet të implementohet vetëm për tregues të mençur** për të shmangur konfuzionin.
///
/// Për arsye të ngjashme,**ky trait nuk duhet të dështojë kurrë**.Dështimi gjatë referimit mund të jetë jashtëzakonisht konfuz kur `Deref` thirret në mënyrë implicite.
///
/// # Më shumë mbi shtrëngimin `Deref`
///
/// Nëse `T` zbaton `Deref<Target = U>`, dhe `x` është një vlerë e llojit `T`, atëherë:
///
/// * Në kontekste të pandryshueshme, `*x` (ku `T` nuk është as referencë, as tregues i papërpunuar) është ekuivalent me `* Deref::deref(&x)`.
/// * Vlerat e tipit `&T` janë detyruar në vlerat e tipit `&U`
/// * `T` në mënyrë implicite zbaton të gjitha metodat (immutable) të tipit `U`.
///
/// Për më shumë detaje, vizitoni [the chapter in *The Rust Programming Language*][book] si dhe seksionet e referencës në [the dereference operator][ref-deref-op], [method resolution] dhe [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Një strukturë me një fushë të vetme e cila është e arritshme duke referuar strukturën.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Lloji që rezulton pas riferencimit.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Çreferencon vlerën.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Përdoret për operacione të paqëndrueshme të referimit, si në `*v = 1;`.
///
/// Përveç që përdoret për operacione të qarta deferencimi me operatorin (unary) `*` në kontekste të paqëndrueshme, `DerefMut` përdoret gjithashtu në mënyrë implicite nga përpiluesi në shumë rrethana.
/// Ky mekanizëm quhet ['`Deref` coercion'][more].
/// Në kontekste të pandryshueshme, përdoret [`Deref`].
///
/// Zbatimi i `DerefMut` për treguesit inteligjentë bën që mutacioni i të dhënave që qëndrojnë pas tyre të jetë i përshtatshëm, prandaj ata implementojnë `DerefMut`.
/// Nga ana tjetër, rregullat në lidhje me [`Deref`] dhe `DerefMut` janë krijuar posaçërisht për të akomoduar treguesit inteligjentë.
/// Për shkak të kësaj,**`DerefMut` duhet të zbatohet vetëm për treguesit inteligjentë** për të shmangur konfuzionin.
///
/// Për arsye të ngjashme,**ky trait nuk duhet të dështojë kurrë**.Dështimi gjatë referimit mund të jetë jashtëzakonisht konfuz kur `DerefMut` thirret në mënyrë implicite.
///
/// # Më shumë mbi shtrëngimin `Deref`
///
/// Nëse `T` zbaton `DerefMut<Target = U>`, dhe `x` është një vlerë e llojit `T`, atëherë:
///
/// * Në kontekste të ndryshueshme, `*x` (ku `T` nuk është as referencë, as tregues i papërpunuar) është ekuivalent me `* DerefMut::deref_mut(&mut x)`.
/// * Vlerat e tipit `&mut T` janë detyruar në vlerat e tipit `&mut U`
/// * `T` në mënyrë implicite zbaton të gjitha metodat (mutable) të tipit `U`.
///
/// Për më shumë detaje, vizitoni [the chapter in *The Rust Programming Language*][book] si dhe seksionet e referencës në [the dereference operator][ref-deref-op], [method resolution] dhe [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Një strukturë me një fushë të vetme e cila mund të modifikohet duke referuar strukturën.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Në mënyrë të pandryshueshme çrregullon vlerën.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Tregon që një strukturë mund të përdoret si një marrës metode, pa veçorinë `arbitrary_self_types`.
///
/// Kjo zbatohet nga llojet e treguesve stdlib si `Box<T>`, `Rc<T>`, `&T` dhe `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}