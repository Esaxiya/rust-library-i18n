use crate::marker::Unpin;
use crate::pin::Pin;

/// Rezultati i rifillimit të gjeneratorit.
///
/// Ky enum kthehet nga metoda `Generator::resume` dhe tregon vlerat e mundshme të kthimit të një gjeneratori.
/// Aktualisht kjo korrespondon ose me një pikë pezullimi (`Yielded`) ose me një pikë përfundimi (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Gjeneratori i pezulluar me një vlerë.
    ///
    /// Kjo gjendje tregon që një gjenerator është pezulluar dhe zakonisht korrespondon me një deklaratë `yield`.
    /// Vlera e dhënë në këtë variant korrespondon me shprehjen e kaluar në `yield` dhe lejon gjeneratorët të japin një vlerë sa herë që japin.
    ///
    ///
    Yielded(Y),

    /// Gjeneratori i kompletuar me një vlerë kthyese.
    ///
    /// Kjo gjendje tregon që një gjenerator ka përfunduar ekzekutimin me vlerën e dhënë.
    /// Sapo një gjenerator të kthejë `Complete` konsiderohet një gabim i programuesit për të thirrur përsëri `resume`.
    ///
    Complete(R),
}

/// trait i implementuar nga llojet e gjeneratorëve të ndërtuar.
///
/// Gjeneratorët, të referuar zakonisht si korutina, aktualisht janë një tipar i gjuhës eksperimentale në Rust.
/// Shtuar në gjeneratorët [RFC 2033] aktualisht synohet të sigurojë kryesisht një bllok ndërtimi për sintaksën async/await por ka të ngjarë të shtrihet edhe në sigurimin e një përkufizimi ergonomik për përsëritësit dhe primitivët e tjerë.
///
///
/// Sintaksa dhe semantika për gjeneratorët është e paqëndrueshme dhe do të kërkojë një RFC të mëtejshëm për stabilizim.Në këtë kohë, sidoqoftë, sintaksa është si mbyllja:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Më shumë dokumentacion i gjeneratorëve mund të gjenden në librin e paqëndrueshëm.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Lloji i vlerës që jep ky gjenerator.
    ///
    /// Ky lloj i lidhur korrespondon me shprehjen `yield` dhe vlerat të cilat lejohen të kthehen sa herë që jep një gjenerator.
    ///
    /// Për shembull, një iterator-si-gjenerator ka të ngjarë ta ketë këtë lloj si `T`, lloji që përsëritet.
    ///
    type Yield;

    /// Lloji i vlerës që kthen gjeneratori.
    ///
    /// Kjo korrespondon me llojin e kthyer nga një gjenerator ose me një deklaratë `return` ose në mënyrë implicite si shprehja e fundit e një gjeneratori fjalë për fjalë.
    /// Për shembull futures do ta përdorte këtë si `Result<T, E>` pasi përfaqëson një future të përfunduar.
    ///
    ///
    type Return;

    /// Rifillon ekzekutimin e këtij gjeneratori.
    ///
    /// Ky funksion do të rifillojë ekzekutimin e gjeneratorit ose do të fillojë ekzekutimin nëse nuk e ka bërë tashmë.
    /// Kjo thirrje do të kthehet përsëri në pikën e fundit të pezullimit të gjeneratorit, duke rifilluar ekzekutimin nga `yield` i fundit.
    /// Gjeneratori do të vazhdojë ekzekutimin derisa të jepet ose të kthehet, në këtë pikë ky funksion do të kthehet.
    ///
    /// # Vlera e kthimit
    ///
    /// Enumi `GeneratorState` i kthyer nga ky funksion tregon se në çfarë gjendje është gjeneratori pas kthimit.
    /// Nëse varianti `Yielded` kthehet, gjeneratori ka arritur një pikë pezullimi dhe një vlerë është dhënë.
    /// Gjeneratorët në këtë gjendje janë në dispozicion për rifillim në një pikë të mëvonshme.
    ///
    /// Nëse `Complete` kthehet, atëherë gjeneratori ka përfunduar plotësisht me vlerën e dhënë.Invshtë e pavlefshme që gjeneratori të rifillojë përsëri.
    ///
    /// # Panics
    ///
    /// Ky funksion mund të jetë panic nëse thirret pasi të jetë kthyer më parë varianti `Complete`.
    /// Ndërsa fjalë për fjalë të gjeneratorit në gjuhë janë të garantuara për panic që të rifillojnë pas `Complete`, kjo nuk është e garantuar për të gjitha implementimet e `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}