/// Versioni i operatorit të thirrjes që merr një marrës të pandryshueshëm.
///
/// Instancat e `Fn` mund të thirren në mënyrë të përsëritur pa gjendje mutacioni.
///
/// *Ky trait (`Fn`) nuk duhet të ngatërrohet me [function pointers] (`fn`).*
///
/// `Fn` zbatohet automatikisht nga mbylljet të cilat marrin vetëm referenca të pandryshueshme për variablat e kapur ose nuk kapin asgjë fare, si dhe (safe) [function pointers] (me disa paralajmërime, shihni dokumentacionin e tyre për më shumë detaje).
///
/// Për më tepër, për çdo lloj `F` që zbaton `Fn`, `&F` zbaton edhe `Fn`.
///
/// Meqenëse të dy [`FnMut`] dhe [`FnOnce`] janë supertraits të `Fn`, çdo rast i `Fn` mund të përdoret si një parametër ku pritet një [`FnMut`] ose [`FnOnce`].
///
/// Përdorni `Fn` si një lidhje kur dëshironi të pranoni një parametër të tipit të ngjashëm me funksionin dhe duhet ta thirrni atë në mënyrë të përsëritur dhe pa gjendje mutacioni (p.sh., kur e quani njëkohësisht).
/// Nëse nuk ju duhen kërkesa të tilla strikte, përdorni [`FnMut`] ose [`FnOnce`] si kufij.
///
/// Shihni [chapter on closures in *The Rust Programming Language*][book] për më shumë informacion mbi këtë temë.
///
/// Gjithashtu për t`u theksuar është sintaksa speciale për `Fn` traits (p.sh.
/// `Fn(usize, bool) -> përdorim`).Ata që janë të interesuar për detajet teknike të kësaj mund t'i referohen [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Thirrja e një mbylljeje
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Përdorimi i një parametri `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // në mënyrë që regex të mbështetet në atë `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Kryen operacionin e thirrjes.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Versioni i operatorit të thirrjes që merr një marrës të ndryshueshëm.
///
/// Instancat e `FnMut` mund të thirren në mënyrë të përsëritur dhe mund të ndryshojnë gjendjen.
///
/// `FnMut` zbatohet automatikisht nga mbylljet të cilat marrin referenca të ndryshueshme ndaj variablave të kapur, si dhe të gjitha llojet që implementojnë [`Fn`], p.sh., (safe) [function pointers] (pasi `FnMut` është një supertrait i [`Fn`]).
/// Për më tepër, për çdo lloj `F` që zbaton `FnMut`, `&mut F` zbaton edhe `FnMut`.
///
/// Meqenëse [`FnOnce`] është një supertrait i `FnMut`, çdo rast i `FnMut` mund të përdoret aty ku pritet një [`FnOnce`], dhe meqenëse [`Fn`] është një nën-ngushticë e `FnMut`, çdo rast i [`Fn`] mund të përdoret aty ku pritet `FnMut`.
///
/// Përdorni `FnMut` si një lidhje kur doni të pranoni një parametër të tipit të ngjashëm me funksionin dhe duhet ta telefononi atë në mënyrë të përsëritur, ndërsa lejoni që ai të ndryshojë gjendjen.
/// Nëse nuk doni që parametri të ndryshojë gjendjen, përdorni [`Fn`] si një lidhje;nëse nuk keni nevojë ta telefononi në mënyrë të përsëritur, përdorni [`FnOnce`].
///
/// Shihni [chapter on closures in *The Rust Programming Language*][book] për më shumë informacion mbi këtë temë.
///
/// Gjithashtu për t`u theksuar është sintaksa speciale për `Fn` traits (p.sh.
/// `Fn(usize, bool) -> përdorim`).Ata që janë të interesuar për detajet teknike të kësaj mund t'i referohen [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Thirrja e një mbylljeje të kapur në mënyrë të paqëndrueshme
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Përdorimi i një parametri `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // në mënyrë që regex të mbështetet në atë `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Kryen operacionin e thirrjes.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Versioni i operatorit të thirrjes që merr një marrës nën-vlerë.
///
/// Raste të `FnOnce` mund të thirren, por mund të mos jenë të thirrura shumë herë.Për shkak të kësaj, nëse e vetmja gjë që dihet për një lloj është se ai zbaton `FnOnce`, ai mund të thirret vetëm një herë.
///
/// `FnOnce` zbatohet automatikisht nga mbylljet që mund të konsumojnë ndryshoret e kapura, si dhe të gjitha llojet që implementojnë [`FnMut`], p.sh., (safe) [function pointers] (pasi `FnOnce` është një supertrait i [`FnMut`]).
///
///
/// Meqenëse të dy [`Fn`] dhe [`FnMut`] janë nënshtresa të `FnOnce`, çdo rast i [`Fn`] ose [`FnMut`] mund të përdoret aty ku pritet një `FnOnce`.
///
/// Përdorni `FnOnce` si një lidhje kur dëshironi të pranoni një parametër të tipit të ngjashëm me funksionin dhe duhet ta telefononi vetëm një herë.
/// Nëse duhet të telefononi parametrin në mënyrë të përsëritur, përdorni [`FnMut`] si një lidhje;nëse gjithashtu ju nevojitet që të mos ndryshoni gjendjen, përdorni [`Fn`].
///
/// Shihni [chapter on closures in *The Rust Programming Language*][book] për më shumë informacion mbi këtë temë.
///
/// Gjithashtu për t`u theksuar është sintaksa speciale për `Fn` traits (p.sh.
/// `Fn(usize, bool) -> përdorim`).Ata që janë të interesuar për detajet teknike të kësaj mund t'i referohen [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Përdorimi i një parametri `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` konsumon variablat e kapur, kështu që nuk mund të ekzekutohet më shumë se një herë.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Përpjekja për të thirrur `func()` përsëri do të hedhë një gabim `use of moved value` për `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` nuk mund të thirret më në këtë pikë
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // në mënyrë që regex të mbështetet në atë `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Lloji i kthyer pasi përdoret operatori i thirrjes.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Kryen operacionin e thirrjes.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}