#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Një future përfaqëson një llogaritje asinkron.
///
/// Një future është një vlerë që mund të mos ketë mbaruar ende llogaritjen.
/// Ky lloj "asynchronous value" bën të mundur që një fije të vazhdojë të bëjë punë të dobishme ndërsa pret që vlera të vihet në dispozicion.
///
///
/// # Metoda `poll`
///
/// Metoda thelbësore e future, `poll`,*përpiqet* për të zgjidhur future në një vlerë përfundimtare.
/// Kjo metodë nuk bllokon nëse vlera nuk është gati.
/// Në vend të kësaj, detyra aktuale është planifikuar të zgjohet kur është e mundur të bëhet përparim i mëtejshëm duke "sondazh" përsëri.
/// `context` i kaluar në metodën `poll` mund të sigurojë një [`Waker`], i cili është një dorezë për zgjimin e detyrës aktuale.
///
/// Kur përdorni një future, zakonisht nuk do të telefononi `poll` direkt, por në vend të kësaj vlera `.await`.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Lloji i vlerës së prodhuar pas përfundimit.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Përpjekje për të zgjidhur future në një vlerë përfundimtare, duke regjistruar detyrën aktuale për zgjim nëse vlera nuk është ende e disponueshme.
    ///
    /// # Vlera e kthimit
    ///
    /// Ky funksion kthen:
    ///
    /// - [`Poll::Pending`] nëse future nuk është ende gati
    /// - [`Poll::Ready(val)`] me rezultatin `val` të kësaj future nëse përfundon me sukses.
    ///
    /// Pasi të ketë mbaruar një future, klientët nuk duhet ta `poll` atë përsëri.
    ///
    /// Kur një future nuk është ende gati, `poll` kthen `Poll::Pending` dhe ruan një klon të [`Waker`] të kopjuar nga [`Context`] i tanishëm.
    /// Ky [`Waker`] zgjohet atëherë kur future mund të bëjë përparim.
    /// Për shembull, një future që pret që një fole të bëhet e lexueshme do të telefononte `.clone()` në [`Waker`] dhe do ta ruante atë.
    /// Kur një sinjal arrin diku tjetër që tregon se foleja është e lexueshme, thirret [`Waker::wake`] dhe detyra e folesë future zgjohet.
    /// Pasi një detyrë të jetë zgjuar, ajo duhet të përpiqet të `poll` future përsëri, e cila mund të prodhojë ose jo një vlerë përfundimtare.
    ///
    /// Vini re se në thirrjet e shumta në `poll`, vetëm [`Waker`] nga [`Context`] i kaluar në telefonatën më të fundit duhet të planifikohet për të marrë një zgjim.
    ///
    /// # Karakteristikat e kohës së ekzekutimit
    ///
    /// Vetëm Futures janë *inerte*;ata duhet të *sondohen* në mënyrë aktive për të bërë përparim, që do të thotë që sa herë që detyra aktuale zgjohet, ajo duhet të rindotë në mënyrë aktive në pritje të futures për të cilën ajo ende ka interes.
    ///
    /// Funksioni `poll` nuk thirret në mënyrë të përsëritur në një lak të ngushtë-përkundrazi, ai duhet të thirret vetëm kur future tregon se është gati të bëjë përparim (duke telefonuar `wake()`).
    /// Nëse jeni të njohur me sykalimet `poll(2)` ose `select(2)` në Unix vlen të përmendet se futures zakonisht *nuk* vuajnë të njëjtat probleme të "all wakeups must poll all events";ato janë më shumë si `epoll(4)`.
    ///
    /// Një zbatim i `poll` duhet të përpiqet të kthehet shpejt dhe nuk duhet të bllokojë.Kthimi shpejt parandalon bllokimin e panevojshëm të fijeve ose sytheve të ngjarjeve.
    /// Nëse dihet para kohe që një thirrje për `poll` mund të përfundojë duke marrë pak kohë, puna duhet të shkarkohet në një pishinë me fije (ose diçka të ngjashme) për të siguruar që `poll` mund të kthehet shpejt.
    ///
    /// # Panics
    ///
    /// Pasi të ketë përfunduar një future (kthyer `Ready` nga `poll`), thirrja e metodës `poll` përsëri mund të panic, të bllokojë përgjithmonë, ose të shkaktojë lloje të tjera problemesh;`Future` trait nuk vendos kërkesa për efektet e një thirrjeje të tillë.
    /// Sidoqoftë, pasi metoda `poll` nuk është e shënuar `unsafe`, zbatohen rregullat e zakonshme të Rust: thirrjet nuk duhet të shkaktojnë asnjëherë sjellje të papërcaktuar (prishja e kujtesës, përdorimi i pasaktë i funksioneve `unsafe` ose të ngjashme), pavarësisht nga gjendja e future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}