#![stable(feature = "futures_api", since = "1.36.0")]

//! Vlerat asinkrone.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Ky lloj është i nevojshëm sepse:
///
/// a) Gjeneratorët nuk mund të implementojnë `for<'a, 'b> Generator<&'a mut Context<'b>>`, prandaj duhet të kalojmë një tregues të papërpunuar (shih <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Treguesit e papërpunuar dhe `NonNull` nuk janë `Send` ose `Sync`, kështu që do të bënte çdo future non-Send/Sync gjithashtu, dhe ne nuk e duam atë.
///
/// Thjesht thjeshton uljen e HIR të `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Përfundoni një gjenerator në një future.
///
/// Ky funksion kthen një `GenFuture` poshtë, por e fsheh atë në `impl Trait` për të dhënë mesazhe më të mira gabimi (`impl Future` sesa `GenFuture<[closure.....]>`).
///
// Ky është `const` për të shmangur gabime shtesë pasi të shërohemi nga `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Ne mbështetemi në faktin se async/await futures janë të paluajtshme në mënyrë që të krijojnë hua vetë-referuese në gjeneratorin themelor.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SIGURIA: E sigurt sepse jemi !Unpin + !Drop, dhe ky është vetëm një parashikim fushor.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Rifilloni gjeneratorin, duke e kthyer `&mut Context` në një tregues të papërpunuar `NonNull`.
            // Ulja `.await` do ta kthejë atë në mënyrë të sigurt në një `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SIGURIA: thirrësi duhet të garantojë që `cx.0` është një tregues i vlefshëm
    // që plotëson të gjitha kërkesat për një referencë të ndryshueshme.
    unsafe { &mut *cx.0.as_ptr().cast() }
}