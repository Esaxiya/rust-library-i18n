//! Vlerat dembele dhe inicimi një herë i të dhënave statike.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Një qelizë e cila mund të shkruhet vetëm një herë.
///
/// Ndryshe nga `RefCell`, një `OnceCell` ofron vetëm referenca të ndara `&T` për vlerën e tij.
/// Ndryshe nga `Cell`, një `OnceCell` nuk kërkon kopjimin ose zëvendësimin e vlerës për të hyrë në të.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // E pandryshueshme: e shkruar më së shumti një herë.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Krijon një qelizë të re bosh.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Merr referencën për vlerën themelore.
    ///
    /// Kthen `None` nëse qeliza është bosh.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // SIGURIA: E sigurt për shkak të invariancës së 'brendshme'
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Merr referencën e ndryshueshme për vlerën themelore.
    ///
    /// Kthen `None` nëse qeliza është bosh.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // SIGURIA: E sigurt sepse kemi qasje unike
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Vendos përmbajtjen e qelizës në `value`.
    ///
    /// # Errors
    ///
    /// Kjo metodë kthen `Ok(())` nëse qeliza ishte bosh dhe `Err(value)` nëse ishte e mbushur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // SIGURIA: E sigurt sepse nuk mund të kemi mbivendosje të huazimeve të ndryshueshme
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // SIGURIA: Ky është i vetmi vend ku vendosim vendin e caktuar, pa gara
        // për shkak të reentrancy/concurrency janë të mundshme, dhe ne kemi kontrolluar që foleja është aktualisht `None`, kështu që ky shkrim mban të pandryshueshmen e "brendshme".
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Merr përmbajtjen e qelizës, duke e iniciuar atë me `f` nëse qeliza ishte e zbrazët.
    ///
    /// # Panics
    ///
    /// Nëse `f` panics, panic përhapet në telefonues, dhe qeliza mbetet e pa iniciale.
    ///
    ///
    /// Shtë një gabim që të iniciojmë përsëri qelizën nga `f`.Bërja e kësaj rezulton në një panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Merr përmbajtjen e qelizës, duke e iniciuar atë me `f` nëse qeliza ishte e zbrazët.
    /// Nëse qeliza ishte bosh dhe `f` dështoi, një gabim kthehet.
    ///
    /// # Panics
    ///
    /// Nëse `f` panics, panic përhapet në telefonues, dhe qeliza mbetet e pa iniciale.
    ///
    ///
    /// Shtë një gabim që të iniciojmë përsëri qelizën nga `f`.Bërja e kësaj rezulton në një panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Vini re se *disa* forma të inicimit të rimbursimit mund të çojnë në UB (shih testin `reentrant_init`).
        // Unë besoj se thjesht heqja e këtij `assert`, ndërsa mbajtja e `set/get` do të ishte e shëndoshë, por panic i duket më mirë sesa të përdorë në heshtje një vlerë të vjetër.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Konsumon qelizën, duke kthyer vlerën e mbështjellë.
    ///
    /// Kthen `None` nëse qeliza ishte bosh.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Për shkak se `into_inner` merr `self` me vlerë, përpiluesi verifikon statistikisht se nuk është huazuar aktualisht.
        // Pra, është e sigurt të lëvizësh `Option<T>`.
        self.inner.into_inner()
    }

    /// Merr vlerën e këtij `OnceCell`, duke e zhvendosur përsëri në një gjendje të pa inicializuar.
    ///
    /// Nuk ka efekt dhe kthen `None` nëse `OnceCell` nuk është iniciuar.
    ///
    /// Siguria garantohet duke kërkuar një referencë të ndryshueshme.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Një vlerë e cila inicializohet në hyrjen e parë.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   inicializimi i gatshëm
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Krijon një vlerë të re dembel me funksionin e dhënë inicializues.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Forcon vlerësimin e kësaj vlere dembele dhe kthen një referencë në rezultat.
    ///
    ///
    /// Kjo është ekuivalente me implikimin `Deref`, por është e qartë.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Krijon një vlerë të re dembele duke përdorur `Default` si funksion fillestar.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}