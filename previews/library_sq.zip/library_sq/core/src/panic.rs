//! Mbështetje Panic në bibliotekën standarde.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Një strukturë që ofron informacion në lidhje me një panic.
///
/// `PanicInfo` struktura i kalon një panic hook të vendosur nga funksioni [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Kthen ngarkesën e lidhur me panic.
    ///
    /// Kjo do të jetë zakonisht, por jo gjithmonë, një `&'static str` ose [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Nëse makro `panic!` nga `core` crate (jo nga `std`) është përdorur me një varg formatimi dhe disa argumente shtesë, kthen atë mesazh të gatshëm për t'u përdorur për shembull me [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Kthen informacionin rreth vendndodhjes nga e ka origjinën panic, nëse është i disponueshëm.
    ///
    /// Kjo metodë aktualisht do të kthejë gjithmonë [`Some`], por kjo mund të ndryshojë në versionet future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Nëse kjo ndryshohet për të kthyer ndonjëherë Asnjë,
        // merreni me atë rast në std::panicking::default_hook dhe std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ne nuk mund të përdorim downcast_ref: :<String>() këtu
        // meqenëse String nuk është i disponueshëm në libcore!
        // Ngarkesa është një Varg kur `std::panic!` thirret me shumë argumente, por në atë rast mesazhi është gjithashtu i disponueshëm.
        //

        self.location.fmt(formatter)
    }
}

/// Një strukturë që përmban informacion në lidhje me vendndodhjen e një panic.
///
/// Kjo strukturë është krijuar nga [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Krahasimet për barazinë dhe renditjen bëhen në skedar, rresht, pastaj përparësi kolone.
/// Skedarët krahasohen si vargje, jo `Path`, gjë që mund të jetë e papritur.
/// Shikoni dokumentacionin e ["Vendndodhja: : skedari"] për më shumë diskutime.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Kthen vendndodhjen burimore të telefonuesit të këtij funksioni.
    /// Nëse thirrësi i atij funksioni është shënuar, atëherë vendndodhja e tij e thirrjes do të kthehet, e kështu me radhë deri në pirg në telefonatën e parë brenda një organi funksioni jo të gjurmuar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Kthen [`Location`] në të cilin quhet.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Kthen një [`Location`] nga përkufizimi i këtij funksioni.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // ekzekutimi i të njëjtit funksion të pakontrolluar në një vendndodhje tjetër na jep të njëjtin rezultat
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ekzekutimi i funksionit të gjurmuar në një vend tjetër prodhon një vlerë tjetër
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Kthen emrin e skedarit burimor nga e ka zanafillën panic.
    ///
    /// # `&str`, jo `&Path`
    ///
    /// Emri i kthyer i referohet një rruge burimi në sistemin e përpilimit, por nuk është e vlefshme ta përfaqësosh këtë direkt si `&Path`.
    /// Kodi i përpiluar mund të ekzekutohet në një sistem tjetër me një zbatim tjetër `Path` sesa sistemi që ofron përmbajtjen dhe kjo bibliotekë aktualisht nuk ka një lloj tjetër "host path".
    ///
    /// Sjellja më befasuese ndodh kur skedari "the same" është i arritshëm përmes shtigjeve të shumta në sistemin e modulit (zakonisht duke përdorur atributin `#[path = "..."]` ose të ngjashëm), gjë që mund të shkaktojë që kodi identik të kthejë vlera të ndryshme nga ky funksion.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Kjo vlerë nuk është e përshtatshme për kalimin te `Path::new` ose konstruktorë të ngjashëm kur platforma pritëse dhe platforma e synuar ndryshojnë.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Kthen numrin e linjës nga e ka origjinën panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Kthen kolonën nga e cila ka origjinën panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Një trait i brendshëm i përdorur nga libstd për të kaluar të dhëna nga libstd në `panic_unwind` dhe kohëzgjatjet e tjera të panic.
/// Nuk synohet të stabilizohet së shpejti, mos e përdorni.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Merrni pronësinë e plotë të përmbajtjes.
    /// Lloji i kthimit është në të vërtetë `Box<dyn Any + Send>`, por ne nuk mund ta përdorim `Box` në libcore.
    ///
    /// Pasi të quhet kjo metodë, vetëm disa vlera të paracaktuara bedel kanë mbetur në `self`.
    /// Thirrja e kësaj metode dy herë, ose thirrja `get` pasi thirrja e kësaj metode, është një gabim.
    ///
    /// Argumenti është huazuar sepse panic koha e ekzekutimit (`__rust_start_panic`) merr vetëm një `dyn BoxMeUp` të huazuar.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Thjesht huazoni përmbajtjen.
    fn get(&mut self) -> &(dyn Any + Send);
}