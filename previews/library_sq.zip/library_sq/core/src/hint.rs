#![stable(feature = "core_hint", since = "1.27.0")]

//! Lë të kuptohet se për përpiluesin që ndikon në mënyrën se si duhet të emetohet ose optimizohet kodi.
//! Sugjerimet mund të jenë koha e përpilimit ose koha e ekzekutimit.

use crate::intrinsics;

/// Informon përpiluesin se kjo pikë në kod nuk është e arritshme, duke mundësuar optimizime të mëtejshme.
///
/// # Safety
///
/// Arritja e këtij funksioni është plotësisht *sjellje e papërcaktuar*(UB).Në veçanti, përpiluesi supozon se e gjithë UB nuk duhet të ndodhë kurrë, dhe për këtë arsye do të eleminojë të gjitha degët që arrijnë në një thirrje në `unreachable_unchecked()`.
///
/// Ashtu si të gjitha rastet e UB, nëse kjo supozim rezulton e gabuar, dmth. Thirrja `unreachable_unchecked()` është në të vërtetë e arritshme midis të gjitha rrjedhave të mundshme të kontrollit, përpiluesi do të zbatojë strategjinë e gabuar të optimizimit dhe ndonjëherë mund edhe të korruptojë kodin në dukje të palidhur, duke shkaktuar vështirësi-për të korrigjuar problemet.
///
///
/// Përdoreni këtë funksion vetëm kur mund të provoni se kodi nuk do ta thërrasë kurrë.
/// Përndryshe, konsideroni përdorimin e makros [`unreachable!`], e cila nuk lejon optimizime, por do të panic kur ekzekutohet.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` është gjithmonë pozitiv (jo zero), prandaj `checked_div` nuk do të kthehet më `None`.
/////
///     // Prandaj, branch tjetër nuk është e arritshme.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SIGURIA: kontrata e sigurisë për `intrinsics::unreachable` duhet
    // mbështetet nga thirrësi.
    unsafe { intrinsics::unreachable() }
}

/// Lëshon një udhëzim makinerie për të sinjalizuar procesorin se po ekzekutohet në një spin-loje të pritur të zënë ("bllokimi i rrotullimit").
///
/// Pas marrjes së sinjalit spin-loop, procesori mund të zgjedhë sjelljen e tij, për shembull, duke kursyer energji ose duke ndërruar fijet hyper.
///
/// Ky funksion është i ndryshëm nga [`thread::yield_now`] i cili i jep direkt kalendarit të sistemit, ndërsa `spin_loop` nuk ndërvepron me sistemin operativ.
///
/// Një rast i zakonshëm përdorimi për `spin_loop` është implementimi i tjerrjes optimiste të kufizuar në një lak CAS në primitivët e sinkronizimit.
/// Për të shmangur problemet si përmbysja e përparësisë, rekomandohet fuqimisht që cikli i rrotullimit të ndërpritet pasi të bëhet një sasi e kufizuar e përsëritjeve dhe të bëhet një bllokim i duhur bllokues.
///
///
/// **Shënim**: Në platformat që nuk mbështesin marrjen e sugjerimeve të spin-loop, ky funksion nuk bën asgjë fare.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Një vlerë e përbashkët atomike që fijet do të përdorin për të koordinuar
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Në një sfond sfondi ne përfundimisht do të vendosim vlerën
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Bëni disa punë, pastaj bëjeni vlerën të gjallë
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Kthehu në fillin tonë aktual, ne presim që vlera të vendoset
/// while !live.load(Ordering::Acquire) {
///     // Spin loop është një aluzion për CPU-në që ne jemi duke pritur, por ndoshta jo për shumë kohë
/////
///     hint::spin_loop();
/// }
///
/// // Vlera është vendosur tani
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SIGURIA: Tërheqësi `cfg` siguron që ne ta ekzekutojmë këtë vetëm në synimet x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SIGURIA: Tërheqësi `cfg` siguron që ne ta ekzekutojmë këtë vetëm në synimet x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SIGURIA: Tërheqësi `cfg` siguron që ne ta ekzekutojmë këtë vetëm në synimet aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SIGURIA: Tërheqësi `cfg` siguron që ne ta ekzekutojmë këtë vetëm në shënjestrat e krahut
            // me mbështetje për tiparin v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Një funksion identiteti që *__ lë të kuptohet __* tek përpiluesi për të qenë maksimalisht pesimist për atë që mund të bëjë `black_box`.
///
/// Ndryshe nga [`std::convert::identity`], një përpilues i Rust inkurajohet të supozojë se `black_box` mund të përdorë `dummy` në çdo mënyrë të mundshme të vlefshme për të cilën lejohet kodi Rust pa futur sjellje të padefinuar në kodin thirrës.
///
/// Kjo veti e bën `black_box` të dobishme për shkrimin e kodit në të cilin nuk dëshirohen optimizime të caktuara, siç janë standardet.
///
/// Vini re megjithatë, se `black_box` sigurohet vetëm (dhe mund të sigurohet) vetëm mbi bazën "best-effort".Shkalla në të cilën mund të bllokojë optimizimet mund të ndryshojë në varësi të platformës dhe kodit mbështetës të gjenit të kodit të përdorur.
/// Programet nuk mund të mbështeten në `black_box` për *korrektësi* në asnjë mënyrë.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Ne kemi nevojë për të argumentuar "use" në një farë mënyre LLVM nuk mund të shikojë, dhe për objektivat që e mbështesin atë zakonisht mund të përdorim asamblenë inline për ta bërë këtë.
    // Interpretimi i LLVM për montimin inline është se, pra, është një kuti e zezë.
    // Ky nuk është implementimi më i mirë pasi që ajo ndoshta deoptimizon më shumë sesa duam, por është deri tani mjaftueshëm i mirë.
    //
    //

    #[cfg(not(miri))] // Ky është vetëm një aluzion, kështu që është mirë të kalosh në Miri.
    // SIGURIA: asambleja inline është një no-op.
    unsafe {
        // FIXME: Nuk mund të përdoret `asm!` sepse nuk mbështet MIPS dhe arkitektura të tjera.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}