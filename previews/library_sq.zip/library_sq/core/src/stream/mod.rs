//! Iteracioni asinkron i përbërë.
//!
//! Nëse futures janë vlera asinkrone, atëherë rrjedhat janë përsëritës asinkronë.
//! Nëse e keni gjetur veten me një koleksion asinkron të një lloji, dhe keni nevojë për të kryer një operacion në elementet e koleksionit në fjalë, shpejt do të hasni në 'streams'.
//! Rrymat përdoren shumë në kodin identik asinkron Rust, kështu që ia vlen të njiheni me to.
//!
//! Para se të shpjegojmë më shumë, le të flasim për mënyrën se si është strukturuar ky modul:
//!
//! # Organization
//!
//! Ky modul është organizuar kryesisht nga lloji:
//!
//! * [Traits] janë pjesa kryesore: këto traits përcaktojnë se çfarë lloj rrjedhash ekzistojnë dhe çfarë mund të bësh me to.Metodat e këtyre traits ia vlen të vendosni një kohë shtesë studimi.
//! * Funksionet ofrojnë disa mënyra të dobishme për të krijuar disa rrjedha themelore.
//! * Strukturat shpesh janë llojet e kthimit të metodave të ndryshme në traits të këtij moduli.Zakonisht do të dëshironi të shikoni metodën që krijon `struct`, sesa vetë `struct`.
//! Për më shumë detaje rreth arsyes, shikoni '[Implementing Stream](#implement-stream)'.
//!
//! [Traits]: #traits
//!
//! Kjo eshte!Le të gërmojmë në përrenj.
//!
//! # Stream
//!
//! Zemra dhe shpirti i këtij moduli është [`Stream`] trait.Thelbi i [`Stream`] duket kështu:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Ndryshe nga `Iterator`, `Stream` bën një dallim midis metodës [`poll_next`] që përdoret kur implementon një `Stream`, dhe një metode (to-be-implemented) `next` e cila përdoret kur konsumon një rrjedhë.
//!
//! Konsumatorët e `Stream` duhet të marrin parasysh vetëm `next`, i cili kur thirret, kthen një future i cili jep `Option<Stream::Item>`.
//!
//! future i kthyer nga `next` do të japë `Some(Item)` për sa kohë që ka elemente, dhe pasi të jenë shteruar të gjithë, do të japë `None` për të treguar që përsëritja ka mbaruar.
//! Nëse jemi duke pritur diçka asinkrone për të zgjidhur, future do të presë derisa transmetimi të jetë gati të japë përsëri.
//!
//! Transmetimet individuale mund të zgjedhin të rifillojnë përsëritjen, dhe kështu thirrja përsëri `next` mund të japë ose jo përfundimisht `Some(Item)` përsëri në një moment.
//!
//! Përkufizimi i plotë i ["Rrymës"] përfshin një numër metodash të tjera, por ato janë metoda të paracaktuara, të ndërtuara në krye të [`poll_next`], dhe kështu t'i merrni falas.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementimi i Rrymës
//!
//! Krijimi i një transmetimi nga ana juaj përfshin dy hapa: krijimin e një `struct` për të mbajtur gjendjen e transmetimit dhe pastaj implementimin e [`Stream`] për atë `struct`.
//!
//! Le të bëjmë një rrjedhë me emrin `Counter` e cila numëron nga `1` në `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Së pari, struktura:
//!
//! /// Një rrjedhë e cila numëron nga një në pesë
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ne duam që numërimi ynë të fillojë në një, kështu që le të shtojmë një metodë new() për të ndihmuar.
//! // Kjo nuk është rreptësisht e nevojshme, por është e përshtatshme.
//! // Vini re se ne e fillojmë `count` në zero, do të shohim pse në zbatimin `poll_next()`'s më poshtë.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Pastaj, ne implementojmë `Stream` për `Counter` tonë:
//!
//! impl Stream for Counter {
//!     // ne do të numërojmë me përdorim
//!     type Item = usize;
//!
//!     // poll_next() është e vetmja metodë e kërkuar
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Rritni numrin tonë.Kjo është arsyeja pse ne filluam në zero.
//!         self.count += 1;
//!
//!         // Kontrolloni për të parë nëse kemi mbaruar numërimin apo jo.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Përrenjtë janë *dembelë*.Kjo do të thotë që vetëm krijimi i një transmetimi nuk _do_ shumë.Asgjë nuk ndodh në të vërtetë derisa të telefononi `next`.
//! Kjo ndonjëherë është një burim konfuzioni kur krijoni një rrjedhë vetëm për efektet e saj anësore.
//! Përpiluesi do të na paralajmërojë për këtë lloj sjelljeje:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;