use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Një ndërfaqe për trajtimin e përsëritësve asinkronë.
///
/// Kjo është rryma kryesore trait.
/// Për më shumë në lidhje me konceptin e rrjedhave në përgjithësi, ju lutem shikoni [module-level documentation].
/// Në veçanti, ju mund të dëshironi të dini se si të [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Lloji i artikujve të dhënë nga rryma.
    type Item;

    /// Përpjekje për të tërhequr vlerën tjetër të kësaj transmetimi, duke regjistruar detyrën aktuale për zgjim nëse vlera nuk është akoma e disponueshme dhe duke kthyer `None` nëse transmetimi është shteruar.
    ///
    /// # Vlera e kthimit
    ///
    /// Ka disa vlera të mundshme të kthimit, secila tregon një gjendje të veçantë të rrymës:
    ///
    /// - `Poll::Pending` do të thotë që vlera tjetër e këtij transmetimi nuk është ende gati.Zbatimet do të sigurojnë që detyra aktuale do të njoftohet kur vlera tjetër mund të jetë gati.
    ///
    /// - `Poll::Ready(Some(val))` do të thotë që transmetimi ka prodhuar me sukses një vlerë, `val`, dhe mund të prodhojë vlera të mëtejshme në thirrjet pasuese `poll_next`.
    ///
    /// - `Poll::Ready(None)` do të thotë që transmetimi ka përfunduar dhe `poll_next` nuk duhet të thirret përsëri.
    ///
    /// # Panics
    ///
    /// Sapo të ketë mbaruar një transmetim (kthehet `Ready(None)` from `poll_next`), duke thirrur metodën e saj `poll_next` përsëri mund të panic, të bllokojë përgjithmonë, ose të shkaktojë lloje të tjera problemesh; `Stream` trait nuk vendos ndonjë kërkesë për efektet e një thirrjeje të tillë.
    ///
    /// Sidoqoftë, pasi metoda `poll_next` nuk është e shënuar `unsafe`, zbatohen rregullat e zakonshme të Rust: thirrjet nuk duhet të shkaktojnë asnjëherë sjellje të papërcaktuar (prishja e kujtesës, përdorimi i pasaktë i funksioneve `unsafe` ose të ngjashme), pavarësisht nga gjendja e transmetimit.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Kthen kufijtë në gjatësinë e mbetur të transmetimit.
    ///
    /// Në mënyrë të veçantë, `size_hint()` kthen një tuple ku elementi i parë është kufiri i poshtëm, dhe elementi i dytë është kufiri i sipërm.
    ///
    /// Gjysma e dytë e tuple që kthehet është një ["Opsion"] "<" ["përdor") ">.
    /// Një [`None`] këtu do të thotë që ose nuk ka asnjë lidhje të sipërme të njohur, ose kufiri i sipërm është më i madh se [`usize`].
    ///
    /// # Shënime zbatimi
    ///
    /// Nuk zbatohet që një implementim i rrjedhës të jep numrin e deklaruar të elementeve.Një rrjedhë e gabuar mund të japë më pak se kufiri i poshtëm ose më shumë se kufiri i sipërm i elementeve.
    ///
    /// `size_hint()` është menduar kryesisht të përdoret për optimizime të tilla si rezervimi i hapësirës për elementet e transmetimit, por nuk duhet t'i besohet p.sh., heqja e kontrolleve të kufijve në kodin e pasigurt.
    /// Një zbatim i pasaktë i `size_hint()` nuk duhet të çojë në shkelje të sigurisë së kujtesës.
    ///
    /// Thënë kjo, zbatimi duhet të sigurojë një vlerësim të saktë, sepse përndryshe do të ishte shkelje e protokollit të trait.
    ///
    /// Zbatimi i paracaktuar kthen "(0," ["Asnjë"] ") që është i saktë për çdo transmetim.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}