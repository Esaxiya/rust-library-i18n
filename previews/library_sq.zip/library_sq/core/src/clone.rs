//! `Clone` trait për llojet që nuk mund të 'kopjohen në mënyrë të nënkuptuar'.
//!
//! Në Rust, disa lloje të thjeshtë janë "implicitly copyable" dhe kur i caktoni ato ose i kaloni ato si argumente, marrësi do të marrë një kopje, duke lënë vlerën origjinale në vend.
//! Këto lloje nuk kërkojnë alokim për t'u kopjuar dhe nuk kanë finalizues (p.sh., ato nuk përmbajnë kuti në pronësi ose nuk zbatojnë [`Drop`]), kështu që përpiluesi i konsideron ato të lira dhe të sigurta për t'u kopjuar.
//!
//! Për llojet e tjera, kopjet duhet të bëhen në mënyrë të qartë, duke zbatuar konventën [`Clone`] trait dhe duke thirrur metodën [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Shembulli i përdorimit themelor:
//!
//! ```
//! let s = String::new(); // Lloji i vargut zbaton Klonin
//! let copy = s.clone(); // kështu që ne mund ta klonojmë atë
//! ```
//!
//! Për të zbatuar me lehtësi Clone trait, mund të përdorni edhe `#[derive(Clone)]`.Shembull:
//!
//! ```
//! #[derive(Clone)] // ne shtojmë Clone trait në strukturën Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // dhe tani mund ta klonojmë!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Një trait i zakonshëm për aftësinë për të kopjuar qartë një objekt.
///
/// Ndryshimet nga [`Copy`] në atë [`Copy`] janë implicite dhe jashtëzakonisht të lira, ndërsa `Clone` është gjithmonë e qartë dhe mund ose nuk mund të jetë e shtrenjtë.
/// Për të zbatuar këto karakteristika, Rust nuk ju lejon të rimplementoni [`Copy`], por mund të rimplementoni `Clone` dhe të ekzekutoni një kod arbitrar.
///
/// Meqenëse `Clone` është më e përgjithshme se [`Copy`], automatikisht mund të bëni që çdo gjë [`Copy`] të jetë `Clone`.
///
/// ## Derivable
///
/// Ky trait mund të përdoret me `#[derive]` nëse të gjitha fushat janë `Clone`.Implementimi `nxjerr`d i [`Clone`] thirrjeve [`clone`] në secilën fushë.
///
/// [`clone`]: Clone::clone
///
/// Për një strukturë gjenerike, `#[derive]` zbaton `Clone` me kusht duke shtuar `Clone` të lidhur në parametrat gjenerikë.
///
/// ```
/// // `derive` zbaton Klonin për Lexim<T>kur T është Kloni.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Si mund ta implementoj `Clone`?
///
/// Llojet që janë [`Copy`] duhet të kenë një zbatim të parëndësishëm të `Clone`.Më zyrtarisht:
/// nëse `T: Copy`, `x: T` dhe `y: &T`, atëherë `let x = y.clone();` është ekuivalent me `let x = *y;`.
/// Zbatimet manuale duhet të jenë të kujdesshme për të mbështetur këtë të pandryshueshme;megjithatë, kodi i pasigurt nuk duhet të mbështetet në të për të siguruar sigurinë e kujtesës.
///
/// Një shembull është një strukturë e përgjithshme që mban një tregues funksioni.Në këtë rast, zbatimi i `Clone` nuk mund të "nxirret" d, por mund të zbatohet si:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Zbatuesit shtesë
///
/// Përveç [implementors listed below][impls], llojet e mëposhtme gjithashtu implementojnë `Clone`:
///
/// * Llojet e artikujve të funksioneve (d.m.th., llojet e dallueshme të përcaktuara për secilin funksion)
/// * Llojet e treguesit të funksionit (p.sh., `fn() -> i32`)
/// * Llojet e grupeve, për të gjitha madhësitë, nëse lloji i artikullit zbaton gjithashtu `Clone` (p.sh., `[i32; 123456]`)
/// * Llojet e dyfishta, nëse secili komponent zbaton gjithashtu `Clone` (p.sh., `()`, `(i32, bool)`)
/// * Llojet e mbylljes, nëse nuk kapin asnjë vlerë nga mjedisi ose nëse të gjitha vlerat e tilla të kapura zbatojnë vetë `Clone`.
///   Vini re se variablat e kapur nga referenca e përbashkët gjithmonë zbatojnë `Clone` (edhe nëse referenca nuk e bën), ndërsa ndryshoret e kapura nga referenca e ndryshueshme kurrë nuk zbatojnë `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Kthen një kopje të vlerës.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str zbaton Klonin
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Kryen caktimin e kopjimit nga `source`.
    ///
    /// `a.clone_from(&b)` është ekuivalente me `a = b.clone()` në funksionalitet, por mund të mbivlerësohet për të ripërdorur burimet e `a` për të shmangur alokimet e panevojshme.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Nxjerr makro që gjeneron një impl të trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): këto struktura përdoren vetëm nga#[derivoj] për të pohuar se çdo përbërës i një lloji zbaton Clone ose Copy.
//
//
// Këto stile nuk duhet të shfaqen kurrë në kodin e përdoruesit.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Zbatimet e `Clone` për llojet primitive.
///
/// Zbatimet që nuk mund të përshkruhen në Rust zbatohen në `traits::SelectionContext::copy_clone_conditions()` në `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Referencat e përbashkëta mund të klonohen, por referencat e ndryshueshme *nuk munden*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Referencat e përbashkëta mund të klonohen, por referencat e ndryshueshme *nuk munden*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}