//! Funksione falas për të krijuar `&[T]` dhe `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Formon një fetë nga një tregues dhe një gjatësi.
///
/// Argumenti `len` është numri i **elementeve**, jo numri i bajteve.
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `data` duhet të jetë [valid] për lexime për shumë `len * mem::size_of::<T>()` bajte, dhe duhet të jetë i rreshtuar siç duhet.Kjo do të thotë në veçanti:
///
///     * E gjithë diapazoni i kujtesës së kësaj flete duhet të përmbahet në një objekt të vetëm të alokuar!
///       Fetë nuk mund të shtrihen kurrë nëpër objekte të shumta të alokuara.Shihni [below](#incorrect-usage) për një shembull gabimisht duke mos e marrë parasysh këtë.
///     * `data` duhet të jetë jo null dhe i rreshtuar edhe për feta me gjatësi zero.
///     Një arsye për këtë është që optimizimet e paraqitjes së enumit mund të mbështeten në referencat (përfshirë feta të çdo gjatësi) që janë në një linjë dhe jo null për t'i dalluar ato nga të dhënat e tjera.
///     Ju mund të merrni një tregues që është i përdorshëm si `data` për feta me gjatësi zero duke përdorur [`NonNull::dangling()`].
///
/// * `data` duhet të tregojë në `len` vlerat e iniciuara si duhet të njëpasnjëshme të tipit `T`.
///
/// * Kujtesa e referuar nga feta e kthyer nuk duhet të ndryshohet gjatë gjithë jetës `'a`, përveç brenda një `UnsafeCell`.
///
/// * Madhësia totale `len * mem::size_of::<T>()` e fetë nuk duhet të jetë më e madhe se `isize::MAX`.
///   Shihni dokumentacionin e sigurisë së [`pointer::offset`].
///
/// # Caveat
///
/// Jetëgjatësia për fetë e kthyera nxirret nga përdorimi i saj.
/// Për të parandaluar keqpërdorimin aksidental, sugjerohet që të lidhet jeta e jetës me cilindo burim jetëgjatësia është e sigurt në kontekst, të tilla si duke siguruar një funksion ndihmës duke marrë jetëgjatësinë e një vlere pritëse për fetë, ose me shënim të qartë.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestojë një fetë për një element të vetëm
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Përdorim i pasaktë
///
/// Funksioni i mëposhtëm `join_slices` është **i pa shëndoshë**
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Pohimi i mësipërm siguron që `fst` dhe `snd` janë të afërta, por ato përsëri mund të përmbahen brenda _different allocated objects_, në këtë rast krijimi i kësaj flete është një sjellje e papërcaktuar.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` dhe `b` janë objekte të ndryshme të alokuara ...
///     let a = 42;
///     let b = 27;
///     // ... i cili sidoqoftë mund të përcaktohet në mënyrë të vazhdueshme në kujtesë: |një |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Kryen të njëjtën funksionalitet si [`from_raw_parts`], përveç se kthehet një fetë e ndryshueshme.
///
/// # Safety
///
/// Sjellja është e papërcaktuar nëse shkel ndonjë nga kushtet e mëposhtme:
///
/// * `data` duhet të jetë [valid] për të dy leximet dhe shkrimet për `len * mem::size_of::<T>()` shumë bajte, dhe duhet të rreshtohet siç duhet.Kjo do të thotë në veçanti:
///
///     * E gjithë diapazoni i kujtesës së kësaj flete duhet të përmbahet në një objekt të vetëm të alokuar!
///       Fetë nuk mund të shtrihen kurrë nëpër objekte të shumta të alokuara.
///     * `data` duhet të jetë jo null dhe i rreshtuar edhe për feta me gjatësi zero.
///     Një arsye për këtë është që optimizimet e paraqitjes së enumit mund të mbështeten në referencat (përfshirë feta të çdo gjatësi) që janë në një linjë dhe jo null për t'i dalluar ato nga të dhënat e tjera.
///
///     Ju mund të merrni një tregues që është i përdorshëm si `data` për feta me gjatësi zero duke përdorur [`NonNull::dangling()`].
///
/// * `data` duhet të tregojë në `len` vlerat e iniciuara si duhet të njëpasnjëshme të tipit `T`.
///
/// * Kujtesa e referuar nga feta e kthyer nuk duhet të arrihet përmes ndonjë treguesi tjetër (që nuk rrjedh nga vlera e kthimit) për tërë jetën `'a`.
///   Hyrja në lexim dhe shkrim është e ndaluar.
///
/// * Madhësia totale `len * mem::size_of::<T>()` e fetë nuk duhet të jetë më e madhe se `isize::MAX`.
///   Shihni dokumentacionin e sigurisë së [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Shndërron një referencë në T në një fetë me gjatësi 1 (pa kopjuar).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Shndërron një referencë në T në një fetë me gjatësi 1 (pa kopjuar).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}