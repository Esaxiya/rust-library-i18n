// ignore-tidy-filelength

//! Menaxhimi i feta dhe manipulimi.
//!
//! Për më shumë detaje shih [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Implementimi i pastër i rust memchr, marrë nga rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Ky funksion është publik vetëm sepse nuk ka asnjë mënyrë tjetër për të provuar njësinë e grupit të provës.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Kthen numrin e elementeve në fetë.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SIGURIA: tingull konstant sepse ne zhvendosim fushën e gjatësisë si një përdorim (i cili duhet të jetë)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SIGURIA: kjo është e sigurt sepse `&[T]` dhe `FatPtr<T>` kanë të njëjtën paraqitje.
            // Vetëm `std` mund ta bëjë këtë garanci.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Zëvendësoni me `crate::ptr::metadata(self)` kur kjo është e qëndrueshme.
            // Që nga ky shkrim, kjo shkakton një gabim "Const-stable functions can only call other const-stable functions".
            //

            // SIGURIA: Hyrja në vlerën nga bashkimi `PtrRepr` është e sigurt pasi * const T
            // dhe PtrComponents<T>kanë paraqitjet e njëjta të kujtesës.
            // Vetëm std mund ta bëjë këtë garanci.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Kthen `true` nëse feta ka një gjatësi 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Kthen elementin e parë të fetë, ose `None` nëse është bosh.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Kthen një tregues të ndryshueshëm në elementin e parë të fetë, ose `None` nëse është bosh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Kthen elementet e para dhe të gjithë pjesën tjetër të fetë, ose `None` nëse është bosh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Kthen elementet e para dhe të gjithë pjesën tjetër të fetë, ose `None` nëse është bosh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Kthen elementet e fundit dhe të gjithë pjesën tjetër të fetë, ose `None` nëse është bosh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Kthen elementet e fundit dhe të gjithë pjesën tjetër të fetë, ose `None` nëse është bosh.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Kthen elementin e fundit të fotos, ose `None` nëse është bosh.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Kthen një tregues të ndryshueshëm te artikulli i fundit në fetë.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Kthen një referencë në një element ose nënfushë në varësi të llojit të indeksit.
    ///
    /// - Nëse i jepet një pozicion, i kthen një referencë elementit në atë pozicion ose `None` nëse nuk është në kufij.
    ///
    /// - Nëse i jepet një interval, kthen nënfushën që korrespondon me atë diapazon, ose `None` nëse është jashtë kufijve.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Kthen një referencë të ndryshueshme në një element ose nënfushë në varësi të llojit të indeksit (shih [`get`]) ose `None` nëse indeksi është jashtë kufijve.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Kthen një referencë në një element ose nëngrup, pa bërë kontroll të kufijve.
    ///
    /// Për një alternativë të sigurt shih [`get`].
    ///
    /// # Safety
    ///
    /// Thirrja e kësaj metode me një indeks jashtë kufijve është *[sjellje e papërcaktuar]* edhe nëse referenca rezultuese nuk përdoret.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SIGURIA: telefonuesi duhet të përmbajë shumicën e kërkesave të sigurisë për `get_unchecked`;
        // feta është e referueshme, sepse `self` është një referencë e sigurt.
        // Treguesi i kthyer është i sigurt sepse impiantet e `SliceIndex` duhet të garantojnë që është.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Kthen një referencë të paqëndrueshme në një element ose nëngrup, pa bërë kontrollin e kufijve.
    ///
    /// Për një alternativë të sigurt shih [`get_mut`].
    ///
    /// # Safety
    ///
    /// Thirrja e kësaj metode me një indeks jashtë kufijve është *[sjellje e papërcaktuar]* edhe nëse referenca rezultuese nuk përdoret.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SIGURIA: telefonuesi duhet të përmbajë kërkesat e sigurisë për `get_unchecked_mut`;
        // feta është e referueshme, sepse `self` është një referencë e sigurt.
        // Treguesi i kthyer është i sigurt sepse impiantet e `SliceIndex` duhet të garantojnë që është.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Kthen një tregues të papërpunuar në buffer-in e fetë-s.
    ///
    /// Telefonuesi duhet të sigurojë që feta të jetojë më shumë në treguesin që ky funksion kthehet, përndryshe do të përfundojë duke treguar mbeturinat.
    ///
    /// Thirrësi gjithashtu duhet të sigurojë që kujtesa në të cilën treguesi (non-transitively) tregon të mos shkruhet kurrë (përveç brenda një `UnsafeCell`) duke përdorur këtë tregues ose ndonjë tregues që rrjedh prej tij.
    /// Nëse keni nevojë të mutoni përmbajtjen e fotos, përdorni [`as_mut_ptr`].
    ///
    /// Modifikimi i kontejnerit të referuar nga kjo fetë mund të shkaktojë që bufferi i tij të rialokohet, gjë që gjithashtu do të bënte të pavlefshëm çdo tregues për të.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Kthen një tregues të pasigurt të paqëndrueshëm në bufferin e fetë.
    ///
    /// Telefonuesi duhet të sigurojë që feta të jetojë më shumë në treguesin që ky funksion kthehet, përndryshe do të përfundojë duke treguar mbeturinat.
    ///
    /// Modifikimi i kontejnerit të referuar nga kjo fetë mund të shkaktojë që bufferi i tij të rialokohet, gjë që gjithashtu do të bënte të pavlefshëm çdo tregues për të.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Kthen dy treguesit e papërpunuar që shtrihen në fetë.
    ///
    /// Diapazoni i kthyer është gjysmë i hapur, që do të thotë që treguesi përfundimtar tregon *një të kaluar* elementin e fundit të fotos.
    /// Në këtë mënyrë, një fetë bosh përfaqësohet nga dy tregues të barabartë, dhe ndryshimi midis dy treguesve paraqet madhësinë e fotos.
    ///
    /// Shihni [`as_ptr`] për paralajmërime për përdorimin e këtyre treguesve.Treguesi përfundimtar kërkon një kujdes shtesë, pasi nuk tregon për një element të vlefshëm në fetë.
    ///
    /// Ky funksion është i dobishëm për bashkëveprimin me ndërfaqet e huaja të cilat përdorin dy tregues për t'iu referuar një sërë elementesh në memorje, siç është e zakonshme në C++ .
    ///
    ///
    /// Mund të jetë gjithashtu e dobishme të kontrolloni nëse një tregues i një elementi i referohet një elementi të kësaj flete:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SIGURIA: `add` këtu është i sigurt, sepse:
        //
        //   - Të dy treguesit janë pjesë e të njëjtit objekt, pasi vlen drejtpërdrejt edhe objekti.
        //
        //   - Madhësia e fotos nuk është kurrë më e madhe se isize::MAX bajte, siç është përmendur këtu:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Nuk ka asnjë mbështjellje të përfshirë, pasi feta nuk përfundojnë në fund të hapësirës së adresës.
        //
        // Shihni dokumentacionin e pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Kthen dy treguesit e pasigurt të paqëndrueshëm që shtrihen në fetë.
    ///
    /// Diapazoni i kthyer është gjysmë i hapur, që do të thotë që treguesi përfundimtar tregon *një të kaluar* elementin e fundit të fotos.
    /// Në këtë mënyrë, një fetë bosh përfaqësohet nga dy tregues të barabartë, dhe ndryshimi midis dy treguesve paraqet madhësinë e fotos.
    ///
    /// Shihni [`as_mut_ptr`] për paralajmërime për përdorimin e këtyre treguesve.
    /// Treguesi përfundimtar kërkon një kujdes shtesë, pasi nuk tregon për një element të vlefshëm në fetë.
    ///
    /// Ky funksion është i dobishëm për bashkëveprimin me ndërfaqet e huaja të cilat përdorin dy tregues për t'iu referuar një sërë elementesh në memorje, siç është e zakonshme në C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SIGURIA: Shikoni as_ptr_range() më lart për arsyen pse `add` këtu është i sigurt.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Shkëmben dy elemente në fetë.
    ///
    /// # Arguments
    ///
    /// * a, Indeksi i elementit të parë
    /// * b, Indeksi i elementit të dytë
    ///
    /// # Panics
    ///
    /// Panics nëse `a` ose `b` janë jashtë kufijve.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Nuk mund të marrësh dy kredi të ndryshueshme nga një vector, kështu që në vend të kësaj përdor tregues të papërpunuar.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SIGURIA: `pa` dhe `pb` janë krijuar nga referenca të sigurta të paqëndrueshme dhe referohen
        // tek elementet në fetë dhe për këtë arsye janë të garantuara të jenë të vlefshme dhe të përafruara.
        // Vini re se hyrja në elementet prapa `a` dhe `b` është e kontrolluar dhe do të panic kur nuk është në kufij.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Ndryshon rendin e elementeve në fetë, në vend.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Për lloje shumë të vegjël, të gjithë individët që lexojnë në rrugën normale performojnë dobët.
        // Ne mund të bëjmë më mirë, duke pasur parasysh load/store efikas të pavendosur, duke ngarkuar një copë më të madhe dhe duke përmbysur një regjistër.
        //

        // Idealisht LLVM do ta bënte këtë për ne, pasi ajo e di më mirë sesa ne nëse leximet e pavendosura janë efikase (pasi që ndryshon midis versioneve të ndryshme të ARM, për shembull) dhe cila do të ishte madhësia e copës më të mirë.
        // Për fat të keq, që nga LLVM 4.0 (2017-05) ajo vetëm hap unazën, kështu që ne duhet ta bëjmë këtë vetë.
        // (Hipoteza: e kundërta është e mundimshme sepse anët mund të rreshtohen ndryshe-do të jetë, kur gjatësia është e çuditshme-kështu që nuk ka asnjë mënyrë për të emetuar para dhe postlude për të përdorur SIMD plotësisht të rreshtuar në mes.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Përdorni llvm.bswap të brendshme për të kthyer u8-të në një përdorim
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SIGURIA: Ka disa gjëra për të kontrolluar këtu:
                //
                // - Vini re se `chunk` është ose 4 ose 8 për shkak të kontrollit të cfg më sipër.Pra, `chunk - 1` është pozitiv.
                // - Indeksimi me indeksin `i` është i mirë pasi garanton kontrolli i lakut
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indeksimi me indeksin `ln - i - chunk = ln - (i + chunk)` është i mirë:
                //   - `i + chunk > 0` është trivialisht e vërtetë.
                //   - Kontrolli i lakut garanton:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, kështu zbritja nuk rrjedh.
                // - Telefonatat `read_unaligned` dhe `write_unaligned` janë në rregull:
                //   - `pa` pikë në indeksin `i` ku `i < ln / 2 - (chunk - 1)` (shih më lart) dhe `pb` pikë në indeksin `ln - i - chunk`, kështu që të dy janë të paktën `chunk` shumë bajt larg nga fundi i `self`.
                //
                //   - Çdo kujtesë e iniciuar është e vlefshme `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Përdorni rotate-by-16 për të kthyer u16 në u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SIGURIA: Një u32 pa rreshtim mund të lexohet nga `i` nëse `i + 1 < ln`
                // (dhe padyshim `i < ln`), sepse secili element është 2 bajt dhe ne po lexojmë 4.
                //
                // `i + chunk - 1 < ln / 2` # ndërsa kusht
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Meqenëse është më pak se gjatësia e ndarë me 2, atëherë duhet të jetë në kufij.
                //
                // Kjo gjithashtu do të thotë që gjendja `0 < i + chunk <= ln` respektohet gjithmonë, duke siguruar që treguesi `pb` të mund të përdoret në mënyrë të sigurt.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SIGURIA: `i` është inferiore ndaj gjysmës së gjatësisë së fetë, pra
            // hyrja në `i` dhe `ln - i - 1` është e sigurt (`i` fillon me 0 dhe nuk do të shkojë më tej se `ln / 2 - 1`).
            // Treguesit rezultues `pa` dhe `pb` janë, pra, të vlefshëm dhe të rreshtuar, dhe mund të lexohen dhe shkruhen në të.
            //
            //
            unsafe {
                // Swap i pasigurt për të shmangur kontrollin e kufijve në swap të sigurt.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Kthen një iterator mbi fetë.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Kthen një iterator që lejon modifikimin e secilës vlerë.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Kthen një iterator mbi të gjithë windows ngjitur me gjatësi `size`.
    /// Mbivendosja windows.
    /// Nëse feta është më e shkurtër se `size`, iteratori nuk kthen vlera.
    ///
    /// # Panics
    ///
    /// Panics nëse `size` është 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Nëse feta është më e shkurtër se `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Kthen një iterator mbi elementët `chunk_size` të fotos në të njëjtën kohë, duke filluar nga fillimi i fotos.
    ///
    /// Pjesët janë feta dhe nuk mbivendosen.Nëse `chunk_size` nuk e ndan gjatësinë e fetë, atëherë copa e fundit nuk do të ketë gjatësi `chunk_size`.
    ///
    /// Shihni [`chunks_exact`] për një variant të këtij iteratori që kthen copa me elemente gjithnjë saktësisht `chunk_size`, dhe [`rchunks`] për të njëjtin përsëritës por duke filluar në fund të fotos.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `chunk_size` është 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Kthen një iterator mbi elementët `chunk_size` të fotos në të njëjtën kohë, duke filluar nga fillimi i fotos.
    ///
    /// Pjesët janë feta të ndryshueshme dhe nuk mbivendosen.Nëse `chunk_size` nuk e ndan gjatësinë e fetë, atëherë copa e fundit nuk do të ketë gjatësi `chunk_size`.
    ///
    /// Shihni [`chunks_exact_mut`] për një variant të këtij iteratori që kthen copa me elemente gjithnjë saktësisht `chunk_size`, dhe [`rchunks_mut`] për të njëjtin përsëritës por duke filluar në fund të fotos.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `chunk_size` është 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Kthen një iterator mbi elementët `chunk_size` të fotos në të njëjtën kohë, duke filluar nga fillimi i fotos.
    ///
    /// Pjesët janë feta dhe nuk mbivendosen.
    /// Nëse `chunk_size` nuk e ndan gjatësinë e fotos, atëherë elementet e fundit deri në `chunk_size-1` do të hiqen dhe mund të merren nga funksioni `remainder` i përsëritësit.
    ///
    ///
    /// Për shkak të secilës pjesë që ka saktësisht elemente `chunk_size`, përpiluesi shpesh mund të zgjedh kodin që rezulton më mirë sesa në rastin e [`chunks`].
    ///
    /// Shihni [`chunks`] për një variant të këtij iteratori që gjithashtu kthen pjesën e mbetur si një copë më të vogël, dhe [`rchunks_exact`] për të njëjtin iterator, por duke filluar në fund të fotos.
    ///
    /// # Panics
    ///
    /// Panics nëse `chunk_size` është 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Kthen një iterator mbi elementët `chunk_size` të fotos në të njëjtën kohë, duke filluar nga fillimi i fotos.
    ///
    /// Pjesët janë feta të ndryshueshme dhe nuk mbivendosen.
    /// Nëse `chunk_size` nuk e ndan gjatësinë e fotos, atëherë elementet e fundit deri në `chunk_size-1` do të hiqen dhe mund të merren nga funksioni `into_remainder` i përsëritësit.
    ///
    ///
    /// Për shkak të secilës pjesë që ka saktësisht elemente `chunk_size`, përpiluesi shpesh mund të zgjedh kodin që rezulton më mirë sesa në rastin e [`chunks_mut`].
    ///
    /// Shihni [`chunks_mut`] për një variant të këtij iteratori që gjithashtu kthen pjesën e mbetur si një copë më të vogël, dhe [`rchunks_exact_mut`] për të njëjtin iterator, por duke filluar në fund të fotos.
    ///
    /// # Panics
    ///
    /// Panics nëse `chunk_size` është 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Ndan fetë në një fetë të vargjeve të elementeve `N`, duke supozuar se nuk ka asnjë mbetje.
    ///
    ///
    /// # Safety
    ///
    /// Kjo mund të quhet vetëm kur
    /// - Feta ndahet saktësisht në copa të elementit `N` (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SIGURIA: Pjesët me 1 element nuk kanë asnjëherë mbetje
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SIGURIA: Gjatësia e fetë (6) është shumëfish i 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Këto do të ishin të paqëndrueshme:
    /// // le copa: &[[_;5]]= slice.as_chunks_unchecked()//Gjatësia e fotos nuk është shumëfish i 5 copave të letrës:&[[_ _;0]]= slice.as_chunks_unchecked()//Pjesët me gjatësi zero nuk lejohen kurrë
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SIGURIA: Parakushti ynë është pikërisht ajo që nevojitet për ta thirrur këtë
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SIGURIA: Ne hedhim një pjesë të elementeve `new_len * N` në
        // një copë `new_len` shumë elemente `N`.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Ndan fetë në një fetë të vargjeve të elementit `N`, duke filluar nga fillimi i fetë, dhe një fetë e mbetur me gjatësi në mënyrë rigoroze më të vogël se `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `N` është 0. Ky kontroll me shumë gjasë do të ndryshojë në një gabim të kohës së përpilimit përpara se kjo metodë të stabilizohet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SIGURIA: Ne tashmë jemi në panik për zero dhe jemi siguruar nga ndërtimi
        // se gjatësia e nënfushës është shumëfish i N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Ndan fetë në një fetë të vargjeve të elementeve `N`, duke filluar në fund të fetë, dhe një fetë të mbetur me gjatësi saktësisht më të vogël se `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `N` është 0. Ky kontroll me shumë gjasë do të ndryshojë në një gabim të kohës së përpilimit përpara se kjo metodë të stabilizohet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SIGURIA: Ne tashmë jemi në panik për zero dhe jemi siguruar nga ndërtimi
        // se gjatësia e nënfushës është shumëfish i N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Kthen një iterator mbi elementët `N` të fotos në të njëjtën kohë, duke filluar nga fillimi i fotos.
    ///
    /// Pjesët janë referenca të grupeve dhe nuk mbivendosen.
    /// Nëse `N` nuk e ndan gjatësinë e fotos, atëherë elementet e fundit deri në `N-1` do të hiqen dhe mund të merren nga funksioni `remainder` i përsëritësit.
    ///
    ///
    /// Kjo metodë është ekuivalenti gjenerik konstant i [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics nëse `N` është 0. Ky kontroll me shumë gjasë do të ndryshojë në një gabim të kohës së përpilimit përpara se kjo metodë të stabilizohet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Ndan fetë në një fetë të vargjeve të elementeve `N`, duke supozuar se nuk ka asnjë mbetje.
    ///
    ///
    /// # Safety
    ///
    /// Kjo mund të quhet vetëm kur
    /// - Feta ndahet saktësisht në copa të elementit `N` (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SIGURIA: Pjesët me 1 element nuk kanë asnjëherë mbetje
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SIGURIA: Gjatësia e fetë (6) është shumëfish i 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Këto do të ishin të paqëndrueshme:
    /// // le copa: &[[_;5]]= slice.as_chunks_unchecked_mut()//Gjatësia e fotos nuk është shumëfish i 5 copave të letrës:&[[_ _;0]]= slice.as_chunks_unchecked_mut()//Pjesët me gjatësi zero nuk lejohen kurrë
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SIGURIA: Parakushti ynë është pikërisht ajo që nevojitet për ta thirrur këtë
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SIGURIA: Ne hedhim një pjesë të elementeve `new_len * N` në
        // një copë `new_len` shumë elemente `N`.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Ndan fetë në një fetë të vargjeve të elementit `N`, duke filluar nga fillimi i fetë, dhe një fetë e mbetur me gjatësi në mënyrë rigoroze më të vogël se `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `N` është 0. Ky kontroll me shumë gjasë do të ndryshojë në një gabim të kohës së përpilimit përpara se kjo metodë të stabilizohet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SIGURIA: Ne tashmë jemi në panik për zero dhe jemi siguruar nga ndërtimi
        // se gjatësia e nënfushës është shumëfish i N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Ndan fetë në një fetë të vargjeve të elementeve `N`, duke filluar në fund të fetë, dhe një fetë të mbetur me gjatësi saktësisht më të vogël se `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `N` është 0. Ky kontroll me shumë gjasë do të ndryshojë në një gabim të kohës së përpilimit përpara se kjo metodë të stabilizohet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SIGURIA: Ne tashmë jemi në panik për zero dhe jemi siguruar nga ndërtimi
        // se gjatësia e nënfushës është shumëfish i N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Kthen një iterator mbi elementët `N` të fotos në të njëjtën kohë, duke filluar nga fillimi i fotos.
    ///
    /// Pjesët janë referenca të vargut të ndryshueshëm dhe nuk mbivendosen.
    /// Nëse `N` nuk e ndan gjatësinë e fotos, atëherë elementet e fundit deri në `N-1` do të hiqen dhe mund të merren nga funksioni `into_remainder` i përsëritësit.
    ///
    ///
    /// Kjo metodë është ekuivalenti gjenerik konstant i [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics nëse `N` është 0. Ky kontroll me shumë gjasë do të ndryshojë në një gabim të kohës së përpilimit përpara se kjo metodë të stabilizohet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Kthen një iterator mbi mbivendosjen e windows të elementeve `N` të një fete, duke filluar nga fillimi i fotos.
    ///
    ///
    /// Ky është ekuivalenti themelor gjenerik i [`windows`].
    ///
    /// Nëse `N` është më e madhe se madhësia e fetë, ajo nuk do të kthehet windows.
    ///
    /// # Panics
    ///
    /// Panics nëse `N` është 0.
    /// Ky kontroll me shumë gjasë do të ndryshojë në një gabim të kohës së përpilimit përpara se kjo metodë të stabilizohet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Kthen një iterator mbi elementët `chunk_size` të fotos në të njëjtën kohë, duke filluar në fund të fotos.
    ///
    /// Pjesët janë feta dhe nuk mbivendosen.Nëse `chunk_size` nuk e ndan gjatësinë e fetë, atëherë copa e fundit nuk do të ketë gjatësi `chunk_size`.
    ///
    /// Shihni [`rchunks_exact`] për një variant të këtij iteratori që kthen copa me elemente gjithnjë saktësisht `chunk_size`, dhe [`chunks`] për të njëjtin përsëritës, por duke filluar në fillim të fotos.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `chunk_size` është 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Kthen një iterator mbi elementët `chunk_size` të fotos në të njëjtën kohë, duke filluar në fund të fotos.
    ///
    /// Pjesët janë feta të ndryshueshme dhe nuk mbivendosen.Nëse `chunk_size` nuk e ndan gjatësinë e fetë, atëherë copa e fundit nuk do të ketë gjatësi `chunk_size`.
    ///
    /// Shihni [`rchunks_exact_mut`] për një variant të këtij iteratori që kthen copa me elemente gjithnjë saktësisht `chunk_size`, dhe [`chunks_mut`] për të njëjtin përsëritës, por duke filluar në fillim të fotos.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `chunk_size` është 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Kthen një iterator mbi elementët `chunk_size` të fotos në të njëjtën kohë, duke filluar në fund të fotos.
    ///
    /// Pjesët janë feta dhe nuk mbivendosen.
    /// Nëse `chunk_size` nuk e ndan gjatësinë e fotos, atëherë elementet e fundit deri në `chunk_size-1` do të hiqen dhe mund të merren nga funksioni `remainder` i përsëritësit.
    ///
    /// Për shkak të secilës pjesë që ka saktësisht elemente `chunk_size`, përpiluesi shpesh mund të zgjedh kodin që rezulton më mirë sesa në rastin e [`chunks`].
    ///
    /// Shihni [`rchunks`] për një variant të këtij iteratori që gjithashtu kthen pjesën e mbetur si një copë më të vogël, dhe [`chunks_exact`] për të njëjtin iterator por duke filluar në fillim të fotos.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `chunk_size` është 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Kthen një iterator mbi elementët `chunk_size` të fotos në të njëjtën kohë, duke filluar në fund të fotos.
    ///
    /// Pjesët janë feta të ndryshueshme dhe nuk mbivendosen.
    /// Nëse `chunk_size` nuk e ndan gjatësinë e fotos, atëherë elementet e fundit deri në `chunk_size-1` do të hiqen dhe mund të merren nga funksioni `into_remainder` i përsëritësit.
    ///
    /// Për shkak të secilës pjesë që ka saktësisht elemente `chunk_size`, përpiluesi shpesh mund të zgjedh kodin që rezulton më mirë sesa në rastin e [`chunks_mut`].
    ///
    /// Shihni [`rchunks_mut`] për një variant të këtij iteratori që gjithashtu kthen pjesën e mbetur si një copë më të vogël, dhe [`chunks_exact_mut`] për të njëjtin iterator por duke filluar në fillim të fotos.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `chunk_size` është 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Kthen një iterator mbi fetë duke prodhuar ekzekutime jo-mbivendosëse të elementeve duke përdorur kallëzuesin për t'i ndarë ato.
    ///
    /// Kallëzuesi thirret në dy elemente që ndjekin vetveten, kjo do të thotë që kallëzuesi thirret në `slice[0]` dhe `slice[1]` pastaj në `slice[1]` dhe `slice[2]` etj.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kjo metodë mund të përdoret për të nxjerrë nënpjesët e renditura:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Kthen një iterator mbi fetë duke prodhuar ekzekutime të paqëndrueshme të elementeve që nuk mbivendosen, duke përdorur kallëzuesin për t'i ndarë ato.
    ///
    /// Kallëzuesi thirret në dy elemente që ndjekin vetveten, kjo do të thotë që kallëzuesi thirret në `slice[0]` dhe `slice[1]` pastaj në `slice[1]` dhe `slice[2]` etj.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kjo metodë mund të përdoret për të nxjerrë nënpjesët e renditura:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Ndan një fetë në dy në një indeks.
    ///
    /// E para do të përmbajë të gjitha indekset nga `[0, mid)` (duke përjashtuar vetë indeksin `mid`) dhe e dyta do të përmbajë të gjitha indekset nga `[mid, len)` (duke përjashtuar vetë indeksin `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SIGURIA: `[ptr; mid]` dhe `[mid; len]` janë brenda `self`, e cila
        // plotëson kërkesat e `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Ndan një fetë të ndryshueshme në dy në një indeks.
    ///
    /// E para do të përmbajë të gjitha indekset nga `[0, mid)` (duke përjashtuar vetë indeksin `mid`) dhe e dyta do të përmbajë të gjitha indekset nga `[mid, len)` (duke përjashtuar vetë indeksin `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SIGURIA: `[ptr; mid]` dhe `[mid; len]` janë brenda `self`, e cila
        // plotëson kërkesat e `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Ndan një fetë në dy në një indeks, pa bërë kontroll të kufijve.
    ///
    /// E para do të përmbajë të gjitha indekset nga `[0, mid)` (duke përjashtuar vetë indeksin `mid`) dhe e dyta do të përmbajë të gjitha indekset nga `[mid, len)` (duke përjashtuar vetë indeksin `len`).
    ///
    ///
    /// Për një alternativë të sigurt shih [`split_at`].
    ///
    /// # Safety
    ///
    /// Thirrja e kësaj metode me një indeks jashtë kufijve është *[sjellje e papërcaktuar]* edhe nëse referenca që rezulton nuk përdoret.Telefonuesi duhet të sigurojë që `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SIGURIA: Thirrësi duhet të kontrollojë nëse `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Ndan një fetë të ndryshueshme në dy në një indeks, pa bërë kontroll të kufijve.
    ///
    /// E para do të përmbajë të gjitha indekset nga `[0, mid)` (duke përjashtuar vetë indeksin `mid`) dhe e dyta do të përmbajë të gjitha indekset nga `[mid, len)` (duke përjashtuar vetë indeksin `len`).
    ///
    ///
    /// Për një alternativë të sigurt shih [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Thirrja e kësaj metode me një indeks jashtë kufijve është *[sjellje e papërcaktuar]* edhe nëse referenca që rezulton nuk përdoret.Telefonuesi duhet të sigurojë që `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SIGURIA: Thirrësi duhet të kontrollojë nëse `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` dhe `[mid; len]` nuk janë të mbivendosur, kështu që kthimi i një reference të ndryshueshme është mirë.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Kthen një iterator mbi nënpjesët të ndara me elemente që përputhen me `pred`.
    /// Elementi i përputhur nuk përmbahet në nënpjesë.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Nëse elementi i parë përputhet, një fetë bosh do të jetë artikulli i parë i kthyer nga përsëritësi.
    /// Në mënyrë të ngjashme, nëse elementi i fundit në fetë përputhet, një fetë bosh do të jetë artikulli i fundit i kthyer nga përsëritësi:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Nëse dy elementë të përputhur janë ngjitur direkt, një fetë bosh do të jetë e pranishme midis tyre:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Kthen një iterator mbi nënpjesët e ndryshueshme të ndara nga elementë që përputhen me `pred`.
    /// Elementi i përputhur nuk përmbahet në nënpjesë.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Kthen një iterator mbi nënpjesët të ndara me elemente që përputhen me `pred`.
    /// Elementi i përputhur përmbahet në fund të nën-fisit të mëparshëm si terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Nëse elementi i fundit i fotos përputhet, ai element do të konsiderohet terminatori i fotos paraardhëse.
    ///
    /// Kjo fetë do të jetë artikulli i fundit i kthyer nga përsëritësi.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Kthen një iterator mbi nënpjesët e ndryshueshme të ndara nga elementë që përputhen me `pred`.
    /// Elementi i përputhur përmbahet në nënnjërën e mëparshme si terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Kthen një iterator mbi nënpjesët të ndara nga elementë që përputhen me `pred`, duke filluar në fund të fotos dhe duke punuar prapa.
    /// Elementi i përputhur nuk përmbahet në nënpjesë.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ashtu si me `split()`, nëse elementi i parë ose i fundit përputhet, një fetë bosh do të jetë artikulli i parë (ose i fundit) i kthyer nga përsëritësi.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Kthen një iterator mbi nënpjesët e ndryshueshme të ndara nga elementë që përputhen me `pred`, duke filluar në fund të fotos dhe duke punuar prapa.
    /// Elementi i përputhur nuk përmbahet në nënpjesë.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Kthen një iterator mbi nënpjesët e ndara nga elementë që përputhen me `pred`, të kufizuar në kthimin e më së shumti artikujve `n`.
    /// Elementi i përputhur nuk përmbahet në nënpjesë.
    ///
    /// Elementi i fundit i kthyer, nëse ka, do të përmbajë pjesën e mbetur të fetë.
    ///
    /// # Examples
    ///
    /// Shtypni copën e ndarë një herë me numra të pjesëtueshëm me 3 (dmth. `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Kthen një iterator mbi nënpjesët e ndara nga elementë që përputhen me `pred`, të kufizuar në kthimin e më së shumti artikujve `n`.
    /// Elementi i përputhur nuk përmbahet në nënpjesë.
    ///
    /// Elementi i fundit i kthyer, nëse ka, do të përmbajë pjesën e mbetur të fetë.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Kthen një iterator mbi nënpjesët të ndara nga elementë që përputhen me `pred` të kufizuar në kthimin e më së shumti artikujve `n`.
    /// Kjo fillon në fund të fetë dhe funksionon prapa.
    /// Elementi i përputhur nuk përmbahet në nënpjesë.
    ///
    /// Elementi i fundit i kthyer, nëse ka, do të përmbajë pjesën e mbetur të fetë.
    ///
    /// # Examples
    ///
    /// Shtypni copën e copave një herë, duke filluar nga fundi, me numra të pjesëtueshëm me 3 (dmth. `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Kthen një iterator mbi nënpjesët të ndara nga elementë që përputhen me `pred` të kufizuar në kthimin e më së shumti artikujve `n`.
    /// Kjo fillon në fund të fetë dhe funksionon prapa.
    /// Elementi i përputhur nuk përmbahet në nënpjesë.
    ///
    /// Elementi i fundit i kthyer, nëse ka, do të përmbajë pjesën e mbetur të fetë.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Kthen `true` nëse feta përmban një element me vlerën e dhënë.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Nëse nuk keni një `&T`, por vetëm një `&U` të tillë që `T: Borrow<U>` (p.sh.
    /// `Vargu: Merr hua<str>`), ju mund të përdorni `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // fetë e `String`
    /// assert!(v.iter().any(|e| e == "hello")); // kërko me `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Kthen `true` nëse `needle` është një parashtesë e pjesës.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Gjithmonë kthen `true` nëse `needle` është një fetë bosh:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Kthen `true` nëse `needle` është një prapashtesë e pjesës.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Gjithmonë kthen `true` nëse `needle` është një fetë bosh:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Kthen një nënfjalë me parashtesën e hequr.
    ///
    /// Nëse feta fillon me `prefix`, kthen nënfushën pas parashtesës, të mbështjellë me `Some`.
    /// Nëse `prefix` është bosh, thjesht kthen fetë origjinale.
    ///
    /// Nëse feta nuk fillon me `prefix`, kthen `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ky funksion do të ketë nevojë për rishkrim nëse dhe kur SlicePattern bëhet më i sofistikuar.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Kthen një nënfushë me prapashtesën e hequr.
    ///
    /// Nëse feta përfundon me `suffix`, kthen nënfushën para prapashtesës, të mbështjellë me `Some`.
    /// Nëse `suffix` është bosh, thjesht kthen fetë origjinale.
    ///
    /// Nëse feta nuk përfundon me `suffix`, kthen `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Ky funksion do të ketë nevojë për rishkrim nëse dhe kur SlicePattern bëhet më i sofistikuar.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binar kërkon këtë fetë të renditur për një element të caktuar.
    ///
    /// Nëse vlera gjendet, atëherë [`Result::Ok`] kthehet, që përmban indeksin e elementit që përputhet.
    /// Nëse ka ndeshje të shumta, atëherë secila prej ndeshjeve mund të kthehet.
    /// Nëse vlera nuk gjendet, atëherë [`Result::Err`] kthehet, duke përmbajtur indeksin ku mund të futet një element përputhës duke ruajtur renditjen e renditur.
    ///
    ///
    /// Shihni gjithashtu [`binary_search_by`], [`binary_search_by_key`] dhe [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Kërkon një seri prej katër elementësh.
    /// E para është gjetur, me një pozicion të përcaktuar në mënyrë unike;e dyta dhe e treta nuk gjenden;i katërti mund të përputhet me çdo pozicion në `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Nëse dëshironi të futni një artikull në një vector të renditur, duke ruajtur renditjen e renditjes:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binary kërkon këtë fetë të renditur me një funksion krahasues.
    ///
    /// Funksioni krahasues duhet të zbatojë një urdhër në përputhje me renditjen e renditjes së pjesës themelore, duke kthyer një kod porosie që tregon nëse argumenti i tij është `Less`, `Equal` ose `Greater` synimi i dëshiruar.
    ///
    ///
    /// Nëse vlera gjendet, atëherë [`Result::Ok`] kthehet, që përmban indeksin e elementit që përputhet.Nëse ka ndeshje të shumta, atëherë secila prej ndeshjeve mund të kthehet.
    /// Nëse vlera nuk gjendet, atëherë [`Result::Err`] kthehet, duke përmbajtur indeksin ku mund të futet një element përputhës duke ruajtur renditjen e renditur.
    ///
    /// Shihni gjithashtu [`binary_search`], [`binary_search_by_key`] dhe [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Kërkon një seri prej katër elementësh.E para është gjetur, me një pozicion të përcaktuar në mënyrë unike;e dyta dhe e treta nuk gjenden;i katërti mund të përputhet me çdo pozicion në `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SIGURIA: thirrja bëhet e sigurt nga invariancat e mëposhtme:
            // - `mid >= 0`
            // - `mid < size`: `mid` është i kufizuar nga `[left; right)` i lidhur.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Arsyeja pse ne përdorim rrjedhën e kontrollit if/else sesa ndeshjen është sepse ndeshja rendit operacionet e krahasimit, e cila është shumë e ndjeshme.
            //
            // Kjo është x86 asm për u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binary kërkon këtë fetë të renditur me një funksion kyç të nxjerrjes.
    ///
    /// Supozon që feta të renditet sipas çelësit, për shembull me [`sort_by_key`] duke përdorur të njëjtin funksion të nxjerrjes së çelësit.
    ///
    /// Nëse vlera gjendet, atëherë [`Result::Ok`] kthehet, që përmban indeksin e elementit që përputhet.
    /// Nëse ka ndeshje të shumta, atëherë secila prej ndeshjeve mund të kthehet.
    /// Nëse vlera nuk gjendet, atëherë [`Result::Err`] kthehet, duke përmbajtur indeksin ku mund të futet një element përputhës duke ruajtur renditjen e renditur.
    ///
    ///
    /// Shihni gjithashtu [`binary_search`], [`binary_search_by`] dhe [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Kërkon një seri prej katër elementësh në një pjesë të çifteve të renditura sipas elementeve të tyre të dytë.
    /// E para është gjetur, me një pozicion të përcaktuar në mënyrë unike;e dyta dhe e treta nuk gjenden;i katërti mund të përputhet me çdo pozicion në `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links lejohet pasi `slice::sort_by_key` është në crate `alloc`, dhe si e tillë nuk ekziston akoma kur ndërtohet `core`.
    //
    // lidhje me crate në rrjedhën e poshtme: #74481.Meqenëse primitivët janë të dokumentuar vetëm në libstd (#73423), kjo nuk çon kurrë në lidhje të prishura në praktikë.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Rendit feta, por mund të mos ruajë rendin e elementeve të barabarta.
    ///
    /// Ky lloj është i paqëndrueshëm (dmth, mund të rendit elemente të barabarta), në vend (dmth. Nuk alokon) dhe *O*(*n*\*log(* n*)) rasti më i keq.
    ///
    /// # Zbatimi aktual
    ///
    /// Algoritmi aktual bazohet në [pattern-defeating quicksort][pdqsort] nga Orson Peters, i cili ndërthur rastet mesatare të shpejta të quicksort-it të rastësishëm me rastin më të shpejtë të heapsort-it, ndërsa arrin kohën lineare në feta me modele të caktuara.
    /// Ai përdor një farë rastësie për të shmangur raste të degjeneruara, por me një seed fiks për të siguruar gjithnjë sjellje përcaktuese.
    ///
    /// Typicallyshtë zakonisht më e shpejtë se klasifikimi i qëndrueshëm, përveç në disa raste të veçanta, p.sh., kur feta përbëhet nga disa sekuenca të renditura të bashkuara.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Rendit fetë me një funksion krahasues, por mund të mos ruajë rendin e elementeve të barabarta.
    ///
    /// Ky lloj është i paqëndrueshëm (dmth, mund të rendit elemente të barabarta), në vend (dmth. Nuk alokon) dhe *O*(*n*\*log(* n*)) rasti më i keq.
    ///
    /// Funksioni krahasues duhet të përcaktojë një renditje totale për elementet në fetë.Nëse renditja nuk është totale, renditja e elementeve është e paspecifikuar.Një porosi është një porosi totale nëse është (për të gjithë `a`, `b` dhe `c`):
    ///
    /// * total dhe antisimetrik: saktësisht një nga `a < b`, `a == b` ose `a > b` është i vërtetë, dhe
    /// * kalimtare, `a < b` dhe `b < c` nënkupton `a < c`.E njëjta gjë duhet të vlejë si për `==` ashtu edhe për `>`.
    ///
    /// Për shembull, ndërsa [`f64`] nuk implementon [`Ord`] sepse `NaN != NaN`, ne mund të përdorim `partial_cmp` si funksionin tonë të renditjes kur e dimë që feta nuk përmban `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Zbatimi aktual
    ///
    /// Algoritmi aktual bazohet në [pattern-defeating quicksort][pdqsort] nga Orson Peters, i cili ndërthur rastet mesatare të shpejta të quicksort-it të rastësishëm me rastin më të shpejtë të heapsort-it, ndërsa arrin kohën lineare në feta me modele të caktuara.
    /// Ai përdor një farë rastësie për të shmangur raste të degjeneruara, por me një seed fiks për të siguruar gjithnjë sjellje përcaktuese.
    ///
    /// Typicallyshtë zakonisht më e shpejtë se klasifikimi i qëndrueshëm, përveç në disa raste të veçanta, p.sh., kur feta përbëhet nga disa sekuenca të renditura të bashkuara.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // klasifikimi i kundërt
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Rendit feta me një funksion kyç të nxjerrjes, por nuk mund të ruajë rendin e elementeve të barabarta.
    ///
    /// Ky lloj është i paqëndrueshëm (dmth, mund të rirreshtojë elementë të barabartë), në vend (dmth. Nuk alokon) dhe *O*(m\* * n *\* log(*n*)) rasti më i keq, ku funksioni kryesor është *O*(*m*).
    ///
    /// # Zbatimi aktual
    ///
    /// Algoritmi aktual bazohet në [pattern-defeating quicksort][pdqsort] nga Orson Peters, i cili ndërthur rastet mesatare të shpejta të quicksort-it të rastësishëm me rastin më të shpejtë të heapsort-it, ndërsa arrin kohën lineare në feta me modele të caktuara.
    /// Ai përdor një farë rastësie për të shmangur raste të degjeneruara, por me një seed fiks për të siguruar gjithnjë sjellje përcaktuese.
    ///
    /// Për shkak të strategjisë së tij kryesore të thirrjes, [`sort_unstable_by_key`](#method.sort_unstable_by_key) ka të ngjarë të jetë më e ngadaltë se [`sort_by_cached_key`](#method.sort_by_cached_key) në rastet kur funksioni kryesor është i shtrenjtë.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Renditeni fetë ashtu që elementi në `index` të jetë në pozicionin e tij të renditur përfundimtar.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Renditeni fetë me një funksion krahasues të tillë që elementi në `index` të jetë në pozicionin e tij të renditur përfundimtar.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Renditeni fetë me një funksion kyç të nxjerrjes të tillë që elementi në `index` të jetë në pozicionin e tij të fundit të renditur.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Renditeni fetë ashtu që elementi në `index` të jetë në pozicionin e tij të renditur përfundimtar.
    ///
    /// Kjo renditje ka vetinë shtesë që çdo vlerë në pozicionin `i < index` do të jetë më e vogël ose e barabartë me çdo vlerë në një pozicion `j > index`.
    /// Për më tepër, kjo rregullim është e paqëndrueshme (dmth
    /// çdo numër i elementeve të barabartë mund të përfundojë në pozicionin `index`), në vend (dmth.)
    /// nuk alokon), dhe *O*(*n*) rasti më i keq.
    /// Ky funksion është/i njohur edhe si "kth element" në bibliotekat e tjera.
    /// Kthen trefishin e vlerave të mëposhtme: të gjithë elementët më pak se ai në indeksin e dhënë, vlera në indeksin e dhënë dhe të gjithë elementët më të mëdhenj se ai në indeksin e dhënë.
    ///
    ///
    /// # Zbatimi aktual
    ///
    /// Algoritmi aktual bazohet në pjesën e zgjedhjes së shpejtë të të njëjtit algoritëm quicksort të përdorur për [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kur `index >= len()`, domethënë gjithmonë panics në feta boshe.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Gjeni mesoren
    /// v.select_nth_unstable(2);
    ///
    /// // Ne jemi të garantuar vetëm se feta do të jetë një nga më poshtë, bazuar në mënyrën se si ne renditim për indeksin e specifikuar.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Renditeni fetë me një funksion krahasues të tillë që elementi në `index` të jetë në pozicionin e tij të renditur përfundimtar.
    ///
    /// Kjo renditje ka vetinë shtesë që çdo vlerë në pozicionin `i < index` do të jetë më e vogël ose e barabartë me çdo vlerë në një pozicion `j > index` duke përdorur funksionin e krahasuesit.
    /// Për më tepër, kjo renditje është e paqëndrueshme (dmth. Çdo numër i elementeve të barabartë mund të përfundojë në pozicionin `index`), në vend (dmth. Nuk alokon) dhe *O*(*n*) rasti më i keq.
    /// Ky funksion njihet gjithashtu si "kth element" në bibliotekat e tjera.
    /// Kthen trefishin e vlerave të mëposhtme: të gjithë elementët më pak se ai në indeksin e dhënë, vlera në indeksin e dhënë dhe të gjithë elementët më të mëdhenj se ai në indeksin e dhënë, duke përdorur funksionin e krahasuar të dhënë.
    ///
    ///
    /// # Zbatimi aktual
    ///
    /// Algoritmi aktual bazohet në pjesën e zgjedhjes së shpejtë të të njëjtit algoritëm quicksort të përdorur për [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kur `index >= len()`, domethënë gjithmonë panics në feta boshe.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Gjeni mesoren sikur feta të renditet në rend zbritës.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Ne jemi të garantuar vetëm se feta do të jetë një nga më poshtë, bazuar në mënyrën se si ne renditim për indeksin e specifikuar.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Renditeni fetë me një funksion kyç të nxjerrjes të tillë që elementi në `index` të jetë në pozicionin e tij të fundit të renditur.
    ///
    /// Kjo renditje ka vetinë shtesë që çdo vlerë në pozicionin `i < index` do të jetë më e vogël ose e barabartë me çdo vlerë në një pozicion `j > index` duke përdorur funksionin e nxjerrjes kryesore.
    /// Për më tepër, kjo renditje është e paqëndrueshme (dmth. Çdo numër i elementeve të barabartë mund të përfundojë në pozicionin `index`), në vend (dmth. Nuk alokon) dhe *O*(*n*) rasti më i keq.
    /// Ky funksion njihet gjithashtu si "kth element" në bibliotekat e tjera.
    /// Kthen trefishin e vlerave të mëposhtme: të gjithë elementët më pak se ai në indeksin e dhënë, vlera në indeksin e dhënë dhe të gjithë elementët më të mëdhenj se ai në indeksin e dhënë, duke përdorur funksionin e siguruar të nxjerrjes së çelësit.
    ///
    ///
    /// # Zbatimi aktual
    ///
    /// Algoritmi aktual bazohet në pjesën e zgjedhjes së shpejtë të të njëjtit algoritëm quicksort të përdorur për [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics kur `index >= len()`, domethënë gjithmonë panics në feta boshe.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Ktheni mesoren sikur grupi të renditet sipas vlerës absolute.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Ne jemi të garantuar vetëm se feta do të jetë një nga më poshtë, bazuar në mënyrën se si ne renditim për indeksin e specifikuar.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Lëviz të gjithë elementët e përsëritur të njëpasnjëshëm në fund të fotos sipas zbatimit të [`PartialEq`] trait.
    ///
    ///
    /// Kthen dy feta.E para nuk përmban elemente të njëpasnjëshme radhazi.
    /// E dyta përmban të gjitha kopjimet në asnjë mënyrë të caktuar.
    ///
    /// Nëse feta është e renditur, feta e parë e kthyer nuk përmban dublikata.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Lëviz të gjithë, përveç elementit të parë të njëpasnjëshëm, në fund të fotos duke përmbushur një lidhje të caktuar barazie.
    ///
    /// Kthen dy feta.E para nuk përmban elemente të njëpasnjëshme radhazi.
    /// E dyta përmban të gjitha kopjimet në asnjë mënyrë të caktuar.
    ///
    /// Funksioni `same_bucket` i kalon referencat dy elementeve nga feta dhe duhet të përcaktojë nëse elementet krahasohen të barabartë.
    /// Elementet kalohen në rend të kundërt nga renditja e tyre në fetë, kështu që nëse `same_bucket(a, b)` kthen `true`, `a` zhvendoset në fund të fotos.
    ///
    ///
    /// Nëse feta është e renditur, feta e parë e kthyer nuk përmban dublikata.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Megjithëse kemi një referencë të ndryshueshme ndaj `self`, nuk mund të bëjmë ndryshime * arbitrare.Thirrjet `same_bucket` mund të panic, kështu që ne duhet të sigurojmë që feta të jetë në një gjendje të vlefshme gjatë gjithë kohës.
        //
        // Mënyra se si e trajtojmë këtë është duke përdorur swap;ne përsërisim mbi të gjithë elementët, duke shkëmbyer ndërsa shkojmë në mënyrë që në fund elementët që dëshirojmë të mbajmë të jenë përpara, dhe ata që dëshirojmë t'i refuzojmë janë në pjesën e pasme.
        // Pastaj mund ta ndajmë fetë.
        // Ky operacion është akoma `O(n)`.
        //
        // Shembull: Ne fillojmë në këtë gjendje, ku `r` përfaqëson "tjetër"
        // lexo "dhe `w` përfaqëson" next_write ".
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Krahasimi i self[r] me vetveten [w-1], kjo nuk është dublikatë, kështu që ne ndërrojmë self[r] dhe self[w] (pa efekt si r==w) dhe pastaj rritim të dy r dhe w, duke na lënë me:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Duke krahasuar self[r] me vetveten [w-1], kjo vlerë është dublikatë, kështu që ne rritim `r` por lëmë gjithçka tjetër të pandryshuar:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Krahasimi i self[r] me vetveten [w-1], ky nuk është dublikatë, kështu që ndërroni self[r] dhe self[w] dhe përparoni r dhe w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Jo kopjuar, përsërite:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Dublikatë, fetë advance r. End.Ndarë në w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SIGURIA: gjendja `while` garanton `next_read` dhe `next_write`
        // janë më pak se `len`, pra janë brenda `self`.
        // `prev_ptr_write` tregon një element përpara `ptr_write`, por `next_write` fillon me 1, kështu që `prev_ptr_write` nuk është kurrë më pak se 0 dhe është brenda fotos.
        // Kjo përmbush kërkesat për referimin `ptr_read`, `prev_ptr_write` dhe `ptr_write` dhe për përdorimin e `ptr.add(next_read)`, `ptr.add(next_write - 1)` dhe `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` rritet gjithashtu më së shumti një herë në lak, domethënë asnjë element nuk kapërcehet kur mund të ketë nevojë të ndërrohet.
        //
        // `ptr_read` dhe `prev_ptr_write` kurrë nuk tregojnë për të njëjtin element.Kjo kërkohet që `&mut *ptr_read`, `&mut* prev_ptr_write` të jetë i sigurt.
        // Shpjegimi është thjesht se `next_read >= next_write` është gjithmonë i vërtetë, kështu që `next_read > next_write - 1` është gjithashtu i vërtetë.
        //
        //
        //
        //
        //
        unsafe {
            // Shmangni kontrollet e kufijve duke përdorur tregues të papërpunuar.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Lëviz të gjithë, përveç elementit të parë radhazi, në fund të fotos që zgjidhen në të njëjtin çelës.
    ///
    ///
    /// Kthen dy feta.E para nuk përmban elemente të njëpasnjëshme radhazi.
    /// E dyta përmban të gjitha kopjimet në asnjë mënyrë të caktuar.
    ///
    /// Nëse feta është e renditur, feta e parë e kthyer nuk përmban dublikata.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Rrotullohet feta në vend ashtu që elementët e parë `mid` të fetë të lëvizin në fund ndërsa elementët e fundit `self.len() - mid` lëvizin përpara.
    /// Pas thirrjes `rotate_left`, elementi më parë në indeksin `mid` do të bëhet elementi i parë në fetë.
    ///
    /// # Panics
    ///
    /// Ky funksion do të panic nëse `mid` është më i madh se gjatësia e fetë.Vini re se `mid == self.len()` bën _not_ panic dhe është një rotacion pa opsion.
    ///
    /// # Complexity
    ///
    /// Merr lineare (në kohën `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Rrotullimi i një nënfille:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SIGURIA: Diapazoni `[p.add(mid) - mid, p.add(mid) + k)` është i parëndësishëm
        // e vlefshme për lexim dhe shkrim, siç kërkohet nga `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Rrotullohet feta në vend ashtu që elementët e parë `self.len() - k` të fetë të lëvizin në fund ndërsa elementët e fundit `k` lëvizin përpara.
    /// Pas thirrjes `rotate_right`, elementi më parë në indeksin `self.len() - k` do të bëhet elementi i parë në fetë.
    ///
    /// # Panics
    ///
    /// Ky funksion do të panic nëse `k` është më i madh se gjatësia e fetë.Vini re se `k == self.len()` bën _not_ panic dhe është një rotacion pa opsion.
    ///
    /// # Complexity
    ///
    /// Merr lineare (në kohën `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Rrotulloni një nënfushë:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SIGURIA: Diapazoni `[p.add(mid) - mid, p.add(mid) + k)` është i parëndësishëm
        // e vlefshme për lexim dhe shkrim, siç kërkohet nga `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Mbush `self` me elemente duke klonuar `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Mbush `self` me elementë të kthyer duke thirrur një mbyllje në mënyrë të përsëritur.
    ///
    /// Kjo metodë përdor një mbyllje për të krijuar vlera të reja.Nëse preferoni që [`Clone`] të ketë një vlerë të caktuar, përdorni [`fill`].
    /// Nëse dëshironi të përdorni [`Default`] trait për të gjeneruar vlera, mund të kaloni [`Default::default`] si argument.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopjon elementet nga `src` në `self`.
    ///
    /// Gjatësia e `src` duhet të jetë e njëjtë me `self`.
    ///
    /// Nëse `T` zbaton `Copy`, mund të jetë më e efektshme të përdorni [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ky funksion do të panic nëse dy feta kanë gjatësi të ndryshme.
    ///
    /// # Examples
    ///
    /// Klonimi i dy elementeve nga një fetë në një tjetër:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Meqenëse feta duhet të ketë të njëjtën gjatësi, ne e presim fetë e burimit nga katër elementë në dy.
    /// // Do të panic nëse nuk e bëjmë këtë.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust zbaton që mund të ketë vetëm një referencë të ndryshueshme pa referenca të pandryshueshme për një pjesë të veçantë të të dhënave në një fushë të caktuar.
    /// Për shkak të kësaj, përpjekja për të përdorur `clone_from_slice` në një fetë të vetme do të rezultojë në një dështim të përpilimit:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Për të punuar rreth kësaj, ne mund të përdorim [`split_at_mut`] për të krijuar dy nën-feta të dallueshme nga një fetë:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopjon të gjithë elementët nga `src` në `self`, duke përdorur një memcpy.
    ///
    /// Gjatësia e `src` duhet të jetë e njëjtë me `self`.
    ///
    /// Nëse `T` nuk zbaton `Copy`, përdorni [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Ky funksion do të panic nëse dy feta kanë gjatësi të ndryshme.
    ///
    /// # Examples
    ///
    /// Kopjimi i dy elementeve nga një fetë në një tjetër:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Meqenëse feta duhet të ketë të njëjtën gjatësi, ne e presim fetë e burimit nga katër elementë në dy.
    /// // Do të panic nëse nuk e bëjmë këtë.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust zbaton që mund të ketë vetëm një referencë të ndryshueshme pa referenca të pandryshueshme për një pjesë të veçantë të të dhënave në një fushë të caktuar.
    /// Për shkak të kësaj, përpjekja për të përdorur `copy_from_slice` në një fetë të vetme do të rezultojë në një dështim të përpilimit:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Për të punuar rreth kësaj, ne mund të përdorim [`split_at_mut`] për të krijuar dy nën-feta të dallueshme nga një fetë:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Shtegu i kodit panic u vendos në një funksion të ftohtë për të mos fryrë vendin e thirrjes.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SIGURIA: `self` është e vlefshme për elementët `self.len()` sipas përkufizimit, dhe `src` ishte
        // kontrollohet të ketë të njëjtën gjatësi.
        // Fetë nuk mund të mbivendosen sepse referencat e ndryshueshme janë ekskluzive.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopjon elemente nga një pjesë e fetë në një pjesë tjetër e vetvetes, duke përdorur një memmove.
    ///
    /// `src` është diapazoni brenda `self` për tu kopjuar.
    /// `dest` është indeksi fillestar i intervalit brenda `self` për të kopjuar, i cili do të ketë të njëjtën gjatësi si `src`.
    /// Të dy diapazonet mund të mbivendosen.
    /// Skajet e dy vargjeve duhet të jenë më të vogla ose të barabarta me `self.len()`.
    ///
    /// # Panics
    ///
    /// Ky funksion do të panic nëse secila varg tejkalon fundin e fotos, ose nëse fundi i `src` është para fillimit.
    ///
    ///
    /// # Examples
    ///
    /// Kopjimi i katër bajtëve brenda një fete:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SIGURIA: kushtet për `ptr::copy` janë kontrolluar të gjitha më lart,
        // siç kanë ato për `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Ndërron të gjithë elementët në `self` me ato në `other`.
    ///
    /// Gjatësia e `other` duhet të jetë e njëjtë me `self`.
    ///
    /// # Panics
    ///
    /// Ky funksion do të panic nëse dy feta kanë gjatësi të ndryshme.
    ///
    /// # Example
    ///
    /// Shkëmbimi i dy elementeve nëpër feta:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust zbaton që mund të ketë vetëm një referencë të ndryshueshme për një pjesë të veçantë të të dhënave në një fushë të caktuar.
    ///
    /// Për shkak të kësaj, përpjekja për të përdorur `swap_with_slice` në një fetë të vetme do të rezultojë në një dështim të përpilimit:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Për të punuar rreth kësaj, ne mund të përdorim [`split_at_mut`] për të krijuar dy nën-feta të dallueshme të ndryshueshme nga një fetë:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SIGURIA: `self` është e vlefshme për elementët `self.len()` sipas përkufizimit, dhe `src` ishte
        // kontrollohet të ketë të njëjtën gjatësi.
        // Fetë nuk mund të mbivendosen sepse referencat e ndryshueshme janë ekskluzive.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funksioni për të llogaritur gjatësitë e mesit dhe pjesës zvarritëse për `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Ajo që ne do të bëjmë për `rest` është të kuptojmë se çfarë shumëfishi të `U` mund të vendosim në një numër më të ulët të`T`.
        //
        // Dhe sa `T` na duhen për secilin "multiple" të tillë.
        //
        // Shikoni për shembull T=u8 U=u16.Atëherë mund të vendosim 1 U në 2 Ts.E thjeshtë
        // Tani, merrni parasysh për shembull një rast ku size_of: :<T>=16, madhësia_e::<U>=24.</u>
        // Ne mund të vendosim 2 Us në vend të çdo 3 Ts në fetë `rest`.
        // Pak më e komplikuar.
        //
        // Formula për të llogaritur këtë është:
        //
        // Na= lcm(size_of::<T>, size_of::<U>)/madhësia e tij: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/madhësia e tij::</u><T>
        //
        // Zgjeruar dhe thjeshtuar:
        //
        // Na=madhësia e: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=madhësia_e::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Për fat të mirë pasi e gjithë kjo vlerësohet vazhdimisht ... performanca këtu nuk ka rëndësi!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // algoritmi iterativ i stein-it Ne ende duhet ta bëjmë këtë `const fn` (dhe ta kthejmë në algoritëm rekursiv nëse e bëjmë) sepse duke u mbështetur në llvm për të konvervuar e gjithë kjo është…mirë, kjo më bën të pakëndshme.
            //
            //

            // SIGURIA: `a` dhe `b` kontrollohen të jenë vlera jo zero.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // hiqni të gjithë faktorët e 2 nga b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SIGURIA: `b` kontrollohet të mos jetë zero.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Të armatosur me këtë njohuri, ne mund të gjejmë se sa `U` mund të përshtatim!
        let us_len = self.len() / ts * us;
        // Dhe sa `T` do të jenë në fetë zvarritëse!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmetoni fetë në një fetë të një lloji tjetër, duke siguruar që rreshtimi i llojeve të ruhet.
    ///
    /// Kjo metodë e ndan fetë në tre feta të dallueshme: prefiksi, feta e mesit e rreshtuar saktë e një lloji të ri dhe feta e prapashtesës.
    /// Metoda mund ta bëjë fenë e mesit gjatësinë më të madhe të mundshme për një lloj të caktuar dhe fetë hyrëse, por vetëm performanca e algoritmit tuaj duhet të varet nga kjo, jo nga korrektësia e tij.
    ///
    /// Shtë e lejueshme që të gjitha të dhënat e dhëna të kthehen si prefiks ose fetë prapashtese.
    ///
    /// Kjo metodë nuk ka ndonjë qëllim kur elementi i hyrjes `T` ose elementi i daljes `U` janë me madhësi zero dhe do të kthejnë copën origjinale pa copëtuar asgjë.
    ///
    /// # Safety
    ///
    /// Kjo metodë është në thelb një `transmute` në lidhje me elementët në pjesën e mesme të kthyer, kështu që këtu zbatohen të gjitha paralajmërimet e zakonshme që i përkasin `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Vini re se shumica e këtij funksioni do të vlerësohet vazhdimisht,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // merreni me ZST-të posaçërisht, që është-mos i trajtoni fare.
            return (self, &[], &[]);
        }

        // Së pari, gjeni në cilën pikë ndahemi midis fetëës së parë dhe të dytë.
        // Lehtë me ptr.align_offset.
        let ptr = self.as_ptr();
        // SIGURIA: Shihni metodën `align_to_mut` për komentin e hollësishëm të sigurisë.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SIGURIA: tani `rest` është drejtpërdrejt i rreshtuar, kështu që `from_raw_parts` më poshtë është në rregull,
            // pasi thirrësi garanton që ne mund ta shndërrojmë `T` në `U` në mënyrë të sigurt.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmetoni fetë në një fetë të një lloji tjetër, duke siguruar që rreshtimi i llojeve të ruhet.
    ///
    /// Kjo metodë e ndan fetë në tre feta të dallueshme: prefiksi, feta e mesit e rreshtuar saktë e një lloji të ri dhe feta e prapashtesës.
    /// Metoda mund ta bëjë fenë e mesit gjatësinë më të madhe të mundshme për një lloj të caktuar dhe fetë hyrëse, por vetëm performanca e algoritmit tuaj duhet të varet nga kjo, jo nga korrektësia e tij.
    ///
    /// Shtë e lejueshme që të gjitha të dhënat e dhëna të kthehen si prefiks ose fetë prapashtese.
    ///
    /// Kjo metodë nuk ka ndonjë qëllim kur elementi i hyrjes `T` ose elementi i daljes `U` janë me madhësi zero dhe do të kthejnë copën origjinale pa copëtuar asgjë.
    ///
    /// # Safety
    ///
    /// Kjo metodë është në thelb një `transmute` në lidhje me elementët në pjesën e mesme të kthyer, kështu që këtu zbatohen të gjitha paralajmërimet e zakonshme që i përkasin `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Vini re se shumica e këtij funksioni do të vlerësohet vazhdimisht,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // merreni me ZST-të posaçërisht, që është-mos i trajtoni fare.
            return (self, &mut [], &mut []);
        }

        // Së pari, gjeni në cilën pikë ndahemi midis fetëës së parë dhe të dytë.
        // Lehtë me ptr.align_offset.
        let ptr = self.as_ptr();
        // SIGURIA: Këtu po sigurohemi se do të përdorim tregues të rreshtuar për U për
        // pjesa tjetër e metodës.Kjo bëhet duke kaluar një tregues te&[T] me një shtrirje të synuar për U.
        // `crate::ptr::align_offset` thirret me një tregues të saktë dhe të vlefshëm `ptr` (vjen nga një referencë në `self`) dhe me një madhësi që është një fuqi prej dy (pasi vjen nga përafrimi për U), duke përmbushur kufizimet e tij të sigurisë.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Ne nuk mund ta përdorim `rest` përsëri pas kësaj, kjo do të zhvleftësonte pseudonimin e tij `mut_ptr`!SIGURIA: shikoni komentet për `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Kontrollon nëse elementet e kësaj fete janë të renditura.
    ///
    /// Kjo do të thotë, për secilin element `a` dhe elementin e tij vijues `b`, `a <= b` duhet të mbajë.Nëse feta jep saktësisht zero ose një element, `true` kthehet.
    ///
    /// Vini re se nëse `Self::Item` është vetëm `PartialOrd`, por jo `Ord`, përkufizimi i mësipërm nënkupton që ky funksion kthen `false` nëse ndonjë prej dy artikujve radhazi nuk janë të krahasueshëm.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Kontrollon nëse elementet e kësaj fete janë renditur duke përdorur funksionin e dhënë krahasues.
    ///
    /// Në vend që të përdorë `PartialOrd::partial_cmp`, ky funksion përdor funksionin e dhënë `compare` për të përcaktuar renditjen e dy elementeve.
    /// Përveç kësaj, është ekuivalente me [`is_sorted`];shikoni dokumentacionin e tij për më shumë informacion.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Kontrollon nëse elementet e kësaj fete janë renditur duke përdorur funksionin e dhënë të nxjerrjes së çelësit.
    ///
    /// Në vend të krahasimit të elementeve të fetë drejtpërdrejt, ky funksion krahason çelësat e elementeve, siç përcaktohet nga `f`.
    /// Përveç kësaj, është ekuivalente me [`is_sorted`];shikoni dokumentacionin e tij për më shumë informacion.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Kthen indeksin e pikës së ndarjes sipas kallëzuesit të dhënë (indeksi i elementit të parë të ndarjes së dytë).
    ///
    /// Fetë supozohet të ndahet sipas kallëzuesit të dhënë.
    /// Kjo do të thotë që të gjithë elementët për të cilët kallëzuesi kthehet i vërtetë janë në fillim të pjesës dhe të gjithë elementët për të cilët kallëzuesi kthehet i rremë janë në fund.
    ///
    /// Për shembull, [7, 15, 3, 5, 4, 12, 6] është një ndarje nën kallëzuesin x% 2!=0 (të gjithë numrat tek janë në fillim, të gjithë madje edhe në fund).
    ///
    /// Nëse kjo fetë nuk është e ndarë, rezultati i kthyer është i paspecifikuar dhe i pakuptimtë, pasi kjo metodë kryen një lloj kërkimi binar.
    ///
    /// Shihni gjithashtu [`binary_search`], [`binary_search_by`] dhe [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SIGURIA: Kur `left < right`, `left <= mid < right`.
            // Prandaj `left` gjithmonë rritet dhe `right` gjithmonë zvogëlohet, dhe secila prej tyre zgjidhet.Në të dy rastet `left <= right` është i kënaqur.Prandaj nëse `left < right` në një hap, `left <= right` është i kënaqur në hapin tjetër.
            //
            // Prandaj, për sa kohë që `left != right`, `0 <= left < right <= len` është i kënaqur dhe nëse edhe ky rast është i kënaqur `0 <= mid < len`.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Ne duhet t'i presim në mënyrë eksplicite në të njëjtën gjatësi
        // për ta bërë më të lehtë për optimizuesin që të heq kontrollin e kufijve.
        // Por meqenëse nuk mund të mbështetet, ne gjithashtu kemi një specializim të qartë për T: Kopjo.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Krijon një fetë bosh.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Krijon një fetë bosh të paqëndrueshme.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Modele në feta, aktualisht, të përdorura vetëm nga `strip_prefix` dhe `strip_suffix`.
/// Në një pikë future, ne shpresojmë të përgjithësojmë `core::str::Pattern` (i cili në kohën e shkrimit është i kufizuar në `str`) në feta, dhe pastaj ky trait do të zëvendësohet ose shfuqizohet.
///
pub trait SlicePattern {
    /// Lloji i elementit të fetë që përputhet.
    type Item;

    /// Aktualisht, konsumatorët e `SlicePattern` kanë nevojë për një copë.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}