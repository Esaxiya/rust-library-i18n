// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Rrotullon diapazonin `[mid-left, mid+right)` të tillë që elementi në `mid` të bëhet elementi i parë.Në mënyrë ekuivalente, rrotullon elementët e diapazonit `left` në të majtë ose elementët `right` në të djathtë.
///
/// # Safety
///
/// Diapazoni i specifikuar duhet të jetë i vlefshëm për leximin dhe shkrimin.
///
/// # Algorithm
///
/// Algoritmi 1 përdoret për vlera të vogla të `left + right` ose për `T` të mëdha.
/// Elementet zhvendosen në pozicionet e tyre përfundimtare një nga një duke filluar nga `mid - left` dhe avancohen nga hapat `right` modulo `left + right`, i tillë që të nevojitet vetëm një i përkohshëm.
/// Përfundimisht, ne mbërrijmë përsëri në `mid - left`.
/// Sidoqoftë, nëse `gcd(left + right, right)` nuk është 1, hapat e mësipërm anashkalohen mbi elementet.
/// Për shembull:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Për fat të mirë, numri i elementeve të anashkaluara midis elementeve të përfunduara është gjithmonë i barabartë, kështu që ne thjesht mund të kompensojmë pozicionin tonë fillestar dhe të bëjmë më shumë raunde (numri i përgjithshëm i raundeve është `gcd(left + right, right)` value).
///
/// Rezultati përfundimtar është që të gjithë elementët të finalizohen një herë dhe vetëm një herë.
///
/// Algoritmi 2 përdoret nëse `left + right` është i madh, por `min(left, right)` është aq i vogël sa të përshtatet në një buffer stack.
/// Elementet `min(left, right)` kopjohen në tampon, `memmove` zbatohet te të tjerët, dhe ato në tampon zhvendosen përsëri në vrimë në anën e kundërt të vendit ku kanë origjinën.
///
/// Algoritmet që mund të vektorizohen tejkalojnë sa më sipër sapo `left + right` të bëhet mjaft i madh.
/// Algoritmi 1 mund të vektorizohet duke copëtuar dhe kryer shumë raunde në të njëjtën kohë, por ka shumë pak xhiro mesatarisht derisa `left + right` të jetë i madh, dhe rasti më i keq i një raundi të vetëm është gjithmonë aty.
/// Në vend të kësaj, algoritmi 3 shfrytëzon shkëmbimin e përsëritur të elementeve `min(left, right)` derisa të lihet një problem më i vogël rrotullimi.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// kur `left < right` ndërrimi ndodh nga e majta në vend.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. algoritmet e mëposhtëm mund të dështojnë nëse këto raste nuk kontrollohen
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Mikrobenchmarks Algoritmi 1 tregojnë se performanca mesatare për ndërrime të rastit është më e mirë deri në rreth `left + right == 32`, por performanca e rastit më të keq prishet madje rreth 16.
            // 24 u zgjodh si terren i mesëm.
            // Nëse madhësia e `T` është më e madhe se 4 usize `s, ky algoritëm gjithashtu tejkalon performancën e algoritmeve të tjerë.
            //
            //
            let x = unsafe { mid.sub(left) };
            // fillimi i raundit të parë
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` mund të gjendet përpara dorës duke llogaritur `gcd(left + right, right)`, por është më shpejt të bësh një lak që llogarit gcd si një efekt anësor, pastaj duke bërë pjesën tjetër të copës
            //
            //
            let mut gcd = right;
            // Standardet tregojnë se është më shpejt të ndërrosh bashkëkohësit deri në vend që të lexosh një të përkohshëm një herë, të kopjosh mbrapsht dhe pastaj ta shkruash atë të përkohshme në fund.
            // Kjo është ndoshta për shkak të faktit se ndërrimi ose zëvendësimi i përkohësve përdor vetëm një adresë kujtese në lak në vend që të ketë nevojë për të menaxhuar dy.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // në vend që të rritim `i` dhe pastaj të kontrollojmë nëse është jashtë kufijve, ne kontrollojmë nëse `i` do të dalë jashtë kufijve në rritjen tjetër.
                // Kjo parandalon çdo mbështjellje të treguesve ose `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // fundi i raundit të parë
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ky kusht duhet të jetë këtu nëse `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // përfundoni copën me më shumë raunde
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` nuk është një lloj me madhësi zero, kështu që është në rregull të ndahet me madhësinë e tij.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmi 2 `[T; 0]` këtu është për të siguruar që është rreshtuar në mënyrë të përshtatshme për T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmi 3 Ekziston një mënyrë alternative e ndërrimit që përfshin gjetjen se ku do të ishte shkëmbimi i fundit i këtij algoritmi dhe shkëmbimi duke përdorur atë copë të fundit në vend të ndërrimit të pjesëve ngjitur siç bën ky algoritëm, por kjo mënyrë është akoma më e shpejtë.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritmi 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}