//! Operacionet në ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Kontrollon nëse të gjithë bajtët në këtë pjesë janë brenda intervalit ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Kontrollon që dy feta janë një përputhje e pandjeshme e çështjes ASCII.
    ///
    /// Njësoj si `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, por pa alokuar dhe kopjuar përkohësit.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Konverton këtë fetë në ekuivalentin e saj me shkronja të mëdha ASCII në vend.
    ///
    /// Shkronjat ASCII 'a' në 'z' janë të shënuara në 'A' në 'Z', por shkronjat jo ASCII janë të pandryshuara.
    ///
    /// Për të kthyer një vlerë të re me shkronja të mëdha pa modifikuar atë ekzistuese, përdorni [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Konverton këtë fetë në ekuivalentin e saj me shkronja të vogla ASCII në vend.
    ///
    /// Shkronjat ASCII 'A' në 'Z' janë të shënuara në 'a' në 'z', por shkronjat jo-ASCII janë të pandryshuara.
    ///
    /// Për të kthyer një vlerë të re të vogël, pa modifikuar atë ekzistuese, përdorni [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Kthen `true` nëse ndonjë bajt në fjalën `v` është nonascii (>=128).
/// Snarfed nga `../str/mod.rs`, i cili bën diçka të ngjashme për vërtetimin utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Testi i optimizuar ASCII që do të përdorë operacionet e përdorimit në një kohë në vend të operacioneve bajt në një kohë (kur është e mundur).
///
/// Algoritmi që ne përdorim këtu është shumë i thjeshtë.Nëse `s` është shumë i shkurtër, ne thjesht kontrollojmë secilin bajt dhe përfundojmë me të.Përndryshe:
///
/// - Lexoni fjalën e parë me një ngarkesë të pavendosur.
/// - Renditni treguesin, lexoni fjalët vijuese deri në fund me ngarkesa të rreshtuara.
/// - Lexoni `usize` të fundit nga `s` me një ngarkesë të pavendosur.
///
/// Nëse ndonjë nga këto ngarkesa prodhon diçka për të cilën `contains_nonascii` (above) kthehet e vërtetë, atëherë ne e dimë që përgjigjja është e gabuar.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Nëse nuk do të përfitonim asgjë nga implementimi fjalë për kohë, kthehuni përsëri në një lak skalar.
    //
    // Ne gjithashtu e bëjmë këtë për arkitektura ku `size_of::<usize>()` nuk është rreshtim i mjaftueshëm për `usize`, sepse është një rast i çuditshëm edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Ne gjithmonë lexojmë fjalën e parë të pa rreshtuar, që do të thotë se `align_offset` është
    // 0, ne do të lexonim të njëjtën vlerë përsëri për leximin e rreshtuar.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SIGURIA: Ne verifikojmë `len < USIZE_SIZE` më lart.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Ne e kontrolluam këtë më lart, disi në mënyrë implicite.
    // Vini re se `offset_to_aligned` është ose `align_offset` ose `USIZE_SIZE`, të dyja janë kontrolluar qartë më sipër.
    //
    debug_assert!(offset_to_aligned <= len);

    // SIGURIA: word_ptr është ptr përdorimi (i rreshtuar si duhet) që përdorim për të lexuar
    // copa e mesme e fetë.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` është indeksi bajt i `word_ptr`, i përdorur për kontrollet në fund të lakut.
    let mut byte_pos = offset_to_aligned;

    // Kontrolloni Paranoia për shtrirjen, pasi ne jemi gati të bëjmë një bandë ngarkesash të pavendosura.
    // Megjithatë, në praktikë kjo duhet të jetë e pamundur përjashtuar një të metë në `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Lexoni fjalët vijuese deri në fjalën e fundit të rreshtuar, duke përjashtuar fjalën e fundit të rreshtuar në vetvete që do të bëhet në kontrollin e bishtit më vonë, për të siguruar që bishti të jetë gjithmonë një `usize` më së shumti tek branch `byte_pos == len` shtesë.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Kontrolloni mendjen se leximi është në kufij
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Dhe se supozimet tona në lidhje me `byte_pos` mbajnë.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SIGURIA: Ne e dimë që `word_ptr` është në përputhje të duhur (për shkak të
        // `align_offset`), dhe ne e dimë që kemi mjaft bajte midis `word_ptr` dhe fundit
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SIGURIA: Ne e dimë se `byte_pos <= len - USIZE_SIZE`, që do të thotë se
        // pas këtij `add`, `word_ptr` do të jetë më së shumti një e kaluar.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Kontroll i mendjes së shëndoshë për të siguruar që ka mbetur vetëm një `usize`.
    // Kjo duhet të garantohet nga gjendja jonë e lakut.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SIGURIA: Kjo mbështetet te `len >= USIZE_SIZE`, të cilën ne e kontrollojmë në fillim.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}