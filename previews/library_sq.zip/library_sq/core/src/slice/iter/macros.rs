//! Makrot e përdorura nga përsëritësit e pjesëve.

// Renditja është_boshe dhe len bën një ndryshim të madh të performancës
macro_rules! is_empty {
    // Mënyra se si kodifikojmë gjatësinë e një iteratori ZST, kjo funksionon si për ZST ashtu edhe për jo-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Për të hequr qafe disa kontrolle kufijsh (shih `position`), ne llogarisim gjatësinë në një mënyrë disi të papritur.
// (Testuar nga `kodi/kontrolli i pozicionit të fetë-pozicionit`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // ne jemi përdorur ndonjëherë brenda një blloku të pasigurt

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ky _cannot_ përdor `unchecked_sub` sepse ne varet nga mbështjellja për të përfaqësuar gjatësinë e përsëritësve të gjatë të feta ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Ne e dimë që `start <= end`, kështu që mund të bëjmë më mirë se `offset_from`, i cili duhet të merret nënshkruar.
            // Duke vendosur flamuj të përshtatshëm këtu, ne mund t'ia tregojmë LLVM këtë, e cila e ndihmon atë të heqë kontrollet e kufijve.
            // SIGURIA: Sipas llojit të pandryshueshëm, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Duke i thënë gjithashtu LLVM se treguesit janë larg nga një shumëfish i saktë i madhësisë së tipit, ai mund të optimizojë `len() == 0` deri në `start == end` në vend të `(end - start) < size`.
            //
            // SIGURIA: Sipas llojit të pandryshueshëm, treguesit janë drejtuar në mënyrë që
            //         distanca midis tyre duhet të jetë një shumëfish i madhësisë së pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Përkufizimi i përbashkët i përsëritësve `Iter` dhe `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Kthen elementin e parë dhe lëviz fillimin e iteratorit përpara me 1.
        // Përmirëson shumë performancën në krahasim me një funksion të nënvizuar.
        // Përsëritësi nuk duhet të jetë bosh.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Kthen elementin e fundit dhe lëviz fundin e iteratorit prapa me 1.
        // Përmirëson shumë performancën në krahasim me një funksion të nënvizuar.
        // Përsëritësi nuk duhet të jetë bosh.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Tkurr iteratorin kur T është ZST, duke lëvizur fundin e iteratorit prapa me `n`.
        // `n` nuk duhet të kalojë `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Funksion ndihmës për krijimin e një fete nga iteratori.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SIGURIA: iteratori u krijua nga një fetë me tregues
                // `self.ptr` dhe gjatësia `len!(self)`.
                // Kjo garanton që të gjitha parakushtet për `from_raw_parts` janë përmbushur.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Funksioni ndihmës për lëvizjen e fillimit të iteratorit përpara nga elementët `offset`, duke kthyer fillimin e vjetër.
            //
            // E pasigurt sepse kompensimi nuk duhet të kalojë `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SIGURIA: telefonuesi garanton që `offset` nuk e kalon `self.len()`,
                    // kështu që ky tregues i ri është brenda `self` dhe kështu garantohet që të mos jetë nul.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Funksion ndihmës për lëvizjen e fundit të iteratorit prapa nga elementët `offset`, duke kthyer fundin e ri.
            //
            // E pasigurt sepse kompensimi nuk duhet të kalojë `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SIGURIA: telefonuesi garanton që `offset` nuk e kalon `self.len()`,
                    // e cila është e garantuar të mos tejkalojë një `isize`.
                    // Gjithashtu, treguesi që rezulton është në kufijtë e `slice`, i cili plotëson kërkesat e tjera për `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // mund të zbatohet me feta, por kjo shmang kontrollet e kufijve

                // SIGURIA: Thirrjet `assume` janë të sigurta që nga treguesi i fillimit të një flete
                // duhet të jetë jo-null, dhe fetë mbi jo-ZST duhet të kenë gjithashtu një tregues fundor jo-null.
                // Telefonata për në `next_unchecked!` është e sigurt pasi që ne kontrollojmë nëse përsëritësi është bosh së pari.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ky përsëritës tani është bosh.
                    if mem::size_of::<T>() == 0 {
                        // Ne duhet ta bëjmë në këtë mënyrë pasi `ptr` mund të mos jetë kurrë 0, por `end` mund të jetë (për shkak të mbështjelljes).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SIGURIA: fundi nuk mund të jetë 0 nëse T nuk është ZST sepse ptr nuk është 0 dhe fundi>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SIGURIA: Ne jemi në kufij.`post_inc_start` bën gjënë e duhur edhe për ZST-të.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Ne anashkalojmë zbatimin e paracaktuar, i cili përdor `try_fold`, sepse ky implementim i thjeshtë gjeneron më pak IR LLVM dhe përpilohet më shpejt.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Ne anashkalojmë zbatimin e paracaktuar, i cili përdor `try_fold`, sepse ky implementim i thjeshtë gjeneron më pak IR LLVM dhe përpilohet më shpejt.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Ne anashkalojmë zbatimin e paracaktuar, i cili përdor `try_fold`, sepse ky implementim i thjeshtë gjeneron më pak IR LLVM dhe përpilohet më shpejt.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Ne anashkalojmë zbatimin e paracaktuar, i cili përdor `try_fold`, sepse ky implementim i thjeshtë gjeneron më pak IR LLVM dhe përpilohet më shpejt.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Ne anashkalojmë zbatimin e paracaktuar, i cili përdor `try_fold`, sepse ky implementim i thjeshtë gjeneron më pak IR LLVM dhe përpilohet më shpejt.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Ne anashkalojmë zbatimin e paracaktuar, i cili përdor `try_fold`, sepse ky implementim i thjeshtë gjeneron më pak IR LLVM dhe përpilohet më shpejt.
            // Gjithashtu, `assume` shmang një kontroll të kufijve.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SIGURIA: ne jemi të garantuar të jemi në kufij nga cikli i pandryshueshëm:
                        // kur `i >= n`, `self.next()` kthen `None` dhe lakja prishet.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Ne anashkalojmë zbatimin e paracaktuar, i cili përdor `try_fold`, sepse ky implementim i thjeshtë gjeneron më pak IR LLVM dhe përpilohet më shpejt.
            // Gjithashtu, `assume` shmang një kontroll të kufijve.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SIGURIA: `i` duhet të jetë më e ulët se `n` pasi fillon me `n`
                        // dhe vetëm po zvogëlohet.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SIGURIA: thirrësi duhet të garantojë që `i` është në kufij
                // feta themelore, kështu që `i` nuk mund të tejkalojë një `isize`, dhe referencat e kthyera garantohen se i referohen një elementi të fotos dhe kështu garantohet të jetë e vlefshme.
                //
                // Gjithashtu vini re se telefonuesi gjithashtu garanton që ne kurrë nuk jemi thirrur me të njëjtin indeks, dhe se nuk thirren asnjë metodë tjetër që do të hyjnë në këtë nënfushë, kështu që është e vlefshme që referenca e kthyer të jetë e ndryshueshme në
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // mund të zbatohet me feta, por kjo shmang kontrollet e kufijve

                // SIGURIA: Thirrjet `assume` janë të sigurta pasi treguesi fillestar i një flete duhet të mos jetë i pavlefshëm,
                // dhe fetë mbi jo-ZST duhet të kenë gjithashtu një tregues fundor jo-null.
                // Telefonata për në `next_back_unchecked!` është e sigurt pasi që ne kontrollojmë nëse përsëritësi është bosh së pari.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ky përsëritës tani është bosh.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SIGURIA: Ne jemi në kufij.`pre_dec_end` bën gjënë e duhur edhe për ZST-të.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}