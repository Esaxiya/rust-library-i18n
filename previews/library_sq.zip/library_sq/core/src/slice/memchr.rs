// Zbatimi origjinal është marrë nga rust-memchr.
// E drejta e autorit 2015 Andrew Gallant, bluss dhe Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Përdorni shkurtimin.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Kthen `true` nëse `x` përmban ndonjë zero bajt.
///
/// Nga *Matters Computational*, J. Arndt:
///
/// "Ideja është që të zbres një nga secili prej bajtëve dhe pastaj të kërkohet për bajte ku huazimi përhapet deri në më të rëndësishmet
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Kthen indeksin e parë që përputhet me bajtin `x` në `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Shteg i shpejtë për feta të vogla
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Skanoni për një vlerë të vetme bajt duke lexuar dy fjalë `usize` në të njëjtën kohë.
    //
    // Ndani `text` në tre pjesë
    // - pjesa fillestare e pa rreshtuar, para fjalës së parë adresa e rreshtuar në tekst
    // - trup, skanoni me 2 fjalë në të njëjtën kohë
    // - pjesa e fundit e mbetur, <2 madhësia e fjalës

    // kërkoni deri në një kufi të rreshtuar
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // kërkoni trupin e tekstit
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SIGURIA: kallëzuesi ndërkohë garanton një distancë prej të paktën 2 * usize_bytes
        // midis kompensimit dhe fundit të fetë.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // pushim nëse ka një bajt që përputhet
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Gjeni bajtin pas pikës që laku i trupit u ndal.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Kthen indeksin e fundit që përputhet me bajtin `x` në `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Skanoni për një vlerë të vetme bajt duke lexuar dy fjalë `usize` në të njëjtën kohë.
    //
    // Ndani `text` në tre pjesë:
    // - bisht i pa rreshtuar, pas fjalës së fundit adresa e rreshtuar në tekst,
    // - trup, skanuar nga 2 fjalë në të njëjtën kohë,
    // - bajtet e para të mbetura, <2 madhësia e fjalës.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Ne e quajmë këtë vetëm për të marrë gjatësinë e parashtesës dhe prapashtesës.
        // Në mes, ne gjithmonë përpunojmë dy copa në të njëjtën kohë.
        // SIGURIA: shndërrimi i `[u8]` në `[usize]` është i sigurt me përjashtim të ndryshimeve në madhësi të cilat trajtohen nga `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Kërkoni trupin e tekstit, sigurohuni që të mos kalojmë min_aligned_offset.
    // kompensimi është gjithmonë në një linjë, kështu që vetëm testimi i `>` është i mjaftueshëm dhe shmang tejmbushjen e mundshme.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SIGURIA: kompensimi fillon me len, suffix.len(), për sa kohë që është më i madh se
        // min_aligned_offset (prefix.len()) distanca e mbetur është të paktën 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Prisni nëse ka një bajt që përputhet.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Gjeni bajtin para pikës që laku i trupit të ndalet.
    text[..offset].iter().rposition(|elt| *elt == x)
}