//! Renditja e fetave
//!
//! Ky modul përmban një algoritëm të renditjes bazuar në quicksort-in-mposhtës të modelit të Orson Peters, botuar në: <https://github.com/orlp/pdqsort>
//!
//!
//! Renditja e paqëndrueshme është e pajtueshme me libcore sepse nuk cakton memorje, ndryshe nga implementimi ynë i qëndrueshëm i renditjes.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Kur bie, kopjoni nga `src` në `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SIGURIA: Kjo është një klasë ndihmëse.
        //          Ju lutemi referojuni përdorimit të tij për korrektësi.
        //          Gjegjësisht, duhet të jemi të sigurt se `src` dhe `dst` nuk mbivendosen siç kërkohet nga `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Zhvendos elementin e parë në të djathtë derisa të hasë një element më të madh ose të barabartë.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SIGURIA: Operacionet e pasigurta më poshtë përfshijnë indeksimin pa një kontroll të detyruar (`get_unchecked` dhe `get_unchecked_mut`)
    // dhe kopjimi i kujtesës (`ptr::copy_nonoverlapping`).
    //
    // aIndeksimi:
    //  1. Ne kontrolluam madhësinë e grupit në>=2.
    //  2. E gjithë indeksimi që ne do të bëjmë është gjithmonë midis {0 <= index < len} më së shumti.
    //
    // bKopjimi i kujtesës
    //  1. Ne jemi duke marrë tregues për referencat të cilat janë të garantuara të jenë të vlefshme.
    //  2. Ato nuk mund të mbivendosen sepse marrim tregues të indekseve të diferencës së fetë.
    //     Gjegjësisht, `i` dhe `i-1`.
    //  3. Nëse feta është e rreshtuar si duhet, elementet rreshtohen siç duhet.
    //     Responsibilityshtë përgjegjësia e telefonuesit që të sigurohet që feta është në një linjë të duhur.
    //
    // Shihni komentet më poshtë për detaje të mëtejshme.
    unsafe {
        // Nëse dy elementët e parë janë jashtë funksionit ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Lexoni elementin e parë në një variabël të caktuar në pirg.
            // Nëse një operacion krahasimi vijues panics, `hole` do të bjerë dhe automatikisht shkruaj elementin përsëri në fetë.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Lëvizni elementin `i`-të një vend në të majtë, duke zhvendosur kështu vrimën në të djathtë.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` bie dhe kështu kopjon `tmp` në vrimën e mbetur në `v`.
        }
    }
}

/// Zhvendos elementin e fundit në të majtë derisa të hasë një element më të vogël ose të barabartë.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SIGURIA: Operacionet e pasigurta më poshtë përfshijnë indeksimin pa një kontroll të detyruar (`get_unchecked` dhe `get_unchecked_mut`)
    // dhe kopjimi i kujtesës (`ptr::copy_nonoverlapping`).
    //
    // aIndeksimi:
    //  1. Ne kontrolluam madhësinë e grupit në>=2.
    //  2. E gjithë indeksimi që ne do të bëjmë është gjithmonë midis `0 <= index < len-1` më së shumti.
    //
    // bKopjimi i kujtesës
    //  1. Ne jemi duke marrë tregues për referencat të cilat janë të garantuara të jenë të vlefshme.
    //  2. Ato nuk mund të mbivendosen sepse marrim tregues të indekseve të diferencës së fetë.
    //     Gjegjësisht, `i` dhe `i+1`.
    //  3. Nëse feta është e rreshtuar si duhet, elementet rreshtohen siç duhet.
    //     Responsibilityshtë përgjegjësia e telefonuesit që të sigurohet që feta është në një linjë të duhur.
    //
    // Shihni komentet më poshtë për detaje të mëtejshme.
    unsafe {
        // Nëse dy elementët e fundit janë jashtë funksionit ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Lexoni elementin e fundit në një variabël të caktuar në pirg.
            // Nëse një operacion krahasimi vijues panics, `hole` do të bjerë dhe automatikisht shkruaj elementin përsëri në fetë.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Lëvizni elementin `i` një vend në të djathtë, duke zhvendosur kështu vrimën në të majtë.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` bie dhe kështu kopjon `tmp` në vrimën e mbetur në `v`.
        }
    }
}

/// Rendit pjesërisht një fetë duke zhvendosur disa elementë jashtë rendit përreth.
///
/// Kthen `true` nëse feta është renditur në fund.Ky funksion është *O*(*n*) rasti më i keq.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Numri maksimal i çifteve ngjitur jashtë rendit që do të zhvendosen.
    const MAX_STEPS: usize = 5;
    // Nëse feta është më e shkurtër se kjo, mos zhvendosni asnjë element.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SIGURIA: Ne tashmë e kemi bërë në mënyrë të qartë kontrollimin e detyruar me `i < len`.
        // I gjithë indeksimi ynë pasues është vetëm në intervalin `0 <= index < len`
        unsafe {
            // Gjeni çiftin tjetër të elementeve ngjitur jashtë renditjes.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // A kemi mbaruar
        if i == len {
            return true;
        }

        // Mos zhvendosni elementet në vargje të shkurtra, që ka një kosto të performancës.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Ndërroni palën e gjetur të elementeve.Kjo i vendos ato në rendin e duhur.
        v.swap(i - 1, i);

        // Zhvendosni elementin më të vogël në të majtë.
        shift_tail(&mut v[..i], is_less);
        // Zhvendosni elementin më të madh në të djathtë.
        shift_head(&mut v[i..], is_less);
    }

    // Nuk arrita të zgjidhte fetë në numrin e kufizuar të hapave.
    false
}

/// Rendit një fetë duke përdorur llojin e futjes, i cili është *O*(*n*^ 2) rasti më i keq.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Rendit `v` duke përdorur grupin e grumbulluar, i cili garanton *O*(*n*\*log(* n*)) rastin më të keq.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ky grumbull binar respekton `parent >= child` të pandryshuar.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Fëmijët e `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Zgjidhni fëmijën më të madh.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Ndaloni nëse pandryshimi qëndron në `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Ndërroni `node` me fëmijën më të madh, lëvizni një hap poshtë dhe vazhdoni të sitni.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Ndërtoni grumbullin në kohë lineare.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop elementet maksimale nga grumbulli.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Ndarjet `v` në elemente më të vogla se `pivot`, të ndjekura nga elemente më të mëdha ose të barabarta me `pivot`.
///
///
/// Kthen numrin e elementeve më të vegjël se `pivot`.
///
/// Ndarja kryhet bllok për bllok në mënyrë që të minimizohet kostoja e operacioneve të degëzimit.
/// Kjo ide paraqitet në punimin [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Numri i elementeve në një bllok tipik.
    const BLOCK: usize = 128;

    // Algoritmi i ndarjes përsërit hapat e mëposhtëm deri në përfundim:
    //
    // 1. Gjurmoni një bllok nga ana e majtë për të identifikuar elemente më të mëdha ose të barabarta me boshtin.
    // 2. Gjurmoni një bllok nga ana e djathtë për të identifikuar elementë më të vegjël se boshti.
    // 3. Shkëmbeni elementët e identifikuar midis anës së majtë dhe të djathtë.
    //
    // Ne i mbajmë variablat e mëposhtëm për një bllok elementesh:
    //
    // 1. `block` - Numri i elementeve në bllok.
    // 2. `start` - Filloni treguesin në grupin `offsets`.
    // 3. `end` - Fundi i treguesit në grupin `offsets`.
    // 4. `offsets, Treguesit e elementeve jashtë rendit brenda bllokut.

    // Blloku aktual në anën e majtë (nga `l` në `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Blloku aktual në anën e djathtë (nga `r.sub(block_r)` to `r`).
    // SIGURIA: Dokumentacioni për .add() përmend specifikisht që `vec.as_ptr().add(vec.len())` është gjithmonë i sigurt`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Kur marrim VLA, më mirë provoni të krijoni një grup me gjatësi `min(v.len(), 2 * BLOCK) `
    // se dy vargje me madhësi fikse me gjatësi `BLOCK`.VLA-të mund të jenë më efikase në memorjen memorëse.

    // Kthen numrin e elementeve ndërmjet treguesve `l` (inclusive) dhe `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Ne kemi mbaruar me ndarjen bllok-nga-bllok kur `l` dhe `r` afrohen shumë.
        // Pastaj bëjmë një punë patch-up në mënyrë që të ndajmë elementët e mbetur në mes.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Numri i elementeve të mbetura (akoma nuk krahasohet me pivotin).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Rregulloni madhësitë e bllokut në mënyrë që blloku i majtë dhe i djathtë të mos mbivendosen, por të rreshtohen në mënyrë të përsosur për të mbuluar të gjithë boshllëkun e mbetur.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Gjurmoni elementët `block_l` nga ana e majtë.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SIGURIA: Operacionet e pasigurisë më poshtë përfshijnë përdorimin e `offset`.
                //         Sipas kushteve të kërkuara nga funksioni, ne i përmbushim ato sepse:
                //         1. `offsets_l` është alokuar pirg, dhe kështu konsiderohet objekt i ndarë i ndarë.
                //         2. Funksioni `is_less` kthen një `bool`.
                //            Hedhja e një `bool` nuk do të tejkalojë kurrë `isize`.
                //         3. Ne kemi garantuar që `block_l` do të jetë `<= BLOCK`.
                //            Plus, `end_l` fillimisht ishte vendosur në treguesin startues të `offsets_` i cili ishte deklaruar në pirg.
                //            Kështu, ne e dimë që edhe në rastin më të keq (të gjitha thirrjet e `is_less` kthehen false) ne do të jemi më së shumti 1 bajt që kalon fundin.
                //        Një operacion tjetër i pasigurisë këtu është referimi `elem`.
                //        Sidoqoftë, `elem` ishte fillimisht treguesi fillestar për fetë e cila është gjithmonë e vlefshme.
                unsafe {
                    // Krahasimi pa degë.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Gjurmoni elementet `block_r` nga ana e djathtë.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SIGURIA: Operacionet e pasigurisë më poshtë përfshijnë përdorimin e `offset`.
                //         Sipas kushteve të kërkuara nga funksioni, ne i përmbushim ato sepse:
                //         1. `offsets_r` është alokuar pirg, dhe kështu konsiderohet objekt i ndarë i ndarë.
                //         2. Funksioni `is_less` kthen një `bool`.
                //            Hedhja e një `bool` nuk do të tejkalojë kurrë `isize`.
                //         3. Ne kemi garantuar që `block_r` do të jetë `<= BLOCK`.
                //            Plus, `end_r` fillimisht ishte vendosur në treguesin startues të `offsets_` i cili ishte deklaruar në pirg.
                //            Kështu, ne e dimë që edhe në rastin më të keq (të gjitha thirrjet e `is_less` kthehen të vërteta) ne do të jemi vetëm më së shumti 1 bajt në fund.
                //        Një operacion tjetër i pasigurisë këtu është referimi `elem`.
                //        Sidoqoftë, `elem` fillimisht ishte `1 *sizeof(T)` pas fundit dhe ne e zvogëlonim atë me `1* sizeof(T)` përpara se ta përdorim.
                //        Plus, `block_r` u pohua të jetë më pak se `BLOCK` dhe `elem` do të tregojë më së shumti në fillim të pjesës.
                unsafe {
                    // Krahasimi pa degë.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Numri i elementeve jashtë rendit për tu shkëmbyer midis anës së majtë dhe të djathtë.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Në vend që të ndërroni një palë në atë kohë, është më efikase të kryeni një ndërrim ciklik.
            // Kjo nuk është saktësisht ekuivalente me ndërrimin, por prodhon një rezultat të ngjashëm duke përdorur më pak operacione të kujtesës.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Të gjithë elementët jashtë rendit në bllokun e majtë u zhvendosën.Kaloni në bllokun tjetër.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Të gjithë elementët jashtë rendit në bllokun e djathtë u zhvendosën.Kaloni në bllokun e mëparshëm.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // E tëra që mbetet tani është më së shumti një bllok (ose majtas ose djathtas) me elemente jashtë rendit që duhen lëvizur.
    // Elementë të tillë të mbetur thjesht mund të zhvendosen deri në fund brenda bllokut të tyre.
    //

    if start_l < end_l {
        // Blloku i majtë mbetet.
        // Lëvizni elementët e tij të mbetur jashtë rendit në të djathtën ekstreme.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Blloku i duhur mbetet.
        // Lëvizni elementet e tij të mbetur jashtë rendit në të majtën.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Asgjë tjetër për të bërë, ne kemi mbaruar.
        width(v.as_mut_ptr(), l)
    }
}

/// Ndarjet `v` në elemente më të vogla se `v[pivot]`, të ndjekura nga elemente më të mëdha ose të barabarta me `v[pivot]`.
///
///
/// Kthen një pjesë të:
///
/// 1. Numri i elementeve më të vegjël se `v[pivot]`.
/// 2. E vërtetë nëse `v` ishte ndarë tashmë.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Vendosni boshtin në fillim të fetë.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Lexoni boshtin në një variabël të caktuar për pirg për efikasitetin.
        // Nëse një operacion krahasimi vijues panics, boshti do të shkruhet automatikisht përsëri në fetë.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Gjeni çiftin e parë të elementeve jashtë renditjes.
        let mut l = 0;
        let mut r = v.len();

        // SIGURIA: Pasiguria më poshtë përfshin indeksimin e një grupi.
        // Për të parën: Ne tashmë bëjmë kontrollimin e kufijve këtu me `l < r`.
        // Për të dytën: Fillimisht kemi `l == 0` dhe `r == v.len()` dhe kemi kontrolluar atë `l < r` në çdo operacion indeksimi.
        //                     Nga këtu ne e dimë që `r` duhet të jetë së paku `r == l` e cila u tregua e vlefshme nga e para.
        unsafe {
            // Gjeni elementin e parë më të madh ose të barabartë me boshtin.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Gjeni elementin e fundit më të vogël se boshti.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` del nga fushëveprimi dhe shkruan strumbullarin (i cili është një variabël i alokuar në pirg) përsëri në atë pjesë ku ishte fillimisht.
        // Ky hap është kritik në garantimin e sigurisë!
        //
    };

    // Vendosni boshtin midis dy ndarjeve.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Ndarjet `v` në elemente të barabarta me `v[pivot]` të ndjekura nga elemente më të mëdha se `v[pivot]`.
///
/// Kthen numrin e elementeve të barabartë me boshtin.
/// Supozohet se `v` nuk përmban elementë më të vegjël se boshti.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Vendosni boshtin në fillim të fetë.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Lexoni boshtin në një variabël të caktuar për pirg për efikasitetin.
    // Nëse një operacion krahasimi vijues panics, boshti do të shkruhet automatikisht përsëri në fetë.
    // SIGURIA: Treguesi këtu është i vlefshëm sepse merret nga një referencë në një fetë.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Tani ndani fetë.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SIGURIA: Pasiguria më poshtë përfshin indeksimin e një grupi.
        // Për të parën: Ne tashmë bëjmë kontrollimin e kufijve këtu me `l < r`.
        // Për të dytën: Fillimisht kemi `l == 0` dhe `r == v.len()` dhe kemi kontrolluar atë `l < r` në çdo operacion indeksimi.
        //                     Nga këtu ne e dimë që `r` duhet të jetë së paku `r == l` e cila u tregua e vlefshme nga e para.
        unsafe {
            // Gjeni elementin e parë më të madh se boshti.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Gjeni elementin e fundit të barabartë me boshtin.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // A kemi mbaruar
            if l >= r {
                break;
            }

            // Ndërroni çiftin e gjetur të elementeve jashtë renditjes.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Gjetëm elemente `l` të barabarta me boshtin.Shto 1 për të llogaritur vetë boshtin.
    l + 1

    // `_pivot_guard` del nga fushëveprimi dhe shkruan strumbullarin (i cili është një variabël i alokuar në pirg) përsëri në atë pjesë ku ishte fillimisht.
    // Ky hap është kritik në garantimin e sigurisë!
}

/// Shpërndan disa elementë përreth në një përpjekje për të thyer modele që mund të shkaktojnë ndarje të çekuilibruara në grupin e parë.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Gjenerator i numrave të rremë nga letra "Xorshift RNGs" nga George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Merrni numrat e rastit modulo këtë numër.
        // Numri përshtatet në `usize` sepse `len` nuk është më i madh se `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Disa kandidatë kryesorë do të jenë në afërsi të këtij indeksi.Le t'i rastësojmë ata.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Gjeneroni një modul të numrave të rastit `len`.
            // Sidoqoftë, në mënyrë që të shmangim operacione të kushtueshme, së pari marrim atë në modul me një fuqi prej dy, dhe pastaj ulemi me `len` derisa të përshtatet në intervalin `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` është e garantuar të jetë më e vogël se `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Zgjedh një strumbullar në `v` dhe kthen indeksin dhe `true` nëse feta është e zgjidhur tashmë.
///
/// Elementet në `v` mund të renditen përsëri në proces.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Gjatësia minimale për të zgjedhur metodën mesatare e mesatareve.
    // Feta më të shkurtra përdorin metodën e thjeshtë mesatare të tre.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Numri maksimal i ndërrimeve që mund të kryhen në këtë funksion.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tre indekse pranë të cilave do të zgjedhim një strumbullar.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Numëron numrin e përgjithshëm të swap-eve që do të kryejmë gjatë klasifikimit të indekseve.
    let mut swaps = 0;

    if len >= 8 {
        // Shkëmben indekset në mënyrë që `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Shkëmben indekset në mënyrë që `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Gjen mesoren e `v[a - 1], v[a], v[a + 1]` dhe ruan indeksin në `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Gjeni mesatarë në lagjet `a`, `b` dhe `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Gjeni mesoren midis `a`, `b` dhe `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // U krye numri maksimal i swap-eve.
        // Shanset janë që feta është në rënie ose kryesisht në rënie, kështu që kthimi mbrapa ndoshta do të ndihmojë në zgjidhjen e tij më shpejt.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Rendit `v` në mënyrë rekursive.
///
/// Nëse feta kishte një paraardhës në grupin origjinal, ajo specifikohet si `pred`.
///
/// `limit` është numri i ndarjeve të lejuara të çekuilibruar para se të kaloni në `heapsort`.
/// Nëse është zero, ky funksion do të kalojë menjëherë në grupin e grumbulluar.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Fetë deri në këtë gjatësi renditen duke përdorur llojin e futjes.
    const MAX_INSERTION: usize = 20;

    // E vërtetë nëse ndarja e fundit ishte e balancuar në mënyrë të arsyeshme.
    let mut was_balanced = true;
    // E vërtetë nëse ndarja e fundit nuk ka përzier elemente (feta ishte e ndarë tashmë).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Feta shumë të shkurtra renditen duke përdorur llojin e futjes.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Nëse janë bërë shumë zgjedhje të gabuara bosht, thjesht kthehuni në grupin e grumbulluar për të garantuar rastin më të keq të `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Nëse ndarja e fundit ishte e çekuilibruar, provoni të thyeni modelet në fetë duke rivendosur disa elementë përreth.
        // Shpresojmë që këtë herë të zgjedhim një strumbullar më të mirë.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Zgjidhni një strumbullar dhe provoni të hamendësoni nëse feta është zgjidhur tashmë.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Nëse ndarja e fundit ishte e ekuilibruar në mënyrë të denjë dhe nuk lëvizte elemente, dhe nëse zgjedhja e boshtit parashikon që feta të jetë zgjidhur tashmë ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Provoni të identifikoni disa elementë jashtë rendit dhe t'i zhvendosni ato në pozicione të korrigjuara.
            // Nëse feta përfundon e zgjidhur plotësisht, ne kemi mbaruar.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Nëse boshti i zgjedhur është i barabartë me paraardhësin, atëherë ai është elementi më i vogël në fetë.
        // Ndani fetë në elemente të barabarta me dhe elemente më të mëdha se boshti.
        // Kjo rast zakonisht goditet kur feta përmban shumë elementë të kopjuar.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Vazhdoni të renditni elementet më të mëdha se boshti.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Ndani fetë.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Ndajeni fetë në `left`, `pivot` dhe `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Rikuperohuni në anën më të shkurtër vetëm në mënyrë që të minimizoni numrin e përgjithshëm të thirrjeve rekursive dhe të konsumoni më pak hapësirë në pirg.
        // Pastaj thjesht vazhdoni me anën më të gjatë (kjo është e ngjashme me rekursionin e bishtit).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Rendit `v` duke përdorur quicksortin që mposht modelin, i cili është *O*(*n*\*log(* n*)) rasti më i keq.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Renditja nuk ka sjellje domethënëse për llojet me madhësi zero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Kufizoni numrin e ndarjeve të çekuilibruara në `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Për feta deri në këtë gjatësi është ndoshta më e shpejtë për t'i renditur thjesht.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Zgjidhni një strumbullar
        let (pivot, _) = choose_pivot(v, is_less);

        // Nëse boshti i zgjedhur është i barabartë me paraardhësin, atëherë ai është elementi më i vogël në fetë.
        // Ndani fetë në elemente të barabarta me dhe elemente më të mëdha se boshti.
        // Kjo rast zakonisht goditet kur feta përmban shumë elementë të kopjuar.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Nëse e kemi kaluar indeksin tonë, atëherë jemi mirë.
                if mid > index {
                    return;
                }

                // Përndryshe, vazhdoni të renditni elementë më të mëdhenj se boshti.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Ndajeni fetë në `left`, `pivot` dhe `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Nëse indeksi mes==, atëherë kemi mbaruar, pasi që partition() garantoi që të gjithë elementët pas mesit janë më të mëdha ose të barabarta me mesin.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Renditja nuk ka sjellje domethënëse për llojet me madhësi zero.Mos bej gje.
    } else if index == v.len() - 1 {
        // Gjeni elementin max dhe vendoseni në pozicionin e fundit të vargut.
        // Ne jemi të lirë të përdorim `unwrap()` këtu sepse e dimë që v nuk duhet të jetë bosh.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Gjeni elementin min dhe vendoseni në pozicionin e parë të vargut.
        // Ne jemi të lirë të përdorim `unwrap()` këtu sepse e dimë që v nuk duhet të jetë bosh.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}