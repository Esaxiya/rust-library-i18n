//! Funksionet e shërbimeve për bignums që nuk kanë shumë kuptim për t'u kthyer në metoda.

// FIXME Emri i këtij moduli është pak për të ardhur keq, pasi që edhe modulet e tjerë importojnë `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Testoni nëse shkurtimi i të gjitha bitëve më pak domethënës se `ones_place` paraqet një gabim relativ më pak, të barabartë ose më të madh se 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Nëse të gjitha bitët e mbetur janë zero, është= 0.5 ULP, përndryshe> 0.5 Nëse nuk ka më bit (half_bit==0), edhe më poshtë saktë kthen Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Shndërron një varg ASCII që përmban vetëm shifra dhjetore në `u64`.
///
/// Nuk kryen kontrolle për mbingarkesë ose karaktere të pavlefshëm, kështu që nëse telefonuesi nuk është i kujdesshëm, rezultati është fals dhe mund të panic (megjithëse nuk do të jetë `unsafe`).
/// Për më tepër, vargjet bosh trajtohen si zero.
/// Ky funksion ekziston sepse
///
/// 1. përdorimi i `FromStr` në `&[u8]` kërkon `from_utf8_unchecked`, e cila është e keqe, dhe
/// 2. bashkimi i rezultateve të `integral.parse()` dhe `fractional.parse()` është më i komplikuar se i gjithë ky funksion.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Shndërron një varg të shifrave ASCII në një zinxhir.
///
/// Ashtu si `from_str_unchecked`, ky funksion mbështetet në analizuesin për të shkulur jo-shifrat.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Zbulon një bignum në një numër të plotë 64 bit.Panics nëse numri është shumë i madh.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Nxjerr një sërë bitësh.

/// Indeksi 0 është biti më pak i rëndësishëm dhe diapazoni është gjysmë i hapur si zakonisht.
/// Panics nëse kërkohet të nxjerrë më shumë bit sesa përshtaten në llojin e kthimit.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}