//! Fiddling bit në noton pozitive IEEE 754.Numrat negativë nuk trajtohen dhe nuk duhet të trajtohen.
//! Numrat normalë të pikave lundruese kanë një paraqitje kanonike si (frac, exp) e tillë që vlera të jetë 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) ku N është numri i bitëve.
//!
//! Nënnormalet janë paksa të ndryshme dhe të çuditshme, por zbatohet i njëjti parim.
//!
//! Këtu, megjithatë, ne i përfaqësojmë ata si (sig, k) me f pozitiv, të tillë që vlera të jetë f *
//! 2 <sup>e</sup> .Përveç që e bën "hidden bit" të qartë, kjo ndryshon eksponentin nga e ashtuquajtura ndërrim i mantisës.
//!
//! E thënë ndryshe, normalisht float shkruhen si (1) por këtu ato shkruhen si (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Ne e quajmë (1) përfaqësimin fraksionar **dhe (2)** përfaqësimin integral **.
//!
//! Shumë funksione në këtë modul trajtojnë vetëm numrat normalë.Rutinat dec2flt në mënyrë konservatore marrin rrugën e ngadaltë universale të saktë (Algoritmi M) për numra shumë të vegjël dhe shumë të mëdhenj.
//! Ai algoritëm ka nevojë vetëm për next_float() i cili merret me nënnormalet dhe zero.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Një ndihmës trait për të shmangur dublikimin në thelb të të gjithë kodit të konvertimit për `f32` dhe `f64`.
///
/// Shikoni komentin e dokuit të modulit prind për arsyen pse është e nevojshme.
///
/// A duhet të zbatohet **kurrë** për lloje të tjera ose të përdoret jashtë modulit dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Lloji i përdorur nga `to_bits` dhe `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Kryen një transmutim të papërpunuar në një numër të plotë.
    fn to_bits(self) -> Self::Bits;

    /// Kryen një transmutim të papërpunuar nga një numër i plotë.
    fn from_bits(v: Self::Bits) -> Self;

    /// Kthen kategorinë në të cilën ky numër bie.
    fn classify(self) -> FpCategory;

    /// Kthen mantisën, eksponentin dhe shenjën si numra të plotë.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Deshifron noton.
    fn unpack(self) -> Unpacked;

    /// Hedh nga një numër i plotë i vogël që mund të përfaqësohet saktësisht.
    /// Panic nëse numri i plotë nuk mund të përfaqësohet, kodi tjetër në këtë modul sigurohet që të mos e lejojë atë kurrë të ndodhë.
    fn from_int(x: u64) -> Self;

    /// Merr vlerën 10 <sup>e</sup> nga një tabelë e para-llogaritur.
    /// Panics për `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Çfarë thotë emri.
    /// Easiershtë më e lehtë për të përdorur kodin e vështirë se sa mashtrimi i brendshëm dhe duke shpresuar se LLVM e palos atë.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Një konservator i lidhur me shifrat dhjetore të inputeve që nuk mund të prodhojnë mbingarkesë ose zero ose
    /// nënnormalet.Ndoshta eksponenti dhjetor i vlerës maksimale normale, pra emri.
    const MAX_NORMAL_DIGITS: usize;

    /// Kur shifra dhjetore më e rëndësishme ka një vlerë vendi më të madhe se kjo, numri sigurisht rrumbullakoset në pafundësi.
    ///
    const INF_CUTOFF: i64;

    /// Kur shifra dhjetore më e rëndësishme ka një vlerë vendi më të vogël se kjo, numri sigurisht rrumbullakoset në zero.
    ///
    const ZERO_CUTOFF: i64;

    /// Numri i bitëve në eksponent.
    const EXP_BITS: u8;

    /// Numri i bitëve në shenjë dhe *, përfshirë* bitin e fshehur.
    const SIG_BITS: u8;

    /// Numri i bitëve në shenjë dhe *, duke përjashtuar* bitin e fshehur.
    const EXPLICIT_SIG_BITS: u8;

    /// Eksponenti ligjor maksimal në përfaqësimin e pjesshëm.
    const MAX_EXP: i16;

    /// Eksponenti minimal ligjor në përfaqësimin e pjesshëm, duke përjashtuar nënnormalet.
    const MIN_EXP: i16;

    /// `MAX_EXP` për përfaqësim integral, pra, me ndërrimin e aplikuar.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` i koduar (dmth., me paragjykim të kompensuar)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` për përfaqësim integral, pra, me ndërrimin e aplikuar.
    const MIN_EXP_INT: i16;

    /// Rëndësia maksimale e normalizuar dhe në përfaqësimin integral.
    const MAX_SIG: u64;

    /// Rëndësia minimale e normalizuar dhe në përfaqësimin integral.
    const MIN_SIG: u64;
}

// Kryesisht një zgjidhje për #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Kthen mantisën, eksponentin dhe shenjën si numra të plotë.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Paragjykimi i eksponentit + ndërrimi i mantisës
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe është e pasigurt nëse `as` raundon në mënyrë korrekte në të gjitha platformat.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Kthen mantisën, eksponentin dhe shenjën si numra të plotë.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Paragjykimi i eksponentit + ndërrimi i mantisës
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe është e pasigurt nëse `as` raundon në mënyrë korrekte në të gjitha platformat.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Konverton një `Fp` në llojin më të afërt të notit të makinës.
/// Nuk merret me rezultate nën normale.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f është 64 bit, kështu që xe ka një ndryshim të mantisës 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Raundin e domethënies 64-bitëshe në bitët T::SIG_BITS me gjysmën e çiftimit.
/// Nuk merret me tejmbushjen e eksponentëve.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Rregulloni ndërrimin e mantisës
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Anasjelltas i `RawFloat::unpack()` për numrat e normalizuar.
/// Panics nëse shenja dhe eksponenti nuk janë të vlefshme për numrat e normalizuar.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Hiqni copën e fshehur
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Rregulloni eksponentin për paragjykimin e eksponentit dhe ndërrimin e mantisës
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Lëreni pak shenjën në 0 ("+"), të gjithë numrat tanë janë pozitivë
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Ndërtoni një nënnormale.Lejohet një mantisë prej 0 dhe ndërton zero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Eksponenti i koduar është 0, biti i shenjës është 0, kështu që ne vetëm duhet të riinterpretojmë bitët.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Përafro një bignum me një Fp.Raundet brenda 0.5 ULP me gjysmën e barazimit.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Ne prerë të gjitha bitët para indeksit `start`, d.m.th., ne në mënyrë efektive zhvendosemi në të djathtë me një sasi `start`, kështu që ky është gjithashtu eksponenti që na nevojitet.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Raundi (half-to-even) varet nga bitët e cunguar.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Gjen numrin më të madh të pikës lundruese në mënyrë rigoroze më të vogël se argumenti.
/// Nuk merret me nënnormale, zero, ose nënshkrim eksponent.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Gjeni numrin më të vogël të pikës lundruese në mënyrë rigoroze më të madhe se argumenti.
// Ky operacion po ngop, dmth., next_float(inf) ==inf.
// Ndryshe nga shumica e kodit në këtë modul, ky funksion merret me zero, nënnormale dhe pafundësi.
// Sidoqoftë, si të gjithë kodet e tjera këtu, ai nuk merret me numrat NaN dhe negativë.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Kjo duket shumë e mirë për të qenë e vërtetë, por funksionon.
        // 0.0 është kodifikuar si fjala krejt zero.Nënormalët janë 0x000m ... m ku m është mantissa.
        // Në veçanti, nënnormalja më e vogël është 0x0 ... 01 dhe më e madhja është 0x000F ... F.
        // Numri më i vogël normal është 0x0010 ... 0, kështu që edhe ky rast qoshe funksionon.
        // Nëse rritja tejkalon mantisën, biti i bartjes rrit eksponentin siç duam, dhe copat e mantisës bëhen zero.
        // Për shkak të konventës së fshehur të bitëve, edhe kjo është pikërisht ajo që duam!
        // Më në fund, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}