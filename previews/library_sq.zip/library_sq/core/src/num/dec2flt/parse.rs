//! Vlerësimi dhe zbërthimi i një vargu dhjetor të formës:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Me fjalë të tjera, sintaksa standarde e pikës lundruese, me dy përjashtime: Pa shenjë dhe pa trajtim të "inf" dhe "NaN".Këto trajtohen nga funksioni i drejtuesit (super::dec2flt).
//!
//! Megjithëse njohja e inputeve të vlefshme është relativisht e lehtë, ky modul gjithashtu duhet të refuzojë variacionet e panumërta të pavlefshme, asnjëherë panic, dhe të kryejë kontrolle të shumta që modulet e tjerë mbështeten në jo panic (ose tejmbushje) nga ana tjetër.
//!
//! Për t'i bërë gjërat edhe më keq, gjithçka që ndodh në një kalim të vetëm mbi kontributin.
//! Pra, jini të kujdesshëm kur modifikoni ndonjë gjë, dhe kontrolloni dy herë me modulet e tjera.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Pjesët interesante të një vargu dhjetor.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Eksponenti dhjetor, i garantuar të ketë më pak se 18 shifra dhjetore.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Kontrollon nëse vargu i hyrjes është një numër i vlefshëm i pikës lundruese dhe nëse po, lokalizoni pjesën integrale, pjesën thyesore dhe eksponentin në të.
/// Nuk merret me shenja.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Asnjë shifër para 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Ne kërkojmë të paktën një shifër të vetme para ose pas pikës.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Plehra zvarritës pas pjesës fraksionare
            }
        }
        _ => Invalid, // Mbështetja e hedhurinave pas vargut të parë me shifra
    }
}

/// Gdhend shifrat dhjetore deri në karakterin e parë jo-shifror.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Nxjerrja e eksponentit dhe kontrolli i gabimit.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Junk hedhur pas eksponent
    }
    if number.is_empty() {
        return Invalid; // Eksponent bosh
    }
    // Në këtë pikë, sigurisht që kemi një varg të vlefshëm të shifrave.Mund të jetë shumë e gjatë për tu vendosur në një `i64`, por nëse është kaq e madhe, sigurisht që hyrja është zero ose pafundësi.
    // Meqenëse çdo zero në shifrat dhjetore rregullon vetëm eksponentin me +/-1, në exp=10 ^ 18 hyrja do të duhej të ishte 17 exabyte (!) zero për t'u afruar nga larg për të qenë të fundme.
    //
    // Ky nuk është saktësisht një rast përdorimi për të cilin duhet të kujdesemi.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}