//! Algoritmet e ndryshme nga punimi.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Numri i shenjave dhe bitëve në Fp
const P: u32 = 64;

// Ne thjesht ruajmë përafrimin më të mirë për * të gjithë eksponentët, kështu që ndryshorja "h" dhe kushtet shoqëruese mund të hiqen.
// Kjo tregton performancën për një çift kilobajt hapësirë.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Në shumicën e arkitekturave, operacionet e pikave lundruese kanë një madhësi të qartë bit, prandaj saktësia e llogaritjes përcaktohet mbi bazën për çdo operacion.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Në x86, x87 FPU përdoret për operacione notimi nëse zgjerimet SSE/SSE2 nuk janë të disponueshme.
// x87 FPU operon me 80 bit precize si parazgjedhje, që do të thotë se operacionet do të rrumbullakosen në 80 bit duke bërë që rrumbullakimi i dyfishtë të ndodhë kur vlerat përfaqësohen përfundimisht si
//
// 32/64 vlerat e notimit bit.Për të kapërcyer këtë, fjala e kontrollit FPU mund të vendoset në mënyrë që llogaritjet të kryhen në saktësinë e dëshiruar.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Një strukturë e përdorur për të ruajtur vlerën origjinale të fjalës së kontrollit FPU, në mënyrë që të mund të restaurohet kur struktura të bjerë.
    ///
    ///
    /// x87 FPU është një regjistër 16 bitësh, fushat e të cilit janë si më poshtë:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dokumentacioni për të gjitha fushat është në dispozicion në Manualin e Zhvilluesit të Softuerit IA-32 Architectures (Vëllimi 1).
    ///
    /// E vetmja fushë që është e rëndësishme për kodin e mëposhtëm është PC, Kontrolli i precizionit.
    /// Kjo fushë përcakton saktësinë e operacioneve të kryera nga FPU.
    /// Mund të vendoset në:
    ///  - 0b00, me saktësi të vetme dmth., 32-bit
    ///  - 0b10, saktësi e dyfishtë, dmth., 64 bit
    ///  - 0b11, saktësi e zgjeruar dyfish, dmth. 80 bit (gjendje e paracaktuar) Vlera 0b01 është e rezervuar dhe nuk duhet të përdoret.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SIGURIA: udhëzimi `fldcw` është audituar për të qenë në gjendje të punojë si duhet me të
        // çdo `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Ne po përdorim sintaksën ATT për të mbështetur LLVM 8 dhe LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Vendos fushën e saktësisë së FPU në `T` dhe kthen një `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Llogaritni vlerën për fushën e Kontrollit të Precizionit që është e përshtatshme për `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bit
            8 => 0x0200, // 64 bit
            _ => 0x0300, // parazgjedhur, 80 bit
        };

        // Merrni vlerën origjinale të fjalës së kontrollit për ta rikthyer atë më vonë, kur struktura `FPUControlWord` bie SIGURIA: udhëzimi `fnstcw` është audituar për të qenë në gjendje të punojë si duhet me çdo `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Ne po përdorim sintaksën ATT për të mbështetur LLVM 8 dhe LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Vendosni fjalën e kontrollit në saktësinë e dëshiruar.
        // Kjo arrihet duke maskuar saktësinë e vjetër (bitët 8 dhe 9, 0x300) dhe duke e zëvendësuar atë me flamurin e saktësisë të llogaritur më sipër.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Rruga e shpejtë e Bellerophon duke përdorur numra të plotë dhe nota të përmasave të makinës.
///
/// Ky ekstraktohet në një funksion të veçantë në mënyrë që të mund të provohet para se të ndërtohet një bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) 15.95.
    // Ne krahasojmë vlerën e saktë me MAX_SIG afër fundit, kjo është vetëm një refuzim i shpejtë, i lirë (dhe gjithashtu çliron pjesën tjetër të kodit nga shqetësimi për nën-rrjedhjen).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Rruga e shpejtë varet shumë nga rrumbullakimi i aritmetikës në numrin e saktë të bitëve pa ndonjë rrumbullakim të ndërmjetëm.
    // Në x86 (pa SSE ose SSE2) kjo kërkon që saktësia e pirgut x87 FPU të ndryshohet në mënyrë që të rrumbullakoset drejtpërdrejt në bit 64/32.
    // Funksioni `set_precision` kujdeset për vendosjen e saktësisë në arkitektura të cilat kërkojnë vendosjen e saj duke ndryshuar gjendjen globale (si fjala e kontrollit e x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Rasti e <0 nuk mund të paloset në branch tjetër.
    // Fuqitë negative rezultojnë në një pjesë të përsëritur fraksionale në binar, të cilat janë të rrumbullakosura, gjë që shkakton gabime reale (dhe herë pas here mjaft të rëndësishme!) Në rezultatin përfundimtar.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritmi Bellerophon është kod i parëndësishëm i justifikuar nga analiza numerike jo e parëndësishme.
///
/// Ai rrumbullakon "f" në një noton me domethënie 64 bit dhe e shumëzon atë me përafrimin më të mirë të `10^e` (në të njëjtin format të pikës lundruese).Kjo shpesh është e mjaftueshme për të marrë rezultatin e saktë.
/// Sidoqoftë, kur rezultati është afër gjysmës së rrugës midis dy notave fqinje (ordinary), gabimi i rrumbullakosjes së përbërë nga shumëzimi i dy përafrimit do të thotë se rezultati mund të jetë jashtë me disa bit.
/// Kur kjo të ndodhë, Algoritmi përsëritës R rregullon gjërat.
///
/// "close to halfway" i valëzuar me dorë bëhet preciz nga analiza numerike në letër.
/// Me fjalët e Clinger:
///
/// > Pjerrësia, e shprehur në njësi me bit më pak të rëndësishëm, është një detyrim gjithëpërfshirës për gabimin
/// > akumuluar gjatë llogaritjes së pikës lundruese të përafrimit me f * 10 ^ e.(Pjerrtësia është
/// > nuk është një lidhje për gabimin e vërtetë, por kufizon ndryshimin midis përafrimit z dhe
/// > përafrimi më i mirë i mundshëm që përdor p bit të domethënies dhe.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Rastet abs(e) <log5(2^N) janë në fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // A është pjerrësia mjaft e madhe për të bërë një ndryshim kur rrumbullakoset në n bit?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Një algoritëm përsëritës që përmirëson një përafrim të pikës lundruese të `f * 10^e`.
///
/// Çdo përsëritje merr një njësi në vendin e fundit më afër, gjë që natyrisht kërkon shumë kohë për tu konverguar nëse `z0` është edhe butë i fikur.
/// Për fat të mirë, kur përdoret si ndërrim për Bellerophon, përafrimi fillestar është jo më shumë se një ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Gjeni numrat e plotë pozitivë `x`, `y` të tillë që `x / y` të jetë saktësisht `(f *10^e) / (m* 2^k)`.
        // Kjo jo vetëm që shmang trajtimin e shenjave të `e` dhe `k`, ne gjithashtu eleminojmë fuqinë e dy të përbashkëtave për `10^e` dhe `2^k` për t'i bërë numrat më të vegjël.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Kjo është shkruar pak në mënyrë të vështirë sepse bignums tona nuk mbështesin numra negativë, kështu që ne përdorim vlerën absolute + informacionin e shenjës.
        // Shumëzimi me m_digit nuk mund të tejkalojë.
        // Nëse `x` ose `y` janë mjaft të mëdhenj sa duhet të shqetësohemi për tejmbushjen, atëherë ato janë gjithashtu mjaft të mëdha sa që `make_ratio` ka zvogëluar fraksionin me një faktor prej 2 ^ 64 ose më shumë.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Nuk ju duhen më x, përveç një clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Ende keni nevojë për y, bëni një kopje.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Duke pasur parasysh `x = f` dhe `y = m` ku `f` paraqet shifrat dhjetore hyrëse si zakonisht dhe `m` është domethënia e një përafrimi të pikës lundruese, bëjeni raportin `x / y` të barabartë me `(f *10^e) / (m* 2^k)`, mundësisht të zvogëluar nga një fuqi e dy të dyve kanë të përbashkët.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, përveç që e zvogëlojmë thyesën me disa fuqi të dy.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Kjo nuk mund të vërshojë sepse kërkon `e` pozitiv dhe `k` negativ, gjë që mund të ndodhë vetëm për vlera jashtëzakonisht afër 1, që do të thotë që `e` dhe `k` do të jenë relativisht të vogla.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Edhe kjo nuk mund të vërshojë, shih më lart.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), përsëri duke zvogëluar me një fuqi të përbashkët prej dy.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konceptualisht, Algoritmi M është mënyra më e thjeshtë për të kthyer një dhjetore në një noton.
///
/// Ne formojmë një raport që është i barabartë me `f * 10^e`, pastaj hedhim në fuqi dy, derisa të japë një domethënie të vlefshme të notimit.
/// Eksponenti binar `k` është numri i herëve që shumëzojmë numëruesin ose emëruesin me dy, dmth., Në çdo kohë `f *10^e` është e barabartë me `(u / v)* 2^k`.
/// Kur kemi zbuluar domethënien dhe, ne duhet vetëm të rrumbullakosemi duke inspektuar pjesën e mbetur të ndarjes, e cila bëhet në funksionet ndihmëse më poshtë.
///
///
/// Ky algoritëm është super i ngadaltë, madje edhe me optimizmin e përshkruar në `quick_start()`.
/// Sidoqoftë, është algoritmi më i thjeshtë për t'u përshtatur për mbingarkesë, mbingarkesë dhe rezultate nën normale.
/// Ky zbatim merr përsipër kur Bellerophon dhe Algorithm R mbingarkohen.
/// Zbulimi i rrymës dhe mbingarkesës është i lehtë: Raporti ende nuk është një rëndësi në interval dhe megjithatë eksponenti minimum/maximum është arritur.
/// Në rastin e tejmbushjes, ne thjesht kthejmë pafundësinë.
///
/// Trajtimi i nënfushave dhe nënnormaleve është më i ndërlikuar.
/// Një problem i madh është se, me eksponentin minimal, raporti mund të jetë akoma shumë i madh për një domethënie.
/// Shihni underflow() për detaje.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // Optimizimi i mundshëm FIXME: përgjithësoni big_to_fp në mënyrë që të mund të bëjmë ekuivalentin e fp_to_float(big_to_fp(u)) këtu, vetëm pa rrumbullakimin e dyfishtë.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Ne duhet të ndalemi në eksponentin minimal, nëse presim deri në `k < T::MIN_EXP_INT`, atëherë do të ishim larg një faktori dy.
            // Fatkeqësisht kjo do të thotë që ne duhet të specifikojmë numrat normalë me eksponentin minimal.
            // FIXME gjeni një formulim më elegant, por ekzekutoni testin `tiny-pow10` për t'u siguruar që është në të vërtetë e saktë!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Kalon mbi shumicën e përsëritjeve të Algoritmit M duke kontrolluar gjatësinë e bitit.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Gjatësia e bitit është një vlerësim i logaritmit bazë dy, dhe log(u / v) = log(u), log(v).
    // Vlerësimi është jo më shumë se 1, por gjithmonë një nënvlerësim, kështu që gabimi në log(u) dhe log(v) është i së njëjtës shenjë dhe anulohet (nëse të dy janë të mëdhenj).
    // Prandaj, gabimi për log(u / v) është më së shumti një.
    // Raporti i synuar është ai ku u/v është me një rëndësi brenda rrezes.Kështu që gjendja jonë e përfundimit është log2(u / v) duke qenë bitet domethënëse, plus/minus një.
    // FIXME Shikimi i bitit të dytë mund të përmirësojë vlerësimin dhe të shmangë disa ndarje.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Nënshkrimi ose nënnormalja.Lëreni atë në funksionin kryesor.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Tejmbushur.Lëreni atë në funksionin kryesor.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Raporti nuk është një rëndësi në interval dhe me eksponentin minimal, kështu që ne duhet të rrumbullakosim bitët e tepërt dhe ta rregullojmë eksponentin në përputhje me rrethanat.
    // Vlera reale tani duket kështu:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trung.(perfaqesuar nga rem)
    //
    // Prandaj, kur copëzat e rrumbullakosura janë!= 0.5 ULP, ata vendosin vetë rrumbullakimin.
    // Kur ato janë të barabarta dhe pjesa e mbetur nuk është zero, vlera ende duhet të rrumbullakoset.
    // Vetëm kur bitët e rrumbullakosura janë 1/2 dhe pjesa e mbetur është zero, ne kemi një situatë gjysmë të barabartë.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Raundi i zakonshëm i rrumbullakëtimit, i ngatërruar duke u dashur të rrumbullakoset bazuar në pjesën e mbetur të një ndarjeje.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}