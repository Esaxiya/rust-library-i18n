//! Llojet e gabimeve për shndërrim në lloje integrale.

use crate::convert::Infallible;
use crate::fmt;

/// Lloji i gabimit kthehet kur dështon një konvertim i kontrolluar i tipit integral.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Përputhuni më shumë sesa detyroni për t'u siguruar që kodi si `From<Infallible> for TryFromIntError` më lart do të vazhdojë të funksionojë kur `Infallible` të bëhet një pseudonim me `!`.
        //
        //
        match never {}
    }
}

/// Një gabim i cili mund të kthehet kur analizon një numër të plotë.
///
/// Ky gabim përdoret si tip gabimi për funksionet `from_str_radix()` në llojet e plota primitive, siç është [`i8::from_str_radix`].
///
/// # Shkaqet e mundshme
///
/// Ndër shkaqe të tjera, `ParseIntError` mund të hidhet për shkak të hapësirës së bardhë kryesore ose zvarritëse në varg p.sh., kur merret nga hyrja standarde.
///
/// Përdorimi i metodës [`str::trim()`] siguron që asnjë hapësirë e bardhë të mos mbetet përpara analizimit.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum për të ruajtur llojet e ndryshme të gabimeve që mund të shkaktojnë dështimin e analizimit të një numri të plotë.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Vlera që analizohet është bosh.
    ///
    /// Ndër shkaqet e tjera, ky variant do të ndërtohet kur analizon një varg bosh.
    Empty,
    /// Përmban një shifër të pavlefshme në kontekstin e saj.
    ///
    /// Ndër shkaqe të tjera, ky variant do të ndërtohet kur analizon një varg që përmban një karakter jo-ASCII.
    ///
    /// Ky variant ndërtohet gjithashtu kur një `+` ose `-` është i gabuar brenda një vargu ose më vete ose në mes të një numri.
    ///
    ///
    InvalidDigit,
    /// Integri është shumë i madh për tu ruajtur në llojin e synuar të plotë.
    PosOverflow,
    /// Integri është shumë i vogël për tu ruajtur në llojin e synuar të plotë.
    NegOverflow,
    /// Vlera ishte Zero
    ///
    /// Ky variant do të emetohet kur vargu parsues ka një vlerë zero, e cila do të ishte e paligjshme për llojet jo zero.
    ///
    Zero,
}

impl ParseIntError {
    /// Nxjerr shkakun e hollësishëm të dështimit të analizimit të një numri të plotë.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}