//! Deshifron një vlerë të pikës lëvizëse në pjesë individuale dhe diapazonin e gabimeve.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Vlera e fundme e deshifruar e nënshkruar, e tillë që:
///
/// - Vlera origjinale është e barabartë me `mant * 2^exp`.
///
/// - Çdo numër nga `(mant - minus)*2^exp` në `(mant + plus)* 2^exp` do të rrumbullakoset në vlerën origjinale.
/// Diapazoni është gjithëpërfshirës vetëm kur `inclusive` është `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Mantisa e shkallëzuar.
    pub mant: u64,
    /// Diapazoni më i ulët i gabimit.
    pub minus: u64,
    /// Diapazoni i sipërm i gabimit.
    pub plus: u64,
    /// Eksponenti i përbashkët në bazën 2.
    pub exp: i16,
    /// E vërtetë kur diapazoni i gabimit është gjithëpërfshirës.
    ///
    /// Në IEEE 754, kjo është e vërtetë kur mantisa origjinale ishte e barabartë.
    pub inclusive: bool,
}

/// Vlera e deshifruar e pa firmosur.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Pafundësi, qoftë pozitive ose negative.
    Infinite,
    /// Zero, qoftë pozitiv ose negativ.
    Zero,
    /// Numra të fundëm me fusha të deshifruara më tej.
    Finite(Decoded),
}

/// Një tip i pikës lundruese i cili mund të `dekodohet`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Vlera minimale e normalizuar pozitive.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Kthen një shenjë (e vërtetë kur është negative) dhe vlera `FullDecoded` nga numri i dhënë i pikës lundruese.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // fqinjët: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode gjithmonë e ruan eksponentin, kështu që mantisa shkallëzohet për nënnormalet.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // fqinjët: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // ku maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // fqinjët: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}