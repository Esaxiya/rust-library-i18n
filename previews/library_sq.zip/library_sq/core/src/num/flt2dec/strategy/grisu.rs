//! Përshtatja Rust e algoritmit Grisu3 e përshkruar në "Shtypja e numrave me pikë lëvizëse shpejt dhe saktë me numrat e plotë" [^ 1].
//! Përdor rreth 1 KB tabelë të parakompjuteruar, dhe nga ana tjetër, është shumë e shpejtë për shumicën e inputeve.
//!
//! [^1]: Florian Loitsch.2010. Printimi i shpejtë i numrave me pikë lundruese dhe
//!   me saktësi me numrat e plotë.SIGPLAN Jo.45, 6 (qershor 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// shikoni komentet në `format_shortest_opt` për arsyetimin.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Duke pasur parasysh `x > 0`, kthen `(k, 10^k)` të tillë që `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Zbatimi i mënyrës më të shkurtër për Grisu.
///
/// Kthen `None` kur përndryshe do të kthente një përfaqësim jo të saktë.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // na duhen të paktën tre copa precize shtesë

    // filloni me vlerat e normalizuara me eksponentin e përbashkët
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // gjeni ndonjë `cached = 10^minusk` të tillë që `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // meqenëse `plus` është normalizuar, kjo do të thotë `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // duke pasur parasysh zgjedhjet tona të `ALPHA` dhe `GAMMA`, kjo e vë `plus * cached` në `[4, 2^32)`.
    //
    // është padyshim e dëshirueshme që të maksimizohet `GAMMA - ALPHA`, në mënyrë që të mos na duhen shumë fuqi të memorizuara prej 10, por ka disa konsiderata:
    //
    //
    // 1. ne duam ta mbajmë `floor(plus * cached)` brenda `u32` pasi që ka nevojë për një ndarje të kushtueshme.
    //    (kjo nuk mund të shmanget me të vërtetë, pjesa tjetër kërkohet për vlerësimin e saktësisë.)
    // 2.
    // pjesa e mbetur e `floor(plus * cached)` shumëzohet në mënyrë të përsëritur me 10 dhe nuk duhet të tejmbushet.
    //
    // e para jep `64 + GAMMA <= 32`, ndërsa e dyta jep `10 * 2^-ALPHA <= 2^64`;
    // -60 dhe -32 është diapazoni maksimal me këtë kufizim, dhe V8 gjithashtu i përdor ato.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // shkallë fps.kjo jep gabimin maksimal prej 1 ulp (provuar nga Teorema 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-diapazoni aktual i minusit
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // mbi `minus`, `v` dhe `plus` janë *përafrime* të kuantizuara (gabimi <1 ulp).
    // pasi nuk e dimë që gabimi është pozitiv ose negativ, ne përdorim dy përafrime të ndara në mënyrë të barabartë dhe kemi gabimin maksimal prej 2 ulps.
    //
    // "unsafe region" është një interval liberal të cilin fillimisht e gjenerojmë.
    // "safe region" është një interval konservator të cilin ne vetëm e pranojmë.
    // ne fillojmë me repin e saktë brenda rajonit të pasigurt dhe përpiqemi të gjejmë repin më të afërt me `v` i cili është gjithashtu brenda rajonit të sigurt.
    // nëse nuk mundemi, dorëzohemi.
    //
    let plus1 = plus.f + 1;
    // le plus0 = plus.f, 1;//vetëm për shpjegim le të minus0 = minus.f + 1;//vetëm për shpjegim
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // eksponent i përbashkët

    // ndani `plus1` në pjesë integrale dhe thyesore.
    // pjesët integrale garantohen të futen në u32, meqenëse fuqia e memorizuar garanton `plus < 2^32` dhe `plus.f` i normalizuar është gjithmonë më pak se `2^64 - 2^4` për shkak të kërkesës së saktësisë.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // llogaritni `10^max_kappa` më të madh jo më shumë se `plus1` (pra `plus1 < 10^(max_kappa+1)`).
    // ky është një kufi i sipërm i `kappa` më poshtë.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: nëse `k` është numri i plotë më i madh rr
    // `0 <= y mod 10^k <= y - x`,              atëherë `V = floor(y / 10^k) * 10^k` është në `[x, y]` dhe një nga paraqitjet më të shkurtra (me numrin minimal të shifrave të konsiderueshme) në atë diapazon.
    //
    //
    // gjeni gjatësinë shifrore `kappa` midis `(minus1, plus1)` sipas Teoremës 6.2.
    // Teorema 6.2 mund të miratohet për të përjashtuar `x` duke kërkuar në vend të saj `y mod 10^k < y - x`.
    // (p.sh., `x` =32000, `y` =32777; `kappa` =2 meqenëse `y mod 10 ^ 3=777 <y, x=777`.) algoritmi mbështetet në fazën e mëvonshme të verifikimit për të përjashtuar `y`.
    //
    let delta1 = plus1 - minus1;
    // le delta1int=(delta1>> e) si të përdorni;//vetëm për shpjegim
    let delta1frac = delta1 & ((1 << e) - 1);

    // bëj pjesë integrale, ndërsa kontrollon saktësinë në secilin hap.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // shifrat që ende nuk do të jepen
    loop {
        // ne gjithmonë kemi të paktën një shifër për të dhënë, si `plus1 >= 10^kappa` të pandryshueshme:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (rrjedh se `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // ndani `remainder` me `10^kappa`.të dyja janë shkallëzuar nga `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; ne kemi gjetur `kappa` të saktë.
            let ten_kappa = (ten_kappa as u64) << e; // shkalla 10 ^ kappa përsëri në eksponentin e përbashkët
            return round_and_weed(
                // SIGURIA: ne kemi iniciuar atë kujtesë më sipër.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // prish lak kur kemi dhënë të gjitha shifrat integrale.
        // numri i saktë i shifrave është `max_kappa + 1` si `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // rivendosni invariancat
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // bëj pjesë të pjesshme, ndërsa kontrollon saktësinë në secilin hap.
    // kësaj here ne mbështetemi te shumëzimet e përsëritura, pasi pjesëtimi do të humbasë saktësinë.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // shifra tjetër duhet të jetë domethënëse pasi e kemi testuar para se të shpërthejmë invariancat, ku `m = max_kappa + 1` (#e shifrave në pjesën integrale):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // nuk do të vërshojë, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // ndani `remainder` me `10^kappa`.
        // të dyja janë shkallëzuar nga `2^e / 10^kappa`, kështu që kjo e fundit nënkuptohet këtu.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // pjesëtues i nënkuptuar
            return round_and_weed(
                // SIGURIA: ne kemi iniciuar atë kujtesë më sipër.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // rivendosni invariancat
        kappa -= 1;
        remainder = r;
    }

    // ne kemi gjeneruar të gjitha shifrat domethënëse të `plus1`, por nuk jemi të sigurt nëse është ai më i miri.
    // për shembull, nëse `minus1` është 3.14153 ... dhe `plus1` është 3.14158 ..., ka 5 paraqitje të ndryshme më të shkurtër nga 3.14154 në 3.14158 por ne kemi vetëm atë më të madhen.
    // ne duhet të ulim në mënyrë të njëpasnjëshme shifrën e fundit dhe të kontrollojmë nëse kjo është repr optimale.
    // ka më së shumti 9 kandidatë (..1 deri në ..9), kështu që kjo është mjaft e shpejtë.(Faza "rounding")
    //
    // funksioni kontrollon nëse ky reprim i "optimal" është në të vërtetë brenda kufijve të ulp, dhe gjithashtu, është e mundur që reprimi "second-to-optimal" mund të jetë në të vërtetë optimale për shkak të gabimit të rrumbullakimit.
    // në të dy rastet kjo kthen `None`.
    // (Faza "weeding")
    //
    // të gjitha argumentet këtu shkallëzohen nga vlera e përbashkët (por implicite) `k`, në mënyrë që:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (dhe gjithashtu, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (dhe gjithashtu, `threshold > plus1v` nga invariancat e mëparshme)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // prodhojnë dy përafrime me `v` (në të vërtetë `plus1 - v`) brenda 1.5 ulps.
        // përfaqësimi që rezulton duhet të jetë përfaqësimi më i afërt për të dy.
        //
        // këtu përdoret `plus1 - v` pasi llogaritjet bëhen në lidhje me `plus1` në mënyrë që të shmanget overflow/underflow (prandaj emrat në dukje të ndërruar).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // zvogëlo shifrën e fundit dhe ndalo në paraqitjen më të afërt me `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // ne punojmë me shifrat e përafruara `w(n)`, e cila fillimisht është e barabartë me `plus1 - plus1 % 10^kappa`.pasi keni ekzekutuar trupin e lakut `n` herë, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // ne vendosim `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (kështu `mbetja= plus1w(0)`) për të thjeshtuar kontrollet.
            // vini re se `plus1w(n)` është gjithmonë në rritje.
            //
            // kemi tre kushte për t`i ndërprerë.ndonjëri prej tyre do ta bëjë lakun të mos mund të vazhdojë, por atëherë kemi të paktën një përfaqësim të vlefshëm që dihet se është gjithsesi më afër `v + 1 ulp`.
            // ne do t'i shënojmë ato si TC1 përmes TC3 për shkurtësi.
            //
            // TC1: `w(n) <= v + 1 ulp`, dmth., Ky është rep i fundit që mund të jetë ai më i afërti.
            // kjo është ekuivalente me `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // e kombinuar me TC2 (e cila kontrollon nëse `w(n+1)` is valid), kjo parandalon mbingarkesën e mundshme në llogaritjen e `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, pra, repi tjetër definitivisht nuk rrumbullakoset në `v`.
            // kjo është ekuivalente me `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // ana e majtë mund të vërshojë, por ne e dimë `threshold > plus1v`, kështu që nëse TC1 është false, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` dhe ne mund të provojmë me siguri nëse `threshold - plus1w(n) < 10^kappa` në vend.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, pra, repi tjetër është
            // jo më afër `v + 1 ulp` sesa repr aktual.
            // duke pasur parasysh `z(n) = plus1v_up - plus1w(n)`, kjo bëhet `abs(z(n)) <= abs(z(n+1))`.përsëri duke supozuar se TC1 është false, ne kemi `z(n) > 0`.kemi dy raste për tu marrë në konsideratë:
            //
            // - kur `z(n+1) >= 0`: TC3 bëhet `z(n) <= z(n+1)`.
            // ndërsa `plus1w(n)` po rritet, `z(n)` duhet të ulet dhe kjo është qartë e gabuar.
            // - kur `z(n+1) < 0`:
            //   - TC3a: parakushti është `plus1v_up < plus1w(n) + 10^kappa`.duke supozuar se TC2 është false, `threshold >= plus1w(n) + 10^kappa` kështu që nuk mund të vërshojë.
            //   - TC3b: TC3 bëhet `z(n) <= -z(n+1)`, dmth., `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 i mohuar jep `plus1v_up > plus1w(n)`, kështu që nuk mund të mbipopullohet ose të derdhet nën ujë kur kombinohet me TC3a.
            //
            // si pasojë, ne duhet të ndalemi kur `TC1 || TC2 || (TC3a && TC3b)`.e mëposhtme është e barabartë me anasjelltasin e saj, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // repi më i shkurtër nuk mund të përfundojë me `0`
                plus1w += ten_kappa;
            }
        }

        // kontrolloni nëse kjo përfaqësim është edhe përfaqësimi më i afërt me `v - 1 ulp`.
        //
        // kjo është thjesht e njëjtë me kushtet e përfundimit për `v + 1 ulp`, me të gjithë `plus1v_up` të zëvendësuar nga `plus1v_down` në vend.
        // Analiza e tejmbushjes qëndron njësoj.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // tani kemi përfaqësimin më të afërt me `v` midis `plus1` dhe `minus1`.
        // kjo është shumë liberale, megjithatë, kështu që ne refuzojmë çdo `w(n)` jo midis `plus0` dhe `minus0`, dmth., `plus1 - plus1w(n) <= minus0` ose `plus1 - plus1w(n) >= plus0`.
        // ne shfrytëzojmë faktet që `threshold = plus1 - minus1` dhe `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Zbatimi i mënyrës më të shkurtër për Grisu me rikthimin e Dragoit.
///
/// Kjo duhet të përdoret për shumicën e rasteve.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SIGURIA: Kontrolluesi i huazimit nuk është aq i zgjuar sa të na lejojë të përdorim `buf`
    // në branch të dytë, kështu që ne pastrojmë jetën këtu.
    // Por ne e ripërdorim `buf` vetëm nëse `format_shortest_opt` ktheu `None` kështu që kjo është në rregull.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Zbatimi i saktë dhe i mënyrës fikse për Grisu.
///
/// Kthen `None` kur përndryshe do të kthente një përfaqësim jo të saktë.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // na duhen të paktën tre copa precize shtesë
    assert!(!buf.is_empty());

    // normalizoni dhe shkallëzoni `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // ndani `v` në pjesë integrale dhe thyesore.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // si `v` i vjetër ashtu edhe `v` i ri (i shkallëzuar nga `10^-k`) kanë një gabim prej <1 ulp (Teorema 5.1).
    // pasi nuk e dimë që gabimi është pozitiv ose negativ, ne përdorim dy përafrime të ndara në mënyrë të barabartë dhe kemi gabimin maksimal prej 2 ulps (njëlloj me rastin më të shkurtër).
    //
    //
    // qëllimi është të gjejmë serinë pikërisht të rrumbullakosura të shifrave që janë të përbashkëta për të dy `v - 1 ulp` dhe `v + 1 ulp`, në mënyrë që të jemi maksimalisht të sigurt.
    // nëse kjo nuk është e mundur, ne nuk e dimë se cili është rezultati i saktë për `v`, kështu që ne heqim dorë dhe biem prapa.
    //
    // `err` përcaktohet si `1 ulp * 2^e` këtu (njësoj si ulp në `vfrac`), dhe ne do ta shkallëzojmë sa herë që `v` shkallëzohet.
    //
    //
    //
    let mut err = 1;

    // llogaritni `10^max_kappa` më të madh jo më shumë se `v` (pra `v < 10^(max_kappa+1)`).
    // ky është një kufi i sipërm i `kappa` më poshtë.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // nëse jemi duke punuar me kufizimin me shifrën e fundit, duhet të shkurtojmë bufferin para paraqitjes aktuale në mënyrë që të shmangim rrumbullakimin e dyfishtë.
    //
    // vini re se duhet të zmadhojmë buffer-in përsëri kur ndodh rrumbullakimi!
    let len = if exp <= limit {
        // oops, ne nuk mund të prodhojmë as *një* shifër.
        // kjo është e mundur kur, të themi, ne kemi diçka si 9.5 dhe po rrumbullakoset në 10.
        //
        // në parim mund ta quajmë menjëherë `possibly_round` me një buffer bosh, por shkallëzimi `max_ten_kappa << e` me 10 mund të rezultojë në tejmbushje.
        //
        // kështu që ne jemi duke u turbullt këtu dhe zgjerojmë diapazonin e gabimeve me një faktor 10.
        // kjo do të rrisë normën e rreme negative, por vetëm shumë,*shumë* pak;
        // mund të ketë rëndësi të dukshme vetëm kur mantisa është më e madhe se 60 bit.
        //
        // SIGURIA: `len=0`, kështu që detyrimi i inicimit të kësaj memorie është i parëndësishëm.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // bëj pjesë integrale.
    // gabimi është tërësisht i pjesshëm, prandaj nuk kemi nevojë ta kontrollojmë në këtë pjesë.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // shifrat që ende nuk do të jepen
    loop {
        // ne gjithmonë kemi të paktën një shifër për të dhënë invariants:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (rrjedh se `remainder = vint % 10^(kappa+1)`)
        //
        //

        // ndani `remainder` me `10^kappa`.të dyja janë shkallëzuar nga `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // a është tampon i plotë?drejtoni kalimin e rrumbullakimit me pjesën e mbetur.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SIGURIA: ne kemi iniciuar shumë `len` bajte.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // prish lak kur kemi dhënë të gjitha shifrat integrale.
        // numri i saktë i shifrave është `max_kappa + 1` si `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // rivendosni invariancat
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // bëj pjesë të pjesshme.
    //
    // në parim mund të vazhdojmë deri në shifrën e fundit të disponueshme dhe të kontrollojmë saktësinë.
    // fatkeqësisht ne jemi duke punuar me numrat e plotë me madhësi të fundme, kështu që na duhet një kriter për të zbuluar mbingarkesën.
    // V8 përdor `remainder > err`, e cila bëhet false kur shifrat e para të rëndësishme `i` të `v - 1 ulp` dhe `v` ndryshojnë.
    // megjithatë kjo refuzon shumë të dhëna përndryshe të vlefshme.
    //
    // meqenëse faza e mëvonshme ka një zbulim korrekt të mbingarkesës, ne përdorim një kriter më të ngushtë:
    // ne vazhdojmë derisa `err` tejkalon `10^kappa / 2`, kështu që diapazoni midis `v - 1 ulp` dhe `v + 1 ulp` përmban patjetër dy ose më shumë paraqitje të rrumbullakosura.
    //
    // kjo është e njëjtë me dy krahasimet e para nga `possibly_round`, për referencë.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariante, ku `m = max_kappa + 1` (#i shifrave në pjesën integrale):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // nuk do të vërshojë, `2^e * 10 < 2^64`
        err *= 10; // nuk do të vërshojë, `err * 10 < 2^e * 5 < 2^64`

        // ndani `remainder` me `10^kappa`.
        // të dyja janë shkallëzuar nga `2^e / 10^kappa`, kështu që kjo e fundit nënkuptohet këtu.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // a është tampon i plotë?drejtoni kalimin e rrumbullakimit me pjesën e mbetur.
        if i == len {
            // SIGURIA: ne kemi iniciuar shumë `len` bajte.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // rivendosni invariancat
        remainder = r;
    }

    // llogaritja e mëtejshme është e padobishme (`possibly_round` definitivisht dështon), kështu që ne heqim dorë.
    return None;

    // ne kemi gjeneruar të gjitha shifrat e kërkuara të `v`, të cilat duhet të jenë të njëjta me shifrat përkatëse të `v - 1 ulp`.
    // tani ne kontrollojmë nëse ka një përfaqësim unik të ndarë nga të dy `v - 1 ulp` dhe `v + 1 ulp`;kjo mund të jetë e njëjtë me shifrat e gjeneruara, ose me versionin e rrumbullakosur të atyre shifrave.
    //
    // nëse diapazoni përmban paraqitje të shumëfishta me të njëjtën gjatësi, nuk mund të jemi të sigurt dhe duhet të kthejmë `None`.
    //
    // të gjitha argumentet këtu shkallëzohen nga vlera e përbashkët (por implicite) `k`, në mënyrë që:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SIGURIA: bajtet e para `len` të `buf` duhet të iniciohen.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (për referencë, vija me pika tregon vlerën e saktë për paraqitjet e mundshme në numrin e dhënë të shifrave.)
        //
        //
        // gabimi është shumë i madh se ka të paktën tre paraqitje të mundshme midis `v - 1 ulp` dhe `v + 1 ulp`.
        // ne nuk mund të përcaktojmë se cila është e saktë.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // në fakt, 1/2 ulp është e mjaftueshme për të prezantuar dy paraqitje të mundshme.
        // (mos harroni se na duhet një paraqitje unike si për `v - 1 ulp` ashtu edhe për `v + 1 ulp`.) kjo nuk do të tejkalojë, pasi `ulp < ten_kappa` nga kontrolli i parë.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // nëse `v + 1 ulp` është më afër përfaqësimit të rrumbullakosur poshtë (i cili tashmë është në `buf`), atëherë mund të kthehemi në mënyrë të sigurt.
        // vini re se `v - 1 ulp`*mund të jetë* më pak se përfaqësimi aktual, por si `1 ulp < 10^kappa / 2`, kjo gjendje është e mjaftueshme:
        // distanca midis `v - 1 ulp` dhe paraqitjes aktuale nuk mund të kalojë `10^kappa / 2`.
        //
        // gjendja është e barabartë me `remainder + ulp < 10^kappa / 2`.
        // meqenëse kjo lehtë mund të tejkalojë, së pari kontrolloni nëse `remainder < 10^kappa / 2`.
        // ne tashmë kemi verifikuar që `ulp < 10^kappa / 2`, kështu që për sa kohë që `10^kappa` nuk ka dalë nga shtrati, kontrolli i dytë është i mirë.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SIGURIA: thirrësi ynë nisi atë kujtesë.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------mbetja------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // nga ana tjetër, nëse `v - 1 ulp` është më afër përfaqësimit të rrumbullakosur, ne duhet të rrumbullakosemi dhe të kthehemi.
        // për të njëjtën arsye nuk kemi nevojë të kontrollojmë `v + 1 ulp`.
        //
        // gjendja është e barabartë me `remainder - ulp >= 10^kappa / 2`.
        // përsëri ne së pari kontrollojmë nëse `remainder > ulp` (vini re se kjo nuk është `remainder >= ulp`, pasi `10^kappa` nuk është kurrë zero).
        //
        // gjithashtu vini re se `remainder - ulp <= 10^kappa`, kështu që kontrolli i dytë nuk del nga shtrati.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SIGURIA: thirrësi ynë duhet ta ketë iniciuar atë kujtesë.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // shtoni vetëm një shifër shtesë kur të na kërkohet saktësia fikse.
                // ne gjithashtu duhet të kontrollojmë që, nëse bufferi origjinal ishte bosh, shifra shtesë mund të shtohet vetëm kur `exp == limit` (rasti edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SIGURIA: ne dhe thirrësi ynë e iniciuam atë kujtim.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // përndryshe ne jemi të dënuar (dmth., disa vlera midis `v - 1 ulp` dhe `v + 1 ulp` rrumbullakohen poshtë dhe të tjerët po rrumbullakohen) dhe heqim dorë.
        //
        None
    }
}

/// Zbatimi i saktë dhe i modalitetit fiks për Grisu me rikthimin e Dragoit.
///
/// Kjo duhet të përdoret për shumicën e rasteve.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SIGURIA: Kontrolluesi i huazimit nuk është aq i zgjuar sa të na lejojë të përdorim `buf`
    // në branch të dytë, kështu që ne pastrojmë jetën këtu.
    // Por ne e ripërdorim `buf` vetëm nëse `format_exact_opt` ktheu `None` kështu që kjo është në rregull.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}