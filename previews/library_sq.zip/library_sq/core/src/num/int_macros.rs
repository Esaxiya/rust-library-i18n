macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Vlera më e vogël që mund të përfaqësohet nga ky lloj i plotë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Vlera më e madhe që mund të përfaqësohet nga ky lloj i plotë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Madhësia e këtij lloji të plotë në bit.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Shndërron një fetë vargu në një bazë të caktuar në një numër të plotë.
        ///
        /// Vargu pritet të jetë një shenjë opsionale `+` ose `-` e ndjekur nga shifra.
        /// Hapësira e bardhë drejtuese dhe zvarritëse paraqet një gabim.
        /// Shifrat janë një nëngrup i këtyre karaktereve, në varësi të `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Ky funksion panics nëse `radix` nuk është në intervalin nga 2 në 36.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Kthen numrin e atyre në paraqitjen binare të `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Kthen numrin e zerove në paraqitjen binare të `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Kthen numrin e zero drejtuese në përfaqësimin binar të `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Kthen numrin e zerove zvarritës në paraqitjen binare të `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Kthen numrin e atyre kryesorë në përfaqësimin binar të `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Kthen numrin e atyre që zvarriten në përfaqësimin binar të `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Zhvendos bitët majtas me një sasi të specifikuar, `n`, duke mbështjellë bitët e cunguar në fund të numrit të plotë që rezulton.
        ///
        ///
        /// Ju lutem vini re se ky nuk është i njëjti operacion me operatorin zhvendosës `<<`!
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Zhvendos bitët në të djathtë me një sasi të specifikuar, `n`, duke mbështjellë bitët e cunguar në fillim të numrit të plotë që rezulton.
        ///
        ///
        /// Ju lutem vini re se ky nuk është i njëjti operacion me operatorin zhvendosës `>>`!
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Ndryshon rendin e bajtëve të numrit të plotë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// le m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Ndryshon rendin e bitëve në numrin e plotë.
        /// Biti më pak i rëndësishëm bëhet biti më i rëndësishëm, i dyti bit i dytë më pak i rëndësishëm bëhet biti i dytë më i rëndësishëm, etj.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// le m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Shndërron një numër të plotë nga endiani i madh në endianitetin e synimit.
        ///
        /// Në endian të madh kjo është një no-op.Në endianin e vogël bajtet shkëmbehen.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// nëse cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } tjeter {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Shndërron një numër të plotë nga endiani i vogël në endianitetin e synimit.
        ///
        /// Në pak endian kjo është një no-op.Në endian të madh bajtët shkëmbehen.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// nëse cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } tjeter {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Shndërron `self` në endian të madh nga endianiteti i synimit.
        ///
        /// Në endian të madh kjo është një no-op.Në endianin e vogël bajtet shkëmbehen.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// nëse cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } tjetër { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // apo te mos jesh?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Shndërron `self` në endian të vogël nga endianiteti i synimit.
        ///
        /// Në pak endian kjo është një no-op.Në endian të madh bajtët shkëmbehen.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// nëse cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } tjetër { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Shtesë e plotë e kontrolluar.
        /// Llogarit `self + rhs`, duke e kthyer `None` nëse ka ndodhur mbingarkesë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Shtesë e plotë e paketuar.Llogarit `self + rhs`, duke supozuar se nuk mund të ndodhë mbingarkesë.
        /// Kjo rezulton në një sjellje të papërcaktuar kur
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Zbritja e kontrolluar e plotë.
        /// Llogarit `self - rhs`, duke e kthyer `None` nëse ka ndodhur mbingarkesë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Zbritja e plotë e paketuar.Llogarit `self - rhs`, duke supozuar se nuk mund të ndodhë mbingarkesë.
        /// Kjo rezulton në një sjellje të papërcaktuar kur
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Shumëzimi i kontrolluar i plotë.
        /// Llogarit `self * rhs`, duke e kthyer `None` nëse ka ndodhur mbingarkesë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Shumëzimi i plotë i pakontrolluar.Llogarit `self * rhs`, duke supozuar se nuk mund të ndodhë mbingarkesë.
        /// Kjo rezulton në një sjellje të papërcaktuar kur
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Ndarja e kontrolluar e plotë.
        /// Llogarit `self / rhs`, duke e kthyer `None` nëse `rhs == 0` ose ndarja rezulton në tejmbushje.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SIGURIA: div me zero dhe me INT_MIN janë kontrolluar më sipër
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Ndarja e kontrolluar euklidiane.
        /// Llogarit `self.div_euclid(rhs)`, duke e kthyer `None` nëse `rhs == 0` ose ndarja rezulton në tejmbushje.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Pjesa e mbetur e plotë e kontrolluar.
        /// Llogarit `self % rhs`, duke e kthyer `None` nëse `rhs == 0` ose ndarja rezulton në tejmbushje.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SIGURIA: div me zero dhe me INT_MIN janë kontrolluar më sipër
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Pjesa e mbetur e kontrolluar euklidiane.
        /// Llogarit `self.rem_euclid(rhs)`, duke e kthyer `None` nëse `rhs == 0` ose ndarja rezulton në tejmbushje.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Mohimi i kontrolluar.
        /// Llogarit `-self`, duke e kthyer `None` nëse `self == MIN`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ndryshimi i kontrolluar majtas.
        /// Llogarit `self << rhs`, duke e kthyer `None` nëse `rhs` është më i madh ose i barabartë me numrin e bitëve në `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ndryshimi i kontrolluar djathtas.
        /// Llogarit `self >> rhs`, duke e kthyer `None` nëse `rhs` është më i madh ose i barabartë me numrin e bitëve në `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Vlera absolute e kontrolluar.
        /// Llogarit `self.abs()`, duke e kthyer `None` nëse `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Eksponimi i kontrolluar.
        /// Llogarit `self.pow(exp)`, duke e kthyer `None` nëse ka ndodhur mbingarkesë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // që nga exp!=0, më në fund exp duhet të jetë 1.
            // Merreni me bitin e fundit të eksponentit veçmas, pasi që katrorizimi i bazës më pas nuk është i nevojshëm dhe mund të shkaktojë një tejkalim të panevojshëm.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Saturatimi i mbledhjes së plotë.
        /// Llogarit `self + rhs`, duke ngopur në kufijtë numerikë në vend që të tejmbushet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Saturatimi i zbritjes së plotë.
        /// Llogarit `self - rhs`, duke ngopur në kufijtë numerikë në vend që të tejmbushet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Saturatimi i mohimit të plotë.
        /// Llogarit `-self`, duke e kthyer `MAX` nëse `self == MIN` në vend që të vërshojë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Ngopja e vlerës absolute.
        /// Llogarit `self.abs()`, duke e kthyer `MAX` nëse `self == MIN` në vend që të vërshojë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Ngopja e shumëzimit të plotë.
        /// Llogarit `self * rhs`, duke ngopur në kufijtë numerikë në vend që të tejmbushet.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Ngopja e eksponentimit të plotë.
        /// Llogarit `self.pow(exp)`, duke ngopur në kufijtë numerikë në vend që të tejmbushet.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Mbështjellja e shtesës (modular).
        /// Llogarit `self + rhs`, duke u mbështjellë në kufirin e llojit.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Mbështjellja e zbritjes (modular).
        /// Llogarit `self - rhs`, duke u mbështjellë në kufirin e llojit.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Mbështjellja e shumëzimit (modular).
        /// Llogarit `self * rhs`, duke u mbështjellë në kufirin e llojit.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Mbështjellja e ndarjes (modular).Llogarit `self / rhs`, duke u mbështjellë në kufirin e llojit.
        ///
        /// Rasti i vetëm ku mund të ndodhë një mbështjellje e tillë është kur ndan `MIN / -1` në një tip të nënshkruar (ku `MIN` është vlera minimale negative për llojin);kjo është ekuivalente me `-MIN`, një vlerë pozitive që është shumë e madhe për t'u përfaqësuar në llojin.
        /// Në një rast të tillë, ky funksion e kthen `MIN` vetë.
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Mbështjellja e ndarjes Euklidiane.
        /// Llogarit `self.div_euclid(rhs)`, duke u mbështjellë në kufirin e llojit.
        ///
        /// Mbështjellja do të ndodhë vetëm në `MIN / -1` në një lloj të nënshkruar (ku `MIN` është vlera minimale negative për llojin).
        /// Kjo është ekuivalente me `-MIN`, një vlerë pozitive që është shumë e madhe për t'u përfaqësuar në llojin.
        /// Në këtë rast, kjo metodë kthen `MIN` vetë.
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Mbështjellja e mbetjes (modular).Llogarit `self % rhs`, duke u mbështjellë në kufirin e llojit.
        ///
        /// Një mbështjellje e tillë kurrë nuk ndodh në të vërtetë matematikisht;artefaktet e implementimit e bëjnë `x % y` të pavlefshëm për `MIN / -1` në një lloj të nënshkruar (ku `MIN` është vlera minimale negative).
        ///
        /// Në një rast të tillë, ky funksion kthen `0`.
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Mbështjellja e mbetjeve euklidiane.Llogarit `self.rem_euclid(rhs)`, duke u mbështjellë në kufirin e llojit.
        ///
        /// Mbështjellja do të ndodhë vetëm në `MIN % -1` në një lloj të nënshkruar (ku `MIN` është vlera minimale negative për llojin).
        /// Në këtë rast, kjo metodë kthen 0.
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Paketimi i negacionit të (modular).Llogarit `-self`, duke u mbështjellë në kufirin e llojit.
        ///
        /// Rasti i vetëm ku mund të ndodhë një mbështjellje e tillë është kur mohon `MIN` në një tip të nënshkruar (ku `MIN` është vlera minimale negative për llojin);kjo është një vlerë pozitive që është shumë e madhe për t'u përfaqësuar në llojin.
        /// Në një rast të tillë, ky funksion e kthen `MIN` vetë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Zhvendosje bitwise pa Panic-majtas;jep `self << mask(rhs)`, ku `mask` heq çdo bit të rendit të lartë të `rhs` që do të bënte që zhvendosja të tejkalonte bitwidth-in e llojit.
        ///
        /// Vini re se kjo nuk është * e njëjtë me një rrotullim-majtas;RHS i një zhvendosjeje majtas të mbështjellësit kufizohet në diapazonin e llojit, në vend që bitët e zhvendosur nga LHS të kthehen në skajin tjetër.
        ///
        /// Llojet e plota primitive zbatojnë të gjithë një funksion [`rotate_left`](Self::rotate_left), i cili mund të jetë ai që dëshironi në vend.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SIGURIA: maskimi nga lloji i vogël i llojit siguron që ne të mos zhvendosemi
            // jashtë caqeve
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Shift-djathtas pa pikë Panic;jep `self >> mask(rhs)`, ku `mask` heq çdo bit të rendit të lartë të `rhs` që do të bënte që zhvendosja të tejkalonte bitwidth-in e llojit.
        ///
        /// Vini re se kjo nuk është * e njëjtë me një djathtas rrotulluese;RHS i një zhvendosje djathtas mbështjellëse kufizohet në diapazonin e llojit, në vend që bitët e zhvendosur nga LHS të kthehen në skajin tjetër.
        ///
        /// Llojet e plota primitive zbatojnë të gjithë një funksion [`rotate_right`](Self::rotate_right), i cili mund të jetë ai që dëshironi në vend.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SIGURIA: maskimi nga lloji i vogël i llojit siguron që ne të mos zhvendosemi
            // jashtë caqeve
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Mbështjellja e vlerës absolute (modular).Llogarit `self.abs()`, duke u mbështjellë në kufirin e llojit.
        ///
        /// Rasti i vetëm ku mund të ndodhë një mbështjellje e tillë është kur dikush merr vlerën absolute të vlerës minimale negative për llojin;kjo është një vlerë pozitive që është shumë e madhe për t'u përfaqësuar në llojin.
        /// Në një rast të tillë, ky funksion e kthen `MIN` vetë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Llogarit vlerën absolute të `self` pa asnjë mbështjellje ose panik.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Mbështjellja e eksponentimit (modular).
        /// Llogarit `self.pow(exp)`, duke u mbështjellë në kufirin e llojit.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // që nga exp!=0, më në fund exp duhet të jetë 1.
            // Merreni me bitin e fundit të eksponentit veçmas, pasi që katrorizimi i bazës më pas nuk është i nevojshëm dhe mund të shkaktojë një tejkalim të panevojshëm.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Llogarit `self` + `rhs`
        ///
        /// Kthen një pjesë të mbledhjes së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Nëse një tejmbushje do të kishte ndodhur, atëherë vlera e mbështjellur kthehet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Llogarit `self`, `rhs`
        ///
        /// Kthen një pjesë të zbritjes së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Nëse një tejmbushje do të kishte ndodhur, atëherë vlera e mbështjellur kthehet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Llogarit shumëzimin e `self` dhe `rhs`.
        ///
        /// Kthen një pjesë të shumëzimit së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Nëse një tejmbushje do të kishte ndodhur, atëherë vlera e mbështjellur kthehet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, e vërtetë));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Llogarit pjesëtuesin kur `self` ndahet me `rhs`.
        ///
        /// Kthen një pjesë të pjesëtuesit së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Nëse do të ndodhte një tejmbushje, atëherë vetja kthehet.
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Llogarit herësin e ndarjes Euklidiane `self.div_euclid(rhs)`.
        ///
        /// Kthen një pjesë të pjesëtuesit së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Nëse do të ndodhte një tejkalim, atëherë `self` kthehet.
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Llogarit pjesën e mbetur kur `self` ndahet me `rhs`.
        ///
        /// Kthen një copëz të pjesës së mbetur pasi të ndahet së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Nëse do të ndodhte një tejkalim, atëherë kthehet 0.
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Pjesa e mbetur euklidiane e tejmbushur.Llogarit `self.rem_euclid(rhs)`.
        ///
        /// Kthen një copëz të pjesës së mbetur pasi të ndahet së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Nëse do të ndodhte një tejkalim, atëherë kthehet 0.
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Negatitet vetë, tejmbushur nëse kjo është e barabartë me vlerën minimale.
        ///
        /// Kthen një pjesë të versionit të mohuar të vetvetes së bashku me një boolean që tregon nëse ka ndodhur një tejmbushje.
        /// Nëse `self` është vlera minimale (p.sh., `i32::MIN` për vlerat e tipit `i32`), atëherë vlera minimale do të kthehet përsëri dhe `true` do të kthehet për një mbingarkesë që ndodh.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Zhvendoset vetë lënë nga bitët `rhs`.
        ///
        /// Kthen një pjesë të versionit të zhvendosur të vetvetes së bashku me një boolean që tregon nëse vlera e zhvendosjes ishte më e madhe ose e barabartë me numrin e bitëve.
        /// Nëse vlera e zhvendosjes është shumë e madhe, atëherë vlera maskohet (N-1) ku N është numri i bitëve, dhe kjo vlerë përdoret më pas për të kryer zhvendosjen.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, e vërtetë));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Zhvendoset vetë drejt nga bitët `rhs`.
        ///
        /// Kthen një pjesë të versionit të zhvendosur të vetvetes së bashku me një boolean që tregon nëse vlera e zhvendosjes ishte më e madhe ose e barabartë me numrin e bitëve.
        /// Nëse vlera e zhvendosjes është shumë e madhe, atëherë vlera maskohet (N-1) ku N është numri i bitëve, dhe kjo vlerë përdoret më pas për të kryer zhvendosjen.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, e vërtetë));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Llogarit vlerën absolute të `self`.
        ///
        /// Kthen një pjesë të versionit absolut të vetvetes së bashku me një boolean që tregon nëse ka ndodhur një tejmbushje.
        /// Nëse vetja është vlera minimale
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// atëherë vlera minimale do të kthehet përsëri dhe e vërteta do të kthehet për një tejmbushje që ndodh.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Ngre veten në fuqinë e `exp`, duke përdorur eksponentimin me katror.
        ///
        /// Kthen një pjesë të eksponentimit së bashku me një bool duke treguar nëse ka ndodhur një mbingarkesë.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, e vërtetë));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Hapësirë gërvishtëse për ruajtjen e rezultateve të tejmbushur_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // që nga exp!=0, më në fund exp duhet të jetë 1.
            // Merreni me bitin e fundit të eksponentit veçmas, pasi që katrorizimi i bazës më pas nuk është i nevojshëm dhe mund të shkaktojë një tejkalim të panevojshëm.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Ngre veten në fuqinë e `exp`, duke përdorur eksponentimin me katror.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // që nga exp!=0, më në fund exp duhet të jetë 1.
            // Merreni me bitin e fundit të eksponentit veçmas, pasi që katrorizimi i bazës më pas nuk është i nevojshëm dhe mund të shkaktojë një tejkalim të panevojshëm.
            //
            //
            acc * base
        }

        /// Llogarit herësin e ndarjes Euklidiane të `self` me `rhs`.
        ///
        /// Kjo llogarit numrin e plotë `n` të tillë që `self = n * rhs + self.rem_euclid(rhs)`, me `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Me fjalë të tjera, rezultati është `self / rhs` i rrumbullakosur në numrin e plotë `n` i tillë që `self >= n * rhs`.
        /// Nëse `self > 0`, kjo është e barabartë me raundin drejt zeros (parazgjedhja në Rust);
        /// nëse `self < 0`, kjo është e barabartë me raundin drejt +/-pafundësi.
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0 ose ndarja rezulton në tejmbushje.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// le b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Llogarit pjesën më të vogël të mbetjes jonegative të `self (mod rhs)`.
        ///
        /// Kjo bëhet sikur nga algoritmi i ndarjes Euklidiane-dhënë `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` dhe `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0 ose ndarja rezulton në tejmbushje.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// le b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Llogarit vlerën absolute të `self`.
        ///
        /// # Sjellja e tejmbushur
        ///
        /// Vlera absolute e
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// nuk mund të përfaqësohet si një
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// dhe përpjekja për ta llogaritur atë do të shkaktojë një tejmbushje.
        /// Kjo do të thotë që kodi në modalitetin e korrigjimit do të shkaktojë një panic në këtë rast dhe kodi i optimizuar do të kthehet
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// pa një panic.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Vini re se#[inline] më lart do të thotë se semantika e tejmbushjes së zbritjes varet nga crate në të cilën po theksohemi.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Kthen një numër që përfaqëson shenjën e `self`.
        ///
        ///  - `0` nëse numri është zero
        ///  - `1` nëse numri është pozitiv
        ///  - `-1` nëse numri është negativ
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Kthen `true` nëse `self` është pozitiv dhe `false` nëse numri është zero ose negativ.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Kthen `true` nëse `self` është negativ dhe `false` nëse numri është zero ose pozitiv.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Ktheni paraqitjen e kujtesës së këtij numri të plotë si një grup bajtësh në rendin bajt të madh-endian (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Ktheni paraqitjen e kujtesës së këtij numri të plotë si një grup bajtësh në rend bajt pak endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Ktheni përfaqësimin e memorjes së këtij numri të plotë si një grup bajtësh sipas radhës së bajtëve.
        ///
        /// Ndërsa përdoret endianness amtare e platformës së synuar, në vend të kësaj, kodi i lëvizshëm duhet të përdorë [`to_be_bytes`] ose [`to_le_bytes`], sipas rastit.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bajt, nëse cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } tjeter {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SIGURIA: tinguj konstë sepse numrat e plotë janë tip të thjeshtë të të dhënave, kështu që ne mundemi gjithmonë
        // shndërroni ato në vargje bajtesh
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SIGURIA: numrat e plotë janë tip të thjeshtë të të dhënave, kështu që ne gjithmonë mund t'i zhvendosim ato
            // vargje bajtesh
            unsafe { mem::transmute(self) }
        }

        /// Ktheni përfaqësimin e memorjes së këtij numri të plotë si një grup bajtësh sipas radhës së bajtëve.
        ///
        ///
        /// [`to_ne_bytes`] duhet të preferohet mbi këtë kurdo që është e mundur.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// le bajte= num.as_ne_bytes();
        /// assert_eq!(
        ///     bajt, nëse cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } tjeter {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SIGURIA: numrat e plotë janë tip të thjeshtë të të dhënave, kështu që ne gjithmonë mund t'i zhvendosim ato
            // vargje bajtesh
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Krijoni një vlerë të plotë nga përfaqësimi i saj si një grup bajtësh në big endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// përdorni std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=pushim;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Krijoni një vlerë të plotë nga përfaqësimi i saj si një grup bajtësh në pak endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// përdorni std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=pushim;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Krijoni një vlerë të plotë nga përfaqësimi i saj i kujtesës si një grup bajtësh në endianitetin vendas.
        ///
        /// Ndërsa përdoret endianness amtare e platformës së synuar, kodi portativ ka të ngjarë të dëshirojë të përdorë [`from_be_bytes`] ose [`from_le_bytes`], siç është e përshtatshme në vend të kësaj.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } tjeter {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// përdorni std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=pushim;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SIGURIA: tinguj konstë sepse numrat e plotë janë tip të thjeshtë të të dhënave, kështu që ne mundemi gjithmonë
        // shndërrohet në to
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SIGURIA: numrat e plotë janë tip të thjeshtë të të dhënave, kështu që ne gjithmonë mund t'i transferojmë ato
            unsafe { mem::transmute(bytes) }
        }

        /// Kodi i ri duhet të preferojë të përdoret
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Kthen vlerën më të vogël që mund të përfaqësohet nga ky lloj i plotë.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Kodi i ri duhet të preferojë të përdoret
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Kthen vlerën më të madhe që mund të përfaqësohet nga ky lloj i plotë.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}