//! Konstantet për llojin e plotë të nënshkruar 32-bit.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! Kodi i ri duhet të përdorë konstante të shoqëruara direkt në llojin primitiv.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }