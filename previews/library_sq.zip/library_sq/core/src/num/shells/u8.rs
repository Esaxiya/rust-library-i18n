//! Konstantet për llojin e plotë të pa nënshkruar 8-bitësh.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! Kodi i ri duhet të përdorë konstante të shoqëruara direkt në llojin primitiv.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }