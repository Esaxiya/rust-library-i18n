//! Konstantet për llojin e plotë të nënshkruar me madhësi të treguesit.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Kodi i ri duhet të përdorë konstante të shoqëruara direkt në llojin primitiv.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }