//! Konstantet për llojin e plotë të nënshkruar 16-bitësh.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Kodi i ri duhet të përdorë konstante të shoqëruara direkt në llojin primitiv.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }