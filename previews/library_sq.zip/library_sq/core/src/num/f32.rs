//! Konstante specifike për llojin e pikës lundruese me precizion të vetëm `f32`.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Numra të rëndësishëm matematikisht janë dhënë në nën-modulin `consts`.
//!
//! Për konstantet e përcaktuara direkt në këtë modul (siç dallohen nga ato të përcaktuara në nën-modulin `consts`), kodi i ri duhet të përdorë konstantat shoqërues të përcaktuar direkt në llojin `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Radix ose baza e përfaqësimit të brendshëm të `f32`.
/// Përdorni [`f32::RADIX`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // mënyra e synuar
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Numri i shifrave të konsiderueshme në bazën 2.
/// Përdorni [`f32::MANTISSA_DIGITS`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // mënyra e synuar
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Numri i përafërt i shifrave të konsiderueshme në bazën 10.
/// Përdorni [`f32::DIGITS`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // mënyra e synuar
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] vlera për `f32`.
/// Përdorni [`f32::EPSILON`] në vend.
///
/// Ky është ndryshimi midis `1.0` dhe numrit tjetër më të madh të përfaqësueshëm.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // mënyra e synuar
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Vlera më e vogël e fundme `f32`.
/// Përdorni [`f32::MIN`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // mënyra e synuar
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Vlera më e vogël pozitive normale `f32`.
/// Përdorni [`f32::MIN_POSITIVE`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // mënyra e synuar
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Vlera më e madhe e fundme `f32`.
/// Përdorni [`f32::MAX`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // mënyra e synuar
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Një më i madh se fuqia minimale e mundshme normale e 2 eksponentit.
/// Përdorni [`f32::MIN_EXP`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // mënyra e synuar
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Fuqia maksimale e mundshme e 2 eksponentit.
/// Përdorni [`f32::MAX_EXP`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // mënyra e synuar
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Fuqia minimale e mundshme normale e 10 eksponentit.
/// Përdorni [`f32::MIN_10_EXP`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // mënyra e synuar
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Fuqia maksimale e mundshme e 10 eksponentit.
/// Përdorni [`f32::MAX_10_EXP`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // mënyra e synuar
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Jo një numër (NaN).
/// Përdorni [`f32::NAN`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // mënyra e synuar
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Përdorni [`f32::INFINITY`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // mënyra e synuar
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Pafundësi negative (−∞).
/// Përdorni [`f32::NEG_INFINITY`] në vend.
///
/// # Examples
///
/// ```rust
/// // mënyrë e amortizuar
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // mënyra e synuar
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Konstantat themelore matematikore.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: zëvendësoni me konstantat matematikore nga cmath.

    /// Konstanta e Arkimedit (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Konstanta e rrethit të plotë (τ)
    ///
    /// E barabartë me 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Numri i Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Radix ose baza e përfaqësimit të brendshëm të `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Numri i shifrave të konsiderueshme në bazën 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Numri i përafërt i shifrave të konsiderueshme në bazën 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] vlera për `f32`.
    ///
    /// Ky është ndryshimi midis `1.0` dhe numrit tjetër më të madh të përfaqësueshëm.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Vlera më e vogël e fundme `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Vlera më e vogël pozitive normale `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Vlera më e madhe e fundme `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Një më i madh se fuqia minimale e mundshme normale e 2 eksponentit.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Fuqia maksimale e mundshme e 2 eksponentit.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Fuqia minimale e mundshme normale e 10 eksponentit.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Fuqia maksimale e mundshme e 10 eksponentit.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Jo një numër (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Pafundësi negative (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Kthen `true` nëse kjo vlerë është `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` është publikisht i padisponueshëm në libcore për shkak të shqetësimeve në lidhje me transportueshmërinë, kështu që ky zbatim është për përdorim privat brenda.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Kthen `true` nëse kjo vlerë është pafundësi pozitive ose pafundësi negative, dhe `false` ndryshe.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Kthen `true` nëse ky numër nuk është as i pafund dhe as `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Nuk ka nevojë të trajtohet veçmas NaN: nëse vetja është NaN, krahasimi nuk është i vërtetë, saktësisht siç dëshirohet.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Kthen `true` nëse numri është [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Vlerat midis `0` dhe `min` janë nën normale.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Kthen `true` nëse numri nuk është as zero, i pafund, [subnormal] ose `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Vlerat midis `0` dhe `min` janë nën normale.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Kthen kategorinë e pikës lundruese të numrit.
    /// Nëse vetëm një pronë do të testohet, zakonisht është më shpejt të përdoret kallëzuesi specifik në vend të tij.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Kthen `true` nëse `self` ka një shenjë pozitive, përfshirë `+0.0`, `NaN` me pak shenjë pozitive dhe pafundësi pozitive.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Kthen `true` nëse `self` ka një shenjë negative, përfshirë `-0.0`, `NaN` me pak shenjë negative dhe pafundësi negative.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 thotë: isSignMinus(x) është i vërtetë nëse dhe vetëm nëse x ka shenjë negative.
        // isSignMinus vlen edhe për zero dhe NaN.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Merr (inverse) reciproke të një numri, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Shndërron radianët në gradë.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Përdorni një konstante për saktësi më të mirë.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Shndërron gradët në radian.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Kthen maksimumin e dy numrave.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Nëse një nga argumentet është NaN, atëherë argumenti tjetër kthehet.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Kthen minimumin e dy numrave.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Nëse një nga argumentet është NaN, atëherë argumenti tjetër kthehet.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Rrotullohet drejt zeros dhe shndërrohet në çdo lloj numri primitiv të plotë, duke supozuar se vlera është e fundme dhe përshtatet në atë lloj.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Vlera duhet të:
    ///
    /// * Të mos jetë `NaN`
    /// * Të mos jetë i pafund
    /// * Jini të përfaqësueshëm në llojin e kthimit `Int`, pasi të shkurtoni pjesën e tij fraksionale
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Transmetimi i papërpunuar në `u32`.
    ///
    /// Kjo aktualisht është identike me `transmute::<f32, u32>(self)` në të gjitha platformat.
    ///
    /// Shihni `from_bits` për disa diskutime mbi transportueshmërinë e këtij operacioni (pothuajse nuk ka çështje).
    ///
    /// Vini re se ky funksion është i dallueshëm nga hedhja `as`, e cila përpiqet të ruajë vlerën *numerike*, dhe jo vlerën bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() nuk po hedh!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // SIGURIA: `u32` është një tip i thjeshtë i të dhënave, kështu që ne gjithmonë mund të zhvendosemi në të
        unsafe { mem::transmute(self) }
    }

    /// Transmetimi i papërpunuar nga `u32`.
    ///
    /// Kjo aktualisht është identike me `transmute::<u32, f32>(v)` në të gjitha platformat.
    /// Rezulton se kjo është tepër e lëvizshme, për dy arsye:
    ///
    /// * Floats dhe Ints kanë të njëjtën fundshmëri në të gjitha platformat e mbështetura.
    /// * IEEE-754 specifikon me saktësi paraqitjen e bitit të notave.
    ///
    /// Sidoqoftë ekziston një paralajmërim: para versionit të IEEE-754 të vitit 2008, mënyra për të interpretuar bitin e sinjalizimit NaN nuk ishte specifikuar në të vërtetë.
    /// Shumica e platformave (sidomos x86 dhe ARM) zgjodhën interpretimin që u standardizua përfundimisht në 2008, por disa nuk e bënë (sidomos MIPS).
    /// Si rezultat, të gjithë NaN-të sinjalizues në MIPS janë NaN-të e qetë në x86, dhe anasjelltas.
    ///
    /// Në vend që të përpiqet të ruajë ndër-platformën e sinjalizimit, ky implementim favorizon ruajtjen e bitëve të saktë.
    /// Kjo do të thotë që çdo ngarkesë e ngarkuar e koduar në NaN do të ruhet edhe nëse rezultati i kësaj metode dërgohet përmes rrjetit nga një makinë x86 në atë MIPS.
    ///
    ///
    /// Nëse rezultatet e kësaj metode manipulohen vetëm nga e njëjta arkitekturë që i prodhoi ato, atëherë nuk ka asnjë shqetësim për transportueshmërinë.
    ///
    /// Nëse hyrja nuk është NaN, atëherë nuk ka shqetësim për transportueshmëri.
    ///
    /// Nëse nuk ju intereson sinjalizimi (ka shumë të ngjarë), atëherë nuk ka shqetësim për transportueshmëri.
    ///
    /// Vini re se ky funksion është i dallueshëm nga hedhja `as`, e cila përpiqet të ruajë vlerën *numerike*, dhe jo vlerën bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // SIGURIA: `u32` është një tip i thjeshtë i të dhënave, kështu që ne gjithmonë mund të zhvendosemi prej tij
        // Rezulton se çështjet e sigurisë me sNaN ishin të tejmbushura!Urë!
        unsafe { mem::transmute(v) }
    }

    /// Ktheni paraqitjen e kujtesës të këtij numri të pikave lundruese si një grup bajtësh në rendin bajt të madh-endian (network).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Ktheni paraqitjen e kujtesës të këtij numri të pikës lundruese si një grup bajtësh në rend bajt pak endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Ktheni paraqitjen e kujtesës të këtij numri të pikës lundruese si një grup bajtësh në rendin e bajtëve vendas.
    ///
    /// Ndërsa përdoret endianness amtare e platformës së synuar, në vend të kësaj, kodi i lëvizshëm duhet të përdorë [`to_be_bytes`] ose [`to_le_bytes`], sipas rastit.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Ktheni paraqitjen e kujtesës të këtij numri të pikës lundruese si një grup bajtësh në rendin e bajtëve vendas.
    ///
    ///
    /// [`to_ne_bytes`] duhet të preferohet mbi këtë kurdo që është e mundur.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // SIGURIA: `f32` është një tip i thjeshtë i të dhënave, kështu që ne gjithmonë mund të zhvendosemi në të
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Krijoni një vlerë të pikës lundruese nga paraqitja e saj si një grup bajtësh në endian të madh.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Krijoni një vlerë të pikës lundruese nga paraqitja e saj si një grup bajtësh në pak endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Krijoni një vlerë të pikës lundruese nga përfaqësimi i saj si një grup bajtësh në endianin vendas.
    ///
    /// Ndërsa përdoret endianness amtare e platformës së synuar, kodi portativ ka të ngjarë të dëshirojë të përdorë [`from_be_bytes`] ose [`from_le_bytes`], siç është e përshtatshme në vend të kësaj.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Kthen një renditje midis vetes dhe vlerave të tjera.
    /// Ndryshe nga krahasimi i pjesshëm standard midis numrave të pikave lundruese, ky krahasim prodhon gjithmonë një renditje në përputhje me kallëzuesin totalOrder siç përcaktohet në standardin e pikës lundruese IEEE 754 (rishikim 2008).
    /// Vlerat renditen sipas renditjes vijuese:
    /// - NeN qetësia negative
    /// - Sinjalizimi negativ NaN
    /// - Pafundësi negative
    /// - Numrat negativë
    /// - Numrat nënnormalë negativë
    /// - Zero negative
    /// - Zero pozitive
    /// - Numrat pozitivë nënnormalë
    /// - Numrat pozitivë
    /// - Pafundësi pozitive
    /// - Sinjalizimi pozitiv i NaN
    /// - Qetë pozitive NaN
    ///
    /// Vini re se ky funksion nuk është gjithmonë dakord me implementimet [`PartialOrd`] dhe [`PartialEq`] të `f32`.Në veçanti, ata e konsiderojnë zero negative dhe pozitive si të barabartë, ndërsa `total_cmp` jo.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Në rast të negativave, rrokullisni të gjitha bitët përveç shenjës për të arritur një paraqitje të ngjashme me numrat e plotë plotësues të dyve
        //
        // Pse funksionon kjo?Notat IEEE 754 përbëhen nga tre fusha:
        // Shenjë bit, eksponent dhe mantissa.Bashkësia e fushave të eksponentit dhe mantisës në tërësi kanë vetinë që rendi i tyre bitwise është i barabartë me madhësinë numerike ku përcaktohet madhësia.
        // Madhësia normalisht nuk përcaktohet në vlerat NaN, por IEEE 754 totalOrder përcakton vlerat NaN gjithashtu për të ndjekur rendin bit.Kjo çon në rendin e shpjeguar në komentin e dok.
        // Sidoqoftë, paraqitja e madhësisë është e njëjtë për numrat negativë dhe pozitivë-vetëm biti i shenjës është i ndryshëm.
        // Për të krahasuar lehtësisht notat si numra të plotë të nënshkruar, duhet të rrokullisim bitët e eksponentit dhe mantissa në rast të numrave negativë.
        // Ne në mënyrë efektive i konvertojmë numrat në formën "two's complement".
        //
        // Për të bërë rrotullimin, ne ndërtojmë një maskë dhe XOR kundër saj.
        // Ne llogarisim me degë një maskë "all-ones except for the sign bit" nga vlerat e nënshkruara negativisht: shenja me zhvendosje të djathtë-zgjat numrin e plotë, kështu që ne "fill" maskën me copa shenjash, dhe pastaj konvertohemi në të pa nënshkruar për të shtyrë një bit tjetër zero.
        //
        // Në vlerat pozitive, maska është e gjitha zero, kështu që është një no-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Kufizoni një vlerë në një interval të caktuar nëse nuk është NaN.
    ///
    /// Kthen `max` nëse `self` është më i madh se `max` dhe `min` nëse `self` është më i vogël se `min`.
    /// Përndryshe kjo kthen `self`.
    ///
    /// Vini re se ky funksion kthen NaN nëse edhe vlera fillestare ishte NaN.
    ///
    /// # Panics
    ///
    /// Panics nëse `min > max`, `min` është NaN, ose `max` është NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}