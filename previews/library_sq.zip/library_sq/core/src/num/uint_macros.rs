macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Vlera më e vogël që mund të përfaqësohet nga ky lloj i plotë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Vlera më e madhe që mund të përfaqësohet nga ky lloj i plotë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Madhësia e këtij lloji të plotë në bit.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Shndërron një fetë vargu në një bazë të caktuar në një numër të plotë.
        ///
        /// Vargu pritet të jetë një shenjë opsionale `+` e ndjekur nga shifra.
        ///
        /// Hapësira e bardhë drejtuese dhe zvarritëse paraqet një gabim.
        /// Shifrat janë një nëngrup i këtyre karaktereve, në varësi të `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Ky funksion panics nëse `radix` nuk është në intervalin nga 2 në 36.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Kthen numrin e atyre në paraqitjen binare të `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Kthen numrin e zerove në paraqitjen binare të `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Kthen numrin e zero drejtuese në përfaqësimin binar të `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Kthen numrin e zerove zvarritës në paraqitjen binare të `self`.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Kthen numrin e atyre kryesorë në përfaqësimin binar të `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Kthen numrin e atyre që zvarriten në përfaqësimin binar të `self`.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Zhvendos bitët majtas me një sasi të specifikuar, `n`, duke mbështjellë bitët e cunguar në fund të numrit të plotë që rezulton.
        ///
        ///
        /// Ju lutem vini re se ky nuk është i njëjti operacion me operatorin zhvendosës `<<`!
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Zhvendos bitët në të djathtë me një sasi të specifikuar, `n`, duke mbështjellë bitët e cunguar në fillim të numrit të plotë që rezulton.
        ///
        ///
        /// Ju lutem vini re se ky nuk është i njëjti operacion me operatorin zhvendosës `>>`!
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Ndryshon rendin e bajtëve të numrit të plotë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// le m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Ndryshon rendin e bitëve në numrin e plotë.
        /// Biti më pak i rëndësishëm bëhet biti më i rëndësishëm, i dyti bit i dytë më pak i rëndësishëm bëhet biti i dytë më i rëndësishëm, etj.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// le m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Shndërron një numër të plotë nga endiani i madh në endianitetin e synimit.
        ///
        /// Në endian të madh kjo është një no-op.
        /// Në endianin e vogël bajtet shkëmbehen.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// nëse cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } tjeter {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Shndërron një numër të plotë nga endiani i vogël në endianitetin e synimit.
        ///
        /// Në pak endian kjo është një no-op.
        /// Në endian të madh bajtët shkëmbehen.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// nëse cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } tjeter {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Shndërron `self` në endian të madh nga endianiteti i synimit.
        ///
        /// Në endian të madh kjo është një no-op.
        /// Në endianin e vogël bajtet shkëmbehen.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// nëse cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } tjetër { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // apo te mos jesh?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Shndërron `self` në endian të vogël nga endianiteti i synimit.
        ///
        /// Në pak endian kjo është një no-op.
        /// Në endian të madh bajtët shkëmbehen.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// nëse cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } tjetër { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Shtesë e plotë e kontrolluar.
        /// Llogarit `self + rhs`, duke e kthyer `None` nëse ka ndodhur mbingarkesë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Shtesë e plotë e paketuar.Llogarit `self + rhs`, duke supozuar se nuk mund të ndodhë mbingarkesë.
        /// Kjo rezulton në një sjellje të papërcaktuar kur
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Zbritja e kontrolluar e plotë.
        /// Llogarit `self - rhs`, duke e kthyer `None` nëse ka ndodhur mbingarkesë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Zbritja e plotë e paketuar.Llogarit `self - rhs`, duke supozuar se nuk mund të ndodhë mbingarkesë.
        /// Kjo rezulton në një sjellje të papërcaktuar kur
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Shumëzimi i kontrolluar i plotë.
        /// Llogarit `self * rhs`, duke e kthyer `None` nëse ka ndodhur mbingarkesë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Shumëzimi i plotë i pakontrolluar.Llogarit `self * rhs`, duke supozuar se nuk mund të ndodhë mbingarkesë.
        /// Kjo rezulton në një sjellje të papërcaktuar kur
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Ndarja e kontrolluar e plotë.
        /// Llogarit `self / rhs`, duke e kthyer `None` nëse `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SIGURIA: div nga zero është kontrolluar më sipër dhe llojet e pa nënshkruar nuk kanë asnjë tjetër
                // mënyrat e dështimit për ndarjen
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Ndarja e kontrolluar euklidiane.
        /// Llogarit `self.div_euclid(rhs)`, duke e kthyer `None` nëse `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Pjesa e mbetur e plotë e kontrolluar.
        /// Llogarit `self % rhs`, duke e kthyer `None` nëse `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SIGURIA: div nga zero është kontrolluar më sipër dhe llojet e pa nënshkruar nuk kanë asnjë tjetër
                // mënyrat e dështimit për ndarjen
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Moduli i kontrolluar euklidian.
        /// Llogarit `self.rem_euclid(rhs)`, duke e kthyer `None` nëse `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Mohimi i kontrolluar.Llogarit `-self`, duke e kthyer `None` përveç nëse `vetja==
        /// 0`.
        ///
        /// Vini re se mohimi i ndonjë numri të plotë pozitiv do të tejmbushet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ndryshimi i kontrolluar majtas.
        /// Llogarit `self << rhs`, duke e kthyer `None` nëse `rhs` është më i madh ose i barabartë me numrin e bitëve në `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ndryshimi i kontrolluar djathtas.
        /// Llogarit `self >> rhs`, duke e kthyer `None` nëse `rhs` është më i madh ose i barabartë me numrin e bitëve në `self`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Eksponimi i kontrolluar.
        /// Llogarit `self.pow(exp)`, duke e kthyer `None` nëse ka ndodhur mbingarkesë.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // që nga exp!=0, më në fund exp duhet të jetë 1.
            // Merreni me bitin e fundit të eksponentit veçmas, pasi që katrorizimi i bazës më pas nuk është i nevojshëm dhe mund të shkaktojë një tejkalim të panevojshëm.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Saturatimi i mbledhjes së plotë.
        /// Llogarit `self + rhs`, duke ngopur në kufijtë numerikë në vend që të tejmbushet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Saturatimi i zbritjes së plotë.
        /// Llogarit `self - rhs`, duke ngopur në kufijtë numerikë në vend që të tejmbushet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Ngopja e shumëzimit të plotë.
        /// Llogarit `self * rhs`, duke ngopur në kufijtë numerikë në vend që të tejmbushet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Ngopja e eksponentimit të plotë.
        /// Llogarit `self.pow(exp)`, duke ngopur në kufijtë numerikë në vend që të tejmbushet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Mbështjellja e shtesës (modular).
        /// Llogarit `self + rhs`, duke u mbështjellë në kufirin e llojit.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Mbështjellja e zbritjes (modular).
        /// Llogarit `self - rhs`, duke u mbështjellë në kufirin e llojit.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Mbështjellja e shumëzimit (modular).
        /// Llogarit `self * rhs`, duke u mbështjellë në kufirin e llojit.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// Ju lutem vini re se ky shembull ndahet midis llojeve të plota.
        /// Gjë që shpjegon pse përdoret `u8` këtu.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Mbështjellja e ndarjes (modular).Llogarit `self / rhs`.
        /// Ndarja e mbështjellë në llojet e pa nënshkruar është thjesht ndarje normale.
        /// Nuk ka asnjë mënyrë që të ndodhë paketimi.
        /// Ky funksion ekziston, kështu që të gjitha operacionet llogariten në operacionet e mbështjelljes.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Mbështjellja e ndarjes Euklidiane.Llogarit `self.div_euclid(rhs)`.
        /// Ndarja e mbështjellë në llojet e pa nënshkruar është thjesht ndarje normale.
        /// Nuk ka asnjë mënyrë që të ndodhë paketimi.
        /// Ky funksion ekziston, kështu që të gjitha operacionet llogariten në operacionet e mbështjelljes.
        /// Meqenëse, për numrat e plotë pozitivë, të gjithë përkufizimet e zakonshme të ndarjes janë të barabarta, kjo është saktësisht e barabartë me `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Mbështjellja e mbetjes (modular).Llogarit `self % rhs`.
        /// Llogaritja e mbetjeve të mbështjellura në llojet e pa nënshkruara është vetëm llogaritja e mbetjeve të rregullta.
        ///
        /// Nuk ka asnjë mënyrë që të ndodhë paketimi.
        /// Ky funksion ekziston, kështu që të gjitha operacionet llogariten në operacionet e mbështjelljes.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Mbështjellja e modulit euklidian.Llogarit `self.rem_euclid(rhs)`.
        /// Llogaritja e modulit të mbështjellur në llojet e pa nënshkruar është vetëm llogaritja e rregullt e mbetjeve.
        /// Nuk ka asnjë mënyrë që të ndodhë paketimi.
        /// Ky funksion ekziston, kështu që të gjitha operacionet llogariten në operacionet e mbështjelljes.
        /// Meqenëse, për numrat e plotë pozitivë, të gjithë përkufizimet e zakonshme të ndarjes janë të barabarta, kjo është saktësisht e barabartë me `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Paketimi i negacionit (modular).
        /// Llogarit `-self`, duke u mbështjellë në kufirin e llojit.
        ///
        /// Meqenëse llojet e pa nënshkruar nuk kanë ekuivalentë negativë, të gjitha aplikacionet e këtij funksioni do të përfundojnë (përveç `-0`).
        /// Për vlerat më të vogla se maksimumi i tipit përkatës të nënshkruar rezultati është i njëjtë me hedhjen e vlerës përkatëse të nënshkruar.
        ///
        /// Çdo vlerë më e madhe është ekuivalente me `MAX + 1 - (val - MAX - 1)` ku `MAX` është maksimumi i tipit përkatës të nënshkruar.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// Ju lutem vini re se ky shembull ndahet midis llojeve të plota.
        /// Gjë që shpjegon pse përdoret `i8` këtu.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Zhvendosje bitwise pa Panic-majtas;
        /// jep `self << mask(rhs)`, ku `mask` heq çdo bit të rendit të lartë të `rhs` që do të bënte që zhvendosja të tejkalonte bitwidth-in e llojit.
        ///
        /// Vini re se kjo nuk është * e njëjtë me një rrotullim-majtas;RHS i një zhvendosjeje majtas të mbështjellësit kufizohet në diapazonin e llojit, në vend që bitët e zhvendosur nga LHS të kthehen në skajin tjetër.
        /// Llojet e plota primitive zbatojnë të gjithë një funksion [`rotate_left`](Self::rotate_left), i cili mund të jetë ai që dëshironi në vend.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SIGURIA: maskimi nga lloji i vogël i llojit siguron që ne të mos zhvendosemi
            // jashtë caqeve
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Shift-djathtas pa pikë Panic;
        /// jep `self >> mask(rhs)`, ku `mask` heq çdo bit të rendit të lartë të `rhs` që do të bënte që zhvendosja të tejkalonte bitwidth-in e llojit.
        ///
        /// Vini re se kjo nuk është * e njëjtë me një djathtas rrotulluese;RHS i një zhvendosje djathtas mbështjellëse kufizohet në diapazonin e llojit, në vend që bitët e zhvendosur nga LHS të kthehen në skajin tjetër.
        /// Llojet e plota primitive zbatojnë të gjithë një funksion [`rotate_right`](Self::rotate_right), i cili mund të jetë ai që dëshironi në vend.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SIGURIA: maskimi nga lloji i vogël i llojit siguron që ne të mos zhvendosemi
            // jashtë caqeve
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Mbështjellja e eksponentimit (modular).
        /// Llogarit `self.pow(exp)`, duke u mbështjellë në kufirin e llojit.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // që nga exp!=0, më në fund exp duhet të jetë 1.
            // Merreni me bitin e fundit të eksponentit veçmas, pasi që katrorizimi i bazës më pas nuk është i nevojshëm dhe mund të shkaktojë një tejkalim të panevojshëm.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Llogarit `self` + `rhs`
        ///
        /// Kthen një pjesë të mbledhjes së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Nëse një tejmbushje do të kishte ndodhur, atëherë vlera e mbështjellur kthehet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Llogarit `self`, `rhs`
        ///
        /// Kthen një pjesë të zbritjes së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Nëse një tejmbushje do të kishte ndodhur, atëherë vlera e mbështjellur kthehet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Llogarit shumëzimin e `self` dhe `rhs`.
        ///
        /// Kthen një pjesë të shumëzimit së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Nëse një tejmbushje do të kishte ndodhur, atëherë vlera e mbështjellur kthehet.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// Ju lutem vini re se ky shembull ndahet midis llojeve të plota.
        /// Gjë që shpjegon pse këtu përdoret `u32`.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Llogarit pjesëtuesin kur `self` ndahet me `rhs`.
        ///
        /// Kthen një pjesë të pjesëtuesit së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Vini re se për numrat e plotë të pa nënshkruar nuk ndodh kurrë mbingarkesa, kështu që vlera e dytë është gjithmonë `false`.
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Llogarit herësin e ndarjes Euklidiane `self.div_euclid(rhs)`.
        ///
        /// Kthen një pjesë të pjesëtuesit së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Vini re se për numrat e plotë të pa nënshkruar nuk ndodh kurrë mbingarkesa, kështu që vlera e dytë është gjithmonë `false`.
        /// Meqenëse, për numrat e plotë pozitivë, të gjithë përkufizimet e zakonshme të ndarjes janë të barabarta, kjo është saktësisht e barabartë me `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Llogarit pjesën e mbetur kur `self` ndahet me `rhs`.
        ///
        /// Kthen një copëz të pjesës së mbetur pasi të ndahet së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Vini re se për numrat e plotë të pa nënshkruar nuk ndodh kurrë mbingarkesa, kështu që vlera e dytë është gjithmonë `false`.
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Llogarit pjesën e mbetur `self.rem_euclid(rhs)` sikur me ndarjen euklidiane.
        ///
        /// Kthen një copë të modulit pasi të ndahet së bashku me një boolean që tregon nëse do të ndodhte një tejkalim aritmetik.
        /// Vini re se për numrat e plotë të pa nënshkruar nuk ndodh kurrë mbingarkesa, kështu që vlera e dytë është gjithmonë `false`.
        /// Meqenëse, për numrat e plotë pozitivë, të gjithë përkufizimet e zakonshme të ndarjes janë të barabarta, ky operacion është saktësisht i barabartë me `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negatit veten në një mënyrë të tejmbushur.
        ///
        /// Kthen `!self + 1` duke përdorur operacione mbështjellëse për të kthyer vlerën që përfaqëson mohimin e kësaj vlere të nënshkruar.
        /// Vini re se për vlerat pozitive të nënshkruara ndodh gjithmonë tejmbushja, por mohimi i 0 nuk tejmbush.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Zhvendoset vetë lënë nga bitët `rhs`.
        ///
        /// Kthen një pjesë të versionit të zhvendosur të vetvetes së bashku me një boolean që tregon nëse vlera e zhvendosjes ishte më e madhe ose e barabartë me numrin e bitëve.
        /// Nëse vlera e zhvendosjes është shumë e madhe, atëherë vlera maskohet (N-1) ku N është numri i bitëve, dhe kjo vlerë përdoret më pas për të kryer zhvendosjen.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Zhvendoset vetë drejt nga bitët `rhs`.
        ///
        /// Kthen një pjesë të versionit të zhvendosur të vetvetes së bashku me një boolean që tregon nëse vlera e zhvendosjes ishte më e madhe ose e barabartë me numrin e bitëve.
        /// Nëse vlera e zhvendosjes është shumë e madhe, atëherë vlera maskohet (N-1) ku N është numri i bitëve, dhe kjo vlerë përdoret më pas për të kryer zhvendosjen.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Ngre veten në fuqinë e `exp`, duke përdorur eksponentimin me katror.
        ///
        /// Kthen një pjesë të eksponentimit së bashku me një bool duke treguar nëse ka ndodhur një mbingarkesë.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, e vërtetë));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Hapësirë gërvishtëse për ruajtjen e rezultateve të tejmbushur_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // që nga exp!=0, më në fund exp duhet të jetë 1.
            // Merreni me bitin e fundit të eksponentit veçmas, pasi që katrorizimi i bazës më pas nuk është i nevojshëm dhe mund të shkaktojë një tejkalim të panevojshëm.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Ngre veten në fuqinë e `exp`, duke përdorur eksponentimin me katror.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // që nga exp!=0, më në fund exp duhet të jetë 1.
            // Merreni me bitin e fundit të eksponentit veçmas, pasi që katrorizimi i bazës më pas nuk është i nevojshëm dhe mund të shkaktojë një tejkalim të panevojshëm.
            //
            //
            acc * base
        }

        /// Kryen ndarjen euklidiane.
        ///
        /// Meqenëse, për numrat e plotë pozitivë, të gjithë përkufizimet e zakonshme të ndarjes janë të barabarta, kjo është saktësisht e barabartë me `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Llogarit pjesën më të vogël të `self (mod rhs)`.
        ///
        /// Meqenëse, për numrat e plotë pozitivë, të gjithë përkufizimet e zakonshme të ndarjes janë të barabarta, kjo është saktësisht e barabartë me `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ky funksion do të panic nëse `rhs` është 0.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Kthen `true` nëse dhe vetëm nëse `self == 2^k` për disa `k`.
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Kthen një më pak se fuqia tjetër e dy.
        // (Për 8u8 fuqia tjetër e dy është 8u8 dhe për 6u8 është 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Kjo metodë nuk mund të tejkalojë, pasi në rastet e mbingarkesës `next_power_of_two` në vend të kësaj përfundon duke kthyer vlerën maksimale të llojit dhe mund të kthejë 0 për 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SIGURIA: Për shkak të `p > 0`, nuk mund të përbëhet tërësisht nga zero drejtuese.
            // Kjo do të thotë që zhvendosja është gjithmonë brenda kufijve, dhe disa procesorë (të tillë si intel pre-haswell) kanë intrinsika më efikase të ctlz kur argumenti nuk është zero.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Kthen fuqinë më të vogël prej dy më të madhe ose të barabartë me `self`.
        ///
        /// Kur vlera e kthimit tejmbush (p.sh., `self > (1 << (N-1))` për llojin `uN`), ajo panics në modalitetin e korrigjimit dhe vlera e kthimit mbështillet në 0 në mënyrën e lëshimit (e vetmja situatë në të cilën metoda mund të kthejë 0).
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Kthen fuqinë më të vogël prej dy më të madhe ose të barabartë me `n`.
        /// Nëse fuqia tjetër e dy është më e madhe se vlera maksimale e llojit, `None` kthehet, përndryshe fuqia e dy është e mbështjellë me `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Kthen fuqinë më të vogël prej dy më të madhe ose të barabartë me `n`.
        /// Nëse fuqia tjetër e dy është më e madhe se vlera maksimale e llojit, vlera e kthimit mbështillet në `0`.
        ///
        ///
        /// # Examples
        ///
        /// Përdorimi bazë:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Ktheni paraqitjen e kujtesës së këtij numri të plotë si një grup bajtësh në rendin bajt të madh-endian (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Ktheni paraqitjen e kujtesës së këtij numri të plotë si një grup bajtësh në rend bajt pak endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Ktheni përfaqësimin e memorjes së këtij numri të plotë si një grup bajtësh sipas radhës së bajtëve.
        ///
        /// Ndërsa përdoret endianness amtare e platformës së synuar, në vend të kësaj, kodi i lëvizshëm duhet të përdorë [`to_be_bytes`] ose [`to_le_bytes`], sipas rastit.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bajt, nëse cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } tjeter {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SIGURIA: tinguj konstë sepse numrat e plotë janë tip të thjeshtë të të dhënave, kështu që ne mundemi gjithmonë
        // shndërroni ato në vargje bajtesh
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SIGURIA: numrat e plotë janë tip të thjeshtë të të dhënave, kështu që ne gjithmonë mund t'i zhvendosim ato
            // vargje bajtesh
            unsafe { mem::transmute(self) }
        }

        /// Ktheni përfaqësimin e memorjes së këtij numri të plotë si një grup bajtësh sipas radhës së bajtëve.
        ///
        ///
        /// [`to_ne_bytes`] duhet të preferohet mbi këtë kurdo që është e mundur.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// le bajte= num.as_ne_bytes();
        /// assert_eq!(
        ///     bajt, nëse cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } tjeter {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SIGURIA: numrat e plotë janë tip të thjeshtë të të dhënave, kështu që ne gjithmonë mund t'i zhvendosim ato
            // vargje bajtesh
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Krijoni një vlerë të plotë indiane endian nga përfaqësimi i tij si një grup bajtësh në big endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// përdorni std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=pushim;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Krijoni një vlerë të plotë indiane endian nga përfaqësimi i saj si një grup bajtësh në pak endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// përdorni std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=pushim;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Krijoni një vlerë të plotë indiane endian nga paraqitja e saj e kujtesës si një grup bajtësh në endianitetin vendas.
        ///
        /// Ndërsa përdoret endianness amtare e platformës së synuar, kodi portativ ka të ngjarë të dëshirojë të përdorë [`from_be_bytes`] ose [`from_le_bytes`], siç është e përshtatshme në vend të kësaj.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } tjeter {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// përdorni std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=pushim;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SIGURIA: tinguj konstë sepse numrat e plotë janë tip të thjeshtë të të dhënave, kështu që ne mundemi gjithmonë
        // shndërrohet në to
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SIGURIA: numrat e plotë janë tip të thjeshtë të të dhënave, kështu që ne gjithmonë mund t'i transferojmë ato
            unsafe { mem::transmute(bytes) }
        }

        /// Kodi i ri duhet të preferojë të përdoret
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Kthen vlerën më të vogël që mund të përfaqësohet nga ky lloj i plotë.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Kodi i ri duhet të preferojë të përdoret
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Kthen vlerën më të madhe që mund të përfaqësohet nga ky lloj i plotë.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}