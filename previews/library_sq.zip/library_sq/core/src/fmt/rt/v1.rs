//! Ky është një modul i brendshëm i përdorur nga ifmt!koha e ekzekutimitKëto struktura emetohen në vargje statike për të parakompiluar vargjet e formatit përpara kohe.
//!
//! Këto përkufizime janë të ngjashme me ekuivalentët e tyre `ct`, por ndryshojnë në atë që këto mund të alokohen statikisht dhe janë optimizuar pak për kohën e ekzekutimit.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Rreshtimet e mundshme që mund të kërkohen si pjesë e një direktive të formatimit.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Tregues që përmbajtja duhet të rreshtohet në të majtë.
    Left,
    /// Tregues se përmbajtja duhet të jetë e drejtuar.
    Right,
    /// Tregues që përmbajtja duhet të jetë në një linjë qendrore.
    Center,
    /// Asnjë rreshtim nuk u kërkua.
    Unknown,
}

/// Përdoret nga specifikuesit [width](https://doc.rust-lang.org/std/fmt/#width) dhe [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Specifikuar me një numër fjalë për fjalë, ruan vlerën
    Is(usize),
    /// Specifikuar duke përdorur sintaksat `$` dhe `*`, ruan indeksin në `args`
    Param(usize),
    /// E paspecifikuar
    Implied,
}