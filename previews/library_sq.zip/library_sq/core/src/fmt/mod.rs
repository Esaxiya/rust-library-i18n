//! Shërbime për formatimin dhe shtypjen e vargjeve.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Rreshtimet e mundshme të kthyera nga `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Tregues që përmbajtja duhet të rreshtohet në të majtë.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Tregues se përmbajtja duhet të jetë e drejtuar.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Tregues që përmbajtja duhet të jetë në një linjë qendrore.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Lloji i kthyer nga metodat e formatimit.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Lloji i gabimit i cili kthehet nga formatimi i një mesazhi në një transmetim.
///
/// Ky lloj nuk mbështet transmetimin e një gabimi tjetër përveç se një gabim ka ndodhur.
/// Çdo informacion shtesë duhet të rregullohet që të transmetohet përmes disa mënyrave të tjera.
///
/// Një gjë e rëndësishme për të mbajtur mend është se lloji `fmt::Error` nuk duhet të ngatërrohet me [`std::io::Error`] ose [`std::error::Error`], të cilat gjithashtu mund të keni në fushëveprim.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// Një trait për të shkruar ose formatuar në buffer ose transmetime që pranojnë Unicode.
///
/// Ky trait pranon vetëm të dhëna të koduara me UTF-8 dhe nuk është [flushable].
/// Nëse dëshironi të pranoni vetëm Unicode dhe nuk keni nevojë për skuqje, duhet të zbatoni këtë trait;
/// përndryshe duhet të implementoni [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Shkruan një fetë vargu në këtë shkrimtar, duke u kthyer nëse shkrimi kishte sukses.
    ///
    /// Kjo metodë mund të ketë sukses vetëm nëse e gjithë feta e vargut është shkruar me sukses, dhe kjo metodë nuk do të kthehet derisa të gjitha të dhënat të jenë shkruar ose të ndodhë një gabim.
    ///
    ///
    /// # Errors
    ///
    /// Ky funksion do të kthejë një shembull të [`Error`] në gabim.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Shkruan një [`char`] në këtë shkrimtar, duke u kthyer nëse shkrimi kishte sukses.
    ///
    /// Një [`char`] i vetëm mund të kodifikohet si më shumë se një bajt.
    /// Kjo metodë mund të ketë sukses vetëm nëse e gjithë sekuenca e bajteve është shkruar me sukses, dhe kjo metodë nuk do të kthehet derisa të gjitha të dhënat të jenë shkruar ose të ndodhë një gabim.
    ///
    ///
    /// # Errors
    ///
    /// Ky funksion do të kthejë një shembull të [`Error`] në gabim.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Ngjitës për përdorimin e makros [`write!`] me implementuesit e këtij trait.
    ///
    /// Kjo metodë përgjithësisht nuk duhet të thirret manualisht, por më tepër përmes vetë makros [`write!`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Konfigurimi për formatimin.
///
/// Një `Formatter` përfaqëson mundësi të ndryshme në lidhje me formatimin.
/// Përdoruesit nuk ndërtojnë `Formatter` direkt;një referencë e ndryshueshme për njërën i kalohet metodës `fmt` të të gjitha formateve traits, si [`Debug`] dhe [`Display`].
///
///
/// Për të bashkëvepruar me një `Formatter`, do të thirrni metoda të ndryshme për të ndryshuar opsionet e ndryshme që lidhen me formatimin.
/// Për shembuj, ju lutemi shikoni dokumentacionin e metodave të përcaktuara në `Formatter` më poshtë.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Argumenti është në thelb një funksion formatimi i zbatuar pjesërisht i optimizuar, ekuivalent me `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Ky struktur përfaqëson "argument" gjenerik i cili merret nga familja e funksioneve Xprintf.Ai përmban një funksion për të formatuar vlerën e dhënë.
/// Në kohën e përpilimit sigurohet që funksioni dhe vlera të kenë llojet e sakta, dhe pastaj kjo strukturë përdoret për të kanonizuar argumentet në një lloj.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Kjo garanton një vlerë të vetme të qëndrueshme për treguesin e funksionit të lidhur me indices/counts në infrastrukturën e formatimit.
//
// Vini re se një funksion i përcaktuar si i tillë nuk do të ishte i saktë pasi funksionet gjithmonë etiketohen si unamed_addr me uljen e rrymës në IR LLVM, kështu që adresa e tyre nuk konsiderohet e rëndësishme për LLVM dhe si e tillë hedhja as_usize mund të ishte keqpërbërë.
//
// Në praktikë, ne kurrë nuk e quajmë as_usize në të dhëna që nuk përdorin (si çështje e gjenerimit statik të argumenteve të formatimit), kështu që ky është thjesht një kontroll shtesë.
//
// Kryesisht duam të sigurojmë që treguesi i funksionit në `USIZE_MARKER` të ketë një adresë që korrespondon *vetëm* me funksionet që gjithashtu marrin `&usize` si argumentin e tyre të parë.
// Read_volatile këtu siguron që ne të mund të përgatisim me siguri një përdorim nga referenca e kaluar dhe që kjo adresë të mos tregojë në funksionin e marrjes jo-të përdorimit.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // SIGURIA: ptr është një referencë
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // SIGURIA: `mem::transmute(x)` është i sigurt sepse
        //     1. `&'b T` mban jetën e origjinës me `'b` (në mënyrë që të mos ketë një jetë të pakufizuar)
        //     2.
        //     `&'b T` dhe `&'b Opaque` kanë të njëjtën paraqitje të kujtesës (kur `T` është `Sized`, siç është këtu) `mem::transmute(f)` është i sigurt pasi `fn(&T, &mut Formatter<'_>) -> Result` dhe `fn(&Opaque, &mut Formatter<'_>) -> Result` kanë të njëjtën ABI (për sa kohë që `T` është `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // SIGURIA: Fusha `formatter` është vendosur në USIZE_MARKER vetëm nëse
            // vlera është një përdorim, kështu që kjo është e sigurt
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// flamuj të disponueshëm në formatin v1 të formatit_argëve
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Kur përdorni makron format_args! (), Ky funksion përdoret për të gjeneruar strukturën e Argumenteve.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Ky funksion përdoret për të specifikuar parametrat jostandardë të formatimit.
    /// Vargu `pieces` duhet të jetë të paktën aq i gjatë sa `fmt` për të ndërtuar një strukturë të vlefshme Argumentesh.
    /// Gjithashtu, çdo `Count` brenda `fmt` që është `CountIsParam` ose `CountIsNextParam` duhet të tregojë për një argument të krijuar me `argumentusize`.
    ///
    /// Sidoqoftë, dështimi për ta bërë këtë nuk shkakton pasiguri, por do të injorojë të pavlefshëm.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Vlerëson gjatësinë e tekstit të formatuar.
    ///
    /// Kjo është menduar të përdoret për të vendosur kapacitetin fillestar `String` kur përdorni `format!`.
    /// Note: kjo nuk është as kufiri i poshtëm dhe as i sipërm.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Nëse vargu i formatit fillon me një argument, mos alokoni asgjë, përveç nëse gjatësia e pjesëve është e rëndësishme.
            //
            //
            0
        } else {
            // Ka disa argumente, kështu që çdo shtytje shtesë do të rialokojë vargun.
            //
            // Për të shmangur atë, ne jemi "pre-doubling" kapaciteti këtu.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Kjo strukturë përfaqëson një version të parakompiluar në mënyrë të sigurt të një vargu të formatit dhe argumenteve të tij.
/// Kjo nuk mund të gjenerohet gjatë kohës së ekzekutimit sepse nuk mund të bëhet në mënyrë të sigurt, kështu që nuk jepen asnjë ndërtues dhe fushat janë private për të parandaluar modifikimin.
///
///
/// Makro [`format_args!`] do të krijojë në mënyrë të sigurt një shembull të kësaj strukture.
/// Makroja vërteton vargun e formatit në kohën e përpilimit, në mënyrë që përdorimi i funksioneve [`write()`] dhe [`format()`] të mund të kryhet në mënyrë të sigurt.
///
/// Ju mund të përdorni `Arguments<'a>` që [`format_args!`] kthen në kontekste `Debug` dhe `Display` siç shihet më poshtë.
/// Shembulli gjithashtu tregon që formati `Debug` dhe `Display` për të njëjtën gjë: vargu i formatit të ndërfutur në `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Formatoni pjesët e vargut për t'u shtypur.
    pieces: &'a [&'static str],

    // Specifikimet e mbajtësve të vendit ose `None` nëse të gjitha specifikimet janë parazgjedhur (si në "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Argumente dinamike për interpolation, që do të ndërthuren me pjesë vargu.
    // (Çdo argument paraprihet nga një pjesë e vargut.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Merrni vargun e formatuar, nëse nuk ka argumente për tu formatuar.
    ///
    /// Kjo mund të përdoret për të shmangur alokimet në rastin më të parëndësishëm.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` duhet të formatojë rezultatin në një kontekst të drejtuar nga programuesi, për korrigjimin e gabimeve.
///
/// Në përgjithësi, duhet të zbatoni vetëm `derive` një `Debug`.
///
/// Kur përdoret me specifikuesin e formatit alternativ `#?`, rezultati është shtypur bukur.
///
/// Për më shumë informacion mbi formatuesit, shihni [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// Ky trait mund të përdoret me `#[derive]` nëse të gjitha fushat zbatojnë `Debug`.
/// Kur `nxirret`d për struktura, ai do të përdorë emrin e `struct`, pastaj `{`, pastaj një listë të ndarë me presje për emrin e secilës fushë dhe vlerën `Debug`, pastaj `}`.
/// Për `enum`, ai do të përdorë emrin e variantit dhe, nëse është e aplikueshme, `(`, pastaj vlerat `Debug` të fushave, pastaj `)`.
///
/// # Stability
///
/// Formatet `Debug` të nxjerra nuk janë të qëndrueshme, dhe kështu që mund të ndryshojnë me versionet future Rust.
/// Për më tepër, implementimet `Debug` të llojeve të siguruara nga biblioteka standarde (`libstd`, `libcore`, `liballoc`, etj.) Nuk janë të qëndrueshme, dhe gjithashtu mund të ndryshojnë me versionet future Rust.
///
///
/// # Examples
///
/// Nxjerrja e një zbatimi:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Zbatimi manual:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Ekzistojnë një numër metodash ndihmëse në strukturën [`Formatter`] për t'ju ndihmuar me implementime manuale, të tilla si [`debug_struct`].
///
/// `Debug` implementimet duke përdorur ose `derive` ose API-në e ndërtuesit të korrigjimeve në [`Formatter`] mbështesin printimin e bukur duke përdorur flamurin alternativ: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Printim i bukur me `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Formaton vlerën duke përdorur formatuesin e dhënë.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Modul i veçantë për të rieksportuar makro `Debug` nga prelude pa trait `Debug`.
pub(crate) mod macros {
    /// Nxjerr makro që gjeneron një impl të trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Formatoni trait për një format bosh, `{}`.
///
/// `Display` është i ngjashëm me [`Debug`], por `Display` është për daljen në përdorim dhe kështu nuk mund të nxirret.
///
///
/// Për më shumë informacion mbi formatuesit, shihni [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Zbatimi i `Display` në një lloj:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Formaton vlerën duke përdorur formatuesin e dhënë.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait duhet të formatojë prodhimin e tij si numër në base-8.
///
/// Për integruesit primitivë të nënshkruar (`i8` në `i128` dhe `isize`), vlerat negative formatohen si paraqitje plotësuese e të dyve.
///
///
/// Flamuri alternativ, `#`, shton një `0o` përpara daljes.
///
/// Për më shumë informacion mbi formatuesit, shihni [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Përdorimi bazë me `i32`:
///
/// ```
/// let x = 42; // 42 është '52' në oktal
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Zbatimi i `Octal` në një lloj:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // delegojnë në zbatimin e i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Formaton vlerën duke përdorur formatuesin e dhënë.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait duhet të formatojë prodhimin e tij si një numër në binar.
///
/// Për integruesit primitivë të nënshkruar ([`i8`] në [`i128`] dhe [`isize`]), vlerat negative formatohen si paraqitje plotësuese e të dyve.
///
///
/// Flamuri alternativ, `#`, shton një `0b` përpara daljes.
///
/// Për më shumë informacion mbi formatuesit, shihni [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Përdorimi bazë me [`i32`]:
///
/// ```
/// let x = 42; // 42 është '101010' në binar
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Zbatimi i `Binary` në një lloj:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // delegojnë në zbatimin e i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Formaton vlerën duke përdorur formatuesin e dhënë.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait duhet të formatojë prodhimin e tij si numër në heksadecimal, me `a` deri `f` me shkronja të vogla.
///
/// Për integruesit primitivë të nënshkruar (`i8` në `i128` dhe `isize`), vlerat negative formatohen si paraqitje plotësuese e të dyve.
///
///
/// Flamuri alternativ, `#`, shton një `0x` përpara daljes.
///
/// Për më shumë informacion mbi formatuesit, shihni [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Përdorimi bazë me `i32`:
///
/// ```
/// let x = 42; // 42 është '2a' në magji
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Zbatimi i `LowerHex` në një lloj:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // delegojnë në zbatimin e i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Formaton vlerën duke përdorur formatuesin e dhënë.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait duhet të formatojë prodhimin e tij si numër në heksadecimal, me `A` deri `F` me shkronja të mëdha.
///
/// Për integruesit primitivë të nënshkruar (`i8` në `i128` dhe `isize`), vlerat negative formatohen si paraqitje plotësuese e të dyve.
///
///
/// Flamuri alternativ, `#`, shton një `0x` përpara daljes.
///
/// Për më shumë informacion mbi formatuesit, shihni [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Përdorimi bazë me `i32`:
///
/// ```
/// let x = 42; // 42 është '2A' në magji
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Zbatimi i `UpperHex` në një lloj:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // delegojnë në zbatimin e i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Formaton vlerën duke përdorur formatuesin e dhënë.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait duhet të formatojë prodhimin e tij si një vendndodhje kujtese.
/// Kjo zakonisht paraqitet si heksadecimale.
///
/// Për më shumë informacion mbi formatuesit, shihni [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Përdorimi bazë me `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // kjo prodhon diçka si '0x7f06092ac6d0'
/// ```
///
/// Zbatimi i `Pointer` në një lloj:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // përdorni `as` për t'u kthyer në një `*const T`, i cili zbaton Pointer, të cilin mund ta përdorim
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Formaton vlerën duke përdorur formatuesin e dhënë.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait duhet të formatojë prodhimin e tij në shënime shkencore me një `e` të vogël.
///
/// Për më shumë informacion mbi formatuesit, shihni [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Përdorimi bazë me `f64`:
///
/// ```
/// let x = 42.0; // 42.0 është '4.2e1' në shënimet shkencore
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Zbatimi i `LowerExp` në një lloj:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // delegojnë në zbatimin e f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Formaton vlerën duke përdorur formatuesin e dhënë.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait duhet të formatojë prodhimin e tij në shënime shkencore me një `E` të vogël.
///
/// Për më shumë informacion mbi formatuesit, shihni [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Përdorimi bazë me `f64`:
///
/// ```
/// let x = 42.0; // 42.0 është '4.2E1' në shënimet shkencore
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Zbatimi i `UpperExp` në një lloj:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // delegojnë në zbatimin e f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Formaton vlerën duke përdorur formatuesin e dhënë.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// Funksioni `write` merr një rrjedhë dalëse dhe një strukturë `Arguments` që mund të parakompilohet me makro `format_args!`.
///
///
/// Argumentet do të formatohen sipas vargut të specifikuar të formatit në rrjedhën e dhënë të dhënë.
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Ju lutemi vini re se përdorimi i [`write!`] mund të jetë i preferueshëm.Shembull:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // Ne mund të përdorim parametrat e paracaktuar të formatimit për të gjitha argumentet.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Çdo specifikim ka një argument përkatës që paraprihet nga një pjesë e vargut.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // SIGURIA: arg dhe args.args vijnë nga të njëjtat argumente,
                // e cila garanton që indekset janë gjithmonë brenda kufijve.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Mund të mbetet vetëm një pjesë e vargut zvarritës.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // SIGURIA: argumentet dhe harqet vijnë nga të njëjtat argumente,
    // e cila garanton që indekset janë gjithmonë brenda kufijve.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Nxirrni argumentin e saktë
    debug_assert!(arg.position < args.len());
    // SIGURIA: argumentet dhe harqet vijnë nga të njëjtat argumente,
    // e cila garanton indeksin e saj është gjithmonë brenda kufijve.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Pastaj në fakt bëni disa shtypje
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // SIGURIA: cnt dhe harqet vijnë nga të njëjtat argumente,
            // i cili garanton që ky indeks është gjithmonë brenda kufijve.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// Mbushja pas përfundimit të diçkaje.Kthyer nga `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Shkruaj këtë mbushje postimi.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // Ne duam ta ndryshojmë këtë
            buf: wrap(self.buf),

            // Dhe ruaji këto
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Metodat ndihmëse të përdorura për mbushjen dhe përpunimin e argumenteve të formatimit që mund të përdorin të gjitha formatet traits.
    //

    /// Kryen mbushjen e saktë për një numër të plotë i cili tashmë është emetuar në një rr.
    /// Rrjedhja nuk duhet të përmbajë * shenjën për numrin e plotë, që do të shtohet me këtë metodë.
    ///
    /// # Arguments
    ///
    /// * nuk është negativ, nëse numri i plotë origjinal ishte pozitiv ose zero.
    /// * parashtesa, nëse jepet karakteri '#' (Alternate), kjo është parashtesa që vendoset përpara numrit.
    ///
    /// * buf, vargu bajt në të cilin është formatuar numri
    ///
    /// Ky funksion do të llogarisë saktë flamujt e dhënë, si dhe gjerësinë minimale.
    /// Nuk do të marrë parasysh saktësinë.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // Ne duhet të heqim "-" nga numri i daljes.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Shkruan shenjën nëse ekziston, dhe pastaj prefiksin nëse është kërkuar
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Fusha `width` është më shumë një parametër `min-width` në këtë pikë.
        match self.width {
            // Nëse nuk ka kërkesa minimale për gjatësi, atëherë ne thjesht mund të shkruajmë bajte.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Kontrolloni nëse jemi mbi gjerësinë minimale, nëse po, atëherë mund të shkruajmë edhe bajte.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Shenja dhe prefiksi shkojnë përpara mbushjes nëse karakteri i mbushjes është zero
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Përndryshe, shenja dhe prefiksi shkojnë pas mbushjes
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Ky funksion merr një fetë vargu dhe e emeton atë në bufferin e brendshëm pasi të ketë aplikuar flamujt përkatës të formatimit.
    /// Flamujt e njohur për vargjet gjenerike janë:
    ///
    /// * gjerësia, gjerësia minimale e asaj që duhet të emetojë
    /// * fill/align - çfarë të emetojë dhe ku ta emetojë nëse vargu i dhënë duhet të mbushet
    /// * saktësia, gjatësia maksimale për të lëshuar, vargu pritet nëse është më i gjatë se kjo gjatësi
    ///
    /// Veçanërisht ky funksion injoron parametrat `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Sigurohuni që të keni një rrugë të shpejtë përpara
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // Fusha `precision` mund të interpretohet si `max-width` për vargun që formatohet.
        //
        let s = if let Some(max) = self.precision {
            // Nëse vargu ynë është më i gjatë se saktësia, atëherë duhet të kemi shkurtim.
            // Sidoqoftë flamuj të tjerë si `fill`, `width` dhe `align` duhet të veprojnë si gjithmonë.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM këtu nuk mund të provojë se `..i` nuk do të panic `&s[..i]`, por ne e dimë që nuk mund të panic.
                // Përdorni `get` + `unwrap_or` për të shmangur `unsafe` dhe përndryshe mos lëshoni ndonjë kod të lidhur me panic këtu.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Fusha `width` është më shumë një parametër `min-width` në këtë pikë.
        match self.width {
            // Nëse jemi nën gjatësinë maksimale dhe nuk ka kërkesa minimale për gjatësinë, atëherë ne thjesht mund të lëshojmë vargun
            //
            None => self.buf.write_str(s),
            // Nëse jemi nën gjerësinë maksimale, kontrolloni nëse jemi mbi gjerësinë minimale, nëse është aq e lehtë sa thjesht emetimi i vargut.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Nëse jemi nën gjerësinë maksimale dhe minimale, atëherë plotësoni gjerësinë minimale me vargun e specifikuar + disa shtrirje.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Shkruani mbushjen paraprake dhe ktheni post-mbushjen e pashkruar.
    /// Telefonuesit janë përgjegjës për të siguruar që post-mbushja të shkruhet pasi gjëja që mbushet.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Merr pjesët e formatuara dhe zbaton mbushjen.
    /// Supozon se thirrësi tashmë i ka dhënë pjesët me saktësinë e kërkuar, në mënyrë që `self.precision` të mund të injorohet.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // për mbushjen zero të vetëdijshme për shenjën, ne e japim shenjën së pari dhe sillemi sikur të mos kishim asnjë shenjë që nga fillimi.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // një shenjë shkon gjithmonë e para
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // hiqni shenjën nga pjesët e formatuara
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // pjesët e mbetura kalojnë nëpër procesin e zakonshëm të mbushjes.
            let len = formatted.len();
            let ret = if width <= len {
                // pa mbushje
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // ky është rasti i zakonshëm dhe ne marrim një shkurtore
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // SIGURIA: Kjo përdoret për `flt2dec::Part::Num` dhe `flt2dec::Part::Copy`.
            // Safeshtë i sigurt për t'u përdorur për `flt2dec::Part::Num` pasi që çdo karikues `c` është midis `b'0'` dhe `b'9'`, që do të thotë që `s` është UTF-8 i vlefshëm.
            // Alsoshtë gjithashtu ndoshta e sigurt në praktikë të përdoret për `flt2dec::Part::Copy(buf)` pasi `buf` duhet të jetë ASCII e thjeshtë, por është e mundur që dikush të kalojë një vlerë të keqe për `buf` në `flt2dec::to_shortest_str` pasi që është një funksion publik.
            //
            // FIXME: Përcaktoni nëse kjo mund të rezultojë në UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 zero
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Shkruan disa të dhëna në bufferin themelor që përmbahet në këtë formatues.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Kjo është ekuivalente me:
    ///         // shkruaj! (formatues, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Shkruan disa informacione të formatuara në këtë rast.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Flamujt për formatimin
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Karakteri përdoret si 'fill' sa herë që ka shtrirje.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Ne vendosim përafrimin në të djathtë me ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Flamuri që tregon çfarë forme të shtrirjes është kërkuar.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Gjerësia e plotë e specifikuar sipas opsionit që duhet të jetë prodhimi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Nëse kemi marrë një gjerësi, ne e përdorim atë
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Përndryshe ne nuk bëjmë asgjë të veçantë
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Precizion i specifikuar opsionalisht për llojet numerike.
    /// Përndryshe, gjerësia maksimale për llojet e vargjeve.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Nëse kemi marrë një saktësi, ne e përdorim atë.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Përndryshe ne vendosim në 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Përcakton nëse flamuri `+` ishte specifikuar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Përcakton nëse flamuri `-` ishte specifikuar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Dëshironi një shenjë minus?Keni një!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Përcakton nëse flamuri `#` ishte specifikuar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Përcakton nëse flamuri `0` ishte specifikuar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // Ne injorojmë opsionet e formatuesit.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Vendosni se çfarë API publik duam për këto dy flamuj.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Krijon një ndërtues [`DebugStruct`] i projektuar për të ndihmuar në krijimin e implementimeve [`fmt::Debug`] për strukturat.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Krijon një ndërtues `DebugTuple` i dizajnuar për të ndihmuar në krijimin e implementimeve `fmt::Debug` për tufa.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Krijon një ndërtues `DebugList` i projektuar për të ndihmuar në krijimin e implementimeve `fmt::Debug` për strukturat e ngjashme me listën.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Krijon një ndërtues `DebugSet` i projektuar për të ndihmuar në krijimin e implementimeve `fmt::Debug` për strukturat e ngjashme.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Në këtë shembull më kompleks, ne përdorim [`format_args!`] dhe `.debug_set()` për të ndërtuar një listë të krahëve të ndeshjes:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Krijon një ndërtues `DebugMap` i projektuar për të ndihmuar në krijimin e implementimeve `fmt::Debug` për strukturat e ngjashme me hartën.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Zbatimet e formatimit thelbësor traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Nëse karrocat kanë nevojë të shpëtojnë, nxirrni prapambetje deri tani dhe shkruani, përndryshe anashkaloni
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Flamuri alternativ tashmë është trajtuar nga LowerHex si special-ai tregon nëse duhet të parashtesën me 0x.
        // Ne e përdorim atë për të punuar nëse zgjatet apo jo në zero, dhe pastaj vendosim pa kushte për të marrë prefiksin.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Zbatimi i Display/Debug për lloje të ndryshme thelbësore

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell është huazuar në mënyrë të paqëndrueshme kështu që këtu nuk mund ta shikojmë vlerën e tij.
                // Në vend të kësaj, tregoni një mbajtës vendesh.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Nëse keni pritur që testet të jenë këtu, shikoni në vend skedarin core/tests/fmt.rs, është shumë më lehtë sesa të krijoni të gjitha strukturat rt::Piece këtu.
//
// Ekzistojnë edhe teste në alokimin crate, për ata që kanë nevojë për alokime.