//! Libcore prelude
//!
//! Ky modul është menduar për përdoruesit e libcore që nuk lidhen me libstd gjithashtu.
//! Ky modul importohet si parazgjedhje kur `#![no_std]` përdoret në të njëjtën mënyrë si prelude e bibliotekës standarde.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Versioni 2015 i prelude thelbësore.
///
/// Shihni [module-level documentation](self) për më shumë.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Versioni 2018 i prelude thelbësore.
///
/// Shihni [module-level documentation](self) për më shumë.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Versioni 2021 i prelude thelbësore.
///
/// Shihni [module-level documentation](self) për më shumë.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Shtoni më shumë gjëra.
}