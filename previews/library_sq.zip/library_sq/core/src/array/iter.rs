//! Përcakton iteratorin në pronësi të `IntoIter` për vargje.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Një përsëritës me vlerë [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Kjo është grupi që po përsërisim.
    ///
    /// Elementet me indeksin `i` ku `alive.start <= i < alive.end` nuk janë dhënë akoma dhe janë shënime të vlefshme të vargut.
    /// Elementet me indekse `i < alive.start` ose `i >= alive.end` janë dhënë tashmë dhe nuk duhet të përdoren më!Ata elementë të vdekur madje mund të jenë në një gjendje krejt të pa inicializuar!
    ///
    ///
    /// Pra, invariancat janë:
    /// - `data[alive]` është gjallë (dmth. përmban elemente të vlefshme)
    /// - `data[..alive.start]` dhe `data[alive.end..]` kanë vdekur (dmth. elementet ishin lexuar tashmë dhe nuk duhet të preken më!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Elementet në `data` që nuk janë dhënë ende.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Krijon një iterator të ri mbi `array` të dhënë.
    ///
    /// *Shënim*: kjo metodë mund të zhvlerësohet në future, pas [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Lloji i `value` është `i32` këtu, në vend të `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SIGURIA: Transmute këtu është në të vërtetë e sigurt.Dokumentet e `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` është e garantuar që të ketë të njëjtën madhësi dhe shtrirje
        // > si `T`.
        //
        // Dokumentet madje tregojnë një transmute nga një varg `MaybeUninit<T>` në një grup `T`.
        //
        //
        // Me këtë, ky inicializim plotëson gjërat e pandryshueshme.

        // FIXME(LukasKalbertodt): në të vërtetë përdorni `mem::transmute` këtu, pasi të punojë me gjenerikët konst:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Deri atëherë, ne mund të përdorim `mem::transmute_copy` për të krijuar një kopje bitwise si një lloj tjetër, pastaj harrojmë `array` në mënyrë që të mos bjerë.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Kthen një fetë të pandryshueshme të të gjithë elementëve që nuk janë dhënë akoma.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SIGURIA: Ne e dimë që të gjithë elementët brenda `alive` janë iniciuar siç duhet.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Kthen një fetë të ndryshueshme të të gjithë elementëve që nuk janë dhënë akoma.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SIGURIA: Ne e dimë që të gjithë elementët brenda `alive` janë iniciuar siç duhet.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Merrni indeksin tjetër nga përpara.
        //
        // Rritja e `alive.start` me 1 mban të pandryshuarën në lidhje me `alive`.
        // Sidoqoftë, për shkak të këtij ndryshimi, për një kohë të shkurtër, zona e gjallë nuk është më `data[alive]`, por `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Lexoni elementin nga vargu.
            // SIGURIA: `idx` është një indeks në ish-rajonin "alive" të vendit
            // grupLeximi i këtij elementi do të thotë që `data[idx]` konsiderohet si i vdekur tani (dmth. Mos e prekni).
            // Ndërsa `idx` ishte fillimi i zonës së gjallë, zona e gjallë tani është përsëri `data[alive]`, duke rivendosur të gjitha invariancat.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Merrni indeksin tjetër nga mbrapa.
        //
        // Ulja e `alive.end` me 1 mban të pandryshuarën në lidhje me `alive`.
        // Sidoqoftë, për shkak të këtij ndryshimi, për një kohë të shkurtër, zona e gjallë nuk është më `data[alive]`, por `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Lexoni elementin nga vargu.
            // SIGURIA: `idx` është një indeks në ish-rajonin "alive" të vendit
            // grupLeximi i këtij elementi do të thotë që `data[idx]` konsiderohet si i vdekur tani (dmth. Mos e prekni).
            // Ndërsa `idx` ishte fundi i zonës së gjallë, zona e gjallë tani është përsëri `data[alive]`, duke rivendosur të gjitha invariancat.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SIGURIA: Kjo është e sigurt: `as_mut_slice` kthen pikërisht nën-fetë
        // të elementeve që nuk janë zhvendosur ende dhe që mbeten për t'u hedhur.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Kurrë nuk do të derdhet për shkak të pandryshueshëm `të gjallë. Fillo <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iteratori vërtet raporton gjatësinë e saktë.
// Numri i elementeve "alive" (që do të jepet akoma) është gjatësia e intervalit `alive`.
// Ky varg zvogëlohet në gjatësi ose në `next` ose `next_back`.
// Gjithmonë zvogëlohet me 1 në ato metoda, por vetëm nëse `Some(_)` kthehet.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Vini re, ne nuk kemi nevojë të përputhemi me saktësisht të njëjtën gamë të gjallë, kështu që ne thjesht mund të klonojmë në kompensimin 0, pavarësisht se ku është `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klononi të gjithë elementët e gjallë.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Shkruani një klon në grupin e ri, dhe pastaj azhurnoni gamën e tij të gjallë.
            // Nëse klonojmë panics, ne do të heqim saktë artikujt e mëparshëm.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Printo vetëm elementët që nuk janë dhënë akoma: nuk mund t'i qasemi më elementëve të dhënë.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}