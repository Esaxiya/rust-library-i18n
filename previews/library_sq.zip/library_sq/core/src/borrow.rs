//! Një modul për të punuar me të dhëna të huazuara.

#![stable(feature = "rust1", since = "1.0.0")]

/// Një trait për huazimin e të dhënave.
///
/// Në Rust, është e zakonshme të sigurohen përfaqësime të ndryshme të një lloji për raste të ndryshme përdorimi.
/// Për shembull, vendndodhja e ruajtjes dhe menaxhimi i një vlere mund të zgjidhen në mënyrë specifike si të përshtatshme për një përdorim të veçantë përmes llojeve të treguesit të tillë si [`Box<T>`] ose [`Rc<T>`].
/// Përtej këtyre mbështjellësve gjenerikë që mund të përdoren me çdo lloj lloji, disa lloje ofrojnë aspekte opcionale duke siguruar një funksionalitet potencialisht të kushtueshëm.
/// Një shembull për një lloj të tillë është [`String`] i cili shton aftësinë për të zgjatur një varg në [`str`] bazë.
/// Kjo kërkon mbajtjen e informacionit shtesë të panevojshëm për një varg të thjeshtë, të pandryshueshëm.
///
/// Këto lloje sigurojnë qasje në të dhënat themelore përmes referimeve në llojin e atyre të dhënave.Thuhet se janë 'huazuar si' ai lloj.
/// Për shembull, një [`Box<T>`] mund të huazohet si `T` ndërsa një [`String`] mund të huazohet si `str`.
///
/// Llojet shprehin se ato mund të huazohen si disa të tipit `T` duke zbatuar `Borrow<T>`, duke siguruar një referencë për një `T` në metodën [`borrow`] të trait.Një lloj është i lirë të huazohet si disa lloje të ndryshme.
/// Nëse dëshiron të huazojë në mënyrë të paqëndrueshme si tip-duke lejuar që të dhënat themelore të modifikohen, ajo mund të zbatojë gjithashtu [`BorrowMut<T>`].
///
/// Për më tepër, kur sigurohen zbatime për traits shtesë, duhet të merret parasysh nëse ato duhet të sillen identike me ato të llojit themelor si pasojë e veprimit si përfaqësim i atij lloji themelor.
/// Kodi gjenerik zakonisht përdor `Borrow<T>` kur mbështetet në sjelljen identike të këtyre implementimeve shtesë të trait.
/// Këto traits ka të ngjarë të shfaqen si trait bounds shtesë.
///
/// Në veçanti `Eq`, `Ord` dhe `Hash` duhet të jenë ekuivalente për vlerat e huazuara dhe ato në pronësi: `x.borrow() == y.borrow()` duhet të japë të njëjtin rezultat si `x == y`.
///
/// Nëse kodi gjenerik thjesht duhet të funksionojë për të gjitha llojet që mund të japin një referencë për llojin e lidhur `T`, shpesh është më mirë të përdoret [`AsRef<T>`] pasi më shumë lloje mund ta zbatojnë atë në mënyrë të sigurt.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Si një koleksion i të dhënave, [`HashMap<K, V>`] zotëron si çelësat ashtu edhe vlerat.Nëse të dhënat aktuale të çelësit janë të mbështjella me një lloj menaxhimi të një lloji, megjithatë, duhet të jetë akoma e mundur të kërkohet një vlerë duke përdorur një referencë për të dhënat e çelësit.
/// Për shembull, nëse çelësi është një varg, atëherë ka të ngjarë të ruhet me hartën e hashit si [`String`], ndërsa duhet të jetë e mundur të kërkohet duke përdorur një [`&str`][`str`].
/// Kështu, `insert` duhet të operojë në një `String` ndërsa `get` duhet të jetë në gjendje të përdorë një `&str`.
///
/// Pak thjeshtuar, pjesët përkatëse të `HashMap<K, V>` duken kështu:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // fushat e harruara
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// E gjithë harta e hashit është e përgjithshme mbi një tip kyç `K`.Për shkak se këto çelësa janë ruajtur me hartën e hashit, ky lloj duhet të zotërojë të dhënat e çelësit.
/// Kur futni një palë me vlerë çelësi, hartës i jepet një `K` e tillë dhe duhet të gjejë kovën e saktë të hashit dhe të kontrollojë nëse çelësi është tashmë i pranishëm bazuar në atë `K`.Prandaj kërkon `K: Hash + Eq`.
///
/// Kur kërkoni për një vlerë në hartë, sidoqoftë, duhet të siguroni një referencë për një `K` si çelësi për të kërkuar do të kërkonte që gjithmonë të krijoni një vlerë të tillë në pronësi.
/// Për çelësat e vargut, kjo do të thotë se duhet të krijohet një vlerë `String` vetëm për kërkimin e rasteve kur vetëm një `str` është i disponueshëm.
///
/// Në vend të kësaj, metoda `get` është e përgjithshme mbi llojin e të dhënave themelore themelore, të quajtur `Q` në nënshkrimin e metodës më sipër.Aty thuhet që `K` merr hua si `Q` duke kërkuar që `K: Borrow<Q>`.
/// Duke kërkuar gjithashtu `Q: Hash + Eq`, ajo sinjalizon kërkesën që `K` dhe `Q` të kenë implementime të `Hash` dhe `Eq` traits që prodhojnë rezultate identike.
///
/// Zbatimi i `get` mbështetet veçanërisht në implementime identike të `Hash` duke përcaktuar kovën e hashit të çelësit duke thirrur `Hash::hash` në vlerën `Q` edhe pse e vendosi çelësin bazuar në vlerën e hashit të llogaritur nga vlera `K`.
///
///
/// Si pasojë, harta e hashit prishet nëse një `K` që mbështjell një vlerë `Q` prodhon një hash të ndryshëm nga `Q`.Për shembull, imagjinoni se keni një lloj që mbështjell një varg por krahason shkronjat ASCII duke injoruar rastin e tyre:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Për shkak se dy vlera të barabarta duhet të prodhojnë të njëjtën vlerë hash, zbatimi i `Hash` duhet të injorojë edhe rastin ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// A mund ta zbatojë `CaseInsensitiveString` `Borrow<str>`?Sigurisht që mund të sigurojë një referencë në një fetë vargu përmes vargut të saj të zotëruar.
/// Por për shkak se implementimi i tij `Hash` ndryshon, ai sillet ndryshe nga `str` dhe për këtë arsye nuk duhet të zbatojë `Borrow<str>`.
/// Nëse dëshiron t'u lejojë të tjerëve qasje në `str` themelor, mund ta bëjë këtë përmes `AsRef<str>` i cili nuk mbart ndonjë kërkesë shtesë.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Huazon në mënyrë të pandryshueshme nga një vlerë në pronësi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Një trait për huazimin e të dhënave në mënyrë të paqëndrueshme.
///
/// Si një shoqërues i [`Borrow<T>`], ky trait lejon një lloj të marrë hua si një tip themelor duke siguruar një referencë të ndryshueshme.
/// Shihni [`Borrow<T>`] për më shumë informacion mbi huazimin si një lloj tjetër.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Huazon në mënyrë të pandryshueshme nga një vlerë në pronësi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}