//! Manipulimi i vargut.
//!
//! Për më shumë detaje, shihni modulin [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. jashtë caqeve
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. filloj <=mbaroj
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. kufiri i karakterit
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // gjeni karakterin
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` duhet të jetë më pak se kufiri len dhe një karakter
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Kthen gjatësinë e `self`.
    ///
    /// Kjo gjatësi është në bajte, jo [`char`] ose grafema.
    /// Me fjalë të tjera, mund të mos jetë ajo që një njeri e konsideron gjatësinë e telit.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // dashuroj f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Kthen `true` nëse `self` ka një gjatësi zero bajte.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Kontrollon që bajtja `indeks` është bajti i parë në një sekuencë të pikës së kodit UTF-8 ose në fund të vargut.
    ///
    ///
    /// Fillimi dhe mbarimi i vargut (kur `indeksi== self.len()`) konsiderohen të jenë kufij.
    ///
    /// Kthen `false` nëse `index` është më i madh se `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // fillimi i `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // bajti i dytë i `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // bajti i tretë i `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 dhe len janë gjithmonë në rregull.
        // Testoni për 0 në mënyrë të qartë në mënyrë që të mund të zgjedh kontrollin lehtë dhe të kalojë leximin e të dhënave të vargut për atë rast.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Kjo është pak magji e barazvlefshme me: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Shndërron një fetë vargu në një fetë bajtesh.
    /// Për ta kthyer sërish fetë bajtësh në një fetë vargu, përdorni funksionin [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SIGURIA: tingull konstant sepse shndërrojmë dy lloje me të njëjtën paraqitje
        unsafe { mem::transmute(self) }
    }

    /// Shndërron një fetë vargu të ndryshueshëm në një fetë bajte të ndryshueshme.
    ///
    /// # Safety
    ///
    /// Telefonuesi duhet të sigurojë që përmbajtja e fotos është e vlefshme UTF-8 para se të përfundojë huazimi dhe të përdoret `str` themelor.
    ///
    ///
    /// Përdorimi i një `str` përmbajtja e të cilit nuk është e vlefshme UTF-8 është sjellje e papërcaktuar.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SIGURIA: hedhja nga `&str` në `&[u8]` është e sigurt që nga `str`
        // ka të njëjtën paraqitje si `&[u8]` (vetëm libstd mund ta bëjë këtë garanci).
        // Deferencimi i treguesit është i sigurt pasi vjen nga një referencë e ndryshueshme e cila garantohet të jetë e vlefshme për shkrimet.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Konverton një fetë vargu në një tregues të papërpunuar.
    ///
    /// Ndërsa fetë vargu janë një copë bajtesh, treguesi i papërpunuar tregon për një [`u8`].
    /// Ky tregues do të tregojë në bajtin e parë të pjesës së vargut.
    ///
    /// Telefonuesi duhet të sigurojë që treguesi i kthyer nuk është shkruar asnjëherë.
    /// Nëse keni nevojë të mutoni përmbajtjen e pjesës së vargut, përdorni [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Konverton një fetë vargu të ndryshueshëm në një tregues të papërpunuar.
    ///
    /// Ndërsa fetë vargu janë një copë bajtesh, treguesi i papërpunuar tregon për një [`u8`].
    /// Ky tregues do të tregojë në bajtin e parë të pjesës së vargut.
    ///
    /// Responsibilityshtë përgjegjësia juaj të siguroheni që feta e vargut të modifikohet vetëm në një mënyrë që të mbetet e vlefshme UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Kthen një nënfushë të `str`.
    ///
    /// Kjo është alternativa jo-panik për indeksimin e `str`.
    /// Kthen [`None`] sa herë që operacioni ekuivalent i indeksimit do të panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indekset jo në kufijtë e sekuencës UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // jashtë caqeve
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Kthen një nënfushë të ndryshueshme të `str`.
    ///
    /// Kjo është alternativa jo-panik për indeksimin e `str`.
    /// Kthen [`None`] sa herë që operacioni ekuivalent i indeksimit do të panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // gjatësia e saktë
    /// assert!(v.get_mut(0..5).is_some());
    /// // jashtë caqeve
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Kthen një nënnjësi të pakontrolluar të `str`.
    ///
    /// Kjo është alternativa e pakontrolluar për indeksimin e `str`.
    ///
    /// # Safety
    ///
    /// Telefonuesit e këtij funksioni janë përgjegjës që këto parakushte të plotësohen:
    ///
    /// * Indeksi fillestar nuk duhet të kalojë indeksin përfundimtar;
    /// * Indekset duhet të jenë brenda kufijve të pjesës origjinale;
    /// * Indekset duhet të qëndrojnë në kufijtë e sekuencës UTF-8.
    ///
    /// Nëse dështon, feta e vargut të kthyer mund të referojë memorie të pavlefshme ose të shkelë invariancat e komunikuara nga lloji `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SIGURIA: thirrësi duhet të mbajë kontratën e sigurisë për `get_unchecked`;
        // feta është e referueshme, sepse `self` është një referencë e sigurt.
        // Treguesi i kthyer është i sigurt sepse impiantet e `SliceIndex` duhet të garantojnë që është.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Kthen një nënngarje të paqëndrueshme, të pakontrolluar të `str`.
    ///
    /// Kjo është alternativa e pakontrolluar për indeksimin e `str`.
    ///
    /// # Safety
    ///
    /// Telefonuesit e këtij funksioni janë përgjegjës që këto parakushte të plotësohen:
    ///
    /// * Indeksi fillestar nuk duhet të kalojë indeksin përfundimtar;
    /// * Indekset duhet të jenë brenda kufijve të pjesës origjinale;
    /// * Indekset duhet të qëndrojnë në kufijtë e sekuencës UTF-8.
    ///
    /// Nëse dështon, feta e vargut të kthyer mund të referojë memorie të pavlefshme ose të shkelë invariancat e komunikuara nga lloji `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SIGURIA: thirrësi duhet të mbajë kontratën e sigurisë për `get_unchecked_mut`;
        // feta është e referueshme, sepse `self` është një referencë e sigurt.
        // Treguesi i kthyer është i sigurt sepse impiantet e `SliceIndex` duhet të garantojnë që është.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Krijon një fetë vargu nga një fetë tjetër vargu, duke anashkaluar kontrollet e sigurisë.
    ///
    /// Kjo zakonisht nuk rekomandohet, përdorni me kujdes!Për një alternativë të sigurt shih [`str`] dhe [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Kjo fetë e re shkon nga `begin` në `end`, përfshirë `begin` por duke përjashtuar `end`.
    ///
    /// Për të marrë një fetë vargu të ndryshueshëm, shihni metodën [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Telefonuesit e këtij funksioni janë përgjegjës që tre parakushte të plotësohen:
    ///
    /// * `begin` nuk duhet të kalojë `end`.
    /// * `begin` dhe `end` duhet të jenë pozicione bajtësh në fetë vargu.
    /// * `begin` dhe `end` duhet të shtrihet në kufijtë e sekuencës UTF-8.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SIGURIA: thirrësi duhet të mbajë kontratën e sigurisë për `get_unchecked`;
        // feta është e referueshme, sepse `self` është një referencë e sigurt.
        // Treguesi i kthyer është i sigurt sepse impiantet e `SliceIndex` duhet të garantojnë që është.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Krijon një fetë vargu nga një fetë tjetër vargu, duke anashkaluar kontrollet e sigurisë.
    /// Kjo zakonisht nuk rekomandohet, përdorni me kujdes!Për një alternativë të sigurt shih [`str`] dhe [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Kjo fetë e re shkon nga `begin` në `end`, përfshirë `begin` por duke përjashtuar `end`.
    ///
    /// Për të marrë një fetë vargu të pandryshueshëm, shihni metodën [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Telefonuesit e këtij funksioni janë përgjegjës që tre parakushte të plotësohen:
    ///
    /// * `begin` nuk duhet të kalojë `end`.
    /// * `begin` dhe `end` duhet të jenë pozicione bajtësh në fetë vargu.
    /// * `begin` dhe `end` duhet të shtrihet në kufijtë e sekuencës UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SIGURIA: thirrësi duhet të mbajë kontratën e sigurisë për `get_unchecked_mut`;
        // feta është e referueshme, sepse `self` është një referencë e sigurt.
        // Treguesi i kthyer është i sigurt sepse impiantet e `SliceIndex` duhet të garantojnë që është.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Ndani një fetë vargu në dy në një indeks.
    ///
    /// Argumenti, `mid`, duhet të jetë një bajt i kompensuar nga fillimi i vargut.
    /// Duhet gjithashtu të jetë në kufirin e një pike kodi UTF-8.
    ///
    /// Të dy feta të kthyera shkojnë nga fillimi i feta vargu në `mid`, dhe nga `mid` deri në fund të fetë vargut.
    ///
    /// Për të marrë në vend feta vargu të ndryshueshëm, shihni metodën [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics nëse `mid` nuk është në kufirin e pikës së kodit UTF-8, ose nëse i kalon fundi i pikës së fundit të kodit të rreshtit të vargut.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary kontrollon që indeksi është në [0, .len()]
        if self.is_char_boundary(mid) {
            // SIGURIA: sapo keni kontrolluar që `mid` është në një kufi të kufizuar.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Ndani një fetë vargu të ndryshueshëm në dy në një indeks.
    ///
    /// Argumenti, `mid`, duhet të jetë një bajt i kompensuar nga fillimi i vargut.
    /// Duhet gjithashtu të jetë në kufirin e një pike kodi UTF-8.
    ///
    /// Të dy feta të kthyera shkojnë nga fillimi i feta vargu në `mid`, dhe nga `mid` deri në fund të fetë vargut.
    ///
    /// Për të marrë në vend feta të vargut të pandryshueshëm, shihni metodën [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics nëse `mid` nuk është në kufirin e pikës së kodit UTF-8, ose nëse i kalon fundi i pikës së fundit të kodit të rreshtit të vargut.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary kontrollon që indeksi është në [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SIGURIA: sapo keni kontrolluar që `mid` është në një kufi të kufizuar.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Kthen një iterator mbi [`char`] s e një fete vargu.
    ///
    /// Ndërsa një fetë vargu përbëhet nga UTF-8 e vlefshme, ne mund të përsërisim përmes një fete vargu nga [`char`].
    /// Kjo metodë kthen një përsëritës të tillë.
    ///
    /// Importantshtë e rëndësishme të mbani mend se [`char`] përfaqëson një vlerë shkallore Unicode dhe mund të mos përputhet me idenë tuaj se çfarë është 'character'.
    ///
    /// Përsëritja mbi grupe grafemash mund të jetë ajo që dëshironi në të vërtetë.
    /// Ky funksionalitet nuk sigurohet nga biblioteka standarde e Rust, në vend të kësaj kontrolloni crates.io.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Mos harroni, [`char`] s mund të mos përputhen me intuitën tuaj në lidhje me karakteret:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // jo 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Kthen një iterator mbi [`char`] s e një fete vargu dhe pozicionet e tyre.
    ///
    /// Ndërsa një fetë vargu përbëhet nga UTF-8 e vlefshme, ne mund të përsërisim përmes një fete vargu nga [`char`].
    /// Kjo metodë kthen një iterator të të dy këtyre [`char`] s, si dhe pozicionet e tyre të bajtit.
    ///
    /// Iteratori jep tupla.Pozicioni është i pari, [`char`] është i dyti.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Mos harroni, [`char`] s mund të mos përputhen me intuitën tuaj në lidhje me karakteret:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // jo (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // shënoni 3 këtu, karakteri i fundit zuri dy bajt
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Një iterator mbi bajtët e një fete vargu.
    ///
    /// Ndërsa një fetë vargu përbëhet nga një sekuencë bajtesh, ne mund të përsërisim përmes një fete vargu për bajt.
    /// Kjo metodë kthen një përsëritës të tillë.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Ndan një fetë vargu sipas hapësirës së bardhë.
    ///
    /// Iteratori i kthyer do të kthejë feta vargu që janë nën-feta të rreshtit origjinal të vargut, të ndara nga çdo sasi e hapësirës së bardhë.
    ///
    ///
    /// 'Whitespace' përcaktohet në përputhje me kushtet e Unicode Derived Core Property `White_Space`.
    /// Nëse dëshironi të ndaheni në hapësirën e bardhë ASCII, përdorni [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Të gjitha llojet e hapësirës së bardhë konsiderohen:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Ndan një fetë vargu nga hapësira e bardhë ASCII.
    ///
    /// Iteratori i kthyer do të kthejë feta vargu që janë nën-feta të rreshtit origjinal të vargut, të ndara nga çdo sasi e hapësirës së bardhë të ASCII.
    ///
    ///
    /// Në vend të kësaj, për të ndarë me Unicode `Whitespace`, përdorni [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Të gjitha llojet e hapësirës së bardhë të ASCII konsiderohen:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Një iterator mbi vijat e një vargu, si feta vargu.
    ///
    /// Linjat përfundojnë ose me një linjë të re (`\n`) ose me një kthim karroce me një furnizim linje (`\r\n`).
    ///
    /// Mbarimi i rreshtit përfundimtar është opsional.
    /// Një varg që përfundon me një fund të rreshtit përfundimtar do të kthejë të njëjtat rreshta si një varg ndryshe identik pa mbaruar rreshti përfundimtar.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Mbarimi i rreshtit përfundimtar nuk kërkohet:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Një iterator mbi vijat e një vargu.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Kthen një përsëritës të `u16` mbi vargun e koduar si UTF-16.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Kthen `true` nëse modeli i dhënë përputhet me një nën-fetë të kësaj fete vargu.
    ///
    /// Kthen `false` nëse nuk e bën.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Kthen `true` nëse modeli i dhënë përputhet me një parashtesë të kësaj fete vargu.
    ///
    /// Kthen `false` nëse nuk e bën.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Kthen `true` nëse modeli i dhënë përputhet me një prapashtesë të kësaj fete vargu.
    ///
    /// Kthen `false` nëse nuk e bën.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Kthen indeksin e bajteve të karakterit të parë të kësaj fete vargu që përputhet me modelin.
    ///
    /// Kthen [`None`] nëse modeli nuk përputhet.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modele të thjeshta:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Modele më komplekse duke përdorur stilin pa pika dhe mbylljet:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Mos gjetja e modelit:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Kthen indeksin e bajteve për karakterin e parë të ndeshjes më të duhur të modelit në këtë fetë vargu.
    ///
    /// Kthen [`None`] nëse modeli nuk përputhet.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modele të thjeshta:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Modele më komplekse me mbyllje:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Mos gjetja e modelit:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Një përsëritës mbi nënshtresat e kësaj fete vargu, të ndarë nga karaktere që përputhen me një model.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Sjellja e përsëritësit
    ///
    /// Iteratori i kthyer do të jetë një [`DoubleEndedIterator`] nëse modeli lejon një kërkim të kundërt dhe kërkimi forward/reverse jep të njëjtat elemente.
    /// Kjo është e vërtetë për, p.sh., [`char`], por jo për `&str`.
    ///
    /// Nëse modeli lejon një kërkim të kundërt, por rezultatet e tij mund të ndryshojnë nga një kërkim përpara, metoda [`rsplit`] mund të përdoret.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Modele të thjeshta:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Nëse modeli është një fetë e karaktereve, ndani secilën dukuri të ndonjërit prej personazheve:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Një model më kompleks, duke përdorur një mbyllje:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Nëse një varg përmban ndarës të shumtë ngjitës, do të përfundoni me vargje bosh në dalje:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Ndarësit ngjitës ndahen nga vargu bosh.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Ndarësit në fillim ose në fund të një vargu fqinjëzohen nga tela bosh.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Kur vargu i zbrazët përdoret si ndarës, ajo ndan çdo karakter në varg, së bashku me fillimin dhe fundin e vargut.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Ndarësit e afërt mund të çojnë në sjellje të habitshme kur hapësira e bardhë përdoret si ndarëse.Ky kod është i saktë:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Ju jep _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Përdorni [`split_whitespace`] për këtë sjellje.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Një përsëritës mbi nënshtresat e kësaj fete vargu, të ndarë nga karaktere që përputhen me një model.
    /// Ndryshimet nga iteratori i prodhuar nga `split` në atë që `split_inclusive` lë pjesën e përputhur si terminatorin e nënshtresës.
    ///
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Nëse elementi i fundit i vargut përputhet, ai element do të konsiderohet terminatori i nënshtresës paraardhëse.
    /// Kjo nënshtresë do të jetë artikulli i fundit i kthyer nga përsëritësi.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Një iterator mbi nënshtresat e rreshtit të dhënë të vargut, i ndarë nga karaktere që përputhen me një model dhe jepnin në rend të kundërt.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Sjellja e përsëritësit
    ///
    /// Iteratori i kthyer kërkon që modeli të mbështesë një kërkim të kundërt, dhe do të jetë një [`DoubleEndedIterator`] nëse një kërkim forward/reverse jep të njëjtat elemente.
    ///
    ///
    /// Për përsëritjen nga përpara, mund të përdoret metoda [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Modele të thjeshta:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Një model më kompleks, duke përdorur një mbyllje:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Një iterator mbi nënshtresat e rreshtit të dhënë të vargut, i ndarë nga karaktere që përputhen me një model.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ekuivalente me [`split`], përveç që nënshtresa fundore anashkalohet nëse është bosh.
    ///
    /// [`split`]: str::split
    ///
    /// Kjo metodë mund të përdoret për të dhënat e vargut që janë _terminated_, sesa _separated_ nga një model.
    ///
    /// # Sjellja e përsëritësit
    ///
    /// Iteratori i kthyer do të jetë një [`DoubleEndedIterator`] nëse modeli lejon një kërkim të kundërt dhe kërkimi forward/reverse jep të njëjtat elemente.
    /// Kjo është e vërtetë për, p.sh., [`char`], por jo për `&str`.
    ///
    /// Nëse modeli lejon një kërkim të kundërt, por rezultatet e tij mund të ndryshojnë nga një kërkim përpara, metoda [`rsplit_terminator`] mund të përdoret.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Një iterator mbi nënshtresat e `self`, të ndara me karaktere që përputhen me një model dhe jepnin në rend të kundërt.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ekuivalente me [`split`], përveç që nënshtresa fundore anashkalohet nëse është bosh.
    ///
    /// [`split`]: str::split
    ///
    /// Kjo metodë mund të përdoret për të dhënat e vargut që janë _terminated_, sesa _separated_ nga një model.
    ///
    /// # Sjellja e përsëritësit
    ///
    /// Iteratori i kthyer kërkon që modeli të mbështesë një kërkim të kundërt, dhe do të përfundojë dyfish nëse një kërkim forward/reverse jep të njëjtat elemente.
    ///
    ///
    /// Për përsëritjen nga përpara, mund të përdoret metoda [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Një iterator mbi nënshtresat e rreshtit të dhënë të vargut, i ndarë nga një model, i kufizuar në kthimin e më së shumti artikujve `n`.
    ///
    /// Nëse nënshtresat `n` kthehen, nënshtresa e fundit (nënshtresa `n`) do të përmbajë pjesën e mbetur të vargut.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Sjellja e përsëritësit
    ///
    /// Iteratori i kthyer nuk do të ketë fund të dyfishtë, sepse nuk është efikas për tu mbështetur.
    ///
    /// Nëse modeli lejon një kërkim të kundërt, mund të përdoret metoda [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Modele të thjeshta:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Një model më kompleks, duke përdorur një mbyllje:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Një përsëritës mbi nënshtresat e kësaj fete vargu, i ndarë nga një model, duke filluar nga fundi i vargut, kufizohet në kthimin e më së shumti artikujve `n`.
    ///
    ///
    /// Nëse nënshtresat `n` kthehen, nënshtresa e fundit (nënshtresa `n`) do të përmbajë pjesën e mbetur të vargut.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Sjellja e përsëritësit
    ///
    /// Iteratori i kthyer nuk do të ketë fund të dyfishtë, sepse nuk është efikas për tu mbështetur.
    ///
    /// Për ndarje nga përpara, mund të përdoret metoda [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Modele të thjeshta:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Një model më kompleks, duke përdorur një mbyllje:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Ndan vargun në shfaqjen e parë të përcaktuesit të specifikuar dhe kthen parashtesën para ndarësit dhe prapashtesën pas ndarësit.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Ndan vargun në ndodhjen e fundit të përcaktuesit të specifikuar dhe kthen parashtesën para ndarësit dhe prapashtesën pas ndarësit.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Një përsëritës mbi përputhjet e ndara të një modeli brenda rreshtit të dhënë të vargut.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Sjellja e përsëritësit
    ///
    /// Iteratori i kthyer do të jetë një [`DoubleEndedIterator`] nëse modeli lejon një kërkim të kundërt dhe kërkimi forward/reverse jep të njëjtat elemente.
    /// Kjo është e vërtetë për, p.sh., [`char`], por jo për `&str`.
    ///
    /// Nëse modeli lejon një kërkim të kundërt, por rezultatet e tij mund të ndryshojnë nga një kërkim përpara, metoda [`rmatches`] mund të përdoret.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Një përsëritës mbi përputhjet e ndara të një modeli brenda kësaj fete vargu, dha në rend të kundërt.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Sjellja e përsëritësit
    ///
    /// Iteratori i kthyer kërkon që modeli të mbështesë një kërkim të kundërt, dhe do të jetë një [`DoubleEndedIterator`] nëse një kërkim forward/reverse jep të njëjtat elemente.
    ///
    ///
    /// Për përsëritjen nga përpara, mund të përdoret metoda [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Një përsëritës mbi përputhjet e ndara të një modeli brenda kësaj fete vargu, si dhe indeksin në të cilin fillon ndeshja.
    ///
    /// Për ndeshjet e `pat` brenda `self` që mbivendosen, kthehen vetëm indekset që korrespondojnë me ndeshjen e parë.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Sjellja e përsëritësit
    ///
    /// Iteratori i kthyer do të jetë një [`DoubleEndedIterator`] nëse modeli lejon një kërkim të kundërt dhe kërkimi forward/reverse jep të njëjtat elemente.
    /// Kjo është e vërtetë për, p.sh., [`char`], por jo për `&str`.
    ///
    /// Nëse modeli lejon një kërkim të kundërt, por rezultatet e tij mund të ndryshojnë nga një kërkim përpara, metoda [`rmatch_indices`] mund të përdoret.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // vetëm `aba` i parë
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Një përsëritës mbi ndeshjet e ndara të një modeli brenda `self`, dha në rend të kundërt së bashku me indeksin e ndeshjes.
    ///
    /// Për ndeshjet e `pat` brenda `self` që mbivendosen, kthehen vetëm indekset që korrespondojnë me ndeshjen e fundit.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Sjellja e përsëritësit
    ///
    /// Iteratori i kthyer kërkon që modeli të mbështesë një kërkim të kundërt, dhe do të jetë një [`DoubleEndedIterator`] nëse një kërkim forward/reverse jep të njëjtat elemente.
    ///
    ///
    /// Për përsëritjen nga përpara, mund të përdoret metoda [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // vetëm `aba` e fundit
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Kthen një fetë vargu me hapësirën e bardhë drejtuese dhe zvarritëse të hequr.
    ///
    /// 'Whitespace' përcaktohet në përputhje me kushtet e Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Kthen një fetë vargu me hapësirën kryesore të hequr.
    ///
    /// 'Whitespace' përcaktohet në përputhje me kushtet e Unicode Derived Core Property `White_Space`.
    ///
    /// # Drejtimi i tekstit
    ///
    /// Një varg është një sekuencë bajtesh.
    /// `start` në këtë kontekst nënkupton pozicionin e parë të asaj vargu bajtesh;për një gjuhë nga e majta në të djathtë si anglishtja ose rusishtja, kjo do të jetë në anën e majtë dhe për gjuhët nga e djathta në të majtë si arabishtja ose hebraishtja, kjo do të jetë ana e djathtë.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Kthen një fetë vargu me hapësirën e bardhë zvarritëse të hequr.
    ///
    /// 'Whitespace' përcaktohet në përputhje me kushtet e Unicode Derived Core Property `White_Space`.
    ///
    /// # Drejtimi i tekstit
    ///
    /// Një varg është një sekuencë bajtesh.
    /// `end` në këtë kontekst nënkupton pozicionin e fundit të asaj vargu bajt;për një gjuhë nga e majta në të djathtë si anglishtja ose rusishtja, kjo do të jetë ana e djathtë dhe për gjuhët nga e djathta në të majtë si arabishtja ose hebraishtja, kjo do të jetë ana e majtë.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Kthen një fetë vargu me hapësirën kryesore të hequr.
    ///
    /// 'Whitespace' përcaktohet në përputhje me kushtet e Unicode Derived Core Property `White_Space`.
    ///
    /// # Drejtimi i tekstit
    ///
    /// Një varg është një sekuencë bajtesh.
    /// 'Left' në këtë kontekst nënkupton pozicionin e parë të asaj vargu bajtesh;për një gjuhë si arabishtja ose hebraishtja që janë 'djathtas majtas' sesa 'majtas djathtas', kjo do të jetë ana _right_, jo e majta.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Kthen një fetë vargu me hapësirën e bardhë zvarritëse të hequr.
    ///
    /// 'Whitespace' përcaktohet në përputhje me kushtet e Unicode Derived Core Property `White_Space`.
    ///
    /// # Drejtimi i tekstit
    ///
    /// Një varg është një sekuencë bajtesh.
    /// 'Right' në këtë kontekst nënkupton pozicionin e fundit të asaj vargu bajt;për një gjuhë si arabishtja ose hebraishtja që janë 'djathtas majtas' sesa 'majtas djathtas', kjo do të jetë ana _left_, jo e djathta.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Kthen një fetë vargu me të gjitha parashtesat dhe prapashtesat që përputhen me një model të hequr në mënyrë të përsëritur.
    ///
    /// [pattern] mund të jetë një [`char`], një copë ['char'] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Modele të thjeshta:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Një model më kompleks, duke përdorur një mbyllje:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Mos harroni ndeshjen më të hershme të njohur, korrigjojeni më poshtë nëse
            // ndeshja e fundit është ndryshe
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SIGURIA: `Searcher` dihet se kthen indekse të vlefshme.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Kthen një fetë vargu me të gjitha parashtesat që përputhen me një model të hequr në mënyrë të përsëritur.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Drejtimi i tekstit
    ///
    /// Një varg është një sekuencë bajtesh.
    /// `start` në këtë kontekst nënkupton pozicionin e parë të asaj vargu bajtesh;për një gjuhë nga e majta në të djathtë si anglishtja ose rusishtja, kjo do të jetë në anën e majtë dhe për gjuhët nga e djathta në të majtë si arabishtja ose hebraishtja, kjo do të jetë ana e djathtë.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SIGURIA: `Searcher` dihet se kthen indekse të vlefshme.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Kthen një fetë vargu me prefiksin e hequr.
    ///
    /// Nëse vargu fillon me modelin `prefix`, kthen nënshtresën pas parashtesës, të mbështjellë me `Some`.
    /// Ndryshe nga `trim_start_matches`, kjo metodë heq prefiksin saktësisht një herë.
    ///
    /// Nëse vargu nuk fillon me `prefix`, kthen `None`.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Kthen një fetë vargu me prapashtesën e hequr.
    ///
    /// Nëse vargu përfundon me modelin `suffix`, kthen nënshtresën para prapashtesës, të mbështjellë me `Some`.
    /// Ndryshe nga `trim_end_matches`, kjo metodë heq prapashtesën saktësisht një herë.
    ///
    /// Nëse vargu nuk mbaron me `suffix`, kthen `None`.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Kthen një fetë vargu me të gjitha prapashtesat që përputhen me një model të hequr në mënyrë të përsëritur.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Drejtimi i tekstit
    ///
    /// Një varg është një sekuencë bajtesh.
    /// `end` në këtë kontekst nënkupton pozicionin e fundit të asaj vargu bajt;për një gjuhë nga e majta në të djathtë si anglishtja ose rusishtja, kjo do të jetë ana e djathtë dhe për gjuhët nga e djathta në të majtë si arabishtja ose hebraishtja, kjo do të jetë ana e majtë.
    ///
    ///
    /// # Examples
    ///
    /// Modele të thjeshta:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Një model më kompleks, duke përdorur një mbyllje:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SIGURIA: `Searcher` dihet se kthen indekse të vlefshme.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Kthen një fetë vargu me të gjitha parashtesat që përputhen me një model të hequr në mënyrë të përsëritur.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Drejtimi i tekstit
    ///
    /// Një varg është një sekuencë bajtesh.
    /// 'Left' në këtë kontekst nënkupton pozicionin e parë të asaj vargu bajtesh;për një gjuhë si arabishtja ose hebraishtja që janë 'djathtas majtas' sesa 'majtas djathtas', kjo do të jetë ana _right_, jo e majta.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Kthen një fetë vargu me të gjitha prapashtesat që përputhen me një model të hequr në mënyrë të përsëritur.
    ///
    /// [pattern] mund të jetë një `&str`, [`char`], një pjesë e [`char`] s, ose një funksion ose mbyllje që përcakton nëse një karakter përputhet.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Drejtimi i tekstit
    ///
    /// Një varg është një sekuencë bajtesh.
    /// 'Right' në këtë kontekst nënkupton pozicionin e fundit të asaj vargu bajt;për një gjuhë si arabishtja ose hebraishtja që janë 'djathtas majtas' sesa 'majtas djathtas', kjo do të jetë ana _left_, jo e djathta.
    ///
    ///
    /// # Examples
    ///
    /// Modele të thjeshta:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Një model më kompleks, duke përdorur një mbyllje:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// E zbërthen këtë fetë vargu në një lloj tjetër.
    ///
    /// Për shkak se `parse` është kaq i përgjithshëm, mund të shkaktojë probleme me përfundimin e tipit.
    /// Si i tillë, `parse` është një nga të paktat herë që do të shihni sintaksën e njohur me dashuri si 'turbofish': `::<>`.
    ///
    /// Kjo ndihmon algoritmin e konkluzionit të kuptojë specifikisht se në cilin lloj jeni duke u munduar të analizoni.
    ///
    /// `parse` mund të analizojë në çdo lloj që zbaton [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Do të kthejë [`Err`] nëse nuk është e mundur të analizohet kjo fetë vargu në llojin e dëshiruar.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Përdorimi bazë
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Përdorni 'turbofish' në vend që të shënoni `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Dështimi i analizimit:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Kontrollon nëse të gjithë personazhet në këtë varg janë brenda intervalit ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Ne mund ta trajtojmë secilin bajt si karakter këtu: të gjithë personazhet multibyte fillojnë me një bajt që nuk është në intervalin ascii, kështu që do të ndalemi këtu tashmë.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Kontrollon që dy vargje janë një përputhje e pandjeshme e ASCII.
    ///
    /// Njësoj si `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, por pa alokuar dhe kopjuar përkohësit.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Shndërron këtë varg në ekuivalentin e saj të sipërm ASCII në vend.
    ///
    /// Shkronjat ASCII 'a' në 'z' janë të shënuara në 'A' në 'Z', por shkronjat jo ASCII janë të pandryshuara.
    ///
    /// Për të kthyer një vlerë të re me shkronja të mëdha pa modifikuar atë ekzistuese, përdorni [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SIGURIA: e sigurt sepse shndërrojmë dy lloje me të njëjtën paraqitje.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Shndërron këtë varg në ekuivalentin e saj të vogël ASCII në vend.
    ///
    /// Shkronjat ASCII 'A' në 'Z' janë të shënuara në 'a' në 'z', por shkronjat jo-ASCII janë të pandryshuara.
    ///
    /// Për të kthyer një vlerë të re të vogël, pa modifikuar atë ekzistuese, përdorni [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SIGURIA: e sigurt sepse shndërrojmë dy lloje me të njëjtën paraqitje.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Ktheni një përsëritës që i shpëton secilit karakter në `self` me [`char::escape_debug`].
    ///
    ///
    /// Note: do të shpëtohen vetëm kodet e zgjeruara të grafemave që fillojnë vargun.
    ///
    /// # Examples
    ///
    /// Si përsëritës:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Përdorimi i `println!` direkt:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Të dyja janë ekuivalente me:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Përdorimi i `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Ktheni një përsëritës që i shpëton secilit karakter në `self` me [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Si përsëritës:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Përdorimi i `println!` direkt:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Të dyja janë ekuivalente me:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Përdorimi i `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Ktheni një përsëritës që i shpëton secilit karakter në `self` me [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Si përsëritës:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Përdorimi i `println!` direkt:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Të dyja janë ekuivalente me:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Përdorimi i `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Krijon një str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Krijon një rr bosh të paqëndrueshëm
    #[inline]
    fn default() -> Self {
        // SIGURIA: Vargu bosh është i vlefshëm UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Një tip fn i emërtueshëm, i klonueshëm
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SIGURIA: jo e sigurt
        unsafe { from_utf8_unchecked(bytes) }
    };
}