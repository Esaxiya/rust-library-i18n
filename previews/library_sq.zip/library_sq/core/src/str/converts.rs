//! Mënyrat për të krijuar një `str` nga fetë bajtesh.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Shndërron një fetë bajtësh në një fetë vargu.
///
/// Një fetë vargu ([`&str`]) është bërë nga bajte ([`u8`]), dhe një fetë bajt ([`&[u8]`][byteslice]) është bërë nga bajte, kështu që ky funksion shndërrohet në mes të dyve.
/// Jo të gjitha fetë bajtët janë feta të vargut të vlefshëm, megjithatë: [`&str`] kërkon që të jetë e vlefshme UTF-8.
/// `from_utf8()` kontrollon për të siguruar që bajtet janë të vlefshme UTF-8, dhe pastaj bën konvertimin.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Nëse jeni të sigurt që feta e bajtit është e vlefshme UTF-8 dhe nuk doni të kryeni kontrollin e vlefshmërisë, ekziston një version i pasigurt i këtij funksioni, [`from_utf8_unchecked`], i cili ka të njëjtën sjellje, por kalon kontrollin.
///
///
/// Nëse keni nevojë për një `String` në vend të një `&str`, merrni parasysh [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Për shkak se mund të caktoni një pirg `[u8; N]` dhe mund të merrni një [`&[u8]`][byteslice] të tij, ky funksion është një mënyrë për të pasur një varg të caktuar në pirg.Ekziston një shembull i kësaj në seksionin e shembujve më poshtë.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Kthen `Err` nëse feta nuk është UTF-8 me një përshkrim pse feta e dhënë nuk është UTF-8.
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::str;
///
/// // disa bajte, në një vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Ne e dimë që këto bajte janë të vlefshme, prandaj thjesht përdorni `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bajte të pasakta:
///
/// ```
/// use std::str;
///
/// // disa bajt të pavlefshëm, në një vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Shihni dokumentet për [`Utf8Error`] për më shumë detaje mbi llojet e gabimeve që mund të kthehen.
///
/// Një "stack allocated string":
///
/// ```
/// use std::str;
///
/// // disa bajte, në një grup të caktuar për pirg
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Ne e dimë që këto bajte janë të vlefshme, prandaj thjesht përdorni `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SIGURIA: Vetëm vlefshmëria e ekzekutuar.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Shndërron një fetë të ndryshueshme bajtësh në një fetë vargu të ndryshueshëm.
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" si një vector i ndryshueshëm
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Siç e dimë që këto bajte janë të vlefshme, ne mund të përdorim `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bajte të pasakta:
///
/// ```
/// use std::str;
///
/// // Disa bajt të pavlefshëm në një vector të ndryshueshëm
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Shihni dokumentet për [`Utf8Error`] për më shumë detaje mbi llojet e gabimeve që mund të kthehen.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SIGURIA: Vetëm vlefshmëria e ekzekutuar.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Shndërron një fetë bajtësh në një fetë vargu pa kontrolluar që vargu përmban UTF-8 të vlefshëm.
///
/// Shihni versionin e sigurt, [`from_utf8`], për më shumë informacion.
///
/// # Safety
///
/// Ky funksion është i pasigurt sepse nuk kontrollon që bajtet e kaluara janë të vlefshme UTF-8.
/// Nëse ky kufizim shkelet, sjellja e papërcaktuar rezulton, pasi pjesa tjetër e Rust supozon se ["&str"] s janë të vlefshme UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::str;
///
/// // disa bajte, në një vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SIGURIA: thirrësi duhet të garantojë që bajtet `v` janë UTF-8 të vlefshme.
    // Gjithashtu mbështetet në `&str` dhe `&[u8]` që kanë të njëjtën paraqitje.
    unsafe { mem::transmute(v) }
}

/// Shndërron një fetë bajtësh në një fetë vargu pa kontrolluar që vargu përmban UTF-8 të vlefshëm;version i ndryshueshem.
///
///
/// Shihni versionin e pandryshueshëm, [`from_utf8_unchecked()`] për më shumë informacion.
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SIGURIA: thirrësi duhet të garantojë që bajtet `v`
    // janë të vlefshme UTF-8, kështu që hedhja në `*mut str` është e sigurt.
    // Gjithashtu, referenca e treguesit është e sigurt sepse ai tregues vjen nga një referencë e cila është e garantuar të jetë e vlefshme për shkrimet.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}