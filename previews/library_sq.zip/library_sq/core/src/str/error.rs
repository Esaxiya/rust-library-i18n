//! Përcakton llojin e gabimit utf8.

use crate::fmt;

/// Gabime të cilat mund të ndodhin kur përpiqeni të interpretoni një sekuencë të [`u8`] si një varg.
///
/// Si e tillë, familja e funksioneve dhe metodave `from_utf8` për të dy [`String`] s dhe [`&str`] përdorin këtë gabim, për shembull.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Metodat e këtij lloji gabimi mund të përdoren për të krijuar funksionalitet të ngjashëm me `String::from_utf8_lossy` pa alokuar memorje të grumbulluar:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Kthen indeksin në vargun e dhënë deri në të cilin është verifikuar UTF-8 i vlefshëm.
    ///
    /// Indexshtë indeksi maksimal i tillë që `from_utf8(&input[..index])` të kthejë `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::str;
    ///
    /// // disa bajt të pavlefshëm, në një vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 kthen një Gabim Utf8
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // bajti i dytë është i pavlefshëm këtu
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Jep më shumë informacion në lidhje me dështimin:
    ///
    /// * `None`: fundi i inputit u arrit papritur.
    ///   `self.valid_up_to()` është 1 deri në 3 bajt nga fundi i hyrjes.
    ///   Nëse një rrymë bajtesh (si p.sh. një skedar ose një fole rrjeti) po dekodohet në mënyrë graduale, kjo mund të jetë një `char` e vlefshme, sekuenca e bajtit UTF-8 e së cilës shtrihet në copa të shumta.
    ///
    ///
    /// * `Some(len)`: u has një bajt i papritur.
    ///   Gjatësia e dhënë është ajo e sekuencës së pavlefshme të bajtit që fillon nga indeksi i dhënë nga `valid_up_to()`.
    ///   Dekodimi duhet të rifillojë pas asaj sekuence (pas futjes së një [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) në rast të dekodimit me humbje.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Një gabim u kthye kur dështon analizimi i një `bool` duke përdorur [`from_str`]
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}