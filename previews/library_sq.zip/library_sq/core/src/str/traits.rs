//! Trait implementimet për `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Zbaton renditjen e vargjeve.
///
/// Vargjet renditen [lexicographically](Ord#lexicographical-comparison) nga vlerat e tyre të bajtit.
/// Kjo urdhëron pikat e kodit Unicode bazuar në pozicionet e tyre në tabelat e kodeve.
/// Kjo nuk është domosdoshmërisht e njëjtë me rendin "alphabetical", i cili ndryshon nga gjuha dhe vendndodhja.
/// Renditja e vargjeve sipas standardeve të pranuara nga ana kulturore kërkon të dhëna specifike për vendndodhjen që janë jashtë fushës së tipit `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Zbaton operacionet e krahasimit në vargje.
///
/// Vargjet krahasohen [lexicographically](Ord#lexicographical-comparison) nga vlerat e tyre të bajtit.
/// Kjo krahason pikat e kodit Unicode bazuar në pozicionet e tyre në tabelat e kodeve.
/// Kjo nuk është domosdoshmërisht e njëjtë me rendin "alphabetical", i cili ndryshon nga gjuha dhe vendndodhja.
/// Krahasimi i vargjeve sipas standardeve të pranuara nga ana kulturore kërkon të dhëna specifike për vendndodhjen që janë jashtë fushës së tipit `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Zbaton prerjen e nënshtresave me sintaksën `&self[..]` ose `&mut self[..]`.
///
/// Kthen një fetë të të gjithë vargut, pra, kthen `&self` ose `&mut self`.Ekuivalente me `&vetveten [0 ..
/// len] `ose`&mut veten [0 ..
/// len]`.
/// Ndryshe nga operacionet e tjera të indeksimit, kjo kurrë nuk mund të panic.
///
/// Ky operacion është *O*(1).
///
/// Para 1.20.0, këto operacione indeksimi ende mbështeteshin nga zbatimi i drejtpërdrejtë i `Index` dhe `IndexMut`.
///
/// Ekuivalente me `&self[0 .. len]` ose `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Zbaton prerjen e nënshtresave me sintaksën `&self[begin .. end]` ose `&mut self[begin .. end]`.
///
/// Kthen një fetë të vargut të dhënë nga diapazoni i bajteve [`start`, `end`).
///
/// Ky operacion është *O*(1).
///
/// Para 1.20.0, këto operacione indeksimi ende mbështeteshin nga zbatimi i drejtpërdrejtë i `Index` dhe `IndexMut`.
///
/// # Panics
///
/// Panics nëse `begin` ose `end` nuk tregon zhvendosjen e bajtëve fillestarë të një karakteri (siç përcaktohet nga `is_char_boundary`), nëse `begin > end`, ose nëse `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // këto do të panic:
/// // bajt 2 qëndron brenda `ö`:
/// // &s [2 ..3];
///
/// // bajti 8 qëndron brenda `老`&s [1 ..
/// // 8];
///
/// // bajt 100 është jashtë vargut&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIGURIA: sapo keni kontrolluar që `start` dhe `end` janë në kufijtë e ngarkesës,
            // dhe ne po kalojmë në një referencë të sigurt, kështu që vlera e kthimit do të jetë gjithashtu një.
            // Ne gjithashtu kontrolluam kufijtë e karakterit, kështu që kjo është e vlefshme UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIGURIA: sapo keni kontrolluar që `start` dhe `end` janë në kufijtë e ngarkesës.
            // Ne e dimë që treguesi është unik sepse e kemi marrë nga `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SIGURIA: telefonuesi garanton që `self` është në kufijtë e `slice`
        // i cili plotëson të gjitha kushtet për `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SIGURIA: shikoni komentet për `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary kontrollon që indeksi është në [0, .len()] nuk mund ta ripërdorë `get` si më sipër, për shkak të problemeve të NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIGURIA: sapo keni kontrolluar që `start` dhe `end` janë në kufijtë e ngarkesës,
            // dhe ne po kalojmë në një referencë të sigurt, kështu që vlera e kthimit do të jetë gjithashtu një.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Zbaton prerjen e nënshtresave me sintaksën `&self[.. end]` ose `&mut self[.. end]`.
///
/// Kthen një fetë të vargut të dhënë nga diapazoni i bajtit [`0`, `end`).
/// Ekuivalente me `&self[0 .. end]` ose `&mut self[0 .. end]`.
///
/// Ky operacion është *O*(1).
///
/// Para 1.20.0, këto operacione indeksimi ende mbështeteshin nga zbatimi i drejtpërdrejtë i `Index` dhe `IndexMut`.
///
/// # Panics
///
/// Panics nëse `end` nuk tregon fillimin e bajtëve të një karakteri (siç përcaktohet nga `is_char_boundary`), ose nëse `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SIGURIA: sapo keni kontrolluar që `end` është në një kufi të kufizuar,
            // dhe ne po kalojmë në një referencë të sigurt, kështu që vlera e kthimit do të jetë gjithashtu një.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SIGURIA: sapo keni kontrolluar që `end` është në një kufi të kufizuar,
            // dhe ne po kalojmë në një referencë të sigurt, kështu që vlera e kthimit do të jetë gjithashtu një.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SIGURIA: sapo keni kontrolluar që `end` është në një kufi të kufizuar,
            // dhe ne po kalojmë në një referencë të sigurt, kështu që vlera e kthimit do të jetë gjithashtu një.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Zbaton prerjen e nënshtresave me sintaksën `&self[begin ..]` ose `&mut self[begin ..]`.
///
/// Kthen një fetë të vargut të dhënë nga diapazoni i bajteve [`start`, `len`).Ekuivalente me `&vetveten [fillo ..
/// len] `ose`&mut veten [fillo ..
/// len]`.
///
/// Ky operacion është *O*(1).
///
/// Para 1.20.0, këto operacione indeksimi ende mbështeteshin nga zbatimi i drejtpërdrejtë i `Index` dhe `IndexMut`.
///
/// # Panics
///
/// Panics nëse `begin` nuk tregon fillimin e bajtëve të një karakteri (siç përcaktohet nga `is_char_boundary`), ose nëse `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SIGURIA: sapo keni kontrolluar që `start` është në një kufi të kufizuar,
            // dhe ne po kalojmë në një referencë të sigurt, kështu që vlera e kthimit do të jetë gjithashtu një.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SIGURIA: sapo keni kontrolluar që `start` është në një kufi të kufizuar,
            // dhe ne po kalojmë në një referencë të sigurt, kështu që vlera e kthimit do të jetë gjithashtu një.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SIGURIA: telefonuesi garanton që `self` është në kufijtë e `slice`
        // i cili plotëson të gjitha kushtet për `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SIGURIA: identike me `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SIGURIA: sapo keni kontrolluar që `start` është në një kufi të kufizuar,
            // dhe ne po kalojmë në një referencë të sigurt, kështu që vlera e kthimit do të jetë gjithashtu një.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Zbaton prerjen e nënshtresave me sintaksën `&self[begin ..= end]` ose `&mut self[begin ..= end]`.
///
/// Kthen një fetë të vargut të dhënë nga diapazoni i bajteve [`begin`, `end`].Ekuivalente me `&self [begin .. end + 1]` ose `&mut self[begin .. end + 1]`, përveç nëse `end` ka vlerën maksimale për `usize`.
///
/// Ky operacion është *O*(1).
///
/// # Panics
///
/// Panics nëse `begin` nuk tregon fillimin e bajtit të një karakteri (siç përcaktohet nga `is_char_boundary`), nëse `end` nuk tregon bajtin e mbarimit të një karakteri (`end + 1` është ose një bajt fillestar ose i barabartë me `len`), nëse `begin > end`, ose nëse `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Zbaton prerjen e nënshtresave me sintaksën `&self[..= end]` ose `&mut self[..= end]`.
///
/// Kthen një pjesë të vargut të dhënë nga diapazoni i bajteve [0, `end`].
/// Ekuivalente me `&self [0 .. end + 1]`, përveç nëse `end` ka vlerën maksimale për `usize`.
///
/// Ky operacion është *O*(1).
///
/// # Panics
///
/// Panics nëse `end` nuk tregon përfundimin e bajtit të kompensimit të një karakteri (`end + 1` është ose një zbritje bajtesh fillestare siç përcaktohet nga `is_char_boundary`, ose e barabartë me `len`), ose nëse `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SIGURIA: telefonuesi duhet të mbajë kontratën e sigurisë për `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analizoni një vlerë nga një varg
///
/// Metoda [`from_str`] e `FromStr` shpesh përdoret në mënyrë implicite, përmes metodës [`parse`] të [str]].
/// Shikoni dokumentacionin e ["parse"] për shembuj.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` nuk ka një parametër të jetës, dhe kështu ju mund të analizoni vetëm llojet që nuk përmbajnë vetë një parametër të jetës.
///
/// Me fjalë të tjera, ju mund të analizoni një `i32` me `FromStr`, por jo një `&i32`.
/// Mund të analizoni një strukturë që përmban një `i32`, por jo një që përmban një `&i32`.
///
/// # Examples
///
/// Zbatimi themelor i `FromStr` në një shembull të tipit `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Gabimi shoqërues i cili mund të kthehet nga analizimi.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analizon një varg `s` për të kthyer një vlerë të këtij lloji.
    ///
    /// Nëse analizimi ka sukses, ktheni vlerën brenda [`Ok`], përndryshe kur vargu është i formatuar keq, ktheni një gabim specifik për [`Err`] brenda.
    /// Lloji i gabimit është specifik për zbatimin e trait.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë me [`i32`], një lloj që zbaton `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analizoni një `bool` nga një varg.
    ///
    /// Jep një `Result<bool, ParseBoolError>`, sepse `s` mund ose nuk mund të analizohet në të vërtetë.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Vini re, në shumë raste, metoda `.parse()` në `str` është më e përshtatshme.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}