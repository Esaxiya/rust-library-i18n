use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Ndërsa ky funksion përdoret në një vend dhe zbatimi i tij mund të nënvizohet, përpjekjet e mëparshme për ta bërë këtë e bënë rustc më të ngadaltë:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Renditja e një blloku të kujtesës.
///
/// Një shembull i `Layout` përshkruan një plan urbanistik të veçantë të kujtesës.
/// Ju ndërtoni një `Layout` up si një input për t'i dhënë një shpërndarësi.
///
/// Të gjitha paraqitjet kanë një madhësi të lidhur dhe një renditje të fuqisë së dyve.
///
/// (Vini re që paraqitjet nuk kërkohen * që të kenë madhësi jo zero, edhe pse `GlobalAlloc` kërkon që të gjitha kërkesat e kujtesës të mos jenë me madhësi jo zero.
/// Një telefonues duhet të sigurojë që kushtet e tilla janë përmbushur, të përdorë shpërndarës specifik me kërkesa më të lira, ose të përdorë ndërfaqen më të butë `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // madhësia e bllokut të kërkuar të kujtesës, e matur në bajte.
    size_: usize,

    // rreshtimi i bllokut të kërkuar të kujtesës, i matur në bajte.
    // ne sigurojmë që kjo të jetë gjithmonë një fuqi e të dyve, sepse API-të si `posix_memalign` e kërkojnë atë dhe është një kufizim i arsyeshëm për t'u imponuar konstruktorëve të Layout.
    //
    //
    // (Sidoqoftë, ne nuk kërkojmë në mënyrë analoge `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Ndërton një `Layout` nga një `size` dhe `align` të dhënë, ose kthen `LayoutError` nëse ndonjë nga kushtet e mëposhtme nuk plotësohet:
    ///
    /// * `align` nuk duhet të jetë zero,
    ///
    /// * `align` duhet të jetë një fuqi e dy,
    ///
    /// * `size`, kur rrumbullakoset në shumëfishin më të afërt të `align`, nuk duhet të tejmbushë (dmth., vlera e rrumbullakosur duhet të jetë më e vogël ose e barabartë me `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (fuqia e të dyve nënkupton rreshtimin!=0.)

        // Madhësia e rrumbullakosur është:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Ne e dimë nga lart se përafrimi!=0.
        // Nëse shtimi (përafrimi, 1) nuk tejmbush, atëherë rrumbullakimi do të jetë mirë.
        //
        // Anasjelltas,&-maskimi me! (Rresht, 1) do të heqë vetëm bitët e rendit të ulët.
        // Kështu nëse ndodh mbingarkesa me shumën,&-maska nuk mund të zbritet aq sa të zhbëhet ajo mbingarkesë.
        //
        //
        // Më sipër nënkupton që kontrolli për mbingarkesë përmbledhëse është i domosdoshëm dhe i mjaftueshëm.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SIGURIA: kushtet për `from_size_align_unchecked` kanë qenë
        // kontrolluar me siper.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Krijon një paraqitje, duke anashkaluar të gjitha kontrollet.
    ///
    /// # Safety
    ///
    /// Ky funksion është i pasigurt pasi nuk verifikon parakushtet nga [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SIGURIA: thirrësi duhet të sigurojë që `align` është më i madh se zero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Madhësia minimale në bajt për një bllok memorje të kësaj paraqitjeje.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Renditja minimale e bajteve për një bllok memorie të kësaj paraqitjeje.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Ndërton një `Layout` të përshtatshëm për mbajtjen e një vlere të tipit `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SIGURIA: përafrimi garantohet nga Rust të jetë një fuqi e dy dhe
        // madhësia + bashkimi i bashkuar është i garantuar që të përshtatet në hapësirën tonë të adresave.
        // Si rezultat, përdorni konstruktorin e pakontrolluar këtu për të shmangur futjen e kodit që panics nëse nuk është optimizuar mjaft mirë.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Prodhon një paraqitje që përshkruan një rekord që mund të përdoret për të caktuar strukturën mbështetëse për `T` (e cila mund të jetë një trait ose një lloj tjetër i pa madhësisë si një fetë).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SIGURIA: shikoni arsyetimin në `new` pse po përdor këtë variant të pasigurt
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Prodhon një paraqitje që përshkruan një rekord që mund të përdoret për të caktuar strukturën mbështetëse për `T` (e cila mund të jetë një trait ose një lloj tjetër i pa madhësisë si një fetë).
    ///
    /// # Safety
    ///
    /// Ky funksion është i sigurt për tu thirrur vetëm nëse ekzistojnë kushtet e mëposhtme:
    ///
    /// - Nëse `T` është `Sized`, ky funksion është gjithmonë i sigurt për t'u thirrur.
    /// - Nëse bishti pa madhësi i `T` është:
    ///     - një [slice], atëherë gjatësia e bishtit të feta duhet të jetë një numër i plotë i intializuar, dhe madhësia e vlerës së plotë * (gjatësia dinamike e bishtit + prefiksi me madhësi statike) duhet të përshtatet në `isize`.
    ///     - një [trait object], atëherë pjesa vtable e treguesit duhet të tregojë në një tryezë të vlefshme për llojin `T` të fituar nga një koerzion pa madhësi, dhe madhësia e *vlerës së plotë*(gjatësia dinamike e bishtit + parashtesa me madhësi statike) duhet të përshtatet në `isize`.
    ///
    ///     - një (unstable) [extern type], atëherë ky funksion është gjithmonë i sigurt për t`u thirrur, por mund që panic ose përndryshe të kthejë vlerën e gabuar, pasi paraqitja e llojit të jashtëm nuk dihet.
    ///     Kjo është e njëjta sjellje si [`Layout::for_value`] në lidhje me një bisht të tipit të jashtëm.
    ///     - përndryshe, në mënyrë konservative nuk lejohet të thirret ky funksion.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SIGURIA: ne i kalojmë parakushtet e këtyre funksioneve telefonuesit
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SIGURIA: shikoni arsyetimin në `new` pse po përdor këtë variant të pasigurt
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Krijon një `NonNull` që është i varur, por i rreshtuar mirë për këtë Paraqitje.
    ///
    /// Vini re se vlera e treguesit potencialisht mund të përfaqësojë një tregues të vlefshëm, që do të thotë se kjo nuk duhet të përdoret si një vlerë roje "not yet initialized".
    /// Llojet që caktojnë me përtesë duhet të ndjekin inicializimin me disa mjete të tjera.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SIGURIA: rreshtimi është i garantuar të mos jetë zero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Krijon një paraqitje që përshkruan rekordin që mund të mbajë një vlerë të paraqitjes së njëjtë si `self`, por që gjithashtu është në linjë me shtrirjen `align` (matur në bajt).
    ///
    ///
    /// Nëse `self` tashmë përmbush rreshtimin e përshkruar, atëherë kthen `self`.
    ///
    /// Vini re se kjo metodë nuk shton asnjë mbushje në madhësinë e përgjithshme, pavarësisht nëse paraqitja e kthyer ka një shtrirje tjetër.
    /// Me fjalë të tjera, nëse `K` ka madhësinë 16, `K.align_to(32)`*akoma* do të ketë madhësinë 16.
    ///
    /// Kthen një gabim nëse kombinimi i `self.size()` dhe `align` i dhënë shkel kushtet e renditura në [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Kthen sasinë e mbushjes që duhet të fusim pas `self` për të siguruar që adresa e mëposhtme do të kënaqë `align` (matur në bajt).
    ///
    /// p.sh., nëse `self.size()` është 9, atëherë `self.padding_needed_for(4)` kthen 3, sepse ky është numri minimal i bajtave të mbushjes që kërkohen për të marrë një adresë me 4 rreshta (duke supozuar që blloku përkatës i kujtesës fillon në një adresë me 4 rreshta).
    ///
    ///
    /// Vlera e kthimit të këtij funksioni nuk ka kuptim nëse `align` nuk është fuqi-e-dy.
    ///
    /// Vini re se dobia e vlerës së kthyer kërkon që `align` të jetë më e vogël ose e barabartë me rreshtimin e adresës fillestare për të gjithë bllokun e caktuar të kujtesës.Një mënyrë për të përmbushur këtë kufizim është sigurimi i `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Vlera e rrumbullakosur është:
        //   len_rounded_up=(len + rresht, 1)&! (rresht, 1);
        // dhe pastaj e kthejmë ndryshimin e mbushjes: `len_rounded_up - len`.
        //
        // Ne përdorim aritmetikë modulare përgjatë:
        //
        // 1. rreshtimi është i garantuar të jetë> 0, kështu që rreshtimi, 1 është gjithmonë i vlefshëm.
        //
        // 2.
        // `len + align - 1` mund të tejkalojë më së shumti `align - 1`, kështu që&-maska me `!(align - 1)` do të sigurojë që në rastin e mbingarkesës, `len_rounded_up` në vetvete do të jetë 0.
        //
        //    Kështu mbushja e kthyer, kur shtohet në `len`, jep 0, e cila në mënyrë të parëndësishme plotëson rreshtimin `align`.
        //
        // (Sigurisht, përpjekjet për të caktuar blloqe memorie madhësia dhe mbushja e të cilave tejkalojnë në mënyrën e mësipërme duhet të bëjnë që alokuesi të japë një gabim gjithsesi.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Krijon një paraqitje duke rrumbullakuar madhësinë e kësaj paraqitjeje deri në një shumëfish të shtrirjes së faqosjes.
    ///
    ///
    /// Kjo është ekuivalente me shtimin e rezultatit të `padding_needed_for` në madhësinë aktuale të faqosjes.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Kjo nuk mund të vërshojë.Duke cituar nga e pandryshueshmja e Layout:
        // > `size`, kur rrumbullakoset në shumëfishin më të afërt të `align`,
        // > nuk duhet të mbingarkohet (dmth., vlera e rrumbullakosur duhet të jetë më e vogël se
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Krijon një plan urbanistik që përshkruan rekordin për shembujt `n` të `self`, me një sasi të përshtatshme mbushje midis secilës për të siguruar që secilës instancë t'i jepet madhësia dhe shtrirja e kërkuar.
    /// Me sukses, kthimet `(k, offs)` ku `k` është paraqitja e grupit dhe `offs` është distanca midis fillimit të secilit element në grup.
    ///
    /// Në mbingarkesën aritmetike, kthen `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Kjo nuk mund të vërshojë.Duke cituar nga e pandryshueshmja e Layout:
        // > `size`, kur rrumbullakoset në shumëfishin më të afërt të `align`,
        // > nuk duhet të mbingarkohet (dmth., vlera e rrumbullakosur duhet të jetë më e vogël se
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SIGURIA: self.align tashmë dihet se është e vlefshme dhe madhësia e shpërndarësit ka qenë
        // mbushur tashmë.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Krijon një plan urbanistik që përshkruan rekordin për `self` të ndjekur nga `next`, duke përfshirë çdo mbushje të nevojshme për të siguruar që `next` do të rreshtohet siç duhet, por *pa mbushje prapa*.
    ///
    /// Në mënyrë që të përputhen me paraqitjen e përfaqësimit C `repr(C)`, duhet të telefononi `pad_to_align` pasi të keni shtrirë paraqitjen me të gjitha fushat.
    /// (Nuk ka asnjë mënyrë që të përputhet me paraqitjen e parazgjedhur të përfaqësimit Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Vini re se përafrimi i paraqitjes që rezulton do të jetë maksimumi i atyre të `self` dhe `next`, në mënyrë që të sigurojë përafrimin e të dy pjesëve.
    ///
    /// Kthen `Ok((k, offset))`, ku `k` është paraqitja e rekordit të bashkuar dhe `offset` është vendndodhja relative, në bajte, e fillimit të `next` të ngulitur brenda rekordit të bashkuar (duke supozuar që rekordi vetë fillon në kompensimin 0).
    ///
    ///
    /// Në mbingarkesën aritmetike, kthen `LayoutError`.
    ///
    /// # Examples
    ///
    /// Për të llogaritur paraqitjen e një strukture `#[repr(C)]` dhe kompensimet e fushave nga paraqitjet e fushave të saj:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Mos harroni të finalizoni me `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // provoni që funksionon
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Krijon një plan urbanistik që përshkruan rekordin për rastet `n` të `self`, pa mbushje midis secilës shembull.
    ///
    /// Vini re se, ndryshe nga `repeat`, `repeat_packed` nuk garanton që instancat e përsëritura të `self` do të rreshtohen siç duhet, edhe nëse një shembull i dhënë i `self` është i rreshtuar siç duhet.
    /// Me fjalë të tjera, nëse faqosja e kthyer nga `repeat_packed` përdoret për caktimin e një grupi, nuk është e garantuar që të gjithë elementët në grup do të rreshtohen siç duhet.
    ///
    /// Në mbingarkesën aritmetike, kthen `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Krijon një plan urbanistik që përshkruan rekordin për `self` të ndjekur nga `next` pa asnjë mbushje shtesë midis të dyve.
    /// Meqenëse nuk është futur asnjë mbushje, rreshtimi i `next` është i parëndësishëm dhe nuk është i përfshirë *fare* në paraqitjen që rezulton.
    ///
    ///
    /// Në mbingarkesën aritmetike, kthen `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Krijon një plan urbanistik që përshkruan rekordin për një `[T; n]`.
    ///
    /// Në mbingarkesën aritmetike, kthen `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parametrat e dhënë `Layout::from_size_align` ose ndonjë konstruktor tjetër `Layout` nuk i përmbushin kufizimet e tij të dokumentuara.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (kjo na duhet për ndikimin në rrjedhën e poshtme të gabimit trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}