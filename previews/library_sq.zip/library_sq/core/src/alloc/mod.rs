//! API-të e ndarjes së kujtesës

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Gabimi `AllocError` tregon një dështim të alokimit që mund të jetë për shkak të shterimit të burimeve ose për diçka të gabuar kur kombinoni argumentet e dhëna të dhëna me këtë shpërndarës.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (kjo na duhet për ndikimin në rrjedhën e poshtme të gabimit trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Një zbatim i `Allocator` mund të caktojë, rritet, tkurret dhe të shpërndajë blloqe arbitrare të të dhënave të përshkruara përmes [`Layout`][].
///
/// `Allocator` është krijuar për tu implementuar në ZST, referenca ose tregues të zgjuar sepse të kesh një shpërndarës si `MyAlloc([u8; N])` nuk mund të zhvendoset, pa azhurnuar treguesit në memorjen e caktuar.
///
/// Ndryshe nga [`GlobalAlloc`][], alokimet me madhësi zero lejohen në `Allocator`.
/// Nëse një alokues themelor nuk e mbështet këtë (si jemalloc) ose nuk kthen një tregues nul (siç është `libc::malloc`), kjo duhet të kapet nga implementimi.
///
/// ### Kujtesa e ndarë aktualisht
///
/// Disa nga metodat kërkojnë që një bllok memorie të ndahet *aktualisht* përmes një alokuesi.Kjo do të thotë se:
///
/// * adresa fillestare për atë bllok kujtese është kthyer më parë nga [`allocate`], [`grow`] ose [`shrink`], dhe
///
/// * blloku i kujtesës nuk është zhvendosur më pas, ku blloqet ose zhvendosen drejtpërdrejt duke kaluar në [`deallocate`] ose janë ndryshuar duke kaluar në [`grow`] ose [`shrink`] që kthen `Ok`.
///
/// Nëse `grow` ose `shrink` kanë kthyer `Err`, treguesi i kaluar mbetet i vlefshëm.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Montimi i kujtesës
///
/// Disa nga metodat kërkojnë që një paraqitje *të përshtatet* në një bllok kujtese.
/// Ajo që do të thotë për një paraqitje në "fit" një bllok memorie do të thotë (ose ekuivalente, për një bllok memorie në "fit" një plan urbanistik) është se duhet të mbajnë kushtet e mëposhtme:
///
/// * Blloku duhet të caktohet me të njëjtën rreshtim si [`layout.align()`], dhe
///
/// * [`layout.size()`] i dhënë duhet të bjerë në intervalin `min ..= max`, ku:
///   - `min` është madhësia e faqosjes së përdorur së fundmi për caktimin e bllokut, dhe
///   - `max` është madhësia aktuale e fundit e kthyer nga [`allocate`], [`grow`] ose [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Blloqet e kujtesës të kthyera nga një alokues duhet të drejtojnë në memorjen e vlefshme dhe të ruajnë vlefshmërinë e tyre derisa instanca dhe të gjithë klonet e saj të bien,
///
/// * klonimi ose lëvizja e shpërndarësit nuk duhet të zhvlerësojë blloqet e kujtesës të kthyera nga ky alokues.Një shpërndarës i klonuar duhet të sillet si i njëjti alokues, dhe
///
/// * çdo tregues në një bllok memorie i cili është [*currently allocated*] mund të kalojë në ndonjë metodë tjetër të alokuesit.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Përpjekjet për të caktuar një bllok të kujtesës.
    ///
    /// Me sukses, kthen një takim [`NonNull<[u8]>`][NonNull] me madhësinë dhe garancitë e shtrirjes së `layout`.
    ///
    /// Blloku i kthyer mund të ketë një madhësi më të madhe se sa specifikohet nga `layout.size()`, dhe mund të ketë ose jo përmbajtjen e tij të iniciuar.
    ///
    /// # Errors
    ///
    /// Kthimi i `Err` tregon që kujtesa është ezauruar ose `layout` nuk i plotëson madhësitë e alokuesit ose kufizimet e shtrirjes.
    ///
    /// Zbatimet inkurajohen të rikthejnë `Err` në rraskapitjen e kujtesës sesa në panik ose abort, por kjo nuk është një kërkesë e rreptë.
    /// (Në mënyrë të veçantë: është *e ligjshme* të zbatosh këtë trait në majë të një biblioteke themelore të shpërndarjes vendase që ndërpret lodhjen e kujtesës.)
    ///
    /// Klientët që dëshirojnë të ndërpresin llogaritjen në përgjigje të një gabimi të alokimit inkurajohen të thërrasin funksionin [`handle_alloc_error`], në vend që të kërkojnë direkt `panic!` ose të ngjashëm.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Sjell si `allocate`, por gjithashtu siguron që kujtesa e kthyer të iniciohet zero.
    ///
    /// # Errors
    ///
    /// Kthimi i `Err` tregon që kujtesa është ezauruar ose `layout` nuk i plotëson madhësitë e alokuesit ose kufizimet e shtrirjes.
    ///
    /// Zbatimet inkurajohen të rikthejnë `Err` në rraskapitjen e kujtesës sesa në panik ose abort, por kjo nuk është një kërkesë e rreptë.
    /// (Në mënyrë të veçantë: është *e ligjshme* të zbatosh këtë trait në majë të një biblioteke themelore të shpërndarjes vendase që ndërpret lodhjen e kujtesës.)
    ///
    /// Klientët që dëshirojnë të ndërpresin llogaritjen në përgjigje të një gabimi të alokimit inkurajohen të thërrasin funksionin [`handle_alloc_error`], në vend që të kërkojnë direkt `panic!` ose të ngjashëm.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SIGURIA: `alloc` kthen një bllok memorie të vlefshëm
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Zhvendos kujtesën e referuar nga `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` duhet të shënojë një bllok të kujtesës [*currently allocated*] përmes këtij alokuesi, dhe
    /// * `layout` duhet [*fit*] ai bllok i kujtesës.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Përpjekjet për të zgjatur bllokun e kujtesës.
    ///
    /// Kthen një [`NonNull<[u8]>`][NonNull] të ri që përmban një tregues dhe madhësinë aktuale të kujtesës së caktuar.Treguesi është i përshtatshëm për mbajtjen e të dhënave të përshkruara nga `new_layout`.
    /// Për ta arritur këtë, alokuesi mund të zgjasë shpërndarjen referuar nga `ptr` për t'iu përshtatur paraqitjes së re.
    ///
    /// Nëse kjo kthen `Ok`, atëherë pronësia e bllokut të kujtesës referuar nga `ptr` është transferuar te ky alokues.
    /// Kujtesa mund të jetë liruar ose jo, dhe duhet të konsiderohet e papërdorshme nëse nuk transferohet përsëri tek thirrësi përmes vlerës së kthimit të kësaj metode.
    ///
    /// Nëse kjo metodë kthen `Err`, atëherë pronësia e bllokut të kujtesës nuk është transferuar te ky alokues dhe përmbajtja e bllokut të kujtesës është e pandryshuar.
    ///
    /// # Safety
    ///
    /// * `ptr` duhet të shënojë një bllok të kujtesës [*currently allocated*] përmes këtij alokuesi.
    /// * `old_layout` duhet [*fit*] ai bllok i kujtesës (argumenti `new_layout` nuk ka pse të përshtatet.)
    /// * `new_layout.size()` duhet të jetë më e madhe ose e barabartë me `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Kthen `Err` nëse paraqitja e re nuk plotëson madhësinë e alokuesit dhe kufizimet e rreshtimit të alokuesit, ose nëse rritja ndryshe dështon.
    ///
    /// Zbatimet inkurajohen të rikthejnë `Err` në rraskapitjen e kujtesës sesa në panik ose abort, por kjo nuk është një kërkesë e rreptë.
    /// (Në mënyrë të veçantë: është *e ligjshme* të zbatosh këtë trait në majë të një biblioteke themelore të shpërndarjes vendase që ndërpret lodhjen e kujtesës.)
    ///
    /// Klientët që dëshirojnë të ndërpresin llogaritjen në përgjigje të një gabimi të alokimit inkurajohen të thërrasin funksionin [`handle_alloc_error`], në vend që të kërkojnë direkt `panic!` ose të ngjashëm.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SIGURIA: sepse `new_layout.size()` duhet të jetë më e madhe ose e barabartë me
        // `old_layout.size()`, alokimi i kujtesës së vjetër dhe i ri janë të vlefshëm për lexime dhe shkrime për bajtë `old_layout.size()`.
        // Gjithashtu, për shkak se ndarja e vjetër nuk ishte shpërndarë ende, ajo nuk mund të mbivendoset `new_ptr`.
        // Kështu, thirrja për në `copy_nonoverlapping` është e sigurt.
        // Kontrata e sigurisë për `dealloc` duhet të mbahet nga thirrësi.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Sjell si `grow`, por gjithashtu siguron që përmbajtja e re të vendoset në zero para se të kthehet.
    ///
    /// Blloku i kujtesës do të përmbajë përmbajtjen e mëposhtme pas një thirrje të suksesshme për të
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` ruhen nga alokimi origjinal.
    ///   * Bytes `old_layout.size()..old_size` ose do të ruhen ose do të zerohen, në varësi të zbatimit të alokuesit.
    ///   `old_size` i referohet madhësisë së bllokut të kujtesës para thirrjes `grow_zeroed`, e cila mund të jetë më e madhe se madhësia që u kërkua fillimisht kur u alokua.
    ///   * Bajtet `old_size..new_size` zerohen.`new_size` i referohet madhësisë së bllokut të kujtesës të kthyer nga thirrja `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` duhet të shënojë një bllok të kujtesës [*currently allocated*] përmes këtij alokuesi.
    /// * `old_layout` duhet [*fit*] ai bllok i kujtesës (argumenti `new_layout` nuk ka pse të përshtatet.)
    /// * `new_layout.size()` duhet të jetë më e madhe ose e barabartë me `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Kthen `Err` nëse paraqitja e re nuk plotëson madhësinë e alokuesit dhe kufizimet e rreshtimit të alokuesit, ose nëse rritja ndryshe dështon.
    ///
    /// Zbatimet inkurajohen të rikthejnë `Err` në rraskapitjen e kujtesës sesa në panik ose abort, por kjo nuk është një kërkesë e rreptë.
    /// (Në mënyrë të veçantë: është *e ligjshme* të zbatosh këtë trait në majë të një biblioteke themelore të shpërndarjes vendase që ndërpret lodhjen e kujtesës.)
    ///
    /// Klientët që dëshirojnë të ndërpresin llogaritjen në përgjigje të një gabimi të alokimit inkurajohen të thërrasin funksionin [`handle_alloc_error`], në vend që të kërkojnë direkt `panic!` ose të ngjashëm.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SIGURIA: sepse `new_layout.size()` duhet të jetë më e madhe ose e barabartë me
        // `old_layout.size()`, alokimi i kujtesës së vjetër dhe i ri janë të vlefshëm për lexime dhe shkrime për bajtë `old_layout.size()`.
        // Gjithashtu, për shkak se ndarja e vjetër nuk ishte shpërndarë ende, ajo nuk mund të mbivendoset `new_ptr`.
        // Kështu, thirrja për në `copy_nonoverlapping` është e sigurt.
        // Kontrata e sigurisë për `dealloc` duhet të mbahet nga thirrësi.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Përpjekjet për të zvogëluar bllokun e kujtesës.
    ///
    /// Kthen një [`NonNull<[u8]>`][NonNull] të ri që përmban një tregues dhe madhësinë aktuale të kujtesës së caktuar.Treguesi është i përshtatshëm për mbajtjen e të dhënave të përshkruara nga `new_layout`.
    /// Për ta arritur këtë, alokuesi mund të zvogëlojë alokimin e referuar nga `ptr` për t'iu përshtatur paraqitjes së re.
    ///
    /// Nëse kjo kthen `Ok`, atëherë pronësia e bllokut të kujtesës referuar nga `ptr` është transferuar te ky alokues.
    /// Kujtesa mund të jetë liruar ose jo, dhe duhet të konsiderohet e papërdorshme nëse nuk transferohet përsëri tek thirrësi përmes vlerës së kthimit të kësaj metode.
    ///
    /// Nëse kjo metodë kthen `Err`, atëherë pronësia e bllokut të kujtesës nuk është transferuar te ky alokues dhe përmbajtja e bllokut të kujtesës është e pandryshuar.
    ///
    /// # Safety
    ///
    /// * `ptr` duhet të shënojë një bllok të kujtesës [*currently allocated*] përmes këtij alokuesi.
    /// * `old_layout` duhet [*fit*] ai bllok i kujtesës (argumenti `new_layout` nuk ka pse të përshtatet.)
    /// * `new_layout.size()` duhet të jetë më i vogël ose i barabartë me `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Kthen `Err` nëse paraqitja e re nuk plotëson madhësinë e alokuesit dhe kufizimet e rreshtimit të alokuesit, ose nëse tkurrja ndryshe dështon.
    ///
    /// Zbatimet inkurajohen të rikthejnë `Err` në rraskapitjen e kujtesës sesa në panik ose abort, por kjo nuk është një kërkesë e rreptë.
    /// (Në mënyrë të veçantë: është *e ligjshme* të zbatosh këtë trait në majë të një biblioteke themelore të shpërndarjes vendase që ndërpret lodhjen e kujtesës.)
    ///
    /// Klientët që dëshirojnë të ndërpresin llogaritjen në përgjigje të një gabimi të alokimit inkurajohen të thërrasin funksionin [`handle_alloc_error`], në vend që të kërkojnë direkt `panic!` ose të ngjashëm.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SIGURIA: sepse `new_layout.size()` duhet të jetë më e ulët ose e barabartë me
        // `old_layout.size()`, alokimi i kujtesës së vjetër dhe i ri janë të vlefshëm për lexime dhe shkrime për bajtë `new_layout.size()`.
        // Gjithashtu, për shkak se ndarja e vjetër nuk ishte shpërndarë ende, ajo nuk mund të mbivendoset `new_ptr`.
        // Kështu, thirrja për në `copy_nonoverlapping` është e sigurt.
        // Kontrata e sigurisë për `dealloc` duhet të mbahet nga thirrësi.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Krijon një përshtatës "by reference" për këtë shembull të `Allocator`.
    ///
    /// Përshtatësi i kthyer gjithashtu zbaton `Allocator` dhe thjesht do ta huazojë këtë.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SIGURIA: kontrata e sigurisë duhet të mbahet nga thirrësi
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURIA: kontrata e sigurisë duhet të mbahet nga thirrësi
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURIA: kontrata e sigurisë duhet të mbahet nga thirrësi
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURIA: kontrata e sigurisë duhet të mbahet nga thirrësi
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}