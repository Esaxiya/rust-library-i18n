//! Llojet që vendosin të dhëna në vendndodhjen e tyre në memorje.
//!
//! Ndonjëherë është e dobishme të kesh objekte që garantohen të mos lëvizin, në kuptimin që vendosja e tyre në kujtesë nuk ndryshon, dhe kështu mund të mbështetet.
//! Një shembull kryesor i një skenari të tillë do të ishte ndërtimi i goditjeve vetë-referuese, pasi lëvizja e një objekti me tregues në vetvete do t'i zhvlerësojë ato, gjë që mund të shkaktojë sjellje të papërcaktuar.
//!
//! Në një nivel të lartë, një [`Pin<P>`] siguron që bashkuesi i çdo lloji treguesi `P` të ketë një vendndodhje të qëndrueshme në memorje, që do të thotë se nuk mund të zhvendoset diku tjetër dhe kujtesa e tij nuk mund të zhvendoset derisa të bjerë.Ne themi se pointee është "pinned".Gjërat bëhen më delikate kur diskutohen llojet që kombinohen të dhëna të ngulura me të dhëna jo të fiksuara;[see below](#projections-and-structural-pinning) për më shumë detaje.
//!
//! Si parazgjedhje, të gjitha llojet në Rust janë të lëvizshme.
//! Rust lejon kalimin e të gjitha llojeve nënvlera, dhe llojet e zakonshëm të treguesve inteligjentë siç janë [`Box<T>`] dhe `&mut T` lejojnë zëvendësimin dhe lëvizjen e vlerave që ato përmbajnë: mund të lëvizni nga një [`Box<T>`] ose mund të përdorni [`mem::swap`].
//! [`Pin<P>`] mbështjell një tregues të tipit `P`, kështu që ["Pin"] "<" ["Kutia"] "<T>>`funksionon shumë si një rregullt
//!
//! [`Box<T>`]: when një [`Pin`]"<"["Kutia"]"<T>>`bie, po ashtu edhe përmbajtja e saj, dhe kujtesa bie
//!
//! i shpërndarë.Në mënyrë të ngjashme, [`Pin`]"<&mut T>"i ngjan shumë `&mut T`.Sidoqoftë, [`Pin<P>`] nuk i lejon klientët të marrin në të vërtetë një [`Box<T>`] ose `&mut T` në të dhëna të fiksuara, gjë që nënkupton që ju nuk mund të përdorni operacione të tilla si [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` ka nevojë për `&mut T`, por nuk mund ta marrim.
//!     // Ne jemi bllokuar, nuk mund të ndërrojmë përmbajtjen e këtyre referencave.
//!     // Ne mund të përdorim `Pin::get_unchecked_mut`, por kjo është e pasigurt për një arsye:
//!     // nuk na lejohet ta përdorim atë për lëvizjen e gjërave nga `Pin`.
//! }
//! ```
//!
//! Vlen të përsëritet që [`Pin<P>`]*nuk* ndryshon faktin që një përpilues Rust i konsideron të gjitha llojet të lëvizshme.[`mem::swap`] mbetet e thirrshme për çdo `T`.Në vend të kësaj, [`Pin<P>`] parandalon që disa vlera * (të treguara nga treguesit e mbështjellë me [`Pin<P>`]) të lëvizen duke e bërë të pamundur thirrjen e metodave që kërkojnë `&mut T` mbi to (si [`mem::swap`]).
//!
//! [`Pin<P>`] mund të përdoret për të mbështjellë çdo tregues të tipit `P`, dhe si i tillë ai ndërvepron me [`Deref`] dhe [`DerefMut`].Një [`Pin<P>`] ku `P: Deref` duhet të konsiderohet si "`P`-style pointer" në një `P::Target` të fiksuar-pra, një ["Pin"] "<" ["Kutia"] "<T>>"është një tregues në pronësi të një `T` të fiksuar dhe një ["Pin"]"<"["Rc"]"<T>>"është një tregues i numëruar si referencë për një `T` të fiksuar.
//! Për korrektësi, [`Pin<P>`] mbështetet në implementimet e [`Deref`] dhe [`DerefMut`] për të mos lëvizur nga parametri i tyre `self`, dhe vetëm për të kthyer një tregues në të dhënat e fiksuara kur ato thirren në një tregues të fiksuar.
//!
//! # `Unpin`
//!
//! Shumë lloje janë gjithmonë të lëvizshme lirshëm, edhe kur janë të fiksuar, sepse nuk mbështeten në të paturit e një adrese të qëndrueshme.Kjo përfshin të gjitha llojet themelore (si [`bool`], [`i32`] dhe referencat) si dhe llojet që përbëhen vetëm nga këto lloje.Llojet që nuk kujdesen për afishimin zbatojnë [`Unpin`] auto-trait, e cila anulon efektin e [`Pin<P>`].
//! Për `T: Unpin`, ["Pin"] "<" ["Kutia"] "<T>>"dhe [`Box<T>`] funksionojnë në mënyrë identike, ashtu si ["Pin"]"<&mut T>"dhe `&mut T`.
//!
//! Vini re se fiksimi dhe [`Unpin`] ndikojnë vetëm në tipin drejtues `P::Target`, jo në vetë treguesin tip `P` që u mbështoll në [`Pin<P>`].Për shembull, nëse [`Box<T>`] është [`Unpin`] apo jo, nuk ka asnjë efekt në sjelljen e ["Pin"] "<" ["Kutia"] "<T>> (këtu `T` është tip i drejtuar nga goja).
//!
//! # Shembull: strukturë vetë-referuese
//!
//! Para se të hyjmë në më shumë detaje për të shpjeguar garancitë dhe zgjedhjet e lidhura me `Pin<T>`, ne diskutojmë disa shembuj se si mund të përdoret.
//! Ndjehuni të lirë në [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Ky është një strukturë e vetë-referencës sepse fusha e pjesëve tregon për fushën e të dhënave.
//! // Ne nuk mund ta informojmë përpiluesin për këtë me një referencë normale, pasi ky model nuk mund të përshkruhet me rregullat e zakonshme të huazimit.
//! //
//! // Në vend të kësaj ne përdorim një tregues të papërpunuar, megjithëse dihet që nuk është nul, pasi e dimë që tregon në varg.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Për të siguruar që të dhënat nuk lëvizin kur funksioni kthehet, ne i vendosim ato në grumbull ku do të qëndrojë për tërë jetën e objektit, dhe mënyra e vetme për t'i hyrë do të ishte përmes një treguesi tek ai.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // ne vetëm krijojmë treguesin kur të dhënat janë në vend, përndryshe ai do të ketë lëvizur tashmë para se të fillojmë
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // ne e dimë që kjo është e sigurt sepse modifikimi i një fushe nuk lëviz të gjithë strukturën
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Treguesi duhet të tregojë në vendin e duhur, për sa kohë që struktura nuk ka lëvizur.
//! //
//! // Ndërkohë, ne jemi të lirë të lëvizim treguesin përreth.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Meqenëse lloji ynë nuk zbaton Zhgozhdo, kjo nuk do të përpilojë:
//! // le mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Shembull: listë ndërhyrëse e lidhur dyfish
//!
//! Në një listë ndërhyrëse të lidhur dyfish, koleksioni nuk shpërndan në të vërtetë kujtesën për vetë elementet.
//! Alokimi kontrollohet nga klientët dhe elementët mund të jetojnë në një kornizë pirgu që jeton më pak sesa koleksioni.
//!
//! Për ta bërë këtë punë, çdo element ka tregues të paraardhësit dhe pasardhësit të tij në listë.Elementet mund të shtohen vetëm kur janë të fiksuar, sepse lëvizja e elementeve përreth do të zhvleftësonte treguesit.Për më tepër, zbatimi [`Drop`] i një elementi të listës së lidhur do të rregullojë treguesit e paraardhësit dhe pasardhësit të tij për të hequr veten nga lista.
//!
//! Ç'është më e rëndësishmja, ne duhet të jemi në gjendje të mbështetemi në thirrjen [`drop`].Nëse një element mund të zhvendoset ose zhvlerësohet ndryshe pa thirrur [`drop`], treguesit në të nga elementët fqinjë do të bëheshin të pavlefshëm, gjë që do të prishte strukturën e të dhënave.
//!
//! Prandaj, fiksimi gjithashtu vjen me një garanci të lidhur me ["rënien"].
//!
//! # `Drop` guarantee
//!
//! Qëllimi i fiksimit është të jesh në gjendje të mbështetesh në vendosjen e disa të dhënave në memorje.
//! Për ta bërë këtë punë, jo vetëm lëvizja e të dhënave është e kufizuar;kufizohet gjithashtu edhe zhvendosja, ripozicionimi ose ndryshe zhvlerësimi i kujtesës së përdorur për të ruajtur të dhënat.
//! Konkretisht, për të dhënat e mbërthyera ju duhet të mbani të pandryshueshme që *kujtesa e saj nuk do të zhvlerësohet ose rivendoset nga momenti kur ngulitet deri kur të thirret [`drop`]*.Vetëm sa të kthehet [`drop`] ose panics, kujtesa mund të ripërdoret.
//!
//! Kujtesa mund të jetë "invalidated" me shpërndarje, por gjithashtu duke zëvendësuar një [`Some(v)`] me [`None`], ose duke thirrur [`Vec::set_len`] në "kill" disa elementë jashtë një vector.Mund të rivendoset duke përdorur [`ptr::write`] për ta mbishkruar atë pa thirrur më parë destruktorin.Asnjë nga këto nuk lejohet për të dhëna të fiksuara pa thirrur [`drop`].
//!
//! Ky është saktësisht lloji i garancisë që lista ndërhyrëse e ndërlidhur nga seksioni i mëparshëm ka nevojë të funksionojë si duhet.
//!
//! Vini re se kjo garanci nuk do të thotë *se kujtesa nuk rrjedh!Stillshtë akoma plotësisht në rregull që të mos telefononi kurrë [`drop`] në një element të fiksuar (p.sh., përsëri mund të telefononi [`mem::forget`] në një ["Pin"] "<" ["Kutia"] "<T>>").Në shembullin e listës së lidhur dyfish, ai element thjesht do të qëndronte në listë.Sidoqoftë ju nuk mund ta lironi ose ripërdorni hapësirën ruajtëse* pa thirrur [`rënie`] *.
//!
//! # `Drop` implementation
//!
//! Nëse lloji juaj përdor fiksim (siç janë dy shembujt e mësipërm), duhet të keni kujdes kur zbatoni [`Drop`].Funksioni [`drop`] merr `&mut self`, por kjo quhet *edhe nëse lloji juaj ishte i fiksuar më parë*!Duket sikur përpiluesi automatikisht quhet [`Pin::get_unchecked_mut`].
//!
//! Kjo nuk mund të shkaktojë kurrë një problem në kodin e sigurt sepse zbatimi i një lloji që mbështetet në afishimin kërkon kod të pasigurt, por kini kujdes që të vendosni të përdorni pinning në llojin tuaj (për shembull duke zbatuar disa operacione në ["Pin"] "<&Self>"ose ["Pin"]"<&mut Vetë>") ka pasoja edhe për zbatimin tuaj [`Drop`]: nëse një element i llojit tuaj mund të ishte ngulur, ju duhet ta trajtoni [`Drop`] si në mënyrë implicite duke marrë ["Pin"]"<&mut Vetë>".
//!
//!
//! Për shembull, ju mund të implementoni `Drop` si më poshtë:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` është në rregull sepse e dimë që kjo vlerë nuk përdoret më kurrë pasi të bie.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Kodi aktual i rënies shkon këtu.
//!         }
//!     }
//! }
//! ```
//!
//! Funksioni `inner_drop` ka llojin që duhet të ketë [`drop`] *, kështu që kjo sigurohet që ju të mos përdorni aksidentalisht `self`/`this` në një mënyrë që bie ndesh me fiksimin.
//!
//! Për më tepër, nëse lloji juaj është `#[repr(packed)]`, përpiluesi automatikisht do të lëvizë fushat për t'i rënë.Mund ta bëjë këtë edhe për fushat që ndodhin të rreshtohen mjaftueshëm.Si pasojë, nuk mund të përdorni fiksimin me një tip `#[repr(packed)]`.
//!
//! # Projeksionet dhe Lidhja Strukturore
//!
//! Kur punoni me struktura të fiksuara, lind pyetja se si mund të hyni në fushat e asaj strukture në një metodë që merr vetëm [`Pin`]"<&mut Struktura>".
//! Metoda e zakonshme është të shkruash metoda ndihmëse (të ashtuquajturat *projeksione*) që i kthejnë ["Pin"] "&&Struktura>" në një referencë në fushë, por çfarë lloji duhet të ketë ajo referencë?A është [`Pin`]"<&mut Field>`apo `&mut Field`?
//! E njëjta pyetje lind me fushat e një `enum`, dhe gjithashtu kur merren parasysh llojet container/wrapper të tilla si [`Vec<T>`], [`Box<T>`] ose [`RefCell<T>`].
//! (Kjo pyetje vlen për referencat e ndryshueshme dhe ato të përbashkëta, ne thjesht përdorim rastin më të zakonshëm të referencave të ndryshueshme këtu për ilustrim.)
//!
//! Rezulton se në të vërtetë i takon autorit të strukturës së të dhënave të vendosë nëse projeksioni i mbështetur për një fushë të veçantë e kthen ["Pin"] "<&mut Struktura>" në ["Pin"] "<&mut Field>" ose `&mut Field`.Megjithatë ekzistojnë disa kufizime, dhe pengesa më e rëndësishme është *qëndrueshmëria*:
//! çdo fushë mund të jetë *ose* projektuar në një referencë të fiksuar,*ose* hiqet afishimi si pjesë e projeksionit.
//! Nëse të dy bëhen për të njëjtën fushë, kjo ka të ngjarë të jetë e paqartë!
//!
//! Si autor i një strukture të dhënash ju duhet të vendosni për secilën fushë nëse vendosni "propagates" në këtë fushë apo jo.
//! Mbërthimi që përhapet quhet ndryshe "structural", sepse ndjek strukturën e llojit.
//! Në nënseksionet vijuese, ne përshkruajmë konsideratat që duhet të bëhen për secilën zgjedhje.
//!
//! ## Mbërthimi *nuk është* strukturor për `field`
//!
//! Mund të duket kundër-intuitive që fusha e një strukture të mbërthyer mund të mos jetë e mbërthyer, por kjo është në të vërtetë zgjedhja më e lehtë: nëse një ["Pin"] "<&mut Field>" nuk krijohet kurrë, asgjë nuk mund të shkojë keq!Pra, nëse vendosni që një fushë nuk ka afishim strukturor, gjithçka që duhet të siguroni është që të mos krijoni kurrë një referencë të fiksuar në atë fushë.
//!
//! Fushat pa mbështetje strukturore mund të kenë një metodë projeksioni që kthen ["Pin"] "&&Struktura>> në `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Kjo është në rregull sepse `field` nuk konsiderohet kurrë e mbërthyer.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Ju gjithashtu mund të `impl Unpin for Struct`*edhe nëse* lloji i `field` nuk është [`Unpin`].Ajo që mendon ai lloj për vendosjen nuk është e rëndësishme kur nuk krijohet asnjë ["Pin"] "<&mut Field>".
//!
//! ## Mbërthimi *është* strukturor për `field`
//!
//! Opsioni tjetër është të vendosni që fiksimi të jetë "structural" për `field`, që do të thotë se nëse struktura është e fiksuar, atëherë do të jetë edhe fusha.
//!
//! Kjo lejon shkrimin e një projeksioni që krijon një ["Pin"] "<&mut Field>", duke dëshmuar kështu që fusha është e mbërthyer:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Kjo është në rregull sepse `field` mbështetet kur është `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Sidoqoftë, fiksimi strukturor vjen me disa kërkesa shtesë:
//!
//! 1. Struktura duhet të jetë [`Unpin`] vetëm nëse të gjitha fushat strukturore janë [`Unpin`].Kjo është parazgjedhja, por [`Unpin`] është një trait i sigurt, kështu që si autor i strukturës është përgjegjësia juaj *jo* të shtoni diçka si `impl<T> Unpin for Struct<T>`.
//! (Vini re se shtimi i një operacioni projektimi kërkon një kod të pasigurt, kështu që fakti që [`Unpin`] është një trait i sigurt nuk e prish parimin që duhet të shqetësoheni vetëm për ndonjë nga këto nëse përdorni "të pasigurt".)
//! 2. Shkatërruesi i strukturës nuk duhet të lëvizë fushat strukturore nga argumenti i tij.Kjo është pika e saktë që u ngrit në [previous section][drop-impl]: `drop` merr `&mut self`, por struktura (dhe rrjedhimisht fushat e saj) mund të ishin mbështetur më parë.
//!     Ju duhet të garantoni që nuk lëvizni një fushë brenda implementimit tuaj [`Drop`].
//!     Në veçanti, siç u shpjegua më parë, kjo do të thotë që struktura juaj *nuk duhet* të jetë `#[repr(packed)]`.
//!     Shikoni atë pjesë për mënyrën e të shkruarit [`drop`] në një mënyrë që përpiluesi të ju ndihmojë të mos prishni aksidentalisht vendosjen.
//! 3. Ju duhet të siguroheni që të mbani [`Drop` guarantee][drop-guarantee]:
//!     sapo struktura juaj të mbërthehet, kujtesa që përmban përmbajtjen nuk mbishkruhet ose shpërndahet pa thirrur shkatërruesit e përmbajtjes.
//!     Kjo mund të jetë e ndërlikuar, siç dëshmohet nga [`VecDeque<T>`]: shkatërruesi i [`VecDeque<T>`] mund të dështojë të thërrasë [`drop`] në të gjithë elementët nëse një nga shkatërruesit panics.Kjo shkel garancinë [`Drop`], sepse mund të çojë në eleokimin e elementeve pa u thirrur shkatërruesi i tyre.([`VecDeque<T>`] nuk ka parashikime të fiksimit, kështu që kjo nuk shkakton pandjeshmëri.)
//! 4. Ju nuk duhet të ofroni ndonjë operacion tjetër që mund të çojë në zhvendosjen e të dhënave nga fushat strukturore kur lloji juaj ngulitet.Për shembull, nëse struktura përmban një [`Option<T>`] dhe ekziston një operacion i ngjashëm me 'marrjen' me llojin `fn(Pin<&mut Struct<T>>) -> Option<T>`, ai operacion mund të përdoret për të lëvizur një `T` nga një `Struct<T>` i mbështjellë-që do të thotë që fiksimi nuk mund të jetë strukturor për fushën që e mban këtë të dhëna.
//!
//!     Për një shembull më kompleks të lëvizjes së të dhënave nga një lloj i fiksuar, imagjinoni nëse [`RefCell<T>`] do të kishte një metodë `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Atëherë mund të bëjmë sa vijon:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Kjo është katastrofike, do të thotë që së pari mund të vendosim përmbajtjen e [`RefCell<T>`] (duke përdorur `RefCell::get_pin_mut`) dhe pastaj ta zhvendosim atë përmbajtje duke përdorur referencën e ndryshueshme që morëm më vonë.
//!
//! ## Examples
//!
//! Për një lloj si [`Vec<T>`], të dy mundësitë (vendosja strukturore ose jo) kanë kuptim.
//! Një [`Vec<T>`] me afishim strukturor mund të ketë metoda `get_pin`/`get_pin_mut` për të marrë referenca të fiksuara në elemente.Sidoqoftë, nuk mund të *lejonte* thirrjen e [`pop`][Vec::pop] në një [`Vec<T>`] të fiksuar, sepse kjo do të lëvizte përmbajtjen (e fiksuar nga struktura)!As nuk mund të lejonte [`push`][Vec::push], i cili mund të rialokojë dhe kështu të lëvizë edhe përmbajtjen.
//!
//! Një [`Vec<T>`] pa fiksim strukturor mund të jetë `impl<T> Unpin for Vec<T>`, sepse përmbajtja nuk mbërthehet kurrë dhe vetë [`Vec<T>`] është mirë të zhvendoset gjithashtu.
//! Në atë pikë, fiksimi thjesht nuk ka aspak efekt në vector.
//!
//! Në bibliotekën standarde, llojet e treguesve në përgjithësi nuk kanë mbështetje strukturore, dhe kështu ato nuk ofrojnë parashikime të afishimit.Kjo është arsyeja pse `Box<T>: Unpin` vlen për të gjithë `T`.
//! Ka kuptim ta bësh këtë për llojet e treguesve, sepse lëvizja e `Box<T>` nuk lëviz në të vërtetë `T`: [`Box<T>`] mund të lëvizet lirshëm (aka `Unpin`) edhe nëse `T` nuk është.Në fakt, edhe ["Pin"] "<" ["Kutia"] "<T>>`dhe [`Pin`] "<&mut T>" janë gjithmonë [`Unpin`] vetë, për të njëjtën arsye: përmbajtja e tyre (`T`) mbështetet, por vetë treguesit mund të zhvendosen pa lëvizur të dhënat e fiksuara.
//! Si për [`Box<T>`] ashtu edhe për ["Pin"] "<" ["Kutia"] "<T>>", nëse përmbajtja është e mbërthyer është plotësisht e pavarur nga nëse treguesi është i mbërthyer, që do të thotë se fiksimi nuk është * strukturor.
//!
//! Kur zbatoni një kombinues [`Future`], ju zakonisht do të keni nevojë për fiksim strukturor për futures të futur, pasi ju duhet të merrni referenca të mbështetura tek ata për të thirrur [`poll`].
//! Por nëse kombinuesi juaj përmban ndonjë të dhënë tjetër që nuk ka nevojë të ngulitet, ju mund t'i bëni ato fusha të mos jenë strukturore dhe kështu lirisht t'i përdorni ato me një referencë të ndryshueshme edhe kur thjesht keni ["Pin"] "<&mut Self>" (të tilla si në implementimin tuaj [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Një tregues i gozhduar.
///
/// Ky është një mbështjellës rreth një lloj treguesi që e bën atë tregues "pin" vlerën e tij në vend, duke parandaluar që vlera e referuar nga ai tregues të zhvendoset nëse nuk zbaton [`Unpin`].
///
///
/// *Shihni dokumentacionin [`pin` module] për një shpjegim të afishimit.*
///
/// [`pin` module]: self
///
// Note: `Clone` që rrjedh më poshtë shkakton pandjeshmëri pasi është e mundur të zbatohet
// `Clone` për referenca të ndryshueshme.
// Shihni <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> për më shumë detaje.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Zbatimet e mëposhtme nuk janë nxjerrë për të shmangur çështjet e shëndetit.
// `&self.pointer` nuk duhet të jenë të arritshme për zbatimet e pasigurta të trait.
//
// Shihni <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> për më shumë detaje.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Ndërtoni një `Pin<P>` të ri rreth një treguesi për disa të dhëna të një lloji që zbaton [`Unpin`].
    ///
    /// Ndryshe nga `Pin::new_unchecked`, kjo metodë është e sigurt sepse treguesi `P` i referohet një lloji [`Unpin`], i cili anulon garancitë e fiksimit.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SIGURIA: vlera e treguar është `Unpin`, dhe kështu nuk ka kërkesa
        // rreth pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Zhbllokon këtë `Pin<P>` duke kthyer treguesin themelor.
    ///
    /// Kjo kërkon që të dhënat brenda këtij `Pin` të jenë [`Unpin`] në mënyrë që të mund të injorojmë invariancat e fiksimit kur i zbërthejmë ato.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Ndërtoni një `Pin<P>` të ri rreth një referencë për disa të dhëna të një lloji që mund të zbatojë ose jo `Unpin`.
    ///
    /// Nëse defektet `pointer` për një tip `Unpin`, në vend të tij duhet të përdoret `Pin::new`.
    ///
    /// # Safety
    ///
    /// Ky konstruktor është i pasigurt sepse nuk mund të garantojmë që të dhënat e cekura nga `pointer` të jenë të fiksuara, që do të thotë që të dhënat nuk do të zhvendosen ose hapësira e tyre e pavlefshme do të zhvlerësohet derisa të bien.
    /// Nëse `Pin<P>` i ndërtuar nuk garanton që të dhënat e pikave `P` të jenë të mbërthyera, kjo është një shkelje e kontratës API dhe mund të çojë në sjellje të papërcaktuar në operacionet e mëvonshme (safe).
    ///
    /// Duke përdorur këtë metodë, ju po bëni një promise në lidhje me implementimet `P::Deref` dhe `P::DerefMut`, nëse ato ekzistojnë.
    /// Më e rëndësishmja, ata nuk duhet të lëvizin nga argumentet e tyre `self`: `Pin::as_mut` dhe `Pin::as_ref` do të thërrasin `DerefMut::deref_mut` dhe `Deref::deref`*në treguesin e fiksuar* dhe presin që këto metoda të mbështesin invariancat e fiksimit.
    /// Për më tepër, duke e thirrur këtë metodë ju promise që referencat e referencave `P` për të nuk do të zhvendosen përsëri;në veçanti, nuk duhet të jetë e mundur të merret një `&mut P::Target` dhe pastaj të zhvendoset nga ajo referencë (duke përdorur, për shembull [`mem::swap`]).
    ///
    ///
    /// Për shembull, thirrja e `Pin::new_unchecked` në një `&'a mut T` është e pasigurt sepse ndërsa jeni në gjendje ta lidhni atë për jetën e dhënë `'a`, nuk keni kontroll nëse ajo mbahet e mbërthyer pasi të mbarojë `'a`:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Kjo do të thotë që `a` i bashkuar nuk mund të lëvizë më kurrë.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adresa e `a` ndryshoi në slotin e rafteve `b`, kështu që `a` u zhvendos edhe pse më parë e kemi fiksuar!Ne kemi shkelur kontratën e afishimit të API-së.
    /////
    /// }
    /// ```
    ///
    /// Një vlerë, pasi të jetë e mbërthyer, duhet të mbetet e mbërthyer përgjithmonë (përveç nëse lloji i saj zbaton `Unpin`).
    ///
    /// Në mënyrë të ngjashme, thirrja e `Pin::new_unchecked` në një `Rc<T>` është e pasigurt sepse mund të ketë pseudonime për të njëjtat të dhëna që nuk i nënshtrohen kufizimeve të vendosjes:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Kjo do të thotë që i bashkuari nuk mund të lëvizë më kurrë.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Tani, nëse `x` ishte referenca e vetme, ne kemi një referencë të ndryshueshme për të dhënat që vendosëm më sipër, të cilat mund t'i përdorim për t'i lëvizur siç kemi parë në shembullin e mëparshëm.
    ///     // Ne kemi shkelur kontratën e afishimit të API-së.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Merr një referencë të përbashkët të fiksuar nga ky tregues i gozhduar.
    ///
    /// Kjo është një metodë e përgjithshme për të kaluar nga `&Pin<Pointer<T>>` në `Pin<&T>`.
    /// Isshtë e sigurt sepse, si pjesë e kontratës së `Pin::new_unchecked`, i bashkuari nuk mund të lëvizë pasi `Pin<Pointer<T>>` u krijua.
    ///
    /// "Malicious" implementimet e `Pointer::Deref` përjashtohen gjithashtu nga kontrata e `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SIGURIA: shihni dokumentacionin mbi këtë funksion
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Zhbllokon këtë `Pin<P>` duke kthyer treguesin themelor.
    ///
    /// # Safety
    ///
    /// Ky funksion është i pasigurt.Ju duhet të garantoni se do të vazhdoni ta trajtoni treguesin `P` si të mbërthyer pasi të keni thirrur këtë funksion, në mënyrë që invariancat në llojin `Pin` të mund të mbështeten.
    /// Nëse kodi duke përdorur `P` që rezulton nuk vazhdon të ruajë invariancat e fiksimit që është një shkelje e kontratës API dhe mund të çojë në sjellje të papërcaktuar në operacionet e mëvonshme (safe).
    ///
    ///
    /// Nëse të dhënat themelore janë [`Unpin`], në vend të kësaj duhet të përdoret [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Merr një referencë të ngurtësuar të kyçur nga ky tregues i fiksuar.
    ///
    /// Kjo është një metodë e përgjithshme për të kaluar nga `&mut Pin<Pointer<T>>` në `Pin<&mut T>`.
    /// Isshtë e sigurt sepse, si pjesë e kontratës së `Pin::new_unchecked`, i bashkuari nuk mund të lëvizë pasi `Pin<Pointer<T>>` u krijua.
    ///
    /// "Malicious" implementimet e `Pointer::DerefMut` përjashtohen gjithashtu nga kontrata e `Pin::new_unchecked`.
    ///
    /// Kjo metodë është e dobishme kur bëni thirrje të shumta për funksionet që konsumojnë llojin e fiksuar.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // bej dicka
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` konsumon `self`, kështu që rigjeni `Pin<&mut Self>` përmes `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SIGURIA: shihni dokumentacionin mbi këtë funksion
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Cakton një vlerë të re në kujtesën prapa referencës së fiksuar.
    ///
    /// Kjo mbishkruan të dhënat e mbërthyera, por kjo është në rregull: shkatërruesi i tij ekzekutohet përpara se të mbishkruhet, kështu që asnjë shkelje e garancisë nuk është shkelur.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Ndërton një kunj të ri duke hartuar vlerën e brendshme.
    ///
    /// Për shembull, nëse dëshironi të merrni një `Pin` të një fushe të diçkaje, mund ta përdorni këtë për të marrë qasje në atë fushë në një rresht të kodit.
    /// Sidoqoftë, ka disa blerje me këto "pinning projections";
    /// shikoni dokumentacionin [`pin` module] për detaje të mëtejshme mbi atë temë.
    ///
    /// # Safety
    ///
    /// Ky funksion është i pasigurt.
    /// Ju duhet të garantoni që të dhënat që ktheni të mos lëvizin për sa kohë që vlera e argumentit nuk lëviz (për shembull, sepse është një nga fushat e asaj vlere), dhe gjithashtu që të mos lëvizni nga argumenti që merrni funksioni i brendshëm.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SIGURIA: kontrata e sigurisë për `new_unchecked` duhet të jetë
        // mbështetur nga thirrësi.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Merr një referencë të përbashkët nga një kunj.
    ///
    /// Kjo është e sigurt sepse nuk është e mundur të dilni nga një referencë e përbashkët.
    /// Mund të duket sikur këtu ka një çështje me ndryshueshmërinë e brendshme: në fakt,*është* e mundur të zhvendosni një `T` nga një `&RefCell<T>`.
    /// Sidoqoftë, ky nuk është problem për sa kohë që nuk ekziston gjithashtu një `Pin<&T>` që tregon të njëjtat të dhëna dhe `RefCell<T>` nuk ju lejon të krijoni një referencë të fiksuar në përmbajtjen e saj.
    ///
    /// Shihni diskutimin në ["pinning projections"] për detaje të mëtejshme.
    ///
    /// Note: `Pin` gjithashtu zbaton `Deref` në shenjë, e cila mund të përdoret për të hyrë në vlerën e brendshme.
    /// Sidoqoftë, `Deref` ofron vetëm një referencë që jeton për aq kohë sa huazimi i `Pin`, jo gjithë jetëgjatësia e `Pin` vetë.
    /// Kjo metodë lejon kthimin e `Pin` në një referencë me të njëjtën jetëgjatësi si `Pin` origjinale.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Shndërron këtë `Pin<&mut T>` në një `Pin<&T>` me të njëjtën jetëgjatësi.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Merr një referencë të ndryshueshme për të dhënat brenda këtij `Pin`.
    ///
    /// Kjo kërkon që të dhënat brenda këtij `Pin` të jenë `Unpin`.
    ///
    /// Note: `Pin` gjithashtu implementon `DerefMut` në të dhëna, të cilat mund të përdoren për të hyrë në vlerën e brendshme.
    /// Sidoqoftë, `DerefMut` siguron vetëm një referencë që jeton për aq kohë sa huazimi i `Pin`, jo jetëgjatësia e `Pin` vetë.
    ///
    /// Kjo metodë lejon kthimin e `Pin` në një referencë me të njëjtën jetëgjatësi si `Pin` origjinale.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Merr një referencë të ndryshueshme për të dhënat brenda këtij `Pin`.
    ///
    /// # Safety
    ///
    /// Ky funksion është i pasigurt.
    /// Ju duhet të garantoni se nuk do t'i zhvendosni kurrë të dhënat nga referenca e paqëndrueshme që merrni kur e telefononi këtë funksion, në mënyrë që invariancat në llojin `Pin` të mund të mbështeten.
    ///
    ///
    /// Nëse të dhënat themelore janë `Unpin`, në vend të kësaj duhet të përdoret `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Ndërtoni një kunj të ri duke hartuar vlerën e brendshme.
    ///
    /// Për shembull, nëse dëshironi të merrni një `Pin` të një fushe të diçkaje, mund ta përdorni këtë për të marrë qasje në atë fushë në një rresht të kodit.
    /// Sidoqoftë, ka disa blerje me këto "pinning projections";
    /// shikoni dokumentacionin [`pin` module] për detaje të mëtejshme mbi atë temë.
    ///
    /// # Safety
    ///
    /// Ky funksion është i pasigurt.
    /// Ju duhet të garantoni që të dhënat që ktheni të mos lëvizin për sa kohë që vlera e argumentit nuk lëviz (për shembull, sepse është një nga fushat e asaj vlere), dhe gjithashtu që të mos lëvizni nga argumenti që merrni funksioni i brendshëm.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SIGURIA: telefonuesi është përgjegjës për mos lëvizjen e
        // vlera nga kjo referencë.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SIGURIA: pasi vlera e `this` është e garantuar të mos ketë
        // është zhvendosur, kjo thirrje për `new_unchecked` është e sigurt.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Merrni një referencë të fiksuar nga një referencë statike.
    ///
    /// Kjo është e sigurt, sepse `T` është huazuar për tërë jetën `'static`, e cila nuk mbaron kurrë.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SIGURIA: Huamarrja statike garanton që të dhënat nuk do të jenë
        // moved/invalidated derisa të bjerë (e cila nuk është kurrë).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Merrni një referencë të ndryshueshme të mbërthyer nga një referencë statike e ndryshueshme.
    ///
    /// Kjo është e sigurt, sepse `T` është huazuar për tërë jetën `'static`, e cila nuk mbaron kurrë.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SIGURIA: Huamarrja statike garanton që të dhënat nuk do të jenë
        // moved/invalidated derisa të bjerë (e cila nuk është kurrë).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: kjo do të thotë se çdo implikim i `CoerceUnsized` që lejon detyrimin nga
// një tip që nënkupton `Deref<Target=impl !Unpin>` në një tip që nënkupton `Deref<Target=Unpin>` është i pazëshëm.
// Sidoqoftë, çdo implikim i tillë do të ishte i paqartë për arsye të tjera, prandaj duhet të kujdesemi që të mos lejojmë që implse të tilla të zbarkojnë në std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}