use crate::iter::{FusedIterator, TrustedLen};

/// Krijon një iterator të ri që përsërit pafundësisht një element të vetëm.
///
/// Funksioni `repeat()` përsërit një vlerë të vetme pa pushim.
///
/// Përsëritës të pafund si `repeat()` përdoren shpesh me adaptorë si [`Iterator::take()`], në mënyrë që t'i bëjnë ato të fundme.
///
/// Nëse lloji i elementit të përsëritësit që ju nevojitet nuk implementon `Clone`, ose nëse nuk doni ta mbani elementin e përsëritur në kujtesë, në vend të kësaj mund të përdorni funksionin [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::iter;
///
/// // numri katër 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // po, akoma katër
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Shkuarja e fundme me [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ai shembull i fundit ishte shumë katërsh.Le të kemi vetëm katër katërshe.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... dhe tani kemi mbaruar
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Një iterator që përsërit një element pa fund.
///
/// Ky `struct` është krijuar nga funksioni [`repeat()`].Shihni dokumentacionin e tij për më shumë.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}