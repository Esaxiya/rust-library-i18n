use crate::iter::{FusedIterator, TrustedLen};

/// Krijon një iterator që gjeneron me lazdi një vlerë saktësisht një herë duke thirrur mbylljen e parashikuar.
///
/// Kjo zakonisht përdoret për të përshtatur një gjenerator të vlerës së vetme në një [`chain()`] të llojeve të tjera të përsëritjes.
/// Ndoshta ju keni një iterator që mbulon pothuajse gjithçka, por keni nevojë për një rast ekstra të veçantë.
/// Ndoshta ju keni një funksion i cili punon në përsëritës, por duhet vetëm të përpunoni një vlerë.
///
/// Ndryshe nga [`once()`], ky funksion do të gjenerojë me përtesë vlerën sipas kërkesës.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::iter;
///
/// // njëri është numri më i vetmuar
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // vetëm një, kjo është gjithçka që marrim
/// assert_eq!(None, one.next());
/// ```
///
/// Zinxhirimi së bashku me një përsëritës tjetër.
/// Le të themi se duam të përsërisim mbi secilin skedar të direktorisë `.foo`, por edhe një skedar konfigurimi,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ne kemi nevojë për të kthyer nga një iterator i DirEntry-së në një iterator i PathBufs, kështu që ne përdorim hartën
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // tani, iteratori ynë vetëm për skedarin tonë konfigurues
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // zinxhironi dy përsëritësit së bashku në një përsëritës të madh
/// let files = dirs.chain(config);
///
/// // kjo do të na japë të gjitha skedarët në .foo si dhe .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Një iterator që jep një element të vetëm të tipit `A` duke aplikuar mbylljen `F: FnOnce() -> A` të parashikuar.
///
///
/// Ky `struct` është krijuar nga funksioni [`once_with()`].
/// Shihni dokumentacionin e tij për më shumë.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}