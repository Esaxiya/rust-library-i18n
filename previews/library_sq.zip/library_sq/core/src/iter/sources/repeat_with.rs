use crate::iter::{FusedIterator, TrustedLen};

/// Krijon një iterator të ri që përsërit elementet e tipit `A` pafund duke aplikuar mbylljen e parashikuar, përsëritësin, `F: FnMut() -> A`.
///
/// Funksioni `repeat_with()` thërret përsëritësin pa pushim.
///
/// Përsëritës të pafund si `repeat_with()` përdoren shpesh me adaptorë si [`Iterator::take()`], në mënyrë që t'i bëjnë ato të fundme.
///
/// Nëse lloji i elementit të përsëritësit që ju nevojitet zbaton [`Clone`], dhe është në rregull të mbani elementin burimor në memorje, në vend të kësaj duhet të përdorni funksionin [`repeat()`].
///
///
/// Një përsëritës i prodhuar nga `repeat_with()` nuk është [`DoubleEndedIterator`].
/// Nëse ju duhet `repeat_with()` për të kthyer një [`DoubleEndedIterator`], ju lutemi hapni një çështje të GitHub që shpjegon rastin tuaj të përdorimit.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::iter;
///
/// // le të supozojmë se kemi një vlerë të një lloji që nuk është `Clone` ose që nuk dëshiron ta ketë në kujtesë akoma sepse është i shtrenjtë:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // një vlerë e veçantë përgjithmonë:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Përdorimi i mutacionit dhe kalimi i fundëm:
///
/// ```rust
/// use std::iter;
///
/// // Nga zeroti në fuqinë e tretë të dy:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... dhe tani kemi mbaruar
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Një iterator që përsërit elementet e tipit `A` pafundësisht duke aplikuar mbylljen `F: FnMut() -> A` të parashikuar.
///
///
/// Ky `struct` është krijuar nga funksioni [`repeat_with()`].
/// Shihni dokumentacionin e tij për më shumë.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}