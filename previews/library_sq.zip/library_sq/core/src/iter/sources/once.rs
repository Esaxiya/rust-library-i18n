use crate::iter::{FusedIterator, TrustedLen};

/// Krijon një iterator që jep një element saktësisht një herë.
///
/// Kjo zakonisht përdoret për të përshtatur një vlerë të vetme në një [`chain()`] të llojeve të tjera të përsëritjes.
/// Ndoshta ju keni një iterator që mbulon pothuajse gjithçka, por keni nevojë për një rast ekstra të veçantë.
/// Ndoshta ju keni një funksion i cili punon në përsëritës, por duhet vetëm të përpunoni një vlerë.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::iter;
///
/// // njëri është numri më i vetmuar
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // vetëm një, kjo është gjithçka që marrim
/// assert_eq!(None, one.next());
/// ```
///
/// Zinxhirimi së bashku me një përsëritës tjetër.
/// Le të themi se duam të përsërisim mbi secilin skedar të direktorisë `.foo`, por edhe një skedar konfigurimi,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ne kemi nevojë për të kthyer nga një iterator i DirEntry-së në një iterator i PathBufs, kështu që ne përdorim hartën
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // tani, iteratori ynë vetëm për skedarin tonë konfigurues
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // zinxhironi dy përsëritësit së bashku në një përsëritës të madh
/// let files = dirs.chain(config);
///
/// // kjo do të na japë të gjitha skedarët në .foo si dhe .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Një iterator që jep një element saktësisht një herë.
///
/// Ky `struct` është krijuar nga funksioni [`once()`].Shihni dokumentacionin e tij për më shumë.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}