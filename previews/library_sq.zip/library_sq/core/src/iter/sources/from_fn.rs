use crate::fmt;

/// Krijon një përsëritës të ri ku secila përsëritje e quan mbylljen e parashikuar `F: FnMut() -> Option<T>`.
///
/// Kjo lejon krijimin e një iteratori të personalizuar me çdo sjellje pa përdorur sintaksën më të folur të krijimit të një lloji të dedikuar dhe implementimin e [`Iterator`] trait për të.
///
/// Vini re se përsëritësi `FromFn` nuk bën supozime në lidhje me sjelljen e mbylljes, dhe për këtë arsye në mënyrë konservatore nuk zbaton [`FusedIterator`], ose tejkalon [`Iterator::size_hint()`] nga `(0, None)` i tij i paracaktuar.
///
///
/// Mbyllja mund të përdorë kapjet dhe mjedisin e saj për të gjetur gjendjen në të gjithë përsëritjet.Në varësi të mënyrës se si përdoret përsëritësi, kjo mund të kërkojë specifikimin e fjalës kyçe [`move`] në mbyllje.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Le të ri-zbatojmë kundër-iteratorin nga [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Rritni numrin tonë.Kjo është arsyeja pse ne filluam në zero.
///     count += 1;
///
///     // Kontrolloni për të parë nëse kemi mbaruar numërimin apo jo.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Një përsëritës ku secila përsëritje e quan mbylljen e parashikuar `F: FnMut() -> Option<T>`.
///
/// Ky `struct` është krijuar nga funksioni [`iter::from_fn()`].
/// Shihni dokumentacionin e tij për më shumë.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}