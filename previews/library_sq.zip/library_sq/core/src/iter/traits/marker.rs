/// Një përsëritës që vazhdon gjithmonë të japë `None` kur të rraskapitet.
///
/// Thirrja tjetër në një përsëritës të shkrirë që ka kthyer një herë `None` është e garantuar që të kthehet përsëri [`None`].
/// Ky trait duhet të implementohet nga të gjithë përsëritësit që sillen në këtë mënyrë sepse lejon optimizimin e [`Iterator::fuse()`].
///
///
/// Note: Në përgjithësi, nuk duhet të përdorni `FusedIterator` në kufij të përgjithshëm nëse keni nevojë për një përsëritës të shkrirë.
/// Në vend të kësaj, thjesht duhet të telefononi [`Iterator::fuse()`] në përsëritës.
/// Nëse përsëritësi është shkrirë tashmë, mbështjellësi shtesë [`Fuse`] do të jetë një opsion pa ndalim pa asnjë ndëshkim të performancës.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Një iterator që raporton një gjatësi të saktë duke përdorur size_hint.
///
/// Iterator raporton një aluzion të madhësisë ku është ose i saktë (kufiri i poshtëm është i barabartë me kufirin e sipërm), ose kufiri i sipërm është [`None`].
///
/// Kufiri i sipërm duhet të jetë [`None`] vetëm nëse gjatësia aktuale e përsëritësit është më e madhe se [`usize::MAX`].
/// Në atë rast, kufiri i poshtëm duhet të jetë [`usize::MAX`], duke rezultuar në një [`Iterator::size_hint()`] të `(usize::MAX, None)`.
///
/// Përsëritësi duhet të prodhojë saktësisht numrin e elementeve që raportoi ose të ndryshojnë përpara se të arrijë në fund.
///
/// # Safety
///
/// Ky trait duhet të zbatohet vetëm kur kontrata është në fuqi.
/// Konsumatorët e këtij trait duhet të inspektojnë kufirin e sipërm [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Një përsëritës që kur jep një artikull do të ketë marrë të paktën një element nga [`SourceIter`] i tij themelor.
///
/// Thirrja e çdo metode që përparon iteratorin, p.sh.
/// [`next()`] ose [`try_fold()`], garanton që për secilin hap të paktën një vlerë e burimit themelor të iteratorit është zhvendosur dhe rezultati i zinxhirit iterator mund të futet në vendin e tij, duke supozuar se kufizimet strukturore të burimit lejojnë një futje të tillë.
///
/// Me fjalë të tjera, ky trait tregon se një tubacion iterator mund të mblidhet në vend.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}