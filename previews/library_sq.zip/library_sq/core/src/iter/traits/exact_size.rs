/// Një përsëritës që di gjatësinë e tij të saktë.
///
/// Shumë [`Iterator`] nuk e dinë sa herë do të përsëriten, por disa e dinë.
/// Nëse një përsëritës e di se sa herë mund të përsëritet, sigurimi i qasjes në atë informacion mund të jetë i dobishëm.
/// Për shembull, nëse doni të përsërisni prapa, një fillim i mirë është të dini se ku është fundi.
///
/// Kur zbatoni një `ExactSizeIterator`, duhet të zbatoni gjithashtu [`Iterator`].
/// Kur veproni kështu, implementimi i [`Iterator::size_hint`]*duhet* të kthejë madhësinë e saktë të përsëritësit.
///
/// Metoda [`len`] ka një implementim të paracaktuar, kështu që zakonisht nuk duhet ta zbatoni atë.
/// Sidoqoftë, mund të jeni në gjendje të siguroni një zbatim më performancë sesa të paracaktuarit, kështu që tejkalimi i tij në këtë rast ka kuptim.
///
///
/// Vini re se ky trait është një trait i sigurt dhe si i tillë nuk *dhe* dhe *nuk mund të* garantojë që gjatësia e kthyer është e saktë.
/// Kjo do të thotë që kodi `unsafe`**nuk duhet të** mbështetet në korrektësinë e [`Iterator::size_hint`].
/// [`TrustedLen`](super::marker::TrustedLen) trait e paqëndrueshme dhe e pasigurt jep këtë garanci shtesë.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// // një diapazon i kufizuar e di saktësisht se sa herë do të përsëritet
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Në [module-level docs], ne kemi zbatuar një [`Iterator`], `Counter`.
/// Le të zbatojmë `ExactSizeIterator` edhe për të:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Ne lehtë mund të llogarisim numrin e mbetur të përsëritjeve.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Dhe tani mund ta përdorim!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Kthen gjatësinë e saktë të përsëritësit.
    ///
    /// Zbatimi siguron që përsëritësi do të kthejë saktësisht `len()` herë më shumë se një vlerë [`Some(T)`], para se të kthejë [`None`].
    ///
    /// Kjo metodë ka një zbatim të paracaktuar, kështu që zakonisht nuk duhet ta zbatoni atë drejtpërdrejt.
    /// Sidoqoftë, nëse mund të siguroni një zbatim më efikas, mund ta bëni.
    /// Shihni dokumentet [trait-level] për një shembull.
    ///
    /// Ky funksion ka të njëjtat garanci sigurie si funksioni [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // një diapazon i kufizuar e di saktësisht se sa herë do të përsëritet
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Ky pohim është tepër mbrojtës, por kontrollon të pandryshueshmen
        // garantuar nga trait.
        // Nëse ky trait do të ishte rust-i brendshëm, ne mund të përdorim debug_assert !;pohoj_eq!do të kontrollojë gjithashtu të gjitha zbatimet e përdoruesve të Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Kthen `true` nëse përsëritësi është bosh.
    ///
    /// Kjo metodë ka një implementim të paracaktuar duke përdorur [`ExactSizeIterator::len()`], kështu që nuk keni nevojë ta zbatoni vetë.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}