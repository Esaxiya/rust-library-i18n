// injoroni-rregulloni-gjatësinë e skedarit Kjo skedar pothuajse ekskluzivisht përbëhet nga përkufizimi i `Iterator`.
// Ne nuk mund ta ndajmë atë në skedarë të shumtë.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Një ndërfaqe për trajtimin e përsëritësve.
///
/// Ky është iteratori kryesor trait.
/// Për më shumë në lidhje me konceptin e përsëritësve në përgjithësi, ju lutemi shikoni [module-level documentation].
/// Në veçanti, ju mund të dëshironi të dini se si të [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Lloji i elementeve që përsëriten.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Përparon iteratorin dhe kthen vlerën tjetër.
    ///
    /// Kthen [`None`] kur mbaron përsëritja.
    /// Implementimet individuale të iteratorit mund të zgjedhin të rifillojnë përsëritjen, dhe kështu që thirrja përsëri në `next()` mund të fillojë ose jo përfundimisht të kthejë [`Some(Item)`] përsëri në një moment.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Një telefonatë në next() kthen vlerën tjetër ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... dhe pastaj Asnjë pasi të ketë mbaruar.
    /// assert_eq!(None, iter.next());
    ///
    /// // Më shumë telefonata mund ose nuk mund të kthehen `None`.Këtu, ata gjithmonë do të bëjnë.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Kthen kufijtë në gjatësinë e mbetur të përsëritësit.
    ///
    /// Në mënyrë të veçantë, `size_hint()` kthen një tuple ku elementi i parë është kufiri i poshtëm, dhe elementi i dytë është kufiri i sipërm.
    ///
    /// Gjysma e dytë e tuple që kthehet është një ["Opsion"] "<" ["përdor") ">.
    /// Një [`None`] këtu do të thotë që ose nuk ka asnjë lidhje të sipërme të njohur, ose kufiri i sipërm është më i madh se [`usize`].
    ///
    /// # Shënime zbatimi
    ///
    /// Nuk zbatohet që një zbatim iterator jep numrin e deklaruar të elementeve.Një iterator buggy mund të japë më pak se kufiri i poshtëm ose më shumë se kufiri i sipërm i elementeve.
    ///
    /// `size_hint()` është menduar kryesisht të përdoret për optimizime të tilla si rezervimi i hapësirës për elementet e përsëritësit, por nuk duhet t'i besohet p.sh., heqja e kontrolleve të kufijve në kodin e pasigurt.
    /// Një zbatim i pasaktë i `size_hint()` nuk duhet të çojë në shkelje të sigurisë së kujtesës.
    ///
    /// Thënë kjo, zbatimi duhet të sigurojë një vlerësim të saktë, sepse përndryshe do të ishte shkelje e protokollit të trait.
    ///
    /// Zbatimi i paracaktuar kthen "(0," ["Asnjë"] ") i cili është i saktë për çdo përsëritës.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Një shembull më kompleks:
    ///
    /// ```
    /// // Numrat çift nga zero në dhjetë.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Ne mund të përsërisim nga zero në dhjetë herë.
    /// // Të dish që janë pesë saktësisht nuk do të ishte e mundur pa ekzekutuar filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Le të shtojmë pesë numra të tjerë me chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // tani të dy kufijtë janë rritur me pesë
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Kthimi i `None` për një kufi të sipërm:
    ///
    /// ```
    /// // një iterator i pafund nuk ka kufirin e sipërm dhe kufirin maksimal të mundshëm të poshtëm
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Konsumon iteratorin, duke numëruar numrin e përsëritjeve dhe duke e kthyer atë.
    ///
    /// Kjo metodë do të thërrasë [`next`] në mënyrë të përsëritur derisa të haset [`None`], duke kthyer numrin e herëve që pa [`Some`].
    /// Vini re se [`next`] duhet të thirret të paktën një herë edhe nëse përsëritësi nuk ka ndonjë element.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Sjellja e tejmbushur
    ///
    /// Metoda nuk mbron nga mbingarkesat, kështu që numërimi i elementeve të një iteratori me më shumë se elementë [`usize::MAX`] prodhon rezultat të gabuar ose panics.
    ///
    /// Nëse pohimet e korrigjimeve janë të aktivizuara, një panic është e garantuar.
    ///
    /// # Panics
    ///
    /// Ky funksion mund të jetë panic nëse iteratori ka më shumë se elementë [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Konsumon iteratorin, duke kthyer elementin e fundit.
    ///
    /// Kjo metodë do të vlerësojë përsëritësin derisa të kthejë [`None`].
    /// Ndërsa e bën këtë, ajo mban gjurmët e elementit aktual.
    /// Pasi të kthehet [`None`], `last()` do të kthejë elementin e fundit që pa.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Përparon iteratorin nga elementet `n`.
    ///
    /// Kjo metodë do të kapërcejë me padurim elementet `n` duke thirrur [`next`] deri në `n` herë derisa të haset [`None`].
    ///
    /// `advance_by(n)` do të kthejë [`Ok(())`][Ok] nëse iteratori përparon me sukses nga elementet `n`, ose [`Err(k)`][Err] nëse haset [`None`], ku `k` është numri i elementeve nga të cilat avancohet iteratori para se të mbarojnë elementet (dmth.
    /// gjatësia e përsëritësit).
    /// Vini re se `k` është gjithmonë më pak se `n`.
    ///
    /// Thirrja `advance_by(0)` nuk konsumon asnjë element dhe gjithmonë kthen [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // vetëm `&4` u anashkalua
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Kthen elementin `n` të përsëritësit.
    ///
    /// Ashtu si shumica e operacioneve të indeksimit, numërimi fillon nga zero, kështu që `nth(0)` kthen vlerën e parë, `nth(1)` të dytën, etj.
    ///
    /// Vini re se të gjithë elementët paraardhës, si dhe elementi i kthyer, do të konsumohen nga përsëritësi.
    /// Kjo do të thotë që elementët e mëparshëm do të hidhen poshtë, dhe gjithashtu se thirrja e `nth(0)` shumë herë në të njëjtin përsëritës do të kthejë elementë të ndryshëm.
    ///
    ///
    /// `nth()` do të kthejë [`None`] nëse `n` është më e madhe ose e barabartë me gjatësinë e përsëritësit.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Thirrja e `nth()` disa herë nuk e kthen përsëritësin:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Kthimi i `None` nëse ka më pak se elementë `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Krijon një përsëritës duke filluar në të njëjtën pikë, por duke shkelur me shumën e dhënë në çdo përsëritje.
    ///
    /// Shënim 1: Elementi i parë i përsëritësit do të kthehet gjithmonë, pavarësisht nga hapi i dhënë.
    ///
    /// Shënim 2: Koha në të cilën tërhiqen elementët e injoruar nuk është fikse.
    /// `StepBy` sillet si sekuenca `next(), nth(step-1), nth(step-1),…`, por është gjithashtu e lirë të sillet si sekuenca
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Cila mënyrë është përdorur mund të ndryshojë për disa përsëritës për arsye të performancës.
    /// Mënyra e dytë do të avancojë përsëritësin më herët dhe mund të konsumojë më shumë artikuj.
    ///
    /// `advance_n_and_return_first` është ekuivalenti i:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metoda do të panic nëse hapi i dhënë është `0`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Merr dy përsëritës dhe krijon një përsëritës të ri në radhë.
    ///
    /// `chain()` do të kthejë një iterator të ri i cili së pari do të përsërisë mbi vlerat nga iteratori i parë dhe pastaj mbi vlerat nga iteratori i dytë.
    ///
    /// Me fjalë të tjera, lidh dy përsëritës së bashku, në një zinxhir.🔗
    ///
    /// [`once`] përdoret zakonisht për të përshtatur një vlerë të vetme në një zinxhir të llojeve të tjera të përsëritjes.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Meqenëse argumenti në `chain()` përdor [`IntoIterator`], ne mund të kalojmë gjithçka që mund të shndërrohet në një [`Iterator`], jo vetëm një [`Iterator`] vetë.
    /// Për shembull, fetat (`&[T]`) zbatojnë [`IntoIterator`], dhe kështu mund t'i kalohen `chain()` drejtpërdrejt:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nëse punoni me Windows API, mund të dëshironi ta shndërroni [`OsStr`] në `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zip lart' dy përsëritës në një përsëritës të vetëm të çifteve.
    ///
    /// `zip()` kthen një iterator të ri që do të përsëritet mbi dy përsëritës të tjerë, duke kthyer një tuple ku elementi i parë vjen nga iteratori i parë, dhe elementi i dytë vjen nga iteratori i dytë.
    ///
    ///
    /// Me fjalë të tjera, zipon dy përsëritës së bashku, në një të vetëm.
    ///
    /// Nëse cilido nga iteratorët kthen [`None`], [`next`] nga iteratori i zipuar do të kthejë [`None`].
    /// Nëse përsëritësi i parë kthen [`None`], `zip` do të lidhet me qark të shkurtër dhe `next` nuk do të thirret në përsëritësin e dytë.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Meqenëse argumenti në `zip()` përdor [`IntoIterator`], ne mund të kalojmë gjithçka që mund të shndërrohet në një [`Iterator`], jo vetëm një [`Iterator`] vetë.
    /// Për shembull, fetat (`&[T]`) zbatojnë [`IntoIterator`], dhe kështu mund t'i kalohen `zip()` drejtpërdrejt:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` përdoret shpesh për të ngjeshur një iterator të pafund në një të fundëm.
    /// Kjo funksionon sepse përsëritësi i fundëm përfundimisht do të kthejë [`None`], duke i dhënë fund zinxhirit.Mbërthimi me `(0..)` mund të duket shumë si [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Krijon një përsëritës të ri i cili vendos një kopje të `separator` midis artikujve ngjitur të përsëritësit origjinal.
    ///
    /// Në rast se `separator` nuk zbaton [`Clone`] ose duhet të llogaritet çdo herë, përdorni [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Elementi i parë nga `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ndarësi.
    /// assert_eq!(a.next(), Some(&1));   // Elementi tjetër nga `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ndarësi.
    /// assert_eq!(a.next(), Some(&2));   // Elementi i fundit nga `a`.
    /// assert_eq!(a.next(), None);       // Iteratori ka mbaruar.
    /// ```
    ///
    /// `intersperse` mund të jetë shumë e dobishme për t'u bashkuar me artikujt e një iteratori duke përdorur një element të përbashkët:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Krijon një përsëritës të ri i cili vendos një artikull të krijuar nga `separator` midis artikujve ngjitur të përsëritësit origjinal.
    ///
    /// Mbyllja do të thirret saktësisht një herë sa herë që një send vendoset midis dy sendeve ngjitur nga përsëritësi themelor;
    /// konkretisht, mbyllja nuk quhet nëse përsëritësi themelor jep më pak se dy artikuj dhe pasi jepet artikulli i fundit.
    ///
    ///
    /// Nëse artikulli i përsëritësit zbaton [`Clone`], mund të jetë më e lehtë të përdoret [`intersperse`].
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Elementi i parë nga `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ndarësi.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Elementi tjetër nga `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ndarësi.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Elementi i fundit nga nga `v`.
    /// assert_eq!(it.next(), None);               // Iteratori ka mbaruar.
    /// ```
    ///
    /// `intersperse_with` mund të përdoret në situata kur ndarësi duhet të llogaritet:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Mbyllja në mënyrë të paqëndrueshme huazon kontekstin e saj për të gjeneruar një artikull.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Merr një mbyllje dhe krijon një iterator i cili e quan atë mbyllje në secilin element.
    ///
    /// `map()` shndërron një përsëritës në një tjetër, me anë të argumentit të tij:
    /// diçka që zbaton [`FnMut`].Ai prodhon një iterator të ri i cili e quan këtë mbyllje në secilin element të iteratorit origjinal.
    ///
    /// Nëse jeni i mirë për të menduar në lloje, ju mund të mendoni për `map()` si kjo:
    /// Nëse keni një iterator që ju jep elemente të një lloji tjetër `A` dhe dëshironi një iterator të një lloji tjetër `B`, mund të përdorni `map()`, duke kaluar një mbyllje që merr një `A` dhe kthen një `B`.
    ///
    ///
    /// `map()` është konceptualisht i ngjashëm me një lak [`for`].Sidoqoftë, pasi `map()` është dembel, përdoret më mirë kur tashmë po punoni me përsëritës të tjerë.
    /// Nëse jeni duke bërë një lloj looping për një efekt anësor, konsiderohet më idiomatike të përdorni [`for`] sesa `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nëse jeni duke bërë një lloj efekti anësor, preferoni [`for`] në `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // mos e bëni këtë:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // as nuk do të ekzekutohet, pasi është dembel.Rust do t'ju paralajmërojë për këtë.
    ///
    /// // Në vend të kësaj, përdorni për:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Thërret mbylljen e secilit element të një iteratori.
    ///
    /// Kjo është ekuivalente me përdorimin e një lak [`for`] në përsëritësin, megjithëse `break` dhe `continue` nuk janë të mundshme nga mbyllja.
    /// Në përgjithësi është më idiomatike të përdorësh një lak `for`, por `for_each` mund të jetë më i lexueshëm kur përpunon artikuj në fund të zinxhirëve më të gjatë përsëritës.
    ///
    /// Në disa raste, `for_each` mund të jetë më shpejt se një lak, sepse do të përdorë përsëritje të brendshme në adaptorë si `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Për një shembull kaq të vogël, një lak `for` mund të jetë më i pastër, por `for_each` mund të jetë i preferueshëm për të mbajtur një stil funksional me përsëritës më të gjatë:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Krijon një iterator i cili përdor një mbyllje për të përcaktuar nëse duhet të jepet një element.
    ///
    /// Duke pasur parasysh një element mbyllja duhet të kthejë `true` ose `false`.Iteratori i kthyer do të japë vetëm elementët për të cilët mbyllja kthehet e vërtetë.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Për shkak se mbyllja e kaluar në `filter()` merr një referencë, dhe shumë përsëritës përsërisin mbi referencat, kjo çon në një situatë ndoshta konfuze, ku lloji i mbylljes është një referencë e dyfishtë:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // duhen dy *!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Commonshtë e zakonshme që në vend të kësaj të përdoret destruktimi në argument për të hequr një:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // të dy dhe *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ose te dyja:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dy &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// nga këto shtresa.
    ///
    /// Vini re se `iter.filter(f).next()` është ekuivalente me `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Krijon një iterator që filtron dhe harton.
    ///
    /// Iteratori i kthyer jep vetëm `vlerën` për të cilën mbyllja e furnizuar kthen `Some(value)`.
    ///
    /// `filter_map` mund të përdoret për të bërë zinxhirë të [`filter`] dhe [`map`] më konciz.
    /// Shembulli më poshtë tregon se si një `map().filter().map()` mund të shkurtohet në një telefonatë të vetme në `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Këtu është i njëjti shembull, por me [`filter`] dhe [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Krijon një iterator i cili jep numrin aktual të përsëritjes, si dhe vlerën tjetër.
    ///
    /// Iteratori i kthyer jep çiftet `(i, val)`, ku `i` është indeksi aktual i përsëritjes dhe `val` është vlera e kthyer nga iteratori.
    ///
    ///
    /// `enumerate()` mban numrin e saj si një [`usize`].
    /// Nëse doni të numëroni nga një numër i plotë me madhësi të ndryshme, funksioni [`zip`] siguron funksionalitet të ngjashëm.
    ///
    /// # Sjellja e tejmbushur
    ///
    /// Metoda nuk mbron nga mbingarkesat, kështu që numërimi i më shumë se elementeve [`usize::MAX`] prodhon rezultat të gabuar ose panics.
    /// Nëse pohimet e korrigjimeve janë të aktivizuara, një panic është e garantuar.
    ///
    /// # Panics
    ///
    /// Iteratori i kthyer mund të panic nëse indeksi që do të kthehet do të tejkalonte një [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Krijon një iterator i cili mund të përdorë [`peek`] për të parë elementin tjetër të iteratorit pa e konsumuar atë.
    ///
    /// Shton një metodë [`peek`] në një iterator.Shihni dokumentacionin e tij për më shumë informacion.
    ///
    /// Vini re se iteratori themelor është akoma i avancuar kur thirret [`peek`] për herë të parë: Në mënyrë që të rimarrë elementin tjetër, [`next`] thirret në iteratorin themelor, pra efektet anësore (dmth.
    ///
    /// do të ndodhë diçka tjetër përveç marrjes së vlerës tjetër) të metodës [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() na lejon të shohim në future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // ne mund të peek() shumë herë, iteratori nuk do të përparojë
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // pasi të ketë mbaruar përsëritësi, kështu është edhe peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Krijon një përsëritës që elementet e [`kapërcejë '' bazuar në një kallëzues.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` merr mbylljen si argument.Do ta thërrasë këtë mbyllje në secilin element të përsëritësit dhe do të injorojë elementet derisa të kthejë `false`.
    ///
    /// Pasi të kthehet `false`, puna `skip_while()`'s ka mbaruar dhe pjesa tjetër e elementeve jepet.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Për shkak se mbyllja e kaluar në `skip_while()` merr një referencë, dhe shumë përsëritës përsërisin mbi referencat, kjo çon në një situatë ndoshta konfuze, ku lloji i argumentit të mbylljes është një referencë e dyfishtë:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // duhen dy *!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ndalimi pas një `false` fillestare:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ndërsa kjo do të kishte qenë false, pasi që ne tashmë kemi një false, skip_while() nuk përdoret më
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Krijon një iterator që jep elemente bazuar në një kallëzues.
    ///
    /// `take_while()` merr mbylljen si argument.Do të thërrasë këtë mbyllje në secilin element të iteratorit, dhe do të japë elemente ndërsa kthen `true`.
    ///
    /// Pasi të kthehet `false`, puna `take_while()`'s ka mbaruar dhe pjesa tjetër e elementeve nuk merren parasysh.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Për shkak se mbyllja e kaluar në `take_while()` merr një referencë, dhe shumë përsëritës përsërisin mbi referencat, kjo çon në një situatë konfuze, ku lloji i mbylljes është një referencë e dyfishtë:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // duhen dy *!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ndalimi pas një `false` fillestare:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Kemi më shumë elementë që janë më pak se zero, por meqë tashmë kemi një false, take_while() nuk përdoret më
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Për shkak se `take_while()` duhet të shikojë vlerën për të parë nëse duhet të përfshihet apo jo, përsëritësit që konsumojnë do të shohin që ajo është hequr:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` nuk është më aty, sepse është konsumuar për të parë nëse përsëritja duhet të ndalet, por nuk është vendosur përsëri në përsëritës.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Krijon një iterator që të dy jep elemente bazuar në një kallëzues dhe harta.
    ///
    /// `map_while()` merr mbylljen si argument.
    /// Do të thërrasë këtë mbyllje në secilin element të iteratorit, dhe do të japë elemente ndërsa kthen [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Këtu është i njëjti shembull, por me [`take_while`] dhe [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ndalimi pas një [`None`] fillestare:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Kemi më shumë elementë që mund të përshtaten në u32 (4, 5), por `map_while` ktheu `None` për `-3` (pasi `predicate` ktheu `None`) dhe `collect` ndalet në `None` të parë të hasur.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Për shkak se `map_while()` duhet të shikojë vlerën për të parë nëse duhet të përfshihet apo jo, përsëritësit që konsumojnë do të shohin që ajo është hequr:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` nuk është më aty, sepse është konsumuar për të parë nëse përsëritja duhet të ndalet, por nuk është vendosur përsëri në përsëritës.
    ///
    /// Vini re se ndryshe nga [`take_while`] ky përsëritës **nuk është shkrirë**.
    /// Gjithashtu nuk specifikohet se çfarë kthen ky përsëritës pasi të kthehet [`None`] i parë.
    /// Nëse keni nevojë për përsëritës të shkrirë, përdorni [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Krijon një iterator që kapërcen elementët e parë `n`.
    ///
    /// Pasi të jenë konsumuar, pjesa tjetër e elementeve jepet.
    /// Në vend që të mbizotëroni këtë metodë direkt, në vend të kësaj anashkaloni metodën `nth`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Krijon një iterator që jep elementet e tij të parë `n`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` përdoret shpesh me një iterator të pafund, për ta bërë atë të fundme:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nëse janë në dispozicion më pak se elementë `n`, `take` do të kufizohet në madhësinë e përsëritësit themelor:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Një adaptor iterator i ngjashëm me [`fold`] që mban gjendje të brendshme dhe prodhon një iterator të ri.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` merr dy argumente: një vlerë fillestare që mbjell gjendjen e brendshme dhe një mbyllje me dy argumente, e para është një referencë e ndryshueshme për gjendjen e brendshme dhe e dyta një element përsëritës.
    ///
    /// Mbyllja mund t'i caktojë gjendjen e brendshme për të ndarë gjendjen midis përsëritjeve.
    ///
    /// Në përsëritje, mbyllja do të zbatohet për secilin element të përsëritësit dhe vlera e kthimit nga mbyllja, një [`Option`], jepet nga përsëritësi.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // çdo përsëritje, ne do të shumëzojmë gjendjen me elementin
    ///     *state = *state * x;
    ///
    ///     // atëherë, ne do të japim mohimin e shtetit
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Krijon një iterator që funksionon si hartë, por sheshon strukturën e vendosur.
    ///
    /// Përshtatësi [`map`] është shumë i dobishëm, por vetëm kur argumenti i mbylljes prodhon vlera.
    /// Nëse prodhon një iterator në vend, ekziston një shtresë shtesë indirektive.
    /// `flat_map()` do ta heqë vetë këtë shtresë shtesë.
    ///
    /// Ju mund të mendoni për `flat_map(f)` si ekuivalentin semantik të pingut [`map}], dhe më pas [` rrafshoj`] ing si në `map(f).flatten()`.
    ///
    /// Një mënyrë tjetër e të menduarit rreth `flat_map()`: mbyllja e ["map"] kthen një artikull për secilin element, dhe mbyllja `flat_map()`'s kthen një iterator për secilin element.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() kthen një përsëritës
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Krijon një iterator që sheshon strukturën e vendosur.
    ///
    /// Kjo është e dobishme kur keni një përsëritës të përsëritësve ose një përsëritës të gjërave që mund të shndërrohen në përsëritës dhe doni të hiqni një nivel të indirektit.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Hartimi dhe më pas rrafshimi:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() kthen një përsëritës
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Ju gjithashtu mund ta rishkruani këtë në terma të [`flat_map()`], e cila është e preferueshme në këtë rast pasi që përcjell qëllimin më qartë:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() kthen një përsëritës
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Rrafshimi heq vetëm një nivel foleje në të njëjtën kohë:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Këtu shohim që `flatten()` nuk kryen një rrafshim "deep".
    /// Në vend të kësaj, hiqet vetëm një nivel folezimi.Kjo është, nëse `flatten()` keni një koleksion tre-dimensional, rezultati do të jetë dy-dimensional dhe jo një-dimensional.
    /// Për të marrë një strukturë një-dimensionale, duhet të `flatten()` përsëri.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Krijon një iterator i cili përfundon pas [`None`] të parë.
    ///
    /// Pas kthimit të një përsëritësi [`None`], thirrjet future mund ose nuk japin [`Some(T)`] përsëri.
    /// `fuse()` përshtat një iterator, duke siguruar që pasi të jepet një [`None`], ai gjithmonë do të kthejë [`None`] përgjithmonë.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // një iterator i cili alternohet midis Disa dhe Asnjë
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // nëse është madje, Some(i32), tjetër Asnjë
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // ne mund ta shohim iteratorin tonë duke shkuar para dhe prapa
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // megjithatë, sapo ta bashkojmë atë ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // gjithmonë do të kthehet `None` pas herës së parë.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Bën diçka me secilin element të një iteratori, duke kaluar vlerën.
    ///
    /// Kur përdorni përsëritës, shpesh do të lidhni disa prej tyre së bashku.
    /// Ndërsa punoni për një kod të tillë, ju mund të dëshironi të shikoni se çfarë po ndodh në pjesë të ndryshme në tubacion.Për ta bërë këtë, futni një telefonatë në `inspect()`.
    ///
    /// Moreshtë më e zakonshme që `inspect()` të përdoret si një mjet korrigjimi se sa të ekzistojë në kodin tuaj përfundimtar, por aplikacionet mund ta konsiderojnë të dobishme në situata të caktuara kur gabimet duhet të regjistrohen para se të hidhen.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // kjo sekuencë përsëritëse është komplekse.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // le të shtojmë disa thirrje inspect() për të hetuar se çfarë po ndodh
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Kjo do të shtypë:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Gabimet e regjistrimit para se t'i hidhni ato:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Kjo do të shtypë:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Merr një iterator, në vend që ta konsumojë atë.
    ///
    /// Kjo është e dobishme për të lejuar aplikimin e adaptorëve të iteratorit duke mbajtur ende pronësinë e iteratorit origjinal.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // nëse përpiqemi ta përdorim përsëri iter, nuk do të funksionojë.
    /// // Rreshti i mëposhtëm jep "gabim: përdorimi i vlerës së lëvizur: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // le ta provojmë përsëri
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // në vend të kësaj, ne shtojmë një .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // tani kjo është në rregull:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transformon një iterator në një koleksion.
    ///
    /// `collect()` mund të marrë gjithçka të dobishme dhe ta kthejë atë në një koleksion përkatës.
    /// Kjo është një nga metodat më të fuqishme në bibliotekën standarde, e përdorur në një larmi kontekstesh.
    ///
    /// Modeli më themelor në të cilin përdoret `collect()` është kthimi i një koleksioni në një tjetër.
    /// Ju merrni një koleksion, telefononi [`iter`] në të, bëni një bandë transformimesh dhe pastaj `collect()` në fund.
    ///
    /// `collect()` gjithashtu mund të krijojë shembuj të llojeve që nuk janë koleksione tipike.
    /// Për shembull, një [`String`] mund të ndërtohet nga [`char`] s, dhe një përsëritës i artikujve [`Result<T, E>`][`Result`] mund të mblidhet në `Result<Collection<T>, E>`.
    ///
    /// Shihni shembujt më poshtë për më shumë.
    ///
    /// Për shkak se `collect()` është kaq i përgjithshëm, mund të shkaktojë probleme me përfundimin e tipit.
    /// Si i tillë, `collect()` është një nga të paktat herë që do të shihni sintaksën e njohur me dashuri si 'turbofish': `::<>`.
    /// Kjo ndihmon algoritmin e konkluzionit të kuptojë në veçanti se në cilin koleksion po përpiqeni të mbledhni.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Vini re se na duhej `: Vec<i32>` në anën e majtë.Kjo është për shkak se ne mund të mbledhim, për shembull, një [`VecDeque<T>`] në vend:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Përdorni 'turbofish' në vend që të shënoni `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Meqenëse `collect()` kujdeset vetëm për atë që po grumbulloni, përsëri mund të përdorni një aluzion të tipit të pjesshëm, `_`, me turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Përdorni `collect()` për të bërë një [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Nëse keni një listë të [Rezultati<T, E>"][" Rezultati "] s, ju mund të përdorni `collect()` për të parë nëse ndonjë prej tyre dështoi:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // na jep gabimin e parë
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // na jep listën e përgjigjeve
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Konsumon një iterator, duke krijuar dy koleksione prej tij.
    ///
    /// Kallëzuesi i kaluar në `partition()` mund të kthejë `true`, ose `false`.
    /// `partition()` kthen një palë, të gjithë elementët për të cilët ktheu `true` dhe të gjithë elementët për të cilët ktheu `false`.
    ///
    ///
    /// Shihni gjithashtu [`is_partitioned()`] dhe [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Rendit elementet e këtij iteratori *në vend* sipas kallëzuesit të dhënë, i tillë që të gjithë ata që kthejnë `true` u paraprijnë të gjithë atyre që kthejnë `false`.
    ///
    /// Kthen numrin e elementeve `true` të gjetura.
    ///
    /// Rendi relativ i artikujve të ndarë nuk mbahet.
    ///
    /// Shihni gjithashtu [`is_partitioned()`] dhe [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Ndarja në vend midis çifteve dhe mosmarrëveshjeve
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: a duhet të shqetësohemi për tejkalimin e numërimit?Mënyra e vetme për të pasur më shumë se
        // `usize::MAX` referencat e ndryshueshme janë me ZST, të cilat nuk janë të dobishme për ndarjen ...

        // Këto funksione mbyllëse "factory" ekzistojnë për të shmangur gjeneritetin në `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Gjeni në mënyrë të përsëritur `false` të parë dhe ndërroni atë me `true` të fundit.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Kontrollon nëse elementët e këtij iteratori janë të ndarë sipas kallëzuesit të dhënë, i tillë që të gjithë ata që kthejnë `true` paraprijnë të gjithë ata që kthejnë `false`.
    ///
    ///
    /// Shihni gjithashtu [`partition()`] dhe [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Ose të gjithë artikujt testojnë `true`, ose klauzola e parë ndalet në `false` dhe ne kontrollojmë që të mos ketë më artikuj `true` pas kësaj.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Një metodë iterator që zbaton një funksion për sa kohë që kthehet me sukses, duke prodhuar një vlerë të vetme, përfundimtare.
    ///
    /// `try_fold()` merr dy argumente: një vlerë fillestare dhe një mbyllje me dy argumente: një 'accumulator' dhe një element.
    /// Mbyllja ose kthehet me sukses, me vlerën që duhet të ketë akumuluesi për përsëritjen tjetër, ose kthen dështimin, me një vlerë gabimi që përhapet përsëri në telefonues menjëherë (short-circuiting).
    ///
    ///
    /// Vlera fillestare është vlera që akumuluesi do të ketë në telefonatën e parë.Nëse aplikimi i mbylljes ka pasur sukses kundër çdo elementi të përsëritësit, `try_fold()` kthen akumuluesin përfundimtar si sukses.
    ///
    /// Palosja është e dobishme sa herë që keni një koleksion të diçkaje, dhe doni të prodhoni një vlerë të vetme prej saj.
    ///
    /// # Shënim për Zbatuesit
    ///
    /// Disa nga metodat e tjera (forward) kanë implementime të paracaktuara për sa i përket kësaj, prandaj përpiquni ta zbatoni në mënyrë të qartë nëse mund të bëjë diçka më mirë sesa implementimi i paracaktuar i lakut `for`.
    ///
    /// Veçanërisht, përpiquni ta keni këtë thirrje `try_fold()` në pjesët e brendshme nga të cilat përbëhet ky përsëritës.
    /// Nëse nevojiten thirrje të shumta, operatori `?` mund të jetë i përshtatshëm për të lidhur zinxhirin e vlerës së akumulatorit, por kini kujdes çdo ndryshimi që duhet të mbahet përpara atyre kthimeve të hershme.
    /// Kjo është një metodë `&mut self`, kështu që përsëritja duhet të rifillojë pasi të keni goditur një gabim këtu.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // shuma e kontrolluar e të gjithë elementëve të grupit
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Kjo shumë tejmbush kur shtohet elementi 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Për shkak se qarku i shkurtër, elementët e mbetur janë ende në dispozicion përmes përsëritësit.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Një metodë iterator që zbaton një funksion të gabueshëm për secilin artikull në iterator, duke ndaluar në gabimin e parë dhe duke e kthyer atë gabim.
    ///
    ///
    /// Kjo gjithashtu mund të mendohet si formë e gabueshme e [`for_each()`] ose si version pa shtetësi i [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // U lidh në qark të shkurtër, kështu që artikujt e mbetur janë akoma në përsëritës:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Palos çdo element në një akumulator duke aplikuar një operacion, duke kthyer rezultatin përfundimtar.
    ///
    /// `fold()` merr dy argumente: një vlerë fillestare dhe një mbyllje me dy argumente: një 'accumulator' dhe një element.
    /// Mbyllja kthen vlerën që duhet të ketë akumuluesi për përsëritjen tjetër.
    ///
    /// Vlera fillestare është vlera që akumuluesi do të ketë në telefonatën e parë.
    ///
    /// Pas aplikimit të kësaj mbylljeje për çdo element të përsëritësit, `fold()` kthen akumulatorin.
    ///
    /// Ky operacion nganjëherë quhet 'reduce' ose 'inject'.
    ///
    /// Palosja është e dobishme sa herë që keni një koleksion të diçkaje, dhe doni të prodhoni një vlerë të vetme prej saj.
    ///
    /// Note: `fold()`, dhe metoda të ngjashme që përshkojnë të gjithë përsëritësin, mund të mos përfundojnë për përsëritës të pafund, madje edhe në traits për të cilat një rezultat është i përcaktueshëm në kohë të fundme.
    ///
    /// Note: [`reduce()`] mund të përdoret për të përdorur elementin e parë si vlerë fillestare, nëse lloji i akumulatorit dhe lloji i artikullit janë të njëjtë.
    ///
    /// # Shënim për Zbatuesit
    ///
    /// Disa nga metodat e tjera (forward) kanë implementime të paracaktuara për sa i përket kësaj, prandaj përpiquni ta zbatoni në mënyrë të qartë nëse mund të bëjë diçka më mirë sesa implementimi i paracaktuar i lakut `for`.
    ///
    ///
    /// Në veçanti, përpiquni ta keni këtë thirrje `fold()` në pjesët e brendshme nga të cilat është krijuar ky përsëritës.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // shuma e të gjithë elementëve të grupit
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Le të ndjekim secilin hap të përsëritjes këtu:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Dhe kështu, rezultati ynë përfundimtar, `6`.
    ///
    /// Commonshtë e zakonshme për njerëzit që nuk kanë përdorur përsëritës shumë të përdorin një lak `for` me një listë të gjërave për të krijuar një rezultat.Ato mund të shndërrohen në `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // për lak:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // jane te njejtat
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Redukton elementet në një të vetme, duke aplikuar në mënyrë të përsëritur një veprim reduktues.
    ///
    /// Nëse përsëritësi është bosh, kthen [`None`];përndryshe, kthen rezultatin e zvogëlimit.
    ///
    /// Për përsëritësit me të paktën një element, kjo është e njëjtë me [`fold()`] me elementin e parë të iteratorit si vlerën fillestare, duke palosur çdo element pasues në të.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Gjeni vlerën maksimale:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Teston nëse çdo element i përsëritësit përputhet me një kallëzues.
    ///
    /// `all()` merr një mbyllje që kthen `true` ose `false`.Zbaton këtë mbyllje për secilin element të përsëritësit, dhe nëse të gjithë kthejnë `true`, atëherë edhe `all()`.
    /// Nëse ndonjëri prej tyre kthen `false`, ai kthen `false`.
    ///
    /// `all()` është qark i shkurtër;me fjalë të tjera, ai do të ndalojë përpunimin sa më shpejt që të gjejë një `false`, duke pasur parasysh se pa marrë parasysh se çfarë ndodh tjetër, rezultati do të jetë gjithashtu `false`.
    ///
    ///
    /// Një përsëritës bosh kthen `true`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Ndalimi në `false` i parë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // ne ende mund të përdorim `iter`, pasi ka më shumë elemente.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Teston nëse ndonjë element i iteratorit përputhet me një kallëzues.
    ///
    /// `any()` merr një mbyllje që kthen `true` ose `false`.Zbaton këtë mbyllje për secilin element të përsëritësit, dhe nëse ndonjëri prej tyre kthen `true`, atëherë edhe `any()`.
    /// Nëse të gjithë kthejnë `false`, ajo kthen `false`.
    ///
    /// `any()` është qark i shkurtër;me fjalë të tjera, ai do të ndalojë përpunimin sa më shpejt që të gjejë një `true`, duke pasur parasysh se pa marrë parasysh se çfarë ndodh tjetër, rezultati do të jetë gjithashtu `true`.
    ///
    ///
    /// Një përsëritës bosh kthen `false`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Ndalimi në `true` i parë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // ne ende mund të përdorim `iter`, pasi ka më shumë elemente.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Kërkon një element të një iteratori që plotëson një kallëzues.
    ///
    /// `find()` merr një mbyllje që kthen `true` ose `false`.
    /// Zbaton këtë mbyllje për secilin element të përsëritësit, dhe nëse ndonjëri prej tyre kthen `true`, atëherë `find()` kthen [`Some(element)`].
    /// Nëse të gjithë kthejnë `false`, ajo kthen [`None`].
    ///
    /// `find()` është qark i shkurtër;me fjalë të tjera, ai do të ndalojë përpunimin sa më shpejt që mbyllja të kthehet `true`.
    ///
    /// Për shkak se `find()` merr një referencë, dhe shumë përsëritës përsërisin mbi referencat, kjo çon në një situatë ndoshta konfuze kur argumenti është një referencë e dyfishtë.
    ///
    /// Këtë efekt mund ta shihni në shembujt më poshtë, me `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Ndalimi në `true` i parë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // ne ende mund të përdorim `iter`, pasi ka më shumë elemente.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Vini re se `iter.find(f)` është ekuivalente me `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Zbaton funksionin në elementet e iteratorit dhe kthen rezultatin e parë pa asnjë.
    ///
    ///
    /// `iter.find_map(f)` është ekuivalente me `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Zbaton funksionin në elementet e iteratorit dhe kthen rezultatin e parë të vërtetë ose gabimin e parë.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Kërkon një element në një iterator, duke kthyer indeksin e tij.
    ///
    /// `position()` merr një mbyllje që kthen `true` ose `false`.
    /// Zbaton këtë mbyllje për secilin element të iteratorit, dhe nëse njëri prej tyre kthen `true`, atëherë `position()` kthen [`Some(index)`].
    /// Nëse të gjithë kthejnë `false`, ajo kthen [`None`].
    ///
    /// `position()` është qark i shkurtër;me fjalë të tjera, ai do të ndalojë përpunimin sa më shpejt që të gjejë një `true`.
    ///
    /// # Sjellja e tejmbushur
    ///
    /// Metoda nuk mbron nga mbingarkesat, kështu që nëse ka më shumë se elementë [`usize::MAX`] që nuk përputhen, ose prodhon rezultat të gabuar ose panics.
    ///
    /// Nëse pohimet e korrigjimeve janë të aktivizuara, një panic është e garantuar.
    ///
    /// # Panics
    ///
    /// Ky funksion mund të jetë panic nëse iteratori ka më shumë se `usize::MAX` elementë që nuk përputhen.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Ndalimi në `true` i parë:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // ne ende mund të përdorim `iter`, pasi ka më shumë elemente.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Indeksi i kthyer varet nga gjendja e përsëritësit
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Kërkon një element në një iterator nga e djathta, duke kthyer indeksin e tij.
    ///
    /// `rposition()` merr një mbyllje që kthen `true` ose `false`.
    /// Zbaton këtë mbyllje për secilin element të iteratorit, duke filluar nga fundi, dhe nëse njëri prej tyre kthen `true`, atëherë `rposition()` kthen [`Some(index)`].
    ///
    /// Nëse të gjithë kthejnë `false`, ajo kthen [`None`].
    ///
    /// `rposition()` është qark i shkurtër;me fjalë të tjera, ai do të ndalojë përpunimin sa më shpejt që të gjejë një `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Ndalimi në `true` i parë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // ne ende mund të përdorim `iter`, pasi ka më shumë elemente.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Nuk ka nevojë për një kontroll të tejmbushjes këtu, sepse `ExactSizeIterator` nënkupton që numri i elementeve përshtatet në një `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Kthen elementin maksimal të një iteratori.
    ///
    /// Nëse disa elemente janë maksimalisht të barabartë, elementi i fundit kthehet.
    /// Nëse përsëritësi është bosh, [`None`] kthehet.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Kthen elementin minimal të një iteratori.
    ///
    /// Nëse disa elemente janë njësoj minimale, elementi i parë kthehet.
    /// Nëse përsëritësi është bosh, [`None`] kthehet.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Kthen elementin që jep vlerën maksimale nga funksioni i specifikuar.
    ///
    ///
    /// Nëse disa elemente janë maksimalisht të barabartë, elementi i fundit kthehet.
    /// Nëse përsëritësi është bosh, [`None`] kthehet.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Kthen elementin që jep vlerën maksimale në lidhje me funksionin e specifikuar të krahasimit.
    ///
    ///
    /// Nëse disa elemente janë maksimalisht të barabartë, elementi i fundit kthehet.
    /// Nëse përsëritësi është bosh, [`None`] kthehet.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Kthen elementin që jep vlerën minimale nga funksioni i specifikuar.
    ///
    ///
    /// Nëse disa elemente janë njësoj minimale, elementi i parë kthehet.
    /// Nëse përsëritësi është bosh, [`None`] kthehet.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Kthen elementin që jep vlerën minimale në lidhje me funksionin e specifikuar të krahasimit.
    ///
    ///
    /// Nëse disa elemente janë njësoj minimale, elementi i parë kthehet.
    /// Nëse përsëritësi është bosh, [`None`] kthehet.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Ndryshon drejtimin e një iteratori.
    ///
    /// Zakonisht, përsëritësit përsëriten nga e majta në të djathtë.
    /// Pas përdorimit të `rev()`, një iterator do të përsëritet nga e djathta në të majtë.
    ///
    /// Kjo është e mundur vetëm nëse përsëritësi ka një fund, kështu që `rev()` punon vetëm në ["DoubleEndedIterator"].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Shndërron një iterator të çifteve në një palë kontejnerë.
    ///
    /// `unzip()` konsumon një përsëritës të plotë të çifteve, duke prodhuar dy koleksione: një nga elementët e majtë të çifteve dhe një nga elementët e duhur.
    ///
    ///
    /// Ky funksion është, në një farë kuptimi, e kundërta e [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Krijon një iterator i cili kopjon të gjithë elementët e tij.
    ///
    /// Kjo është e dobishme kur keni një përsëritës mbi `&T`, por keni nevojë për një përsëritës mbi `T`.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopjuar është e njëjtë me .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Krijon një iterator i cili ['klon'] s të gjithë elementët e tij.
    ///
    /// Kjo është e dobishme kur keni një përsëritës mbi `&T`, por keni nevojë për një përsëritës mbi `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // i klonuar është i njëjtë me .map(|&x| x), për numrat e plotë
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Përsërit një iterator pa fund.
    ///
    /// Në vend që të ndalet në [`None`], iteratori do të fillojë përsëri, nga fillimi.Pasi të përsëritet përsëri, do të fillojë përsëri në fillim.Dhe perseri.
    /// Dhe perseri.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Përmbledh elementet e një përsëritësi.
    ///
    /// Merr secilin element, i mbledh bashkë dhe kthen rezultatin.
    ///
    /// Një iterator bosh kthen vlerën zero të llojit.
    ///
    /// # Panics
    ///
    /// Kur thirrni `sum()` dhe po kthehet një tip i plotë primitiv, kjo metodë do të panic nëse llogaritja tejkalon dhe pohimet e korrigjimit janë të aktivizuara.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Përsëritet mbi të gjithë përsëritësin, duke shumëzuar të gjithë elementët
    ///
    /// Një iterator i zbrazët kthen një vlerë të tipit.
    ///
    /// # Panics
    ///
    /// Kur thirrni `product()` dhe po kthehet një tip i plotë primitiv, metoda do të panic nëse llogaritja tejkalon dhe pohimet e korrigjimit janë të aktivizuara.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) krahason elementet e këtij [`Iterator`] me ato të një tjetri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) krahason elementet e këtij [`Iterator`] me ato të një tjetri në lidhje me funksionin e specifikuar të krahasimit.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) krahason elementet e këtij [`Iterator`] me ato të një tjetri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) krahason elementet e këtij [`Iterator`] me ato të një tjetri në lidhje me funksionin e specifikuar të krahasimit.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Përcakton nëse elementët e këtij [`Iterator`] janë të barabartë me ato të një tjetri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Përcakton nëse elementët e këtij [`Iterator`] janë të barabartë me ato të një tjetri në lidhje me funksionin e specifikuar të barazisë.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Përcakton nëse elementët e këtij [`Iterator`] janë të pabarabartë me ato të një tjetri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Përcakton nëse elementet e këtij [`Iterator`] janë [lexicographically](Ord#lexicographical-comparison) më pak se ato të një tjetri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Përcakton nëse elementët e këtij [`Iterator`] janë [lexicographically](Ord#lexicographical-comparison) më pak ose të barabartë me ato të një tjetri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Përcakton nëse elementet e këtij [`Iterator`] janë [lexicographically](Ord#lexicographical-comparison) më të mëdha se ato të një tjetri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Përcakton nëse elementet e këtij [`Iterator`] janë [lexicographically](Ord#lexicographical-comparison) më të mëdha ose të barabarta me ato të një tjetri.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Kontrollon nëse elementet e këtij iteratori janë të renditur.
    ///
    /// Kjo do të thotë, për secilin element `a` dhe elementin e tij vijues `b`, `a <= b` duhet të mbajë.Nëse iteratori jep saktësisht zero ose një element, `true` kthehet.
    ///
    /// Vini re se nëse `Self::Item` është vetëm `PartialOrd`, por jo `Ord`, përkufizimi i mësipërm nënkupton që ky funksion kthen `false` nëse ndonjë prej dy artikujve radhazi nuk janë të krahasueshëm.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Kontrollon nëse elementet e këtij iteratori renditen duke përdorur funksionin e dhënë krahasues.
    ///
    /// Në vend që të përdorë `PartialOrd::partial_cmp`, ky funksion përdor funksionin e dhënë `compare` për të përcaktuar renditjen e dy elementeve.
    /// Përveç kësaj, është ekuivalente me [`is_sorted`];shikoni dokumentacionin e tij për më shumë informacion.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Kontrollon nëse elementet e këtij iteratori renditen duke përdorur funksionin e dhënë të nxjerrjes së çelësit.
    ///
    /// Në vend që të krahasojë drejtpërdrejt elementet e iteratorit, ky funksion krahason çelësat e elementeve, siç përcaktohet nga `f`.
    /// Përveç kësaj, është ekuivalente me [`is_sorted`];shikoni dokumentacionin e tij për më shumë informacion.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Shihni [TrustedRandomAccess]
    // Emri i pazakontë është të shmangni përplasjet e emrave në zgjidhjen e metodës shih #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}