use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Ky trait siguron qasje kalimtare në fazën e burimit në një tubacion integrues-përshtatës në kushtet që
/// * vetë burimi iterator `S` zbaton `SourceIter<Source = S>`
/// * ekziston një implementim delegues i këtij trait për secilin përshtatës në tubacion midis burimit dhe konsumatorit të tubacionit.
///
/// Kur burimi është një strukturë zotëruese e iteratorit (e quajtur zakonisht `IntoIter`) atëherë kjo mund të jetë e dobishme për specializimin e implementimeve [`FromIterator`] ose rikuperimin e elementeve të mbetura pasi një iterator të jetë shteruar pjesërisht.
///
///
/// Vini re se implementimet nuk kanë domosdoshmërisht nevojë për të siguruar hyrjen në burimin më të brendshëm të një tubacioni.Një përshtatës i ndërmjetëm shtetëror mund të vlerësojë me padurim një pjesë të tubacionit dhe të ekspozojë deponimin e tij të brendshëm si burim.
///
/// trait është i pasigurt sepse zbatuesit duhet të mbajnë vetitë shtesë të sigurisë.
/// Shihni [`as_inner`] për detaje.
///
/// # Examples
///
/// Marrja e një burimi pjesërisht të konsumuar:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Një fazë burimi në një tubacion iterator.
    type Source: Iterator;

    /// Merrni burimin e një tubacioni iterator.
    ///
    /// # Safety
    ///
    /// Zbatimet e duhet të kthejnë të njëjtën referencë të ndryshueshme për jetën e tyre, përveç nëse zëvendësohen nga një telefonues.
    /// Telefonuesit mund të zëvendësojnë referencën vetëm kur ndalojnë përsëritjen dhe heqin tubacionin iterator pas nxjerrjes së burimit.
    ///
    /// Kjo do të thotë që adaptorët iteratorë mund të mbështeten tek burimi që nuk ndryshon gjatë përsëritjes, por ata nuk mund të mbështeten tek ai në implementimet e tyre Drop.
    ///
    /// Zbatimi i kësaj metode do të thotë që adaptuesit të heqin dorë nga hyrja vetëm në burimin e tyre dhe mund të mbështeten vetëm në garancitë e bëra bazuar në llojet e marrësve të metodës.
    /// Mungesa e aksesit të kufizuar gjithashtu kërkon që adaptuesit të mbështesin API-në publike të burimit edhe kur ata kanë qasje në brendësi të tij.
    ///
    /// Telefonuesit nga ana e tyre duhet të presin që burimi të jetë në çdo gjendje që është në përputhje me API-në e tij publike pasi adaptorët që qëndrojnë midis tij dhe burimit kanë të njëjtën qasje.
    /// Në veçanti një përshtatës mund të ketë konsumuar më shumë elemente sesa është e nevojshme rreptësisht.
    ///
    /// Qëllimi i përgjithshëm i këtyre kërkesave është të lejojnë konsumatorin të përdorë një tubacion
    /// * çfarëdo që mbetet në burim pasi të jetë ndalur përsëritja
    /// * memoria që është bërë e papërdorur duke avancuar një përsëritës konsumues
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Një adaptor iterator që prodhon dalje për sa kohë që iteratori themelor prodhon vlera `Result::Ok`.
///
///
/// Nëse haset një gabim, iteratori ndalet dhe gabimi ruhet.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Përpunoni iteratorin e dhënë sikur të jepte një `T` në vend të një `Result<T, _>`.
/// Çdo gabim do të ndalojë iteratorin e brendshëm dhe rezultati i përgjithshëm do të jetë një gabim.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}