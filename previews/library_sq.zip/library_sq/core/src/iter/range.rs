use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Objekte që kanë një nocion të operacioneve *pasardhës* dhe *paraardhës*.
///
/// Operacioni *pasardhës* lëviz drejt vlerave që krahasohen më shumë.
/// Operacioni *paraardhësi* lëviz drejt vlerave që krahasohen më pak.
///
/// # Safety
///
/// Ky trait është `unsafe` sepse zbatimi i tij duhet të jetë korrekt për sigurinë e implementimeve `unsafe trait TrustedLen` dhe rezultatet e përdorimit të këtij trait përndryshe mund të besohen nga kodi `unsafe` për të qenë korrekt dhe për të përmbushur detyrimet e renditura.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Kthen numrin e hapave *pasardhës* të kërkuar për të kaluar nga `start` në `end`.
    ///
    /// Kthen `None` nëse numri i hapave do të tejkalonte `usize` (ose është i pafund, ose nëse `end` nuk do të arrihej kurrë).
    ///
    ///
    /// # Invariants
    ///
    /// Për çdo `a`, `b` dhe `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` nëse dhe vetëm nëse `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` nëse dhe vetëm nëse `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` vetëm nëse `a <= b`
    ///   * Përfundim: `steps_between(&a, &b) == Some(0)` nëse dhe vetëm nëse `a == b`
    ///   * Vini re se `a <= b` nënkupton _not_ `steps_between(&a, &b) != None`;
    ///     ky është rasti kur do të duheshin më shumë se hapa `usize::MAX` për të arritur në `b`
    /// * `steps_between(&a, &b) == None` nëse `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Kthen vlerën që do të merret duke marrë *pasardhësin* e `self` `count` herë.
    ///
    /// Nëse kjo do të tejkalonte gamën e vlerave të mbështetura nga `Self`, kthen `None`.
    ///
    /// # Invariants
    ///
    /// Për çdo `a`, `n` dhe `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Për çdo `a`, `n` dhe `m` ku `n + m` nuk tejmbush:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Për çdo `a` dhe `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Kthen vlerën që do të merret duke marrë *pasardhësin* e `self` `count` herë.
    ///
    /// Nëse kjo do të tejkalonte gamën e vlerave të mbështetura nga `Self`, ky funksion lejohet të panic, të mbështjellë ose të ngopet.
    ///
    /// Sjellja e sugjeruar është të panic kur janë të mundshme pohimet e korrigjimeve, dhe të mbështillet ose të ngopet ndryshe.
    ///
    /// Kodi i pasigurt nuk duhet të mbështetet në korrektësinë e sjelljes pas tejmbushjes.
    ///
    /// # Invariants
    ///
    /// Për çdo `a`, `n` dhe `m`, ku nuk ka mbingarkesë:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Për çdo `a` dhe `n`, ku nuk ka mbingarkesë:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Kthen vlerën që do të merret duke marrë *pasardhësin* e `self` `count` herë.
    ///
    /// # Safety
    ///
    /// Behaviorshtë një sjellje e papërcaktuar që ky operacion të tejkalojë gamën e vlerave të mbështetura nga `Self`.
    /// Nëse nuk mund të garantoni se kjo nuk do të vërshojë, përdorni në vend të tyre `forward` ose `forward_checked`.
    ///
    /// # Invariants
    ///
    /// Për çdo `a`:
    ///
    /// * nëse ekziston `b` i tillë që `b > a`, është e sigurt të telefononi `Step::forward_unchecked(a, 1)`
    /// * nëse ekziston `b`, `n` i tillë që `steps_between(&a, &b) == Some(n)`, është e sigurt të telefononi `Step::forward_unchecked(a, m)` për çdo `m <= n`.
    ///
    ///
    /// Për çdo `a` dhe `n`, ku nuk ka mbingarkesë:
    ///
    /// * `Step::forward_unchecked(a, n)` është ekuivalente me `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Kthen vlerën që do të merret duke marrë *paraardhësin* e `self` `count` herë.
    ///
    /// Nëse kjo do të tejkalonte gamën e vlerave të mbështetura nga `Self`, kthen `None`.
    ///
    /// # Invariants
    ///
    /// Për çdo `a`, `n` dhe `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Për çdo `a` dhe `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Kthen vlerën që do të merret duke marrë *paraardhësin* e `self` `count` herë.
    ///
    /// Nëse kjo do të tejkalonte gamën e vlerave të mbështetura nga `Self`, ky funksion lejohet të panic, të mbështjellë ose të ngopet.
    ///
    /// Sjellja e sugjeruar është të panic kur janë të mundshme pohimet e korrigjimeve, dhe të mbështillet ose të ngopet ndryshe.
    ///
    /// Kodi i pasigurt nuk duhet të mbështetet në korrektësinë e sjelljes pas tejmbushjes.
    ///
    /// # Invariants
    ///
    /// Për çdo `a`, `n` dhe `m`, ku nuk ka mbingarkesë:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Për çdo `a` dhe `n`, ku nuk ka mbingarkesë:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Kthen vlerën që do të merret duke marrë *paraardhësin* e `self` `count` herë.
    ///
    /// # Safety
    ///
    /// Behaviorshtë një sjellje e papërcaktuar që ky operacion të tejkalojë gamën e vlerave të mbështetura nga `Self`.
    /// Nëse nuk mund të garantoni se kjo nuk do të vërshojë, përdorni në vend të tyre `backward` ose `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Për çdo `a`:
    ///
    /// * nëse ekziston `b` i tillë që `b < a`, është e sigurt të telefononi `Step::backward_unchecked(a, 1)`
    /// * nëse ekziston `b`, `n` i tillë që `steps_between(&b, &a) == Some(n)`, është e sigurt të telefononi `Step::backward_unchecked(a, m)` për çdo `m <= n`.
    ///
    ///
    /// Për çdo `a` dhe `n`, ku nuk ka mbingarkesë:
    ///
    /// * `Step::backward_unchecked(a, n)` është ekuivalente me `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Këto janë akoma të krijuara makro sepse fjalët e plota të plota zgjidhen në lloje të ndryshme.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // SIGURIA: thirrësi duhet të garantojë që `start + n` të mos tejkalojë.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // SIGURIA: thirrësi duhet të garantojë që `start - n` të mos tejkalojë.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // Në ndërtimet e korrigjimeve, aktivizoni një panic në tejmbushje.
            // Kjo duhet të zgjedh plotësisht në ndërtimet e lëshimit.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Bëni matematikë mbështjellëse për të lejuar p.sh. `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // Në ndërtimet e korrigjimeve, aktivizoni një panic në tejmbushje.
            // Kjo duhet të zgjedh plotësisht në ndërtimet e lëshimit.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Bëni matematikë mbështjellëse për të lejuar p.sh. `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Kjo mbështetet në $u_narrower <=përdor
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // nëse n është jashtë rrezes, `unsigned_start + n` është gjithashtu
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // nëse n është jashtë rrezes, `unsigned_start - n` është gjithashtu
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Kjo mbështetet në $i_narrower <=përdor
                        //
                        // Hedhja për të izoluar shtrin gjerësinë por ruan shenjën.
                        // Përdorni wrapping_sub në hapësirën e izolimit dhe hidhni për të përdorur për të llogaritur ndryshimin që mund të mos përshtatet brenda intervalit të izizimit.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Mbështjellja merret me raste si `Step::forward(-120_i8, 200) == Some(80_i8)`, edhe pse 200 është jashtë rrezes për i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Shtesa u tejmbush
                            }
                        }
                        // Nëse n është jashtë rrezes së p.sh.
                        // u8, atëherë është më e madhe se e gjithë diapazoni për i8 është i gjerë kështu që `any_i8 + n` domosdoshmërisht tejmbush i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Mbështjellja merret me raste si `Step::forward(-120_i8, 200) == Some(80_i8)`, edhe pse 200 është jashtë rrezes për i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Zbritja tejmbushur
                            }
                        }
                        // Nëse n është jashtë rrezes së p.sh.
                        // u8, atëherë është më e madhe se e gjithë diapazoni për i8 është i gjerë kështu që `any_i8 - n` domosdoshmërisht tejmbush i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Nëse ndryshimi është shumë i madh p.sh.
                            // i128, do të jetë gjithashtu shumë e madhe për t'u përdorur me më pak bit.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // SIGURIA: res është një sklar i vlefshëm unikod
            // (poshtë 0x110000 dhe jo në 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // SIGURIA: res është një sklar i vlefshëm unikod
        // (poshtë 0x110000 dhe jo në 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SIGURIA: thirrësi duhet të garantojë që kjo të mos tejmbushet
        // diapazoni i vlerave për një karakter.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // SIGURIA: thirrësi duhet të garantojë që kjo të mos tejmbushet
            // diapazoni i vlerave për një karakter.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // SIGURIA: për shkak të kontratës së mëparshme, kjo është e garantuar
        // nga thirrësi të jetë një karakter i vlefshëm.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SIGURIA: thirrësi duhet të garantojë që kjo të mos tejmbushet
        // diapazoni i vlerave për një karakter.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // SIGURIA: thirrësi duhet të garantojë që kjo të mos tejmbushet
            // diapazoni i vlerave për një karakter.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // SIGURIA: për shkak të kontratës së mëparshme, kjo është e garantuar
        // nga thirrësi të jetë një karakter i vlefshëm.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // SIGURIA: sapo kontrolluar parakushtin
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // SIGURIA: sapo kontrolluar parakushtin
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Këto makro gjenerojnë implikime `ExactSizeIterator` për lloje të ndryshme diapazoni.
//
// * `ExactSizeIterator::len` kërkohet të kthejë gjithmonë një `usize` të saktë, kështu që asnjë diapazon nuk mund të jetë më i gjatë se `usize::MAX`.
//
// * Për llojet e plota në `Range<_>`, ky është rasti për llojet më të ngushta se ose aq të gjera sa `usize`.
//   Për llojet e plota në `RangeInclusive<_>`, ky është rasti për llojet *rreptësisht të ngushta* se `usize` pasi që p.sh.
//   `(0..=u64::MAX).len()` do të ishte `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Këto janë të inkorporuara për arsyetimin e mësipërm, por heqja e tyre do të ishte një ndryshim thyerës pasi ato ishin stabilizuar në Rust 1.0.0.
    // Kështu p.sh.
    // `(0..66_000_u32).len()` për shembull do të përpilojë pa gabime ose paralajmërime në platformat 16-bitëshe, por vazhdoni të jepni një rezultat të gabuar.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Këto janë të inkorporuara për arsyetimin e mësipërm, por heqja e tyre do të ishte një ndryshim thyerës pasi ato ishin stabilizuar në Rust 1.26.0.
    // Kështu p.sh.
    // `(0..=u16::MAX).len()` për shembull do të përpilojë pa gabime ose paralajmërime në platformat 16-bitëshe, por vazhdoni të jepni një rezultat të gabuar.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // SIGURIA: sapo kontrolluar parakushtin
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // SIGURIA: sapo kontrolluar parakushtin
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SIGURIA: sapo kontrolluar parakushtin
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SIGURIA: sapo kontrolluar parakushtin
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // SIGURIA: sapo kontrolluar parakushtin
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // SIGURIA: sapo kontrolluar parakushtin
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}