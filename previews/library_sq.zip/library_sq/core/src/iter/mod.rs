//! Përsëritja e jashtme e përbërë.
//!
//! Nëse e keni gjetur veten me një koleksion të një lloji, dhe keni nevojë për të kryer një operacion në elementet e koleksionit në fjalë, ju do të shpejt të hasni në 'iterators'.
//! Iteratorët përdoren shumë në kodin idiomatik Rust, kështu që ia vlen të njiheni me ta.
//!
//! Para se të shpjegojmë më shumë, le të flasim për mënyrën se si është strukturuar ky modul:
//!
//! # Organization
//!
//! Ky modul është organizuar kryesisht nga lloji:
//!
//! * [Traits] janë pjesa kryesore: këto traits përcaktojnë se çfarë lloj përsëritësish ekzistojnë dhe çfarë mund të bësh me ta.Metodat e këtyre traits ia vlen të vendosni një kohë shtesë studimi.
//! * [Functions] siguroni disa mënyra të dobishme për të krijuar disa përsëritës themelorë.
//! * [Structs] shpesh janë llojet e kthimit të metodave të ndryshme në traits të këtij moduli.Zakonisht do të dëshironi të shikoni metodën që krijon `struct`, sesa vetë `struct`.
//! Për më shumë detaje rreth arsyes, shihni '[Implementing Iterator](#implementues-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Kjo eshte!Le të gërmojmë në përsëritës.
//!
//! # Iterator
//!
//! Zemra dhe shpirti i këtij moduli është [`Iterator`] trait.Thelbi i [`Iterator`] duket kështu:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Një iterator ka një metodë, [`next`], e cila kur thirret, kthen një ["Opsion"] "<Item>`
//! [`next`] do të kthejë [`Some(Item)`] për sa kohë që ka elementë dhe pasi të jenë shteruar të gjithë, do të kthejë `None` për të treguar që përsëritja ka mbaruar.
//! Përsëritësit individualë mund të zgjedhin të rifillojnë përsëritjen, dhe kështu thirrja përsëri në [`next`] mund të fillojë ose jo përfundimisht të kthejë [`Some(Item)`] përsëri në një moment (për shembull, shih [`TryIter`]).
//!
//!
//! Përkufizimi i plotë i ["Iterator"] përfshin një numër metodash të tjera, por ato janë metoda të paracaktuara, të ndërtuara në krye të [`next`], dhe kështu t'i merrni falas.
//!
//! Përsëritësit janë gjithashtu të kompozueshëm, dhe është e zakonshme t'i zinxhirosh së bashku për të bërë forma më komplekse të përpunimit.Shihni seksionin [Adapters](#adapters) më poshtë për më shumë detaje.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Tri format e përsëritjes
//!
//! Ekzistojnë tre metoda të zakonshme që mund të krijojnë përsëritës nga një koleksion:
//!
//! * `iter()`, e cila përsëritet mbi `&T`.
//! * `iter_mut()`, e cila përsëritet mbi `&mut T`.
//! * `into_iter()`, e cila përsëritet mbi `T`.
//!
//! Gjëra të ndryshme në bibliotekën standarde mund të zbatojnë një ose më shumë nga tre, kur është e përshtatshme.
//!
//! # Zbatimi i Iteratorit
//!
//! Krijimi i një iteratori juaj përfshin dy hapa: krijimin e një `struct` për të mbajtur gjendjen e iteratorit, dhe pastaj implementimin e [`Iterator`] për atë `struct`.
//! Kjo është arsyeja pse ka kaq shumë struktura në këtë modul: ka një për secilin përsëritës dhe përshtatësin e iteratorit.
//!
//! Le të bëjmë një përsëritës me emrin `Counter` i cili llogaritet nga `1` në `5`:
//!
//! ```
//! // Së pari, struktura:
//!
//! /// Një përsëritës i cili numëron nga një në pesë
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ne duam që numërimi ynë të fillojë në një, kështu që le të shtojmë një metodë new() për të ndihmuar.
//! // Kjo nuk është rreptësisht e nevojshme, por është e përshtatshme.
//! // Vini re se ne e fillojmë `count` në zero, do të shohim pse në zbatimin `next()`'s më poshtë.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Pastaj, ne implementojmë `Iterator` për `Counter` tonë:
//!
//! impl Iterator for Counter {
//!     // ne do të numërojmë me përdorim
//!     type Item = usize;
//!
//!     // next() është e vetmja metodë e kërkuar
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Rritni numrin tonë.Kjo është arsyeja pse ne filluam në zero.
//!         self.count += 1;
//!
//!         // Kontrolloni për të parë nëse kemi mbaruar numërimin apo jo.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Dhe tani mund ta përdorim!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Thirrja [`next`] në këtë mënyrë përsëritet.Rust ka një konstrukt i cili mund të telefonojë [`next`] në përsëritësin tuaj, derisa të arrijë `None`.Le ta kalojmë atë tjetër.
//!
//! Gjithashtu vini re se `Iterator` siguron një implementim të paracaktuar të metodave të tilla si `nth` dhe `fold` të cilat thërrasin `next` brenda.
//! Sidoqoftë, është gjithashtu e mundur të shkruhet një zbatim i personalizuar i metodave si `nth` dhe `fold` nëse një iterator mund t'i llogarisë ato në mënyrë më efikase pa thirrur `next`.
//!
//! # `for` sythe dhe `IntoIterator`
//!
//! Sintaksa e lakut `for` të Rust është në të vërtetë sheqer për përsëritësit.Këtu është një shembull themelor i `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Kjo do të shtypë numrat një deri në pesë, secili në vijën e vet.Por ju do të vini re diçka këtu: ne kurrë nuk kemi thirrur ndonjë gjë në vector tonë për të prodhuar një përsëritës.Çfarë jep?
//!
//! Ka një trait në bibliotekën standarde për shndërrimin e diçkaje në një përsëritës: [`IntoIterator`].
//! Ky trait ka një metodë, [`into_iter`], e cila shndërron sendin që zbaton [`IntoIterator`] në një përsëritës.
//! Le të hedhim një vështrim në atë lak `for` përsëri, dhe çfarë përpiluesi e shndërron atë:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sheqernat e kësaj në:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Së pari, ne e quajmë `into_iter()` në vlerë.Pastaj, përputhemi në përsëritësin që kthehet, duke thirrur [`next`] pa pushim derisa të shohim një `None`.
//! Në atë pikë, ne `break` jemi jashtë loop, dhe kemi mbaruar duke përsëritur.
//!
//! Ekziston edhe një pak më delikate këtu: biblioteka standarde përmban një implementim interesant të [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Me fjalë të tjera, të gjithë [`Iterator`]-ët implementojnë [`IntoIterator`], duke u kthyer vetëm.Kjo do të thotë dy gjëra:
//!
//! 1. Nëse jeni duke shkruar një [`Iterator`], mund ta përdorni me një lak `for`.
//! 2. Nëse jeni duke krijuar një koleksion, implementimi i [`IntoIterator`] për të do të lejojë që koleksioni juaj të përdoret me lak `for`.
//!
//! # Përsëritje me referencë
//!
//! Meqenëse [`into_iter()`] merr `self` sipas vlerës, duke përdorur një lak `for` për të përsëritur mbi një koleksion konsumon atë koleksion.Shpesh, ju mund të dëshironi të përsërisni një koleksion pa e konsumuar atë.
//! Shumë koleksione ofrojnë metoda që ofrojnë përsëritës mbi referencat, të quajtura konvencionale përkatësisht `iter()` dhe `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` është ende në pronësi të këtij funksioni.
//! ```
//!
//! Nëse një lloj koleksioni `C` siguron `iter()`, ai zakonisht zbaton gjithashtu `IntoIterator` për `&C`, me një implementim që thjesht thërret `iter()`.
//! Po kështu, një koleksion `C` që siguron `iter_mut()` zakonisht zbaton `IntoIterator` për `&mut C` duke deleguar në `iter_mut()`.Kjo mundëson një stenografi të përshtatshme:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // njëlloj si `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // njëlloj si `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Ndërsa shumë koleksione ofrojnë `iter()`, jo të gjitha ofrojnë `iter_mut()`.
//! Për shembull, mutimi i çelësave të një [`HashSet<T>`] ose [`HashMap<K, V>`] mund ta vendosë koleksionin në një gjendje jo konsistente nëse ndryshimi i hasheve të tastit, kështu që këto koleksione ofrojnë vetëm `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funksionet që marrin një [`Iterator`] dhe kthejnë një tjetër [`Iterator`] shpesh quhen 'adaptues iterator', pasi ato janë një formë e 'adaptorit'
//! pattern'.
//!
//! Përshtatësit e zakonshëm të përsëritësit përfshijnë [`map`], [`take`] dhe [`filter`].
//! Për më shumë, shihni dokumentacionin e tyre.
//!
//! Nëse një përshtatës përsëritës panics, iteratori do të jetë në një gjendje të paspecifikuar (por memorie e sigurt).
//! Kjo gjendje gjithashtu nuk është e garantuar të qëndrojë e njëjtë në të gjithë versionet e Rust, kështu që duhet të shmangni mbështetjen te vlerat e sakta të kthyera nga një përsëritës i cili u panik.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Përsëritësit (dhe përsëritësi [adapters](#adapters)) janë *dembel*. Kjo do të thotë që thjesht krijimi i një përsëritësi nuk bën _do_ në tërësi. Asgjë nuk ndodh në të vërtetë derisa të telefononi [`next`].
//! Kjo ndonjëherë është një burim konfuzioni kur krijoni një përsëritës vetëm për efektet e tij anësore.
//! Për shembull, metoda [`map`] thërret një mbyllje për secilin element që përsërit:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Kjo nuk do të shtypë ndonjë vlerë, pasi kemi krijuar vetëm një përsëritës, në vend që ta përdorim atë.Përpiluesi do të na paralajmërojë për këtë lloj sjelljeje:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Mënyra idiomatike për të shkruar një [`map`] për efektet e saj anësore është të përdorni një lak `for` ose të telefononi metodën [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Një mënyrë tjetër e zakonshme për të vlerësuar një përsëritës është përdorimi i metodës [`collect`] për të prodhuar një koleksion të ri.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Përsëritësit nuk kanë pse të jenë të kufizuar.Si shembull, një diapazon i hapur është një përsëritës i pafund:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Commonshtë e zakonshme të përdoret përshtatësi [`take`] iterator për të kthyer një iterator të pafund në një të fundëm:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Kjo do të shtypë numrat `0` deri `4`, secili në linjën e vet.
//!
//! Kini parasysh që metodat në përsëritës të pafund, madje edhe ato për të cilat një rezultat mund të përcaktohet matematikisht në kohë të fundme, mund të mos përfundojnë.
//! Në mënyrë të veçantë, metoda të tilla si [`min`], të cilat në rastin e përgjithshëm kërkojnë përshkimin e çdo elementi në iterator, ka të ngjarë të mos kthehen me sukses për asnjë përsëritës të pafund.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh jo!Një lak i pafund!
//! // `ones.min()` shkakton një lak të pafund, kështu që ne nuk do ta arrijmë këtë pikë!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;