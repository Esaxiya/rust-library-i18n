use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Një tip mbështjellës për të ndërtuar shembuj të pa inicializuar të `T`.
///
/// # Invarianizimi i inicializimit
///
/// Përpiluesi, në përgjithësi, supozon se një variabël inicializohet siç duhet në përputhje me kërkesat e llojit të ndryshores.Për shembull, një ndryshore e llojit të referencës duhet të jetë në linjë dhe jo-NULL.
/// Ky është një i pandryshueshëm që duhet *gjithmonë* të mbëshetet, madje edhe në një kod të pasigurt.
/// Si pasojë, inicializimi zero i një ndryshore të llojit të referencës shkakton [undefined behavior][ub] të menjëhershëm, pa marrë parasysh nëse ajo referencë përdoret ndonjëherë për të hyrë në memorje:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // sjellje e padefinuar!⚠️
/// // Kodi ekuivalent me `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // sjellje e padefinuar!⚠️
/// ```
///
/// Kjo shfrytëzohet nga përpiluesi për optimizime të ndryshme, të tilla si heqja e kontrolleve të ekzekutimit dhe optimizimi i paraqitjes `enum`.
///
/// Në mënyrë të ngjashme, kujtesa plotësisht e pa iniciale mund të ketë ndonjë përmbajtje, ndërsa një `bool` duhet të jetë gjithmonë `true` ose `false`.Prandaj, krijimi i një `bool` të pa inicializuar është një sjellje e papërcaktuar:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // sjellje e padefinuar!⚠️
/// // Kodi ekuivalent me `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // sjellje e padefinuar!⚠️
/// ```
///
/// Për më tepër, kujtesa e pa inicializuar është e veçantë në atë që nuk ka një vlerë fikse ("fixed" do të thotë "it won't change without being written to").Leximi i të njëjtit bajt të pa inicializuar shumë herë mund të japë rezultate të ndryshme.
/// Kjo e bën sjelljen e papërcaktuar që të kesh të dhëna të pa iniciale në një ndryshore edhe nëse ajo ndryshore ka një tip të plotë, i cili përndryshe mund të mbajë çdo model bit *fiks*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // sjellje e padefinuar!⚠️
/// // Kodi ekuivalent me `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // sjellje e padefinuar!⚠️
/// ```
/// (Vini re se rregullat rreth numrave të plotë të pa inicializuar nuk janë finalizuar ende, por derisa të jenë përfunduar, këshillohet t'i shmangni ato.)
///
/// Për më tepër, mos harroni se shumica e llojeve kanë invariante shtesë përtej thjesht konsiderimit të iniciuar në nivelin e tipit.
/// Për shembull, një [`Vec<T>`] i iniciuar me `1` konsiderohet i iniciuar (nën zbatimin aktual; kjo nuk përbën një garanci të qëndrueshme) sepse e vetmja kërkesë që përpiluesi di për të është se treguesi i të dhënave duhet të jetë jo nul.
/// Krijimi i një `Vec<T>` të tillë nuk shkakton sjellje *të menjëhershme* të papërcaktuar, por do të shkaktojë sjellje të papërcaktuar me shumicën e operacioneve të sigurta (përfshirë rënien e tij).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` shërben për të mundësuar kodin e pasigurt që të merret me të dhëna të pa iniciale.
/// Shtë një sinjal për përpiluesin që tregon se të dhënat këtu mund *të mos* inicializohen:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Krijoni një referencë të qartë të pa inicializuar.
/// // Përpiluesi e di se të dhënat brenda një `MaybeUninit<T>` mund të jenë të pavlefshme, dhe prandaj kjo nuk është UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Vendoseni në një vlerë të vlefshme.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Nxjerrni të dhënat e iniciuara-kjo lejohet vetëm *pas* inicimit të duhur të `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Përpiluesi atëherë di të mos bëjë ndonjë supozim të gabuar ose optimizim mbi këtë kod.
///
/// Ju mund të mendoni se `MaybeUninit<T>` është pak si `Option<T>` por pa ndonjë nga ndjekjet e kohës dhe pa ndonjë nga kontrollet e sigurisë.
///
/// ## out-pointers
///
/// Ju mund të përdorni `MaybeUninit<T>` për të zbatuar "out-pointers": në vend që të ktheni të dhëna nga një funksion, kalojeni atë një tregues te ndonjë memorje (uninitialized) për të vendosur rezultatin.
/// Kjo mund të jetë e dobishme kur është e rëndësishme që telefonuesi të kontrollojë mënyrën e ndarjes së kujtesës që ruhet rezultati dhe ju doni të shmangni lëvizjet e panevojshme.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` nuk lëshon përmbajtjen e vjetër, gjë që është e rëndësishme.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Tani e dimë që `v` është inicializuar!Kjo gjithashtu siguron që vector të bjerë siç duhet.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inicimi i një elementi element pas element
///
/// `MaybeUninit<T>` mund të përdoret për të iniciuar një grup të madh element-nga-element:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Krijoni një koleksion të pa inicializuar të `MaybeUninit`.
///     // `assume_init` është i sigurt sepse lloji që ne po pretendojmë të kemi iniciuar këtu është një tufë `MaybeUninit`, të cilat nuk kërkojnë inicializim.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Rënia e një `MaybeUninit` nuk bën asgjë.
///     // Kështu që përdorimi i caktimit të treguesit të papërpunuar në vend të `ptr::write` nuk bën që të hiqet vlera e vjetër e pa inicializuar.
/////
///     // Gjithashtu nëse ka një panic gjatë kësaj loop, kemi një rrjedhje të kujtesës, por nuk ka ndonjë çështje të sigurisë së kujtesës.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Gjithçka inicializohet.
///     // Transmetoni vargun në llojin e inicializuar.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Ju gjithashtu mund të punoni me vargje pjesërisht të iniciuara, të cilat mund të gjenden në strukturat e të dhënave të nivelit të ulët.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Krijoni një koleksion të pa inicializuar të `MaybeUninit`.
/// // `assume_init` është i sigurt sepse lloji që ne po pretendojmë të kemi iniciuar këtu është një tufë `MaybeUninit`, të cilat nuk kërkojnë inicializim.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Numëroni numrin e elementeve që kemi caktuar.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Për secilin artikull në grup, hidhni nëse e ndajmë.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inicimi i një strukture fushë pas fushe
///
/// Ju mund të përdorni `MaybeUninit<T>` dhe makro [`std::ptr::addr_of_mut`], për të iniciuar strukturat fushë pas fushe:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inicimi i fushës `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inicimi i fushës `list` Nëse këtu ka një panic, atëherë rrjedh `String` në fushën `name`.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Të gjitha fushat janë inicializuar, kështu që ne telefonojmë `assume_init` për të marrë një Foo të iniciuar.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` është e garantuar të ketë të njëjtën madhësi, shtrirje dhe ABI si `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Sidoqoftë mbani mend se një lloj *që përmban* një `MaybeUninit<T>` nuk është domosdoshmërisht i njëjti paraqitje;Rust nuk garanton në përgjithësi që fushat e një `Foo<T>` kanë të njëjtën renditje si një `Foo<U>` edhe nëse `T` dhe `U` kanë të njëjtën madhësi dhe shtrirje.
///
/// Për më tepër, sepse çdo vlerë bit është e vlefshme për një `MaybeUninit<T>`, përpiluesi nuk mund të zbatojë optimizime non-zero/niche-filling, duke rezultuar potencialisht në një madhësi më të madhe:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Nëse `T` është i sigurt nga FFI, atëherë edhe `MaybeUninit<T>` është i sigurt.
///
/// Ndërsa `MaybeUninit` është `#[repr(transparent)]` (duke treguar se garanton të njëjtën madhësi, rreshtim dhe ABI si `T`), kjo *nuk* ndryshon asnjë nga paralajmërimet e mëparshme.
/// `Option<T>` dhe `Option<MaybeUninit<T>>` mund të kenë akoma madhësi të ndryshme, dhe llojet që përmbajnë një fushë të tipit `T` mund të paraqiten (dhe me madhësi) ndryshe sesa nëse ajo fushë do të ishte `MaybeUninit<T>`.
/// `MaybeUninit` është një lloj bashkimi, dhe `#[repr(transparent)]` në sindikata është e paqëndrueshme (shih [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Me kalimin e kohës, garancitë e sakta të `#[repr(transparent)]` për sindikatat mund të evoluojnë, dhe `MaybeUninit` mund të mbetet ose jo `#[repr(transparent)]`.
/// Thënë kjo, `MaybeUninit<T>`*gjithmonë* garanton se ka të njëjtën madhësi, shtrirje dhe ABI si `T`;është vetëm se mënyra se si `MaybeUninit` zbaton atë garanci mund të evoluojë.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Gjë e ngurtë që të mund të mbështjellim lloje të tjera në të.Kjo është e dobishme për gjeneratorët.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Duke mos thirrur `T::clone()`, nuk mund të dimë nëse jemi inicializuar mjaftueshëm për këtë.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Krijon një `MaybeUninit<T>` të ri të iniciuar me vlerën e dhënë.
    /// Safeshtë e sigurt të telefononi [`assume_init`] në vlerën e kthimit të këtij funksioni.
    ///
    /// Vini re se lëshimi i një `MaybeUninit<T>` nuk do të thërrasë kurrë kodin e rënies së `T`.
    /// Responsibilityshtë përgjegjësia juaj të siguroheni që `T` të bjerë nëse është iniciuar.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Krijon një `MaybeUninit<T>` të ri në një gjendje të pa inicializuar.
    ///
    /// Vini re se lëshimi i një `MaybeUninit<T>` nuk do të thërrasë kurrë kodin e rënies së `T`.
    /// Responsibilityshtë përgjegjësia juaj të siguroheni që `T` të bjerë nëse është iniciuar.
    ///
    /// Shihni [type-level documentation][MaybeUninit] për disa shembuj.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Krijoni një koleksion të ri të artikujve `MaybeUninit<T>`, në një gjendje të pa iniciale.
    ///
    /// Note: në një version future Rust kjo metodë mund të bëhet e panevojshme kur sintaksa fjalë për fjalë e vargut lejon [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Shembulli më poshtë mund të përdorë `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Kthen një pjesë (ndoshta më të vogël) të të dhënave që u lexuan në të vërtetë
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SIGURIA: Një `[MaybeUninit<_>; LEN]` e pa iniciale është e vlefshme.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Krijon një `MaybeUninit<T>` të ri në një gjendje të pa inicializuar, me kujtesën që mbushet me `0` bajte.Varet nga `T` nëse kjo tashmë bën inicimin e duhur.
    ///
    /// Për shembull, `MaybeUninit<usize>::zeroed()` inicializohet, por `MaybeUninit<&'static i32>::zeroed()` nuk është sepse referencat nuk duhet të jenë nul.
    ///
    /// Vini re se lëshimi i një `MaybeUninit<T>` nuk do të thërrasë kurrë kodin e rënies së `T`.
    /// Responsibilityshtë përgjegjësia juaj të siguroheni që `T` të bjerë nëse është iniciuar.
    ///
    /// # Example
    ///
    /// Përdorimi i saktë i këtij funksioni: inicimi i një strukture me zero, ku të gjitha fushat e strukturës mund të mbajnë modelin e bitit 0 si një vlerë të vlefshme.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Përdorimi i pasaktë* i këtij funksioni: thirrja `x.zeroed().assume_init()` kur `0` nuk është një model bit i vlefshëm për llojin:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Brenda një çifti, ne krijojmë një `NotZero` që nuk ka një diskriminues të vlefshëm.
    /// // Kjo është një sjellje e papërcaktuar.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SIGURIA: `u.as_mut_ptr()` pikë në kujtesën e caktuar.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Vendos vlerën e `MaybeUninit<T>`.
    /// Kjo mbishkruan çdo vlerë të mëparshme pa e rënë, prandaj bëni kujdes mos e përdorni dy herë nëse nuk doni të kaloni duke përdorur destruktorin.
    ///
    /// Për lehtësinë tuaj, kjo gjithashtu kthen një referencë të ndryshueshme për përmbajtjen (tani e iniciuar në mënyrë të sigurt) të `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SIGURIA: Ne sapo e iniciuam këtë vlerë.
        unsafe { self.assume_init_mut() }
    }

    /// Merr një tregues në vlerën e përmbajtur.
    /// Leximi nga ky tregues ose kthimi i tij në një referencë është një sjellje e papërcaktuar nëse nuk iniciohet `MaybeUninit<T>`.
    /// Shkrimi në kujtesë që tregon ky tregues (non-transitively) është sjellje e papërcaktuar (përveç brenda një `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Përdorimi i saktë i kësaj metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Krijoni një referencë në `MaybeUninit<T>`.Kjo është në rregull sepse ne e kemi iniciuar atë.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Përdorimi i pasaktë* i kësaj metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Ne kemi krijuar një referencë për një vector të pa inicializuar!Kjo është një sjellje e papërcaktuar.⚠️
    /// ```
    ///
    /// (Vini re se rregullat për referencat në të dhëna të paanicizuara nuk janë finalizuar ende, por derisa të bëhen ato, është e këshillueshme që t'i shmangni ato.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` dhe `ManuallyDrop` janë të dy `repr(transparent)` kështu që ne mund ta hedhim treguesin.
        self as *const _ as *const T
    }

    /// Merr një tregues të ndryshueshëm në vlerën e përmbajtur.
    /// Leximi nga ky tregues ose kthimi i tij në një referencë është një sjellje e papërcaktuar nëse nuk iniciohet `MaybeUninit<T>`.
    ///
    /// # Examples
    ///
    /// Përdorimi i saktë i kësaj metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Krijoni një referencë në `MaybeUninit<Vec<u32>>`.
    /// // Kjo është në rregull sepse ne e kemi iniciuar atë.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Përdorimi i pasaktë* i kësaj metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Ne kemi krijuar një referencë për një vector të pa inicializuar!Kjo është një sjellje e papërcaktuar.⚠️
    /// ```
    ///
    /// (Vini re se rregullat për referencat në të dhëna të paanicizuara nuk janë finalizuar ende, por derisa të bëhen ato, është e këshillueshme që t'i shmangni ato.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` dhe `ManuallyDrop` janë të dy `repr(transparent)` kështu që ne mund ta hedhim treguesin.
        self as *mut _ as *mut T
    }

    /// Nxjerr vlerën nga ena `MaybeUninit<T>`.Kjo është një mënyrë e shkëlqyeshme për të siguruar që të dhënat do të bien, sepse `T` që rezulton i nënshtrohet trajtimit të zakonshëm të rënies.
    ///
    /// # Safety
    ///
    /// Varet nga thirrësi që të garantojë që `MaybeUninit<T>` me të vërtetë është në një gjendje të iniciuar.Thirrja e kësaj kur përmbajtja ende nuk është iniciuar plotësisht shkakton sjellje të menjëhershme të papërcaktuar.
    /// [type-level documentation][inv] përmban më shumë informacion në lidhje me këtë invariant të inicimit.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Për më tepër, mos harroni se shumica e llojeve kanë invariante shtesë përtej thjesht konsiderimit të iniciuar në nivelin e tipit.
    /// Për shembull, një [`Vec<T>`] i iniciuar me `1` konsiderohet i iniciuar (nën zbatimin aktual; kjo nuk përbën një garanci të qëndrueshme) sepse e vetmja kërkesë që përpiluesi di për të është se treguesi i të dhënave duhet të jetë jo nul.
    ///
    /// Krijimi i një `Vec<T>` të tillë nuk shkakton sjellje *të menjëhershme* të papërcaktuar, por do të shkaktojë sjellje të papërcaktuar me shumicën e operacioneve të sigurta (përfshirë rënien e tij).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Përdorimi i saktë i kësaj metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Përdorimi i pasaktë* i kësaj metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` nuk ishte iniciuar ende, kështu që kjo linjë e fundit shkaktoi sjellje të papërcaktuar.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SIGURIA: thirrësi duhet të garantojë që `self` të iniciohet.
        // Kjo gjithashtu do të thotë që `self` duhet të jetë një variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Lexon vlerën nga ena `MaybeUninit<T>`.`T` që rezulton i nënshtrohet trajtimit të zakonshëm të rënies.
    ///
    /// Kurdoherë që është e mundur, preferohet të përdoret [`assume_init`] në vend të kësaj, gjë që parandalon dublikimin e përmbajtjes së `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Varet nga thirrësi që të garantojë që `MaybeUninit<T>` me të vërtetë është në një gjendje të iniciuar.Thirrja e kësaj kur përmbajtja nuk është iniciuar plotësisht, shkakton sjellje të papërcaktuar.
    /// [type-level documentation][inv] përmban më shumë informacion në lidhje me këtë invariant të inicimit.
    ///
    /// Për më tepër, kjo lë një kopje të të njëjtave të dhëna prapa në `MaybeUninit<T>`.
    /// Kur përdorni shumë kopje të të dhënave (duke telefonuar `assume_init_read` shumë herë, ose së pari duke telefonuar `assume_init_read` dhe pastaj [`assume_init`]), është përgjegjësia juaj të siguroni që ato të dhëna mund të kopjohen vërtet.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Përdorimi i saktë i kësaj metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` është `Copy`, kështu që ne mund të lexojmë shumë herë.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Dublikimi i një vlere `None` është në rregull, kështu që ne mund të lexojmë shumë herë.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Përdorimi i pasaktë* i kësaj metode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Tani krijuam dy kopje të të njëjtit vector, duke çuar në një dyfishtë ⚠️ kur të dy bien!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SIGURIA: thirrësi duhet të garantojë që `self` të iniciohet.
        // Leximi nga `self.as_ptr()` është i sigurt pasi që `self` duhet të fillohet.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Bën vlerën e përmbajtur në vend.
    ///
    /// Nëse keni pronësi të `MaybeUninit`, mund të përdorni [`assume_init`] në vend.
    ///
    /// # Safety
    ///
    /// Varet nga thirrësi që të garantojë që `MaybeUninit<T>` me të vërtetë është në një gjendje të iniciuar.Thirrja e kësaj kur përmbajtja nuk është iniciuar plotësisht, shkakton sjellje të papërcaktuar.
    ///
    /// Për më tepër, të gjithë invariancat shtesë të tipit `T` duhet të jenë të kënaqur, pasi zbatimi `Drop` i `T` (ose anëtarët e tij) mund të mbështetet në këtë.
    /// Për shembull, një [`Vec<T>`] i iniciuar me `1` konsiderohet i iniciuar (nën zbatimin aktual; kjo nuk përbën një garanci të qëndrueshme) sepse e vetmja kërkesë që përpiluesi di për të është se treguesi i të dhënave duhet të jetë jo nul.
    ///
    /// Rënia e një `Vec<T>` të tillë sidoqoftë do të shkaktojë sjellje të papërcaktuar.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SIGURIA: thirrësi duhet të garantojë që `self` të jetë inicializuar dhe
        // kënaq të gjitha invariante të `T`.
        // Rënia e vlerës në vend është e sigurt nëse është kështu.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Merr një referencë të përbashkët për vlerën e përmbajtur.
    ///
    /// Kjo mund të jetë e dobishme kur duam të përdorim një `MaybeUninit` që është iniciuar por nuk kemi pronësi të `MaybeUninit` (duke parandaluar përdorimin e `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Thirrja e kësaj kur përmbajtja nuk është iniciuar plotësisht, shkakton sjellje të papërcaktuar: i takon thirrësit të garantojë që `MaybeUninit<T>` me të vërtetë është në një gjendje të iniciuar.
    ///
    ///
    /// # Examples
    ///
    /// ### Përdorimi i saktë i kësaj metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inicializoni `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Tani që `MaybeUninit<_>` ynë dihet se është iniciuar, është në rregull të krijoni një referencë të përbashkët për të:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SIGURIA: `x` është inicializuar.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Përdorimet e pasakta* të kësaj metode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Ne kemi krijuar një referencë për një vector të pa inicializuar!Kjo është një sjellje e papërcaktuar.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inicializoni `MaybeUninit` duke përdorur `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referencë për një `Cell<bool>` të pa inicializuar: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SIGURIA: thirrësi duhet të garantojë që `self` të iniciohet.
        // Kjo gjithashtu do të thotë që `self` duhet të jetë një variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Merr një referencë të paqëndrueshme (unique) për vlerën e përmbajtur.
    ///
    /// Kjo mund të jetë e dobishme kur duam të përdorim një `MaybeUninit` që është iniciuar por nuk kemi pronësi të `MaybeUninit` (duke parandaluar përdorimin e `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Thirrja e kësaj kur përmbajtja nuk është iniciuar plotësisht, shkakton sjellje të papërcaktuar: i takon thirrësit të garantojë që `MaybeUninit<T>` me të vërtetë është në një gjendje të iniciuar.
    /// Për shembull, `.assume_init_mut()` nuk mund të përdoret për të iniciuar një `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Përdorimi i saktë i kësaj metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicializon *të gjithë* bajtët e buffer-it të hyrjes.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inicializoni `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Tani ne e dimë që `buf` është inicializuar, kështu që ne mund ta `.assume_init()` atë.
    /// // Sidoqoftë, përdorimi i `.assume_init()` mund të shkaktojë një `memcpy` të 2048 bajteve.
    /// // Për të pohuar që bufferi ynë është iniciuar pa e kopjuar, ne e azhurnojmë `&mut MaybeUninit<[u8; 2048]>` në një `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SIGURIA: `buf` është inicializuar.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Tani mund ta përdorim `buf` si një fetë normale:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Përdorimet e pasakta* të kësaj metode:
    ///
    /// Ju nuk mund të përdorni `.assume_init_mut()` për të iniciuar një vlerë:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Ne kemi krijuar një referencë (mutable) për një `bool` të pa iniciale!
    ///     // Kjo është një sjellje e papërcaktuar.⚠️
    /// }
    /// ```
    ///
    /// Për shembull, nuk mund ta bëni [`Read`] në një buffer të pa inicializuar:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referencë për kujtesën e pa iniciale!
    ///                             // Kjo është një sjellje e papërcaktuar.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// As nuk mund të përdorni akses të drejtpërdrejtë në terren për të bërë fillimin gradual fushë për fushë:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referencë për kujtesën e pa iniciale!
    ///                  // Kjo është një sjellje e papërcaktuar.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referencë për kujtesën e pa iniciale!
    ///                  // Kjo është një sjellje e papërcaktuar.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Ne aktualisht mbështetemi në atë se sa më sipër janë të pasakta, dmth., Ne kemi referenca në të dhëna të pa iniciale (p.sh., në `libcore/fmt/float.rs`).
    // Ne duhet të marrim një vendim përfundimtar në lidhje me rregullat përpara stabilizimit.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SIGURIA: thirrësi duhet të garantojë që `self` të iniciohet.
        // Kjo gjithashtu do të thotë që `self` duhet të jetë një variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Nxjerr vlerat nga një grup kontejnerësh `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Varet nga thirrësi që të garantojë që të gjithë elementët e grupit janë në një gjendje të iniciuar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SIGURIA: Tani e sigurt ndërsa iniciuam të gjithë elementët
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Telefonuesi garanton që të gjithë elementët e grupit të iniciohen
        // * `MaybeUninit<T>` dhe T janë të garantuara që të kenë të njëjtën paraqitje
        // * MaybeUnint nuk bie, kështu që nuk ka tarifa të dyfishta dhe kështu konvertimi është i sigurt
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Duke supozuar se të gjitha elementet janë iniciuar, merrni një copë to.
    ///
    /// # Safety
    ///
    /// Varet nga thirrësi që të garantojë që elementët `MaybeUninit<T>` me të vërtetë janë në një gjendje të iniciuar.
    ///
    /// Thirrja e kësaj kur përmbajtja nuk është iniciuar plotësisht, shkakton sjellje të papërcaktuar.
    ///
    /// Shihni [`assume_init_ref`] për më shumë detaje dhe shembuj.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SIGURIA: hedhja e copave në `*const [T]` është e sigurt pasi telefonuesi ju garanton këtë
        // `slice` inicializohet, dhe `NdoshtaUninit` është e garantuar të ketë të njëjtën paraqitje si `T`.
        // Treguesi i marrë është i vlefshëm pasi i referohet kujtesës në pronësi të `slice` e cila është një referencë dhe kështu garantohet të jetë e vlefshme për leximet.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Duke supozuar se të gjithë elementët janë iniciuar, merrni një fetë të ndryshueshme për to.
    ///
    /// # Safety
    ///
    /// Varet nga thirrësi që të garantojë që elementët `MaybeUninit<T>` me të vërtetë janë në një gjendje të iniciuar.
    ///
    /// Thirrja e kësaj kur përmbajtja nuk është iniciuar plotësisht, shkakton sjellje të papërcaktuar.
    ///
    /// Shihni [`assume_init_mut`] për më shumë detaje dhe shembuj.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SIGURIA: e ngjashme me shënimet e sigurisë për `slice_get_ref`, por ne kemi një
        // referencë e ndryshueshme e cila gjithashtu është e garantuar të jetë e vlefshme për shkrimet.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Merr një tregues tek elementi i parë i vargut.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Merr një tregues të ndryshueshëm te elementi i parë i vargut.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopjon elementet nga `src` në `this`, duke kthyer një referencë të ndryshueshme ndaj përmbajtjes së initalizuar tani të `this`.
    ///
    /// Nëse `T` nuk zbaton `Copy`, përdorni [`write_slice_cloned`]
    ///
    /// Kjo është e ngjashme me [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ky funksion do të panic nëse dy feta kanë gjatësi të ndryshme.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIGURIA: ne sapo kemi kopjuar të gjithë elementët e len-it në kapacitetin rezervë
    /// // elementet e para src.len() të vec janë të vlefshme tani.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SIGURIA: &[T] dhe&[NdoshtaUninit<T>] kanë të njëjtën paraqitje
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SIGURIA: Elementet e vlefshme sapo janë kopjuar në `this` kështu që initalizohet
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klonon elementet nga `src` në `this`, duke kthyer një referencë të ndryshueshme ndaj përmbajtjes së initalizuar tani të `this`.
    /// Çdo element tashmë i initalizuar nuk do të hiqet.
    ///
    /// Nëse `T` zbaton `Copy`, përdorni [`write_slice`]
    ///
    /// Kjo është e ngjashme me [`slice::clone_from_slice`] por nuk lëshon elementë ekzistues.
    ///
    /// # Panics
    ///
    /// Ky funksion do të panic nëse dy feta kanë gjatësi të ndryshme, ose nëse zbatimi i `Clone` panics.
    ///
    /// Nëse ka një panic, elementët tashmë të klonuar do të hidhen.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIGURIA: ne sapo kemi klonuar të gjithë elementët e lenit në kapacitetin rezervë
    /// // elementet e para src.len() të vec janë të vlefshme tani.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // ndryshe nga copy_from_slice kjo nuk e quan clone_from_slice në fetë kjo është për shkak se `MaybeUninit<T: Clone>` nuk zbaton Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SIGURIA: kjo fetë e papërpunuar do të përmbajë vetëm objekte të iniciuara
                // kjo është arsyeja pse, lejohet të bjerë.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Ne duhet t'i presim në mënyrë eksplicite në të njëjtën gjatësi
        // që kontrolli i kufijve të zgjidhet, dhe optimizuesi do të gjenerojë memcpy për raste të thjeshta (për shembull T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // nevojitet mbrojtës b/c panic mund të ndodhë gjatë një kloni
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SIGURIA: Elementët e vlefshëm sapo janë shkruar në `this` kështu që initalizohet
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}