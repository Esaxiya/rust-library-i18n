use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Një mbështjellës për të penguar përpiluesin nga thirrja automatike e shkatërruesit të `T`.
/// Kjo mbështjellëse është me kosto 0.
///
/// `ManuallyDrop<T>` i nënshtrohet të njëjtave optimizime të paraqitjeve si `T`.
/// Si pasojë, ai nuk ka *asnjë efekt* në supozimet që përpiluesi bën për përmbajtjen e tij.
/// Për shembull, inicializimi i një `ManuallyDrop<&mut T>` me [`mem::zeroed`] është një sjellje e papërcaktuar.
/// Nëse keni nevojë për të trajtuar të dhëna të pa iniciale, përdorni [`MaybeUninit<T>`] në vend.
///
/// Vini re se hyrja në vlerën brenda një `ManuallyDrop<T>` është e sigurt.
/// Kjo do të thotë që një `ManuallyDrop<T>` përmbajtja e së cilës është hequr nuk duhet të ekspozohet përmes një API të sigurt publik.
/// Përkatësisht, `ManuallyDrop::drop` është i pasigurt.
///
/// # `ManuallyDrop` dhe renditjes.
///
/// Rust ka një vlera [drop order] të përcaktuara mirë.
/// Për t'u siguruar që fushat ose vendasit bien në një renditje të veçantë, renditni përsëri deklaratat në mënyrë që rendi i nënkuptuar i rënies të jetë i saktë.
///
/// Possibleshtë e mundur të përdoret `ManuallyDrop` për të kontrolluar rendin e rënies, por kjo kërkon një kod të pasigurt dhe është e vështirë të bëhet në mënyrë korrekte në prani të zgjidhjes.
///
///
/// Për shembull, nëse doni të siguroheni që një fushë specifike do të bjerë pas të tjerave, bëjeni fushën e fundit të një strukture:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` do të bjerë pas `children`.
///     // Rust garanton që fushat do të bien sipas radhës së deklarimit.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Përfundoni një vlerë që do të bjerë manualisht.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Ju ende mund të përdorni në mënyrë të sigurt vlerën
    /// assert_eq!(*x, "Hello");
    /// // Por `Drop` nuk do të ekzekutohet këtu
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Nxjerr vlerën nga ena `ManuallyDrop`.
    ///
    /// Kjo lejon që vlera të bjerë përsëri.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Kjo bie `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Merr vlerën nga kontejneri `ManuallyDrop<T>`.
    ///
    /// Kjo metodë ka për qëllim kryesisht lëvizjen e vlerave në rënie.
    /// Në vend që të përdorni [`ManuallyDrop::drop`] për të hequr manualisht vlerën, mund të përdorni këtë metodë për të marrë vlerën dhe për ta përdorur atë me sa dëshironi.
    ///
    /// Kurdoherë që është e mundur, preferohet të përdoret [`into_inner`][`ManuallyDrop::into_inner`] në vend të kësaj, gjë që parandalon dublikimin e përmbajtjes së `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Ky funksion semantikisht lëviz nga vlera e përmbajtur pa parandaluar përdorimin e mëtejshëm, duke e lënë gjendjen e këtij kontejneri të pandryshuar.
    /// Responsibilityshtë përgjegjësia juaj të siguroheni që ky `ManuallyDrop` të mos përdoret përsëri.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SIGURIA: ne po lexojmë nga një referencë, e cila është e garantuar
        // të jetë e vlefshme për leximet.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Bie manualisht vlerën e përmbajtur.Kjo është saktësisht ekuivalente me thirrjen e [`ptr::drop_in_place`] me një tregues për vlerën e përmbajtur.
    /// Si e tillë, përveç nëse vlera e përmbajtur është një strukturë e mbushur, shkatërruesi do të thirret në vend pa lëvizur vlerën, dhe kështu mund të përdoret për të rënë në mënyrë të sigurt të të dhënave [pinned].
    ///
    /// Nëse keni pronësi të vlerës, mund të përdorni [`ManuallyDrop::into_inner`] në vend.
    ///
    /// # Safety
    ///
    /// Ky funksion drejton destruktorin e vlerës së përmbajtur.
    /// Përveç ndryshimeve të bëra nga vetë destruktori, kujtesa mbetet e pandryshuar dhe për sa i përket përpiluesit ende mban një model bit-i i cili është i vlefshëm për llojin `T`.
    ///
    ///
    /// Sidoqoftë, kjo vlerë "zombie" nuk duhet të ekspozohet ndaj kodit të sigurt dhe ky funksion nuk duhet të thirret më shumë se një herë.
    /// Për të përdorur një vlerë pasi të jetë rënë, ose të lëshoni një vlerë disa herë, mund të shkaktojë Sjellje të Padefinuar (në varësi të asaj që bën `drop`).
    /// Kjo normalisht parandalohet nga sistemi i tipit, por përdoruesit e `ManuallyDrop` duhet të mbajnë ato garanci pa ndihmën e përpiluesit.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SIGURIA: ne po heqim vlerën e treguar nga një referencë e ndryshueshme
        // e cila është e garantuar të jetë e vlefshme për shkrimet.
        // Varet nga thirrësi që të sigurohet që `slot` të mos bjerë përsëri.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}