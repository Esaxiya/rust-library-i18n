//! Funksionet themelore për trajtimin e kujtesës.
//!
//! Ky modul përmban funksione për pyetjen e madhësisë dhe rreshtimin e llojeve, inicimin dhe manipulimin e kujtesës.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Merr pronësinë dhe "forgets" për vlerën **pa ekzekutuar shkatërruesin e saj**.
///
/// Çdo burim që administron vlera, siç është memoria e grumbulluar ose një dorezë skedari, do të qëndrojnë përgjithmonë në një gjendje të paarritshme.Sidoqoftë, nuk garanton që treguesit e kësaj kujtese do të mbeten të vlefshme.
///
/// * Nëse dëshironi të dilni në kujtesë, shihni [`Box::leak`].
/// * Nëse dëshironi të merrni një tregues të papërpunuar të kujtesës, shihni [`Box::into_raw`].
/// * Nëse dëshironi të hidhni një vlerë siç duhet, duke përdorur destruktorin e saj, shihni [`mem::drop`].
///
/// # Safety
///
/// `forget` nuk është shënuar si `unsafe`, sepse garancitë e sigurisë së Rust nuk përfshijnë një garanci se shkatërruesit do të funksionojnë gjithmonë.
/// Për shembull, një program mund të krijojë një cikël referimi duke përdorur [`Rc`][rc], ose të telefonojë [`process::exit`][exit] për të dalë pa përdorur destruktorë.
/// Kështu, lejimi i `mem::forget` nga kodi i sigurt nuk ndryshon thelbësisht garancitë e sigurisë së Rust.
///
/// Kjo tha, rrjedhja e burimeve të tilla si kujtesa ose objektet I/O është zakonisht e padëshirueshme.
/// Nevoja paraqitet në disa raste përdorimi të specializuara për FFI ose kod të pasigurt, por edhe atëherë, [`ManuallyDrop`] zakonisht preferohet.
///
/// Meqenëse harrimi i një vlere lejohet, çdo kod `unsafe` që shkruani duhet ta lejojë këtë mundësi.Ju nuk mund të ktheni një vlerë dhe të prisni që thirrësi do të përdorë domosdoshmërisht shkatërruesin e vlerës.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Përdorimi kanonik i sigurt i `mem::forget` është për të anashkaluar shkatërruesin e një vlere të zbatuar nga `Drop` trait.Për shembull, kjo do të rrjedhë një `File`, dmth
/// rimarr hapësirën e marrë nga ndryshorja, por kurrë mos e mbyll burimin themelor të sistemit:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Kjo është e dobishme kur pronësia e burimit themelor u transferua më parë në kod jashtë Rust, për shembull duke transmetuar përshkruesin e skedarit të papërpunuar në kodin C.
///
/// # Marrëdhënia me `ManuallyDrop`
///
/// Ndërsa `mem::forget` mund të përdoret gjithashtu për të transferuar pronësinë e *kujtesës*, veprimi i tillë është i prirur për gabime.
/// [`ManuallyDrop`] duhet të përdoret në vend.Konsideroni, për shembull, këtë kod:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Ndërtoni një `String` duke përdorur përmbajtjen e `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // rrjedh `v` sepse kujtesa e tij tani menaxhohet nga `s`
/// mem::forget(v);  // GABIM, v është i pavlefshëm dhe nuk duhet t'i kalohet një funksioni
/// assert_eq!(s, "Az");
/// // `s` është rënë në mënyrë implicite dhe kujtesa e saj zhvendoset.
/// ```
///
/// Ka dy çështje me shembullin e mësipërm:
///
/// * Nëse do të shtohej më shumë kod midis ndërtimit të `String` dhe thirrjes së `mem::forget()`, një panic brenda tij do të shkaktonte një dyfishim të lirë sepse e njëjta memorie trajtohet si nga `v` ashtu edhe nga `s`.
/// * Pas thirrjes `v.as_mut_ptr()` dhe transmetimit të pronësisë së të dhënave në `s`, vlera `v` është e pavlefshme.
/// Edhe kur një vlerë sapo zhvendoset në `mem::forget` (e cila nuk do ta inspektojë atë), disa lloje kanë kërkesa të rrepta për vlerat e tyre që i bëjnë ato të pavlefshme kur varen ose nuk janë më në pronësi.
/// Përdorimi i vlerave të pavlefshme në çfarëdo mënyre, përfshirë kalimin e tyre ose kthimin e tyre nga funksionet, përbën sjellje të papërcaktuar dhe mund të thyejë supozimet e bëra nga përpiluesi.
///
/// Kalimi në `ManuallyDrop` shmang të dy çështjet:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Para se ta çmontojmë `v` në pjesët e tij të papërpunuara, sigurohuni që të mos bjerë!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Tani çmontoni `v`.Këto operacione nuk mund të panic, kështu që nuk mund të ketë një rrjedhje.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Më në fund, ndërtoni një `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` është rënë në mënyrë implicite dhe kujtesa e saj zhvendoset.
/// ```
///
/// `ManuallyDrop` me forcë parandalon dyfishtë, sepse ne e çaktivizojmë shkatërruesin e `v` para se të bëjmë ndonjë gjë tjetër.
/// `mem::forget()` nuk e lejon këtë sepse konsumon argumentin e saj, duke na detyruar ta quajmë atë vetëm pasi të nxjerrim çdo gjë që na nevojitet nga `v`.
/// Edhe nëse do të prezantohej një panic midis ndërtimit të `ManuallyDrop` dhe ndërtimit të vargut (gjë që nuk mund të ndodhë në kod siç tregohet), kjo do të rezultojë në një rrjedhje dhe jo dyfish të lirë.
/// Me fjalë të tjera, `ManuallyDrop` gabon në anën e rrjedhjes në vend që të gabojë në anën e rënies (dyfishtë).
///
/// Gjithashtu, `ManuallyDrop` na parandalon që të kemi "touch" `v` pas transferimit të pronësisë në `s`-hapi i fundit i bashkëveprimit me `v` për ta hedhur atë pa drejtuar shkatërruesin e tij shmanget plotësisht.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Ashtu si [`forget`], por gjithashtu pranon vlera të papërmasuara.
///
/// Ky funksion është thjesht një shim që synohet të hiqet kur karakteristika `unsized_locals` stabilizohet.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Kthen madhësinë e një lloji në bajte.
///
/// Më konkretisht, kjo është kompensimi në bajte midis elementeve të njëpasnjëshëm në një grup me atë lloj artikulli duke përfshirë mbushjen e shtrirjes.
///
/// Kështu, për çdo lloj `T` dhe gjatësi `n`, `[T; n]` ka një madhësi prej `n * size_of::<T>()`.
///
/// Në përgjithësi, madhësia e një lloji nuk është e qëndrueshme në përpilimet, por llojet specifike siç janë primitivët janë.
///
/// Tabela e mëposhtme jep madhësinë për primitivët.
///
/// Lloji |madhësia e:::<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 karrota |4
///
/// Për më tepër, `usize` dhe `isize` kanë të njëjtën madhësi.
///
/// Llojet `*const T`, `&T`, `Box<T>`, `Option<&T>` dhe `Option<Box<T>>` të gjithë kanë të njëjtën madhësi.
/// Nëse `T` është me madhësi, të gjithë ata lloje kanë të njëjtën madhësi si `usize`.
///
/// Ndryshueshmëria e një treguesi nuk e ndryshon madhësinë e tij.Si të tillë, `&T` dhe `&mut T` kanë të njëjtën madhësi.
/// Po kështu për `*const T` dhe `* mut T`.
///
/// # Madhësia e artikujve `#[repr(C)]`
///
/// Përfaqësimi `C` për artikujt ka një paraqitje të përcaktuar.
/// Me këtë paraqitje, madhësia e artikujve është gjithashtu e qëndrueshme për sa kohë që të gjitha fushat kanë një madhësi të qëndrueshme.
///
/// ## Madhësia e Strukturave
///
/// Për `structs`, madhësia përcaktohet nga algoritmi i mëposhtëm.
///
/// Për secilën fushë në strukturën e renditur sipas urdhrit të deklarimit:
///
/// 1. Shtoni madhësinë e fushës.
/// 2. Mblidhni madhësinë aktuale në shumëfishin më të afërt të [alignment] të fushës tjetër.
///
/// Në fund, rrumbullakosni madhësinë e strukturës në shumëfishin më të afërt të [alignment] të tij.
/// Rreshtimi i strukturës është zakonisht shtrirja më e madhe e të gjitha fushave të saj;kjo mund të ndryshohet me përdorimin e `repr(align(N))`.
///
/// Ndryshe nga `C`, strukturat me madhësi zero nuk rrumbullakosen në madhësi deri në një bajt.
///
/// ## Madhësia e Enumeve
///
/// Enumet që nuk mbajnë të dhëna të tjera përveç diskriminuesit kanë të njëjtën madhësi si C enumet në platformën për të cilën janë përpiluar.
///
/// ## Madhësia e Sindikatave
///
/// Madhësia e një bashkimi është madhësia e fushës së saj më të madhe.
///
/// Ndryshe nga `C`, sindikatat me madhësi zero nuk rrumbullakosen në madhësi deri në një bajt.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Disa primitivë
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Disa vargje
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Barazia e madhësisë së treguesit
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Përdorimi i `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Madhësia e fushës së parë është 1, kështu që shtoni 1 në madhësi.Madhësia është 1.
/// // Rreshtimi i fushës së dytë është 2, kështu që shtoni 1 në madhësi për mbushje.Madhësia është 2.
/// // Madhësia e fushës së dytë është 2, kështu që shtoni 2 në madhësi.Madhësia është 4.
/// // Rreshtimi i fushës së tretë është 1, kështu që shtoni 0 në madhësinë për mbushje.Madhësia është 4.
/// // Madhësia e fushës së tretë është 1, kështu që shtoni 1 në madhësi.Madhësia është 5.
/// // Së fundmi, shtrirja e strukturës është 2 (sepse rreshtimi më i madh midis fushave të tij është 2), kështu që shtoni 1 në madhësi për mbushje.
/// // Madhësia është 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Strukturat e dyfishta ndjekin të njëjtat rregulla.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Vini re se renditja e fushave mund të ulë madhësinë.
/// // Ne mund t'i heqim të dy bajtat e mbushjes duke vendosur `third` para `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Madhësia e unionit është madhësia e fushës më të madhe.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Kthen madhësinë e vlerës së theksuar në bajt.
///
/// Kjo është zakonisht e njëjtë me `size_of::<T>()`.
/// Sidoqoftë, kur `T` * nuk ka madhësi të njohur statistikisht, p.sh., një fetë [`[T]`][slice] ose një [trait object], atëherë `size_of_val` mund të përdoret për të marrë madhësinë e njohur dinamikisht.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SIGURIA: `val` është një referencë, pra është një tregues i vlefshëm i papërpunuar
    unsafe { intrinsics::size_of_val(val) }
}

/// Kthen madhësinë e vlerës së theksuar në bajt.
///
/// Kjo është zakonisht e njëjtë me `size_of::<T>()`.Sidoqoftë, kur `T`*nuk ka* madhësi të njohur statistikisht, p.sh., një fetë [`[T]`][slice] ose një [trait object], atëherë `size_of_val_raw` mund të përdoret për të marrë madhësinë e njohur dinamikisht.
///
/// # Safety
///
/// Ky funksion është i sigurt për tu thirrur vetëm nëse ekzistojnë kushtet e mëposhtme:
///
/// - Nëse `T` është `Sized`, ky funksion është gjithmonë i sigurt për t'u thirrur.
/// - Nëse bishti pa madhësi i `T` është:
///     - një [slice], atëherë gjatësia e bishtit të feta duhet të jetë një numër i plotë i iniciuar, dhe madhësia e vlerës së plotë * (gjatësia dinamike e bishtit + prefiksi me madhësi statike) duhet të përshtatet në `isize`.
///     - një [trait object], atëherë pjesa vtable e treguesit duhet të tregojë në një tryezë të vlefshme të fituar nga një shtrëngim pa madhësi, dhe madhësia e vlerës së plotë * (gjatësia dinamike e bishtit + prefiksi me madhësi statike) duhet të përshtatet në `isize`.
///
///     - një (unstable) [extern type], atëherë ky funksion është gjithmonë i sigurt për t`u thirrur, por mund që panic ose përndryshe të kthejë vlerën e gabuar, pasi paraqitja e llojit të jashtëm nuk dihet.
///     Kjo është e njëjta sjellje si [`size_of_val`] në lidhje me një lloj me një bisht të tipit të jashtëm.
///     - përndryshe, në mënyrë konservative nuk lejohet të thirret ky funksion.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIGURIA: thirrësi duhet të sigurojë një tregues të vlefshëm të papërpunuar
    unsafe { intrinsics::size_of_val(val) }
}

/// Kthen rreshtimin minimal të kërkuar nga [ABI] të një lloji.
///
/// Çdo referencë për një vlerë të tipit `T` duhet të jetë shumëfish i këtij numri.
///
/// Kjo është rreshtimi i përdorur për fushat strukturë.Mund të jetë më i vogël se rreshtimi i preferuar.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Kthen rreshtimin minimal të kërkuar nga [ABI] të llojit të vlerës për të cilën tregon `val`.
///
/// Çdo referencë për një vlerë të tipit `T` duhet të jetë shumëfish i këtij numri.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SIGURIA: val është një referencë, pra është një tregues i vlefshëm i papërpunuar
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Kthen rreshtimin minimal të kërkuar nga [ABI] të një lloji.
///
/// Çdo referencë për një vlerë të tipit `T` duhet të jetë shumëfish i këtij numri.
///
/// Kjo është rreshtimi i përdorur për fushat strukturë.Mund të jetë më i vogël se rreshtimi i preferuar.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Kthen rreshtimin minimal të kërkuar nga [ABI] të llojit të vlerës për të cilën tregon `val`.
///
/// Çdo referencë për një vlerë të tipit `T` duhet të jetë shumëfish i këtij numri.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SIGURIA: val është një referencë, pra është një tregues i vlefshëm i papërpunuar
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Kthen rreshtimin minimal të kërkuar nga [ABI] të llojit të vlerës për të cilën tregon `val`.
///
/// Çdo referencë për një vlerë të tipit `T` duhet të jetë shumëfish i këtij numri.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Ky funksion është i sigurt për tu thirrur vetëm nëse ekzistojnë kushtet e mëposhtme:
///
/// - Nëse `T` është `Sized`, ky funksion është gjithmonë i sigurt për t'u thirrur.
/// - Nëse bishti pa madhësi i `T` është:
///     - një [slice], atëherë gjatësia e bishtit të feta duhet të jetë një numër i plotë i iniciuar, dhe madhësia e vlerës së plotë * (gjatësia dinamike e bishtit + prefiksi me madhësi statike) duhet të përshtatet në `isize`.
///     - një [trait object], atëherë pjesa vtable e treguesit duhet të tregojë në një tryezë të vlefshme të fituar nga një shtrëngim pa madhësi, dhe madhësia e vlerës së plotë * (gjatësia dinamike e bishtit + prefiksi me madhësi statike) duhet të përshtatet në `isize`.
///
///     - një (unstable) [extern type], atëherë ky funksion është gjithmonë i sigurt për t`u thirrur, por mund që panic ose përndryshe të kthejë vlerën e gabuar, pasi paraqitja e llojit të jashtëm nuk dihet.
///     Kjo është e njëjta sjellje si [`align_of_val`] në lidhje me një lloj me një bisht të tipit të jashtëm.
///     - përndryshe, në mënyrë konservative nuk lejohet të thirret ky funksion.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIGURIA: thirrësi duhet të sigurojë një tregues të vlefshëm të papërpunuar
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Kthen `true` nëse vlerat e rënies së tipit `T` kanë rëndësi.
///
/// Ky është thjesht një aluzion i optimizimit dhe mund të zbatohet në mënyrë konservatore:
/// mund të kthejë `true` për llojet që nuk kanë nevojë të hidhen.
/// Si i tillë gjithmonë kthimi i `true` do të ishte një zbatim i vlefshëm i këtij funksioni.Sidoqoftë, nëse ky funksion në të vërtetë kthen `false`, atëherë mund të jeni i sigurt se rënia `T` nuk ka efekt anësor.
///
/// Zbatimet e nivelit të ulët të gjërave si koleksionet, të cilat duhet të heqin dorë të dhënat e tyre, duhet ta përdorin këtë funksion për të shmangur përpjekjet e panevojshme për të hedhur të gjithë përmbajtjen e tyre kur ato shkatërrohen.
///
/// Kjo mund të mos bëjë një ndryshim në ndërtimet e lëshimit (kur një lak që nuk ka efekte anësore zbulohet dhe eliminohet lehtësisht), por shpesh është një fitore e madhe për ndërtimet e korrigjimeve.
///
/// Vini re se [`drop_in_place`] tashmë e kryen këtë kontroll, kështu që nëse ngarkesa juaj e punës mund të reduktohet në një numër të vogël të thirrjeve [`drop_in_place`], përdorimi i kësaj është i panevojshëm.
/// Në veçanti vini re se ju mund të [`drop_in_place`] një fetë, dhe kjo do të bëjë një kontroll të vetëm të nevojave_drop për të gjitha vlerat.
///
/// Llojet si Vec prandaj vetëm `drop_in_place(&mut self[..])` pa përdorur `needs_drop` në mënyrë të qartë.
/// Nga ana tjetër, llojet si [`HashMap`], duhet të heqin vlerat një nga një dhe duhet të përdorin këtë API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Këtu keni një shembull se si një koleksion mund të përdorë `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // lësho të dhënat
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Kthen vlerën e tipit `T` të përfaqësuar nga modeli bajt të gjitha zero.
///
/// Kjo do të thotë që, për shembull, bajti i mbushjes në `(u8, u16)` nuk zerohet domosdoshmërisht.
///
/// Nuk ka asnjë garanci që një model bajtësh të gjitha zero përfaqëson një vlerë të vlefshme të disa llojeve `T`.
/// Për shembull, modeli i bajtëve të gjitha zero nuk është një vlerë e vlefshme për llojet e referencës (`&T`, `&mut T`) dhe treguesit e funksioneve.
/// Përdorimi i `zeroed` në lloje të tillë shkakton [undefined behavior][ub] të menjëhershëm sepse [the Rust compiler assumes][inv] gjithmonë ekziston një vlerë e vlefshme në një ndryshore që ai e konsideron të iniciuar.
///
///
/// Ky ka të njëjtin efekt si [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Sometimesshtë i dobishëm për FFI nganjëherë, por zakonisht duhet të shmanget.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Përdorimi i saktë i këtij funksioni: inicializimi i një numri të plotë me zero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Përdorimi i pasaktë* i këtij funksioni: inicializimi i një reference me zero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Sjellje e padefinuar!
/// let _y: fn() = unsafe { mem::zeroed() }; // Dhe perseri!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SIGURIA: thirrësi duhet të garantojë që një vlerë krejt zero është e vlefshme për `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Anashkalon kontrollet fillestare të kujtesës për Rust duke pretenduar se prodhojnë një vlerë të tipit `T`, ndërsa nuk bëjnë asgjë fare.
///
/// **Ky funksion është i vjetruar.** Përdorni [`MaybeUninit<T>`] në vend.
///
/// Arsyeja e amortizimit është se funksioni në thelb nuk mund të përdoret si duhet: ai ka të njëjtin efekt si [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Siç shpjegon [`assume_init` documentation][assume_init], vlerat [the Rust compiler assumes][inv] inicohen siç duhet.
/// Si pasojë, thirrja p.sh.
/// `mem::uninitialized::<bool>()` shkakton sjellje të menjëhershme të papërcaktuar për kthimin e një `bool` që nuk është përfundimisht as `true` ose `false`.
/// Më keq, kujtesa me të vërtetë e pa inicializuar si ajo që kthehet këtu është e veçantë në atë që përpiluesi e di që nuk ka një vlerë fikse.
/// Kjo e bën sjellje të papërcaktuar që të kesh të dhëna të pa iniciale në një ndryshore edhe nëse ajo ndryshore ka një tip të plotë.
/// (Vini re se rregullat rreth numrave të plotë të pa inicializuar nuk janë finalizuar ende, por derisa të jenë përfunduar, këshillohet t'i shmangni ato.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SIGURIA: thirrësi duhet të garantojë që një vlerë e njësuar është e vlefshme për `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Ndërron vlerat në dy vendndodhje të ndryshueshme, pa deinitializuar as njërën.
///
/// * Nëse dëshironi të ndërroni me një vlerë të paracaktuar ose bedel, shihni [`take`].
/// * Nëse dëshironi të ndërroni me një vlerë të kaluar, duke kthyer vlerën e vjetër, shihni [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SIGURIA: treguesit e papërpunuar janë krijuar nga referenca të sigurta të paqëndrueshme që kënaqin të gjitha
    // kufizimet në `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Zëvendëson `dest` me vlerën e paracaktuar të `T`, duke kthyer vlerën e mëparshme `dest`.
///
/// * Nëse dëshironi të zëvendësoni vlerat e dy ndryshoreve, shihni [`swap`].
/// * Nëse dëshironi të zëvendësoni me një vlerë të kaluar në vend të vlerës së paracaktuar, shihni [`replace`].
///
/// # Examples
///
/// Një shembull i thjeshtë:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` lejon marrjen në pronësi të një fushe strukturë duke e zëvendësuar atë me një vlerë "empty".
/// Pa `take` mund të hasni në çështje si këto:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Vini re se `T` nuk zbaton domosdoshmërisht [`Clone`], kështu që nuk mund as të klonojë dhe rivendosë `self.buf`.
/// Por `take` mund të përdoret për të shkëputur vlerën origjinale të `self.buf` nga `self`, duke lejuar që ajo të kthehet:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Lëviz `src` në `dest` të referuar, duke kthyer vlerën e mëparshme `dest`.
///
/// Asnjëra vlerë nuk është rënë.
///
/// * Nëse dëshironi të zëvendësoni vlerat e dy ndryshoreve, shihni [`swap`].
/// * Nëse dëshironi të zëvendësoni me një vlerë të paracaktuar, shihni [`take`].
///
/// # Examples
///
/// Një shembull i thjeshtë:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` lejon konsumimin e një fushe strukturore duke e zëvendësuar atë me një vlerë tjetër.
/// Pa `replace` mund të hasni në çështje si këto:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Vini re se `T` nuk zbaton domosdoshmërisht [`Clone`], kështu që ne as nuk mund të klonojmë `self.buf[i]` për të shmangur lëvizjen.
/// Por `replace` mund të përdoret për të shkëputur vlerën origjinale në atë indeks nga `self`, duke lejuar që ajo të kthehet:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SIGURIA: Ne lexojmë nga `dest` por direkt shkruajmë `src` në të më pas,
    // e tillë që vlera e vjetër të mos kopjohet.
    // Asgjë nuk bie dhe asgjë këtu nuk mund të panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Disponon një vlerë.
///
/// Kjo e bën këtë duke thirrur zbatimin e argumentit të [`Drop`][drop].
///
/// Kjo në mënyrë efektive nuk bën asgjë për llojet që implementojnë `Copy`, p.sh.
/// integers.
/// Vlera të tilla kopjohen dhe _then_ zhvendoset në funksion, kështu që vlera vazhdon pas thirrjes së këtij funksioni.
///
///
/// Ky funksion nuk është magji;është përcaktuar fjalë për fjalë si
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Për shkak se `_x` është zhvendosur në funksion, ai bie automatikisht para se të kthehet funksioni.
///
/// [drop]: Drop
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // në mënyrë të qartë rënie vector
/// ```
///
/// Meqenëse [`RefCell`] zbaton rregullat e huazimit gjatë kohës së ekzekutimit, `drop` mund të lëshojë një hua [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // hiqni dorë nga huazimi i paqëndrueshëm në këtë vend të caktuar
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Integrat dhe llojet e tjerë që zbatojnë [`Copy`] nuk preken nga `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // një kopje e `x` zhvendoset dhe hidhet
/// drop(y); // një kopje e `y` zhvendoset dhe hidhet
///
/// println!("x: {}, y: {}", x, y.0); // akoma në dispozicion
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpreton `src` si tip `&U` dhe më pas lexon `src` pa lëvizur vlerën e përmbajtur.
///
/// Ky funksion do të supozojë në mënyrë të pasigurt se treguesi `src` është i vlefshëm për [`size_of::<U>`][size_of] bajtë duke shndërruar `&T` në `&U` dhe më pas duke lexuar `&U` (përveç që kjo të bëhet në një mënyrë që është e saktë edhe kur `&U` bën kërkesa më të rrepta të rreshtimit sesa `&T`).
/// Ai gjithashtu do të krijojë në mënyrë të pasigurt një kopje të vlerës së përmbajtur në vend që të lëvizë nga `src`.
///
/// Nuk është një gabim në kohën e përpilimit nëse `T` dhe `U` kanë madhësi të ndryshme, por inkurajohet shumë që të thirret vetëm ky funksion ku `T` dhe `U` kanë të njëjtën madhësi.Ky funksion shkakton [undefined behavior][ub] nëse `U` është më i madh se `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopjoni të dhënat nga 'foo_array' dhe trajtojeni si 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Modifikoni të dhënat e kopjuara
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Përmbajtja e 'foo_array' nuk duhet të ketë ndryshuar
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Nëse U ka një kërkesë më të lartë të shtrirjes, src mund të mos rreshtohet në mënyrë të përshtatshme.
    if align_of::<U>() > align_of::<T>() {
        // SIGURIA: `src` është një referencë e cila garantohet të jetë e vlefshme për leximet.
        // Telefonuesi duhet të garantojë që transmutimi aktual është i sigurt.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SIGURIA: `src` është një referencë e cila garantohet të jetë e vlefshme për leximet.
        // Sapo kemi kontrolluar që `src as *const U` ishte në rregull.
        // Telefonuesi duhet të garantojë që transmutimi aktual është i sigurt.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Lloji i paqartë që përfaqëson diskriminuesin e një enumi.
///
/// Shihni funksionin [`discriminant`] në këtë modul për më shumë informacion.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Këto implementime të trait nuk mund të nxirren sepse nuk duam asnjë kufi për T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Kthen një vlerë duke identifikuar në mënyrë unike variantin e enum-it në `v`.
///
/// Nëse `T` nuk është një enum, thirrja e këtij funksioni nuk do të rezultojë në sjellje të papërcaktuar, por vlera e kthimit është e paspecifikuar.
///
///
/// # Stability
///
/// Diskriminuesi i një varianti enum mund të ndryshojë nëse përkufizimi i enumit ndryshon.
/// Një diskriminues i disa varianteve nuk do të ndryshojë midis përpilimeve me të njëjtin përpilues.
///
/// # Examples
///
/// Kjo mund të përdoret për të krahasuar enumet që mbajnë të dhëna, duke mos marrë parasysh të dhënat aktuale:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Kthen numrin e varianteve në llojin enum `T`.
///
/// Nëse `T` nuk është një enum, thirrja e këtij funksioni nuk do të rezultojë në sjellje të papërcaktuar, por vlera e kthimit është e paspecifikuar.
/// Po kështu, nëse `T` është një numërim me më shumë variante se `usize::MAX`, vlera e kthimit është e paspecifikuar.
/// Variantet e pabanuara do të numërohen.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}