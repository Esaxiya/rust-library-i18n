# `rustc-std-workspace-std` crate

Shihni dokumentacionin për `rustc-std-workspace-core` crate.