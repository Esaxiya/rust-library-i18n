# Kontribuar në stdarch

`stdarch` crate është më se i gatshëm të pranojë kontribute!Së pari, ju ndoshta do të dëshironi të kontrolloni depon dhe të siguroheni që testet të kalojnë për ju:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Kur `<your-target-arch>` është trefishi i synuar siç përdoret nga `rustup`, p.sh. `x86_x64-unknown-linux-gnu` (pa ndonjë `nightly-` paraardhës ose të ngjashëm).
Mos harroni gjithashtu se ky depo kërkon kanalin natën të Rust!
Testet e mësipërme në fakt kërkojnë që rust i natës të jetë i parazgjedhuri në sistemin tuaj, për të vendosur që përdorin `rustup default nightly` (dhe `rustup default stable` për t'u kthyer).

Nëse ndonjë nga hapat e mësipërm nuk funksionon, [please let us know][new]!

Tjetra, ju mund të ndihmoni [find an issue][issues], ne kemi zgjedhur disa me etiketat [`help wanted`][help] dhe [`impl-period`][impl] të cilat mund të përdorin veçanërisht ndonjë ndihmë. 
Ju mund të jeni më të interesuar për [#40][vendor], duke zbatuar të gjitha elementet e brendshme të shitësit në x86.Kjo çështje ka disa tregues të mirë se ku të filloni!

Nëse keni pyetje të përgjithshme, mos ngurroni në [join us on gitter][gitter] dhe pyesni rreth!Mos ngurroni të bëni ping me@BurntSushi ose@alexcrichton me pyetje.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Si të shkruani shembuj për intrinsics stdarch

Ekzistojnë disa tipare që duhet të jenë të aktivizuara që brendia e dhënë të funksionojë si duhet dhe shembulli duhet të ekzekutohet nga `cargo test --doc` vetëm kur tipari mbështetet nga CPU.

Si rezultat, `fn main` i parazgjedhur që gjenerohet nga `rustdoc` nuk do të funksionojë (në shumicën e rasteve).
Merrni parasysh përdorimin e mëposhtëm si një udhëzues për të siguruar që shembulli juaj të funksionojë siç pritet.

```rust
/// # // Na duhet cfg_target_feature për të siguruar që shembulli është vetëm
/// # // drejtohet nga `cargo test --doc` kur CPU mbështet funksionin
/// # #![feature(cfg_target_feature)]
/// # // Ne kemi nevojë për target_feature që i brendshëm të funksionojë
/// # #![feature(target_feature)]
/// #
/// # // rustdoc si parazgjedhje përdor `extern crate stdarch`, por na duhet
/// # // `#[macro_use]`
/// # # [makro_përdorimi] i jashtëm crate stdarch;
/// #
/// # // Funksioni kryesor i vërtetë
/// # fn main() {
/// #     // Ekzekutojeni këtë vetëm nëse mbështetet `<target feature>`
/// #     nëse cfg_feature_enabled! ("<target feature>"){
/// #         // Krijoni një funksion `worker` që do të ekzekutohet vetëm nëse karakteristika e synuar
/// #         // mbështetet dhe sigurohuni që `target_feature` të jetë i aktivizuar për punëtorin tuaj
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         i pasigurt fn worker() {
/// // Shkruani shembullin tuaj këtu.Karakteristikat e brendshme të veçanta do të funksionojnë këtu!Shko e egër!
///
/// #         }
///
/// #         i pasigurt { worker(); }
/// #     }
/// # }
```

Nëse disa nga sintaksa e mësipërme nuk duken të njohura, seksioni [Documentation as tests] i [Rust Book] përshkruan sintaksën `rustdoc` mjaft mirë.
Si gjithmonë, mos ngurroni në [join us on gitter][gitter] dhe na pyesni nëse keni goditur ndonjë pengesë dhe faleminderit që ndihmuat për të përmirësuar dokumentacionin e `stdarch`!

# Udhëzime alternative të testimit

Në përgjithësi rekomandohet që të përdorni `ci/run.sh` për të ekzekutuar testet.
Megjithatë kjo mund të mos funksionojë për ju, p.sh. nëse jeni në Windows.

Në atë rast, mund të riktheheni përsëri në ekzekutimin e `cargo +nightly test` dhe `cargo +nightly test --release -p core_arch` për të testuar gjenerimin e kodit.
Vini re se këto kërkojnë të instalohet zinxhiri i veglave natën dhe që `rustc` të dijë për trefishin e synuar dhe CPU-në e tij.
Në veçanti ju duhet të vendosni ndryshoren e mjedisit `TARGET` siç do të bënit për `ci/run.sh`.
Për më tepër ju duhet të vendosni `RUSTCFLAGS` (keni nevojë për `C`) për të treguar tiparet e synuara, p.sh. `RUSTCFLAGS="-C -target-features=+avx2"`.
Ju gjithashtu mund të vendosni `-C -target-cpu=native` nëse jeni duke u zhvilluar "just" kundrejt CPU-së suaj aktuale.

Paralajmëroni që kur përdorni këto udhëzime alternative, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], p.sh.
Testet e gjenerimit të udhëzimeve mund të dështojnë sepse çmontuesi i emërtoi ndryshe, p.sh.
mund të gjenerojë `vaesenc` në vend të udhëzimeve `aesenc` pavarësisht se ata sillen njësoj.
Gjithashtu këto udhëzime ekzekutojnë më pak teste sesa do të bëheshin normalisht, prandaj mos u habisni kur kur përfundimisht kërkoni disa gabime mund të shfaqen për testet që nuk janë përfshirë këtu.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






