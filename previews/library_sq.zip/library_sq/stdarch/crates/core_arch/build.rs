use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Përdoret për të treguar shënimet tona `#[assert_instr]` se të gjithë intrinsics simd janë në dispozicion për të testuar kodin e tyre, pasi që disa janë të mbyllur pas një `-Ctarget-feature=+unimplemented-simd128` shtesë që nuk ka ndonjë ekuivalent në `#[target_feature]` tani.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}