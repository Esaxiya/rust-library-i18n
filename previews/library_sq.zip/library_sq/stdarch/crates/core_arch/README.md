`core::arch` - Praktikat specifike të arkitekturës kryesore të bibliotekës së Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Moduli `core::arch` zbaton elemente të brendshme të varura nga arkitektura (p.sh. SIMD).

# Usage 

`core::arch` është në dispozicion si pjesë e `libcore` dhe ri-eksportohet nga `libstd`.Preferoni ta përdorni atë përmes `core::arch` ose `std::arch` sesa përmes këtij crate.
Karakteristikat e paqëndrueshme janë shpesh të disponueshme në Rust natën përmes `feature(stdsimd)`.

Përdorimi i `core::arch` përmes këtij crate kërkon Rust natën, dhe ai mund (dhe bën) të prishet shpesh.Rastet e vetme në të cilat duhet të konsideroni ta përdorni përmes këtij crate janë:

* nëse keni nevojë të ri-përpiloni vetë `core::arch`, p.sh., me veçori të veçanta të synuara të aktivizuara, të cilat nuk janë të aktivizuara për `libcore`/`libstd`.
Note: nëse keni nevojë ta ri-përpiloni atë për një objektiv jo-standard, ju lutemi preferoni të përdorni `xargo` dhe ri-përpiloni `libcore`/`libstd` sipas rastit në vend që të përdorni këtë crate.
  
* duke përdorur disa veçori që mund të mos jenë të disponueshme edhe pas veçorive të paqëndrueshme Rust.Ne përpiqemi t'i mbajmë këto në minimum.
Nëse keni nevojë të përdorni disa nga këto veçori, ju lutemi hapni një çështje në mënyrë që t'i ekspozojmë ato në Rust natën dhe t'i përdorni që andej.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` shpërndahet kryesisht nën kushtet e licencës MIT dhe licencës Apache (Version 2.0), me pjesë të mbuluara nga licenca të ndryshme si BSD.

Shihni LICENCSE-APACHE dhe LICENC-MIT për detaje.

# Contribution

Në qoftë se nuk shprehni shprehimisht ndryshe, çdo kontribut i paraqitur qëllimisht për përfshirje në `core_arch` nga ju, siç përcaktohet në licencën Apache-2.0, do të jetë i licencuar dyfish si më sipër, pa ndonjë kusht ose kusht shtesë.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












