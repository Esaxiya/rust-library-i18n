#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Shihni [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Shihni [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Shihni [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Shihni [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Shihni [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Shihni [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Merrni vijën e fshehtë që përmban adresën `p` duke përdorur `rw` dhe `locality` të dhëna.
///
/// `rw` duhet të jetë një nga:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): prefetch po përgatitet për një lexim.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): prefetch po përgatitet për një shkrim.
///
/// `locality` duhet të jetë një nga:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Parametër transmetimi ose jo-kohor, për të dhënat që përdoren vetëm një herë.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Merrni në memorien e fshehtë të nivelit 3.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Merrni në memorien e fshehtë të nivelit 2.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Merrni në memorien e fshehtë të nivelit 1.
///
/// Udhëzimet e paravendosjes së kujtesës sinjalizojnë në sistemin e kujtesës se qasja e kujtesës nga një adresë e specifikuar ka të ngjarë të ndodhë në future afër.
/// Sistemi i kujtesës mund të përgjigjet duke ndërmarrë veprime që pritet të përshpejtojnë hyrjen e kujtesës kur ato ndodhin, të tilla si para-ngarkimi i adresës së specifikuar në një ose më shumë memorje memorie.
///
/// Meqenëse këto sinjale janë vetëm sugjerime, është e vlefshme që një CPU i veçantë të trajtojë ndonjë ose të gjitha udhëzimet e paracaktimit si NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Ne përdorim `llvm.prefetch` instrinsic me `cache type` =1 (memorje e të dhënave).
    // `rw` dhe `strategy` bazohen në parametrat e funksionit.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}