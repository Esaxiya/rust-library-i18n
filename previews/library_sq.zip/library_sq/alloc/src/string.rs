//! Një varg i koduar, i rritshëm, i koduar nga UTF-8.
//!
//! Ky modul përmban llojin [`String`], [`ToString`] trait për shndërrim në vargje dhe disa lloje gabimesh që mund të rezultojnë nga puna me ["String"] s.
//!
//!
//! # Examples
//!
//! Ka mënyra të shumta për të krijuar një [`String`] të ri nga një varg fjalë për fjalë:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Ju mund të krijoni një [`String`] të ri nga një ekzistues duke u bashkuar me
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Nëse keni një vector me bajtë të vlefshëm UTF-8, mund të bëni një [`String`] prej tij.Mund të bësh edhe të kundërtën.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Ne e dimë që këto bajte janë të vlefshme, kështu që ne do të përdorim `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Një varg i koduar, i rritshëm, i koduar nga UTF-8.
///
/// Lloji `String` është lloji më i zakonshëm i vargut që ka pronësi mbi përmbajtjen e vargut.Ajo ka një marrëdhënie të ngushtë me homologun e saj të huazuar, primitivin [`str`].
///
/// # Examples
///
/// Ju mund të krijoni një `String` nga [a literal string][`str`] me [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Ju mund të shtoni një [`char`] në një `String` me metodën [`push`] dhe të shtoni një [`&str`] me metodën [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Nëse keni një vector me UTF-8 bajt, mund të krijoni një `String` prej tij me metodën [`from_utf8`]:
///
/// ```
/// // disa bajte, në një vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Ne e dimë që këto bajte janë të vlefshme, kështu që ne do të përdorim `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `Vargjet janë gjithmonë të vlefshme UTF-8.Kjo ka disa implikime, e para prej të cilave është se nëse keni nevojë për një varg jo-UTF-8, merrni parasysh [`OsString`].Isshtë e ngjashme, por pa kufizimin UTF-8.Implikimi i dytë është që ju nuk mund të indeksoni në një `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indeksimi synon të jetë një operacion me kohë konstante, por kodimi UTF-8 nuk na lejon ta bëjmë këtë.Për më tepër, nuk është e qartë se çfarë lloj gjëje duhet të kthejë indeksi: një bajt, një kodifikim ose një grup grafemash.
/// Metodat [`bytes`] dhe [`chars`] kthejnë përsëritësit respektivisht në dy të parat.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String` implementon [`Deref`] `<Target=str>`, dhe kështu trashëgoi të gjitha metodat e [str]].Përveç kësaj, kjo do të thotë që ju mund të kaloni një `String` në një funksion që merr një [`&str`] duke përdorur një ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Kjo do të krijojë një [`&str`] nga `String` dhe do ta kalojë atë brenda. Ky konvertim është shumë i lirë, dhe kështu përgjithësisht, funksionet do t'i pranojnë [`&str`] si argumente nëse nuk u duhet një `String` për ndonjë arsye specifike.
///
/// Në raste të caktuara Rust nuk ka informacion të mjaftueshëm për të bërë këtë shndërrim, të njohur si detyrim [`Deref`].Në shembullin vijues një fetë vargu [`&'a str`][`&str`] zbaton trait `TraitExample`, dhe funksioni `example_func` merr gjithçka që zbaton trait.
/// Në këtë rast Rust do të duhet të bëjë dy shndërrime të nënkuptuara, të cilat Rust nuk ka mjetet për të bërë.
/// Për atë arsye, shembulli i mëposhtëm nuk do të përpilohet.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Ekzistojnë dy opsione që do të funksiononin në vend.E para do të ishte ndryshimi i linjës `example_func(&example_string);` në `example_func(example_string.as_str());`, duke përdorur metodën [`as_str()`] për të nxjerrë në mënyrë eksplicite fetë vargu që përmban vargun.
/// Mënyra e dytë ndryshon `example_func(&example_string);` në `example_func(&*example_string);`.
/// Në këtë rast ne jemi duke referuar një `String` në një [`str`][`&str`], pastaj duke iu referuar [`str`][`&str`] përsëri në [`&str`].
/// Mënyra e dytë është më idiomatike, megjithatë të dy punojnë për ta bërë konvertimin në mënyrë të qartë sesa të mbështeten në shndërrimin e nënkuptuar.
///
/// # Representation
///
/// Një `String` përbëhet nga tre përbërës: një tregues për disa bajt, një gjatësi dhe një kapacitet.Treguesi tregon një buffer të brendshëm që `String` përdor për të ruajtur të dhënat e tij.Gjatësia është numri i bajteve që ruhen aktualisht në buffer, dhe kapaciteti është madhësia e buffer-it në bajte.
///
/// Si e tillë, gjatësia do të jetë gjithmonë më e vogël ose e barabartë me kapacitetin.
///
/// Ky buffer ruhet gjithnjë në tog.
///
/// Këto mund t'i shikoni me metodat [`as_ptr`], [`len`] dhe [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Përditësoni këtë kur stabilizohet vec_into_raw_part.
/// // Parandalon hedhjen automatike të të dhënave të Vargut
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // historia ka nëntëmbëdhjetë bajte
/// assert_eq!(19, len);
///
/// // Ne mund të rindërtojmë një Varg nga ptr, len dhe kapacitetet.
/// // E gjithë kjo është e pasigurt sepse ne jemi përgjegjës për t'u siguruar që përbërësit janë të vlefshëm:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Nëse një `String` ka kapacitet të mjaftueshëm, shtimi i elementeve nuk do të alokohet përsëri.Për shembull, merrni parasysh këtë program:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Kjo do të nxjerrë sa vijon:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Në fillim, nuk kemi asnjë memorie të alokuar fare, por ndërsa i shtohemi vargut, ajo rrit kapacitetin e saj në mënyrë të përshtatshme.Nëse në vend të kësaj përdorim metodën [`with_capacity`] për të alokuar kapacitetin e duhur fillimisht:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Ne përfundojmë me një dalje tjetër:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Këtu, nuk ka nevojë të caktoni më shumë memorie brenda lakut.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Një vlerë e mundshme e gabimit kur konverton një `String` nga një bajt UTF-8 vector.
///
/// Ky lloj është lloji i gabimit për metodën [`from_utf8`] në [`String`].
/// Designedshtë dizajnuar në një mënyrë të tillë për të shmangur rialokimet me kujdes: metoda [`into_bytes`] do të kthejë bajtin vector që është përdorur në përpjekjen e konvertimit.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Lloji [`Utf8Error`] i siguruar nga [`std::str`] paraqet një gabim që mund të ndodhë kur shndërroni një fetë të [`u8`] s në [`&str`].
/// Në këtë kuptim, është një analog i `FromUtf8Error`, dhe mund ta merrni një nga `FromUtf8Error` përmes metodës [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// // disa bajt të pavlefshëm, në një vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Një vlerë e mundshme e gabimit kur konverton një `String` nga një fetë bajt UTF-16.
///
/// Ky lloj është lloji i gabimit për metodën [`from_utf16`] në [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Krijon një `String` të ri bosh.
    ///
    /// Duke qenë se `String` është bosh, kjo nuk do të caktojë ndonjë buffer fillestar.Ndërsa kjo do të thotë që ky operacion fillestar është shumë i lirë, ai mund të shkaktojë shpërndarje të tepruar më vonë kur shtoni të dhëna.
    ///
    /// Nëse keni një ide se sa të dhëna do të mbajë `String`, merrni parasysh metodën [`with_capacity`] për të parandaluar alokimin e tepruar.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Krijon një `String` të ri bosh me një kapacitet të veçantë.
    ///
    /// `String` s kanë një buffer të brendshëm për të mbajtur të dhënat e tyre.
    /// Kapaciteti është gjatësia e këtij bufferi dhe mund të kërkohet me metodën [`capacity`].
    /// Kjo metodë krijon një `String` të zbrazët, por një me një buffer fillestar që mund të mbajë `capacity` bajte.
    /// Kjo është e dobishme kur mund të jeni duke shtuar një tufë të dhënash në `String`, duke zvogëluar numrin e rialokimeve që duhet të bëjë.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Nëse kapaciteti i dhënë është `0`, asnjë alokim nuk do të ndodhë, dhe kjo metodë është identike me metodën [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Vargu nuk përmban karaktere, edhe pse ka kapacitet për më shumë
    /// assert_eq!(s.len(), 0);
    ///
    /// // Të gjitha këto bëhen pa rialokuar ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... por kjo mund ta bëjë vargun të rialokohet
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): me cfg(test) metoda e natyrshme `[T]::to_vec`, e cila kërkohet për këtë përkufizim të metodës, nuk është e disponueshme.
    // Meqenëse ne nuk e kërkojmë këtë metodë për qëllime testimi, unë thjesht do ta shënoj atë NB shikoni modulin slice::hack në slice.rs për më shumë informacion
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Shndërron një vector bajtësh në `String`.
    ///
    /// Një varg ([`String`]) është bërë nga bajte ([`u8`]), dhe një vector bajt ([`Vec<u8>`]) është bërë nga bajte, kështu që ky funksion shndërrohet në mes të dyve.
    /// Jo të gjitha fetë bajtët janë të vlefshme `String`, megjithatë: `String` kërkon që ajo të jetë e vlefshme UTF-8.
    /// `from_utf8()` kontrollon për të siguruar që bajtet janë të vlefshme UTF-8, dhe pastaj bën konvertimin.
    ///
    /// Nëse jeni të sigurt që feta e bajtit është e vlefshme UTF-8 dhe nuk doni të kryeni kontrollin e vlefshmërisë, ekziston një version i pasigurt i këtij funksioni, [`from_utf8_unchecked`], i cili ka të njëjtën sjellje, por kalon kontrollin.
    ///
    ///
    /// Kjo metodë do të kujdeset që të mos kopjoni vector, për hir të efikasitetit.
    ///
    /// Nëse keni nevojë për një [`&str`] në vend të një `String`, merrni parasysh [`str::from_utf8`].
    ///
    /// Inversi i kësaj metode është [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Kthen [`Err`] nëse feta nuk është UTF-8 me një përshkrim pse bajtet e dhëna nuk janë UTF-8.Përfshihet edhe vector ku keni lëvizur.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // disa bajte, në një vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Ne e dimë që këto bajte janë të vlefshme, kështu që ne do të përdorim `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bajte të pasakta:
    ///
    /// ```
    /// // disa bajt të pavlefshëm, në një vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Shihni dokumentet për [`FromUtf8Error`] për më shumë detaje se çfarë mund të bëni me këtë gabim.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Shndërron një pjesë bajtesh në një varg, duke përfshirë karaktere të pavlefshëm.
    ///
    /// Vargjet janë bërë nga bajte ([`u8`]), dhe një pjesë e bajteve ([`&[u8]`][byteslice]) është bërë nga bajte, kështu që ky funksion shndërrohet në mes të dyve.Jo të gjitha fetë bajtët janë vargje të vlefshme, megjithatë: nga vargjet kërkohet që të jenë të vlefshme UTF-8.
    /// Gjatë këtij shndërrimi, `from_utf8_lossy()` do të zëvendësojë çdo sekuencë të pavlefshme UTF-8 me [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], e cila duket si kjo:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Nëse jeni i sigurt që feta e bajtave është e vlefshme UTF-8 dhe nuk doni të merrni lartësinë e konvertimit, ekziston një version i pasigurt i këtij funksioni, [`from_utf8_unchecked`], i cili ka të njëjtën sjellje por kalon kontrollet.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Ky funksion kthen një [`Cow<'a, str>`].Nëse feta e bajtit tonë është UTF-8 e pavlefshme, atëherë duhet të fusim karakteret zëvendësuese, të cilat do të ndryshojnë madhësinë e vargut, dhe kështu, kërkohet një `String`.
    /// Por nëse është tashmë i vlefshëm UTF-8, nuk kemi nevojë për një alokim të ri.
    /// Ky lloj kthimi na lejon të trajtojmë të dy rastet.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // disa bajte, në një vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bajte të pasakta:
    ///
    /// ```
    /// // disa bajte të pavlefshëm
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Dekodoni një vector `v` të koduar me UTF-16 në `String`, duke kthyer [`Err`] nëse `v` përmban ndonjë të dhënë të pavlefshme.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Kjo nuk është bërë përmes mbledhjes: : <Result<_, _>> () për arsye të performancës.
        // FIXME: funksioni mund të thjeshtohet përsëri kur #48994 të jetë i mbyllur.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Deshifroni një fetë të koduar `v` me UTF-16 në `String`, duke zëvendësuar të dhënat e pavlefshme me [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Ndryshe nga [`from_utf8_lossy`] i cili kthen një [`Cow<'a, str>`], `from_utf16_lossy` kthen një `String` pasi konvertimi UTF-16 në UTF-8 kërkon një alokim të kujtesës.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Zbërthen një `String` në përbërësit e tij të papërpunuar.
    ///
    /// Kthen treguesin e papërpunuar te të dhënat themelore, gjatësinë e vargut (në bajt) dhe kapacitetin e caktuar të të dhënave (në bajt).
    /// Këto janë të njëjtat argumente në të njëjtën renditje si argumentet për [`from_raw_parts`].
    ///
    /// Pas thirrjes së këtij funksioni, telefonuesi është përgjegjës për kujtesën e administruar më parë nga `String`.
    /// Mënyra e vetme për ta bërë këtë është kthimi i treguesit të papërpunuar, gjatësisë dhe kapacitetit përsëri në një `String` me funksionin [`from_raw_parts`], duke lejuar shkatërruesin të kryejë pastrimin.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Krijon një `String` të ri nga një gjatësi, kapacitet dhe tregues.
    ///
    /// # Safety
    ///
    /// Kjo është shumë e pasigurt, për shkak të numrit të invariancave që nuk kontrollohen:
    ///
    /// * Kujtesa në `buf` duhet të jetë alokuar më parë nga i njëjti shpërndarës që përdor biblioteka standarde, me një shtrirje të kërkuar saktësisht 1.
    /// * `length` duhet të jetë më pak se ose e barabartë me `capacity`.
    /// * `capacity` duhet të jetë vlera e saktë.
    /// * Bajtet e para `length` në `buf` duhet të jenë të vlefshme UTF-8.
    ///
    /// Shkelja e këtyre mund të shkaktojë probleme si prishja e strukturave të brendshme të të dhënave të alokuesit.
    ///
    /// Pronësia e `buf` transferohet në mënyrë efektive te `String` e cila më pas mund të zhvendosë, rialokojë ose ndryshojë përmbajtjen e kujtesës të treguar nga treguesi sipas dëshirës.
    /// Sigurohuni që asgjë tjetër nuk e përdor treguesin pas thirrjes së këtij funksioni.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Përditësoni këtë kur stabilizohet vec_into_raw_part.
    ///     // Parandalon hedhjen automatike të të dhënave të Vargut
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Shndërron një vector bajtësh në `String` pa kontrolluar që vargu përmban UTF-8 të vlefshëm.
    ///
    /// Shihni versionin e sigurt, [`from_utf8`], për më shumë detaje.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Ky funksion është i pasigurt sepse nuk kontrollon që bajtet e kaluara janë të vlefshme UTF-8.
    /// Nëse ky kufizim shkelet, mund të shkaktojë probleme të pasigurisë së kujtesës me përdoruesit future të `String`, pasi pjesa tjetër e bibliotekës standarde supozon se `Vargu` janë të vlefshëm UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // disa bajte, në një vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Shndërron një `String` në një bajt vector.
    ///
    /// Kjo konsumon `String`, kështu që nuk kemi nevojë të kopjojmë përmbajtjen e tij.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Nxjerr një fetë vargu që përmban të gjithë `String`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Shndërron një `String` në një fetë vargu të ndryshueshëm.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Shton një fetë vargu të dhënë në fund të këtij `String`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Kthen kapacitetin e kësaj "Vargu", në bajte.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Siguron që kapaciteti i kësaj String është të paktën `additional` bajt më i madh se gjatësia e tij.
    ///
    /// Kapaciteti mund të rritet me më shumë se `additional` bajte nëse zgjedh, për të parandaluar rialokimet e shpeshta.
    ///
    ///
    /// Nëse nuk e dëshironi këtë sjellje "at least", shihni metodën [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics nëse kapaciteti i ri tejkalon [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Kjo në të vërtetë nuk mund të rrisë kapacitetin:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s tani ka një gjatësi prej 2 dhe një kapacitet prej 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Meqenëse tashmë kemi një kapacitet shtesë 8, duke e quajtur këtë ...
    /// s.reserve(8);
    ///
    /// // ... në të vërtetë nuk rritet.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Siguron që kapaciteti i kësaj String është `additional` bajt më i madh se gjatësia e tij.
    ///
    /// Merrni parasysh përdorimin e metodës [`reserve`] nëse nuk dini absolutisht më mirë se alokuesi.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics nëse kapaciteti i ri tejkalon `usize`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Kjo në të vërtetë nuk mund të rrisë kapacitetin:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s tani ka një gjatësi prej 2 dhe një kapacitet prej 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Meqenëse tashmë kemi një kapacitet shtesë 8, duke e quajtur këtë ...
    /// s.reserve_exact(8);
    ///
    /// // ... në të vërtetë nuk rritet.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Mundohet të rezervojë kapacitetin për të paktën `additional` më shumë elementë që do të futen në `String` të dhënë.
    /// Grumbullimi mund të rezervojë më shumë hapësirë për të shmangur rialokimet e shpeshta.
    /// Pas thirrjes `reserve`, kapaciteti do të jetë më i madh ose i barabartë me `self.len() + additional`.
    /// Nuk bën asgjë nëse kapaciteti është tashmë i mjaftueshëm.
    ///
    /// # Errors
    ///
    /// Nëse kapaciteti tejkalohet, ose alokuesi raporton një dështim, atëherë një gabim kthehet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Rezervoni paraprakisht kujtesën, duke dalë nëse nuk mundemi
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tani e dimë që kjo nuk mund të OOM në mes të punës sonë komplekse
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Përpiqet të rezervojë kapacitetin minimal për saktësisht `additional` më shumë elementë që do të futen në `String` të dhënë.
    ///
    /// Pas thirrjes `reserve_exact`, kapaciteti do të jetë më i madh ose i barabartë me `self.len() + additional`.
    /// Nuk bën asgjë nëse kapaciteti është tashmë i mjaftueshëm.
    ///
    /// Vini re se alokuesi mund t'i japë koleksionit më shumë hapësirë sesa kërkon.
    /// Prandaj, kapaciteti nuk mund të mbështetet për të qenë saktësisht minimal.
    /// Preferoni `reserve` nëse priten futje të future.
    ///
    /// # Errors
    ///
    /// Nëse kapaciteti tejkalohet, ose alokuesi raporton një dështim, atëherë një gabim kthehet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Rezervoni paraprakisht kujtesën, duke dalë nëse nuk mundemi
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tani e dimë që kjo nuk mund të OOM në mes të punës sonë komplekse
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Zvogëlon kapacitetin e këtij `String` që të përputhet me gjatësinë e tij.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Zvogëlon kapacitetin e këtij `String` me një kufi më të ulët.
    ///
    /// Kapaciteti do të mbetet të paktën aq i madh sa gjatësia dhe vlera e furnizuar.
    ///
    ///
    /// Nëse kapaciteti aktual është më i vogël se kufiri i poshtëm, ky është një mos-opsion.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Shton [`char`] të dhënë në fund të këtij `String`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Kthen një fetë bajtësh të përmbajtjes së kësaj "Vargje".
    ///
    /// Inversi i kësaj metode është [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Shkurton këtë `String` në gjatësinë e specifikuar.
    ///
    /// Nëse `new_len` është më e madhe se gjatësia aktuale e vargut, kjo nuk ka efekt.
    ///
    ///
    /// Vini re se kjo metodë nuk ka efekt në kapacitetin e caktuar të vargut
    ///
    /// # Panics
    ///
    /// Panics nëse `new_len` nuk shtrihet në një kufi [`char`].
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Heq karakterin e fundit nga tampon vargu dhe e kthen atë.
    ///
    /// Kthen [`None`] nëse ky `String` është bosh.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Heq një [`char`] nga ky `String` në një pozicion bajt dhe e kthen atë.
    ///
    /// Ky është një operacion *O*(*n*), pasi kërkon kopjimin e çdo elementi në buffer.
    ///
    /// # Panics
    ///
    /// Panics nëse `idx` është më e madhe ose e barabartë me gjatësinë e "Vargut", ose nëse nuk shtrihet në një kufi [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Hiqni të gjitha përputhjet e modelit `pat` në `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Ndeshjet do të zbulohen dhe hiqen në mënyrë të përsëritur, kështu që në rastet kur modelet mbivendosen, vetëm modeli i parë do të hiqet:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SIGURIA: fillimi dhe mbarimi do të jenë në kufijtë utf8 bajt për
        // dokumentet e Kërkuesit
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Mban vetëm karakteret e specifikuara nga kallëzuesi.
    ///
    /// Me fjalë të tjera, hiqni të gjitha karakteret `c` ashtu që `f(c)` të kthejë `false`.
    /// Kjo metodë vepron në vend, duke vizituar secilin karakter saktësisht një herë në rendin origjinal dhe ruan rendin e karaktereve të ruajtura.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Rendi i saktë mund të jetë i dobishëm për të ndjekur gjendjen e jashtme, si një indeks.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Drejto idx te karakteri tjetër
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Fut një karakter në këtë `String` në një pozicion bajt.
    ///
    /// Ky është një operacion *O*(*n*) pasi kërkon kopjimin e çdo elementi në buffer.
    ///
    /// # Panics
    ///
    /// Panics nëse `idx` është më e madhe se gjatësia e "Vargut", ose nëse nuk shtrihet në një kufi [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Fut një fetë vargu në këtë `String` në një pozicion bajt.
    ///
    /// Ky është një operacion *O*(*n*) pasi kërkon kopjimin e çdo elementi në buffer.
    ///
    /// # Panics
    ///
    /// Panics nëse `idx` është më e madhe se gjatësia e "Vargut", ose nëse nuk shtrihet në një kufi [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Kthen një referencë të ndryshueshme për përmbajtjen e këtij `String`.
    ///
    /// # Safety
    ///
    /// Ky funksion është i pasigurt sepse nuk kontrollon që bajtet e kaluara janë të vlefshme UTF-8.
    /// Nëse ky kufizim shkelet, mund të shkaktojë probleme të pasigurisë së kujtesës me përdoruesit future të `String`, pasi pjesa tjetër e bibliotekës standarde supozon se `Vargu` janë të vlefshëm UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Kthen gjatësinë e këtij `String`, në bajte, jo ["char"] ose grafema.
    /// Me fjalë të tjera, mund të mos jetë ajo që një njeri e konsideron gjatësinë e telit.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Kthen `true` nëse ky `String` ka një gjatësi zero, dhe ndryshe `false`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ndan vargun në dy në indeksin e dhënë të bajtit.
    ///
    /// Kthen një `String` të sapo alokuar.
    /// `self` përmban bajte `[0, at)`, dhe `String` të kthyer përmban bajte `[at, len)`.
    /// `at` duhet të jetë në kufirin e një pike kodi UTF-8.
    ///
    /// Vini re se kapaciteti i `self` nuk ndryshon.
    ///
    /// # Panics
    ///
    /// Panics nëse `at` nuk është në kufirin e pikës së kodit `UTF-8`, ose nëse është përtej pikës së kodit të fundit të vargut.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Shkurton këtë `String`, duke hequr të gjithë përmbajtjen.
    ///
    /// Ndërsa kjo do të thotë që `String` do të ketë një gjatësi zero, ai nuk prek kapacitetin e tij.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Krijon një iterator kullues që heq diapazonin e specifikuar në `String` dhe jep `chars` të hequr.
    ///
    ///
    /// Note: Diapazoni i elementeve hiqet edhe nëse iteratori nuk konsumohet deri në fund.
    ///
    /// # Panics
    ///
    /// Panics nëse pika e fillimit ose pika e mbarimit nuk shtrihen në një kufi [`char`], ose nëse ato janë jashtë kufijve.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Hiqni diapazonin deri në β nga vargu
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Një gamë e plotë pastron vargun
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Siguria e kujtesës
        //
        // Versioni String i Drain nuk ka çështjet e sigurisë së kujtesës të versionit vector.
        // Të dhënat janë thjesht bajte.
        // Për shkak se heqja e diapazonit ndodh në Drop, nëse rrjedhësi Drain rrjedh, heqja nuk do të ndodhë.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Merrni dy hua të njëkohshme.
        // Vargu &mut nuk do të aksesohet derisa të përfundojë përsëritja, në Drop.
        let self_ptr = self as *mut _;
        // SIGURIA: `slice::range` dhe `is_char_boundary` bëjnë kontrollet e duhura të kufijve.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Heq vargun e specifikuar në varg dhe e zëvendëson atë me vargun e dhënë.
    /// Vargu i dhënë nuk ka nevojë të jetë i njëjti gjatësi me diapazonin.
    ///
    /// # Panics
    ///
    /// Panics nëse pika e fillimit ose pika e mbarimit nuk shtrihen në një kufi [`char`], ose nëse ato janë jashtë kufijve.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Zëvendësoni diapazonin deri në β nga vargu
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Siguria e kujtesës
        //
        // Replace_range nuk ka çështjet e sigurisë së kujtesës të një bashkimi vector.
        // të versionit vector.Të dhënat janë thjesht bajte.

        // PARALAJMRIM: Përfshirja e kësaj ndryshore do të ishte e paqartë (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // PARALAJMRIM: Përfshirja e kësaj ndryshore do të ishte e paqartë (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Përdorimi i `range` përsëri do të ishte i paqëndrueshëm (#81138) Supozojmë se kufijtë e raportuar nga `range` mbeten të njëjtat, por një zbatim kundërshtar mund të ndryshojë midis thirrjeve
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Konverton këtë `String` në një ["Kutia"] "<" ["str"] ">".
    ///
    /// Kjo do të heqë çdo kapacitet të tepërt.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Kthen një pjesë të bajteve [`u8`] që u përpoqën të shndërroheshin në `String`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // disa bajt të pavlefshëm, në një vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Kthen bajtët që u përpoqën të shndërroheshin në `String`.
    ///
    /// Kjo metodë është ndërtuar me kujdes për të shmangur alokimin.
    /// Do të konsumojë gabimin, duke lëvizur bajtet, kështu që një kopje e bajtëve nuk ka nevojë të bëhet.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // disa bajt të pavlefshëm, në një vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Merrni një `Utf8Error` për të marrë më shumë detaje në lidhje me dështimin e konvertimit.
    ///
    /// Lloji [`Utf8Error`] i siguruar nga [`std::str`] paraqet një gabim që mund të ndodhë kur shndërroni një fetë të [`u8`] s në [`&str`].
    /// Në këtë kuptim, është një analog me `FromUtf8Error`.
    /// Shihni dokumentacionin e tij për më shumë detaje mbi përdorimin e tij.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// // disa bajt të pavlefshëm, në një vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // bajti i parë është i pavlefshëm këtu
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Për shkak se ne po përsërisim mbi `String`, ne mund të shmangim të paktën një alokim duke marrë vargun e parë nga iteratori dhe duke i bashkangjitur të gjitha vargjet pasuese.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Për shkak se po përsërisim mbi CoWs, ne mund të shmangim të paktën një alokim duke marrë artikullin e parë dhe duke ia bashkangjitur të gjithë artikujt vijues.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Një impl komoditet që delegon në impl për `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Krijon një `String` bosh.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Zbaton operatorin `+` për bashkimin e dy vargjeve.
///
/// Kjo konsumon `String` në anën e majtë dhe ri-përdor buffer-in e tij (duke e rritur nëse është e nevojshme).
/// Kjo është bërë për të shmangur caktimin e një `String` të ri dhe kopjimin e të gjithë përmbajtjes në çdo operacion, gjë që do të çonte në kohën e ekzekutimit *O*(*n*^ 2) kur ndërton një varg *n*-bajt me bashkimin e përsëritur.
///
///
/// Vargu në anën e djathtë është vetëm i huazuar;përmbajtja e tij kopjohet në `String` të kthyer.
///
/// # Examples
///
/// Bashkimi i dy String `s merr të parën nga vlera dhe merr hua të dytën:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` është zhvendosur dhe nuk mund të përdoret më këtu.
/// ```
///
/// Nëse dëshironi të vazhdoni të përdorni `String` të parë, mund ta klononi atë dhe t'i bashkangjiteni klonit në vend të kësaj:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` është ende e vlefshme këtu.
/// ```
///
/// Fetë bashkuese të `&str` mund të bëhen duke shndërruar të parën në `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Zbaton operatorin `+=` për bashkimin e një `String`.
///
/// Kjo ka të njëjtën sjellje si metoda [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Një pseudonim i llojit për [`Infallible`].
///
/// Ky pseudonim ekziston për pajtueshmëri prapa dhe mund të zhvlerësohet përfundimisht.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Një trait për shndërrimin e një vlere në `String`.
///
/// Ky trait zbatohet automatikisht për çdo lloj që zbaton [`Display`] trait.
/// Si i tillë, `ToString` nuk duhet të zbatohet drejtpërdrejt:
/// [`Display`] duhet të implementohet në vend të kësaj, dhe ju merrni implementimin `ToString` falas.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Shndërron vlerën e dhënë në `String`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Në këtë implementim, metoda `to_string` panics nëse implementimi `Display` kthen një gabim.
/// Kjo tregon një implementim jo korrekt të `Display` pasi `fmt::Write for String` kurrë nuk kthen një gabim vetë.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Një udhëzues i zakonshëm është që të mos inline funksionet gjenerike.
    // Sidoqoftë, heqja e `#[inline]` nga kjo metodë shkakton regresione të papërfillshme.
    // Shihni <https://github.com/rust-lang/rust/pull/74852>, përpjekja e fundit për t'u përpjekur ta hiqni atë.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Shndërron një `&mut str` në një `String`.
    ///
    /// Rezultati ndahet në tog.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: tërheq testin në libstd, gjë që shkakton gabime këtu
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Konverton fetë e dhënë me kutinë `str` në një `String`.
    /// Notshtë e dukshme që feta `str` është në pronësi.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Konverton `String` të dhënë në një fetë `str` në kuti që është në pronësi.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Shndërron një fetë vargu në një variant të Huazuar.
    /// Asnjë shpërndarje grumbulli nuk është kryer dhe vargu nuk është kopjuar.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Konverton një varg në një variant të zotëruar.
    /// Asnjë shpërndarje grumbulli nuk është kryer dhe vargu nuk është kopjuar.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Konverton një referencë String në një variant të Huazuar.
    /// Asnjë shpërndarje grumbulli nuk është kryer dhe vargu nuk është kopjuar.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Shndërron `String` të dhënë në një vector `Vec` që mban vlera të tipit `u8`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Një iterator kullues për `String`.
///
/// Ky struktur është krijuar nga metoda [`drain`] në [`String`].
/// Shihni dokumentacionin e tij për më shumë.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Do të përdoret si&'një varg mut në shkatërrues
    string: *mut String,
    /// Fillimi i pjesës për tu hequr
    start: usize,
    /// Fundi i pjesës për tu hequr
    end: usize,
    /// Diapazoni aktual i mbetur për tu hequr
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Përdorni Vec::drain.
            // "Reaffirm" kontrollet e kufijve për të shmangur futjen përsëri të kodit panic.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Kthen vargun (nën) e mbetur të këtij iteratori si një fetë.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: uncomment AsRef nënkupton më poshtë kur stabilizohet.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Moskomentimi kur stabilizoni `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>për Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> për Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}