//! Treguesit e numërimit të referencës me një fije.'Rc' qëndron për 'Referencë
//! Counted'.
//!
//! Lloji [`Rc<T>`][`Rc`] siguron pronësinë e përbashkët të një vlere të tipit `T`, të alokuar në grumbull.
//! Duke thirrur [`clone`][clone] në [`Rc`] prodhon një tregues të ri për të njëjtën shpërndarje në grumbull.
//! Kur shkatërrohet treguesi i fundit [`Rc`] për një shpërndarje të caktuar, vlera e ruajtur në atë alokim (shpesh referohet si "inner value") gjithashtu hidhet.
//!
//! Referencat e ndara në Rust nuk lejojnë mutacionin si parazgjedhje, dhe [`Rc`] nuk bën përjashtim: zakonisht nuk mund të merrni një referencë të ndryshueshme për diçka brenda një [`Rc`].
//! Nëse keni nevojë për ndryshueshmëri, vendosni një [`Cell`] ose [`RefCell`] brenda [`Rc`];shih [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] përdor numërimin e referencës jo-atomike.
//! Kjo do të thotë që lartësia është shumë e ulët, por një [`Rc`] nuk mund të dërgohet midis fijeve, dhe për pasojë [`Rc`] nuk zbaton [`Send`][send].
//! Si rezultat, përpiluesi Rust do të kontrollojë *në kohën e përpilimit* që nuk po dërgoni [`Rc`] midis fijeve.
//! Nëse keni nevojë për numërimin e referencës atomike me shumë fije, përdorni [`sync::Arc`][arc].
//!
//! Metoda [`downgrade`][downgrade] mund të përdoret për të krijuar një tregues [`Weak`] që nuk zotëron.
//! Një tregues [`Weak`] mund të [[upgrade]][upgrade] d në një [`Rc`], por kjo do të kthejë [`None`] nëse vlera e ruajtur në alokim është rënë tashmë.
//! Me fjalë të tjera, treguesit `Weak` nuk e mbajnë gjallë vlerën brenda alokimit;megjithatë, ata *e mbajnë* gjallë ndarjen (rezervën mbështetëse për vlerën e brendshme).
//!
//! Një cikël midis treguesve [`Rc`] nuk do të shpërndahet kurrë.
//! Për këtë arsye, [`Weak`] përdoret për të prishur ciklet.
//! Për shembull, një pemë mund të ketë tregues të fortë [`Rc`] nga nyjet prindërore tek fëmijët, dhe treguesit [`Weak`] nga fëmijët përsëri te prindërit e tyre.
//!
//! `Rc<T>` automatikisht deferencat për `T` (përmes [`Deref`] trait), kështu që ju mund të telefononi metodat e `T` në një vlerë të tipit [`Rc<T>`][`Rc`].
//! Për të shmangur përplasjet e emrave me metodat e `T`, metodat e vetë [`Rc<T>`][`Rc`] janë funksione të shoqëruara, të quajtura duke përdorur [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Implementimet e traits si `Clone` gjithashtu mund të thirren duke përdorur sintaksë plotësisht të kualifikuar.
//! Disa njerëz preferojnë të përdorin sintaksë plotësisht të kualifikuar, ndërsa të tjerët preferojnë të përdorin sintaksë metodë-thirrje.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintaksa e thirrjes metodë
//! let rc2 = rc.clone();
//! // Sintaksa e kualifikuar plotësisht
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] nuk bën ri-referencë automatike te `T`, sepse vlera e brendshme mund të jetë rënë tashmë.
//!
//! # Referencat e klonimit
//!
//! Krijimi i një referencë të re për të njëjtën shpërndarje si një tregues ekzistues i numëruar i referencave bëhet duke përdorur `Clone` trait të zbatuar për [`Rc<T>`][`Rc`] dhe [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Të dy sintaksat më poshtë janë ekuivalente.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a dhe b të dy tregojnë për të njëjtin vend të kujtesës si foo.
//! ```
//!
//! Sintaksa `Rc::clone(&from)` është më idiomatika sepse përcjell më qartë kuptimin e kodit.
//! Në shembullin e mësipërm, kjo sintaksë e bën më të lehtë për të parë se ky kod po krijon një referencë të re sesa kopjon tërë përmbajtjen e foo.
//!
//! # Examples
//!
//! Merrni parasysh një skenar ku një grup i "Veglave" janë në pronësi të një `Owner` të caktuar.
//! Ne duam të tregojmë `Gadget` tonë në `Owner` të tyre.Ne nuk mund ta bëjmë këtë me pronësi unike, sepse më shumë se një vegël mund t'i përkasë të njëjtit `Owner`.
//! [`Rc`] na lejon të ndajmë një `Owner` midis 'Veglave' të shumëfishta, dhe `Owner` të mbetet i alokuar për aq kohë sa çdo pikë `Gadget` në të.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... fusha të tjera
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... fusha të tjera
//! }
//!
//! fn main() {
//!     // Krijoni një `Owner` të numëruar si referencë.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Krijoni `Vegël` që i përket `gadget_owner`.
//!     // Klonimi i `Rc<Owner>` na jep një tregues të ri për të njëjtën alokim `Owner`, duke rritur numrin e referencës në proces.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Hidhni variablin tonë lokal `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Përkundër rënies së `gadget_owner`, ne jemi akoma në gjendje të shtypim emrin e `Owner` të `Vegël`.
//!     // Kjo është për shkak se ne kemi lëshuar vetëm një `Rc<Owner>` të vetëm, jo `Owner` për të cilin tregon.
//!     // Për sa kohë që ka `Rc<Owner>` të tjerë që tregojnë në të njëjtën alokim `Owner`, ai do të mbetet i drejtpërdrejtë.
//!     // Projeksioni i fushës `gadget1.owner.name` funksionon sepse `Rc<Owner>` automatikisht heq referencat për `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Në fund të funksionit, `gadget1` dhe `gadget2` shkatërrohen, dhe bashkë me to referencat e fundit të numëruara për `Owner` tonë.
//!     // Gadget Man tani shkatërrohet gjithashtu.
//!     //
//! }
//! ```
//!
//! Nëse kërkesat tona ndryshojnë dhe ne gjithashtu duhet të jemi në gjendje të kalojmë nga `Owner` në `Gadget`, do të hasim probleme.
//! Një tregues [`Rc`] nga `Owner` në `Gadget` paraqet një cikël.
//! Kjo do të thotë se numri i referencave të tyre nuk mund të arrijë kurrë 0, dhe alokimi nuk do të shkatërrohet kurrë:
//! një rrjedhje kujtese.Në mënyrë që ta kalojmë këtë, ne mund të përdorim tregues [`Weak`].
//!
//! Rust në fakt e bën disi të vështirë për të prodhuar këtë lak në radhë të parë.Në mënyrë që të përfundojmë me dy vlera që tregojnë njëra-tjetrën, njëra prej tyre duhet të jetë e ndryshueshme.
//! Kjo është e vështirë sepse [`Rc`] zbaton sigurinë e kujtesës duke dhënë vetëm referenca të përbashkëta për vlerën që mbështjell, dhe këto nuk lejojnë mutacion të drejtpërdrejtë.
//! Ne duhet të mbështjellim pjesën e vlerës që dëshirojmë të shndërrojmë në një [`RefCell`], i cili siguron *ndryshueshmëri të brendshme*: një metodë për të arritur ndryshueshmërinë përmes një reference të përbashkët.
//! [`RefCell`] zbaton rregullat e huazimit të Rust gjatë kohës së ekzekutimit.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... fusha të tjera
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... fusha të tjera
//! }
//!
//! fn main() {
//!     // Krijoni një `Owner` të numëruar si referencë.
//!     // Vini re se ne kemi vendosur vector të `Pronarit` të`Vegël` brenda një `RefCell` në mënyrë që ta shndërrojmë atë përmes një reference të përbashkët.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Krijoni `Vegël` që i përket `gadget_owner`, si më parë.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Shtoni `Vegël` në `Owner` të tyre.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` huazimi dinamik përfundon këtu.
//!     }
//!
//!     // Përsërisni `Vegël` tonë, duke shtypur detajet e tyre.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` është një `Weak<Gadget>`.
//!         // Meqenëse treguesit `Weak` nuk mund të garantojnë se alokimi ende ekziston, ne duhet të telefonojmë `upgrade`, i cili kthen një `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Në këtë rast, ne e dimë që alokimi ekziston ende, kështu që ne thjesht `unwrap` `Option`.
//!         // Në një program më të komplikuar, mund t'ju duhet trajtimi i gabuar i gabimeve për një rezultat `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Në fund të funksionit, `gadget_owner`, `gadget1` dhe `gadget2` shkatërrohen.
//!     // Tani nuk ka tregues të fortë (`Rc`) për pajisjet, kështu që ato shkatërrohen.
//!     // Kjo zeron numrin e referencës tek Gadget Man, kështu që ai shkatërrohet gjithashtu.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Kjo është e papërshtatshme nga repr(C) në future kundër rregullimit të mundshëm të fushës, gjë që do të ndërhynte me [into|from]_raw() ndryshe të sigurt të llojeve të brendshme të ndryshueshme.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Një tregues i numërimit të referencës me një fije.'Rc' qëndron për 'Referencë
/// Counted'.
///
/// Shihni [module-level documentation](./index.html) për më shumë detaje.
///
/// Metodat e qenësishme të `Rc` janë të gjitha funksionet e shoqëruara, që do të thotë që ju duhet t'i thirrni si p.sh., [`Rc::get_mut(&mut value)`][get_mut] në vend të `value.get_mut()`.
/// Kjo shmang konfliktet me metodat e tipit të brendshëm `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Kjo pasiguri është në rregull sepse ndërsa kjo Rc është gjallë ne jemi të garantuar që treguesi i brendshëm është i vlefshëm.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Ndërton një `Rc<T>` të ri.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Ekziston një tregues i nënkuptuar i dobët i zotëruar nga të gjithë treguesit e fortë, i cili siguron që shkatërruesi i dobët kurrë të mos e lërë ndarjen ndërsa destruktori i fortë po funksionon, edhe nëse treguesi i dobët është i ruajtur brenda një të forti.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Ndërton një `Rc<T>` të ri duke përdorur një referencë të dobët ndaj vetvetes.
    /// Përpjekja për të azhurnuar referencën e dobët para se ky funksion të kthehet do të rezultojë në një vlerë `None`.
    ///
    /// Sidoqoftë, referenca e dobët mund të klonohet lirshëm dhe të ruhet për përdorim në një kohë të mëvonshme.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... më shumë fusha
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Ndërtoni pjesën e brendshme në gjendjen "uninitialized" me një referencë të vetme të dobët.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Importantshtë e rëndësishme që ne të mos heqim dorë nga pronësia e treguesit të dobët, përndryshe kujtesa mund të lirohet deri në kohën kur `data_fn` kthehet.
        // Nëse me të vërtetë do të donim të kalonim pronësinë, mund të krijonim një tregues shtesë të dobët për veten tonë, por kjo do të rezultojë në azhurnime shtesë të numërimit të dobët të referencës, i cili mund të mos ishte i nevojshëm ndryshe.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Referencat e forta duhet të zotërojnë së bashku një referencë të dobët të përbashkët, kështu që mos e përdorni destruktorin për referencën tonë të vjetër të dobët.
        //
        mem::forget(weak);
        strong
    }

    /// Ndërton një `Rc` të ri me përmbajtje të pa iniciale.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ndërton një `Rc` të ri me përmbajtje të pa iniciale, me kujtesën që mbushet me `0` bajte.
    ///
    ///
    /// Shihni [`MaybeUninit::zeroed`][zeroed] për shembuj të përdorimit korrekt dhe jo korrekt të kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ndërton një `Rc<T>` të ri, duke kthyer një gabim nëse alokimi dështon
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Ekziston një tregues i nënkuptuar i dobët i zotëruar nga të gjithë treguesit e fortë, i cili siguron që shkatërruesi i dobët kurrë të mos e lërë ndarjen ndërsa destruktori i fortë po funksionon, edhe nëse treguesi i dobët është i ruajtur brenda një të forti.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Ndërton një `Rc` të ri me përmbajtje të pa inicializuar, duke kthyer një gabim nëse alokimi dështon
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Ndërton një `Rc` të ri me përmbajtje të pa iniciale, me kujtesën e mbushur me `0` bajte, duke kthyer një gabim nëse alokimi dështon
    ///
    ///
    /// Shihni [`MaybeUninit::zeroed`][zeroed] për shembuj të përdorimit korrekt dhe jo korrekt të kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Ndërton një `Pin<Rc<T>>` të ri.
    /// Nëse `T` nuk zbaton `Unpin`, atëherë `value` do të vendoset në memorie dhe nuk mund të zhvendoset.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Kthen vlerën e brendshme, nëse `Rc` ka saktësisht një referencë të fortë.
    ///
    /// Përndryshe, një [`Err`] kthehet me të njëjtën `Rc` që u kalua brenda.
    ///
    ///
    /// Kjo do të ketë sukses edhe nëse ka referenca të dobëta të jashtëzakonshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopjoni objektin e përmbajtur

                // Tregoni Weaks se ato nuk mund të promovohen duke zvogëluar numrin e fortë dhe më pas hiqni treguesin e nënkuptuar "strong weak" duke trajtuar gjithashtu logjikën e rënies duke krijuar vetëm një Dobët të rremë.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Ndërton një fetë të re të numëruar nga referencat me përmbajtje të pa iniciale.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Ndërton një fetë të re të numëruar si referencë me përmbajtje të pa iniciale, me kujtesën që mbushet me `0` bajte.
    ///
    ///
    /// Shihni [`MaybeUninit::zeroed`][zeroed] për shembuj të përdorimit korrekt dhe jo korrekt të kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Konvertohet në `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Ashtu si me [`MaybeUninit::assume_init`], i takon thirrësit të garantojë se vlera e brendshme është me të vërtetë në një gjendje të iniciuar.
    ///
    /// Thirrja e kësaj kur përmbajtja ende nuk është iniciuar plotësisht shkakton sjellje të menjëhershme të papërcaktuar.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Konvertohet në `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Ashtu si me [`MaybeUninit::assume_init`], i takon thirrësit të garantojë se vlera e brendshme është me të vërtetë në një gjendje të iniciuar.
    ///
    /// Thirrja e kësaj kur përmbajtja ende nuk është iniciuar plotësisht shkakton sjellje të menjëhershme të papërcaktuar.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Konsumon `Rc`, duke kthyer treguesin e mbështjellur.
    ///
    /// Për të shmangur një rrjedhje të kujtesës, treguesi duhet të kthehet në një `Rc` duke përdorur [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Siguron një tregues të papërpunuar të të dhënave.
    ///
    /// Numërimet nuk preken në asnjë mënyrë dhe `Rc` nuk konsumohet.
    /// Treguesi është i vlefshëm për aq kohë sa ka numërime të forta në `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // SIGURIA: Kjo nuk mund të kalojë nëpër Deref::deref ose Rc::inner sepse
        // kjo kërkohet për të ruajtur prejardhjen raw/mut të tillë që p.sh.
        // `get_mut` mund të shkruajë përmes treguesit pasi Rc të rikuperohet përmes `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Ndërton një `Rc<T>` nga një tregues i papërpunuar.
    ///
    /// Treguesi i papërpunuar duhet të jetë kthyer më parë nga një telefonatë në [`Rc<U>::into_raw`][into_raw] ku `U` duhet të ketë të njëjtën madhësi dhe shtrirje si `T`.
    /// Kjo është trivialisht e vërtetë nëse `U` është `T`.
    /// Vini re se nëse `U` nuk është `T` por ka të njëjtën madhësi dhe shtrirje, kjo në thelb është si transferimi i referencave të llojeve të ndryshme.
    /// Shihni [`mem::transmute`][transmute] për më shumë informacion se çfarë kufizimesh zbatohen në këtë rast.
    ///
    /// Përdoruesi i `from_raw` duhet të sigurohet që një vlerë specifike e `T` të bjerë vetëm një herë.
    ///
    /// Ky funksion është i pasigurt sepse përdorimi i pahijshëm mund të çojë në pasiguri të kujtesës, edhe nëse nuk kthehet kurrë te `Rc<T>` i kthyer.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Kthehuni përsëri në një `Rc` për të parandaluar rrjedhjet.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Telefonatat e mëtejshme drejt `Rc::from_raw(x_ptr)` do të ishin të pasigurta në kujtesë.
    /// }
    ///
    /// // Kujtesa u çlirua kur `x` doli jashtë fushës së sipërme, kështu që `x_ptr` tani po varet!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Kthimi i kompensimit për të gjetur RcBox origjinal.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Krijon një tregues të ri [`Weak`] për këtë alokim.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Sigurohuni që të mos krijojmë një Dobët të varur
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Merr numrin e treguesve [`Weak`] për këtë alokim.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Merr numrin e treguesve të fortë (`Rc`) për këtë alokim.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Kthen `true` nëse nuk ka tregues të tjerë `Rc` ose [`Weak`] në këtë alokim.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Kthen një referencë të ndryshueshme në `Rc` të dhënë, nëse nuk ka tregues të tjerë `Rc` ose [`Weak`] për të njëjtën shpërndarje.
    ///
    ///
    /// Kthen [`None`] ndryshe, sepse nuk është e sigurt të shndërrosh një vlerë të përbashkët.
    ///
    /// Shikoni gjithashtu [`make_mut`][make_mut], i cili do të [`clone`][clone] vlerën e brendshme kur ka tregues të tjerë.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Kthen një referencë të ndryshueshme në `Rc` të dhënë, pa ndonjë kontroll.
    ///
    /// Shikoni gjithashtu [`get_mut`], i cili është i sigurt dhe bën kontrollet e duhura.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Çdo tregues tjetër `Rc` ose [`Weak`] për të njëjtën shpërndarje nuk duhet të referohet për kohëzgjatjen e huasë së kthyer.
    ///
    /// Kjo është e parëndësishme nëse nuk ekzistojnë tregues të tillë, për shembull menjëherë pas `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Ne jemi të kujdesshëm që *të mos* krijojmë një referencë që mbulon fushat "count", pasi kjo do të binte ndesh me hyrjet në numërimin e referencave (p.sh.
        // nga `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Kthen `true` nëse të dy `Rc` tregojnë për të njëjtën ndarje (në një mënyrë të ngjashme me [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Bën një referencë të ndryshueshme në `Rc` të dhënë.
    ///
    /// Nëse ka tregues të tjerë `Rc` për të njëjtën shpërndarje, atëherë `make_mut` do të [`clone`] vlerën e brendshme për një alokim të ri për të siguruar pronësinë unike.
    /// Kjo është referuar gjithashtu si klon-mbi-shkruaj.
    ///
    /// Nëse nuk ka tregues të tjerë `Rc` për këtë shpërndarje, atëherë treguesit [`Weak`] për këtë shpërndarje do të ndahen.
    ///
    /// Shikoni gjithashtu [`get_mut`], i cili do të dështojë më shumë sesa klonimi.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Nuk do të klonojë asgjë
    /// let mut other_data = Rc::clone(&data);    // Nuk do të klonojë të dhënat e brendshme
    /// *Rc::make_mut(&mut data) += 1;        // Klonon të dhënat e brendshme
    /// *Rc::make_mut(&mut data) += 1;        // Nuk do të klonojë asgjë
    /// *Rc::make_mut(&mut other_data) *= 2;  // Nuk do të klonojë asgjë
    ///
    /// // Tani `data` dhe `other_data` tregojnë për alokime të ndryshme.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] treguesit do të ndahen:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Gotta klonon të dhënat, ka RC të tjerë.
            // Alokoni paraprakisht kujtesën për të lejuar shkrimin e vlerës së klonuar drejtpërdrejt.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Thjesht mund të vjedhin të dhënat, e gjitha që ka mbetur është Dobësitë
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Hiq ref-in e nënkuptuar të fortë të dobët (nuk ka nevojë të krijosh një Dobët të rremë këtu-ne e dimë që Dobësitë e tjera mund të pastrojnë për ne)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Kjo pasiguri është në rregull sepse ne jemi të garantuar që treguesi i kthyer është treguesi *i vetëm* që do t'i kthehet ndonjëherë T.
        // Numri ynë i referencës është i garantuar të jetë 1 në këtë pikë, dhe ne kërkuam që vetë `Rc<T>` të jetë `mut`, kështu që po i kthejmë referencën e vetme të mundshme alokimit.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Përpjekje për të ulur `Rc<dyn Any>` në një lloj betoni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Alokon një `RcBox<T>` me hapësirë të mjaftueshme për një vlerë të mundshme të pa madhësisë, ku vlera ka paraqitur paraqitjen.
    ///
    /// Funksioni `mem_to_rcbox` thirret me treguesin e të dhënave dhe duhet të kthejë një pikë (potencialisht të majme) për `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Llogaritni paraqitjen duke përdorur paraqitjen e vlerës së dhënë.
        // Më parë, faqosja ishte llogaritur në shprehjen `&*(ptr as* const RcBox<T>)`, por kjo krijoi një referencë të gabuar (shih #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Alokon një `RcBox<T>` me hapësirë të mjaftueshme për një vlerë të brendshme me madhësi të pakuptimtë, ku vlera ka paraqitur paraqitjen, duke kthyer një gabim nëse alokimi dështon.
    ///
    ///
    /// Funksioni `mem_to_rcbox` thirret me treguesin e të dhënave dhe duhet të kthejë një pikë (potencialisht të majme) për `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Llogaritni paraqitjen duke përdorur paraqitjen e vlerës së dhënë.
        // Më parë, faqosja ishte llogaritur në shprehjen `&*(ptr as* const RcBox<T>)`, por kjo krijoi një referencë të gabuar (shih #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Alokoni për paraqitjen.
        let ptr = allocate(layout)?;

        // Filloni RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Alokon një `RcBox<T>` me hapësirë të mjaftueshme për një vlerë të brendshme të pa madhësisë
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Alokoni për `RcBox<T>` duke përdorur vlerën e dhënë.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopjoni vlerën si bajte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Lironi alokimin pa rënë në përmbajtje
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Alokon një `RcBox<[T]>` me gjatësinë e dhënë.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopjoni elementet nga feta në Rc të sapo alokuar <\[T\]>
    ///
    /// E pasigurt sepse telefonuesi ose duhet të marrë pronësinë ose të lidhë `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Ndërton një `Rc<[T]>` nga një iterator i njohur për një madhësi të caktuar.
    ///
    /// Sjellja është e papërcaktuar nëse madhësia është e gabuar.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Mbrojtësi Panic gjatë klonimit të elementeve T.
        // Në rast të një panic, elementët që janë shkruar në RcBox të ri do të hidhen, pastaj kujtesa do të lirohet.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Treguesi tek elementi i parë
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Gjithçka e qartë.Harrojeni rojën në mënyrë që të mos lirojë RcBox-in e ri.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializimi trait përdoret për `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Bie `Rc`.
    ///
    /// Kjo do të zvogëlojë numërimin e fortë të referencës.
    /// Nëse numërimi i fortë i referencës arrin në zero, atëherë referencat e tjera të tjera (nëse ka) janë [`Weak`], kështu që ne `drop` vlerën e brendshme.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Nuk shtyp asgjë
    /// drop(foo2);   // Printime "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // shkatërrojë objektin e përmbajtur
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // hiqni treguesin e nënkuptuar "strong weak" tani që kemi shkatërruar përmbajtjen.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Bën një klon të treguesit `Rc`.
    ///
    /// Kjo krijon një tregues tjetër për të njëjtën shpërndarje, duke rritur numrin e fortë të referencës.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Krijon një `Rc<T>` të ri, me vlerën `Default` për `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack për të lejuar specializimin në `Eq` edhe pse `Eq` ka një metodë.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Ne jemi duke e bërë këtë specializim këtu, dhe jo si një optimizim më i përgjithshëm në `&T`, sepse përndryshe do të shtonte një kosto për të gjitha kontrollet e barazisë në ref.
/// Supozojmë se `Rc` përdoren për të ruajtur vlera të mëdha, të cilat ngadalësohen për t`u klonuar, por edhe të rënda për të kontrolluar barazinë, duke bërë që kjo kosto të shlyhet më lehtë.
///
/// Alsoshtë gjithashtu më e mundshme që të ketë dy klone `Rc`, që tregojnë për të njëjtën vlerë, sesa dy `&T`.
///
/// Ne mund ta bëjmë këtë vetëm kur `T: Eq` si `PartialEq` mund të jetë qëllimisht reflektues.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Barazia për dy `Rc` s.
    ///
    /// Dy `Rc` janë të barabartë nëse vlerat e tyre të brendshme janë të barabarta, edhe nëse ato ruhen në alokim të ndryshëm.
    ///
    /// Nëse `T` gjithashtu zbaton `Eq` (nënkupton refleksivitetin e barazisë), dy `Rc` që tregojnë të njëjtën shpërndarje janë gjithmonë të barabartë.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Pabarazia për dy `Rc` s.
    ///
    /// Dy `Rc` janë të pabarabartë nëse vlerat e tyre të brendshme janë të pabarabarta.
    ///
    /// Nëse `T` zbaton gjithashtu `Eq` (nënkupton refleksivitetin e barazisë), dy `Rc` që tregojnë të njëjtën shpërndarje nuk janë kurrë të pabarabarta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Krahasimi i pjesshëm për dy `Rc` s.
    ///
    /// Të dy krahasohen duke thirrur `partial_cmp()` në vlerat e tyre të brendshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Krahasimi më pak se dy `Rc`.
    ///
    /// Të dy krahasohen duke thirrur `<` në vlerat e tyre të brendshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Krahasimi 'Më i vogël ose i barabartë me' për dy `Rc`.
    ///
    /// Të dy krahasohen duke thirrur `<=` në vlerat e tyre të brendshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Krahasim më i madh se dy `Rc` s.
    ///
    /// Të dy krahasohen duke thirrur `>` në vlerat e tyre të brendshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Krahasimi 'Më i madh se ose i barabartë me' për dy `Rc`.
    ///
    /// Të dy krahasohen duke thirrur `>=` në vlerat e tyre të brendshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Krahasimi për dy `Rc` s.
    ///
    /// Të dy krahasohen duke thirrur `cmp()` në vlerat e tyre të brendshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Alokoni një fetë të numëruar si referencë dhe plotësojeni duke klonuar artikujt e `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Alokoni një fetë vargu të numëruar si referencë dhe kopjoni `v` në të.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Alokoni një fetë vargu të numëruar si referencë dhe kopjoni `v` në të.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Lëvizni një objekt me kuti në një alokim të ri, të numëruar si referencë.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Alokoni një fetë të numëruar si referencë dhe zhvendosni sendet e `v` në të.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Lejoni Vec-in të lirojë kujtesën e tij, por mos të shkatërrojë përmbajtjen e tij
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Merr secilin element në `Iterator` dhe e mbledh atë në një `Rc<[T]>`.
    ///
    /// # Karakteristikat e performancës
    ///
    /// ## Çështja e përgjithshme
    ///
    /// Në rastin e përgjithshëm, mbledhja në `Rc<[T]>` bëhet duke mbledhur së pari në një `Vec<T>`.Kjo është, kur shkruani sa vijon:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// kjo sillet sikur të kemi shkruar:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Grupi i parë i alokimeve ndodh këtu.
    ///     .into(); // Një alokim i dytë për `Rc<[T]>` ndodh këtu.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Kjo do të caktojë sa herë të jetë e nevojshme për ndërtimin e `Vec<T>` dhe pastaj do të caktojë një herë për kthimin e `Vec<T>` në `Rc<[T]>`.
    ///
    ///
    /// ## Iteratorë me gjatësi të njohur
    ///
    /// Kur `Iterator` juaj zbaton `TrustedLen` dhe është me një madhësi të saktë, do të bëhet një alokim i vetëm për `Rc<[T]>`.Për shembull:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Vetëm një alokim i vetëm ndodh këtu.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specializimi trait përdoret për mbledhjen në `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Ky është rasti për një përsëritës `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SIGURIA: Ne duhet të sigurojmë që përsëritësi ka një gjatësi të saktë dhe ne kemi.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Bëni përsëri në zbatimin normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` është një version i [`Rc`] që mban një referencë jo-pronare ndaj alokimit të menaxhuar.Alokimi arrihet duke thirrur [`upgrade`] në treguesin `Weak`, i cili kthen një ["Opsion"] "<" ["Rc"] "<T>>".
///
/// Meqenëse një referencë `Weak` nuk llogaritet në pronësi, ajo nuk do të parandalojë që vlera e ruajtur në alokim të bjerë, dhe vetë `Weak` nuk bën asnjë garanci për vlerën që është akoma e pranishme.
/// Kështu që mund të kthejë [`None`] kur ["azhurnimi"] d.
/// Megjithatë, vini re se një referencë `Weak` * nuk lejon që alokimi vetë (dyqani mbështetës) të shperndahet.
///
/// Një tregues `Weak` është i dobishëm për të mbajtur një referencë të përkohshme në shpërndarjen e menaxhuar nga [`Rc`] pa parandaluar rënien e vlerës së tij të brendshme.
/// Përdoret gjithashtu për të parandaluar referencat rrethore midis treguesve [`Rc`], meqenëse referencat e zotërimit të ndërsjellë nuk do të lejonin asnjëherë të hidhet [`Rc`].
/// Për shembull, një pemë mund të ketë tregues të fortë [`Rc`] nga nyjet prindërore tek fëmijët, dhe treguesit `Weak` nga fëmijët përsëri te prindërit e tyre.
///
/// Mënyra tipike për të marrë një tregues `Weak` është të telefononi [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ky është një `NonNull` për të lejuar optimizimin e madhësisë së këtij lloji në enum, por nuk është domosdoshmërisht një tregues i vlefshëm.
    //
    // `Weak::new` e vendos këtë në `usize::MAX` në mënyrë që të mos ketë nevojë të caktojë hapësirë në grumbull.
    // Kjo nuk është një vlerë që një tregues i vërtetë do të ketë ndonjëherë sepse RcBox ka rreshtim të paktën 2.
    // Kjo është e mundur vetëm kur `T: Sized`;`T` pa madhësi kurrë nuk var.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Ndërton një `Weak<T>` të ri, pa caktuar asnjë kujtesë.
    /// Thirrja [`upgrade`] në vlerën e kthimit gjithmonë jep [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Lloji ndihmës për të lejuar hyrjen në numërimin e referencave pa bërë asnjë pohim në lidhje me fushën e të dhënave.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Kthen një tregues të papërpunuar në objektin `T` të treguar nga ky `Weak<T>`.
    ///
    /// Treguesi është i vlefshëm vetëm nëse ka disa referenca të forta.
    /// Treguesi mund të jetë i varur, i pavendosur ose edhe [`null`] ndryshe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Të dy tregojnë për të njëjtin objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // I forti këtu e mban gjallë, kështu që ne ende mund të kemi qasje në objekt.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Por jo më.
    /// // Ne mund të bëjmë weak.as_ptr(), por hyrja në tregues do të çonte në një sjellje të papërcaktuar.
    /// // assert_eq! ("përshëndetje", i pasigurt {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Nëse treguesi është i varur, ne e kthejmë rojet direkt.
            // Kjo nuk mund të jetë një adresë e vlefshme e ngarkesës, pasi ngarkesa është të paktën e njëjtë me RcBox (usize).
            ptr as *const T
        } else {
            // SIGURIA: nëse is_dangling kthen false, atëherë treguesi është i referueshëm.
            // Ngarkesa mund të bjerë në këtë pikë, dhe ne duhet të ruajmë origjinën, kështu që përdorni manipulimin e papërpunuar të treguesit.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Konsumon `Weak<T>` dhe e kthen atë në një tregues të papërpunuar.
    ///
    /// Kjo e kthen treguesin e dobët në një tregues të papërpunuar, duke ruajtur ende pronësinë e një reference të dobët (numërimi i dobët nuk modifikohet nga ky operacion).
    /// Mund të kthehet përsëri në `Weak<T>` me [`from_raw`].
    ///
    /// Zbatohen të njëjtat kufizime të hyrjes në shënjestrën e treguesit si me [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konverton një tregues të papërpunuar të krijuar më parë nga [`into_raw`] përsëri në `Weak<T>`.
    ///
    /// Kjo mund të përdoret për të marrë në mënyrë të sigurt një referencë të fortë (duke telefonuar [`upgrade`] më vonë) ose për të zhvendosur numërimin e dobët duke rënë `Weak<T>`.
    ///
    /// Merr pronësinë e një referencë të dobët (me përjashtim të treguesve të krijuar nga [`new`], pasi këto nuk zotërojnë asgjë; metoda ende funksionon në to).
    ///
    /// # Safety
    ///
    /// Treguesi duhet të ketë origjinën nga [`into_raw`] dhe duhet të ketë ende referencën e tij të dobët.
    ///
    /// Lejohet që numërimi i fortë të jetë 0 në kohën e thirrjes së tij.
    /// Sidoqoftë, kjo merr në pronësi një referencë të dobët që përfaqësohet aktualisht si një tregues i papërpunuar (numërimi i dobët nuk modifikohet nga ky operacion) dhe për këtë arsye duhet të shoqërohet me një thirrje të mëparshme në [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Zbërtheni numrin e fundit të dobët.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Shihni Weak::as_ptr për kontekstin se si nxirret treguesi i hyrjes.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ky është një Dobët i varur.
            ptr as *mut RcBox<T>
        } else {
            // Përndryshe, ne jemi të garantuar që treguesi erdhi nga një Dobët i paqartë.
            // SIGURIA: data_offset është e sigurt për t`u thirrur, pasi referencat ptr i referohen një T-je reale (potencialisht të rënë).
            let offset = unsafe { data_offset(ptr) };
            // Kështu, ne e ndryshojmë kompensimin për të marrë të gjithë RcBox.
            // SIGURIA: treguesi ka origjinën nga një i dobët, kështu që ky kompensim është i sigurt.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SIGURIA: tani kemi rikuperuar treguesin origjinal të Dobët, kështu që mund të krijojmë Dobët.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Përpjekjet për të azhurnuar treguesin `Weak` në një [`Rc`], duke vonuar rënien e vlerës së brendshme nëse është i suksesshëm.
    ///
    ///
    /// Kthen [`None`] nëse vlera e brendshme ka rënë.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Shkatërroni të gjithë treguesit e fortë.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Merr numrin e treguesve të fortë (`Rc`) që tregojnë këtë alokim.
    ///
    /// Nëse `self` është krijuar duke përdorur [`Weak::new`], kjo do të kthejë 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Merr numrin e treguesve `Weak` që tregojnë këtë alokim.
    ///
    /// Nëse nuk mbetet asnjë tregues i fortë, kjo do të kthejë zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // zbrit ptr-në e nënkuptuar të dobët
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Kthen `None` kur treguesi është i varur dhe nuk ka asnjë `RcBox` të caktuar, (dmth. Kur ky `Weak` është krijuar nga `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Ne jemi të kujdesshëm që * të mos krijojmë një referencë që mbulon fushën "data", pasi fusha mund të mutohet njëkohësisht (për shembull, nëse `Rc` i fundit bie, fusha e të dhënave do të bjerë në vend).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Kthen `true` nëse të dy `Dobët` tregojnë për të njëjtën shpërndarje (e ngjashme me [`ptr::eq`]), ose nëse të dy nuk tregojnë ndonjë alokim (sepse ato janë krijuar me `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Meqenëse kjo krahason treguesit do të thotë që `Weak::new()` do të barazohet me njëri-tjetrin, edhe pse nuk tregojnë ndonjë alokim.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Krahasimi i `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Bie treguesin `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Nuk shtyp asgjë
    /// drop(foo);        // Printime "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // numërimi i dobët fillon në 1, dhe do të shkojë në zero vetëm nëse të gjithë treguesit e fortë janë zhdukur.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Bën një klon të treguesit `Weak` që tregon për të njëjtën shpërndarje.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Ndërton një `Weak<T>` të ri, duke caktuar memorje për `T` pa e inicuar atë.
    /// Thirrja [`upgrade`] në vlerën e kthimit gjithmonë jep [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Ne kontrolluam_shto këtu për t'u marrë me mem::forget në mënyrë të sigurt.Veçanërisht
// nëse keni mem::forget Rc (ose Dobësi), numërimi i ri-numërimit mund të tejkalojë, dhe pastaj mund të lironi ndarjen ndërsa ekzistojnë Rc (ose Dobësi) të papaguara.
//
// Abortojmë sepse ky është një skenar kaq i degjeneruar saqë nuk na intereson se çfarë ndodh-asnjë program i vërtetë nuk duhet ta përjetojë kurrë këtë.
//
// Kjo duhet të ketë lartësi të papërfillshme pasi që në të vërtetë nuk keni nevojë t'i klononi këto shumë në Rust falë pronësisë dhe semantikës së lëvizjes.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Ne duam të ndërpresim tejmbushjen në vend që të heqim vlerën.
        // Numërimi i referencës nuk do të jetë kurrë zero kur kjo të thirret;
        // megjithatë, ne vendosim një abort këtu për të lënë të kuptohet LLVM për një optimizëm të humbur ndryshe.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Ne duam të ndërpresim tejmbushjen në vend që të heqim vlerën.
        // Numërimi i referencës nuk do të jetë kurrë zero kur kjo të thirret;
        // megjithatë, ne vendosim një abort këtu për të lënë të kuptohet LLVM për një optimizëm të humbur ndryshe.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Merrni kompensimin brenda një `RcBox` për ngarkesën prapa një treguesi.
///
/// # Safety
///
/// Treguesi duhet të tregojë (dhe të ketë meta të dhëna të vlefshme) për një shembull më parë të vlefshëm të T, por T lejohet të hidhet.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Drejtoni vlerën e pa madhësuar në fund të RcBox.
    // Për shkak se RcBox është repr(C), do të jetë gjithmonë fusha e fundit në kujtesë.
    // SIGURIA: meqenëse llojet e vetme pa madhësi të mundshme janë feta, objekte trait,
    // dhe llojet e jashtme, kërkesa e sigurisë së hyrjes aktualisht është e mjaftueshme për të përmbushur kërkesat e align_of_val_raw;ky është një detaj zbatimi i gjuhës që nuk mund të mbështetet jashtë std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}