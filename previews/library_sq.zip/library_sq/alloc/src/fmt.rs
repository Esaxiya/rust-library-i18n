//! Shërbime për formatimin dhe shtypjen `String`.
//!
//! Ky modul përmban mbështetjen e ekzekutimit për zgjatjen e sintaksës [`format!`].
//! Kjo makro është implementuar në përpilues për të lëshuar thirrje në këtë modul në mënyrë që të formatojë argumentet gjatë kohës së ekzekutimit në vargje.
//!
//! # Usage
//!
//! Makroja [`format!`] ka për qëllim të jetë e njohur për ata që vijnë nga funksionet C's `printf`/`fprintf` ose funksioni Python's `str.format`.
//!
//! Disa shembuj të shtrirjes [`format!`] janë:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" me zero drejtuese
//! ```
//!
//! Nga këto, ju mund të shihni se argumenti i parë është një varg i formatit.Kërkohet nga përpiluesi që kjo të jetë një varg fjalë për fjalë;nuk mund të jetë një ndryshore e kaluar (në mënyrë që të kryhet kontrolli i vlefshmërisë).
//! Përpiluesi pastaj do të analizojë vargun e formatit dhe të përcaktojë nëse lista e argumenteve të dhëna është e përshtatshme për t'i kaluar kësaj vargu të formatit.
//!
//! Për të kthyer një vlerë të vetme në një varg, përdorni metodën [`to_string`].Kjo do të përdorë formatimin [`Display`] trait.
//!
//! ## Parametrat pozicionues
//!
//! Secili argument i formatimit lejohet të specifikojë cilin argument vlere i referohet, dhe nëse hiqet, supozohet të jetë "the next argument".
//! Për shembull, vargu i formatit `{} {} {}` do të merrte tre parametra dhe ato do të formatoheshin në të njëjtën renditje siç janë dhënë.
//! Vargu i formatit `{2} {1} {0}`, megjithatë, do të formatonte argumentet në rend të kundërt.
//!
//! Gjërat mund të bëhen pak të ndërlikuara pasi të filloni të ndërthurni dy llojet e specifikuesve të pozicionit.Specifikuesi "next argument" mund të mendohet si një përsëritës mbi argumentin.
//! Sa herë që shihet një specifikues "next argument", iteratori përparon.Kjo sjell sjellje si kjo:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Iteratori i brendshëm mbi argumentin nuk është avancuar në kohën kur shihet `{}` i parë, kështu që shtyp argumentin e parë.Pastaj me arritjen e `{}` të dytë, iteratori ka përparuar në argumentin e dytë.
//! Në thelb, parametrat që emërtojnë në mënyrë të qartë argumentin e tyre nuk ndikojnë në parametrat që nuk emërtojnë një argument për sa i përket specifikuesve të pozicionit.
//!
//! Një varg i formatit kërkohet të përdorë të gjitha argumentet e tij, përndryshe është një gabim i kohës së përpilimit.Ju mund t'i referoheni të njëjtit argument më shumë se një herë në vargun e formatit.
//!
//! ## Parametrat e emëruar
//!
//! Vetë Rust nuk ka një ekuivalent të ngjashëm me Python të parametrave të emëruar në një funksion, por makroja [`format!`] është një zgjerim sintakse që i lejon asaj të përdorë parametrat e emëruar.
//! Parametrat e përmendur renditen në fund të listës së argumenteve dhe kanë sintaksën:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Për shembull, shprehjet e mëposhtme [`format!`] përdorin të gjitha argumentet me emër:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Nuk është e vlefshme të vendosni parametra pozicionues (ata pa emra) pas argumenteve që kanë emra.Ashtu si me parametrat pozicionues, nuk është e vlefshme të sigurohen parametra të emëruar që nuk përdoren nga vargu i formatit.
//!
//! # Parametrat e formatimit
//!
//! Secili argument që formatohet mund të transformohet nga një numër parametrash formatimi (që korrespondojnë me `format_spec` në [the syntax](#syntax)). Këto parametra ndikojnë në paraqitjen e vargut të asaj që formatohet.
//!
//! ## Width
//!
//! ```
//! // Të gjitha këto shtypin "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Ky është një parametër për formatin "minimum width" që duhet të marrë.
//! Nëse vargu i vlerës nuk plotëson kaq shumë karaktere, atëherë mbushja e specifikuar nga fill/alignment do të përdoret për të zënë hapësirën e kërkuar (shih më poshtë).
//!
//! Vlera për gjerësinë mund të sigurohet gjithashtu si [`usize`] në listën e parametrave duke shtuar një postfix `$`, duke treguar që argumenti i dytë është një [`usize`] që specifikon gjerësinë.
//!
//! Referimi i një argumenti me sintaksën e dollarit nuk ndikon në numëruesin "next argument", kështu që zakonisht është një ide e mirë t'i referoheni argumenteve sipas pozicionit, ose të përdorni argumente të emërtuara.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Karakteri dhe shtrirja opsionale e mbushjes sigurohet normalisht në lidhje me parametrin [`width`](#width).Duhet të përcaktohet para `width`, menjëherë pas `:`.
//! Kjo tregon që nëse vlera që formatohet është më e vogël se `width`, disa karaktere shtesë do të shtypen rreth tij.
//! Mbushja vjen në variantet e mëposhtme për rreshtime të ndryshme:
//!
//! * `[fill]<` - argumenti rreshtohet në të majtë në kolonat `width`
//! * `[fill]^` - argumenti është i rreshtuar në qendër në kolonat `width`
//! * `[fill]>` - argumenti është i drejtuar në kolonat `width`
//!
//! [fill/alignment](#fillalignment) i paracaktuar për jo-numerikët është një hapësirë dhe e rreshtuar majtas.Parazgjedhja për formatuesit numerikë është gjithashtu një karakter hapësire por me rreshtimin e djathtë.
//! Nëse flamuri `0` (shih më poshtë) është specifikuar për numerikë, atëherë karakteri i nënkuptuar i mbushjes është `0`.
//!
//! Vini re se shtrirja mund të mos zbatohet nga disa lloje.Në veçanti, nuk zbatohet përgjithësisht për `Debug` trait.
//! Një mënyrë e mirë për të siguruar zbatimin e mbushjes është që të formatoni inputin tuaj, pastaj vendosni këtë varg që rezulton për të marrë prodhimin tuaj:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Përshëndetje Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Të gjithë këta janë flamuj që ndryshojnë sjelljen e formatuesit.
//!
//! * `+` - Kjo është menduar për llojet numerike dhe tregon se shenja duhet të shtypet gjithmonë.Shenjat pozitive nuk shtypen kurrë si parazgjedhje, dhe shenja negative shtypet vetëm si parazgjedhje për `Signed` trait.
//! Ky flamur tregon se shenja e saktë (`+` ose `-`) duhet të shtypet gjithmonë.
//! * `-` - Aktualisht nuk përdoret
//! * `#` - Ky flamur tregon se duhet të përdoret forma "alternate" e shtypjes.Format alternative janë:
//!     * `#?` - printoni bukur formatimin [`Debug`]
//!     * `#x` - i paraprinë argumentit me një `0x`
//!     * `#X` - i paraprinë argumentit me një `0x`
//!     * `#b` - i paraprinë argumentit me një `0b`
//!     * `#o` - i paraprinë argumentit me një `0o`
//! * `0` - Kjo përdoret për të treguar për formatet e plota se mbushja e `width` duhet të bëhet me karakter `0` si dhe të jetë e vetëdijshme për shenjat.
//! Një format si `{:08}` do të jepte `00000001` për numrin e plotë `1`, ndërsa i njëjti format do të jepte `-0000001` për numrin e plotë `-1`.
//! Vini re se versioni negativ ka një zero më pak se versioni pozitiv.
//!         Vini re që zero të mbushjes vendosen gjithmonë pas shenjës (nëse ka) dhe para shifrave.Kur përdoret së bashku me flamurin `#`, zbatohet një rregull i ngjashëm: zero të mbushjes futen pas prefiksit, por para shifrave.
//!         Parashtesa përfshihet në gjerësinë totale.
//!
//! ## Precision
//!
//! Për llojet jo-numerike, kjo mund të konsiderohet një "maximum width".
//! Nëse vargu që rezulton është më i gjatë se kjo gjerësi, atëherë cungohet deri në këtë shumë karaktere dhe ajo vlerë e cunguar emetohet me `fill`, `alignment` dhe `width` të duhur nëse ato parametra janë vendosur.
//!
//! Për llojet integrale, kjo është injoruar.
//!
//! Për llojet e pikave lundruese, kjo tregon se sa shifra pas pikës dhjetore duhet të shtypen.
//!
//! Ekzistojnë tre mënyra të mundshme për të specifikuar `precision` të dëshiruar:
//!
//! 1. Një numër i plotë `.N`:
//!
//!    numri i plotë `N` në vetvete është saktësi.
//!
//! 2. Një numër i plotë ose emër i ndjekur nga shenja e dollarit `.N$`:
//!
//!    përdorni saktësinë e formatit *argument*`N` (i cili duhet të jetë `usize`).
//!
//! 3. Një yll `.*`:
//!
//!    `.*` do të thotë që ky `{...}` shoqërohet me hyrje të formatit *dy* dhe jo me një: hyrja e parë mban saktësinë `usize` dhe e dyta mban vlerën për t'u shtypur.
//!    Vini re se në këtë rast, nëse dikush përdor vargun e formatit `{<arg>:<spec>.*}`, atëherë pjesa `<arg>` i referohet* vlerës * për të shtypur, dhe `precision` duhet të vijë në hyrjen paraardhëse të `<arg>`.
//!
//! Për shembull, thirrjet e mëposhtme të gjitha shtypin të njëjtën gjë `Hello x is 0.01000`:
//!
//! ```
//! // Përshëndetje {arg 0 ("x")} është {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Përshëndetje {arg 1 ("x")} është {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Përshëndetje {arg 0 ("x")} është {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Përshëndetje {next arg ("x")} është {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Përshëndetje {next arg ("x")} është {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Përshëndetje {next arg ("x")} është {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Ndërsa këto:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! shtypni tre gjëra dukshëm të ndryshme:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Në disa gjuhë programimi, sjellja e funksioneve të formatimit të vargut varet nga vendosja e vendndodhjes së sistemit operativ.
//! Funksionet e formatit të ofruara nga biblioteka standarde e Rust nuk kanë ndonjë koncept të vendndodhjes dhe do të prodhojnë të njëjtat rezultate në të gjitha sistemet pavarësisht nga konfigurimi i përdoruesit.
//!
//! Për shembull, kodi i mëposhtëm do të shtypë gjithmonë `1.5` edhe nëse lokali i sistemit përdor një ndarës dhjetor përveç një pike.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Karakteret fjalë për fjalë `{` dhe `}` mund të përfshihen në një varg duke i paraprirë me të njëjtin karakter.Për shembull, karakteri `{` është shpëtuar me `{{` dhe karakteri `}` është shpëtuar me `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Për ta përmbledhur, këtu mund të gjeni gramatikën e plotë të vargjeve të formatit.
//! Sintaksa për gjuhën e formatimit të përdorur është nxjerrë nga gjuhë të tjera, kështu që nuk duhet të jetë shumë e huaj.Argumentet janë të formatuara me sintaksë të ngjashme me Python, që do të thotë se argumentet janë të rrethuara nga `{}` në vend të C-si `%`.
//! Gramatika aktuale për sintaksën e formatimit është:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Në gramatikën e mësipërme, `text` mund të mos përmbajë asnjë shenjë `'{'` ose `'}'`.
//!
//! # Formatimi i traits
//!
//! Kur kërkoni që një argument të formatohet me një lloj të veçantë, ju në të vërtetë po kërkoni që një argument t'i përshkruhet një trait të veçantë.
//! Kjo lejon që shumë lloje aktuale të formatohen përmes `{:x}` (si [`i8`] si dhe [`isize`]).Hartifikimi aktual i llojeve në traits është:
//!
//! * *asgjë*[`Display`]
//! * `?` [`Debug`]
//! * `x?` 00 [`Debug`] me numra të plotë heksadecimalë me shkronja të vogla
//! * `X?` 00 [`Debug`] me numra të plotë heksadecimalë me shkronja të mëdha
//! * `o` [`Octal`]
//! * `x` [`LowerHex`]
//! * `X` [`UpperHex`]
//! * `p` [`Pointer`]
//! * `b` [`Binary`]
//! * `e` [`LowerExp`]
//! * `E` [`UpperExp`]
//!
//! Çfarë do të thotë kjo është që çdo lloj argumenti që zbaton [`fmt::Binary`][`Binary`] trait mund të formatohet me `{:b}`.Zbatimet janë siguruar për këto traits për një numër të llojeve primitive gjithashtu nga biblioteka standarde.
//!
//! Nëse nuk përcaktohet asnjë format (si në `{}` ose `{:6}`), atëherë formati trait i përdorur është [`Display`] trait.
//!
//! Kur zbatoni një format trait për llojin tuaj, do t'ju duhet të zbatoni një metodë të nënshkrimit:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // lloji ynë me porosi
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Lloji juaj do të kalojë si `self` me referencë, dhe pastaj funksioni duhet të lëshojë dalje në rrjedhën `f.buf`.Implementationshtë në varësi të çdo zbatimi të formatit trait që t'i përmbahen saktë parametrave të kërkuar të formatimit.
//! Vlerat e këtyre parametrave do të renditen në fushat e strukturës [`Formatter`].Në mënyrë që të ndihmoni me këtë, struktura [`Formatter`] gjithashtu ofron disa metoda ndihmëse.
//!
//! Për më tepër, vlera e kthimit e këtij funksioni është [`fmt::Result`] e cila është një pseudonim tip i ["Rezultati"] "<()," ["std: : fmt::Gabim"] ">".
//! Zbatimet e formatimit duhet të sigurojnë që ato përhapin gabime nga [`Formatter`] (p.sh., kur telefononi [`write!`]).
//! Sidoqoftë, ata kurrë nuk duhet t'i kthejnë gabimet në mënyrë të rreme.
//! Kjo do të thotë, një implementim i formatimit duhet dhe mund të kthejë një gabim vetëm nëse [`Formatter`] i futur kthen një gabim.
//! Kjo sepse, në kundërshtim me atë që mund të sugjerojë nënshkrimi i funksionit, formatimi i vargut është një veprim i pagabueshëm.
//! Ky funksion kthen vetëm një rezultat sepse shkrimi në rrjedhën themelore mund të dështojë dhe ai duhet të sigurojë një mënyrë për të përhapur faktin se një gabim ka ndodhur duke e mbështetur në pirg.
//!
//! Një shembull i zbatimit të formatimit traits do të dukej:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Vlera `f` zbaton `Write` trait, e cila është ajo që shkruaj!makro është duke pritur.
//!         // Vini re se ky formatim injoron flamujt e ndryshëm të dhënë për të formatuar vargjet.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits të ndryshme lejojnë forma të ndryshme të prodhimit të një lloji.
//! // Kuptimi i këtij formati është të shtypni madhësinë e një vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respektoni flamujt e formatimit duke përdorur metodën ndihmëse `pad_integral` në objektin Formatter.
//!         // Shihni dokumentacionin e metodës për detaje, dhe funksioni `pad` mund të përdoret për të vendosur vargjet.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Këto dy formatime traits kanë qëllime të dallueshme:
//!
//! - [`fmt::Display`][`Display`] implementimet pohojnë se lloji mund të përfaqësohet me besnikëri si një varg UTF-8 në çdo kohë.**Nuk** pritet që të gjitha llojet të zbatojnë [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] implementimet duhet të zbatohen për **të gjithë** llojet publike.
//!   Prodhimi zakonisht përfaqëson gjendjen e brendshme sa më besnikërisht të jetë e mundur.
//!   Qëllimi i [`Debug`] trait është të lehtësojë korrigjimin e kodit Rust.Në shumicën e rasteve, përdorimi i `#[derive(Debug)]` është i mjaftueshëm dhe rekomandohet.
//!
//! Disa shembuj të daljes nga të dy traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Makrot e lidhura
//!
//! Ekzistojnë një numër makrosh të lidhura në familjen [`format!`].Ato që zbatohen aktualisht janë:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Kjo dhe [`writeln!`] janë dy makro të cilat përdoren për të lëshuar vargun e formatit në një transmetim të specifikuar.Kjo përdoret për të parandaluar caktimet e ndërmjetme të vargjeve të formatit dhe në vend të kësaj shkruaj direkt prodhimin.
//! Nën kapak, ky funksion në të vërtetë po thërret funksionin [`write_fmt`] të përcaktuar në [`std::io::Write`] trait.
//! Përdorimi Shembull është:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Kjo dhe [`println!`] lëshojnë prodhimin e tyre në stdout.Ngjashëm me makron [`write!`], qëllimi i këtyre makrove është të shmangin alokimet e ndërmjetme kur shtypni prodhimin.Përdorimi Shembull është:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Makrot [`eprint!`] dhe [`eprintln!`] janë identike me [`print!`] dhe [`println!`], respektivisht, përveç që ato lëshojnë prodhimin e tyre në stderr.
//!
//! ### `format_args!`
//!
//! Kjo është një makro kurioze që përdoret për të kaluar në mënyrë të sigurt rreth një objekti të paqartë që përshkruan vargun e formatit.Ky objekt nuk kërkon ndonjë shpërndarje grumbulli për të krijuar, dhe ai i referohet vetëm informacionit në pirg.
//! Nën kapuç, të gjitha makrot përkatëse janë implementuar në kuptim të kësaj.
//! Së pari, disa shembuj të përdorimit janë:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Rezultati i makros [`format_args!`] është një vlerë e tipit [`fmt::Arguments`].
//! Kjo strukturë më pas mund t'i kalohet funksioneve [`write`] dhe [`format`] brenda këtij moduli në mënyrë që të përpunojë vargun e formatit.
//! Qëllimi i kësaj makro është të parandalojë edhe më tej alokimet e ndërmjetme kur kemi të bëjmë me formatimin e vargjeve.
//!
//! Për shembull, një bibliotekë regjistruese mund të përdorë sintaksën standarde të formatimit, por ajo do të kalonte brenda kësaj strukture derisa të përcaktohet se ku duhet të shkojë prodhimi.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Funksioni `format` merr një strukturë [`Arguments`] dhe kthen vargun e formatuar që rezulton.
///
///
/// Shembulli [`Arguments`] mund të krijohet me makron [`format_args!`].
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Ju lutemi vini re se përdorimi i [`format!`] mund të jetë i preferueshëm.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}