use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specializimi trait përdoret për Vec::from_iter
///
/// ## Grafiku i delegacionit:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Një rast i zakonshëm është kalimi i një vector në një funksion i cili menjëherë mblidhet përsëri në një vector.
        // Mund ta lidhim me qark të shkurtër nëse IntoIter nuk është avancuar fare.
        // Kur të jetë avancuar Ne gjithashtu mund të ripërdorim kujtesën dhe t'i transferojmë të dhënat përpara.
        // Por ne e bëjmë këtë vetëm kur Vec që rezulton nuk do të kishte më shumë kapacitet të papërdorur sesa do ta krijonte përmes zbatimit të përgjithshëm FromIterator.
        //
        // Ky kufizim nuk është rreptësisht i nevojshëm pasi sjellja e alokimit të Vec është qëllimisht e paspecifikuar.
        // Por është një zgjedhje konservatore.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // duhet të delegojë në spec_extend() pasi që extend() vetë delegon në spec_from për Vec-et bosh
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Kjo shfrytëzon `iterator.as_slice().to_vec()` pasi spec_extend duhet të marrë më shumë hapa për të arsyetuar në lidhje me kapacitetin përfundimtar + gjatësinë dhe kështu të bëjë më shumë punë.
// `to_vec()` drejtpërdrejt cakton shumën e saktë dhe e plotëson atë saktësisht.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): me cfg(test) metoda e natyrshme `[T]::to_vec`, e cila kërkohet për këtë përkufizim të metodës, nuk është e disponueshme.
    // Në vend të kësaj përdorni funksionin `slice::to_vec` i cili është i disponueshëm vetëm me cfg(test) NB shikoni modulin slice::hack në slice.rs për më shumë informacion
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}