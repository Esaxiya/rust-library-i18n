// Vendosni gjatësinë e vec kur vlera `SetLenOnDrop` del jashtë fushës së veprimit.
//
// Ideja është: Fusha e gjatësisë në SetLenOnDrop është një variabël lokale që optimizuesi do të shohë nuk ka pseudonim me asnjë dyqan përmes treguesit të të dhënave të Vec.
// Ky është një zgjidhje për çështjen e analizës alias #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}