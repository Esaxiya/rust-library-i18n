//! Një lloj grupi i rritshëm i afërt me përmbajtje të alokuar në grumbull, i shkruar `Vec<T>`.
//!
//! Vectors kanë indeksimin `O(1)`, shtytjen e amortizuar `O(1)` (deri në fund) dhe `O(1)` pop (nga fundi).
//!
//!
//! Vectors sigurojnë që ata kurrë të mos ndajnë më shumë se `isize::MAX` bajte.
//!
//! # Examples
//!
//! Ju mund të krijoni qartë një [`Vec`] me [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... ose duke përdorur makron [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // dhjetë zero
//! ```
//!
//! Ju mund të vlerësoni [`push`] në fund të një vector (i cili do të rritet vector sipas nevojës):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping vlerat funksionon në të njëjtën mënyrë:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors gjithashtu mbështet indeksimin (përmes [`Index`] dhe [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Një tip array rritës i afërt, i shkruar si `Vec<T>` dhe i shqiptuar 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Makro [`vec!`] është dhënë për ta bërë inicializimin më të përshtatshëm:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Ai gjithashtu mund të inicializojë çdo element të një `Vec<T>` me një vlerë të dhënë.
/// Kjo mund të jetë më efikase sesa kryerja e alokimit dhe inicializimit në hapa të veçantë, veçanërisht kur inicioni një vector me zero:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Më poshtë është ekuivalente, por potencialisht më e ngadaltë:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Për më shumë informacion, shihni [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Përdorni një `Vec<T>` si një pirg efikas:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Printimet 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Lloji `Vec` lejon hyrjen e vlerave sipas indeksit, sepse zbaton [`Index`] trait.Një shembull do të jetë më i qartë:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // do të shfaq '2'
/// ```
///
/// Sidoqoftë, jini të kujdesshëm: nëse përpiqeni të përdorni një indeks që nuk është në `Vec`, programi juaj do të panic!Ju nuk mund ta bëni këtë:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Përdorni [`get`] dhe [`get_mut`] nëse dëshironi të kontrolloni nëse indeksi është në `Vec`.
///
/// # Slicing
///
/// Një `Vec` mund të jetë i ndryshueshëm.Nga ana tjetër, fetat janë objekte vetëm për lexim.
/// Për të marrë një [slice][prim@slice], përdorni [`&`].Shembull:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... dhe kjo eshte e gjitha!
/// // gjithashtu mund ta bësh kështu:
/// let u: &[usize] = &v;
/// // ose si kjo:
/// let u: &[_] = &v;
/// ```
///
/// Në Rust, është më e zakonshme të kalosh feta si argumente sesa vectors kur thjesht dëshiron të sigurosh akses leximi.E njëjta gjë vlen edhe për [`String`] dhe [`&str`].
///
/// # Kapaciteti dhe rialokimi
///
/// Kapaciteti i një vector është sasia e hapësirës së caktuar për çdo element future që do të shtohet në vector.Kjo nuk duhet ngatërruar me *gjatësinë* e një vector, i cili specifikon numrin e elementeve aktuale brenda vector.
/// Nëse gjatësia e një vector tejkalon kapacitetin e tij, kapaciteti i tij automatikisht do të rritet, por elementët e tij do të duhet të rialokohen.
///
/// Për shembull, një vector me kapacitet 10 dhe gjatësi 0 do të ishte një vector i zbrazët me hapësirë për 10 elementë të tjerë.Shtyrja e 10 ose më pak elementëve në vector nuk do të ndryshojë kapacitetin e tij ose do të bëjë që të ndodhë rialokimi.
/// Sidoqoftë, nëse gjatësia e vector rritet në 11, do të duhet të rialokohet, gjë që mund të jetë e ngadaltë.Për këtë arsye, rekomandohet të përdorni [`Vec::with_capacity`] sa herë që është e mundur për të specifikuar se sa i madh pritet të marrë vector.
///
/// # Guarantees
///
/// Për shkak të natyrës së tij tepër themelore, `Vec` bën shumë garanci për modelin e tij.Kjo siguron që të jetë sa më e ulët se e mundur në rastin e përgjithshëm, dhe mund të manipulohet si duhet në mënyra primitive nga një kod i pasigurt.Vini re se këto garanci i referohen një `Vec<T>` të pakualifikuar.
/// Nëse shtohen parametra shtesë të tipit (p.sh., për të mbështetur alokuesit e personalizuar), tejkalimi i parazgjedhjeve të tyre mund të ndryshojë sjelljen.
///
/// Më thelbësisht, `Vec` është dhe gjithmonë do të jetë një treshe (tregues, kapacitet, gjatësi).Jo me shume Jo me pak.Renditja e këtyre fushave është plotësisht e paspecifikuar, dhe ju duhet të përdorni metodat e duhura për t'i modifikuar ato.
/// Treguesi nuk do të jetë kurrë nul, kështu që ky lloj është i optimizuar me null-pointer.
///
/// Sidoqoftë, treguesi mund të mos tregojë në kujtesën e caktuar.
/// Në veçanti, nëse ndërtoni një `Vec` me kapacitet 0 përmes [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] ose duke thirrur [`shrink_to_fit`] në një Vec të zbrazët, nuk do të caktojë memorje.Në mënyrë të ngjashme, nëse ruani lloje me madhësi zero brenda një `Vec`, nuk do t'ju ndajë hapësirë.
/// *Vini re se në këtë rast `Vec` nuk mund të raportojë një [`capacity`] prej 0*.
/// `Vec` do të caktojë nëse dhe vetëm nëse [`mem: : size_of::<T>`]"() * capacity()> 0".
/// Në përgjithësi, detajet e alokimit të "Vec" janë shumë delikate-nëse keni ndërmend të caktoni memorje duke përdorur një `Vec` dhe ta përdorni për diçka tjetër (ose për të kaluar në një kod të pasigurt, ose për të ndërtuar koleksionin tuaj të mbështetur në kujtesë), sigurohuni për të zhvendosur këtë kujtesë duke përdorur `from_raw_parts` për të rikuperuar `Vec` dhe më pas duke e lëshuar atë.
///
/// Nëse një `Vec`*ka* kujtesë të caktuar, atëherë kujtesa për të cilën tregohet është në grumbull (siç përcaktohet nga alokuesi Rust është konfiguruar të përdoret si parazgjedhje), dhe treguesi i tij tregon për [`len`] elementet e iniciuara me radhë me radhë (çfarë do të shikoni nëse e keni detyruar atë në një fetë), e ndjekur nga ["kapaciteti"] "," ["len"] elemente logjikisht të pa inicializuar, të afërta.
///
///
/// Një vector që përmban elementet `'a'` dhe `'b'` me kapacitet 4 mund të vizualizohet si më poshtë.Pjesa e sipërme është struktura `Vec`, përmban një tregues për kokën e alokimit në grumbull, gjatësi dhe kapacitet.
/// Pjesa e poshtme është shpërndarja në grumbull, një bllok i memorjes ngjitur.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** përfaqëson memorie që nuk është iniciuar, shih [`MaybeUninit`].
/// - Note: ABI nuk është i qëndrueshëm dhe `Vec` nuk jep garanci për paraqitjen e tij të kujtesës (përfshirë renditjen e fushave).
///
/// `Vec` nuk do të kryejë kurrë një "small optimization" ku elementët në të vërtetë janë ruajtur në pirg për dy arsye:
///
/// * Do ta bënte më të vështirë për kodin e pasigurt manipulimin e duhur të një `Vec`.Përmbajtja e një `Vec` nuk do të kishte një adresë të qëndrueshme nëse do të zhvendosej vetëm dhe do të ishte më e vështirë të përcaktohej nëse një `Vec` kishte alokuar në të vërtetë memorje.
///
/// * Do të penalizonte çështjen e përgjithshme, duke pësuar një branch shtesë për çdo qasje.
///
/// `Vec` kurrë nuk do të tkurret automatikisht, edhe nëse është plotësisht bosh.Kjo siguron që të mos ndodhin alokime të panevojshme ose shpërndarje.Zbrazja e një `Vec` dhe pastaj plotësimi i tij përsëri në të njëjtën [`len`] nuk duhet të ketë thirrje ndaj alokuesit.Nëse dëshironi të lironi memorie të papërdorur, përdorni [`shrink_to_fit`] ose [`shrink_to`].
///
/// [`push`] dhe [`insert`] kurrë nuk (do të) alokojë nëse kapaciteti i raportuar është i mjaftueshëm.[`push`] dhe [`insert`] * do të (ri) alokojnë nëse [`len`]"=="["kapaciteti"].Kjo është, kapaciteti i raportuar është plotësisht i saktë, dhe mund të mbështetet.Mund të përdoret edhe për të liruar manualisht kujtesën e caktuar nga një `Vec` nëse dëshironi.
/// Metodat e futjes me shumicë *mund të* rialokohen, edhe kur nuk është e nevojshme.
///
/// `Vec` nuk garanton ndonjë strategji të veçantë të rritjes kur rialokohet kur është e plotë, as kur thirret [`reserve`].Strategjia aktuale është themelore dhe mund të jetë e dëshirueshme të përdoret një faktor i rritjes jo konstante.Cilado qoftë strategjia që përdoret sigurisht do të garantojë *O*(1) [`push`] të amortizuar.
///
/// `vec![x; n]`, `vec![a, b, c, d]`, dhe [`Vec::with_capacity(n)`][`Vec::with_capacity`], të gjithë do të prodhojnë një `Vec` me saktësisht kapacitetin e kërkuar.
/// Nëse [`len`]"=="["kapaciteti"], (siç është rasti për makro [`vec!`]), atëherë një `Vec<T>` mund të shndërrohet në dhe nga një [`Box<[T]>`][owned slice] pa rialokuar ose lëvizur elementet.
///
/// `Vec` nuk do të mbishkruaj specifikisht asnjë të dhënë që është hequr prej saj, por gjithashtu nuk do t'i ruajë ato në mënyrë specifike.Memoria e saj e pa inicializuar është hapësira gërvishtëse që mund ta përdorë si të dojë.Në përgjithësi do të bëjë gjithçka që është më efikase ose ndryshe është e lehtë për t'u zbatuar.Mos u mbështetni te të dhënat e hequra për t'u fshirë për qëllime sigurie.
/// Edhe nëse lëshoni një `Vec`, bufferi i tij thjesht mund të ripërdoret nga një tjetër `Vec`.
/// Edhe nëse fillimisht zerosni memorien e një `Vec`, kjo mund të mos ndodhë në të vërtetë sepse optimizuesi nuk e konsideron këtë si një efekt anësor që duhet të ruhet.
/// Megjithatë, ekziston një rast të cilin ne nuk do ta thyejmë: përdorimi i kodit `unsafe` për të shkruar kapacitetin e tepërt, dhe pastaj rritja e gjatësisë për tu përputhur, është gjithmonë e vlefshme.
///
/// Aktualisht, `Vec` nuk garanton rendin në të cilin hidhen elementet.
/// Renditja ka ndryshuar në të kaluarën dhe mund të ndryshojë përsëri.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Metodat e qenësishme
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Ndërton një `Vec<T>` të ri, të zbrazët.
    ///
    /// vector nuk do të caktojë derisa elementët të mos shtyhen mbi të.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Ndërton një `Vec<T>` të ri, bosh, me kapacitetin e specifikuar.
    ///
    /// vector do të jetë në gjendje të mbajë saktësisht elemente `capacity` pa rialokuar.
    /// Nëse `capacity` është 0, vector nuk do të caktojë.
    ///
    /// Importantshtë e rëndësishme të theksohet se megjithëse vector i kthyer ka *kapacitetin* e specifikuar, vector do të ketë një gjatësi *zero*.
    ///
    /// Për një shpjegim të ndryshimit midis gjatësisë dhe kapacitetit, shih *[Kapaciteti dhe rialokimi]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector nuk përmban artikuj, edhe pse ka kapacitet për më shumë
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Të gjitha këto bëhen pa rialokuar ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... por kjo mund të bëjë që vector të rialokohet
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Krijon një `Vec<T>` direkt nga përbërësit e papërpunuar të një vector tjetër.
    ///
    /// # Safety
    ///
    /// Kjo është shumë e pasigurt, për shkak të numrit të invariancave që nuk kontrollohen:
    ///
    /// * `ptr` duhet të jetë alokuar më parë përmes ["String"]/"Vec<T>"(të paktën, ka shumë të ngjarë të jetë e pasaktë nëse nuk do të ishte).
    /// * `T` duhet të ketë të njëjtën madhësi dhe shtrirje si ajo me të cilën është ndarë `ptr`.
    ///   (`T` që ka një shtrirje më pak të rreptë nuk është e mjaftueshme, rreshtimi me të vërtetë duhet të jetë i barabartë për të përmbushur kërkesën [`dealloc`] që kujtesa duhet të alokohet dhe të shpërndahet me të njëjtën paraqitje.)
    ///
    /// * `length` duhet të jetë më pak se ose e barabartë me `capacity`.
    /// * `capacity` duhet të jetë kapaciteti me të cilin është alokuar treguesi.
    ///
    /// Shkelja e këtyre mund të shkaktojë probleme si prishja e strukturave të brendshme të të dhënave të alokuesit.Për shembull,**nuk është** e sigurt për të ndërtuar një `Vec<u8>` nga një tregues në një grup C `char` me gjatësi `size_t`.
    /// Gjithashtu nuk është e sigurt të ndërtohet një nga një `Vec<u16>` dhe gjatësia e tij, sepse alokuesi kujdeset për shtrirjen, dhe këto dy lloje kanë shtrirje të ndryshme.
    /// Baferi u caktua me shtrirjen 2 (për `u16`), por pasi ta shndërrojë atë në `Vec<u8>`, ai do të shpërndahet me shtrirjen 1.
    ///
    /// Pronësia e `ptr` transferohet në mënyrë efektive te `Vec<T>` e cila më pas mund të zhvendosë, rialokojë ose ndryshojë përmbajtjen e kujtesës të treguar nga treguesi sipas dëshirës.
    /// Sigurohuni që asgjë tjetër nuk e përdor treguesin pas thirrjes së këtij funksioni.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Përditësoni këtë kur stabilizohet vec_into_raw_part.
    ///     // Parandalon drejtimin e destruktorit të `v` kështu që ne të jemi në kontroll të plotë të alokimit.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Nxirrni informacione të ndryshme të rëndësishme për `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Mbishkruaj kujtesën me 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Vendosni gjithçka përsëri së bashku në një Veç
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Ndërton një `Vec<T, A>` të ri, të zbrazët.
    ///
    /// vector nuk do të caktojë derisa elementët të mos shtyhen mbi të.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Ndërton një `Vec<T, A>` të ri, bosh, me kapacitetin e specifikuar me alokuesin e dhënë.
    ///
    /// vector do të jetë në gjendje të mbajë saktësisht elemente `capacity` pa rialokuar.
    /// Nëse `capacity` është 0, vector nuk do të caktojë.
    ///
    /// Importantshtë e rëndësishme të theksohet se megjithëse vector i kthyer ka *kapacitetin* e specifikuar, vector do të ketë një gjatësi *zero*.
    ///
    /// Për një shpjegim të ndryshimit midis gjatësisë dhe kapacitetit, shih *[Kapaciteti dhe rialokimi]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector nuk përmban artikuj, edhe pse ka kapacitet për më shumë
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Të gjitha këto bëhen pa rialokuar ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... por kjo mund të bëjë që vector të rialokohet
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Krijon një `Vec<T, A>` direkt nga përbërësit e papërpunuar të një vector tjetër.
    ///
    /// # Safety
    ///
    /// Kjo është shumë e pasigurt, për shkak të numrit të invariancave që nuk kontrollohen:
    ///
    /// * `ptr` duhet të jetë alokuar më parë përmes ["String"]/"Vec<T>"(të paktën, ka shumë të ngjarë të jetë e pasaktë nëse nuk do të ishte).
    /// * `T` duhet të ketë të njëjtën madhësi dhe shtrirje si ajo me të cilën është ndarë `ptr`.
    ///   (`T` që ka një shtrirje më pak të rreptë nuk është e mjaftueshme, rreshtimi me të vërtetë duhet të jetë i barabartë për të përmbushur kërkesën [`dealloc`] që kujtesa duhet të alokohet dhe të shpërndahet me të njëjtën paraqitje.)
    ///
    /// * `length` duhet të jetë më pak se ose e barabartë me `capacity`.
    /// * `capacity` duhet të jetë kapaciteti me të cilin është alokuar treguesi.
    ///
    /// Shkelja e këtyre mund të shkaktojë probleme si prishja e strukturave të brendshme të të dhënave të alokuesit.Për shembull,**nuk është** e sigurt për të ndërtuar një `Vec<u8>` nga një tregues në një grup C `char` me gjatësi `size_t`.
    /// Gjithashtu nuk është e sigurt të ndërtohet një nga një `Vec<u16>` dhe gjatësia e tij, sepse alokuesi kujdeset për shtrirjen, dhe këto dy lloje kanë shtrirje të ndryshme.
    /// Baferi u caktua me shtrirjen 2 (për `u16`), por pasi ta shndërrojë atë në `Vec<u8>`, ai do të shpërndahet me shtrirjen 1.
    ///
    /// Pronësia e `ptr` transferohet në mënyrë efektive te `Vec<T>` e cila më pas mund të zhvendosë, rialokojë ose ndryshojë përmbajtjen e kujtesës të treguar nga treguesi sipas dëshirës.
    /// Sigurohuni që asgjë tjetër nuk e përdor treguesin pas thirrjes së këtij funksioni.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Përditësoni këtë kur stabilizohet vec_into_raw_part.
    ///     // Parandalon drejtimin e destruktorit të `v` kështu që ne të jemi në kontroll të plotë të alokimit.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Nxirrni informacione të ndryshme të rëndësishme për `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Mbishkruaj kujtesën me 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Vendosni gjithçka përsëri së bashku në një Veç
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Zbërthen një `Vec<T>` në përbërësit e tij të papërpunuar.
    ///
    /// Kthen treguesin e papërpunuar te të dhënat themelore, gjatësinë e vector (në elemente) dhe kapacitetin e alokuar të të dhënave (në elemente).
    /// Këto janë të njëjtat argumente në të njëjtën renditje si argumentet për [`from_raw_parts`].
    ///
    /// Pas thirrjes së këtij funksioni, telefonuesi është përgjegjës për kujtesën e administruar më parë nga `Vec`.
    /// Mënyra e vetme për ta bërë këtë është kthimi i treguesit të papërpunuar, gjatësisë dhe kapacitetit përsëri në një `Vec` me funksionin [`from_raw_parts`], duke lejuar shkatërruesin të kryejë pastrimin.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Tani mund të bëjmë ndryshime në komponentët, të tilla si transferimi i treguesit të papërpunuar në një lloj të përputhshëm.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Zbërthen një `Vec<T>` në përbërësit e tij të papërpunuar.
    ///
    /// Kthen treguesin e papërpunuar te të dhënat themelore, gjatësinë e vector (në elemente), kapacitetin e alokuar të të dhënave (në elemente) dhe shpërndarësin.
    /// Këto janë të njëjtat argumente në të njëjtën renditje si argumentet për [`from_raw_parts_in`].
    ///
    /// Pas thirrjes së këtij funksioni, telefonuesi është përgjegjës për kujtesën e administruar më parë nga `Vec`.
    /// Mënyra e vetme për ta bërë këtë është kthimi i treguesit të papërpunuar, gjatësisë dhe kapacitetit përsëri në një `Vec` me funksionin [`from_raw_parts_in`], duke lejuar shkatërruesin të kryejë pastrimin.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Tani mund të bëjmë ndryshime në komponentët, të tilla si transferimi i treguesit të papërpunuar në një lloj të përputhshëm.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Kthen numrin e elementeve që vector mund të mbajë pa i rialokuar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Rezervon kapacitetin për të paktën `additional` më shumë elementë që do të futen në `Vec<T>` të dhënë.
    /// Grumbullimi mund të rezervojë më shumë hapësirë për të shmangur rialokimet e shpeshta.
    /// Pas thirrjes `reserve`, kapaciteti do të jetë më i madh ose i barabartë me `self.len() + additional`.
    /// Nuk bën asgjë nëse kapaciteti është tashmë i mjaftueshëm.
    ///
    /// # Panics
    ///
    /// Panics nëse kapaciteti i ri tejkalon `isize::MAX` bajte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Rezervon kapacitetin minimal për saktësisht `additional` më shumë elementë që do të futen në `Vec<T>` të dhënë.
    ///
    /// Pas thirrjes `reserve_exact`, kapaciteti do të jetë më i madh ose i barabartë me `self.len() + additional`.
    /// Nuk bën asgjë nëse kapaciteti është tashmë i mjaftueshëm.
    ///
    /// Vini re se alokuesi mund t'i japë koleksionit më shumë hapësirë sesa kërkon.
    /// Prandaj, kapaciteti nuk mund të mbështetet për të qenë saktësisht minimal.
    /// Preferoni `reserve` nëse priten futje të future.
    ///
    /// # Panics
    ///
    /// Panics nëse kapaciteti i ri tejkalon `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Mundohet të rezervojë kapacitetin për të paktën `additional` më shumë elementë që do të futen në `Vec<T>` të dhënë.
    /// Grumbullimi mund të rezervojë më shumë hapësirë për të shmangur rialokimet e shpeshta.
    /// Pas thirrjes `try_reserve`, kapaciteti do të jetë më i madh ose i barabartë me `self.len() + additional`.
    /// Nuk bën asgjë nëse kapaciteti është tashmë i mjaftueshëm.
    ///
    /// # Errors
    ///
    /// Nëse kapaciteti tejkalohet, ose alokuesi raporton një dështim, atëherë një gabim kthehet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Rezervoni paraprakisht kujtesën, duke dalë nëse nuk mundemi
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tani e dimë që kjo nuk mund të OOM në mes të punës sonë komplekse
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // shume e nderlikuar
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Përpiqet të rezervojë kapacitetin minimal për pikërisht elementët `additional` që do të futen në `Vec<T>` të dhënë.
    /// Pasi të telefononi `try_reserve_exact`, kapaciteti do të jetë më i madh ose i barabartë me `self.len() + additional` nëse kthen `Ok(())`.
    ///
    /// Nuk bën asgjë nëse kapaciteti është tashmë i mjaftueshëm.
    ///
    /// Vini re se alokuesi mund t'i japë koleksionit më shumë hapësirë sesa kërkon.
    /// Prandaj, kapaciteti nuk mund të mbështetet për të qenë saktësisht minimal.
    /// Preferoni `reserve` nëse priten futje të future.
    ///
    /// # Errors
    ///
    /// Nëse kapaciteti tejkalohet, ose alokuesi raporton një dështim, atëherë një gabim kthehet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Rezervoni paraprakisht kujtesën, duke dalë nëse nuk mundemi
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Tani e dimë që kjo nuk mund të OOM në mes të punës sonë komplekse
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // shume e nderlikuar
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Zvogëlon kapacitetin e vector sa më shumë që të jetë e mundur.
    ///
    /// Do të bjerë sa më afër gjatësisë, por alokuesi përsëri mund të informojë vector se ka hapësirë për disa elementë të tjerë.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Kapaciteti nuk është kurrë më i vogël se gjatësia, dhe nuk ka asgjë për të bërë kur ato janë të barabarta, kështu që ne mund të shmangim rastin panic në `RawVec::shrink_to_fit` duke e quajtur atë vetëm me një kapacitet më të madh.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Zvogëlon kapacitetin e vector me një kufi më të ulët.
    ///
    /// Kapaciteti do të mbetet të paktën aq i madh sa gjatësia dhe vlera e furnizuar.
    ///
    ///
    /// Nëse kapaciteti aktual është më i vogël se kufiri i poshtëm, ky është një mos-opsion.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Shndërron vector në [`Box<[T]>`][owned slice].
    ///
    /// Vini re se kjo do të heqë çdo kapacitet të tepërt.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Çdo kapacitet i tepërt hiqet:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Shkurton vector, duke mbajtur elementët e parë `len` dhe duke rënë pjesën tjetër.
    ///
    /// Nëse `len` është më e madhe se gjatësia aktuale e vector, kjo nuk ka efekt.
    ///
    /// Metoda [`drain`] mund të imitojë `truncate`, por bën që elementët e tepërt të kthehen në vend që të bien.
    ///
    ///
    /// Vini re se kjo metodë nuk ka asnjë efekt në kapacitetin e alokuar të vector.
    ///
    /// # Examples
    ///
    /// Shkurtimi i pesë elementeve vector në dy elemente:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Asnjë shkurtim nuk ndodh kur `len` është më e madhe se gjatësia aktuale e vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Shkurtimi kur `len == 0` është ekuivalent me thirrjen e metodës [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Kjo është e sigurt sepse:
        //
        // * feta e kaluar në `drop_in_place` është e vlefshme;rasti `len > self.len` shmang krijimin e një fete të pavlefshme, dhe
        // * `len` i vector zvogëlohet përpara se të telefononi `drop_in_place`, e tillë që asnjë vlerë nuk do të bjerë dy herë në rast se `drop_in_place` do të ishte një herë në panic (nëse panics dy herë, programi anulohet).
        //
        //
        //
        unsafe {
            // Note: Alshtë e qëllimshme që ky është `>` dhe jo `>=`.
            //       Ndryshimi i tij në `>=` ka implikime negative të performancës në disa raste.
            //       Shihni #78884 për më shumë.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Nxjerr një fetë që përmban të gjithë vector.
    ///
    /// Ekuivalente me `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Nxjerr një fetë të ndryshueshme të të gjithë vector.
    ///
    /// Ekuivalente me `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Kthen një tregues të papërpunuar në buffer-in e vector.
    ///
    /// Telefonuesi duhet të sigurojë që vector të jetojë më shumë gjatë treguesit që ky funksion kthehet, ose përndryshe do të përfundojë duke treguar mbeturinat.
    /// Modifikimi i vector mund të shkaktojë rishpërndarjen e mbrojtësit të tij, gjë që gjithashtu do të bënte të pavlefshëm çdo tregues për të.
    ///
    /// Thirrësi gjithashtu duhet të sigurojë që kujtesa në të cilën treguesi (non-transitively) tregon të mos shkruhet kurrë (përveç brenda një `UnsafeCell`) duke përdorur këtë tregues ose ndonjë tregues që rrjedh prej tij.
    /// Nëse keni nevojë të mutoni përmbajtjen e fotos, përdorni [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Ne bëjmë hije metodën e fetë me të njëjtin emër për të shmangur kalimin nëpër `deref`, e cila krijon një referencë të ndërmjetme.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Kthen një tregues të pasigurt të paqëndrueshëm në bufferin e vector.
    ///
    /// Telefonuesi duhet të sigurojë që vector të jetojë më shumë gjatë treguesit që ky funksion kthehet, ose përndryshe do të përfundojë duke treguar mbeturinat.
    ///
    /// Modifikimi i vector mund të shkaktojë rishpërndarjen e mbrojtësit të tij, gjë që gjithashtu do të bënte të pavlefshëm çdo tregues për të.
    ///
    /// # Examples
    ///
    /// ```
    /// // Alokoni vector mjaft të madh për 4 elemente.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Filloni elementet përmes shkrimeve të treguesit të papërpunuar, pastaj vendosni gjatësinë.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Ne bëjmë hije metodën e fetë me të njëjtin emër për të shmangur kalimin nëpër `deref_mut`, e cila krijon një referencë të ndërmjetme.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Kthen një referencë te alokuesi themelor.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Forcon gjatësinë e vector në `new_len`.
    ///
    /// Ky është një operacion i nivelit të ulët që nuk mban asnjë nga invariancat normale të llojit.
    /// Zakonisht ndryshimi i gjatësisë së një vector bëhet duke përdorur një nga operacionet e sigurta, të tilla si [`truncate`], [`resize`], [`extend`] ose [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` duhet të jetë më e vogël ose e barabartë me [`capacity()`].
    /// - Elementet në `old_len..new_len` duhet të iniciohen.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Kjo metodë mund të jetë e dobishme për situatat në të cilat vector shërben si një buffer për kodin tjetër, veçanërisht mbi FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Ky është vetëm një skelet minimal për shembullin doc;
    /// # // mos e përdorni këtë si pikënisje për një bibliotekë të vërtetë.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Sipas dokumenteve të metodës FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SIGURIA: Kur `deflateGetDictionary` kthen `Z_OK`, konstaton se:
    ///     // 1. `dict_length` elementet u inicializuan.
    ///     // 2.
    ///     // `dict_length` <=kapaciteti (32_768) i cili e bën `set_len` të sigurt për të thirrur.
    ///     unsafe {
    ///         // Bëni thirrjen FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... dhe azhurnoni gjatësinë në atë që ishte iniciuar.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Ndërsa shembulli i mëposhtëm është i shëndoshë, ka një rrjedhje kujtese pasi Z0vektorët e brendshëm Z0 nuk u liruan para thirrjes `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` është bosh, kështu që asnjë element nuk ka nevojë të iniciohet.
    /// // 2. `0 <= capacity` gjithmonë mban çfarëdo që është `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalisht, këtu, dikush do të përdorte [`clear`] për të rënë në mënyrë korrekte të përmbajtjes dhe kështu të mos dilte memorie.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Heq një element nga vector dhe e kthen atë.
    ///
    /// Elementi i hequr zëvendësohet nga elementi i fundit i vector.
    ///
    /// Kjo nuk e ruan porositjen, por është O(1).
    ///
    /// # Panics
    ///
    /// Panics nëse `index` është jashtë kufijve.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Ne e zëvendësojmë vetë [indeksin] me elementin e fundit.
            // Vini re se nëse kontrolli i kufijve më lart ka sukses, duhet të ketë një element të fundit (i cili mund të jetë vetë [indeksi] vetë).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Fut një element në pozicionin `index` brenda vector, duke zhvendosur të gjithë elementët pas tij në të djathtë.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // hapësirë për elementin e ri
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // i pagabueshëm Vendi për të vendosur vlerën e re
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Zhvendosni gjithçka për të bërë hapësirë.
                // (Dublikimi i elementit `indeks 'në dy vende radhazi.)
                ptr::copy(p, p.offset(1), len - index);
                // Shkruajeni atë, duke mbishkruar kopjen e parë të elementit `indeks '.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Heq dhe kthen elementin në pozicionin `index` brenda vector, duke zhvendosur të gjithë elementët pas tij në të majtë.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `index` është jashtë kufijve.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // vendi nga po marrim.
                let ptr = self.as_mut_ptr().add(index);
                // kopjojeni atë, duke patur në mënyrë të pasigurt një kopje të vlerës në pirg dhe në vector në të njëjtën kohë.
                //
                ret = ptr::read(ptr);

                // Zhvendos gjithçka poshtë për të mbushur atë vend.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Mban vetëm elementet e specifikuara nga kallëzuesi.
    ///
    /// Me fjalë të tjera, hiqni të gjithë elementët `e` të tillë që `f(&e)` të kthejë `false`.
    /// Kjo metodë operon në vend, duke vizituar secilin element saktësisht një herë në rendin origjinal, dhe ruan rendin e elementeve të mbajtura.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Për shkak se elementët vizitohen saktësisht një herë në rendin origjinal, gjendja e jashtme mund të përdoret për të vendosur se cilat elemente duhet të mbahen.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Shmangni rënien e dyfishtë nëse mbrojtësi i rënies nuk ekzekutohet, pasi që mund të bëjmë disa vrima gjatë procesit.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-leni i përpunuar-> |^-tjetër për të kontrolluar
        //                  | <-fshihet cnt-> |
        //      | <-origjinale_len-> |Kept: Elementet që kallëzuesit kthehen të vërteta.
        //
        // Vrima: Foleja e elementit e lëvizur ose e rënë.
        // E pakontrolluar: Elemente të pavlefshëm të vlefshëm.
        //
        // Ky mbrojtës rënie do të thirret kur kallëzuesi ose `drop` i elementit panikohet.
        // Ai zhvendos elemente të pakontrolluar për të mbuluar vrimat dhe `set_len` në gjatësinë e duhur.
        // Në rastet kur kallëzuesi dhe `drop` nuk frikësohen kurrë, ai do të optimizohet.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SIGURIA: Sendet e pakontrolluara duhet të jenë të vlefshme pasi ne kurrë nuk i prekim ato.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SIGURIA: Pas mbushjes së vrimave, të gjitha sendet janë në kujtesën e afërt.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SIGURIA: Elementi i pakontrolluar duhet të jetë i vlefshëm.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Paraprakisht herët për të shmangur rënien e dyfishtë nëse paniku `drop_in_place`.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SIGURIA: Ne kurrë nuk e prekim këtë element pasi të biem.
                unsafe { ptr::drop_in_place(cur) };
                // Ne tashmë kemi avancuar banakun.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SIGURIA: `deleted_cnt`> 0, kështu që foleja e vrimës nuk duhet të mbivendoset me elementin aktual.
                // Ne përdorim kopje për lëvizje dhe kurrë më mos e prekni këtë element.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // I gjithë artikulli përpunohet.Kjo mund të optimizohet në `set_len` nga LLVM.
        drop(g);
    }

    /// Heq të gjithë, përveç elementit të parë të njëpasnjëshëm në vector që zgjidhen në të njëjtin çelës.
    ///
    ///
    /// Nëse vector është renditur, kjo heq të gjitha kopjimet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Heq të gjithë, përveç elementit të parë të njëpasnjëshëm në vector, duke përmbushur një lidhje të caktuar barazie.
    ///
    /// Funksioni `same_bucket` i kalon referencat për dy elemente nga vector dhe duhet të përcaktojë nëse elementet krahasohen të barabartë.
    /// Elementet kalohen në rend të kundërt nga renditja e tyre në fetë, kështu që nëse `same_bucket(a, b)` kthen `true`, `a` hiqet.
    ///
    ///
    /// Nëse vector është renditur, kjo heq të gjitha kopjimet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Shton një element në pjesën e pasme të një koleksioni.
    ///
    /// # Panics
    ///
    /// Panics nëse kapaciteti i ri tejkalon `isize::MAX` bajte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Kjo do të panic ose anulojë nëse do të caktonim> isize::MAX bajte ose nëse rritja e gjatësisë do të tejkalonte për llojet me madhësi zero.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Heq elementin e fundit nga një vector dhe e kthen atë, ose [`None`] nëse është bosh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Lëviz të gjithë elementët e `other` në `Self`, duke e lënë `other` bosh.
    ///
    /// # Panics
    ///
    /// Panics nëse numri i elementeve në vector tejmbush një `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Shton elemente në `Self` nga tampon tjetër.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Krijon një iterator kullues që heq diapazonin e specifikuar në vector dhe jep artikujt e hequr.
    ///
    /// Kur iterator **bie**, të gjithë elementët në rang hiqen nga vector, edhe nëse iteratori nuk është konsumuar plotësisht.
    /// Nëse përsëritësi **nuk bie**(me [`mem::forget`] për shembull), është e paspecifikuar sa elementë hiqen.
    ///
    /// # Panics
    ///
    /// Panics nëse pika e fillimit është më e madhe se pika e fundit ose nëse pika e fundit është më e madhe se gjatësia e vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Një gamë e plotë pastron vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Siguria e kujtesës
        //
        // Kur Drain krijohet për herë të parë, ajo shkurton gjatësinë e burimit vector për t'u siguruar që asnjë element i pa inicializuar ose i lëvizur nuk mund të arrihet nëse shkatërruesi i Drain nuk do të ekzekutohet kurrë.
        //
        //
        // Drain do ptr::read nga vlerat për të hequr.
        // Kur të keni mbaruar, bishti i mbetur i vec kopjohet përsëri për të mbuluar vrimën, dhe gjatësia vector rikthehet në gjatësinë e re.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // vendosni gjatësinë self.vec për të filluar, për të qenë të sigurt në rast se Drain rrjedh
            self.set_len(start);
            // Përdorni huazimin në IterMut për të treguar sjelljen e huazimit të të gjithë përsëritësit Drain (si &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Pastron vector, duke hequr të gjitha vlerat.
    ///
    /// Vini re se kjo metodë nuk ka asnjë efekt në kapacitetin e alokuar të vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Kthen numrin e elementeve në vector, të referuar edhe si 'length' të tij.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Kthen `true` nëse vector nuk përmban elemente.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Ndan koleksionin në dy në indeksin e dhënë.
    ///
    /// Kthen një vector të sapo alokuar që përmban elementët në intervalin `[at, len)`.
    /// Pas thirrjes, vector origjinal do të mbetet që përmban elementet `[0, at)` me kapacitetin e tij të mëparshëm të pandryshuar.
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // vector i ri mund të marrë bafenë origjinale dhe të shmangë kopjimin
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len` në mënyrë të pasigurt dhe kopjoni artikujt në `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Ndryshon madhësinë e `Vec` në vend, në mënyrë që `len` të jetë e barabartë me `new_len`.
    ///
    /// Nëse `new_len` është më i madh se `len`, `Vec` zgjerohet me ndryshimin, me secilën vend të caktuar shtesë të mbushur me rezultatin e thirrjes së mbylljes `f`.
    ///
    /// Vlerat e kthimit nga `f` do të përfundojnë në `Vec` në rendin që janë gjeneruar.
    ///
    /// Nëse `new_len` është më pak se `len`, `Vec` thjesht cungohet.
    ///
    /// Kjo metodë përdor një mbyllje për të krijuar vlera të reja në çdo shtytje.Nëse preferoni që [`Clone`] të ketë një vlerë të caktuar, përdorni [`Vec::resize`].
    /// Nëse dëshironi të përdorni [`Default`] trait për të gjeneruar vlera, mund të kaloni [`Default::default`] si argumentin e dytë.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Konsumon dhe rrjedh `Vec`, duke kthyer një referencë të ndryshueshme për përmbajtjen, `&'a mut [T]`.
    /// Vini re se lloji `T` duhet të jetojë më gjatë gjatë jetës së zgjedhur `'a`.
    /// Nëse lloji ka vetëm referenca statike, ose aspak, atëherë kjo mund të zgjidhet të jetë `'static`.
    ///
    /// Ky funksion është i ngjashëm me funksionin [`leak`][Box::leak] në [`Box`] përveç që nuk ka asnjë mënyrë për të rikuperuar kujtesën e rrjedhur.
    ///
    ///
    /// Ky funksion është kryesisht i dobishëm për të dhënat që jetojnë për pjesën e mbetur të jetës së programit.
    /// Hedhja e referencës së kthyer do të shkaktojë rrjedhje të kujtesës.
    ///
    /// # Examples
    ///
    /// Përdorimi i thjeshtë:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Kthen kapacitetin e mbetur të vector si një copë `MaybeUninit<T>`.
    ///
    /// Feta e kthyer mund të përdoret për të mbushur vector me të dhëna (p.sh.
    /// duke lexuar nga një skedar) para se të shënoni të dhënat si të iniciuara duke përdorur metodën [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Alokoni vector mjaft të madh për 10 elemente.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Plotësoni 3 elementët e parë.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Shënoni 3 elementët e parë të vector si të iniciuar.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Kjo metodë nuk është zbatuar në terma të `split_at_spare_mut`, për të parandaluar pavlefshmërinë e treguesve në buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Kthen përmbajtjen e vector si një fetë `T`, së bashku me kapacitetin rezervë të mbetur të vector si një fetë `MaybeUninit<T>`.
    ///
    /// Fetë e kapacitetit rezervë të kthyer mund të përdoret për të mbushur vector me të dhëna (p.sh. duke lexuar nga një skedar) përpara se të shënoni të dhënat si të iniciuara duke përdorur metodën [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Vini re se ky është një API i nivelit të ulët, i cili duhet të përdoret me kujdes për qëllime optimizimi.
    /// Nëse duhet të shtoni të dhëna në një `Vec`, mund të përdorni [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] ose [`resize_with`], në varësi të nevojave tuaja të sakta.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Rezervoni hapësirë shtesë mjaft të madhe për 10 elemente.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Plotësoni 4 elementët e ardhshëm.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Shënoni 4 elementet e vector si të iniciuar.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len është injoruar dhe kështu nuk ndryshohet kurrë
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Siguria: ndryshimi i kthimit .2 (përdorimi i &mut) konsiderohet i njëjtë me thirrjen e `.set_len(_)`.
    ///
    /// Kjo metodë përdoret për të pasur qasje unike në të gjitha pjesët vec në të njëjtën kohë në `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` është e garantuar të jetë e vlefshme për elementet `len`
        // - `spare_ptr` po tregon një element pas buffer-it, kështu që nuk përputhet me `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Ndryshon madhësinë e `Vec` në vend, në mënyrë që `len` të jetë e barabartë me `new_len`.
    ///
    /// Nëse `new_len` është më i madh se `len`, `Vec` zgjatet nga diferenca, me secilën vend shtesë shtesë të mbushur me `value`.
    ///
    /// Nëse `new_len` është më pak se `len`, `Vec` thjesht cungohet.
    ///
    /// Kjo metodë kërkon që `T` të implementojë [`Clone`], në mënyrë që të jetë në gjendje të klonojë vlerën e kaluar.
    /// Nëse keni nevojë për më shumë fleksibilitet (ose dëshironi të mbështeteni te [`Default`] në vend të [`Clone`]), përdorni [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Klonon dhe bashkon të gjithë elementët në një fetë në `Vec`.
    ///
    /// Përsëritet mbi fetë `other`, klonon secilin element dhe pastaj ia bashkangjit këtë `Vec`.
    /// `other` vector përshkohet sipas rendit.
    ///
    /// Vini re se ky funksion është i njëjtë me [`extend`], përveç që është i specializuar për të punuar me feta.
    ///
    /// Nëse dhe kur Rust merr specializim, ky funksion ka të ngjarë të zhvlerësohet (por akoma i disponueshëm).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopjon elemente nga diapazoni `src` deri në fund të vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garanton që diapazoni i dhënë është i vlefshëm për indeksimin e vetvetes
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Ky kod përgjithëson `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Zgjatni vlerat vector me `n`, duke përdorur gjeneratorin e dhënë.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Përdorni SetLenOnDrop për të punuar me të metat ku përpiluesi mund të mos e kuptojë dyqanin përmes `ptr` përmes self.set_len() mos pseudonimi.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Shkruaj të gjithë elementët përveç atij të fundit
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Rritni gjatësinë në çdo hap në rastin next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Mund ta shkruajmë elementin e fundit drejtpërdrejt pa klonuar pa nevojë
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len vendosur nga roje fushëveprimi
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Heq elementet e njëpasnjëshme të njëpasnjëshme në vector sipas zbatimit [`PartialEq`] trait.
    ///
    ///
    /// Nëse vector është renditur, kjo heq të gjitha kopjimet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Metodat dhe funksionet e brendshme
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` duhet të jetë indeks i vlefshëm
    /// - `self.capacity() - self.len()` duhet të jetë `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len rritet vetëm pas inicimit të elementeve
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - telefonuesi garanton se src është një indeks i vlefshëm
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Elementi sapo u inicializua me `MaybeUninit::write`, kështu që është mirë të rritet len
            // - len rritet pas çdo elementi për të parandaluar rrjedhjet (shih numrin #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - telefonuesi garanton se `src` është një indeks i vlefshëm
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Të dy treguesit janë krijuar nga referencat unike të feta (`&mut [_]`) kështu që ato janë të vlefshme dhe nuk mbivendosen.
            //
            // - Elementet janë: Kopjo kështu që është në rregull t'i kopjosh ato, pa bërë asgjë me vlerat origjinale
            // - `count` është e barabartë me len e `source`, kështu që burimi është i vlefshëm për leximet `count`
            // - `.reserve(count)` garanton se `spare.len() >= count` aq rezervë është e vlefshme për `count` shkruan
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Elementet sapo u iniciuan nga `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implementimet e zakonshme të trait për Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): me cfg(test) metoda e natyrshme `[T]::to_vec`, e cila kërkohet për këtë përkufizim të metodës, nuk është e disponueshme.
    // Në vend të kësaj përdorni funksionin `slice::to_vec` i cili është i disponueshëm vetëm me cfg(test) NB shikoni modulin slice::hack në slice.rs për më shumë informacion
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // hidhni gjithçka që nuk do të mbishkruhet
        self.truncate(other.len());

        // self.len <= other.len për shkak të cungimit të mësipërm, kështu që fetë këtu janë gjithmonë brenda kufijve.
        //
        let (init, tail) = other.split_at(self.len());

        // ripërdorni vlerat e përmbajtura allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Krijon një përsëritës konsumues, domethënë, një që lëviz secilën vlerë nga vector (nga fillimi në fund).
    /// vector nuk mund të përdoret pasi e thirrni këtë.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s ka tip Varg, jo &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // metoda e fletës për të cilën delegojnë zbatime të ndryshme SpecFrom/SpecExtend kur nuk kanë më optimizime për t'u aplikuar
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Ky është rasti për një përsëritës të përgjithshëm.
        //
        // Ky funksion duhet të jetë ekuivalenti moral i:
        //
        //      për artikullin në përsëritës {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB nuk mund të vërshojë pasi do të na duhej të caktonim hapësirën e adresës
                self.set_len(len + 1);
            }
        }
    }

    /// Krijon një iterator bashkues që zëvendëson diapazonin e specifikuar në vector me iteratorin e dhënë `replace_with` dhe jep artikujt e hequr.
    ///
    /// `replace_with` nuk ka nevojë të jetë e njëjtën gjatësi si `range`.
    ///
    /// `range` hiqet edhe nëse iteratori nuk konsumohet deri në fund.
    ///
    /// Unshtë e paspecifikuar sa elementë hiqen nga vector nëse rrjedh vlera `Splice`.
    ///
    /// Iteratori i hyrjes `replace_with` konsumohet vetëm kur bie vlera `Splice`.
    ///
    /// Kjo është optimale nëse:
    ///
    /// * Bishti (elementet në vector pas `range`) është bosh,
    /// * ose `replace_with` jep më pak elementë ose të barabartë sesa gjatësia e `gamës`
    /// * ose kufiri i poshtëm i `size_hint()` i tij është i saktë.
    ///
    /// Përndryshe, një vector i përkohshëm ndahet dhe bishti lëvizet dy herë.
    ///
    /// # Panics
    ///
    /// Panics nëse pika e fillimit është më e madhe se pika e fundit ose nëse pika e fundit është më e madhe se gjatësia e vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Krijon një iterator i cili përdor një mbyllje për të përcaktuar nëse një element duhet të hiqet.
    ///
    /// Nëse mbyllja kthehet e vërtetë, atëherë elementi hiqet dhe jepet.
    /// Nëse mbyllja kthehet false, elementi do të mbetet në vector dhe nuk do të jepet nga përsëritësi.
    ///
    /// Përdorimi i kësaj metode është ekuivalente me kodin e mëposhtëm:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // kodi juaj këtu
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Por `drain_filter` është më i lehtë për t'u përdorur.
    /// `drain_filter` është gjithashtu më efikas, sepse mund të zhvendosë elementët e grupit me shumicë.
    ///
    /// Vini re se `drain_filter` gjithashtu ju lejon të mutoni çdo element në mbylljen e filtrit, pavarësisht nëse vendosni ta mbani ose hiqni atë.
    ///
    ///
    /// # Examples
    ///
    /// Ndarja e një grupi në çifte dhe mosmarrëveshje, duke ripërdorur ndarjen origjinale:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Ruaju nga rënia e tij (përforcimi i rrjedhjes)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Zgjasni zbatimin që kopjon elemente nga referencat para se t'i shtyni ato në Vec.
///
/// Ky zbatim është i specializuar për përsëritësit e fetave, ku përdor [`copy_from_slice`] për të bashkangjitur të gjithë fetë njëherësh.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Zbaton krahasimin e vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Zbaton renditjen e vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // përdorimi i rënies për [T] përdorni një fetë të papërpunuar për t'iu referuar elementeve të vector si lloji më i dobët i nevojshëm;
            //
            // mund të shmangte pyetjet e vlefshmërisë në raste të caktuara
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec merret me shpërndarjen
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Krijon një `Vec<T>` bosh.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: tërheq testin në libstd, gjë që shkakton gabime këtu
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: tërheq testin në libstd, gjë që shkakton gabime këtu
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Merr të gjithë përmbajtjen e `Vec<T>` si një grup, nëse madhësia e tij përputhet saktësisht me atë të grupit të kërkuar.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Nëse gjatësia nuk përputhet, hyrja kthehet në `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Nëse jeni mirë vetëm duke marrë një prefiks të `Vec<T>`, mund të telefononi më parë [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SIGURIA: `.set_len(0)` është gjithmonë e shëndoshë.
        unsafe { vec.set_len(0) };

        // SIGURIA: Treguesi i një `Vec` gjithmonë është në rregull, dhe
        // përafrimi për të cilin ka nevojë grupi është i njëjtë me artikujt.
        // Ne kemi kontrolluar më herët që kemi artikuj të mjaftueshëm.
        // Artikujt nuk do të bien dy herë pasi `set_len` i thotë `Vec` të mos i hedhë gjithashtu ato.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}