use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Një iterator i cili përdor një mbyllje për të përcaktuar nëse një element duhet të hiqet.
///
/// Ky struktur është krijuar nga [`Vec::drain_filter`].
/// Shihni dokumentacionin e tij për më shumë.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Indeksi i artikullit që do të inspektohet nga thirrja tjetër në `next`.
    pub(super) idx: usize,
    /// Numri i artikujve që janë kulluar (removed) deri më tani.
    pub(super) del: usize,
    /// Gjatësia origjinale e `vec` para kullimit.
    pub(super) old_len: usize,
    /// Kallëzuesi i provës së filtrit.
    pub(super) pred: F,
    /// Një flamur që tregon një panic ka ndodhur në kallëzuesin e provës së filtrit.
    /// Kjo është përdorur si një aluzion në zbatimin e rënies për të parandaluar konsumin e pjesës së mbetur të `DrainFilter`.
    /// Çdo artikull i papërpunuar do të zhvendoset në `vec`, por asnjë artikull tjetër nuk do të bjerë ose testohet nga kallëzuesi i filtrit.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Kthen një referencë te alokuesi themelor.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Azhurnoni indeksin *pasi* thirret kallëzuesi.
                // Nëse indeksi azhurnohet paraprakisht dhe kallëzuesi panics, elementi në këtë indeks do të rrjedhë.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Ky është një shtet mjaft i ngatërruar dhe nuk ka me të vërtetë një gjë të qartë për të bërë.
                        // Ne nuk duam të vazhdojmë të përpiqemi për të ekzekutuar `pred`, kështu që ne thjesht zhvendosim prapa të gjithë elementët e papërpunuar dhe i themi vec-it se ato ende ekzistojnë.
                        //
                        // Ndryshimi i pasëm kërkohet për të parandaluar një rënie të dyfishtë të artikullit të fundit të kulluar me sukses para një panic në kallëzuesin.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Përpjekje për të konsumuar ndonjë element të mbetur nëse kallëzuesi i filtrit nuk është akoma në panik.
        // Ne do të zhvendosim me elemente të prapambetura çdo element të mbetur, nëse tashmë kemi panik ose nëse konsumimi këtu panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}