use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Shënues specializimi për mbledhjen e një tubacioni iterator në Vec ndërsa ripërdor alokimin e burimit, dmth
/// ekzekutimin e tubacionit në vend.
///
/// Prindi SourceIter trait është i nevojshëm për funksionin specializues për të hyrë në alokimin i cili do të ripërdoret.
/// Por nuk mjafton që specializimi të jetë i vlefshëm.
/// Shihni kufijtë shtesë në nënkuptim.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-i brendshëm SourceIter/InPlaceIterable traits zbatohen vetëm nga zinxhirët e adaptorit <Adapter<Adapter<IntoIter>>> (të gjitha në pronësi të core/std).
// Kufijtë shtesë në implementimet e adaptorit (përtej `impl<I: Trait> Trait for Adapter<I>`) varen vetëm nga traits të tjerë të shënuar tashmë si specializim traits (Kopjimi, TrustedRandomAccess, FusedIterator).
//
// I.e. shënuesi nuk varet nga jetëgjatësia e llojeve të furnizuara nga përdoruesit.Modulo vrimën e kopjimit, nga e cila varen tashmë disa specializime të tjera.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Kërkesa shtesë të cilat nuk mund të shprehen përmes trait bounds.Në vend të kësaj, ne mbështetemi te evolucioni:
        // a) nuk ka ZST pasi nuk do të kishte alokim për ripërdorimin dhe aritmetika e treguesit do panic b) përputhja e madhësisë siç kërkohet nga kontrata Alloc c) rreshtimet përputhen siç kërkohet nga kontrata Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // rikthim në implementime më gjenerike
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // përdorni try-fish që nga
        // - vektorizohet më mirë për disa adaptorë iteratorë
        // - ndryshe nga shumica e metodave të përsëritjes së brendshme, ajo merr vetëm një vetvete &mut
        // - na lejon të fusim treguesin e shkrimit nëpër brendësi të tij dhe ta marrim përsëri në fund
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // përsëritja pati sukses, mos u hiqni kokën
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // kontrolloni nëse kontrata SourceIter ishte mbështetur si paralajmërim: nëse nuk do të ishin ne mund të mos arrinim deri në këtë pikë
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // kontrolloni Kontratën InPlaceIterable.Kjo është e mundur vetëm nëse iteratori përparon treguesin burimor fare.
        // Nëse përdor qasje të pakontrolluar përmes TrustedRandomAccess atëherë treguesi burimor do të qëndrojë në pozicionin e tij fillestar dhe ne nuk mund ta përdorim atë si referencë
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // hidhni çdo vlerë të mbetur në bisht të burimit, por parandaloni rënien e alokimit vetë sapo IntoIter të dalë jashtë fushës, nëse rënia panics atëherë ne gjithashtu rrjedhim çdo element të mbledhur në dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // kontrata InPlaceIterable nuk mund të verifikohet saktësisht këtu pasi try_fold ka një referencë ekskluzive në treguesin burimor gjithçka që mund të bëjmë është të kontrollojmë nëse është akoma në diapazon
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}