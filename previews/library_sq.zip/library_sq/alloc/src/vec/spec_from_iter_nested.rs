use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// Një tjetër specializim trait për Vec::from_iter i domosdoshëm për t'i dhënë përparësi manualisht specializimeve të mbivendosura shih [`SpecFromIter`](super::SpecFromIter) për detaje.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Zhbllokoni përsëritjen e parë, pasi vector do të zgjerohet në këtë përsëritje në çdo rast kur e përsëritura nuk është e zbrazët, por cikli në extend_desugared() nuk do të shohë vector të jetë i plotë në disa përsëritje të lakut pasues.
        //
        // Pra, kemi parashikim më të mirë të branch.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // duhet të delegojë në spec_extend() pasi që extend() vetë delegon në spec_from për Vec-et bosh
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // duhet të delegojë në spec_extend() pasi që extend() vetë delegon në spec_from për Vec-et bosh
        //
        vector.spec_extend(iterator);
        vector
    }
}