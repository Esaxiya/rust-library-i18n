#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Përmbajtja e kujtesës së re është e pa iniciale.
    Uninitialized,
    /// Kujtesa e re garantohet të zerohet.
    Zeroed,
}

/// Një ndërmarrje e nivelit të ulët për alokimin, rialokimin dhe shpërndarjen më ergonomike të një memorie memorie në tokë pa u shqetësuar për të gjitha rastet e qosheve të përfshira.
///
/// Ky lloj është i shkëlqyeshëm për ndërtimin e strukturave tuaja të të dhënave si Vec dhe VecDeque.
/// Veçanërisht:
///
/// * Prodhon `Unique::dangling()` në lloje me madhësi zero.
/// * Prodhon `Unique::dangling()` në shpërndarjet me gjatësi zero.
/// * Shmang lirimin e `Unique::dangling()`.
/// * Kap të gjitha tejkalimet në llogaritjet e kapacitetit (i promovon ato në "capacity overflow" panics).
/// * Garda kundër sistemeve 32-bit që alokojnë më shumë se isize::MAX bajte.
/// * Rojet kundër tejmbushjes së gjatësisë tuaj.
/// * Thërret `handle_alloc_error` për ndarje të gabueshme.
/// * Përmban një `ptr::Unique` dhe kështu i dhuron përdoruesit të gjitha përfitimet e lidhura.
/// * Përdor tepricën e kthyer nga alokuesi për të përdorur kapacitetin më të madh në dispozicion.
///
/// Sidoqoftë, ky lloj nuk inspekton kujtesën që administron.Kur të bjerë,*do të* çlirojë kujtesën e tij, por *nuk do* të përpiqet të heqë përmbajtjen e saj.
/// Varet nga përdoruesi i `RawVec` për të trajtuar gjërat aktuale *të ruajtura* brenda një `RawVec`.
///
/// Vini re se teprica e llojeve me madhësi zero është gjithmonë e pafund, kështu që `capacity()` gjithmonë kthen `usize::MAX`.
/// Kjo do të thotë që duhet të keni kujdes kur rrotulloni këtë lloj me `Box<[T]>`, pasi `capacity()` nuk do të japë gjatësinë.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Kjo ekziston sepse konstruksionet `#[unstable]` nuk duhet të përputhen me `min_const_fn` dhe kështu që ato nuk mund të thirren as në `min_const_fn`.
    ///
    /// Nëse ndryshoni `RawVec<T>::new` ose varësi, ju lutemi kujdesuni që të mos prezantoni ndonjë gjë që do të shkelte vërtet `min_const_fn`.
    ///
    /// NOTE: Ne mund ta shmangim këtë përputhje dhe kontroll të përputhshmërisë me disa atribute `#[rustc_force_min_const_fn]` që kërkon përputhje me `min_const_fn` por nuk lejon domosdoshmërisht thirrjen e tij në `stable(...) const fn`/kodi i përdoruesit që nuk mundëson `foo` kur `#[rustc_const_unstable(feature = "foo", issue = "01234")]` është i pranishëm.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Krijon `RawVec` më të madh të mundshëm (në grumbullin e sistemit) pa alokuar.
    /// Nëse `T` ka madhësi pozitive, atëherë kjo e bën një `RawVec` me kapacitet `0`.
    /// Nëse `T` është me madhësi zero, atëherë ai bën një `RawVec` me kapacitet `usize::MAX`.
    /// E dobishme për zbatimin e alokimit të vonuar.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Krijon një `RawVec` (në grumbullin e sistemit) me saktësisht kapacitetin dhe kërkesat e rreshtimit për një `[T; capacity]`.
    /// Kjo është ekuivalente me thirrjen `RawVec::new` kur `capacity` është `0` ose `T` është me madhësi zero.
    /// Vini re se nëse `T` është me madhësi zero kjo do të thotë që ju *nuk* do të merrni një `RawVec` me kapacitetin e kërkuar.
    ///
    /// # Panics
    ///
    /// Panics nëse kapaciteti i kërkuar tejkalon `isize::MAX` bajte.
    ///
    /// # Aborts
    ///
    /// Aborton në OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Ashtu si `with_capacity`, por garanton që bufferi të zerohet.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Rindërton një `RawVec` nga një tregues dhe kapacitet.
    ///
    /// # Safety
    ///
    /// `ptr` duhet të caktohet (në grumbullin e sistemit), dhe me `capacity` të dhënë.
    /// `capacity` nuk mund të tejkalojë `isize::MAX` për llojet me madhësi.(vetëm një shqetësim për sistemet 32-bit).
    /// ZST vectors mund të ketë një kapacitet deri në `usize::MAX`.
    /// Nëse `ptr` dhe `capacity` vijnë nga një `RawVec`, atëherë kjo është e garantuar.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecet e vegjel jane memece.Kalo te:
    // - 8 nëse madhësia e elementit është 1, sepse çdo shpërndarës grumbulli ka të ngjarë të mbledhë një kërkesë prej më pak se 8 bajt në të paktën 8 bajt.
    //
    // - 4 nëse elementet janë me madhësi të moderuar (<=1 KiB).
    // - 1 përndryshe, për të shmangur humbjen e shumë hapësirës për Vec-et shumë të shkurtër.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Ashtu si `new`, por i parameterizuar mbi zgjedhjen e alokuesit për `RawVec` të kthyer.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` do të thotë "unallocated".llojet me madhësi zero janë injoruar.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Ashtu si `with_capacity`, por i parameterizuar mbi zgjedhjen e alokuesit për `RawVec` të kthyer.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Ashtu si `with_capacity_zeroed`, por i parameterizuar mbi zgjedhjen e alokuesit për `RawVec` të kthyer.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Shndërron një `Box<[T]>` në një `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Shndërron të gjithë bufferin në `Box<[MaybeUninit<T>]>` me `len` të specifikuar.
    ///
    /// Vini re se kjo do të rikonstruktojë saktë çdo ndryshim `cap` që mund të jetë kryer.(Shikoni përshkrimin e llojit për detaje.)
    ///
    /// # Safety
    ///
    /// * `len` duhet të jetë më e madhe ose e barabartë me kapacitetin e kërkuar më së fundmi, dhe
    /// * `len` duhet të jetë më e vogël ose e barabartë me `self.capacity()`.
    ///
    /// Vini re, se kapaciteti i kërkuar dhe `self.capacity()` mund të ndryshojnë, pasi një alokues mund të vendosë në përgjithësi dhe të kthejë një bllok memorie më të madh sesa kërkohet.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Kontrolloni mendjen e shëndoshë gjysmën e kërkesës së sigurisë (nuk mund ta kontrollojmë gjysmën tjetër).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Ne shmangim `unwrap_or_else` këtu sepse ai fryn sasinë e IR LLVM të gjeneruar.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Rindërton një `RawVec` nga një tregues, kapacitet dhe alokues.
    ///
    /// # Safety
    ///
    /// `ptr` duhet të caktohet (përmes shpërndarësit të dhënë `alloc`), dhe me `capacity` të dhënë.
    /// `capacity` nuk mund të tejkalojë `isize::MAX` për llojet me madhësi.
    /// (vetëm një shqetësim për sistemet 32-bit).
    /// ZST vectors mund të ketë një kapacitet deri në `usize::MAX`.
    /// Nëse `ptr` dhe `capacity` vijnë nga një `RawVec` i krijuar përmes `alloc`, atëherë kjo është e garantuar.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Merr një tregues të papërpunuar për fillimin e alokimit.
    /// Vini re se kjo është `Unique::dangling()` nëse `capacity == 0` ose `T` është me madhësi zero.
    /// Në rastin e mëparshëm, duhet të keni kujdes.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Merr kapacitetin e alokimit.
    ///
    /// Kjo do të jetë gjithmonë `usize::MAX` nëse `T` është me madhësi zero.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Kthen një referencë të përbashkët te alokuesi që mbështet këtë `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Ne kemi një pjesë të caktuar të kujtesës, kështu që mund të anashkalojmë kontrollet e ekzekutimit për të marrë paraqitjen tonë aktuale.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Siguron që bufferi përmban të paktën hapësirë të mjaftueshme për të mbajtur elementët `len + additional`.
    /// Nëse nuk ka tashmë kapacitet të mjaftueshëm, do të rialokojë hapësirë të mjaftueshme plus hapësirë të rehatshme të dobët për të marrë sjellje të amortizuar *O*(1).
    ///
    /// Do ta kufizojë këtë sjellje nëse do të shkaktonte veten pa nevojë për panic.
    ///
    /// Nëse `len` tejkalon `self.capacity()`, kjo mund të dështojë që në të vërtetë të caktojë hapësirën e kërkuar.
    /// Ky nuk është me të vërtetë i pasigurt, por mund të prishet kodi i pasigurt *që ju shkruani* dhe mbështetet në sjelljen e këtij funksioni.
    ///
    /// Kjo është ideale për zbatimin e një operacioni me shtypje të madhe si `extend`.
    ///
    /// # Panics
    ///
    /// Panics nëse kapaciteti i ri tejkalon `isize::MAX` bajte.
    ///
    /// # Aborts
    ///
    /// Aborton në OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // rezerva do të abortohej ose panikosej nëse len tejkalonte `isize::MAX` kështu që kjo është e sigurt të bëhet e pakontrolluar tani.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// E njëjta gjë si `reserve`, por kthen gabime në vend që të kap paniku ose aborti.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Siguron që bufferi përmban të paktën hapësirë të mjaftueshme për të mbajtur elementët `len + additional`.
    /// Nëse jo tashmë, do të rialokojë sasinë minimale të mundshme të kujtesës të nevojshme.
    /// Në përgjithësi kjo do të jetë saktësisht sasia e kujtesës së nevojshme, por në parim shpërndarësi është i lirë të kthejë më shumë sesa kemi kërkuar.
    ///
    ///
    /// Nëse `len` tejkalon `self.capacity()`, kjo mund të dështojë që në të vërtetë të caktojë hapësirën e kërkuar.
    /// Ky nuk është me të vërtetë i pasigurt, por mund të prishet kodi i pasigurt *që ju shkruani* dhe mbështetet në sjelljen e këtij funksioni.
    ///
    /// # Panics
    ///
    /// Panics nëse kapaciteti i ri tejkalon `isize::MAX` bajte.
    ///
    /// # Aborts
    ///
    /// Aborton në OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Njësoj si `reserve_exact`, por kthen gabime në vend që të kap paniku ose aborti.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Zvogëlon alokimin deri në shumën e specifikuar.
    /// Nëse shuma e dhënë është 0, në të vërtetë zhvendoset plotësisht.
    ///
    /// # Panics
    ///
    /// Panics nëse sasia e dhënë është *më e madhe* se kapaciteti aktual.
    ///
    /// # Aborts
    ///
    /// Aborton në OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Kthehet nëse bufferi duhet të rritet për të përmbushur kapacitetin shtesë të nevojshëm.
    /// Kryesisht përdoret për të bërë të mundur thirrjen e rezervave të rezervuara pa rreshtuar `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Kjo metodë zakonisht instancohet shumë herë.Pra, ne duam që ajo të jetë sa më e vogël që të jetë e mundur, për të përmirësuar kohën e përpilimit.
    // Por ne gjithashtu duam që sa më shumë nga përmbajtja e tij të jetë statistikisht e llogaritshme që të jetë e mundur, për ta bërë kodin e gjeneruar të funksionojë më shpejt.
    // Prandaj, kjo metodë është shkruar me kujdes në mënyrë që i gjithë kodi që varet nga `T` të jetë brenda saj, ndërsa sa më shumë i kodit që nuk varet nga `T` të jetë e mundur është në funksionet që nuk janë të përgjithshme mbi `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Kjo sigurohet nga kontekstet thirrëse.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Meqenëse kthejmë një kapacitet prej `usize::MAX` kur është `elem_size`
            // 0, arritja deri këtu do të thotë domosdoshmërisht që `RawVec` është i plotë.
            return Err(CapacityOverflow);
        }

        // Fatkeqësisht, asgjë nuk mund të bëjmë vërtet për këto kontrolle.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Kjo garanton rritje eksponenciale.
        // Dyfishimi nuk mund të tejkalojë sepse `cap <= isize::MAX` dhe lloji i `cap` është `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` është jo-gjenerik mbi `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Kufizimet në këtë metodë janë shumë të njëjta me ato në `grow_amortized`, por kjo metodë zakonisht instancohet më rrallë, kështu që është më pak kritike.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Meqenëse ne kthejmë një kapacitet prej `usize::MAX` kur madhësia e llojit është
            // 0, arritja deri këtu do të thotë domosdoshmërisht që `RawVec` është i plotë.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` është jo-gjenerik mbi `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ky funksion është jashtë `RawVec` për të minimizuar kohën e përpilimit.Shihni komentin më sipër `RawVec::grow_amortized` për detaje.
// (Parametri `A` nuk është i rëndësishëm, sepse numri i llojeve të ndryshme `A` që shihen në praktikë është shumë më i vogël se numri i llojeve `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Kontrolloni për gabimin këtu për të minimizuar madhësinë e `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Alokuesi kontrollon për barazinë e shtrirjes
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Liron memorien në pronësi të `RawVec`*pa u përpjekur* të heqë përmbajtjen e saj.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Funksioni qendror për trajtimin e gabimit rezervë.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Ne duhet të garantojmë sa vijon:
// * Ne kurrë nuk alokojmë objekte me madhësi `> isize::MAX` bajt.
// * Ne nuk e tejkalojmë `usize::MAX` dhe në të vërtetë alokojmë shumë pak.
//
// Në 64-bit thjesht duhet të kontrollojmë për mbingarkesë pasi që përpjekja për të alokuar `> isize::MAX` bajte me siguri do të dështojë.
// Në 32-bit dhe 16-bit duhet të shtojmë një mbrojtës shtesë për këtë në rast se po vrapojmë në një platformë e cila mund të përdorë të gjitha 4 GB në hapësirën e përdoruesit, p.sh., PAE ose x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Një funksion qendror përgjegjës për raportimin e tejmbushjes së kapacitetit.
// Kjo do të sigurojë që gjenerimi i kodit në lidhje me këto panics të jetë minimal pasi ka vetëm një vendndodhje që panics sesa një bandë në të gjithë modulin.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}