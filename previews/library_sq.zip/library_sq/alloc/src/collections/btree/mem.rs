use core::intrinsics;
use core::mem;
use core::ptr;

/// Kjo zëvendëson vlerën prapa referencës unike `v` duke thirrur funksionin përkatës.
///
///
/// Nëse një panic ndodh në mbylljen `change`, i gjithë procesi do të ndërpritet.
#[allow(dead_code)] // mbajeni si ilustrim dhe për përdorim future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Kjo zëvendëson vlerën prapa referencës unike `v` duke thirrur funksionin përkatës dhe kthen një rezultat të marrë gjatë rrugës.
///
///
/// Nëse një panic ndodh në mbylljen `change`, i gjithë procesi do të ndërpritet.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}