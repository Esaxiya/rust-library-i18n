use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Rezervon një nyje të dobët ndoshta duke u bashkuar ose vjedhur me një vëlla ose motër.
    /// Nëse është i suksesshëm, por me koston e tkurrjes së nyjes mëmë, e kthen atë nyje mëmë.
    /// Kthen një `Err` nëse nyja është një rrënjë boshe.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Rezervon një nyje të mundshme të plotë, dhe nëse kjo bën që nyja e saj mëmë të tkurret, rezervon prindin, në mënyrë rekursive.
    /// Kthen `true` nëse rregullon pemën, `false` nëse nuk mundet sepse nyja rrënjë u boshatis.
    ///
    /// Kjo metodë nuk pret që paraardhësit të jenë më të dobët me rastin e hyrjes dhe panics nëse has një paraardhës të zbrazët.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// Heq nivelet e zbrazëta në majë, por mban një fletë bosh nëse e gjithë pema është e zbrazët.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// Rezervat lart ose bashkojnë çdo nyje të plotë në kufirin e djathtë të pemës.
    /// Nyjet e tjera, ato që nuk janë rrënja dhe as edge më e drejtë, duhet të kenë tashmë të paktën MIN_LEN elemente.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// Kloni simetrik i `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// Grumbulloni çdo nyje të plotë në kufirin e djathtë të pemës.
    /// Nyjet e tjera, ato që nuk janë rrënja dhe as edge më e drejtë, duhet të përgatiten që të vjedhin deri në MIN_LEN elemente.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // Kontrolloni nëse fëmija më i djathtë është i pashembullt.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // Ne kemi nevojë për të vjedhur.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // Shkoni më poshtë.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Rezervat e fëmijës së majtë, duke supozuar se fëmija i duhur nuk është i plotë, dhe provizionet janë një element shtesë për të lejuar bashkimin e fëmijëve të tij nga ana tjetër pa u bërë më i dobët.
    ///
    /// Kthen fëmijën e majtë.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` për të shmangur rregullimin nëse bashkimi ndodh në nivelin tjetër.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// Rezervat e fëmijës së duhur, duke supozuar se fëmija i majtë nuk është i plotë, dhe provizionet janë një element shtesë për të lejuar bashkimin e fëmijëve të tij nga ana tjetër pa u bërë më i dobët.
    ///
    /// Kthehet kudo ku ka përfunduar fëmija i duhur.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` për të shmangur rregullimin nëse bashkimi ndodh në nivelin tjetër.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}