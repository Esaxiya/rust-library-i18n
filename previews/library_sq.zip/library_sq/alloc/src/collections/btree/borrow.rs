use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelon një reborrow të disa referencave unike, kur e dini se reborrow dhe të gjithë pasardhësit e tij (dmth., Të gjithë treguesit dhe referencat që rrjedhin prej tij) nuk do të përdoren më në një moment, pas së cilës ju doni të përdorni përsëri referencën unike origjinale përsëri .
///
///
/// Kontrolluesi i huazimit zakonisht merret me këtë grumbullim të huazimeve për ju, por disa flukse kontrolli që përmbushin këtë grumbullim janë shumë të komplikuara për tu ndjekur nga përpiluesi.
/// Një `DormantMutRef` ju lejon të kontrolloni vetë huazimin, ndërsa jeni duke shprehur akoma natyrën e tij të grumbulluar dhe duke përmbledhur kodin e papërpunuar të treguesit të nevojshëm për ta bërë këtë pa sjellje të papërcaktuar.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Kapni një hua unike dhe menjëherë rigjeni atë.
    /// Për përpiluesit, jetëgjatësia e referencës së re është e njëjtë me jetëgjatësinë e referencës origjinale, por ju promise për ta përdorur atë për një periudhë më të shkurtër.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SIGURIA: ne e mbajmë huazimin përgjatë 'a përmes `_marker` dhe e ekspozojmë
        // vetëm kjo referencë, pra është unike.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Kthehu te huazimi unik i kapur fillimisht.
    ///
    /// # Safety
    ///
    /// Reborrow duhet të ketë përfunduar, dmth., Referenca e kthyer nga `new` dhe të gjithë treguesit dhe referencat që dalin prej tij, nuk duhet të përdoren më.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SIGURIA: kushtet tona të sigurisë nënkuptojnë që kjo referencë është përsëri unike.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;