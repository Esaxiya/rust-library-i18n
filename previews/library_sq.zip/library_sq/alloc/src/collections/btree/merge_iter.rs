use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// Bërthama e një iteratori që bashkon prodhimin e dy përsëritësve në mënyrë rigoroze në ngjitje, për shembull një bashkim ose një ndryshim simetrik.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// Standardet më të shpejta sesa mbështjellja e të dy përsëritësve në një Peekable, ndoshta sepse kemi mundësi të vendosim një lidhje të lidhur me FusedIterator.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// Krijon një bërthamë të re për një iterator që bashkon një çift burimesh.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// Kthen palën tjetër të artikujve që rrjedhin nga çifti i burimeve që bashkohen.
    /// Nëse të dy opsionet e kthyera përmbajnë një vlerë, ajo vlerë është e barabartë dhe ndodh në të dy burimet.
    /// Nëse një nga opsionet e kthyera përmban një vlerë, ajo vlerë nuk ndodh në burimin tjetër (ose burimet nuk janë në rritje rigoroze).
    ///
    /// Nëse asnjë nga opsionet e kthyera nuk përmban një vlerë, përsëritja ka përfunduar dhe thirrjet pasuese do të kthejnë të njëjtën palë boshe.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// Kthen një palë kufijsh të sipërm për `size_hint` të përsëritësit përfundimtar.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}