use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Shton të gjitha çiftet me vlerë kyçe nga bashkimi i dy përsëritësve në ngjitje, duke rritur një ndryshore `length` gjatë rrugës.Kjo e fundit e bën më të lehtë për telefonuesin për të shmangur një rrjedhje kur një mbajtës i pikave panik.
    ///
    /// Nëse të dy përsëritësit prodhojnë të njëjtin çelës, kjo metodë heq çiftin nga përsëritësi i majtë dhe i bashkon çiftin nga përsëritësi i djathtë.
    ///
    /// Nëse dëshironi që pema të përfundojë në një mënyrë rigorozisht ngjitëse, si për një `BTreeMap`, të dy përsëritësit duhet të prodhojnë çelësa në mënyrë rigoroze ngjitëse, secili më i madh se të gjithë çelësat në pemë, përfshirë çelësat tashmë në pemë kur të hyni.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Ne përgatitemi për të bashkuar `left` dhe `right` në një sekuencë të renditur në kohë lineare.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Ndërkohë, ne ndërtojmë një pemë nga sekuenca e renditur në kohë lineare.
        self.bulk_push(iter, length)
    }

    /// Shtyn të gjitha çiftet e vlerës kryesore në fund të pemës, duke rritur një ndryshore `length` gjatë rrugës.
    /// Kjo e fundit e bën më të lehtë për telefonuesin për të shmangur një rrjedhje kur përsëritësi panik.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Përsërisni të gjithë çiftet me vlerë kyçe, duke i shtyrë ato në nyjet në nivelin e duhur.
        for (key, value) in iter {
            // Mundohuni të shtyni çiftin e vlerës kryesore në nyjën aktuale të fletës.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Nuk ka vend më, shko lart dhe shtyhu atje.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Gjeta një nyje me hapësirën e mbetur, shtyni këtu.
                                open_node = parent;
                                break;
                            } else {
                                // Ngjitu përsëri.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Ne jemi në krye, krijojmë një nyje të re rrënjë dhe shtyjmë atje.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Shtyp çiftin e vlerës kryesore dhe nënpemën e re të djathtë.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Shkoni përsëri në fletën më të djathtë përsëri.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Rritja e gjatësisë në çdo përsëritje, për t'u siguruar që harta të rrëzojë elementet e bashkangjitura edhe nëse avancohet paniku i iteratorit.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Një përsëritës për bashkimin e dy sekuencave të renditura në një
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Nëse dy çelësa janë të barabartë, kthen çiftin e vlerës së çelësit nga burimi i duhur.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}