use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Një përfshirëse që do të kërkojë, ashtu si `Bound::Included(T)`.
    Included(T),
    /// Një ekskluziv i kërkuar për të kërkuar, ashtu si `Bound::Excluded(T)`.
    Excluded(T),
    /// Një lidhje gjithëpërfshirëse e pakushtëzuar, ashtu si `Bound::Unbounded`.
    AllIncluded,
    /// Një lidhje ekskluzive e pakushtëzuar.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Kërkon një çelës të dhënë në një (nën) pemë të drejtuar nga nyja, në mënyrë rekursive.
    /// Kthen një `Found` me dorezën e KV që përputhet, nëse ka.
    /// Përndryshe, kthen një `GoDown` me dorezën e fletës edge ku i përket çelësi.
    ///
    /// Rezultati është kuptimplotë vetëm nëse pema renditet me çelës, siç është pema në një `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Zbritet në nyjen më të afërt ku edge që përputhet me kufirin e poshtëm të intervalit është i ndryshëm nga edge që përputhet me kufirin e sipërm, dmth., Nyja më e afërt që ka të paktën një çelës të përfshirë në interval.
    ///
    ///
    /// Nëse gjendet, kthen një `Ok` me atë nyje, çifti i indekseve edge në të duke kufizuar intervalin, dhe çiftin përkatës të kufijve për vazhdimin e kërkimit në nyjet fëmijë, në rast se nyja është e brendshme.
    ///
    /// Nëse nuk gjendet, kthen një `Err` me fletën edge që përputhet me të gjithë gamën.
    ///
    /// Rezultati është kuptimplotë vetëm nëse pema renditet me çelës.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Nënvizimi i këtyre ndryshoreve duhet të shmanget.
        // Supozojmë se kufijtë e raportuar nga `range` mbeten të njëjtat, por një zbatim kundërshtar mund të ndryshojë midis thirrjeve (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Gjen një edge në nyjen që kufizon kufirin e poshtëm të një diapazoni.
    /// Gjithashtu kthen kufirin e poshtëm që do të përdoret për të vazhduar kërkimin në nyjen e fëmijës që përputhet, nëse `self` është një nyje e brendshme.
    ///
    ///
    /// Rezultati është kuptimplotë vetëm nëse pema renditet me çelës.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Kloni i `find_lower_bound_edge` për kufirin e sipërm.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Kërkon një çelës të dhënë në nyje, pa rekursion.
    /// Kthen një `Found` me dorezën e KV që përputhet, nëse ka.
    /// Përndryshe, kthen një `GoDown` me dorezën e edge ku mund të gjendet çelësi (nëse nyja është e brendshme) ose ku mund të futet çelësi.
    ///
    ///
    /// Rezultati është kuptimplotë vetëm nëse pema renditet me çelës, siç është pema në një `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Kthen ose indeksin KV në nyjën në të cilën ekziston çelësi (ose një ekuivalent), ose indeksin edge ku i përket çelësi.
    ///
    ///
    /// Rezultati është kuptimplotë vetëm nëse pema renditet me çelës, siç është pema në një `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Gjen një indeks edge në nyjen që kufizon kufirin e poshtëm të një diapazoni.
    /// Gjithashtu kthen kufirin e poshtëm që do të përdoret për të vazhduar kërkimin në nyjen e fëmijës që përputhet, nëse `self` është një nyje e brendshme.
    ///
    ///
    /// Rezultati është kuptimplotë vetëm nëse pema renditet me çelës.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Kloni i `find_lower_bound_index` për kufirin e sipërm.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}