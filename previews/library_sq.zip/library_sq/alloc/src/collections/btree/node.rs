// Kjo është një përpjekje për një zbatim që ndjek idealin
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Meqenëse Rust në të vërtetë nuk ka lloje të varura dhe rekursion polimorfik, ne arrijmë shumë siguri.
//

// Një qëllim kryesor i këtij moduli është të shmangë kompleksitetin duke trajtuar pemën si një enë gjenerike (nëse ka një formë të çuditshme) dhe duke shmangur trajtimin e shumicës së pandryshuesve të Pemës B.
//
// Si i tillë, këtij moduli nuk i intereson nëse hyrjet janë të renditura, cilat nyje mund të jenë të pashembullta, apo edhe çfarë do të thotë nënveprim.Sidoqoftë, ne mbështetemi në disa gjëra të pandryshueshme:
//
// - Pemët duhet të kenë uniforme depth/height.Kjo do të thotë që çdo rrugë poshtë një gjethe nga një nyje e dhënë ka saktësisht të njëjtën gjatësi.
// - Një nyje me gjatësi `n` ka çelësa `n`, vlera `n` dhe skajet `n + 1`.
//   Kjo nënkupton që edhe një nyje e zbrazët ka të paktën një edge.
//   Për një nyje gjetheje, "having an edge" do të thotë vetëm se ne mund të identifikojmë një pozicion në nyje, pasi skajet e gjetheve janë bosh dhe nuk kanë nevojë për paraqitje të të dhënave.
// Në një nyje të brendshme, një edge identifikon një pozicion dhe përmban një tregues për një nyje fëmije.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Përfaqësimi themelor i nyjeve të gjetheve dhe një pjesë e përfaqësimit të nyjeve të brendshme.
struct LeafNode<K, V> {
    /// Ne duam të jemi kovariant në `K` dhe `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Indeksi i kësaj nyje në grupin `edges` të nyjes prind.
    /// `*node.parent.edges[node.parent_idx]` duhet të jetë e njëjta gjë si `node`.
    /// Kjo është e garantuar që të inicializohet vetëm kur `parent` nuk është nul.
    parent_idx: MaybeUninit<u16>,

    /// Numri i çelësave dhe vlerave që ruan kjo nyje.
    len: u16,

    /// Vargjet që ruajnë të dhënat aktuale të nyjës.
    /// Vetëm elementët e parë `len` të secilës grup janë inicializuar dhe të vlefshëm.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inicializon një `LeafNode` të ri në vend.
    unsafe fn init(this: *mut Self) {
        // Si një politikë e përgjithshme, ne i lëmë fushat të pa iniciale nëse mund të jenë, pasi kjo duhet të jetë pak më e shpejtë dhe më e lehtë për t'u gjurmuar në Valgrind.
        //
        unsafe {
            // prindërit_idx, çelësat dhe vals janë të gjithë MbaseUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Krijon një `LeafNode` të ri në kuti.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Paraqitja themelore e nyjeve të brendshme.Ashtu si me `LeafNode`, këto duhet të fshihen pas`BoxedNode`s për të parandaluar rënien e çelësave dhe vlerave të pa inicializuar.
/// Çdo tregues në një `InternalNode` mund të hidhet drejtpërdrejt në një tregues në pjesën themelore `LeafNode` të nyjes, duke lejuar që kodi të veprojë në nyjet gjethe dhe të brendshme në mënyrë gjenerike pa pasur nevojë të kontrollojë as në cilin prej të dyve tregon një tregues.
///
/// Kjo pronë mundësohet nga përdorimi i `repr(C)`.
///
#[repr(C)]
// gdb_providers.py përdor këtë emër lloji për introspeksion.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Treguesit për fëmijët e kësaj nyje.
    /// `len + 1` nga këto konsiderohen të iniciuara dhe të vlefshme, përveç që afër fundit, ndërsa pema mbahet përmes huasë së tipit `Dying`, disa nga këta tregues janë të varur.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Krijon një `InternalNode` të ri në kuti.
    ///
    /// # Safety
    /// Një e pandryshueshme e nyjeve të brendshme është se ata kanë të paktën një edge të iniciuar dhe të vlefshëm.
    /// Ky funksion nuk vendos një edge të tillë.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Ne vetëm duhet të iniciojmë të dhënat;skajet janë MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Një tregues i menaxhuar, jo null në një nyje.Ky është ose një tregues në pronësi të `LeafNode<K, V>` ose një tregues në pronësi të `InternalNode<K, V>`.
///
/// Sidoqoftë, `BoxedNode` nuk përmban asnjë informacion se cili nga dy llojet e nyjeve përmban në të vërtetë, dhe, pjesërisht për shkak të kësaj mungese informacioni, nuk është një lloj i veçantë dhe nuk ka shkatërrues.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Nyja rrënjësore e një peme në pronësi.
///
/// Vini re se ky nuk ka një shkatërrues dhe duhet të pastrohet manualisht.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Kthen një pemë të re në pronësi, me nyjen e vet rrënjë që fillimisht është bosh.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` nuk duhet të jetë zero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Huazon në mënyrë të pandryshueshme nyjen rrënjë në pronësi.
    /// Ndryshe nga `reborrow_mut`, kjo është e sigurt sepse vlera e kthimit nuk mund të përdoret për të shkatërruar rrënjën dhe nuk mund të ketë referenca të tjera për pemën.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Pak huazon në mënyrë të paqëndrueshme nyjen rrënjë në pronësi.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Kalohet në mënyrë të pakthyeshme në një referencë që lejon përshkimin dhe ofron metoda shkatërruese dhe pak më shumë.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Shton një nyje të re të brendshme me një edge të vetme që tregon nyjën rrënjë të mëparshme, bëjeni atë nyje të re nyjen rrënjë dhe kthejeni atë.
    /// Kjo rrit lartësinë me 1 dhe është e kundërta e `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, përveç që sapo harruam se jemi të brendshëm tani:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Heq nyjen e brendshme të rrënjës, duke përdorur fëmijën e saj të parë si nyjen e re rrënjë.
    /// Siç synohet të thirret vetëm kur nyja rrënjë ka vetëm një fëmijë, nuk bëhet pastrim në asnjë prej çelësave, vlerave dhe fëmijëve të tjerë.
    ///
    /// Kjo zvogëlon lartësinë me 1 dhe është e kundërta e `push_internal_level`.
    ///
    /// Kërkon qasje ekskluzive në objektin `Root` por jo në nyjen rrënjë;
    /// nuk do të zhvlerësojë dorezat ose referencat e tjera në nyjën rrënjë.
    ///
    /// Panics nëse nuk ka një nivel të brendshëm, dmth., Nëse nyja rrënjë është një gjethe.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SIGURIA: kemi pohuar se jemi të brendshëm.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SIGURIA: ne huazuam `self` ekskluzivisht dhe lloji i tij i huazimit është ekskluziv.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SIGURIA: edge i parë inicializohet gjithmonë.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` është gjithmonë kovariant në `K` dhe `V`, edhe kur `BorrowType` është `Mut`.
// Kjo është teknikisht e gabuar, por nuk mund të rezultojë në ndonjë pasiguri për shkak të përdorimit të brendshëm të `NodeRef` sepse qëndrojmë plotësisht gjenerikë mbi `K` dhe `V`.
//
// Sidoqoftë, sa herë që një tip publik mbështjell `NodeRef`, sigurohuni që të ketë ndryshimin e duhur.
//
/// Një referencë për një nyje.
///
/// Ky lloj ka një numër parametrash që kontrollojnë se si vepron:
/// - `BorrowType`: Një tip bedel që përshkruan llojin e huazimit dhe mbart një jetë.
///    - Kur kjo është `Immut<'a>`, `NodeRef` vepron përafërsisht si `&'a Node`.
///    - Kur kjo është `ValMut<'a>`, `NodeRef` vepron përafërsisht si `&'a Node` në lidhje me çelësat dhe strukturën e pemës, por gjithashtu lejon që të bashkëjetojnë shumë referenca të ndryshueshme ndaj vlerave në të gjithë pemën.
///    - Kur kjo është `Mut<'a>`, `NodeRef` vepron përafërsisht si `&'a mut Node`, megjithëse metodat e futjes lejojnë që një tregues i ndryshueshëm në një vlerë të bashkëjetojë.
///    - Kur kjo është `Owned`, `NodeRef` vepron përafërsisht si `Box<Node>`, por nuk ka një shkatërrues dhe duhet të pastrohet manualisht.
///    - Kur kjo është `Dying`, `NodeRef` ende vepron përafërsisht si `Box<Node>`, por ka metoda për të shkatërruar pemën pak nga pak, dhe metodat e zakonshme, megjithëse nuk janë shënuar si të pasigurta për t'u thirrur, mund të thirren në UB nëse thirren gabimisht.
///
///   Meqenëse çdo `NodeRef` lejon lundrimin nëpër pemë, `BorrowType` zbatohet në mënyrë efektive për të gjithë pemën, jo vetëm për vetë nyjen.
/// - `K` dhe `V`: Këto janë llojet e çelësave dhe vlerave të ruajtura në nyje.
/// - `Type`: Kjo mund të jetë `Leaf`, `Internal` ose `LeafOrInternal`.
/// Kur kjo është `Leaf`, `NodeRef` tregon një nyje gjethe, kur kjo është `Internal` `NodeRef` tregon një nyje të brendshme, dhe kur kjo është `LeafOrInternal` `NodeRef` mund të tregojë në secilin lloj të nyjes.
///   `Type` quhet `NodeType` kur përdoret jashtë `NodeRef`.
///
/// Të dy `BorrowType` dhe `NodeType` kufizojnë ato metoda që zbatojmë, për të shfrytëzuar sigurinë e tipit statik.Ka kufizime në mënyrën se si ne mund të zbatojmë kufizime të tilla:
/// - Për secilin parametër të tipit, ne mund të përcaktojmë vetëm një metodë ose në mënyrë gjenerike ose për një lloj të veçantë.
/// Për shembull, ne nuk mund të përcaktojmë një metodë si `into_kv` përgjithësisht për të gjithë `BorrowType`, ose një herë për të gjitha llojet që mbajnë gjatë gjithë jetës, sepse duam që ajo të kthejë referencat `&'a`.
///   Prandaj, ne e përcaktojmë atë vetëm për llojin më pak të fuqishëm `Immut<'a>`.
/// - Ne nuk mund të marrim shtrëngim të nënkuptuar nga themi `Mut<'a>` në `Immut<'a>`.
///   Prandaj, ne duhet ta quajmë shprehimisht `reborrow` në një `NodeRef` më të fuqishme në mënyrë që të arrijmë një metodë si `into_kv`.
///
/// Të gjitha metodat në `NodeRef` që kthejnë një lloj reference, ose:
/// - Merrni `self` sipas vlerës dhe kthejeni jetën e kryer nga `BorrowType`.
///   Ndonjëherë, për të thirrur një metodë të tillë, duhet të telefonojmë `reborrow_mut`.
/// - Merrni `self` me referencë, dhe (implicitly) ktheni atë jetëgjatësi të referencës, në vend të jetës së kryer nga `BorrowType`.
/// Në atë mënyrë, kontrolluesi i huazimit garanton që `NodeRef` të mbetet i huazuar për sa kohë që përdoret referenca e kthyer.
///   Metodat që mbështesin futjen e përkulin këtë rregull duke kthyer një tregues të papërpunuar, dmth., Një referencë pa asnjë jetëgjatësi.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Numri i niveleve që nyja dhe niveli i gjetheve janë të ndara, një konstante e nyjes që nuk mund të përshkruhet tërësisht nga `Type`, dhe që nyja vetë nuk e ruan.
    /// Ne vetëm duhet të ruajmë lartësinë e nyjes rrënjë dhe të nxjerrim lartësinë e çdo nyje tjetër nga ajo.
    /// Duhet të jetë zero nëse `Type` është `Leaf` dhe jo-zero nëse `Type` është `Internal`.
    ///
    ///
    height: usize,
    /// Treguesi në fletë ose nyjen e brendshme.
    /// Përkufizimi i `InternalNode` siguron që treguesi të jetë i vlefshëm.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Shpaketoni një referencë nyje që ishte e paketuar si `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ekspozon të dhënat e një nyje të brendshme.
    ///
    /// Kthen një ptr të papërpunuar për të shmangur zhvlerësimin e referencave të tjera në këtë nyje.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SIGURIA: lloji i nyjes statike është `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Merr hyrjen ekskluzive në të dhënat e një nyjeje të brendshme.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Gjen gjatësinë e nyjes.Ky është numri i çelësave ose vlerave.
    /// Numri i skajeve është `len() + 1`.
    /// Vini re se, pavarësisht se është i sigurt, thirrja e këtij funksioni mund të ketë efektin anësor të pavlefshmërisë së referencave të paqëndrueshme që ka krijuar kodi i pasigurt.
    ///
    pub fn len(&self) -> usize {
        // Ç'është më e rëndësishmja, këtu kemi qasje vetëm në fushën `len`.
        // Nëse BorrowType është marker::ValMut, mund të ketë referenca të pazgjidhura të paqëndrueshme ndaj vlerave që nuk duhet t'i zhvlerësojmë.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Kthen numrin e niveleve që nyja dhe gjethet janë të ndara.
    /// Lartësia zero do të thotë që nyja është vetë një gjethe.
    /// Nëse pikturoni pemë me rrënjën sipër, numri thotë se në cilën lartësi shfaqet nyja.
    /// Nëse pikturoni pemë me gjethe sipër, numri tregon se sa lart shtrihet pema mbi nyjen.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Përkohësisht merr një referencë tjetër, të pandryshueshme për të njëjtën nyje.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Ekspozon pjesën e gjethes të çdo gjetheje ose nyje të brendshme.
    ///
    /// Kthen një ptr të papërpunuar për të shmangur zhvlerësimin e referencave të tjera në këtë nyje.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Nyja duhet të jetë e vlefshme për të paktën pjesën LeafNode.
        // Kjo nuk është një referencë në llojin NodeRef sepse nuk e dimë nëse duhet të jetë unike ose e përbashkët.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Gjen prindin e nyjes aktuale.
    /// Kthen `Ok(handle)` nëse nyja aktuale në të vërtetë ka një prind, ku `handle` tregon edge të prindit që tregon nyjen aktuale.
    ///
    /// Kthen `Err(self)` nëse nyja aktuale nuk ka prind, duke i dhënë `NodeRef` origjinale.
    ///
    /// Emri i metodës supozon se ju pikturoni pemë me nyjën rrënjë sipër.
    ///
    /// `edge.descend().ascend().unwrap()` dhe `node.ascend().unwrap().descend()`, me sukses, të dy nuk duhet të bëjnë asgjë.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Ne duhet të përdorim tregues të papërpunuar për nyjet sepse, nëse BorrowType është marker::ValMut, mund të ketë referenca të pazgjidhura të paqëndrueshme për vlerat që nuk duhet t'i zhvlerësojmë.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Vini re se `self` duhet të jetë i zbrazët.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Vini re se `self` duhet të jetë i zbrazët.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Ekspozon pjesën e gjethes të çdo gjetheje ose nyje të brendshme në një pemë të pandryshueshme.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SIGURIA: nuk mund të ketë referenca të ndryshueshme në këtë pemë të huazuar si `Immut`.
        unsafe { &*ptr }
    }

    /// Hap një pamje në tastet e ruajtura në nyje.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Ngjashëm me `ascend`, merr një referencë në nyjen mëmë të një nyje, por gjithashtu zhvendos nyjen aktuale në proces.
    /// Kjo është e pasigurt sepse nyja aktuale do të jetë akoma e arritshme pavarësisht se do të shpërndahet.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Në mënyrë të pasigurt pohon tek përpiluesi informacionin statik se kjo nyje është `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Në mënyrë të pasigurt i pohon përpiluesit informacionin statik se kjo nyje është `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Përkohësisht merr një referencë tjetër, të ndryshueshme për të njëjtën nyje.Kujdes, pasi kjo metodë është shumë e rrezikshme, dyfish kështu që nuk mund të duket menjëherë e rrezikshme.
    ///
    /// Meqenëse treguesit e ndryshueshëm mund të enden kudo rreth pemës, treguesi i kthyer mund të përdoret lehtësisht për ta bërë treguesin origjinal të varur, jashtë kufijve, ose të pavlefshëm nën rregullat e grumbulluara të huazimit.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) konsideroni shtimin e një parametri tjetër tipi në `NodeRef` që kufizon përdorimin e metodave të navigimit në pointerët e rigjetur, duke parandaluar këtë pasiguri.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Hyrja ekskluzive në pjesën e gjetheve të çdo gjetheje ose nyje të brendshme.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SIGURIA: ne kemi qasje ekskluzive në të gjithë nyjen.
        unsafe { &mut *ptr }
    }

    /// Ofron qasje ekskluzive në pjesën e gjetheve të çdo gjetheje ose nyje të brendshme.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SIGURIA: ne kemi qasje ekskluzive në të gjithë nyjen.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Merr hyrjen ekskluzive në një element të zonës kryesore të magazinimit.
    ///
    /// # Safety
    /// `index` është në kufijtë e 0..KAPACITETI
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SIGURIA: telefonuesi nuk do të jetë në gjendje të thërrasë metoda të mëtejshme në vetvete
        // derisa të hiqet referenca e pjesës kryesore, pasi kemi qasje unike për tërë jetën e huasë.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Merr hyrjen ekskluzive në një element ose pjesë të zonës së ruajtjes së vlerës së nyjes.
    ///
    /// # Safety
    /// `index` është në kufijtë e 0..KAPACITETI
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SIGURIA: telefonuesi nuk do të jetë në gjendje të thërrasë metoda të mëtejshme në vetvete
        // derisa referenca e pjesës së vlerës të mos bjerë, pasi kemi qasje unike për tërë jetën e huasë.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Merr hyrjen ekskluzive në një element ose pjesë të zonës së ruajtjes së nyjes për përmbajtjen e edge.
    ///
    /// # Safety
    /// `index` është në kufijtë e 0..KAPACITETI + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SIGURIA: telefonuesi nuk do të jetë në gjendje të thërrasë metoda të mëtejshme në vetvete
        // derisa referenca e fetë edge të mos bjerë, pasi kemi qasje unike për tërë jetën e huasë.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Nyja ka më shumë se elementë të inicuar `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Ne krijojmë vetëm një referencë për një element për të cilin jemi të interesuar, për të shmangur aliasimin me referenca të jashtëzakonshme ndaj elementeve të tjerë, veçanërisht ato që i janë kthyer telefonuesit në përsëritjet e mëparshme.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Ne duhet të shtrëngojmë treguesit e grupeve të papërmasa për shkak të çështjes Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Hapja ekskluzive e Borrows në gjatësinë e nyjes.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Vendos lidhjen e nyjes në edge të saj mëmë, pa bërë të pavlefshme referencat e tjera për nyjen.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Pastron lidhjen e rrënjës me edge të saj mëmë.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Shton një çift të vlerës kryesore në fund të nyjës.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Çdo artikull i kthyer nga `range` është një indeks i vlefshëm edge për nyjën.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Shton një çift me vlerë kyçe dhe një edge për të shkuar në të djathtë të asaj çifti, në fund të nyjes.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Kontrollon nëse një nyje është një nyje `Internal` apo një nyje `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Një referencë për një çift specifik të vlerës kyçe ose edge brenda një nyje.
/// Parametri `Node` duhet të jetë `NodeRef`, ndërsa `Type` mund të jetë `KV` (që nënkupton një dorezë në një çift me vlerë kyçe) ose `Edge` (që nënkupton një dorezë në një edge).
///
/// Vini re se edhe nyjet `Leaf` mund të kenë doreza `Edge`.
/// Në vend që të përfaqësojnë një tregues në një nyje fëmije, këto përfaqësojnë hapësirat ku treguesit e fëmijëve do të shkonin midis çifteve me vlerë kyçe.
/// Për shembull, në një nyje me gjatësi 2, do të kishte 3 vendndodhje të mundshme edge, një në të majtë të nyjes, një midis dy çifteve dhe një në të djathtë të nyjes.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Ne nuk kemi nevojë për përgjithësinë e plotë të `#[derive(Clone)]`, pasi e vetmja kohë që `Node` do të jetë "Klone" e mundur kur është një referencë e pandryshueshme dhe për këtë arsye `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Marr nyjen që përmban çiftin edge ose çelësin me vlerë në të cilën tregon kjo dorezë.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Kthen pozicionin e kësaj doreze në nyje.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Krijon një dorezë të re në një çift me vlerë kyçe në `node`.
    /// I pasigurt sepse telefonuesi duhet të sigurojë që `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Mund të jetë një implementim publik i PartialEq, por përdoret vetëm në këtë modul.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Përkohësisht nxjerr një dorezë tjetër, të pandryshueshme në të njëjtin vend.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Ne nuk mund të përdorim Handle::new_kv ose Handle::new_edge sepse nuk e dimë llojin tonë
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Në mënyrë të pasigurt pohon tek përpiluesi informacionin statik se nyja e dorezës është `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Përkohësisht nxjerr një dorezë tjetër, të ndryshueshme në të njëjtin vend.
    /// Kujdes, pasi kjo metodë është shumë e rrezikshme, dyfish kështu që nuk mund të duket menjëherë e rrezikshme.
    ///
    ///
    /// Për detaje, shihni `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Ne nuk mund të përdorim Handle::new_kv ose Handle::new_edge sepse nuk e dimë llojin tonë
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Krijon një dorezë të re për një edge në `node`.
    /// I pasigurt sepse telefonuesi duhet të sigurojë që `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Duke pasur parasysh një indeks edge ku duam të fusim në një nyje të mbushur me kapacitet, llogarit një indeks të ndjeshëm KV të një pike të ndarë dhe ku të kryhet futja.
///
/// Qëllimi i pikës së ndarë është që çelësi dhe vlera e saj të përfundojnë në një nyje prind;
/// çelësat, vlerat dhe skajet në të majtë të pikës së ndarjes bëhen fëmija i majtë;
/// çelësat, vlerat dhe skajet në të djathtë të pikës së ndarjes bëhen fëmija i duhur.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Çështja Rust #74834 përpiqet të shpjegojë këto rregulla simetrike.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Fut një palë të re me vlerë çelësi midis çifteve me vlerë çelës në të djathtë dhe të majtë të kësaj edge.
    /// Kjo metodë supozon se ka mjaft hapësirë në nyje që çifti i ri të përshtatet.
    ///
    /// Treguesi i kthyer tregon për vlerën e futur.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Fut një palë të re me vlerë çelësi midis çifteve me vlerë çelës në të djathtë dhe të majtë të kësaj edge.
    /// Kjo metodë ndan nyjen nëse nuk ka vend të mjaftueshëm.
    ///
    /// Treguesi i kthyer tregon për vlerën e futur.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Rregullon treguesin dhe indeksin prind në nyjen e fëmijës ku lidhet kjo edge.
    /// Kjo është e dobishme kur renditja e skajeve është ndryshuar,
    fn correct_parent_link(self) {
        // Krijoni backpointer pa bërë të pavlefshme referencat e tjera në nyje.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Fut një çift të ri me vlerë kyçe dhe një edge që do të shkojë në të djathtë të asaj çifti të ri midis këtij edge dhe çiftit të vlerës kyçe në të djathtë të këtij edge.
    /// Kjo metodë supozon se ka mjaft hapësirë në nyje që çifti i ri të përshtatet.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Fut një çift të ri me vlerë kyçe dhe një edge që do të shkojë në të djathtë të asaj çifti të ri midis këtij edge dhe çiftit të vlerës kyçe në të djathtë të këtij edge.
    /// Kjo metodë ndan nyjen nëse nuk ka vend të mjaftueshëm.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Fut një palë të re me vlerë çelësi midis çifteve me vlerë çelës në të djathtë dhe të majtë të kësaj edge.
    /// Kjo metodë ndan nyjen nëse nuk ka hapësirë të mjaftueshme dhe përpiqet të fusë pjesën e ndarë në nyjen prind në mënyrë rekursive, derisa të arrihet rrënja.
    ///
    ///
    /// Nëse rezultati i kthyer është një `Fit`, nyja e dorezës së tij mund të jetë nyja e këtij edge ose një paraardhës.
    /// Nëse rezultati i kthyer është `Split`, fusha `left` do të jetë nyja rrënjësore.
    /// Treguesi i kthyer tregon për vlerën e futur.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Gjen nyjen e treguar nga kjo edge.
    ///
    /// Emri i metodës supozon se ju pikturoni pemë me nyjën rrënjë sipër.
    ///
    /// `edge.descend().ascend().unwrap()` dhe `node.ascend().unwrap().descend()`, me sukses, të dy nuk duhet të bëjnë asgjë.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Ne duhet të përdorim tregues të papërpunuar për nyjet sepse, nëse BorrowType është marker::ValMut, mund të ketë referenca të pazgjidhura të paqëndrueshme për vlerat që nuk duhet t'i zhvlerësojmë.
        // Nuk ka asnjë shqetësim për të hyrë në fushën e lartësisë sepse ajo vlerë kopjohet.
        // Kini kujdes që, pasi të jetë referuar treguesi i nyjes, ne kemi qasje në skajin e skajeve me një referencë (Rust çështje #73987) dhe zhvleftësojmë çdo referencë tjetër në ose brenda grupit, nëse duhet të jetë rreth.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Ne nuk mund të quajmë metoda të ndara të çelësit dhe vlerës, sepse thirrja e së dytës bën të pavlefshme referencën e kthyer nga e para.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Zëvendësoni çelësin dhe vlerën që i referohet doreza e KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Ndihmon implementimet e `split` për një `NodeType` të veçantë, duke u kujdesur për të dhënat e gjetheve.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Ndan nyjen themelore në tre pjesë:
    ///
    /// - Nyja cungohet për të përmbajtur vetëm çiftet e vlerës kyçe në të majtë të kësaj doreze.
    /// - Çelësi dhe vlera që tregon kjo dorezë nxirren.
    /// - Të gjithë çiftet e vlerës kryesore në të djathtë të kësaj doreze vendosen në një nyje të sapo alokuar.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Heq çiftin e vlerës kyçe të treguar nga kjo dorezë dhe e kthen atë, së bashku me edge në të cilën çifti i vlerës kryesore u shemb.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Ndan nyjen themelore në tre pjesë:
    ///
    /// - Nyja cungohet për të përmbajtur vetëm skajet dhe çiftet e vlerës kyçe në të majtë të kësaj doreze.
    /// - Çelësi dhe vlera që tregon kjo dorezë nxirren.
    /// - Të gjitha skajet dhe çiftet e vlerës kyçe në të djathtë të kësaj doreze vendosen në një nyje të sapo alokuar.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Përfaqëson një sesion për vlerësimin dhe kryerjen e një operacioni balancues rreth një çifti të brendshëm të vlerës kryesore.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Zgjedh një kontekst balancues që përfshin nyjen si fëmijë, pra midis KV menjëherë në të majtë ose në të djathtë në nyjen prind.
    /// Kthen një `Err` nëse nuk ka prind.
    /// Panics nëse prindi është bosh.
    ///
    /// Preferon anën e majtë, për të qenë optimale nëse nyja e dhënë është disi e dobët, do të thotë këtu vetëm se ajo ka më pak elemente sesa vëllai ose motra e tij e majtë, nëse ato ekzistojnë.
    /// Në atë rast, bashkimi me vëllain ose motrën e majtë është më i shpejtë, pasi ne duhet vetëm të lëvizim elementët N të nyjes, në vend që t'i zhvendosim ato në të djathtë dhe të lëvizim më shumë se elementët N përpara.
    /// Vjedhja nga vëllai ose motra e majtë është gjithashtu tipikisht më e shpejtë, pasi duhet vetëm të zhvendosim elementët N të nyjes në të djathtë, në vend që të zhvendosim të paktën N të elementit të vëllait ose motrës në të majtë.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Kthen nëse bashkimi është i mundur, dmth., Nëse ka hapësirë të mjaftueshme në një nyje për të kombinuar KV qendrore me të dy nyjet fqinje të fëmijëve.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Kryen një bashkim dhe lejon një mbyllje të vendosë se çfarë do të kthejë.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SIGURIA: lartësia e nyjeve që bashkohen është një nën lartësinë
                // të nyjes së kësaj edge, pra mbi zero, kështu që ato janë të brendshme.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Bashkon çiftin e vlerës kryesore të prindit dhe të dy nyjet ngjitur të fëmijës në nyjën e majtë të fëmijës dhe kthen nyjen prind të zvogëluar.
    ///
    ///
    /// Panics nëse nuk `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Bashkon çiftin e vlerës kryesore të prindit dhe të dy nyjet ngjitur të fëmijës në nyjën e majtë të fëmijës dhe kthen atë nyje fëmije.
    ///
    ///
    /// Panics nëse nuk `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Bashkon çiftin e vlerës kryesore të prindit dhe të dy nyjet ngjitur të fëmijës në nyjën e majtë të fëmijës dhe kthen dorezën edge në atë nyje fëmije ku përfundoi fëmija i ndjekur edge,
    ///
    ///
    /// Panics nëse nuk `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Heq një çift me vlerë çelësi nga fëmija i majtë dhe e vendos atë në magazinën me vlerë çelës të prindit, ndërsa shtyn çiftin e vjetër me vlerë çelësin prind në fëmijën e duhur.
    ///
    /// Kthen një dorezë në edge në fëmijën e duhur që korrespondon me vendin ku përfundoi edge origjinal i specifikuar nga `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Heq një palë me vlerë çelësi nga fëmija i duhur dhe e vendos atë në magazinimin e vlerës kryesore për prindin, ndërsa shtyn çiftin e vjetër të vlerës së çelësit prind mbi fëmijën e majtë.
    ///
    /// Kthen një dorezë te edge te fëmija i majtë i specifikuar nga `track_left_edge_idx`, i cili nuk lëvizi.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Kjo bën vjedhje të ngjashme me `steal_left` por vjedh shumë elementë në të njëjtën kohë.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Sigurohuni që mund të vjedhim të sigurt.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Zhvendosni të dhënat e gjetheve.
            {
                // Bëni vend për elementet e vjedhura tek fëmija i duhur.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Lëvizni elementet nga fëmija i majtë në të djathtën.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Lëviz çiftin e majtë-më të vjedhur te prindi.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Zhvendos çiftin e vlerës kryesore të prindit tek fëmija i duhur.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Bëni vend për skajet e vjedhura.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Vidhni skajet.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Kloni simetrik i `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Sigurohuni që mund të vjedhim të sigurt.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Zhvendosni të dhënat e gjetheve.
            {
                // Lëviz çiftin më të djathtë të vjedhur te prindi.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Zhvendos çiftin e vlerës kryesore të prindit tek fëmija i majtë.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Lëvizni elementet nga fëmija i djathtë në atë të majtë.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Mbush boshllëkun aty ku kanë qenë elementet e vjedhura.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Vidhni skajet.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Mbush boshllëkun aty ku kanë qenë skajet e vjedhura.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Heq çdo informacion statik duke pohuar se kjo nyje është një nyje `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Heq çdo informacion statik duke pohuar se kjo nyje është një nyje `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Kontrollon nëse nyja themelore është një nyje `Internal` apo një nyje `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Zhvendosni prapashtesën pas `self` nga një nyje në një tjetër.`right` duhet të jetë bosh.
    /// edge i parë i `right` mbetet i pandryshuar.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Rezultati i futjes, kur një nyje duhet të zgjerohet përtej kapacitetit të saj.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nyja e ndryshuar në pemën ekzistuese me elemente dhe buzë që i përkasin majtas së `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Disa çelës dhe vlera ndahen, për tu futur diku tjetër.
    pub kv: (K, V),
    // Nyje e re, në pronësi, e palidhur, me elemente dhe skaje që i përkasin të djathtës së `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Nëse referencat e nyjeve të këtij lloji huazimi lejojnë kalimin në nyjet e tjera në pemë.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Kalimi nuk është i nevojshëm, kjo ndodh duke përdorur rezultatin e `borrow_mut`.
        // Duke çaktivizuar përshkimin, dhe vetëm duke krijuar referenca të reja për rrënjët, ne e dimë se çdo referencë e llojit `Owned` është në një nyje rrënjë.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Fut një vlerë në një pjesë të elementeve të iniciuar të ndjekur nga një element i pa inicializuar.
///
/// # Safety
/// Feta ka më shumë se elemente `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Heq dhe kthen një vlerë nga një fetë e të gjithë elementëve të iniciuar, duke lënë pas një element të pa inicializuar.
///
///
/// # Safety
/// Feta ka më shumë se elemente `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Zhvendos elementet në një fetë pozicionesh `distance` majtas.
///
/// # Safety
/// Feta ka të paktën elemente `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Zhvendos elementet në një fetë pozicionesh `distance` në të djathtë.
///
/// # Safety
/// Feta ka të paktën elemente `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Lëviz të gjitha vlerat nga një pjesë e elementeve të iniciuar në një pjesë e elementeve të pa inicializuar, duke lënë pas `src` si të gjithë të pa inicializuar.
///
/// Punon si `dst.copy_from_slice(src)` por nuk kërkon që `T` të jetë `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;