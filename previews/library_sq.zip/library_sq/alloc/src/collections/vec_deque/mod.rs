//! Një radhë me dy fund të zbatuar me një mbrojtës unazor të rritshëm.
//!
//! Kjo radhë ka *O*(1) futje dhe heqje të amortizuara nga të dy skajet e kontejnerit.
//! Ai gjithashtu ka indeksimin *O*(1) si një vector.
//! Elementet e përmbajtura nuk kërkohet të jenë të kopjueshme dhe radha do të dërgohet nëse lloji i përmbajtur është i dërgueshëm.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Fuqia më e madhe e mundshme e dy

/// Një radhë me dy fund të zbatuar me një mbrojtës unazor të rritshëm.
///
/// Përdorimi "default" i këtij lloji si radhë është përdorimi i [`push_back`] për të shtuar në radhë dhe [`pop_front`] për të hequr nga radhë.
///
/// [`extend`] dhe [`append`] shtyhen në pjesën e prapme në këtë mënyrë, dhe përsëritja mbi `VecDeque` shkon para mbrapa.
///
/// Meqenëse `VecDeque` është një amortizues unazor, elementet e tij nuk janë domosdoshmërisht të afërta në kujtesë.
/// Nëse dëshironi të përdorni elementet si një fetë të vetme, të tilla si për një renditje efikase, mund të përdorni [`make_contiguous`].
/// Ai rrotullon `VecDeque` në mënyrë që elementët e tij të mos mbështillen dhe kthen një fetë të ndryshueshme në sekuencën e elementeve tani fqinjë.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // bishti dhe koka janë tregues në tampon.
    // Bishti tregon gjithmonë tek elementi i parë që mund të lexohet, Head gjithmonë tregon se ku duhet të shkruhen të dhënat.
    //
    // Nëse bosh==koka, bufferi është bosh.Gjatësia e zhurmës së unazës përcaktohet si distanca midis të dyjave.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Drejton destruktorin për të gjitha sendet në fetë kur bie (normalisht ose gjatë zgjidhjes).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // përdorimi i rënies për [T]
            ptr::drop_in_place(front);
        }
        // RawVec merret me shpërndarjen
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Krijon një `VecDeque<T>` bosh.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Margjinalisht më i përshtatshëm
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Margjinalisht më i përshtatshëm
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Për llojet me madhësi zero, ne jemi gjithmonë në kapacitet maksimal
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Kthejeni ptr në një fetë
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Kthejeni ptr në një fetë mut
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Lëviz një element nga bufferi
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Shkruan një element në buffer, duke e lëvizur atë.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Kthen `true` nëse bufferi është me kapacitet të plotë.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Kthen indeksin në bufferin themelor për një indeks të dhënë të elementit logjik.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Kthen indeksin në bufferin themelor për një indeks të caktuar element logjik + shtojcë.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Kthen indeksin në bufferin themelor për një indeks të dhënë të elementit logjik, nëntragjen.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Kopjon një bllok të memorjes ngjitur gjatë nga src në dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kopjon një bllok të memorjes ngjitur gjatë nga src në dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kopjon një bllok potencialisht të mbështjelljes së kujtesës së gjatë nga src në dest.
    /// (abs(dst - src) + len) nuk duhet të jetë më i madh se cap() (Duhet të ketë më së shumti një rajon të vazhdueshëm të mbivendosur midis src dhe dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src nuk mbështillet, dst nuk mbështillet
                //
                //        S..
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst para src, src nuk mbështillet, dst përfundon
                //
                //
                //    S..
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src para dst, src nuk mbështillet, dst përfundon
                //
                //
                //              S..
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst para src, src përfundon, dst nuk mbështillet
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src para dst, src përfundon, dst nuk mbështillet
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst para src, src përfundon, dst përfundon
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src para dst, src përfundon, dst mbështjell
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs pjesën e kokës dhe bishtit përreth për të trajtuar faktin që ne vetëm rialokuar.
    /// E pasigurt sepse i beson kapacitetit të vjetër.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Lëviz pjesën më të shkurtër ngjitëse të tamponit të unazës TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo.....
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // Një Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Krijon një `VecDeque` bosh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Krijon një `VecDeque` bosh me hapësirë për të paktën elementet `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 pasi që butoni i ziles gjithmonë e lë një hapësirë bosh
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Jep një referencë për elementin në indeksin e dhënë.
    ///
    /// Elementi në indeksin 0 është pjesa e përparme e radhës.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Siguron një referencë të ndryshueshme për elementin në indeksin e dhënë.
    ///
    /// Elementi në indeksin 0 është pjesa e përparme e radhës.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Ndërron elementet në indekset `i` dhe `j`.
    ///
    /// `i` dhe `j` mund të jenë të barabartë.
    ///
    /// Elementi në indeksin 0 është pjesa e përparme e radhës.
    ///
    /// # Panics
    ///
    /// Panics nëse indeksi është jashtë kufijve.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Kthen numrin e elementeve që `VecDeque` mund të mbajë pa i rialokuar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Rezervon kapacitetin minimal për saktësisht `additional` më shumë elementë që do të futen në `VecDeque` të dhënë.
    /// Nuk bën asgjë nëse kapaciteti është tashmë i mjaftueshëm.
    ///
    /// Vini re se alokuesi mund t'i japë koleksionit më shumë hapësirë sesa kërkon.
    /// Prandaj, kapaciteti nuk mund të mbështetet për të qenë saktësisht minimal.
    /// Preferoni [`reserve`] nëse priten futje të future.
    ///
    /// # Panics
    ///
    /// Panics nëse kapaciteti i ri tejkalon `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Rezervon kapacitetin për të paktën `additional` më shumë elementë që do të futen në `VecDeque` të dhënë.
    /// Grumbullimi mund të rezervojë më shumë hapësirë për të shmangur rialokimet e shpeshta.
    ///
    /// # Panics
    ///
    /// Panics nëse kapaciteti i ri tejkalon `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Përpiqet të rezervojë kapacitetin minimal për saktësisht `additional` më shumë elementë që do të futen në `VecDeque<T>` të dhënë.
    ///
    /// Pasi të telefononi `try_reserve_exact`, kapaciteti do të jetë më i madh ose i barabartë me `self.len() + additional`.
    /// Nuk bën asgjë nëse kapaciteti është tashmë i mjaftueshëm.
    ///
    /// Vini re se alokuesi mund t'i japë koleksionit më shumë hapësirë sesa kërkon.
    /// Prandaj, kapaciteti nuk mund të mbështetet për të qenë saktësisht minimal.
    /// Preferoni `reserve` nëse priten futje të future.
    ///
    /// # Errors
    ///
    /// Nëse kapaciteti tejkalon `usize`, ose alokuesi raporton një dështim, atëherë një gabim kthehet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Rezervoni paraprakisht kujtesën, duke dalë nëse nuk mundemi
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Tani e dimë që kjo nuk mund të jetë OOM(Out-Of-Memory) në mes të punës sonë komplekse
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // shume e nderlikuar
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Mundohet të rezervojë kapacitetin për të paktën `additional` më shumë elementë që do të futen në `VecDeque<T>` të dhënë.
    /// Grumbullimi mund të rezervojë më shumë hapësirë për të shmangur rialokimet e shpeshta.
    /// Pas thirrjes `try_reserve`, kapaciteti do të jetë më i madh ose i barabartë me `self.len() + additional`.
    /// Nuk bën asgjë nëse kapaciteti është tashmë i mjaftueshëm.
    ///
    /// # Errors
    ///
    /// Nëse kapaciteti tejkalon `usize`, ose alokuesi raporton një dështim, atëherë një gabim kthehet.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Rezervoni paraprakisht kujtesën, duke dalë nëse nuk mundemi
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Tani e dimë që kjo nuk mund të OOM në mes të punës sonë komplekse
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // shume e nderlikuar
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Zvogëlon kapacitetin e `VecDeque` sa më shumë që të jetë e mundur.
    ///
    /// Do të bjerë sa më afër gjatësisë, por alokuesi përsëri mund të informojë `VecDeque` se ka hapësirë për disa elementë të tjerë.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Zvogëlon kapacitetin e `VecDeque` me një kufi më të ulët.
    ///
    /// Kapaciteti do të mbetet të paktën aq i madh sa gjatësia dhe vlera e furnizuar.
    ///
    ///
    /// Nëse kapaciteti aktual është më i vogël se kufiri i poshtëm, ky është një mos-opsion.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Ne nuk duhet të shqetësohemi për një mbingarkesë pasi as `self.len()` dhe as `self.capacity()` nuk mund të jenë kurrë `usize::MAX`.
        // +1 pasi zilja e ziles gjithmonë e lë një hapësirë bosh.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Ekzistojnë tre raste me interes:
            //   Të gjithë elementët nuk janë në kufijtë e dëshiruar Elementët janë pranë, dhe koka është jashtë kufijve të dëshiruar Elementet janë të paqëndrueshëm dhe bishti është jashtë kufijve të dëshiruar
            //
            //
            // Në çdo kohë tjetër, pozicionet e elementeve nuk preken.
            //
            // Tregon që elementët në kokë duhet të lëvizen.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Lëviz elementet nga kufijtë e dëshiruar (pozicionet pas kapakut të synuar)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Shkurton `VecDeque`, duke mbajtur elementët e parë `len` dhe duke lënë pjesën tjetër.
    ///
    ///
    /// Nëse `len` është më e madhe se gjatësia aktuale e "VecDeque", kjo nuk ka efekt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Drejton destruktorin për të gjitha sendet në fetë kur bie (normalisht ose gjatë zgjidhjes).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // I sigurt sepse:
        //
        // * Çdo fetë e kaluar në `drop_in_place` është e vlefshme;rasti i dytë ka `len <= front.len()` dhe kthimi në `len > self.len()` siguron `begin <= back.len()` në rastin e parë
        //
        // * Koka e VecDeque zhvendoset para se të telefononi `drop_in_place`, kështu që asnjë vlerë nuk bie dy herë nëse `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Sigurohuni që pjesa e dytë të bjerë edhe kur një shkatërrues në atë të parë panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Kthen një përsëritës para-mbrapa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Kthen një iterator para-mbrapa që kthen referenca të ndryshueshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SIGURIA: Pavarësia e brendshme e sigurisë `IterMut` është krijuar sepse
        // `ring` ne krijojmë është një fetë e paqartë për tërë jetën '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Kthen një palë feta të cilat përmbajnë, sipas radhës, përmbajtjen e `VecDeque`.
    ///
    /// Nëse më parë ishte thirrur [`make_contiguous`], të gjithë elementët e `VecDeque` do të jenë në fetë e parë dhe feta e dytë do të jetë bosh.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Kthen një palë feta të cilat përmbajnë, sipas radhës, përmbajtjen e `VecDeque`.
    ///
    /// Nëse më parë ishte thirrur [`make_contiguous`], të gjithë elementët e `VecDeque` do të jenë në fetë e parë dhe feta e dytë do të jetë bosh.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Kthen numrin e elementeve në `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Kthen `true` nëse `VecDeque` është bosh.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Krijon një iterator që mbulon diapazonin e specifikuar në `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics nëse pika e fillimit është më e madhe se pika e fundit ose nëse pika e fundit është më e madhe se gjatësia e vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Një gamë e plotë përfshin të gjitha përmbajtjet
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Referenca e përbashkët që kemi në &self ruhet në '_ të Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Krijon një iterator që mbulon diapazonin e specifikuar të ndryshueshëm në `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics nëse pika e fillimit është më e madhe se pika e fundit ose nëse pika e fundit është më e madhe se gjatësia e vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Një gamë e plotë përfshin të gjitha përmbajtjet
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SIGURIA: Pavarësia e brendshme e sigurisë `IterMut` është krijuar sepse
        // `ring` ne krijojmë është një fetë e paqartë për tërë jetën '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Krijon një iterator kullues që heq diapazonin e specifikuar në `VecDeque` dhe jep artikujt e hequr.
    ///
    /// Shënim 1: Diapazoni i elementeve hiqet edhe nëse përsëritësi nuk konsumohet deri në fund.
    ///
    /// Shënim 2: unshtë e paspecifikuar sa elementë hiqen nga deque, nëse vlera `Drain` nuk bie, por huazimi që mban skadon (p.sh., për shkak të `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics nëse pika e fillimit është më e madhe se pika e fundit ose nëse pika e fundit është më e madhe se gjatësia e vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Një gamë e plotë pastron të gjitha përmbajtjet
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Siguria e kujtesës
        //
        // Kur Drain krijohet për herë të parë, deque burimi shkurtohet për t'u siguruar që asnjë element i pa inicializuar ose i lëvizur nuk mund të arrihet fare nëse shkatërruesi i Drain nuk do të ekzekutohet kurrë.
        //
        //
        // Drain do ptr::read nga vlerat për të hequr.
        // Kur të keni mbaruar, të dhënat e mbetura do të kopjohen përsëri për të mbuluar vrimën dhe vlerat head/tail do të rikthehen në mënyrë korrekte.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Elementet e deque ndahen në tre segmente:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=brain_bisht;h=drain_head
        //
        // Ne e ruajmë drain_tail si self.head, dhe drain_head dhe self.head si after_tail dhe after_head përkatësisht në Drain.
        // Kjo gjithashtu shkurton grupin efektiv të tillë që nëse Drain rrjedh, ne kemi harruar vlerat e lëvizura potencialisht pas fillimit të drain.
        //
        //
        //        H th
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" në lidhje me vlerat pas fillimit të drain deri pasi drain të ketë përfunduar dhe shkatërruesi Drain të ekzekutohet.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Ç'është më e rëndësishmja, ne këtu krijojmë vetëm referenca të përbashkëta nga `self` dhe lexojmë prej tij.
                // Ne nuk i shkruajmë `self` dhe as nuk i drejtohemi një reference të ndryshueshme.
                // Prandaj, treguesi i papërpunuar që krijuam më lart, për `deque`, mbetet i vlefshëm.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Pastron `VecDeque`, duke hequr të gjitha vlerat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Kthen `true` nëse `VecDeque` përmban një element të barabartë me vlerën e dhënë.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Siguron një referencë në elementin e përparmë, ose `None` nëse `VecDeque` është bosh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Siguron një referencë të ndryshueshme për elementin e përparmë, ose `None` nëse `VecDeque` është bosh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Jep një referencë për elementin e pasmë, ose `None` nëse `VecDeque` është bosh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Siguron një referencë të ndryshueshme për elementin e pasmë, ose `None` nëse `VecDeque` është bosh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Heq elementin e parë dhe e kthen atë, ose `None` nëse `VecDeque` është bosh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Heq elementin e fundit nga `VecDeque` dhe e kthen atë, ose `None` nëse është bosh.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Kalon një element në `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Shton një element në pjesën e pasme të `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: A duhet ta konsiderojmë `head == 0` si kuptim
        // që `self` është i afërt?
        self.tail <= self.head
    }

    /// Heq një element nga kudo në `VecDeque` dhe e kthen atë, duke e zëvendësuar me elementin e parë.
    ///
    ///
    /// Kjo nuk e ruan renditjen, por është *O*(1).
    ///
    /// Kthen `None` nëse `index` është jashtë kufijve.
    ///
    /// Elementi në indeksin 0 është pjesa e përparme e radhës.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Heq një element nga kudo në `VecDeque` dhe e kthen atë, duke e zëvendësuar me elementin e fundit.
    ///
    ///
    /// Kjo nuk e ruan renditjen, por është *O*(1).
    ///
    /// Kthen `None` nëse `index` është jashtë kufijve.
    ///
    /// Elementi në indeksin 0 është pjesa e përparme e radhës.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Fut një element në `index` brenda `VecDeque`, duke zhvendosur të gjithë elementët me indekse më të mëdha ose të barabarta me `index` drejt pjesës së pasme.
    ///
    ///
    /// Elementi në indeksin 0 është pjesa e përparme e radhës.
    ///
    /// # Panics
    ///
    /// Panics nëse `index` është më e madhe se gjatësia e "VecDeque"
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Lëvizni numrin më të vogël të elementeve në buffer unazë dhe futni objektin e dhënë
        //
        // Më së shumti len/2, 1 element do të zhvendoset. O(min(n, n-i))
        //
        // Ekzistojnë tre raste kryesore:
        //  Elementet janë të afërta
        //      - rast i veçantë kur bishti është 0 Elementet janë të paqëndrueshëm dhe futja është në pjesën e bishtit Elementet janë të paqëndrueshme dhe inserti është në pjesën e kokës
        //
        //
        // Për secilin prej tyre ka edhe dy raste të tjera:
        //  Futja është më afër bishtit Vendosja është më afër kokës
        //
        // Çelësi: H, self.head
        //      T, self.tail o, Elementi i vlefshëm I, Elementi i futjes A, Elementi që duhet të jetë pas pikës së futjes M, Tregon elementin e zhvendosur
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [Një oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // ngjitur, futur më afër bishtit:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // ngjitur, futur më afër bishtit dhe bishti është 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Lëvizur tashmë bishtin, kështu që ne kopjojmë vetëm elementët `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ngjitur, futeni afër kokës:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // diskontingjent, futeni më afër bishtit, seksioni i bishtit:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // diskontingjent, futeni afër kokës, seksioni i bishtit:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kopjoni elementet deri në kokën e re
                    self.copy(1, 0, self.head);

                    // kopjoni elementin e fundit në vendin bosh në fund të tamponit
                    self.copy(0, self.cap() - 1, 1);

                    // lëviz elementet nga idx në fund përpara duke mos përfshirë elementin ^
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // i ndërprerë, futja është më afër bishtit, seksionit të kokës dhe është në indeksin zero në tamponin e brendshëm:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kopjoni elementet deri në bisht të ri
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopjoni elementin e fundit në vendin bosh në fund të tamponit
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // diskontingjent, futeni afër bishtit, pjesa e kokës:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // kopjoni elementet deri në bisht të ri
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // kopjoni elementin e fundit në vendin bosh në fund të tamponit
                    self.copy(self.cap() - 1, 0, 1);

                    // lëvizin elementet nga idx-1 për të përfunduar përpara duke mos përfshirë elementin ^
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // i paqëndrueshëm, futur afër kokës, pjesa e kokës:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // bishti mund të jetë ndryshuar kështu që duhet të rillogarisim
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Heq dhe kthen elementin në `index` nga `VecDeque`.
    /// Cilado fund të jetë më afër pikës së heqjes do të zhvendoset për të lënë vend, dhe të gjithë elementët e prekur do të zhvendosen në pozicione të reja.
    ///
    /// Kthen `None` nëse `index` është jashtë kufijve.
    ///
    /// Elementi në indeksin 0 është pjesa e përparme e radhës.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Ekzistojnë tre raste kryesore:
        //  Elementet janë të afërta Elementet janë të paqëndrueshëm dhe heqja është në pjesën e bishtit Elementet janë të paqëndrueshme dhe heqja është në pjesën e kokës
        //
        //      - rast i veçantë kur elementët janë teknikisht të afërt, por self.head =0
        //
        // Për secilin prej tyre ka edhe dy raste të tjera:
        //  Futja është më afër bishtit Vendosja është më afër kokës
        //
        // Çelësi: H, self.head
        //      T, self.tail o, Element i vlefshëm x, Elementi i shënuar për heqjen R, Tregon elementin që po hiqet M, Tregon se elementi u zhvendos
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // ngjitur, hiqni më afër bishtit:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ngjitur, hiqeni afër kokës:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // diskontigjene, hiqeni afër bishtit, seksioni i bishtit:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // disi ndërprerë, hiqeni afër kokës, pjesa e kokës:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // disi ndërprerë, hiqeni afër kokës, pjesa e bishtit:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // ose gjysmë i ndërprerë, hiqni pranë kokës, seksioni i bishtit:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // vizatoni elemente në pjesën e bishtit
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Parandalon nënshkrimin.
                    if self.head != 0 {
                        // kopjoni elementin e parë në vend të zbrazët
                        self.copy(self.cap() - 1, 0, 1);

                        // lëvizin elementet në pjesën e kokës prapa
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // diskontingjent, hiqeni afër bishtit, pjesa e kokës:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // vizatoni elemente deri në idx
                    self.copy(1, 0, idx);

                    // kopjoni elementin e fundit në një vend bosh
                    self.copy(0, self.cap() - 1, 1);

                    // lëvizni elementet nga bishti në fund përpara, duke përjashtuar atë të fundit
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Ndan `VecDeque` në dy në indeksin e dhënë.
    ///
    /// Kthen një `VecDeque` të sapo alokuar.
    /// `self` përmban elementet `[0, at)`, dhe `VecDeque` i kthyer përmban elementët `[at, len)`.
    ///
    /// Vini re se kapaciteti i `self` nuk ndryshon.
    ///
    /// Elementi në indeksin 0 është pjesa e përparme e radhës.
    ///
    /// # Panics
    ///
    /// Panics nëse `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` qëndron në gjysmën e parë.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // thjesht merrni të gjithë pjesën e dytë.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` qëndron në gjysmën e dytë, duhet të faktorizojmë elementet që kemi anashkaluar në pjesën e parë.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Pastrimi atje ku janë skajet e tamponëve
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Lëviz të gjithë elementët e `other` në `self`, duke e lënë `other` bosh.
    ///
    /// # Panics
    ///
    /// Panics nëse numri i ri i elementeve në vetvete tejmbush një `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // nënkuptim naiv
        self.extend(other.drain(..));
    }

    /// Mban vetëm elementet e specifikuara nga kallëzuesi.
    ///
    /// Me fjalë të tjera, hiqni të gjithë elementët `e` të tillë që `f(&e)` të kthehet false.
    /// Kjo metodë operon në vend, duke vizituar secilin element saktësisht një herë në rendin origjinal, dhe ruan rendin e elementeve të mbajtura.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Rendi i saktë mund të jetë i dobishëm për të ndjekur gjendjen e jashtme, si një indeks.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Kjo mund të panic ose të ndërpresë
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Dyfishoni madhësinë e tamponit.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Modifikon `VecDeque` në vend, në mënyrë që `len()` të jetë e barabartë me `new_len`, ose duke hequr elementët e tepërt nga mbrapa ose duke bashkuar elementët e gjeneruar duke thirrur `generator` në pjesën e pasme.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Riorganizon deponimin e brendshëm të këtij deque kështu që është një fetë ngjitur, e cila më pas kthehet.
    ///
    /// Kjo metodë nuk cakton dhe nuk ndryshon rendin e elementeve të futura.Ndërsa kthen një fetë të ndryshueshme, kjo mund të përdoret për të klasifikuar një deque.
    ///
    /// Sapo memorja e brendshme të jetë e afërt, metodat [`as_slices`] dhe [`as_mut_slices`] do të kthejnë të gjithë përmbajtjen e `VecDeque` në një fetë të vetme.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Renditja e përmbajtjes së një deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // klasifikimin e deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // duke e renditur në rend të kundërt
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Marrja e hyrjes së pandryshueshme në fetë ngjitur.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // tani mund të jemi të sigurt se `slice` përmban të gjithë elementët e deque, ndërsa akoma ka qasje të pandryshueshme në `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // ka mjaft hapësirë të lirë për të kopjuar bishtin me një lëvizje, kjo do të thotë që së pari ta zhvendosim kokën mbrapa, dhe pastaj ta kopjojmë bishtin në pozicionin e duhur.
            //
            //
            // nga: DEFGH .... ABC
            // te: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Ne aktualisht nuk e konsiderojmë .... ABCDEFGH
            // të jetë i afërt sepse `head` do të ishte `0` në këtë rast.
            // Ndërsa ne ndoshta duam ta ndryshojmë këtë nuk është e parëndësishme pasi disa vende presin që `is_contiguous` të thotë që ne thjesht mund të bëjmë copë duke përdorur `buf[tail..head]`.
            //
            //

            // ka mjaft hapësirë të lirë për të kopjuar kokën me një lëvizje, kjo do të thotë që së pari ta zhvendosim bishtin përpara, dhe pastaj ta kopjojmë kokën në pozicionin e duhur.
            //
            //
            // nga: FGH .... ABCDE
            // te: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // falas është më e vogël se koka dhe bishti, kjo do të thotë që ne duhet të ngadalë "swap" bishtin dhe kokën.
            //
            //
            // nga: EFGHI ... ABCD ose HIJK.ABCDEFG
            // te: ABCDEFGHI ... ose ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Problemi i përgjithshëm duket si ky GHIJKLM ... ABCDEF, para se të bëhet ndonjë ndërrim
                //                  - atëherë rindizni algoritmin me një dyqan të ri (smaller) Ndonjëherë depo temp arrihet kur edge e duhur është në fund të buffer-it, kjo do të thotë se kemi arritur rendin e duhur me më pak swap!
                //
                // E.g
                // EF..ABCD ABCDEF .., pas vetëm katër ndërrimeve që kemi mbaruar
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Rrotullon radhën me fund të dyfishtë `mid` vendet majtas.
    ///
    /// Equivalently,
    /// - Rrotullon artikullin `mid` në pozicionin e parë.
    /// - Kërkon artikujt e parë `mid` dhe i shtyn deri në fund.
    /// - Rrotullon vendet `len() - mid` në të djathtë.
    ///
    /// # Panics
    ///
    /// Nëse `mid` është më i madh se `len()`.
    /// Vini re se `mid == len()` bën _not_ panic dhe është një rotacion pa opsion.
    ///
    /// # Complexity
    ///
    /// Merr kohë `*O*(min(mid, len() - mid))` dhe nuk ka hapësirë shtesë.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Rrotullon radhët me fund të dyfishtë `k` në të djathtë.
    ///
    /// Equivalently,
    /// - Rrotullon artikullin e parë në pozicionin `k`.
    /// - Kërkon artikujt e fundit `k` dhe i shtyn përpara.
    /// - Rrotullon vendet `len() - k` majtas.
    ///
    /// # Panics
    ///
    /// Nëse `k` është më i madh se `len()`.
    /// Vini re se `k == len()` bën _not_ panic dhe është një rotacion pa opsion.
    ///
    /// # Complexity
    ///
    /// Merr kohë `*O*(min(k, len() - k))` dhe nuk ka hapësirë shtesë.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SIGURIA: dy metodat e mëposhtme kërkojnë që sasia e rrotullimit
    // të jetë më pak se gjysma e gjatësisë së deque.
    //
    // `wrap_copy` kërkon që `min(x, cap() - x) + copy_len <= cap()`, por `min` nuk është kurrë më shumë se gjysma e kapacitetit, pavarësisht nga x, kështu që është e shëndoshë të telefonosh këtu sepse ne po telefonojmë me diçka më pak se gjysma e gjatësisë, e cila kurrë nuk është mbi gjysmën e kapacitetit.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binar kërkon këtë `VecDeque` të renditur për një element të caktuar.
    ///
    /// Nëse vlera gjendet, atëherë [`Result::Ok`] kthehet, që përmban indeksin e elementit që përputhet.
    /// Nëse ka ndeshje të shumta, atëherë secila prej ndeshjeve mund të kthehet.
    /// Nëse vlera nuk gjendet, atëherë [`Result::Err`] kthehet, duke përmbajtur indeksin ku mund të futet një element përputhës duke ruajtur renditjen e renditur.
    ///
    ///
    /// # Examples
    ///
    /// Kërkon një seri prej katër elementësh.
    /// E para është gjetur, me një pozicion të përcaktuar në mënyrë unike;e dyta dhe e treta nuk gjenden;i katërti mund të përputhet me çdo pozicion në `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Nëse dëshironi të futni një artikull në një renditur `VecDeque`, duke ruajtur renditjen e renditjes:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binary kërkon këtë `VecDeque` të renditur me një funksion krahasues.
    ///
    /// Funksioni krahasues duhet të zbatojë një urdhër në përputhje me renditjen e renditjes së `VecDeque` themelor, duke kthyer një kod urdhri që tregon nëse argumenti i tij është `Less`, `Equal` ose `Greater` sesa synimi i dëshiruar.
    ///
    ///
    /// Nëse vlera gjendet, atëherë [`Result::Ok`] kthehet, që përmban indeksin e elementit që përputhet.Nëse ka ndeshje të shumta, atëherë secila prej ndeshjeve mund të kthehet.
    /// Nëse vlera nuk gjendet, atëherë [`Result::Err`] kthehet, duke përmbajtur indeksin ku mund të futet një element përputhës duke ruajtur renditjen e renditur.
    ///
    /// # Examples
    ///
    /// Kërkon një seri prej katër elementësh.E para është gjetur, me një pozicion të përcaktuar në mënyrë unike;e dyta dhe e treta nuk gjenden;i katërti mund të përputhet me çdo pozicion në `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binary kërkon këtë `VecDeque` të renditur me një funksion kyç të nxjerrjes.
    ///
    /// Supozon që `VecDeque` është renditur sipas çelësit, për shembull me [`make_contiguous().sort_by_key()`](#method.make_contiguous) duke përdorur të njëjtin funksion të nxjerrjes së çelësit.
    ///
    ///
    /// Nëse vlera gjendet, atëherë [`Result::Ok`] kthehet, që përmban indeksin e elementit që përputhet.
    /// Nëse ka ndeshje të shumta, atëherë secila prej ndeshjeve mund të kthehet.
    /// Nëse vlera nuk gjendet, atëherë [`Result::Err`] kthehet, duke përmbajtur indeksin ku mund të futet një element përputhës duke ruajtur renditjen e renditur.
    ///
    /// # Examples
    ///
    /// Kërkon një seri prej katër elementësh në një pjesë të çifteve të renditura sipas elementeve të tyre të dytë.
    /// E para është gjetur, me një pozicion të përcaktuar në mënyrë unike;e dyta dhe e treta nuk gjenden;i katërti mund të përputhet me çdo pozicion në `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Modifikon `VecDeque` në vend, në mënyrë që `len()` të jetë e barabartë me new_len, ose duke hequr elementët e tepërt nga mbrapa ose duke shtuar klone të `value` në pjesën e pasme.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Kthen indeksin në bufferin themelor për një indeks të dhënë të elementit logjik.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // madhësia është gjithmonë një fuqi prej 2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Llogaritni numrin e elementeve të mbetura për tu lexuar në tampon
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // madhësia është gjithmonë një fuqi prej 2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Gjithmonë i ndashëm në tre seksione, për shembull: vetë: [a b c|d e f] tjetër: [0 1 2 3|4 5] përpara=3, mes=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Nuk është e mundur të përdoret Hash::hash_slice në feta të kthyera nga metoda as_slices pasi gjatësia e tyre mund të ndryshojë në deqe ndryshe identike.
        //
        //
        // Hasher garanton vetëm barazvlefshmëri për grupin ekzaktësisht të njëjtë të thirrjeve në metodat e tij.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Konsumon `VecDeque` në një kthyes para-mbrapa duke dhënë elemente sipas vlerës.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Ky funksion duhet të jetë ekuivalenti moral i:
        //
        //      për artikullin në iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Kthejeni një [`Vec<T>`] në një [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Kjo shmang rialokimin kur është e mundur, por kushtet për këtë janë të rrepta dhe mund të ndryshojnë, dhe kështu nuk duhet të mbështetemi nëse `Vec<T>` nuk ka ardhur nga `From<VecDeque<T>>` dhe nuk është rialokuar.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Nuk ka asnjë alokim aktual për ZST-të që të shqetësohen për kapacitetin, por `VecDeque` nuk mund të trajtojë aq gjatësi sa `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Ne duhet të ndryshojmë madhësinë nëse kapaciteti nuk është një fuqi e dy, shumë e vogël ose nuk ka të paktën një hapësirë të lirë.
            // Ne e bëjmë këtë ndërsa është akoma në `Vec` kështu që artikujt do të bien në panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Kthejeni një [`VecDeque<T>`] në një [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Kjo kurrë nuk ka nevojë të rishpërndahet, por ka nevojë të bëjë lëvizjen e të dhënave *O*(*n*) nëse buffer-i rrethor nuk ndodh të jetë në fillim të alokimit.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Ky është *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Kjo kërkon rirregullimin e të dhënave.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}