//! Një radhë prioritare e zbatuar me një grumbull binar.
//!
//! Futja dhe shfaqja e elementit më të madh kanë kompleksitetin kohor *O*(log(*n*)).
//! Kontrollimi i elementit më të madh është *O*(1).Konvertimi i një vector në një grumbull binar mund të bëhet në vend, dhe ka kompleksitet *O*(*n*).
//! Një grumbull binar mund të shndërrohet gjithashtu në një vector të renditur në vend, duke e lejuar atë të përdoret për një grup të mbledhjes *O*(*n*\*log(* n*)) në vend.
//!
//! # Examples
//!
//! Ky është një shembull më i madh që zbaton [Dijkstra's algorithm][dijkstra] për të zgjidhur [shortest path problem][sssp] në një [directed graph][dir_graph].
//!
//! Ajo tregon se si të përdoret [`BinaryHeap`] me lloje të personalizuara.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Radha e përparësisë varet nga `Ord`.
//! // Zbatoni në mënyrë të qartë trait në mënyrë që radha të bëhet një grumbull min në vend të një grumbulli maksimal.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Vini re se ne bëjmë porosinë mbi kostot.
//!         // Në rast të barazimit, ne krahasojmë pozicionet, ky hap është i nevojshëm për t'i bërë zbatimet `PartialEq` dhe `Ord` të qëndrueshme.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` duhet të implementohet gjithashtu.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Çdo nyje përfaqësohet si një `usize`, për një zbatim më të shkurtër.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // Algoritmi i rrugës më të shkurtër të Dijkstra.
//!
//! // Filloni nga `start` dhe përdorni `dist` për të ndjekur distancën më të shkurtër aktuale në secilën nyje.Ky implementim nuk është efikas në memorje pasi mund të lërë nyje kopjuese në radhë.
//! //
//! // Ai gjithashtu përdor `usize::MAX` si një vlerë roje, për një zbatim më të thjeshtë.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [nyja]=distanca më e shkurtër aktuale nga `start` në `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Ne jemi në `start`, me një kosto zero
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Kontrolloni kufirin me nyje me kosto më të ulët (min-heap) së pari
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Përndryshe do të mund të kishim vazhduar të gjenim të gjitha rrugët më të shkurtra
//!         if position == goal { return Some(cost); }
//!
//!         // E rëndësishme pasi që mund ta kemi gjetur tashmë një mënyrë më të mirë
//!         if cost > dist[position] { continue; }
//!
//!         // Për secilën nyje që mund të arrijmë, shikoni nëse mund të gjejmë një mënyrë me një kosto më të ulët duke kaluar nëpër këtë nyje
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Nëse është kështu, shtoni atë në kufi dhe vazhdoni
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Relaksimi, tani kemi gjetur një mënyrë më të mirë
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Qëllimi nuk është i arritshëm
//!     None
//! }
//!
//! fn main() {
//!     // Ky është grafiku i drejtuar që do të përdorim.
//!     // Numrat e nyjeve korrespondojnë me gjendje të ndryshme, dhe peshat edge simbolizojnë koston e lëvizjes nga një nyje në tjetrën.
//!     //
//!     // Vini re se skajet janë njëkahëshe.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Grafiku përfaqësohet si një listë e afërsisë ku secili indeks, që i përgjigjet një vlere nyje, ka një listë të skajeve dalëse.
//!     // E zgjedhur për efikasitetin e saj.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nyja 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Nyja 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Nyja 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Nyja 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nyja 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Një radhë prioritare e zbatuar me një grumbull binar.
///
/// Kjo do të jetë një grumbull maksimal.
///
/// Isshtë një gabim logjik që një artikull të modifikohet në mënyrë të tillë që renditja e artikullit në krahasim me çdo artikull tjetër, siç përcaktohet nga `Ord` trait, të ndryshojë ndërsa është në grumbull.
///
/// Kjo normalisht është e mundur vetëm përmes `Cell`, `RefCell`, gjendjes globale, I/O ose kodit të pasigurt.
/// Sjellja që rezulton nga një gabim i tillë logjik nuk është specifikuar, por nuk do të rezultojë në sjellje të papërcaktuar.
/// Kjo mund të përfshijë panics, rezultate të pasakta, aborte, rrjedhje të kujtesës dhe mosfundim.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // Përfundimi i tipit na lejon të heqim dorë nga një nënshkrim i qartë i tipit (i cili do të ishte `BinaryHeap<i32>` në këtë shembull).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Ne mund të përdorim vështrimin për të parë artikullin tjetër në tog.
/// // Në këtë rast, ende nuk ka artikuj atje, kështu që ne nuk marrim asnjë.
/// assert_eq!(heap.peek(), None);
///
/// // Le të shtojmë disa rezultate ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Tani përgjimi tregon artikullin më të rëndësishëm në tog.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Ne mund të kontrollojmë gjatësinë e një grumbulli.
/// assert_eq!(heap.len(), 3);
///
/// // Ne mund të përsërisim mbi artikujt në grumbull, megjithëse ato kthehen në një renditje të rastësishme.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Nëse në vend të kësaj i hapim këto rezultate, ato duhet të kthehen në rregull.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Ne mund të pastrojmë grumbullin e çdo sendi të mbetur.
/// heap.clear();
///
/// // Grumbulli tani duhet të jetë bosh.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Ose `std::cmp::Reverse` ose një zbatim me porosi `Ord` mund të përdoret për ta bërë `BinaryHeap` një grumbull minutash.
/// Kjo bën që `heap.pop()` të kthejë vlerën më të vogël në vend të vlerës më të madhe.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Mbështillni vlerat në `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Nëse i nxjerrim këto rezultate tani, ato duhet të kthehen në rendin e kundërt.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Kompleksiteti i kohës
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Vlera për `push` është një kosto e pritshme;dokumentacioni i metodës jep një analizë më të hollësishme.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Struktura duke mbështetur një referencë të ndryshueshme për artikullin më të madh në një `BinaryHeap`.
///
///
/// Ky `struct` është krijuar nga metoda [`peek_mut`] në [`BinaryHeap`].
/// Shihni dokumentacionin e tij për më shumë.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SIGURIA: PeekMut paraqitet vetëm për grumbuj jo të zbrazët.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SIGURT Pe: PeekMut është krijuar vetëm për grumbuj jo të zbrazët
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SIGURT Pe: PeekMut është krijuar vetëm për grumbuj jo të zbrazët
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Heq vlerën e shikuar nga grumbulli dhe e kthen atë.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Krijon një `BinaryHeap<T>` bosh.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Krijon një `BinaryHeap` të zbrazët si një grumbull maksimal.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Krijon një `BinaryHeap` bosh me një kapacitet specifik.
    /// Kjo para-alokon kujtesë të mjaftueshme për elementet `capacity`, në mënyrë që `BinaryHeap` të mos duhet të rialokohet derisa të përmbajë të paktën kaq shumë vlera.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Kthen një referencë të ndryshueshme në artikullin më të madh në grumbullin binar, ose `None` nëse është bosh.
    ///
    /// Note: Nëse vlera `PeekMut` rrjedh, grumbulli mund të jetë në një gjendje jo konsistente.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Kompleksiteti i kohës
    ///
    /// Nëse artikulli modifikohet, atëherë kompleksiteti i kohës më të keqe është *O*(log(*n*)), përndryshe është *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Heq artikullin më të madh nga grumbulli binar dhe e kthen atë, ose `None` nëse është bosh.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Kompleksiteti i kohës
    ///
    /// Kostoja më e keqe e `pop` në një grumbull që përmban *n* elemente është *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SIGURIA: !self.is_empty() do të thotë që self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Shtyn një send në tog binare.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Kompleksiteti i kohës
    ///
    /// Kostoja e pritur e `push`, mesatarisht mbi çdo renditje të mundshme të elementeve që shtyhen, dhe mbi një numër mjaft të madh shtytjesh, është *O*(1).
    ///
    /// Kjo është metrika më domethënëse e kostos kur shtyhen elementet që *nuk janë* tashmë në ndonjë model të renditur.
    ///
    /// Kompleksiteti i kohës degradon nëse elementët shtyhen në rendin kryesisht rritës.
    /// Në rastin më të keq, elementët shtyhen në renditje ngjitëse të renditura dhe kostoja e amortizuar për shtytje është *O*(log(*n*)) kundrejt një grumbulli që përmban elemente *n*.
    ///
    /// Kostoja më e keqe e një thirrjeje *të vetme* në `push` është *O*(*n*).Rasti më i keq ndodh kur kapaciteti është izauruar dhe ka nevojë për një ndryshim të madhësisë.
    /// Kostoja e ndryshimit të madhësisë është amortizuar në figurat e mëparshme.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SIGURIA: Meqenëse kemi shtyrë një artikull të ri, kjo do të thotë se
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Konsumon `BinaryHeap` dhe kthen një vector sipas renditjes (ascending).
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SIGURIA: `end` kalon nga `self.len() - 1` në 1 (përfshirë të dy),
            //  kështu që është gjithmonë një indeks i vlefshëm për të hyrë.
            //  Safeshtë e sigurt për të hyrë në indeksin 0 (dmth. `ptr`), sepse
            //  1 <=fundi <self.len(), që do të thotë self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SIGURIA: `end` kalon nga `self.len() - 1` në 1 (të përfshira të dy) kështu që:
            //  0 <1 <=fund <= self.len(), 1 <self.len() Që do të thotë 0 <fund dhe fund <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Implementimet e sift_up dhe sift_down përdorin blloqe të pasigurta në mënyrë që të lëvizin një element nga vector (duke lënë pas një vrimë), të zhvendosen përgjatë të tjerëve dhe të lëvizin elementin e hequr përsëri në vector në vendin përfundimtar të vrimës.
    //
    // Lloji `Hole` përdoret për të përfaqësuar këtë, dhe sigurohuni që vrima të mbushet përsëri në fund të fushës së saj, madje edhe në panic.
    // Përdorimi i një vrime zvogëlon faktorin konstant krahasuar me përdorimin e swap-eve, që përfshin lëvizje dy herë më shumë.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Telefonuesi duhet të garantojë që `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Nxirrni vlerën në `pos` dhe krijoni një vrimë.
        // SIGURIA: Thirrësi garanton pozicionin <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SIGURIA: hole.pos()> start>=0, që do të thotë hole.pos()> 0
            //  dhe kështu hole.pos(), 1 nuk mund të derdhet.
            //  Kjo garanton që prindi <hole.pos() kështu që është një indeks i vlefshëm dhe gjithashtu!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SIGURIA: Njësoj si më sipër
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Merrni një element në `pos` dhe lëvizeni poshtë në grumbull, ndërsa fëmijët e tij janë më të mëdhenj.
    ///
    ///
    /// # Safety
    ///
    /// Telefonuesi duhet të garantojë që `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SIGURIA: Thirrësi garanton që pos <fund <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Lak i pandryshueshëm: fëmija==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // krahasoni me SIGURIN më të madhe të dy fëmijëve: fëmijë <fund, 1 <self.len() dhe fëmijë + 1 <fund <= self.len(), kështu që ata janë indekse të vlefshme.
            //
            //  fëmijë==2 *hole.pos() + 1!= hole.pos() dhe fëmijë + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 ose 2* hole.pos() + 2 mund të mbipopullohet nëse T është një ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // nëse jemi tashmë në rregull, ndalo.
            // SIGURIA: fëmija tani është ose fëmija i vjetër ose fëmija i vjetër + 1
            //  Ne tashmë kemi provuar që të dy janë <self.len() dhe!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SIGURIA: njësoj si më sipër.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SIGURIA: &&qark i shkurtër, që do të thotë se në
        //  kushti i dytë tashmë është e vërtetë që fëmija==fund, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SIGURIA: fëmija tashmë është provuar të jetë një indeks i vlefshëm dhe
            //  fëmijë==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Telefonuesi duhet të garantojë që `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SIGURIA: pos <len garantohet nga thirrësi dhe
        //  padyshim len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Merrni një element në `pos` dhe zhvendoseni deri në grumbull, pastaj shoshiteni në pozicionin e tij.
    ///
    ///
    /// Note: Kjo është më e shpejtë kur dihet se elementi është i madh/duhet të jetë më afër fundit.
    ///
    /// # Safety
    ///
    /// Telefonuesi duhet të garantojë që `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SIGURIA: Thirrësi garanton pozicionin <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Lak i pandryshueshëm: fëmija==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SIGURIA: fëmija <fund, 1 <self.len() dhe
            //  fëmijë + 1 <fund <= self.len(), kështu që ato janë indekse të vlefshme.
            //  fëmijë==2 *hole.pos() + 1!= hole.pos() dhe fëmijë + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 ose 2* hole.pos() + 2 mund të mbipopullohet nëse T është një ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SIGURIA: Njësoj si më sipër
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SIGURIA: fëmija==fundi, 1 <self.len(), pra është një indeks i vlefshëm
            //  dhe fëmija==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SIGURIA: poz është pozicioni në vrimë dhe është provuar tashmë
        //  të jetë një indeks i vlefshëm.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SIGURIA: n fillon nga self.len()/2 dhe zbret në 0.
            //  Rasti i vetëm kur! (N <self.len()) është nëse self.len() ==0, por përjashtohet nga kushti i lakut.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Lëviz të gjithë elementët e `other` në `self`, duke e lënë `other` bosh.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` merr operacione O(len1 + len2) dhe krahasime rreth 2 *(len1 + len2) në rastin më të keq ndërsa `extend` merr operacione O(len2* log(len1)) dhe rreth 1 *len2* log_2(len1) krahasime në rastin më të keq, duke supozuar len1>= len2.
        // Për grumbuj më të mëdhenj, pika e kryqëzimit nuk ndjek më këtë arsyetim dhe u përcaktua në mënyrë empirike.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Kthen një iterator i cili rimerr elementet në rendin e grumbullit.
    /// Elementet e marra hiqen nga grumbulli origjinal.
    /// Elementet e mbetura do të hiqen në rënie në rendin e grumbullit.
    ///
    /// Note:
    /// * `.drain_sorted()` është *O*(*n*\*log(* n*)); shumë më ngadalë se `.drain()`.
    ///   Këtë të fundit duhet ta përdorni për shumicën e rasteve.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // heq të gjithë elementët në rendin e grumbullit
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Mban vetëm elementet e specifikuara nga kallëzuesi.
    ///
    /// Me fjalë të tjera, hiqni të gjithë elementët `e` të tillë që `f(&e)` të kthejë `false`.
    /// Elementet vizitohen në një renditje të pa renditur (dhe të paspecifikuar).
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // vetëm mbaj numra çift
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Kthen një përsëritës që viziton të gjitha vlerat në vector, në renditje arbitrare.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Shtypni 1, 2, 3, 4 në mënyrë arbitrare
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Kthen një iterator i cili rimerr elementet në rendin e grumbullit.
    /// Kjo metodë konsumon grumbullin origjinal.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Kthen artikullin më të madh në grumbullin binar, ose `None` nëse është bosh.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Kompleksiteti i kohës
    ///
    /// Kostoja është *O*(1) në rastin më të keq.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Kthen numrin e elementeve që grumbulli binar mund të mbajë pa i rialokuar.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Rezervon kapacitetin minimal për saktësisht `additional` më shumë elementë që do të futen në `BinaryHeap` të dhënë.
    /// Nuk bën asgjë nëse kapaciteti është tashmë i mjaftueshëm.
    ///
    /// Vini re se alokuesi mund t'i japë koleksionit më shumë hapësirë sesa kërkon.
    /// Prandaj, kapaciteti nuk mund të mbështetet për të qenë saktësisht minimal.
    /// Preferoni [`reserve`] nëse priten futje të future.
    ///
    /// # Panics
    ///
    /// Panics nëse kapaciteti i ri tejkalon `usize`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Rezervon kapacitetin për të paktën `additional` më shumë elementë që do të futen në `BinaryHeap`.
    /// Grumbullimi mund të rezervojë më shumë hapësirë për të shmangur rialokimet e shpeshta.
    ///
    /// # Panics
    ///
    /// Panics nëse kapaciteti i ri tejkalon `usize`.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Hedh sa më shumë kapacitet shtesë.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Hedh kapacitetin me një kufi më të ulët.
    ///
    /// Kapaciteti do të mbetet të paktën aq i madh sa gjatësia dhe vlera e furnizuar.
    ///
    ///
    /// Nëse kapaciteti aktual është më i vogël se kufiri i poshtëm, ky është një mos-opsion.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Konsumon `BinaryHeap` dhe kthen vector themelor në një mënyrë arbitrare.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Do të shtypet në një mënyrë
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Kthen gjatësinë e grumbullit binar.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Kontrollon nëse grumbulli binar është bosh.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Pastron grumbullin binar, duke kthyer një iterator mbi elementët e hequr.
    ///
    /// Elementet hiqen në mënyrë arbitrare.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// I hedh të gjitha sendet nga grumbulli binar.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Vrima përfaqëson një vrimë në një fetë, dmth., Një indeks pa vlerë të vlefshme (sepse është zhvendosur nga ose kopjuar).
///
/// Në rënie, `Hole` do të rivendosë fetë duke mbushur pozicionin e vrimës me vlerën që u hoq fillimisht.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Krijoni një `Hole` të ri në indeksin `pos`.
    ///
    /// E pasigurt sepse pos duhet të jetë brenda pjesës së të dhënave.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pos duhet të jetë brenda fetë
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Kthen një referencë në elementin e hequr.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Kthen një referencë në elementin në `index`.
    ///
    /// I pasigurt sepse indeksi duhet të jetë brenda pjesës së të dhënave dhe jo i barabartë me poz.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Zhvendos vrimën në vendndodhje të re
    ///
    /// I pasigurt sepse indeksi duhet të jetë brenda pjesës së të dhënave dhe jo i barabartë me poz.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // mbushni vrimën përsëri
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Një iterator mbi elementet e një `BinaryHeap`.
///
/// Ky `struct` është krijuar nga [`BinaryHeap::iter()`].
/// Shihni dokumentacionin e tij për më shumë.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Hiqeni në favor të `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Një iterator zotërues mbi elementet e një `BinaryHeap`.
///
/// Ky `struct` është krijuar nga [`BinaryHeap::into_iter()`] (siguruar nga `IntoIterator` trait).
/// Shihni dokumentacionin e tij për më shumë.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Një iterator kullues mbi elementët e një `BinaryHeap`.
///
/// Ky `struct` është krijuar nga [`BinaryHeap::drain()`].
/// Shihni dokumentacionin e tij për më shumë.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Një iterator kullues mbi elementët e një `BinaryHeap`.
///
/// Ky `struct` është krijuar nga [`BinaryHeap::drain_sorted()`].
/// Shihni dokumentacionin e tij për më shumë.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Heq elementet e grumbullit në rendin e grumbullit.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Shndërron një `Vec<T>` në një `BinaryHeap<T>`.
    ///
    /// Ky konvertim ndodh në vend, dhe ka *O*(*n*) kompleksitet kohor.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Shndërron një `BinaryHeap<T>` në një `Vec<T>`.
    ///
    /// Ky konvertim nuk kërkon lëvizje ose alokim të të dhënave, dhe ka kompleksitet të vazhdueshëm kohor.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Krijon një përsëritës konsumues, domethënë, një që lëviz secilën vlerë nga grumbulli binar në një mënyrë arbitrare.
    /// Grumbulli binar nuk mund të përdoret pasi e thirrni këtë.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Shtypni 1, 2, 3, 4 në mënyrë arbitrare
    /// for x in heap.into_iter() {
    ///     // x ka llojin i32, jo &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}