//! Feta të vargut Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Lloji `&str` është një nga dy llojet kryesore të vargut, tjetri është `String`.
//! Ndryshe nga homologu i tij `String`, përmbajtja e tij është huazuar.
//!
//! # Përdorimi themelor
//!
//! Një deklaratë themelore e vargut e tipit `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Këtu kemi shpallur një varg fjalë për fjalë, i njohur gjithashtu si një fetë vargu.
//! Literaturat e vargut kanë një jetë statike, që do të thotë se vargu `hello_world` është i garantuar të jetë i vlefshëm për kohëzgjatjen e të gjithë programit.
//!
//! Ne mund të specifikojmë në mënyrë të qartë edhe jetën e `hello_world`:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Shumë prej përdorimeve në këtë modul përdoren vetëm në konfigurimin e provës.
// Ershtë më e pastër që thjesht të çaktivizoni paralajmërimin e papërdorur_import sesa t'i rregulloni ato.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` në `Concat<str>` nuk ka kuptim këtu.
/// Ky parametër tip i trait ekziston vetëm për të mundësuar një impl tjetër.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // sythe me madhësi të koduara të ngurtësuara funksionojnë shumë më shpejt specializojnë rastet me gjatësi të vogla ndarëse
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // kthim arbitrar i madhësisë jo zero
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Zbatimi i optimizuar i bashkimit që funksionon për të dy Vec<T>(T: Kopjo) dhe vesi i brendshëm i String Aktualisht (2018-05-13) ekziston një defekt me tipin e konkluzionit dhe specializimit (shih numrin #36262) Për këtë arsye SliceConcat<T>nuk është e specializuar për T: Copy dhe SliceConcat<str>është përdoruesi i vetëm i këtij funksioni.
// Lihet në vend për kohën kur rregullohet.
//
// kufijtë për String-join janë S: Huazo<str>dhe për Vec-join Borrow <[T]> [T] dhe str të dy nënkuptojnë AsRef <[T]> për disa T
// => s.borrow().as_ref() dhe ne gjithmonë kemi feta
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // feta e parë është e vetmja pa një ndarës që i paraprin asaj
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // llogarit gjatësinë e saktë totale të Vec-it të bashkuar nëse llogaritja `len` tejkalohet, ne do të panic do të na mbaronte kujtesa gjithsesi dhe pjesa tjetër e funksionit kërkon të gjithë Vec të para-alokuar për sigurinë
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // përgatitni një buffer të pa inicializuar
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // ndarës kopjimi dhe feta kontrolle pa kufij gjenerojnë sythe me ndërprerje të koduar për ndarës të vegjël përmirësime masive të mundshme (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Një zbatim i çuditshëm i huazimit mund të kthejë feta të ndryshme për llogaritjen e gjatësisë dhe kopjen aktuale.
        //
        // Sigurohuni që ne të mos i ekspozojmë bajtët e pa inicializuar në telefonues.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Metodat për fetat e telit.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Shndërron një `Box<str>` në një `Box<[u8]>` pa kopjuar ose alokuar.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Zëvendëson të gjitha përputhjet e një modeli me një varg tjetër.
    ///
    /// `replace` krijon një [`String`] të ri dhe kopjon të dhënat nga kjo pjesë e vargut në të.
    /// Ndërsa e bën këtë, ajo përpiqet të gjejë përputhjet e një modeli.
    /// Nëse gjen ndonjë, i zëvendëson ato me fetë vargu zëvendësues.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Kur modeli nuk përputhet:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Zëvendëson N ndeshjet e para të një modeli me një varg tjetër.
    ///
    /// `replacen` krijon një [`String`] të ri dhe kopjon të dhënat nga kjo pjesë e vargut në të.
    /// Ndërsa e bën këtë, ajo përpiqet të gjejë përputhjet e një modeli.
    /// Nëse gjen ndonjë, i zëvendëson ato me fetë vargu zëvendësuese më së shumti `count` herë.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Kur modeli nuk përputhet:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Shpresoj të zvogëloj kohën e rialokimit
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Kthen ekuivalentin e shkronjave të vogla të kësaj fete vargu, si një [`String`] të ri.
    ///
    /// 'Lowercase' përcaktohet në përputhje me kushtet e Unicode Derived Core Property `Lowercase`.
    ///
    /// Meqenëse disa karaktere mund të zgjerohen në shumë karaktere kur ndryshojnë kutinë, ky funksion kthen një [`String`] në vend që të modifikojë parametrin në vend.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Një shembull i ndërlikuar, me sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // por në fund të një fjale, është ς, jo σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Gjuhët pa shkronja nuk ndryshohen:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ harton në σ, përveç në fund të një fjale ku harton në ς.
                // Ky është i vetmi hartëzim i kushtëzuar (contextual) por i pavarur nga gjuha në `SpecialCasing.txt`, kështu që kodojeni më shumë se sa të keni një mekanizëm gjenerik "condition".
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // për përkufizimin e `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Kthen ekuivalentin e madh të kësaj flete vargu, si një [`String`] të ri.
    ///
    /// 'Uppercase' përcaktohet në përputhje me kushtet e Unicode Derived Core Property `Uppercase`.
    ///
    /// Meqenëse disa karaktere mund të zgjerohen në shumë karaktere kur ndryshojnë kutinë, ky funksion kthen një [`String`] në vend që të modifikojë parametrin në vend.
    ///
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Shkrimet pa shkronja nuk ndryshohen:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Një karakter mund të bëhet i shumëfishtë:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Shndërron një [`Box<str>`] në një [`String`] pa kopjuar ose alokuar.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Krijon një [`String`] të ri duke përsëritur një varg `n` herë.
    ///
    /// # Panics
    ///
    /// Ky funksion do të panic nëse kapaciteti do të tejmbushur.
    ///
    /// # Examples
    ///
    /// Përdorimi bazë:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// Një panic me tejmbushje:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Kthen një kopje të kësaj vargu ku secili karakter është i shënuar në ekuivalentin e tij të sipërm ASCII.
    ///
    ///
    /// Shkronjat ASCII 'a' në 'z' janë të shënuara në 'A' në 'Z', por shkronjat jo ASCII janë të pandryshuara.
    ///
    /// Për të shkruar më të madhe vlerën në vend, përdorni [`make_ascii_uppercase`].
    ///
    /// Për karaktere të mëdha ASCII përveç karaktereve jo-ASCII, përdorni [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() ruan pandryshuar UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Kthen një kopje të kësaj vargu ku secili karakter është i shënuar në ekuivalentin e tij të vogël ASCII.
    ///
    ///
    /// Shkronjat ASCII 'A' në 'Z' janë të shënuara në 'a' në 'z', por shkronjat jo-ASCII janë të pandryshuara.
    ///
    /// Për të zvogëluar vlerën në vend, përdorni [`make_ascii_lowercase`].
    ///
    /// Për të përdorur shkronjat e vogla ASCII përveç karaktereve jo-ASCII, përdorni [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() ruan pandryshuar UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Konverton një fetë me bajte të kutuar në një fetë vargu të kutuar pa kontrolluar që vargu përmban UTF-8 të vlefshëm.
///
///
/// # Examples
///
/// Përdorimi bazë:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}