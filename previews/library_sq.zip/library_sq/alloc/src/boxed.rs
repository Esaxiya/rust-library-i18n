//! Një lloj treguesi për caktimin e grumbullit.
//!
//! [`Box<T>`], i referuar rastësisht si 'box', ofron formën më të thjeshtë të shpërndarjes së grumbullit në Rust.Kutitë sigurojnë pronësinë për këtë alokim dhe hedhin përmbajtjen e tyre kur ato dalin nga fusha e qëllimit.Kutitë gjithashtu sigurojnë që ato të mos ndajnë kurrë më shumë se `isize::MAX` bajte.
//!
//! # Examples
//!
//! Lëvizni një vlerë nga pirgu në grumbull duke krijuar një [`Box`]:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Lëvizni një vlerë nga një [`Box`] përsëri në pirg me [dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Krijimi i një strukture rekursive të të dhënave:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! Kjo do të shtypë `Cons (1, Cons(2, Nil))`.
//!
//! Strukturat rekursive duhet të futen në kuti, sepse nëse përkufizimi i `Cons` do të dukej kështu:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! Nuk do të funksiononte.Kjo është për shkak se madhësia e një `List` varet nga sa elementë janë në listë, dhe kështu që ne nuk e dimë se sa memorje duhet të alokojmë për një `Cons`.Duke prezantuar një [`Box<T>`], i cili ka një madhësi të përcaktuar, ne e dimë se sa i madh duhet të jetë `Cons`.
//!
//! # Paraqitja e kujtesës
//!
//! Për vlera me madhësi jo zero, një [`Box`] do të përdorë shpërndarësin [`Global`] për alokimin e tij.Validshtë e vlefshme të shndërrohen të dy mënyrat midis një [`Box`] dhe një treguesi të papërcaktuar të alokuar me alokuesin [`Global`], duke pasur parasysh që [`Layout`] i përdorur me alokuesin është i saktë për llojin.
//!
//! Më saktësisht, një `value:*mut T` që është alokuar me alokuesin [`Global`] me `Layout::for_value(&* value)` mund të shndërrohet në një kuti duke përdorur [`Box::<T>::from_raw(value)`].
//! Në të kundërt, kujtesa që mbështet një `value:*mut T` të marrë nga [`Box::<T>::into_raw`] mund të zhvendoset duke përdorur alokuesin [`Global`] me [`Layout::for_value(&* value)`].
//!
//! Për vlera me përmasa zero, treguesi `Box` duhet të jetë [valid] për lexime dhe shkrime dhe të rreshtohet mjaftueshëm.
//! Në veçanti, hedhja e ndonjë numri të plotë të drejtuar jo-zero drejtpërdrejt në një tregues të papërpunuar prodhon një tregues të vlefshëm, por një tregues që tregon kujtesën e alokuar më parë, që kur u lirua nuk është i vlefshëm.
//! Mënyra e rekomanduar për të ndërtuar një Kuti në një ZST nëse `Box::new` nuk mund të përdoret është përdorimi i [`ptr::NonNull::dangling`].
//!
//! Për sa kohë që `T: Sized`, një `Box<T>` është e garantuar të përfaqësohet si një tregues i vetëm dhe është gjithashtu i pajtueshëm me ABI me treguesit C (dmth., Tipi C `T*`).
//! Kjo do të thotë që nëse keni funksione të jashtme "C" Rust që do të thirren nga C, ju mund të përcaktoni ato funksione Rust duke përdorur lloje `Box<T>` dhe të përdorni `T*` si tip përkatës në anën C.
//! Si shembull, merrni parasysh këtë kokë C e cila deklaron funksionet që krijojnë dhe shkatërrojnë një lloj vlere `Foo`:
//!
//! ```c
//! /* Header C */
//!
//! /* Kthen pronësinë te thirrësi */
//! struct Foo* foo_new(void);
//!
//! /* Merr pronësinë nga thirrësi;no-op kur thirret me NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! Këto dy funksione mund të implementohen në Rust si më poshtë.Këtu, lloji `struct Foo*` nga C përkthehet në `Box<Foo>`, i cili kap kufizimet e pronësisë.
//! Vini re gjithashtu se argumenti i pavlefshëm për `foo_delete` përfaqësohet në Rust si `Option<Box<Foo>>`, pasi që `Box<Foo>` nuk mund të jetë nul.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Edhe pse `Box<T>` ka të njëjtën përfaqësim dhe C ABI si një tregues C, kjo nuk do të thotë që ju mund të shndërroni një `T*` arbitrar në një `Box<T>` dhe të prisni që gjërat të funksionojnë.
//! `Box<T>` vlerat gjithmonë do të jenë në linjë plotësisht, tregues jo-null.Për më tepër, shkatërruesi për `Box<T>` do të përpiqet të lirojë vlerën me shpërndarësin global.Në përgjithësi, praktika më e mirë është përdorimi i `Box<T>` vetëm për treguesit që kanë origjinën nga alokuesi global.
//!
//! **E rëndësishme.** Të paktën aktualisht, duhet të shmangni përdorimin e llojeve `Box<T>` për funksionet që janë përcaktuar në C, por të thirrura nga Rust.Në ato raste, ju duhet të pasqyroni direkt llojet C sa më afër që të jetë e mundur.
//! Përdorimi i llojeve si `Box<T>` ku përkufizimi C thjesht përdor `T*` mund të çojë në sjellje të papërcaktuar, siç përshkruhet në [rust-lang/unsafe-code-guidelines#198][ucg#198].
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// Një lloj treguesi për caktimin e grumbullit.
///
/// Shihni [module-level documentation](../../std/boxed/index.html) për më shumë.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// Alokon kujtesën në grumbull dhe më pas vendos `x` në të.
    ///
    /// Kjo nuk shpërndan nëse `T` është me madhësi zero.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// Ndërton një kuti të re me përmbajtje të pa iniciale.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// Ndërton një `Box` të ri me përmbajtje të pa iniciale, me kujtesën e mbushur me `0` bajte.
    ///
    ///
    /// Shihni [`MaybeUninit::zeroed`][zeroed] për shembuj të përdorimit korrekt dhe jo korrekt të kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Ndërton një `Pin<Box<T>>` të ri.
    /// Nëse `T` nuk zbaton `Unpin`, atëherë `x` do të vendoset në memorie dhe nuk mund të zhvendoset.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// Alokon kujtesën në grumbull pastaj vendos `x` në të, duke kthyer një gabim nëse alokimi dështon
    ///
    ///
    /// Kjo nuk shpërndan nëse `T` është me madhësi zero.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Ndërton një kuti të re me përmbajtje të pa iniciale në grumbull, duke kthyer një gabim nëse alokimi dështon
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Ndërton një `Box` të ri me përmbajtje të pa iniciale, me kujtesën e mbushur me `0` bajte në grumbull
    ///
    ///
    /// Shihni [`MaybeUninit::zeroed`][zeroed] për shembuj të përdorimit korrekt dhe jo korrekt të kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Alokon kujtesën në alokuesin e dhënë pastaj vendos `x` në të.
    ///
    /// Kjo nuk shpërndan nëse `T` është me madhësi zero.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// Alokon kujtesën në shpërndarësin e dhënë, pastaj vendos `x` në të, duke kthyer një gabim nëse alokimi dështon
    ///
    ///
    /// Kjo nuk shpërndan nëse `T` është me madhësi zero.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// Ndërton një kuti të re me përmbajtje të pa iniciale në shpërndarësin e dhënë.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Preferoni ndeshjen sesa unwrap_or_else pasi mbyllja ndonjëherë nuk është e patjetërsueshme.
        // Kjo do ta bënte madhësinë e kodit më të madhe.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Ndërton një kuti të re me përmbajtje të pa iniciale në shpërndarësin e dhënë, duke kthyer një gabim nëse alokimi dështon
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Ndërton një `Box` të ri me përmbajtje të pa iniciale, me kujtesën që mbushet me `0` bajte në alokuesin e dhënë.
    ///
    ///
    /// Shihni [`MaybeUninit::zeroed`][zeroed] për shembuj të përdorimit korrekt dhe jo korrekt të kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Preferoni ndeshjen sesa unwrap_or_else pasi mbyllja ndonjëherë nuk është e patjetërsueshme.
        // Kjo do ta bënte madhësinë e kodit më të madhe.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Ndërton një `Box` të ri me përmbajtje të pa iniciale, me kujtesën që mbushet me `0` bajte në alokuesin e dhënë, duke kthyer një gabim nëse alokimi dështon,
    ///
    ///
    /// Shihni [`MaybeUninit::zeroed`][zeroed] për shembuj të përdorimit korrekt dhe jo korrekt të kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Ndërton një `Pin<Box<T, A>>` të ri.
    /// Nëse `T` nuk zbaton `Unpin`, atëherë `x` do të vendoset në memorie dhe nuk mund të zhvendoset.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// Shndërron një `Box<T>` në një `Box<[T]>`
    ///
    /// Ky shndërrim nuk caktohet në grumbull dhe ndodh në vend.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Konsumon `Box`, duke kthyer vlerën e mbështjellur.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// Ndërton një fetë të re në kuti me përmbajtje të pa iniciale.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Ndërton një fetë të re në kuti me përmbajtje të pa iniciale, me kujtesën e mbushur me `0` bajte.
    ///
    ///
    /// Shihni [`MaybeUninit::zeroed`][zeroed] për shembuj të përdorimit korrekt dhe jo korrekt të kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Ndërton një fetë të re në kuti me përmbajtje të pa iniciale në shpërndarësin e dhënë.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Ndërton një fetë të re në kuti me përmbajtje të pa iniciale në alokuesin e dhënë, me kujtesën e mbushur me `0` bajte.
    ///
    ///
    /// Shihni [`MaybeUninit::zeroed`][zeroed] për shembuj të përdorimit korrekt dhe jo korrekt të kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Konvertohet në `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// Ashtu si me [`MaybeUninit::assume_init`], i takon thirrësit të garantojë se vlera është me të vërtetë në një gjendje të iniciuar.
    ///
    /// Thirrja e kësaj kur përmbajtja ende nuk është iniciuar plotësisht shkakton sjellje të menjëhershme të papërcaktuar.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Konvertohet në `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// Ashtu si me [`MaybeUninit::assume_init`], i takon thirrësit të garantojë që vlerat me të vërtetë janë në një gjendje të iniciuar.
    ///
    /// Thirrja e kësaj kur përmbajtja ende nuk është iniciuar plotësisht shkakton sjellje të menjëhershme të papërcaktuar.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Ndërton një kuti nga një tregues i papërpunuar.
    ///
    /// Pas thirrjes së këtij funksioni, treguesi i papërpunuar zotërohet nga `Box` që rezulton.
    /// Në mënyrë të veçantë, shkatërruesi `Box` do të thërrasë destruktorin e `T` dhe do të lirojë memorien e caktuar.
    /// Që kjo të jetë e sigurt, kujtesa duhet të jetë caktuar në përputhje me [memory layout] të përdorur nga `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Ky funksion është i pasigurt sepse përdorimi i pahijshëm mund të çojë në probleme të kujtesës.
    /// Për shembull, një dyfishtë mund të ndodhë nëse funksioni thirret dy herë në të njëjtin tregues të papërpunuar.
    ///
    /// Kushtet e sigurisë përshkruhen në seksionin [memory layout].
    ///
    /// # Examples
    ///
    /// Rikrijoni një `Box` i cili më parë ishte konvertuar në një tregues të papërpunuar duke përdorur [`Box::into_raw`]:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Krijoni manualisht një `Box` nga e para duke përdorur shpërndarësin global:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // Në përgjithësi .write kërkohet të shmangë përpjekjen për të shkatërruar përmbajtjen e mëparshme (uninitialized) të `ptr`, megjithëse për këtë shembull të thjeshtë `*ptr = 5` do të kishte funksionuar gjithashtu.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Ndërton një kuti nga një tregues i papërpunuar në alokuesin e dhënë.
    ///
    /// Pas thirrjes së këtij funksioni, treguesi i papërpunuar zotërohet nga `Box` që rezulton.
    /// Në mënyrë të veçantë, shkatërruesi `Box` do të thërrasë destruktorin e `T` dhe do të lirojë memorien e caktuar.
    /// Që kjo të jetë e sigurt, kujtesa duhet të jetë caktuar në përputhje me [memory layout] të përdorur nga `Box`.
    ///
    ///
    /// # Safety
    ///
    /// Ky funksion është i pasigurt sepse përdorimi i pahijshëm mund të çojë në probleme të kujtesës.
    /// Për shembull, një dyfishtë mund të ndodhë nëse funksioni thirret dy herë në të njëjtin tregues të papërpunuar.
    ///
    /// # Examples
    ///
    /// Rikrijoni një `Box` i cili më parë ishte konvertuar në një tregues të papërpunuar duke përdorur [`Box::into_raw_with_allocator`]:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Krijoni manualisht një `Box` nga e para duke përdorur alokuesin e sistemit:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // Në përgjithësi .write kërkohet të shmangë përpjekjen për të shkatërruar përmbajtjen e mëparshme (uninitialized) të `ptr`, megjithëse për këtë shembull të thjeshtë `*ptr = 5` do të kishte funksionuar gjithashtu.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// Konsumon `Box`, duke kthyer një tregues të papërpunuar të mbështjellë.
    ///
    /// Treguesi do të rreshtohet si duhet dhe jo nul.
    ///
    /// Pas thirrjes së këtij funksioni, telefonuesi është përgjegjës për kujtesën e administruar më parë nga `Box`.
    /// Në veçanti, telefonuesi duhet të shkatërrojë siç duhet `T` dhe të lirojë memorien, duke marrë parasysh [memory layout] të përdorur nga `Box`.
    /// Mënyra më e lehtë për ta bërë këtë është kthimi i treguesit të papërpunuar përsëri në një `Box` me funksionin [`Box::from_raw`], duke lejuar shkatërruesin `Box` të kryejë pastrimin.
    ///
    ///
    /// Note: ky është një funksion i shoqëruar, që do të thotë që ju duhet ta quani atë si `Box::into_raw(b)` në vend të `b.into_raw()`.
    /// Kjo është në mënyrë që të mos ketë konflikt me një metodë për llojin e brendshëm.
    ///
    /// # Examples
    /// Shndërrimi i treguesit të papërpunuar përsëri në një `Box` me [`Box::from_raw`] për pastrim automatik:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// Pastrimi manual duke drejtuar në mënyrë të qartë shkatërruesin dhe duke e shpërndarë kujtesën:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// Konsumon `Box`, duke kthyer një tregues të papërpunuar të mbështjellë dhe shpërndarësin.
    ///
    /// Treguesi do të rreshtohet si duhet dhe jo nul.
    ///
    /// Pas thirrjes së këtij funksioni, telefonuesi është përgjegjës për kujtesën e administruar më parë nga `Box`.
    /// Në veçanti, telefonuesi duhet të shkatërrojë siç duhet `T` dhe të lirojë memorien, duke marrë parasysh [memory layout] të përdorur nga `Box`.
    /// Mënyra më e lehtë për ta bërë këtë është kthimi i treguesit të papërpunuar përsëri në një `Box` me funksionin [`Box::from_raw_in`], duke lejuar shkatërruesin `Box` të kryejë pastrimin.
    ///
    ///
    /// Note: ky është një funksion i shoqëruar, që do të thotë që ju duhet ta quani atë si `Box::into_raw_with_allocator(b)` në vend të `b.into_raw_with_allocator()`.
    /// Kjo është në mënyrë që të mos ketë konflikt me një metodë për llojin e brendshëm.
    ///
    /// # Examples
    /// Shndërrimi i treguesit të papërpunuar përsëri në një `Box` me [`Box::from_raw_in`] për pastrim automatik:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// Pastrimi manual duke drejtuar në mënyrë të qartë shkatërruesin dhe duke e shpërndarë kujtesën:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Kutia njihet si "unique pointer" nga Stacked Borrows, por brenda saj është një tregues i papërpunuar për sistemin e tipit.
        // Kthimi i tij drejtpërdrejt në një tregues të papërpunuar nuk do të njihet si "releasing" treguesi unik për të lejuar hyrjet aliaside të para, kështu që të gjitha metodat e treguesit të papërpunuar duhet të kalojnë nëpër `Box::leak`.
        //
        // Duke e kthyer *atë* në një tregues të papërpunuar sillet si duhet.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// Kthen një referencë te alokuesi themelor.
    ///
    /// Note: ky është një funksion i shoqëruar, që do të thotë që ju duhet ta quani atë si `Box::allocator(&b)` në vend të `b.allocator()`.
    /// Kjo është në mënyrë që të mos ketë konflikt me një metodë për llojin e brendshëm.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Konsumon dhe rrjedh `Box`, duke kthyer një referencë të ndryshueshme, `&'a mut T`.
    /// Vini re se lloji `T` duhet të jetojë më gjatë gjatë jetës së zgjedhur `'a`.
    /// Nëse lloji ka vetëm referenca statike, ose aspak, atëherë kjo mund të zgjidhet të jetë `'static`.
    ///
    /// Ky funksion është kryesisht i dobishëm për të dhënat që jetojnë për pjesën e mbetur të jetës së programit.
    /// Hedhja e referencës së kthyer do të shkaktojë rrjedhje të kujtesës.
    /// Nëse kjo nuk është e pranueshme, referenca duhet së pari të mbështillet me funksionin [`Box::from_raw`] duke prodhuar një `Box`.
    ///
    /// Ky `Box` mund të lëshohet, i cili do të shkatërrojë siç duhet `T` dhe do të lëshojë kujtesën e caktuar.
    ///
    /// Note: ky është një funksion i shoqëruar, që do të thotë që ju duhet ta quani atë si `Box::leak(b)` në vend të `b.leak()`.
    /// Kjo është në mënyrë që të mos ketë konflikt me një metodë për llojin e brendshëm.
    ///
    /// # Examples
    ///
    /// Përdorimi i thjeshtë:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// Të dhëna pa madhësi:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// Shndërron një `Box<T>` në një `Pin<Box<T>>`
    ///
    /// Ky shndërrim nuk caktohet në grumbull dhe ndodh në vend.
    ///
    /// Kjo është gjithashtu e disponueshme përmes [`From`].
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // Nuk është e mundur të zhvendosni ose zëvendësoni pjesët e brendshme të një `Pin<Box<T>>` kur `T: !Unpin`, kështu që është e sigurt ta vendosni atë drejtpërdrejt pa ndonjë kërkesë shtesë.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: Mos bëj asgjë, rënia aktualisht kryhet nga përpiluesi.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Krijon një `Box<T>`, me vlerën `Default` për T.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Kthen një kuti të re me një përmbajtje `clone()` të kësaj kutie.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // Vlera është e njëjtë
    /// assert_eq!(x, y);
    ///
    /// // Por ato janë objekte unike
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Alokoni paraprakisht kujtesën për të lejuar shkrimin e vlerës së klonuar drejtpërdrejt.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// Kopjon përmbajtjen e `burimit` në `self` pa krijuar një alokim të ri.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // Vlera është e njëjtë
    /// assert_eq!(x, y);
    ///
    /// // Dhe asnjë alokim nuk ndodhi
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // kjo bën një kopje të të dhënave
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// Konverton një tip gjenerik `T` në `Box<T>`
    ///
    /// Konvertimi alokohet në grumbull dhe lëviz `t` nga pirgu në të.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// Shndërron një `Box<T>` në një `Pin<Box<T>>`
    ///
    /// Ky shndërrim nuk caktohet në grumbull dhe ndodh në vend.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// Shndërron një `&[T]` në një `Box<[T]>`
    ///
    /// Ky shndërrim cakton në grumbull dhe kryen një kopje të `slice`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // krijoni një&[u8] i cili do të përdoret për të krijuar një Kuti <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// Shndërron një `&str` në një `Box<str>`
    ///
    /// Ky shndërrim cakton në grumbull dhe kryen një kopje të `s`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// Shndërron një `Box<str>` në një `Box<[u8]>`
    /// Ky shndërrim nuk caktohet në grumbull dhe ndodh në vend.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // krijoni një Kuti<str>e cila do të përdoret për të krijuar një Kuti <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // krijoni një&[u8] i cili do të përdoret për të krijuar një Kuti <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// Shndërron një `[T; N]` në një `Box<[T]>`
    /// Ky konvertim e zhvendos koleksionin në memorjen e alokuar rishtazi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Përpjekje për të zbritur kutinë në një lloj betoni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// Përpjekje për të zbritur kutinë në një lloj betoni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// Përpjekje për të zbritur kutinë në një lloj betoni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Nuk është e mundur të nxirret Uniqi i brendshëm direkt nga Kutia, përkundrazi, ne e hedhim atë në një konstatim * i cili quhet Unique
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// Specializimi për `s me madhësi që përdor` `implementimin e `last()` në vend të paracaktuar.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}