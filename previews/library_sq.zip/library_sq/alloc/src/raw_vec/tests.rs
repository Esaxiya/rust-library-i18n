use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Shkrimi i një testi integrimi midis alokuesve të palëve të treta dhe `RawVec` është pak i ndërlikuar sepse `RawVec` API nuk ekspozon metodat e ndarjes së gabueshme, kështu që nuk mund të kontrollojmë se çfarë ndodh kur shpërndarësi shteron (përtej zbulimit të një panic).
    //
    //
    // Në vend të kësaj, kjo thjesht kontrollon që metodat `RawVec` të paktën kalojnë nëpër Allocator API kur rezervon hapësirën e ruajtjes.
    //
    //
    //
    //
    //

    // Një shpërndarës memec që konsumon një sasi fikse të karburantit para se përpjekjet e alokimit të fillojnë të dështojnë.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (shkakton një rialok, duke përdorur 50 + 150=200 njësi të karburantit)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Së pari, `reserve` alokon si `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 është më shumë se dyfishi i 7, kështu që `reserve` duhet të funksionojë si `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 është më pak se gjysma e 12, kështu që `reserve` duhet të rritet në mënyrë eksponenciale.
        // Në kohën e shkrimit, ky faktor i rritjes së testit është 2, kështu që kapaciteti i ri është 24, megjithatë, faktori i rritjes së 1.5 është gjithashtu në rregull.
        //
        // Prandaj `>= 18` në pohim.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}