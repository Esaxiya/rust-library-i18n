#![stable(feature = "rust1", since = "1.0.0")]

//! Treguesit e numërimit të referencës të sigurt për fillin.
//!
//! Shihni dokumentacionin [`Arc<T>`][Arc] për më shumë detaje.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Një kufi i butë për sasinë e referencave që mund t'i bëhen një `Arc`.
///
/// Kalimi mbi këtë kufi do ta ndërpresë programin tuaj (megjithëse jo domosdoshmërisht) në referencat _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer nuk mbështet gardhet e kujtesës.
// Për të shmangur raporte të rreme pozitive në zbatimin Arc/dobët përdorni ngarkesa atomike për sinkronizim në vend.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Një tregues i numërimit të referencës pa fije.'Arc' qëndron për 'Atomically Reference Counted'.
///
/// Lloji `Arc<T>` siguron pronësinë e përbashkët të një vlere të tipit `T`, të alokuar në grumbull.Duke thirrur [`clone`][clone] në `Arc` prodhon një shembull të ri `Arc`, i cili tregon për të njëjtën shpërndarje në grumbull si burimi `Arc`, ndërsa rrit një numër referimi.
/// Kur shkatërrohet treguesi i fundit `Arc` për një shpërndarje të caktuar, vlera e ruajtur në atë alokim (shpesh referohet si "inner value") gjithashtu hidhet.
///
/// Referencat e ndara në Rust nuk lejojnë mutacionin si parazgjedhje dhe `Arc` nuk bën përjashtim: zakonisht nuk mund të merrni një referencë të ndryshueshme për diçka brenda një `Arc`.Nëse keni nevojë të mutoni përmes një `Arc`, përdorni [`Mutex`][mutex], [`RwLock`][rwlock] ose një nga llojet [`Atomic`][atomic].
///
/// ## Siguria e Thread
///
/// Ndryshe nga [`Rc<T>`], `Arc<T>` përdor veprime atomike për numërimin e referencës.Kjo do të thotë që është i sigurt për fijet.Disavantazhi është se operacionet atomike janë më të shtrenjta sesa akseset e zakonshme të kujtesës.Nëse nuk po ndani alokime të numëruara nga referencat midis fijeve, merrni parasysh përdorimin e [`Rc<T>`] për shpenzimet e përgjithshme të sipërme.
/// [`Rc<T>`] është një parazgjedhje e sigurt, sepse përpiluesi do të kapë çdo përpjekje për të dërguar një [`Rc<T>`] midis fijeve.
/// Sidoqoftë, një bibliotekë mund të zgjedhë `Arc<T>` në mënyrë që t'u japë konsumatorëve të bibliotekës më shumë fleksibilitet.
///
/// `Arc<T>` do të implementojë [`Send`] dhe [`Sync`] për sa kohë që `T` zbaton [`Send`] dhe [`Sync`].
/// Pse nuk mund të vendosni një tip `T` pa fije në një `Arc<T>` për ta bërë atë të sigurt për fije?Kjo mund të jetë pak kundër-intuitive në fillim: në fund të fundit, a nuk është pika e fijes `Arc<T>` siguri?Kryesorja është kjo: `Arc<T>` e bën të sigurt fillimin e zotërimit të shumëfishtë të të njëjtave të dhëna, por nuk shton sigurinë e fijeve në të dhënat e saj.
///
/// Merrni në konsideratë `Arc <" ["RefCell<T>`]">".
/// [`RefCell<T>`] nuk është [`Sync`], dhe nëse `Arc<T>` ishte gjithmonë [`Send`], `Arc <" ["RefCell<T>"]"> do të ishte gjithashtu.
/// Por atëherë do të kishim një problem:
/// [`RefCell<T>`] nuk është i sigurt në fije;ai mban gjurmët e numërimit të huazimeve duke përdorur operacione jo-atomike.
///
/// Në fund të fundit, kjo do të thotë që ju mund të keni nevojë të çiftoni `Arc<T>` me një lloj të llojit [`std::sync`], zakonisht [`Mutex<T>`][mutex].
///
/// ## Ciklet e prishjes me `Weak`
///
/// Metoda [`downgrade`][downgrade] mund të përdoret për të krijuar një tregues [`Weak`] jo-pronar.Një tregues [`Weak`] mund të [[upgrade]][upgrade] d në një `Arc`, por kjo do të kthejë [`None`] nëse vlera e ruajtur në alokim është rënë tashmë.
/// Me fjalë të tjera, treguesit `Weak` nuk e mbajnë gjallë vlerën brenda alokimit;megjithatë, ata * e mbajnë gjallë ndarjen (rezervën mbështetëse për vlerën).
///
/// Një cikël midis treguesve `Arc` nuk do të shpërndahet kurrë.
/// Për këtë arsye, [`Weak`] përdoret për të prishur ciklet.Për shembull, një pemë mund të ketë tregues të fortë `Arc` nga nyjet prindërore tek fëmijët, dhe treguesit [`Weak`] nga fëmijët përsëri te prindërit e tyre.
///
/// # Referencat e klonimit
///
/// Krijimi i një referencë të re nga një tregues ekzistues i numëruar i referencave bëhet duke përdorur `Clone` trait të zbatuar për [`Arc<T>`][Arc] dhe [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Të dy sintaksat më poshtë janë ekuivalente.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b dhe foo janë të gjithë Harka që tregojnë për të njëjtin vend të kujtesës
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automatikisht deferencat për `T` (përmes [`Deref`][deref] trait), kështu që ju mund të telefononi metodat e `T` në një vlerë të tipit `Arc<T>`.Për të shmangur përplasjet e emrave me metodat e `T`, metodat e vetë `Arc<T>` janë funksione të shoqëruara, të quajtura duke përdorur [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Harku<T>Implementimet e traits si `Clone` gjithashtu mund të thirren duke përdorur sintaksë plotësisht të kualifikuar.
/// Disa njerëz preferojnë të përdorin sintaksë plotësisht të kualifikuar, ndërsa të tjerët preferojnë të përdorin sintaksë metodë-thirrje.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintaksa e thirrjes metodë
/// let arc2 = arc.clone();
/// // Sintaksa e kualifikuar plotësisht
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] nuk bën ri-referencë automatike te `T`, sepse vlera e brendshme mund të jetë rënë tashmë.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Ndarja e të dhënave të pandryshueshme midis fijeve:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Vini re se ne ** nuk i ekzekutojmë këto teste këtu.
// Ndërtuesit windows bëhen shumë të pakënaqur nëse një fije e mbijeton fillin kryesor dhe më pas del në të njëjtën kohë (bllokime të diçkaje) kështu që ne thjesht e shmangim këtë plotësisht duke mos ekzekutuar këto teste.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Ndarja e një [`AtomicUsize`] të paqëndrueshme:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Shihni [`rc` documentation][rc_examples] për më shumë shembuj të numërimit të referencave në përgjithësi.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` është një version i [`Arc`] që mban një referencë jo-pronare ndaj alokimit të menaxhuar.
/// Alokimi arrihet duke thirrur [`upgrade`] në treguesin `Weak`, i cili kthen një ["Opsion"] "<" ["Arc"] "<T>>".
///
/// Meqenëse një referencë `Weak` nuk llogaritet në pronësi, ajo nuk do të parandalojë që vlera e ruajtur në alokim të bjerë, dhe vetë `Weak` nuk bën asnjë garanci për vlerën që është akoma e pranishme.
///
/// Kështu që mund të kthejë [`None`] kur ["azhurnimi"] d.
/// Megjithatë, vini re se një referencë `Weak` * nuk lejon që alokimi vetë (dyqani mbështetës) të shperndahet.
///
/// Një tregues `Weak` është i dobishëm për të mbajtur një referencë të përkohshme në shpërndarjen e menaxhuar nga [`Arc`] pa parandaluar rënien e vlerës së tij të brendshme.
/// Përdoret gjithashtu për të parandaluar referencat rrethore midis treguesve [`Arc`], meqenëse referencat e zotërimit të ndërsjellë nuk do të lejonin asnjëherë të hidhet [`Arc`].
/// Për shembull, një pemë mund të ketë tregues të fortë [`Arc`] nga nyjet prindërore tek fëmijët, dhe treguesit `Weak` nga fëmijët përsëri te prindërit e tyre.
///
/// Mënyra tipike për të marrë një tregues `Weak` është të telefononi [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Ky është një `NonNull` për të lejuar optimizimin e madhësisë së këtij lloji në enum, por nuk është domosdoshmërisht një tregues i vlefshëm.
    //
    // `Weak::new` e vendos këtë në `usize::MAX` në mënyrë që të mos ketë nevojë të caktojë hapësirë në grumbull.
    // Kjo nuk është një vlerë që një tregues i vërtetë do të ketë ndonjëherë sepse RcBox ka rreshtim të paktën 2.
    // Kjo është e mundur vetëm kur `T: Sized`;`T` pa madhësi kurrë nuk var.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Kjo është e papërshtatshme nga repr(C) në future kundër rregullimit të mundshëm të fushës, gjë që do të ndërhynte me [into|from]_raw() ndryshe të sigurt të llojeve të brendshme të ndryshueshme.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // vlera usize::MAX vepron si një rojtar për përkohësisht "locking" aftësinë për të azhurnuar treguesit e dobët ose për të ulur gradën ato të forta;kjo përdoret për të shmangur garat në `make_mut` dhe `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Ndërton një `Arc<T>` të ri.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Filloni numërimin e dobët të treguesit si 1, i cili është treguesi i dobët që mbahet nga të gjithë treguesit e fortë (kinda), shih std/rc.rs për më shumë informacion
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Ndërton një `Arc<T>` të ri duke përdorur një referencë të dobët ndaj vetvetes.
    /// Përpjekja për të azhurnuar referencën e dobët para se ky funksion të kthehet do të rezultojë në një vlerë `None`.
    /// Sidoqoftë, referenca e dobët mund të klonohet lirshëm dhe të ruhet për përdorim në një kohë të mëvonshme.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Ndërtoni pjesën e brendshme në gjendjen "uninitialized" me një referencë të vetme të dobët.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Importantshtë e rëndësishme që ne të mos heqim dorë nga pronësia e treguesit të dobët, përndryshe kujtesa mund të lirohet deri në kohën kur `data_fn` kthehet.
        // Nëse me të vërtetë do të donim të kalonim pronësinë, mund të krijonim një tregues shtesë të dobët për veten tonë, por kjo do të rezultojë në azhurnime shtesë të numërimit të dobët të referencës, i cili mund të mos ishte i nevojshëm ndryshe.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Tani ne mund ta iniciojmë siç duhet vlerën e brendshme dhe ta kthejmë referencën tonë të dobët në një referencë të fortë.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Shkrimet e mësipërme në fushën e të dhënave duhet të jenë të dukshme për çdo fije që vëzhgon një numër të fortë jo-zero.
            // Prandaj na duhet të paktën renditja "Release" në mënyrë që të sinkronizohemi me `compare_exchange_weak` në `Weak::upgrade`.
            //
            // "Acquire" porosia nuk është e nevojshme.
            // Kur shqyrtojmë sjelljet e mundshme të `data_fn`, duhet vetëm të shohim se çfarë mund të bëjë duke iu referuar një `Weak` të pa-azhurnueshëm:
            //
            // - Mund të *klonojë*`Weak`, duke rritur numrin e dobët të referencës.
            // - Mund të bjerë ato klone, duke ulur numrin e dobët të referencës (por asnjëherë në zero).
            //
            // Këto efekte anësore nuk na ndikojnë në asnjë mënyrë dhe asnjë efekt tjetër anësor nuk është i mundur vetëm me një kod të sigurt.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Referencat e forta duhet të zotërojnë së bashku një referencë të dobët të përbashkët, kështu që mos e përdorni destruktorin për referencën tonë të vjetër të dobët.
        //
        mem::forget(weak);
        strong
    }

    /// Ndërton një `Arc` të ri me përmbajtje të pa iniciale.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ndërton një `Arc` të ri me përmbajtje të pa iniciale, me kujtesën e mbushur me `0` bajte.
    ///
    ///
    /// Shihni [`MaybeUninit::zeroed`][zeroed] për shembuj të përdorimit korrekt dhe jo korrekt të kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Ndërton një `Pin<Arc<T>>` të ri.
    /// Nëse `T` nuk zbaton `Unpin`, atëherë `data` do të vendoset në memorie dhe nuk mund të zhvendoset.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Ndërton një `Arc<T>` të ri, duke kthyer një gabim nëse alokimi dështon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Filloni numërimin e dobët të treguesit si 1, i cili është treguesi i dobët që mbahet nga të gjithë treguesit e fortë (kinda), shih std/rc.rs për më shumë informacion
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Ndërton një `Arc` të ri me përmbajtje të pa inicializuar, duke kthyer një gabim nëse alokimi dështon.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Ndërton një `Arc` të ri me përmbajtje të pa iniciale, me kujtesën që mbushet me `0` bajte, duke kthyer një gabim nëse alokimi dështon.
    ///
    ///
    /// Shihni [`MaybeUninit::zeroed`][zeroed] për shembuj të përdorimit korrekt dhe jo korrekt të kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Kthen vlerën e brendshme, nëse `Arc` ka saktësisht një referencë të fortë.
    ///
    /// Përndryshe, një [`Err`] kthehet me të njëjtën `Arc` që u kalua brenda.
    ///
    ///
    /// Kjo do të ketë sukses edhe nëse ka referenca të dobëta të jashtëzakonshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Bëni një tregues të dobët për të pastruar referencën implicite të fortë-të dobët
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Ndërton një fetë të re të numëruar me referencë atomike me përmbajtje të pa iniciale.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Ndërton një fetë të re të numëruar me referencë atomike me përmbajtje të pa iniciale, me kujtesën e mbushur me `0` bajte.
    ///
    ///
    /// Shihni [`MaybeUninit::zeroed`][zeroed] për shembuj të përdorimit korrekt dhe jo korrekt të kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Konvertohet në `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Ashtu si me [`MaybeUninit::assume_init`], i takon thirrësit të garantojë se vlera e brendshme është me të vërtetë në një gjendje të iniciuar.
    ///
    /// Thirrja e kësaj kur përmbajtja ende nuk është iniciuar plotësisht shkakton sjellje të menjëhershme të papërcaktuar.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Konvertohet në `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Ashtu si me [`MaybeUninit::assume_init`], i takon thirrësit të garantojë se vlera e brendshme është me të vërtetë në një gjendje të iniciuar.
    ///
    /// Thirrja e kësaj kur përmbajtja ende nuk është iniciuar plotësisht shkakton sjellje të menjëhershme të papërcaktuar.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Inicializimi i shtyrë:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Konsumon `Arc`, duke kthyer treguesin e mbështjellur.
    ///
    /// Për të shmangur një rrjedhje të kujtesës, treguesi duhet të kthehet në një `Arc` duke përdorur [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Siguron një tregues të papërpunuar të të dhënave.
    ///
    /// Numërimet nuk preken në asnjë mënyrë dhe `Arc` nuk konsumohet.
    /// Treguesi është i vlefshëm për aq kohë sa ka numërime të forta në `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SIGURIA: Kjo nuk mund të kalojë nëpër Deref::deref ose RcBoxPtr::inner sepse
        // kjo kërkohet për të ruajtur prejardhjen raw/mut të tillë që p.sh.
        // `get_mut` mund të shkruajë përmes treguesit pasi Rc të rikuperohet përmes `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Ndërton një `Arc<T>` nga një tregues i papërpunuar.
    ///
    /// Treguesi i papërpunuar duhet të jetë kthyer më parë nga një telefonatë në [`Arc<U>::into_raw`][into_raw] ku `U` duhet të ketë të njëjtën madhësi dhe shtrirje si `T`.
    /// Kjo është trivialisht e vërtetë nëse `U` është `T`.
    /// Vini re se nëse `U` nuk është `T` por ka të njëjtën madhësi dhe shtrirje, kjo në thelb është si transferimi i referencave të llojeve të ndryshme.
    /// Shihni [`mem::transmute`][transmute] për më shumë informacion se çfarë kufizimesh zbatohen në këtë rast.
    ///
    /// Përdoruesi i `from_raw` duhet të sigurohet që një vlerë specifike e `T` të bjerë vetëm një herë.
    ///
    /// Ky funksion është i pasigurt sepse përdorimi i pahijshëm mund të çojë në pasiguri të kujtesës, edhe nëse nuk kthehet kurrë te `Arc<T>` i kthyer.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Kthehuni përsëri në një `Arc` për të parandaluar rrjedhjet.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Telefonatat e mëtejshme drejt `Arc::from_raw(x_ptr)` do të ishin të pasigurta në kujtesë.
    /// }
    ///
    /// // Kujtesa u çlirua kur `x` doli jashtë fushës së sipërme, kështu që `x_ptr` tani po varet!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Kthimi i kompensimit për të gjetur ArcInner origjinal.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Krijon një tregues të ri [`Weak`] për këtë alokim.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Kjo Relaxed është në rregull sepse po kontrollojmë vlerën në CAS më poshtë.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // kontrolloni nëse numëruesi i dobët është aktualisht "locked";nëse është kështu, tjerr.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ky kod aktualisht injoron mundësinë e tejmbushjes
            // në usize::MAX;në përgjithësi si Rc ashtu edhe Arc duhet të rregullohen për t'u marrë me tejmbushjen.
            //

            // Ndryshe nga Clone(), ne kemi nevojë që kjo të jetë një Blerje e lexuar për të sinkronizuar me shkrimet që vijnë nga `is_unique`, në mënyrë që ngjarjet para kësaj shkrimi të ndodhin para këtij leximi.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Sigurohuni që të mos krijojmë një Dobët të varur
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Merr numrin e treguesve [`Weak`] për këtë alokim.
    ///
    /// # Safety
    ///
    /// Kjo metodë në vetvete është e sigurt, por përdorimi i saj i saktë kërkon kujdes shtesë.
    /// Një fije tjetër mund të ndryshojë numërimin e dobët në çdo kohë, përfshirë potencialisht midis thirrjes së kësaj metode dhe veprimit të rezultatit.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ky pohim është përcaktues sepse ne nuk kemi ndarë `Arc` ose `Weak` midis fijeve.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Nëse numërimi i dobët aktualisht është i kyçur, vlera e numërimit ishte 0 pak para se të merrte bllokimin.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Merr numrin e treguesve të fortë (`Arc`) për këtë alokim.
    ///
    /// # Safety
    ///
    /// Kjo metodë në vetvete është e sigurt, por përdorimi i saj i saktë kërkon kujdes shtesë.
    /// Një fije tjetër mund të ndryshojë numërimin e fortë në çdo kohë, përfshirë potencialisht midis thirrjes së kësaj metode dhe veprimit të rezultatit.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ky pohim është përcaktues sepse ne nuk e kemi ndarë `Arc` midis fijeve.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Rrit numrin e fortë të referencës në `Arc<T>` të lidhur me treguesin e dhënë nga një.
    ///
    /// # Safety
    ///
    /// Treguesi duhet të jetë marrë përmes `Arc::into_raw`, dhe instanca e lidhur `Arc` duhet të jetë e vlefshme (dmth
    /// numërimi i fortë duhet të jetë së paku 1) për kohëzgjatjen e kësaj metode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ky pohim është përcaktues sepse ne nuk e kemi ndarë `Arc` midis fijeve.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Mbaj harkun, por mos prek përsëri llogaritjen duke e mbështjellë në ManualDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Tani rritja e llogaritjes së parave, por as mos lësho një llogaritje të re
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Zvogëlon numrin e fortë të referencës në `Arc<T>` të lidhur me treguesin e dhënë nga një.
    ///
    /// # Safety
    ///
    /// Treguesi duhet të jetë marrë përmes `Arc::into_raw`, dhe instanca e lidhur `Arc` duhet të jetë e vlefshme (dmth
    /// numërimi i fortë duhet të jetë së paku 1) kur thirret në këtë metodë.
    /// Kjo metodë mund të përdoret për të lëshuar `Arc` përfundimtar dhe hapësirën e ruajtjes, por **nuk duhet** të thirret pasi të dalë `Arc` përfundimtar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Këto pohime janë përcaktuese sepse ne nuk e kemi ndarë `Arc` midis fijeve.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Kjo pasiguri është në rregull sepse ndërsa ky hark është i gjallë ne jemi të garantuar që treguesi i brendshëm është i vlefshëm.
        // Për më tepër, ne e dimë që struktura `ArcInner` në vetvete është `Sync` sepse të dhënat e brendshme janë `Sync` gjithashtu, kështu që jemi në rregull duke huazuar një tregues të pandryshueshëm për këto përmbajtje.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Pjesë jo e nënvizuar e `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Shkatërroni të dhënat në këtë kohë, edhe pse mund të mos e lirojmë vetë shpërndarjen e kutisë (mund të ketë akoma tregues të dobët përreth).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Hidhni ref-in e dobët të mbajtur kolektivisht nga të gjitha referencat e forta
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Kthen `true` nëse të dy `Arc`-ët tregojnë për të njëjtën shpërndarje (në një mënyrë të ngjashme me [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Alokon një `ArcInner<T>` me hapësirë të mjaftueshme për një vlerë të brendshme me mundësi të pa madhësisë, ku vlera ka paraqitjen e dhënë.
    ///
    /// Funksioni `mem_to_arcinner` thirret me treguesin e të dhënave dhe duhet të kthejë një pikë (potencialisht të majme) për `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Llogaritni paraqitjen duke përdorur paraqitjen e vlerës së dhënë.
        // Më parë, faqosja ishte llogaritur në shprehjen `&*(ptr as* const ArcInner<T>)`, por kjo krijoi një referencë të gabuar (shih #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Alokon një `ArcInner<T>` me hapësirë të mjaftueshme për një vlerë të brendshme me madhësi të pakuptimtë, ku vlera ka paraqitur paraqitjen, duke kthyer një gabim nëse alokimi dështon.
    ///
    ///
    /// Funksioni `mem_to_arcinner` thirret me treguesin e të dhënave dhe duhet të kthejë një pikë (potencialisht të majme) për `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Llogaritni paraqitjen duke përdorur paraqitjen e vlerës së dhënë.
        // Më parë, faqosja ishte llogaritur në shprehjen `&*(ptr as* const ArcInner<T>)`, por kjo krijoi një referencë të gabuar (shih #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Filloni ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Alokon një `ArcInner<T>` me hapësirë të mjaftueshme për një vlerë të brendshme të pa madhësisë.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Alokoni për `ArcInner<T>` duke përdorur vlerën e dhënë.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopjoni vlerën si bajte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Lironi alokimin pa rënë në përmbajtje
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Alokon një `ArcInner<[T]>` me gjatësinë e dhënë.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopjoni elementet nga feta në Arc </[T\]> të sapo alokuar
    ///
    /// E pasigurt sepse telefonuesi ose duhet të marrë pronësinë ose të lidhë `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Ndërton një `Arc<[T]>` nga një iterator i njohur për një madhësi të caktuar.
    ///
    /// Sjellja është e papërcaktuar nëse madhësia është e gabuar.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Mbrojtësi Panic gjatë klonimit të elementeve T.
        // Në rast të një panic, elementët që janë shkruar në ArcInner të ri do të hidhen, pastaj kujtesa do të lirohet.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Treguesi tek elementi i parë
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Gjithçka e qartë.Harrojeni rojën në mënyrë që të mos lirojë ArcInner të ri.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializimi trait përdoret për `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Bën një klon të treguesit `Arc`.
    ///
    /// Kjo krijon një tregues tjetër për të njëjtën shpërndarje, duke rritur numrin e fortë të referencës.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Përdorimi i një renditje të relaksuar është në rregull këtu, pasi njohja e referencës origjinale parandalon fijet e tjera të fshijnë gabimisht objektin.
        //
        // Siç është shpjeguar në [Boost documentation][1], Rritja e njehsorit të referencës mund të bëhet gjithmonë me memory_order_relaxed: Referencat e reja për një objekt mund të formohen vetëm nga një referencë ekzistuese, dhe kalimi i një referencë ekzistuese nga një fije në tjetrën duhet të sigurojë tashmë çdo sinkronizim të kërkuar.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Sidoqoftë ne duhet të ruhemi nga llogaritjet masive në rast se dikush harron harqet.
        // Nëse nuk e bëjmë këtë numërimi mund të tejkalojë dhe përdoruesit do të përdorin falas.
        // Ne ngopemi me racizëm në `isize::MAX` me supozimin se nuk ka filma ~2 miliardë që rritin numrin e referencës menjëherë.
        //
        // Ky branch nuk do të merret kurrë në ndonjë program realist.
        //
        // Abortojmë sepse një program i tillë është tepër i degjeneruar dhe nuk na intereson ta mbështesim atë.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Bën një referencë të ndryshueshme në `Arc` të dhënë.
    ///
    /// Nëse ka tregues të tjerë `Arc` ose [`Weak`] për të njëjtën shpërndarje, atëherë `make_mut` do të krijojë një alokim të ri dhe do të thirret [`clone`][clone] në vlerën e brendshme për të siguruar pronësinë unike.
    /// Kjo është referuar gjithashtu si klon-mbi-shkruaj.
    ///
    /// Vini re se kjo ndryshon nga sjellja e [`Rc::make_mut`] e cila ndan çdo tregues të mbetur `Weak`.
    ///
    /// Shikoni gjithashtu [`get_mut`][get_mut], i cili do të dështojë më shumë sesa klonimi.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Nuk do të klonojë asgjë
    /// let mut other_data = Arc::clone(&data); // Nuk do të klonojë të dhënat e brendshme
    /// *Arc::make_mut(&mut data) += 1;         // Klonon të dhënat e brendshme
    /// *Arc::make_mut(&mut data) += 1;         // Nuk do të klonojë asgjë
    /// *Arc::make_mut(&mut other_data) *= 2;   // Nuk do të klonojë asgjë
    ///
    /// // Tani `data` dhe `other_data` tregojnë për alokime të ndryshme.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Vini re se ne kemi një referencë të fortë dhe një referencë të dobët.
        // Kështu, lirimi i referencës sonë të fortë nuk do të bëjë, në vetvete, që kujtesa të zhvendoset.
        //
        // Përdorni Acquire për të siguruar që shohim ndonjë shkrim në `weak` që ndodh para se të shkruhet lëshimi (dmth. Ulje) në `strong`.
        // Meqenëse kemi një numërim të dobët, nuk ka asnjë shans që vetë ArcInner të mund të shpërndahet.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Ekziston një tjetër tregues i fortë, prandaj duhet të klonojmë.
            // Alokoni paraprakisht kujtesën për të lejuar shkrimin e vlerës së klonuar drejtpërdrejt.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Mjafton të qetë në sa më sipër, sepse ky është në thelb një optimizëm: ne gjithmonë jemi duke garuar me tregues të dobët që bien.
            // Rasti më i keq, ne përfundimisht shpërndamë një Arc të ri pa nevojë.
            //

            // Ne kemi hequr ref-in e fundit të fortë, por ka refs shtesë të dobët që kanë mbetur.
            // Ne do ta zhvendosim përmbajtjen në një Hark të ri dhe do të zhvlerësojmë referat e tjerë të dobët.
            //

            // Vini re se nuk është e mundur që leximi i `weak` të japë usize::MAX (dmth. I kyçur), pasi numërimi i dobët mund të bllokohet vetëm nga një fije me një referencë të fortë.
            //
            //

            // Materializoni treguesin tonë të dobët të nënkuptuar, në mënyrë që ai të pastrojë ArcInner sipas nevojës.
            //
            let _weak = Weak { ptr: this.ptr };

            // Thjesht mund të vjedhin të dhënat, e gjitha që ka mbetur është Dobësitë
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Ne ishim referenca e vetme e të dy llojeve;përplas numrin e fortë të ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Ashtu si me `get_mut()`, pasiguria është në rregull sepse referenca jonë ishte ose unike për të filluar, ose u bë një me klonimin e përmbajtjes.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Kthen një referencë të ndryshueshme në `Arc` të dhënë, nëse nuk ka tregues të tjerë `Arc` ose [`Weak`] për të njëjtën shpërndarje.
    ///
    ///
    /// Kthen [`None`] ndryshe, sepse nuk është e sigurt të shndërrosh një vlerë të përbashkët.
    ///
    /// Shikoni gjithashtu [`make_mut`][make_mut], i cili do të [`clone`][clone] vlerën e brendshme kur ka tregues të tjerë.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Kjo pasiguri është në rregull sepse ne jemi të garantuar që treguesi i kthyer është treguesi *i vetëm* që do t'i kthehet ndonjëherë T.
            // Numri ynë i referencës është i garantuar të jetë 1 në këtë pikë, dhe ne kërkuam që vetë Harku të jetë `mut`, kështu që po i kthejmë referencën e vetme të mundshme të dhënave të brendshme.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Kthen një referencë të ndryshueshme në `Arc` të dhënë, pa ndonjë kontroll.
    ///
    /// Shikoni gjithashtu [`get_mut`], i cili është i sigurt dhe bën kontrollet e duhura.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Çdo tregues tjetër `Arc` ose [`Weak`] për të njëjtën shpërndarje nuk duhet të referohet për kohëzgjatjen e huasë së kthyer.
    ///
    /// Kjo është e parëndësishme nëse nuk ekzistojnë tregues të tillë, për shembull menjëherë pas `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Ne jemi të kujdesshëm që *të mos* krijojmë një referencë që mbulon fushat "count", pasi kjo do të quhej alias me qasjen e njëkohshme në numërimin e referencave (p.sh.
        // nga `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Përcaktoni nëse kjo është referencë unike (përfshirë ref-et e dobëta) për të dhënat themelore.
    ///
    ///
    /// Vini re se kjo kërkon mbylljen e numrit të dobët të ref.
    fn is_unique(&mut self) -> bool {
        // bllokoni numrin e dobët të treguesit nëse dukemi se jemi mbajtësi i vetëm i dobët i treguesit.
        //
        // Etiketa e blerjes këtu siguron një marrëdhënie të ndodhë-para me çdo shkrim në `strong` (veçanërisht në `Weak::upgrade`) para uljeve të numërimit të `weak` (përmes `Weak::drop`, i cili përdor lëshimin).
        // Nëse ref-i i azhurnuar i azhurnuar nuk do të binte kurrë, CAS këtu do të dështojë kështu që ne nuk na intereson të sinkronizohemi.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Kjo duhet të jetë një `Acquire` për të sinkronizuar me uljen e numëruesit `strong` në `drop`-e vetmja qasje që ndodh kur ndonjë, por referenca e fundit po hidhet.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Shkrimi i lëshimit këtu sinkronizohet me një lexim në `downgrade`, duke parandaluar që leximi i mësipërm i `strong` të ndodhë pas shkrimit.
            //
            //
            self.inner().weak.store(1, Release); // lëshoni bllokimin
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Bie `Arc`.
    ///
    /// Kjo do të zvogëlojë numërimin e fortë të referencës.
    /// Nëse numërimi i fortë i referencës arrin në zero, atëherë referencat e tjera të tjera (nëse ka) janë [`Weak`], kështu që ne `drop` vlerën e brendshme.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Nuk shtyp asgjë
    /// drop(foo2);   // Printime "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Për shkak se `fetch_sub` është tashmë atomik, ne nuk kemi nevojë të sinkronizohemi me fije të tjera përveç nëse do të fshijmë objektin.
        // Kjo logjikë e njëjtë vlen për `fetch_sub` më poshtë për numërimin `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Ky gardh është i nevojshëm për të parandaluar renditjen e përdorimit të të dhënave dhe fshirjen e të dhënave.
        // Për shkak se është shënuar `Release`, zvogëlimi i numrit të referencës sinkronizohet me këtë gardh `Acquire`.
        // Kjo do të thotë që përdorimi i të dhënave ndodh para se të zvogëlohet numri i referencës, i cili ndodh para këtij gardhi, i cili ndodh para fshirjes së të dhënave.
        //
        // Siç shpjegohet në [Boost documentation][1],
        //
        // > Shtë e rëndësishme të zbatohet çdo qasje e mundshme në objekt në një
        // > fije (përmes një referencë ekzistuese) të ndodhë *përpara* fshirjes
        // > objekti në një fije tjetër.Kjo arrihet nga një "release"
        // > operacion pas rënies së një referencë (çdo qasje në objekt
        // > përmes kësaj referimi padyshim që duhet të ketë ndodhur më parë), dhe an
        // > "acquire" operacion para fshirjes së objektit.
        //
        // Në veçanti, ndërsa përmbajtja e një Arc është zakonisht e pandryshueshme, është e mundur të keni shkrime të brendshme për diçka si një Mutex<T>.
        // Meqenëse një Mutex nuk merret kur fshihet, ne nuk mund të mbështetemi në logjikën e tij të sinkronizimit për të bërë shkrimet në fijen A të dukshme për një shkatërrues që ekzekutohet në fijen B.
        //
        //
        // Gjithashtu vini re se gardhi i Blerjes këtu mund të zëvendësohet me një ngarkesë të Blerjes, e cila mund të përmirësojë performancën në situata shumë të pretenduara.Shihni [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Përpjekje për të ulur `Arc<dyn Any + Send + Sync>` në një lloj betoni.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Ndërton një `Weak<T>` të ri, pa caktuar asnjë kujtesë.
    /// Thirrja [`upgrade`] në vlerën e kthimit gjithmonë jep [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Lloji ndihmës për të lejuar hyrjen në numërimin e referencave pa bërë asnjë pohim në lidhje me fushën e të dhënave.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Kthen një tregues të papërpunuar në objektin `T` të treguar nga ky `Weak<T>`.
    ///
    /// Treguesi është i vlefshëm vetëm nëse ka disa referenca të forta.
    /// Treguesi mund të jetë i varur, i pavendosur ose edhe [`null`] ndryshe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Të dy tregojnë për të njëjtin objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // I forti këtu e mban gjallë, kështu që ne ende mund të kemi qasje në objekt.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Por jo më.
    /// // Ne mund të bëjmë weak.as_ptr(), por hyrja në tregues do të çonte në një sjellje të papërcaktuar.
    /// // assert_eq! ("përshëndetje", i pasigurt {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Nëse treguesi është i varur, ne e kthejmë rojet direkt.
            // Kjo nuk mund të jetë një adresë e vlefshme e ngarkesës, pasi ngarkesa është të paktën e njëjtë me ArcInner (usize).
            ptr as *const T
        } else {
            // SIGURIA: nëse is_dangling kthen false, atëherë treguesi është i referueshëm.
            // Ngarkesa mund të bjerë në këtë pikë, dhe ne duhet të ruajmë origjinën, kështu që përdorni manipulimin e papërpunuar të treguesit.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Konsumon `Weak<T>` dhe e kthen atë në një tregues të papërpunuar.
    ///
    /// Kjo e kthen treguesin e dobët në një tregues të papërpunuar, duke ruajtur ende pronësinë e një reference të dobët (numërimi i dobët nuk modifikohet nga ky operacion).
    /// Mund të kthehet përsëri në `Weak<T>` me [`from_raw`].
    ///
    /// Zbatohen të njëjtat kufizime të hyrjes në shënjestrën e treguesit si me [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konverton një tregues të papërpunuar të krijuar më parë nga [`into_raw`] përsëri në `Weak<T>`.
    ///
    /// Kjo mund të përdoret për të marrë në mënyrë të sigurt një referencë të fortë (duke telefonuar [`upgrade`] më vonë) ose për të zhvendosur numërimin e dobët duke rënë `Weak<T>`.
    ///
    /// Merr pronësinë e një referencë të dobët (me përjashtim të treguesve të krijuar nga [`new`], pasi këto nuk zotërojnë asgjë; metoda ende funksionon në to).
    ///
    /// # Safety
    ///
    /// Treguesi duhet të ketë origjinën nga [`into_raw`] dhe duhet të ketë ende referencën e tij të dobët.
    ///
    /// Lejohet që numërimi i fortë të jetë 0 në kohën e thirrjes së tij.
    /// Sidoqoftë, kjo merr në pronësi një referencë të dobët që përfaqësohet aktualisht si një tregues i papërpunuar (numërimi i dobët nuk modifikohet nga ky operacion) dhe për këtë arsye duhet të shoqërohet me një thirrje të mëparshme në [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Zbërtheni numrin e fundit të dobët.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Shihni Weak::as_ptr për kontekstin se si nxirret treguesi i hyrjes.

        let ptr = if is_dangling(ptr as *mut T) {
            // Ky është një Dobët i varur.
            ptr as *mut ArcInner<T>
        } else {
            // Përndryshe, ne jemi të garantuar që treguesi erdhi nga një Dobët i paqartë.
            // SIGURIA: data_offset është e sigurt për t`u thirrur, pasi referencat ptr i referohen një T-je reale (potencialisht të rënë).
            let offset = unsafe { data_offset(ptr) };
            // Kështu, ne e ndryshojmë kompensimin për të marrë të gjithë RcBox.
            // SIGURIA: treguesi ka origjinën nga një i dobët, kështu që ky kompensim është i sigurt.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SIGURIA: tani kemi rikuperuar treguesin origjinal të Dobët, kështu që mund të krijojmë Dobët.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Përpjekjet për të azhurnuar treguesin `Weak` në një [`Arc`], duke vonuar rënien e vlerës së brendshme nëse është i suksesshëm.
    ///
    ///
    /// Kthen [`None`] nëse vlera e brendshme ka rënë.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Shkatërroni të gjithë treguesit e fortë.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Ne përdorim një lak CAS për të rritur numërimin e fortë në vend të një fetch_add pasi ky funksion nuk duhet të marrë kurrë numërimin e referencës nga zero në një.
        //
        //
        let inner = self.inner()?;

        // Ngarkesa e relaksuar sepse çdo shkrim i 0 që mund të vëzhgojmë lë fushën në një gjendje të përhershme zero (kështu që leximi "stale" i 0 është i mirë), dhe çdo vlerë tjetër konfirmohet përmes CAS më poshtë.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Shihni komentet në `Arc::clone` pse e bëjmë këtë (për `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Të relaksuar është mirë për rastin e dështimit sepse nuk kemi ndonjë pritje për shtetin e ri.
            // Blerja është e nevojshme që çështja e suksesit të sinkronizohet me `Arc::new_cyclic`, kur vlera e brendshme mund të iniciohet pasi referencat `Weak` të jenë krijuar tashmë.
            // Në atë rast, ne presim të vëzhgojmë vlerën e iniciuar plotësisht.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null i kontrolluar më sipër
                Err(old) => n = old,
            }
        }
    }

    /// Merr numrin e treguesve të fortë (`Arc`) që tregojnë këtë alokim.
    ///
    /// Nëse `self` është krijuar duke përdorur [`Weak::new`], kjo do të kthejë 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Merr një përafrim të numrit të treguesve `Weak` që tregojnë këtë alokim.
    ///
    /// Nëse `self` është krijuar duke përdorur [`Weak::new`], ose nëse nuk ka asnjë tregues të fortë, kjo do të kthejë 0.
    ///
    /// # Accuracy
    ///
    /// Për shkak të detajeve të implementimit, vlera e kthyer mund të fiket me 1 në secilin drejtim kur fijet e tjera manipulojnë çdo `Arc` ose `dobët` duke treguar të njëjtën shpërndarje.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Meqenëse kemi vërejtur që kishte të paktën një tregues të fortë pas leximit të numërimit të dobët, ne e dimë se referenca e dobët implicite (e pranishme sa herë që ndonjë referencë e fortë është e gjallë) ishte akoma rreth kur vëzhguam numërimin e dobët, dhe për këtë arsye mund ta zbresim atë në mënyrë të sigurt.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Kthen `None` kur treguesi është i varur dhe nuk ka asnjë `ArcInner` të caktuar, (dmth. Kur ky `Weak` është krijuar nga `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Ne jemi të kujdesshëm që * të mos krijojmë një referencë që mbulon fushën "data", pasi fusha mund të mutohet njëkohësisht (për shembull, nëse `Arc` i fundit bie, fusha e të dhënave do të bjerë në vend).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Kthen `true` nëse të dy `Dobët` tregojnë për të njëjtën shpërndarje (e ngjashme me [`ptr::eq`]), ose nëse të dy nuk tregojnë ndonjë alokim (sepse ato janë krijuar me `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Meqenëse kjo krahason treguesit do të thotë që `Weak::new()` do të barazohet me njëri-tjetrin, edhe pse nuk tregojnë ndonjë alokim.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Krahasimi i `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Bën një klon të treguesit `Weak` që tregon për të njëjtën shpërndarje.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Shihni komentet në Arc::clone() pse është relaksuar kjo.
        // Kjo mund të përdorë një fetch_add (duke injoruar bllokimin) sepse numërimi i dobët bllokohet vetëm atje ku nuk ka *tregues të tjerë* të dobët.
        //
        // (Kështu që ne nuk mund ta përdorim këtë kod në atë rast).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Shihni komentet në Arc::clone() pse e bëjmë këtë (për mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Ndërton një `Weak<T>` të ri, pa caktuar kujtesë.
    /// Thirrja [`upgrade`] në vlerën e kthimit gjithmonë jep [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Bie treguesin `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Nuk shtyp asgjë
    /// drop(foo);        // Printime "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Nëse zbulojmë se kemi qenë treguesi i fundit i dobët, atëherë është koha për të zhvendosur plotësisht të dhënat.Shihni diskutimin në Arc::drop() rreth renditjeve të kujtesës
        //
        // Nuk është e nevojshme të kontrolloni gjendjen e kyçur këtu, sepse numërimi i dobët mund të kyçet vetëm nëse ka pasur saktësisht një ref të dobët, që do të thotë që rënia mund të funksionojë vetëm më pas në atë ref të dobët të mbetur, gjë që mund të ndodhë vetëm pasi të jetë lëshuar bllokimi.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Ne jemi duke e bërë këtë specializim këtu, dhe jo si një optimizim më i përgjithshëm në `&T`, sepse përndryshe do të shtonte një kosto për të gjitha kontrollet e barazisë në ref.
/// Supozojmë se `Arc` janë përdorur për të ruajtur vlera të mëdha, të cilat ngadalësohen për t`u klonuar, por edhe të rënda për të kontrolluar barazinë, duke bërë që kjo kosto të shlyhet më lehtë.
///
/// Alsoshtë gjithashtu më e mundshme që të ketë dy klone `Arc`, që tregojnë për të njëjtën vlerë, sesa dy `&T`.
///
/// Ne mund ta bëjmë këtë vetëm kur `T: Eq` si `PartialEq` mund të jetë qëllimisht reflektues.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Barazia për dy `Arc` s.
    ///
    /// Dy `Arc` s janë të barabartë nëse vlerat e tyre të brendshme janë të barabarta, edhe nëse ato ruhen në alokim të ndryshëm.
    ///
    /// Nëse `T` zbaton edhe `Eq` (nënkupton refleksivitetin e barazisë), dy harqe që tregojnë për të njëjtën ndarje janë gjithmonë të barabartë.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Pabarazia për dy `Arc`.
    ///
    /// Dy `Arc` nuk janë të barabarta nëse vlerat e tyre të brendshme janë të pabarabarta.
    ///
    /// Nëse `T` gjithashtu zbaton `Eq` (nënkupton refleksivitetin e barazisë), dy harqe që tregojnë për të njëjtën vlerë nuk janë kurrë të pabarabarta.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Krahasimi i pjesshëm për dy `Arc`.
    ///
    /// Të dy krahasohen duke thirrur `partial_cmp()` në vlerat e tyre të brendshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Krahasimi më pak se dy `Arc` s.
    ///
    /// Të dy krahasohen duke thirrur `<` në vlerat e tyre të brendshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Krahasimi 'Më pak se ose i barabartë me' për dy `Arc`.
    ///
    /// Të dy krahasohen duke thirrur `<=` në vlerat e tyre të brendshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Krahasim më i madh se dy Arc`
    ///
    /// Të dy krahasohen duke thirrur `>` në vlerat e tyre të brendshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Krahasimi 'Më i madh se ose i barabartë me' për dy `Arc`.
    ///
    /// Të dy krahasohen duke thirrur `>=` në vlerat e tyre të brendshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Krahasimi për dy `Arc` s.
    ///
    /// Të dy krahasohen duke thirrur `cmp()` në vlerat e tyre të brendshme.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Krijon një `Arc<T>` të ri, me vlerën `Default` për `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Alokoni një fetë të numëruar si referencë dhe plotësojeni duke klonuar artikujt e `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Alokoni një `str` të numëruar si referencë dhe kopjoni `v` në të.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Alokoni një `str` të numëruar si referencë dhe kopjoni `v` në të.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Zhvendosni një objekt me kuti në një alokim të ri, të numëruar nga referencat.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Alokoni një fetë të numëruar si referencë dhe zhvendosni sendet e `v` në të.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Lejoni Vec-in të lirojë kujtesën e tij, por mos të shkatërrojë përmbajtjen e tij
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Merr secilin element në `Iterator` dhe e mbledh atë në një `Arc<[T]>`.
    ///
    /// # Karakteristikat e performancës
    ///
    /// ## Çështja e përgjithshme
    ///
    /// Në rastin e përgjithshëm, mbledhja në `Arc<[T]>` bëhet duke mbledhur së pari në një `Vec<T>`.Kjo është, kur shkruani sa vijon:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// kjo sillet sikur të kemi shkruar:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Grupi i parë i alokimeve ndodh këtu.
    ///     .into(); // Një alokim i dytë për `Arc<[T]>` ndodh këtu.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Kjo do të caktojë sa herë të jetë e nevojshme për ndërtimin e `Vec<T>` dhe pastaj do të caktojë një herë për kthimin e `Vec<T>` në `Arc<[T]>`.
    ///
    ///
    /// ## Iteratorë me gjatësi të njohur
    ///
    /// Kur `Iterator` juaj zbaton `TrustedLen` dhe është me një madhësi të saktë, do të bëhet një alokim i vetëm për `Arc<[T]>`.Për shembull:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Vetëm një alokim i vetëm ndodh këtu.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specializimi trait përdoret për mbledhjen në `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Ky është rasti për një përsëritës `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SIGURIA: Ne duhet të sigurojmë që përsëritësi ka një gjatësi të saktë dhe ne kemi.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Bëni përsëri në zbatimin normal.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Merrni kompensimin brenda një `ArcInner` për ngarkesën prapa një treguesi.
///
/// # Safety
///
/// Treguesi duhet të tregojë (dhe të ketë meta të dhëna të vlefshme) për një shembull më parë të vlefshëm të T, por T lejohet të hidhet.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Drejtoni vlerën e pa madhësisë në fund të ArcInner.
    // Për shkak se RcBox është repr(C), do të jetë gjithmonë fusha e fundit në kujtesë.
    // SIGURIA: meqenëse llojet e vetme pa madhësi të mundshme janë feta, objekte trait,
    // dhe llojet e jashtme, kërkesa e sigurisë së hyrjes aktualisht është e mjaftueshme për të përmbushur kërkesat e align_of_val_raw;ky është një detaj zbatimi i gjuhës që nuk mund të mbështetet jashtë std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}