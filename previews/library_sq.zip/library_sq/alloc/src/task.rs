#![stable(feature = "wake_trait", since = "1.51.0")]
//! Llojet dhe Traits për të punuar me detyra asinkrone.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Zbatimi i zgjimit të një detyre për një ekzekutues.
///
/// Ky trait mund të përdoret për të krijuar një [`Waker`].
/// Një ekzekutues mund të përcaktojë një zbatim të këtij trait, dhe ta përdorë atë për të ndërtuar një Waker për të kaluar në detyrat që ekzekutohen në atë ekzekutues.
///
/// Ky trait është një alternativë ergonomike e sigurt për kujtesën për ndërtimin e një [`RawWaker`].
/// Ai mbështet projektin e zakonshëm të ekzekutuesit në të cilin të dhënat e përdorura për të zgjuar një detyrë ruhen në një [`Arc`].
/// Disa ekzekutues (veçanërisht ata për sistemet e ngulitura) nuk mund ta përdorin këtë API, prandaj [`RawWaker`] ekziston si një alternativë për ato sisteme.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Një funksion themelor `block_on` që merr një future dhe e ekzekuton atë deri në përfundim në fijen aktuale.
///
/// **Note:** Ky shembull tregton korrektësi për thjeshtësi.
/// Në mënyrë që të parandalohen bllokimet, zbatimet e shkallës së prodhimit do të duhet gjithashtu të trajtojnë thirrjet e ndërmjetme në `thread::unpark` si dhe thirrjet e vendosura brenda.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Një zgjues që zgjon fillin aktual kur thirret.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Ekzekutoni një future deri në përfundimin në fijen aktuale.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Mbërtheni future në mënyrë që të mund të anketohet.
///     let mut fut = Box::pin(fut);
///
///     // Krijoni një kontekst të ri për t'i kaluar future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Drejtoni future deri në përfundim.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Zgjojeni këtë detyrë.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Zgjojeni këtë detyrë pa konsumuar zgjimin.
    ///
    /// Nëse një ekzekutues mbështet një mënyrë më të lirë për tu zgjuar pa konsumuar zgjimin, ajo duhet ta tejkalojë këtë metodë.
    /// Si parazgjedhje, klonon [`Arc`] dhe telefonon [`wake`] në klon.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SIGURIA: Kjo është e sigurt sepse prodhuesi i papërpunuar ndërton në mënyrë të sigurt
        // një RawWaker nga Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ky funksion privat për ndërtimin e një RawWaker përdoret, në vend se
// duke e nënvizuar këtë në implikimin `From<Arc<W>> for RawWaker`, për të siguruar që siguria e `From<Arc<W>> for Waker` nuk varet nga dërgimi i saktë i trait, përkundrazi të dy implikimet e quajnë këtë funksion drejtpërdrejt dhe në mënyrë të qartë.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Rritni numrin e referencës së harkut për ta klonuar atë.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Zgjohuni sipas vlerës, duke e zhvendosur Harkun në funksionin Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Zgjohuni me referencë, mbështillni gotën me ManualDrop për të shmangur rënien e tij
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Zbërtheni numrin e referencës së Harkut në rënie
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}