// rsbegin.o dhe rsend.o janë të ashtuquajturat "compiler runtime startup objects".
// Ato përmbajnë kod të nevojshëm për të iniciuar saktë kohën e përpilimit të përpiluesit.
//
// Kur një imazh i ekzekutueshëm ose dylib është i lidhur, të gjithë kodet e përdoruesit dhe bibliotekat janë "sandwiched" midis këtyre dy skedarëve të objektit, kështu që kodi ose të dhënat nga rsbegin.o bëhen të parët në seksionet përkatëse të imazhit, ndërsa kodi dhe të dhënat nga rsend.o bëhen ato të fundit.
// Ky efekt mund të përdoret për të vendosur simbole në fillim ose në fund të një pjese, si dhe për të futur çfarëdo titulli ose fundi i kërkuar.
//
// Vini re se pika aktuale e hyrjes së modulit është e vendosur në objektin e fillimit të kohës së ekzekutimit C (zakonisht i quajtur `crtX.o`), i cili më pas thirrjet e thirrjeve fillestare të komponentëve të tjerë të kohës së ekzekutimit (regjistruar përmes një seksioni tjetër të veçantë të imazhit).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Shënon fillimin e pjesës së informacionit të kornizës së pirgut
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Hapësirë gërvishtëse për mbajtjen e brendshme të librave të padëshiruar.
    // Kjo përcaktohet si `struct object` në $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Shpalosni rutinat e informacionit registration/deregistration.
    // Shikoni dokumentet e libpanic_windind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // regjistrohu lësho informacionin për fillimin e modulit
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // çregjistrohuni në mbyllje
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Regjistrimi rutinor specifik për MinGW init/uninit
    pub mod mingw_init {
        // Objektet e fillimit të MinGW (crt0.o/dllcrt0.o) do të kërkojnë konstruktorë globalë në seksionet .ctors dhe .dtors gjatë fillimit dhe daljes.
        // Në rastin e DLL-ve, kjo bëhet kur DLL-ja ngarkohet dhe shkarkohet.
        //
        // Lidhësi do të rendisë seksionet, gjë që siguron që thirrjet tona të vendosen në fund të listës.
        // Meqenëse konstruktorët drejtohen në mënyrë të kundërt, kjo siguron që thirrjet tona të kthyera janë të parat dhe të fundit.
        //
        //

        #[link_section = ".ctors.65535"] // .ktorët. *: Thirrjet e fillimit të C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: Thirrjet e përfundimit të C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}