# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Një bibliotekë për blerjen e backtraces në kohën e duhur për Rust.
Kjo bibliotekë synon të rrisë mbështetjen e bibliotekës standarde duke siguruar një ndërfaqe programatike për të punuar me të, por gjithashtu mbështet thjesht shtypjen me lehtësi të backtrace aktuale si panics e libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Për të kapur thjesht një rikthim dhe për ta shtyrë trajtimin e tij deri në një kohë më vonë, mund të përdorni llojin e nivelit të lartë `Backtrace`.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Nëse, megjithatë, dëshironi më shumë qasje të papërpunuar në funksionalitetin aktual të gjurmimit, mund të përdorni funksionet `trace` dhe `resolve` drejtpërdrejt.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Zgjidh këtë tregues udhëzimi në një emër simboli
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // vazhdo të shkosh në kornizën tjetër
    });
}
```

# License

Ky projekt është i licencuar në njërën prej të dyja

 * Licenca Apache, Versioni 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ose http://www.apache.org/licenses/LICENSE-2.0)
 * Licencë MIT ([LICENSE-MIT](LICENSE-MIT) ose http://opensource.org/licenses/MIT)

sipas opsionit tuaj.

### Contribution

Në qoftë se nuk shprehni shprehimisht ndryshe, çdo kontribut i paraqitur qëllimisht për tu përfshirë në rikthim nga ju, siç përcaktohet në licencën Apache-2.0, do të jetë i licencuar dyfish si më sipër, pa ndonjë kusht ose kusht shtesë.







