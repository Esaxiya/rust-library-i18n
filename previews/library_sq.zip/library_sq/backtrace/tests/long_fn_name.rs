use backtrace::Backtrace;

// Emri i modulit me 50 karaktere
mod _234567890_234567890_234567890_234567890_234567890 {
    // Emër strukturor me 50 karaktere
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Emrat e funksioneve të gjata duhet të shkurtohen në (MAX_SYM_NAME, 1) karaktere.
// Bëni këtë provë vetëm për msvc, pasi gnu shtyp "<no info>" për të gjitha kornizat.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 përsëritje të emrit të strukturës, kështu që emri i funksionit plotësisht i kualifikuar është së paku 10 *(50 + 50)* 2=2000 karaktere i gjatë.
    //
    // Në të vërtetë është më e gjatë pasi përfshin gjithashtu `::`, `<>` dhe emrin e modulit aktual
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}