use backtrace::Backtrace;

// Ky test funksionon vetëm në platforma që kanë një funksion `symbol_address` që punon për kornizat që raporton adresën fillestare të një simboli.
// Si rezultat, aktivizohet vetëm në disa platforma.
//
const ENABLED: bool = cfg!(all(
    // Windows nuk është testuar me të vërtetë dhe OSX nuk mbështet gjetjen në të vërtetë të një kornize mbyllëse, kështu që çaktivizojeni këtë
    //
    target_os = "linux",
    // Në ARM, gjetja e funksionit mbyllës thjesht po kthen vetë ip-in.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}