#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Një formatues për backtraces.
///
/// Ky lloj mund të përdoret për të shtypur një backtrace pa marrë parasysh se nga vjen vetë backtrace.
/// Nëse keni një lloj `Backtrace`, atëherë implementimi i tij `Debug` tashmë e përdor këtë format shtypi.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Stilet e shtypjes që mund të shtypim
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Shtyp një rikthim rutinor që idealisht përmban vetëm informacionin përkatës
    Short,
    /// Shtyp një prapavijë që përmban të gjithë informacionin e mundshëm
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Krijoni një `BacktraceFmt` të ri i cili do të shkruajë prodhimin në `fmt` të dhënë.
    ///
    /// Argumenti `format` do të kontrollojë stilin në të cilin shtypet backtrace dhe argumenti `print_path` do të përdoret për të shtypur shembujt `BytesOrWideString` të emrave të skedarëve.
    /// Vetë ky lloj nuk bën ndonjë shtypje të emrave të skedarëve, por kjo thirrje kërkohet për ta bërë këtë.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Shtyp një parathënie për backtrace që do të shtypet.
    ///
    /// Kjo kërkohet në disa platforma që backtraces të simbolizohen plotësisht më vonë, dhe përndryshe kjo duhet të jetë thjesht metoda e parë që telefononi pasi keni krijuar një `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Shton një kornizë në daljen e backtrace.
    ///
    /// Ky angazhim kthen një shembull RAII të një `BacktraceFrameFmt` i cili mund të përdoret për të shtypur në të vërtetë një kornizë, dhe në shkatërrim do të rritet numëruesi i kornizës.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Përfundon daljen e backtrace.
    ///
    /// Kjo është aktualisht një no-op, por është shtuar për pajtueshmërinë future me format backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Aktualisht një no-op-- përfshirë këtë hook për të lejuar shtesa të future.
        Ok(())
    }
}

/// Një formatues për vetëm një kornizë të një backtrace.
///
/// Ky lloj është krijuar nga funksioni `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Shtyp një `BacktraceFrame` me këtë formatues kornizë.
    ///
    /// Kjo do të shtypë në mënyrë rekursive të gjitha instancat `BacktraceSymbol` brenda `BacktraceFrame`.
    ///
    /// # Karakteristikat e kërkuara
    ///
    /// Ky funksion kërkon që të aktivizohet tipari `std` i `backtrace` crate dhe tipari `std` është aktivizuar si parazgjedhje.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Shtyp një `BacktraceSymbol` brenda një `BacktraceFrame`.
    ///
    /// # Karakteristikat e kërkuara
    ///
    /// Ky funksion kërkon që të aktivizohet tipari `std` i `backtrace` crate dhe tipari `std` është aktivizuar si parazgjedhje.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: kjo nuk është e shkëlqyeshme që ne të mos shtypim asgjë
            // me emra skedarësh jo-utf8.
            // Fatmirësisht pothuajse gjithçka është utf8 kështu që kjo nuk duhet të jetë shumë e keqe.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Printon një `Frame` dhe `Symbol` të gjurmuar të papërpunuar, zakonisht nga kthimet e kthyera të këtij crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Shton një kornizë të papërpunuar në daljen e backtrace.
    ///
    /// Kjo metodë, ndryshe nga e mëparshmja, merr argumentet e papërpunuara në rast se po burojnë nga vende të ndryshme.
    /// Vini re se kjo mund të quhet shumë herë për një kornizë.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Shton një kornizë të papërpunuar në daljen e backtrace, duke përfshirë informacionin e kolonës.
    ///
    /// Kjo metodë, si e mëparshmja, merr argumentet e papërpunuara në rast se po burojnë nga vende të ndryshme.
    /// Vini re se kjo mund të quhet shumë herë për një kornizë.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia nuk është në gjendje të simbolizojë brenda një procesi kështu që ka një format të veçantë i cili mund të përdoret për të simbolizuar më vonë.
        // Shtypni atë në vend të shtypjes së adresave në formatin tonë këtu.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Nuk ka nevojë për të shtypur korniza "null", kjo në thelb thjesht do të thotë që sistemi i kthimit ishte pak i etur për të gjetur shumë larg.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Për të zvogëluar madhësinë e TCB në enklavën Sgx, ne nuk duam të zbatojmë funksionalitetin e rezolucionit të simbolit.
        // Përkundrazi, ne mund të shtypim ofsetin e adresës këtu, i cili më vonë mund të hartëzohet për të korrigjuar funksionin.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Printo indeksin e kornizës si dhe treguesin opsional të udhëzimit të kornizës.
        // Nëse jemi përtej simbolit të parë të kësaj kornize, megjithëse thjesht shtypim hapësirën e duhur të bardhë.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Tjetra shkruani emrin e simbolit, duke përdorur formatimin alternativ për më shumë informacion nëse jemi një rikthim i plotë.
        // Këtu ne gjithashtu trajtojmë simbole që nuk kanë emër,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Dhe së fundmi, shtypni numrin filename/line nëse ato janë në dispozicion.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line janë shtypur në rreshta nën emrin e simbolit, kështu që shtypni hapësirën e duhur të duhur për të rregulluar veten.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegoni në thirrjen tonë të brendshme për të shtypur emrin e skedarit dhe më pas shtypni numrin e rreshtit.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Shtoni numrin e kolonës, nëse është i disponueshëm.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Ne kujdesemi vetëm për simbolin e parë të një kornize
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}