//! Llojet e varura nga platforma.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Një përfaqësim i pavarur nga platforma i një vargu.
/// Kur punoni me `std` të aktivizuar, rekomandohet që metodat e lehtësisë për sigurimin e shndërrimeve në llojet `std`.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Një fetë, e dhënë zakonisht në platformat Unix.
    Bytes(&'a [u8]),
    /// Vargje të gjera zakonisht nga Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Humbja shndërrohet në një `Cow<str>`, do të ndahet nëse `Bytes` nuk është i vlefshëm UTF-8 ose nëse `BytesOrWideString` është `Wide`.
    ///
    /// # Karakteristikat e kërkuara
    ///
    /// Ky funksion kërkon që të aktivizohet tipari `std` i `backtrace` crate dhe tipari `std` është aktivizuar si parazgjedhje.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Siguron një përfaqësim `Path` të `BytesOrWideString`.
    ///
    /// # Karakteristikat e kërkuara
    ///
    /// Ky funksion kërkon që të aktivizohet tipari `std` i `backtrace` crate dhe tipari `std` është aktivizuar si parazgjedhje.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}