use core::ffi::c_void;
use core::fmt;

/// Inspekton thirrjen aktuale, duke kaluar të gjitha kornizat aktive në mbylljen e parashikuar për të llogaritur një gjurmë të pirgut.
///
/// Ky funksion është kali i punës i kësaj biblioteke në llogaritjen e gjurmëve të pirgjeve për një program.Mbyllja e dhënë `cb` është dhënë shembuj të një `Frame` që përfaqëson informacion në lidhje me atë kornizë thirrjeje në pirg.
/// Mbyllja jepet korniza në një mënyrë nga lart-poshtë (së fundmi të quajtur së pari funksionet).
///
/// Vlera e kthimit e mbylljes është një tregues nëse duhet të vazhdojë kthimi prapa.Një vlerë kthyese e `false` do të përfundojë kthimin prapa dhe do të kthehet menjëherë.
///
/// Sapo të fitohet një `Frame`, ju me siguri do të dëshironi të telefononi `backtrace::resolve` për të kthyer `ip` (treguesin e udhëzimit) ose adresën e simbolit në një `Symbol` përmes së cilës mund të mësohet emri dhe/ose emri i skedarit/numri i linjës.
///
///
/// Vini re se ky është një funksion relativisht i nivelit të ulët dhe nëse dëshironi, për shembull, të kapni një backtrace për t'u inspektuar më vonë, atëherë lloji `Backtrace` mund të jetë më i përshtatshmi.
///
/// # Karakteristikat e kërkuara
///
/// Ky funksion kërkon që të aktivizohet tipari `std` i `backtrace` crate dhe tipari `std` është aktivizuar si parazgjedhje.
///
/// # Panics
///
/// Ky funksion përpiqet të mos panic kurrë, por nëse `cb` siguron panics atëherë disa platforma do të detyrojnë një panic të dyfishtë të ndërpresë procesin.
/// Disa platforma përdorin një bibliotekë C e cila përdor brenda kthimin e thirrjeve të cilat nuk mund të zgjidhen, kështu që paniku nga `cb` mund të shkaktojë një ndërprerje të procesit.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // vazhdoni backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Njësoj si `trace`, vetëm i pasigurt pasi është i pasinkronizuar.
///
/// Ky funksion nuk ka garanci të sinkronizimit por është i disponueshëm kur tipari `std` i këtij crate nuk është i përpiluar.
/// Shihni funksionin `trace` për më shumë dokumente dhe shembuj.
///
/// # Panics
///
/// Shihni informacionin mbi `trace` për paralajmërimet mbi panikun `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Një trait që përfaqëson një kornizë të një backtrace, i është dhënë funksionit `trace` të këtij crate.
///
/// Mbyllja e funksionit gjurmues do të jepet korniza, dhe korniza dërgohet praktikisht pasi zbatimi themelor nuk dihet gjithmonë deri në kohën e ekzekutimit.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Kthen treguesin aktual të udhëzimeve të kësaj kornize.
    ///
    /// Ky është zakonisht udhëzimi tjetër për të ekzekutuar në kornizë, por jo të gjitha implementimet e rendisin këtë me 100% saktësi (por zakonisht është shumë afër).
    ///
    ///
    /// Rekomandohet ta kaloni këtë vlerë në `backtrace::resolve` për ta kthyer atë në një emër simboli.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Kthen treguesin aktual të pirgut të kësaj kornize.
    ///
    /// Në rast se një backend nuk mund të rimarrë treguesin e pirgut për këtë kornizë, një tregues nul kthehet.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Kthen adresën e simbolit fillestar të kornizës së këtij funksioni.
    ///
    /// Kjo do të përpiqet të rikthejë treguesin e udhëzimeve të kthyer nga `ip` në fillimin e funksionit, duke e kthyer atë vlerë.
    ///
    /// Në disa raste, megjithatë, backends thjesht do të kthejnë `ip` nga ky funksion.
    ///
    /// Vlera e kthyer ndonjëherë mund të përdoret nëse `backtrace::resolve` dështoi në `ip` të dhënë më sipër.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Kthen adresën bazë të modulit të cilit i përket korniza.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Kjo duhet të vijë së pari, për të siguruar që Miri të marrë përparësi mbi platformën pritëse
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // përdoret vetëm në dbghelp simbolizojnë
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}