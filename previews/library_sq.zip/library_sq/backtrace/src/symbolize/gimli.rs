//! Mbështetje për simbolizimin duke përdorur `gimli` crate në crates.io
//!
//! Ky është implementimi i parazgjedhur i simbolizimit për Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'jeta statike është një gënjeshtër për t'u hakuar rreth mungesës së mbështetjes për goditjet vetë-referuese.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Shndërroni në 'jetë të gjata statike pasi që simbolet duhet të marrin hua vetëm `map` dhe `stash` dhe ne po i ruajmë ato më poshtë.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Për ngarkimin e bibliotekave vendase në Windows, shihni disa diskutime për rust-lang/rust#71060 për strategjitë e ndryshme këtu.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Bibliotekat MinGW aktualisht nuk mbështesin ASLR (rust-lang/rust#16514), por DLL-të mund të zhvendosen përsëri në hapësirën e adresave.
            // Duket se adresat në informacionin e korrigjimit janë të gjitha sikur kjo bibliotekë të jetë ngarkuar në "image base", e cila është një fushë në titullin e skedarëve COFF.
            // Meqenëse kjo është ajo që duket se rendit debuginfo, ne analizojmë tabelën e simboleve dhe adresat e dyqaneve sikur biblioteka të ishte e ngarkuar edhe në "image base".
            //
            // Biblioteka mund të mos ngarkohet në "image base", megjithatë.
            // (me sa duket diçka tjetër mund të ngarkohet atje?) Këtu hyn në lojë fusha `bias` dhe ne duhet të kuptojmë vlerën e `bias` këtu.Për fat të keq, megjithëse nuk është e qartë se si ta fitojmë këtë nga një modul i ngarkuar.
            // Ajo që kemi, megjithatë, është adresa aktuale e ngarkesës (`modBaseAddr`).
            //
            // Si një cop-out për tani ne mmap skedarin, lexoni informacionin e kokës së skedarit, pastaj lëshojmë mmap.Kjo është e kotë sepse ndoshta do të rihapim më vonë mmap, por kjo duhet të funksionojë mjaft mirë tani për tani.
            //
            // Pasi të kemi `image_base` (vendndodhja e dëshiruar e ngarkesës) dhe `base_addr` (vendndodhja aktuale e ngarkesës) ne mund të plotësojmë `bias` (ndryshimi midis aktualit dhe asaj të dëshiruar) dhe atëherë adresa e deklaruar e secilit segment është `image_base` pasi që kjo është ajo që thotë skedari.
            //
            //
            // Tani për tani duket se ndryshe nga ELF/MachO ne mund të arrijmë me një segment për bibliotekë, duke përdorur `modBaseSize` si madhësi të tërë.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS përdor formatin e skedarit Mach-O dhe përdor API-të specifike për DYLD për të ngarkuar një listë të bibliotekave vendase që janë pjesë e aplikacionit.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Merrni emrin e kësaj biblioteke që korrespondon me rrugën se ku mund ta ngarkoni gjithashtu.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Vendosni kokën e imazhit të kësaj biblioteke dhe delegojeni tek `object` për të analizuar të gjitha komandat e ngarkesës në mënyrë që të kuptojmë të gjitha segmentet e përfshira këtu.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Përsërisni segmentet dhe regjistroni rajone të njohura për segmentet që gjejmë.
            // Për më tepër, regjistroni informacione për segmentet e tekstit për përpunim më vonë, shihni komentet më poshtë.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Përcaktoni "slide" për këtë bibliotekë që përfundon të jetë paragjykim që përdorim për të kuptuar se ku janë ngarkuar objektet në kujtesë.
            // Ky është paksa një llogaritje e çuditshme edhe pse dhe është rezultat i provimit të disa gjërave në natyrë dhe të shohit se çfarë ngjitet.
            //
            // Ideja e përgjithshme është që `bias` plus një segment i `stated_virtual_memory_address` do të jetë aty ku në hapësirën aktuale të adresës banon segmenti.
            // Gjëja tjetër në të cilën mbështetemi sidoqoftë është se një adresë e vërtetë minus `bias` është indeksi për të kërkuar në tabelën e simboleve dhe debuginfo.
            //
            // Sidoqoftë, rezulton se për bibliotekat e ngarkuara në sistem, këto llogaritje janë të pasakta.Për ekzekutuesit vendas, sidoqoftë, duket e saktë.
            // Duke hequr disa logjika nga burimi i LLDB, ajo ka një shtresë speciale për pjesën e parë `__TEXT` të ngarkuar nga skedari 0 me një madhësi jo zero.
            // Për çfarëdo arsye kur kjo është e pranishme, duket se do të thotë që tabela e simboleve është relativisht vetëm me diapozitivin vmaddr për bibliotekën.
            // Nëse nuk është * i pranishëm, atëherë tabela e simbolit është relativ me diapozitivin vmaddr plus adresën e deklaruar të segmentit.
            //
            // Për të trajtuar këtë situatë nëse *nuk* gjejmë një seksion teksti në zero të skedarit, atëherë ne rrisim paragjykimin nga adresa e deklaruar e seksioneve të para dhe ulim të gjitha adresat e deklaruara gjithashtu me atë shumë.
            //
            // Në atë mënyrë tabela e simboleve shfaqet gjithmonë në raport me shumën e paragjykimit të bibliotekës.
            // Kjo duket se ka rezultatet e duhura për simbolizimin përmes tabelës së simbolit.
            //
            // Sinqerisht nuk jam plotësisht i sigurt nëse kjo është e drejtë ose nëse ka diçka tjetër që duhet të tregojë se si ta bëjmë këtë.
            // Tani për tani megjithëse kjo duket se funksionon mjaft mirë (?) dhe ne gjithmonë duhet të jemi në gjendje ta rregullojmë këtë me kalimin e kohës nëse është e nevojshme.
            //
            // Për disa informacione të tjera shih #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Tjetër Unix (p.sh.
        // Platformat Linux) përdorin ELF si një format të skedarit të objektit dhe zakonisht implementojnë një API të quajtur `dl_iterate_phdr` për të ngarkuar bibliotekat vendase.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` duhet të jenë një tregues i vlefshëm.
        // `vec` duhet të jetë një tregues i vlefshëm për një `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 nuk mbështet informacionin e korrigjimit, por sistemi i ndërtimit do të vendosë informacionin e korrigjimit në rrugën `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Çdo gjë tjetër duhet të përdorë ELF, por nuk di se si të ngarkojë biblioteka vendase.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Të gjitha bibliotekat e njohura të ndara që janë ngarkuar.
    libraries: Vec<Library>,

    /// Hartat e memorjeve ku mbajmë informacionin e xhuxhit të analizuar.
    ///
    /// Kjo listë ka një kapacitet fiks për tërë kohën e saj të ngritjes, e cila nuk rritet kurrë.
    /// Elementi `usize` i secilës palë është një indeks në `libraries` sipër ku `usize::max_value()` paraqet ekzekutuesin aktual.
    ///
    /// `Mapping` është informacioni korrespondues i xhuxhit i analizuar.
    ///
    /// Vini re se kjo në thelb është një memorie memorie LRU dhe ne do t'i zhvendosim gjërat këtu pasi simbolizojmë adresat.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmentet e kësaj biblioteke janë ngarkuar në memorje dhe ku janë ngarkuar.
    segments: Vec<LibrarySegment>,
    /// "bias" e kësaj biblioteke, zakonisht aty ku është e ngarkuar në memorje.
    /// Kjo vlerë shtohet në adresën e deklaruar të secilit segment për të marrë adresën aktuale të kujtesës virtuale në të cilën është ngarkuar segmenti.
    /// Për më tepër, ky paragjykim zbritet nga adresat reale të kujtesës virtuale për të indeksuar në debuginfo dhe tabelën e simboleve.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Adresa e deklaruar e këtij segmenti në skedarin e objektit.
    /// Kjo nuk është aty ku ngarkohet segmenti, por përkundrazi kjo adresë plus bibliotekën që përmban `bias` është vendi ku mund ta gjeni.
    ///
    stated_virtual_memory_address: usize,
    /// Madhësia e segmentit Ths në memorje.
    len: usize,
}

// e pasigurt sepse kjo kërkohet të sinkronizohet nga jashtë
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // e pasigurt sepse kjo kërkohet të sinkronizohet nga jashtë
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Një memorie memorie LRU shumë e vogël, shumë e thjeshtë për hartat e informacioneve të korrigjimeve.
        //
        // Shkalla e goditjes duhet të jetë shumë e lartë, pasi grumbulli tipik nuk kalon midis shumë bibliotekave të përbashkëta.
        //
        // Strukturat `addr2line::Context` janë mjaft të kushtueshme për tu krijuar.
        // Kostoja e tij pritet të amortizohet nga pyetjet pasuese `locate`, të cilat përdorin strukturat e ndërtuara kur ndërtojnë `addr2line: : Context` për të marrë shpejtësi të këndshme.
        //
        // Nëse nuk do ta kishim këtë memorje të fshehtë, ai amortizim nuk do të ndodhte kurrë, dhe tërheqjet simbolizuese do të ishin ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Së pari, provoni nëse ky `lib` ka ndonjë segment që përmban `addr` (trajtimi i zhvendosjes).Nëse ky kontroll kalon, atëherë ne mund të vazhdojmë më poshtë dhe në fakt ta përkthejmë adresën.
                //
                // Vini re se ne jemi duke përdorur `wrapping_add` këtu për të shmangur kontrollet e tejmbushjes.Beenshtë parë në të egra që llogaritja e paragjykimit SVMA + tejmbushet.
                // Duket pak e çuditshme që do të ndodhte, por nuk ka një sasi të madhe që mund të bëjmë në lidhje me të, përveç që thjesht të injorojmë ato segmente, pasi ato ka të ngjarë të drejtohen në hapësirë.
                //
                // Kjo fillimisht doli në rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Tani që e dimë që `lib` përmban `addr`, ne mund të kompensojmë me paragjykimin për të gjetur adresën e përmendur të kujtesës virutale.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Pavarur: pasi kjo gjendje plotësohet pa u kthyer herët
        // nga një gabim, hyrja e memorjes së fshehtë për këtë rrugë është në indeksin 0.

        if let Some(idx) = idx {
            // Kur hartëzimi është tashmë në memorje të fshehtë, zhvendoseni atë përpara.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Kur hartëzimi nuk është në memorje memorie, krijoni një hartë të re, futeni në pjesën e përparme të memorjes së fshehtë dhe dëboni hyrjen më të vjetër të memorjes së fshehtë nëse është e nevojshme.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // mos rrjedhni jetëgjatësi `'static`, sigurohuni që ajo të jetë e përcaktuar vetëm për ne
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Zgjatni jetëgjatësinë e `sym` në `'static` pasi që fatkeqësisht na kërkohet këtu, por gjithnjë po del si referencë kështu që asnjë referencë për të nuk duhet të vazhdojë përtej këtij kuadri gjithsesi.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Në fund, merrni një hartë të memorizuar ose krijoni një hartë të re për këtë skedar, dhe vlerësoni informacionin DWARF për të gjetur file/line/name për këtë adresë.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Ne ishim në gjendje të lokalizonim informacionin e kornizës për këtë simbol, dhe korniza e `addr2line` brenda saj ka të gjitha detajet e guximshme.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Nuk mund të gjesh informacionin e korrigjimit të gabimeve, por i gjetëm në tabelën e simboleve të kukudhit të ekzekutueshëm.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}