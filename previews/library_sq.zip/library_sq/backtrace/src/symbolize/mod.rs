use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Zgjidh një adresë në një simbol, duke kaluar simbolin në mbylljen e specifikuar.
///
/// Ky funksion do të kërkojë adresën e dhënë në zona të tilla si tabela lokale e simboleve, tabela dinamike e simboleve, ose informacioni i korrigjimit të gabimeve DWARF (në varësi të implementimit të aktivizuar) për të gjetur simbolet që japin.
///
///
/// Mbyllja nuk mund të thirret nëse rezolucioni nuk mund të kryhet, dhe gjithashtu mund të thirret më shumë se një herë në rastin e funksioneve të nënvizuara.
///
/// Simbolet e dhëna paraqesin ekzekutimin në `addr` të specifikuar, duke kthyer çiftet file/line për atë adresë (nëse ka).
///
/// Vini re se nëse keni një `Frame` atëherë rekomandohet të përdorni funksionin `resolve_frame` në vend të këtij.
///
/// # Karakteristikat e kërkuara
///
/// Ky funksion kërkon që të aktivizohet tipari `std` i `backtrace` crate dhe tipari `std` është aktivizuar si parazgjedhje.
///
/// # Panics
///
/// Ky funksion përpiqet të mos panic kurrë, por nëse `cb` siguron panics atëherë disa platforma do të detyrojnë një panic të dyfishtë të ndërpresë procesin.
/// Disa platforma përdorin një bibliotekë C e cila përdor brenda kthimin e thirrjeve të cilat nuk mund të zgjidhen, kështu që paniku nga `cb` mund të shkaktojë një ndërprerje të procesit.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // shikoni vetëm kornizën e sipërme
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Zgjidh një kornizë të kapur më parë në një simbol, duke kaluar simbolin në mbylljen e specifikuar.
///
/// Ky funktin kryen të njëjtin funksion si `resolve` përveç që merr një `Frame` si argument në vend të një adrese.
/// Kjo mund të lejojë disa zbatime të platformës së kthimit të informacionit për të siguruar informacion më të saktë të simboleve ose informacion në lidhje me kornizat inline për shembull.
///
/// Rekomandohet të përdorni këtë nëse keni mundësi.
///
/// # Karakteristikat e kërkuara
///
/// Ky funksion kërkon që të aktivizohet tipari `std` i `backtrace` crate dhe tipari `std` është aktivizuar si parazgjedhje.
///
/// # Panics
///
/// Ky funksion përpiqet të mos panic kurrë, por nëse `cb` siguron panics atëherë disa platforma do të detyrojnë një panic të dyfishtë të ndërpresë procesin.
/// Disa platforma përdorin një bibliotekë C e cila përdor brenda kthimin e thirrjeve të cilat nuk mund të zgjidhen, kështu që paniku nga `cb` mund të shkaktojë një ndërprerje të procesit.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // shikoni vetëm kornizën e sipërme
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Vlerat IP nga kornizat e pirgut janë zakonisht (always?) udhëzimi *pas* thirrjes që është gjurma aktuale e pirgut.
// Simbolizimi i kësaj bën që numri filename/line të jetë një përpara dhe ndoshta në zbrazëti nëse është afër fundit të funksionit.
//
// Kjo duket se në thelb gjithmonë ndodh në të gjitha platformat, kështu që ne gjithmonë e heqim një nga një IP të zgjidhur për ta zgjidhur atë në udhëzimin e thirrjes së mëparshme në vend që t'i kthehet udhëzimi.
//
//
// Idealisht nuk do ta bënim këtë.
// Në mënyrë ideale, ne do të kërkojmë që telefonuesit e API-ve `resolve` këtu të bëjnë manualisht -1 dhe të marrin parasysh që ata duan informacione për vendndodhjen për udhëzimet * e mëparshme, jo për ato aktuale.
// Idealisht ne do të ekspozonim edhe në `Frame` nëse vërtet jemi adresa e udhëzimit tjetër ose rrymës.
//
// Tani për tani megjithëse ky është një shqetësim mjaft i mirë, kështu që ne vetëm brendësisht zbresim një.
// Konsumatorët duhet të vazhdojnë të punojnë dhe të marrin rezultate mjaft të mira, kështu që ne duhet të jemi mjaft të mirë.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Njësoj si `resolve`, vetëm i pasigurt pasi është i pasinkronizuar.
///
/// Ky funksion nuk ka garanci të sinkronizimit por është i disponueshëm kur tipari `std` i këtij crate nuk është i përpiluar.
/// Shihni funksionin `resolve` për më shumë dokumente dhe shembuj.
///
/// # Panics
///
/// Shihni informacionin mbi `resolve` për paralajmërimet mbi panikun `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Njësoj si `resolve_frame`, vetëm i pasigurt pasi është i pasinkronizuar.
///
/// Ky funksion nuk ka garanci të sinkronizimit por është i disponueshëm kur tipari `std` i këtij crate nuk është i përpiluar.
/// Shihni funksionin `resolve_frame` për më shumë dokumente dhe shembuj.
///
/// # Panics
///
/// Shihni informacionin mbi `resolve_frame` për paralajmërimet mbi panikun `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Një trait që përfaqëson rezolucionin e një simboli në një skedar.
///
/// Ky trait jepet si një objekt trait për mbylljen dhënë funksionit `backtrace::resolve`, dhe është dërguar praktikisht pasi nuk dihet cili implementim qëndron pas tij.
///
///
/// Një simbol mund të japë informacione kontekstuale në lidhje me një funksion, për shembull emrin, emrin e skedarit, numrin e rreshtit, adresën e saktë, etj.
/// Jo të gjitha informacionet janë gjithmonë të disponueshme në një simbol, megjithatë, kështu që të gjitha metodat kthejnë një `Option`.
///
///
pub struct Symbol {
    // TODO: kjo lidhje e përjetshme duhet të vazhdojë përfundimisht në `Symbol`,
    // por aktualisht kjo është një ndryshim thelbësor.
    // Tani për tani kjo është e sigurt pasi që `Symbol` shpërndahet vetëm me referencë dhe nuk mund të klonohet.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Kthen emrin e këtij funksioni.
    ///
    /// Struktura e kthyer mund të përdoret për të kërkuar veti të ndryshme në lidhje me emrin e simbolit:
    ///
    ///
    /// * Zbatimi `Display` do të shtypë simbolin e zbërthyer.
    /// * Vlera e papërpunuar `str` e simbolit mund të arrihet (nëse është e vlefshme utf-8).
    /// * Mund të arrihen bajtet e papërpunuara për emrin e simbolit.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Kthen adresën fillestare të këtij funksioni.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Kthen emrin e skedarit të papërpunuar si një fetë.
    /// Kjo është kryesisht e dobishme për mjediset `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Kthen numrin e kolonës për vendin ku ekzekutohet aktualisht ky simbol.
    ///
    /// Vetëm gimli aktualisht ofron një vlerë këtu dhe madje edhe atëherë vetëm nëse `filename` kthen `Some`, dhe kështu që rrjedhimisht i nënshtrohet paralajmërimeve të ngjashme.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Kthen numrin e rreshtit për vendin ku ekzekuton aktualisht ky simbol.
    ///
    /// Kjo vlerë kthyese zakonisht është `Some` nëse `filename` kthen `Some`, dhe si pasojë i nënshtrohet paralajmërimeve të ngjashme.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Kthen emrin e skedarit ku është përcaktuar ky funksion.
    ///
    /// Kjo aktualisht është në dispozicion vetëm kur përdoret libbacktrace ose gimli (p.sh.
    /// unix platforma të tjera) dhe kur një binar përpilohet me debuginfo.
    /// Nëse asnjë nga këto kushte nuk plotësohet, atëherë kjo ka të ngjarë të kthejë `None`.
    ///
    /// # Karakteristikat e kërkuara
    ///
    /// Ky funksion kërkon që të aktivizohet tipari `std` i `backtrace` crate dhe tipari `std` është aktivizuar si parazgjedhje.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Ndoshta një simbol i analizuar C++ , nëse analizimi i simbolit të copëzuar pasi Rust dështoi.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Sigurohuni që ta mbani këtë me madhësi zero, në mënyrë që tipari `cpp_demangle` të mos ketë kosto kur është me aftësi të kufizuara.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Një mbështjellës rreth një emri simbol për të siguruar aksesorë ergonomikë të emrit të zbërthyer, bajteve të papërpunuara, vargut të papërpunuar, etj.
///
// Lejoni kodin e vdekur kur funksioni `cpp_demangle` nuk është i aktivizuar.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Krijon një emër të ri simboli nga bajtet e papërpunuara themelorë.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Kthen emrin e papërpunuar të simbolit (mangled) si `str` nëse simboli është i vlefshëm utf-8.
    ///
    /// Përdorni zbatimin `Display` nëse dëshironi versionin e zbërthyer.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Kthen emrin e simbolit të papërpunuar si një listë bajtesh
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Kjo mund të shtypet nëse simboli i zbërthyer nuk është i vlefshëm, prandaj trajtojeni gabimin këtu me hijeshi duke mos e përhapur atë jashtë.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Përpjekje për të rimarrë atë memorje të memorizuar të përdorur për të simbolizuar adresat.
///
/// Kjo metodë do të përpiqet të lëshojë çdo strukturë globale të të dhënave që përndryshe janë grumbulluar globalisht ose në fije që zakonisht përfaqëson informacionin e analizuar të DWARF ose të ngjashme.
///
///
/// # Caveats
///
/// Ndërsa ky funksion është gjithmonë i disponueshëm, ai në të vërtetë nuk bën asgjë në shumicën e implementimeve.
/// Bibliotekat si dbghelp ose libbacktrace nuk ofrojnë lehtësira për të shpërndarë gjendjen dhe për të menaxhuar kujtesën e caktuar.
/// Tani për tani tipari `gimli-symbolize` i këtij crate është tipari i vetëm ku ky funksion ka ndonjë efekt.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}