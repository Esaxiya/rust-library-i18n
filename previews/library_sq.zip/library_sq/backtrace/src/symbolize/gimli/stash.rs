// përdoret vetëm në Linux tani, kështu që lejoni kodin e vdekur diku tjetër
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Një alokues i thjeshtë i arenës për buffer bajtesh.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Alokon një buffer të madhësisë së specifikuar dhe i kthen një referencë të ndryshueshme.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SIGURIA: ky është funksioni i vetëm që ndërton ndonjëherë një mjet të ndryshueshëm
        // referimi i `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SIGURIA: ne kurrë nuk heqim elemente nga `self.buffers`, kështu që një referencë
        // te të dhënat brenda çdo buffer do të jetojnë për aq kohë sa `self` bën.
        &mut buffers[i]
    }
}