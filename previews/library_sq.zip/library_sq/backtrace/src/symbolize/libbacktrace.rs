//! Strategjia e simbolizimit duke përdorur kodin analizues të DWARF në libbacktrace.
//!
//! Biblioteka libbacktrace C, e shpërndarë në mënyrë tipike me gcc, mbështet jo vetëm gjenerimin e një backtrace (të cilën ne nuk e përdorim në të vërtetë) por gjithashtu simbolizon backtrace dhe trajtimin e informacionit të korrigjimit të xhuxhit për gjëra të tilla si kornizat e rreshtuara dhe çfarë jo.
//!
//!
//! Kjo është relativisht e komplikuar për shkak të shumë shqetësimeve të ndryshme këtu, por ideja themelore është:
//!
//! * Së pari ne e quajmë `backtrace_syminfo`.Ky merr informacionin e simbolit nga tabela dinamike e simbolit nëse mundemi.
//! * Tjetra ne e quajmë `backtrace_pcinfo`.Kjo do të analizojë tabelat e debuginfo nëse ato janë në dispozicion dhe na lejon të rimarrim informacionin në lidhje me kornizat inline, emrat e skedarëve, numrat e linjës, etj.
//!
//! Ka shumë hile në lidhje me futjen e tabelave xhuxh në gjurmët e kthimit, por shpresojmë se nuk është fundi i botës dhe është mjaft i qartë kur lexoni më poshtë.
//!
//! Kjo është strategjia e paracaktuar e simbolizimit për platformat jo-MSVC dhe jo-OSX.Në libstd edhe pse kjo është strategjia e paracaktuar për OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Nëse është e mundur, preferoni emrin `function` i cili vjen nga debuginfo dhe zakonisht mund të jetë më i saktë për kornizat inline për shembull.
                // Nëse kjo nuk është e pranishme, përsëri kthehuni në emrin e tabelës simbol të specifikuar në `symname`.
                //
                // Vini re se nganjëherë `function` mund të ndjehet disi më pak i saktë, për shembull duke u renditur si `try<i32,closure>` në vend të `std::panicking::try::do_call`.
                //
                // Nuk është vërtet e qartë pse, por në përgjithësi emri `function` duket më i saktë.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // mos bej asgje per tani
}

/// Lloji i treguesit `data` i kaluar në `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Pasi të thirret kjo kthim thirrje nga `backtrace_syminfo` kur fillojmë të zgjidhim, shkojmë më tej për të thirrur `backtrace_pcinfo`.
    // Funksioni `backtrace_pcinfo` do të konsultojë informacionin e korrigjimit të gabimeve dhe do të përpiqet të bëjë gjëra të tilla si rikuperimi i informacionit file/line, si dhe kornizat e thella.
    // Vini re megjithatë se `backtrace_pcinfo` mund të dështojë ose të mos bëjë shumë nëse nuk ka informacion për korrigjimin e gabimeve, kështu që nëse kjo ndodh, ne jemi të sigurt për të thirrur thirrjen me të paktën një simbol nga `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Lloji i treguesit `data` i kaluar në `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API-ja libbacktrace mbështet krijimin e një shteti, por nuk mbështet shkatërrimin e një shteti.
// Unë personalisht e kuptoj këtë që një shtet duhet të krijohet dhe të jetojë përgjithmonë.
//
// Unë do të doja të regjistroja një mbajtës at_exit() i cili pastron këtë gjendje, por libbacktrace nuk ofron asnjë mënyrë për ta bërë këtë.
//
// Me këto kufizime, ky funksion ka një gjendje statike të memorizuar që llogaritet herën e parë që kërkohet.
//
// Mos harroni se tërheqja e të gjitha gjërave ndodh serikisht (një bllokim global).
//
// Vini re mungesa e sinkronizimit këtu është për shkak të kërkesës që `resolve` të sinkronizohet nga jashtë.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Mos ushtroni aftësi fijesh të sigurta të libbacktrace pasi që ne gjithmonë e quajmë atë në një mënyrë të sinkronizuar.
        //
        0,
        error_cb,
        ptr::null_mut(), // nuk ka të dhëna shtesë
    );

    return STATE;

    // Vini re se që libbacktrace të funksionojë fare, duhet të gjejë informacionin e korrigjimit të DWARF për ekzekutuesin aktual.Zakonisht e bën këtë përmes një numri mekanizmash, duke përfshirë, por pa u kufizuar në:
    //
    // * /proc/self/exe në platformat e mbështetura
    // * Emri i skedarit kaloi qartë kur krijon gjendje
    //
    // Biblioteka libbacktrace është një tufë e madhe e kodit C.Kjo natyrisht do të thotë se ka dobësi të sigurisë në memorje, veçanërisht kur merreni me debuginfo të keqformuar.
    // Historikisht Libstd ka hasur në shumë prej tyre.
    //
    // Nëse përdoret /proc/self/exe, ne zakonisht mund t'i injorojmë këto pasi supozojmë se libbacktrace është "mostly correct" dhe përndryshe nuk bën gjëra të çuditshme me informacionin e korrigjimit të xhuxhit "attempted to be correct".
    //
    //
    // Sidoqoftë, nëse kalojmë në një emër skedari, atëherë është e mundur në disa platforma (si BSD) ku një aktor me qëllim të keq mund të shkaktojë vendosjen e një skedari arbitrar në atë vend.
    // Kjo do të thotë që nëse i tregojmë libbacktrace për një emër skedari, mund të jetë duke përdorur një skedar arbitrar, duke shkaktuar segfaault.
    // Nëse nuk i themi libbacktrace ndonjë gjë, atëherë atëherë ajo nuk do të bëjë asgjë në platformat që nuk mbështesin shtigje si /proc/self/exe!
    //
    // Duke pasur parasysh të gjitha ato, ne përpiqemi sa më shumë që të jetë e mundur që *të mos* kalojmë në një emër skedari, por duhet të futemi në platformat që nuk mbështesin aspak /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Vini re se në mënyrë ideale do të përdorim `std::env::current_exe`, por nuk mund të kërkojmë `std` këtu.
            //
            // Përdorni `_NSGetExecutablePath` për të ngarkuar shtegun aktual të ekzekutueshëm në një zonë statike (e cila nëse është shumë e vogël, hiqni dorë).
            //
            //
            // Vini re se ne po besojmë seriozisht në kthimin këtu për të mos vdekur nga ekzekutuesit e korruptuar, por sigurisht që po ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ka një mënyrë të hapjes së skedarëve ku pasi është hapur nuk mund të fshihet.
            // Kjo është në përgjithësi ajo që duam këtu, sepse duam të sigurohemi që ekzekutuesja jonë të mos ndryshojë nga poshtë nesh pasi ta dorëzojmë atë në kthim, duke shpresuar në zbutjen e aftësisë për të kaluar në të dhëna arbitrare në gjurmët e kthimit (të cilat mund të keqpërdoren).
            //
            //
            // Duke pasur parasysh që ne bëjmë pak vallëzim këtu për t'u përpjekur të marrim një lloj bllokimi të imazhit tonë:
            //
            // * Merrni një dorezë në procesin aktual, ngarkoni emrin e skedarit.
            // * Hapni një skedar në atë emër skedari me flamujt e duhur.
            // * Riparko emrin e skedarit të procesit aktual, duke u siguruar që është e njëjtë
            //
            // Nëse të gjitha kalojnë, ne në teori me të vërtetë kemi hapur dosjen e procesit tonë dhe jemi të garantuar se nuk do të ndryshojë.FWIW një pjesë e kësaj është kopjuar nga libstd historikisht, kështu që ky është interpretimi im më i mirë i asaj që po ndodhte.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Kjo jeton në kujtesën statike kështu që ne mund ta kthejmë atë.
                static mut BUF: [i8; N] = [0; N];
                // ... dhe kjo jeton në pirg pasi është e përkohshme
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // rrjedhim qëllimisht `handle` këtu sepse duke pasur atë të hapur duhet të ruajë bllokimin tonë në këtë emër skedari.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Ne duam të kthejmë një fetë që përfundon nul, kështu që nëse gjithçka është plotësuar dhe është e barabartë me gjatësinë totale, atëherë barazojeni atë me dështimin.
                //
                //
                // Përndryshe, kur të ktheni suksesin, sigurohuni që bajati nul të përfshihet në fetë.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // gabimet e kthimit aktualisht janë përfshirë nën qilim
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Thirrni `backtrace_syminfo` API i cili (nga leximi i kodit) duhet të telefonojë `syminfo_cb` saktësisht një herë (ose të dështojë me një gabim me sa duket).
    // Ne pastaj trajtojmë më shumë brenda `syminfo_cb`.
    //
    // Vini re se ne e bëjmë këtë pasi që `syminfo` do të konsultohet me tabelën e simboleve, duke gjetur emra simbolesh edhe nëse nuk ka asnjë informacion korrigjimi në binar.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}