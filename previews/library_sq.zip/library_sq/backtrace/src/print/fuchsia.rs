use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr merr një përgjigje që do të marrë një tregues dl_phdr_info për çdo OSSH që është lidhur në proces.
    // dl_iterate_phdr gjithashtu siguron që lidhësi dinamik të jetë i kyçur nga fillimi në fund të përsëritjes.
    // Nëse kthimi i kthimit jep një vlerë jo zero, përsëritja përfundon herët.
    // 'data' do të kalojë si argumenti i tretë në kthimin e thirrjes në secilën thirrje.
    // 'size' jep madhësinë e dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Ne duhet të analizojmë ID-në e ndërtimit dhe disa të dhëna themelore të kokës së programit që do të thotë se na duhen pak gjëra edhe nga specifikimi i ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Tani duhet të replikojmë, bit për bit, strukturën e tipit dl_phdr_info të përdorur nga lidhësi dinamik aktual i fuchsia-s.
// Chromium gjithashtu ka këtë kufi ABI si dhe crashpad.
// Përfundimisht, ne do të dëshironim t'i zhvendosnim këto raste për të përdorur kërkimin e kukudhëve, por do të na duhej ta siguronim atë në SDK dhe kjo nuk është bërë ende.
//
// Kështu që ne (dhe ata) jemi të detyruar të përdorim këtë metodë e cila shkakton një bashkim të ngushtë me fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Ne nuk kemi asnjë mënyrë për të ditur të kontrollojmë nëse e_phoff dhe e_phnum janë të vlefshme.
    // libc duhet ta sigurojë këtë për ne, megjithatë kështu që është e sigurt të krijosh një fetë këtu.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr përfaqëson një kokë programi ELF 64-bit në endianitetin e arkitekturës së synuar.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr përfaqëson një titull të vlefshëm të programit ELF dhe përmbajtjen e tij.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Ne nuk kemi asnjë mënyrë për të kontrolluar nëse p_addr ose p_memsz janë të vlefshme.
    // Libc-i i Fuchsia-s analizon së pari shënimet, megjithatë, për shkak të të qenit këtu, këto koka duhet të jenë të vlefshme.
    //
    // ShënimIter nuk kërkon që të dhënat themelore të jenë të vlefshme, por kërkon që kufijtë të jenë të vlefshëm.
    // Ne kemi besim se libc ka siguruar që kjo të jetë rasti për ne këtu.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Lloji i shënimit për ID-të e ndërtimit.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr përfaqëson një titull shënimi ELF në fundin e synimit.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Shënimi përfaqëson një shënim ELF (kokë + përmbajtje).
// Emri lihet si një fetë u8 sepse nuk mbaron gjithmonë nul dhe rust e bën mjaft të lehtë për të kontrolluar që bajtet përputhen gjithsesi.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter ju lejon të përsërisni në mënyrë të sigurt mbi një segment shënimi.
// Përfundon sa më shpejt që të ndodhë një gabim ose nuk ka më shënime.
// Nëse përsërisni mbi të dhëna të pavlefshme, ato do të funksionojnë sikur nuk u gjetën shënime.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Isshtë një funksion i pandryshueshëm që treguesi dhe madhësia e dhënë tregojnë një gamë të vlefshme bajtesh që mund të lexohen të gjitha.
    // Përmbajtja e këtyre bajtëve mund të jetë gjithçka, por diapazoni duhet të jetë i vlefshëm që kjo të jetë e sigurt.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to përafron 'x' me rreshtimin 'në' bajt duke supozuar se 'to' është një fuqi prej 2.
// Kjo ndjek një model standard në kodin e analizës C/C ++ ELF ku përdoret (x + në, 1)&-to.
// Rust nuk ju lejon të mohoni përdorimin kështu që unë përdor
// Konvertimi i komplementit 2 për të rikrijuar atë.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 konsumon num bajtësh nga feta (nëse është e pranishme) dhe gjithashtu siguron që feta përfundimtare të jetë në rregull.
// Nëse një ose numri i bajteve të kërkuara është shumë i madh ose feta nuk mund të ridrejtohet më pas për shkak të mos ekzistimit të mjaftueshëm të bajteve, Asnjë nuk kthehet dhe feta nuk modifikohet.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ky funksion nuk ka ndryshime të vërteta që thirrësi duhet të mbajë përveç se ndoshta 'bytes' duhet të rreshtohet për performancë (dhe për korrektësinë e disa arkitekturave).
// Vlerat në fushat Elf_Nhdr mund të jenë të pakuptimta, por ky funksion nuk siguron diçka të tillë.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Kjo është e sigurt për sa kohë që ka hapësirë të mjaftueshme dhe ne sapo konfirmuam që në deklaratën if më lart, kjo nuk duhet të jetë e pasigurt.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Vini re se sice_of: :<Elf_Nhdr>() është gjithmonë i rreshtuar me 4 bajt.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Kontrolloni nëse kemi arritur në fund.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Ne shndërrojmë një nhdr por ne me kujdes e konsiderojmë strukturën që rezulton.
        // Ne nuk i besojmë namesz ose descsz dhe nuk marrim vendime të pasigurta bazuar në llojin.
        //
        // Pra, edhe nëse nxjerrim mbeturina të plota, ne duhet të jemi të sigurt.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Tregon që një segment është i ekzekutueshëm.
const PERM_X: u32 = 0b00000001;
/// Tregon që një segment është i shkruar.
const PERM_W: u32 = 0b00000010;
/// Tregon që një segment është i lexueshëm.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Përfaqëson një segment ELF gjatë kohës së ekzekutimit.
struct Segment {
    /// Jep adresën virtuale të ekzekutimit të përmbajtjes së këtij segmenti.
    addr: usize,
    /// Jep madhësinë e kujtesës së përmbajtjes së këtij segmenti.
    size: usize,
    /// Jep adresën virtuale të modulit të këtij segmenti me skedarin ELF.
    mod_rel_addr: usize,
    /// Jep lejet e gjetura në skedarin ELF.
    /// Sidoqoftë, këto leje nuk janë domosdoshmërisht lejet e pranishme gjatë kohës së ekzekutimit.
    flags: Perm,
}

/// Lejon një përsëritje të segmenteve nga një OSSH.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Përfaqëson një ELF DSO (Objekt Dinamik i Përbashkët).
/// Ky lloj i referohet të dhënave të ruajtura në OSSH aktuale në vend që të bëjë kopjen e vet.
struct Dso<'a> {
    /// Lidhësi dinamik gjithmonë na jep një emër, edhe nëse emri është bosh.
    /// Në rastin e ekzekutueses kryesore, ky emër do të jetë bosh.
    /// Në rastin e një objekti të përbashkët do të jetë soname (shih DT_SONAME).
    name: &'a str,
    /// Në Fuchsia praktikisht të gjithë binaret kanë ID të ndërtuar por kjo nuk është një kërkesë e rreptë.
    /// Nuk ka asnjë mënyrë për të krahasuar informacionin e OSSH-së me një skedar të vërtetë ELF më pas nëse nuk ka ndonjë ndërtesë_idhënëse, kështu që ne kërkojmë që çdo OSSH të ketë një këtu.
    ///
    /// OSS-të pa një ndërtesë_idhënie injorohen.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Kthen një iterator mbi segmentet në këtë OSSH.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Këto gabime kodojnë çështjet që lindin gjatë analizimit të informacionit për secilin OSSH.
///
enum Error {
    /// NameError do të thotë se ndodhi një gabim gjatë shndërrimit të një vargu të stilit C në një varg rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError do të thotë që ne nuk gjetëm një ID të ndërtimit.
    /// Kjo mund të jetë sepse OSSH nuk kishte ID të ndërtimit ose sepse segmenti që përmban ID-në e ndërtimit ishte keqformuar.
    ///
    BuildIDError,
}

/// Thirrjet ose 'dso' ose 'error' për secilin OSSH të lidhur në proces nga lidhësi dinamik.
///
///
/// # Arguments
///
/// * `visitor` - Një DsoPrinter që do të ketë njërën nga metodat që quhet OSS e foreach.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr siguron që info.name do të tregojë në një vendndodhje të vlefshme.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ky funksion shtyp shtypjen e simbolizuesit Fuchsia për të gjithë informacionin që përmbahet në një OSSH.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}