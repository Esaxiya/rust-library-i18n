//! Një bibliotekë mbështetëse për makro autorët kur përcaktojnë makrot e reja.
//!
//! Kjo bibliotekë, e siguruar nga shpërndarja standarde, siguron llojet e konsumuara në ndërfaqet e makro përkufizimeve të përcaktuara procedurale siç janë makrot `#[proc_macro]` të ngjashme me funksionet, atributet makro `#[proc_macro_attribute]` dhe atributet e derivuara me porosi "#[proc_macro_derive]".
//!
//!
//! Shihni [the book] për më shumë.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Përcakton nëse proc_macro është bërë i arritshëm për programin që po ekzekutohet aktualisht.
///
/// Proc_macro crate është menduar vetëm për përdorim brenda implementimit të makrove procedurale.Të gjitha funksionet në këtë crate panic nëse thirren nga një makro procedurale, të tilla si nga një skenar i ndërtimit ose provë njësie ose binari i zakonshëm Rust.
///
/// Me konsideratë për bibliotekat Rust që janë krijuar për të mbështetur rastet e përdorimit makro dhe jo-makro, `proc_macro::is_available()` siguron një mënyrë jo-panik për të zbuluar nëse infrastruktura e nevojshme për të përdorur API të proc_macro aktualisht është e disponueshme.
/// Kthehet true nëse thirret nga brenda një makro procedurale, false nëse thirret nga ndonjë binar tjetër.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Lloji kryesor i siguruar nga kjo crate, që përfaqëson një rrjedhë abstrakte të tokens, ose, më konkretisht, një sekuencë të pemëve token.
/// Lloji siguron ndërfaqe për përsëritjen e atyre pemëve token dhe, anasjelltas, mbledhjen e një numri të pemëve token në një rrjedhë.
///
///
/// Kjo është si hyrja ashtu edhe dalja e përkufizimeve `#[proc_macro]`, `#[proc_macro_attribute]` dhe `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Gabimi i kthyer nga `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Kthen një `TokenStream` të zbrazët që nuk përmban pemë token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Kontrollon nëse ky `TokenStream` është bosh.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Përpjekjet për të thyer vargun në tokens dhe analizuar ato tokens në një rrjedhë token.
/// Mund të dështojë për një numër arsyesh, për shembull, nëse vargu përmban përcaktues të paekuilibruar ose karaktere që nuk ekzistojnë në gjuhë.
///
/// Të gjithë tokens në transmetimin e analizuar marrin hapësira `Span::call_site()`.
///
/// NOTE: disa gabime mund të shkaktojnë panics në vend që të kthejnë `LexError`.Ne rezervojmë të drejtën t'i ndryshojmë këto gabime në `LexError` më vonë.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, ura siguron vetëm `to_string`, zbato `fmt::Display` bazuar në të (e kundërta e marrëdhënies së zakonshme midis të dyve).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Shtyp rrjedhën token si një varg që supozohet se mund të konvertohet pa humbje përsëri në të njëjtën rrjedhë token (hapësira modulesh), me përjashtim të `TokenTree: : Group` me ndarës `Delimiter::None` dhe fjalë për fjalë numerike negative.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Shtyp token në një formë të përshtatshme për korrigjimin e gabimeve.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Krijon një transmetim token që përmban një pemë të vetme token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Mbledh një numër pemësh token në një rrjedhë të vetme.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Një operacion "flattening" në rrjedhat token, mbledh pemët token nga rryma të shumta token në një rrjedhë të vetme.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Përdorni një implementim të optimizuar if/when të mundshëm.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Detaje të implementimit publik për llojin `TokenStream`, siç janë përsëritësit.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Një përsëritës mbi `TokenTree` të`TokenStream`.
    /// Përsëritja është "shallow", p.sh., iteratori nuk rikuperohet në grupe të kufizuara, dhe kthen grupe të tëra si pemë token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` pranon tokens arbitrar dhe zgjerohet në një `TokenStream` duke përshkruar hyrjen.
/// Për shembull, `quote!(a + b)` do të prodhojë një shprehje, që, kur vlerësohet, ndërton `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unkotimi bëhet me `$`, dhe funksionon duke marrë identitetin e vetëm të ardhshëm si term të pakotuar.
/// Për të cituar vetë `$`, përdorni `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Një rajon i kodit burimor, së bashku me informacionin për zgjerimin makro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Krijon një `Diagnostic` të ri me `message` të dhënë në hapësirën `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Një hapësirë që zgjidhet në sitin e përcaktimit makro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Hapësira e thirrjes së makros aktuale procedurale.
    /// Identifikuesit e krijuar me këtë hapësirë do të zgjidhen sikur të ishin shkruar direkt në vendndodhjen e thirrjes makro (higjiena e faqes së thirrjes) dhe kodi tjetër në sitin e thirrjes makro do të jetë në gjendje t'u referohet atyre gjithashtu.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Një hapësirë që përfaqëson higjienën `macro_rules`, dhe nganjëherë zgjidhet në vendin e përcaktimit makro (ndryshoret lokale, etiketat, `$crate`) dhe nganjëherë në faqen e thirrjeve makro (gjithçka tjetër).
    ///
    /// Vendndodhja e hapësirës është marrë nga faqja e thirrjes.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Skedari origjinal burim në të cilin tregon kjo hapësirë.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` për tokens në zgjerimin e mëparshëm makro nga i cili u krijua `self`, nëse ka.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Hapësira për kodin burim origjinal nga i cili është gjeneruar `self`.
    /// Nëse kjo `Span` nuk është gjeneruar nga zgjerime të tjera makro, vlera e kthimit është e njëjtë me `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Merr line/column fillestar në skedarin burimor për këtë hapësirë.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Merr përfundimin line/column në skedarin burimor për këtë hapësirë.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Krijon një hapësirë të re që përfshin `self` dhe `other`.
    ///
    /// Kthen `None` nëse `self` dhe `other` janë nga skedarë të ndryshëm.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Krijon një hapësirë të re me të njëjtin informacion line/column si `self` por që zgjidh simbolet sikur të ishin në `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Krijon një hapësirë të re me të njëjtën sjellje të rezolucionit të emrit si `self` por me informacionin line/column të `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Krahasohet me shtrirjet për të parë nëse janë të barabartë.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Kthen tekstin burimor prapa një hapësire.
    /// Kjo ruan kodin origjinal të burimit, duke përfshirë hapësira dhe komente.
    /// Ai kthen një rezultat vetëm nëse hapësira i korrespondon kodit real të burimit.
    ///
    /// Note: Rezultati i vëzhgueshëm i një makro duhet të mbështetet vetëm në tokens dhe jo në këtë tekst burimor.
    ///
    /// Rezultati i këtij funksioni është një përpjekje më e mirë për t'u përdorur vetëm për diagnostikim.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Shtyp një hapësirë në një formë të përshtatshme për korrigjimin e gabimeve.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Një palë kolonë vijash që përfaqëson fillimin ose mbarimin e një `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Linja e indeksuar 1 në skedarin burimor në të cilin hapësira fillon ose mbaron (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Kolona e indeksuar 0 (me karaktere UTF-8) në skedarin burimor në të cilin hapësira fillon ose mbaron (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Skedari burimor i një `Span` të dhënë.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Merr rrugën për në këtë skedar burimor.
    ///
    /// ### Note
    /// Nëse hapësira e kodit e lidhur me këtë `SourceFile` është gjeneruar nga një makro e jashtme, kjo makro, kjo mund të mos jetë një rrugë aktuale në sistemin e skedarëve.
    /// Përdorni [`is_real`] për të kontrolluar.
    ///
    /// Gjithashtu vini re se edhe nëse `is_real` kthen `true`, nëse `--remap-path-prefix` është kaluar në rreshtin e komandës, rruga siç është dhënë mund të mos jetë në të vërtetë e vlefshme.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Kthen `true` nëse kjo skedar burim është një skedar burimor i vërtetë, dhe jo i krijuar nga zgjerimi i një makroje të jashtme.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Ky është një kollë e thatë derisa të zbatohen hapësirat ndër-bashkiake dhe ne mund të kemi skedarë burim të vërtetë për shtrirjet e krijuara në makrot e jashtme.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Një token i vetëm ose një sekuencë e kufizuar e pemëve token (p.sh., `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Një rrjedhë token e rrethuar nga ndarësa kllapash.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Një identifikues.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Një karakter i vetëm pikësimi ("+", `,`, `$`, etj.)
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Një karakter letrar (`'a'`), vargu (`"hello"`), numri (`2.3`), etj.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Kthen hapësirën e kësaj peme, duke deleguar në metodën `span` të token të përmbajtura ose një rryme të kufizuar.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfiguron hapësirën për *vetëm këtë token*.
    ///
    /// Vini re se nëse kjo token është `Group` atëherë kjo metodë nuk do të konfigurojë hapësirën e secilës prej tokens të brendshme, kjo thjesht do të delegojë në metodën `set_span` të secilit variant.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Shtyp pemën token në një formë të përshtatshme për korrigjimin e gabimeve.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Secila prej tyre ka emrin në llojin e strukturës në korrigjimin e derivuar, prandaj mos u shqetësoni me një shtresë shtesë të indirektit
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, ura siguron vetëm `to_string`, zbato `fmt::Display` bazuar në të (e kundërta e marrëdhënies së zakonshme midis të dyve).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Shtyp pemën token si një varg që supozohet se mund të konvertohet pa humbje përsëri në të njëjtën pemë token (shtrirja e modulit), me përjashtim të `TokenTree: : Group` me ndarës `Delimiter::None` dhe fjalë për fjalë numerike negative.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Një transmetim i kufizuar token.
///
/// Një `Group` brenda saj përmban një `TokenStream` i cili është i rrethuar nga `Delimiter`.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Përshkruan se si një sekuencë e pemëve token është e kufizuar.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Një ndarës i nënkuptuar, që mund, për shembull, të shfaqet rreth tokens që vjen nga një "macro variable" `$var`.
    /// Shtë e rëndësishme të ruhen përparësitë e operatorit në raste si `$var * 3` ku `$var` është `1 + 2`.
    /// Përcaktuesit e nënkuptuar mund të mos mbijetojnë vajtje-ardhje të një rryme token përmes një vargu.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Krijon një `Group` të ri me ndarësin e dhënë dhe rrymën token.
    ///
    /// Ky konstruktor do të caktojë hapësirën për këtë grup në `Span::call_site()`.
    /// Për të ndryshuar hapësirën mund të përdorni metodën `set_span` më poshtë.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Kthen ndarësin e këtij `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Kthen `TokenStream` të tokens që përcaktohet në këtë `Group`.
    ///
    /// Vini re se transmetimi i kthyer token nuk përfshin ndarësin e kthyer më lart.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Kthen hapësirën për ndarësit e kësaj rryme token, duke përfshirë të gjithë `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Kthen hapësirën duke treguar ndarësin hapës të këtij grupi.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Kthen hapësirën duke treguar ndarësin mbyllës të këtij grupi.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Konfiguron hapësirën për ndarësit e këtij `Grupi`, por jo tokens të tij të brendshëm.
    ///
    /// Kjo metodë **nuk do të** vendosë hapësirën e të gjithë tokens të brendshëm të shtrirë nga ky grup, por përkundrazi do të vendosë vetëm hapësirën e ndarësit tokens në nivelin e `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, ura siguron vetëm `to_string`, zbato `fmt::Display` bazuar në të (e kundërta e marrëdhënies së zakonshme midis të dyve).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Shtyp grupin si një varg që duhet të konvertohet pa humbje përsëri në të njëjtin grup (hapësira modulesh), me përjashtim të `TokenTree: : Group` me ndarës `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// Një `Punct` është një karakter i vetëm i pikësimit si `+`, `-` ose `#`.
///
/// Operatorët me shumë karakter si `+=` përfaqësohen si dy raste të `Punct` me forma të ndryshme të `Spacing` të kthyera.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Nëse një `Punct` ndiqet menjëherë nga një `Punct` tjetër ose ndiqet nga një tjetër token ose hapësirë e bardhë.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// p.sh., `+` është `Alone` në `+ =`, `+ident` ose `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// p.sh., `+` është `Joint` në `+=` ose `'#`.
    /// Për më tepër, kuota e vetme `'` mund të bashkohet me identifikuesit për të formuar jetëgjatësi `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Krijon një `Punct` të ri nga karakteri dhe hapësira e dhënë.
    /// Argumenti `ch` duhet të jetë një karakter pikësimi i vlefshëm i lejuar nga gjuha, përndryshe funksioni do të panic.
    ///
    /// `Punct` i kthyer do të ketë hapësirën e paracaktuar të `Span::call_site()` i cili mund të konfigurohet më tej me metodën `set_span` më poshtë.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Kthen vlerën e këtij karakteri pikësimi si `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Kthen hapësirën e këtij karakteri pikësimi, duke treguar nëse ajo ndiqet menjëherë nga një tjetër `Punct` në transmetimin token, kështu që ata mund të kombinohen potencialisht në një operator me shumë karaktere (`Joint`), ose ndiqet nga disa token ose hapësira e bardhë (`Alone`) kështu që operatori sigurisht që ka mbaroi.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Kthen hapësirën për këtë karakter pikësimi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfiguroni hapësirën për këtë karakter pikësimi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ura siguron vetëm `to_string`, zbato `fmt::Display` bazuar në të (e kundërta e marrëdhënies së zakonshme midis të dyve).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Shtyp karakterin e pikësimit si një varg që duhet të konvertohet pa humbje përsëri në të njëjtin karakter.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Një identifikues (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Krijon një `Ident` të ri me `string` të dhënë si dhe `span` të specifikuar.
    /// Argumenti `string` duhet të jetë një identifikues i vlefshëm i lejuar nga gjuha (përfshirë fjalët kyçe, p.sh. `self` ose `fn`).Përndryshe, funksioni do të panic.
    ///
    /// Vini re se `span`, aktualisht në rustc, konfiguron informacionin e higjienës për këtë identifikues.
    ///
    /// Që nga kjo kohë, `Span::call_site()` shprehimisht zgjedh higjienën "call-site", që do të thotë se identifikuesit e krijuar me këtë hapësirë do të zgjidhen sikur të ishin shkruar direkt në vendndodhjen e thirrjes makro dhe kodi tjetër në faqen e thirrjes makro do të jetë në gjendje t'i referohet po ashtu.
    ///
    ///
    /// Hapësira e mëvonshme si `Span::def_site()` do të lejojë të zgjedhin higjienën "definition-site" që do të thotë që identifikuesit e krijuar me këtë hapësirë do të zgjidhen në vendndodhjen e përkufizimit makro dhe kodi tjetër në sitin e thirrjes makro nuk do të jetë në gjendje t'u referohet atyre.
    ///
    /// Për shkak të rëndësisë aktuale të higjienës, ky konstruktor, ndryshe nga tokens të tjerë, kërkon që një `Span` të specifikohet gjatë ndërtimit.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Njësoj si `Ident::new`, por krijon një identifikues të papërpunuar (`r#ident`).
    /// Argumenti `string` të jetë një identifikues i vlefshëm i lejuar nga gjuha (përfshirë fjalët kyçe, p.sh. `fn`).
    /// Fjalë kyçe të cilat janë të përdorshme në segmentet e shtegut (p.sh.
    /// `self`, `super`) nuk mbështeten dhe do të shkaktojnë një panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Kthen hapësirën e këtij `Ident`, duke përfshirë të gjithë vargun e kthyer nga [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfiguron hapësirën e këtij `Ident`, ndoshta duke ndryshuar kontekstin e tij të higjienës.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ura siguron vetëm `to_string`, zbato `fmt::Display` bazuar në të (e kundërta e marrëdhënies së zakonshme midis të dyve).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Shtyp identifikuesin si një varg që duhet të konvertohet pa humbje përsëri në të njëjtin identifikues.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Një varg i drejtpërdrejtë (`"hello"`), vargu bajt (`b"hello"`), karakteri (`'a'`), karakteri bajt (`b'a'`), një numër i plotë ose numër i pikës lundruese me ose pa prapashtesë (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Fjalë për fjalë boolean si `true` dhe `false` nuk i përkasin këtu, ato janë `Ident` s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Krijon një numër të plotë prapashtesë të plotë fjalë për fjalë me vlerën e specifikuar.
        ///
        /// Ky funksion do të krijojë një numër të plotë si `1u32` ku vlera e plotë e specifikuar është pjesa e parë e token dhe integrali po ashtu është prapashtesë në fund.
        /// Fjalët e krijuara nga numrat negativë nuk mund të mbijetojnë gjatë vajtje-ardhjeve përmes `TokenStream` ose vargjeve dhe mund të ndahen në dy tokens (`-` dhe pozitive fjalë për fjalë).
        ///
        ///
        /// Fjalët e krijuara përmes kësaj metode kanë hapësirën `Span::call_site()` si parazgjedhje, e cila mund të konfigurohet me metodën `set_span` më poshtë.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Krijon një numër të plotë të ri të pakufizuar me vlerën e specifikuar.
        ///
        /// Ky funksion do të krijojë një numër të plotë si `1` ku vlera e plotë e specifikuar është pjesa e parë e token.
        /// Asnjë prapashtesë nuk është specifikuar në këtë token, që do të thotë se thirrjet si `Literal::i8_unsuffixed(1)` janë ekuivalente me `Literal::u32_unsuffixed(1)`.
        /// Fjalët e shkruara të krijuara nga numrat negativë mund të mos mbijetojnë nga rripat e rreshtave përmes `TokenStream` ose vargjeve dhe mund të ndahen në dy tokens (`-` dhe pozitive fjalë për fjalë).
        ///
        ///
        /// Fjalët e krijuara përmes kësaj metode kanë hapësirën `Span::call_site()` si parazgjedhje, e cila mund të konfigurohet me metodën `set_span` më poshtë.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Krijon një fjalë për fjalë të re të pikës lundruese të papërcaktuar.
    ///
    /// Ky konstruktor është i ngjashëm me ato si `Literal::i8_unsuffixed` ku vlera e notave lëshohet drejtpërdrejt në token por nuk përdoret asnjë prapashtesë, kështu që mund të nxirret se është `f64` më vonë në përpilues.
    ///
    /// Fjalët e shkruara të krijuara nga numrat negativë mund të mos mbijetojnë nga rripat e rreshtave përmes `TokenStream` ose vargjeve dhe mund të ndahen në dy tokens (`-` dhe pozitive fjalë për fjalë).
    ///
    /// # Panics
    ///
    /// Ky funksion kërkon që nota e specifikuar të jetë e fundme, për shembull nëse është pafundësi ose NaN ky funksion do të panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Krijon një fjalëpërfjalës të re të pikës lundruese të prapashtesës.
    ///
    /// Ky konstruktor do të krijojë një fjalë për fjalë si `1.0f32` ku vlera e specifikuar është pjesa paraardhëse e token dhe `f32` është prapashtesa e token.
    /// Ky token gjithmonë do të nxirret se është `f32` në përpilues.
    /// Fjalët e shkruara të krijuara nga numrat negativë mund të mos mbijetojnë nga rripat e rreshtave përmes `TokenStream` ose vargjeve dhe mund të ndahen në dy tokens (`-` dhe pozitive fjalë për fjalë).
    ///
    ///
    /// # Panics
    ///
    /// Ky funksion kërkon që nota e specifikuar të jetë e fundme, për shembull nëse është pafundësi ose NaN ky funksion do të panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Krijon një fjalë për fjalë të re të pikës lundruese të papërcaktuar.
    ///
    /// Ky konstruktor është i ngjashëm me ato si `Literal::i8_unsuffixed` ku vlera e notave lëshohet drejtpërdrejt në token por nuk përdoret asnjë prapashtesë, kështu që mund të nxirret se është `f64` më vonë në përpilues.
    ///
    /// Fjalët e shkruara të krijuara nga numrat negativë mund të mos mbijetojnë nga rripat e rreshtave përmes `TokenStream` ose vargjeve dhe mund të ndahen në dy tokens (`-` dhe pozitive fjalë për fjalë).
    ///
    /// # Panics
    ///
    /// Ky funksion kërkon që nota e specifikuar të jetë e fundme, për shembull nëse është pafundësi ose NaN ky funksion do të panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Krijon një fjalëpërfjalës të re të pikës lundruese të prapashtesës.
    ///
    /// Ky konstruktor do të krijojë një fjalë për fjalë si `1.0f64` ku vlera e specifikuar është pjesa paraardhëse e token dhe `f64` është prapashtesa e token.
    /// Ky token gjithmonë do të nxirret se është `f64` në përpilues.
    /// Fjalët e shkruara të krijuara nga numrat negativë mund të mos mbijetojnë nga rripat e rreshtave përmes `TokenStream` ose vargjeve dhe mund të ndahen në dy tokens (`-` dhe pozitive fjalë për fjalë).
    ///
    ///
    /// # Panics
    ///
    /// Ky funksion kërkon që nota e specifikuar të jetë e fundme, për shembull nëse është pafundësi ose NaN ky funksion do të panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Vargu fjalë për fjalë.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Karakteri fjalë për fjalë.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Vargu bajt fjalë për fjalë.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Kthen hapësirën që përfshin këtë fjalë për fjalë.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfiguron hapësirën e lidhur për këtë fjalë për fjalë.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Kthen një `Span` që është një nëngrup i `self.span()` që përmban vetëm bajtët burim në intervalin `range`.
    /// Kthen `None` nëse hapësira që pritet të shkurtohet është jashtë kufijve të `self`.
    ///
    // FIXME(SergioBenitez): kontrolloni që diapazoni i bajteve fillon dhe mbaron në një kufi UTF-8 të burimit.
    // përndryshe, ka të ngjarë që një panic të ndodhë diku tjetër kur të shtypet teksti burimor.
    // FIXME(SergioBenitez): nuk ka asnjë mënyrë që përdoruesi të dijë se në çfarë harton në të vërtetë `self.span()`, kështu që kjo metodë aktualisht mund të quhet vetëm verbërisht.
    // Për shembull, `to_string()` për karakterin 'c' kthen "'\u{63}'";nuk ka asnjë mënyrë që përdoruesi të dijë nëse teksti burimor ishte 'c' ose nëse ishte '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) diçka e ngjashme me `Option::cloned`, por për `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, ura siguron vetëm `to_string`, zbato `fmt::Display` bazuar në të (e kundërta e marrëdhënies së zakonshme midis të dyve).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Shtyp fjalën si një varg që duhet të konvertohet pa humbje përsëri në të njëjtën fjalë për fjalë (me përjashtim të rrumbullakimit të mundshëm për fjalët e pikave lundruese).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Aksesi i gjurmuar në variablat e mjedisit.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Merrni një variabël të mjedisit dhe shtojeni atë për të ndërtuar informacione të varësisë.
    /// Sistemi i ndërtimit që ekzekuton përpiluesin do të dijë që variabli është aksesuar gjatë përpilimit dhe do të jetë në gjendje të ribërë ndërtimin kur vlera e kësaj ndryshore ndryshon.
    ///
    /// Përveç ndjekjes së varësisë, ky funksion duhet të jetë ekuivalent me `env::var` nga biblioteka standarde, përveç që argumenti duhet të jetë UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}