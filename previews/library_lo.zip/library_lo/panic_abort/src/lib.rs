//! ການປະຕິບັດຂອງ Rust panics ຜ່ານສໍາເລັດຂະບວນການ
//!
//! ເມື່ອປຽບທຽບກັບການຈັດຕັ້ງປະຕິບັດໂດຍຜ່ານການບໍ່ເອົາໃຈໃສ່, crate ນີ້ແມ່ນ *ຫຼາຍ* ລຽບງ່າຍ!ທີ່ຖືກເວົ້າມານັ້ນ, ມັນບໍ່ແມ່ນຂ້ອນຂ້າງທີ່ຫລາກຫລາຍ, ແຕ່ນີ້ໄປ!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" ໄດ້ payload ແລະ shim ກັບຍົກເລີກກ່ຽວຂ້ອງໃນເວທີໃນຄໍາຖາມ.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // ໂທຫາ std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // ໃນ Windows, ໃຊ້ກົນໄກ __fastfail ທີ່ໃຊ້ໂດຍໂປເຊດເຊີ.ໃນ Windows 8 ແລະຕໍ່ມາ, ນີ້ຈະຢຸດຂະບວນການໃນທັນທີໂດຍບໍ່ມີການແລ່ນໃນຂະບວນການໃດຫນຶ່ງລົດຍົກຍົກເວັ້ນ.
            // ໃນ Windows ລຸ້ນກ່ອນ ໜ້າ ນີ້, ຄຳ ແນະ ນຳ ສະບັບນີ້ຈະຖືກປະຕິບັດວ່າເປັນການລະເມີດການເຂົ້າເຖິງ, ຢຸດຕິຂັ້ນຕອນແຕ່ບໍ່ ຈຳ ເປັນຕ້ອງຜ່ານຜູ້ຈັດການຍົກເວັ້ນທັງ ໝົດ.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: ນີ້ແມ່ນການປະຕິບັດຄືກັນກັບ `abort_internal` ຂອງ libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// ນີ້ ... ແມ່ນເລື່ອງເລັກໆນ້ອຍໆ.ການ tl; dr;ແມ່ນວ່າມັນ ຈຳ ເປັນຕ້ອງເຊື່ອມໂຍງຢ່າງຖືກຕ້ອງ, ຄຳ ອະທິບາຍຕໍ່ໄປນີ້ແມ່ນຢູ່ຂ້າງລຸ່ມ.
//
// ດຽວນີ້ຖານຂໍ້ມູນສອງຫລຽນຂອງ libcore/libstd ທີ່ພວກເຮົາຈັດສົ່ງຖືກລວບລວມດ້ວຍ `-C panic=unwind`.ນີ້ແມ່ນເຮັດເພື່ອໃຫ້ແນ່ໃຈວ່າໄບນາລີແມ່ນສູງສຸດທີ່ດເຫມາະສົມກັບສະຖານະການຈໍານວນຫຼາຍເທົ່າທີ່ເປັນໄປ.
// ເຖິງຢ່າງໃດກໍ່ຕາມຕົວລວບລວມຂໍ້ມູນຕ້ອງມີ "personality function" ສຳ ລັບທຸກໆ ໜ້າ ທີ່ທີ່ຖືກລວບລວມກັບ `-C panic=unwind`.ໜ້າ ທີ່ຂອງບຸກຄະລິກລັກສະນະນີ້ແມ່ນ hardcoded ກັບສັນຍາລັກ `rust_eh_personality` ແລະຖືກ ກຳ ນົດໂດຍລາຍການ `eh_personality` lang.
//
// So...
// ເປັນຫຍັງຈຶ່ງບໍ່ພຽງແຕ່ກໍານົດວ່າລາຍ lang ນີ້?ຄໍາຖາມທີ່ດີ!ວິທີການທີ່ runtime panic ກໍາລັງເຊື່ອມຕໍ່ໃນຕົວຈິງແລ້ວແມ່ນເປັນພຽງເລັກນ້ອຍທີ່ລຶກຊຶ້ງໃນທີ່ພວກເຂົາເຈົ້າກໍາລັງ "sort of" ໃນ compiler ຂອງຮ້ານ crate, ແຕ່ວ່າພຽງແຕ່ການເຊື່ອມໂຍງຕົວຈິງຖ້າຫາກວ່າຄົນອື່ນບໍ່ໄດ້ເຊື່ອມຕໍ່ຕົວຈິງ.
//
// ສິ້ນສຸດລົງນີ້ເກີດຂຶ້ນຊຶ່ງຫມາຍຄວາມວ່າທັງສອງ crate ນີ້ແລະ panic_unwind crate ສາມາດປາກົດຢູ່ໃນ compiler ຂອງຮ້ານ crate, ແລະຖ້າຫາກວ່າທັງສອງກໍານົດການລາຍ `eh_personality` lang ຫຼັງຈາກນັ້ນທີ່ຈະມົນຕີຄວາມຜິດພາດ.
//
// ການຈັດການນີ້ compiler ໄດ້ພຽງແຕ່ຮຽກຮ້ອງໃຫ້ມີການ `eh_personality` ຖືກກໍານົດໄວ້ຖ້າ runtime panic ມີການເຊື່ອມໂຍງໃນແມ່ນ runtime ຄາຍ, ແລະຖ້າບໍ່ດັ່ງນັ້ນມັນບໍ່ຈໍາເປັນຕ້ອງໄດ້ຮັບການກໍານົດ (ຊອບທໍາດັ່ງນັ້ນ).
// ໃນກໍລະນີດັ່ງກ່າວນີ້, ແນວໃດກໍ່ຕາມ, ຫ້ອງສະຫມຸດນີ້ພຽງແຕ່ໄດ້ກໍານົດສັນຍາລັກນີ້ດັ່ງນັ້ນບໍ່ມີຢ່າງຫນ້ອຍບາງ somewhere ບຸກຄະລິກ.
//
// ສິ່ງ ສຳ ຄັນສັນຍາລັກນີ້ແມ່ນພຽງແຕ່ຖືກ ກຳ ນົດໃຫ້ມີສາຍໄຟ libcore/libstd ຂະ ໜາດ ນ້ອຍເທົ່ານັ້ນ, ແຕ່ມັນບໍ່ຄວນຈະຖືກເອີ້ນວ່າພວກເຮົາບໍ່ເຊື່ອມໂຍງກັບເວລາແລ່ນລ້າໆ.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // ໃນ x86_64-pc-windows-gnu ພວກເຮົາໃຊ້ຟັງຊັນບຸກຄະລິກຂອງພວກເຮົາເອງທີ່ຕ້ອງການສົ່ງຄືນ `ExceptionContinueSearch` ໃນຂະນະທີ່ພວກເຮົາ ກຳ ລັງຖ່າຍທອດຂອບຂອງພວກເຮົາທັງ ໝົດ.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // ຄ້າຍຄືກັນກັບຂ້າງເທິງ, ສິ່ງນີ້ກົງກັບສິນຄ້າ `eh_catch_typeinfo` lang ທີ່ໃຊ້ໃນ Emscripten ປະຈຸບັນ.
    //
    // ເນື່ອງຈາກວ່າ panics ບໍ່ສ້າງຂໍ້ຍົກເວັ້ນແລະການຍົກເວັ້ນຕ່າງປະເທດປະຈຸບັນມີ UB ກັບ -C panic=ຍົກເລີກ (ເຖິງແມ່ນວ່ານີ້ອາດຈະມີການປ່ຽນແປງ), ໂທ catch_unwind ໃດຈະບໍ່ໃຊ້ typeinfo ນີ້.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // ທັງສອງໄດ້ຖືກເອີ້ນວ່າໂດຍວັດຖຸເລີ່ມຕົ້ນລະບົບຂອງພວກເຮົາກ່ຽວກັບການ i686, ຄອມພິວເຕີ, windows-gnu, ແຕ່ພວກເຂົາເຈົ້າບໍ່ຈໍາເປັນຕ້ອງເຮັດຫຍັງເພື່ອອົງການຈັດຕັ້ງແມ່ນ nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}