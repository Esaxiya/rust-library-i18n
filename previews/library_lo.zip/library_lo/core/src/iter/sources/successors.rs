use crate::{fmt, iter::FusedIterator};

/// ສ້າງເປັນ iterator ໃຫມ່ບ່ອນທີ່ແຕ່ລະລາຍການສົບຜົນສໍາເລັດແມ່ນ computed ອີງໃສ່ຫນຶ່ງກ່ອນ.
///
/// ຕົວປ່ຽນແປງເລີ່ມຕົ້ນດ້ວຍລາຍການ ທຳ ອິດທີ່ໃຫ້ (ຖ້າມີ) ແລະຮຽກເອົາການປິດ `FnMut(&T) -> Option<T>` ເພື່ອລວບລວມຜູ້ສືບທອດຂອງແຕ່ລະລາຍການ.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // ຖ້າຫາກວ່າການທໍາງານນີ້ໄດ້ກັບຄືນ `impl Iterator<Item=T>` ມັນສາມາດໄດ້ຮັບການໂດຍອີງໃສ່ `unfold` ແລະບໍ່ຈໍາເປັນຕ້ອງປະເພດການອຸທິດ.
    //
    // ຢ່າງໃດກໍຕາມມີຊື່ຊະນິດ `Successors<T, F>` ອະນຸຍາດໃຫ້ມັນຈະ `Clone` ໃນເວລາທີ່ `T` ແລະ `F` ແມ່ນ.
    Successors { next: first, succ }
}

/// ເປັນ iterator ໃຫມ່ບ່ອນທີ່ແຕ່ລະລາຍການສົບຜົນສໍາເລັດແມ່ນ computed ອີງໃສ່ຫນຶ່ງກ່ອນ.
///
/// `struct` ນີ້ຖືກສ້າງຂຶ້ນໂດຍການທໍາງານຂອງ [`iter::successors()`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}