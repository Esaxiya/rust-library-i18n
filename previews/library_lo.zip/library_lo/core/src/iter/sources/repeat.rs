use crate::iter::{FusedIterator, TrustedLen};

/// ສ້າງເປັນ iterator ໃຫມ່ທີ່ບໍ່ຮູ້ຈົບຊ້ໍາເປັນອົງປະກອບດຽວ.
///
/// ການທໍາງານຂອງ `repeat()` repeats ຄ່າດຽວໃນໄລຍະແລະຫຼາຍກວ່າອີກເທື່ອຫນຶ່ງ.
///
/// iterators ນິດເຊັ່ນ: `repeat()` ໄດ້ຖືກນໍາໃຊ້ກັບອະແດບເຕີຄື [`Iterator::take()`], ໃນຄໍາສັ່ງທີ່ຈະເຮັດໃຫ້ເຂົາເຈົ້າ finite.
///
/// ຖ້າຫາກວ່າປະເພດອົງປະກອບຂອງ iterator ທີ່ທ່ານຕ້ອງການບໍ່ໄດ້ປະຕິບັດ `Clone`, ຫຼືຖ້າວ່າທ່ານບໍ່ຕ້ອງການທີ່ຈະຮັກສາອົງປະກອບຊ້ໍາໃນຫນ່ວຍຄວາມຈໍາ, ທ່ານແທນທີ່ຈະສາມາດນໍາໃຊ້ການທໍາງານຂອງ [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::iter;
///
/// // ຈໍານວນສີ່ 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, ຍັງສີ່
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// ໄປ finite ກັບ [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ທີ່ຍົກຕົວຢ່າງທີ່ຜ່ານມານີ້ແມ່ນສີ່ຫຼາຍເກີນໄປ.ຂໍໃຫ້ມີຄວາມພຽງແຕ່ສີ່ສີ່.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ແລະດຽວນີ້ພວກເຮົາ ສຳ ເລັດແລ້ວ
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// ເຄື່ອງປັບທີ່ເຮັດຊ້ ຳ ອີກອົງປະກອບ ໜຶ່ງ ຢ່າງບໍ່ສິ້ນສຸດ.
///
/// `struct` ນີ້ຖືກສ້າງຂຶ້ນໂດຍການທໍາງານຂອງ [`repeat()`].ເບິ່ງເອກະສານຂອງຕົນສໍາລັບການເພີ່ມເຕີມ.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}