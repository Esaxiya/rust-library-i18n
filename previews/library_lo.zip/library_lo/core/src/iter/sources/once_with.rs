use crate::iter::{FusedIterator, TrustedLen};

/// ສ້າງ iterator ທີ່ lazily ສ້າງມູນຄ່າແນ່ນອນເມື່ອໂດຍ invoking ໄດ້ປິດໃຫ້ເປັນ.
///
/// ນີ້ໄດ້ຖືກນໍາໃຊ້ທົ່ວໄປທີ່ຈະເຮັດໃຫ້ເຫມາະສົມກໍາເນີດໄຟຟ້າມູນຄ່າດຽວໃນ [`chain()`] ຂອງປະເພດອື່ນໆຂອງ iteration.
/// ບາງທ່ານທີ່ມີ iterator ທີ່ການປົກຫຸ້ມຂອງເກືອບທຸກສິ່ງທຸກຢ່າງ, ແຕ່ວ່າທ່ານຕ້ອງການເປັນກໍລະນີພິເສດພິເສດໄດ້.
/// ບາງທ່ານທີ່ມີຫນ້າທີ່ເຮັດວຽກກ່ຽວກັບ iterators, ແຕ່ທ່ານພຽງແຕ່ຕ້ອງການທີ່ຈະປະມວນຜົນຄ່າຫນຶ່ງ.
///
/// ບໍ່ເຫມືອນກັບ [`once()`], ການທໍາງານນີ້ lazily ຈະສ້າງມູນຄ່າກ່ຽວກັບການຮ້ອງຂໍ.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::iter;
///
/// // ຫນຶ່ງແມ່ນຈໍານວນ loneliest ໄດ້
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ພຽງແຕ່ຫນຶ່ງ, ນີ້ເປັນສິ່ງທີ່ພວກເຮົາໄດ້ຮັບ
/// assert_eq!(None, one.next());
/// ```
///
/// ບົບຕ່ອງໂສ້ຮ່ວມກັນກັບ iterator ອື່ນ.
/// ໃຫ້ຂອງເວົ້າວ່າພວກເຮົາຕ້ອງການທີ່ຈະ iterate ໃນໄລຍະເອກະສານໃນແຕ່ລະຂອງລະບົບ `.foo`, ແຕ່ຍັງໄຟລ໌ການຕັ້ງຄ່າເປັນ,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ພວກເຮົາຈໍາເປັນຕ້ອງໄດ້ປ່ຽນຈາກ iterator ຂອງ DirEntry-s ໄປ iterator ຂອງ PathBufs ເປັນ, ສະນັ້ນພວກເຮົານໍາໃຊ້ແຜນທີ່
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ໃນປັດຈຸບັນ, iterator ຂອງພວກເຮົາພຽງແຕ່ສໍາລັບເອກະສານຂອງພວກເຮົາ config
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // ລະບົບຕ່ອງໂສ້ທັງສອງ iterators ກັນເປັນ iterator ໃຫຍ່ຫນຶ່ງ
/// let files = dirs.chain(config);
///
/// // ນີ້ຈະໃຫ້ພວກເຮົາທັງຫມົດຂອງໄຟລ໌ໃນ .foo ໄດ້ເຊັ່ນດຽວກັນກັບ .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// ເປັນ iterator ທີ່ yields ເປັນການອົງປະກອບດຽວຂອງປະເພດ `A` ໂດຍການນໍາໃຊ້ການປິດໃຫ້ `F: FnOnce() -> A`.
///
///
/// `struct` ນີ້ຖືກສ້າງຂຶ້ນໂດຍການທໍາງານຂອງ [`once_with()`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}