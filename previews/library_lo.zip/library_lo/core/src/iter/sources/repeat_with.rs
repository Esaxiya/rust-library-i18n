use crate::iter::{FusedIterator, TrustedLen};

/// ສ້າງເປັນ iterator ໃຫມ່ທີ່ຊ້ໍາອົງປະກອບຂອງປະເພດ `A` endlessly ໂດຍການນໍາໃຊ້ການປິດສະຫນອງໃຫ້, ເຮັດເລື້ມຄືນ, `F: FnMut() -> A`.
///
/// ການທໍາງານຂອງ `repeat_with()` ໂທ repeater ໃນໄລຍະແລະຫຼາຍກວ່າອີກເທື່ອຫນຶ່ງ.
///
/// iterators ນິດເຊັ່ນ: `repeat_with()` ໄດ້ຖືກນໍາໃຊ້ກັບອະແດບເຕີຄື [`Iterator::take()`], ໃນຄໍາສັ່ງທີ່ຈະເຮັດໃຫ້ເຂົາເຈົ້າ finite.
///
/// ຖ້າຫາກວ່າປະເພດອົງປະກອບຂອງ iterator ທີ່ທ່ານຈໍາເປັນຕ້ອງປະຕິບັດ [`Clone`], ແລະມັນບໍ່ເປັນຫຍັງດອກທີ່ຈະຮັກສາອົງປະກອບແຫຼ່ງໃນຫນ່ວຍຄວາມຈໍາ, ທ່ານແທນທີ່ຈະຄວນໃຊ້ການທໍາງານຂອງ [`repeat()`].
///
///
/// ຕົວລະອໍທີ່ຜະລິດໂດຍ `repeat_with()` ບໍ່ແມ່ນ [`DoubleEndedIterator`].
/// ຖ້າຫາກວ່າທ່ານຕ້ອງການ `repeat_with()` ເພື່ອກັບຄືນເປັນ [`DoubleEndedIterator`], ກະລຸນາເປີດບັນຫາ GitHub ການອະທິບາຍກໍລະນີການນໍາໃຊ້ຂອງທ່ານ.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::iter;
///
/// // ໃຫ້ສົມມຸດວ່າເຮົາມີຄຸນຄ່າຂອງປະເພດທີ່ບໍ່ແມ່ນ `Clone` ຫຼືທີ່ບໍ່ຕ້ອງການທີ່ຈະມີຢູ່ໃນຫນ່ວຍຄວາມຈໍາພຽງແຕ່ຍັງເນື່ອງຈາກວ່າມັນເປັນລາຄາແພງບາງ:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // ຄ່າໂດຍສະເພາະຕະຫຼອດໄປ:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// ການ ນຳ ໃຊ້ການກາຍພັນແລະການ ກຳ ນົດຂັ້ນຕອນ:
///
/// ```rust
/// use std::iter;
///
/// // ຈາກ zeroth ກັບພະລັງງານທີສາມຂອງສອງ:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ແລະດຽວນີ້ພວກເຮົາ ສຳ ເລັດແລ້ວ
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// ຕົວປັບທີ່ເຮັດຊ້ ຳ ກັບອົງປະກອບຂອງປະເພດ `A` ແບບບໍ່ຢຸດຢັ້ງໂດຍການ ນຳ ໃຊ້ `F: FnMut() -> A` ປິດທີ່ສະ ໜອງ ໃຫ້.
///
///
/// `struct` ນີ້ຖືກສ້າງຂຶ້ນໂດຍການທໍາງານຂອງ [`repeat_with()`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}