use crate::fmt;

/// ສ້າງເປັນ iterator ໃຫມ່ບ່ອນທີ່ແຕ່ລະ iteration ເອີ້ນໃຫ້ປິດ `F: FnMut() -> Option<T>`.
///
/// ນີ້ອະນຸຍາດໃຫ້ສ້າງຕົວປ່ຽນແປງແບບ ກຳ ນົດເອງໂດຍມີພຶດຕິ ກຳ ໃດໆໂດຍບໍ່ຕ້ອງໃຊ້ syntax verbose ຫຼາຍຂື້ນໃນການສ້າງປະເພດທີ່ອຸທິດຕົນແລະປະຕິບັດ [`Iterator`] trait ສຳ ລັບມັນ.
///
/// ໃຫ້ສັງເກດວ່າການ `FromFn` iterator ບໍ່ໄດ້ເຮັດໃຫ້ສົມມຸດຕິຖານກ່ຽວກັບການເຮັດວຽກຂອງການປິດໄດ້, ແລະດັ່ງນັ້ນຈິ່ງອະນຸລັກບໍ່ໃຊ້ [`FusedIterator`] ຫລືຂຽນທັບ [`Iterator::size_hint()`] ຈາກໄວ້ໃນຕອນຕົ້ນຂອງຕົນ `(0, None)`.
///
///
/// ການປິດສາມາດໃຊ້ຈັບແລະສະພາບແວດລ້ອມຂອງຕົນເພື່ອຕິດຕາມສະຖານະທົ່ວ iterations.ອີງຕາມວິທີ iterator ໄດ້ຖືກນໍາໃຊ້, ນີ້ອາດຈະຮຽກຮ້ອງໃຫ້ມີການລະບຸຄໍາ [`move`] ກ່ຽວກັບການປິດໄດ້.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// ໃຫ້ Re: ປະຕິບັດວຽກງານຕ້ານ iterator ຈາກ [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // ເພີ່ມຄ່ານັບຂອງພວກເຮົາ.ນີ້ແມ່ນເຫດຜົນທີ່ພວກເຮົາເລີ່ມຕົ້ນທີ່ສູນ.
///     count += 1;
///
///     // ກວດສອບເພື່ອເບິ່ງວ່າພວກເຮົາໄດ້ຄິດໄລ່ໄດ້ສໍາເລັດຫຼືບໍ່.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// ຕົວຊີ້ທິດທາງບ່ອນທີ່ແຕ່ລະສຽງເອີ້ນວ່າປິດ `F: FnMut() -> Option<T>`.
///
/// `struct` ນີ້ຖືກສ້າງຂຶ້ນໂດຍການທໍາງານຂອງ [`iter::from_fn()`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}