//! iteration ພາຍນອກການຂຽນຈົດຫມາຍ.
//!
//! ຖ້າຫາກວ່າທ່ານໄດ້ພົບເຫັນຕົວທ່ານເອງມີການເກັບກໍາບາງປະເພດໄດ້, ແລະຈໍາເປັນໃນການປະຕິບັດການດໍາເນີນງານກ່ຽວກັບອົງປະກອບຂອງການເກັບກໍາໄດ້ກ່າວວ່າ, ທ່ານຈະດໍາເນີນການເຂົ້າໄປໃນ 'iterators' ຢ່າງໄວວາ.
//! ເຄື່ອງຕັດໄດ້ຖືກນໍາໃຊ້ຢ່າງຫຼວງຫຼາຍໃນລະຫັດ Rust idiomatic, ສະນັ້ນມັນຄຸ້ມຄ່າທີ່ຈະຄຸ້ນເຄີຍກັບພວກມັນ.
//!
//! ກ່ອນທີ່ຈະອະທິບາຍຍິ່ງຂຶ້ນ, ໃຫ້ສົນທະນາກ່ຽວກັບວິທີໂມດູນນີ້ແມ່ນໂຄງສ້າງ:
//!
//! # Organization
//!
//! ໂມດູນນີ້ແມ່ນໄດ້ຖືກຈັດໂດຍສ່ວນໃຫຍ່ແມ່ນປະເພດນີ້:
//!
//! * [Traits] ມີສ່ວນສໍາຄັນ: traits ເຫຼົ່ານີ້ກໍານົດຊະນິດຂອງ iterators ມີແລະສິ່ງທີ່ທ່ານສາມາດເຮັດໄດ້ກັບເຂົາເຈົ້າ.ວິທີການຂອງ traits ເຫຼົ່ານີ້ແມ່ນມູນຄ່າການວາງເວລາສຶກສາພິເສດບາງຢ່າງເຂົ້າໄປໃນ.
//! * [Functions] ໃຫ້ບາງວິທີການເປັນປະໂຫຍດທີ່ຈະສ້າງ iterators ພື້ນຖານຈໍານວນຫນຶ່ງ.
//! * [Structs] ກໍເປັນປະເພດຜົນຕອບແທນຂອງວິທີການຕ່າງໆກ່ຽວກັບການລະຫັດນີ້ traits.ທ່ານມັກຈະຕ້ອງການເບິ່ງວິທີການທີ່ສ້າງ `struct`, ແທນທີ່ຈະແມ່ນ `struct` ເອງ.
//! ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມກ່ຽວກັບເຫດຜົນ, ເບິ່ງ '[ການຈັດຕັ້ງປະຕິບັດເຄື່ອງມື](#ການປະຕິບັດ-ຜູ້ປະຕິບັດ)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! ດັ່ງນັ້ນ, ມັນ!ໃຫ້ຂອງຂຸດເຂົ້າໄປໃນ iterators.
//!
//! # Iterator
//!
//! ຫົວໃຈແລະຈິດວິນຍານຂອງໂມດູນນີ້ແມ່ນ [`Iterator`] trait.ຫົວໃຈຫລັກຂອງ [`Iterator`] ຄ້າຍຄືນີ້:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! ເປັນ iterator ມີວິທີການ, [`next`], ເຊິ່ງໃນເວລາທີ່ເອີ້ນວ່າຜົນຕອບແທນເປັນ [`Option`]`<Item>`.
//! [`next`] ຈະກັບຄືນ [`Some(Item)`] ຕາບໃດທີ່ມີອົງປະກອບ, ແລະເມື່ອພວກເຂົາໄດ້ທັງຫມົດຖືກຫມົດ, ຈະກັບຄືນ `None` ເພື່ອບົ່ງບອກວ່າ iteration ສໍາເລັດແລ້ວ.
//! iterators ບຸກຄົນອາດຈະເລືອກທີ່ຈະດໍາເນີນ iteration ແລະດັ່ງນັ້ນການໂທ [`next`] ອີກເທື່ອຫນຶ່ງອາດຈະຫຼືອາດຈະບໍ່ໃນທີ່ສຸດກໍເລີ່ມຕົ້ນກັບຄືນ [`Some(Item)`] ອີກເທື່ອຫນຶ່ງຢູ່ບາງຈຸດ (ສໍາລັບຕົວຢ່າງ, ເບິ່ງ [`TryIter`]).
//!
//!
//! [`Iterator`] 's ຄໍານິຍາມຢ່າງເຕັມທີ່ປະກອບມີຈໍານວນຂອງວິທີການອື່ນໆເຊັ່ນກັນ, ແຕ່ພວກເຂົາເຈົ້າແມ່ນວິທີການເລີ່ມຕົ້ນ, ການກໍ່ສ້າງກ່ຽວກັບການເທິງຂອງ [`next`], ແລະດັ່ງນັ້ນທ່ານໄດ້ຮັບໃຫ້ເຂົາເຈົ້າສໍາລັບການຟຣີ.
//!
//! iterators ແມ່ນຍັງນັກປະພັນເພງ, ແລະມັນຂອງທົ່ວໄປລະບົບຕ່ອງໂສ້ດ້ວຍກັນເພື່ອເຮັດແນວໃດຮູບແບບສະລັບສັບຊ້ອນຫຼາຍຂອງການປຸງແຕ່ງ.ເບິ່ງພາກ [Adapters](#adapters) ຂ້າງລຸ່ມນີ້ ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # ສາມຮູບແບບຂອງ iteration
//!
//! ມີສາມວິທີການທົ່ວໄປທີ່ສາມາດສ້າງ iterators ຈາກເກັບກໍາຂໍ້ມູນມີດັ່ງນີ້:
//!
//! * `iter()`, ທີ່ iterates ໃນໄລຍະ `&T`.
//! * `iter_mut()`, ເຊິ່ງ iterates ຫຼາຍກວ່າ `&mut T`.
//! * `into_iter()`, ທີ່ iterates ໃນໄລຍະ `T`.
//!
//! ສິ່ງຕ່າງໆໃນຫ້ອງສະຫມຸດມາດຕະຖານອາດຈະໃຊ້ຫນຶ່ງຫຼືຫຼາຍກວ່າຂອງສາມ, ບ່ອນທີ່ເຫມາະສົມ.
//!
//! # ການນໍາ Iterator
//!
//! ການສ້າງເປັນ iterator ຂອງທ່ານເອງກ່ຽວຂ້ອງກັບສອງຂັ້ນຕອນ: ການສ້າງ `struct` ໃຫ້ລັດ iterator ຂອງ, ແລະຫຼັງຈາກນັ້ນປະຕິບັດ [`Iterator`] ສໍາລັບ `struct` ວ່າ.
//! ນີ້ແມ່ນເປັນຫຍັງຈຶ່ງມີຈໍານວນຫຼາຍດັ່ງນັ້ນ `struct`s ໃນໂມດູນນີ້: ບໍ່ມີຫນຶ່ງສໍາລັບແຕ່ລະ iterator ແລະອະແດບເຕີ iterator.
//!
//! ໃຫ້ຂອງເຮັດໃຫ້ iterator ທີ່ມີຊື່ `Counter` ທີ່ນັບຈາກ `1` ກັບ `5`:
//!
//! ```
//! // ຫນ້າທໍາອິດ, ໄດ້ struct:
//!
//! /// ເປັນ iterator ທີ່ນັບຈາກຫນຶ່ງຫາຫ້າ
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ພວກເຮົາຕ້ອງນັບຂອງພວກເຮົາຈະເລີ່ມຕົ້ນທີ່ຫນຶ່ງ, ສະນັ້ນໃຫ້ຂອງເພີ່ມວິທີການ new() ກັບການຊ່ວຍເຫຼືອ.
//! // ນີ້ບໍ່ແມ່ນມີຄວາມຈໍາເປັນຢ່າງເຂັ້ມງວດ, ແຕ່ສະດວກ.
//! // ໃຫ້ສັງເກດວ່າພວກເຮົາເລີ່ມຕົ້ນ `count` ຢູ່ສູນ, ພວກເຮົາຈະເບິ່ງວ່າເປັນຫຍັງໃນການດໍາເນີນ `next()`'s ຕ່ໍາກວ່າ.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // ຫຼັງຈາກນັ້ນ, ພວກເຮົາປະຕິບັດ `Iterator` ສໍາລັບ `Counter` ຂອງພວກເຮົາ:
//!
//! impl Iterator for Counter {
//!     // ພວກເຮົາຈະໄດ້ຮັບການນັບກັບ usize
//!     type Item = usize;
//!
//!     // next() ແມ່ນວິທີການທີ່ກໍານົດໄວ້ພຽງແຕ່
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // ເພີ່ມຄ່ານັບຂອງພວກເຮົາ.ນີ້ແມ່ນເຫດຜົນທີ່ພວກເຮົາເລີ່ມຕົ້ນທີ່ສູນ.
//!         self.count += 1;
//!
//!         // ກວດສອບເພື່ອເບິ່ງວ່າພວກເຮົາໄດ້ຄິດໄລ່ໄດ້ສໍາເລັດຫຼືບໍ່.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // ແລະໃນປັດຈຸບັນພວກເຮົາສາມາດນໍາໃຊ້ມັນ!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! ການໂທຫາ [`next`] ດ້ວຍວິທີນີ້ຊໍ້າຊໍ້າ.Rust ມີ construct ທີ່ສາມາດໂທຫາ [`next`] ກ່ຽວກັບ iterator ຂອງທ່ານ, ຈົນກ່ວາມັນໄປຮອດ `None` ໄດ້.ໃຫ້ຂອງໄປຫຼາຍກວ່າທີ່ຕໍ່ໄປ.
//!
//! ຍັງໄດ້ສັງເກດວ່າ `Iterator` ໃຫ້ການປະຕິບັດໃນຕອນຕົ້ນຂອງວິທີການດັ່ງກ່າວເປັນ `nth` ແລະ `fold` ທີ່ເອີ້ນ `next` ຢູ່ພາຍໃນ.
//! ຢ່າງໃດກໍຕາມ, ມັນຍັງເປັນໄປໄດ້ທີ່ຈະຂຽນເປັນການປະຕິບັດກໍາຫນົດເອງຂອງວິທີການຄ້າຍຄື `nth` ແລະ `fold` ຖ້າ iterator ສາມາດຄໍານວນໃຫ້ເຂົາເຈົ້າປະສິດທິຜົນຫຼາຍໂດຍບໍ່ມີການໂທຫາ `next`.
//!
//! # `for` loops ແລະ `IntoIterator`
//!
//! syntax loop `for` ຂອງ Rust ແມ່ນຕົວຈິງ ສຳ ລັບນ້ ຳ ຕານ.ຕໍ່ໄປນີ້ແມ່ນຕົວຢ່າງພື້ນຖານຂອງ `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! ນີ້ຈະພິມຈໍານວນຫນຶ່ງໂດຍຜ່ານຫ້າ, ແຕ່ລະກ່ຽວກັບເສັ້ນຂອງຕົນເອງຂອງເຂົາເຈົ້າ.ແຕ່ວ່າທ່ານຈະສັງເກດເຫັນບາງສິ່ງບາງຢ່າງທີ່ນີ້: ພວກເຮົາບໍ່ເຄີຍເອີ້ນວ່າຫຍັງກ່ຽວກັບ vector ຂອງຕົນຜະລິດເປັນ iterator.ສິ່ງທີ່ໃຫ້?
//!
//! ມີ trait ຢູ່ໃນຫ້ອງສະຫມຸດມາດຕະຖານສໍາລັບການເປັນບາງສິ່ງບາງຢ່າງເຂົ້າໄປໃນ iterator: [`IntoIterator`].
//! trait ນີ້ມີຫນຶ່ງວິທີການ, [`into_iter`] 'ທີ່ຊ່ວຍປ່ຽນສິ່ງທີ່ປະຕິບັດ [`IntoIterator`] ເປັນ iterator.
//! ລອງພິຈາລະນາເບິ່ງວ່າ `for` loop ອີກເທື່ອ ໜຶ່ງ, ແລະສິ່ງທີ່ຜູ້ລວບລວມຂໍ້ມູນນັ້ນປ່ຽນເປັນ:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust ນີ້ de-sugars ເຂົ້າໄປໃນ:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! ຫນ້າທໍາອິດ, ພວກເຮົາໂທຫາ `into_iter()` ມູນຄ່າ.ຫຼັງຈາກນັ້ນ, ພວກເຮົາກົງກັບ iterator ທີ່ຜົນຕອບແທນ, ໂທ [`next`] ໃນໄລຍະແລະຫຼາຍກວ່າຈົນກ່ວາພວກເຮົາເຫັນ `None`.
//! ໃນເວລານັ້ນ, ພວກເຮົາ `break` ອອກຈາກ loop ໄດ້, ແລະພວກເຮົາກໍາລັງເຮັດຊ້ໍາເຮັດ.
//!
//! ມີຄົນ bit ລະອຽດເພີ່ມເຕີມທີ່ນີ້: ຫ້ອງສະຫມຸດມາດຕະຖານປະກອບດ້ວຍການປະຕິບັດທີ່ຫນ້າສົນໃຈຂອງ [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ທັງຫມົດ [`Iterator`] s ໃຊ້ [`IntoIterator`], ໂດຍພຽງແຕ່ກັບຄືນດ້ວຍຕົນເອງ.ນີ້ຫມາຍຄວາມວ່າທັງສອງສິ່ງທີ່:
//!
//! 1. ຖ້າຫາກວ່າທ່ານກໍາລັງຂຽນເປັນ [`Iterator`], ທ່ານສາມາດນໍາໃຊ້ມັນມີຫ່ວງ `for`.
//! 2. ຖ້າທ່ານ ກຳ ລັງສ້າງຊຸດສະສົມ, ປະຕິບັດ [`IntoIterator`] ສຳ ລັບມັນຈະຊ່ວຍໃຫ້ການລວບລວມຂອງທ່ານຖືກ ນຳ ໃຊ້ກັບຊ່ອງ `for`.
//!
//! # iterating ໂດຍອ້າງອິງ
//!
//! ເນື່ອງຈາກວ່າ [`into_iter()`] ໃຊ້ເວລາ `self` ໂດຍມູນຄ່າ, ການນໍາໃຊ້ວົງ `for` ກັບ iterate ໃນໄລຍະການເກັບກໍາ consumes ວ່າການເກັບກໍາ.ປົກກະຕິແລ້ວ, ທ່ານອາດຈະຕ້ອງການທີ່ຈະ iterate ໃນໄລຍະເກັບກໍາຂໍ້ມູນໂດຍບໍ່ມີການຊົມໃຊ້ມັນ.
//! ການລວບລວມຂໍ້ມູນຫຼາຍສະ ເໜີ ວິທີການທີ່ສະ ໜອງ ວັດຖຸດິບຜ່ານເອກະສານອ້າງອີງ, ເຊິ່ງເອີ້ນວ່າ `iter()` ແລະ `iter_mut()` ຕາມ ລຳ ດັບ:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ຍັງຄົງເປັນເຈົ້າຂອງໂດຍຟັງຊັນນີ້.
//! ```
//!
//! ຖ້າປະເພດການລວບລວມ `C` ໃຫ້ `iter()`, ມັນມັກຈະປະຕິບັດ `IntoIterator` ສໍາລັບ `&C`, ໂດຍມີການປະຕິບັດທີ່ພຽງແຕ່ເອີ້ນວ່າ `iter()`.
//! ນອກຈາກນັ້ນ, ການເກັບກໍາ `C` ທີ່ສະຫນອງໂດຍທົ່ວໄປ `iter_mut()` ດໍາເນີນ `IntoIterator` ສໍາລັບ `&mut C` ໂດຍກະຈາຍການ `iter_mut()`.ນີ້ເຮັດໃຫ້ເປັນຊະວະເລກສະດວກ:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // ເຊັ່ນດຽວກັນກັບ `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // ເຊັ່ນດຽວກັນກັບ `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! ໃນຂະນະທີ່ການເກັບຈໍານວນຫຼາຍສະເຫນີ `iter()`, ບໍ່ແມ່ນທັງຫມົດສະເຫນີ `iter_mut()`.
//! ຍົກຕົວຢ່າງ, ການແລກປ່ຽນລະຫັດຂອງ [`HashSet<T>`] ຫຼື [`HashMap<K, V>`] ສາມາດເຮັດໃຫ້ການລວບລວມເຂົ້າໄປໃນສະຖານະການທີ່ບໍ່ສອດຄ່ອງຖ້າຫາກວ່າ hashes key ມີການປ່ຽນແປງ, ສະນັ້ນການລວບລວມຂໍ້ມູນເຫຼົ່ານີ້ສະ ເໜີ `iter()` ເທົ່ານັ້ນ.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! ປະຕິບັດຫນ້າທີ່ໃຊ້ເວລາເປັນ [`Iterator`] ແລະກັບຄືນ [`Iterator`] ອື່ນມັກຈະຖືກເອີ້ນວ່າ 'ອະແດບເຕີ iterator', ຍ້ອນວ່າເຂົາເຈົ້າກໍາລັງຮູບແບບຂອງ 'ຜູ້ດັດແປງເປັນ
//! pattern'.
//!
//! ເຄື່ອງປັບອາກາດທົ່ວໄປລວມມີ [`map`], [`take`], ແລະ [`filter`].
//! ຂໍ້ມູນເພີ່ມເຕີມ, ເບິ່ງເອກະສານຂອງເຂົາເຈົ້າ.
//!
//! ຖ້າຫາກວ່າເປັນ iterator ຜູ້ດັດແປງ panics, iterator ທີ່ຈະຢູ່ໃນທີ່ບໍ່ລະບຸ (ແຕ່ປອດໄພຄວາມຊົງຈໍາ) ລັດ.
//! ຣັຖນີ້ແມ່ນຍັງບໍ່ຮັບປະກັນທີ່ຈະຍັງຢູ່ຄືເກົ່າໃນທົ່ວສະບັບຂອງ Rust, ດັ່ງນັ້ນທ່ານຄວນຫຼີກເວັ້ນການອາໄສຢູ່ໃນຄ່າຄືກັນອ້ອຍຕ້ອຍກັບຄືນໂດຍ iterator ທີ່ພາກັນຢ້ານກົວ.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! iterators (ແລະ [adapters](#adapters)) iterator ແມ່ນ * * lazy. ຫມາຍຄວາມວ່ານີ້ວ່າພຽງແຕ່ການສ້າງເປັນ iterator ບໍ່ _do_ ຫຼາຍທັງຫມົດ. ບໍ່ມີຫຍັງແທ້ທີ່ເກີດຂຶ້ນຈົນກວ່າທ່ານຈະໂທຫາ [`next`].
//! ນີ້ແມ່ນບາງຄັ້ງແຫລ່ງທີ່ມາຂອງຄວາມສັບສົນໃນເວລາທີ່ການສ້າງເປັນ iterator solely ສໍາລັບຜົນຂ້າງຄຽງຂອງຕົນ.
//! ສໍາລັບຕົວຢ່າງ, ໃນວິທີການ [`map`] ຮຽກຮ້ອງໃຫ້ເປັນການປິດໃນແຕ່ລະອົງປະກອບມັນ iterates ໃນໄລຍະ:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! ນີ້ຈະບໍ່ພິມຄ່າໃດກໍ່ຕາມ, ດັ່ງທີ່ພວກເຮົາໄດ້ສ້າງພຽງແຕ່ເປັນ iterator, ແທນທີ່ຈະກ່ວາການນໍາໃຊ້ມັນ.ນັກຂຽນຈະເຕືອນພວກເຮົາກ່ຽວກັບພຶດຕິ ກຳ ແບບນີ້:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! ວິທີ idiomatic ໃນການຂຽນ [`map`] ສຳ ລັບຜົນຂ້າງຄຽງຂອງມັນແມ່ນການໃຊ້ `for` loop ຫລືໂທຫາວິທີ [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! ອີກວິທີ ໜຶ່ງ ທີ່ ທຳ ມະດາໃນການປະເມີນເຄື່ອງປັບແມ່ນໃຊ້ວິທີ [`collect`] ເພື່ອຜະລິດຊຸດສະສົມ ໃໝ່.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! iterators ບໍ່ຈໍາເປັນຕ້ອງເປັນ finite.ໃນຖານະເປັນຕົວຢ່າງ, ເປັນລະດັບເປີດສິ້ນສຸດລົງເປັນ iterator infinite:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! ມັນເປັນທີ່ຈະໃຊ້ຂອງຜູ້ດັດແປງ iterator [`take`] ເຮັດໃຫ້ເປັນ iterator ນິດເຂົ້າໄປໃນຂອບເຂດຫນຶ່ງ:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! ນີ້ຈະພິມຕົວເລກ `0` ຜ່ານ `4`, ແຕ່ລະເສັ້ນຢູ່ໃນເສັ້ນຂອງພວກເຂົາເອງ.
//!
//! ຮັບຜິດຊອບໃນຈິດໃຈທີ່ວິທີການກ່ຽວກັບການ iterators infinite, ແມ້ກະທັ້ງຜູ້ທີ່ເປັນຜົນສາມາດໄດ້ຮັບການກໍານົດຄະນິດສາດໃນເວລາທີ່ຈໍາກັດ, ບໍ່ສາມາດຢຸດຕິ.
//! ໂດຍສະເພາະ, ວິທີການຕ່າງໆເຊັ່ນ [`min`], ເຊິ່ງໃນກໍລະນີທົ່ວໄປຮຽກຮ້ອງໃຫ້ມີການເຄື່ອນຍ້າຍທຸກໆອົງປະກອບທີ່ຢູ່ໃນຕົວປັບ, ມີແນວໂນ້ມທີ່ຈະບໍ່ກັບມາປະສົບຜົນ ສຳ ເລັດ ສຳ ລັບຕົວປ່ຽນແປງທີ່ບໍ່ມີຂອບເຂດ.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // ໂອບໍ່!ເປັນ loop infinite!
//! // `ones.min()` ສາເຫດຂອງວົງທີ່ບໍ່ມີຂອບເຂດ, ສະນັ້ນພວກເຮົາຈະບໍ່ເຂົ້າເຖິງຈຸດນີ້!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;