/// ເປັນ iterator ທີ່ສະເຫມີຍັງຈະສືບຕໍ່ໃຫ້ຜົນຜະລິດໃນເວລາທີ່ `None` ຫມົດ.
///
/// ໂທຫາຕໍ່ໄປໃນ fused iterator ທີ່ໄດ້ກັບຄືນ `None` ຄັ້ງແມ່ນຮັບປະກັນໃຫ້ກັບຄືນ [`None`] ອີກເທື່ອຫນຶ່ງ.
/// trait ນີ້ຄວນໄດ້ຮັບການປະຕິບັດໂດຍ iterators ທັງຫມົດທີ່ປະຕິບັດຕົວວິທີການນີ້ເນື່ອງຈາກວ່າມັນອະນຸຍາດໃຫ້ເພີ່ມ [`Iterator::fuse()`].
///
///
/// Note: ໂດຍທົ່ວໄປ, ທ່ານບໍ່ຄວນໃຊ້ `FusedIterator` ໃນຂອບເຂດທົ່ວຖ້າຫາກວ່າທ່ານຕ້ອງການ fused iterator.
/// ແທນທີ່ຈະ, ທ່ານພຽງແຕ່ຄວນໂທ [`Iterator::fuse()`] ກ່ຽວກັບ iterator ໄດ້.
/// ຖ້າ iterator ໄດ້ແມ່ນ fused ແລ້ວ, ໄດ້ wrapper [`Fuse`] ເພີ່ມເຕີມຈະບໍ່ມີ op ກັບໂທດປະສິດທິພາບບໍ່ມີ.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// ເປັນ iterator ທີ່ລາຍງານເປັນໄລຍະທີ່ຖືກຕ້ອງໃຊ້ size_hint.
///
/// The iterator ລາຍງານຄໍາແນະນໍາທີ່ຂະຫນາດທີ່ມັນເປັນບໍ່ວ່າຈະຄືກັນອ້ອຍຕ້ອຍ (ໃບຢັ້ງຢືນຜູກພັນແມ່ນເທົ່າທຽມກັນກັບຜູກເທິງ), ຫຼືຜູກມັດເທິງແມ່ນ [`None`].
///
/// ການຕ້ອງຮີບເທິງເທົ່ານັ້ນຈະ [`None`] ຖ້າຍາວ iterator ຕົວຈິງແມ່ນຂະຫນາດໃຫຍ່ກ່ວາ [`usize::MAX`].
/// ໃນກໍລະນີດັ່ງກ່າວ, ຂອບເຂດຕ່ ຳ ຕ້ອງແມ່ນ [`usize::MAX`], ສົ່ງຜົນໃຫ້ [`Iterator::size_hint()`] ຂອງ `(usize::MAX, None)`.
///
/// The iterator ຕ້ອງຜະລິດແທ້ຈໍານວນຂອງອົງປະກອບມັນລາຍງານຫຼື divergent ໄດ້ກ່ອນທີ່ຈະເຖິງທີ່ສຸດ.
///
/// # Safety
///
/// trait ນີ້ຕ້ອງໄດ້ກໍ່ພຽງແຕ່ໃນເວລາທີ່ສັນຍາໄດ້ຖືກແຕ່ງຕັ້ງ.
/// ຜູ້ບໍລິໂພກຂອງ trait ນີ້ຕ້ອງໄດ້ກວດກາ [`Iterator::size_hint()`]’s ຜູກເທິງ.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// ເປັນ iterator ທີ່ໃນເວລາທີ່ຜົນຜະລິດລາຍການຈະໄດ້ປະຕິບັດອົງປະກອບຢ່າງຫນ້ອຍຫນຶ່ງຈາກຕິດພັນ [`SourceIter`] ຂອງຕົນ.
///
/// ໂທຫາວິທີການທີ່ກ້າວຫນ້າ iterator ໄດ້, ຕົວຢ່າງ:
/// [`next()`] ຫຼື [`try_fold()`], ຮັບປະກັນວ່າສໍາລັບແຕ່ລະຂັ້ນຕອນມູນຄ່າຢ່າງຫນ້ອຍຫນຶ່ງໃນແຫຼ່ງທີ່ຕິດພັນ iterator ຂອງໄດ້ຖືກຍ້າຍອອກແລະຜົນມາຈາກລະບົບຕ່ອງໂສ້ iterator ອາດຈະ inserted ໃນສະຖານທີ່ຂອງຕົນ, ສົມມຸດວ່າຂໍ້ຈໍາກັດໂຄງສ້າງຂອງຂໍ້ມູນດັ່ງກ່າວອະນຸຍາດໃຫ້ແຊກໄດ້.
///
/// ໃນຄໍາສັບຕ່າງໆອື່ນໆ trait ນີ້ຊີ້ໃຫ້ເຫັນວ່າທໍ່ iterator ສາມາດໄດ້ຮັບການເກັບກໍາຂໍ້ມູນໃນສະຖານທີ່.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}