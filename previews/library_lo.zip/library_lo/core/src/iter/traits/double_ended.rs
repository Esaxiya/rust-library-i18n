use crate::ops::{ControlFlow, Try};

/// ເປັນ iterator ສາມາດອົງປະກອບຜົນຜະລິດຈາກສອງສົ້ນ.
///
/// ບາງສິ່ງບາງຢ່າງທີ່ປະຕິບັດ `DoubleEndedIterator` ມີຄວາມສາມາດພິເສດ ໜຶ່ງ ຕໍ່ບາງສິ່ງບາງຢ່າງທີ່ປະຕິບັດກັບ [`Iterator`]: ຄວາມສາມາດໃນການ ນຳ ເອົາ `It`` ຈາກດ້ານຫຼັງ, ພ້ອມທັງດ້ານ ໜ້າ.
///
///
/// ມັນເປັນສິ່ງສໍາຄັນທີ່ຈະສັງເກດວ່າທັງສອງກັບຄືນໄປບ່ອນແລະດັງນີ້ຕໍ່ໄປການເຮັດວຽກກ່ຽວກັບລະດັບດຽວກັນ, ແລະເຮັດແນວໃດໄດ້ກາ: iteration ແມ່ນໃນໄລຍະເວລາທີ່ພວກເຂົາເຈົ້າຕອບສະຫນອງໃນປານກາງ.
///
/// ໃນວິທີການຄ້າຍຄືກັນກັບອະນຸສັນຍາ [`Iterator`], ເມື່ອເປັນ `DoubleEndedIterator` ໃຫ້ຜົນໄດ້ຮັບ [`None`] ຈາກ [`next_back()`], ໂທຫາມັນອີກເທື່ອຫນຶ່ງອາດຈະຫຼືອາດຈະບໍ່ເຄີຍກັບຄືນ [`Some`] ອີກເທື່ອຫນຶ່ງ.
/// [`next()`] ແລະ [`next_back()`] ແມ່ນ interchangeable ສໍາລັບຈຸດປະສົງນີ້.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// ລົບແລະຜົນຕອບແທນເປັນອົງປະກອບຈາກຕອນທ້າຍຂອງ iterator ໄດ້.
    ///
    /// ຜົນໄດ້ຮັບໃນເວລາທີ່ `None` ບໍ່ມີອົງປະກອບເພີ່ມເຕີມ.
    ///
    /// ເອກສານ [trait-level] ປະກອບດ້ວຍລາຍລະອຽດເພີ່ມເຕີມ.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// ອົງປະກອບຂອງຜົນຜະລິດໂດຍ `ວິທີ DoubleEndedIterator` ອາດມີຄວາມແຕກຕ່າງຈາກບໍ່ໄດ້ຜົນຜະລິດໂດຍວິທີການ [`Iterator`] 's:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// ຄວາມກ້າວຫນ້າ iterator ຈາກກັບຄືນໄປບ່ອນໂດຍອົງປະກອບ `n` ໄດ້.
    ///
    /// `advance_back_by` ເປັນສະບັບພາສາໄດ້ຢ່າງສິ້ນເຊີງຂອງ [`advance_by`].ວິທີການນີ້ກະຫາຍທີ່ຈະຂ້າມອົງປະກອບ `n` ເລີ່ມຈາກໄປໂດຍການໂທຫາ [`next_back`] ເຖິງເວລາທີ່ `n` ຈົນກ່ວາ [`None`] ແມ່ນພົບ.
    ///
    /// `advance_back_by(n)` ຈະກັບຄືນ [`Ok(())`] ຖ້າ iterator ໄດ້ສົບຜົນສໍາເລັດຄວາມກ້າວຫນ້າໂດຍອົງປະກອບ `n` ຫລື [`Err(k)`] ຖ້າ [`None`] ແມ່ນພົບ, ບ່ອນທີ່ `k` ແມ່ນຈໍານວນຂອງອົງປະກອບດັ່ງກ່າວ iterator ເຖິງຂັ້ນໂດຍກ່ອນທີ່ຈະແລ່ນອອກຈາກອົງປະກອບ (ie
    /// ຄວາມຍາວຂອງຕົວປ່ຽນແປງ).
    /// ໃຫ້ສັງເກດວ່າ `k` ແມ່ນສະເຫມີໄປຫນ້ອຍກ່ວາ `n`.
    ///
    /// ການໂທຫາ `advance_back_by(0)` ບໍ່ບໍລິໂພກອົງປະກອບໃດໆແລະຈະກັບຄືນ [`Ok(())`] ສະເຫມີ.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // ພຽງແຕ່ `&3` ໄດ້ຂ້າມ
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// ຜົນຕອບແທນທີ່ `ອົງປະກອບ n`th ຈາກຕອນທ້າຍຂອງ iterator ໄດ້.
    ///
    /// ນີ້ເປັນສິ່ງຈໍາເປັນສະບັບພາສາໄດ້ຢ່າງສິ້ນເຊີງຂອງ [`Iterator::nth()`].
    /// ເຖິງແມ່ນວ່າການດໍາເນີນງານເຊັ່ນ: ດັດຊະນີຫຼາຍທີ່ສຸດ, ນັບຈະເລີ່ມຈາກສູນ, ສະນັ້ນ `nth_back(0)` ສົ່ງກັບຄ່າທໍາອິດຈາກຕອນສຸດທ້າຍ, `nth_back(1)` ຄັ້ງທີສອງ, ແລະອື່ນໆ.
    ///
    ///
    /// ໃຫ້ສັງເກດວ່າອົງປະກອບທັງຫມົດລະຫວ່າງໃນຕອນທ້າຍແລະອົງປະກອບທີ່ສົ່ງກັບຈະຖືກບໍລິໂພກ, ລວມທັງອົງປະກອບກັບຄືນໄດ້.
    /// ນີ້ຫມາຍຄວາມວ່າໂທຫາ `nth_back(0)` ຫຼາຍຄັ້ງກ່ຽວກັບ iterator ດຽວກັນຈະກັບຄືນອົງປະກອບທີ່ແຕກຕ່າງກັນ.
    ///
    /// `nth_back()` ຈະກັບຄືນ [`None`] ຖ້າ `n` ແມ່ນຫຼາຍກ່ວາຫຼືເທົ່າກັບຄວາມຍາວຂອງ iterator ໄດ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// ໂທ `nth_back()` ຫຼາຍຄັ້ງບໍ່ໄດ້ຍ້ອນ iterator ໄດ້:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// ກັບຄືນ `None` ຖ້າມີຫນ້ອຍກ່ວາອົງປະກອບ `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// ນີ້ແມ່ນຮຸ່ນປີ້ນກັບກັນຂອງ [`Iterator::try_fold()`]: ມັນໃຊ້ເວລາອົງປະກອບເລີ່ມຈາກດ້ານຫລັງຂອງໂຕປັບ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // ເນື່ອງຈາກວ່າມັນສັ້ນ circuited, ອົງປະກອບທີ່ຍັງເຫຼືອຍັງສາມາດໃຊ້ໄດ້ຜ່ານ iterator ໄດ້.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ເປັນວິທີການ iterator ວ່າການຫຼຸດຜ່ອນອົງປະກອບ iterator ໃນການດຽວ, ມູນຄ່າສຸດທ້າຍໂດຍເລີ່ມຈາກໄປ.
    ///
    /// ນີ້ແມ່ນການສະບັບໄດ້ຢ່າງສິ້ນເຊີງຂອງ [`Iterator::fold()`]: ມັນໃຊ້ເວລາອົງປະກອບເລີ່ມຕົ້ນຈາກດ້ານຫລັງຂອງ iterator ໄດ້.
    ///
    /// `rfold()` ໃຊ້ເວລາທັງສອງກະທູ້: ເປັນຄ່າເລີ່ມຕົ້ນ, ແລະປິດດ້ວຍສອງອາກິວເມນ: ເປັນ 'accumulator', ແລະອົງປະກອບໄດ້.
    /// ການປິດໃຫ້ຜົນໄດ້ຮັບມູນຄ່າທີ່ສະສົມຄວນມີສໍາລັບ iteration ຕໍ່ໄປ.
    ///
    /// ຄ່າເລີ່ມຕົ້ນແມ່ນມູນຄ່າທີ່ຜູ້ສະສົມຈະມີໃນການໂທຄັ້ງ ທຳ ອິດ.
    ///
    /// ຫຼັງຈາກຍື່ນຄໍາຮ້ອງຂໍການປິດນີ້ອົງປະກອບຂອງ iterator ໃນທຸກໆ, `rfold()` ໃຫ້ຜົນໄດ້ຮັບສະສົມໄດ້.
    ///
    /// ການປະຕິບັດງານນີ້ບາງຄັ້ງກໍ່ເອີ້ນວ່າ 'reduce' ຫຼື 'inject'.
    ///
    /// ພັບເປັນປະໂຫຍດທຸກຄັ້ງທີ່ທ່ານມີການເກັບກໍາບາງສິ່ງບາງຢ່າງ, ແລະຕ້ອງການທີ່ຈະຜະລິດເປັນມູນຄ່າດຽວຈາກມັນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ຜົນລວມຂອງທັງຫມົດຂອງອົງປະກອບຂອງໄດ້
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ຕົວຢ່າງນີ້ສ້າງສາຍ, ເລີ່ມຕົ້ນດ້ວຍຄ່າເລີ່ມຕົ້ນແລະສືບຕໍ່ແຕ່ລະອົງປະກອບຈາກທາງຫລັງຈົນກ່ວາທາງ ໜ້າ:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// ຄົ້ນຫາສໍາລັບອົງປະກອບຂອງ iterator ຈາກກັບຄືນໄປບ່ອນທີ່ satisfies ເປັນຢາໄດ້.
    ///
    /// `rfind()` ໃຊ້ເວລາປິດທີ່ໃຫ້ຜົນໄດ້ຮັບ `true` ຫຼື `false` ໄດ້.
    /// ມັນໃຊ້ໄດ້ປິດນີ້ອົງປະກອບຂອງ iterator ຂອງແຕ່ລະຄົນ, ເລີ່ມຕົ້ນຢູ່ໃນຕອນທ້າຍຂອງ, ແລະຖ້າມີການໃຫ້ເຂົາເຈົ້າກັບຄືນ `true`, ຫຼັງຈາກນັ້ນຜົນໄດ້ຮັບ `rfind()` [`Some(element)`].
    /// ຖ້າພວກເຂົາທັງ ໝົດ ກັບຄືນ `false`, ມັນຈະສົ່ງຄືນ [`None`].
    ///
    /// `rfind()` ສັ້ນວົງຈອນ;ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ມັນຈະຢຸດການປຸງແຕ່ງທັນທີທີ່ການປິດຈະກັບຄືນ `true`.
    ///
    /// ເນື່ອງຈາກວ່າ `rfind()` ໃຊ້ເວລາກະສານອ້າງອີງ, ແລະ iterators ຫຼາຍ iterate ໃນໄລຍະເອກະສານ, ເຮັດໃຫ້ນີ້ເປັນສະຖານະການເປັນໄປໄດ້ຂອງເຊື້ອຕະກຸນທີ່ໂຕ້ຖຽງແມ່ນກະສານອ້າງອີງເທົ່ານັ້ນ.
    ///
    /// ທ່ານສາມາດເບິ່ງຜົນກະທົບນີ້ໃນຕົວຢ່າງຂ້າງລຸ່ມນີ້, ມີ `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// ຂາຍຢູ່ທີ່ທໍາອິດ `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // ພວກເຮົາຍັງສາມາດໃຊ້ `iter`, ເນື່ອງຈາກວ່າມີອົງປະກອບເພີ່ມເຕີມ.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}