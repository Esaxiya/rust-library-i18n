/// ການແປງຈາກ [`Iterator`].
///
/// ໂດຍປະຕິບັດ `FromIterator` ສໍາລັບຊະນິດ, ທ່ານກໍານົດວິທີການມັນຈະໄດ້ຮັບການສ້າງຕັ້ງຂື້ນຈາກການ iterator.
/// ນີ້ມັກເກີດຂື້ນປະເພດທີ່ອະທິບາຍການເກັບກໍາບາງປະເພດໄດ້.
///
/// [`FromIterator::from_iter()`] ແມ່ນບໍ່ຄ່ອຍຈະເອີ້ນວ່າຢ່າງຊັດເຈນ, ແລະຖືກນໍາໃຊ້ແທນທີ່ຈະຜ່ານວິທີການ [`Iterator::collect()`].
///
/// ເບິ່ງເອກະສານ [`Iterator::collect()`]'s ສຳ ລັບຕົວຢ່າງເພີ່ມເຕີມ.
///
/// ເບິ່ງຕື່ມ: [`IntoIterator`].
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// ການນໍາໃຊ້ [`Iterator::collect()`] ກັບ implicitly ໃຊ້ `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// ປະຕິບັດ `FromIterator` ສໍາລັບປະເທດຂອງທ່ານ:
///
/// ```
/// use std::iter::FromIterator;
///
/// // ການເກັບລວບລວມຕົວຢ່າງ, ນັ້ນແມ່ນພຽງແຕ່ຫໍ່ຂອງ Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ໃຫ້ຂອງໃຫ້ມັນວິທີການຈໍານວນຫນຶ່ງດັ່ງນັ້ນພວກເຮົາສາມາດສ້າງຫນຶ່ງແລະເພີ່ມສິ່ງທີ່ມັນ.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ແລະພວກເຮົາຈະຈັດຕັ້ງປະຕິບັດ FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // ໃນປັດຈຸບັນພວກເຮົາສາມາດເຮັດໃຫ້ເປັນ iterator ໃຫມ່ ...
/// let iter = (0..5).into_iter();
///
/// // ... ແລະເຮັດໃຫ້ MyCollection ອອກຈາກມັນ
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // ເກັບ ກຳ ຜົນງານຄືກັນ!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// ສ້າງຄ່າຈາກ iterator.
    ///
    /// ເບິ່ງ [module-level documentation] ສຳ ລັບເພີ່ມເຕີມ.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// ແປງເຂົ້າໄປໃນ [`Iterator`].
///
/// ໂດຍການຈັດຕັ້ງປະຕິບັດ `IntoIterator` ສຳ ລັບປະເພດໃດ ໜຶ່ງ, ທ່ານ ກຳ ນົດວິທີທີ່ມັນຈະຖືກປ່ຽນເປັນຕົວປັບ.
/// ນີ້ມັກເກີດຂື້ນປະເພດທີ່ອະທິບາຍການເກັບກໍາບາງປະເພດໄດ້.
///
/// ຜົນປະໂຫຍດຂອງການປະຕິບັດ `IntoIterator` ແມ່ນວ່າປະເທດຂອງທ່ານຈະ [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// ເບິ່ງຕື່ມ: [`FromIterator`].
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// ປະຕິບັດ `IntoIterator` ສໍາລັບປະເທດຂອງທ່ານ:
///
/// ```
/// // ການເກັບລວບລວມຕົວຢ່າງ, ນັ້ນແມ່ນພຽງແຕ່ຫໍ່ຂອງ Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ໃຫ້ຂອງໃຫ້ມັນວິທີການຈໍານວນຫນຶ່ງດັ່ງນັ້ນພວກເຮົາສາມາດສ້າງຫນຶ່ງແລະເພີ່ມສິ່ງທີ່ມັນ.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ແລ້ວພວກເຮົາຈະປະຕິບັດ IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // ໃນປັດຈຸບັນພວກເຮົາສາມາດເຮັດໃຫ້ເປັນການເກັບກໍາໃຫມ່ ...
/// let mut c = MyCollection::new();
///
/// // ... ເພີ່ມເນື້ອຫາບາງຢ່າງທີ່ຈະມັນ ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ແລະຫຼັງຈາກນັ້ນເຮັດໃຫ້ມັນເຂົ້າໄປໃນ Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// ມັນເປັນທີ່ຈະໃຊ້ `IntoIterator` ເປັນ trait bound.ນີ້ອະນຸຍາດໃຫ້ input type ເກັບກໍາຂໍ້ມູນການປ່ຽນແປງ, ສະນັ້ນຕາບໃດທີ່ມັນຍັງຄົງເປັນ iterator.
/// ຂອບເຂດເພີ່ມເຕີມສາມາດໄດ້ຮັບການກໍານົດໂດຍຈໍາກັດກ່ຽວກັບ
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// ປະເພດຂອງອົງປະກອບທີ່ຖືກ iterated ໃນໄລຍະ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ເຊິ່ງປະເພດຂອງ iterator ພວກເຮົາປ່ຽນເປັນສີນີ້ເຂົ້າໄປໃນ?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// ສ້າງເປັນ iterator ຈາກຄ່າ.
    ///
    /// ເບິ່ງ [module-level documentation] ສຳ ລັບເພີ່ມເຕີມ.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// ຂະຫຍາຍການເກັບກໍາຂໍ້ມູນທີ່ມີເນື້ອໃນຂອງ iterator ໄດ້.
///
/// iterators ຜະລິດຊຸດຂອງຄ່າ, ແລະການເກັບກູ້ຍັງສາມາດໄດ້ຮັບການຄິດຂອງເປັນຊຸດຂອງຄ່າ.
/// The `Extend` trait ເຊື່ອມຕໍ່ຊ່ອງຫວ່າງນີ້, ຊ່ວຍໃຫ້ທ່ານສາມາດຂະຫຍາຍການເກັບ ກຳ ຂໍ້ມູນໄດ້ໂດຍການລວມເອົາເນື້ອໃນຂອງເຄື່ອງວັດແທກນັ້ນ.
/// ໃນເວລາທີ່ການຂະຫຍາຍການເກັບກໍາທີ່ມີທີ່ສໍາຄັນທີ່ມີຢູ່ແລ້ວ, ການທີ່ຖືກປັບປຸງຫຼື, ໃນກໍລະນີມີການເກັບກູ້ທີ່ອະນຸຍາດໃຫ້ອອກສຽງດ້ວຍໃຊ້ເທົ່າທຽມກັນ, ທີ່ເຂົ້າແມ່ນ inserted.
///
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// // ທ່ານສາມາດຂະຫຍາຍ String ກັບຕົວອັກສອນຈໍານວນຫນຶ່ງເປັນ:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// ຈັດຕັ້ງປະຕິບັດ `Extend`:
///
/// ```
/// // ການເກັບລວບລວມຕົວຢ່າງ, ນັ້ນແມ່ນພຽງແຕ່ຫໍ່ຂອງ Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ໃຫ້ຂອງໃຫ້ມັນວິທີການຈໍານວນຫນຶ່ງດັ່ງນັ້ນພວກເຮົາສາມາດສ້າງຫນຶ່ງແລະເພີ່ມສິ່ງທີ່ມັນ.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ນັບຕັ້ງແຕ່ MyCollection ມີບັນຊີລາຍຊື່ຂອງ i32s, ພວກເຮົາປະຕິບັດຂະຫຍາຍສໍາລັບ i32
/// impl Extend<i32> for MyCollection {
///
///     // ນີ້ແມ່ນນ້ອຍ simpler ກັບລາຍເຊັນປະເພດຊີມັງໄດ້: ພວກເຮົາສາມາດໂທຫາການຂະຫຍາຍການໃນສິ່ງໃດແດ່ທີ່ສາມາດໄດ້ຮັບການຫັນເຂົ້າສູ່ Iterator ທີ່ເຮັດໃຫ້ພວກເຮົາ i32s.
///     // ເນື່ອງຈາກວ່າພວກເຮົາຕ້ອງການ i32s ເພື່ອໃສ່ໃນ MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // ການຈັດຕັ້ງປະຕິບັດແມ່ນກົງໄປກົງມາຫຼາຍທີ່ສຸດ: ເຊື່ອມຕໍ່ຕົວຕັ້ງໂຕະ, ແລະ add() ແຕ່ລະອົງປະກອບໃຫ້ຕົວເຮົາເອງ.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ໃຫ້ຂອງການຂະຫຍາຍການເກັບກໍາຂໍ້ເວັບມີສາມຈໍານວນຫຼາຍ
/// c.extend(vec![1, 2, 3]);
///
/// // ພວກເຮົາໄດ້ເພີ່ມອົງປະກອບເຫຼົ່ານີ້ໃສ່ທີ່ສຸດ
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// ຊ່ວຍຍືດອາການເກັບກໍາທີ່ມີເນື້ອໃນຂອງ iterator ໄດ້.
    ///
    /// ໃນຖານະເປັນນີ້ແມ່ນວິທີການທີ່ກໍານົດໄວ້ເທົ່ານັ້ນສໍາຫລັບ trait ນີ້, ເອກະສານປະກອບດ້ວຍ [trait-level] ລາຍລະອຽດເພີ່ມເຕີມ.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // ທ່ານສາມາດຂະຫຍາຍ String ກັບຕົວອັກສອນຈໍານວນຫນຶ່ງເປັນ:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// ຂະຫຍາຍການລວບລວມດ້ວຍອົງປະກອບ ໜຶ່ງ ຢ່າງແນ່ນອນ.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// ຄວາມອາດສາມາດສໍາຮອງໃນການເກັບກໍາສໍາລັບການຈໍານວນດັ່ງກ່າວຂອງອົງປະກອບເພີ່ມເຕີມໄດ້.
    ///
    /// ການປະຕິບັດໃນຕອນຕົ້ນບໍ່ມີຫຍັງ.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}