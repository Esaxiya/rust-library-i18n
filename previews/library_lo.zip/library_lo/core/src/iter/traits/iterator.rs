// ບໍ່ສົນໃຈ, ກະທັດຮັດ, filelength ເອກະສານນີ້ເກືອບສະເພາະແຕ່ປະກອບດ້ວຍຄໍານິຍາມຂອງ `Iterator` ໄດ້.
// ພວກເຮົາບໍ່ສາມາດແຍກອອກເປັນຫລາຍໆເອກະສານ.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// ເປັນການໂຕ້ຕອບສໍາລັບການຈັດການກັບ iterators.
///
/// ນີ້ແມ່ນຕົວຍີ່ງ ສຳ ຄັນ trait.
/// ສໍາລັບເພີ່ມເຕີມກ່ຽວກັບແນວຄວາມຄິດຂອງ iterators ໂດຍທົ່ວໄປແລ້ວ, ກະລຸນາເບິ່ງ [module-level documentation].
/// ໂດຍສະເພາະ, ທ່ານອາດຈະຕ້ອງການຮູ້ວິທີການ [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// ປະເພດຂອງອົງປະກອບທີ່ຖືກ iterated ໃນໄລຍະ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ຄວາມກ້າວຫນ້າ iterator ແລະໃຫ້ຜົນໄດ້ຮັບມູນຄ່າຕໍ່ໄປ.
    ///
    /// ຜົນໄດ້ຮັບໃນເວລາທີ່ [`None`] iteration ສໍາເລັດແລ້ວ.
    /// ການປະຕິບັດ iterator ບຸກຄົນອາດຈະເລືອກທີ່ຈະດໍາເນີນ iteration ແລະດັ່ງນັ້ນການໂທ `next()` ອີກເທື່ອຫນຶ່ງອາດຈະຫຼືອາດຈະບໍ່ໃນທີ່ສຸດກໍເລີ່ມຕົ້ນກັບຄືນ [`Some(Item)`] ອີກວ່າມີບາງຈຸດ.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // A call to next() ໃຫ້ຜົນໄດ້ຮັບມູນຄ່າຕໍ່ໄປ ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ແລະຫຼັງຈາກນັ້ນບໍ່ມີເມື່ອມັນເປັນໄລຍະ.
    /// assert_eq!(None, iter.next());
    ///
    /// // ການໂທເພີ່ມເຕີມອາດຈະຫລືບໍ່ກັບຄືນ `None`.ນີ້, ພວກເຂົາຈະ.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// ຜົນໄດ້ຮັບຂອບເຂດໃນຄວາມຍາວທີ່ຍັງເຫຼືອຂອງ iterator ໄດ້.
    ///
    /// ໂດຍສະເພາະ, `size_hint()` ໃຫ້ຜົນໄດ້ຮັບ tuple ທີ່ອົງປະກອບທໍາອິດແມ່ນຜູກພັນຕ່ໍາ, ແລະອົງປະກອບທີ່ສອງແມ່ນຄວາມຜູກພັນເທິງ.
    ///
    /// ໃນເຄິ່ງທີ່ສອງຂອງ tuple ທີ່ໄດ້ກັບຄືນເປັນ [`Option`]`<`[`usize`] `>`.
    /// A [`None`] ທີ່ນີ້ຫມາຍຄວາມວ່າບໍ່ວ່າຈະມີແມ່ນເປັນທີ່ຮູ້ຈັກທີ່ບໍ່ມີຜູກມັດເທິງ, ຫຼືຜູກມັດເທິງແມ່ນຂະຫນາດໃຫຍ່ກ່ວາ [`usize`].
    ///
    /// # ບັນທຶກການປະຕິບັດ
    ///
    /// ມັນບໍ່ໄດ້ຖືກບັງຄັບໃຊ້ທີ່ເປັນການປະຕິບັດ iterator yields ຈໍານວນປະກາດຂອງອົງປະກອບ.ຕົວບິດເບື່ອອາດຈະໃຫ້ຜົນຜະລິດ ໜ້ອຍ ກ່ວາຂອບເຂດຕ່ ຳ ຫລືຫຼາຍກ່ວາຂອບເຂດສ່ວນເທິງຂອງສ່ວນປະກອບ.
    ///
    /// `size_hint()` ມີຈຸດປະສົງຕົ້ນຕໍທີ່ຈະໄດ້ຮັບການນໍາໃຊ້ສໍາລັບປະສິດທິພາບເຊັ່ນ: ຮອງພື້ນສໍາລັບອົງປະກອບຂອງ iterator ໄດ້, ແຕ່ຕ້ອງບໍ່ໄດ້ຮັບການໄວ້ວາງໃຈກັບເຊັ່ນ, ຂອບເຂດການກວດສອບ omit ໃນລະຫັດທີ່ບໍ່ປອດໄພ.
    /// ການປະຕິບັດທີ່ບໍ່ຖືກຕ້ອງຂອງ `size_hint()` ບໍ່ຄວນນໍາໄປສູ່ການລະເມີດຄວາມປອດໄພຂອງຄວາມຊົງຈໍາ.
    ///
    /// ທີ່ເວົ້າວ່າ, ການປະຕິບັດຄວນຈະສະຫນອງການຄາດຄະເນທີ່ຖືກຕ້ອງ, ເພາະວ່າຖ້າບໍ່ດັ່ງນັ້ນມັນຈະເປັນການລະເມີດຂອງອະນຸສັນຍາ trait ຂອງ.
    ///
    /// ການປະຕິບັດໃນຕອນຕົ້ນຜົນຕອບແທນ `(0,` [`None`]`)`ທີ່ຖືກຕ້ອງສໍາລັບ iterator ໃດ.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// ຕົວຢ່າງທີ່ສັບສົນກວ່າ:
    ///
    /// ```
    /// // ເຖິງແມ່ນວ່າຕົວເລກຈາກສູນເຖິງສິບ.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // ພວກເຮົາອາດຈະ iterate ຈາກສູນກັບສິບເທື່ອ.
    /// // ຮູ້ວ່າຂອງມັນຫ້າແທ້ເປັນໄປບໍ່ໄດ້ໂດຍບໍ່ມີການປະຕິບັດ filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // ໃຫ້ຕື່ມຫ້າຈໍານວນຫຼາຍທີ່ມີ chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ດຽວນີ້ຂອບເຂດທັງສອງໄດ້ເພີ່ມຂຶ້ນ 5 ເທົ່າ
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// ກັບຄືນ `None` ສໍາລັບຜູກເທິງ:
    ///
    /// ```
    /// // ຕົວຍີ່ງທີ່ບໍ່ມີຂອບເຂດບໍ່ມີຂອບສູງສຸດແລະສູງສຸດທີ່ອາດເປັນໄປໄດ້
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// consumes iterator ໄດ້, ນັບຈໍານວນຂອງ iterations ໄດ້ແລະກັບຄືນມັນ.
    ///
    /// ວິທີການນີ້ຈະໂທຫາ [`next`] ຊ້ໍາ ໆ ຈົນກວ່າ [`None`] ແມ່ນພົບ, ກັບຄືນຈໍານວນຂອງເວລາມັນເຫັນ [`Some`] ໄດ້.
    /// ໃຫ້ສັງເກດວ່າ [`next`] ຈະສາມາດໄດ້ຮັບການເອີ້ນວ່າຢ່າງຫນ້ອຍຫນຶ່ງຄັ້ງເຖິງແມ່ນວ່າຖ້າຫາກວ່າ iterator ບໍ່ມີອົງປະກອບໃດໆ.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # ພຶດຕິກໍາ overflow
    ///
    /// ວິທີການບໍ່ guarding ຕ້ານ overflow ບໍ່ມີ, ສະນັ້ນນັບອົງປະກອບຂອງ iterator ມີຫຼາຍກ່ວາ [`usize::MAX`] ອົງປະກອບບໍ່ວ່າຈະສາມາດຜະລິດຜົນໄດ້ຮັບທີ່ບໍ່ຖືກຕ້ອງຫຼື panics.
    ///
    /// ຖ້າຫາກວ່າການຍື່ນຍັນ debug ຖືກເປີດໃຫ້ໃຊ້ງານ, ເປັນ panic ແມ່ນການຮັບປະກັນ.
    ///
    /// # Panics
    ///
    /// ອາດຟັງຊັນນີ້ panic ຖ້າ iterator ມີຫຼາຍກ່ວາອົງປະກອບ [`usize::MAX`].
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// consumes iterator ໄດ້, ກັບຄືນອົງປະກອບທີ່ຜ່ານມາ.
    ///
    /// ວິທີການນີ້ຈະປະເມີນຜົນ iterator ຈົນກ່ວາມັນຈະກັບຄືນ [`None`].
    /// ໃນຂະນະທີ່ດໍາເນີນການດັ່ງ, ມັນເຮັດໃຫ້ຕິດຕາມຂອງອົງປະກອບໃນປະຈຸບັນ.
    /// ຫຼັງຈາກ [`None`] ຈະຖືກສົ່ງກັບ `last()` ຫຼັງຈາກນັ້ນຈະກັບອົງປະກອບທີ່ຜ່ານມາມັນໄດ້ເຫັນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// ຄວາມກ້າວຫນ້າ iterator ໂດຍອົງປະກອບ `n` ໄດ້.
    ///
    /// ວິທີການນີ້ກະຫາຍທີ່ຈະຂ້າມອົງປະກອບ `n` ໂດຍການໂທຫາ [`next`] ເຖິງເວລາທີ່ `n` ຈົນກ່ວາ [`None`] ແມ່ນພົບ.
    ///
    /// `advance_by(n)` ຈະກັບຄືນ [`Ok(())`][Ok] ຖ້າ iterator ໄດ້ສົບຜົນສໍາເລັດຄວາມກ້າວຫນ້າໂດຍອົງປະກອບ `n` ຫລື [`Err(k)`][Err] ຖ້າ [`None`] ແມ່ນພົບ, ບ່ອນທີ່ `k` ແມ່ນຈໍານວນຂອງອົງປະກອບດັ່ງກ່າວ iterator ເຖິງຂັ້ນໂດຍກ່ອນທີ່ຈະແລ່ນອອກຈາກອົງປະກອບ (ie
    /// ຄວາມຍາວຂອງຕົວປ່ຽນແປງ).
    /// ໃຫ້ສັງເກດວ່າ `k` ແມ່ນສະເຫມີໄປຫນ້ອຍກ່ວາ `n`.
    ///
    /// ໂທ `advance_by(0)` ບໍ່ບໍລິໂພກອົງປະກອບແລະສະເຫມີຜົນໄດ້ຮັບ [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // ພຽງແຕ່ `&4` ໄດ້ຂ້າມ
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// ຜົນຕອບແທນທີ່ `ອົງປະກອບ n`th ຂອງ iterator ໄດ້.
    ///
    /// ເຊັ່ນດຽວກັນກັບການດໍາເນີນງານຈັດດັດສະນີຫຼາຍທີ່ສຸດ, ນັບຈະເລີ່ມຈາກສູນ, ສະນັ້ນ `nth(0)` ສົ່ງກັບຄ່າທໍາອິດ, `nth(1)` ຄັ້ງທີສອງ, ແລະອື່ນໆ.
    ///
    /// ໃຫ້ສັງເກດວ່າອົງປະກອບທັງຫມົດກ່ອນ, ເຊັ່ນດຽວກັນກັບອົງປະກອບຜົນຫລັບທີ່ໄດ້ຈະໄດ້ຮັບການບໍລິໂພກຈາກ iterator ໄດ້.
    /// ຫມາຍຄວາມວ່າວ່າອົງປະກອບການກ່ອນຫນ້ານັ້ນຈະໄດ້ຮັບການຍົກເລີກ, ແລະຍັງມີການໂທ `nth(0)` ຫຼາຍຄັ້ງກ່ຽວກັບ iterator ດຽວກັນຈະກັບຄືນອົງປະກອບທີ່ແຕກຕ່າງກັນ.
    ///
    ///
    /// `nth()` ຈະກັບຄືນ [`None`] ຖ້າ `n` ແມ່ນຫຼາຍກ່ວາຫຼືເທົ່າກັບຄວາມຍາວຂອງ iterator ໄດ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// ໂທ `nth()` ຫຼາຍຄັ້ງບໍ່ໄດ້ຍ້ອນ iterator ໄດ້:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// ກັບຄືນ `None` ຖ້າມີຫນ້ອຍກ່ວາອົງປະກອບ `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// ສ້າງເປັນ iterator ເລີ່ມຕົ້ນທີ່ຈຸດດຽວກັນ, ແຕ່ວ່າຂັ້ນຕອນໂດຍປະລິມານດັ່ງກ່າວໃນແຕ່ລະ iteration.
    ///
    /// ຂໍ້ແນະ ນຳ ທີ 1: ອົງປະກອບ ທຳ ອິດຂອງຕົວຍົກຍ້າຍຈະຖືກສົ່ງຄືນສະ ເໝີ ໄປ, ບໍ່ວ່າຈະເປັນບາດກ້າວທີ່ໄດ້ໃຫ້ໄວ້.
    ///
    /// ໝາຍ ເຫດ 2: ເວລາທີ່ການດຶງເອົາອົງປະກອບທີ່ບໍ່ສົນໃຈມາໃຊ້ແມ່ນບໍ່ມີ ກຳ ນົດ.
    /// `StepBy` ປະຕິບັດຕົວຄືລໍາດັບ `next(), nth(step-1), nth(step-1),…`, ແຕ່ຍັງແມ່ນຟຣີທີ່ຈະປະຕິບັດຕົວຄືລໍາດັບເຫດການ
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// ເຊິ່ງວິທີການແມ່ນການນໍາໃຊ້ອາດຈະມີການປ່ຽນແປງສໍາລັບ iterators ບາງສໍາລັບເຫດຜົນການປະຕິບັດ.
    /// ວິທີທີສອງຈະກ້າວຫນ້າ iterator ກ່ອນຫນ້ານີ້ແລະອາດຈະບໍລິໂພກສິນຄ້າອື່ນ ໆ .
    ///
    /// `advance_n_and_return_first` ແມ່ນທຽບເທົ່າຂອງ:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// ວິທີການດັ່ງກ່າວຈະ panic ຖ້າຂັ້ນຕອນທີ່ໃຫ້ໄວ້ແມ່ນ `0`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// ໃຊ້ເວລາສອງ iterators ແລະສ້າງເປັນ iterator ໃຫມ່ໃນໄລຍະທັງສອງໃນລໍາດັບ.
    ///
    /// `chain()` ຈະກັບຄືນເປັນ iterator ໃຫມ່ທີ່ທໍາອິດຈະ iterate ໃນໄລຍະຄ່າຈາກ iterator ທໍາອິດແລະຫຼັງຈາກນັ້ນໃນໄລຍະຄ່າຈາກ iterator ທີສອງ.
    ///
    /// ເວົ້າອີກຢ່າງ ໜຶ່ງ, ມັນເຊື່ອມໂຍງສອງຕົວເຊື່ອມຕໍ່ກັນ, ໃນລະບົບຕ່ອງໂສ້.🔗
    ///
    /// [`once`] ຖືກນໍາໃຊ້ທົ່ວໄປສາມາດປັບຄ່າດຽວເຂົ້າໄປໃນລະບົບຕ່ອງໂສ້ຂອງປະເພດອື່ນໆຂອງ iteration ໄດ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ນັບຕັ້ງແຕ່ການໂຕ້ຖຽງໃນການ `chain()` ໃຊ້ [`IntoIterator`], ພວກເຮົາສາມາດຜ່ານສິ່ງໃດແດ່ທີ່ສາມາດໄດ້ຮັບການປ່ຽນໃຈເຫລື້ອມໃສເຂົ້າໄປໃນ [`Iterator`], ບໍ່ພຽງແຕ່ເປັນ [`Iterator`] ຕົວຂອງມັນເອງ.
    /// ສໍາລັບຕົວຢ່າງ, slices (`&[T]`) ໃຊ້ [`IntoIterator`], ແລະດັ່ງນັ້ນສາມາດຜ່ານໄປ `chain()` ໂດຍກົງ:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ຖ້າຫາກວ່າທ່ານເຮັດວຽກຮ່ວມກັບ Windows API, ທ່ານອາດຈະຕ້ອງການທີ່ຈະປ່ຽນ [`OsStr`] ກັບ `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips ເຖິງ' ສອງ iterators ເປັນ iterator ດຽວຂອງຄູ່.
    ///
    /// `zip()` ຜົນຕອບແທນເປັນ iterator ໃຫມ່ທີ່ຈະ iterate ໃນໄລຍະສອງ iterators ອື່ນໆ, ກັບຄືນ tuple ເປັນບ່ອນທີ່ອົງປະກອບທໍາອິດທີ່ມາຈາກ iterator ທໍາອິດ, ແລະອົງປະກອບທີສອງມາຈາກ iterator ທີສອງ.
    ///
    ///
    /// ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ມັນ Zips ສອງ iterators ກັນ, ເປັນຫນຶ່ງດຽວ.
    ///
    /// ຖ້າຫາກວ່າຜົນໄດ້ຮັບ iterator [`None`], [`next`] ຈາກ zipped iterator ຈະກັບຄືນ [`None`].
    /// ຖ້າຕົວປ່ຽນທິດ ທຳ ອິດກັບຄືນ [`None`], `zip` ຈະສັ້ນກະແສໄຟຟ້າແລະ `next` ຈະບໍ່ຖືກເອີ້ນໃສ່ຕົວປະຕິບັດທີສອງ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ນັບຕັ້ງແຕ່ການໂຕ້ຖຽງກັບ `zip()` ໃຊ້ [`IntoIterator`], ພວກເຮົາສາມາດຜ່ານສິ່ງທີ່ສາມາດປ່ຽນເປັນ [`Iterator`], ບໍ່ພຽງແຕ່ [`Iterator`] ຕົວມັນເອງ.
    /// ສໍາລັບຕົວຢ່າງ, slices (`&[T]`) ໃຊ້ [`IntoIterator`], ແລະດັ່ງນັ້ນສາມາດຜ່ານໄປ `zip()` ໂດຍກົງ:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ມັກຖືກນໍາໃຊ້ກັບໄປສະນີເປັນ iterator infinite ກັບ finite ຫນຶ່ງ.
    /// ນີ້ເຮັດວຽກເນື່ອງຈາກວ່າ finite ໄດ້ iterator ໃນທີ່ສຸດກໍຈະກັບຄືນ [`None`], ສິ້ນສຸດ zipper ໄດ້.zipping ກັບ `(0..)` ສາມາດເບິ່ງຫຼາຍເຊັ່ນ: [`enumerate`] ເປັນ:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// ສ້າງເປັນ iterator ໃຫມ່ທີ່ສະຖານທີ່ສໍາເນົາຂອງ `separator` ລະຫວ່າງລາຍການຢູ່ໃກ້ຊິດຂອງ iterator ຕົ້ນສະບັບ.
    ///
    /// ໃນກໍລະນີ `separator` ບໍ່ປະຕິບັດ [`Clone`] ຫຼືຕ້ອງການ ຄຳ ນວນທຸກໆຄັ້ງ, ໃຊ້ [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // ອົງປະກອບທໍາອິດຈາກ `a`.
    /// assert_eq!(a.next(), Some(&100)); // ຕົວແຍກ.
    /// assert_eq!(a.next(), Some(&1));   // ອົງປະກອບຕໍ່ໄປຈາກ `a`.
    /// assert_eq!(a.next(), Some(&100)); // ຕົວແຍກ.
    /// assert_eq!(a.next(), Some(&2));   // ອົງປະກອບສຸດທ້າຍຈາກ `a`.
    /// assert_eq!(a.next(), None);       // The iterator ແມ່ນສໍາເລັດ.
    /// ```
    ///
    /// `intersperse` ສາມາດເປັນປະໂຫຍດຫຼາຍທີ່ຈະເຂົ້າຮ່ວມລາຍການເປັນຂອງ iterator ໃຊ້ອົງປະກອບທົ່ວໄປ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// ສ້າງເປັນ iterator ໃຫມ່ທີ່ສະຖານທີ່ລາຍການທີ່ສ້າງຂຶ້ນໂດຍ `separator` ລະຫວ່າງລາຍການຢູ່ໃກ້ຊິດຂອງ iterator ຕົ້ນສະບັບ.
    ///
    /// ການປິດຈະໄດ້ຮັບການເອີ້ນວ່າແທ້ເມື່ອໃນແຕ່ລະຄັ້ງລາຍການແມ່ນຖືກຈັດໃສ່ໃນລະຫວ່າງສອງລາຍການຢູ່ໃກ້ຊິດຈາກ iterator ຕິດພັນ;
    /// ໂດຍສະເພາະ, ການປິດບໍ່ໄດ້ເອີ້ນວ່າຖ້າຫາກວ່າຜົນຜະລິດທີ່ຕິດພັນ iterator ຫນ້ອຍກ່ວາສອງລາຍການແລະຫຼັງຈາກລາຍການທີ່ຜ່ານມາແມ່ນຜົນຜະລິດ.
    ///
    ///
    /// ຖ້າ iterator ຂອງການປະຕິບັດລາຍການ [`Clone`], ມັນອາດຈະງ່າຍຕໍ່ການນໍາໃຊ້ [`intersperse`].
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // ອົງປະກອບທໍາອິດຈາກ `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // ຕົວແຍກ.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // ອົງປະກອບຕໍ່ໄປຈາກ `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // ຕົວແຍກ.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // ອົງປະກອບທີ່ຜ່ານມາຈາກຈາກ `v`.
    /// assert_eq!(it.next(), None);               // The iterator ແມ່ນສໍາເລັດ.
    /// ```
    ///
    /// `intersperse_with` ສາມາດຖືກນໍາໃຊ້ໃນສະຖານະການທີ່ແຍກຕ້ອງໄດ້ຮັບການຄໍານວນ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // ການປິດບໍ່ແນ່ນອນ borrows ບໍລິບົດຂອງຕົນໃນການສ້າງລາຍການ.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// ໃຊ້ເວລາປິດແລະສ້າງ iterator ເຊິ່ງຮຽກຮ້ອງໃຫ້ປິດໃນແຕ່ລະອົງປະກອບທີ່ເປັນ.
    ///
    /// `map()` ປ່ຽນຫນຶ່ງ iterator ເຂົ້າໄປໃນອີກແບບນຶ່ງໂດຍວິທີການຂອງການໂຕ້ຖຽງຂອງຕົນ:
    /// ບາງສິ່ງບາງຢ່າງທີ່ປະຕິບັດ [`FnMut`].ມັນສາມາດຜະລິດເປັນ iterator ໃຫມ່ເຊິ່ງຮຽກຮ້ອງໃຫ້ປິດນີ້ອົງປະກອບຂອງຕົ້ນສະບັບ iterator ແຕ່ລະ.
    ///
    /// ຖ້າຫາກວ່າທ່ານມີຄວາມດີຢູ່ໃນຄິດໃນປະເພດ, ທ່ານສາມາດຄິດວ່າຂອງ `map()` ເຊັ່ນນີ້:
    /// ຖ້າຫາກທ່ານມີ iterator ທີ່ເຮັດໃຫ້ທ່ານອົງປະກອບຂອງປະເພດ `A` ບາງ, ແລະທ່ານຕ້ອງການເປັນ iterator ຂອງບາງປະເພດອື່ນໆ `B`, ທ່ານສາມາດໃຊ້ `map()`, ຜ່ານການປິດທີ່ໃຊ້ເວລາເປັນ `A` ແລະຜົນຕອບແທນ `B` ໄດ້.
    ///
    ///
    /// `map()` ແມ່ນຈືຂໍ້ມູນທີ່ຄ້າຍຄືກັນກັບວົງ [`for`].ຢ່າງໃດກໍຕາມ, ເປັນ `map()` ແມ່ນ lazy, ມັນຖືກນໍາໃຊ້ທີ່ດີທີ່ສຸດໃນເວລາທີ່ທ່ານກໍາລັງເຮັດວຽກກັບ iterators ອື່ນໆ.
    /// ຖ້າທ່ານ ກຳ ລັງເຮັດບາງສ່ວນຂອງ looping ສຳ ລັບຜົນຂ້າງຄຽງ, ມັນຈະຖືກພິຈາລະນາວ່າບໍ່ດີທີ່ຈະໃຊ້ [`for`] ກ່ວາ `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ຖ້າທ່ານ ກຳ ລັງເຮັດບາງຜົນຂ້າງຄຽງ, ໃຫ້ເລືອກ [`for`] ຫາ `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ຢ່າເຮັດແນວນີ້:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // ມັນຈະບໍ່ແມ່ນແຕ່ປະຕິບັດ, ຍ້ອນວ່າມັນເປັນຂີ້ຕົວະ.Rust ຈະເຕືອນທ່ານກ່ຽວກັບເລື່ອງນີ້.
    ///
    /// // ແທນທີ່ຈະ, ການນໍາໃຊ້ສໍາລັບ:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// ຮຽກຮ້ອງການປິດຂອງແຕ່ລະອົງປະກອບຂອງເຄື່ອງປັບ.
    ///
    /// ນີ້ແມ່ນທຽບເທົ່າກັບການນໍາໃຊ້ເປັນ loop [`for`] ກ່ຽວກັບ iterator ໄດ້, ເຖິງແມ່ນວ່າ `break` ແລະ `continue` ແມ່ນບໍ່ສາມາດຈາກການປິດໄດ້.
    /// ມັນເປັນໂດຍທົ່ວໄປ idiomatic ຫຼາຍທີ່ຈະນໍາໃຊ້ເປັນ loop `for`, ແຕ່ `for_each` ອາດຈະອ່ານເພີ່ມເຕີມໃນເວລາທີ່ປະມວນຜົນລາຍການຢູ່ໃນຕອນທ້າຍຂອງລະບົບຕ່ອງໂສ້ iterator ຕໍ່ໄປອີກແລ້ວ.
    ///
    /// ໃນບາງກໍລະນີ `for_each` ຍັງອາດຈະໄວກ່ວາ loop ເປັນ, ເນື່ອງຈາກວ່າມັນຈະໃຊ້ iteration ພາຍໃນກ່ຽວກັບອະແດບເຕີຄື `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// ສໍາລັບເປັນຕົວຢ່າງທີ່ມີຂະຫນາດນ້ອຍ, ເປັນ `for` loop ອາດຈະເຮັດຄວາມສະອາດ, ແຕ່ `for_each` ອາດຈະຕ້ອງການທີ່ຈະຮັກສາເປັນແບບທີ່ມີປະໂຫຍດ iterators ຕໍ່ໄປອີກແລ້ວ:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// ສ້າງ iterator ທີ່ໃຊ້ປິດການກໍານົດຖ້າຫາກວ່າເປັນອົງປະກອບຄວນຈະໄດ້ຮັບຜົນຜະລິດໄດ້.
    ///
    /// ໃຫ້ອົງປະກອບປິດຕ້ອງກັບຄືນ `true` ຫຼື `false` ເປັນ.ການກັບຄືນ iterator ຈະໃຫ້ຜົນຜະລິດພຽງແຕ່ອົງປະກອບສໍາລັບການທີ່ປິດໄດ້ໃຫ້ຜົນໄດ້ຮັບທີ່ແທ້ຈິງ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ເນື່ອງຈາກວ່າການປິດຜ່ານໄປ `filter()` ໃຊ້ເວລາກະສານອ້າງອີງ, ແລະ iterators ຫຼາຍ iterate ໃນໄລຍະເອກະສານ, ເຮັດໃຫ້ນີ້ເປັນສະຖານະການເປັນໄປໄດ້ຂອງເຊື້ອຕະກຸນ, ບ່ອນທີ່ປະເພດຂອງການປິດໄດ້ຈະໃຊ້ອ້າງອິງ double:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // ຕ້ອງການສອງ * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ມັນເປັນເລື່ອງ ທຳ ມະດາທີ່ຈະໃຊ້ການ ທຳ ລາຍໃນການໂຕ້ຖຽງເພື່ອແກ້ຕົວ ໜຶ່ງ:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ທັງສອງແລະ *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ຫຼືທັງສອງ:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // ສອງ &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ຂອງຂັ້ນຕອນເຫຼົ່ານີ້.
    ///
    /// ໃຫ້ສັງເກດວ່າ `iter.filter(f).next()` ແມ່ນທຽບເທົ່າກັບ `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// ສ້າງເປັນ iterator ທີ່ທັງການກັ່ນຕອງແລະແຜນທີ່.
    ///
    /// ຕົວປະຕິບັດທີ່ສົ່ງຄືນຈະສົ່ງຜົນໃຫ້ພຽງແຕ່ `ມູນຄ່າເທົ່ານັ້ນທີ່ການປິດການສະ ໜອງ ຈະສົ່ງຄືນ `Some(value)`.
    ///
    /// `filter_map` ສາມາດຖືກນໍາໃຊ້ເພື່ອເຮັດໃຫ້ລະບົບຕ່ອງໂສ້ຂອງ [`filter`] ແລະ [`map`] concise ຫຼາຍໄດ້.
    /// ຕົວຢ່າງຂ້າງລຸ່ມນີ້ສະແດງວິທີການເປັນ `map().filter().map()` ສາມາດໄດ້ຮັບການ shortened ກັບສາຍດຽວກັບ `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ນີ້ແມ່ນຕົວຢ່າງດຽວກັນ, ແຕ່ວ່າມີ [`filter`] ແລະ [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// ສ້າງ iterator ຊຶ່ງເຮັດໃຫ້ຈໍານວນ iteration ປັດຈຸບັນເຊັ່ນດຽວກັນກັບມູນຄ່າຕໍ່ໄປໄດ້.
    ///
    /// The iterator ຜົນຜະລິດຄືນຄູ່ `(i, val)`, ບ່ອນທີ່ `i` ເປັນດັດຊະນີໃນປະຈຸບັນຂອງ iteration ແລະ `val` ເປັນມູນຄ່າທີ່ສົ່ງກັບມາຈາກ iterator ໄດ້.
    ///
    ///
    /// `enumerate()` ຮັກສາການນັບຂອງມັນເປັນ [`usize`].
    /// ຖ້າຫາກວ່າທ່ານຕ້ອງການທີ່ຈະນັບໂດຍຈໍານວນເຕັມຂະຫນາດທີ່ແຕກຕ່າງກັນ, ການທໍາງານຂອງ [`zip`] ໃຫ້ການທໍາງານທີ່ຄ້າຍຄືກັນ.
    ///
    /// # ພຶດຕິກໍາ overflow
    ///
    /// ວິທີການໃຊ້ບໍ່ໄດ້ຜົນ guarding ຕ້ານ overflow, ສະນັ້ນການຈາລະໄນຫຼາຍກ່ວາອົງປະກອບ [`usize::MAX`] ບໍ່ວ່າຈະສາມາດຜະລິດຜົນໄດ້ຮັບທີ່ບໍ່ຖືກຕ້ອງຫຼື panics.
    /// ຖ້າຫາກວ່າການຍື່ນຍັນ debug ຖືກເປີດໃຫ້ໃຊ້ງານ, ເປັນ panic ແມ່ນການຮັບປະກັນ.
    ///
    /// # Panics
    ///
    /// ຕົວປ່ຽນແປງທີ່ສົ່ງກັບຄືນມາອາດຈະເປັນ panic ຖ້າດັດຊະນີທີ່ຕ້ອງໄດ້ກັບຄືນມາຈະເກີນ [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// ສ້າງເປັນ iterator ທີ່ສາມາດນໍາໃຊ້ [`peek`] ເພື່ອເບິ່ງອົງປະກອບຕໍ່ໄປຂອງ iterator ໂດຍບໍ່ມີການຊົມໃຊ້ມັນ.
    ///
    /// ເພີ່ມວິທີການ [`peek`] ກັບ iterator.ເບິ່ງເອກະສານຂອງຕົນສໍາລັບຂໍ້ມູນເພີ່ມເຕີມ.
    ///
    /// ໃຫ້ສັງເກດວ່າການທີ່ແຝງຢູ່ iterator ຍັງກ້າວຫນ້າທາງດ້ານໃນເວລາທີ່ [`peek`] ຖືກເອີ້ນວ່າເປັນຄັ້ງທໍາອິດ: ໃນຄໍາສັ່ງທີ່ຈະດຶງອົງປະກອບຕໍ່ໄປ, [`next`] ແມ່ນໄດ້ຮຽກຮ້ອງໃຫ້ຕິດພັນ iterator, ເພາະສະນັ້ນຜົນຂ້າງຄຽງໃດໆ (ເຊັ່ນ
    ///
    /// ສິ່ງອື່ນນອກຈາກເອີ້ນຄ່າຕໍ່ໄປ) ຂອງວິທີການ [`next`] ຈະເກີດຂຶ້ນ.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ສາມາດເຮັດໃຫ້ພວກເຮົາເບິ່ງເຂົ້າໄປໃນ future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // ພວກເຮົາສາມາດ peek() ເວລາຫຼາຍ, ໄດ້ iterator ຈະບໍ່ລ່ວງຫນ້າ
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ຫຼັງຈາກເຄື່ອງປັບປ່ຽນ ສຳ ເລັດແລ້ວ, ແມ່ນ peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// ສ້າງເປັນ iterator ທີ່ອົງປະກອບ [`skip`] s ອີງໃສ່ຢາໄດ້.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` ໃຊ້ເວລາປິດເປັນການໂຕ້ຖຽງໄດ້.ມັນຈະໂທຫາປິດນີ້ອົງປະກອບຂອງ iterator ຂອງແຕ່ລະຄົນ, ແລະບໍ່ສົນໃຈອົງປະກອບຈົນກ່ວາມັນຈະກັບຄືນ `false`.
    ///
    /// ຫຼັງຈາກ `false` ຈະຖືກສົ່ງກັບວຽກເຮັດງານທໍາ `skip_while()`'s ແມ່ນໃນໄລຍະ, ແລະສ່ວນທີ່ເຫຼືອຂອງອົງປະກອບດັ່ງກ່າວແມ່ນຜົນຜະລິດ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ເນື່ອງຈາກວ່າການປິດຜ່ານໄປ `skip_while()` ໃຊ້ເວລາກະສານອ້າງອີງ, ແລະ iterators ຫຼາຍ iterate ໃນໄລຍະເອກະສານ, ເຮັດໃຫ້ນີ້ເປັນສະຖານະການເປັນໄປໄດ້ຂອງເຊື້ອຕະກຸນ, ບ່ອນທີ່ປະເພດຂອງການໂຕ້ຖຽງປິດໄດ້ແມ່ນກະສານອ້າງອີງ double:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // ຕ້ອງການສອງ * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ຢຸດຫຼັງຈາກ `false` ເລີ່ມຕົ້ນ:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ໃນຂະນະທີ່ສິ່ງນີ້ຈະເປັນສິ່ງທີ່ບໍ່ຖືກຕ້ອງ, ເພາະວ່າພວກເຮົາມີຂໍ້ຜິດພາດຢູ່ແລ້ວ, skip_while() ບໍ່ໄດ້ຖືກ ນຳ ໃຊ້ອີກຕໍ່ໄປ
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// ສ້າງເປັນ iterator ທີ່ອົງປະກອບຜົນຜະລິດໂດຍອີງໃສ່ຢາໄດ້.
    ///
    /// `take_while()` ໃຊ້ເວລາປິດເປັນການໂຕ້ຖຽງ.ມັນຈະໂທຫາປິດນີ້ອົງປະກອບຂອງ iterator ຂອງແຕ່ລະຄົນ, ແລະຜົນຜະລິດອົງປະກອບໃນຂະນະທີ່ມັນຈະກັບຄືນມາ `true`.
    ///
    /// ຫຼັງຈາກ `false` ຈະຖືກສົ່ງກັບວຽກເຮັດງານທໍາ `take_while()`'s ແມ່ນໃນໄລຍະ, ແລະສ່ວນທີ່ເຫຼືອຂອງອົງປະກອບດັ່ງກ່າວຈະຖືກລະເລີຍ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ເນື່ອງຈາກວ່າການປິດໄດ້ຜ່ານໄປທີ່ `take_while()` ໃຊ້ເວລາການອ້າງອີງ, ແລະຫຼາຍໆທິດສະດີມັນກ່ຽວກັບການອ້າງອີງ, ນີ້ຈະເຮັດໃຫ້ສະຖານະການສັບສົນທີ່ອາດຈະເກີດຂື້ນ, ເຊິ່ງປະເພດຂອງການປິດນັ້ນແມ່ນການອ້າງອີງສອງເທົ່າ:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // ຕ້ອງການສອງ * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ຢຸດຫຼັງຈາກ `false` ເລີ່ມຕົ້ນ:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // ພວກເຮົາມີອົງປະກອບເພີ່ມເຕີມທີ່ມີຫນ້ອຍກ່ວາສູນ, ແຕ່ນັບຕັ້ງແຕ່ພວກເຮົາແລ້ວໄດ້ຮັບທີ່ບໍ່ຖືກຕ້ອງ, take_while() ບໍ່ໄດ້ໃຊ້ອີກຕໍ່ໄປ
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ເນື່ອງຈາກວ່າ `take_while()` ຕ້ອງເບິ່ງມູນຄ່າໃນຄໍາສັ່ງເພື່ອເຂົ້າໄປເບິ່ງຖ້າຫາກວ່າມັນຄວນຈະໄດ້ຮັບການປະກອບຫຼືບໍ່, ການຊົມໃຊ້ iterators ຈະເຫັນວ່າມັນຖືກໂຍກຍ້າຍ:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// The `3` ບໍ່ມີຕໍ່ໄປອີກແລ້ວມີ, ເນື່ອງຈາກວ່າມັນໄດ້ຖືກບໍລິໂພກໃນຄໍາສັ່ງເພື່ອເບິ່ງວ່າ iteration ຄວນຢຸດເຊົາການ, ແຕ່ບໍ່ໄດ້ເກັບໄວ້ກັບຄືນໄປບ່ອນເຂົ້າໄປໃນ iterator ໄດ້.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// ສ້າງເປັນ iterator ທີ່ອົງປະກອບທັງຜົນຜະລິດໂດຍອີງໃສ່ເປັນຢາແລະແຜນທີ່.
    ///
    /// `map_while()` ໃຊ້ເວລາປິດເປັນການໂຕ້ຖຽງ.
    /// ມັນຈະເອີ້ນວ່າການປິດນີ້ໃນແຕ່ລະອົງປະກອບຂອງຕົວປັບ, ແລະອົງປະກອບທີ່ໃຫ້ຜົນຜະລິດໃນຂະນະທີ່ມັນກັບຄືນ [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ຕໍ່ໄປນີ້ແມ່ນຕົວຢ່າງດຽວກັນ, ແຕ່ວ່າມີ [`take_while`] ແລະ [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ການຢຸດເຊົາຫຼັງຈາກ [`None`] ເບື້ອງຕົ້ນ:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // ພວກເຮົາມີຫຼາຍອົງປະກອບທີ່ສາມາດ ເໝາະ ກັບ u32 (4, 5), ແຕ່ `map_while` ໄດ້ສົ່ງຄືນ `None` ສຳ ລັບ `-3` (ຍ້ອນວ່າ `predicate` ກັບຄືນ `None`) ແລະ `collect` ທີ່ `None` ທຳ ອິດພົບ.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// ເນື່ອງຈາກວ່າ `map_while()` ຕ້ອງເບິ່ງມູນຄ່າໃນຄໍາສັ່ງເພື່ອເຂົ້າໄປເບິ່ງຖ້າຫາກວ່າມັນຄວນຈະໄດ້ຮັບການປະກອບຫຼືບໍ່, ການຊົມໃຊ້ iterators ຈະເຫັນວ່າມັນຖືກໂຍກຍ້າຍ:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// The `-3` ບໍ່ມີຕໍ່ໄປອີກແລ້ວມີ, ເນື່ອງຈາກວ່າມັນໄດ້ຖືກບໍລິໂພກໃນຄໍາສັ່ງເພື່ອເບິ່ງວ່າ iteration ຄວນຢຸດເຊົາການ, ແຕ່ບໍ່ໄດ້ເກັບໄວ້ກັບຄືນໄປບ່ອນເຂົ້າໄປໃນ iterator ໄດ້.
    ///
    /// ໃຫ້ສັງເກດວ່າບໍ່ເຫມືອນກັບ [`take_while`] iterator ນີ້ **ບໍ່** fused.
    /// ມັນຍັງບໍ່ໄດ້ລະບຸສິ່ງທີ່ນີ້ກັບຄືນ iterator ຫຼັງຈາກທໍາອິດ [`None`] ຖືກສົ່ງກັບ.
    /// ຖ້າຫາກວ່າທ່ານຕ້ອງການ fused iterator ໃຊ້ [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// ສ້າງ iterator ທີ່ຂ້າມອົງປະກອບ `n` ທໍາອິດເປັນ.
    ///
    /// ຫຼັງຈາກທີ່ພວກເຂົາເຈົ້າໄດ້ຮັບການບໍລິໂພກ, ສ່ວນທີ່ເຫຼືອຂອງອົງປະກອບທີ່ມີຜົນຜະລິດ.
    /// ແທນທີ່ຈະກ່ວາເອົາຊະນະວິທີການນີ້ໂດຍກົງ, ແທນທີ່ຈະເປັນແທນທີ່ວິທີການ `nth`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// ສ້າງ iterator ທີ່ຜະອົງປະກອບ `n` ທໍາອິດຂອງຕົນໄດ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` ມັກຖືກນໍາໃຊ້ກັບ iterator infinite, ເພື່ອເຮັດໃຫ້ມັນ finite:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ຖ້າຕ່ໍາກວ່າອົງປະກອບ `n` ມີ, `take` ຈະຈໍາກັດການຕົວຂອງມັນເອງກັບຂະຫນາດຂອງ iterator ທີ່ຕິດພັນ:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// ອະແດບເຕີ iterator ຄ້າຍຄືກັນກັບ [`fold`] ທີ່ຖືລັດພາຍໃນແລະສາມາດຜະລິດເປັນ iterator ໃຫມ່.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` ໃຊ້ເວລາທັງສອງກະທູ້: ເປັນຄ່າເລີ່ມຕົ້ນທີ່ແກ່ນລັດພາຍໃນ, ແລະປິດດ້ວຍທັງສອງກະທູ້, ຄົນທໍາອິດເປັນກະສານອ້າງອີງບໍ່ແນ່ນອນກັບສະຖານະພາຍໃນແລະຄັ້ງທີສອງເປັນອົງປະກອບ iterator ໄດ້.
    ///
    /// ການປິດສາມາດກໍາຫນົດໃຫ້ສະຖານະພາຍໃນຂອງລັດແບ່ງປັນລະຫວ່າງ iterations.
    ///
    /// ກ່ຽວກັບ iteration, ການປິດຈະຖືກນໍາໃຊ້ກັບແຕ່ລະອົງປະກອບຂອງຕົວປ່ຽນແປງແລະມູນຄ່າການກັບມາຈາກການປິດ, [`Option`], ແມ່ນຜົນຜະລິດໂດຍຕົວຊີ້ວັດ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // ແຕ່ລະຄັ້ງ, ພວກເຮົາຈະທະວີຄູນລັດໂດຍອົງປະກອບ
    ///     *state = *state * x;
    ///
    ///     // ຫຼັງຈາກນັ້ນ, ພວກເຮົາຈະໃຫ້ຜົນຜະລິດປະຕິເສດຂອງລັດໄດ້
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// ສ້າງ iterator ທີ່ເຮັດວຽກຄ້າຍຄືແຜນການ, ແຕ່ flattens ໂຄງສ້າງຮັງ.
    ///
    /// ຂອງຜູ້ດັດແປງ [`map`] ເປັນປະໂຫຍດທີ່ສຸດ, ແຕ່ພຽງແຕ່ໃນເວລາທີ່ການໂຕ້ຖຽງປິດສາມາດຜະລິດຄ່າ.
    /// ຖ້າຫາກວ່າມັນສາມາດຜະລິດເປັນ iterator ແທນທີ່ຈະ, ມີຊັ້ນພິເສດຂອງທາງອ້ອມ.
    /// `flat_map()` ຈະເອົາຊັ້ນພິເສດນີ້ກ່ຽວກັບຂອງຕົນເອງ.
    ///
    /// ທ່ານສາມາດຄິດວ່າຂອງ `flat_map(f)` ເປັນທຽບເທົ່າ semantic ຂອງ [`map`] ping, ແລະຫຼັງຈາກນັ້ນ [`flatten`] ໄອເອັນຈີໃນ `map(f).flatten()`.
    ///
    /// ອີກວິທີຫນຶ່ງຂອງການຄິດກ່ຽວ `flat_map()`: [`map`] 's ປິດຄືນຫນຶ່ງລາຍການສໍາລັບແຕ່ລະອົງປະກອບ, ແລະ `flat_map()`'s ຄືນປິດເປັນ iterator ສໍາລັບແຕ່ລະອົງປະກອບ.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ສົ່ງຄືນຜູ້ຕິດຕໍ່
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// ສ້າງ iterator ທີ່ flattens ໂຄງສ້າງຮັງໄດ້.
    ///
    /// ນີ້ແມ່ນເປັນປະໂຫຍດໃນເວລາທີ່ທ່ານມີ iterator ຂອງ iterators ຫຼື iterator ຂອງສິ່ງທີ່ສາມາດໄດ້ຮັບການຫັນເຂົ້າໄປໃນ iterators ແລະທ່ານຕ້ອງການທີ່ຈະເອົາໄປຫນຶ່ງລະດັບຂອງທາງອ້ອມ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// ການສ້າງແຜນທີ່ແລະຫຼັງຈາກນັ້ນແບນ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ສົ່ງຄືນຜູ້ຕິດຕໍ່
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// ນອກນັ້ນທ່ານຍັງສາມາດຂຽນໃນຂໍ້ກໍານົດຂອງ [`flat_map()`], ເຊິ່ງເປັນທີ່ນິຍົມໃນກໍລະນີນີ້ນັບຕັ້ງແຕ່ມັນສະແດງເຖິງເຈດຕະນາຫຼາຍຢ່າງຊັດເຈນ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ສົ່ງຄືນຜູ້ຕິດຕໍ່
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// flattening ພຽງແຕ່ removes ລະດັບຫນຶ່ງໃນຮັງຢູ່ທີ່ໃຊ້ເວລາເປັນ:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// ທີ່ນີ້ພວກເຮົາເຫັນວ່າ `flatten()` ບໍ່ປະຕິບັດເປັນ Flatten "deep".
    /// ແທນທີ່ຈະ, ພຽງແຕ່ຫນຶ່ງໃນລະດັບຂອງຮັງຖືກຍ້າຍອອກ.ຫມາຍຄວາມວ່າ, ຖ້າຫາກວ່າທ່ານ `flatten()` ເປັນ array ສາມມິຕິລະດັບ, ຜົນໄດ້ຮັບຈະມີສອງມິຕິລະດັບແລະບໍ່ມີພຽງຂະຫນາດ.
    /// ເພື່ອໃຫ້ໄດ້ຮັບເປັນໂຄງສ້າງຫນຶ່ງມິຕິລະດັບ, ທ່ານຈໍາເປັນຕ້ອງ `flatten()` ອີກເທື່ອຫນຶ່ງ.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// ສ້າງ iterator ທີ່ສິ້ນສຸດລົງພາຍຫຼັງທີ່ທໍາອິດ [`None`] ເປັນ.
    ///
    /// ຫຼັງຈາກທີ່ເປັນ iterator ໃຫ້ຜົນໄດ້ຮັບ [`None`], ໂທ future ອາດຫຼືອາດຈະບໍ່ໃຫ້ຜົນຜະລິດ [`Some(T)`] ອີກເທື່ອຫນຶ່ງ.
    /// `fuse()` ປັບເປັນ iterator, ການຮັບປະກັນວ່າພາຍຫຼັງທີ່ [`None`] ຖືກມອບໃຫ້, ມັນສະເຫມີໄປຈະກັບຄືນ [`None`] ຕະຫຼອດໄປ.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // ເປັນ iterator ທີ່ສະຫລັບລະຫວ່າງບາງແລະບໍ່ມີ
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ຖ້າຫາກວ່າມັນເປັນແມ້ກະທັ້ງ, Some(i32), ອື່ນບໍ່ມີ
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // ພວກເຮົາສາມາດເບິ່ງພວກເຮົາກັບຄືນໄປບ່ອນໄປ iterator ແລະດັງນີ້ຕໍ່ໄປ
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ຢ່າງໃດກໍຕາມ, ເມື່ອພວກເຮົາ fuse ມັນ ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ມັນສະເຫມີໄປຈະກັບຄືນ `None` ຫຼັງຈາກທີ່ໃຊ້ເວລາທໍາອິດ.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// ບໍ່ບາງສິ່ງບາງຢ່າງທີ່ມີອົງປະກອບຂອງ iterator ແຕ່ລະ, ຖ່າຍທອດມູນຄ່າກ່ຽວກັບການ.
    ///
    /// ໃນເວລາທີ່ການນໍາໃຊ້ iterators, ທ່ານມັກຈະລະບົບຕ່ອງໂສ້ຫຼາຍຂອງເຂົາເຈົ້າຮ່ວມກັນ.
    /// ໃນຂະນະທີ່ເຮັດວຽກກ່ຽວກັບລະຫັດດັ່ງກ່າວ, ທ່ານອາດຈະຕ້ອງການທີ່ຈະກວດສອບການອອກສິ່ງທີ່ເກີດຂຶ້ນຢູ່ໃນພາກສ່ວນຕ່າງໆຢູ່ໃນແຜນເທື່ອ.ເພື່ອເຮັດແນວນັ້ນ, ສະແດງກິ່ງງ່າ call to `inspect()` ໄດ້.
    ///
    /// ມັນເປັນການທົ່ວໄປສໍາລັບ `inspect()` ທີ່ຈະຖືກນໍາໃຊ້ເປັນເຄື່ອງມືແກ້ຈຸດບົກພ່ອງກ່ວາທີ່ຈະມີໃນລະຫັດສຸດທ້າຍຂອງທ່ານ, ແຕ່ຄໍາຮ້ອງສະຫມັກອາດຈະເຫັນວ່າມັນເປັນປະໂຫຍດໃນບາງກໍລະນີໃນເວລາທີ່ຄວາມຜິດພາດຈໍາເປັນຕ້ອງໄດ້ຮັບການເຂົ້າສູ່ລະບົບກ່ອນທີ່ຈະຖືກຍົກເລີກ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ລໍາດັບ iterator ນີ້ແມ່ນສະລັບສັບຊ້ອນ.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ໃຫ້ຕື່ມບາງໂທ inspect() ເພື່ອສືບສວນວ່າມີຫຍັງແດ່ທີ່ເກີດຂຶ້ນ
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// ນີ້ຈະພິມ:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// ການຕັດໄມ້ທ່ອນຄວາມຜິດພາດກ່ອນທີ່ຈະຖິ້ມໃຫ້ເຂົາເຈົ້າ:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// ນີ້ຈະພິມ:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// ການກູ້ຢືມເງິນເປັນ iterator, ແທນທີ່ຈະກ່ວາບໍລິສຸດ.
    ///
    /// ນີ້ແມ່ນເປັນປະໂຫຍດທີ່ຈະອະນຸຍາດໃຫ້ຍື່ນຄໍາຮ້ອງຂໍອະແດບເຕີ iterator ໃນຂະນະທີ່ຍັງຮັກສາຄວາມເປັນເຈົ້າຂອງຂອງ iterator ຕົ້ນສະບັບ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ຖ້າພວກເຮົາພະຍາຍາມໃຊ້ມັນອີກ, ມັນຈະບໍ່ເຮັດວຽກ.
    /// // ເສັ້ນດັ່ງຕໍ່ໄປນີ້ເຮັດໃຫ້ "ຄວາມຜິດພາດ: ການນໍາໃຊ້ມູນຄ່າຍ້າຍ: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ໃຫ້ຂອງພະຍາຍາມອີກເທື່ອຫນຶ່ງ
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ແທນທີ່ຈະ, ພວກເຮົາໄດ້ເພີ່ມໃນ .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ໃນປັດຈຸບັນນີ້ເປັນພຽງແຕ່ດີ:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// ປ່ຽນເປັນ iterator ເຂົ້າໄປໃນການເກັບກໍາ.
    ///
    /// `collect()` ສາມາດໃຊ້ເວລາການລຶ້ມຄືນເຊັ່ນຫຍັງ, ແລະເຮັດໃຫ້ມັນເຂົ້າໄປໃນການເກັບກໍາທີ່ກ່ຽວຂ້ອງ.
    /// ນີ້ແມ່ນຫນຶ່ງໃນວິທີການມີອໍານາດຫຼາຍໃນໄລບາລີມາດຕະຖານທີ່ໃຊ້ໃນຫຼາຍໆຂອງທີ່ກວ້າງຂວາງ.
    ///
    /// ຮູບແບບພື້ນຖານທີ່ສຸດທີ່ `collect()` ຖືກນໍາໃຊ້ແມ່ນເພື່ອເຮັດໃຫ້ຫນຶ່ງການເກັບກໍາເຂົ້າໄປໃນອີກ.
    /// ທ່ານໃຊ້ເວລາເກັບກໍາຂໍ້ມູນ, ໂທ [`iter`] ໃສ່ມັນ, ເຮັດແນວໃດຊໍ່ຂອງການຫັນເປັນ, ແລະຫຼັງຈາກນັ້ນ `collect()` ທີ່ສຸດ.
    ///
    /// `collect()` ຍັງສາມາດສ້າງຕົວຢ່າງຂອງປະເພດທີ່ບໍ່ແມ່ນຊັນປົກກະຕິ.
    /// ສໍາລັບຕົວຢ່າງ, ເປັນ [`String`] ສາມາດໄດ້ຮັບການສ້າງຂຶ້ນຈາກ [`char`] s, ແລະເປັນ iterator ຂອງລາຍການ [`Result<T, E>`][`Result`] ສາມາດໄດ້ຮັບການເກັບກໍາຂໍ້ມູນເຂົ້າໄປໃນ `Result<Collection<T>, E>`.
    ///
    /// ເບິ່ງຕົວຢ່າງຂ້າງລຸ່ມນີ້ ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ.
    ///
    /// ເນື່ອງຈາກວ່າ `collect()` ແມ່ນທົ່ວໄປສະນັ້ນ, ມັນສາມາດເຮັດໃຫ້ເກີດບັນຫາກ່ຽວກັບປະເພດການອະນຸມານ.
    /// ໃນຖານະເຊັ່ນ, `collect()` ເປັນຫນຶ່ງໃນບໍ່ເທົ່າໃດເວລາທີ່ທ່ານຈະເບິ່ງໄວຢາກອນຮູ້ຈັກຮັກເປັນ 'turbofish': `::<>`.
    /// ນີ້ຈະຊ່ວຍໃຫ້ຂັ້ນຕອນວິທີການອະນຸມານໄດ້ເຂົ້າໃຈໂດຍສະເພາະການເກັບກໍາທີ່ທ່ານກໍາລັງພະຍາຍາມເພື່ອເກັບກໍາເຂົ້າໄປໃນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ໃຫ້ສັງເກດວ່າພວກເຮົາຈໍາເປັນ `: Vec<i32>` ກ່ຽວກັບເບື້ອງຊ້າຍມື.ນີ້ແມ່ນຍ້ອນວ່າພວກເຮົາສາມາດເກັບກໍາເຂົ້າໄປໃນ, ສໍາລັບການຍົກຕົວຢ່າງ, ເປັນ [`VecDeque<T>`] ແທນທີ່ຈະ:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// ການນໍາໃຊ້ 'turbofish' ແທນທີ່ຈະເປັນ annotating `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ເນື່ອງຈາກວ່າ `collect()` ພຽງແຕ່ເປັນຫ່ວງເປັນໄຍກ່ຽວກັບສິ່ງທີ່ທ່ານກໍາລັງເກັບກໍາເຂົ້າໄປໃນ, ທ່ານຍັງສາມາດນໍາໃຊ້ຄໍາແນະນໍາປະເພດບາງສ່ວນ, `_`, ມີ turbofish ໄດ້:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ການນໍາໃຊ້ `collect()` ເພື່ອເຮັດໃຫ້ເປັນ [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// ຖ້າທ່ານມີລາຍຊື່ຂອງ [`ຜົນໄດ້ຮັບ<T, E>`][`Result`] s, ທ່ານສາມາດໃຊ້ `collect()` ເພື່ອເບິ່ງວ່າຂອງເຂົາເຈົ້າສົບຜົນສໍາເລັດ:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ໃຫ້ພວກເຮົາມີຂໍ້ຜິດພາດ ທຳ ອິດ
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ເຮັດໃຫ້ພວກເຮົາບັນຊີລາຍຊື່ຂອງຄໍາຕອບຂອງ
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// ຜູ້ນຶ່ງ iterator, ສ້າງສອງຊັນຈາກມັນ.
    ///
    /// ການຄາດຄະເນຜ່ານໄປ `partition()` ສາມາດສົ່ງຄືນ `true`, ຫຼື `false`.
    /// `partition()` ຜົນໄດ້ຮັບຄູ່, ທັງຫມົດຂອງອົງປະກອບທີ່ສໍາລັບການທີ່ມັນໄດ້ກັບຄືນ `true`, ແລະທັງຫມົດຂອງອົງປະກອບທີ່ສໍາລັບການທີ່ມັນໄດ້ກັບຄືນ `false`.
    ///
    ///
    /// ເບິ່ງຕື່ມທີ່ [`is_partitioned()`] ແລະ [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Re: ຄໍາສັ່ງອົງປະກອບຂອງ iterator ນີ້ *ໃນສະຖານທີ່* ອີງຕາມການຢາດັ່ງກ່າວ, ເຊັ່ນວ່າທັງຫມົດທີ່ກັບຄືນ `true` ເກີດຂຶ້ນກ່ອນຄົນທັງປວງທີ່ກັບຄືນ `false`.
    ///
    /// ຜົນຕອບແທນຈໍານວນຂອງອົງປະກອບ `true` ທີ່ພົບເຫັນ.
    ///
    /// ຄໍາສັ່ງທີ່ກ່ຽວຂ້ອງຂອງລາຍການແບ່ງປັນບໍ່ໄດ້ຖືກຮັກສາໄວ້.
    ///
    /// ເບິ່ງຍັງ [`is_partitioned()`] ແລະ [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // ການແບ່ງປັນຢູ່ໃນສະຖານທີ່ລະຫວ່າງສະມາດ Eve ແລະໂອກາດ
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ພວກເຮົາຄວນຈະກັງວົນກ່ຽວກັບ overflowing ນັບແນວໃດ?ວິທີທີ່ພຽງແຕ່ຈະມີຫຼາຍກ່ວາ
        // `usize::MAX` ເອກະສານທີ່ບໍ່ແນ່ນອນແມ່ນມີ ZSTs ຊຶ່ງບໍ່ເປັນປະໂຫຍດກັບການແບ່ງປັນ ...

        // ເຫຼົ່ານີ້ປິດຫນ້າ "factory" ມີເພື່ອຫຼີກເວັ້ນການອັນໃຫຍ່ຫຼວງໃນ `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // ຊ້ໍາຊອກຫາ `false` ທໍາອິດແລະແລກປ່ຽນປະສົບມັນກັບສຸດທ້າຍ `true` ໄດ້.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// ກວດສອບວ່າອົງປະກອບຂອງນີ້ iterator ແມ່ນ partitioned ຕາມຢາດັ່ງກ່າວ, ເຊັ່ນວ່າທັງຫມົດທີ່ກັບຄືນ `true` ເກີດຂຶ້ນກ່ອນຄົນທັງປວງທີ່ກັບຄືນ `false`.
    ///
    ///
    /// ເບິ່ງຍັງ [`partition()`] ແລະ [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // ບໍ່ວ່າຈະລາຍການທັງຫມົດທົດສອບ `true`, ຫຼືອານຸປະໂຫຍດທໍາອິດຢຸດຢູ່ `false` ແລະພວກເຮົາກວດສອບວ່າບໍ່ມີຫຼາຍລາຍການ `true` ຫຼັງຈາກນັ້ນ.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// ເປັນວິທີການ iterator ທີ່ໃຊ້ການທໍາງານຂອງໄດ້ຕາບໃດທີ່ມັນຈະກັບຄືນມາຢ່າງສໍາເລັດຜົນ, ການຜະລິດດຽວ, ມູນຄ່າສຸດທ້າຍ.
    ///
    /// `try_fold()` ໃຊ້ເວລາທັງສອງກະທູ້: ເປັນຄ່າເລີ່ມຕົ້ນ, ແລະປິດດ້ວຍສອງອາກິວເມນ: ເປັນ 'accumulator', ແລະອົງປະກອບໄດ້.
    /// ການປິດບໍ່ວ່າຈະຕອບແທນສົບຜົນສໍາເລັດ, ທີ່ມີມູນຄ່າທີ່ສະສົມຄວນມີສໍາລັບ iteration ຕໍ່ໄປ, ຫຼືວ່າມັນຈະກັບຄືນມາຄວາມລົ້ມເຫຼວ, ມີມູນຄ່າຄວາມຜິດພາດທີ່ຖືກແພ່ກະຈາຍໄປແປໄດ້ທຸທັນທີ (short-circuiting).
    ///
    ///
    /// ຄ່າເລີ່ມຕົ້ນແມ່ນມູນຄ່າທີ່ຜູ້ສະສົມຈະມີໃນການໂທຄັ້ງ ທຳ ອິດ.ຖ້າຫາກວ່າການນໍາໃຊ້ການປິດສໍາເລັດຜົນກັບອົງປະກອບຂອງ iterator ໃນທຸກໆ, `try_fold()` ໃຫ້ຜົນໄດ້ຮັບທີ່ສະສົມສຸດທ້າຍເປັນຜົນສໍາເລັດ.
    ///
    /// ພັບເປັນປະໂຫຍດທຸກຄັ້ງທີ່ທ່ານມີການເກັບກໍາບາງສິ່ງບາງຢ່າງ, ແລະຕ້ອງການທີ່ຈະຜະລິດເປັນມູນຄ່າດຽວຈາກມັນ.
    ///
    /// # ຫມາຍເຫດກັບ implementor
    ///
    /// ຫຼາຍຂອງວິທີການ (forward) ອື່ນໆມີການປະຕິບັດໃນຕອນຕົ້ນໃນການນີ້, ສະນັ້ນພະຍາຍາມທີ່ຈະປະຕິບັດນີ້ຢ່າງຊັດເຈນຖ້າຫາກວ່າມັນສາມາດເຮັດໄດ້ບາງສິ່ງບາງຢ່າງທີ່ດີກວ່າກ່ວາໄວ້ໃນຕອນຕົ້ນ `for` ການ loop ໄດ້.
    ///
    /// ໂດຍສະເພາະ, ພະຍາຍາມທີ່ຈະມີວິດີໂອນີ້ `try_fold()` ກ່ຽວກັບພາກສ່ວນພາຍໃນທີ່ iterator ນີ້ປະກອບດ້ວຍ.
    /// ຖ້າຫາກວ່າການໂທຫຼາຍມີຄວາມຈໍາເປັນປະຕິບັດການ `?` ອາດຈະສະດວກສໍາລັບບົບຕ່ອງໂສ້ມູນຄ່າສະສົມຕາມ, ແຕ່ລະວັງຄາຄົງທີ່ຈໍາເປັນຕ້ອງໄດ້ຮັບການແຕ່ງຕັ້ງກ່ອນຄືນທໍາອິດທີ່.
    /// ນີ້ແມ່ນວິທີການ `&mut self`, ສະນັ້ນ iteration ຕ້ອງຊີວະປະຫວັດຫຼັງຈາກການກົດແປ້ນພິມຜິດພາດນີ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ລວມກວດກາຂອງທັງຫມົດຂອງອົງປະກອບຂອງອາເລ
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // ຜົນລວມນີ້ລົ້ນໃນເວລາເພີ່ມ 100 ອົງປະກອບ
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // ເນື່ອງຈາກວ່າມັນສັ້ນ circuited, ອົງປະກອບທີ່ຍັງເຫຼືອຍັງສາມາດໃຊ້ໄດ້ຜ່ານ iterator ໄດ້.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ເປັນວິທີການ iterator ທີ່ໃຊ້ການທໍາງານຂອງ fallible ກັບແຕ່ລະລາຍການໃນ iterator, ຂາຍຢູ່ທີ່ຄວາມຜິດພາດຄັ້ງທໍາອິດແລະກັບຄືນຄວາມຜິດພາດທີ່.
    ///
    ///
    /// ນີ້ຍັງສາມາດໄດ້ຮັບການຄິດຂອງເປັນຮູບແບບຜິດຂອງ [`for_each()`] ຫຼືເປັນສະບັບພາສາ stateless ຂອງ [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // ມັນສັ້ນ circuited, ສະນັ້ນໃນລາຍການທີ່ຍັງເຫຼືອແມ່ນຍັງຢູ່ໃນ iterator ໄດ້:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// ຂື້ນອົງປະກອບເຂົ້າໄປໃນສະສົມທຸກໂດຍການນໍາໃຊ້ປະຕິບັດງານ, ກັບຄືນຜົນໄດ້ຮັບສຸດທ້າຍ.
    ///
    /// `fold()` ໃຊ້ເວລາທັງສອງກະທູ້: ເປັນຄ່າເລີ່ມຕົ້ນ, ແລະປິດດ້ວຍສອງອາກິວເມນ: ເປັນ 'accumulator', ແລະອົງປະກອບໄດ້.
    /// ການປິດໃຫ້ຜົນໄດ້ຮັບມູນຄ່າທີ່ສະສົມຄວນມີສໍາລັບ iteration ຕໍ່ໄປ.
    ///
    /// ຄ່າເລີ່ມຕົ້ນແມ່ນມູນຄ່າທີ່ຜູ້ສະສົມຈະມີໃນການໂທຄັ້ງ ທຳ ອິດ.
    ///
    /// ຫຼັງຈາກຍື່ນຄໍາຮ້ອງຂໍການປິດນີ້ອົງປະກອບຂອງ iterator ໃນທຸກໆ, `fold()` ໃຫ້ຜົນໄດ້ຮັບສະສົມໄດ້.
    ///
    /// ການປະຕິບັດງານນີ້ບາງຄັ້ງກໍ່ເອີ້ນວ່າ 'reduce' ຫຼື 'inject'.
    ///
    /// ພັບເປັນປະໂຫຍດທຸກຄັ້ງທີ່ທ່ານມີການເກັບກໍາບາງສິ່ງບາງຢ່າງ, ແລະຕ້ອງການທີ່ຈະຜະລິດເປັນມູນຄ່າດຽວຈາກມັນ.
    ///
    /// Note: `fold()`, ແລະວິທີການທີ່ຄ້າຍຄືກັນທີ່ກວມເອົາເກີນໄດ້ iterator ທັງຫມົດ, ອາດຈະບໍ່ຢຸດຕິການສໍາລັບ iterators infinite, ແມ້ກະທັ້ງສຸດ traits ທີ່ເປັນຜົນໄດ້ຮັບແມ່ນຊາບໃນເວລາຈໍາກັດ.
    ///
    /// Note: [`reduce()`] ສາມາດຖືກນໍາໃຊ້ເພື່ອການນໍາໃຊ້ອົງປະກອບທໍາອິດເປັນຄ່າເລີ່ມຕົ້ນ, ຖ້າຫາກວ່າປະເພດສະສົມແລະປະເພດລາຍການແມ່ນດຽວກັນ.
    ///
    /// # ຫມາຍເຫດກັບ implementor
    ///
    /// ຫຼາຍຂອງວິທີການ (forward) ອື່ນໆມີການປະຕິບັດໃນຕອນຕົ້ນໃນການນີ້, ສະນັ້ນພະຍາຍາມທີ່ຈະປະຕິບັດນີ້ຢ່າງຊັດເຈນຖ້າຫາກວ່າມັນສາມາດເຮັດໄດ້ບາງສິ່ງບາງຢ່າງທີ່ດີກວ່າກ່ວາໄວ້ໃນຕອນຕົ້ນ `for` ການ loop ໄດ້.
    ///
    ///
    /// ໂດຍສະເພາະ, ພະຍາຍາມທີ່ຈະມີວິດີໂອນີ້ `fold()` ກ່ຽວກັບພາກສ່ວນພາຍໃນທີ່ iterator ນີ້ປະກອບດ້ວຍ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ຜົນລວມຂອງທັງຫມົດຂອງອົງປະກອບຂອງຂບວນການໄດ້
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ຍ່າງໃຫ້ຜ່ານຂັ້ນຕອນຂອງ iteration ທີ່ນີ້ແຕ່ລະຄົນ:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// ແລະດັ່ງນັ້ນ, ຜົນສຸດທ້າຍຂອງພວກເຮົາ, `6`.
    ///
    /// ມັນເປັນທົ່ວໄປສໍາລັບປະຊາຊົນຜູ້ທີ່ຍັງບໍ່ທັນໄດ້ນໍາໃຊ້ iterators ຫຼາຍທີ່ຈະນໍາໃຊ້ເປັນ loop `for` ກັບບັນຊີລາຍຊື່ຂອງສິ່ງຕ່າງໆທີ່ຈະສ້າງຂຶ້ນນັ້ນ.ຜູ້ທີ່ສາມາດໄດ້ຮັບການຫັນເຂົ້າໄປໃນ `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // ສໍາລັບວົງ:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ພວກເຂົາເຈົ້າກໍາລັງດຽວກັນ
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// ການຫຼຸດຜ່ອນການອົງປະກອບໃນການເປັນຫນຶ່ງດຽວ, ໂດຍ repeatedly ຍື່ນຄໍາຮ້ອງຂໍປະຕິບັດງານການຫຼຸດຜ່ອນ.
    ///
    /// ຖ້າ iterator ແມ່ນຫວ່າງເປົ່າ, ຜົນໄດ້ຮັບ [`None`];ຖ້າບໍ່ດັ່ງນັ້ນ, ຜົນໄດ້ຮັບຜົນມາຈາກການຫຼຸດຜ່ອນການ.
    ///
    /// ສໍາລັບ iterators ກັບອົງປະກອບຢ່າງຫນ້ອຍຫນຶ່ງ, ນີ້ແມ່ນຄືກັນກັບ [`fold()`] ກັບອົງປະກອບທໍາອິດຂອງ iterator ເປັນມູນຄ່າໃນເບື້ອງຕົ້ນ, ເທົ່າທຸກອົງປະກອບຕໍ່ໄປເຂົ້າໄປໃນມັນ.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// ຊອກຄ່າສູງສຸດໄດ້:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// ການທົດສອບຖ້າຫາກວ່າອົງປະກອບຂອງ iterator ໃນທຸກໆກົງໄວ້ເປັນ.
    ///
    /// `all()` ໃຊ້ເວລາປິດທີ່ໃຫ້ຜົນໄດ້ຮັບ `true` ຫຼື `false` ໄດ້.ມັນໃຊ້ໄດ້ປິດນີ້ອົງປະກອບຂອງ iterator ຂອງແຕ່ລະຄົນ, ແລະຖ້າຫາກວ່າພວກເຂົາເຈົ້າທັງຫມົດກັບຄືນ `true`, ຫຼັງຈາກນັ້ນສະນັ້ນບໍ່ `all()`.
    /// ຖ້າຄົນໃດໃນພວກເຂົາກັບຄືນ `false`, ມັນຈະກັບຄືນມາ `false`.
    ///
    /// `all()` ສັ້ນວົງຈອນ;ເວົ້າອີກຢ່າງ ໜຶ່ງ, ມັນຈະຢຸດການປະມວນຜົນທັນທີທີ່ມັນພົບ `false`, ເຖິງວ່າຈະມີຫຍັງເກີດຂື້ນກໍ່ຕາມ, ຜົນໄດ້ຮັບກໍ່ຈະເປັນ `false` ເຊັ່ນກັນ.
    ///
    ///
    /// ເປັນ iterator ຫວ່າງໃຫ້ຜົນໄດ້ຮັບ `true`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// ຂາຍຢູ່ທີ່ທໍາອິດ `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // ພວກເຮົາຍັງສາມາດໃຊ້ `iter`, ເນື່ອງຈາກວ່າມີອົງປະກອບເພີ່ມເຕີມ.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// ການທົດສອບຖ້າຫາກວ່າອົງປະກອບຂອງ iterator ແຕ່ຢ່າງໃດກົງກັບຢາໄດ້.
    ///
    /// `any()` ໃຊ້ເວລາປິດທີ່ໃຫ້ຜົນໄດ້ຮັບ `true` ຫຼື `false` ໄດ້.ມັນໃຊ້ການປິດນີ້ກັບແຕ່ລະອົງປະກອບຂອງໂຕປັບ, ແລະຖ້າມີມັນກັບຄືນ `true`, ຫຼັງຈາກນັ້ນ `any()` ກໍ່ເຮັດເຊັ່ນກັນ.
    /// ຖ້າຫາກວ່າພວກເຂົາເຈົ້າທັງຫມົດກັບຄືນ `false`, ມັນຈະກັບຄືນມາ `false`.
    ///
    /// `any()` ສັ້ນວົງຈອນ;ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ມັນຈະຢຸດເຊົາການປະມວນຜົນທັນທີທີ່ເຫັນວ່າເປັນ `true`, ຈຸດໃດຫນຶ່ງທີ່ສໍາຄັນແມ່ນຫຍັງທີ່ເກີດຂຶ້ນບໍ່ມີ, ຜົນໄດ້ຮັບຍັງຈະ `true`.
    ///
    ///
    /// ເປັນ iterator ຫວ່າງໃຫ້ຜົນໄດ້ຮັບ `false`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// ຂາຍຢູ່ທີ່ທໍາອິດ `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // ພວກເຮົາຍັງສາມາດໃຊ້ `iter`, ເນື່ອງຈາກວ່າມີອົງປະກອບເພີ່ມເຕີມ.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// ຊອກຫາອົງປະກອບຂອງເຄື່ອງປັບທີ່ພໍໃຈກັບການຄາດເດົາ.
    ///
    /// `find()` ໃຊ້ເວລາປິດທີ່ໃຫ້ຜົນໄດ້ຮັບ `true` ຫຼື `false` ໄດ້.
    /// ມັນໃຊ້ໄດ້ປິດນີ້ອົງປະກອບຂອງ iterator ຂອງແຕ່ລະຄົນ, ແລະຖ້າມີການໃຫ້ເຂົາເຈົ້າກັບຄືນ `true`, ຫຼັງຈາກນັ້ນຜົນໄດ້ຮັບ `find()` [`Some(element)`].
    /// ຖ້າພວກເຂົາທັງ ໝົດ ກັບຄືນ `false`, ມັນຈະສົ່ງຄືນ [`None`].
    ///
    /// `find()` ສັ້ນວົງຈອນ;ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ມັນຈະຢຸດການປຸງແຕ່ງທັນທີທີ່ການປິດຈະກັບຄືນ `true`.
    ///
    /// ເນື່ອງຈາກວ່າ `find()` ໃຊ້ເວລາກະສານອ້າງອີງ, ແລະ iterators ຫຼາຍ iterate ໃນໄລຍະເອກະສານ, ເຮັດໃຫ້ນີ້ເປັນສະຖານະການເປັນໄປໄດ້ຂອງເຊື້ອຕະກຸນທີ່ໂຕ້ຖຽງແມ່ນກະສານອ້າງອີງເທົ່ານັ້ນ.
    ///
    /// ທ່ານສາມາດເບິ່ງຜົນກະທົບນີ້ໃນຕົວຢ່າງຂ້າງລຸ່ມນີ້, ມີ `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// ຂາຍຢູ່ທີ່ທໍາອິດ `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // ພວກເຮົາຍັງສາມາດໃຊ້ `iter`, ເນື່ອງຈາກວ່າມີອົງປະກອບເພີ່ມເຕີມ.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// ໃຫ້ສັງເກດວ່າ `iter.find(f)` ແມ່ນທຽບເທົ່າກັບ `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// ໃຊ້ການທໍາງານຂອງອົງປະກອບຂອງ iterator ແລະໃຫ້ຜົນໄດ້ຮັບຜົນໄດ້ຮັບທີ່ບໍ່ແມ່ນບໍ່ມີຄັ້ງທໍາອິດ.
    ///
    ///
    /// `iter.find_map(f)` ເທົ່າກັບ `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// ໃຊ້ການທໍາງານຂອງອົງປະກອບຂອງ iterator ແລະໃຫ້ຜົນໄດ້ຮັບຜົນໄດ້ຮັບທີ່ແທ້ຈິງທໍາອິດຫຼືຄວາມຜິດພາດຄັ້ງທໍາອິດ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// ຄົ້ນຫາສໍາລັບອົງປະກອບໃນ iterator ເປັນ, ກັບຄືນດັດຊະນີຂອງຕົນ.
    ///
    /// `position()` ໃຊ້ເວລາປິດທີ່ໃຫ້ຜົນໄດ້ຮັບ `true` ຫຼື `false` ໄດ້.
    /// ມັນໃຊ້ການປິດນີ້ກັບແຕ່ລະອົງປະກອບຂອງໂຕປັບ, ແລະຖ້າ ໜຶ່ງ ໃນນັ້ນກັບ `true`, ຫຼັງຈາກນັ້ນ `position()` ຈະກັບຄືນ [`Some(index)`].
    /// ຖ້າຫາກວ່າທັງຫມົດຂອງພວກເຂົາກັບຄືນ `false`, ມັນຈະກັບຄືນມາ [`None`].
    ///
    /// `position()` ແມ່ນສັ້ນ;ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ມັນຈະຢຸດເຊົາການປະມວນຜົນທັນທີທີ່ເຫັນວ່າເປັນ `true`.
    ///
    /// # ພຶດຕິກໍາ overflow
    ///
    /// ວິທີການບໍ່ guarding ຕ້ານ overflow ບໍ່ມີ, ສະນັ້ນຖ້າຫາກວ່າມີຫຼາຍກ່ວາ [`usize::MAX`] ອົງປະກອບທີ່ບໍ່ແມ່ນກົງກັບ, ມັນບໍ່ວ່າຈະສາມາດຜະລິດຜົນໄດ້ຮັບທີ່ບໍ່ຖືກຕ້ອງຫຼື panics.
    ///
    /// ຖ້າຫາກວ່າການຍື່ນຍັນ debug ຖືກເປີດໃຫ້ໃຊ້ງານ, ເປັນ panic ແມ່ນການຮັບປະກັນ.
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ອາດ panic ຖ້າ iterator ມີຫຼາຍກ່ວາ `usize::MAX` ອົງປະກອບທີ່ບໍ່ແມ່ນກົງກັບ.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// ຂາຍຢູ່ທີ່ທໍາອິດ `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // ພວກເຮົາຍັງສາມາດໃຊ້ `iter`, ເນື່ອງຈາກວ່າມີອົງປະກອບເພີ່ມເຕີມ.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ດັດຊະນີທີ່ຖືກສົ່ງຄືນແມ່ນຂື້ນກັບສະຖານະພາບຂອງຜູ້ປັບ
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// ຄົ້ນຫາສໍາລັບອົງປະກອບໃນ iterator ຈາກສິດທິໃນການເປັນ, ກັບຄືນດັດຊະນີຂອງຕົນ.
    ///
    /// `rposition()` ໃຊ້ເວລາປິດທີ່ໃຫ້ຜົນໄດ້ຮັບ `true` ຫຼື `false` ໄດ້.
    /// ມັນໃຊ້ໄດ້ປິດນີ້ອົງປະກອບຂອງ iterator, ໂດຍເລີ່ມຕົ້ນຈາກຕອນສຸດທ້າຍຂອງແຕ່ລະຄົນ, ແລະຖ້າຫາກວ່າຫນຶ່ງຂອງເຂົາເຈົ້າຈະກັບຄືນມາ `true`, ຫຼັງຈາກນັ້ນຜົນໄດ້ຮັບ `rposition()` [`Some(index)`].
    ///
    /// ຖ້າຫາກວ່າທັງຫມົດຂອງພວກເຂົາກັບຄືນ `false`, ມັນຈະກັບຄືນມາ [`None`].
    ///
    /// `rposition()` ແມ່ນສັ້ນ;ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ມັນຈະຢຸດເຊົາການປະມວນຜົນທັນທີທີ່ເຫັນວ່າເປັນ `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// ຂາຍຢູ່ທີ່ທໍາອິດ `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // ພວກເຮົາຍັງສາມາດໃຊ້ `iter`, ເນື່ອງຈາກວ່າມີອົງປະກອບເພີ່ມເຕີມ.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // ຄວາມຈໍາເປັນໃນ overflow ກວດເບິ່ງທີ່ນີ້, ເນື່ອງຈາກວ່າ `ExactSizeIterator` ຫມາຍຄວາມວ່າຈໍານວນຂອງອົງປະກອບການຊັກໃນ `usize` ໄດ້.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// ຜົນໄດ້ຮັບການອົງປະກອບສູງສຸດຂອງ iterator.
    ///
    /// ຖ້າຫຼາຍໆອົງປະກອບສູງສຸດເທົ່າທຽມກັນ, ອົງປະກອບສຸດທ້າຍກໍ່ຈະສົ່ງຄືນ.
    /// ຖ້າ iterator ແມ່ນເປົ່າ, [`None`] ຖືກສົ່ງກັບ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// ຜົນໄດ້ຮັບການອົງປະກອບຕ່ໍາສຸດຂອງ iterator.
    ///
    /// ຖ້າຫາກວ່າອົງປະກອບຫຼາຍມີຕໍາ່ສຸດເທົ່າທຽມກັນ, ອົງປະກອບທໍາອິດຈະຖືກສົ່ງກັບ.
    /// ຖ້າ iterator ແມ່ນເປົ່າ, [`None`] ຖືກສົ່ງກັບ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// ສົ່ງຄືນອົງປະກອບທີ່ໃຫ້ຄຸນຄ່າສູງສຸດຈາກ ໜ້າ ທີ່ທີ່ລະບຸ.
    ///
    ///
    /// ຖ້າຫຼາຍໆອົງປະກອບສູງສຸດເທົ່າທຽມກັນ, ອົງປະກອບສຸດທ້າຍກໍ່ຈະສົ່ງຄືນ.
    /// ຖ້າ iterator ແມ່ນເປົ່າ, [`None`] ຖືກສົ່ງກັບ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// ຜົນຕອບແທນອົງປະກອບທີ່ເຮັດໃຫ້ມູນຄ່າສູງສຸດດ້ວຍຄວາມນັບຖືທີ່ຈະທໍາງານການປຽບທຽບທີ່ລະບຸ.
    ///
    ///
    /// ຖ້າຫຼາຍໆອົງປະກອບສູງສຸດເທົ່າທຽມກັນ, ອົງປະກອບສຸດທ້າຍກໍ່ຈະສົ່ງຄືນ.
    /// ຖ້າ iterator ແມ່ນເປົ່າ, [`None`] ຖືກສົ່ງກັບ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ຜົນຕອບແທນອົງປະກອບທີ່ເຮັດໃຫ້ມູນຄ່າຕ່ໍາສຸດຈາກການທໍາງານທີ່ກໍານົດໄວ້.
    ///
    ///
    /// ຖ້າຫາກວ່າອົງປະກອບຫຼາຍມີຕໍາ່ສຸດເທົ່າທຽມກັນ, ອົງປະກອບທໍາອິດຈະຖືກສົ່ງກັບ.
    /// ຖ້າ iterator ແມ່ນເປົ່າ, [`None`] ຖືກສົ່ງກັບ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// ກັບຄືນອົງປະກອບທີ່ໃຫ້ຄ່າ ຕຳ ່ສຸດທີ່ກັບການ ທຳ ງານຂອງການປຽບທຽບທີ່ລະບຸ.
    ///
    ///
    /// ຖ້າຫາກວ່າອົງປະກອບຫຼາຍມີຕໍາ່ສຸດເທົ່າທຽມກັນ, ອົງປະກອບທໍາອິດຈະຖືກສົ່ງກັບ.
    /// ຖ້າ iterator ແມ່ນເປົ່າ, [`None`] ຖືກສົ່ງກັບ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ຝືນທາງການຂອງ iterator.
    ///
    /// ໂດຍປົກກະຕິແລ້ວ, ເຄື່ອງປັບອາກາດຄັນຈາກຊ້າຍຫາຂວາ.
    /// ຫຼັງຈາກການນໍາໃຊ້ `rev()`, ເປັນ iterator ຈະແທນທີ່ຈະ iterate ຈາກຂວາໄປຊ້າຍ.
    ///
    /// ນີ້ເປັນໄປໄດ້ພຽງແຕ່ຖ້າຫາກວ່າ iterator ໄດ້ຈຶ່ງມີບ່ອນສຸດ, ສະນັ້ນ `rev()` ພຽງແຕ່ເຮັດວຽກກ່ຽວກັບການ [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// ແປງເປັນ iterator ຂອງຄູ່ເປັນຄູ່ຂອງການບັນຈຸໄດ້.
    ///
    /// `unzip()` ຜູ້ນຶ່ງ iterator ທັງຫມົດຂອງຄູ່, ການຜະລິດສອງຊັນ: ຈາກອົງປະກອບທາງດ້ານຊ້າຍຂອງຄູ່, ແລະຈາກອົງປະກອບທີ່ຖືກຕ້ອງ.
    ///
    ///
    /// ໜ້າ ທີ່ນີ້ແມ່ນໃນແງ່ ໜຶ່ງ, ກົງກັນຂ້າມກັບ [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// ສ້າງເປັນ iterator ທີ່ສໍາເນົາທັງຫມົດຂອງອົງປະກອບຂອງຕົນ.
    ///
    /// ນີ້ແມ່ນເປັນປະໂຫຍດໃນເວລາທີ່ທ່ານມີ iterator ໃນໄລຍະ `&T`, ແຕ່ວ່າທ່ານຈໍາເປັນຕ້ອງເປັນ iterator ໃນໄລຍະ `T`.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // ສໍາເນົາແມ່ນຄືກັນກັບ .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// ສ້າງເປັນ iterator ທີ່ [`clone`] s ທັງຫມົດຂອງອົງປະກອບຂອງຕົນ.
    ///
    /// ນີ້ແມ່ນເປັນປະໂຫຍດໃນເວລາທີ່ທ່ານມີ iterator ໃນໄລຍະ `&T`, ແຕ່ວ່າທ່ານຈໍາເປັນຕ້ອງເປັນ iterator ໃນໄລຍະ `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned ແມ່ນຄືກັນກັບ .map(|&x| x), ສໍາລັບຈໍານວນເຕັມ
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// ຊ້ໍາເປັນ iterator endlessly.
    ///
    /// ແທນທີ່ຈະຂາຍຢູ່ [`None`], iterator ແທນຈະເລີ່ມຕົ້ນອີກເທື່ອຫນຶ່ງ, ໃນຕອນເລີ່ມຕົ້ນ.ຫຼັງຈາກ iterating ອີກເທື່ອຫນຶ່ງ, ມັນຈະເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນອີກເທື່ອຫນຶ່ງ.ແລະອີກເທື່ອຫນຶ່ງ.
    /// ແລະອີກເທື່ອຫນຶ່ງ.
    /// Forever.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Sums ອົງປະກອບຂອງ iterator ໄດ້.
    ///
    /// ໃຊ້ເວລາໃນແຕ່ລະອົງປະກອບ, ເພີ່ມໃຫ້ເຂົາເຈົ້າຮ່ວມກັນ, ແລະຜົນໄດ້ຮັບຜົນໄດ້ຮັບ.
    ///
    /// ເປັນ iterator ຫວ່າງໃຫ້ຜົນໄດ້ຮັບມູນຄ່າສູນຂອງປະເພດການ.
    ///
    /// # Panics
    ///
    /// ເມື່ອໂທຫາ `sum()` ແລະປະເພດເລກປະຖົມນິຖານ ກຳ ລັງຖືກສົ່ງຄືນ, ວິທີການນີ້ຈະເປັນ panic ຖ້າການ ຄຳ ນວນທີ່ເກີນ ກຳ ລັງແລະການຢືນຢັນຂອງ debug ຖືກເປີດໃຊ້ງານ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// ລຶ້ມຄືນເຊັ່ນ: ໃນໄລຍະ iterator ທັງຫມົດ, ການຄູນອົງປະກອບທັງຫມົດ
    ///
    /// ເປັນ iterator ຫວ່າງໃຫ້ຜົນໄດ້ຮັບມູນຄ່າຫນຶ່ງໃນປະເພດທີ່.
    ///
    /// # Panics
    ///
    /// ໃນເວລາທີ່ການໂທຫາ `product()` ແລະຊະນິດຈໍານວນເຕັມ primitive ຖືກສົ່ງກັບຄືນ, ວິທີການຈະ panic ຖ້າ overflow ຄອມພິວເຕີແລະການຍື່ນຍັນ debug ຖືກເປີດໃຫ້ໃຊ້ງານ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ປຽບທຽບອົງປະກອບຂອງ [`Iterator`] ນີ້ກັບຂອງຄົນອື່ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ປຽບທຽບອົງປະກອບຂອງ [`Iterator`] ນີ້ກັບບັນດາຄົນອື່ນທີ່ມີຄວາມນັບຖືທີ່ຈະທໍາງານການປຽບທຽບທີ່ລະບຸ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ປຽບທຽບອົງປະກອບຂອງ [`Iterator`] ນີ້ກັບຂອງຄົນອື່ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ປຽບທຽບອົງປະກອບຂອງ [`Iterator`] ນີ້ກັບບັນດາຄົນອື່ນທີ່ມີຄວາມນັບຖືທີ່ຈະທໍາງານການປຽບທຽບທີ່ລະບຸ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// ຕັດສິນກໍານົດຖ້າຫາກວ່າອົງປະກອບຂອງ [`Iterator`] ນີ້ແມ່ນເທົ່າທຽມກັນກັບຜູ້ທີ່ຂອງຄົນອື່ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// ຕັດສິນກໍານົດຖ້າຫາກວ່າອົງປະກອບຂອງ [`Iterator`] ນີ້ແມ່ນເທົ່າທຽມກັນກັບຜູ້ທີ່ຂອງຄົນອື່ນດ້ວຍຄວາມນັບຖືທີ່ຈະທໍາງານຄວາມສະເຫມີພາບທີ່ລະບຸ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// ຕັດສິນກໍານົດຖ້າຫາກວ່າອົງປະກອບຂອງ [`Iterator`] ນີ້ແມ່ນກັນກັບຂອງຄົນອື່ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// ຕັດສິນກໍານົດຖ້າຫາກວ່າອົງປະກອບຂອງ [`Iterator`] ນີ້ແມ່ນ [lexicographically](Ord#lexicographical-comparison) ຫນ້ອຍກ່ວາຜູ້ທີ່ຂອງຄົນອື່ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// ຕັດສິນກໍານົດຖ້າຫາກວ່າອົງປະກອບຂອງ [`Iterator`] ນີ້ແມ່ນ [lexicographically](Ord#lexicographical-comparison) ຫນ້ອຍຫຼືມີຄວາມຫມາຍເທົ່າກັບຂອງຄົນອື່ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// ຕັດສິນກໍານົດຖ້າຫາກວ່າອົງປະກອບຂອງ [`Iterator`] ນີ້ແມ່ນ [lexicographically](Ord#lexicographical-comparison) ຫຼາຍກ່ວາຜູ້ທີ່ຂອງຄົນອື່ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// ຕັດສິນກໍານົດຖ້າຫາກວ່າອົງປະກອບຂອງ [`Iterator`] ນີ້ແມ່ນ [lexicographically](Ord#lexicographical-comparison) ຫມາຍໃຫຍ່ກວ່າຫຼືເທົ່າທຽມກັນທີ່ຫລັງຂອງຄົນອື່ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// ກວດສອບວ່າອົງປະກອບຂອງ iterator ນີ້ແມ່ນຄັດປະເພດ.
    ///
    /// ຫມາຍຄວາມວ່າ, ສໍາລັບແຕ່ລະອົງປະກອບ `a` ແລະຂອງຕົນອົງປະກອບດັ່ງຕໍ່ໄປນີ້ `b`, `a <= b` ຕ້ອງຖື.ຖ້າ iterator ໄດ້ຜົນຜະລິດແທ້ສູນຫຼືອົງປະກອບຫນຶ່ງ, `true` ຖືກສົ່ງກັບ.
    ///
    /// ໃຫ້ສັງເກດວ່າຖ້າຫາກວ່າ `Self::Item` ແມ່ນພຽງແຕ່ `PartialOrd`, ແຕ່ບໍ່ `Ord`, ຄໍານິຍາມຂ້າງເທິງຫມາຍຄວາມວ່າຫນ້າທີ່ນີ້ຈະກັບຄືນມາ `false` ຖ້າມີສອງລາຍການຕິດຕໍ່ກັນບໍ່ໄດ້ການປຽບທຽບ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// ກວດສອບວ່າອົງປະກອບຂອງ iterator ນີ້ແມ່ນຈັດຮຽງນໍາໃຊ້ການທໍາງານຂອງຕົວປຽບທຽບໃຫ້.
    ///
    /// ແທນທີ່ຈະນໍາໃຊ້ `PartialOrd::partial_cmp`, ການທໍາງານນີ້ໃຊ້ໃຫ້ການທໍາງານຂອງ `compare` ການກໍານົດຄໍາສັ່ງຂອງສອງອົງປະກອບທີ່.
    /// ນອກຈາກນັ້ນ, ມັນເປັນການທຽບເທົ່າກັບ [`is_sorted`];ເບິ່ງເອກະສານຂອງຕົນສໍາລັບຂໍ້ມູນເພີ່ມເຕີມ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// ກວດເບິ່ງວ່າອົງປະກອບຂອງຕົວຊີ້ວັດນີ້ຖືກຈັດຮຽງໂດຍໃຊ້ຟັງຊັນການສະກັດເອົາທີ່ ສຳ ຄັນ.
    ///
    /// ແທນທີ່ຈະປຽບທຽບອົງປະກອບ iterator ຂອງໂດຍກົງ, ການທໍາງານນີ້ປຽບທຽບຂໍກະແຈຂອງອົງປະກອບດັ່ງກ່າວ, ເປັນກໍານົດໂດຍ `f`.
    /// ນອກຈາກນັ້ນ, ມັນເປັນການທຽບເທົ່າກັບ [`is_sorted`];ເບິ່ງເອກະສານຂອງຕົນສໍາລັບຂໍ້ມູນເພີ່ມເຕີມ.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// ເບິ່ງ [TrustedRandomAccess]
    // ຊື່ຜິດປົກກະຕິແມ່ນເພື່ອຫຼີກເວັ້ນການ collisions ຊື່ໃນການແກ້ໄຂວິທີການເບິ່ງ #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}