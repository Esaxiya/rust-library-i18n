/// ເປັນ iterator ທີ່ຮູ້ຄວາມຍາວທີ່ແນ່ນອນຂອງຕົນ.
///
/// ຈໍານວນຫຼາຍ [`Iterator`] s ບໍ່ຮູ້ວ່າວິທີການຈໍານວນຫຼາຍເວລາທີ່ເຂົາເຈົ້າຈະ iterate, ແຕ່ບາງຄົນເຮັດ.
/// ຖ້າຜູ້ປະຕິບັດການຮູ້ວ່າມັນສາມາດປ່ຽນແປງໄດ້ຈັກເທື່ອ, ການໃຫ້ຂໍ້ມູນນັ້ນສາມາດເປັນປະໂຫຍດ.
/// ສໍາລັບຕົວຢ່າງ, ຖ້າຫາກວ່າທ່ານຕ້ອງການທີ່ຈະ iterate ຫຼັງ, ເປັນການເລີ່ມຕົ້ນທີ່ດີຄືການຮູ້ບ່ອນທີ່ໃນຕອນທ້າຍແມ່ນ.
///
/// ໃນເວລາທີ່ດໍາເນີນການ `ExactSizeIterator`, ທ່ານຍັງຈະຕ້ອງດໍາເນີນ [`Iterator`].
/// ໃນເວລາທີ່ເຮັດດັ່ງນັ້ນ, ການປະຕິບັດຂອງ [`Iterator::size_hint`]*ຕ້ອງ* ກັບຄືນຂະຫນາດທີ່ແນ່ນອນຂອງຕົວປ່ຽນແປງ.
///
/// ວິທີການ [`len`] ມີການປະຕິບັດໃນຕອນຕົ້ນ, ສະນັ້ນທ່ານປົກກະຕິແລ້ວບໍ່ຄວນໃຊ້ມັນ.
/// ຢ່າງໃດກໍຕາມ, ທ່ານອາດຈະສາມາດທີ່ຈະສະຫນອງການປະຕິບັດປະຕິບັດຫຼາຍກ່ວາໄວ້ໃນຕອນຕົ້ນ, ສະນັ້ນເອົາຊະນະມັນໃນກໍລະນີນີ້ເຮັດໃຫ້ຄວາມຮູ້ສຶກ.
///
///
/// ໃຫ້ສັງເກດວ່າ trait ນີ້ເປັນຄວາມປອດໄພ trait ແລະເປັນດັ່ງກ່າວບໍ່ *ບໍ່* ແລະ *ບໍ່ສາມາດເຮັດໄດ້* ຮັບປະກັນວ່າຄວາມຍາວໄດ້ກັບຄືນຖືກຕ້ອງ.
/// ນີ້ຫມາຍຄວາມວ່າລະຫັດ `unsafe`**ຕ້ອງບໍ່** ອີງໃສ່ຄວາມຖືກຕ້ອງຂອງ [`Iterator::size_hint`] ໄດ້.
/// ເສຖີຍນແລະບໍ່ປອດໄພ [`TrustedLen`](super::marker::TrustedLen) trait ເຮັດໃຫ້ນີ້ຮັບປະກັນເພີ່ມເຕີມ.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// // ຊ່ວງ finite ຮູ້ແທ້ເຮັດແນວໃດຈໍານວນຫຼາຍເວລາມັນຈະ iterate
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// ໃນ [module-level docs], ພວກເຮົາປະຕິບັດ [`Iterator`], `Counter`.
/// ໃຫ້ໃຊ້ `ExactSizeIterator` ມັນເຊັ່ນດຽວກັນ:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // ພວກເຮົາສາມາດຄິດໄລ່ ຈຳ ນວນສ່ວນທີ່ເຫຼືອຂອງມັນໄດ້ຢ່າງງ່າຍດາຍ.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // ແລະໃນປັດຈຸບັນພວກເຮົາສາມາດນໍາໃຊ້ມັນ!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// ຜົນໄດ້ຮັບຄວາມຍາວທີ່ແນ່ນອນຂອງ iterator ໄດ້.
    ///
    /// ການປະຕິບັດຮັບປະກັນວ່າ iterator ທີ່ຈະກັບຄືນແທ້ເວລາ `len()` ຫຼາຍຄ່າ [`Some(T)`], ກ່ອນທີ່ຈະກັບຄືນ [`None`].
    ///
    /// ວິທີການນີ້ມີການປະຕິບັດໃນຕອນຕົ້ນ, ສະນັ້ນທ່ານປົກກະຕິແລ້ວບໍ່ຄວນໃຊ້ມັນໂດຍກົງ.
    /// ຢ່າງໃດກໍຕາມ, ຖ້າຫາກວ່າທ່ານສາມາດສະຫນອງການປະຕິບັດປະສິດທິພາບຫຼາຍ, ທ່ານສາມາດເຮັດແນວນັ້ນ.
    /// ເບິ່ງເອກະສານ [trait-level] ສໍາລັບຕົວຢ່າງ.
    ///
    /// ຟັງຊັນນີ້ມີຮັບປະກັນຄວາມປອດໄພເຊັ່ນດຽວກັນກັບການທໍາງານຂອງ [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // ຊ່ວງ finite ຮູ້ແທ້ເຮັດແນວໃດຈໍານວນຫຼາຍເວລາມັນຈະ iterate
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: ຍື່ນຍັນນີ້ແມ່ນປ້ອງກັນປະເທດຫລາຍເກີນໄປ, ແຕ່ວ່າມັນຈະກວດສອບຄົງທີ່
        // ຮັບປະກັນໂດຍ trait.
        // ຖ້າ trait ນີ້ໄດ້ rust, ພາຍໃນ, ພວກເຮົາສາມາດນໍາໃຊ້ debug_assert !;assert_eq!ຈະກວດສອບການທັງຫມົດການປະຕິບັດຜູ້ໃຊ້ Rust ເກີນໄປ.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// ຜົນຕອບແທນ `true` ຖ້າ iterator ແມ່ນເປົ່າ.
    ///
    /// ວິທີການນີ້ມີການປະຕິບັດໃນຕອນຕົ້ນໂດຍໃຊ້ [`ExactSizeIterator::len()`], ດັ່ງນັ້ນທ່ານບໍ່ຈໍາເປັນຕ້ອງປະຕິບັດມັນຕົວທ່ານເອງ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}