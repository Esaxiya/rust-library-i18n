use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// trait ນີ້ມີອິນເທີຜ່ານແດນກັບມາຂັ້ນຕອນຂອງການຢູ່ໃນທໍ່ລະຫວ່າງຜູ້ດັດແປງພາຍໃຕ້ເງື່ອນໄຂທີ່ໄດ້
/// * ແຫລ່ງ iterator `S` ຕົວຂອງມັນເອງປະຕິບັດ `SourceIter<Source = S>`
/// * ມີການປະຕິບັດກະຈາຍຂອງ trait ນີ້ຜູ້ດັດແປງຢູ່ໃນແຜນເທື່ອລະຫວ່າງແຫຼ່ງແລະຜູ້ບໍລິໂພກແຜນການຂອງແຕ່ລະຄົນ.
///
/// ໃນເວລາທີ່ສະແດງຂໍ້ມູນເປັນເຈົ້າຂອງ struct iterator (ທົ່ວໄປເອີ້ນວ່າ `IntoIter`) ຫຼັງຈາກນັ້ນນີ້ສາມາດເປັນປະໂຫຍດສໍາລັບຜູ້ຊ່ຽວຊານປະຕິບັດ [`FromIterator`] ຫຼືຟື້ນອົງປະກອບທີ່ຍັງເຫຼືອຫຼັງຈາກການ iterator ໄດ້ຮັບການຫມົດບາງສ່ວນ.
///
///
/// ໃຫ້ສັງເກດວ່າການປະຕິບັດບໍ່ຈໍາເປັນຕ້ອງມີເພື່ອສະຫນອງການເຂົ້າເຖິງແຫຼ່ງໃນທີ່ສຸດຂອງແຜນ.A ຜູ້ດັດແປງລະດັບປານກາງ stateful eagerly ອາດປະເມີນຜົນສ່ວນຫນຶ່ງຂອງແຜນການດັ່ງກ່າວແລະສະແດງການເກັບຮັກສາພາຍໃນຂອງຕົນເປັນແຫຼ່ງ.
///
/// The trait ແມ່ນບໍ່ປອດໄພເພາະວ່າການສ້າງຕ້ອງປະຕິບັດຄຸນສົມບັດດ້ານຄວາມປອດໄພເພີ່ມເຕີມ.
/// ເບິ່ງ [`as_inner`] ສຳ ລັບລາຍລະອຽດ.
///
/// # Examples
///
/// ດຶງເອົາແຫຼ່ງທີ່ບໍລິໂພກບາງສ່ວນ:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// A ເວທີແຫຼ່ງໃນທໍ່ iterator.
    type Source: Iterator;

    /// ດຶງຂໍ້ມູນທີ່ມາຂອງທໍ່ iterator ໄດ້.
    ///
    /// # Safety
    ///
    /// ການປະຕິບັດຂອງຕ້ອງກັບຄືນກະສານອ້າງອີງບໍ່ແນ່ນອນດຽວກັນສໍາລັບຊີວິດຂອງເຂົາເຈົ້າ, ເວັ້ນເສຍແຕ່ວ່າແທນທີ່ດ້ວຍໂທ.
    /// ແປໄດ້ທຸພຽງແຕ່ອາດຈະທົດແທນການກະສານອ້າງອີງໃນເວລາທີ່ເຂົາເຈົ້າຢຸດເຊົາ iteration ແລະວາງແຜນ iterator ຫຼັງຈາກທີ່ສະແດງຂໍ້ມູນ.
    ///
    /// ນີ້ຫມາຍຄວາມວ່າ iterator ອະແດບເຕີສາມາດອີງໃສ່ແຫຼ່ງຂໍ້ມູນທີ່ບໍ່ມີໄລຍະ iteration ແຕ່ພວກເຂົາເຈົ້າບໍ່ສາມາດອີງໃສ່ໃນການປະຕິບັດການຫຼຸດລົງຂອງເຂົາເຈົ້າ.
    ///
    /// ການປະຕິບັດວິທີການນີ້ອະແດບເຕີຫມາຍຄວາມວ່າສະຫລະເຂົ້າເອກະຊົນເທົ່ານັ້ນທີ່ຈະມາຂອງເຂົາເຈົ້າແລະພຽງແຕ່ສາມາດອີງໃສ່ຮັບປະກັນເຮັດໃຫ້ອີງໃສ່ປະເພດວິທີການຮັບ.
    /// ການຂາດການເຂົ້າເຖິງຈໍາກັດຍັງຮຽກຮ້ອງໃຫ້ມີທີ່ອະແດບເຕີຕ້ອງປະຕິບັດແຫຼ່ງຂອງ API ສາທາລະນະເຖິງແມ່ນວ່າໃນເວລາທີ່ພວກເຂົາເຈົ້າສາມາດເຂົ້າເຖິງພາຍໃນປະເທດຂອງຕົນ.
    ///
    /// ຜູ້ໂທເຂົ້າຕ້ອງຄາດຫວັງວ່າແຫຼ່ງຂໍ້ມູນຈະຢູ່ໃນລັດໃດ ໜຶ່ງ ທີ່ສອດຄ່ອງກັບ API ສາທາລະນະຂອງມັນເນື່ອງຈາກຜູ້ດັດແປງທີ່ນັ່ງຢູ່ລະຫວ່າງມັນແລະແຫຼ່ງຂໍ້ມູນມີການເຂົ້າເຖິງກັນ.
    /// ໂດຍສະເພາະຜູ້ດັດແປງເປັນອາດຈະບໍລິໂພກອົງປະກອບຫຼາຍກ່ວາຄວາມຈໍາເປັນຢ່າງເຂັ້ມງວດ.
    ///
    /// ເປົ້າຫມາຍໂດຍລວມຂອງຄວາມຕ້ອງການເຫຼົ່ານີ້ແມ່ນເພື່ອໃຫ້ຜູ້ບໍລິໂພກຂອງການນໍາໃຊ້ແຜນ
    /// * ສິ່ງໃດກໍ່ຕາມຍັງຄົງຢູ່ໃນແຫລ່ງຫຼັງຈາກທີ່ໄດ້ຢຸດເຊົາ
    /// * ຄວາມຊົງ ຈຳ ທີ່ໄດ້ກາຍມາເປັນການໃຊ້ໂດຍການກ້າວໄປສູ່ການໃຊ້ເຄື່ອງມືທີ່ໃຊ້ໄຟຟ້າ
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// ອະແດບເຕີ iterator ທີ່ສາມາດຜະລິດຜົນຜະລິດເປັນການຕິດພັນ iterator ສາມາດຜະລິດຄ່າ `Result::Ok`.
///
///
/// ຖ້າພົບຂໍ້ຜິດພາດ, ຕົວຊີ້ວັດຢຸດແລະຂໍ້ຜິດພາດຈະຖືກເກັບໄວ້.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// ປະມວນຜົນ iterator ດັ່ງກ່າວເປັນຖ້າຫາກວ່າມັນຜົນຜະລິດເປັນ `T` ແທນທີ່ຈະເປັນ `Result<T, _>`.
/// ຄວາມຜິດພາດໃດໆຈະຢຸດ iterator ພາຍໃນແລະຜົນໄດ້ຮັບໂດຍລວມຈະເປັນຄວາມຜິດພາດ.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}