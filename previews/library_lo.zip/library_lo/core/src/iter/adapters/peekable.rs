use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// ເປັນ iterator ມີ `peek()` ທີ່ຈະກັບຄືນມາເປັນກະສານອ້າງອີງເພີ່ມເຕີມເພື່ອອົງປະກອບຕໍ່ໄປ.
///
///
/// `struct` ນີ້ຖືກສ້າງຂຶ້ນໂດຍວິທີການ [`peekable`] ກ່ຽວກັບ [`Iterator`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// ຈືຂໍ້ມູນການມູນຄ່າໄປສ່ອງເບິ່ງ, ເຖິງແມ່ນວ່າຖ້າຫາກວ່າມັນແມ່ນບໍ່ມີ.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable ຕ້ອງຈື່ຖ້າຫາກວ່າເປັນບໍ່ໄດ້ຮັບການເຫັນໄດ້ໃນວິທີການ `.peek()`.
// ການຮັບປະກັນວ່າ `.peek();.peek();` ຫຼື `.peek();.next();` ພຽງແຕ່ຄວາມກ້າວຫນ້າທີ່ iterator ທີ່ຕິດພັນໄດ້ສູງສຸດຄັ້ງ.
// ສິ່ງນີ້ບໍ່ໄດ້ເຮັດໃຫ້ຕົວເພີ້ມຂື້ນ.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// ຜົນໄດ້ຮັບເປັນການອ້າງອີງເຖິງມູນຄ່າ next() ໂດຍບໍ່ມີຄວາມກ້າວຫນ້າ iterator ໄດ້.
    ///
    /// ເຊັ່ນດຽວກັນກັບ [`next`], ຖ້າຫາກວ່າມີຄຸນຄ່ານັ້ນ, ມັນຖືກຫໍ່ຢູ່ໃນ `Some(T)`.
    /// ແຕ່ຖ້າຫາກວ່າຄວາມລຶກລັບໄດ້ຜ່ານໄປແລ້ວ, `None` ຈະຖືກສົ່ງຄືນ.
    ///
    /// [`next`]: Iterator::next
    ///
    /// ເນື່ອງຈາກວ່າ `peek()` ຄືນຄ່າອ້າງອິງແລະ iterators ຫຼາຍ iterate ໃນໄລຍະເອກະສານ, ບໍ່ມີສາມາດເປັນສະຖານະການເປັນໄປໄດ້ຂອງເຊື້ອຕະກຸນທີ່ຄ່າຕອບແທນເປັນກະສານອ້າງອີງເທົ່ານັ້ນ.
    /// ທ່ານສາມາດເບິ່ງຜົນກະທົບນີ້ໃນຕົວຢ່າງຂ້າງລຸ່ມນີ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ສາມາດເຮັດໃຫ້ພວກເຮົາເບິ່ງເຂົ້າໄປໃນ future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // The iterator ບໍ່ກ້າວຫນ້າເຖິງແມ່ນວ່າຖ້າຫາກວ່າພວກເຮົາ `peek` ຫຼາຍຄັ້ງ
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ຫຼັງຈາກ iterator ໄດ້ຖືກສໍາເລັດ, ສະນັ້ນແມ່ນ `peek()`
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// ຄືນຄ່າອ້າງອິງບໍ່ແນ່ນອນກັບມູນຄ່າ next() ໂດຍບໍ່ມີຄວາມກ້າວຫນ້າ iterator ໄດ້.
    ///
    /// ເຊັ່ນດຽວກັນກັບ [`next`], ຖ້າຫາກວ່າມີຄຸນຄ່ານັ້ນ, ມັນຖືກຫໍ່ຢູ່ໃນ `Some(T)`.
    /// ແຕ່ຖ້າຫາກວ່າຄວາມລຶກລັບໄດ້ຜ່ານໄປແລ້ວ, `None` ຈະຖືກສົ່ງຄືນ.
    ///
    /// ເນື່ອງຈາກວ່າ `peek_mut()` ຄືນຄ່າອ້າງອິງແລະ iterators ຫຼາຍ iterate ໃນໄລຍະເອກະສານ, ບໍ່ມີສາມາດເປັນສະຖານະການເປັນໄປໄດ້ຂອງເຊື້ອຕະກຸນທີ່ຄ່າຕອບແທນເປັນກະສານອ້າງອີງເທົ່ານັ້ນ.
    /// ທ່ານສາມາດເບິ່ງຜົນກະທົບນີ້ໃນຕົວຢ່າງຂ້າງລຸ່ມນີ້.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // ເຊັ່ນດຽວກັນກັບ `peek()`, ພວກເຮົາສາມາດເບິ່ງເຂົ້າໄປໃນ future ໂດຍບໍ່ມີຄວາມກ້າວຫນ້າ iterator ໄດ້.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ເບິ່ງເຂົ້າໄປໃນຕົວປ່ຽນແປງແລະກໍານົດມູນຄ່າທີ່ຢູ່ເບື້ອງຫລັງການອ້າງອີງທີ່ປ່ຽນແປງໄດ້.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // ຄ່າທີ່ພວກເຮົາເອົາໃຈໃສ່ໃນອີກເປັນ iterator ທີ່ຍັງຈະສືບຕໍ່.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// ບໍລິໂພກແລະສົ່ງຄືນຄ່າຕໍ່ໄປຂອງ iterator ນີ້ຖ້າຫາກວ່າເງື່ອນໄຂທີ່ແທ້ຈິງແມ່ນ.
    /// ຖ້າຫາກວ່າຜົນໄດ້ຮັບ `func` `true` ສໍາລັບມູນຄ່າຕໍ່ໄປຂອງ iterator ນີ້, ບໍລິໂພກແລະສົ່ງກັບຄືນ.
    /// ຖ້າບໍ່ດັ່ງນັ້ນ, ກັບຄືນ `None`.
    /// # Examples
    /// ບໍລິໂພກຈໍານວນຫນຶ່ງຖ້າຫາກວ່າມັນເປັນເທົ່າທຽມກັນກັບ 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // ລາຍການທໍາອິດຂອງ iterator ແມ່ນ 0;ບໍລິໂພກມັນ.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // ລາຍການຕໍ່ໄປກັບຄືນແມ່ນໃນປັດຈຸບັນ 1, ສະນັ້ນ `consume` ຈະກັບຄືນ `false`.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` ຊ່ວຍປະຢັດຄ່າຂອງສິນຄ້າຕໍ່ໄປຖ້າມັນບໍ່ເທົ່າກັບ `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// ບໍລິໂພກຈໍານວນໃດນ້ອຍກວ່າ 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // ບໍລິໂພກຈໍານວນທັງຫມົດຕ່ໍາກວ່າ 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // ມູນຄ່າຕໍ່ໄປກັບຄືນຈະເປັນ 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // ນັບຕັ້ງແຕ່ພວກເຮົາເອີ້ນວ່າ `self.next()`, ພວກເຮົາໄດ້ບໍລິໂພກ `self.peeked`.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// ບໍລິໂພກແລະກັບຄືນລາຍການຕໍ່ໄປຖ້າຫາກວ່າມັນແມ່ນເທົ່າທຽມກັນກັບ `expected`.
    /// # Example
    /// ບໍລິໂພກຈໍານວນຫນຶ່ງຖ້າຫາກວ່າມັນເປັນເທົ່າທຽມກັນກັບ 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // ລາຍການທໍາອິດຂອງ iterator ແມ່ນ 0;ບໍລິໂພກມັນ.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // ລາຍການຕໍ່ໄປກັບຄືນແມ່ນໃນປັດຈຸບັນ 1, ສະນັ້ນ `consume` ຈະກັບຄືນ `false`.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` ຊ່ວຍປະຢັດຄ່າຂອງສິນຄ້າຕໍ່ໄປຖ້າມັນບໍ່ເທົ່າກັບ `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // SAFETY: ການສົ່ງຕໍ່ການທໍາງານຂອງທີ່ບໍ່ປອດໄພທີ່ຈະທໍາງານທີ່ບໍ່ປອດໄພທີ່ມີຄວາມຕ້ອງການດຽວກັນ
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}