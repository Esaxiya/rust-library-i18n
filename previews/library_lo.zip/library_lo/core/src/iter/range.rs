use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// ຈຸດປະສົງທີ່ມີແນວຄິດທີ່ເລື່ອງຂອງ successor * * ແລະ *ການດໍາເນີນງານບັນພະບຸລຸດ* a.
///
/// ການ ດຳ ເນີນງານ *ຜູ້ສືບທອດ* ກ້າວໄປສູ່ຄຸນຄ່າທີ່ປຽບທຽບຫຼາຍກວ່າເກົ່າ.
/// ການ ດຳ ເນີນງານ * ຜູ້ ນຳ ກ່ອນຍ້າຍໄປສູ່ຄຸນຄ່າທີ່ສົມທຽບໃສ່ ໜ້ອຍ ກວ່າ.
///
/// # Safety
///
/// trait ນີ້ແມ່ນ `unsafe` ເນື່ອງຈາກວ່າການປະຕິບັດຂອງຕົນຈະຕ້ອງຖືກຕ້ອງສໍາລັບຄວາມປອດໄພຂອງການໃຊ້ວຽກ `unsafe trait TrustedLen`, ແລະຜົນໄດ້ຮັບຂອງການນໍາໃຊ້ trait ນີ້ສາມາດຖ້າບໍ່ດັ່ງນັ້ນຈະໄດ້ຮັບການເຊື່ອຖືຕາມລະຫັດ `unsafe` ຈະຖືກຕ້ອງແລະບັນລຸຫນ້າທີ່ລະບຸໄວ້ໃນ.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// ຜົນຕອບແທນຈໍານວນຂອງຜູ້ສືບທອດ * * ຂັ້ນຕອນທີ່ຈໍາເປັນເພື່ອໃຫ້ໄດ້ຮັບຈາກ `start` ກັບ `end`.
    ///
    /// ຜົນໄດ້ຮັບ `None` ຖ້າຈໍານວນຂອງຂັ້ນຕອນທີ່ຈະ overflow `usize` (ຫຼືສິ້ນສຸດ, ຫຼືຖ້າ `end` ຈະບໍ່ໄດ້ຮັບການບັນລຸໄດ້).
    ///
    ///
    /// # Invariants
    ///
    /// ສຳ ລັບ `a`, `b`, ແລະ `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` ຖ້າແລະພຽງແຕ່ຖ້າຫາກວ່າ `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` ຖ້າແລະຖ້າ `Step::backward_checked(&a, n) == Some(a)` ເທົ່ານັ້ນ
    /// * `steps_between(&a, &b) == Some(n)` ພຽງແຕ່ຖ້າຫາກວ່າ `a <= b`
    ///   * Corollary: `steps_between(&a, &b) == Some(0)` ຖ້າແລະພຽງແຕ່ຖ້າ `a == b`
    ///   * ໃຫ້ສັງເກດວ່າ `a <= b` ບໍ່ _not_ ຫມາຍເຖິງ `steps_between(&a, &b) != None`;
    ///     ນີ້ແມ່ນກໍລະນີໃນເວລາທີ່ມັນຈະຮຽກຮ້ອງໃຫ້ມີຫຼາຍກ່ວາ `usize::MAX` ຂັ້ນຕອນເພື່ອໃຫ້ໄດ້ຮັບກັບ `b`
    /// * `steps_between(&a, &b) == None` ຖ້າຫາກວ່າ `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// ຜົນຕອບແທນຄ່າທີ່ຈະໄດ້ຮັບໂດຍການຜູ້ສືບທອດ * * ຂອງເວລາ `self` `count`.
    ///
    /// ຖ້າຫາກວ່ານີ້ຈະ overflow ລະດັບຂອງຄ່າສະຫນັບສະຫນຸນໂດຍ `Self`, ໃຫ້ຜົນໄດ້ຮັບ `None`.
    ///
    /// # Invariants
    ///
    /// ສໍາລັບ `a` ໃດ, `n` ແລະ `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// ສໍາລັບ `a` ໃດ, `n` ແລະ `m` ທີ່ `n + m` ບໍ່ overflow:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// ສຳ ລັບ `a` ແລະ `n` ໃດໆ:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// ຜົນຕອບແທນຄ່າທີ່ຈະໄດ້ຮັບໂດຍການຜູ້ສືບທອດ * * ຂອງເວລາ `self` `count`.
    ///
    /// ຖ້າຫາກວ່ານີ້ຈະ overflow ລະດັບຂອງຄ່າສະຫນັບສະຫນຸນໂດຍ `Self` ການ, ການທໍາງານນີ້ແມ່ນອະນຸຍາດໃຫ້ panic, ຫໍ່, ຫຼືການອີ່ມຕົວ.
    ///
    /// ພຶດຕິກໍາການແນະນໍາຄືການ panic ໃນເວລາທີ່ຍື່ນຍັນ debug ຖືກເປີດໃຫ້ໃຊ້ງານ, ແລະຫໍ່ຫຼື saturate ຖ້າບໍ່ດັ່ງນັ້ນ.
    ///
    /// ລະຫັດທີ່ບໍ່ປອດໄພບໍ່ຄວນອີງໃສ່ຄວາມຖືກຕ້ອງຂອງພຶດຕິກໍາຫຼັງຈາກ overflow ໄດ້.
    ///
    /// # Invariants
    ///
    /// ສໍາລັບ `a` ໃດ, `n` ແລະ `m`, ບ່ອນທີ່ບໍ່ມີ overflow ເກີດຂຶ້ນ:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// ສໍາລັບ `a` ແລະ `n`, ບ່ອນທີ່ບໍ່ມີ overflow ເກີດຂຶ້ນ:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// ຜົນຕອບແທນຄ່າທີ່ຈະໄດ້ຮັບໂດຍການຜູ້ສືບທອດ * * ຂອງເວລາ `self` `count`.
    ///
    /// # Safety
    ///
    /// ມັນເປັນພຶດຕິກໍາ undefined ຫວ່າງດໍາເນີນການເພື່ອ overflow ລະດັບຂອງຄ່າສະຫນັບສະຫນຸນໂດຍ `Self` ໄດ້.
    /// ຖ້າຫາກວ່າທ່ານບໍ່ສາມາດຮັບປະກັນວ່ານີ້ຈະບໍ່ overflow, ການນໍາໃຊ້ `forward` ຫຼື `forward_checked` ແທນທີ່ຈະ.
    ///
    /// # Invariants
    ///
    /// ສໍາລັບ `a` ໃດ:
    ///
    /// * ຖ້າຫາກວ່າມີຢູ່ `b` ເຊັ່ນວ່າ `b > a`, ມັນປອດໄພທີ່ຈະໂທຫາ `Step::forward_unchecked(a, 1)`
    /// * ຖ້າມີ `b`, `n` ເຊັ່ນ `steps_between(&a, &b) == Some(n)`, ມັນປອດໄພທີ່ຈະໂທຫາ `Step::forward_unchecked(a, m)` ສຳ ລັບ `m <= n` ໃດໆ.
    ///
    ///
    /// ສໍາລັບ `a` ແລະ `n`, ບ່ອນທີ່ບໍ່ມີ overflow ເກີດຂຶ້ນ:
    ///
    /// * `Step::forward_unchecked(a, n)` ເທົ່າກັບ `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// ຜົນຕອບແທນຄ່າທີ່ຈະໄດ້ຮັບໂດຍການບັນພະບຸລຸດ * * ຂອງເວລາ `self` `count`.
    ///
    /// ຖ້າຫາກວ່ານີ້ຈະ overflow ລະດັບຂອງຄ່າສະຫນັບສະຫນຸນໂດຍ `Self`, ໃຫ້ຜົນໄດ້ຮັບ `None`.
    ///
    /// # Invariants
    ///
    /// ສໍາລັບ `a` ໃດ, `n` ແລະ `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// ສຳ ລັບ `a` ແລະ `n` ໃດໆ:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// ຜົນຕອບແທນຄ່າທີ່ຈະໄດ້ຮັບໂດຍການບັນພະບຸລຸດ * * ຂອງເວລາ `self` `count`.
    ///
    /// ຖ້າຫາກວ່ານີ້ຈະ overflow ລະດັບຂອງຄ່າສະຫນັບສະຫນຸນໂດຍ `Self` ການ, ການທໍາງານນີ້ແມ່ນອະນຸຍາດໃຫ້ panic, ຫໍ່, ຫຼືການອີ່ມຕົວ.
    ///
    /// ພຶດຕິກໍາການແນະນໍາຄືການ panic ໃນເວລາທີ່ຍື່ນຍັນ debug ຖືກເປີດໃຫ້ໃຊ້ງານ, ແລະຫໍ່ຫຼື saturate ຖ້າບໍ່ດັ່ງນັ້ນ.
    ///
    /// ລະຫັດທີ່ບໍ່ປອດໄພບໍ່ຄວນອີງໃສ່ຄວາມຖືກຕ້ອງຂອງພຶດຕິກໍາຫຼັງຈາກ overflow ໄດ້.
    ///
    /// # Invariants
    ///
    /// ສໍາລັບ `a` ໃດ, `n` ແລະ `m`, ບ່ອນທີ່ບໍ່ມີ overflow ເກີດຂຶ້ນ:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// ສໍາລັບ `a` ແລະ `n`, ບ່ອນທີ່ບໍ່ມີ overflow ເກີດຂຶ້ນ:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// ຜົນຕອບແທນຄ່າທີ່ຈະໄດ້ຮັບໂດຍການບັນພະບຸລຸດ * * ຂອງເວລາ `self` `count`.
    ///
    /// # Safety
    ///
    /// ມັນເປັນພຶດຕິກໍາ undefined ຫວ່າງດໍາເນີນການເພື່ອ overflow ລະດັບຂອງຄ່າສະຫນັບສະຫນຸນໂດຍ `Self` ໄດ້.
    /// ຖ້າຫາກວ່າທ່ານບໍ່ສາມາດຮັບປະກັນວ່ານີ້ຈະບໍ່ overflow, ການນໍາໃຊ້ `backward` ຫຼື `backward_checked` ແທນທີ່ຈະ.
    ///
    /// # Invariants
    ///
    /// ສໍາລັບ `a` ໃດ:
    ///
    /// * ຖ້າຫາກວ່າມີຢູ່ `b` ເຊັ່ນວ່າ `b < a`, ມັນປອດໄພທີ່ຈະໂທຫາ `Step::backward_unchecked(a, 1)`
    /// * ຖ້າຫາກວ່າມີຢູ່ `b`, `n` ເຊັ່ນວ່າ `steps_between(&b, &a) == Some(n)`, ມັນປອດໄພທີ່ຈະໂທຫາ `Step::backward_unchecked(a, m)` ສໍາລັບ `m <= n` ໃດ.
    ///
    ///
    /// ສໍາລັບ `a` ແລະ `n`, ບ່ອນທີ່ບໍ່ມີ overflow ເກີດຂຶ້ນ:
    ///
    /// * `Step::backward_unchecked(a, n)` ແມ່ນທຽບເທົ່າກັບ `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// ເຫຼົ່ານີ້ແມ່ນຍັງມະຫາພາກທົ່ວໄປເນື່ອງຈາກວ່າຈໍານວນເຕັມ literals ແກ້ໄຂບັນຫາປະເພດທີ່ແຕກຕ່າງກັນ.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // SAFETY: ແປໄດ້ທຸໄດ້ຮັບປະກັນວ່າ `start + n` ບໍ່ overflow.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // SAFETY: ແປໄດ້ທຸໄດ້ຮັບປະກັນວ່າ `start - n` ບໍ່ overflow.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // ໃນການແກ້ບັນຫາເສີມສ້າງ, ຜົນກະທົບຕໍ່ panic ໃນ overflow.
            // ນີ້ຄວນຈະເພີ່ມປະສິດທິພາບຢ່າງສົມບູນໃນການສ້າງລຸ້ນ.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // ເຮັດຫໍ່ແບບເລກເພື່ອໃຫ້ຕົວຢ່າງ `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // ໃນການແກ້ບັນຫາເສີມສ້າງ, ຜົນກະທົບຕໍ່ panic ໃນ overflow.
            // ນີ້ຄວນຈະເພີ່ມປະສິດທິພາບຢ່າງສົມບູນໃນການສ້າງລຸ້ນ.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // ເຮັດຫໍ່ແບບເລກເພື່ອໃຫ້ຕົວຢ່າງ `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // ນີ້ຖືກແກ້ໄຂເທື່ອສຸດ $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // ຖ້າ n ຢູ່ນອກຂອບເຂດ, `unsigned_start + n` ກໍ່ຄືກັນ
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // ຖ້າ n ຢູ່ນອກຂອບເຂດ, `unsigned_start - n` ແມ່ນເກີນໄປ
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // ນີ້ຂື້ນກັບ $i_narrower <=usize
                        //
                        // Casting ກັບ isize ຂະຫຍາຍ width ແຕ່ປົກປັກຮັກສາອາການ.
                        // ການນໍາໃຊ້ wrapping_sub ໃນຊ່ອງ isize ແລະສຽງໂຫວດທັງຫມົດທີ່ຈະ usize ຄໍານວນແຕກຕ່າງກັນທີ່ອາດຈະບໍ່ພໍດີກັບພາຍໃນລະດັບຂອງ isize ໄດ້.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // ຫໍ່ກໍລະນີທີ່ຈັບຄື `Step::forward(-120_i8, 200) == Some(80_i8)`, ເຖິງແມ່ນວ່າ 200 ຢູ່ນອກຂອບເຂດສໍາລັບການ i8.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // ນອກຈາກນັ້ນໄດ້ໄຫຼລົ້ນ
                            }
                        }
                        // ຖ້າ n ຢູ່ນອກຂອບເຂດຂອງຕົວຢ່າງ
                        // u8, ຫຼັງຈາກນັ້ນມັນເປັນຂະຫນາດໃຫຍ່ກ່ວາລະດັບຄວາມທັງຫມົດສໍາລັບ i8 ແມ່ນກ້ວາງດັ່ງນັ້ນ `any_i8 + n` ຈໍາເປັນ overflows i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // ຫໍ່ກໍລະນີທີ່ຈັບຄື `Step::forward(-120_i8, 200) == Some(80_i8)`, ເຖິງແມ່ນວ່າ 200 ຢູ່ນອກຂອບເຂດສໍາລັບການ i8.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // ການຫັກລົບ overflowed
                            }
                        }
                        // ຖ້າ n ຢູ່ນອກຂອບເຂດຂອງຕົວຢ່າງ
                        // u8, ຫຼັງຈາກນັ້ນມັນເປັນຂະຫນາດໃຫຍ່ກ່ວາລະດັບຄວາມທັງຫມົດສໍາລັບ i8 ແມ່ນກ້ວາງດັ່ງນັ້ນ `any_i8 - n` ຈໍາເປັນ overflows i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // ຖ້າຫາກວ່າຄວາມແຕກຕ່າງກັນແມ່ນຂະຫນາດໃຫຍ່ເກີນໄປສໍາລັບຕົວຢ່າງ:
                            // i128, ມັນຍັງຈະເອົາຍົນຂະຫນາດໃຫຍ່ເກີນໄປສໍາລັບ usize ກັບ bits ຫນ້ອຍ.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // SAFETY: res ເປັນ scalar unicode ຖືກຕ້ອງ
            // (ຕ່ໍາກວ່າ 0x110000 ແລະບໍ່ໄດ້ຢູ່ໃນ 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // SAFETY: res ເປັນ scalar unicode ຖືກຕ້ອງ
        // (ຕ່ໍາກວ່າ 0x110000 ແລະບໍ່ໄດ້ຢູ່ໃນ 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SAFETY: ແປໄດ້ທຸໄດ້ຕ້ອງຮັບປະກັນວ່ານີ້ບໍ່ overflow
        // ລະດັບຂອງຄຸນຄ່າ ສຳ ລັບ char.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // SAFETY: ແປໄດ້ທຸໄດ້ຕ້ອງຮັບປະກັນວ່ານີ້ບໍ່ overflow
            // ລະດັບຂອງຄຸນຄ່າ ສຳ ລັບ char.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // SAFETY: ເນື່ອງຈາກວ່າສັນຍາທີ່ຜ່ານມາ, ນີ້ແມ່ນການຮັບປະກັນ
        // ໂດຍໂທໄປຈະເປັນຖ່ານທີ່ຖືກຕ້ອງ.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // SAFETY: ແປໄດ້ທຸໄດ້ຕ້ອງຮັບປະກັນວ່ານີ້ບໍ່ overflow
        // ລະດັບຂອງຄຸນຄ່າ ສຳ ລັບ char.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // SAFETY: ແປໄດ້ທຸໄດ້ຕ້ອງຮັບປະກັນວ່ານີ້ບໍ່ overflow
            // ລະດັບຂອງຄຸນຄ່າ ສຳ ລັບ char.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // SAFETY: ເນື່ອງຈາກວ່າສັນຍາທີ່ຜ່ານມາ, ນີ້ແມ່ນການຮັບປະກັນ
        // ໂດຍໂທໄປຈະເປັນຖ່ານທີ່ຖືກຕ້ອງ.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດກາກ່ອນເງື່ອນໄຂ
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // ຄວາມປອດໄພ: ພຽງແຕ່ກວດກາກ່ອນເງື່ອນໄຂ
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// ແມໂຄເຫລົ່ານີ້ຈະສ້າງ impl `ExactSizeIterator` ສໍາລັບປະເພດລະດັບຕ່າງໆ.
//
// * `ExactSizeIterator::len` ຈໍາເປັນຕ້ອງໄດ້ສະເຫມີໄປກັບການຄືກັນອ້ອຍຕ້ອຍ `usize`, ສະນັ້ນລະດັບທີ່ບໍ່ມີສາມາດຈະຕໍ່ໄປອີກແລ້ວກ່ວາ `usize::MAX`.
//
// * ສໍາລັບຊະນິດຈໍານວນເຕັມໃນ `Range<_>` ແມ່ນກໍລະນີສໍາລັບຊະນິດແຄບກ່ວາຫຼືເປັນກ້ວາງເປັນ `usize` ນີ້.
//   ສໍາລັບຊະນິດຈໍານວນເຕັມໃນ `RangeInclusive<_>` ແມ່ນກໍລະນີສໍາລັບການປະເພດ *ຢ່າງເຂັ້ມງວດແຄບ* ກ່ວາ `usize` ນັບຕັ້ງແຕ່ເຊັ່ນນີ້
//   `(0..=u64::MAX).len()` ຈະເປັນ `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // ເຫຼົ່ານີ້ແມ່ນ incorect ຕໍ່ເຫດຜົນຂ້າງເທິງ, ແຕ່ການ ກຳ ຈັດພວກມັນອາດຈະເປັນການປ່ຽນແປງທີ່ແຕກແຍກຍ້ອນວ່າພວກມັນມີສະຖຽນລະພາບໃນ Rust 1.0.0.
    // ດັ່ງນັ້ນຕົວຢ່າງ:
    // `(0..66_000_u32).len()` ສໍາລັບການຍົກຕົວຢ່າງຈະສັງລວມໂດຍບໍ່ມີຄວາມຜິດພາດຫຼືການເຕືອນໄພກ່ຽວກັບເວທີ 16-bit, ແຕ່ຍັງສືບຕໍ່ໃຫ້ຜົນຜິດພາດ.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // ເຫຼົ່ານີ້ແມ່ນ incorect ຕໍ່ສົມເຫດສົມຜົນຂ້າງເທິງນີ້, ແຕ່ເຂົາເຈົ້າຖອນອອກຈະມີການປ່ຽນແປງພັກຜ່ອນ, ເປັນເຂົາເຈົ້າໄດ້ຖືກສະຖຽນລະພາບໃນ Rust 1.26.0.
    // ດັ່ງນັ້ນຕົວຢ່າງ:
    // `(0..=u16::MAX).len()` ສໍາລັບການຍົກຕົວຢ່າງຈະສັງລວມໂດຍບໍ່ມີຄວາມຜິດພາດຫຼືການເຕືອນໄພກ່ຽວກັບເວທີ 16-bit, ແຕ່ຍັງສືບຕໍ່ໃຫ້ຜົນຜິດພາດ.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດກາກ່ອນເງື່ອນໄຂ
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // ຄວາມປອດໄພ: ພຽງແຕ່ກວດກາກ່ອນເງື່ອນໄຂ
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດກາກ່ອນເງື່ອນໄຂ
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດກາກ່ອນເງື່ອນໄຂ
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດກາກ່ອນເງື່ອນໄຂ
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດກາກ່ອນເງື່ອນໄຂ
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}