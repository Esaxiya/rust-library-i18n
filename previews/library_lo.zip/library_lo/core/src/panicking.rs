//! ສະຫນັບສະຫນູນ Panic ສໍາລັບ libcore
//!
//! ຫໍສະ ໝຸດ ຫຼັກບໍ່ສາມາດ ກຳ ນົດຄວາມຕື່ນຕົກໃຈໄດ້, ແຕ່ມັນກໍ່ປະກາດ * ປະກາດ.
//! ນີ້ຫມາຍຄວາມວ່າຫນ້າທີ່ຢູ່ພາຍໃນຂອງ libcore ໄດ້ຖືກອະນຸຍາດໃຫ້ panic, ແຕ່ວ່າເພື່ອໃຫ້ມີປະໂຫຍດ crate ທີ່ຢູ່ເບື້ອງເທິງຕ້ອງໄດ້ກໍານົດການກະຕຸ້ນໃຫ້ libcore ໃຊ້.
//! ໃນການໂຕ້ຕອບໃນປັດຈຸບັນສໍາລັບການແຕກຕື່ນຕົກໃຈແມ່ນ:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! ຄໍານິຍາມນີ້ອະນຸຍາດໃຫ້ມີການກະທົບກະເທືອນກັບຂໍ້ຄວາມທົ່ວໄປ, ແຕ່ມັນບໍ່ອະນຸຍາດໃຫ້ລົ້ມເຫລວດ້ວຍຄ່າ `Box<Any>`.
//! (`PanicInfo` ພຽງແຕ່ມີ `&(dyn Any + Send)`, ເຊິ່ງພວກເຮົາຕື່ມມູນຄ່າ dummy ໃນ `PanicInfo: : internal_constructor`.) ເຫດຜົນ ສຳ ລັບສິ່ງນີ້ແມ່ນວ່າ libcore ບໍ່ໄດ້ຖືກອະນຸຍາດໃຫ້ຈັດສັນ.
//!
//!
//! ໂມດູນນີ້ປະກອບມີ ໜ້າ ທີ່ອື່ນໆທີ່ ໜ້າ ແປກໃຈ, ແຕ່ມັນເປັນພຽງແຕ່ລາຍການທີ່ ຈຳ ເປັນ ສຳ ລັບນັກຂຽນ.panics ທັງ ໝົດ ແມ່ນມ່ວນຜ່ານ ໜ້າ ທີ່ນີ້.
//! ສັນຍາລັກຕົວຈິງຖືກປະກາດຜ່ານຄຸນລັກສະນະ `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// ການປະຕິບັດທີ່ຕິດພັນຂອງມະຫາພາກ `panic!` macro ເມື່ອບໍ່ມີການໃຊ້ຮູບແບບ.
#[cold]
// ບໍ່ເຄີຍສາຍພາຍໃນເວັ້ນເສຍແຕ່ວ່າ panic_immediate_abort ເພື່ອຫຼີກລ້ຽງການລະຫັດຂອງລະຫັດທີ່ເວັບໄຊ້ໂທໃຫ້ຫຼາຍເທົ່າທີ່ເປັນໄປໄດ້
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ຕ້ອງການໂດຍ codegen ສຳ ລັບ panic ກ່ຽວກັບການລົ້ນນ້ ຳ ມັນແລະ `Assert` ສາຍໄຟ MIR ອື່ນໆ
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ໃຊ້ Arguments::new_v1 ແທນ format_args! ("{}", expr) ເພື່ອຫຼຸດຜ່ອນຂະ ໜາດ ທີ່ມີທ່າແຮງ.
    // format_args!ມະຫາພາກໃຊ້ການສະແດງ str trait ຂອງ str ເພື່ອຂຽນ expr, ເຊິ່ງຮຽກວ່າ Formatter::pad, ເຊິ່ງຕ້ອງຮອງຮັບການຕັດສາຍແລະແຜ່ນຮອງ (ເຖິງແມ່ນວ່າບໍ່ມີການ ນຳ ໃຊ້ຢູ່ບ່ອນນີ້).
    //
    // ການໃຊ້ Arguments::new_v1 ອາດຈະຊ່ວຍໃຫ້ຜູ້ລວບລວມຂໍ້ມູນ Formatter::pad ອອກຈາກຖານຂໍ້ມູນຜົນຜະລິດ, ປະຢັດພະລັງງານເຖິງສອງສາມກິໂລໄບ.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // ຈຳ ເປັນ ສຳ ລັບ panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // ຕ້ອງການໂດຍ codegen ສຳ ລັບ panic ໃນການເຂົ້າເຖິງ OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// ການປະຕິບັດທີ່ຕິດພັນຂອງ macro `panic!` macro ໃນເວລາທີ່ໃຊ້ຮູບແບບ.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ໝາຍ ເຫດ ໜ້າ ທີ່ນີ້ບໍ່ເຄີຍຂ້າມຊາຍແດນ FFI;ມັນເປັນການໂທ Rust-to-Rust ທີ່ໄດ້ຮັບການແກ້ໄຂກັບ ໜ້າ ທີ່ `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // ຄວາມປອດໄພ: `panic_impl` ຖືກ ກຳ ນົດໄວ້ໃນລະຫັດ Rust ທີ່ປອດໄພແລະດັ່ງນັ້ນຈຶ່ງປອດໄພທີ່ຈະໂທຫາໄດ້.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// ຟັງຊັນພາຍໃນ ສຳ ລັບແມັກ `assert_eq!` ແລະ `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}