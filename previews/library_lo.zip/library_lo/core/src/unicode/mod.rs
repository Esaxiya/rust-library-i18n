#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// ສະບັບຂອງ [Unicode](http://www.unicode.org/) ວ່າພາກສ່ວນ Unicode ຂອງ `char` ແລະ `str` ວິທີການແມ່ນອີງໃສ່ການ.
///
/// Unicode ລຸ້ນ ໃໝ່ ຖືກອອກມາເປັນປົກກະຕິແລະຕໍ່ມາທຸກໆວິທີການໃນຫ້ອງສະມຸດມາດຕະຖານທີ່ຂື້ນກັບ Unicode ແມ່ນຖືກປັບປຸງ.
/// ດັ່ງນັ້ນພຶດຕິ ກຳ ຂອງບາງວິທີ `char` ແລະ `str` ແລະມູນຄ່າຂອງການປ່ຽນແປງຄົງທີ່ນີ້ຕາມການເວລາ.
/// ນີ້ແມ່ນ *ບໍ່ພິຈາລະນາ* ຈະເປັນການປ່ຽນແປງ breaking.
///
/// ໂຄງການສະບັບພາສາເລກແມ່ນໄດ້ອະທິບາຍໃນ [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// ສໍາລັບການນໍາໃຊ້ໃນ liballoc ບໍ່ສົ່ງອອກໃນ libstd.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;