#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// A `RawWaker` ອະນຸຍາດໃຫ້ຜູ້ຈັດຕັ້ງປະຕິບັດວຽກງານສ້າງ [`Waker`] ເຊິ່ງສະ ໜອງ ພຶດຕິ ກຳ ການຕື່ນຕົວຕາມໃຈມັກ.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// ມັນປະກອບດ້ວຍຕົວຊີ້ວັດຂໍ້ມູນແລະ [virtual function pointer table (vtable)][vtable] ທີ່ເຮັດໃຫ້ການປະພຶດຂອງ `RawWaker` ປັບແຕ່ງໄດ້.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// ຕົວຊີ້ຂໍ້ມູນ, ເຊິ່ງສາມາດຖືກ ນຳ ໃຊ້ເພື່ອເກັບຂໍ້ມູນທີ່ຕົນເອງມັກຕາມຄວາມຕ້ອງການຂອງຜູ້ປະຕິບັດງານ.
    /// ນີ້ອາດຈະແມ່ນຕົວຢ່າງ
    /// ຕົວຊີ້ທີ່ຖືກລົບລ້າງໄປທີ່ `Arc` ທີ່ກ່ຽວຂ້ອງກັບ ໜ້າ ວຽກ.
    /// ຄ່າຟິວນີ້ຕ້ອງໄດ້ຮັບຜ່ານການປະຕິບັດຫນ້າທັງຫມົດທີ່ເປັນສ່ວນຫນຶ່ງຂອງ vtable ເປັນພາລາມິເຕີທໍາອິດ.
    ///
    data: *const (),
    /// ຕາຕະລາງຕົວຊີ້ຫນ້າ Virtual ທີ່ປັບແຕ່ງການເຮັດວຽກຂອງ Waker ນີ້.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// ສ້າງ `RawWaker` ໃໝ່ ຈາກຕົວຊີ້ `data` ແລະ `vtable`.
    ///
    /// ຕົວຊີ້ `data` ສາມາດຖືກ ນຳ ໃຊ້ເພື່ອເກັບຂໍ້ມູນທີ່ຕົນເອງມັກຕາມຄວາມຕ້ອງການຂອງຜູ້ປະຕິບັດງານ.ນີ້ອາດຈະແມ່ນຕົວຢ່າງ
    /// ຕົວຊີ້ທີ່ຖືກລົບລ້າງໄປທີ່ `Arc` ທີ່ກ່ຽວຂ້ອງກັບ ໜ້າ ວຽກ.
    /// ຄຸນຄ່າຂອງຕົວຊີ້ນີ້ຈະຖືກສົ່ງຜ່ານ ໜ້າ ທີ່ທັງ ໝົດ ທີ່ເປັນສ່ວນ ໜຶ່ງ ຂອງ `vtable` ເຊິ່ງເປັນພາລາມິເຕີ ທຳ ອິດ.
    ///
    /// `vtable` ປັບແຕ່ງການປະພຶດຂອງ `Waker` ທີ່ຖືກສ້າງຂື້ນຈາກ `RawWaker`.
    /// ສຳ ລັບການ ດຳ ເນີນງານແຕ່ລະຢ່າງກ່ຽວກັບ `Waker`, ໜ້າ ທີ່ທີ່ກ່ຽວຂ້ອງໃນ `vtable` ຂອງ `RawWaker` ທີ່ຢູ່ໃຕ້ຈະຖືກເອີ້ນ.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// ຕາຕະລາງຕົວຊີ້ຈຸດທີ່ເຮັດວຽກແບບ (vtable) ທີ່ລະບຸພຶດຕິ ກຳ ຂອງ [`RawWaker`].
///
/// ຕົວຊີ້ໄດ້ສົ່ງໃຫ້ທຸກ ໜ້າ ທີ່ພາຍໃນ vtable ແມ່ນຕົວຊີ້ `data` ຈາກວັດຖຸ [`RawWaker`] ທີ່ປິດລ້ອມ.
///
/// ໜ້າ ທີ່ພາຍໃນໂຄງສ້າງນີ້ແມ່ນມີຈຸດປະສົງພຽງແຕ່ຈະຖືກເອີ້ນໃສ່ຕົວຊີ້ `data` ຂອງວັດຖຸ [`RawWaker`] ທີ່ຖືກສ້າງຂຶ້ນຢ່າງຖືກຕ້ອງຈາກພາຍໃນການປະຕິບັດ [`RawWaker`].
/// ໂທຫາຫນຶ່ງໃນປະຕິບັດຫນ້າທີ່ມີການນໍາໃຊ້ຕົວຊີ້ `data` ອື່ນໆຈະເຮັດໃຫ້ເກີດພຶດຕິກໍາ undefined.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// ຟັງຊັນນີ້ຈະຖືກເອີ້ນວ່າເມື່ອ [`RawWaker`] ຖືກກົດ ໜາຍ, ຕົວຢ່າງເມື່ອ [`Waker`] ທີ່ [`RawWaker`] ຖືກເກັບຮັກສາຈະຖືກກ້ອນຫີນ.
    ///
    /// ການປະຕິບັດຂອງການທໍາງານນີ້ຕ້ອງຮັກສາໄວ້ຊັບພະຍາກອນທັງຫມົດທີ່ຈໍາເປັນສໍາລັບການຍົກຕົວຢ່າງເພີ່ມເຕີມນີ້ຂອງ [`RawWaker`] ແລະວຽກງານທີ່ກ່ຽວຂ້ອງ.
    /// ການໂທຫາ `wake` ໃນ [`RawWaker`] ທີ່ເປັນຜົນມາຈາກການເຮັດວຽກກໍ່ຈະເຮັດໃຫ້ເກີດຄວາມຕື່ນຕົກໃຈກັບວຽກງານດຽວກັນທີ່ຈະເຮັດໃຫ້ຕື່ນຕົວໂດຍ [`RawWaker`] ເດີມ.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// ຟັງຊັນນີ້ຈະຖືກເອີ້ນເມື່ອ `wake` ຖືກເອີ້ນໃນ [`Waker`].
    /// ມັນຕ້ອງຕື່ນວຽກທີ່ກ່ຽວຂ້ອງກັບ [`RawWaker`] ນີ້.
    ///
    /// ການຈັດຕັ້ງປະຕິບັດ ໜ້າ ທີ່ນີ້ຕ້ອງແນ່ໃຈວ່າຈະປ່ອຍຊັບພະຍາກອນໃດໆທີ່ກ່ຽວຂ້ອງກັບຕົວຢ່າງນີ້ຂອງ [`RawWaker`] ແລະວຽກທີ່ກ່ຽວຂ້ອງ.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// ຟັງຊັນນີ້ຈະຖືກເອີ້ນເມື່ອ `wake_by_ref` ຖືກເອີ້ນໃນ [`Waker`].
    /// ມັນຕ້ອງຕື່ນວຽກທີ່ກ່ຽວຂ້ອງກັບ [`RawWaker`] ນີ້.
    ///
    /// ຟັງຊັນນີ້ແມ່ນຄ້າຍຄືກັບ `wake`, ແຕ່ບໍ່ຕ້ອງບໍລິໂພກຕົວຊີ້ຂໍ້ມູນທີ່ສະ ໜອງ ໃຫ້.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// ຟັງຊັນນີ້ຖືກເອີ້ນເມື່ອ [`RawWaker`] ຖືກລຸດລົງ.
    ///
    /// ການຈັດຕັ້ງປະຕິບັດ ໜ້າ ທີ່ນີ້ຕ້ອງແນ່ໃຈວ່າຈະປ່ອຍຊັບພະຍາກອນໃດໆທີ່ກ່ຽວຂ້ອງກັບຕົວຢ່າງນີ້ຂອງ [`RawWaker`] ແລະວຽກທີ່ກ່ຽວຂ້ອງ.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// ສ້າງ `RawWakerVTable` ໃໝ່ ຈາກ `clone`, `wake`, `wake_by_ref`, ແລະ `drop` ທີ່ໄດ້ໃຫ້.
    ///
    /// # `clone`
    ///
    /// ຟັງຊັນນີ້ຈະຖືກເອີ້ນວ່າເມື່ອ [`RawWaker`] ຖືກກົດ ໜາຍ, ຕົວຢ່າງເມື່ອ [`Waker`] ທີ່ [`RawWaker`] ຖືກເກັບຮັກສາຈະຖືກກ້ອນຫີນ.
    ///
    /// ການປະຕິບັດຂອງການທໍາງານນີ້ຕ້ອງຮັກສາໄວ້ຊັບພະຍາກອນທັງຫມົດທີ່ຈໍາເປັນສໍາລັບການຍົກຕົວຢ່າງເພີ່ມເຕີມນີ້ຂອງ [`RawWaker`] ແລະວຽກງານທີ່ກ່ຽວຂ້ອງ.
    /// ການໂທຫາ `wake` ໃນ [`RawWaker`] ທີ່ເປັນຜົນມາຈາກການເຮັດວຽກກໍ່ຈະເຮັດໃຫ້ເກີດຄວາມຕື່ນຕົກໃຈກັບວຽກງານດຽວກັນທີ່ຈະເຮັດໃຫ້ຕື່ນຕົວໂດຍ [`RawWaker`] ເດີມ.
    ///
    /// # `wake`
    ///
    /// ຟັງຊັນນີ້ຈະຖືກເອີ້ນເມື່ອ `wake` ຖືກເອີ້ນໃນ [`Waker`].
    /// ມັນຕ້ອງຕື່ນວຽກທີ່ກ່ຽວຂ້ອງກັບ [`RawWaker`] ນີ້.
    ///
    /// ການຈັດຕັ້ງປະຕິບັດ ໜ້າ ທີ່ນີ້ຕ້ອງແນ່ໃຈວ່າຈະປ່ອຍຊັບພະຍາກອນໃດໆທີ່ກ່ຽວຂ້ອງກັບຕົວຢ່າງນີ້ຂອງ [`RawWaker`] ແລະວຽກທີ່ກ່ຽວຂ້ອງ.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// ຟັງຊັນນີ້ຈະຖືກເອີ້ນເມື່ອ `wake_by_ref` ຖືກເອີ້ນໃນ [`Waker`].
    /// ມັນຕ້ອງຕື່ນວຽກທີ່ກ່ຽວຂ້ອງກັບ [`RawWaker`] ນີ້.
    ///
    /// ຟັງຊັນນີ້ແມ່ນຄ້າຍຄືກັບ `wake`, ແຕ່ບໍ່ຕ້ອງບໍລິໂພກຕົວຊີ້ຂໍ້ມູນທີ່ສະ ໜອງ ໃຫ້.
    ///
    /// # `drop`
    ///
    /// ຟັງຊັນນີ້ຖືກເອີ້ນເມື່ອ [`RawWaker`] ຖືກລຸດລົງ.
    ///
    /// ການຈັດຕັ້ງປະຕິບັດ ໜ້າ ທີ່ນີ້ຕ້ອງແນ່ໃຈວ່າຈະປ່ອຍຊັບພະຍາກອນໃດໆທີ່ກ່ຽວຂ້ອງກັບຕົວຢ່າງນີ້ຂອງ [`RawWaker`] ແລະວຽກທີ່ກ່ຽວຂ້ອງ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` ຂອງວຽກງານທີ່ບໍ່ສະເຫມີພາບ.
///
/// ໃນປະຈຸບັນ, `Context` ພຽງແຕ່ໃຫ້ບໍລິການເພື່ອເຂົ້າເຖິງ `&Waker` ເຊິ່ງສາມາດຖືກ ນຳ ໃຊ້ເພື່ອປຸກວຽກປະຈຸບັນ.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // ຮັບປະກັນວ່າພວກເຮົາ future-proof ຕໍ່ກັບການປ່ຽນແປງທີ່ແຕກຕ່າງກັນໂດຍການບັງຄັບໃຊ້ຕະຫຼອດຊີວິດໃຫ້ບໍ່ສະບາຍ (ອາຍຸການໃຊ້ໃນການໂຕ້ຖຽງແມ່ນກົງກັນຂ້າມໃນຂະນະທີ່ໄລຍະເວລາຂອງການກັບມາແມ່ນມີຄວາມ ໝາຍ).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// ສ້າງ `Context` ໃໝ່ ຈາກ `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// ຜົນໄດ້ຮັບເປັນການອ້າງອີງເຖິງການ `Waker` ສໍາລັບວຽກງານໃນປະຈຸບັນ.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// A `Waker` ແມ່ນຕົວຈັດການ ສຳ ລັບການຕື່ນວຽກໂດຍແຈ້ງໃຫ້ຜູ້ບໍລິຫານຂອງຕົນຮູ້ວ່າພ້ອມແລ້ວທີ່ຈະແລ່ນ.
///
/// ຕົວຈັດການນີ້ encapsulates ຕົວຢ່າງ [`RawWaker`], ເຊິ່ງກໍານົດພຶດຕິກໍາການຕື່ນຕົວຂອງຜູ້ບໍລິຫານ.
///
///
/// ການປະຕິບັດ [`Clone`], [`Send`], ແລະ [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// ຕື່ນວຽກທີ່ກ່ຽວຂ້ອງກັບ `Waker` ນີ້.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // ການໂທຫາການຕື່ນຕົວຕົວຈິງແມ່ນໄດ້ຮັບການມອບ ໝາຍ ຜ່ານການເອີ້ນການເຮັດວຽກແບບເສມືນໃນການຈັດຕັ້ງປະຕິບັດເຊິ່ງຖືກ ກຳ ນົດໂດຍຜູ້ປະຕິບັດ.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // ຢ່າໂທຫາ `drop`-waker ຈະຖືກບໍລິໂພກໂດຍ `wake`.
        crate::mem::forget(self);

        // ຄວາມປອດໄພ: ສິ່ງນີ້ປອດໄພເພາະ `Waker::from_raw` ແມ່ນວິທີດຽວ
        // ເພື່ອເລີ່ມຕົ້ນ `wake` ແລະ `data` ຮຽກຮ້ອງໃຫ້ຜູ້ໃຊ້ຮັບຮູ້ວ່າສັນຍາ `RawWaker` ແມ່ນຖືກຮັບຮອງ.
        //
        unsafe { (wake)(data) };
    }

    /// ຕື່ນວຽກທີ່ກ່ຽວຂ້ອງກັບ `Waker` ນີ້ໂດຍບໍ່ຕ້ອງກິນ `Waker`.
    ///
    /// ນີ້ແມ່ນຄ້າຍຄືກັບ `wake`, ແຕ່ວ່າມັນອາດຈະມີປະສິດທິພາບ ໜ້ອຍ ໜຶ່ງ ໃນກໍລະນີທີ່ມີ `Waker` ທີ່ເປັນເຈົ້າຂອງ.
    /// ວິທີການນີ້ຄວນຈະເປັນທີ່ດີກວ່າທີ່ຈະໂທຫາ `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // ການໂທຫາການຕື່ນຕົວຕົວຈິງແມ່ນໄດ້ຮັບການມອບ ໝາຍ ຜ່ານການເອີ້ນການເຮັດວຽກແບບເສມືນໃນການຈັດຕັ້ງປະຕິບັດເຊິ່ງຖືກ ກຳ ນົດໂດຍຜູ້ປະຕິບັດ.
        //

        // ຄວາມປອດໄພ: ເບິ່ງ `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// ສົ່ງຄືນ `true` ຖ້າ `Waker` ນີ້ແລະ `Waker` ອື່ນກໍ່ໄດ້ເຮັດໃຫ້ຕື່ນຕາຕື່ນໃຈໃນວຽກງານດຽວກັນ.
    ///
    /// ຟັງຊັນນີ້ເຮັດວຽກບົນພື້ນຖານຄວາມພະຍາຍາມທີ່ດີທີ່ສຸດ, ແລະອາດຈະເຮັດໃຫ້ມັນບໍ່ຖືກຕ້ອງເຖິງແມ່ນວ່າເວລາທີ່ Waker ຈະຕື່ນວຽກດຽວກັນກໍ່ຕາມ.
    /// ຢ່າງໃດກໍຕາມ, ຖ້າຫາກວ່າການທໍາງານນີ້ຈະກັບຄືນມາ `true`, ມັນແມ່ນການຮັບປະກັນວ່າ `Waker`s ຈະປຸກຫນ້າວຽກດຽວກັນ.
    ///
    /// ຫນ້າທີ່ນີ້ຖືກນໍາໃຊ້ຕົ້ນຕໍເພື່ອຈຸດປະສົງການເພີ່ມປະສິດທິພາບ.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// ສ້າງ `Waker` ໃຫມ່ຈາກ [`RawWaker`].
    ///
    /// ພຶດຕິ ກຳ ຂອງ `Waker` ທີ່ຖືກສົ່ງຄືນແມ່ນບໍ່ໄດ້ ກຳ ນົດໄວ້ຖ້າສັນຍາທີ່ໄດ້ ກຳ ນົດໄວ້ໃນເອກະສານຂອງ [`RawWaker`] ແລະ [`RawWakerVTable`] ບໍ່ໄດ້ຖືກຮັບຮອງ.
    ///
    /// ສະນັ້ນວິທີການນີ້ແມ່ນບໍ່ປອດໄພ.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // ຄວາມປອດໄພ: ສິ່ງນີ້ປອດໄພເພາະ `Waker::from_raw` ແມ່ນວິທີດຽວ
            // ເພື່ອເລີ່ມຕົ້ນ `clone` ແລະ `data` ຮຽກຮ້ອງໃຫ້ຜູ້ໃຊ້ຮັບຮູ້ວ່າສັນຍາ [`RawWaker`] ແມ່ນຖືກຮັບຮອງ.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // ຄວາມປອດໄພ: ສິ່ງນີ້ປອດໄພເພາະ `Waker::from_raw` ແມ່ນວິທີດຽວ
        // ເພື່ອເລີ່ມຕົ້ນ `drop` ແລະ `data` ຮຽກຮ້ອງໃຫ້ຜູ້ໃຊ້ຮັບຮູ້ວ່າສັນຍາ `RawWaker` ແມ່ນຖືກຮັບຮອງ.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}