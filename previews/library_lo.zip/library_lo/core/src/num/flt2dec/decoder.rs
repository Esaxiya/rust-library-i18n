//! ຖອດລະຫັດມູນຄ່າທີ່ລອຍຕົວເຂົ້າໄປໃນແຕ່ລະພາກສ່ວນແລະລະດັບຄວາມຜິດພາດ.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// ມູນຄ່າ ສຳ ເລັດຮູບທີ່ບໍ່ໄດ້ລົງນາມເປັນລາຍເຊັນ, ເຊັ່ນວ່າ:
///
/// - ມູນຄ່າເດີມເທົ່າກັບ `mant * 2^exp`.
///
/// - ຕົວເລກໃດໆຈາກ `(mant - minus)*2^exp` ເຖິງ `(mant + plus)* 2^exp` ຈະລວບລວມມູນຄ່າເດີມ.
/// ຊ່ວງແມ່ນລວມເທົ່ານັ້ນເມື່ອ `inclusive` ແມ່ນ `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// ການຂະຫຍາຍຕົວ mantissa.
    pub mant: u64,
    /// ລະດັບຄວາມຜິດພາດຕ່ໍາ.
    pub minus: u64,
    /// ຊ່ວງຄວາມຜິດພາດສູງ.
    pub plus: u64,
    /// ເລກ ກຳ ລັງທີ່ແບ່ງປັນຢູ່ໃນຖານ 2.
    pub exp: i16,
    /// ຖືກຕ້ອງເມື່ອລະດັບຄວາມຜິດພາດລວມ.
    ///
    /// ໃນ IEEE 754, ນີ້ແມ່ນຄວາມຈິງໃນເວລາທີ່ mantissa ຕົ້ນສະບັບ.
    pub inclusive: bool,
}

/// ມູນຄ່າທີ່ບໍ່ໄດ້ເຊັນ.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// ຄວາມບໍ່ມີຕົວຕົນ, ບໍ່ວ່າຈະເປັນດ້ານບວກຫລືລົບ.
    Infinite,
    /// ສູນ, ທັງທາງບວກຫລືລົບ.
    Zero,
    /// ຈຳ ນວນ ຈຳ ກັດທີ່ມີທົ່ງນາທີ່ຖຶກລະຫັດຕື່ມອີກ.
    Finite(Decoded),
}

/// ປະເພດຈຸດເລື່ອນເຊິ່ງສາມາດເປັນ `ຖອດລະຫັດ`.
pub trait DecodableFloat: RawFloat + Copy {
    /// ມູນຄ່າປົກກະຕິຕ່ ຳ ສຸດໃນທາງບວກ.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// ສົ່ງເຄື່ອງ ໝາຍ ຄືນ (ເປັນຄວາມຈິງເມື່ອລົບ) ແລະມູນຄ່າ `FullDecoded` ຈາກ ໝາຍ ເລກຈຸດເລື່ອນ.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // ປະເທດເພື່ອນບ້ານ: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode ປົກປັກຮັກສາເລກ ກຳ ລັງຢູ່ສະ ເໝີ, ສະນັ້ນ mantissa ຈຶ່ງຖືກຂະ ໜາດ ສຳ ລັບຍ່ອຍຍ່ອຍ.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // ປະເທດເພື່ອນບ້ານ: (ຫຼາຍທີ່ສຸດ, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // ບ່ອນທີ່ maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // ປະເທດເພື່ອນບ້ານ: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}