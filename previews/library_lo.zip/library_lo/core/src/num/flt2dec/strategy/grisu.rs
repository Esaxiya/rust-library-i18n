//! ການປັບຕົວ Rust ຂອງສູດ Grisu3 ທີ່ອະທິບາຍໄວ້ໃນ "ການພິມ ຈຳ ນວນຕົວເລກເລື່ອນລອຍຢ່າງໄວວາແລະຖືກຕ້ອງກັບຕົວເລກ" [^ 1].
//! ມັນໃຊ້ປະມານ 1KB ຂອງຕາຕະລາງ precomputed, ແລະໃນທາງກັບກັນ, ມັນໄວຫຼາຍສໍາລັບວັດສະດຸປ້ອນສ່ວນໃຫຍ່.
//!
//! [^1]: Florian Loitsch.2010. ການພິມ ຈຳ ນວນຈຸດລອຍ ນຳ ້ຢ່າງໄວວາແລະ
//!   ຢ່າງຖືກຕ້ອງກັບເລກເຕັມ.SIGPLAN ບໍ່.45, 6 (ເດືອນມິຖຸນາ 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// ເບິ່ງ ຄຳ ເຫັນໃນ `format_shortest_opt` ສຳ ລັບເຫດຜົນ.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// ເມື່ອ `x > 0`, ສົ່ງຄືນ `(k, 10^k)` ເຊັ່ນ `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// ການປະຕິບັດຮູບແບບທີ່ສັ້ນທີ່ສຸດ ສຳ ລັບ Grisu.
///
/// ມັນຈະສົ່ງຄືນ `None` ເມື່ອມັນຈະກັບຄືນຕົວແທນທີ່ບໍ່ມີປະໂຫຍດຖ້າບໍ່ດັ່ງນັ້ນ.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // ພວກເຮົາຕ້ອງການຢ່າງ ໜ້ອຍ ສາມສ່ວນຂອງຄວາມແມ່ນຍໍາເພີ່ມເຕີມ

    // ເລີ່ມຕົ້ນດ້ວຍຄ່າປົກກະຕິກັບຕົວແປທີ່ໃຊ້ຮ່ວມກັນ
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // ຊອກຫາ `cached = 10^minusk` ແບບໃດທີ່ `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // ນັບຕັ້ງແຕ່ `plus` ເປັນປົກກະຕິ, ນີ້ຫມາຍຄວາມວ່າ `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // ໃຫ້ທາງເລືອກຂອງພວກເຮົາຂອງ `ALPHA` ແລະ `GAMMA`, ນີ້ເຮັດໃຫ້ `plus * cached` ເປັນ `[4, 2^32)`.
    //
    // ມັນແມ່ນຄວາມປາຖະ ໜາ ທີ່ຈະເພີ່ມ `GAMMA - ALPHA` ໃຫ້ສູງສຸດ, ດັ່ງນັ້ນພວກເຮົາບໍ່ ຈຳ ເປັນຕ້ອງມີ ອຳ ນາດໃນຖານຄວາມ ຈຳ 10, ແຕ່ວ່າມີບາງຂໍ້ພິຈາລະນາ:
    //
    //
    // 1. ພວກເຮົາຕ້ອງການທີ່ຈະຮັກສາ `floor(plus * cached)` ພາຍໃນ `u32` ເນື່ອງຈາກມັນຕ້ອງການການແບ່ງຈ່າຍທີ່ມີຄ່າໃຊ້ຈ່າຍ.
    //    (ນີ້ບໍ່ແມ່ນສິ່ງທີ່ຫລີກລ້ຽງໄດ້ແທ້ໆ, ສ່ວນທີ່ເຫຼືອແມ່ນ ຈຳ ເປັນ ສຳ ລັບການປະເມີນຄວາມຖືກຕ້ອງ.)
    // 2.
    // ສ່ວນທີ່ເຫຼືອຂອງ `floor(plus * cached)` ຊ້ ຳ ພັດຖືກຄູນດ້ວຍ 10, ແລະມັນກໍ່ບໍ່ຄວນລົ້ນ.
    //
    // ຄັ້ງທໍາອິດໃຫ້ `64 + GAMMA <= 32`, ໃນຂະນະທີ່ສອງໃຫ້ `10 * 2^-ALPHA <= 2^64`;
    // -60 ແລະ -32 ແມ່ນລະດັບຄວາມສູງສຸດທີ່ມີຂໍ້ ຈຳ ກັດນີ້, ແລະ V8 ກໍ່ໃຊ້ມັນ.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // ຂະ ໜາດ fps.ນີ້ເຮັດໃຫ້ຄວາມຜິດພາດສູງສຸດຂອງ 1 ulp (ພິສູດຈາກ Theorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-ລະດັບຕົວຈິງຂອງເຄື່ອງລົບ
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // ຂ້າງເທິງ `minus`, `v` ແລະ `plus` ແມ່ນ *ປະມານ* ປະລິມານ * (ຂໍ້ຜິດພາດ <1 ulp).
    // ຍ້ອນວ່າພວກເຮົາບໍ່ຮູ້ວ່າຄວາມຜິດພາດນັ້ນເປັນບວກຫຼືລົບ, ພວກເຮົາໃຊ້ສອງປະມານທີ່ມີຂອບເຂດເທົ່າທຽມກັນແລະມີຂໍ້ຜິດພາດສູງສຸດຂອງ 2 ບາດ.
    //
    // "unsafe region" ແມ່ນໄລຍະຫ່າງແບບເສລີທີ່ພວກເຮົາສ້າງຂື້ນມາໃນເບື້ອງຕົ້ນ.
    // "safe region" ແມ່ນໄລຍະອະນຸລັກທີ່ພວກເຮົາຍອມຮັບເອົາເທົ່ານັ້ນ.
    // ພວກເຮົາເລີ່ມຕົ້ນດ້ວຍ ຄຳ ສັ່ງທີ່ຖືກຕ້ອງພາຍໃນຂົງເຂດທີ່ບໍ່ປອດໄພ, ແລະພະຍາຍາມຊອກຫາຊ່ອງທາງທີ່ໃກ້ທີ່ສຸດກັບ `v` ເຊິ່ງກໍ່ແມ່ນຢູ່ໃນຂົງເຂດທີ່ປອດໄພ.
    // ຖ້າພວກເຮົາເຮັດບໍ່ໄດ້, ພວກເຮົາຈະຍອມແພ້.
    //
    let plus1 = plus.f + 1;
    // ໃຫ້ plus0 = plus.f, 1;//ສຳ ລັບ ຄຳ ອະທິບາຍເທົ່ານັ້ນໃຫ້ minus0 = minus.f + 1;//ພຽງແຕ່ ສຳ ລັບ ຄຳ ອະທິບາຍ
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // ເລກອະທິບາຍຮ່ວມກັນ

    // ແບ່ງ `plus1` ອອກເປັນສ່ວນປະກອບແລະສ່ວນ ໜຶ່ງ.
    // ສ່ວນປະກອບທີ່ຖືກຮັບປະກັນໃຫ້ ເໝາະ ສົມກັບ u32, ເນື່ອງຈາກວ່າພະລັງງານຈາກຖານຄວາມ ຈຳ ຮັບປະກັນ `plus < 2^32` ແລະ `plus.f` ປົກກະຕິແມ່ນ ໜ້ອຍ ກວ່າ `2^64 - 2^4` ເນື່ອງຈາກຄວາມຕ້ອງການຄວາມແມ່ນ ຍຳ.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // ຄິດໄລ່ `10^max_kappa` ທີ່ໃຫຍ່ທີ່ສຸດບໍ່ເກີນ `plus1` (ດັ່ງນັ້ນ `plus1 < 10^(max_kappa+1)`).
    // ນີ້ແມ່ນຂອບເຂດເທິງຂອງ `kappa` ຂ້າງລຸ່ມນີ້.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // ທິດສະດີ 6.2: ຖ້າ `k` ແມ່ນເລກເຕັມໃຫຍ່ທີ່ສຸດ
    // `0 <= y mod 10^k <= y - x`,              ຫຼັງຈາກນັ້ນ `V = floor(y / 10^k) * 10^k` ແມ່ນຢູ່ໃນ `[x, y]` ແລະ ໜຶ່ງ ໃນຕົວແທນທີ່ສັ້ນທີ່ສຸດ (ມີ ຈຳ ນວນຕົວເລກທີ່ ສຳ ຄັນທີ່ສຸດ) ໃນຂອບເຂດນັ້ນ.
    //
    //
    // ຊອກຫາຄວາມຍາວຂອງຕົວເລກ `kappa` ລະຫວ່າງ `(minus1, plus1)` ຕໍ່ທິດສະດີ 6.2.
    // Theorem 6.2 ສາມາດຖືກຮັບຮອງເອົາເພື່ອຍົກເວັ້ນ `x` ໂດຍຮຽກຮ້ອງໃຫ້ `y mod 10^k < y - x` ແທນ.
    // (ຕົວຢ່າງ: `x` =32000, `y` =32777; `kappa` =2 ນັບຕັ້ງແຕ່ `y mod 10 ^ 3=777 <y, x=777`.) ສູດການຄິດໄລ່ແມ່ນຂື້ນກັບໄລຍະການຢັ້ງຢືນຕໍ່ມາເພື່ອຍົກເວັ້ນ `y`.
    //
    let delta1 = plus1 - minus1;
    // let delta1int=(delta1>> e) ເປັນປະໂຫຍດ;//ພຽງແຕ່ ສຳ ລັບ ຄຳ ອະທິບາຍ
    let delta1frac = delta1 & ((1 << e) - 1);

    // ສະ ເໜີ ຊິ້ນສ່ວນສ່ວນລວມ, ໃນຂະນະທີ່ກວດສອບຄວາມຖືກຕ້ອງໃນແຕ່ລະບາດກ້າວ.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // ຕົວເລກຍັງບໍ່ທັນໄດ້ຖືກສະແດງອອກ
    loop {
        // ພວກເຮົາມີຢ່າງ ໜ້ອຍ ໜຶ່ງ ຕົວເລກເພື່ອສະແດງ, ຄືກັບ `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (ມັນເປັນດັ່ງຕໍ່ໄປນີ້ວ່າ `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // ແບ່ງ `remainder` ໂດຍ `10^kappa`.ທັງສອງຖືກຂະຫຍາຍໂດຍ `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; ພວກເຮົາໄດ້ພົບເຫັນ `kappa` ທີ່ຖືກຕ້ອງ.
            let ten_kappa = (ten_kappa as u64) << e; // ຂະ ໜາດ 10 ^ kappa ກັບຄືນໄປບ່ອນໂຕເລກທີ່ໃຊ້ຮ່ວມກັນ
            return round_and_weed(
                // ຄວາມປອດໄພ: ພວກເຮົາເລີ່ມຕົ້ນຄວາມຊົງ ຈຳ ຂ້າງເທິງນັ້ນ.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // ແຍກວົງຈອນໃນເວລາທີ່ພວກເຮົາໄດ້ສະແດງຕົວເລກທັງ ໝົດ.
        // ຕົວເລກທີ່ແນ່ນອນແມ່ນ `max_kappa + 1` ເປັນ `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // ຟື້ນຟູການບຸກລຸກ
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // ສະ ເໜີ ຊິ້ນສ່ວນສ່ວນ, ໃນຂະນະທີ່ກວດສອບຄວາມຖືກຕ້ອງໃນແຕ່ລະບາດກ້າວ.
    // ເວລານີ້ພວກເຮົາອີງໃສ່ການຄູນຫຼາຍໆເທື່ອ, ຍ້ອນວ່າການແບ່ງແຍກຈະສູນເສຍຄວາມແມ່ນຍໍາ.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // ຕົວເລກຕໍ່ໄປຄວນຈະມີຄວາມ ສຳ ຄັນດັ່ງທີ່ພວກເຮົາໄດ້ທົດສອບວ່າກ່ອນທີ່ຈະ ທຳ ລາຍທະຫານ, ບ່ອນທີ່ `m = max_kappa + 1` (#ຕົວເລກໃນສ່ວນທີ່ບໍ່ ສຳ ຄັນ):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // ຈະບໍ່ລົ້ນ, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // ແບ່ງ `remainder` ໂດຍ `10^kappa`.
        // ທັງສອງໄດ້ຖືກຂະຫຍາຍໂດຍ `2^e / 10^kappa`, ດັ່ງນັ້ນສຸດທ້າຍແມ່ນສະແດງຢູ່ທີ່ນີ້.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // ສ່ວນແບ່ງທີ່ສົມບູນແບບ
            return round_and_weed(
                // ຄວາມປອດໄພ: ພວກເຮົາເລີ່ມຕົ້ນຄວາມຊົງ ຈຳ ຂ້າງເທິງນັ້ນ.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // ຟື້ນຟູການບຸກລຸກ
        kappa -= 1;
        remainder = r;
    }

    // ພວກເຮົາໄດ້ສ້າງຕົວເລກທີ່ ສຳ ຄັນທັງ ໝົດ ຂອງ `plus1`, ແຕ່ບໍ່ແນ່ໃຈວ່າມັນແມ່ນຕົວເລກທີ່ດີທີ່ສຸດ.
    // ຕົວຢ່າງ: ຖ້າ `minus1` ແມ່ນ 3.14153 ... ແລະ `plus1` ແມ່ນ 3.14158 ... , ມີຕົວແທນສັ້ນທີ່ສຸດ 5 ຕົວຈາກ 3.14154 ຫາ 3.14158 ແຕ່ພວກເຮົາມີພຽງຜູ້ທີ່ໃຫຍ່ທີ່ສຸດເທົ່ານັ້ນ.
    // ພວກເຮົາຕ້ອງໄດ້ຫຼຸດລົງຕົວເລກສຸດທ້າຍຢ່າງຕໍ່ເນື່ອງແລະກວດເບິ່ງວ່ານີ້ແມ່ນການຂຽນທີ່ດີທີ່ສຸດ.
    // ມີຜູ້ສະ ໝັກ ຫຼາຍທີ່ສຸດ 9 ຄົນ (ແຕ່ 1 ເຖິງ ..9), ສະນັ້ນນີ້ແມ່ນໄວພໍສົມຄວນ.(ໄລຍະ "rounding")
    //
    // ໜ້າ ທີ່ກວດສອບວ່າ "optimal" repr ນີ້ຢູ່ໃນຂອບເຂດຕົວຈິງແລະມັນກໍ່ເປັນໄປໄດ້ວ່າ "second-to-optimal" repr ສາມາດເຮັດໄດ້ດີທີ່ສຸດເນື່ອງຈາກຂໍ້ຜິດພາດຮອບ.
    // ໃນທັງສອງກໍລະນີນີ້ຈະສົ່ງຄືນ `None`.
    // (ໄລຍະ "weeding")
    //
    // ການໂຕ້ຖຽງທັງ ໝົດ ຢູ່ທີ່ນີ້ແມ່ນໄດ້ຂະຫຍາຍໂດຍ `k` (ແຕ່ສົມຄວນ) ຂອງມູນຄ່າທົ່ວໄປ, ດັ່ງນັ້ນ:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (ແລະຍັງ, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (ແລະຍັງ, `threshold > plus1v` ຈາກການບຸກລຸກກ່ອນ)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // ຜະລິດສອງປະມານໃຫ້ແກ່ `v` (ຕົວຈິງ `plus1 - v`) ພາຍໃນ 1.5 ບາດແຜ.
        // ການເປັນຕົວແທນທີ່ໄດ້ຮັບຄວນຈະເປັນຕົວແທນທີ່ໃກ້ທີ່ສຸດຂອງທັງສອງ.
        //
        // ໃນທີ່ນີ້ `plus1 - v` ຖືກ ນຳ ໃຊ້ນັບຕັ້ງແຕ່ການຄິດໄລ່ແມ່ນເຮັດກັບ `plus1` ເພື່ອຫລີກລ້ຽງ overflow/underflow (ເພາະສະນັ້ນຊື່ທີ່ຖືກປ່ຽນແປງ).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // ຫຼຸດລົງຕົວເລກສຸດທ້າຍແລະຢຸດຢູ່ທີ່ຕົວແທນທີ່ໃກ້ທີ່ສຸດກັບ `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // ພວກເຮົາເຮັດວຽກຮ່ວມກັບຕົວເລກປະມານ `w(n)`, ເຊິ່ງໃນເບື້ອງຕົ້ນເທົ່າກັບ `plus1 - plus1 % 10^kappa`.ຫຼັງຈາກແລ່ນຕົວເລກ loop `n` ເທື່ອແລ້ວ, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // ພວກເຮົາຕັ້ງຄ່າ `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (ດັ່ງນັ້ນ `ຍັງເຫຼືອ= plus1w(0)`) ເພື່ອງ່າຍໃນການກວດສອບ.
            // ສັງເກດວ່າ `plus1w(n)` ແມ່ນເພີ່ມຂື້ນເລື້ອຍໆ.
            //
            // ພວກເຮົາມີເງື່ອນໄຂສາມຢ່າງເພື່ອຢຸດຕິ.ໃດໆຂອງພວກມັນຈະເຮັດໃຫ້ວົງຈອນບໍ່ສາມາດ ດຳ ເນີນການໄດ້, ແຕ່ພວກເຮົາຈະມີຕົວແທນທີ່ຖືກຕ້ອງຢ່າງ ໜ້ອຍ ໜຶ່ງ ຢ່າງທີ່ຮູ້ວ່າຈະຢູ່ໃກ້ກັບ `v + 1 ulp` ຢ່າງໃດກໍ່ຕາມ.
            // ພວກເຮົາຈະ ໝາຍ ເຖິງພວກມັນເປັນ TC1 ຜ່ານ TC3 ສຳ ລັບຄວາມແຕກຕ່າງ.
            //
            // TC1: `w(n) <= v + 1 ulp`, ເຊັ່ນ, ນີ້ແມ່ນ repr ສຸດທ້າຍທີ່ສາມາດເປັນຄົນທີ່ໃກ້ທີ່ສຸດ.
            // ນີ້ເທົ່າກັບ `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // ສົມທົບກັບ TC2 (ເຊິ່ງກວດເບິ່ງວ່າ `w(n+1)` is valid), ນີ້ຈະປ້ອງກັນບໍ່ໃຫ້ເກີດຄວາມລົ້ນໃນການຄິດໄລ່ຂອງ `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, ໝາຍ ຄວາມວ່າ, ການຕໍ່ຄັ້ງຕໍ່ໄປບໍ່ໄດ້ ໝາຍ ເຖິງ `v`.
            // ນີ້ເທົ່າກັບ `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // ເບື້ອງຊ້າຍສາມາດລົ້ນ, ແຕ່ພວກເຮົາຮູ້ `threshold > plus1v`, ສະນັ້ນຖ້າ TC1 ແມ່ນບໍ່ຖືກຕ້ອງ, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` ແລະພວກເຮົາສາມາດທົດສອບໄດ້ຢ່າງປອດໄພຖ້າ `threshold - plus1w(n) < 10^kappa` ແທນ.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, ຕົວຢ່າງ, ການຕໍ່ຄັ້ງຕໍ່ໄປແມ່ນ
            // ບໍ່ໄດ້ໃກ້ຊິດກັບ `v + 1 ulp` ຫຼາຍກ່ວາ repr ປະຈຸບັນ.
            // ໃຫ້ `z(n) = plus1v_up - plus1w(n)`, ນີ້ຈະກາຍເປັນ `abs(z(n)) <= abs(z(n+1))`.ສົມມຸດວ່າ TC1 ແມ່ນບໍ່ຖືກຕ້ອງ, ພວກເຮົາມີ `z(n) > 0`.ພວກເຮົາມີສອງກໍລະນີພິຈາລະນາ:
            //
            // - ເມື່ອ `z(n+1) >= 0`: TC3 ກາຍເປັນ `z(n) <= z(n+1)`.
            // ຍ້ອນວ່າ `plus1w(n)` ກຳ ລັງເພີ່ມຂື້ນ, `z(n)` ຄວນຈະຫຼຸດລົງແລະນີ້ແມ່ນຄວາມຈິງທີ່ບໍ່ຖືກຕ້ອງ.
            // - ເມື່ອ `z(n+1) < 0`:
            //   - TC3a: ເງື່ອນໄຂເບື້ອງຕົ້ນແມ່ນ `plus1v_up < plus1w(n) + 10^kappa`.ສົມມຸດວ່າ TC2 ແມ່ນບໍ່ຖືກຕ້ອງ, `threshold >= plus1w(n) + 10^kappa` ສະນັ້ນມັນບໍ່ສາມາດລົ້ນໄດ້.
            //   - TC3b: TC3 ກາຍເປັນ `z(n) <= -z(n+1)`, ເຊັ່ນ, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 negated ເຮັດໃຫ້ `plus1v_up > plus1w(n)`, ສະນັ້ນມັນບໍ່ສາມາດ overflow ຫຼື underflow ເມື່ອສົມທົບກັບ TC3a.
            //
            // ດັ່ງນັ້ນ, ພວກເຮົາຄວນຢຸດເມື່ອ `TC1 || TC2 || (TC3a && TC3b)`.ຕໍ່ໄປນີ້ແມ່ນເທົ່າກັບກັນຂອງມັນ, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // repr ທີ່ສັ້ນທີ່ສຸດບໍ່ສາມາດສິ້ນສຸດດ້ວຍ `0`
                plus1w += ten_kappa;
            }
        }

        // ກວດເບິ່ງວ່າຕົວແທນນີ້ຍັງເປັນຕົວແທນທີ່ໃກ້ທີ່ສຸດກັບ `v - 1 ulp`.
        //
        // ນີ້ແມ່ນຄືກັນກັບເງື່ອນໄຂການສິ້ນສຸດຂອງ `v + 1 ulp`, ໂດຍ `plus1v_up` ທັງ ໝົດ ຖືກປ່ຽນແທນໂດຍ `plus1v_down` ແທນ.
        // ການວິເຄາະເກີນ ກຳ ນົດ.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // ຕອນນີ້ພວກເຮົາມີຕົວແທນທີ່ໃກ້ທີ່ສຸດກັບ `v` ລະຫວ່າງ `plus1` ແລະ `minus1`.
        // ນີ້ແມ່ນເສລີພາບເກີນໄປ, ເຖິງແມ່ນວ່າ, ດັ່ງນັ້ນພວກເຮົາປະຕິເສດ `w(n)` ໃດໆທີ່ບໍ່ຢູ່ລະຫວ່າງ `plus0` ແລະ `minus0`, ເຊັ່ນ, `plus1 - plus1w(n) <= minus0` ຫຼື `plus1 - plus1w(n) >= plus0`.
        // ພວກເຮົາ ນຳ ໃຊ້ຂໍ້ເທັດຈິງທີ່ `threshold = plus1 - minus1` ແລະ `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// ການປະຕິບັດຮູບແບບທີ່ສັ້ນທີ່ສຸດ ສຳ ລັບ Grisu ກັບ Dragon fallback.
///
/// ສິ່ງນີ້ຄວນໃຊ້ ສຳ ລັບກໍລະນີຫຼາຍທີ່ສຸດ.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // ຄວາມປອດໄພ: ຜູ້ກວດສອບການກູ້ຢືມເງິນແມ່ນບໍ່ສະຫຼາດພໍທີ່ຈະໃຫ້ພວກເຮົາໃຊ້ `buf`
    // ໃນ branch ຄັ້ງທີສອງ, ສະນັ້ນພວກເຮົາຊັກ ນຳ ຕະຫຼອດຊີວິດ.
    // ແຕ່ພວກເຮົາໃຊ້ `buf` ຄືນ ໃໝ່ ເທົ່ານັ້ນຖ້າ `format_shortest_opt` ກັບຄືນ `None` ສະນັ້ນມັນບໍ່ເປັນຫຍັງ.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// ການປະຕິບັດຮູບແບບທີ່ແນ່ນອນແລະຄົງທີ່ ສຳ ລັບ Grisu.
///
/// ມັນຈະສົ່ງຄືນ `None` ເມື່ອມັນຈະກັບຄືນຕົວແທນທີ່ບໍ່ມີປະໂຫຍດຖ້າບໍ່ດັ່ງນັ້ນ.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // ພວກເຮົາຕ້ອງການຢ່າງ ໜ້ອຍ ສາມສ່ວນຂອງຄວາມແມ່ນຍໍາເພີ່ມເຕີມ
    assert!(!buf.is_empty());

    // ປົກກະຕິແລະຂະ ໜາດ `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // ແບ່ງ `v` ອອກເປັນສ່ວນປະກອບແລະສ່ວນ ໜຶ່ງ.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // ທັງ `v` ເກົ່າແລະ `v` ເກົ່າ (ທີ່ຖືກປັບຂະ ໜາດ ໂດຍ `10^-k`) ມີຂໍ້ຜິດພາດຂອງ <1 ulp (Theorem 5.1).
    // ຍ້ອນວ່າພວກເຮົາບໍ່ຮູ້ວ່າຂໍ້ຜິດພາດໃນແງ່ບວກຫລືລົບ, ພວກເຮົາໃຊ້ສອງຈຸດປະມານທີ່ເທົ່າກັນແລະມີຂໍ້ຜິດພາດສູງສຸດ 2 ບາດ (ຄືກັນກັບກໍລະນີທີ່ສັ້ນທີ່ສຸດ).
    //
    //
    // ເປົ້າ ໝາຍ ແມ່ນເພື່ອຊອກຫາຊຸດຕົວເລກທີ່ມີຮູບກົມມົນທີ່ຄ້າຍຄືກັນກັບທັງ `v - 1 ulp` ແລະ `v + 1 ulp`, ເພື່ອໃຫ້ພວກເຮົາມີຄວາມ ໝັ້ນ ໃຈສູງສຸດ.
    // ຖ້າສິ່ງນີ້ເປັນໄປບໍ່ໄດ້, ພວກເຮົາບໍ່ຮູ້ວ່າອັນໃດແມ່ນຜົນຜະລິດທີ່ຖືກຕ້ອງ ສຳ ລັບ `v`, ສະນັ້ນພວກເຮົາຍອມແພ້ແລະຖອຍຫລັງ.
    //
    // `err` ຖືກ ກຳ ນົດເປັນ `1 ulp * 2^e` ຢູ່ທີ່ນີ້ (ດຽວກັນກັບ ulp ໃນ `vfrac`), ແລະພວກເຮົາຈະປັບຂະ ໜາດ ມັນທຸກຄັ້ງທີ່ `v` ຖືກປັບຂະ ໜາດ.
    //
    //
    //
    let mut err = 1;

    // ຄິດໄລ່ `10^max_kappa` ທີ່ໃຫຍ່ທີ່ສຸດບໍ່ເກີນ `v` (ດັ່ງນັ້ນ `v < 10^(max_kappa+1)`).
    // ນີ້ແມ່ນຂອບເຂດເທິງຂອງ `kappa` ຂ້າງລຸ່ມນີ້.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // ຖ້າພວກເຮົາ ກຳ ລັງເຮັດວຽກກັບຂໍ້ ຈຳ ກັດຕົວເລກສຸດທ້າຍ, ພວກເຮົາ ຈຳ ເປັນຕ້ອງເຮັດໃຫ້ບັຟເຟີສັ້ນລົງກ່ອນການ ນຳ ສະ ເໜີ ຕົວຈິງເພື່ອຫຼີກລ້ຽງຮອບສອງ.
    //
    // ໃຫ້ສັງເກດວ່າພວກເຮົາຕ້ອງໄດ້ຂະຫຍາຍ buffer ອີກຄັ້ງໃນເວລາທີ່ການຈັບຄູ່ຈະເກີດຂື້ນ!
    let len = if exp <= limit {
        // oops, ພວກເຮົາບໍ່ສາມາດຜະລິດ *ຕົວເລກ ໜຶ່ງ ຕົວເລກ*.
        // ນີ້ແມ່ນຄວາມເປັນໄປໄດ້ເມື່ອເວົ້າວ່າ, ພວກເຮົາມີບາງສິ່ງບາງຢ່າງເຊັ່ນ 9.5 ແລະມັນໄດ້ຖືກມົນເຖິງ 10.
        //
        // ໃນຫຼັກການພວກເຮົາສາມາດໂທຫາ `possibly_round` ໂດຍທັນທີທີ່ມີຊ່ອງຫວ່າງເປົ່າ, ແຕ່ການຂະຫຍາຍ `max_ten_kappa << e` ໂດຍ 10 ສາມາດສົ່ງຜົນໃຫ້ມີການຊື້ຂາຍເກີນ.
        //
        // ສະນັ້ນ, ພວກເຮົາ ກຳ ລັງເປັນບ່ອນທີ່ບໍ່ແນ່ນອນແລະເປີດກວ້າງຂໍ້ຜິດພາດໂດຍປັດໃຈ 10.
        // ນີ້ຈະເພີ່ມອັດຕາລົບທີ່ບໍ່ຖືກຕ້ອງ, ແຕ່ວ່າພຽງແຕ່ເທົ່ານັ້ນ,*ຫຼາຍ* ເລັກນ້ອຍ;
        // ມັນອາດຈະເປັນເລື່ອງທີ່ ໜ້າ ສັງເກດເມື່ອ mantissa ໃຫຍ່ກວ່າ 60 ບິດ.
        //
        // ຄວາມປອດໄພ: `len=0`, ສະນັ້ນ ໜ້າ ທີ່ຂອງການເລີ່ມຕົ້ນຄວາມຊົງ ຈຳ ນີ້ແມ່ນບໍ່ ສຳ ຄັນ.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // ສະ ເໜີ ພາກສ່ວນທີ່ບໍ່ມີສ່ວນຮ່ວມ.
    // ຂໍ້ຜິດພາດແມ່ນສ່ວນ ໜ້ອຍ, ສະນັ້ນພວກເຮົາບໍ່ ຈຳ ເປັນຕ້ອງກວດເບິ່ງມັນໃນສ່ວນນີ້.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // ຕົວເລກຍັງບໍ່ທັນໄດ້ຖືກສະແດງອອກ
    loop {
        // ພວກເຮົາມີຢ່າງ ໜ້ອຍ ໜຶ່ງ ຕົວເລກເພື່ອສະແດງການບຸກລຸກ:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (ມັນເປັນດັ່ງຕໍ່ໄປນີ້ວ່າ `remainder = vint % 10^(kappa+1)`)
        //
        //

        // ແບ່ງ `remainder` ໂດຍ `10^kappa`.ທັງສອງຖືກຂະຫຍາຍໂດຍ `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // buffer ເຕັມແລ້ວບໍ?ແລ່ນຜ່ານຮອບດ້ວຍສ່ວນທີ່ເຫຼືອ.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // ຄວາມປອດໄພ: ພວກເຮົາໄດ້ເລີ່ມຕົ້ນ `len` ຫຼາຍໄບຕ໌.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // ແຍກວົງຈອນໃນເວລາທີ່ພວກເຮົາໄດ້ສະແດງຕົວເລກທັງ ໝົດ.
        // ຕົວເລກທີ່ແນ່ນອນແມ່ນ `max_kappa + 1` ເປັນ `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // ຟື້ນຟູການບຸກລຸກ
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // render ພາກສ່ວນແຕ່ສ່ວນຫນຶ່ງ.
    //
    // ໃນຫຼັກການພວກເຮົາສາມາດສືບຕໍ່ຕົວເລກສຸດທ້າຍທີ່ມີຢູ່ແລະກວດເບິ່ງຄວາມຖືກຕ້ອງ.
    // ແຕ່ ໜ້າ ເສຍດາຍທີ່ພວກເຮົາ ກຳ ລັງເຮັດວຽກກັບເລກເຕັມຂະ ໜາດ ທີ່ ຈຳ ກັດ, ດັ່ງນັ້ນພວກເຮົາ ຈຳ ເປັນຕ້ອງມີມາດຖານບາງຢ່າງເພື່ອກວດສອບການໄຫຼເກີນ.
    // V8 ໃຊ້ `remainder > err`, ເຊິ່ງກາຍເປັນສິ່ງທີ່ບໍ່ຖືກຕ້ອງເມື່ອຕົວເລກ `i` ຄັ້ງ ທຳ ອິດຂອງ `v - 1 ulp` ແລະ `v` ແຕກຕ່າງກັນ.
    // ຢ່າງໃດກໍ່ຕາມນີ້ປະຕິເສດການປ້ອນຂໍ້ມູນທີ່ຖືກຕ້ອງຖ້າບໍ່ດັ່ງນັ້ນ.
    //
    // ເນື່ອງຈາກວ່າໄລຍະຕໍ່ມາມີການກວດພົບການໄຫຼລົ້ນທີ່ຖືກຕ້ອງ, ພວກເຮົາແທນທີ່ຈະໃຊ້ມາດຕະຖານທີ່ ແໜ້ນ ກວ່າ:
    // ພວກເຮົາສືບຕໍ່ຮອດ `err` ເກີນ `10^kappa / 2`, ສະນັ້ນຂອບເຂດລະຫວ່າງ `v - 1 ulp` ແລະ `v + 1 ulp` ປະກອບມີສອງຕົວແທນເປັນຮູບກົມ.
    //
    // ນີ້ແມ່ນຄືກັນກັບການປຽບທຽບສອງຄັ້ງ ທຳ ອິດຈາກ `possibly_round`, ສຳ ລັບການອ້າງອີງ.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, ບ່ອນທີ່ `m = max_kappa + 1` (#ຂອງຕົວເລກໃນສ່ວນປະສົມ):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // ຈະບໍ່ລົ້ນ, `2^e * 10 < 2^64`
        err *= 10; // ຈະບໍ່ລົ້ນ, `err * 10 < 2^e * 5 < 2^64`

        // ແບ່ງ `remainder` ໂດຍ `10^kappa`.
        // ທັງສອງໄດ້ຖືກຂະຫຍາຍໂດຍ `2^e / 10^kappa`, ດັ່ງນັ້ນສຸດທ້າຍແມ່ນສະແດງຢູ່ທີ່ນີ້.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // buffer ເຕັມແລ້ວບໍ?ແລ່ນຜ່ານຮອບດ້ວຍສ່ວນທີ່ເຫຼືອ.
        if i == len {
            // ຄວາມປອດໄພ: ພວກເຮົາໄດ້ເລີ່ມຕົ້ນ `len` ຫຼາຍໄບຕ໌.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // ຟື້ນຟູການບຸກລຸກ
        remainder = r;
    }

    // ການຄິດໄລ່ຕື່ມອີກແມ່ນບໍ່ມີປະໂຫຍດ (`possibly_round` ລົ້ມເຫລວຢ່າງແນ່ນອນ), ດັ່ງນັ້ນພວກເຮົາຍອມແພ້.
    return None;

    // ພວກເຮົາໄດ້ສ້າງຕົວເລກທັງ ໝົດ ຂອງ `v`, ເຊິ່ງຄວນຈະເປັນຄືກັນກັບຕົວເລກທີ່ສອດຄ້ອງກັນຂອງ `v - 1 ulp`.
    // ຕອນນີ້ພວກເຮົາກວດເບິ່ງວ່າມີຕົວແທນທີ່ເປັນເອກະລັກທີ່ແບ່ງປັນໂດຍທັງ `v - 1 ulp` ແລະ `v + 1 ulp`;ນີ້ສາມາດເປັນຄືກັນກັບຕົວເລກທີ່ຜະລິດ, ຫຼືກັບຮຸ່ນຮອບຂອງຕົວເລກເຫລົ່ານັ້ນ.
    //
    // ຖ້າຫາກວ່າລະດັບຄວາມມີຫລາຍຕົວແທນທີ່ມີຄວາມຍາວດຽວກັນ, ພວກເຮົາບໍ່ສາມາດແນ່ໃຈໄດ້ແລະຄວນສົ່ງຄືນ `None` ແທນ.
    //
    // ການໂຕ້ຖຽງທັງ ໝົດ ຢູ່ທີ່ນີ້ແມ່ນໄດ້ຂະຫຍາຍໂດຍ `k` (ແຕ່ສົມຄວນ) ຂອງມູນຄ່າທົ່ວໄປ, ດັ່ງນັ້ນ:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // ຄວາມປອດໄພ: `len` ໄບຄັ້ງ ທຳ ອິດຂອງ `buf` ຕ້ອງໄດ້ເລີ່ມຕົ້ນ.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (ສຳ ລັບການອ້າງອີງ, ເສັ້ນທີ່ບົ່ງບອກເຖິງມູນຄ່າທີ່ແນ່ນອນ ສຳ ລັບການເປັນຕົວແທນທີ່ເປັນໄປໄດ້ໃນ ຈຳ ນວນຕົວເລກທີ່ ກຳ ນົດໄວ້.)
        //
        //
        // ຂໍ້ຜິດພາດແມ່ນໃຫຍ່ເກີນໄປທີ່ຈະມີຢ່າງ ໜ້ອຍ ສາມຕົວແທນທີ່ເປັນໄປໄດ້ລະຫວ່າງ `v - 1 ulp` ແລະ `v + 1 ulp`.
        // ພວກເຮົາບໍ່ສາມາດ ກຳ ນົດວ່າອັນໃດຖືກ.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ໃນຄວາມເປັນຈິງ, ulx 1/2 ພຽງພໍທີ່ຈະແນະ ນຳ ຕົວແທນສອງຢ່າງທີ່ເປັນໄປໄດ້.
        // (ຈື່ໄວ້ວ່າພວກເຮົາຕ້ອງການຕົວແທນທີ່ເປັນເອກະລັກ ສຳ ລັບທັງ `v - 1 ulp` ແລະ `v + 1 ulp`.) ສິ່ງນີ້ຈະບໍ່ລົ້ນ, ຍ້ອນວ່າ `ulp < ten_kappa` ຈາກການກວດສອບຄັ້ງ ທຳ ອິດ.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ຖ້າ `v + 1 ulp` ໃກ້ຈະເປັນຕົວແທນແບບຮອບດ້ານ (ເຊິ່ງມີຢູ່ໃນ `buf`), ແລ້ວພວກເຮົາສາມາດກັບຄືນມາໄດ້ຢ່າງປອດໄພ.
        // ໃຫ້ສັງເກດວ່າ `v - 1 ulp`*ສາມາດ* ນ້ອຍກວ່າຕົວແທນໃນປະຈຸບັນ, ແຕ່ວ່າເປັນ `1 ulp < 10^kappa / 2`, ສະພາບນີ້ແມ່ນພຽງພໍ:
        // ໄລຍະຫ່າງລະຫວ່າງ `v - 1 ulp` ແລະການເປັນຕົວແທນໃນປະຈຸບັນບໍ່ສາມາດເກີນ `10^kappa / 2`.
        //
        // ເງື່ອນໄຂເທົ່າກັບ `remainder + ulp < 10^kappa / 2`.
        // ເນື່ອງຈາກວ່າສິ່ງນີ້ສາມາດລົ້ນໄດ້ງ່າຍ, ທຳ ອິດໃຫ້ກວດເບິ່ງວ່າ `remainder < 10^kappa / 2`.
        // ພວກເຮົາໄດ້ກວດສອບແລ້ວວ່າ `ulp < 10^kappa / 2`, ຕາບໃດທີ່ `10^kappa` ບໍ່ໄດ້ລົ້ນຫຼັງຈາກທີ່ທັງ ໝົດ, ການກວດຄັ້ງທີສອງແມ່ນດີ.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // ຄວາມປອດໄພ: ຜູ້ໂທຂອງພວກເຮົາໄດ້ເລີ່ມຕົ້ນຄວາມຊົງ ຈຳ ນັ້ນ.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------ສ່ວນທີ່ເຫຼືອ------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // ໃນທາງກົງກັນຂ້າມ, ຖ້າ `v - 1 ulp` ໃກ້ຈະເປັນຕົວແທນທີ່ມີຮູບກົມ, ພວກເຮົາຄວນຈະຈັບຕົວແລະກັບມາ.
        // ດ້ວຍເຫດຜົນດຽວກັນນີ້ພວກເຮົາບໍ່ ຈຳ ເປັນຕ້ອງກວດສອບ `v + 1 ulp`.
        //
        // ເງື່ອນໄຂເທົ່າກັບ `remainder - ulp >= 10^kappa / 2`.
        // ອີກເທື່ອ ໜຶ່ງ ພວກເຮົາກວດເບິ່ງວ່າ `remainder > ulp` (ສັງເກດວ່ານີ້ບໍ່ແມ່ນ `remainder >= ulp`, ຍ້ອນວ່າ `10^kappa` ບໍ່ເຄີຍເປັນສູນ).
        //
        // ຍັງໄດ້ສັງເກດວ່າ `remainder - ulp <= 10^kappa`, ດັ່ງນັ້ນການກວດສອບຄັ້ງທີສອງບໍ່ລົ້ນ.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // ປອດໄພ: ຜູ້ໂທຂອງພວກເຮົາຕ້ອງໄດ້ເລີ່ມຕົ້ນຄວາມຊົງ ຈຳ ນັ້ນ.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // ພຽງແຕ່ເພີ່ມຕົວເລກເພີ່ມເຕີມເມື່ອພວກເຮົາຖືກຮ້ອງຂໍໃຫ້ມີຄວາມແນ່ນອນຄົງທີ່.
                // ພວກເຮົາຍັງຕ້ອງໄດ້ກວດເບິ່ງວ່າ, ຖ້າວ່າ buffer ເດີມແມ່ນຫວ່າງເປົ່າ, ຕົວເລກເພີ່ມເຕີມສາມາດເພີ່ມໄດ້ເມື່ອ `exp == limit` (ກໍລະນີ edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // ຄວາມປອດໄພ: ພວກເຮົາແລະຜູ້ໂທຂອງພວກເຮົາໄດ້ເລີ່ມຕົ້ນຄວາມຊົງ ຈຳ ນັ້ນ.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // ຖ້າບໍ່ດັ່ງນັ້ນພວກເຮົາຈະຖືກ ທຳ ລາຍ (ໝາຍ ຄວາມວ່າຄ່າບາງຢ່າງລະຫວ່າງ `v - 1 ulp` ແລະ `v + 1 ulp` ແມ່ນ ກຳ ລັງຖືກປິດລົງແລະອີກ ຈຳ ນວນ ໜຶ່ງ ກຳ ລັງຖືກຂຸ້ນຂ້ຽວ).
        //
        None
    }
}

/// ການປະຕິບັດຮູບແບບທີ່ແນ່ນອນແລະຄົງທີ່ ສຳ ລັບ Grisu ກັບ Dragon fallback.
///
/// ສິ່ງນີ້ຄວນໃຊ້ ສຳ ລັບກໍລະນີຫຼາຍທີ່ສຸດ.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // ຄວາມປອດໄພ: ຜູ້ກວດສອບການກູ້ຢືມເງິນແມ່ນບໍ່ສະຫຼາດພໍທີ່ຈະໃຫ້ພວກເຮົາໃຊ້ `buf`
    // ໃນ branch ຄັ້ງທີສອງ, ສະນັ້ນພວກເຮົາຊັກ ນຳ ຕະຫຼອດຊີວິດ.
    // ແຕ່ພວກເຮົາໃຊ້ `buf` ຄືນ ໃໝ່ ເທົ່ານັ້ນຖ້າ `format_exact_opt` ກັບຄືນ `None` ສະນັ້ນມັນບໍ່ເປັນຫຍັງ.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}