//! ການແປພາສາ Rust ເກືອບໂດຍກົງ (ແຕ່ມີການເພີ່ມປະສິດທິພາບເລັກນ້ອຍ) ຂອງຮູບ 3 ຂອງ "ການພິມ ຈຳ ນວນຕົວເລກເລື່ອນລອຍຢ່າງໄວວາແລະຖືກຕ້ອງ" [^ 1].
//!
//!
//! [^1]: Burger, RG ແລະ Dybvig, RK 1996. ການພິມ ຈຳ ນວນຕົວເລກເລື່ອນ
//!   ຢ່າງວ່ອງໄວແລະຖືກຕ້ອງ.SIGPLAN ບໍ່.ວັນທີ 31, 5 (ເດືອນພຶດສະພາ 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// ຂບວນການຈັດລຽງຂອງ `ຕົວເລກ` ສຳ ລັບ 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// ໃຊ້ໄດ້ເມື່ອ `x < 16 * scale`;`scaleN` ຄວນຈະເປັນ `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ການປະຕິບັດຮູບແບບທີ່ສັ້ນທີ່ສຸດ ສຳ ລັບມັງກອນ.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ຈຳ ນວນ `v` ທີ່ຈະຈັດຮູບແບບແມ່ນຮູ້ວ່າເປັນ:
    // - ເທົ່າກັບ `mant * 2^exp`;
    // - ກ່ອນ `(mant - 2 *minus)* 2^exp` ໃນປະເພດເດີມ;ແລະ
    // - ຕາມດ້ວຍ `(mant + 2 *plus)* 2^exp` ໃນປະເພດເດີມ.
    //
    // ແນ່ນອນ, `minus` ແລະ `plus` ບໍ່ສາມາດເປັນສູນ.(ສຳ ລັບສິ່ງທີ່ບໍ່ມີຕົວຕົນ, ພວກເຮົາ ນຳ ໃຊ້ຄ່ານອກລະດັບ.) ພວກເຮົາຍັງສົມມຸດວ່າຢ່າງ ໜ້ອຍ ໜຶ່ງ ຕົວເລກແມ່ນຖືກຜະລິດ, ເຊັ່ນ, `mant` ກໍ່ບໍ່ສາມາດເປັນສູນເຊັ່ນກັນ.
    //
    // ນີ້ຍັງ ໝາຍ ຄວາມວ່າຕົວເລກໃດລະຫວ່າງ `low = (mant - minus)*2^exp` ແລະ `high = (mant + plus)* 2^exp` ຈະມີແຜນທີ່ເຖິງ ຈຳ ນວນຈຸດລອຍຕົວທີ່ແນ່ນອນນີ້, ໂດຍມີຂອບເຂດລວມໃນເວລາທີ່ຕົ້ນສະບັບເດີມ (ແມ້ແຕ່ `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` ແມ່ນ `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // ຄາດຄະເນ `k_0` ຈາກວັດຖຸດິບຕົ້ນສະບັບທີ່ພໍໃຈ `10^(k_0-1) < high <= 10^(k_0+1)`.
    // `k` ທີ່ພໍໃຈໃກ້ຊິດ X0X ຖືກຄິດໄລ່ພາຍຫຼັງ.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // ປ່ຽນ `{mant, plus, minus} * 2^exp` ເປັນຮູບແບບສ່ວນ ໜຶ່ງ ເພື່ອວ່າ:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // ແບ່ງ `mant` ໂດຍ `10^k`.ດຽວນີ້ `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // ການແກ້ໄຂເມື່ອ `mant + plus > scale` (ຫຼື `>=`).
    // ພວກເຮົາບໍ່ໄດ້ປັບປຸງຕົວຈິງ `scale`, ເພາະວ່າພວກເຮົາສາມາດຂ້າມຕົວເລກທະວີຄູນເບື້ອງຕົ້ນແທນ.
    // ດຽວນີ້ `scale < mant + plus <= scale * 10` ແລະພວກເຮົາພ້ອມທີ່ຈະສ້າງຕົວເລກ.
    //
    // ສັງເກດວ່າ `d[0]`*ສາມາດ* ເປັນສູນ, ເມື່ອ `scale - plus < mant < scale`.
    // ໃນກໍລະນີນີ້ຮອບວຽນເງື່ອນໄຂ (`up` ຂ້າງລຸ່ມນີ້) ຈະເກີດຂື້ນທັນທີ.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // ທຽບເທົ່າກັບການຂະຫຍາຍ `scale` ໂດຍ 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` ສຳ ລັບການຜະລິດຕົວເລກ.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants, ບ່ອນທີ່ `d[0..n-1]` ແມ່ນຕົວເລກທີ່ສ້າງມາຈົນເຖິງປະຈຸບັນ:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (ດັ່ງນັ້ນ `mant / scale < 10`) ບ່ອນທີ່ `d[i..j]` ແມ່ນສັ້ນ ສຳ ລັບ `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // ສ້າງຕົວເລກ ໜຶ່ງ ຕົວເລກ: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // ນີ້ແມ່ນລາຍລະອຽດແບບງ່າຍໆຂອງວິທີແກ້ມັງກອນ.
        // ເອກະສານອ້າງອີງລະດັບປານກາງແລະການໂຕ້ຖຽງຄົບຖ້ວນຖືກຍົກເວັ້ນເພື່ອຄວາມສະດວກສະບາຍ.
        //
        // ເລີ່ມຕົ້ນດ້ວຍການຮຸກຮານທີ່ປ່ຽນແປງ, ດັ່ງທີ່ພວກເຮົາໄດ້ປັບປຸງ `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // ສົມມຸດວ່າ `d[0..n-1]` ແມ່ນຕົວແທນທີ່ສັ້ນທີ່ສຸດລະຫວ່າງ `low` ແລະ `high`, ໝາຍ ຄວາມວ່າ `d[0..n-1]` ຕອບສະ ໜອງ ທັງສອງຢ່າງດັ່ງຕໍ່ໄປນີ້ແຕ່ `d[0..n-2]` ບໍ່ໄດ້:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: ຕົວເລກຮອບກັບ `v`);ແລະ
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (ຕົວເລກສຸດທ້າຍແມ່ນຖືກຕ້ອງ).
        //
        // ສະພາບການທີສອງງ່າຍດາຍທີ່ຈະເປັນ `2 * mant <= scale`.
        // ການແກ້ໄຂບັນຫາສັດປີກໃນແງ່ຂອງ `mant`, `low` ແລະ `high` ໃຫ້ຜົນຜະລິດລຸ້ນ ທຳ ອິດທີ່ງ່າຍດາຍ: `-plus < mant < minus`.
        // ນັບຕັ້ງແຕ່ `-plus < 0 <= mant`, ພວກເຮົາມີຕົວແທນສັ້ນທີ່ຖືກຕ້ອງທີ່ສຸດເມື່ອ `mant < minus` ແລະ `2 * mant <= scale`.
        // (ອະດີດກາຍເປັນ `mant <= minus` ເມື່ອຕົ້ນສະບັບ mantissa ແມ່ນແຕ່.)
        //
        // ເມື່ອວິນາທີບໍ່ຖື (`2 * mant> scale`), ພວກເຮົາ ຈຳ ເປັນຕ້ອງເພີ່ມຕົວເລກສຸດທ້າຍ.
        // ນີ້ແມ່ນພຽງພໍ ສຳ ລັບການຟື້ນຟູສະພາບການດັ່ງກ່າວ: ພວກເຮົາຮູ້ແລ້ວວ່າການຜະລິດຕົວເລກຮັບປະກັນ `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // ໃນກໍລະນີນີ້, ສະພາບ ທຳ ອິດຈະກາຍເປັນ `-plus < mant - scale < minus`.
        // ນັບຕັ້ງແຕ່ `mant < scale` ຫຼັງຈາກການຜະລິດ, ພວກເຮົາມີ `scale < mant + plus`.
        // (ອີກເທື່ອຫນຶ່ງ, ມັນຈະກາຍເປັນ `scale <= mant + plus` ໃນເວລາທີ່ mantissa ຕົ້ນສະບັບແມ່ນເຖິງແມ່ນວ່າ.)
        //
        // ໃນສັ້ນ:
        // - ຢຸດແລະຮອບ `down` (ຮັກສາຕົວເລກຄືກັນກັບ) ເມື່ອ `mant < minus` (ຫຼື `<=`).
        // - ຢຸດແລະຮອບ `up` (ເພີ່ມຕົວເລກສຸດທ້າຍ) ເມື່ອ `scale < mant + plus` (ຫຼື `<=`).
        // - ຮັກສາການຜະລິດຖ້າບໍ່ດັ່ງນັ້ນ.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // ພວກເຮົາມີຕົວແທນທີ່ສັ້ນທີ່ສຸດ, ດຳ ເນີນການຮອບ

        // ປະຕິສັງຂອນການບຸກລຸກ.
        // ນີ້ເຮັດໃຫ້ສູດການຄິດໄລ່ສິ້ນສຸດສະເຫມີ: `minus` ແລະ `plus` ເພີ່ມຂື້ນສະເຫມີ, ແຕ່ `mant` ຖືກປິດແບບໂມເດວ `scale` ແລະ `scale` ມີການສ້ອມແຊມ.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ໄດ້ຕະຫຼອດເກີດຂື້ນໃນເວລາທີ່ i) ມີພຽງແຕ່ສະພາບການຮອບຕົວເທົ່ານັ້ນທີ່ຖືກກະຕຸ້ນ, ຫຼື ii) ເງື່ອນໄຂທັງສອງແມ່ນໄດ້ຖືກກະຕຸ້ນແລະມັກແຕກແຍກທີ່ມັກ.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ຖ້າຮອບມົນມີການປ່ຽນແປງຄວາມຍາວ, ໂຕເລກກໍ່ຄວນປ່ຽນ.
        // ມັນເບິ່ງຄືວ່າສະພາບການນີ້ແມ່ນຍາກຫຼາຍທີ່ຈະຕອບສະ ໜອງ ໄດ້ (ເປັນໄປບໍ່ໄດ້), ແຕ່ພວກເຮົາພຽງແຕ່ມີຄວາມປອດໄພແລະສອດຄ່ອງຢູ່ທີ່ນີ້.
        //
        // ຄວາມປອດໄພ: ພວກເຮົາເລີ່ມຕົ້ນຄວາມຊົງ ຈຳ ຂ້າງເທິງນັ້ນ.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // ຄວາມປອດໄພ: ພວກເຮົາເລີ່ມຕົ້ນຄວາມຊົງ ຈຳ ຂ້າງເທິງນັ້ນ.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ການປະຕິບັດຮູບແບບທີ່ແນ່ນອນແລະຄົງທີ່ ສຳ ລັບມັງກອນ.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // ຄາດຄະເນ `k_0` ຈາກວັດຖຸດິບຕົ້ນສະບັບທີ່ພໍໃຈ `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // ແບ່ງ `mant` ໂດຍ `10^k`.ດຽວນີ້ `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // ການແກ້ໄຂເມື່ອ `mant + plus >= scale`, ບ່ອນທີ່ `plus / scale = 10^-buf.len() / 2`.
    // ໃນຄໍາສັ່ງທີ່ຈະຮັກສາ bignum ຂະຫນາດຄົງທີ່, ຕົວຈິງແລ້ວພວກເຮົາໃຊ້ `mant + floor(plus) >= scale`.
    // ພວກເຮົາບໍ່ໄດ້ປັບປຸງຕົວຈິງ `scale`, ເພາະວ່າພວກເຮົາສາມາດຂ້າມຕົວເລກທະວີຄູນເບື້ອງຕົ້ນແທນ.
    // ອີກເທື່ອ ໜຶ່ງ ດ້ວຍວິທີຄິດໄລ່ທີ່ສັ້ນທີ່ສຸດ, `d[0]` ສາມາດເປັນສູນແຕ່ມັນຈະຖືກປັບຕົວໃນທີ່ສຸດ.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // ທຽບເທົ່າກັບການຂະຫຍາຍ `scale` ໂດຍ 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // ຖ້າພວກເຮົາ ກຳ ລັງເຮັດວຽກກັບຂໍ້ ຈຳ ກັດຕົວເລກສຸດທ້າຍ, ພວກເຮົາ ຈຳ ເປັນຕ້ອງເຮັດໃຫ້ບັຟເຟີສັ້ນລົງກ່ອນການ ນຳ ສະ ເໜີ ຕົວຈິງເພື່ອຫຼີກລ້ຽງຮອບສອງ.
    //
    // ໃຫ້ສັງເກດວ່າພວກເຮົາຕ້ອງໄດ້ຂະຫຍາຍ buffer ອີກຄັ້ງໃນເວລາທີ່ການຈັບຄູ່ຈະເກີດຂື້ນ!
    let mut len = if k < limit {
        // oops, ພວກເຮົາບໍ່ສາມາດຜະລິດ *ຕົວເລກ ໜຶ່ງ ຕົວເລກ*.
        // ນີ້ແມ່ນຄວາມເປັນໄປໄດ້ເມື່ອເວົ້າວ່າ, ພວກເຮົາມີບາງສິ່ງບາງຢ່າງເຊັ່ນ 9.5 ແລະມັນໄດ້ຖືກມົນເຖິງ 10.
        // ພວກເຮົາສົ່ງຄືນຟຮີເປົ່າ, ໂດຍມີຂໍ້ຍົກເວັ້ນຂອງກໍລະນີຮອບຕໍ່ໄປທີ່ເກີດຂື້ນເມື່ອ `k == limit` ແລະຕ້ອງໄດ້ຜະລິດຕົວເລກ ໜຶ່ງ ຕົວເລກຢ່າງແນ່ນອນ.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` ສຳ ລັບການຜະລິດຕົວເລກ.
        // (ນີ້ອາດຈະແພງ, ສະນັ້ນຢ່າຄິດໄລ່ພວກມັນໃນເວລາທີ່ buffer ຫວ່າງຢູ່.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // ຕົວເລກຕໍ່ໄປນີ້ແມ່ນເລກສູນທັງ ໝົດ, ພວກເຮົາຢຸດຢູ່ນີ້ບໍ່ *ບໍ່* ລອງເຮັດຮອບ!ແທນທີ່ຈະ, ຕື່ມຕົວເລກທີ່ຍັງເຫຼືອ.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // ຄວາມປອດໄພ: ພວກເຮົາເລີ່ມຕົ້ນຄວາມຊົງ ຈຳ ຂ້າງເທິງນັ້ນ.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // ຮອບຖ້າພວກເຮົາຢຸດຢູ່ເຄິ່ງກາງຂອງຕົວເລກຖ້າວ່າຕົວເລກຕໍ່ໄປນີ້ແມ່ນ 5000 ຢ່າງແນ່ນອນ ... , ກວດເບິ່ງຕົວເລກທີ່ຢູ່ເບື້ອງຕົ້ນແລະພະຍາຍາມທີ່ຈະເຮັດໃຫ້ຮອບເຖິງແມ່ນວ່າ (ໝາຍ ຄວາມວ່າ, ຫລີກລ້ຽງການແຂ່ງຂັນໃນເວລາທີ່ຕົວເລກກ່ອນແມ່ນຍັງ).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // ຄວາມປອດໄພ: `buf[len-1]` ແມ່ນເລີ່ມຕົ້ນ.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ຖ້າຮອບມົນມີການປ່ຽນແປງຄວາມຍາວ, ໂຕເລກກໍ່ຄວນປ່ຽນ.
        // ແຕ່ພວກເຮົາໄດ້ຖືກຮຽກຮ້ອງໃຫ້ມີຕົວເລກທີ່ແນ່ນອນ, ສະນັ້ນບໍ່ຄວນປ່ຽນແປງບັຟເຟີ ...
        // ຄວາມປອດໄພ: ພວກເຮົາເລີ່ມຕົ້ນຄວາມຊົງ ຈຳ ຂ້າງເທິງນັ້ນ.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... ເວັ້ນເສຍແຕ່ວ່າພວກເຮົາໄດ້ຮັບການຮ້ອງຂໍຄວາມແມ່ນຍໍາຄົງທີ່ແທນ.
            // ພວກເຮົາຍັງຕ້ອງໄດ້ກວດເບິ່ງວ່າ, ຖ້າວ່າ buffer ເດີມແມ່ນຫວ່າງເປົ່າ, ຕົວເລກເພີ່ມເຕີມສາມາດເພີ່ມໄດ້ເມື່ອ `k == limit` (ກໍລະນີ edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // ຄວາມປອດໄພ: ພວກເຮົາເລີ່ມຕົ້ນຄວາມຊົງ ຈຳ ຂ້າງເທິງນັ້ນ.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}