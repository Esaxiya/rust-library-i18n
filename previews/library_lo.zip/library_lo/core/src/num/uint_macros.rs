macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// ມູນຄ່ານ້ອຍທີ່ສຸດທີ່ສາມາດເປັນຕົວແທນໂດຍປະເພດເລກນີ້.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// ມູນຄ່າທີ່ໃຫຍ່ທີ່ສຸດທີ່ສາມາດເປັນຕົວແທນໂດຍປະເພດເລກນີ້.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// ຂະ ໜາດ ຂອງປະເພດເລກເຕັມນີ້ເປັນບິດ.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// ແປງສ່ວນເຊືອກໃນຖານໃຫ້ເປັນເລກເຕັມ.
        ///
        /// ເຊືອກຄາດວ່າຈະເປັນເຄື່ອງ ໝາຍ `+` ທີ່ເປັນຕົວເລືອກຕາມດ້ວຍຕົວເລກ.
        ///
        /// ການ ນຳ ພາແລະຕິດຕາມຊ່ອງຫວ່າງເປັນຕົວແທນຂອງຂໍ້ຜິດພາດ.
        /// ຕົວເລກແມ່ນຊຸດຍ່ອຍຂອງຕົວອັກສອນເຫຼົ່ານີ້, ຂື້ນກັບ `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ panics ຖ້າ `radix` ບໍ່ຢູ່ໃນຂອບເຂດແຕ່ 2 ເຖິງ 36.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// ສົ່ງຄືນ ຈຳ ນວນໂຕທີ່ຢູ່ໃນຕົວແທນຖານສອງຂອງ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// ສົ່ງ ຈຳ ນວນເລກສູນໃນຕົວແທນຖານສອງຂອງ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// ສົ່ງ ຈຳ ນວນເລກສູນ ນຳ ໜ້າ ໃນຕົວແທນຖານສອງຂອງ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// ສົ່ງ ຈຳ ນວນເລກສູນສູນໃນຕົວແທນຖານສອງຂອງ `self`.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// ສົ່ງຄືນ ຈຳ ນວນໂຕ ນຳ ທີ່ຢູ່ໃນຕົວແທນຖານສອງຂອງ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// ສົ່ງຄືນ ຈຳ ນວນຂອງການຕິດຕາມໃນຕົວແທນຖານສອງຂອງ `self`.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// ປ່ຽນບິດໄປທາງຊ້າຍດ້ວຍ ຈຳ ນວນເງິນທີ່ລະບຸ, `n`, ຫໍ່ສ່ວນທີ່ຕັດເປັນທ່ອນໄປຫາສຸດທ້າຍຂອງ ຈຳ ນວນຜົນທີ່ໄດ້ຮັບ.
        ///
        ///
        /// ກະລຸນາສັງເກດວ່ານີ້ບໍ່ແມ່ນການເຮັດວຽກດຽວກັນກັບຜູ້ປະຕິບັດການຍ້າຍ `<<`!
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// ປ່ຽນບິດໄປທາງຂວາໂດຍ ຈຳ ນວນເງິນທີ່ ກຳ ນົດ, `n`, ຫໍ່ສ່ວນທີ່ຖືກຕັດໃຫ້ເປັນທ່ອນເລີ່ມຕົ້ນຂອງເລກເຕັມທີ່ໄດ້ຮັບ.
        ///
        ///
        /// ກະລຸນາສັງເກດວ່ານີ້ບໍ່ແມ່ນການເຮັດວຽກດຽວກັນກັບຜູ້ປະຕິບັດການຍ້າຍ `>>`!
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// ປີ້ນກັບກັນຕາມ ລຳ ດັບຂອງໄບ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ໃຫ້ m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// ປີ້ນກັບກັນຕາມ ລຳ ດັບຂອງບິດໃນເລກເຕັມ.
        /// ບິດທີ່ ສຳ ຄັນ ໜ້ອຍ ທີ່ສຸດກາຍເປັນບິດທີ່ ສຳ ຄັນທີ່ສຸດ, ບິດທີ່ ສຳ ຄັນທີ່ສອງກາຍເປັນບິດທີ່ ສຳ ຄັນທີ່ສຸດ, ເປັນຕົ້ນ
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ໃຫ້ m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// ປ່ຽນເລກເຕັມຈາກ endian ໃຫຍ່ໄປສູ່ຄວາມຍືນຍົງຂອງເປົ້າ ໝາຍ.
        ///
        /// ກ່ຽວກັບ endian ໃຫຍ່ນີ້ແມ່ນບໍ່ມີ.
        /// ໃນພື້ນທີ່ endian ພຽງເລັກນ້ອຍແມ່ນໄດ້ຖືກແລກປ່ຽນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ຖ້າ cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } ອີກ {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// ປ່ຽນເລກເຕັມຈາກ endian ພຽງເລັກນ້ອຍກັບຄວາມຍືນຍົງຂອງເປົ້າ ໝາຍ.
        ///
        /// ກ່ຽວກັບ endian ພຽງເລັກນ້ອຍນີ້ແມ່ນບໍ່ມີ.
        /// ກ່ຽວກັບ endian ໃຫຍ່ໄບຕ໌ຖືກປ່ຽນໄປ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ຖ້າ cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } ອີກ {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// ແປງ `self` ກັບ endian ໃຫຍ່ຈາກຄວາມອົດທົນຂອງເປົ້າ ໝາຍ.
        ///
        /// ກ່ຽວກັບ endian ໃຫຍ່ນີ້ແມ່ນບໍ່ມີ.
        /// ໃນພື້ນທີ່ endian ພຽງເລັກນ້ອຍແມ່ນໄດ້ຖືກແລກປ່ຽນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ຖ້າ cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } ອີກ { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ຫຼືບໍ່ເປັນ?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// ແປງ `self` ກັບ endian ພຽງເລັກນ້ອຍຈາກຄວາມອົດທົນຂອງເປົ້າຫມາຍ.
        ///
        /// ກ່ຽວກັບ endian ພຽງເລັກນ້ອຍນີ້ແມ່ນບໍ່ມີ.
        /// ກ່ຽວກັບ endian ໃຫຍ່ໄບຕ໌ຖືກປ່ຽນໄປ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ຖ້າ cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } ອີກ { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// ກວດສອບການເພີ່ມເລກເຕັມ.
        /// ຄຳ ນວນ `self + rhs`, ການກັບຄືນ `None` ຖ້າຫາກວ່າເກີດມີການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ການເພີ່ມ ຈຳ ນວນເຕັມທີ່ບໍ່ຖືກເລືອກຄຳ ສັບ `self + rhs`, ສົມມຸດວ່າການລົ້ນບໍ່ສາມາດເກີດຂື້ນໄດ້.
        /// ຜົນໄດ້ຮັບນີ້ຈະເຮັດໃຫ້ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດເວລາ
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// ການຫັກລົບເລກເຊັກ.
        /// ຄຳ ນວນ `self - rhs`, ການກັບຄືນ `None` ຖ້າຫາກວ່າເກີດມີການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ການຫັກລົບ ຈຳ ນວນທີ່ບໍ່ຖືກຄັດເລືອກ.ຄຳ ສັບ `self - rhs`, ສົມມຸດວ່າການລົ້ນບໍ່ສາມາດເກີດຂື້ນໄດ້.
        /// ຜົນໄດ້ຮັບນີ້ຈະເຮັດໃຫ້ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດເວລາ
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// ການກວດສອບເລກທະວີຄູນ.
        /// ຄຳ ນວນ `self * rhs`, ການກັບຄືນ `None` ຖ້າຫາກວ່າເກີດມີການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ຕົວເລກທະວີຄູນແບບບໍ່ນັບ.ຄຳ ສັບ `self * rhs`, ສົມມຸດວ່າການລົ້ນບໍ່ສາມາດເກີດຂື້ນໄດ້.
        /// ຜົນໄດ້ຮັບນີ້ຈະເຮັດໃຫ້ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດເວລາ
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// ກວດກາພະແນກເລກເຕັມ.
        /// ຄຳ ນວນ `self / rhs`, ການກັບຄືນ `None` ຖ້າ `rhs == 0`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // ຄວາມປອດໄພ: div ໂດຍສູນໄດ້ຖືກກວດເບິ່ງຢູ່ຂ້າງເທິງແລະປະເພດທີ່ບໍ່ໄດ້ລົງນາມແມ່ນບໍ່ມີອີກ
                // ຮູບແບບການລົ້ມເຫຼວ ສຳ ລັບການແບ່ງງານ
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// ກວດກາພະແນກ Euclidean.
        /// ຄຳ ນວນ `self.div_euclid(rhs)`, ການກັບຄືນ `None` ຖ້າ `rhs == 0`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// ການກວດສອບສ່ວນທີ່ເຫຼືອຂອງເລກເຕັມ.
        /// ຄຳ ນວນ `self % rhs`, ການກັບຄືນ `None` ຖ້າ `rhs == 0`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // ຄວາມປອດໄພ: div ໂດຍສູນໄດ້ຖືກກວດເບິ່ງຢູ່ຂ້າງເທິງແລະປະເພດທີ່ບໍ່ໄດ້ລົງນາມແມ່ນບໍ່ມີອີກ
                // ຮູບແບບການລົ້ມເຫຼວ ສຳ ລັບການແບ່ງງານ
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// ຕວດສອບ Euclidean modulo.
        /// ຄຳ ນວນ `self.rem_euclid(rhs)`, ການກັບຄືນ `None` ຖ້າ `rhs == 0`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// ການກວດກາຄວາມເສີຍເມີຍ.ຄຳ ນວນ `-self`, ກັບຄືນ `None` ຍົກເວັ້ນ `ຕົນເອງ==
        /// 0`.
        ///
        /// ໃຫ້ສັງເກດວ່າການລົບລ້າງເລກເຕັມໃນທາງບວກຈະລົ້ນລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ເຊັກປ່ຽນຊ້າຍ.
        /// ຄຳ ນວນ `self << rhs`, ການກັບຄືນ `None` ຖ້າ `rhs` ໃຫຍ່ກວ່າຫຼືເທົ່າກັບ ຈຳ ນວນບິດໃນ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ເຊັກປ່ຽນທາງຂວາ.
        /// ຄຳ ນວນ `self >> rhs`, ການກັບຄືນ `None` ຖ້າ `rhs` ໃຫຍ່ກວ່າຫຼືເທົ່າກັບ ຈຳ ນວນບິດໃນ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ການກວດສອບການເລັ່ງລັດ.
        /// ຄຳ ນວນ `self.pow(exp)`, ການກັບຄືນ `None` ຖ້າຫາກວ່າເກີດມີການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // ນັບຕັ້ງແຕ່ exp!=0, ສຸດທ້າຍ exp ຕ້ອງແມ່ນ 1.
            // ຈັດການກັບໂຕເລກສຸດທ້າຍແຍກຕ່າງຫາກ, ເພາະວ່າການກອກພື້ນຖານຫລັງຈາກນັ້ນແມ່ນບໍ່ ຈຳ ເປັນແລະອາດຈະເຮັດໃຫ້ເກີດການໄຫຼວຽນແບບບໍ່ ຈຳ ເປັນ.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// ການເພີ່ມເຕີມເຕັມຂອງ saturating.
        /// ຄອມພິວເຕີ້ `self + rhs`, ອີ່ມຕົວຢູ່ຂອບເຂດຕົວເລກແທນທີ່ຈະລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// ການຫັກລົບ ຈຳ ນວນອີ່ມຕົວ.
        /// ຄອມພິວເຕີ້ `self - rhs`, ອີ່ມຕົວຢູ່ຂອບເຂດຕົວເລກແທນທີ່ຈະລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// ການຄູນເລກທະວີຄູນ.
        /// ຄອມພິວເຕີ້ `self * rhs`, ອີ່ມຕົວຢູ່ຂອບເຂດຕົວເລກແທນທີ່ຈະລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// ການສະແດງອອກທາງອິນເຕີເນເຊິນບວກ.
        /// ຄອມພິວເຕີ້ `self.pow(exp)`, ອີ່ມຕົວຢູ່ຂອບເຂດຕົວເລກແທນທີ່ຈະລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// ການຫໍ່ເອົາ (modular) ເພີ່ມ.
        /// ຄຳ ນວນ `self + rhs`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// ການຫັກລົບ (modular).
        /// ຄຳ ນວນ `self - rhs`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// ຫໍ່ຕົວຄູນ (modular).
        /// ຄຳ ນວນ `self * rhs`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ກະລຸນາສັງເກດວ່າຕົວຢ່າງນີ້ຖືກແບ່ງປັນລະຫວ່າງປະເພດເລກເຕັມ.
        /// ເຊິ່ງອະທິບາຍວ່າເປັນຫຍັງ `u8` ຈຶ່ງຖືກ ນຳ ໃຊ້ຢູ່ນີ້.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// ການຫໍ່ພະແນກ (modular).ຄຳ ນວນ `self / rhs`.
        /// ການແບ່ງສ່ວນຂອງປະເພດທີ່ບໍ່ໄດ້ລົງນາມແມ່ນພຽງແຕ່ການແບ່ງສ່ວນ ທຳ ມະດາ.
        /// ບໍ່ມີວິທີໃດທີ່ຈະຫໍ່ສາມາດເກີດຂື້ນໄດ້.
        /// ຫນ້າທີ່ນີ້ມີຢູ່, ດັ່ງນັ້ນການປະຕິບັດງານທັງຫມົດຖືກຄິດໄລ່ໃນການປະຕິບັດງານຫໍ່.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// ຫໍ່ພະແນກ Euclidean.ຄຳ ນວນ `self.div_euclid(rhs)`.
        /// ການແບ່ງສ່ວນຂອງປະເພດທີ່ບໍ່ໄດ້ລົງນາມແມ່ນພຽງແຕ່ການແບ່ງສ່ວນ ທຳ ມະດາ.
        /// ບໍ່ມີວິທີໃດທີ່ຈະຫໍ່ສາມາດເກີດຂື້ນໄດ້.
        /// ຫນ້າທີ່ນີ້ມີຢູ່, ດັ່ງນັ້ນການປະຕິບັດງານທັງຫມົດຖືກຄິດໄລ່ໃນການປະຕິບັດງານຫໍ່.
        /// ເນື່ອງຈາກວ່າ, ສຳ ລັບເລກເຕັມໃນແງ່ບວກ, ທຸກ ຄຳ ນິຍາມທົ່ວໄປຂອງການແບ່ງສ່ວນແມ່ນເທົ່າກັນ, ນີ້ເທົ່າກັບ `self.wrapping_div(rhs)` ແທ້ໆ.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// ຫໍ່ສ່ວນທີ່ເຫຼືອ (modular).ຄຳ ນວນ `self % rhs`.
        /// ການຄິດໄລ່ສ່ວນທີ່ເຫຼືອຂອງຫໍ່ໃສ່ປະເພດທີ່ບໍ່ໄດ້ລົງນາມແມ່ນພຽງແຕ່ການຄິດໄລ່ສ່ວນທີ່ເຫຼືອເທົ່ານັ້ນ.
        ///
        /// ບໍ່ມີວິທີໃດທີ່ຈະຫໍ່ສາມາດເກີດຂື້ນໄດ້.
        /// ຫນ້າທີ່ນີ້ມີຢູ່, ດັ່ງນັ້ນການປະຕິບັດງານທັງຫມົດຖືກຄິດໄລ່ໃນການປະຕິບັດງານຫໍ່.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Wrapping Euclidean modulo.ຄຳ ນວນ `self.rem_euclid(rhs)`.
        /// ການຄິດໄລ່ແບບໂມດູນຫໍ່ໃສ່ປະເພດທີ່ບໍ່ໄດ້ລົງນາມແມ່ນພຽງແຕ່ການຄິດໄລ່ສ່ວນທີ່ເຫຼືອເທົ່ານັ້ນ.
        /// ບໍ່ມີວິທີໃດທີ່ຈະຫໍ່ສາມາດເກີດຂື້ນໄດ້.
        /// ຫນ້າທີ່ນີ້ມີຢູ່, ດັ່ງນັ້ນການປະຕິບັດງານທັງຫມົດຖືກຄິດໄລ່ໃນການປະຕິບັດງານຫໍ່.
        /// ເນື່ອງຈາກວ່າ, ສຳ ລັບເລກເຕັມໃນແງ່ບວກ, ທຸກ ຄຳ ນິຍາມທົ່ວໄປຂອງການແບ່ງສ່ວນແມ່ນເທົ່າກັນ, ນີ້ເທົ່າກັບ `self.wrapping_rem(rhs)` ແທ້ໆ.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// ການປະຖິ້ມຂໍ້ຫຍໍ້ (modular).
        /// ຄຳ ນວນ `-self`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// ເນື່ອງຈາກວ່າປະເພດທີ່ບໍ່ໄດ້ລົງນາມບໍ່ມີຄວາມເທົ່າທຽມກັນກັບທຸກໆ ຄຳ ຮ້ອງສະ ໝັກ ຂອງ ໜ້າ ທີ່ນີ້ຈະຫໍ່ (ຍົກເວັ້ນ `-0`).
        /// ສຳ ລັບຄຸນຄ່າທີ່ນ້ອຍກວ່າປະລິມານທີ່ສູງສຸດຂອງປະເພດທີ່ຖືກລົງນາມທີ່ສອດຄ້ອງກັນຜົນໄດ້ຮັບແມ່ນຄືກັນກັບການໂຍນມູນຄ່າທີ່ເຊັນກັນ.
        ///
        /// ທຸກໆຄ່າທີ່ໃຫຍ່ກວ່າແມ່ນເທົ່າກັບ `MAX + 1 - (val - MAX - 1)` ບ່ອນທີ່ `MAX` ແມ່ນສູງສຸດຂອງປະເພດທີ່ເຊັນທີ່ສອດຄ້ອງກັນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ກະລຸນາສັງເກດວ່າຕົວຢ່າງນີ້ຖືກແບ່ງປັນລະຫວ່າງປະເພດເລກເຕັມ.
        /// ເຊິ່ງອະທິບາຍວ່າເປັນຫຍັງ `i8` ຈຶ່ງຖືກ ນຳ ໃຊ້ຢູ່ນີ້.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-free bitwise shift-left;
        /// ໃຫ້ຜົນຜະລິດ `self << mask(rhs)`, ບ່ອນທີ່ `mask` ກຳ ຈັດທ່ອນທີ່ມີລະບຽບສູງຂອງ `rhs` ເຊິ່ງຈະເຮັດໃຫ້ການປ່ຽນແປງເກີນອັດຕາສ່ວນຂອງປະເພດ.
        ///
        /// ໃຫ້ສັງເກດວ່ານີ້ແມ່ນ *ບໍ່* ຄືກັນກັບການລ້ຽວຊ້າຍ;RHS ຂອງຫໍ່ປ່ຽນຊ້າຍ-ຊ້າຍແມ່ນຖືກ ຈຳ ກັດໃນຂອບເຂດຂອງປະເພດ, ແທນທີ່ຈະຍ້າຍຈາກ LHS ທີ່ຖືກສົ່ງກັບຄືນສູ່ທ້າຍອື່ນໆ.
        /// ປະເພດເລກປະຖົມສົມບູນທັງ ໝົດ ປະຕິບັດ ໜ້າ ທີ່ [`rotate_left`](Self::rotate_left) ເຊິ່ງມັນອາດຈະເປັນສິ່ງທີ່ທ່ານຕ້ອງການແທນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // ຄວາມປອດໄພ: ການເຮັດ ໜ້າ ກາກໂດຍປະເພດຂອງປະເພດໃຫ້ແນ່ໃຈວ່າພວກເຮົາບໍ່ປ່ຽນແປງ
            // ອອກຈາກຂອບເຂດ
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-free bitwise shift-right;
        /// ໃຫ້ຜົນຜະລິດ `self >> mask(rhs)`, ບ່ອນທີ່ `mask` ກຳ ຈັດທ່ອນທີ່ມີລະບຽບສູງຂອງ `rhs` ເຊິ່ງຈະເຮັດໃຫ້ການປ່ຽນແປງເກີນອັດຕາສ່ວນຂອງປະເພດ.
        ///
        /// ໃຫ້ສັງເກດວ່ານີ້ແມ່ນ *ບໍ່* ຄືກັນກັບການລ້ຽວຂວາ;RHS ຂອງຫໍ່ປ່ຽນ-ຂວາແມ່ນຖືກ ຈຳ ກັດໃນຂອບເຂດຂອງປະເພດ, ແທນທີ່ຈະຖີ້ມອອກຈາກ LHS ຈະຖືກສົ່ງກັບຄືນສູ່ທ້າຍອື່ນໆ.
        /// ປະເພດເລກປະຖົມສົມບູນທັງ ໝົດ ປະຕິບັດ ໜ້າ ທີ່ [`rotate_right`](Self::rotate_right) ເຊິ່ງມັນອາດຈະເປັນສິ່ງທີ່ທ່ານຕ້ອງການແທນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // ຄວາມປອດໄພ: ການເຮັດ ໜ້າ ກາກໂດຍປະເພດຂອງປະເພດໃຫ້ແນ່ໃຈວ່າພວກເຮົາບໍ່ປ່ຽນແປງ
            // ອອກຈາກຂອບເຂດ
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// ການຂູດອັດຕະໂນມັດ (modular).
        /// ຄຳ ນວນ `self.pow(exp)`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // ນັບຕັ້ງແຕ່ exp!=0, ສຸດທ້າຍ exp ຕ້ອງແມ່ນ 1.
            // ຈັດການກັບໂຕເລກສຸດທ້າຍແຍກຕ່າງຫາກ, ເພາະວ່າການກອກພື້ນຖານຫລັງຈາກນັ້ນແມ່ນບໍ່ ຈຳ ເປັນແລະອາດຈະເຮັດໃຫ້ເກີດການໄຫຼວຽນແບບບໍ່ ຈຳ ເປັນ.
            //
            //
            acc.wrapping_mul(base)
        }

        /// ຄິດໄລ່ `self` + `rhs`
        ///
        /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຂອງເຄື່ອງພ້ອມດ້ວຍໃບໄມ້ປ່ອງທີ່ຊີ້ບອກວ່າການໄຫລຜ່ານເລກຄະນິດສາດຈະເກີດຂື້ນຫລືບໍ່.
        /// ຖ້າຫາກວ່າປະລິມານນ້ ຳ ເກີນຈະເກີດຂື້ນ, ມູນຄ່າຫໍ່ຈະຖືກສົ່ງຄືນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// ຄຳ ນວນ `self`, `rhs`
        ///
        /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຂອງການຫັກລົບພ້ອມກັບບູດທະວາຍທີ່ຊີ້ບອກວ່າການໄຫຼເກີນຂອງເລກຄະນິດສາດຈະເກີດຂື້ນຫຼືບໍ່.
        /// ຖ້າຫາກວ່າປະລິມານນ້ ຳ ເກີນຈະເກີດຂື້ນ, ມູນຄ່າຫໍ່ຈະຖືກສົ່ງຄືນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// ຄິດໄລ່ການຄູນຂອງ `self` ແລະ `rhs`.
        ///
        /// ກັບຄືນ tuple ຂອງຄູນພ້ອມກັບ boolean ທີ່ຊີ້ບອກວ່າການໄຫລຜ່ານເລກຄະນິດສາດຈະເກີດຂື້ນຫລືບໍ່.
        /// ຖ້າຫາກວ່າປະລິມານນ້ ຳ ເກີນຈະເກີດຂື້ນ, ມູນຄ່າຫໍ່ຈະຖືກສົ່ງຄືນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ກະລຸນາສັງເກດວ່າຕົວຢ່າງນີ້ຖືກແບ່ງປັນລະຫວ່າງປະເພດເລກເຕັມ.
        /// ເຊິ່ງອະທິບາຍວ່າເປັນຫຍັງ `u32` ຈຶ່ງຖືກ ນຳ ໃຊ້ຢູ່ນີ້.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// ຄິດໄລ່ຕົວເລກເມື່ອ `self` ແບ່ງອອກໂດຍ `rhs`.
        ///
        /// ກັບຄືນ tuple ຂອງ divisor ພ້ອມກັບ boolean ທີ່ຊີ້ບອກວ່າການໄຫລຜ່ານເລກຄະນິດສາດຈະເກີດຂື້ນ.
        /// ໃຫ້ສັງເກດວ່າ ສຳ ລັບເລກເຕັມທີ່ບໍ່ໄດ້ລົງທະບຽນລົ້ນບໍ່ເຄີຍເກີດຂື້ນ, ສະນັ້ນມູນຄ່າທີສອງແມ່ນສະເຫມີ `false`.
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// ຄິດໄລ່ອັດຕາສ່ວນຂອງພະແນກ Euclidean `self.div_euclid(rhs)`.
        ///
        /// ກັບຄືນ tuple ຂອງ divisor ພ້ອມກັບ boolean ທີ່ຊີ້ບອກວ່າການໄຫລຜ່ານເລກຄະນິດສາດຈະເກີດຂື້ນ.
        /// ໃຫ້ສັງເກດວ່າ ສຳ ລັບເລກເຕັມທີ່ບໍ່ໄດ້ລົງທະບຽນລົ້ນບໍ່ເຄີຍເກີດຂື້ນ, ສະນັ້ນມູນຄ່າທີສອງແມ່ນສະເຫມີ `false`.
        /// ເນື່ອງຈາກວ່າ, ສຳ ລັບເລກເຕັມໃນແງ່ບວກ, ທຸກ ຄຳ ນິຍາມທົ່ວໄປຂອງການແບ່ງສ່ວນແມ່ນເທົ່າກັນ, ນີ້ເທົ່າກັບ `self.overflowing_div(rhs)` ແທ້ໆ.
        ///
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// ຄຳ ນວນທີ່ເຫລືອເມື່ອ `self` ແບ່ງອອກໂດຍ `rhs`.
        ///
        /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຫຼັງຈາກທີ່ແບ່ງປັນພ້ອມກັບເຫຼົ້າທີ່ຊີ້ບອກວ່າການໄຫຼເຂົ້າເລກດ້ວຍເລກຄະນິດສາດຈະເກີດຂື້ນຫຼືບໍ່.
        /// ໃຫ້ສັງເກດວ່າ ສຳ ລັບເລກເຕັມທີ່ບໍ່ໄດ້ລົງທະບຽນລົ້ນບໍ່ເຄີຍເກີດຂື້ນ, ສະນັ້ນມູນຄ່າທີສອງແມ່ນສະເຫມີ `false`.
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// ຄຳ ນວນ `self.rem_euclid(rhs)` ທີ່ຍັງເຫຼືອເທົ່າກັບພະແນກ Euclidean.
        ///
        /// ສົ່ງກັບຄືນຮູບແບບຂອງໂມເດວຫຼັງຈາກທີ່ແບ່ງປັນພ້ອມກັບເຄື່ອງບູຕິກທີ່ຊີ້ບອກວ່າການໄຫລຜ່ານເລກຄະນິດສາດຈະເກີດຂື້ນຫຼືບໍ່.
        /// ໃຫ້ສັງເກດວ່າ ສຳ ລັບເລກເຕັມທີ່ບໍ່ໄດ້ລົງທະບຽນລົ້ນບໍ່ເຄີຍເກີດຂື້ນ, ສະນັ້ນມູນຄ່າທີສອງແມ່ນສະເຫມີ `false`.
        /// ເນື່ອງຈາກວ່າ, ສຳ ລັບເລກເຕັມໃນແງ່ບວກ, ທຸກ ຄຳ ນິຍາມທົ່ວໄປຂອງການແບ່ງສ່ວນແມ່ນເທົ່າກັນ, ການ ດຳ ເນີນງານນີ້ແມ່ນເທົ່າກັບ `self.overflowing_rem(rhs)` ແທ້ໆ.
        ///
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// ເຈລະຈາຕົນເອງໃນແບບທີ່ລົ້ນໄຫລ.
        ///
        /// ສົ່ງຄືນ `!self + 1` ໂດຍໃຊ້ການປະຕິບັດງານຫໍ່ເພື່ອກັບຄືນມູນຄ່າທີ່ສະແດງເຖິງຄວາມເສີຍເມີຍຂອງມູນຄ່າທີ່ບໍ່ໄດ້ເຊັນ.
        /// ໃຫ້ສັງເກດວ່າ ສຳ ລັບຄ່າທີ່ບໍ່ໄດ້ລົງນາມໃນແງ່ບວກກໍ່ເກີດຂື້ນເລື້ອຍໆ, ແຕ່ການລົບກວນ 0 ບໍ່ໄດ້ລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// ປ່ຽນດ້ວຍຕົນເອງເບື້ອງຊ້າຍໂດຍ x00X bits.
        ///
        /// ກັບຄືນ tuple ຂອງຮຸ່ນປ່ຽນດ້ວຍຕົນເອງພ້ອມກັບ boolean ທີ່ຊີ້ບອກວ່າມູນຄ່າການປ່ຽນແປງທີ່ໃຫຍ່ກວ່າຫລືເທົ່າກັບ ຈຳ ນວນບິດ.
        /// ຖ້າມູນຄ່າການປ່ຽນແປງໃຫຍ່ເກີນໄປ, ຫຼັງຈາກນັ້ນມູນຄ່າຈະຖືກປິດບັງ (N-1) ບ່ອນທີ່ N ແມ່ນ ຈຳ ນວນບິດ, ແລະຫຼັງຈາກນັ້ນຄ່ານີ້ຈະຖືກ ນຳ ໃຊ້ເພື່ອ ດຳ ເນີນການປ່ຽນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// ປ່ຽນດ້ວຍຕົນເອງໂດຍ `rhs` bits.
        ///
        /// ກັບຄືນ tuple ຂອງຮຸ່ນປ່ຽນດ້ວຍຕົນເອງພ້ອມກັບ boolean ທີ່ຊີ້ບອກວ່າມູນຄ່າການປ່ຽນແປງທີ່ໃຫຍ່ກວ່າຫລືເທົ່າກັບ ຈຳ ນວນບິດ.
        /// ຖ້າມູນຄ່າການປ່ຽນແປງໃຫຍ່ເກີນໄປ, ຫຼັງຈາກນັ້ນມູນຄ່າຈະຖືກປິດບັງ (N-1) ບ່ອນທີ່ N ແມ່ນ ຈຳ ນວນບິດ, ແລະຫຼັງຈາກນັ້ນຄ່ານີ້ຈະຖືກ ນຳ ໃຊ້ເພື່ອ ດຳ ເນີນການປ່ຽນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// ຍົກລະດັບຕົນເອງໃຫ້ກັບພະລັງງານຂອງ `exp`, ການນໍາໃຊ້ການຂະຫຍາຍຕົວໂດຍການກວາດ.
        ///
        /// ກັບຄືນຄ່າຂອງການອອກສຽງທີ່ສົມເຫດສົມຜົນພ້ອມກັບ bool ທີ່ບົ່ງບອກວ່າການໄຫລວຽນຂອງມັນເກີດຂື້ນຫລືບໍ່.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, ຄວາມຈິງ));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // ພື້ນທີ່ຂູດ ສຳ ລັບການເກັບຮັກສາຜົນໄດ້ຮັບທີ່ລົ້ນລົ້ນ _mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // ນັບຕັ້ງແຕ່ exp!=0, ສຸດທ້າຍ exp ຕ້ອງແມ່ນ 1.
            // ຈັດການກັບໂຕເລກສຸດທ້າຍແຍກຕ່າງຫາກ, ເພາະວ່າການກອກພື້ນຖານຫລັງຈາກນັ້ນແມ່ນບໍ່ ຈຳ ເປັນແລະອາດຈະເຮັດໃຫ້ເກີດການໄຫຼວຽນແບບບໍ່ ຈຳ ເປັນ.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// ຍົກລະດັບຕົນເອງໃຫ້ກັບພະລັງງານຂອງ `exp`, ການນໍາໃຊ້ການຂະຫຍາຍຕົວໂດຍການກວາດ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // ນັບຕັ້ງແຕ່ exp!=0, ສຸດທ້າຍ exp ຕ້ອງແມ່ນ 1.
            // ຈັດການກັບໂຕເລກສຸດທ້າຍແຍກຕ່າງຫາກ, ເພາະວ່າການກອກພື້ນຖານຫລັງຈາກນັ້ນແມ່ນບໍ່ ຈຳ ເປັນແລະອາດຈະເຮັດໃຫ້ເກີດການໄຫຼວຽນແບບບໍ່ ຈຳ ເປັນ.
            //
            //
            acc * base
        }

        /// ປະຕິບັດການແບ່ງປັນ Euclidean.
        ///
        /// ເນື່ອງຈາກວ່າ, ສຳ ລັບເລກເຕັມໃນແງ່ບວກ, ທຸກ ຄຳ ນິຍາມທົ່ວໄປຂອງການແບ່ງສ່ວນແມ່ນເທົ່າກັນ, ນີ້ເທົ່າກັບ `self / rhs` ແທ້ໆ.
        ///
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// ຄຳ ນວນທີ່ເຫລືອທີ່ ໜ້ອຍ ທີ່ສຸດຂອງ `self (mod rhs)`.
        ///
        /// ເນື່ອງຈາກວ່າ, ສຳ ລັບເລກເຕັມໃນແງ່ບວກ, ທຸກ ຄຳ ນິຍາມທົ່ວໄປຂອງການແບ່ງສ່ວນແມ່ນເທົ່າກັນ, ນີ້ເທົ່າກັບ `self % rhs` ແທ້ໆ.
        ///
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// ສົ່ງຄືນ `true` ຖ້າແລະຖ້າ `self == 2^k` ສຳ ລັບບາງ `k`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // ສົ່ງຄືນ ໜຶ່ງ ຕ່ ຳ ກວ່າ ກຳ ລັງຕໍ່ໄປຂອງສອງ.
        // (ສຳ ລັບພະລັງງານຕໍ່ໄປຂອງ 8u8 ຂອງສອງແມ່ນ 8u8 ແລະ ສຳ ລັບ 6u8 ແມ່ນ 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // ວິທີການນີ້ບໍ່ສາມາດລົ້ນໄດ້, ຄືກັບກໍລະນີ `next_power_of_two` ລົ້ນມັນແທນທີ່ຈະກັບຄືນມູນຄ່າສູງສຸດຂອງປະເພດ, ແລະສາມາດສົ່ງຄືນ 0 ສຳ ລັບ 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // ຄວາມປອດໄພ: ຍ້ອນວ່າ `p > 0`, ມັນບໍ່ສາມາດປະກອບມີສູນສູນຊັ້ນ ນຳ ທັງ ໝົດ.
            // ນັ້ນ ໝາຍ ຄວາມວ່າການປ່ຽນແປງແມ່ນຢູ່ໃນຂອບເຂດສະ ເໝີ, ແລະບາງ ໜ່ວຍ ປະມວນຜົນ (ເຊັ່ນວ່າ intel pre-haswell) ມີ ctlz ທີ່ມີປະສິດທິພາບຫຼາຍຂື້ນເມື່ອການໂຕ້ຖຽງບໍ່ແມ່ນສູນ.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// ສົ່ງຄືນ ກຳ ລັງນ້ອຍທີ່ສຸດຂອງສອງຂະ ໜາດ ໃຫຍ່ກ່ວາຫຼືເທົ່າກັບ `self`.
        ///
        /// ໃນເວລາທີ່ມູນຄ່າການກັບຄືນມາ (ເຊັ່ນ, `self > (1 << (N-1))` ສໍາລັບປະເພດ `uN`), ມັນ panics ໃນຮູບແບບ debug ແລະມູນຄ່າການກັບຄືນແມ່ນຖືກຫໍ່ໄປ 0 ໃນຮູບແບບການປ່ອຍ (ສະຖານະການດຽວໃນວິທີການທີ່ສາມາດກັບຄືນ 0).
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// ສົ່ງຄືນ ກຳ ລັງນ້ອຍທີ່ສຸດຂອງສອງຂະ ໜາດ ໃຫຍ່ກ່ວາຫຼືເທົ່າກັບ `n`.
        /// ຖ້າພະລັງງານຕໍ່ໄປຂອງສອງແມ່ນໃຫຍ່ກ່ວາມູນຄ່າສູງສຸດຂອງປະເພດ, `None` ຈະຖືກສົ່ງຄືນ, ຖ້າບໍ່ດັ່ງນັ້ນພະລັງງານຂອງສອງຈະຖືກຫໍ່ດ້ວຍ `Some`.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// ສົ່ງຄືນ ກຳ ລັງນ້ອຍທີ່ສຸດຂອງສອງຂະ ໜາດ ໃຫຍ່ກ່ວາຫຼືເທົ່າກັບ `n`.
        /// ຖ້າພະລັງງານຕໍ່ໄປຂອງສອງແມ່ນໃຫຍ່ກ່ວາມູນຄ່າສູງສຸດຂອງປະເພດ, ມູນຄ່າການກັບຄືນຈະຖືກຫໍ່ໃສ່ `0`.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// ສົ່ງຄືນການສະແດງຄວາມຊົງ ຈຳ ຂອງເລກເຕັມນີ້ເປັນຂບວນໄບຕ໌ໃນ (network) byte ໃຫຍ່.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// ສົ່ງຄືນການສະແດງຄວາມຊົງ ຈຳ ຂອງເລກເຕັມນີ້ເປັນຂບວນໄບຕ໌ໃນ ລຳ ດັບໄບຕີ້.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// ສົ່ງຄືນການສະແດງຄວາມຊົງ ຈຳ ຂອງເລກເຕັມນີ້ເປັນຂບວນໄບຕ໌ຕາມ ລຳ ດັບໄບຕ໌ພື້ນເມືອງ.
        ///
        /// ໃນຂະນະທີ່ຄວາມນິຍົມຂອງພື້ນເມືອງຂອງເວທີເປົ້າ ໝາຍ ຖືກໃຊ້, ລະຫັດແບບພະກະພາຄວນໃຊ້ [`to_be_bytes`] ຫຼື [`to_le_bytes`], ຕາມຄວາມ ເໝາະ ສົມ, ແທນ.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, ຖ້າ cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } ອີກ {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // ຄວາມປອດໄພ: ສຽງດີເພາະວ່າຕົວເລກເຕັມແມ່ນຮູບແບບເກົ່າແກ່ ທຳ ມະດາສະນັ້ນພວກເຮົາສາມາດເຮັດໄດ້ຕະຫຼອດເວລາ
        // transmute ໃຫ້ເຂົາເຈົ້າກັບຂບວນຂອງໄບຕ໌
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // ຄວາມປອດໄພ: ເລກເຕັມແມ່ນຮູບແບບເກົ່າແກ່ ທຳ ມະດາສະນັ້ນພວກເຮົາສາມາດສົ່ງສັນຍານເຫຼົ່ານັ້ນໄປສະ ເໝີ
            // ຂບວນຂອງໄບຕ໌
            unsafe { mem::transmute(self) }
        }

        /// ສົ່ງຄືນການສະແດງຄວາມຊົງ ຈຳ ຂອງເລກເຕັມນີ້ເປັນຂບວນໄບຕ໌ຕາມ ລຳ ດັບໄບຕ໌ພື້ນເມືອງ.
        ///
        ///
        /// [`to_ne_bytes`] ຄວນຈະເປັນທີ່ຕ້ອງການໃນໄລຍະນີ້ເມື່ອເປັນໄປໄດ້.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// let bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, ຖ້າ cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } ອີກ {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // ຄວາມປອດໄພ: ເລກເຕັມແມ່ນຮູບແບບເກົ່າແກ່ ທຳ ມະດາສະນັ້ນພວກເຮົາສາມາດສົ່ງສັນຍານເຫຼົ່ານັ້ນໄປສະ ເໝີ
            // ຂບວນຂອງໄບຕ໌
            unsafe { &*(self as *const Self as *const _) }
        }

        /// ສ້າງມູນຄ່າເລກເຕັມ endian ແບບພື້ນເມືອງຈາກການເປັນຕົວແທນຂອງມັນເປັນຂບວນ byte ໃນ endian ໃຫຍ່.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// ໃຊ້ std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ວັດສະດຸປ້ອນ=ສ່ວນທີ່ເຫຼືອ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// ສ້າງມູນຄ່າເລກເຕັມ endian ແບບພື້ນເມືອງຈາກການເປັນຕົວແທນຂອງມັນເປັນຂບວນ byte ໃນ endian ພຽງເລັກນ້ອຍ.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// ໃຊ້ std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ວັດສະດຸປ້ອນ=ສ່ວນທີ່ເຫຼືອ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// ສ້າງມູນຄ່າເລກເຕັມ endian ແບບພື້ນເມືອງຈາກການເປັນຕົວແທນຂອງຄວາມຊົງ ຈຳ ຂອງມັນເປັນຂບວນ byte ໃນ endianness ພື້ນເມືອງ.
        ///
        /// ໃນຂະນະທີ່ຄວາມນິຍົມຂອງພື້ນເມືອງຂອງເວທີເປົ້າ ໝາຍ ຖືກໃຊ້, ລະຫັດແບບເຄື່ອນທີ່ອາດຈະຕ້ອງການໃຊ້ [`from_be_bytes`] ຫຼື [`from_le_bytes`], ຕາມຄວາມ ເໝາະ ສົມແທນ.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } ອີກ {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// ໃຊ້ std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ວັດສະດຸປ້ອນ=ສ່ວນທີ່ເຫຼືອ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // ຄວາມປອດໄພ: ສຽງດີເພາະວ່າຕົວເລກເຕັມແມ່ນຮູບແບບເກົ່າແກ່ ທຳ ມະດາສະນັ້ນພວກເຮົາສາມາດເຮັດໄດ້ຕະຫຼອດເວລາ
        // transmute ກັບພວກເຂົາ
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // ຄວາມປອດໄພ: ເລກເຕັມແມ່ນຮູບແບບເກົ່າແກ່ ທຳ ມະດາສະນັ້ນພວກເຮົາສາມາດສົ່ງຕໍ່ໃຫ້ພວກເຂົາໄດ້ສະ ເໝີ
            unsafe { mem::transmute(bytes) }
        }

        /// ລະຫັດ ໃໝ່ ຄວນໃຊ້
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// ສົ່ງຄ່າທີ່ນ້ອຍທີ່ສຸດທີ່ສາມາດເປັນຕົວແທນໂດຍປະເພດເລກນີ້.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// ລະຫັດ ໃໝ່ ຄວນໃຊ້
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// ສົ່ງຄືນມູນຄ່າທີ່ໃຫຍ່ທີ່ສຸດທີ່ສາມາດເປັນຕົວແທນໂດຍປະເພດເລກນີ້.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}