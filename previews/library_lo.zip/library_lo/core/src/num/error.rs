//! ປະເພດຂໍ້ຜິດພາດ ສຳ ລັບການປ່ຽນເປັນປະເພດ ສຳ ຄັນ.

use crate::convert::Infallible;
use crate::fmt;

/// ປະເພດຂໍ້ຜິດພາດໄດ້ກັບຄືນເມື່ອການກວດສອບການປ່ຽນປະເພດແບບປະສົມປະສານລົ້ມເຫລວ
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // ຈັບຄູ່ກັນແທນທີ່ຈະບັງຄັບໃຫ້ແນ່ໃຈວ່າລະຫັດເຊັ່ນ `From<Infallible> for TryFromIntError` ຂ້າງເທິງຈະເຮັດວຽກໄດ້ເມື່ອ `Infallible` ກາຍເປັນນາມແຝງຂອງ `!`.
        //
        //
        match never {}
    }
}

/// ຂໍ້ຜິດພາດທີ່ສາມາດສົ່ງຄືນໄດ້ໃນເວລາທີ່ວິເຄາະເລກເຕັມ.
///
/// ຂໍ້ຜິດພາດນີ້ຖືກ ນຳ ໃຊ້ເປັນປະເພດຂໍ້ຜິດພາດ ສຳ ລັບ ໜ້າ ທີ່ `from_str_radix()` ກ່ຽວກັບປະເພດເລກປະຖົມນິຖານເຊັ່ນ [`i8::from_str_radix`].
///
/// # ສາເຫດທີ່ອາດເກີດຂື້ນ
///
/// ໃນບັນດາສາເຫດອື່ນໆ, `ParseIntError` ສາມາດຖີ້ມໄດ້ເນື່ອງຈາກການ ນຳ ຫລືລາກຫວ່າງຢູ່ໃນເຊືອກຕົວຢ່າງ, ເມື່ອມັນໄດ້ຮັບຈາກວັດສະດຸປ້ອນມາດຕະຖານ.
///
/// ການໃຊ້ວິທີ [`str::trim()`] ຮັບປະກັນວ່າບໍ່ມີບ່ອນຫວ່າງກ່ອນທີ່ຈະວິເຄາະ.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum ເກັບຮັກສາປະເພດຕ່າງໆຂອງຂໍ້ຜິດພາດທີ່ສາມາດເຮັດໃຫ້ການແຍກຕົວເລກສ່ວນຕົວລົ້ມເຫລວ.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// ມູນຄ່າທີ່ຖືກວິເຄາະແມ່ນຫວ່າງເປົ່າ.
    ///
    /// ໃນບັນດາສາເຫດອື່ນໆ, ຕົວແປນີ້ຈະຖືກສ້າງຂຶ້ນໃນເວລາທີ່ແຍກສາຍເປົ່າ.
    Empty,
    /// ມີຕົວເລກທີ່ບໍ່ຖືກຕ້ອງໃນສະພາບການຂອງມັນ.
    ///
    /// ໃນບັນດາສາເຫດອື່ນໆ, ຕົວແປນີ້ຈະຖືກສ້າງຂຶ້ນເມື່ອແຍກສາຍທີ່ປະກອບດ້ວຍ char ທີ່ບໍ່ແມ່ນ ASCII.
    ///
    /// ຕົວປ່ຽນແປງນີ້ກໍ່ຖືກສ້າງຂື້ນໃນເວລາທີ່ `+` ຫຼື `-` ຖືກວາງຢູ່ໃນສາຍບໍ່ວ່າຈະດ້ວຍຕົວມັນເອງຫຼືຢູ່ເຄິ່ງກາງຂອງຕົວເລກ.
    ///
    ///
    InvalidDigit,
    /// ເລກເຕັມແມ່ນໃຫຍ່ເກີນໄປທີ່ຈະເກັບໄວ້ໃນປະເພດເລກເປົ້າ ໝາຍ.
    PosOverflow,
    /// ເລກເຕັມແມ່ນນ້ອຍເກີນໄປທີ່ຈະເກັບໄວ້ໃນປະເພດເລກເປົ້າ ໝາຍ.
    NegOverflow,
    /// ມູນຄ່າແມ່ນສູນ
    ///
    /// ຕົວປ່ຽນແປງນີ້ຈະຖືກປ່ອຍອອກມາເມື່ອສາຍເຊັກວິເຄາະມີມູນຄ່າສູນເຊິ່ງຈະຜິດກົດ ໝາຍ ສຳ ລັບປະເພດທີ່ບໍ່ແມ່ນສູນ.
    ///
    Zero,
}

impl ParseIntError {
    /// ຜົນໄດ້ຮັບສາເຫດລະອຽດຂອງການແຍກຕົວເລກທີ່ລົ້ມເຫລວ.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}