macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// ມູນຄ່ານ້ອຍທີ່ສຸດທີ່ສາມາດເປັນຕົວແທນໂດຍປະເພດເລກນີ້.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// ມູນຄ່າທີ່ໃຫຍ່ທີ່ສຸດທີ່ສາມາດເປັນຕົວແທນໂດຍປະເພດເລກນີ້.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// ຂະ ໜາດ ຂອງປະເພດເລກເຕັມນີ້ເປັນບິດ.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// ແປງສ່ວນເຊືອກໃນຖານໃຫ້ເປັນເລກເຕັມ.
        ///
        /// ເຊືອກຄາດວ່າຈະເປັນສັນຍາລັກ `+` ຫຼື `-` ທີ່ຕິດຕາມມາດ້ວຍຕົວເລກ.
        /// ການ ນຳ ພາແລະຕິດຕາມຊ່ອງຫວ່າງເປັນຕົວແທນຂອງຂໍ້ຜິດພາດ.
        /// ຕົວເລກແມ່ນຊຸດຍ່ອຍຂອງຕົວອັກສອນເຫຼົ່ານີ້, ຂື້ນກັບ `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ panics ຖ້າ `radix` ບໍ່ຢູ່ໃນຂອບເຂດແຕ່ 2 ເຖິງ 36.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// ສົ່ງຄືນ ຈຳ ນວນໂຕທີ່ຢູ່ໃນຕົວແທນຖານສອງຂອງ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// ສົ່ງ ຈຳ ນວນເລກສູນໃນຕົວແທນຖານສອງຂອງ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// ສົ່ງ ຈຳ ນວນເລກສູນ ນຳ ໜ້າ ໃນຕົວແທນຖານສອງຂອງ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// ສົ່ງ ຈຳ ນວນເລກສູນສູນໃນຕົວແທນຖານສອງຂອງ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// ສົ່ງຄືນ ຈຳ ນວນໂຕ ນຳ ທີ່ຢູ່ໃນຕົວແທນຖານສອງຂອງ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// ສົ່ງຄືນ ຈຳ ນວນຂອງການຕິດຕາມໃນຕົວແທນຖານສອງຂອງ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// ປ່ຽນບິດໄປທາງຊ້າຍດ້ວຍ ຈຳ ນວນເງິນທີ່ລະບຸ, `n`, ຫໍ່ສ່ວນທີ່ຕັດເປັນທ່ອນໄປຫາສຸດທ້າຍຂອງ ຈຳ ນວນຜົນທີ່ໄດ້ຮັບ.
        ///
        ///
        /// ກະລຸນາສັງເກດວ່ານີ້ບໍ່ແມ່ນການເຮັດວຽກດຽວກັນກັບຜູ້ປະຕິບັດການຍ້າຍ `<<`!
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// ປ່ຽນບິດໄປທາງຂວາໂດຍ ຈຳ ນວນເງິນທີ່ ກຳ ນົດ, `n`, ຫໍ່ສ່ວນທີ່ຖືກຕັດໃຫ້ເປັນທ່ອນເລີ່ມຕົ້ນຂອງເລກເຕັມທີ່ໄດ້ຮັບ.
        ///
        ///
        /// ກະລຸນາສັງເກດວ່ານີ້ບໍ່ແມ່ນການເຮັດວຽກດຽວກັນກັບຜູ້ປະຕິບັດການຍ້າຍ `>>`!
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// ປີ້ນກັບກັນຕາມ ລຳ ດັບຂອງໄບ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ໃຫ້ m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// ປີ້ນກັບກັນຕາມ ລຳ ດັບຂອງບິດໃນເລກເຕັມ.
        /// ບິດທີ່ ສຳ ຄັນ ໜ້ອຍ ທີ່ສຸດກາຍເປັນບິດທີ່ ສຳ ຄັນທີ່ສຸດ, ບິດທີ່ ສຳ ຄັນທີ່ສອງກາຍເປັນບິດທີ່ ສຳ ຄັນທີ່ສຸດ, ເປັນຕົ້ນ
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// ໃຫ້ m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// ປ່ຽນເລກເຕັມຈາກ endian ໃຫຍ່ໄປສູ່ຄວາມຍືນຍົງຂອງເປົ້າ ໝາຍ.
        ///
        /// ກ່ຽວກັບ endian ໃຫຍ່ນີ້ແມ່ນບໍ່ມີ.ໃນພື້ນທີ່ endian ພຽງເລັກນ້ອຍແມ່ນໄດ້ຖືກແລກປ່ຽນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ຖ້າ cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } ອີກ {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// ປ່ຽນເລກເຕັມຈາກ endian ພຽງເລັກນ້ອຍກັບຄວາມຍືນຍົງຂອງເປົ້າ ໝາຍ.
        ///
        /// ກ່ຽວກັບ endian ພຽງເລັກນ້ອຍນີ້ແມ່ນບໍ່ມີ.ກ່ຽວກັບ endian ໃຫຍ່ໄບຕ໌ຖືກປ່ຽນໄປ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ຖ້າ cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } ອີກ {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// ແປງ `self` ກັບ endian ໃຫຍ່ຈາກຄວາມອົດທົນຂອງເປົ້າ ໝາຍ.
        ///
        /// ກ່ຽວກັບ endian ໃຫຍ່ນີ້ແມ່ນບໍ່ມີ.ໃນພື້ນທີ່ endian ພຽງເລັກນ້ອຍແມ່ນໄດ້ຖືກແລກປ່ຽນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ຖ້າ cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } ອີກ { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ຫຼືບໍ່ເປັນ?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// ແປງ `self` ກັບ endian ພຽງເລັກນ້ອຍຈາກຄວາມອົດທົນຂອງເປົ້າຫມາຍ.
        ///
        /// ກ່ຽວກັບ endian ພຽງເລັກນ້ອຍນີ້ແມ່ນບໍ່ມີ.ກ່ຽວກັບ endian ໃຫຍ່ໄບຕ໌ຖືກປ່ຽນໄປ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ຖ້າ cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } ອີກ { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// ກວດສອບການເພີ່ມເລກເຕັມ.
        /// ຄຳ ນວນ `self + rhs`, ການກັບຄືນ `None` ຖ້າຫາກວ່າເກີດມີການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ການເພີ່ມ ຈຳ ນວນເຕັມທີ່ບໍ່ຖືກເລືອກຄຳ ສັບ `self + rhs`, ສົມມຸດວ່າການລົ້ນບໍ່ສາມາດເກີດຂື້ນໄດ້.
        /// ຜົນໄດ້ຮັບນີ້ຈະເຮັດໃຫ້ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດເວລາ
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// ການຫັກລົບເລກເຊັກ.
        /// ຄຳ ນວນ `self - rhs`, ການກັບຄືນ `None` ຖ້າຫາກວ່າເກີດມີການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ການຫັກລົບ ຈຳ ນວນທີ່ບໍ່ຖືກຄັດເລືອກ.ຄຳ ສັບ `self - rhs`, ສົມມຸດວ່າການລົ້ນບໍ່ສາມາດເກີດຂື້ນໄດ້.
        /// ຜົນໄດ້ຮັບນີ້ຈະເຮັດໃຫ້ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດເວລາ
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// ການກວດສອບເລກທະວີຄູນ.
        /// ຄຳ ນວນ `self * rhs`, ການກັບຄືນ `None` ຖ້າຫາກວ່າເກີດມີການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ຕົວເລກທະວີຄູນແບບບໍ່ນັບ.ຄຳ ສັບ `self * rhs`, ສົມມຸດວ່າການລົ້ນບໍ່ສາມາດເກີດຂື້ນໄດ້.
        /// ຜົນໄດ້ຮັບນີ້ຈະເຮັດໃຫ້ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດເວລາ
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// ກວດກາພະແນກເລກເຕັມ.
        /// ຄຳ ນວນ `self / rhs`, ການກັບຄືນ `None` ຖ້າ `rhs == 0` ຫຼືການແບ່ງສ່ວນສົ່ງຜົນໃຫ້ມີການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // ຄວາມປອດໄພ: div ໂດຍສູນແລະໂດຍ INT_MIN ໄດ້ຖືກກວດເບິ່ງຢູ່ຂ້າງເທິງ
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// ກວດກາພະແນກ Euclidean.
        /// ຄຳ ນວນ `self.div_euclid(rhs)`, ການກັບຄືນ `None` ຖ້າ `rhs == 0` ຫຼືການແບ່ງສ່ວນສົ່ງຜົນໃຫ້ມີການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// ການກວດສອບສ່ວນທີ່ເຫຼືອຂອງເລກເຕັມ.
        /// ຄຳ ນວນ `self % rhs`, ການກັບຄືນ `None` ຖ້າ `rhs == 0` ຫຼືການແບ່ງສ່ວນສົ່ງຜົນໃຫ້ມີການລົ້ນ.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // ຄວາມປອດໄພ: div ໂດຍສູນແລະໂດຍ INT_MIN ໄດ້ຖືກກວດເບິ່ງຢູ່ຂ້າງເທິງ
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// ສ່ວນທີ່ເຫຼືອແມ່ນກວດກາ Euclidean.
        /// ຄຳ ນວນ `self.rem_euclid(rhs)`, ການກັບຄືນ `None` ຖ້າ `rhs == 0` ຫຼືການແບ່ງສ່ວນສົ່ງຜົນໃຫ້ມີການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// ການກວດກາຄວາມເສີຍເມີຍ.
        /// ຄຳ ນວນ `-self`, ການກັບຄືນ `None` ຖ້າ `self == MIN`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ເຊັກປ່ຽນຊ້າຍ.
        /// ຄຳ ນວນ `self << rhs`, ການກັບຄືນ `None` ຖ້າ `rhs` ໃຫຍ່ກວ່າຫຼືເທົ່າກັບ ຈຳ ນວນບິດໃນ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ເຊັກປ່ຽນທາງຂວາ.
        /// ຄຳ ນວນ `self >> rhs`, ການກັບຄືນ `None` ຖ້າ `rhs` ໃຫຍ່ກວ່າຫຼືເທົ່າກັບ ຈຳ ນວນບິດໃນ `self`.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ກວດກາມູນຄ່າຢ່າງແທ້ຈິງ.
        /// ຄຳ ນວນ `self.abs()`, ການກັບຄືນ `None` ຖ້າ `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// ການກວດສອບການເລັ່ງລັດ.
        /// ຄຳ ນວນ `self.pow(exp)`, ການກັບຄືນ `None` ຖ້າຫາກວ່າເກີດມີການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // ນັບຕັ້ງແຕ່ exp!=0, ສຸດທ້າຍ exp ຕ້ອງແມ່ນ 1.
            // ຈັດການກັບໂຕເລກສຸດທ້າຍແຍກຕ່າງຫາກ, ເພາະວ່າການກອກພື້ນຖານຫລັງຈາກນັ້ນແມ່ນບໍ່ ຈຳ ເປັນແລະອາດຈະເຮັດໃຫ້ເກີດການໄຫຼວຽນແບບບໍ່ ຈຳ ເປັນ.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// ການເພີ່ມເຕີມເຕັມຂອງ saturating.
        /// ຄອມພິວເຕີ້ `self + rhs`, ອີ່ມຕົວຢູ່ຂອບເຂດຕົວເລກແທນທີ່ຈະລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// ການຫັກລົບ ຈຳ ນວນອີ່ມຕົວ.
        /// ຄອມພິວເຕີ້ `self - rhs`, ອີ່ມຕົວຢູ່ຂອບເຂດຕົວເລກແທນທີ່ຈະລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// ຄວາມບໍ່ພໍໃຈກັບຕົວເລກອີ່ມໃຈ.
        /// ຄຳ ນວນ `-self`, ການກັບຄືນ `MAX` ຖ້າ `self == MIN` ແທນທີ່ຈະລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// ຄວາມອີ່ມໃຈກັບຄຸນຄ່າຢ່າງແທ້ຈິງ.
        /// ຄຳ ນວນ `self.abs()`, ການກັບຄືນ `MAX` ຖ້າ `self == MIN` ແທນທີ່ຈະລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// ການຄູນເລກທະວີຄູນ.
        /// ຄອມພິວເຕີ້ `self * rhs`, ອີ່ມຕົວຢູ່ຂອບເຂດຕົວເລກແທນທີ່ຈະລົ້ນ.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// ການສະແດງອອກທາງອິນເຕີເນເຊິນບວກ.
        /// ຄອມພິວເຕີ້ `self.pow(exp)`, ອີ່ມຕົວຢູ່ຂອບເຂດຕົວເລກແທນທີ່ຈະລົ້ນ.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// ການຫໍ່ເອົາ (modular) ເພີ່ມ.
        /// ຄຳ ນວນ `self + rhs`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// ການຫັກລົບ (modular).
        /// ຄຳ ນວນ `self - rhs`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// ຫໍ່ຕົວຄູນ (modular).
        /// ຄຳ ນວນ `self * rhs`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// ການຫໍ່ພະແນກ (modular).ຄຳ ນວນ `self / rhs`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// ກໍລະນີດຽວທີ່ການຫໍ່ດັ່ງກ່າວສາມາດເກີດຂື້ນໄດ້ແມ່ນເມື່ອ ໜຶ່ງ ແຍກ `MIN / -1` ໃສ່ປະເພດທີ່ຖືກເຊັນ (ບ່ອນທີ່ `MIN` ແມ່ນມູນຄ່າ ໜ້ອຍ ທີ່ສຸດ ສຳ ລັບຊະນິດ);ນີ້ເທົ່າກັບ `-MIN`, ມູນຄ່າໃນທາງບວກທີ່ໃຫຍ່ເກີນໄປທີ່ຈະເປັນຕົວແທນໃນປະເພດ.
        /// ໃນກໍລະນີດັ່ງກ່າວ, ຫນ້າທີ່ນີ້ຈະສົ່ງຄືນ `MIN` ຕົວມັນເອງ.
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// ຫໍ່ພະແນກ Euclidean.
        /// ຄຳ ນວນ `self.div_euclid(rhs)`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// ການໃສ່ຫໍ່ຈະເກີດຂື້ນໃນ `MIN / -1` ເທົ່ານັ້ນໃນປະເພດທີ່ມີລາຍເຊັນ (ບ່ອນທີ່ `MIN` ແມ່ນມູນຄ່າ ໜ້ອຍ ທີ່ສຸດ ສຳ ລັບຊະນິດ).
        /// ນີ້ເທົ່າກັບ `-MIN`, ມູນຄ່າໃນທາງບວກທີ່ໃຫຍ່ເກີນໄປທີ່ຈະເປັນຕົວແທນໃນປະເພດ.
        /// ໃນກໍລະນີນີ້, ວິທີການນີ້ຈະກັບຄືນ `MIN` ຕົວມັນເອງ.
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// ຫໍ່ສ່ວນທີ່ເຫຼືອ (modular).ຄຳ ນວນ `self % rhs`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// ຫໍ່ອ້ອມຮອບຕົວຈິງບໍ່ເຄີຍເກີດຂື້ນທາງຄະນິດສາດ;ປອມປະຕິບັດເຮັດໃຫ້ `x % y` ບໍ່ຖືກຕ້ອງ ສຳ ລັບ `MIN / -1` ໃນປະເພດທີ່ມີລາຍເຊັນ (ບ່ອນທີ່ `MIN` ແມ່ນມູນຄ່າ ໜ້ອຍ ທີ່ສຸດ).
        ///
        /// ໃນກໍລະນີດັ່ງກ່າວ, ຟັງຊັນນີ້ຈະກັບຄືນ `0`.
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// ຫໍ່ສ່ວນທີ່ເຫຼືອ Euclidean.ຄຳ ນວນ `self.rem_euclid(rhs)`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// ການໃສ່ຫໍ່ຈະເກີດຂື້ນໃນ `MIN % -1` ເທົ່ານັ້ນໃນປະເພດທີ່ມີລາຍເຊັນ (ບ່ອນທີ່ `MIN` ແມ່ນມູນຄ່າ ໜ້ອຍ ທີ່ສຸດ ສຳ ລັບຊະນິດ).
        /// ໃນກໍລະນີນີ້, ວິທີການນີ້ຈະກັບຄືນ 0.
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// ການວຸ້ນວາຍຂອງ (modular).ຄຳ ນວນ `-self`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// ກໍລະນີດຽວທີ່ການຫໍ່ດັ່ງກ່າວສາມາດເກີດຂື້ນໄດ້ກໍ່ຄືເມື່ອຄົນ ໜຶ່ງ ປະຕິເສດ `MIN` ໃນປະເພດທີ່ມີລາຍເຊັນ (ບ່ອນທີ່ `MIN` ແມ່ນມູນຄ່າ ໜ້ອຍ ທີ່ສຸດ ສຳ ລັບຊະນິດ);ນີ້ແມ່ນຄຸນຄ່າໃນທາງບວກທີ່ໃຫຍ່ເກີນໄປທີ່ຈະເປັນຕົວແທນໃນປະເພດ.
        /// ໃນກໍລະນີດັ່ງກ່າວ, ຫນ້າທີ່ນີ້ຈະສົ່ງຄືນ `MIN` ຕົວມັນເອງ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-free bitwise shift-left;ໃຫ້ຜົນຜະລິດ `self << mask(rhs)`, ບ່ອນທີ່ `mask` ກຳ ຈັດທ່ອນທີ່ມີລະບຽບສູງຂອງ `rhs` ເຊິ່ງຈະເຮັດໃຫ້ການປ່ຽນແປງເກີນອັດຕາສ່ວນຂອງປະເພດ.
        ///
        /// ໃຫ້ສັງເກດວ່ານີ້ແມ່ນ *ບໍ່* ຄືກັນກັບການລ້ຽວຊ້າຍ;RHS ຂອງຫໍ່ປ່ຽນຊ້າຍ-ຊ້າຍແມ່ນຖືກ ຈຳ ກັດໃນຂອບເຂດຂອງປະເພດ, ແທນທີ່ຈະຍ້າຍຈາກ LHS ທີ່ຖືກສົ່ງກັບຄືນສູ່ທ້າຍອື່ນໆ.
        ///
        /// ປະເພດເລກປະຖົມສົມບູນທັງ ໝົດ ປະຕິບັດ ໜ້າ ທີ່ [`rotate_left`](Self::rotate_left) ເຊິ່ງມັນອາດຈະເປັນສິ່ງທີ່ທ່ານຕ້ອງການແທນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // ຄວາມປອດໄພ: ການເຮັດ ໜ້າ ກາກໂດຍປະເພດຂອງປະເພດໃຫ້ແນ່ໃຈວ່າພວກເຮົາບໍ່ປ່ຽນແປງ
            // ອອກຈາກຂອບເຂດ
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-free bitwise shift-right;ໃຫ້ຜົນຜະລິດ `self >> mask(rhs)`, ບ່ອນທີ່ `mask` ກຳ ຈັດທ່ອນທີ່ມີລະບຽບສູງຂອງ `rhs` ເຊິ່ງຈະເຮັດໃຫ້ການປ່ຽນແປງເກີນອັດຕາສ່ວນຂອງປະເພດ.
        ///
        /// ໃຫ້ສັງເກດວ່ານີ້ແມ່ນ *ບໍ່* ຄືກັນກັບການລ້ຽວຂວາ;RHS ຂອງຫໍ່ປ່ຽນ-ຂວາແມ່ນຖືກ ຈຳ ກັດໃນຂອບເຂດຂອງປະເພດ, ແທນທີ່ຈະຖີ້ມອອກຈາກ LHS ຈະຖືກສົ່ງກັບຄືນສູ່ທ້າຍອື່ນໆ.
        ///
        /// ປະເພດເລກປະຖົມສົມບູນທັງ ໝົດ ປະຕິບັດ ໜ້າ ທີ່ [`rotate_right`](Self::rotate_right) ເຊິ່ງມັນອາດຈະເປັນສິ່ງທີ່ທ່ານຕ້ອງການແທນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // ຄວາມປອດໄພ: ການເຮັດ ໜ້າ ກາກໂດຍປະເພດຂອງປະເພດໃຫ້ແນ່ໃຈວ່າພວກເຮົາບໍ່ປ່ຽນແປງ
            // ອອກຈາກຂອບເຂດ
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// ຫໍ່ມູນຄ່າຢ່າງແທ້ຈິງ (modular).ຄຳ ນວນ `self.abs()`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// ກໍລະນີດຽວທີ່ການຫໍ່ດັ່ງກ່າວສາມາດເກີດຂື້ນໄດ້ກໍ່ຄືເມື່ອຄົນເຮົາເອົາມູນຄ່າຂອງມູນຄ່າ ໜ້ອຍ ທີ່ສຸດໃຫ້ກັບຊະນິດ;ນີ້ແມ່ນຄຸນຄ່າໃນທາງບວກທີ່ໃຫຍ່ເກີນໄປທີ່ຈະເປັນຕົວແທນໃນປະເພດ.
        /// ໃນກໍລະນີດັ່ງກ່າວ, ຫນ້າທີ່ນີ້ຈະສົ່ງຄືນ `MIN` ຕົວມັນເອງ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// ລວບລວມມູນຄ່າຢ່າງແທ້ຈິງຂອງ `self` ໂດຍບໍ່ມີການຫຸ້ມຫໍ່ຫຼືຄວາມວຸ້ນວາຍ.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// ການຂູດອັດຕະໂນມັດ (modular).
        /// ຄຳ ນວນ `self.pow(exp)`, ຫໍ່ອ້ອມຂອບເຂດແດນຂອງປະເພດ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // ນັບຕັ້ງແຕ່ exp!=0, ສຸດທ້າຍ exp ຕ້ອງແມ່ນ 1.
            // ຈັດການກັບໂຕເລກສຸດທ້າຍແຍກຕ່າງຫາກ, ເພາະວ່າການກອກພື້ນຖານຫລັງຈາກນັ້ນແມ່ນບໍ່ ຈຳ ເປັນແລະອາດຈະເຮັດໃຫ້ເກີດການໄຫຼວຽນແບບບໍ່ ຈຳ ເປັນ.
            //
            //
            acc.wrapping_mul(base)
        }

        /// ຄິດໄລ່ `self` + `rhs`
        ///
        /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຂອງເຄື່ອງພ້ອມດ້ວຍໃບໄມ້ປ່ອງທີ່ຊີ້ບອກວ່າການໄຫລຜ່ານເລກຄະນິດສາດຈະເກີດຂື້ນຫລືບໍ່.
        /// ຖ້າຫາກວ່າປະລິມານນ້ ຳ ເກີນຈະເກີດຂື້ນ, ມູນຄ່າຫໍ່ຈະຖືກສົ່ງຄືນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// ຄຳ ນວນ `self`, `rhs`
        ///
        /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຂອງການຫັກລົບພ້ອມກັບບູດທະວາຍທີ່ຊີ້ບອກວ່າການໄຫຼເກີນຂອງເລກຄະນິດສາດຈະເກີດຂື້ນຫຼືບໍ່.
        /// ຖ້າຫາກວ່າປະລິມານນ້ ຳ ເກີນຈະເກີດຂື້ນ, ມູນຄ່າຫໍ່ຈະຖືກສົ່ງຄືນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// ຄິດໄລ່ການຄູນຂອງ `self` ແລະ `rhs`.
        ///
        /// ກັບຄືນ tuple ຂອງຄູນພ້ອມກັບ boolean ທີ່ຊີ້ບອກວ່າການໄຫລຜ່ານເລກຄະນິດສາດຈະເກີດຂື້ນຫລືບໍ່.
        /// ຖ້າຫາກວ່າປະລິມານນ້ ຳ ເກີນຈະເກີດຂື້ນ, ມູນຄ່າຫໍ່ຈະຖືກສົ່ງຄືນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, ຄວາມຈິງ));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// ຄິດໄລ່ຕົວເລກເມື່ອ `self` ແບ່ງອອກໂດຍ `rhs`.
        ///
        /// ກັບຄືນ tuple ຂອງ divisor ພ້ອມກັບ boolean ທີ່ຊີ້ບອກວ່າການໄຫລຜ່ານເລກຄະນິດສາດຈະເກີດຂື້ນ.
        /// ຖ້າຫາກວ່າການໄຫຼວຽນເກີນຈະເກີດຂື້ນຫຼັງຈາກນັ້ນຕົນເອງກໍ່ຈະກັບຄືນມາ.
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// ຄິດໄລ່ອັດຕາສ່ວນຂອງພະແນກ Euclidean `self.div_euclid(rhs)`.
        ///
        /// ກັບຄືນ tuple ຂອງ divisor ພ້ອມກັບ boolean ທີ່ຊີ້ບອກວ່າການໄຫລຜ່ານເລກຄະນິດສາດຈະເກີດຂື້ນ.
        /// ຖ້າຫາກວ່າການໄຫຼເຂົ້າເກີນຈະເກີດຂື້ນຫຼັງຈາກນັ້ນ `self` ຈະຖືກສົ່ງຄືນ.
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// ຄຳ ນວນທີ່ເຫລືອເມື່ອ `self` ແບ່ງອອກໂດຍ `rhs`.
        ///
        /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຫຼັງຈາກທີ່ແບ່ງປັນພ້ອມກັບເຫຼົ້າທີ່ຊີ້ບອກວ່າການໄຫຼເຂົ້າເລກດ້ວຍເລກຄະນິດສາດຈະເກີດຂື້ນຫຼືບໍ່.
        /// ຖ້າຫາກວ່າການໄຫຼເຂົ້າເກີນຈະເກີດຂື້ນຫຼັງຈາກນັ້ນ 0 ຈະຖືກສົ່ງຄືນ.
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// ສ່ວນທີ່ເຫຼືອເກີນ Euclidean.ຄິດໄລ່ `self.rem_euclid(rhs)`.
        ///
        /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຫຼັງຈາກທີ່ແບ່ງປັນພ້ອມກັບເຫຼົ້າທີ່ຊີ້ບອກວ່າການໄຫຼເຂົ້າເລກດ້ວຍເລກຄະນິດສາດຈະເກີດຂື້ນຫຼືບໍ່.
        /// ຖ້າຫາກວ່າການໄຫຼເຂົ້າເກີນຈະເກີດຂື້ນຫຼັງຈາກນັ້ນ 0 ຈະຖືກສົ່ງຄືນ.
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// ເຈລະຈາຕົນເອງ, ລົ້ນຖ້າວ່າມັນເທົ່າກັບມູນຄ່າ ຕຳ ່ສຸດ.
        ///
        /// ກັບຄືນ tuple ຂອງສະບັບ negated ຂອງຕົນເອງພ້ອມກັບ boolean ຊີ້ບອກບໍ່ວ່າຈະເປັນການ overflow ທີ່ເກີດຂຶ້ນ.
        /// ຖ້າ `self` ແມ່ນມູນຄ່າຕ່ ຳ ສຸດ (ຕົວຢ່າງ: `i32::MIN` ສຳ ລັບຄ່າຂອງ `i32` ປະເພດ), ຫຼັງຈາກນັ້ນ, ມູນຄ່າ ຕຳ ່ສຸດຈະຖືກສົ່ງຄືນອີກແລະ `true` ກໍ່ຈະຖືກສົ່ງຄືນ ສຳ ລັບການທີ່ເກີດຂື້ນເກີນ ກຳ ນົດ.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// ປ່ຽນດ້ວຍຕົນເອງເບື້ອງຊ້າຍໂດຍ x00X bits.
        ///
        /// ກັບຄືນ tuple ຂອງຮຸ່ນປ່ຽນດ້ວຍຕົນເອງພ້ອມກັບ boolean ທີ່ຊີ້ບອກວ່າມູນຄ່າການປ່ຽນແປງທີ່ໃຫຍ່ກວ່າຫລືເທົ່າກັບ ຈຳ ນວນບິດ.
        /// ຖ້າມູນຄ່າການປ່ຽນແປງໃຫຍ່ເກີນໄປ, ຫຼັງຈາກນັ້ນມູນຄ່າຈະຖືກປິດບັງ (N-1) ບ່ອນທີ່ N ແມ່ນ ຈຳ ນວນບິດ, ແລະຫຼັງຈາກນັ້ນຄ່ານີ້ຈະຖືກ ນຳ ໃຊ້ເພື່ອ ດຳ ເນີນການປ່ຽນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, ຄວາມຈິງ));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// ປ່ຽນດ້ວຍຕົນເອງໂດຍ `rhs` bits.
        ///
        /// ກັບຄືນ tuple ຂອງຮຸ່ນປ່ຽນດ້ວຍຕົນເອງພ້ອມກັບ boolean ທີ່ຊີ້ບອກວ່າມູນຄ່າການປ່ຽນແປງທີ່ໃຫຍ່ກວ່າຫລືເທົ່າກັບ ຈຳ ນວນບິດ.
        /// ຖ້າມູນຄ່າການປ່ຽນແປງໃຫຍ່ເກີນໄປ, ຫຼັງຈາກນັ້ນມູນຄ່າຈະຖືກປິດບັງ (N-1) ບ່ອນທີ່ N ແມ່ນ ຈຳ ນວນບິດ, ແລະຫຼັງຈາກນັ້ນຄ່ານີ້ຈະຖືກ ນຳ ໃຊ້ເພື່ອ ດຳ ເນີນການປ່ຽນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, ຄວາມຈິງ));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// ຄຳ ນວນມູນຄ່າສົມບູນຂອງ `self`.
        ///
        /// ກັບຄືນ tuple ຂອງສະບັບສົມບູນຂອງຕົວເອງພ້ອມກັບ boolean ທີ່ບົ່ງບອກວ່າການໄຫຼຂອງນໍ້າໄດ້ເກີດຂື້ນ.
        /// ຖ້າຕົນເອງແມ່ນມູນຄ່າ ຕຳ ່ສຸດ
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// ຫຼັງຈາກນັ້ນ, ມູນຄ່າຕໍາ່ສຸດທີ່ຈະໄດ້ຮັບການກັບຄືນອີກເທື່ອຫນຶ່ງແລະຄວາມຈິງຈະໄດ້ຮັບການສົ່ງຄືນສໍາລັບການທີ່ເກີດຂຶ້ນ overflow.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// ຍົກລະດັບຕົນເອງໃຫ້ກັບພະລັງງານຂອງ `exp`, ການນໍາໃຊ້ການຂະຫຍາຍຕົວໂດຍການກວາດ.
        ///
        /// ກັບຄືນຄ່າຂອງການອອກສຽງທີ່ສົມເຫດສົມຜົນພ້ອມກັບ bool ທີ່ບົ່ງບອກວ່າການໄຫລວຽນຂອງມັນເກີດຂື້ນຫລືບໍ່.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, ຄວາມຈິງ));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // ພື້ນທີ່ຂູດ ສຳ ລັບການເກັບຮັກສາຜົນໄດ້ຮັບທີ່ລົ້ນລົ້ນ _mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // ນັບຕັ້ງແຕ່ exp!=0, ສຸດທ້າຍ exp ຕ້ອງແມ່ນ 1.
            // ຈັດການກັບໂຕເລກສຸດທ້າຍແຍກຕ່າງຫາກ, ເພາະວ່າການກອກພື້ນຖານຫລັງຈາກນັ້ນແມ່ນບໍ່ ຈຳ ເປັນແລະອາດຈະເຮັດໃຫ້ເກີດການໄຫຼວຽນແບບບໍ່ ຈຳ ເປັນ.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// ຍົກລະດັບຕົນເອງໃຫ້ກັບພະລັງງານຂອງ `exp`, ການນໍາໃຊ້ການຂະຫຍາຍຕົວໂດຍການກວາດ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // ນັບຕັ້ງແຕ່ exp!=0, ສຸດທ້າຍ exp ຕ້ອງແມ່ນ 1.
            // ຈັດການກັບໂຕເລກສຸດທ້າຍແຍກຕ່າງຫາກ, ເພາະວ່າການກອກພື້ນຖານຫລັງຈາກນັ້ນແມ່ນບໍ່ ຈຳ ເປັນແລະອາດຈະເຮັດໃຫ້ເກີດການໄຫຼວຽນແບບບໍ່ ຈຳ ເປັນ.
            //
            //
            acc * base
        }

        /// ຄິດໄລ່ອັດຕາສ່ວນຂອງພະແນກ Euclidean ຂອງ `self` ໂດຍ `rhs`.
        ///
        /// ນີ້ລວບລວມເລກ `n` ຈຳ ນວນດັ່ງກ່າວວ່າ `self = n * rhs + self.rem_euclid(rhs)`, ກັບ `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// ເວົ້າອີກຢ່າງ ໜຶ່ງ, ຜົນໄດ້ຮັບແມ່ນ `self / rhs` ມົນກັບ ຈຳ ນວນ `n` ຈຳ ນວນດັ່ງກ່າວນັ້ນກໍ່ຄື `self >= n * rhs`.
        /// ຖ້າ `self > 0`, ນີ້ເທົ່າກັບຮອບຕໍ່ສູນ (ຄ່າເລີ່ມຕົ້ນໃນ Rust);
        /// ຖ້າ `self < 0`, ນີ້ເທົ່າກັບຮອບຕໍ່ +/-ນິດ.
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0 ຫລືການແບ່ງສ່ວນຈະເຮັດໃຫ້ເກີດການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// let b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// ຄຳ ນວນທີ່ເຫລືອທີ່ບໍ່ມີການຄິດໄລ່ ໜ້ອຍ ທີ່ສຸດຂອງ `self (mod rhs)`.
        ///
        /// ນີ້ແມ່ນເຮັດໄດ້ຄືກັບວ່າໂດຍການແບ່ງປັນ Euclidean algorithm-ໃຫ້ `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r`, ແລະ `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// ຟັງຊັນນີ້ຈະ panic ຖ້າ `rhs` ແມ່ນ 0 ຫລືການແບ່ງສ່ວນຈະເຮັດໃຫ້ເກີດການລົ້ນ.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// let b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// ຄຳ ນວນມູນຄ່າສົມບູນຂອງ `self`.
        ///
        /// # ພຶດຕິ ກຳ ທີ່ລົ້ນລົ້ນ
        ///
        /// ຄຸນຄ່າຢ່າງແທ້ຈິງຂອງ
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// ບໍ່ສາມາດເປັນຕົວແທນໄດ້
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// ແລະການພະຍາຍາມທີ່ຈະຄິດໄລ່ມັນຈະເຮັດໃຫ້ເກີດການລົ້ນ.
        /// ນີ້ຫມາຍຄວາມວ່າລະຫັດໃນຮູບແບບ debug ຈະເຮັດໃຫ້ເກີດ panic ກ່ຽວກັບກໍລະນີນີ້ແລະລະຫັດທີ່ດີທີ່ສຸດຈະກັບຄືນມາ
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// ໂດຍບໍ່ມີການ panic.
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // ໃຫ້ສັງເກດວ່າ#[ເສັ້ນໃນຂ້າງເທິງ] ໝາຍ ຄວາມວ່າອັດຕາສ່ວນເກີນຂອງການຫັກລົບແມ່ນຂື້ນກັບ crate ທີ່ພວກເຮົາ ກຳ ລັງຖືກແນະ ນຳ ເຂົ້າ.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// ສົ່ງ ຈຳ ນວນທີ່ເປັນຕົວແທນຂອງ ໝາຍ ເລກ `self`.
        ///
        ///  - `0` ຖ້າຫາກວ່າຕົວເລກແມ່ນສູນ
        ///  - `1` ຖ້າ ຈຳ ນວນບວກ
        ///  - `-1` ຖ້າ ຈຳ ນວນລົບ
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// ສົ່ງຄືນ `true` ຖ້າ `self` ແມ່ນບວກແລະ `false` ຖ້າຕົວເລກແມ່ນສູນຫຼືລົບ.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// ກັບຄືນ `true` ຖ້າ `self` ແມ່ນລົບແລະ `false` ຖ້າຫາກວ່າຕົວເລກແມ່ນສູນຫຼືບວກ.
        ///
        ///
        /// # Examples
        ///
        /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// ສົ່ງຄືນການສະແດງຄວາມຊົງ ຈຳ ຂອງເລກເຕັມນີ້ເປັນຂບວນໄບຕ໌ໃນ (network) byte ໃຫຍ່.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// ສົ່ງຄືນການສະແດງຄວາມຊົງ ຈຳ ຂອງເລກເຕັມນີ້ເປັນຂບວນໄບຕ໌ໃນ ລຳ ດັບໄບຕີ້.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// ສົ່ງຄືນການສະແດງຄວາມຊົງ ຈຳ ຂອງເລກເຕັມນີ້ເປັນຂບວນໄບຕ໌ຕາມ ລຳ ດັບໄບຕ໌ພື້ນເມືອງ.
        ///
        /// ໃນຂະນະທີ່ຄວາມນິຍົມຂອງພື້ນເມືອງຂອງເວທີເປົ້າ ໝາຍ ຖືກໃຊ້, ລະຫັດແບບພະກະພາຄວນໃຊ້ [`to_be_bytes`] ຫຼື [`to_le_bytes`], ຕາມຄວາມ ເໝາະ ສົມ, ແທນ.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, ຖ້າ cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } ອີກ {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // ຄວາມປອດໄພ: ສຽງດີເພາະວ່າຕົວເລກເຕັມແມ່ນຮູບແບບເກົ່າແກ່ ທຳ ມະດາສະນັ້ນພວກເຮົາສາມາດເຮັດໄດ້ຕະຫຼອດເວລາ
        // transmute ໃຫ້ເຂົາເຈົ້າກັບຂບວນຂອງໄບຕ໌
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // ຄວາມປອດໄພ: ເລກເຕັມແມ່ນຮູບແບບເກົ່າແກ່ ທຳ ມະດາສະນັ້ນພວກເຮົາສາມາດສົ່ງສັນຍານເຫຼົ່ານັ້ນໄປສະ ເໝີ
            // ຂບວນຂອງໄບຕ໌
            unsafe { mem::transmute(self) }
        }

        /// ສົ່ງຄືນການສະແດງຄວາມຊົງ ຈຳ ຂອງເລກເຕັມນີ້ເປັນຂບວນໄບຕ໌ຕາມ ລຳ ດັບໄບຕ໌ພື້ນເມືອງ.
        ///
        ///
        /// [`to_ne_bytes`] ຄວນຈະເປັນທີ່ຕ້ອງການໃນໄລຍະນີ້ເມື່ອເປັນໄປໄດ້.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// let bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, ຖ້າ cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } ອີກ {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // ຄວາມປອດໄພ: ເລກເຕັມແມ່ນຮູບແບບເກົ່າແກ່ ທຳ ມະດາສະນັ້ນພວກເຮົາສາມາດສົ່ງສັນຍານເຫຼົ່ານັ້ນໄປສະ ເໝີ
            // ຂບວນຂອງໄບຕ໌
            unsafe { &*(self as *const Self as *const _) }
        }

        /// ສ້າງມູນຄ່າເລກເຕັມຈາກການເປັນຕົວແທນຂອງມັນເປັນຂບວນ byte ໃນ endian ໃຫຍ່.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// ໃຊ້ std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ວັດສະດຸປ້ອນ=ສ່ວນທີ່ເຫຼືອ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// ສ້າງຄ່າເລກເຕັມຈາກການເປັນຕົວແທນຂອງມັນເປັນຂບວນ byte ໃນ endian ພຽງເລັກນ້ອຍ.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// ໃຊ້ std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ວັດສະດຸປ້ອນ=ສ່ວນທີ່ເຫຼືອ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// ສ້າງມູນຄ່າເລກເຕັມຈາກການເປັນຕົວແທນຄວາມຊົງ ຈຳ ຂອງມັນເປັນຂບວນໄບຕ໌ໃນຄວາມນິຍົມຂອງຄົນພື້ນເມືອງ.
        ///
        /// ໃນຂະນະທີ່ຄວາມນິຍົມຂອງພື້ນເມືອງຂອງເວທີເປົ້າ ໝາຍ ຖືກໃຊ້, ລະຫັດແບບເຄື່ອນທີ່ອາດຈະຕ້ອງການໃຊ້ [`from_be_bytes`] ຫຼື [`from_le_bytes`], ຕາມຄວາມ ເໝາະ ສົມແທນ.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } ອີກ {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// ໃຊ້ std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ວັດສະດຸປ້ອນ=ສ່ວນທີ່ເຫຼືອ;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // ຄວາມປອດໄພ: ສຽງດີເພາະວ່າຕົວເລກເຕັມແມ່ນຮູບແບບເກົ່າແກ່ ທຳ ມະດາສະນັ້ນພວກເຮົາສາມາດເຮັດໄດ້ຕະຫຼອດເວລາ
        // transmute ກັບພວກເຂົາ
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // ຄວາມປອດໄພ: ເລກເຕັມແມ່ນຮູບແບບເກົ່າແກ່ ທຳ ມະດາສະນັ້ນພວກເຮົາສາມາດສົ່ງຕໍ່ໃຫ້ພວກເຂົາໄດ້ສະ ເໝີ
            unsafe { mem::transmute(bytes) }
        }

        /// ລະຫັດ ໃໝ່ ຄວນໃຊ້
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// ສົ່ງຄ່າທີ່ນ້ອຍທີ່ສຸດທີ່ສາມາດເປັນຕົວແທນໂດຍປະເພດເລກນີ້.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// ລະຫັດ ໃໝ່ ຄວນໃຊ້
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// ສົ່ງຄືນມູນຄ່າທີ່ໃຫຍ່ທີ່ສຸດທີ່ສາມາດເປັນຕົວແທນໂດຍປະເພດເລກນີ້.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}