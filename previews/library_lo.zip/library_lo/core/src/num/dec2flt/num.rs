//! ໜ້າ ທີ່ ນຳ ໃຊ້ ສຳ ລັບ bignums ທີ່ບໍ່ມີຄວາມ ໝາຍ ຫຼາຍເກີນໄປທີ່ຈະຫັນເປັນວິທີການ.

// ຊື່ຂອງໂມດູນນີ້ແມ່ນໂຊກບໍ່ດີ, ເພາະວ່າໂມດູນອື່ນໆຍັງ ນຳ ເຂົ້າ `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// ທົດສອບວ່າການຕັດທ່ອນທັງ ໝົດ ໜ້ອຍ ກ່ວາ `ones_place` ແນະ ນຳ ຂໍ້ຜິດພາດທີ່ທຽບເທົ່າ ໜ້ອຍ ກວ່າ, ເທົ່າຫລືໃຫຍ່ກວ່າ 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // ຖ້າບິດທີ່ຍັງເຫຼືອທັງ ໝົດ ເປັນສູນ, ມັນແມ່ນ= 0.5 ULP, ຖ້າບໍ່ດັ່ງນັ້ນ> 0.5 ຖ້າບໍ່ມີບິດອີກຕໍ່ໄປ (half_bit==0), ດ້ານລຸ່ມກໍ່ຈະສົ່ງຄືນໃຫ້ເທົ່າທຽມກັນ.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// ແປງສາຍ ASCII ທີ່ມີພຽງຕົວເລກທົດສະນິຍົມເປັນ `u64` ເທົ່ານັ້ນ.
///
/// ບໍ່ປະຕິບັດການກວດສອບຂໍ້ມູນທີ່ເກີນ ກຳ ນົດຫລືຕົວອັກສອນທີ່ບໍ່ຖືກຕ້ອງ, ສະນັ້ນຖ້າຜູ້ໂທບໍ່ລະມັດລະວັງ, ຜົນໄດ້ຮັບຈະບິດເບືອນແລະສາມາດ panic (ເຖິງແມ່ນວ່າມັນຈະບໍ່ແມ່ນ `unsafe`).
/// ນອກຈາກນັ້ນ, ສາຍເຊືອກທີ່ບໍ່ໄດ້ຮັບການປິ່ນປົວແມ່ນສູນ.
/// ຟັງຊັນນີ້ມີຢູ່ເພາະວ່າ
///
/// 1. ການໃຊ້ `FromStr` ໃນ `&[u8]` ຮຽກຮ້ອງ `from_utf8_unchecked`, ເຊິ່ງບໍ່ດີ, ແລະ
/// 2. ການລວມເອົາຜົນຂອງ `integral.parse()` ແລະ `fractional.parse()` ແມ່ນສັບສົນຫຼາຍກ່ວາ ໜ້າ ທີ່ທັງ ໝົດ ນີ້.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ແປງຕົວເລກຂອງ ASCII ເປັນຕົວເລກ bignum.
///
/// ເຊັ່ນດຽວກັບ `from_str_unchecked`, ໜ້າ ທີ່ນີ້ເພິ່ງພານັກວິສະວະກອນເພື່ອ ກຳ ຈັດວັດສະພືດທີ່ບໍ່ແມ່ນຕົວເລກ.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// ຍົກເລີກ bignum ເປັນເລກເຕັມ 64 ບິດ.Panics ຖ້າ ຈຳ ນວນໃຫຍ່ເກີນໄປ.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// ສະກັດລະດັບຂອງບິດ.

/// ດັດສະນີ 0 ແມ່ນນ້ອຍທີ່ ສຳ ຄັນແລະຂອບເຂດແມ່ນເປີດເຄິ່ງ ໜຶ່ງ ຕາມປົກກະຕິ.
/// Panics ຖ້າຖືກຖາມໃຫ້ສະກັດຖັງຫຼາຍກ່ວາທີ່ ເໝາະ ສົມກັບປະເພດການກັບຄືນ.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}