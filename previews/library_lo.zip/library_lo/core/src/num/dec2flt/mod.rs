//! ການປ່ຽນແປງບັນດາສາຍເຊນເລກເປັນ IEEE 754 ເລກຖານຈຸດລອຍ ນຳ ້.
//!
//! # ຖະແຫຼງການບັນຫາ
//!
//! ພວກເຮົາໄດ້ຮັບສາຍເຊນທະສະນິຍົມເຊັ່ນ `12.34e56`.
//! ສາຍເຊືອກນີ້ປະກອບດ້ວຍ (`12`) ແບບເຊື່ອມໂຍງ, ແຕ່ສ່ວນປະສົມ (`34`), ແລະຊິ້ນສ່ວນ (`56`) ທີ່ເສີຍຫາຍໄປ.ທຸກພາກສ່ວນແມ່ນເປັນທາງເລືອກແລະຖືກຕີຄວາມວ່າເປັນສູນເມື່ອສູນຫາຍໄປ.
//!
//! ພວກເຮົາຊອກຫາຕົວເລກຈຸດລອຍຂອງ IEEE 754 ທີ່ໃກ້ຄຽງກັບມູນຄ່າທີ່ແນ່ນອນຂອງຕົວເລກທົດສະນິຍົມ.
//! ມັນເປັນທີ່ຮູ້ກັນດີວ່າສາຍເຊນທະນິຍົມຫຼາຍໆຊະນິດບໍ່ມີການສິ້ນສຸດການເປັນຕົວແທນຢູ່ໃນຖານສອງ, ສະນັ້ນພວກເຮົາຈຶ່ງໄດ້ໄປຫາ 0.5 ຫົວ ໜ່ວຍ ໃນສະຖານທີ່ສຸດ (ໃນອີກດ້ານ ໜຶ່ງ, ເຊັ່ນດຽວກັນກັບເປັນໄປໄດ້).
//! ສາຍພັນ, ຄ່ານິຍົມຢ່າງແນ່ນອນເຄິ່ງທາງເຄິ່ງທາງລະຫວ່າງສອງຕົວຢ່າງຕໍ່ເນື່ອງ, ໄດ້ຖືກແກ້ໄຂດ້ວຍຍຸດທະສາດເຄິ່ງເຖິງເຄິ່ງ ໜຶ່ງ, ເຊິ່ງເອີ້ນກັນວ່າຮອບທະນາຄານ.
//!
//! ບໍ່ ຈຳ ເປັນຕ້ອງເວົ້າ, ນີ້ແມ່ນຂ້ອນຂ້າງຍາກ, ທັງໃນແງ່ຂອງການສັບຊ້ອນການຈັດຕັ້ງປະຕິບັດແລະໃນດ້ານຂອງວົງຈອນຊີພີຢູ.
//!
//! # Implementation
//!
//! ທຳ ອິດ, ພວກເຮົາບໍ່ສົນໃຈເຄື່ອງ ໝາຍ.ຫຼືແທນທີ່ຈະ, ພວກເຮົາເອົາມັນອອກໃນຕອນເລີ່ມຕົ້ນຂອງຂະບວນການປ່ຽນໃຈເຫລື້ອມໃສແລະ ນຳ ໃຊ້ມັນຄືນ ໃໝ່ ໃນທີ່ສຸດ.
//! ນີ້ແມ່ນຖືກຕ້ອງໃນທຸກໆກໍລະນີ edge ນັບຕັ້ງແຕ່ IEEE floats ແມ່ນ symmetric ປະມານສູນ, negating ຫນຶ່ງພຽງແຕ່ກະພິບບິດ ທຳ ອິດ.
//!
//! ຫຼັງຈາກນັ້ນພວກເຮົາເອົາຈຸດທົດສະນິຍົມອອກໂດຍດັດປັບຕົວເລກ: ແນວຄິດ, `12.34e56` ປ່ຽນເປັນ `1234e54`, ເຊິ່ງພວກເຮົາອະທິບາຍດ້ວຍຕົວເລກບວກ `f = 1234` ແລະ ຈຳ ນວນ `e = 54`.
//! ຕົວແທນ `(f, e)` ຖືກ ນຳ ໃຊ້ໂດຍລະຫັດເກືອບທັງ ໝົດ ທີ່ຜ່ານຂັ້ນຕອນການວິເຄາະ.
//!
//! ຫຼັງຈາກນັ້ນພວກເຮົາລອງທົດລອງໃຊ້ກໍລະນີພິເສດທີ່ຍາວນານກວ່າເກົ່າໂດຍ ນຳ ໃຊ້ເຄື່ອງຈັກຂະ ໜາດ ເຂົ້າແລະຕົວເລກຈຸດລອຍນ້ ຳ ທີ່ມີ ກຳ ນົດ (ຄັ້ງ ທຳ ອິດ `f32`/`f64`, ຫຼັງຈາກນັ້ນປະເພດທີ່ມີ 64 bit significand, `Fp`).
//!
//! ເມື່ອສິ່ງເຫລົ່ານີ້ລົ້ມເຫລວ, ພວກເຮົາກັດລູກປືນແລະຣີສອດກັບສູດການຄິດໄລ່ງ່າຍດາຍແຕ່ຊ້າຫຼາຍທີ່ກ່ຽວຂ້ອງກັບຄອມພິວເຕີ້ `f * 10^e` ຢ່າງເຕັມທີ່ແລະເຮັດການຄົ້ນຫາແບບເດີມໆ ສຳ ລັບການປະມານທີ່ດີທີ່ສຸດ.
//!
//! ຕົ້ນຕໍ, ໂມດູນນີ້ແລະເດັກນ້ອຍຂອງມັນປະຕິບັດລະບົບການຄິດໄລ່ທີ່ໄດ້ອະທິບາຍໄວ້ໃນ:
//! "How to Read Floating Point Numbers Accurately" ໂດຍ William D.
//! Clinger, ມີຢູ່ທາງອິນເຕີເນັດ: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! ນອກຈາກນັ້ນ, ຍັງມີ ໜ້າ ທີ່ຊ່ວຍເຫຼືອຫຼາຍໆຢ່າງທີ່ໃຊ້ໃນເຈ້ຍແຕ່ບໍ່ມີໃນ Rust (ຫຼືຢ່າງ ໜ້ອຍ ກໍ່ເປັນແກນຫຼັກ).
//! ສະບັບຂອງພວກເຮົາແມ່ນມີຄວາມສັບສົນຕື່ມອີກໂດຍຄວາມ ຈຳ ເປັນໃນການຈັດການກັບການໄຫຼວຽນແລະການໄຫຼວຽນແລະຄວາມປາຖະ ໜາ ທີ່ຈະຈັດການກັບຕົວເລກທີ່ບໍ່ມີຕົວຕົນ.
//! Bellerophon ແລະ Algorithm R ມີບັນຫາກ່ຽວກັບການໄຫຼວຽນເກີນ, subnormals, ແລະ underflow.
//! ພວກເຮົາອະນຸລັກປ່ຽນເປັນ Algorithm M (ໂດຍມີການດັດແປງທີ່ໄດ້ອະທິບາຍໄວ້ໃນພາກທີ 8 ຂອງເຈ້ຍ) ເປັນຢ່າງດີກ່ອນທີ່ປັດໄຈ ນຳ ເຂົ້າເຂົ້າໃນພາກພື້ນທີ່ ສຳ ຄັນ.
//!
//! ອີກແງ່ມຸມ ໜຶ່ງ ທີ່ຕ້ອງການຄວາມສົນໃຈແມ່ນ ``RawFloat`` trait ເຊິ່ງເກືອບທັງ ໝົດ ໜ້າ ທີ່ຖືກ parametrized.ຫນຶ່ງອາດຈະຄິດວ່າມັນພຽງພໍທີ່ຈະແຍກອອກເປັນ `f64` ແລະໂຍນຜົນໃຫ້ `f32`.
//! ແຕ່ຫນ້າເສຍດາຍທີ່ມັນບໍ່ແມ່ນໂລກທີ່ພວກເຮົາອາໄສຢູ່, ແລະສິ່ງນີ້ບໍ່ມີຫຍັງກ່ຽວຂ້ອງກັບການໃຊ້ຖານສອງຫລືເຄິ່ງຮອບເຖິງແມ່ນຮອບ.
//!
//! ພິຈາລະນາຍົກຕົວຢ່າງສອງປະເພດ `d2` ແລະ `d4` ເຊິ່ງເປັນຕົວແທນຂອງປະເພດທົດສະນິຍົມທີ່ມີຕົວເລກສອງທົດສະນິຍົມແລະ 4 ຕົວເລກສີ່ທົດສະວັດແຕ່ລະອັນແລະເອົາ "0.01499" ເປັນການປ້ອນຂໍ້ມູນ.ໃຫ້ໃຊ້ຮອບເຄິ່ງ.
//! ໄປໂດຍກົງກັບຕົວເລກສອງຕົວເລກໃຫ້ `0.01`, ແຕ່ຖ້າພວກເຮົາຮວບຮວມ 4 ຕົວເລກກ່ອນ, ພວກເຮົາຈະໄດ້ຮັບ `0.0150`, ເຊິ່ງຈາກນັ້ນກໍ່ຈະຖືກມົນຮອດ `0.02`.
//! ຫຼັກການດຽວກັນນີ້ໃຊ້ໄດ້ກັບການປະຕິບັດງານອື່ນໆເຊັ່ນກັນ, ຖ້າທ່ານຕ້ອງການຄວາມຖືກຕ້ອງຂອງ 0.5 ULP ທ່ານຕ້ອງເຮັດທຸກຢ່າງ *ໃນຄວາມແມ່ນຍໍາແລະຮອບເຕັມ* ແນ່ນອນເທື່ອດຽວ, ໃນຕອນທ້າຍ *, ໂດຍການພິຈາລະນາທຸກສ່ວນທີ່ຖືກຕັດໃນເວລາດຽວກັນ.
//!
//! FIXME: ເຖິງແມ່ນວ່າການເຮັດຊ້ ຳ ລະຫັດບາງຢ່າງແມ່ນມີຄວາມ ຈຳ ເປັນ, ບາງທີບາງສ່ວນຂອງລະຫັດອາດຈະຖືກສັບລົງປະມານດັ່ງນັ້ນລະຫັດ ໜ້ອຍ ແມ່ນຊ້ ຳ ກັນ.
//! ສ່ວນໃຫຍ່ຂອງສູດການຄິດໄລ່ແມ່ນບໍ່ເປັນເອກະລາດຂອງປະເພດທີ່ເລື່ອນໄປຫາຜົນຜະລິດ, ຫຼືພຽງແຕ່ຕ້ອງການການເຂົ້າເຖິງຄົງທີ່ບໍ່ຫຼາຍປານໃດ, ເຊິ່ງສາມາດຜ່ານເປັນຕົວ ກຳ ນົດການ.
//!
//! # Other
//!
//! ການປ່ຽນໃຈເຫລື້ອມໃສຄວນ *ບໍ່ເຄີຍ* panic.
//! ມີການຢືນຢັນແລະລະຫັດ panics ຢ່າງລະອຽດ, ແຕ່ພວກມັນບໍ່ຄວນຖືກເຮັດໃຫ້ເກີດຜົນແລະພຽງແຕ່ເຮັດ ໜ້າ ທີ່ກວດກາຄວາມສະອາດພາຍໃນເທົ່ານັ້ນ.panics ໃດກໍ່ຕາມຄວນຖືວ່າເປັນຂໍ້ບົກພ່ອງ.
//!
//! ມີການທົດສອບຫົວ ໜ່ວຍ ແຕ່ວ່າພວກເຂົາບໍ່ດີພໍທີ່ຈະຮັບປະກັນຄວາມຖືກຕ້ອງ, ພວກເຂົາພຽງແຕ່ກວມເອົາເປີເຊັນນ້ອຍໆຂອງຄວາມຜິດພາດທີ່ເປັນໄປໄດ້.
//! ການທົດສອບທີ່ກວ້າງຂວາງກວ່າເກົ່າແມ່ນຕັ້ງຢູ່ໃນໄດເລກະທໍລີ `src/etc/test-float-parse` ເປັນຕົວອັກສອນ Python.
//!
//! ປື້ມບັນທຶກກ່ຽວກັບ ຈຳ ນວນເຕັມເກີນ: ຫລາຍໆສ່ວນຂອງເອກະສານນີ້ປະຕິບັດກ່ຽວກັບເລກຄະນິດສາດກັບຕົວເລກອັດສະນິຍົມ `e`.
//! ຕົ້ນຕໍ, ພວກເຮົາປ່ຽນຈຸດທົດສະນິຍົມປະມານ: ກ່ອນຕົວເລກທົດສະນິຍົມ ທຳ ອິດ, ຫຼັງຈາກຕົວເລກທົດສະນິຍົມສຸດທ້າຍ, ແລະອື່ນໆ.ນີ້ສາມາດ overflow ຖ້າຫາກວ່າເຮັດໄດ້ບໍ່ສົນໃຈ.
//! ພວກເຮົາອີງໃສ່ແບບອະນຸພາກແບ່ງປັນເພື່ອໃຫ້ພຽງແຕ່ວາງອະທິບາຍຂະ ໜາດ ນ້ອຍ, ບ່ອນທີ່ "sufficient" ໝາຍ ເຖິງ "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! ອະນຸຍາດຂະ ໜາດ ໃຫຍ່ໄດ້ຖືກຍອມຮັບ, ແຕ່ພວກເຮົາບໍ່ໄດ້ເຮັດເລກຄະນິດສາດກັບພວກມັນ, ພວກມັນຖືກປ່ຽນເປັນ {positive,negative} {zero,infinity} ທັນທີ.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// ທັງສອງນີ້ມີການທົດສອບດ້ວຍຕົນເອງ.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// ແປງສາຍເຊືອກໃນຖານ 10 ເປັນຕົວເລື່ອນ.
            /// ຍອມຮັບຕົວແປເລກນິຍົມທາງເລືອກ.
            ///
            /// ຟັງຊັນນີ້ຍອມຮັບເຊືອກເຊັ່ນ
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', ຫຼືທຽບເທົ່າ, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', ຫຼື, ທຽບເທົ່າ, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// ການ ນຳ ພາແລະຕິດຕາມຊ່ອງຫວ່າງເປັນຕົວແທນຂອງຂໍ້ຜິດພາດ.
            ///
            /// # Grammar
            ///
            /// ທຸກສາຍທີ່ຍຶດຕິດກັບໄວຍາກອນ [EBNF] ຕໍ່ໄປນີ້ຈະສົ່ງຜົນໃຫ້ [`Ok`] ຖືກສົ່ງກັບ:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # ແມງໄມ້ທີ່ຮູ້ຈັກ
            ///
            /// ໃນບາງສະຖານະການ, ບາງສາຍທີ່ຄວນສ້າງແບບເລື່ອນລອຍທີ່ຖືກຕ້ອງແທນທີ່ຈະສົ່ງຄືນຂໍ້ຜິດພາດ.
            /// ເບິ່ງ [issue #31407] ສຳ ລັບລາຍລະອຽດ.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, ສາຍສະຕິງ
            ///
            /// # ຄ່າຕອບແທນ
            ///
            /// `Err(ParseFloatError)` ຖ້າສະຕິງບໍ່ໄດ້ ໝາຍ ເຖິງຕົວເລກທີ່ຖືກຕ້ອງ.
            /// ຖ້າບໍ່ດັ່ງນັ້ນ, `Ok(n)` ບ່ອນທີ່ `n` ແມ່ນຕົວເລກຈຸດລອຍທີ່ເປັນຕົວແທນໂດຍ `src`.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// ຂໍ້ຜິດພາດທີ່ສາມາດສົ່ງຄືນໄດ້ເມື່ອການຄົ້ນຄວ້າລອຍຕົວ.
///
/// ຂໍ້ຜິດພາດນີ້ຖືກໃຊ້ເປັນປະເພດຂໍ້ຜິດພາດ ສຳ ລັບການຈັດຕັ້ງປະຕິບັດ [`FromStr`] ສຳ ລັບ [`f32`] ແລະ [`f64`].
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// ແບ່ງປັນສາຍເຊດລົງເປັນເຄື່ອງ ໝາຍ ແລະສ່ວນທີ່ເຫຼືອ, ໂດຍບໍ່ມີການກວດກາຫຼືກວດສອບສິ່ງທີ່ເຫຼືອ.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // ຖ້າຫາກວ່າສະຕິງບໍ່ຖືກຕ້ອງ, ພວກເຮົາບໍ່ເຄີຍໃຊ້ເຄື່ອງ ໝາຍ ດັ່ງນັ້ນພວກເຮົາບໍ່ ຈຳ ເປັນຕ້ອງ ນຳ ໃຊ້ທີ່ນີ້.
        _ => (Sign::Positive, s),
    }
}

/// ປ່ຽນສາຍອັກສອນທົດສະນິຍົມເປັນຕົວເລກຈຸດເລື່ອນ.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// ເຄື່ອງເຮັດວຽກຕົ້ນຕໍ ສຳ ລັບການປ່ຽນເລກທົດສະນິຍົມຫາເລື່ອນ: ຈັດແຈງທຸກຂັ້ນຕອນທີ່ ກຳ ລັງເຮັດກ່ອນແລະຄິດໄລ່ວ່າສູດການຄິດໄລ່ໃດຄວນປ່ຽນແປງຕົວຈິງ.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift ອອກຈຸດທົດສະນິຍົມ.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 ມີ ຈຳ ກັດເຖິງ 1280 ບິດ, ເຊິ່ງແປເປັນປະມານ 385 ໂຕເລກ.
    // ຖ້າພວກເຮົາເກີນສິ່ງນີ້, ພວກເຮົາຈະລົ້ມເຫລວ, ສະນັ້ນພວກເຮົາຜິດພາດກ່ອນທີ່ຈະເຂົ້າໃກ້ເກີນໄປ (ພາຍໃນ 10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // ຕອນນີ້ເລກ ກຳ ລັງແນ່ນອນພໍດີກັບ 16 ບິດ, ເຊິ່ງໃຊ້ໄດ້ຕະຫຼອດສູດການຄິດໄລ່ຫຼັກ.
    let e = e as i16;
    // FIXME ຂອບເຂດເຫຼົ່ານີ້ແມ່ນມີການອະນຸລັກຫຼາຍ.
    // ການວິເຄາະລະມັດລະວັງຫຼາຍກ່ຽວກັບຮູບແບບການລົ້ມເຫຼວຂອງ Bellerophon ສາມາດອະນຸຍາດໃຫ້ໃຊ້ມັນໃນກໍລະນີຫຼາຍ ສຳ ລັບຄວາມໄວທີ່ໃຫຍ່ຫຼວງ.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// ດັ່ງທີ່ຂຽນໄວ້, ສິ່ງນີ້ຈະເຮັດໃຫ້ດີຂື້ນ (ເບິ່ງ #27130, ເຖິງແມ່ນວ່າມັນຈະ ໝາຍ ເຖິງລະຫັດເກົ່າຂອງລະຫັດ).
// `inline(always)` ແມ່ນບັນຫາ ສຳ ລັບສິ່ງນັ້ນ.
// ມີພຽງສອງເວັບໄຊທ໌ໂທໂດຍລວມແລະມັນບໍ່ເຮັດໃຫ້ຂະ ໜາດ ລະຫັດຮ້າຍແຮງກວ່າເກົ່າ.

/// ລອກເອົາເລກສູນຢູ່ບ່ອນທີ່ເປັນໄປໄດ້, ເຖິງແມ່ນວ່າມັນຈະຮຽກຮ້ອງໃຫ້ປ່ຽນແປງເລກ ກຳ ລັງ
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // ການຕັດເລກສູນເຫຼົ່ານີ້ບໍ່ໄດ້ປ່ຽນແປງຫຍັງເລີຍແຕ່ອາດຈະເຮັດໃຫ້ເສັ້ນທາງໄວ (<15 ຕົວເລກ).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // ອະທິບາຍຕົວເລກຂອງແບບຟອມ 0.0 ... x ແລະ x ... 0.0, ດັດປັບຕົວເລກຕາມຄວາມ ເໝາະ ສົມ.
    // ນີ້ອາດຈະບໍ່ແມ່ນໄຊຊະນະສະ ເໝີ ໄປ (ອາດຈະເຮັດໃຫ້ບາງຕົວເລກອອກໄປຈາກເສັ້ນທາງທີ່ໄວ), ແຕ່ມັນຈະເຮັດໃຫ້ພາກສ່ວນອື່ນປ່ຽນແປງໄດ້ຢ່າງຫຼວງຫຼາຍ (ໂດຍສະເພາະການຄາດຄະເນຂະ ໜາດ ຂອງມູນຄ່າ).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// ສົ່ງຄືນທີ່ຮີບດ່ວນທີ່ເປື້ອນຢູ່ເທິງຂະ ໜາດ (log10) ຂອງມູນຄ່າທີ່ໃຫຍ່ທີ່ສຸດທີ່ Algorithm R ແລະ Algorithm M ຈະຄິດໄລ່ໃນຂະນະທີ່ ກຳ ລັງເຮັດວຽກກ່ຽວກັບອັດຕານິຍົມທີ່ໄດ້ຮັບ.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // ພວກເຮົາບໍ່ ຈຳ ເປັນຕ້ອງກັງວົນຫລາຍເກີນໄປກ່ຽວກັບການລົ້ນນ້ ຳ ທີ່ນີ້ຍ້ອນ trivial_cases() ແລະເຄື່ອງເຈາະ, ເຊິ່ງກັ່ນຕອງການ ນຳ ເຂົ້າທີ່ສຸດ ສຳ ລັບພວກເຮົາ.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // ໃນກໍລະນີ e>=0, ທັງສອງສູດການຄິດໄລ່ປະມານ `f * 10^e`.
        // Algorithm R ໄດ້ ດຳ ເນີນການຄິດໄລ່ທີ່ສັບສົນບາງຢ່າງກັບສິ່ງນີ້ແຕ່ພວກເຮົາສາມາດລະເລີຍໄດ້ວ່າ ສຳ ລັບເສັ້ນທາງເທິງເພາະມັນຍັງຊ່ວຍຫຼຸດຜ່ອນສ່ວນປະກອບກ່ອນກ່ອນ, ສະນັ້ນພວກເຮົາມີ buffer ຫຼາຍໆຢູ່ທີ່ນັ້ນ.
        //
        f_len + (e as u64)
    } else {
        // ຖ້າ e <0, Algorithm R ເຮັດແບບດຽວກັນ, ແຕ່ວ່າ Algorithm M ແຕກຕ່າງກັນ:
        // ມັນພະຍາຍາມຊອກຫາຕົວເລກບວກ k ເຊັ່ນວ່າ `f << k / 10^e` ແມ່ນຄວາມ ສຳ ຄັນໃນລະດັບ.
        // ນີ້ຈະສົ່ງຜົນໃຫ້ປະມານ `2^53 *f* 10^e` <`10^17 *f* 10^e`.
        // ການປ້ອນຂໍ້ມູນ ໜຶ່ງ ທີ່ກະຕຸ້ນສິ່ງນີ້ແມ່ນ 0.33 ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// ກວດພົບ ຈຳ ນວນເງິນໄຫຼລົ້ນແລະກະແສໄຟຟ້າຢ່າງຈະແຈ້ງໂດຍບໍ່ຕ້ອງເບິ່ງຕົວເລກທົດສະນິຍົມ.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // ມີສູນສູນແຕ່ພວກມັນຖືກເອົາໄປໂດຍ simplify()
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // ນີ້ແມ່ນປະມານນໍ້າມັນດິບຂອງ ceil(log10(the real value)).
    // ພວກເຮົາບໍ່ ຈຳ ເປັນຕ້ອງກັງວົນຫລາຍເກີນໄປກ່ຽວກັບການລົ້ນນ້ ຳ ຢູ່ທີ່ນີ້ເພາະວ່າຄວາມຍາວຂອງການປ້ອນຂໍ້ມູນມີຂະ ໜາດ ນ້ອຍ (ຢ່າງ ໜ້ອຍ ເມື່ອທຽບໃສ່ 2 ^ 64) ຂອງ 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}