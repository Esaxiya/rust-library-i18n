//! ຍ້ອງຍໍກ່ຽວກັບ IEEE 754 ທີ່ເປັນບວກ.ເລກລົບແມ່ນບໍ່ແລະບໍ່ ຈຳ ເປັນຕ້ອງໄດ້ຮັບການແກ້ໄຂ.
//! ຕົວເລກຈຸດລອຍນ້ ຳ ປົກກະຕິມີຕົວແທນ canonical ຄື (frac, exp) ເຊັ່ນວ່າຄ່າແມ່ນ 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) ເຊິ່ງ N ແມ່ນ ຈຳ ນວນຂອງບິດ.
//!
//! ບັນດາກຸ່ມຍ່ອຍແມ່ນແຕກຕ່າງກັນເລັກນ້ອຍແລະແປກ, ແຕ່ວ່າຫຼັກການດຽວກັນນີ້ໃຊ້ໄດ້.
//!
//! ເຖິງຢ່າງໃດກໍ່ຕາມນີ້, ພວກເຮົາເປັນຕົວແທນໃຫ້ພວກເຂົາເປັນ (sig, k) ດ້ວຍ f ບວກ, ເຊັ່ນວ່າມູນຄ່າແມ່ນ f *
//! 2 <sup>e</sup> .ນອກ ເໜືອ ຈາກການເຮັດໃຫ້ "hidden bit" ມີຄວາມຊັດເຈນ, ສິ່ງນີ້ຈະປ່ຽນແປງເລກທີໂດຍການປ່ຽນ mantissa.
//!
//! ເອົາອີກວິທີ ໜຶ່ງ, ຕາມປົກກະຕິແລ້ວເລື່ອນໄດ້ຖືກຂຽນເປັນ (1) ແຕ່ໃນທີ່ນີ້ພວກມັນຖືກຂຽນເປັນ (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! ພວກເຮົາເອີ້ນວ່າ (1) ແມ່ນ **ການສະແດງສ່ວນທີ່ເປັນສ່ວນປະກອບ** ແລະ (2) ແມ່ນ ** ການເປັນຕົວແທນລວມ.
//!
//! ຫຼາຍ ໜ້າ ທີ່ໃນໂມດູນນີ້ພຽງແຕ່ຈັດການກັບຕົວເລກປົກກະຕິ.ເສັ້ນທາງ dec2flt ໄດ້ອະນຸລັກໃຊ້ເສັ້ນທາງຊ້າທີ່ຖືກຕ້ອງໃນທົ່ວໂລກ (Algorithm M) ສຳ ລັບຕົວເລກນ້ອຍແລະໃຫຍ່ຫຼາຍ.
//! ສູດການຄິດໄລ່ນັ້ນຕ້ອງການພຽງແຕ່ next_float() ເທົ່ານັ້ນທີ່ສາມາດຈັດການກັບລະບົບຍ່ອຍແລະສູນສູນ.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// ຜູ້ຊ່ວຍ trait ເພື່ອຫລີກລ້ຽງການຊໍ້າຊ້ອນໂດຍພື້ນຖານທັງ ໝົດ ລະຫັດການແປງ ສຳ ລັບ `f32` ແລະ `f64`.
///
/// ເບິ່ງ ຄຳ ເຫັນຂອງ doc ຂອງໂມດູນ ສຳ ລັບເຫດຜົນທີ່ ຈຳ ເປັນ.
///
/// ຄວນບໍ່ເຄີຍ ** ໄດ້ຮັບການຈັດຕັ້ງປະຕິບັດ ສຳ ລັບປະເພດອື່ນຫລືຖືກ ນຳ ໃຊ້ຢູ່ນອກໂມດູນ dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// ປະເພດທີ່ໃຊ້ໂດຍ `to_bits` ແລະ `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// ປະຕິບັດການສົ່ງຕໍ່ແບບດິບໃຫ້ກັບຕົວເລກເຕັມ.
    fn to_bits(self) -> Self::Bits;

    /// ປະຕິບັດການສົ່ງຕໍ່ຈາກວັດຖຸດິບ.
    fn from_bits(v: Self::Bits) -> Self;

    /// ສົ່ງຄືນປະເພດທີ່ເລກນີ້ຕົກຢູ່.
    fn classify(self) -> FpCategory;

    /// ກັບຄືນ mantissa, ເລກ ກຳ ລັງແລະລົງນາມເປັນເລກເຕັມ.
    fn integer_decode(self) -> (u64, i16, i8);

    /// ຖອດລະຫັດທີ່ເລື່ອນລອຍ.
    fn unpack(self) -> Unpacked;

    /// ສຽງໂຫວດທັງຫມົດຈາກຕົວເລກນ້ອຍເຊິ່ງສາມາດເປັນຕົວແທນໄດ້ຢ່າງແນ່ນອນ.
    /// Panic ຖ້າຕົວເລກຍ່ອຍບໍ່ສາມາດເປັນຕົວແທນໄດ້, ລະຫັດອື່ນໃນໂມດູນນີ້ໃຫ້ແນ່ໃຈວ່າຈະບໍ່ປ່ອຍໃຫ້ສິ່ງນັ້ນເກີດຂື້ນ.
    fn from_int(x: u64) -> Self;

    /// ໄດ້ຮັບຄ່າ 10 <sup>e</sup> ຈາກຕາຕະລາງທີ່ຄິດໄລ່ມາກ່ອນ.
    /// Panics ສຳ ລັບ `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// ຊື່ຫຍັງເວົ້າ.
    /// ມັນງ່າຍຕໍ່ການໃສ່ລະຫັດຍາກກ່ວາການຂີ່ລົດເຂັນແລະຫວັງວ່າ LLVM ຄົງທີ່.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // ເປັນການອະນຸລັກທີ່ຜູກຢູ່ກັບຕົວເລກທົດສະນິຍົມຂອງປັດໄຈ ນຳ ເຂົ້າທີ່ບໍ່ສາມາດຜະລິດເກີນຫລືສູນຫລື
    /// ອະນຸພາກພື້ນ.ອາດຈະເປັນຕົວເລກທະສະນິຍົມຂອງມູນຄ່າປົກກະຕິສູງສຸດ, ສະນັ້ນຊື່.
    const MAX_NORMAL_DIGITS: usize;

    /// ໃນເວລາທີ່ຕົວເລກທົດສະນິຍົມທີ່ ສຳ ຄັນທີ່ສຸດມີມູນຄ່າທີ່ໃຫຍ່ກວ່ານີ້, ຕົວເລກແມ່ນແນ່ນອນເປັນນິດ.
    ///
    const INF_CUTOFF: i64;

    /// ເມື່ອຕົວເລກທົດສະນິຍົມທີ່ ສຳ ຄັນທີ່ສຸດມີຄ່າ ຕຳ ແໜ່ງ ທີ່ນ້ອຍກວ່ານີ້, ຕົວເລກແນ່ນອນເປັນຮູບສູນເປັນສູນ.
    ///
    const ZERO_CUTOFF: i64;

    /// ຈຳ ນວນຂອງບິດໃນ ຈຳ ນວນ.
    const EXP_BITS: u8;

    /// ຈຳ ນວນຂອງບິດໃນຄວາມ ໝາຍ ແລະ *ລວມທັງ* ສ່ວນນ້ອຍທີ່ເຊື່ອງໄວ້.
    const SIG_BITS: u8;

    /// ຈຳ ນວນຂອງບິດໃນຄວາມ ໝາຍ ແລະ *ຍົກເວັ້ນ* ບິດທີ່ເຊື່ອງໄວ້.
    const EXPLICIT_SIG_BITS: u8;

    /// ອະທິຜົນສູງສຸດທາງດ້ານກົດ ໝາຍ ໃນການເປັນຕົວແທນສ່ວນ ໜຶ່ງ.
    const MAX_EXP: i16;

    /// ການ ນຳ ສະ ເໜີ ນິຕິ ກຳ ຂັ້ນຕ່ ຳ ທີ່ສຸດໃນການເປັນຕົວແທນສ່ວນນ້ອຍ, ບໍ່ລວມເອົາຍ່ອຍຍ່ອຍ.
    const MIN_EXP: i16;

    /// `MAX_EXP` ສຳ ລັບການເປັນຕົວແທນລວມ, ຕົວຢ່າງ, ກັບການປ່ຽນແປງທີ່ ນຳ ໃຊ້.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` encoded (ໝາຍ ຄວາມວ່າມີຄວາມ ລຳ ອຽງທີ່ຊົດເຊີຍ)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` ສຳ ລັບການເປັນຕົວແທນລວມ, ຕົວຢ່າງ, ກັບການປ່ຽນແປງທີ່ ນຳ ໃຊ້.
    const MIN_EXP_INT: i16;

    /// ຄວາມ ໝາຍ ຕາມປົກກະຕິສູງສຸດແລະເປັນຕົວແທນລວມ.
    const MAX_SIG: u64;

    /// ຄວາມ ໝາຍ ປົກກະຕິ ໜ້ອຍ ທີ່ສຸດແລະການເປັນຕົວແທນລວມ.
    const MIN_SIG: u64;
}

// ສ່ວນໃຫຍ່ແມ່ນການເຮັດວຽກສໍາລັບ #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// ກັບຄືນ mantissa, ເລກ ກຳ ລັງແລະລົງນາມເປັນເລກເຕັມ.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // ອະຄະຕິຕໍ່ເນື່ອງ + ການປ່ຽນແປງ mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe ບໍ່ແນ່ໃຈວ່າ `as` ຮອບຕົວຢ່າງຖືກຕ້ອງໃນທຸກແພລະຕະຟອມຫລືບໍ່.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// ກັບຄືນ mantissa, ເລກ ກຳ ລັງແລະລົງນາມເປັນເລກເຕັມ.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // ອະຄະຕິຕໍ່ເນື່ອງ + ການປ່ຽນແປງ mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe ບໍ່ແນ່ໃຈວ່າ `as` ຮອບຕົວຢ່າງຖືກຕ້ອງໃນທຸກແພລະຕະຟອມຫລືບໍ່.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// ແປງ `Fp` ໃຫ້ເປັນປະເພດເລື່ອນເຄື່ອງທີ່ໃກ້ທີ່ສຸດ.
/// ບໍ່ໄດ້ຈັດການກັບຜົນໄດ້ຮັບທີ່ບໍ່ມີຕົວຕົນ.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f ແມ່ນ 64 ນ້ອຍ, ສະນັ້ນ xe ມີການປ່ຽນແປງ mantissa ຂອງ 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// ຮອບ 64 ບິດມີຄວາມ ໝາຍ ແລະ T::SIG_BITS X ນ້ອຍໆກັບເຄິ່ງ ໜຶ່ງ ເຖິງແມ່ນ.
/// ບໍ່ໄດ້ຈັດການກັບການໄຫຼເກີນ ກຳ ນົດ.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // ປັບປ່ຽນການປ່ຽນແປງ mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// ປີ້ນກັບກັນຂອງ `RawFloat::unpack()` ສຳ ລັບຕົວເລກປົກກະຕິ.
/// Panics ຖ້າຫາກວ່າ ໝາຍ ເຫດແລະເລກ ກຳ ລັງບໍ່ຖືກຕ້ອງ ສຳ ລັບຕົວເລກປົກກະຕິ.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // ເອົາສິ່ງທີ່ເຊື່ອງໄວ້ອອກ
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // ປັບຕົວເລກ ສຳ ລັບຄວາມອະຄະຕິແລະການປ່ຽນແປງຂອງ mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // ປ່ອຍປ້າຍນ້ອຍທີ່ 0 ("+"), ຕົວເລກຂອງພວກເຮົາທັງ ໝົດ ແມ່ນບວກ
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ການກໍ່ສ້າງເປັນ subnormal.mantissa ຂອງ 0 ແມ່ນອະນຸຍາດແລະກໍ່ສ້າງສູນ.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // ເລກລະຫັດທີ່ຖືກເຂົ້າລະຫັດແມ່ນ 0, ເຄື່ອງ ໝາຍ ນ້ອຍແມ່ນ 0, ດັ່ງນັ້ນພວກເຮົາພຽງແຕ່ຕ້ອງຕີຄວາມ ໝາຍ ຄືນ ໃໝ່.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ປະມານ bignum ກັບ Fp.ຮອບພາຍໃນ 0.5 ULP ກັບເຄິ່ງ ໜຶ່ງ ເຖິງແມ່ນວ່າ.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // ພວກເຮົາຕັດທ່ອນທັງ ໝົດ ກ່ອນດັດຊະນີ `start`, ໝາຍ ຄວາມວ່າ, ພວກເຮົາມີການປ່ຽນທິດທາງຂວາໂດຍປະລິມານ `start`, ສະນັ້ນນີ້ກໍ່ແມ່ນຕົວເລກທີ່ພວກເຮົາຕ້ອງການ.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // ຮອບ (half-to-even) ຂື້ນຢູ່ກັບສ່ວນທີ່ຖືກຕັດ.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// ຊອກຫາຕົວເລກຈຸດລອຍນໍ້າທີ່ໃຫຍ່ທີ່ສຸດນ້ອຍກວ່າຂໍ້ໂຕ້ແຍ້ງ.
/// ບໍ່ໄດ້ຈັດການກັບ subnormals, ສູນ, ຫຼື exponent underflow.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// ຊອກຫາຕົວເລກທີ່ລອຍຕົວນ້ອຍທີ່ສຸດໃຫຍ່ກວ່າຂໍ້ໂຕ້ແຍ້ງ.
// ການປະຕິບັດງານນີ້ແມ່ນອີ່ມຕົວ, ໝາຍ ຄວາມວ່າ next_float(inf) ==inf.
// ບໍ່ຄືກັບລະຫັດສ່ວນຫຼາຍໃນໂມດູນນີ້, ໜ້າ ທີ່ນີ້ສາມາດຈັດການສູນ, ອະນຸພາກພື້ນ, ແລະຄວາມບໍ່ມີຕົວຕົນ.
// ຢ່າງໃດກໍ່ຕາມ, ຄືກັບລະຫັດອື່ນໆທັງ ໝົດ ຢູ່ນີ້, ມັນບໍ່ກ່ຽວຂ້ອງກັບ NaN ແລະຕົວເລກລົບ.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // ນີ້ເບິ່ງຄືວ່າດີເກີນໄປທີ່ຈະເປັນຄວາມຈິງ, ແຕ່ມັນກໍ່ເຮັດໄດ້.
        // 0.0 ຖືກເຂົ້າລະຫັດເປັນ ຄຳ ທັງ ໝົດ ສູນ.ສັດຍ່ອຍມີຂະ ໜາດ 0x000m ... m ບ່ອນທີ່ m ແມ່ນ mantissa.
        // ໂດຍສະເພາະ, ອະມະຕະທີ່ນ້ອຍທີ່ສຸດແມ່ນ 0x0 ... 01 ແລະໃຫຍ່ທີ່ສຸດແມ່ນ 0x000F ... F.
        // ຕົວເລກປົກກະຕິທີ່ນ້ອຍທີ່ສຸດແມ່ນ 0x0010 ... 0, ສະນັ້ນກໍລະນີມູມນີ້ກໍ່ເຮັດໄດ້ຄືກັນ.
        // ຖ້າຫາກວ່າການເພີ່ມຂື້ນລົ້ນ mantissa, ກະເປົາແບດເຕີຣີເພີ່ມຂື້ນຂະ ໜາດ ຕາມທີ່ພວກເຮົາຕ້ອງການ, ແລະບິດຂອງ mantissa ກາຍເປັນສູນ.
        // ຍ້ອນວ່າສົນທິສັນຍານ້ອຍໆທີ່ຖືກປິດບັງ, ນີ້ກໍ່ແມ່ນສິ່ງທີ່ພວກເຮົາຕ້ອງການ!
        // ສຸດທ້າຍ, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}