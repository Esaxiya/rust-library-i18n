//! ສູດການຄິດໄລ່ຕ່າງໆຈາກເຈ້ຍ.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// ຈໍານວນຂອງ meanand bits ໃນ Fp
const P: u32 = 64;

// ພວກເຮົາພຽງແຕ່ເກັບຮັກສາປະມານທີ່ດີທີ່ສຸດ ສຳ ລັບ *ໝົດ* ເລກ ກຳ ນົດ, ສະນັ້ນຕົວປ່ຽນ "h" ແລະເງື່ອນໄຂທີ່ກ່ຽວຂ້ອງສາມາດຖືກຍົກເວັ້ນ.
// ປະສິດທິພາບການຄ້ານີ້ ສຳ ລັບສອງສາມກິໂລໄບຕໍ່ພື້ນທີ່.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// ໃນສະຖາປັດຕະຍະ ກຳ ສ່ວນໃຫຍ່, ການ ດຳ ເນີນງານຈຸດລອຍນ້ ຳ ມີຂະ ໜາດ ບິດທີ່ຊັດເຈນ, ສະນັ້ນຄວາມແມ່ນ ຍຳ ຂອງການ ຄຳ ນວນແມ່ນຖືກ ກຳ ນົດບົນພື້ນຖານການປະຕິບັດງານ.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// ໃນ x86, x87 FPU ຖືກໃຊ້ ສຳ ລັບການ ດຳ ເນີນງານທີ່ເລື່ອນໄດ້ຖ້າການຂະຫຍາຍ SSE/SSE2 ບໍ່ມີ.
// x87 FPU ປະຕິບັດງານກັບ 80 ບິດຂອງຄວາມແມ່ນຍໍາໂດຍຄ່າເລີ່ມຕົ້ນ, ຊຶ່ງ ໝາຍ ຄວາມວ່າການປະຕິບັດງານຈະມີຄວາມຍາວເຖິງ 80 ບິດເຮັດໃຫ້ການໄດ້ຕະຫຼອດສອງຄັ້ງເກີດຂື້ນເມື່ອຄ່າຕ່າງໆເປັນຕົວແທນໃນທີ່ສຸດ
//
// 32/64 ຄ່າເລື່ອນເລັກນ້ອຍ.ເພື່ອເອົາຊະນະສິ່ງນີ້, ຄຳ ສັ່ງຄວບຄຸມ FPU ສາມາດຕັ້ງຄ່າໄດ້ເພື່ອໃຫ້ການ ຄຳ ນວນໄດ້ຖືກປະຕິບັດຕາມຄວາມແມ່ນ ຍຳ ທີ່ຕ້ອງການ.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// ໂຄງສ້າງທີ່ໃຊ້ເພື່ອຮັກສາມູນຄ່າເດີມຂອງ ຄຳ ສັ່ງຄວບຄຸມ FPU, ເພື່ອໃຫ້ມັນສາມາດຟື້ນຟູໄດ້ເມື່ອໂຄງສ້າງຖືກລຸດລົງ.
    ///
    ///
    /// x87 FPU ແມ່ນລົງທະບຽນ 16 ບິດ, ເຊິ່ງມີທົ່ງນາດັ່ງຕໍ່ໄປນີ້:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// ເອກະສານ ສຳ ລັບທຸກໆຂົງເຂດແມ່ນມີຢູ່ໃນປື້ມຄູ່ມືຂອງນັກພັດທະນາໂປແກຼມສະຖາປັດຍະ ກຳ IA-32 (ເຫຼັ້ມທີ 1).
    ///
    /// ພາກສະຫນາມດຽວທີ່ກ່ຽວຂ້ອງກັບລະຫັດຕໍ່ໄປນີ້ແມ່ນ PC, ການຄວບຄຸມຄວາມແມ່ນຍໍາ.
    /// ພາກສະ ໜາມ ນີ້ ກຳ ນົດຄວາມຊັດເຈນຂອງການ ດຳ ເນີນງານທີ່ປະຕິບັດໂດຍ FPU.
    /// ມັນສາມາດຖືກຕັ້ງຄ່າໃຫ້:
    ///  - 0b00, ຄວາມແມ່ນຍໍາດຽວເຊັ່ນ: 32 ບິດ
    ///  - 0b10, ຄວາມແມ່ນຍໍາສອງເທົ່າເຊັ່ນ: 64 ບິດ
    ///  - 0b11, ຄວາມແມ່ນຍໍາຂະຫຍາຍສອງຄັ້ງເຊັ່ນ: 80 ບິດ (ສະພາບເດີມ) ຄ່າ 0b01 ແມ່ນຖືກສະຫງວນແລະບໍ່ຄວນໃຊ້.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // ຄວາມປອດໄພ: ຄຳ ແນະ ນຳ `fldcw` ໄດ້ຖືກກວດສອບເພື່ອໃຫ້ສາມາດເຮັດວຽກໄດ້ຢ່າງຖືກຕ້ອງ
        // `u16` ໃດໆ
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: ພວກເຮົາ ກຳ ລັງໃຊ້ syntax ATT ເພື່ອຮອງຮັບ LLVM 8 ແລະ LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// ຕັ້ງຄ່າພາກສະຫນາມທີ່ມີຄວາມແມ່ນຍໍາຂອງ FPU ຫາ `T` ແລະສົ່ງຄືນ `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // ລວບລວມມູນຄ່າ ສຳ ລັບພາກສະ ໜາມ ຄວບຄຸມຄວາມແມ່ນຍໍາທີ່ ເໝາະ ສົມກັບ `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 ບາດ
            8 => 0x0200, // 64 ບິດ
            _ => 0x0300, // ຄ່າເລີ່ມຕົ້ນ, 80 ບິດ
        };

        // ເອົາຄ່າຕົ້ນສະບັບຂອງ ຄຳ ສັບຄວບຄຸມເພື່ອໃຫ້ມັນກັບຄືນມາຫລັງ, ເມື່ອໂຄງສ້າງ `FPUControlWord` ຖືກລຸດລົງຢ່າງປອດໄພ: ຄຳ ແນະ ນຳ `fnstcw` ໄດ້ຖືກກວດສອບເພື່ອໃຫ້ສາມາດເຮັດວຽກໄດ້ຢ່າງຖືກຕ້ອງກັບ `u16` ໃດໆ.
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: ພວກເຮົາ ກຳ ລັງໃຊ້ syntax ATT ເພື່ອຮອງຮັບ LLVM 8 ແລະ LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // ຕັ້ງ ຄຳ ສັບຄວບຄຸມໃຫ້ຖືກຕ້ອງຕາມຄວາມຕ້ອງການ.
        // ນີ້ແມ່ນບັນລຸໄດ້ໂດຍການປິດບັງຄວາມແມ່ນຍໍາເກົ່າ (ບິດ 8 ແລະ 9, 0x300) ແລະປ່ຽນແທນດ້ວຍທຸງຄວາມແມ່ນຍໍາທີ່ຄິດໄລ່ຂ້າງເທິງ.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// ເສັ້ນທາງທີ່ໄວຂອງ Bellerophon ໂດຍໃຊ້ຕົວເລກຂະ ໜາດ ຂອງເຄື່ອງແລະເລື່ອນ.
///
/// ນີ້ຖືກສະກັດອອກເປັນຫນ້າທີ່ແຍກຕ່າງຫາກເພື່ອໃຫ້ມັນສາມາດພະຍາຍາມກ່ອນທີ່ຈະສ້າງ bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // ພວກເຮົາປຽບທຽບມູນຄ່າທີ່ແນ່ນອນກັບ MAX_SIG ໃກ້ຈະສິ້ນສຸດ, ນີ້ແມ່ນພຽງແຕ່ການປະຕິເສດທີ່ລວດໄວແລະລາຄາຖືກ (ແລະຍັງປ່ອຍໃຫ້ລະຫັດສ່ວນທີ່ເຫຼືອຈາກຄວາມກັງວົນກ່ຽວກັບການໄຫຼວຽນ).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // ເສັ້ນທາງໄວທີ່ ສຳ ຄັນແມ່ນຂື້ນກັບເລກຄະນິດສາດທີ່ຖືກມົນກັບ ຈຳ ນວນບິດທີ່ບໍ່ຖືກຕ້ອງໂດຍບໍ່ມີການຂື້ນຮອບປານກາງ.
    // ໃນ x86 (ໂດຍບໍ່ມີ SSE ຫຼື SSE2) ນີ້ຕ້ອງມີການປ່ຽນແປງຄວາມແມ່ນຍໍາຂອງ x87 FPU ເພື່ອໃຫ້ມັນມີການປ່ຽນແປງໂດຍກົງຈົນຮອດ 64/32 ນ້ອຍ.
    // ຟັງຊັນ `set_precision` ໃຊ້ເວລາດູແລໃນການຕັ້ງຄ່າຄວາມແມ່ນຍໍາກ່ຽວກັບສະຖາປັດຕະຍະ ກຳ ທີ່ຕ້ອງການຕັ້ງຄ່າມັນໂດຍການປ່ຽນສະຖານະຂອງໂລກ (ເຊັ່ນ ຄຳ ວ່າຄວບຄຸມຂອງ x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // ກໍລະນີ e <0 ບໍ່ສາມາດພັບເຂົ້າໄປໃນ branch ອື່ນໆ.
    // ອຳ ນາດໃນທາງລົບສົ່ງຜົນໃຫ້ເກີດພາກສ່ວນທີ່ຊ້ ຳ ຊ້ອນຊ້ ຳ ອີກໃນຖານສອງ, ເຊິ່ງເປັນຮູບກົມ, ເຊິ່ງກໍ່ໃຫ້ເກີດຂໍ້ຜິດພາດທີ່ແທ້ຈິງ (ແລະບາງຄັ້ງຄາວກໍ່ມີຄວາມ ສຳ ຄັນ!) ໃນຜົນສຸດທ້າຍ
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorithm Bellerophon ແມ່ນລະຫັດທີ່ບໍ່ສົມຄວນທີ່ຖືກວິເຄາະໂດຍການວິເຄາະຕົວເລກທີ່ບໍ່ແມ່ນຕົວຈິງ.
///
/// ມັນໂອບຮອບ ``f` `ໄປທີ່ເລື່ອນດ້ວຍ 64 ບິດມີຄວາມ ໝາຍ ແລະຄູນມັນໂດຍການປະມານທີ່ດີທີ່ສຸດຂອງ `10^e` (ໃນຮູບແບບຈຸດດຽວກັນ).ນີ້ມັກຈະພຽງພໍທີ່ຈະໄດ້ຮັບຜົນທີ່ຖືກຕ້ອງ.
/// ເຖິງຢ່າງໃດກໍ່ຕາມ, ເມື່ອຜົນໄດ້ຮັບໃກ້ຈະຮອດເຄິ່ງທາງລະຫວ່າງສອງເລື່ອນ (ordinary) ທີ່ຢູ່ຕິດກັນ, ຂໍ້ຜິດພາດຮອບປະສົມຈາກການຄູນສອງປະມານນັ້ນ ໝາຍ ຄວາມວ່າຜົນໄດ້ຮັບອາດຖືກປິດລົງໂດຍສອງສາມບິດ.
/// ເມື່ອສິ່ງນີ້ເກີດຂື້ນ, iterative Algorithm R ແກ້ໄຂບັນຫາ.
///
/// "close to halfway" ທີ່ເຮັດດ້ວຍມືດ້ວຍມືຖືກເຮັດໃຫ້ຊັດເຈນໂດຍການວິເຄາະຕົວເລກໃນເຈ້ຍ.
/// ໃນ ຄຳ ເວົ້າຂອງ Clinger:
///
/// > ເປີ້ນພູ, ສະແດງອອກເປັນຫົວ ໜ່ວຍ ນ້ອຍທີ່ ສຳ ຄັນ, ແມ່ນຂໍ້ຜູກມັດລວມ ສຳ ລັບຄວາມຜິດພາດ
/// > ສະສົມໃນໄລຍະການຄິດໄລ່ຈຸດລອຍຕົວຂອງປະມານໃຫ້ກັບ f * 10 ^ e.(ເລື່ອນແມ່ນ
/// > ບໍ່ແມ່ນຂໍ້ຜູກມັດ ສຳ ລັບຄວາມຜິດພາດທີ່ແທ້ຈິງ, ແຕ່ຜູກຄວາມແຕກຕ່າງລະຫວ່າງປະມານ z ແລະ
/// > ການຄາດຄະເນທີ່ເປັນໄປໄດ້ທີ່ດີທີ່ສຸດທີ່ໃຊ້ສ່ວນນ້ອຍໆຂອງ meanand.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // ກໍລະນີທີ່ abs(e) <log5(2^N) ແມ່ນຢູ່ໃນ fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // ເປີ້ນພູມີຂະ ໜາດ ໃຫຍ່ພໍທີ່ຈະເຮັດໃຫ້ມີຄວາມແຕກຕ່າງກັນບໍໃນເວລາທີ່ຈະຂ້ຽວເຂົ້າຫາ n bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// ສູດການຄິດໄລ່ທີ່ປັບປຸງການເລື່ອນຈຸດປະມານຂອງ `f * 10^e`.
///
/// ແຕ່ລະສຽງຂື້ນມາຈະມີ ໜ່ວຍ ໜຶ່ງ ຢູ່ໃນສະຖານທີ່ສຸດທີ່ໃກ້ກວ່າ, ແນ່ນອນວ່າມັນຕ້ອງໃຊ້ເວລາດົນນານໃນການຫັນປ່ຽນຖ້າຫາກວ່າ `z0` ມີຄວາມຮຸນແຮງ.
/// ໂຊກດີ, ໃນເວລາທີ່ຖືກນໍາໃຊ້ເປັນ fallback ສໍາລັບ Bellerophon, ປະມານການເລີ່ມຕົ້ນແມ່ນປິດໂດຍສ່ວນໃຫຍ່ແມ່ນ ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // ຊອກຫາເລກເຕັມບວກ `x`, `y` ວ່າ `x / y` ແມ່ນ `(f *10^e) / (m* 2^k)` ແທ້.
        // ນີ້ບໍ່ພຽງແຕ່ຫລີກລ້ຽງການຈັດການກັບອາການຂອງ `e` ແລະ `k`, ພວກເຮົາຍັງ ກຳ ຈັດ ອຳ ນາດຂອງສອງ ທຳ ມະດາໃຫ້ກັບ `10^e` ແລະ `2^k` ເພື່ອເຮັດໃຫ້ຕົວເລກນ້ອຍລົງ.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // ສິ່ງນີ້ຖືກຂຽນຂື້ນເລັກນ້ອຍເພາະວ່າ bignums ຂອງພວກເຮົາບໍ່ສະ ໜັບ ສະ ໜູນ ຕົວເລກລົບ, ດັ່ງນັ້ນພວກເຮົາຈຶ່ງໃຊ້ຂໍ້ມູນທີ່ມີຄ່າຢ່າງແທ້ຈິງ + ລົງນາມ.
        // ຕົວຄູນກັບ m_digits ບໍ່ສາມາດລົ້ນໄດ້.
        // ຖ້າ `x` ຫຼື `y` ມີຂະ ໜາດ ໃຫຍ່ພໍທີ່ພວກເຮົາຕ້ອງກັງວົນເລື່ອງການໄຫຼວຽນເກີນໄປ, ມັນກໍ່ມີຂະ ໜາດ ໃຫຍ່ພໍທີ່ `make_ratio` ໄດ້ຫຼຸດສ່ວນນ້ອຍລົງໂດຍປັດໃຈ 2 ^ 64 ຫຼືຫຼາຍກວ່ານັ້ນ.
        //
        //
        let (d2, d_negative) = if x >= y {
            // ບໍ່ ຈຳ ເປັນຕ້ອງໃຊ້ x ອີກຕໍ່ໄປ, ບັນທຶກ clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // ຍັງຕ້ອງການ y, ເຮັດ ສຳ ເນົາ.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// ເນື່ອງຈາກ `x = f` ແລະ `y = m` ບ່ອນທີ່ `f` ເປັນຕົວແທນຂອງຕົວເລກທົດສະນິຍົມເຂົ້າເປັນປະກະຕິແລະ `m` ແມ່ນຄວາມ ໝາຍ ແລະຈຸດປະມານທີ່ເລື່ອນໄດ້, ເຮັດໃຫ້ອັດຕາສ່ວນ `x / y` ເທົ່າກັບ `(f *10^e) / (m* 2^k)`, ອາດຈະຫຼຸດລົງໂດຍ ກຳ ລັງຂອງສອງທັງສອງທີ່ມີຢູ່ທົ່ວໄປ.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, ຍົກເວັ້ນວ່າພວກເຮົາຫຼຸດຜ່ອນສ່ວນ ໜຶ່ງ ໂດຍພະລັງງານບາງສ່ວນຂອງສອງ.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m ນີ້ບໍ່ສາມາດລົ້ນໄດ້ເພາະມັນຮຽກຮ້ອງໃຫ້ມີ `e` ບວກແລະ `k` ລົບ, ເຊິ່ງສາມາດເກີດຂື້ນໄດ້ ສຳ ລັບຄ່າທີ່ໃກ້ຄຽງກັບ 1 ເທົ່ານັ້ນ, ນັ້ນ ໝາຍ ຄວາມວ່າ `e` ແລະ `k` ຈະມີຂະ ໜາດ ນ້ອຍປຽບທຽບ.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k ມັນບໍ່ສາມາດລົ້ນໄດ້ເຊັ່ນດຽວກັນ, ເບິ່ງຂ້າງເທິງ.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), ຫຼຸດລົງອີກເທື່ອ ໜຶ່ງ ໂດຍພະລັງງານທົ່ວໄປຂອງສອງ.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// ແນວຄວາມຄິດ, Algorithm M ແມ່ນວິທີທີ່ງ່າຍທີ່ສຸດທີ່ຈະປ່ຽນອັດຕານິຍົມເປັນເລື່ອນ.
///
/// ພວກເຮົາປະກອບເປັນອັດຕາສ່ວນເທົ່າກັບ `f * 10^e`, ຫຼັງຈາກນັ້ນຖິ້ມໃນ ກຳ ລັງຂອງສອງຈົນກວ່າມັນຈະໃຫ້ຕົວແປທີ່ຖືກຕ້ອງແລະມີຄວາມ ໝາຍ.
/// `k` ຕົວເລກຖານສອງແມ່ນຕົວເລກຂອງຕົວເລກທີ່ພວກເຮົາຄູນເລກຫຼືຕົວຫານໂດຍສອງຕົວຢ່າງ, ຕະຫຼອດເວລາ `f *10^e` ເທົ່າກັບ `(u / v)* 2^k`.
/// ໃນເວລາທີ່ພວກເຮົາໄດ້ຄົ້ນພົບຄວາມ ໝາຍ ແລະພວກເຮົາພຽງແຕ່ຕ້ອງການຮອບໂດຍກວດກາສ່ວນທີ່ຍັງເຫຼືອຂອງພະແນກ, ເຊິ່ງເຮັດໃນ ໜ້າ ທີ່ຊ່ວຍໃນຕໍ່ໄປນີ້.
///
///
/// ສູດການຄິດໄລ່ນີ້ແມ່ນຊ້າທີ່ສຸດ, ເຖິງແມ່ນວ່າມີການເພີ່ມປະສິດທິພາບທີ່ໄດ້ອະທິບາຍໄວ້ໃນ `quick_start()`.
/// ເຖິງຢ່າງໃດກໍ່ຕາມ, ມັນງ່າຍດາຍທີ່ສຸດຂອງສູດການຄິດໄລ່ທີ່ຈະປັບຕົວ ສຳ ລັບຜົນໄດ້ຮັບທີ່ລົ້ນ, ລົ້ນໄຫລ, ແລະຜົນໄດ້ຮັບທີ່ຜິດປົກກະຕິ.
/// ການຈັດຕັ້ງປະຕິບັດນີ້ຈະເກີດຂື້ນເມື່ອ Bellerophon ແລະ Algorithm R ຖືກຄອບ ງຳ.
/// ການຊອກຄົ້ນຫາການໄຫຼວຽນແລະການໄຫຼເກີນແມ່ນງ່າຍ: ອັດຕາສ່ວນດັ່ງກ່າວຍັງບໍ່ແມ່ນຄວາມ ໝາຍ ທີ່ບໍ່ມີຂອບເຂດ, ແຕ່ຕົວເລກ minimum/maximum ຍັງບໍ່ທັນໄດ້ບັນລຸ.
/// ໃນກໍລະນີຂອງການລົ້ນ, ພວກເຮົາພຽງແຕ່ກັບຄືນ infinity.
///
/// ການຈັດການ underflow ແລະ subnormals ແມ່ນມີຄວາມຫຍຸ້ງຍາກຫຼາຍ.
/// ບັນຫາໃຫຍ່ ໜຶ່ງ ແມ່ນວ່າ, ໂດຍມີຕົວເລກຕ່ ຳ ສຸດ, ອັດຕາສ່ວນອາດຈະຍັງໃຫຍ່ເກີນໄປ ສຳ ລັບຄວາມ ໝາຍ ແລະ.
/// ເບິ່ງ underflow() ສຳ ລັບລາຍລະອຽດ.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // ການເພີ່ມປະສິດທິພາບທີ່ເປັນໄປໄດ້ຂອງ FIXME: generalize big_to_fp ເພື່ອໃຫ້ພວກເຮົາສາມາດເຮັດທຽບເທົ່າ fp_to_float(big_to_fp(u)) ໄດ້ທີ່ນີ້ເທົ່ານັ້ນ, ໂດຍບໍ່ຕ້ອງໄດ້ສອງເທົ່າ.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // ພວກເຮົາຕ້ອງໄດ້ຢຸດຢູ່ໃນ ຈຳ ນວນຕ່ ຳ ສຸດ, ຖ້າພວກເຮົາລໍຖ້າຈົນຮອດ `k < T::MIN_EXP_INT`, ຫຼັງຈາກນັ້ນພວກເຮົາກໍ່ຈະ ໝົດ ໄປຈາກປັດໄຈສອງ.
            // ແຕ່ໂຊກບໍ່ດີນີ້ ໝາຍ ຄວາມວ່າພວກເຮົາຕ້ອງໄດ້ພິເສດຕົວເລກປົກກະຕິທີ່ມີຕົວເລກຕ່ ຳ ສຸດ.
            // FIXME ຊອກຫາຮູບແບບທີ່ສະຫງ່າງາມກວ່າ, ແຕ່ໃຫ້ທົດສອບ `tiny-pow10` ເພື່ອໃຫ້ແນ່ໃຈວ່າມັນຖືກຕ້ອງແທ້ໆ!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// ຂ້າມຜ່ານສ່ວນໃຫຍ່ຂອງ Algorithm M iterations ໂດຍການກວດສອບຄວາມຍາວເລັກນ້ອຍ.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // ຄວາມຍາວເລັກນ້ອຍແມ່ນການຄາດຄະເນຂອງສອງ logarithm ຖານ, ແລະ log(u / v) = log(u), log(v).
    // ການຄາດຄະເນແມ່ນຫຼຸດລົງໂດຍສ່ວນໃຫຍ່ແມ່ນ 1, ແຕ່ສະເຫມີການຄາດຄະເນທີ່ບໍ່ຖືກຕ້ອງ, ສະນັ້ນຂໍ້ຜິດພາດໃນ log(u) ແລະ log(v) ແມ່ນສັນຍານດຽວກັນແລະຍົກເລີກອອກ (ຖ້າທັງສອງມີຂະ ໜາດ ໃຫຍ່).
    // ເພາະສະນັ້ນຂໍ້ຜິດພາດຂອງ log(u / v) ແມ່ນຫຼາຍທີ່ສຸດເຊັ່ນດຽວກັນ.
    // ອັດຕາສ່ວນເປົ້າ ໝາຍ ແມ່ນ ໜຶ່ງ ທີ່ u/v ແມ່ນຢູ່ໃນຄວາມ ໝາຍ ທີ່ບໍ່ມີຂອບເຂດ.ສະນັ້ນເງື່ອນໄຂການສິ້ນສຸດຂອງພວກເຮົາແມ່ນ log2(u / v) ເປັນສິ່ງທີ່ມີຄວາມ ໝາຍ ແລະຖັງນ້ອຍ, plus/minus.
    // FIXME ຊອກຫາຢູ່ສອງສ່ວນທີສອງສາມາດປັບປຸງການຄາດຄະເນແລະຫລີກລ້ຽງບາງພະແນກການ.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // underflow ຫຼື subnormal.ປ່ອຍໃຫ້ມັນເປັນຫນ້າທີ່ຕົ້ນຕໍ.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // ລົ້ນ.ປ່ອຍໃຫ້ມັນເປັນຫນ້າທີ່ຕົ້ນຕໍ.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // ອັດຕາສ່ວນແມ່ນບໍ່ມີຄວາມ ໝາຍ ໃນລະດັບແລະມີ ຈຳ ນວນຕ່ ຳ ສຸດ, ດັ່ງນັ້ນພວກເຮົາ ຈຳ ເປັນຕ້ອງໄດ້ປິດຕົວເລກທີ່ເກີນແລະດັດປັບ ຈຳ ນວນດັ່ງກ່າວໃຫ້ ເໝາະ ສົມ.
    // ມູນຄ່າທີ່ແທ້ຈິງດຽວນີ້ມີລັກສະນະດັ່ງນີ້:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(ສະແດງໂດຍ rem)
    //
    // ເພາະສະນັ້ນ, ໃນເວລາທີ່ກະບະມົນແມ່ນ!= 0.5 ULP, ພວກເຂົາຕັດສິນໃຈຕັດຮອບດ້ວຍຕົນເອງ.
    // ໃນເວລາທີ່ພວກເຂົາເທົ່າທຽມກັນແລະສ່ວນທີ່ເຫຼືອແມ່ນບໍ່ສູນ, ຄຸນຄ່າຍັງຕ້ອງໄດ້ຮັບການຈັດເປັນຮູບວົງມົນ.
    // ພຽງແຕ່ໃນເວລາທີ່ແຜ່ນປິດມົນແມ່ນ 1/2 ແລະສ່ວນທີ່ເຫຼືອແມ່ນສູນ, ພວກເຮົາມີສະຖານະການເຄິ່ງ ໜຶ່ງ ເຖິງແມ່ນ.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// ປະຊຸມສະໄຫມຕະຫຼອດຮອດເຖິງແມ່ນວ່າ, obfuscated ໂດຍມີຮອບໂດຍອີງໃສ່ສ່ວນທີ່ເຫຼືອຂອງພະແນກ.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}