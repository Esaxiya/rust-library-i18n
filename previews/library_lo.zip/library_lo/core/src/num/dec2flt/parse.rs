//! ການຢືນຢັນແລະເສື່ອມຄ່າແບບທົດສະນິຍົມຂອງແບບຟອມ:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! ໃນຄໍາສັບຕ່າງໆອື່ນໆ, syntax-floating-standard ມາດຕະຖານ, ມີຂໍ້ຍົກເວັ້ນສອງຢ່າງ: ບໍ່ມີສັນຍານ, ແລະບໍ່ມີການຈັດການກັບ "inf" ແລະ "NaN".ສິ່ງເຫຼົ່ານີ້ແມ່ນໄດ້ຖືກຈັດການໂດຍ ໜ້າ ທີ່ຂັບ (super::dec2flt).
//!
//! ເຖິງແມ່ນວ່າການຮັບຮູ້ການປ້ອນຂໍ້ມູນທີ່ຖືກຕ້ອງແມ່ນຂ້ອນຂ້າງງ່າຍ, ແຕ່ວ່າໂມດູນນີ້ຍັງຕ້ອງປະຕິເສດການປ່ຽນແປງທີ່ບໍ່ຖືກຕ້ອງທີ່ນັບບໍ່ຖ້ວນ, ບໍ່ເຄີຍ panic, ແລະ ດຳ ເນີນການກວດສອບຫລາຍໆຢ່າງທີ່ໂມດູນອື່ນໆອີງໃສ່ບໍ່ panic (ຫລືລົ້ນ).
//!
//! ເພື່ອເຮັດໃຫ້ບັນຫາຮ້າຍແຮງກວ່າເກົ່າ, ສິ່ງທັງ ໝົດ ທີ່ເກີດຂື້ນໃນການຜ່ານເຂົ້າດຽວ.
//! ສະນັ້ນ, ຕ້ອງລະມັດລະວັງໃນເວລາແກ້ໄຂຫຍັງ, ແລະກວດສອບສອງຄັ້ງກັບໂມດູນອື່ນໆ.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// ພາກສ່ວນທີ່ ໜ້າ ສົນໃຈຂອງສະຕຣານິຍົມ.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// ຕົວເລກທົດສະນິຍົມ, ຮັບປະກັນໃຫ້ມີຕົວເລກນ້ອຍກວ່າ 18 ທະສະນິຍົມ.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// ກວດເບິ່ງວ່າສະຕິງປ້ອນເຂົ້າແມ່ນຕົວເລກຈຸດລອຍຕົວທີ່ຖືກຕ້ອງແລະຖ້າເປັນແນວນັ້ນ, ຊອກຫາສະຖານທີ່ສ່ວນປະກອບ, ສ່ວນສ່ວນ, ແລະຕົວເລກຢູ່ໃນນັ້ນ.
/// ບໍ່ຈັດການກັບອາການ.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // ບໍ່ມີຕົວເລກກ່ອນ 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // ພວກເຮົາຕ້ອງການຢ່າງ ໜ້ອຍ ໜຶ່ງ ໂຕເລກກ່ອນຈຸດຫລືຫຼັງຈຸດ.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // ຫລັງຈາກຕິດຕາມສ່ວນທີ່ບໍ່ຖືກຕ້ອງ
            }
        }
        _ => Invalid, // ລາກຂີ້ເຫຍື່ອຫລັງຈາກຖີ້ມຕົວເລກ ທຳ ອິດ
    }
}

/// ແກະສະຫຼັກຕົວເລກທົດສະນິຍົມເຖິງຕົວເລກ ທຳ ອິດທີ່ບໍ່ແມ່ນຕົວເລກ.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// ການສະກັດເອົາແລະການກວດສອບຂໍ້ຜິດພາດ.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // ຫລັງຈາກຕິດຕາມຫລັງ
    }
    if number.is_empty() {
        return Invalid; // ອະທິບາຍອະທິບາຍ
    }
    // ໃນຈຸດນີ້, ພວກເຮົາແນ່ນອນວ່າພວກເຮົາຈະມີຕົວເລກທີ່ຖືກຕ້ອງ.ມັນອາດຈະຍາວເກີນໄປທີ່ຈະໃສ່ `i64`, ແຕ່ຖ້າມັນໃຫຍ່, ການປ້ອນຂໍ້ມູນແມ່ນແນ່ນອນວ່າມັນເປັນສູນຫຼື infinity.
    // ເນື່ອງຈາກວ່າແຕ່ລະເລກສູນໃນຕົວເລກທົດສະນິຍົມພຽງແຕ່ດັດປັບຕົວເລກໂດຍ +/-1, ທີ່ exp=10 ^ 18 ການປ້ອນຂໍ້ມູນຈະຕ້ອງເປັນ (!) ຈຳ ນວນ 17 ຕົວຂະ ໜາດ ໃຫຍ່ເກີນໄປເພື່ອໃຫ້ໄດ້ໃກ້ເຖິງຫ່າງໄກຈາກການເປັນທີ່ສຸດ.
    //
    // ນີ້ບໍ່ແມ່ນກໍລະນີການ ນຳ ໃຊ້ທີ່ພວກເຮົາ ຈຳ ເປັນຕ້ອງຕອບສະ ໜອງ.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}