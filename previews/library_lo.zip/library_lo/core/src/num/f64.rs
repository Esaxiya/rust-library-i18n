//! ຄົງທີ່ສະເພາະກັບປະເພດຈຸດເລື່ອນທີ່ມີຄວາມແມ່ນຍໍາສອງເທົ່າ `f64`.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! ເລກທີ່ ສຳ ຄັນທາງຄະນິດສາດແມ່ນໄດ້ສະ ໜອງ ໃຫ້ໃນ `consts` ຍ່ອຍ.
//!
//! ສຳ ລັບ ຈຳ ນວນທີ່ຖືກ ກຳ ນົດໂດຍກົງໃນໂມດູນນີ້ (ແຕກຕ່າງຈາກຕົວ ກຳ ນົດທີ່ອະນຸຍາດໃນ `consts` ຍ່ອຍ), ລະຫັດ ໃໝ່ ແທນທີ່ຈະໃຊ້ລະດັບທີ່ກ່ຽວຂ້ອງທີ່ຖືກ ກຳ ນົດໂດຍກົງໃສ່ຊະນິດ `f64`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// radix ຫຼືພື້ນຖານຂອງການເປັນຕົວແທນພາຍໃນຂອງ `f64`.
/// ໃຊ້ [`f64::RADIX`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// ຈຳ ນວນຕົວເລກທີ່ ສຳ ຄັນໃນຖານ 2.
/// ໃຊ້ [`f64::MANTISSA_DIGITS`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// ຈຳ ນວນປະມານຂອງຕົວເລກທີ່ ສຳ ຄັນໃນຖານ 10.
/// ໃຊ້ [`f64::DIGITS`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] ມູນຄ່າ ສຳ ລັບ `f64`.
/// ໃຊ້ [`f64::EPSILON`] ແທນ.
///
/// ນີ້ແມ່ນຄວາມແຕກຕ່າງລະຫວ່າງ `1.0` ແລະຕົວເລກຕົວແທນທີ່ໃຫຍ່ກວ່າຕໍ່ໄປ.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// ມູນຄ່າ `f64` ທີ່ນ້ອຍທີ່ສຸດ.
/// ໃຊ້ [`f64::MIN`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// ມູນຄ່າ `f64` ປົກກະຕິທີ່ມີຂະ ໜາດ ນ້ອຍທີ່ສຸດ.
/// ໃຊ້ [`f64::MIN_POSITIVE`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// ມູນຄ່າ `f64` ຈົບງາມທີ່ໃຫຍ່ທີ່ສຸດ.
/// ໃຊ້ [`f64::MAX`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// ຫນຶ່ງໃຫຍ່ກ່ວາພະລັງງານປົກກະຕິທີ່ເປັນໄປໄດ້ຕ່ ຳ ສຸດ 2 exponent.
/// ໃຊ້ [`f64::MIN_EXP`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// ພະລັງງານທີ່ເປັນໄປໄດ້ສູງສຸດຂອງ 2 ເລກ ກຳ ລັງ.
/// ໃຊ້ [`f64::MAX_EXP`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// ພະລັງງານປົກກະຕິຕ່ ຳ ສຸດ 10 ຕົວເລກ.
/// ໃຊ້ [`f64::MIN_10_EXP`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// ພະລັງງານທີ່ເປັນໄປໄດ້ສູງສຸດ 10 ຕົວເລກ.
/// ໃຊ້ [`f64::MAX_10_EXP`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// ບໍ່ແມ່ນເລກ (NaN).
/// ໃຊ້ [`f64::NAN`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// ໃຊ້ [`f64::INFINITY`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// infinity (−∞) ລົບ.
/// ໃຊ້ [`f64::NEG_INFINITY`] ແທນ.
///
/// # Examples
///
/// ```rust
/// // ວິທີການຄັດຄ້ານ
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // ວິທີການທີ່ມີຈຸດປະສົງ
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// ຈຳ ນວນພື້ນຖານທາງຄະນິດສາດ.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: ທົດແທນດ້ວຍຄົງທີ່ທາງຄະນິດສາດຈາກ cmath.

    /// (π) ຄົງທີ່ຂອງ Archimedes
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// ວົງວຽນຄົງທີ່ (τ)
    ///
    /// ເທົ່າກັບ2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// ເລກຂອງ Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// radix ຫຼືພື້ນຖານຂອງການເປັນຕົວແທນພາຍໃນຂອງ `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// ຈຳ ນວນຕົວເລກທີ່ ສຳ ຄັນໃນຖານ 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// ຈຳ ນວນປະມານຂອງຕົວເລກທີ່ ສຳ ຄັນໃນຖານ 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] ມູນຄ່າ ສຳ ລັບ `f64`.
    ///
    /// ນີ້ແມ່ນຄວາມແຕກຕ່າງລະຫວ່າງ `1.0` ແລະຕົວເລກຕົວແທນທີ່ໃຫຍ່ກວ່າຕໍ່ໄປ.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// ມູນຄ່າ `f64` ທີ່ນ້ອຍທີ່ສຸດ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// ມູນຄ່າ `f64` ປົກກະຕິທີ່ມີຂະ ໜາດ ນ້ອຍທີ່ສຸດ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// ມູນຄ່າ `f64` ຈົບງາມທີ່ໃຫຍ່ທີ່ສຸດ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// ຫນຶ່ງໃຫຍ່ກ່ວາພະລັງງານປົກກະຕິທີ່ເປັນໄປໄດ້ຕ່ ຳ ສຸດ 2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// ພະລັງງານທີ່ເປັນໄປໄດ້ສູງສຸດຂອງ 2 ເລກ ກຳ ລັງ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// ພະລັງງານປົກກະຕິຕ່ ຳ ສຸດ 10 ຕົວເລກ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// ພະລັງງານທີ່ເປັນໄປໄດ້ສູງສຸດ 10 ຕົວເລກ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// ບໍ່ແມ່ນເລກ (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// infinity (−∞) ລົບ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// ສົ່ງຄືນ `true` ຖ້າມູນຄ່ານີ້ແມ່ນ `NaN`.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` ແມ່ນບໍ່ສາມາດໃຊ້ໄດ້ໃນສາທາລະນະໃນ libcore ເນື່ອງຈາກຄວາມກັງວົນກ່ຽວກັບການເຄື່ອນທີ່, ສະນັ້ນການຈັດຕັ້ງປະຕິບັດນີ້ແມ່ນເພື່ອການ ນຳ ໃຊ້ສ່ວນຕົວພາຍໃນ.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// ສົ່ງຄືນ `true` ຖ້າມູນຄ່ານີ້ແມ່ນ infinity ໃນທາງບວກຫຼື infinity ທາງລົບ, ແລະ `false` ຖ້າບໍ່ດັ່ງນັ້ນ.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// ສົ່ງຄືນ `true` ຖ້າ ຈຳ ນວນນີ້ບໍ່ມີທັງນິດແລະ `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // ບໍ່ ຈຳ ເປັນຕ້ອງຈັດການກັບ NaN ແຍກຕ່າງຫາກ: ຖ້າຕົວເອງແມ່ນ NaN, ການປຽບທຽບບໍ່ແມ່ນຄວາມຈິງ, ແນ່ນອນຕາມຄວາມຕ້ອງການ.
        //
        self.abs_private() < Self::INFINITY
    }

    /// ສົ່ງຄືນ `true` ຖ້າ ຈຳ ນວນແມ່ນ [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // ຄຸນຄ່າລະຫວ່າງ `0` ແລະ `min` ແມ່ນ Subnormal.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// ສົ່ງຄືນ `true` ຖ້າ ຈຳ ນວນບໍ່ແມ່ນສູນ, ນິດ, [subnormal], ຫຼື `NaN`.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // ຄຸນຄ່າລະຫວ່າງ `0` ແລະ `min` ແມ່ນ Subnormal.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// ກັບຄືນປະເພດຈຸດລອຍຂອງ ຈຳ ນວນ.
    /// ຖ້າມີພຽງແຕ່ຊັບສິນດຽວທີ່ຈະຖືກທົດສອບ, ໂດຍທົ່ວໄປແລ້ວມັນຈະໄວກວ່າທີ່ຈະໃຊ້ຕົວຊີ້ບອກສະເພາະແທນ.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// ກັບຄືນ `true` ຖ້າ `self` ມີສັນຍານບວກ, ລວມທັງ `+0.0`, `NaN`s ທີ່ມີສັນຍານບວກແລະ infinity ໃນທາງບວກ.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// ກັບຄືນ `true` ຖ້າ `self` ມີສັນຍານລົບ, ລວມທັງ `-0.0`, `NaN ທີ່ມີສັນຍານລົບແລະ infinity ທາງລົບ.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// ເອົາ (inverse) ຕ່າງກັນຂອງ ຈຳ ນວນ, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// ແປງລັງສີເປັນອົງສາ.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // ພະແນກຢູ່ທີ່ນີ້ແມ່ນກົມມົນຢ່າງຖືກຕ້ອງຕາມມູນຄ່າທີ່ແທ້ຈິງຂອງ 180/π.
        // (ມັນແຕກຕ່າງຈາກ f32, ບ່ອນທີ່ຄົງທີ່ຕ້ອງຖືກ ນຳ ໃຊ້ເພື່ອຮັບປະກັນຜົນໄດ້ຮັບທີ່ຖືກຕ້ອງ.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// ແປງອົງສາເປັນ radians.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// ກັບຄືນ ຈຳ ນວນສູງສຸດຂອງສອງຕົວເລກ.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// ຖ້າການໂຕ້ຖຽງຫນຶ່ງແມ່ນ NaN, ຫຼັງຈາກນັ້ນການໂຕ້ຖຽງອື່ນໆກໍ່ຖືກສົ່ງຄືນ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// ກັບຄືນຕໍາ່ສຸດທີ່ຂອງສອງຕົວເລກ.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// ຖ້າການໂຕ້ຖຽງຫນຶ່ງແມ່ນ NaN, ຫຼັງຈາກນັ້ນການໂຕ້ຖຽງອື່ນໆກໍ່ຖືກສົ່ງຄືນ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// ຮອບເປັນສູນແລະປ່ຽນເປັນປະເພດເລກປະຖົມນິຖານ, ສົມມຸດວ່າມູນຄ່າດັ່ງກ່າວແມ່ນ ຈຳ ກັດແລະ ເໝາະ ສົມກັບປະເພດນັ້ນ.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// ມູນຄ່າຕ້ອງ:
    ///
    /// * ບໍ່ແມ່ນ `NaN`
    /// * ບໍ່ເປັນນິດ
    /// * ເປັນຕົວແທນໃນແບບ `Int` ກັບຄືນ, ຫຼັງຈາກຕັດສ່ວນທີ່ເປັນສ່ວນປະກອບຂອງມັນ
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// ການສົ່ງຕໍ່ດິບໄປ `u64`.
    ///
    /// ປະຈຸບັນນີ້ແມ່ນຄ້າຍຄືກັບ `transmute::<f64, u64>(self)` ໃນທຸກແພລະຕະຟອມ.
    ///
    /// ເບິ່ງ `from_bits` ສຳ ລັບບາງການສົນທະນາກ່ຽວກັບການເຄື່ອນໄຫວຂອງການ ດຳ ເນີນງານນີ້ (ມີເກືອບບໍ່ມີບັນຫາ).
    ///
    /// ໃຫ້ສັງເກດວ່າຫນ້າທີ່ນີ້ແຕກຕ່າງຈາກການຫລໍ່ `as`, ເຊິ່ງພະຍາຍາມຮັກສາຄຸນຄ່າ * ຕົວເລກ, ແລະບໍ່ແມ່ນຄ່າເລັກນ້ອຍ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() ບໍ່ ກຳ ລັງຫລໍ່!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // ຄວາມປອດໄພ: `u64` ແມ່ນແຜ່ນ ທຳ ມະດາເກົ່າແກ່ ທຳ ມະດາດັ່ງນັ້ນພວກເຮົາສາມາດຖ່າຍທອດມັນຢູ່ສະ ເໝີ
        unsafe { mem::transmute(self) }
    }

    /// ການສົ່ງຕໍ່ດິບຈາກ `u64`.
    ///
    /// ປະຈຸບັນນີ້ແມ່ນຄ້າຍຄືກັບ `transmute::<u64, f64>(v)` ໃນທຸກແພລະຕະຟອມ.
    /// ມັນຫັນອອກວ່າມັນເປັນສິ່ງທີ່ສາມາດ ນຳ ໃຊ້ໄດ້ຢ່າງບໍ່ ໜ້າ ເຊື່ອ, ສຳ ລັບສອງເຫດຜົນ:
    ///
    /// * Floats ແລະ Ints ມີຄວາມເປັນເອກະພາບກັນໃນທຸກເວທີທີ່ຮອງຮັບ.
    /// * IEEE-754 ແມ່ນລະບຸຢ່າງຊັດເຈນກ່ຽວກັບການຈັດວາງແບບເລື່ອນລອຍ.
    ///
    /// ເຖິງຢ່າງໃດກໍ່ຕາມມັນມີຄວາມລະແວງສົງໄສ ໜຶ່ງ: ກ່ອນສະບັບ 2008 ຂອງ IEEE-754, ວິທີການຕີຄວາມ ໝາຍ ສັນຍານຂອງ NaN ບໍ່ໄດ້ຖືກລະບຸຕົວຈິງ.
    /// ເວທີສ່ວນໃຫຍ່ (ໂດຍສະເພາະ x86 ແລະ ARM) ໄດ້ເລືອກເອົາການຕີລາຄາທີ່ຖືກມາດຕະຖານໃນທີ່ສຸດໃນປີ 2008, ແຕ່ບາງບ່ອນກໍ່ບໍ່ໄດ້ (ໂດຍສະເພາະ MIPS).
    /// ດັ່ງນັ້ນ, ທຸກສັນຍານຂອງ NaN ທີ່ຢູ່ MIPS ແມ່ນ NaNs ທີ່ງຽບສະຫງັດໃນ x86, ແລະໃນທາງກັບກັນ.
    ///
    /// ແທນທີ່ຈະພະຍາຍາມຮັກສາເສັ້ນທາງຂ້າມສັນຍາລັກທີ່ບໍ່ມີສັນຍານ, ການຈັດຕັ້ງປະຕິບັດນີ້ ເໝາະ ສົມກັບການຮັກສາທ່ອນໄມ້ທີ່ແນ່ນອນ.
    /// ນີ້ຫມາຍຄວາມວ່າຄ່າຂົນສົ່ງໃດໆທີ່ຖືກເຂົ້າລະຫັດໃນ NaNs ຈະຖືກເກັບຮັກສາໄວ້ເຖິງແມ່ນວ່າຜົນໄດ້ຮັບຂອງວິທີການນີ້ຈະຖືກສົ່ງຜ່ານເຄືອຂ່າຍຈາກເຄື່ອງ x86 ໄປຫາເຄື່ອງ MIPS.
    ///
    ///
    /// ຖ້າຜົນໄດ້ຮັບຂອງວິທີການນີ້ຖືກດັດແປງໂດຍສະຖາປັດຕະຍະ ກຳ ດຽວກັນທີ່ຜະລິດພວກມັນ, ແລ້ວມັນກໍ່ບໍ່ມີຄວາມເປັນຫ່ວງກ່ຽວກັບການເຄື່ອນທີ່.
    ///
    /// ຖ້າການປ້ອນຂໍ້ມູນບໍ່ແມ່ນ NaN, ຫຼັງຈາກນັ້ນກໍ່ບໍ່ມີຄວາມກັງວົນກ່ຽວກັບການເຄື່ອນທີ່.
    ///
    /// ຖ້າທ່ານບໍ່ສົນໃຈສັນຍານທີ່ບໍ່ມີສັນຍານ (ອາດຈະເປັນ), ຫຼັງຈາກນັ້ນກໍ່ບໍ່ມີຄວາມກັງວົນກ່ຽວກັບການເຄື່ອນທີ່.
    ///
    /// ໃຫ້ສັງເກດວ່າຫນ້າທີ່ນີ້ແຕກຕ່າງຈາກການຫລໍ່ `as`, ເຊິ່ງພະຍາຍາມຮັກສາຄຸນຄ່າ * ຕົວເລກ, ແລະບໍ່ແມ່ນຄ່າເລັກນ້ອຍ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // ຄວາມປອດໄພ: `u64` ແມ່ນແຜ່ນ ທຳ ມະດາທີ່ເກົ່າແກ່ດັ່ງນັ້ນພວກເຮົາສາມາດຖ່າຍທອດຈາກມັນໄດ້ສະ ເໝີ
        // ມັນຫັນອອກບັນຫາດ້ານຄວາມປອດໄພກັບ sNaN ແມ່ນຖືກລ້າໆ!ຮື!
        unsafe { mem::transmute(v) }
    }

    /// ສົ່ງຄືນຕົວແທນຂອງຄວາມຊົງ ຈຳ ຂອງ ຈຳ ນວນຈຸດທີ່ລອຍມານີ້ເປັນຂບວນ byte ໃນ (network) byte ທີ່ໃຫຍ່.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// ສົ່ງຄືນຕົວແທນຂອງຄວາມຊົງ ຈຳ ຂອງ ຈຳ ນວນຈຸດທີ່ລອຍມານີ້ເປັນຂບວນ byte ໃນ ລຳ ດັບໄບຕີ້.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// ສົ່ງຄືນຕົວແທນຄວາມຊົງ ຈຳ ຂອງ ຈຳ ນວນຈຸດທີ່ລອຍມານີ້ເປັນຂບວນໄບຕ໌ຕາມ ລຳ ດັບໄບຕ໌ຕາມເດີມ.
    ///
    /// ໃນຂະນະທີ່ຄວາມນິຍົມຂອງພື້ນເມືອງຂອງເວທີເປົ້າ ໝາຍ ຖືກໃຊ້, ລະຫັດແບບພະກະພາຄວນໃຊ້ [`to_be_bytes`] ຫຼື [`to_le_bytes`], ຕາມຄວາມ ເໝາະ ສົມ, ແທນ.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// ສົ່ງຄືນຕົວແທນຄວາມຊົງ ຈຳ ຂອງ ຈຳ ນວນຈຸດທີ່ລອຍມານີ້ເປັນຂບວນໄບຕ໌ຕາມ ລຳ ດັບໄບຕ໌ຕາມເດີມ.
    ///
    ///
    /// [`to_ne_bytes`] ຄວນຈະເປັນທີ່ຕ້ອງການໃນໄລຍະນີ້ເມື່ອເປັນໄປໄດ້.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // ຄວາມປອດໄພ: `f64` ແມ່ນແຜ່ນ ທຳ ມະດາເກົ່າແກ່ ທຳ ມະດາສະນັ້ນພວກເຮົາສາມາດຖ່າຍທອດມັນຢູ່ສະ ເໝີ
        unsafe { &*(self as *const Self as *const _) }
    }

    /// ສ້າງມູນຄ່າຈຸດທີ່ໂດດເດັ່ນຈາກການເປັນຕົວແທນຂອງມັນເປັນຂບວນ byte ໃນ endian ໃຫຍ່.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// ສ້າງມູນຄ່າຈຸດທີ່ໂດດເດັ່ນຈາກການເປັນຕົວແທນຂອງມັນເປັນຂບວນ byte ໃນ endian ພຽງເລັກນ້ອຍ.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// ສ້າງມູນຄ່າຈຸດທີ່ໂດດເດັ່ນຈາກການເປັນຕົວແທນຂອງມັນເປັນຂບວນ byte ໃນຕົວແທນພື້ນເມືອງ.
    ///
    /// ໃນຂະນະທີ່ຄວາມນິຍົມຂອງພື້ນເມືອງຂອງເວທີເປົ້າ ໝາຍ ຖືກໃຊ້, ລະຫັດແບບເຄື່ອນທີ່ອາດຈະຕ້ອງການໃຊ້ [`from_be_bytes`] ຫຼື [`from_le_bytes`], ຕາມຄວາມ ເໝາະ ສົມແທນ.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// ສົ່ງຄືນການຈັດ ລຳ ດັບລະຫວ່າງຕົນເອງແລະຄຸນຄ່າອື່ນໆ.
    /// ບໍ່ຄືກັບການປຽບທຽບບາງສ່ວນຂອງມາດຕະຖານລະຫວ່າງຕົວເລກຈຸດທີ່ເລື່ອນໄດ້, ການປຽບທຽບນີ້ສະເຫມີຜະລິດເປັນລະບຽບຕາມຂໍ້ ກຳ ນົດ TotalOrder ທີ່ໄດ້ ກຳ ນົດໄວ້ໃນມາດຕະຖານຈຸດລອຍຂອງ IEEE 754 (2008 ແກ້ໄຂ).
    /// ຄຸນຄ່າແມ່ນຖືກສັ່ງຕາມລະບຽບດັ່ງຕໍ່ໄປນີ້:
    /// - NaN ງຽບລົບ
    /// - ສັນຍາລັກທາງລົບ NaN
    /// - infinity ກະທົບທາງລົບ
    /// - ເລກລົບ
    /// - ຕົວເລກອະນຸພາກລົບ
    /// - ສູນລົບ
    /// - ສູນບວກ
    /// - ຕົວເລກຍ່ອຍທີ່ບໍ່ດີດ້ານບວກ
    /// - ເລກບວກ
    /// - infinity ໃນທາງບວກ
    /// - ສັນຍານໃນທາງບວກ NaN
    /// - NaN ງຽບໃນທາງບວກ
    ///
    /// ໃຫ້ສັງເກດວ່າຫນ້າທີ່ນີ້ບໍ່ໄດ້ຕົກລົງເຫັນດີກັບການປະຕິບັດ [`PartialOrd`] ແລະ [`PartialEq`] ຂອງ `f64`.ໂດຍສະເພາະ, ພວກເຂົາຖືວ່າສູນລົບແລະບວກເທົ່າກັບເທົ່າກັນ, ໃນຂະນະທີ່ `total_cmp` ບໍ່ໄດ້.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // ໃນກໍລະນີທີ່ມີຂໍ້ເສຍ, ກະບອກກະຕ່າທັງ ໝົດ ຍົກເວັ້ນສັນຍານເພື່ອບັນລຸຮູບແບບຄ້າຍຄືກັນກັບສອງຕົວເຕີມເຕັມ
        //
        // ເປັນຫຍັງການເຮັດວຽກນີ້?ເຮືອ IEEE 754 ທີ່ປະກອບດ້ວຍສາມທົ່ງນາ:
        // ລົງທະບຽນນ້ອຍ, ເລກ ກຳ ລັງແລະ mantissa.ທີ່ກໍານົດໄວ້ຂອງເຂດຂໍ້ກໍານົດແລະ mantissa ທັງຫມົດມີຄຸນສົມບັດທີ່ຄໍາສັ່ງເລັກນ້ອຍຂອງພວກເຂົາແມ່ນເທົ່າກັບຂະຫນາດຂອງຕົວເລກທີ່ຂະຫນາດໄດ້ຖືກກໍານົດ.
        // ຂະ ໜາດ ໃຫຍ່ບໍ່ໄດ້ຖືກ ກຳ ນົດໂດຍ ທຳ ມະດາກ່ຽວກັບຄ່າ NaN, ແຕ່ IEEE 754 totalOrder ກຳ ນົດຄ່າ NaN ກໍ່ໃຫ້ປະຕິບັດຕາມ ຄຳ ສັ່ງທີ່ມີຄ່າເລັກນ້ອຍ.ນີ້ເຮັດໃຫ້ ຄຳ ສັ່ງທີ່ຖືກອະທິບາຍໃນ ຄຳ ເຫັນຂອງ doc.
        // ເຖິງຢ່າງໃດກໍ່ຕາມ, ການສະແດງຂອງຂະ ໜາດ ແມ່ນຄືກັນກັບຕົວເລກລົບແລະບວກ-ພຽງແຕ່ເຄື່ອງ ໝາຍ ນ້ອຍຈະແຕກຕ່າງກັນ.
        // ເພື່ອປຽບທຽບພື້ນເຮືອນໄດ້ຢ່າງງ່າຍດາຍເປັນເລກເຕັມທີ່ມີລາຍເຊັນ, ພວກເຮົາ ຈຳ ເປັນຕ້ອງພິກແຜ່ນຈາລຶກແລະ mantissa ໃນກໍລະນີທີ່ມີຕົວເລກລົບ.
        // ພວກເຮົາປ່ຽນຕົວເລກດັ່ງກ່າວໃຫ້ເປັນຮູບແບບ "two's complement" ຢ່າງມີປະສິດຕິຜົນ.
        //
        // ເພື່ອເຮັດກະແສໄຟ, ພວກເຮົາສ້າງ ໜ້າ ກາກແລະ XOR ຕ້ານມັນ.
        // ພວກເຮົາສາມາດຄິດໄລ່ ໜ້າ ກາກ "all-ones except for the sign bit" ຈາກຄຸນຄ່າທີ່ມີລາຍເຊັນໃນທາງລົບ: ສັນຍານປ່ຽນຂວາ-ຂະຫຍາຍເລກເຕັມ, ສະນັ້ນພວກເຮົາ "fill" ໜ້າ ກາກທີ່ມີບິດເຊັນສັນຍາ, ແລະຫຼັງຈາກນັ້ນປ່ຽນເປັນທີ່ບໍ່ໄດ້ລົງນາມເພື່ອຍູ້ ໜຶ່ງ ສ່ວນນ້ອຍ.
        //
        // ກ່ຽວກັບຄຸນຄ່າໃນທາງບວກ, ໜ້າ ກາກແມ່ນສູນທັງ ໝົດ, ສະນັ້ນມັນບໍ່ແມ່ນ.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// ຈຳ ກັດຄ່າໃນໄລຍະຫ່າງທີ່ແນ່ນອນເວັ້ນເສຍແຕ່ວ່າມັນແມ່ນ NaN.
    ///
    /// ກັບຄືນ `max` ຖ້າ `self` ໃຫຍ່ກວ່າ `max`, ແລະ `min` ຖ້າ `self` ນ້ອຍກວ່າ `min`.
    /// ຖ້າບໍ່ດັ່ງນັ້ນສິ່ງນີ້ຈະສົ່ງຄືນ `self`.
    ///
    /// ໃຫ້ສັງເກດວ່າຟັງຊັນນີ້ຈະກັບຄືນ NaN ຖ້າວ່າຄ່າເລີ່ມຕົ້ນແມ່ນ NaN ເຊັ່ນກັນ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `min > max`, `min` ແມ່ນ NaN, ຫຼື `max` ແມ່ນ NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}