//! ຄົງທີ່ ສຳ ລັບປະເພດເລກທະບຽນ 32 ບິດ.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! ລະຫັດ ໃໝ່ ຄວນໃຊ້ຄົງທີ່ທີ່ກ່ຽວຂ້ອງໂດຍກົງໃສ່ປະເພດເດີມ.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }