//! ປະເພດຄົງທີ່ ສຳ ລັບເຄື່ອງ ໝາຍ ເລກຂະ ໜາດ ທີ່ເຊັນດ້ວຍຕົວຊີ້.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! ລະຫັດ ໃໝ່ ຄວນໃຊ້ຄົງທີ່ທີ່ກ່ຽວຂ້ອງໂດຍກົງໃສ່ປະເພດເດີມ.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }