//! ຄົງທີ່ ສຳ ລັບປະເພດເລກເຕັມ 16-bit ເຊັນ.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! ລະຫັດ ໃໝ່ ຄວນໃຊ້ຄົງທີ່ທີ່ກ່ຽວຂ້ອງໂດຍກົງໃສ່ປະເພດເດີມ.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }