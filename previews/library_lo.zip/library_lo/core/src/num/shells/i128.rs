//! ຄົງທີ່ ສຳ ລັບປະເພດເລກເຕັມ 128-bit ເຊັນ.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! ລະຫັດ ໃໝ່ ຄວນໃຊ້ຄົງທີ່ທີ່ກ່ຽວຂ້ອງໂດຍກົງໃສ່ປະເພດເດີມ.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }