//! ຄົງທີ່ ສຳ ລັບປະເພດເລກເຕັມ 128-bit ທີ່ບໍ່ໄດ້ລົງນາມ.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! ລະຫັດ ໃໝ່ ຄວນໃຊ້ຄົງທີ່ທີ່ກ່ຽວຂ້ອງໂດຍກົງໃສ່ປະເພດເດີມ.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }