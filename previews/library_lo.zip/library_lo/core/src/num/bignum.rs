//! ການປະຕິບັດ (bignum) ຈຳ ນວນທີ່ຖືກຕ້ອງຕາມຄວາມຕ້ອງການຂອງລູກຄ້າ.
//!
//! ສິ່ງນີ້ຖືກອອກແບບມາເພື່ອຫລີກລ້ຽງການຈັດສັນ heap ດ້ວຍຄ່າໃຊ້ຈ່າຍຂອງ ໜ່ວຍ ຄວາມ ຈຳ stack.
//! ປະເພດ bignum ທີ່ຖືກໃຊ້ຫຼາຍທີ່ສຸດ, `Big32x40`, ຖືກ ຈຳ ກັດໂດຍ 32 × 40=1,280 ບິດແລະຈະໃຊ້ເວລາຫຼາຍທີ່ສຸດ 160 ໄບໄບຂອງ ໜ່ວຍ ຄວາມ ຈຳ.
//! ນີ້ແມ່ນຫຼາຍກ່ວາພຽງພໍ ສຳ ລັບການລວບລວມມູນຄ່າ `f64` ຈຳ ກັດທີ່ເປັນໄປໄດ້ທັງ ໝົດ.
//!
//! ໃນຫຼັກການມັນເປັນໄປໄດ້ທີ່ຈະມີຫລາຍປະເພດ bignum ສຳ ລັບວັດສະດຸປ້ອນທີ່ແຕກຕ່າງກັນ, ແຕ່ພວກເຮົາບໍ່ເຮັດແນວນັ້ນເພື່ອຫລີກລ້ຽງການລະຫັດຂອງດອກໄຟ.
//!
//! ແຕ່ລະ bignum ຍັງຖືກຕິດຕາມ ສຳ ລັບການ ນຳ ໃຊ້ຕົວຈິງ, ສະນັ້ນມັນປົກກະຕິບໍ່ມີບັນຫາຫຍັງເລີຍ.
//!

// ໂມດູນນີ້ແມ່ນ ສຳ ລັບ dec2flt ແລະ flt2dec ເທົ່ານັ້ນ, ແລະສາທາລະນະເທົ່ານັ້ນເພາະວ່າຫຼັກເກນ.
// ມັນບໍ່ໄດ້ມີຈຸດປະສົງທີ່ຈະຄົງຕົວຕະຫຼອດໄປ.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// ການປະຕິບັດງານກ່ຽວກັບເລກຄະນິດສາດທີ່ຕ້ອງການໂດຍ bignums.
pub trait FullOps: Sized {
    /// ສົ່ງຄືນ `(carry', v')` ເຊັ່ນ `carry' * 2^W + v' = self + other + carry`, ບ່ອນທີ່ `W` ແມ່ນ ຈຳ ນວນຂອງບິດໃນ `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// ສົ່ງຄືນ `(carry', v')` ເຊັ່ນ `carry'*2^W + v' = self* other + carry`, ບ່ອນທີ່ `W` ແມ່ນ ຈຳ ນວນຂອງບິດໃນ `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// ສົ່ງຄືນ `(carry', v')` ເຊັ່ນວ່າ `carry'*2^W + v' = self* other + other2 + carry`, ບ່ອນທີ່ `W` ແມ່ນ ຈຳ ນວນບິດໃນ `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// ສົ່ງຄືນ `(quo, rem)` ເຊັ່ນວ່າ `borrow *2^W + self = quo* other + rem` ແລະ `0 <= rem < other`, ບ່ອນທີ່ `W` ແມ່ນ ຈຳ ນວນບິດໃນ `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // ນີ້ບໍ່ສາມາດລົ້ນໄດ້;ຜົນຜະລິດແມ່ນຢູ່ລະຫວ່າງ `0` ແລະ `2 * 2^nbits - 1`.
                    // FIXME: LLVM ຈະເພີ່ມປະສິດຕິພາບນີ້ເຂົ້າໃນ ADC ຫຼືຄ້າຍຄືກັນບໍ?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // ນີ້ບໍ່ສາມາດລົ້ນໄດ້;
                    // ຜົນຜະລິດແມ່ນຢູ່ລະຫວ່າງ `0` ແລະ `2^nbits * (2^nbits - 1)`.
                    // FIXME: LLVM ຈະເພີ່ມປະສິດຕິພາບນີ້ເຂົ້າໃນ ADC ຫຼືຄ້າຍຄືກັນບໍ?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // ນີ້ບໍ່ສາມາດລົ້ນໄດ້;
                    // ຜົນຜະລິດແມ່ນຢູ່ລະຫວ່າງ `0` ແລະ `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // ນີ້ບໍ່ສາມາດລົ້ນໄດ້;ຜົນຜະລິດແມ່ນຢູ່ລະຫວ່າງ `0` ແລະ `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // ເບິ່ງ RFC #521 ສຳ ລັບເປີດໃຊ້ງານນີ້.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// ຕາຕະລາງ ກຳ ລັງຂອງ 5 ຕົວແທນໃນຕົວເລກ.ໂດຍສະເພາະ, ມູນຄ່າ {u8, u16, u32} ທີ່ໃຫຍ່ທີ່ສຸດທີ່ເປັນພະລັງງານຂອງຫ້າ, ບວກກັບເລກ ກຳ ລັງທີ່ສອດຄ້ອງກັນ.
/// ໃຊ້ໃນ `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// ຈຳ ນວນທີ່ຖືກຈັດສັນໂດຍກົງ-ຊັດເຈນ (ເຖິງ ຈຳ ກັດ) ຈຳ ນວນ.
        ///
        /// ນີ້ແມ່ນສະຫນັບສະຫນູນໂດຍຂບວນຂະຫນາດຄົງທີ່ຂອງປະເພດ ("digit") ທີ່ໄດ້ຮັບ.
        /// ໃນຂະນະທີ່ຂບວນບໍ່ໃຫຍ່ຫຼາຍ (ຕາມປົກກະຕິບາງຮ້ອຍບາດ), ການຄັດລອກມັນແບບຊະຊາຍອາດຈະເຮັດໃຫ້ເກີດຜົນງານ.
        ///
        /// ສະນັ້ນນີ້ແມ່ນເຈດຕະນາບໍ່ແມ່ນ `Copy`.
        ///
        /// ການປະຕິບັດງານທັງ ໝົດ ທີ່ມີໃຫ້ກັບ bignums panic ໃນກໍລະນີຂອງການໄຫຼລົ້ນ.
        /// ຜູ້ໂທແມ່ນຮັບຜິດຊອບທີ່ຈະໃຊ້ປະເພດ bignum ທີ່ມີຂະ ໜາດ ໃຫຍ່ພໍ.
        pub struct $name {
            /// ໜຶ່ງ ບວກການຊົດເຊີຍໄປສູ່ "digit" ສູງສຸດໃນການ ນຳ ໃຊ້.
            /// ນີ້ບໍ່ໄດ້ຫຼຸດລົງ, ສະນັ້ນຈົ່ງຮູ້ເຖິງ ຄຳ ສັ່ງການ ຄຳ ນວນ.
            /// `base[size..]` ຄວນຈະເປັນສູນ.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` ສະແດງ `a + b *2^W + c* 2^(2W) + ...` ບ່ອນທີ່ `W` ແມ່ນ ຈຳ ນວນບິດໃນປະເພດຕົວເລກ.
            base: [$ty; $n],
        }

        impl $name {
            /// ເຮັດໃຫ້ bignum ຈາກຕົວເລກຫນຶ່ງ.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// ເຮັດ bignum ຈາກມູນຄ່າ `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// ສົ່ງຄືນຕົວເລກພາຍໃນເປັນຕົວເລກ `[a, b, c, ...]` ເຊັ່ນວ່າຄ່າຕົວເລກແມ່ນ `a + b *2^W + c* 2^(2W) + ...` ບ່ອນທີ່ `W` ແມ່ນ ຈຳ ນວນຂອງບິດໃນປະເພດຕົວເລກ.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// ສົ່ງຄືນ `i`-th ທີ່ bit 0 ແມ່ນ ໜ້ອຍ ທີ່ສຸດ.
            /// ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ນ້ອຍທີ່ມີນ້ໍາຫນັກ `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// ສົ່ງຄືນ `true` ຖ້າ bignum ແມ່ນສູນ.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// ສົ່ງຄືນ ຈຳ ນວນບິດທີ່ ຈຳ ເປັນເພື່ອສະແດງມູນຄ່ານີ້.
            /// ໃຫ້ສັງເກດວ່າສູນແມ່ນຖືວ່າຕ້ອງການ 0 ບິດ.
            pub fn bit_length(&self) -> usize {
                // ຂ້າມຫລາຍໆຕົວເລກທີ່ ສຳ ຄັນທີ່ສຸດແມ່ນເລກສູນ.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // ບໍ່ມີຕົວເລກທີ່ບໍ່ແມ່ນສູນ, ໝາຍ ຄວາມວ່າຕົວເລກແມ່ນສູນ.
                    return 0;
                }
                // ສິ່ງນີ້ສາມາດເພີ່ມປະສິດທິພາບໄດ້ດ້ວຍ leading_zeros() ແລະການປ່ຽນເລັກນ້ອຍ, ແຕ່ມັນອາດຈະບໍ່ຄຸ້ມຄ່າກັບການລົບກວນ.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// ເພີ່ມ `other` ໃຫ້ຕົວມັນເອງແລະສົ່ງຄືນການອ້າງອິງທີ່ສາມາດປ່ຽນແປງໄດ້.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// ຫັກລົບ `other` ຈາກຕົວມັນເອງແລະສົ່ງຄືນການອ້າງອິງທີ່ສາມາດປ່ຽນແປງໄດ້.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// ຄູນຕົວມັນເອງດ້ວຍ `other` ຂະ ໜາດ ຕົວເລກແລະສົ່ງຄືນການອ້າງອິງຕົວເອງ.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// ຄູນຕົວມັນເອງດ້ວຍ `2^bits` ແລະສົ່ງຄືນການອ້າງອິງຕົວເອງ.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // ປ່ຽນໂດຍ `digits * digitbits` bits
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // ປ່ຽນໂດຍ `bits` bits
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. ຕົວເລກ] ແມ່ນສູນ, ບໍ່ ຈຳ ເປັນຕ້ອງປ່ຽນ
                }

                self.size = sz;
                self
            }

            /// ຄູນຕົວມັນເອງດ້ວຍ `5^e` ແລະສົ່ງຄືນການອ້າງອິງຕົວເອງ.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // ມີເລກສູນ n ຢູ່ເທິງ 2 ^ n, ແລະຂະ ໜາດ ຕົວເລກທີ່ກ່ຽວຂ້ອງເທົ່ານັ້ນແມ່ນ ກຳ ລັງຂອງສອງ, ດັ່ງນັ້ນນີ້ແມ່ນດັດສະນີທີ່ ເໝາະ ສົມ ສຳ ລັບຕາຕະລາງ.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // ຄູນດ້ວຍພະລັງທີ່ມີຕົວເລກໃຫຍ່ທີ່ສຸດເທົ່າທີ່ຈະໄວໄດ້…
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // …ແລ້ວ ສຳ ເລັດສ່ວນທີ່ເຫຼືອ.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// ຄູນຕົວມັນເອງດ້ວຍຕົວເລກທີ່ອະທິບາຍໂດຍ `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (ບ່ອນທີ່ `W` ແມ່ນ ຈຳ ນວນບິດໃນປະເພດຕົວເລກ) ແລະສົ່ງຄືນຂໍ້ອ້າງອີງທີ່ສາມາດປ່ຽນແປງໄດ້.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // ປົກກະຕິພາຍໃນ.ເຮັດວຽກໄດ້ດີທີ່ສຸດເມື່ອ aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// ແບ່ງຕົວຂອງມັນເອງໂດຍ `other` ຕົວເລກທີ່ມີຕົວເລກແລະສົ່ງຄືນການອ້າງອິງທີ່ປ່ຽນແປງຂອງຕົນເອງ *ແລະ* ສ່ວນທີ່ເຫຼືອ.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// ແບ່ງຕົນເອງໂດຍ bignum ອື່ນ, ຂຽນທັບ `q` ກັບຕົວແທນແລະ `r` ກັບສ່ວນທີ່ເຫຼືອ.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // ພະແນກຍາວຊ້າ base-2 ຍາວເອົາຈາກ
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME ໃຊ້ ($ty) ຖານທີ່ໃຫຍ່ກວ່າ ສຳ ລັບການແບ່ງແຍກຍາວ.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // ຕັ້ງຄ່າ `i` ນ້ອຍຂອງ q ຫາ 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// ປະເພດຕົວເລກ ສຳ ລັບ `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// ອັນນີ້ແມ່ນໃຊ້ ສຳ ລັບການທົດສອບເທົ່ານັ້ນ.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}