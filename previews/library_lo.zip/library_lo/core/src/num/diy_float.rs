//! ຄວາມແມ່ນຍໍາສູງ "soft float", ສຳ ລັບໃຊ້ພາຍໃນເທົ່ານັ້ນ.

// ໂມດູນນີ້ແມ່ນ ສຳ ລັບ dec2flt ແລະ flt2dec ເທົ່ານັ້ນ, ແລະສາທາລະນະເທົ່ານັ້ນເພາະວ່າຫຼັກເກນ.
// ມັນບໍ່ໄດ້ມີຈຸດປະສົງທີ່ຈະຄົງຕົວຕະຫຼອດໄປ.
#![doc(hidden)]
#![unstable(
    feature = "core_private_diy_float",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

/// ປະເພດຈຸດລອຍນ້ ຳ ທີ່ມີຂະ ໜາດ 64 ບິດ, ເຊິ່ງເປັນຕົວແທນຂອງ `f * 2^e`.
#[derive(Copy, Clone, Debug)]
#[doc(hidden)]
pub struct Fp {
    /// mantissa ເລກເຕັມ.
    pub f: u64,
    /// ເລກ ກຳ ລັງໃນຖານ 2.
    pub e: i16,
}

impl Fp {
    /// ສົ່ງຄືນຜະລິດຕະພັນມົນທີ່ຖືກຕ້ອງຂອງຕົວມັນເອງແລະ `other`.
    pub fn mul(&self, other: &Fp) -> Fp {
        const MASK: u64 = 0xffffffff;
        let a = self.f >> 32;
        let b = self.f & MASK;
        let c = other.f >> 32;
        let d = other.f & MASK;
        let ac = a * c;
        let bc = b * c;
        let ad = a * d;
        let bd = b * d;
        let tmp = (bd >> 32) + (ad & MASK) + (bc & MASK) + (1 << 31) /* round */;
        let f = ac + (ad >> 32) + (bc >> 32) + (tmp >> 32);
        let e = self.e + other.e + 64;
        Fp { f, e }
    }

    /// Normalizes ຕົວຂອງມັນເອງດັ່ງນັ້ນ mantissa ຜົນໄດ້ຮັບແມ່ນຢ່າງຫນ້ອຍ `2^63`.
    pub fn normalize(&self) -> Fp {
        let mut f = self.f;
        let mut e = self.e;
        if f >> (64 - 32) == 0 {
            f <<= 32;
            e -= 32;
        }
        if f >> (64 - 16) == 0 {
            f <<= 16;
            e -= 16;
        }
        if f >> (64 - 8) == 0 {
            f <<= 8;
            e -= 8;
        }
        if f >> (64 - 4) == 0 {
            f <<= 4;
            e -= 4;
        }
        if f >> (64 - 2) == 0 {
            f <<= 2;
            e -= 2;
        }
        if f >> (64 - 1) == 0 {
            f <<= 1;
            e -= 1;
        }
        debug_assert!(f >= (1 >> 63));
        Fp { f, e }
    }

    /// ປົກກະຕິຕົວຂອງມັນເອງທີ່ຈະມີຕົວເລກທີ່ແບ່ງປັນ.
    /// ມັນພຽງແຕ່ສາມາດຫຼຸດລົງຂອງໂຕເລກ (ແລະດັ່ງນັ້ນຈຶ່ງເພີ່ມ mantissa).
    pub fn normalize_to(&self, e: i16) -> Fp {
        let edelta = self.e - e;
        assert!(edelta >= 0);
        let edelta = edelta as usize;
        assert_eq!(self.f << edelta >> edelta, self.f);
        Fp { f: self.f << edelta, e }
    }
}