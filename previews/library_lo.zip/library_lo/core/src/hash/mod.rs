//! ສະຫນັບສະຫນູນ hashing Generic.
//!
//! ໂມດູນນີ້ຈະສະຫນອງວິທີການທົ່ວໄປເພື່ອຄໍາ [hash] ຂອງມູນຄ່າ.
//! hash ໄດ້ຖືກນໍາໃຊ້ທົ່ວໄປທີ່ສຸດກັບ [`HashMap`] ແລະ [`HashSet`].
//!
//! [hash]: https://en.wikipedia.org/wiki/Hash_function
//! [`HashMap`]: ../../std/collections/struct.HashMap.html
//! [`HashSet`]: ../../std/collections/struct.HashSet.html
//!
//! ວິທີທີ່ງ່າຍທີ່ສຸດເພື່ອເຮັດໃຫ້ເປັນປະເພດ hashable ແມ່ນເພື່ອນໍາໃຊ້ `#[derive(Hash)]`:
//!
//! # Examples
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! #[derive(Hash)]
//! struct Person {
//!     id: u32,
//!     name: String,
//!     phone: u64,
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert!(calculate_hash(&person1) != calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```
//!
//! ຖ້າທ່ານຕ້ອງການຄວບຄຸມເພີ່ມເຕີມກ່ຽວກັບວ່າມູນຄ່າຂອງມັນຖືກຫຼຸດລົງແນວໃດ, ທ່ານ ຈຳ ເປັນຕ້ອງຈັດຕັ້ງປະຕິບັດ [`Hash`] trait:
//!
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! struct Person {
//!     id: u32,
//!     # #[allow(dead_code)]
//!     name: String,
//!     phone: u64,
//! }
//!
//! impl Hash for Person {
//!     fn hash<H: Hasher>(&self, state: &mut H) {
//!         self.id.hash(state);
//!         self.phone.hash(state);
//!     }
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert_eq!(calculate_hash(&person1), calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::marker;

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use self::sip::SipHasher;

#[unstable(feature = "hashmap_internals", issue = "none")]
#[allow(deprecated)]
#[doc(hidden)]
pub use self::sip::SipHasher13;

mod sip;

/// ປະເພດ hashable.
///
/// ປະເພດການປະຕິບັດ `Hash` ສາມາດເປັນ [hash` `] ed ກັບຕົວຢ່າງຂອງ [`Hasher`] ເປັນ.
///
/// ## ການນໍາ `Hash`
///
/// ທ່ານສາມາດມາ `Hash` ກັບ `#[derive(Hash)]` ຖ້າຂົງເຂດທັງຫມົດໃຊ້ `Hash`.
/// ການ hash ໄດ້ຮັບຈະເປັນການລວມກັນຂອງຄ່າຈາກໂທ [`hash`] ກ່ຽວກັບແຕ່ລະພາກສະຫນາມ.
///
/// ```
/// #[derive(Hash)]
/// struct Rustacean {
///     name: String,
///     country: String,
/// }
/// ```
///
/// ຖ້າທ່ານຕ້ອງການຄວບຄຸມເພີ່ມເຕີມກ່ຽວກັບວ່າມູນຄ່າຂອງມັນຖືກຫຼຸດລົງແນວໃດ, ແນ່ນອນທ່ານສາມາດຈັດຕັ້ງປະຕິບັດ `Hash` trait ຕົວທ່ານເອງ:
///
/// ```
/// use std::hash::{Hash, Hasher};
///
/// struct Person {
///     id: u32,
///     name: String,
///     phone: u64,
/// }
///
/// impl Hash for Person {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         self.id.hash(state);
///         self.phone.hash(state);
///     }
/// }
/// ```
///
/// ## `Hash` ແລະ `Eq`
///
/// ໃນເວລາທີ່ປະຕິບັດທັງສອງ `Hash` ແລະ [`Eq`], ມັນເປັນສິ່ງສໍາຄັນວ່າຄຸນສົມບັດດັ່ງຕໍ່ໄປນີ້ຖື:
///
/// ```text
/// k1 == k2 -> hash(k1) == hash(k2)
/// ```
///
/// ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ຖ້າຫາກວ່າທັງສອງທີ່ມີເທົ່າທຽມກັນ, hash ຂອງເຂົາເຈົ້າຍັງຕ້ອງໄດ້ຈະເທົ່າທຽມກັນ.
/// [`HashMap`] ແລະ [`HashSet`] ທັງອີງໃສ່ພຶດຕິກໍານີ້.
///
/// ໂຊກດີ, ທ່ານຈະບໍ່ຈໍາເປັນຕ້ອງເປັນຫ່ວງກ່ຽວກັບການຍົກສູງຄຸນສົມບັດນີ້ໃນເວລາທີ່ຜັນຂະຫຍາຍທັງ [`Eq`] ແລະ `Hash` ກັບ `#[derive(PartialEq, Eq, Hash)]`.
///
///
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [`hash`]: Hash::hash
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hash {
    /// ແຕ່ລະພາກສ່ວນມູນຄ່ານີ້ເປັນ [`Hasher`] ດັ່ງກ່າວ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// 7920.hash(&mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn hash<H: Hasher>(&self, state: &mut H);

    /// ແຕ່ລະພາກສ່ວນຫຼັງຈາກນັ້ນນໍາຂອງປະເພດນີ້ເຂົ້າໄປໃນ [`Hasher`] ໃຫ້ໄດ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let numbers = [6, 28, 496, 8128];
    /// Hash::hash_slice(&numbers, &mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "hash_slice", since = "1.3.0")]
    fn hash_slice<H: Hasher>(data: &[Self], state: &mut H)
    where
        Self: Sized,
    {
        for piece in data {
            piece.hash(state);
        }
    }
}

// ໂມດູນແຍກຕ່າງຫາກເພື່ອ ໝາຍ ຄືນມະຫາພາກ `Hash` ຈາກ prelude ໂດຍບໍ່ຕ້ອງໃຊ້ trait `Hash`.
pub(crate) mod macros {
    /// ມະຫາພາກ Derive ສ້າງເປັນ impl ຂອງ trait `Hash`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Hash($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Hash;

/// A trait ສຳ ລັບກະແສບິດ.
///
/// ກໍລະນີຂອງ `Hasher` ປົກກະຕິແລ້ວເປັນຕົວແທນຂອງລັດທີ່ມີການປ່ຽນແປງໃນຂະນະທີ່ hashing ຂໍ້ມູນ.
///
/// `Hasher` ສະຫນອງການໂຕ້ຕອບເປັນທໍາພື້ນຖານສໍາລັບການດຶງໄດ້ hash ສ້າງ (ກັບ [`finish`]), ແລະລາຍລັກອັກສອນຈໍານວນເຕັມເຊັ່ນດຽວກັນກັບຫຼັງຈາກນັ້ນນໍາຂອງໄບຕ໌ເຂົ້າໄປໃນຕົວຢ່າງເປັນ (ກັບ [`write`] ແລະ [`write_u8`] ແລະອື່ນໆ).
/// ໂດຍສ່ວນໃຫຍ່ແລ້ວ, ຕົວຢ່າງ `Hasher` ແມ່ນໃຊ້ຮ່ວມກັບ [`Hash`] trait.
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::Hasher;
///
/// let mut hasher = DefaultHasher::new();
///
/// hasher.write_u32(1989);
/// hasher.write_u8(11);
/// hasher.write_u8(9);
/// hasher.write(b"Huh?");
///
/// println!("Hash is {:x}!", hasher.finish());
/// ```
///
/// [`finish`]: Hasher::finish
/// [`write`]: Hasher::write
/// [`write_u8`]: Hasher::write_u8
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hasher {
    /// ສົ່ງຄືນຄ່າ hash ສຳ ລັບຄ່າທີ່ຂຽນມາຮອດປະຈຸບັນ.
    ///
    /// ເຖິງວ່າຈະມີຊື່ຂອງຕົນ, ວິທີການທີ່ບໍ່ປັບລັດພາຍໃນ hasher ຂອງ.
    /// ເພີ່ມເຕີມ [`write`] s ຈະສືບຕໍ່ຈາກມູນຄ່າໃນປະຈຸບັນ.
    /// ຖ້າຫາກວ່າທ່ານຕ້ອງການເພື່ອເລີ່ມຕົ້ນການເປັນມູນຄ່າ hash ສົດ, ທ່ານຈະຕ້ອງສ້າງ hasher ໃຫມ່.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// hasher.write(b"Cool!");
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    ///
    /// [`write`]: Hasher::write
    #[stable(feature = "rust1", since = "1.0.0")]
    fn finish(&self) -> u64;

    /// ຂຽນຂໍ້ມູນບາງສ່ວນເຂົ້າໄປໃນ `Hasher` ນີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let data = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef];
    ///
    /// hasher.write(&data);
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write(&mut self, bytes: &[u8]);

    /// ຂຽນ `u8` ດຽວເຂົ້າໃນເຄື່ອງປະດັບນີ້.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u8(&mut self, i: u8) {
        self.write(&[i])
    }
    /// ຂຽນ `u16` ດຽວເຂົ້າໃນເຄື່ອງປະດັບນີ້.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u16(&mut self, i: u16) {
        self.write(&i.to_ne_bytes())
    }
    /// ຂຽນ `u32` ດຽວເຂົ້າໃນເຄື່ອງປະດັບນີ້.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u32(&mut self, i: u32) {
        self.write(&i.to_ne_bytes())
    }
    /// writes ເປັນ `u64` ດຽວເຂົ້າໄປໃນ hasher ນີ້.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u64(&mut self, i: u64) {
        self.write(&i.to_ne_bytes())
    }
    /// writes ເປັນ `u128` ດຽວເຂົ້າໄປໃນ hasher ນີ້.
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_u128(&mut self, i: u128) {
        self.write(&i.to_ne_bytes())
    }
    /// writes ເປັນ `usize` ດຽວເຂົ້າໄປໃນ hasher ນີ້.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_usize(&mut self, i: usize) {
        self.write(&i.to_ne_bytes())
    }

    /// writes ເປັນ `i8` ດຽວເຂົ້າໄປໃນ hasher ນີ້.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i8(&mut self, i: i8) {
        self.write_u8(i as u8)
    }
    /// ຂຽນ `i16` ດຽວເຂົ້າໃນເຄື່ອງປະດັບນີ້.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i16(&mut self, i: i16) {
        self.write_u16(i as u16)
    }
    /// writes ເປັນ `i32` ດຽວເຂົ້າໄປໃນ hasher ນີ້.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i32(&mut self, i: i32) {
        self.write_u32(i as u32)
    }
    /// writes ເປັນ `i64` ດຽວເຂົ້າໄປໃນ hasher ນີ້.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i64(&mut self, i: i64) {
        self.write_u64(i as u64)
    }
    /// writes ເປັນ `i128` ດຽວເຂົ້າໄປໃນ hasher ນີ້.
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_i128(&mut self, i: i128) {
        self.write_u128(i as u128)
    }
    /// writes ເປັນ `isize` ດຽວເຂົ້າໄປໃນ hasher ນີ້.
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_isize(&mut self, i: isize) {
        self.write_usize(i as usize)
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<H: Hasher + ?Sized> Hasher for &mut H {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

/// A trait ສໍາລັບການສ້າງຕົວຢ່າງ [`Hasher`].
///
/// A `BuildHasher` ຖືກນໍາໃຊ້ໂດຍປົກກະຕິ (ຕົວຢ່າງ: , ໂດຍ [`HashMap`]) ເພື່ອສ້າງ [`Hasher`] s ທີ່ສໍາຄັນແຕ່ລະຄົນດັ່ງກ່າວວ່າພວກເຂົາເຈົ້າກໍາລັງ hashed ເປັນອິດສະຫຼະຂອງຄົນອື່ນ, ນັບຕັ້ງແຕ່ [`Hasher`] s ປະກອບດ້ວຍລັດ.
///
///
/// ສຳ ລັບແຕ່ລະຕົວຢ່າງຂອງ `BuildHasher`, [`Hasher`] ສ້າງໂດຍ [`build_hasher`] ຄວນຈະຄືກັນ.
/// ຫມາຍຄວາມວ່າ, ຖ້າຫາກວ່ານ້ໍາດຽວກັນຂອງໄບຕ໌ໄດ້ຖືກປ້ອນເຂົ້າໄປໃນແຕ່ລະ hasher, ຜົນຜະລິດດຽວກັນຈະຍັງໄດ້ຮັບການສ້າງຂຶ້ນ.
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::RandomState;
/// use std::hash::{BuildHasher, Hasher};
///
/// let s = RandomState::new();
/// let mut hasher_1 = s.build_hasher();
/// let mut hasher_2 = s.build_hasher();
///
/// hasher_1.write_u32(8128);
/// hasher_2.write_u32(8128);
///
/// assert_eq!(hasher_1.finish(), hasher_2.finish());
/// ```
///
/// [`build_hasher`]: BuildHasher::build_hasher
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub trait BuildHasher {
    /// ປະເພດຂອງເຄື່ອງຊັກຜ້າທີ່ຈະຖືກສ້າງຂື້ນ.
    #[stable(since = "1.7.0", feature = "build_hasher")]
    type Hasher: Hasher;

    /// ສ້າງ hasher ໃຫມ່.
    ///
    /// call ແຕ່ກັບ `build_hasher` ສຸດຍົກຕົວຢ່າງດຽວແລ້ວກໍ່ເກີດຜົນທີ່ [`Hasher`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::RandomState;
    /// use std::hash::BuildHasher;
    ///
    /// let s = RandomState::new();
    /// let new_s = s.build_hasher();
    /// ```
    #[stable(since = "1.7.0", feature = "build_hasher")]
    fn build_hasher(&self) -> Self::Hasher;
}

/// ການນໍາໃຊ້ເພື່ອສ້າງເປັນຕົວຢ່າງ [`BuildHasher`] ໃນຕອນຕົ້ນສໍາລັບປະເພດທີ່ປະຕິບັດ [`Hasher`] ແລະ [`Default`].
///
/// `BuildHasherDefault<H>` ສາມາດຖືກ ນຳ ໃຊ້ເມື່ອປະເພດ `H` ປະຕິບັດ [`Hasher`] ແລະ [`Default`], ແລະທ່ານຕ້ອງການຕົວຢ່າງ [`BuildHasher`] ທີ່ກົງກັນ, ແຕ່ບໍ່ມີການ ກຳ ນົດ.
///
///
/// `BuildHasherDefault` ໃດຫນຶ່ງແມ່ນ [zero-sized].ມັນສາມາດໄດ້ຮັບການສ້າງຂຶ້ນດ້ວຍ [`default`][method.default].
/// ເມື່ອໃຊ້ `BuildHasherDefault` ກັບ [`HashMap`] ຫຼື [`HashSet`], ນີ້ບໍ່ ຈຳ ເປັນຕ້ອງເຮັດ, ເພາະວ່າພວກມັນປະຕິບັດຕົວຢ່າງ [`Default`] ທີ່ ເໝາະ ສົມກັບຕົວເອງ.
///
/// # Examples
///
/// ການໃຊ້ `BuildHasherDefault` ເພື່ອ ກຳ ນົດ [`BuildHasher`] ທີ່ ກຳ ນົດເອງ
/// [`HashMap`]:
///
/// ```
/// use std::collections::HashMap;
/// use std::hash::{BuildHasherDefault, Hasher};
///
/// #[derive(Default)]
/// struct MyHasher;
///
/// impl Hasher for MyHasher {
///     fn write(&mut self, bytes: &[u8]) {
///         // ສູດການຄິດໄລ່ຂອງທ່ານຢູ່ທີ່ນີ້!
///        unimplemented!()
///     }
///
///     fn finish(&self) -> u64 {
///         // ສູດການຄິດໄລ່ຂອງທ່ານຢູ່ທີ່ນີ້!
///         unimplemented!()
///     }
/// }
///
/// type MyBuildHasher = BuildHasherDefault<MyHasher>;
///
/// let hash_map = HashMap::<u32, u32, MyBuildHasher>::default();
/// ```
///
/// [method.default]: BuildHasherDefault::default
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [zero-sized]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#zero-sized-types-zsts
///
///
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub struct BuildHasherDefault<H>(marker::PhantomData<H>);

#[stable(since = "1.9.0", feature = "core_impl_debug")]
impl<H> fmt::Debug for BuildHasherDefault<H> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("BuildHasherDefault")
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H: Default + Hasher> BuildHasher for BuildHasherDefault<H> {
    type Hasher = H;

    fn build_hasher(&self) -> H {
        H::default()
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Clone for BuildHasherDefault<H> {
    fn clone(&self) -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Default for BuildHasherDefault<H> {
    fn default() -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> PartialEq for BuildHasherDefault<H> {
    fn eq(&self, _other: &BuildHasherDefault<H>) -> bool {
        true
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> Eq for BuildHasherDefault<H> {}

mod impls {
    use crate::mem;
    use crate::slice;

    use super::*;

    macro_rules! impl_write {
        ($(($ty:ident, $meth:ident),)*) => {$(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for $ty {
                #[inline]
                fn hash<H: Hasher>(&self, state: &mut H) {
                    state.$meth(*self)
                }

                #[inline]
                fn hash_slice<H: Hasher>(data: &[$ty], state: &mut H) {
                    let newlen = data.len() * mem::size_of::<$ty>();
                    let ptr = data.as_ptr() as *const u8;
                    // ຄວາມປອດໄພ: `ptr` ແມ່ນຖືກຕ້ອງແລະສອດຄ່ອງ, ເພາະວ່າມະຫາພາກນີ້ແມ່ນໃຊ້ເທົ່ານັ້ນ
                    // ສໍາລັບ primitives ຈໍານວນຫລາຍທີ່ບໍ່ມີ padding.
                    // ກະດາດ ໃໝ່ ຈະແຜ່ລາມໄປທົ່ວ `data` ແລະບໍ່ເຄີຍກາຍພັນ, ແລະຂະ ໜາດ ທັງ ໝົດ ຂອງມັນແມ່ນຄືກັນກັບ `data` ເດີມສະນັ້ນມັນບໍ່ສາມາດກາຍ `isize::MAX` ໄດ້.
                    //
                    state.write(unsafe { slice::from_raw_parts(ptr, newlen) })
                }
            }
        )*}
    }

    impl_write! {
        (u8, write_u8),
        (u16, write_u16),
        (u32, write_u32),
        (u64, write_u64),
        (usize, write_usize),
        (i8, write_i8),
        (i16, write_i16),
        (i32, write_i32),
        (i64, write_i64),
        (isize, write_isize),
        (u128, write_u128),
        (i128, write_i128),
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for bool {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u8(*self as u8)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for char {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u32(*self as u32)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for str {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write(self.as_bytes());
            state.write_u8(0xff)
        }
    }

    #[stable(feature = "never_hash", since = "1.29.0")]
    impl Hash for ! {
        #[inline]
        fn hash<H: Hasher>(&self, _: &mut H) {
            *self
        }
    }

    macro_rules! impl_hash_tuple {
        () => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for () {
                #[inline]
                fn hash<H: Hasher>(&self, _state: &mut H) {}
            }
        );

        ( $($name:ident)+) => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl<$($name: Hash),+> Hash for ($($name,)+) where last_type!($($name,)+): ?Sized {
                #[allow(non_snake_case)]
                #[inline]
                fn hash<S: Hasher>(&self, state: &mut S) {
                    let ($(ref $name,)+) = *self;
                    $($name.hash(state);)+
                }
            }
        );
    }

    macro_rules! last_type {
        ($a:ident,) => { $a };
        ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
    }

    impl_hash_tuple! {}
    impl_hash_tuple! { A }
    impl_hash_tuple! { A B }
    impl_hash_tuple! { A B C }
    impl_hash_tuple! { A B C D }
    impl_hash_tuple! { A B C D E }
    impl_hash_tuple! { A B C D E F }
    impl_hash_tuple! { A B C D E F G }
    impl_hash_tuple! { A B C D E F G H }
    impl_hash_tuple! { A B C D E F G H I }
    impl_hash_tuple! { A B C D E F G H I J }
    impl_hash_tuple! { A B C D E F G H I J K }
    impl_hash_tuple! { A B C D E F G H I J K L }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: Hash> Hash for [T] {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            self.len().hash(state);
            Hash::hash_slice(self, state)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *const T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // ຕົວຊີ້ບາງໆ
                    state.write_usize(*self as *const () as usize);
                } else {
                    // ຕົວຊີ້ໄຂມັນ SAFETY: ພວກເຮົາ ກຳ ລັງເຂົ້າເຖິງ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ເກັບໄວ້ໂດຍ `self` ເຊິ່ງຮັບປະກັນວ່າມັນຖືກຕ້ອງ.
                    // ນີ້ຄາດວ່າຕົວຊີ້ໄຂມັນສາມາດເປັນຕົວແທນໂດຍ `(usize, usize)`, ເຊິ່ງປອດໄພທີ່ຈະເຮັດໃນ `std` ເພາະວ່າມັນຖືກຈັດສົ່ງແລະເກັບຮັກສາໄວ້ໃຫ້ສອດຄ່ອງກັບການຈັດຕັ້ງປະຕິບັດຂອງຈຸດໄຂມັນໃນ `rustc`.
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // ຕົວຊີ້ບາງໆ
                    state.write_usize(*self as *const () as usize);
                } else {
                    // ຕົວຊີ້ໄຂມັນ SAFETY: ພວກເຮົາ ກຳ ລັງເຂົ້າເຖິງ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ເກັບໄວ້ໂດຍ `self` ເຊິ່ງຮັບປະກັນວ່າມັນຖືກຕ້ອງ.
                    // ນີ້ຄາດວ່າຕົວຊີ້ໄຂມັນສາມາດເປັນຕົວແທນໂດຍ `(usize, usize)`, ເຊິ່ງປອດໄພທີ່ຈະເຮັດໃນ `std` ເພາະວ່າມັນຖືກຈັດສົ່ງແລະເກັບຮັກສາໄວ້ໃຫ້ສອດຄ່ອງກັບການຈັດຕັ້ງປະຕິບັດຂອງຈຸດໄຂມັນໃນ `rustc`.
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }
}