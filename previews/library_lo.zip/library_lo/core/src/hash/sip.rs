//! ການຈັດຕັ້ງປະຕິບັດຂອງ SipHash.

#![allow(deprecated)] // ປະເພດໃນໂມດູນນີ້ແມ່ນຄັດຄ້ານ

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// ການປະຕິບັດວຽກຂອງ SipHash 1-3.
///
/// ປະຈຸບັນນີ້ແມ່ນ ໜ້າ ທີ່ hashing ໃນຕອນຕົ້ນທີ່ຖືກ ນຳ ໃຊ້ໂດຍຫໍສະມຸດມາດຕະຖານ (ຕົວຢ່າງ, `collections::HashMap` ໃຊ້ມັນໂດຍຄ່າເລີ່ມຕົ້ນ).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// ການປະຕິບັດຂອງ SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// ການປະຕິບັດຂອງ SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash ແມ່ນ ໜ້າ ທີ່ທີ່ມີຈຸດປະສົງທົ່ວໄປ: ມັນແລ່ນດ້ວຍຄວາມໄວດີ (ແຂ່ງຂັນກັບ Spooky ແລະ City) ແລະອະນຸຍາດໃຫ້ມີ _keyed_ X ທີ່ແຂງແຮງ.
///
/// ນີ້ສາມາດເຮັດໃຫ້ທ່ານສໍາຄັນຕາຕະລາງ hash ຂອງທ່ານຈາກ RNG ທີ່ເຂັ້ມແຂງ, ເຊັ່ນ: [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// ເຖິງແມ່ນວ່າສູດ SipHash ຖືກຖືວ່າມີຄວາມເຂັ້ມແຂງໂດຍທົ່ວໄປ, ມັນບໍ່ໄດ້ຖືກຈຸດປະສົງເພື່ອຈຸດປະສົງ cryptographic.
/// ໃນຖານະດັ່ງກ່າວ, ທຸກໆການໃຊ້ cryptographic ຂອງການຈັດຕັ້ງປະຕິບັດນີ້ແມ່ນ _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // ພວກເຮົາປຸງແຕ່ງເທົ່າໃດໄບ
    state: State,  // State hash
    tail: u64,     // letes ທີ່ບໍ່ໄດ້ຮັບການປຸງແຕ່ງ le
    ntail: usize,  // ວິທີການຈໍານວນຫຼາຍໄບຕ໌ໃນຫາງແມ່ນຖືກຕ້ອງ
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 ແລະ v1, v3 ສະແດງໃຫ້ເຫັນເຖິງໃນຄູ່ໃນຂັ້ນຕອນວິທີການ, ແລະການປະຕິບັດ simd ຂອງ SipHash ຈະໃຊ້ vectors ຂອງ v02 ແລະ v13.
    //
    // ໂດຍຢາຍໃຫ້ພວກເຂົາຢູ່ໃນຄໍາສັ່ງນີ້ໃນ struct ການຄອມໄພເລີສາມາດເລືອກເອົາເຖິງກ່ຽວກັບການເພີ່ມປະສິດທິ simd ພຽງແຕ່ບໍ່ພໍເທົ່າໃດດ້ວຍຕົວມັນເອງ.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// ຊື່ສາມັນເປັນຈໍານວນເຕັມຂອງປະເພດທີ່ຕ້ອງການຈາກກະແສ byte, ໃນຄໍາສັ່ງ LE.
/// ໃຊ້ `copy_nonoverlapping` ເພື່ອໃຫ້ compiler ໄດ້ສ້າງວິທີປະສິດທິພາບຫຼາຍທີ່ສຸດເພື່ອການໂຫຼດຈາກທີ່ຢູ່ໄປ unaligned.
///
///
/// ເນື່ອງຈາກວ່າບໍ່ປອດໄພ: ດັດຊະນີກວດກາຢູ່ i..i+size_of(int_ty)
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// ໂຫລດ u64 ໂດຍໃຊ້ແຜ່ນໄບໄບສູງເຖິງ 7 ບາດ.
/// ມັນເບິ່ງຄືວ່າ clumsy ແຕ່ `copy_nonoverlapping` ໂທທີ່ເກີດຂຶ້ນ (ໂດຍຜ່ານ `load_int_le!`) ທັງຫມົດໄດ້ມີການສ້ອມແຊມຂະຫນາດແລະຫຼີກເວັ້ນການໂທຫາ `memcpy`, ຊຶ່ງເປັນທີ່ດີສໍາລັບຄວາມໄວ.
///
///
/// ເນື່ອງຈາກວ່າບໍ່ປອດໄພ: ດັດຊະນີກວດກາຢູ່ start..start + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // ດັດຊະນີ byte ໃນປະຈຸບັນ (ຈາກ LSB) ໃນການຜະລິດ u64 ໄດ້
    let mut out = 0;
    if i + 3 < len {
        // SAFETY: `i` ບໍ່ສາມາດຈະມີຫຼາຍຂຶ້ນກ່ວາ `len`, ແລະຮັບປະກັນແປໄດ້ທຸຕ້ອງການ
        // ທີ່ start..start ດັດຊະນີໄດ້ + len ແມ່ນຢູ່ໃນຂອບເຂດ.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // ຄວາມປອດໄພ: ຄືກັນກັບຂ້າງເທິງ.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // ຄວາມປອດໄພ: ຄືກັນກັບຂ້າງເທິງ.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// ສ້າງ `SipHasher` ໃຫມ່ທີ່ມີທັງສອງໃຊ້ຄັ້ງທໍາອິດຕັ້ງຄ່າເປັນ 0.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// ສ້າງ `SipHasher` ທີ່ keyed ປິດໃຊ້ສະຫນອງໃຫ້.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// ສ້າງ `SipHasher13` ໃຫມ່ທີ່ມີທັງສອງໃຊ້ຄັ້ງທໍາອິດຕັ້ງຄ່າເປັນ 0.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// ສ້າງ `SipHasher13` ທີ່ keyed ປິດໃຊ້ສະຫນອງໃຫ້.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: ບໍ່ມີວິທີການຈໍານວນເຕັມ hashing (`write_u *`, `write_i*`) ກໍານົດ
    // ສໍາລັບປະເພດນີ້.
    // ພວກເຮົາສາມາດເພີ່ມໃຫ້ເຂົາເຈົ້າ, ສໍາເນົາການປະຕິບັດ `short_write` ໃນ librustc_data_structures/sip128.rs, ແລະເພີ່ມວິທີການ `write_u *`/`write_i*` ກັບ `SipHasher`, `SipHasher13` ແລະ `DefaultHasher`.
    //
    // ນີ້ຈະເພີ່ມຄວາມໄວສູງຂື້ນຢ່າງສົມບູນໂດຍເຄື່ອງຊັກຜ້າດັ່ງກ່າວ, ໃນລາຄາທີ່ຈະຊ້າລົງຄວາມໄວທີ່ລວບລວມລົງເລັກນ້ອຍໃນບາງມາດຖານ.
    // ເບິ່ງ #69152 ສໍາລັບລາຍລະອຽດ.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // SAFETY: `cmp::min(length, needed)` ແມ່ນການຮັບປະກັນວ່າມັນບໍ່ແມ່ນໃນໄລຍະ `length`
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // ຫາງຜ່ອນຄາຍແມ່ນຮ້ອນໆໃນປັດຈຸບັນ, ປະມວນຜົນການປ້ອນຂໍ້ມູນໃຫມ່.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // SAFETY: ເນື່ອງຈາກວ່າ `len - left` ເປັນຫຼາຍໃຫຍ່ທີ່ສຸດຂອງ 8 ຕ່ໍາກວ່າ
            // `len`, ແລະເນື່ອງຈາກວ່າ `i` ເປີດໃຫ້ບໍລິ `needed` ທີ່ `len` ແມ່ນ `length - needed`, `i + 8` ແມ່ນການຮັບປະກັນທີ່ຈະຫນ້ອຍກ່ວາຫຼືເທົ່າທຽມກັນທີ່ `length`.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // ຄວາມປອດໄພ: `i` ດຽວນີ້ແມ່ນ `needed + len.div_euclid(8) * 8`,
        // ສະນັ້ນ `i + left` = `needed + len` = `length`, ເຊິ່ງຕາມຄວາມ ໝາຍ ເທົ່າກັບ `msg.len()`.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// ສ້າງ `Hasher<S>` ກັບທັງສອງໃຊ້ຄັ້ງທໍາອິດຕັ້ງຄ່າເປັນ 0.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}