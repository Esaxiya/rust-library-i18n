//! ສະຫນັບສະຫນູນ Panic ໃນຫ້ອງສະຫມຸດມາດຕະຖານ.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// ໂຄງສ້າງທີ່ໃຫ້ຂໍ້ມູນກ່ຽວກັບ panic.
///
/// `PanicInfo` ໂຄງສ້າງຖືກສົ່ງຜ່ານ panic hook ທີ່ຕັ້ງໂດຍ [`set_hook`] ເຮັດວຽກ.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// ສົ່ງຄືນຄ່າທີ່ກ່ຽວຂ້ອງກັບ panic.
    ///
    /// ສິ່ງນີ້ຈະມັກ, ແຕ່ບໍ່ແມ່ນສະ ເໝີ, ເປັນ `&'static str` ຫຼື [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// ຖ້າຮູບ `panic!` ມະຫາພາກຈາກ `core` crate (ບໍ່ໄດ້ມາຈາກ `std`) ຖືກໃຊ້ກັບສາຍຮູບແບບແລະຂໍ້ໂຕ້ຖຽງເພີ່ມເຕີມບາງຢ່າງ, ສົ່ງຄືນຂໍ້ຄວາມນັ້ນພ້ອມທີ່ຈະໃຊ້ເປັນຕົວຢ່າງກັບ [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// ສົ່ງຄືນຂໍ້ມູນກ່ຽວກັບສະຖານທີ່ທີ່ panic ມີຕົ້ນ ກຳ ເນີດ, ຖ້າມີ.
    ///
    /// ວິທີການນີ້ຈະກັບຄືນ [`Some`] ສະເຫມີ, ແຕ່ວ່ານີ້ອາດຈະມີການປ່ຽນແປງໃນສະບັບ future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: ຖ້າສິ່ງນີ້ຖືກປ່ຽນໄປບາງຄັ້ງກໍ່ບໍ່ກັບຄືນ,
        // ຈັດການກັບກໍລະນີນັ້ນໃນ std::panicking::default_hook ແລະ std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ພວກເຮົາບໍ່ສາມາດໃຊ້ downcast_ref: :<String>() ທີ່ນີ້
        // ນັບຕັ້ງແຕ່ສະຕິງບໍ່ມີຢູ່ໃນ libcore!
        // ໃບເກັບເງິນແມ່ນສາຍສະຕິງເມື່ອ `std::panic!` ຖືກເອີ້ນດ້ວຍການໂຕ້ຖຽງກັນຫຼາຍຄັ້ງ, ແຕ່ໃນກໍລະນີນີ້ຂໍ້ຄວາມກໍ່ມີອີກ.
        //

        self.location.fmt(formatter)
    }
}

/// ໂຄງສ້າງທີ່ມີຂໍ້ມູນກ່ຽວກັບສະຖານທີ່ຂອງ panic.
///
/// ໂຄງສ້າງນີ້ແມ່ນສ້າງຂື້ນໂດຍ [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// ການປຽບທຽບເພື່ອຄວາມສະ ເໝີ ພາບແລະຄວາມເປັນລະບຽບຮຽບຮ້ອຍແມ່ນເຮັດໃນເອກະສານ, ສາຍ, ແລະບຸລິມະສິດແຖວ.
/// ໄຟລ໌ໄດ້ຖືກປຽບທຽບເປັນສາຍ, ບໍ່ແມ່ນ `Path`, ເຊິ່ງອາດຈະບໍ່ຄາດຄິດ.
/// ເບິ່ງເອກະສານ [`ສະຖານທີ່: : file`] ສຳ ລັບການສົນທະນາເພີ່ມເຕີມ.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// ສົ່ງຄືນສະຖານທີ່ແຫຼ່ງຂອງຜູ້ໂທຂອງຟັງຊັນນີ້.
    /// ຖ້າຜູ້ໂທຂອງຟັງຊັນນັ້ນຖືກບັນລະຍາຍຫຼັງຈາກນັ້ນສະຖານທີ່ການໂທຂອງມັນກໍ່ຈະຖືກສົ່ງຄືນ, ແລະອື່ນໆເພື່ອຕິດຕໍ່ກັບການໂທຄັ້ງ ທຳ ອິດພາຍໃນຮ່າງກາຍຂອງ ໜ້າ ທີ່ທີ່ບໍ່ຕິດຕາມ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// ສົ່ງຄືນ [`Location`] ທີ່ມັນຖືກເອີ້ນ.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// ສົ່ງ [`Location`] ຈາກ ຄຳ ນິຍາມຂອງຟັງຊັນນີ້.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // ການເຮັດວຽກທີ່ບໍ່ມີສຽງດຽວກັນຢູ່ໃນສະຖານທີ່ແຕກຕ່າງກັນເຮັດໃຫ້ພວກເຮົາມີຜົນດຽວກັນ
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ການເຮັດວຽກທີ່ຖືກຕິດຕາມຢູ່ໃນສະຖານທີ່ແຕກຕ່າງກັນເຮັດໃຫ້ມີມູນຄ່າແຕກຕ່າງກັນ
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// ກັບຄືນຊື່ຂອງເອກະສານທີ່ມາຈາກທີ່ panic ມີຕົ້ນ ກຳ ເນີດມາ.
    ///
    /// # `&str`, ບໍ່ `&Path`
    ///
    /// ຊື່ທີ່ຖືກສົ່ງຄືນ ໝາຍ ເຖິງເສັ້ນທາງທີ່ມາໃນລະບົບການລວບລວມຂໍ້ມູນ, ແຕ່ວ່າມັນບໍ່ຖືກຕ້ອງທີ່ຈະເປັນຕົວແທນນີ້ໂດຍກົງເປັນ `&Path`.
    /// ລະຫັດທີ່ຖືກລວບລວມອາດຈະໃຊ້ໃນລະບົບທີ່ແຕກຕ່າງກັນກັບການຈັດຕັ້ງປະຕິບັດ `Path` ທີ່ແຕກຕ່າງກັນກ່ວາລະບົບທີ່ໃຫ້ເນື້ອຫາແລະຫ້ອງສະ ໝຸດ ນີ້ບໍ່ມີປະເພດ "host path" ທີ່ແຕກຕ່າງກັນ.
    ///
    /// ພຶດຕິ ກຳ ທີ່ ໜ້າ ແປກທີ່ສຸດແມ່ນເກີດຂື້ນເມື່ອເອກະສານ "the same" ສາມາດເຂົ້າເຖິງໄດ້ຜ່ານຫຼາຍເສັ້ນທາງໃນລະບົບໂມດູນ (ໂດຍປົກກະຕິແມ່ນໃຊ້ຄຸນລັກສະນະ `#[path = "..."]` ຫຼືຄ້າຍຄືກັນ) ເຊິ່ງສາມາດເຮັດໃຫ້ສິ່ງທີ່ເບິ່ງຄືວ່າລະຫັດທີ່ຄ້າຍຄືກັນກັບຄືນຄ່າທີ່ແຕກຕ່າງຈາກ ໜ້າ ທີ່ນີ້.
    ///
    ///
    /// # Cross-compilation
    ///
    /// ມູນຄ່ານີ້ບໍ່ ເໝາະ ສົມ ສຳ ລັບການຖ່າຍທອດໄປທີ່ `Path::new` ຫລືຜູ້ກໍ່ສ້າງຄ້າຍຄືກັນເມື່ອເວທີໂຮດແລະເວທີເປົ້າ ໝາຍ ແຕກຕ່າງກັນ.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// ກັບຄືນເບີໂທທີ່ panic ມີຕົ້ນ ກຳ ເນີດ.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// ກັບຄືນຖັນຈາກທີ່ panic ມີຕົ້ນ ກຳ ເນີດມາ.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait ພາຍໃນທີ່ໃຊ້ໂດຍ libstd ເພື່ອສົ່ງຂໍ້ມູນຈາກ libstd ໄປ `panic_unwind` ແລະລະບົບປະຕິບັດການ panic ອື່ນໆ.
/// ບໍ່ມີຈຸດປະສົງທີ່ຈະສະຖຽນລະພາບໃນເວລາໃດໄວໆນີ້, ຢ່າໃຊ້.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// ຮັບເອົາເນື້ອໃນເປັນເຈົ້າການຢ່າງເຕັມທີ່.
    /// ປະເພດການສົ່ງຄືນແມ່ນຕົວຈິງແລ້ວ `Box<dyn Any + Send>`, ແຕ່ພວກເຮົາບໍ່ສາມາດໃຊ້ `Box` ໃນ libcore.
    ///
    /// ຫຼັງຈາກວິທີການນີ້ຖືກເອີ້ນ, ມີພຽງແຕ່ຄ່າເລີ່ມຕົ້ນທີ່ບໍ່ຖືກຕ້ອງ ສຳ ລັບ `self` ເທົ່ານັ້ນ.
    /// ການໂທຫາວິທີການນີ້ສອງຄັ້ງ, ຫຼືການໂທຫາ `get` ຫຼັງຈາກການໂທຫາວິທີການນີ້, ແມ່ນຂໍ້ຜິດພາດ.
    ///
    /// ການໂຕ້ຖຽງແມ່ນຖືກຢືມເພາະວ່າ panic runtime (`__rust_start_panic`) ພຽງແຕ່ໄດ້ຮັບ `dyn BoxMeUp` ທີ່ຢືມ.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// ພຽງແຕ່ຢືມເນື້ອໃນ.
    fn get(&mut self) -> &(dyn Any + Send);
}