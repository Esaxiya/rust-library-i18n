//! ໂມດູນນີ້ປະຕິບັດໄດ້ `Any` trait, ຊຶ່ງເຮັດໃຫ້ການພິມການເຄື່ອນໄຫວຂອງທຸກປະເພດ `'static` ຜ່ານທ້ອນໃຫ້ເຫັນເຖິງ runtime.
//!
//! `Any` ຕົວມັນເອງສາມາດຖືກນໍາໃຊ້ເພື່ອໃຫ້ໄດ້ `TypeId`, ແລະມີຄຸນລັກສະນະຫຼາຍຂື້ນເມື່ອໃຊ້ເປັນວັດຖຸ trait.
//! ໃນຖານະເປັນ `&dyn Any` (ວັດຖຸ trait ທີ່ຢືມ), ມັນມີວິທີ `is` ແລະ `downcast_ref`, ເພື່ອທົດສອບວ່າມູນຄ່າທີ່ບັນຈຸຢູ່ໃນປະເພດໃດ ໜຶ່ງ, ແລະເພື່ອອ້າງອີງໃສ່ມູນຄ່າພາຍໃນເປັນປະເພດ.
//! ໃນຖານະເປັນ `&mut dyn Any`, ມັນຍັງມີວິທີການ `downcast_mut`, ສໍາລັບການໄດ້ຮັບການອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບມູນຄ່າພາຍໃນ.
//! `Box<dyn Any>` ເພີ່ມວິທີ `downcast`, ເຊິ່ງພະຍາຍາມປ່ຽນເປັນ `Box<T>`.
//! ເບິ່ງເອກະສານ [`Box`] ສຳ ລັບລາຍລະອຽດທັງ ໝົດ.
//!
//! ໃຫ້ສັງເກດວ່າ `&dyn Any` ແມ່ນ ຈຳ ກັດໃນການທົດສອບວ່າມູນຄ່າຂອງມັນແມ່ນຂອງຊະນິດສີມັງ, ແລະບໍ່ສາມາດໃຊ້ເພື່ອທົດສອບໄດ້ວ່າຊະນິດໃດ ໜຶ່ງ ປະຕິບັດແບບ trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # ຕົວຊີ້ວັດ Smart ແລະ `dyn Any`
//!
//! ສ່ວນ ໜຶ່ງ ຂອງພຶດຕິ ກຳ ທີ່ຕ້ອງ ຄຳ ນຶງເຖິງເວລາທີ່ໃຊ້ `Any` ເປັນວັດຖຸ trait, ໂດຍສະເພາະກັບປະເພດເຊັ່ນ `Box<dyn Any>` ຫຼື `Arc<dyn Any>`, ແມ່ນວ່າການພຽງແຕ່ເອີ້ນ `.type_id()` ໃສ່ມູນຄ່າກໍ່ຈະຜະລິດ `TypeId` ຂອງ *container*, ບໍ່ແມ່ນວັດຖຸ trait ທີ່ຕິດພັນ.
//!
//! ສິ່ງນີ້ສາມາດຫລີກລ້ຽງໄດ້ໂດຍການແປງຕົວຊີ້ທີ່ສະຫຼາດໄປເປັນ `&dyn Any` ແທນ, ເຊິ່ງມັນຈະສົ່ງຄືນ `TypeId` ຂອງວັດຖຸ.
//! ຍົກຕົວຢ່າງ:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // ທ່ານມີແນວໂນ້ມທີ່ຈະຕ້ອງນີ້:
//! let actual_id = (&*boxed).type_id();
//! // ... ກ່ວານີ້:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! ພິຈາລະນາສະຖານະການທີ່ພວກເຮົາຕ້ອງການອອກຈາກຄ່າທີ່ຖືກສົ່ງຜ່ານ ໜ້າ ທີ່.
//! ພວກເຮົາຮູ້ຈັກຄຸນຄ່າຂອງພວກເຮົາກໍາລັງເຮັດວຽກກ່ຽວກັບການປະຕິບັດແກ້ໄຂບັນຫາ, ແຕ່ພວກເຮົາບໍ່ຮູ້ວ່າປະເພດຊີມັງຂອງຕົນ.ພວກເຮົາຕ້ອງການໃຫ້ການປິ່ນປົວພິເສດແກ່ບາງປະເພດ: ໃນກໍລະນີນີ້ພິມອອກຄວາມຍາວຂອງຄ່າ String ກ່ອນທີ່ຈະມີຄ່າຂອງມັນ.
//! ພວກເຮົາບໍ່ຮູ້ປະເພດສີມັງຂອງມູນຄ່າຂອງພວກເຮົາໃນເວລາທີ່ລວບລວມ, ສະນັ້ນພວກເຮົາ ຈຳ ເປັນຕ້ອງໃຊ້ການສະທ້ອນເວລາແທນ.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger ຟັງຊັນ ສຳ ລັບປະເພດໃດທີ່ໃຊ້ Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // ພະຍາຍາມທີ່ຈະປ່ຽນຄ່າຂອງພວກເຮົາໄປຍັງ `String`.
//!     // ຖ້າປະສົບຜົນ ສຳ ເລັດ, ພວກເຮົາຕ້ອງການຜົນຜະລິດຄວາມຍາວຂອງ String` ພ້ອມທັງຄຸນຄ່າຂອງມັນ.
//!     // ຖ້າບໍ່, ມັນແມ່ນປະເພດອື່ນ: ພຽງແຕ່ພິມອອກໂດຍບໍ່ໄດ້ຮັບການອະນຸມັດ.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // ໜ້າ ທີ່ນີ້ຕ້ອງການ log parameter ຂອງມັນອອກກ່ອນທີ່ຈະເຮັດວຽກກັບມັນ.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... ເຮັດບາງວຽກອື່ນ
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// ທຸກ trait
///////////////////////////////////////////////////////////////////////////////

/// A trait ເພື່ອເອົາແບບພິມແບບເຄື່ອນໄຫວ.
///
/// ປະເພດສ່ວນໃຫຍ່ປະຕິບັດ `Any`.ເຖິງຢ່າງໃດກໍ່ຕາມ, ປະເພດໃດກໍ່ຕາມທີ່ປະກອບດ້ວຍເອກະສານອ້າງອີງທີ່ບໍ່ແມ່ນ `ບໍ່.
/// ເບິ່ງ [module-level documentation][mod] ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
///
/// [mod]: crate::any
// trait ນີ້ບໍ່ແມ່ນບໍ່ປອດໄພ, ເຖິງແມ່ນວ່າພວກເຮົາອີງໃສ່ການສະເພາະຂອງມັນຂອງ impl sole ຂອງການທໍາງານຂອງ `type_id` ໃນລະຫັດທີ່ບໍ່ປອດໄພ (ຕົວຢ່າງ: , `downcast`) ໄດ້.ຕາມປົກກະຕິ, ທີ່ຈະມີບັນຫາ, ແຕ່ເນື່ອງຈາກວ່າການ impl ພຽງແຕ່ຂອງ `Any` ແມ່ນການປະຕິບັດຜ້າຫົ່ມ, ບໍ່ມີລະຫັດທີ່ສາມາດໃຊ້ `Any`.
//
// ພວກເຮົາສາມາດເຮັດໃຫ້ trait ບໍ່ປອດໄພ-ມັນຈະບໍ່ເຮັດໃຫ້ເກີດການແຕກແຍກ, ເພາະວ່າພວກເຮົາຄວບຄຸມການຈັດຕັ້ງປະຕິບັດທັງ ໝົດ-ແຕ່ພວກເຮົາເລືອກທີ່ຈະບໍ່ເປັນເພາະມັນທັງສອງບໍ່ ຈຳ ເປັນແທ້ໆແລະອາດເຮັດໃຫ້ຜູ້ຊົມໃຊ້ສັບສົນກ່ຽວກັບຄວາມແຕກຕ່າງຂອງ traits ທີ່ບໍ່ປອດໄພແລະວິທີການທີ່ບໍ່ປອດໄພ (ເຊັ່ນ, `type_id` ຍັງຈະມີຄວາມປອດໄພທີ່ຈະໂທຫາ, ແຕ່ພວກເຮົາແນວໂນ້ມທີ່ຈະຕ້ອງການທີ່ຈະສະແດງຖານະເຊັ່ນໃນເອກະສານ).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// ໄດ້ຮັບ `TypeId` ຂອງ `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// ວິທີການຂະຫຍາຍ ສຳ ລັບວັດຖຸ trait ໃດໆ.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// ຮັບປະກັນວ່າຜົນໄດ້ຮັບຂອງຕົວຢ່າງ, ການເຂົ້າຮ່ວມກະທູ້ສາມາດພິມໄດ້ແລະເພາະສະນັ້ນຈຶ່ງ ນຳ ໃຊ້ກັບ `unwrap`.
// ໃນທີ່ສຸດອາດຈະບໍ່ ຈຳ ເປັນຕ້ອງຖ້າການສົ່ງຕໍ່ເຮັດວຽກກັບການໂຄສະນາເຜີຍແຜ່.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// ສົ່ງຄືນ `true` ຖ້າປະເພດກ່ອງແມ່ນຄືກັນກັບ `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // ໄດ້ຮັບ `TypeId` ຂອງປະເພດທີ່ເຮັດວຽກນີ້ໄດ້ຖືກເຮັດໃຫ້ໄວ.
        let t = TypeId::of::<T>();

        // ຮັບເອົາ `TypeId` ຂອງຊະນິດທີ່ຢູ່ໃນວັດຖຸ trait (`self`) X.
        let concrete = self.type_id();

        // ປຽບທຽບທັງສອງ `TypeId` ກ່ຽວກັບຄວາມສະ ເໝີ ພາບ.
        t == concrete
    }

    /// ສົ່ງຂໍ້ມູນອ້າງອີງໃສ່ຄ່າທີ່ຢູ່ໃນກ່ອງຖ້າມັນເປັນຂອງ `T`, ຫຼື `None` ຖ້າມັນບໍ່ແມ່ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SAFETY: ພຽງແຕ່ກວດກາບໍ່ວ່າພວກເຮົາກໍາລັງຊີ້ໄປຫາປະເພດທີ່ຖືກຕ້ອງ, ແລະພວກເຮົາສາມາດອີງໃສ່
            // ທີ່ກວດສອບຄວາມປອດໄພຂອງຄວາມຊົງຈໍາເພາະວ່າພວກເຮົາໄດ້ປະຕິບັດໃດແດ່ສໍາລັບທຸກປະເພດ;ບໍ່ impl ອື່ນໆສາມາດມີຍ້ອນວ່າເຂົາເຈົ້າອາດຈະຂັດແຍ້ງກັບ impl ຂອງພວກເຮົາ.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// ສົ່ງຄືນບາງເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບມູນຄ່າທີ່ຢູ່ໃນກ່ອງຖ້າມັນແມ່ນຂອງ `T`, ຫຼື `None` ຖ້າມັນບໍ່ແມ່ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SAFETY: ພຽງແຕ່ກວດກາບໍ່ວ່າພວກເຮົາກໍາລັງຊີ້ໄປຫາປະເພດທີ່ຖືກຕ້ອງ, ແລະພວກເຮົາສາມາດອີງໃສ່
            // ທີ່ກວດສອບຄວາມປອດໄພຂອງຄວາມຊົງຈໍາເພາະວ່າພວກເຮົາໄດ້ປະຕິບັດໃດແດ່ສໍາລັບທຸກປະເພດ;ບໍ່ impl ອື່ນໆສາມາດມີຍ້ອນວ່າເຂົາເຈົ້າອາດຈະຂັດແຍ້ງກັບ impl ຂອງພວກເຮົາ.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// ຫັນໄປຫາວິທີການທີ່ໄດ້ ກຳ ນົດໄວ້ໃນ `Any` ປະເພດ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// ຫັນໄປຫາວິທີການທີ່ໄດ້ ກຳ ນົດໄວ້ໃນ `Any` ປະເພດ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// ຫັນໄປຫາວິທີການທີ່ໄດ້ ກຳ ນົດໄວ້ໃນ `Any` ປະເພດ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// ຫັນໄປຫາວິທີການທີ່ໄດ້ ກຳ ນົດໄວ້ໃນ `Any` ປະເພດ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// ຫັນໄປຫາວິທີການທີ່ໄດ້ ກຳ ນົດໄວ້ໃນ `Any` ປະເພດ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// ຫັນໄປຫາວິທີການທີ່ໄດ້ ກຳ ນົດໄວ້ໃນ `Any` ປະເພດ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID ແລະວິທີການຂອງມັນ
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` ເປັນຕົວແທນຂອງຕົວລະບຸຕົວຕົນທີ່ມີເອກະລັກທົ່ວໂລກ ສຳ ລັບປະເພດໃດ ໜຶ່ງ.
///
/// ແຕ່ລະ `TypeId` ແມ່ນວັດຖຸທີ່ບໍ່ມີສີສັນທີ່ບໍ່ອະນຸຍາດໃຫ້ກວດກາສິ່ງທີ່ຢູ່ພາຍໃນແຕ່ອະນຸຍາດໃຫ້ມີການ ດຳ ເນີນງານຂັ້ນພື້ນຖານເຊັ່ນ: ການກົດປຸ່ມ, ການປຽບທຽບ, ການພິມແລະການສະແດງ.
///
///
/// A `TypeId` ໃນປະຈຸບັນມີພຽງແຕ່ ສຳ ລັບປະເພດຕ່າງໆທີ່ກ່າວເຖິງ `'static`, ແຕ່ຂໍ້ ຈຳ ກັດນີ້ອາດຈະຖືກ ກຳ ຈັດອອກໃນ future.
///
/// ໃນຂະນະທີ່ `TypeId` ປະຕິບັດ `Hash`, `PartialOrd`, ແລະ `Ord`, ມັນເປັນມູນຄ່າທີ່ສັງເກດວ່າຄວາມຫຍຸ້ງຍາກແລະການສັ່ງຊື້ຈະແຕກຕ່າງກັນລະຫວ່າງການປ່ອຍ Rust.
/// ລະວັງກ່ຽວກັບການເພິ່ງພາອາໄສພວກມັນພາຍໃນລະຫັດຂອງທ່ານ!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// ຜົນໄດ້ຮັບໄດ້ `TypeId` ຂອງປະເພດການເຄື່ອນໄຫວທົ່ວໄປນີ້ໄດ້ຮັບການ instantiated ກັບ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// ສົ່ງຄືນຊື່ຂອງປະເພດເປັນທ່ອນຊ່ອຍແນ່.
///
/// # Note
///
/// ນີ້ມີຈຸດປະສົງສໍາລັບການນໍາໃຊ້ການວິເຄາະຂອງ.
/// ເນື້ອໃນແລະຮູບແບບຂອງສາຍທີ່ຖືກກັບຄືນບໍ່ໄດ້ຖືກລະບຸ, ນອກ ເໜືອ ຈາກການອະທິບາຍປະເພດຂອງຄວາມພະຍາຍາມທີ່ດີທີ່ສຸດ.
/// ຍົກຕົວຢ່າງ, ໃນບັນດາເຊືອກທີ່ `type_name::<Option<String>>()` ອາດຈະກັບຄືນມາແມ່ນ `"Option<String>"` ແລະ `"std::option::Option<std::string::String>"`.
///
///
/// ສະຕິງທີ່ຖືກສົ່ງຄືນບໍ່ຕ້ອງຖືວ່າເປັນຕົວລະບຸຕົວຕົນທີ່ບໍ່ຊ້ ຳ ກັນເພາະວ່າຫລາຍປະເພດອາດຈະຕັ້ງເປັນຊື່ປະເພດດຽວກັນ.
/// ເຊັ່ນດຽວກັນ, ບໍ່ມີການຄ້ ຳ ປະກັນວ່າທຸກພາກສ່ວນຂອງປະເພດໃດ ໜຶ່ງ ຈະປາກົດຢູ່ໃນສາຍທີ່ຖືກສົ່ງຄືນ: ຕົວຢ່າງ, ຕົວລະບຸຕະຫຼອດຊີວິດໃນປະຈຸບັນບໍ່ໄດ້ລວມຢູ່.
/// ນອກຈາກນັ້ນ, ຜົນຜະລິດອາດຈະປ່ຽນແປງລະຫວ່າງຮຸ່ນຂອງນັກຂຽນ.
///
/// ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນໃຊ້ພື້ນຖານໂຄງລ່າງຄືກັນກັບການບົ່ງມະຕິພະຍາດແລະ debuginfo, ແຕ່ນີ້ບໍ່ໄດ້ຮັບປະກັນ.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// ສົ່ງຄືນຊື່ຂອງປະເພດຂອງຄ່າທີ່ຊີ້ໄປຫາຄ່າເປັນການຕັດເຊືອກ.
/// ນີ້ແມ່ນຄືກັນກັບ `type_name::<T>()`, ແຕ່ສາມາດໃຊ້ບ່ອນທີ່ປະເພດຂອງຕົວແປບໍ່ສາມາດໃຊ້ໄດ້ງ່າຍ.
///
/// # Note
///
/// ນີ້ມີຈຸດປະສົງສໍາລັບການນໍາໃຊ້ການວິເຄາະຂອງ.ເນື້ອໃນຄືກັນອ້ອຍຕ້ອຍແລະຮູບແບບຂອງສະຕະຍັງບໍ່ໄດ້ລະບຸ, ອື່ນກ່ວາການເປັນຄໍາອະທິບາຍທີ່ດີທີ່ສຸດຄວາມພະຍາຍາມຂອງປະເພດການ.
/// ສໍາລັບຕົວຢ່າງ, `type_name_of_val::<Option<String>>(None)` ສາມາດກັບຄືນ `"Option<String>"` ຫຼື `"std::option::Option<std::string::String>"`, ແຕ່ບໍ່ `"foobar"`.
///
/// ນອກຈາກນັ້ນ, ຜົນຜະລິດອາດຈະປ່ຽນແປງລະຫວ່າງຮຸ່ນຂອງນັກຂຽນ.
///
/// ຟັງຊັ່ນນີ້ບໍ່ແກ້ໄຂບັນຫາວັດຖຸ trait, ຊຶ່ງຫມາຍຄວາມວ່າ `type_name_of_val(&7u32 as &dyn Debug)` ອາດກັບຄືນ `"dyn Debug"`, ແຕ່ບໍ່ `"u32"`.
///
/// ຊື່ປະເພດບໍ່ຄວນຖືວ່າເປັນຕົວລະບຸສະເພາະຂອງປະເພດໃດ ໜຶ່ງ;
/// ຫລາຍປະເພດອາດຈະແບ່ງປັນຊື່ປະເພດດຽວກັນ.
///
/// ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນໃຊ້ພື້ນຖານໂຄງລ່າງຄືກັນກັບການບົ່ງມະຕິພະຍາດແລະ debuginfo, ແຕ່ນີ້ບໍ່ໄດ້ຮັບປະກັນ.
///
/// # Examples
///
/// ພິມ ຈຳ ນວນຕົວເລກເລີ່ມຕົ້ນແລະແບບເລື່ອນລອຍ.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}