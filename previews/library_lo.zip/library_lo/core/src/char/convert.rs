//! ການປ່ຽນລັກສະນະ.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// ແປງເປັນ `u32` ກັບ `char`.
///
/// ໃຫ້ສັງເກດວ່າທັງ ໝົດ [`char`] ແມ່ນຖືກຕ້ອງ [`u32`], ແລະສາມາດຖືກໂຍນລົງເປັນ ໜຶ່ງ ດຽວ
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ຢ່າງໃດກໍຕາມ, ໄດ້ຢ່າງສິ້ນເຊີງແມ່ນບໍ່ເປັນຄວາມຈິງ: ບໍ່ແມ່ນທັງຫມົດທີ່ຖືກຕ້ອງ [`u32`] s ແມ່ນຖືກຕ້ອງ [`char`] s.
/// `from_u32()` ຈະກັບຄືນ `None` ຖ້າການປ້ອນຂໍ້ມູນບໍ່ແມ່ນມູນຄ່າທີ່ຖືກຕ້ອງສໍາລັບການ [`char`].
///
/// ສຳ ລັບລຸ້ນທີ່ບໍ່ປອດໄພຂອງ ໜ້າ ທີ່ນີ້ເຊິ່ງບໍ່ສົນໃຈກັບການກວດເຫຼົ່ານີ້, ເບິ່ງ [`from_u32_unchecked`].
///
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// ກັບຄືນໃນເວລາທີ່ `None` ການປ້ອນຂໍ້ມູນບໍ່ແມ່ນ [`char`] ຖືກຕ້ອງ:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// ແປງ `u32` ເປັນ `char`, ບໍ່ສົນໃຈຄວາມຖືກຕ້ອງ.
///
/// ໃຫ້ສັງເກດວ່າທັງ ໝົດ [`char`] ແມ່ນຖືກຕ້ອງ [`u32`], ແລະສາມາດຖືກໂຍນລົງເປັນ ໜຶ່ງ ດຽວ
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ຢ່າງໃດກໍຕາມ, ໄດ້ຢ່າງສິ້ນເຊີງແມ່ນບໍ່ເປັນຄວາມຈິງ: ບໍ່ແມ່ນທັງຫມົດທີ່ຖືກຕ້ອງ [`u32`] s ແມ່ນຖືກຕ້ອງ [`char`] s.
/// `from_u32_unchecked()` ຈະບໍ່ສົນໃຈດັ່ງກ່າວນີ້, ແລະແມ່ພິມສໍາລັບສຸ່ມສີ່ສຸ່ມຫ້າໄປ [`char`] ຖ້າເປັນໄປໄດ້ການສ້າງເປັນຫນຶ່ງທີ່ບໍ່ຖືກຕ້ອງ.
///
///
/// # Safety
///
/// ຟັງຊັນນີ້ບໍ່ປອດໄພ, ເພາະມັນອາດຈະສ້າງຄ່າ `char` ທີ່ບໍ່ຖືກຕ້ອງ.
///
/// ສຳ ລັບລຸ້ນທີ່ມີຄວາມປອດໄພຂອງ ໜ້າ ທີ່ນີ້, ເບິ່ງ ໜ້າ ທີ່ [`from_u32`].
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // SAFETY: ການຄໍ້າປະກັນໂທຕ້ອງທີ່ `i` ເປັນມູນຄ່າຖ່ານທີ່ຖືກຕ້ອງ.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// ແປງ [`char`] ເປັນ [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// ແປງເປັນ [`char`] ໃນ [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ລັກສະນະຂອງຖືກ casted ກັບມູນຄ່າຂອງຈຸດລະຫັດໄດ້, ຫຼັງຈາກນັ້ນສູນຂະຫຍາຍໄປ 64 bit.
        // ເບິ່ງ [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// ແປງເປັນ [`char`] ໃນ [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ລັກສະນະຂອງຖືກ casted ກັບມູນຄ່າຂອງຈຸດລະຫັດໄດ້, ຫຼັງຈາກນັ້ນສູນຂະຫຍາຍໄປ 128 bit.
        // ເບິ່ງ [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// ແຜນທີ່ byte ໃນ 0x00 ..=0xFF ຫາ `char` ເຊິ່ງຈຸດລະຫັດມີຄ່າເທົ່າກັນ, ໃນ U + 0000 ..=U + 00FF.
///
/// Unicode ໄດ້ຖືກອອກແບບມາເພື່ອວ່ານີ້ຈະອອກແບບລະຫັດໄບຕ໌ຢ່າງມີປະສິດທິຜົນກັບການເຂົ້າລະຫັດຕົວອັກສອນທີ່ IANA ເອີ້ນວ່າ ISO-8859-1.
/// ການເຂົ້າລະຫັດນີ້ແມ່ນເຫມາະສົມກັບ ASCII.
///
/// ໃຫ້ສັງເກດວ່ານີ້ແຕກຕ່າງຈາກ ISO/IEC 8859-1 aka
/// ISO 8859-1 (ມີ ໜຶ່ງ hyphen ໜ້ອຍ ໜຶ່ງ), ເຊິ່ງເຮັດໃຫ້ບາງ "blanks", ຄ່າໄບຕ໌ທີ່ບໍ່ໄດ້ຖືກມອບ ໝາຍ ໃຫ້ເປັນຕົວໃດ.
/// ISO-8859-1 (the IANA one) ມອບ ໝາຍ ໃຫ້ລະຫັດຄວບຄຸມ C0 ແລະ C1.
///
/// ໃຫ້ສັງເກດວ່ານີ້ແມ່ນ *ຍັງ* ແຕກຕ່າງຈາກ Windows-1252 aka
/// ລະຫັດ ໜ້າ 1252, ເຊິ່ງແມ່ນ X ທີ່ຂະ ໜາດ ໃຫຍ່ ISO/IEC 8859-1 ທີ່ໃຫ້ຂໍ້ມູນບາງສ່ວນ (ບໍ່ແມ່ນທັງ ໝົດ) ເພື່ອໃຊ້ເຄື່ອງ ໝາຍ ວັກແລະຕົວອັກສອນລາແຕັງຕ່າງໆ.
///
/// ໃຫ້ confuse ສິ່ງທີ່ເພີ່ມເຕີມ, [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` ແລະ `windows-1252` ມີນາມແຝງທັງຫມົດສໍາລັບ superset ຂອງ Windows-1252 ທີ່ເຕີມຊ່ອງຫວ່າງທີ່ຍັງເຫຼືອມີທີ່ສອດຄ້ອງກັນ C0 ແລະ C1 ລະຫັດການຄວບຄຸມໄດ້.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// ແປງ [`u8`] ເປັນ [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// ຄວາມຜິດພາດທີ່ສາມາດໄດ້ຮັບການກັບຄືນໃນເວລາທີ່ແຍກ char ໄດ້.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // ຄວາມປອດໄພ: ກວດເບິ່ງວ່າມັນເປັນຄຸນຄ່າຂອງກົດ ໝາຍ unicode
            Ok(unsafe { transmute(i) })
        }
    }
}

/// ປະເພດຂໍ້ຜິດພາດໄດ້ກັບຄືນເມື່ອການແປງຈາກ u32 ກັບ char ລົ້ມເຫລວ.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// ແປງຫລັກໃນຫມຸດະໃຫ້ກັບ `char` ໄດ້.
///
/// A 'radix' ນີ້ບາງຄັ້ງຖືກເອີ້ນວ່າຍັງເປັນ 'base'.
/// A ຫມຸດະຂອງສອງຊີ້ໃຫ້ເຫັນເປັນຈໍານວນຄູ່, ຫມຸດະຂອງສິບ, ອັດຕານິຍົມ, ແລະຫມຸດະສິບຫົກ, ເລກຖານສິບຫົກເປັນ, ເພື່ອໃຫ້ຄຸນຄ່າຂອງຈໍານວນຫນຶ່ງ.
///
/// ຮາກໂຈມຕີຫຼືຍຶດສະຫນັບສະຫນຸນ.
///
/// `from_digit()` ຈະກັບຄືນ `None` ຖ້າການປ້ອນຂໍ້ມູນບໍ່ແມ່ນຕົວເລກໃນຫມຸດະດັ່ງກ່າວ.
///
/// # Panics
///
/// Panics ຖ້າໃຫ້ radix ໃຫຍ່ກ່ວາ 36.
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // ອັດຕານິຍົມ 11 ແມ່ນຕົວເລກດຽວຢູ່ໃນຖານ 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// ກັບຄືນໃນເວລາທີ່ `None` ການປ້ອນຂໍ້ມູນບໍ່ແມ່ນຫລັກ:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// ກຳ ລັງຂ້າມສັນຍານທີ່ໃຫຍ່, ເຊິ່ງກໍ່ໃຫ້ເກີດ panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}