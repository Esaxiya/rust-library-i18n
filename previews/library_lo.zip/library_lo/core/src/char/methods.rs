//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// ຈຸດລະຫັດສູງສຸດທີ່ຖືກຕ້ອງເປັນ `char` ສາມາດມີ.
    ///
    /// A `char` ເປັນ [Unicode Scalar Value], ຊຶ່ງຫມາຍຄວາມວ່າວ່າມັນເປັນ [Code Point], ແຕ່ບໍ່ພຽງແຕ່ພາຍໃນຂົງເຂດສະເພາະໃດຫນຶ່ງ.
    /// `MAX` ແມ່ນລະຫັດທີ່ຖືກຕ້ອງສູງສຸດທີ່ເປັນ [Unicode Scalar Value] ທີ່ຖືກຕ້ອງ.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () ຖືກນໍາໃຊ້ໃນ Unicode ໃຫ້ເປັນຕົວແທນຄວາມຜິດພາດການຖອດລະຫັດໄດ້.
    ///
    /// ມັນສາມາດເກີດຂື້ນ, ຍົກຕົວຢ່າງ, ເມື່ອໃຫ້ UTF-8 bytes ທີ່ບໍ່ຖືກຕ້ອງກັບ [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// ສະບັບຂອງ [Unicode](http://www.unicode.org/) ວ່າພາກສ່ວນ Unicode ຂອງ `char` ແລະ `str` ວິທີການແມ່ນອີງໃສ່ການ.
    ///
    /// Unicode ລຸ້ນ ໃໝ່ ຖືກອອກມາເປັນປົກກະຕິແລະຕໍ່ມາທຸກໆວິທີການໃນຫ້ອງສະມຸດມາດຕະຖານທີ່ຂື້ນກັບ Unicode ແມ່ນຖືກປັບປຸງ.
    /// ດັ່ງນັ້ນພຶດຕິ ກຳ ຂອງບາງວິທີ `char` ແລະ `str` ແລະມູນຄ່າຂອງການປ່ຽນແປງຄົງທີ່ນີ້ຕາມການເວລາ.
    /// ນີ້ແມ່ນ *ບໍ່ພິຈາລະນາ* ຈະເປັນການປ່ຽນແປງ breaking.
    ///
    /// ໂຄງການສະບັບພາສາເລກແມ່ນໄດ້ອະທິບາຍໃນ [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// ສ້າງເປັນ iterator ໃນໄລຍະ UTF-16 ເຂົ້າລະຫັດຈຸດລະຫັດໃນ `iter`, ກັບຄືນຕົວແທນໃດຫນຶ່ງ unpaired ດຽວກັນ Err`s.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// ຕົວຖອດລະຫັດສູນເສຍສາມາດໄດ້ຮັບໂດຍການທົດແທນຜົນລັບ `Err` ດ້ວຍຕົວລະຄອນແທນ:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// ແປງເປັນ `u32` ກັບ `char`.
    ///
    /// ໃຫ້ສັງເກດວ່າທັງຫມົດ `char`s ແມ່ນຖືກຕ້ອງ [`u32`] s, ແລະສາມາດໄດ້ຮັບການແມ່ພິມສໍາລັບການຫນຶ່ງທີ່ມີ
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ເຖິງຢ່າງໃດກໍ່ຕາມ, ປີ້ນກັບກັນບໍ່ແມ່ນຄວາມຈິງ: ບໍ່ແມ່ນທັງ ໝົດ [`u32`] ແມ່ນ 'char' ທີ່ຖືກຕ້ອງ.
    /// `from_u32()` ຈະກັບຄືນ `None` ຖ້າການປ້ອນຂໍ້ມູນບໍ່ແມ່ນມູນຄ່າທີ່ຖືກຕ້ອງສໍາລັບການ `char`.
    ///
    /// ສຳ ລັບລຸ້ນທີ່ບໍ່ປອດໄພຂອງ ໜ້າ ທີ່ນີ້ເຊິ່ງບໍ່ສົນໃຈກັບການກວດເຫຼົ່ານີ້, ເບິ່ງ [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// ສົ່ງຄືນ `None` ເມື່ອການປ້ອນຂໍ້ມູນບໍ່ແມ່ນ `char` ທີ່ຖືກຕ້ອງ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// ແປງ `u32` ເປັນ `char`, ບໍ່ສົນໃຈຄວາມຖືກຕ້ອງ.
    ///
    /// ໃຫ້ສັງເກດວ່າທັງຫມົດ `char`s ແມ່ນຖືກຕ້ອງ [`u32`] s, ແລະສາມາດໄດ້ຮັບການແມ່ພິມສໍາລັບການຫນຶ່ງທີ່ມີ
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ເຖິງຢ່າງໃດກໍ່ຕາມ, ປີ້ນກັບກັນບໍ່ແມ່ນຄວາມຈິງ: ບໍ່ແມ່ນທັງ ໝົດ [`u32`] ແມ່ນ 'char' ທີ່ຖືກຕ້ອງ.
    /// `from_u32_unchecked()` ຈະບໍ່ສົນໃຈດັ່ງກ່າວນີ້, ແລະແມ່ພິມສໍາລັບສຸ່ມສີ່ສຸ່ມຫ້າໄປ `char` ຖ້າເປັນໄປໄດ້ການສ້າງເປັນຫນຶ່ງທີ່ບໍ່ຖືກຕ້ອງ.
    ///
    ///
    /// # Safety
    ///
    /// ຟັງຊັນນີ້ບໍ່ປອດໄພ, ເພາະມັນອາດຈະສ້າງຄ່າ `char` ທີ່ບໍ່ຖືກຕ້ອງ.
    ///
    /// ສຳ ລັບລຸ້ນທີ່ມີຄວາມປອດໄພຂອງ ໜ້າ ທີ່ນີ້, ເບິ່ງ ໜ້າ ທີ່ [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // ຄວາມປອດໄພ: ສັນຍາດ້ານຄວາມປອດໄພຕ້ອງໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ຈາກຜູ້ໂທ.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// ແປງຫລັກໃນຫມຸດະໃຫ້ກັບ `char` ໄດ້.
    ///
    /// A 'radix' ນີ້ບາງຄັ້ງຖືກເອີ້ນວ່າຍັງເປັນ 'base'.
    /// A ຫມຸດະຂອງສອງຊີ້ໃຫ້ເຫັນເປັນຈໍານວນຄູ່, ຫມຸດະຂອງສິບ, ອັດຕານິຍົມ, ແລະຫມຸດະສິບຫົກ, ເລກຖານສິບຫົກເປັນ, ເພື່ອໃຫ້ຄຸນຄ່າຂອງຈໍານວນຫນຶ່ງ.
    ///
    /// ຮາກໂຈມຕີຫຼືຍຶດສະຫນັບສະຫນຸນ.
    ///
    /// `from_digit()` ຈະກັບຄືນ `None` ຖ້າການປ້ອນຂໍ້ມູນບໍ່ແມ່ນຕົວເລກໃນຫມຸດະດັ່ງກ່າວ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າໃຫ້ radix ໃຫຍ່ກ່ວາ 36.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // ອັດຕານິຍົມ 11 ແມ່ນຕົວເລກດຽວຢູ່ໃນຖານ 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// ກັບຄືນໃນເວລາທີ່ `None` ການປ້ອນຂໍ້ມູນບໍ່ແມ່ນຫລັກ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// ກຳ ລັງຂ້າມສັນຍານທີ່ໃຫຍ່, ເຊິ່ງກໍ່ໃຫ້ເກີດ panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// ກວດເບິ່ງວ່າ `char` ແມ່ນຕົວເລກຢູ່ໃນວົງຈອນທີ່ໃຫ້.
    ///
    /// A 'radix' ນີ້ບາງຄັ້ງຖືກເອີ້ນວ່າຍັງເປັນ 'base'.
    /// A ຫມຸດະຂອງສອງຊີ້ໃຫ້ເຫັນເປັນຈໍານວນຄູ່, ຫມຸດະຂອງສິບ, ອັດຕານິຍົມ, ແລະຫມຸດະສິບຫົກ, ເລກຖານສິບຫົກເປັນ, ເພື່ອໃຫ້ຄຸນຄ່າຂອງຈໍານວນຫນຶ່ງ.
    ///
    /// ຮາກໂຈມຕີຫຼືຍຶດສະຫນັບສະຫນຸນ.
    ///
    /// ເມື່ອປຽບທຽບກັບ [`is_numeric()`], ຟັງຊັ່ນນີ້ຈະຮັບຮູ້ພຽງແຕ່ຕົວອັກສອນ `0-9`, `a-z` ແລະ `A-Z` ເທົ່ານັ້ນ.
    ///
    /// 'Digit' ໄດ້ຖືກກໍານົດທີ່ຈະພຽງແຕ່ຕົວອັກສອນດັ່ງຕໍ່ໄປນີ້:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// ເພື່ອຄວາມເຂົ້າໃຈທີ່ສົມບູນແບບກ່ຽວກັບ 'digit', ເບິ່ງ [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics ຖ້າໃຫ້ radix ໃຫຍ່ກ່ວາ 36.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// ກຳ ລັງຂ້າມສັນຍານທີ່ໃຫຍ່, ເຊິ່ງກໍ່ໃຫ້ເກີດ panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// ແປງເປັນ `char` ກັບຫລັກໃນຫມຸດະໃຫ້ໄດ້.
    ///
    /// A 'radix' ນີ້ບາງຄັ້ງຖືກເອີ້ນວ່າຍັງເປັນ 'base'.
    /// A ຫມຸດະຂອງສອງຊີ້ໃຫ້ເຫັນເປັນຈໍານວນຄູ່, ຫມຸດະຂອງສິບ, ອັດຕານິຍົມ, ແລະຫມຸດະສິບຫົກ, ເລກຖານສິບຫົກເປັນ, ເພື່ອໃຫ້ຄຸນຄ່າຂອງຈໍານວນຫນຶ່ງ.
    ///
    /// ຮາກໂຈມຕີຫຼືຍຶດສະຫນັບສະຫນຸນ.
    ///
    /// 'Digit' ໄດ້ຖືກກໍານົດທີ່ຈະພຽງແຕ່ຕົວອັກສອນດັ່ງຕໍ່ໄປນີ້:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// ກັບຄືນ `None` ຖ້າ `char` ບໍ່ໄດ້ ໝາຍ ເຖິງຕົວເລກໃນວົງຈອນທີ່ໃຫ້.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າໃຫ້ radix ໃຫຍ່ກ່ວາ 36.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// ການຖ່າຍທອດຜົນລັບທີ່ບໍ່ແມ່ນຕົວເລກໃນຄວາມລົ້ມເຫຼວ:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// ກຳ ລັງຂ້າມສັນຍານທີ່ໃຫຍ່, ເຊິ່ງກໍ່ໃຫ້ເກີດ panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // ລະຫັດໄດ້ຖືກແບ່ງປັນເຖິງທີ່ນີ້ເພື່ອປັບປຸງຄວາມໄວປະຕິບັດສໍາລັບການກໍລະນີທີ່ `radix` ຈະຄົງທີ່ແລະ 10 ຫຼືຂະຫນາດນ້ອຍກວ່າ
        //
        let val = if likely(radix <= 10) {
            // ຖ້າຫາກວ່າບໍ່ແມ່ນຕົວເລກ, ເປັນຈໍານວນກ່ວາຫມຸດະຈະໄດ້ຮັບການສ້າງຕັ້ງຂື້ນ.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// ສົ່ງຄືນຕົວແກ້ແຄ້ນທີ່ໃຫ້ຜົນລັບຂອງຕົວອັກສອນ Unicode ທີ່ ໜີ ອອກຈາກລັກສະນະເປັນ `char`.
    ///
    /// ນີ້ຈະຫນີລັກສະນະຕ່າງໆທີ່ມີ Rust syntax ຂອງຮູບແບບ `\u{NNNNNN}` ທີ່ `NNNNNN` ແມ່ນຕົວແທນຂອງຕົວເລກ hexadecimal.
    ///
    ///
    /// # Examples
    ///
    /// ໃນຖານະທີ່ເປັນຜູ້ປັບ:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ການນໍາໃຊ້ `println!` ໂດຍກົງ:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// ທັງສອງເທົ່າກັບ:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// ການໃຊ້ `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 ຮັບປະກັນວ່າ ສຳ ລັບ c==0 ລະຫັດລວບລວມຂໍ້ມູນທີ່ຄວນຈະພິມ ໜຶ່ງ ຕົວເລກແລະ (ເຊິ່ງດຽວກັນ) ຫລີກລ້ຽງການໄຫຼວຽນຂອງ (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ດັດຊະນີຂອງທີ່ສຸດ hex ຫລັກທີ່ສໍາຄັນ
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// ຮຸ່ນ `escape_debug` ທີ່ຂະຫຍາຍອອກມາເຊິ່ງສາມາດອະນຸຍາດໃຫ້ຫລົບ ໜີ ຕົວເລືອກລະຫັດ Grapheme ຂະຫຍາຍໄດ້.
    /// ນີ້ອະນຸຍາດໃຫ້ພວກເຮົາຈັດຮູບແບບຕົວ ໜັງ ສືຄືກັບເຄື່ອງ ໝາຍ ທີ່ບໍ່ມີຈຸດ ໝາຍ ດີກວ່າເມື່ອພວກເຂົາເລີ່ມຕົ້ນສາຍ.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// ສົ່ງຄືນຕົວແກ້ໄຂທີ່ໃຫ້ລະຫັດການຫລົບຫນີຕົວຫນັງສືຂອງຕົວລະຄອນເປັນ `char`.
    ///
    /// ນີ້ຈະຫນີຕົວອັກສອນທີ່ຄ້າຍຄືກັນກັບການປະຕິບັດ `Debug` ຂອງ `str` ຫຼື `char`.
    ///
    ///
    /// # Examples
    ///
    /// ໃນຖານະທີ່ເປັນຜູ້ປັບ:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ການນໍາໃຊ້ `println!` ໂດຍກົງ:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// ທັງສອງເທົ່າກັບ:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// ການໃຊ້ `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// ສົ່ງຄືນຕົວແກ້ໄຂທີ່ໃຫ້ລະຫັດການຫລົບຫນີຕົວຫນັງສືຂອງຕົວລະຄອນເປັນ `char`.
    ///
    /// ຄ່າເລີ່ມຕົ້ນຖືກເລືອກດ້ວຍຄວາມ ລຳ ອຽງຕໍ່ການຜະລິດຕົວ ໜັງ ສືທີ່ຖືກຕ້ອງຕາມກົດ ໝາຍ ໃນຫລາຍພາສາ, ລວມທັງ C++ 11 ແລະພາສາ C-family ທີ່ຄ້າຍຄືກັນ.
    /// ກົດລະບຽບການຄືກັນອ້ອຍຕ້ອຍແມ່ນ:
    ///
    /// * ແທັບຖືກ ໜີ ເປັນ `\t`.
    /// * ການກັບຄືນລົດບັນທຸກແມ່ນ ໜີ ໄປເປັນ `\r`.
    /// * ອາຫານເສັ້ນແມ່ນ ໜີ ເປັນ `\n`.
    /// * ໃບສະ ເໜີ ລາຄາດຽວຖືກເອົາຕົວຫຼົບ ໜີ ເປັນ `\'`.
    /// * ໃບສະ ເໜີ ລາຄາຄູ່ຈະຖືກປ່ອຍຕົວເປັນ `\"`.
    /// * Backslash ຖືກຫລົບຫນີເປັນ `\\`.
    /// * ຕົວອັກສອນໃນການ 'ASCII ພິມ' ຊ່ວງ `0x20` .. `0x7e` ລວມແມ່ນຫລົບຫນີບໍ່ໄດ້.
    /// * ຕົວອັກສອນອື່ນໆທັງ ໝົດ ແມ່ນໄດ້ຮັບການ ໜີ ຈາກ Unicode;ເບິ່ງ [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// ໃນຖານະທີ່ເປັນຜູ້ປັບ:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ການນໍາໃຊ້ `println!` ໂດຍກົງ:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// ທັງສອງເທົ່າກັບ:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// ການໃຊ້ `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// ຜົນໄດ້ຮັບຈໍານວນຂອງໄບຕ໌ `char` ນີ້ຈະຕ້ອງຖ້າຫາກວ່າລະຫັດໃນ UTF-8 ໄດ້.
    ///
    /// ຈໍານວນຂອງໄບຕ໌ວ່າເປັນສະເຫມີລະຫວ່າງ 1 ແລະ 4 ລວມ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// The `&str` ປະເພດຮັບປະກັນວ່າເນື້ອໃນຂອງຕົນແມ່ນ UTF-8, ແລະດັ່ງນັ້ນພວກເຮົາສາມາດປຽບທຽບຄວາມຍາວທີ່ມັນຈະໃຊ້ເວລາຖ້າຫາກວ່າໃນແຕ່ລະຈຸດລະຫັດໄດ້ເປັນຕົວແທນເປັນ `char` vs ໃນ `&str` ຕົວຂອງມັນເອງ:
    ///
    ///
    /// ```
    /// // ເປັນ chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ທັງສອງສາມາດເປັນຕົວແທນເປັນສາມ bytes
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // ເປັນ &str, ສອງຢ່າງນີ້ຖືກເຂົ້າລະຫັດໃນ UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // ພວກເຮົາສາມາດເຫັນໄດ້ວ່າພວກເຂົາເອົາທັງ ໝົດ 6 ໄບ ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... ຄືກັນກັບ &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// ກັບຄືນ ຈຳ ນວນຫົວ ໜ່ວຍ ລະຫັດ 16 ບິດທີ່ `char` ນີ້ຕ້ອງການຖ້າມີການເຂົ້າລະຫັດໃນ UTF-16.
    ///
    ///
    /// ເບິ່ງເອກະສານສໍາລັບ [`len_utf8()`] ສໍາລັບຄໍາອະທິບາຍເພີ່ມເຕີມຂອງແນວຄວາມຄິດນີ້.
    /// ຟັງຊັນນີ້ແມ່ນບ່ອນແລກປ່ຽນຄວາມ, ແຕ່ ສຳ ລັບ UTF-16 ແທນ UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// ຖອດລະຫັດລັກສະນະນີ້ເປັນ UTF-8 ເຂົ້າໄປໃນບັຟເຟີ byte ສະຫນອງໃຫ້, ແລະຫຼັງຈາກນັ້ນກັບຄືນມາ subslice ຂອງບັຟເຟີທີ່ປະກອບດ້ວຍລັກສະນະ encoded ລົງໄດ້.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ buffer ແມ່ນບໍ່ພຽງພໍຂະຫນາດໃຫຍ່.
    /// A ບັຟເຟີຂອງຄວາມຍາວສີ່ແມ່ນພຽງພໍຂະຫນາດໃຫຍ່ການເຂົ້າລະຫັດ `char` ໃດ.
    ///
    /// # Examples
    ///
    /// ໃນທັງສອງຕົວຢ່າງເຫລົ່ານີ້, 'ß' ໃຊ້ເວລາສອງ bytes ເພື່ອ encode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// buffer ທີ່ນ້ອຍເກີນໄປ:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // ຄວາມປອດໄພ: `char` ບໍ່ແມ່ນຕົວແທນຕົວແທນ, ດັ່ງນັ້ນນີ້ແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// ເຂົ້າລະຫັດລັກສະນະນີ້ເປັນ UTF-16 ເຂົ້າໄປໃນ buffer `u16` ທີ່ໃຫ້, ແລະຫຼັງຈາກນັ້ນສົ່ງຄືນ subslice ຂອງ buffer ທີ່ປະກອບດ້ວຍຕົວອັກສອນທີ່ຖືກເຂົ້າລະຫັດ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ buffer ແມ່ນບໍ່ພຽງພໍຂະຫນາດໃຫຍ່.
    /// A ບັຟເຟີຂອງຄວາມຍາວ 2 ແມ່ນພຽງພໍຂະຫນາດໃຫຍ່ການເຂົ້າລະຫັດ `char` ໃດ.
    ///
    /// # Examples
    ///
    /// ໃນທັງສອງຕົວຢ່າງເຫຼົ່ານີ້, '𝕊' ໃຊ້ເວລາສອງ `u16` ເພື່ອເຂົ້າລະຫັດ.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// buffer ທີ່ນ້ອຍເກີນໄປ:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// ຜົນຕອບແທນ `true` ຖ້າ `char` ນີ້ມີ `Alphabetic` ຄຸນສົມບັດ.
    ///
    /// `Alphabetic` ຖືກອະທິບາຍໄວ້ໃນບົດທີ 4 (ຄຸນສົມບັດຂອງຕົວລະຄອນ) ຂອງ [Unicode Standard] ແລະລະບຸໄວ້ໃນ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ຄວາມຮັກມີຫຼາຍຢ່າງ, ແຕ່ມັນບໍ່ແມ່ນຕົວ ໜັງ ສື
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// ຜົນຕອບແທນ `true` ຖ້າ `char` ນີ້ມີ `Lowercase` ຄຸນສົມບັດ.
    ///
    /// `Lowercase` ຖືກອະທິບາຍໄວ້ໃນບົດທີ 4 (ຄຸນສົມບັດຂອງຕົວລະຄອນ) ຂອງ [Unicode Standard] ແລະລະບຸໄວ້ໃນ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // ຕົວອັກສອນແລະວັກຕອນຕ່າງໆຂອງຈີນບໍ່ມີກໍລະນີ, ແລະອື່ນໆ:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// ສົ່ງຄືນ `true` ຖ້າ `char` ນີ້ມີຊັບສິນ `Uppercase`.
    ///
    /// `Uppercase` ຖືກອະທິບາຍໄວ້ໃນບົດທີ 4 (ຄຸນສົມບັດຂອງຕົວລະຄອນ) ຂອງ [Unicode Standard] ແລະລະບຸໄວ້ໃນ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // ຕົວອັກສອນແລະວັກຕອນຕ່າງໆຂອງຈີນບໍ່ມີກໍລະນີ, ແລະອື່ນໆ:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// ສົ່ງຄືນ `true` ຖ້າ `char` ນີ້ມີຊັບສິນ `White_Space`.
    ///
    /// `White_Space` ລະບຸໄວ້ໃນ [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // ເປັນພື້ນທີ່ທີ່ບໍ່ແມ່ນການພັກຜ່ອນ
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// ຜົນໄດ້ຮັບ `true` ຖ້ານີ້ `char` satisfies ບໍ່ວ່າຈະ [`is_alphabetic()`] ຫຼື [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// ຜົນຕອບແທນ `true` ຖ້າ `char` ນີ້ມີປະເພດໂດຍທົ່ວໄປສໍາລັບການລະຫັດການຄວບຄຸມ.
    ///
    /// ລະຫັດການຄວບຄຸມ (ຈຸດລະຫັດທີ່ມີປະເພດທົ່ວໄປຂອງ `Cc`) ກໍາລັງອະທິບາຍໃນບົດທີ 4 (Character ຄຸນສົມບັດ) ຂອງ [Unicode Standard] ແລະກໍານົດໄວ້ໃນ [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // U + 009C, ຢູ່ປາຍຍອດ STRING
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// ສົ່ງຄືນ `true` ຖ້າ `char` ນີ້ມີຊັບສິນ `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` ອະທິບາຍໃນ [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ແລະກໍານົດໄວ້ໃນ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// ກັບຄືນ `true` ຖ້າ `char` ນີ້ມີ ໜຶ່ງ ໃນປະເພດທົ່ວໄປ ສຳ ລັບຕົວເລກ.
    ///
    /// ປະເພດທົ່ວໄປຕົວເລກ (`Nd` ສໍາລັບຕົວເລກອັດຕານິຍົມ, `Nl` ສໍາລັບຈົດຫມາຍສະບັບ, ເຊັ່ນ: ຕົວອັກສອນຈໍານວນຫລາຍ, ແລະ `No` ສໍາລັບຕົວອັກສອນຕົວເລກອື່ນໆ) ໄດ້ຖືກກໍານົດໄວ້ໃນ [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// ຜົນຕອບແທນເປັນ iterator ທີ່ຜະການເຮັດແຜນທີ່ lowercase ຂອງ `char` ນີ້ເປັນຫນຶ່ງຫຼືຫຼາຍກວ່ານັ້ນ
    /// `char`s.
    ///
    /// ຖ້າ `char` ນີ້ບໍ່ມີແຜນທີ່ນ້ອຍ, ຕົວຊີ້ວັດຈະໃຫ້ຜົນຜະລິດເທົ່າກັບ `char`.
    ///
    /// ຖ້າ `char` ນີ້ມີຫນຶ່ງໄປຫາຫນຶ່ງໃນອັກສອນຕົວນ້ອຍແຜນທີ່ມອບໃຫ້ໂດຍ [Unicode Character Database][ucd] [`UnicodeData.txt`], ຜົນຜະລິດ iterator ທີ່ `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ຖ້າ `char` ນີ້ຮຽກຮ້ອງໃຫ້ມີການພິຈາລະພິເສດ (ຕົວຢ່າງ: ຫຼາຍ `char`s) ໄດ້ iterator yields ທີ່`char` (s) ໃຫ້ໂດຍ [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ການປະຕິບັດງານນີ້ ດຳ ເນີນການສ້າງແຜນທີ່ໂດຍບໍ່ມີເງື່ອນໄຂໂດຍບໍ່ຕ້ອງປັບແຕ່ງ.ນັ້ນແມ່ນ, ການປ່ຽນໃຈເຫລື້ອມໃສແມ່ນເອກະລາດຂອງສະພາບການແລະພາສາ.
    ///
    /// ໃນ [Unicode Standard], ພາກທີ 4 (ຄຸນສົມບັດລັກສະນະ) ສົນທະນາແຜນທີ່ກໍລະນີໂດຍທົ່ວໄປແລະພາກທີ 3 (Conformance) ສົນທະນາວິທີການໄວ້ໃນຕອນຕົ້ນສໍາລັບກໍລະນີການປ່ຽນແປງ.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ໃນຖານະທີ່ເປັນຜູ້ປັບ:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ການນໍາໃຊ້ `println!` ໂດຍກົງ:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// ທັງສອງເທົ່າກັບ:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// ການໃຊ້ `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // ບາງຄັ້ງຜົນໄດ້ຮັບແມ່ນມີຫຼາຍກວ່າ ໜຶ່ງ ຕົວ ໜັງ ສື:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // ຕົວອັກສອນທີ່ບໍ່ມີທັງຕົວອັກສອນຫຍໍ້ແລະໂຕນ້ອຍປ່ຽນເປັນຕົວເອງ.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// ສົ່ງຄືນເຄື່ອງ ໝາຍ ທີ່ໃຫ້ຜົນຜະລິດທີ່ໃຫຍ່ທີ່ສຸດຂອງ `char` ນີ້ເປັນ ໜຶ່ງ ຫຼືຫຼາຍກວ່ານັ້ນ
    /// `char`s.
    ///
    /// ຖ້າ `char` ນີ້ບໍ່ມີແຜນທີ່ໃຫຍ່, ຕົວຊີ້ວັດຈະໃຫ້ຜົນຜະລິດເທົ່າກັບ `char`.
    ///
    /// ຖ້າ `char` ນີ້ມີແຜນທີ່ໃຫຍ່ທີ່ ໜຶ່ງ ຕໍ່ ໜຶ່ງ ແຜນທີ່ໃຫ້ໂດຍ [Unicode Character Database][ucd] [`UnicodeData.txt`], ຕົວຊີ້ວັດຈະໃຫ້ຜົນຕອບແທນທີ່ `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ຖ້າ `char` ນີ້ຮຽກຮ້ອງໃຫ້ມີການພິຈາລະພິເສດ (ຕົວຢ່າງ: ຫຼາຍ `char`s) ໄດ້ iterator yields ທີ່`char` (s) ໃຫ້ໂດຍ [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ການປະຕິບັດງານນີ້ ດຳ ເນີນການສ້າງແຜນທີ່ໂດຍບໍ່ມີເງື່ອນໄຂໂດຍບໍ່ຕ້ອງປັບແຕ່ງ.ນັ້ນແມ່ນ, ການປ່ຽນໃຈເຫລື້ອມໃສແມ່ນເອກະລາດຂອງສະພາບການແລະພາສາ.
    ///
    /// ໃນ [Unicode Standard], ພາກທີ 4 (ຄຸນສົມບັດລັກສະນະ) ສົນທະນາແຜນທີ່ກໍລະນີໂດຍທົ່ວໄປແລະພາກທີ 3 (Conformance) ສົນທະນາວິທີການໄວ້ໃນຕອນຕົ້ນສໍາລັບກໍລະນີການປ່ຽນແປງ.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ໃນຖານະທີ່ເປັນຜູ້ປັບ:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ການນໍາໃຊ້ `println!` ໂດຍກົງ:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// ທັງສອງເທົ່າກັບ:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// ການໃຊ້ `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // ບາງຄັ້ງຜົນໄດ້ຮັບແມ່ນມີຫຼາຍກວ່າ ໜຶ່ງ ຕົວ ໜັງ ສື:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // ຕົວອັກສອນທີ່ບໍ່ມີທັງຕົວອັກສອນຫຍໍ້ແລະໂຕນ້ອຍປ່ຽນເປັນຕົວເອງ.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # ໝາຍ ເຫດກ່ຽວກັບທ້ອງຖິ່ນ
    ///
    /// ໃນຕວກກີ, ທຽບເທົ່າຂອງ 'i' ໃນລາແຕັງມີຫ້າຮູບແບບແທນທີ່ຈະເປັນສອງ:
    ///
    /// * 'Dotless': I/ຂ້າພະເຈົ້າ, ຂ້າພະເຈົ້າບາງຄັ້ງລາຍລັກອັກສອນ
    /// * 'Dotted': ຂ້າພະເຈົ້າ/ຂ້າພະເຈົ້າ
    ///
    /// ໃຫ້ສັງເກດວ່າຈຸດນ້ອຍໆ 'i' ແມ່ນຄືກັນກັບພາສາລະຕິນ.ເພາະສະນັ້ນ:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// ມູນຄ່າຂອງ `upper_i` ນີ້ຖືກແກ້ໄຂເທື່ອໃນພາສາຂອງຂໍ້ຄວາມ: ຖ້າຫາກວ່າພວກເຮົາກໍາລັງໃນ `en-US`, ມັນຄວນຈະເປັນ `"I"`, ແຕ່ຖ້າຫາກວ່າພວກເຮົາກໍາລັງໃນ `tr_TR`, ມັນຄວນຈະເປັນ `"İ"`.
    /// `to_uppercase()` ບໍ່ໄດ້ພິຈາລະນາເລື່ອງນີ້, ແລະອື່ນໆ:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// ຖືພາສາຕ່າງໆ.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// ກວດເບິ່ງວ່າມູນຄ່າຢູ່ໃນຂອບເຂດ ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// ເຮັດ ສຳ ເນົາຂອງມູນຄ່າໃນເອກະສານຊ້ອນທ້າຍ ASCII ຂອງມັນ.
    ///
    /// ຕົວອັກສອນ ASCII 'a' ກັບ 'z' ແມ່ນ mapped ກັບ 'A' ກັບ 'Z', ແຕ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII ແມ່ນບໍ່ປ່ຽນແປງ.
    ///
    /// ການພິມໃຫຍ່ມູນຄ່າໃນສະຖານທີ່, ການນໍາໃຊ້ [`make_ascii_uppercase()`].
    ///
    /// ການພິມໃຫຍ່ຕົວອັກສອນ ASCII ນອກເຫນືອໄປຈາກຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII, ໃຊ້ [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// ເຮັດສໍາເນົາຂອງມູນຄ່າໃນກໍລະນີຕ່ໍາ ASCII ທຽບເທົ່າຂອງຕົນໄດ້.
    ///
    /// ຕົວອັກສອນ ASCII 'A' ຫາ 'Z' ຖືກແຕ້ມໃສ່ 'a' ຫາ 'z', ແຕ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII ບໍ່ປ່ຽນແປງ.
    ///
    /// ເພື່ອເຮັດໃຫ້ຄຸນຄ່າໃນສະຖານທີ່ນ້ອຍລົງ, ໃຫ້ໃຊ້ [`make_ascii_lowercase()`].
    ///
    /// ເປັນຕົວພິມເລັກຕົວອັກສອນ ASCII ນອກເຫນືອໄປຈາກຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII, ໃຊ້ [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// ການກວດສອບວ່າສອງຄ່າແມ່ນການແຂ່ງຂັນກໍລະນີ, insensitive ASCII.
    ///
    /// ທຽບເທົ່າກັບ `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// ປ່ຽນປະເພດນີ້ໃຫ້ເປັນ ASCII ໂຕໃຫຍ່ໃຫຍ່ທຽບເທົ່າກັບສະຖານທີ່.
    ///
    /// ຕົວອັກສອນ ASCII 'a' ກັບ 'z' ແມ່ນ mapped ກັບ 'A' ກັບ 'Z', ແຕ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII ແມ່ນບໍ່ປ່ຽນແປງ.
    ///
    /// ເພື່ອກັບຄືນຄ່າ ໃໝ່ ທີ່ບໍ່ມີມູນຄ່າ ໃໝ່ ໂດຍບໍ່ຕ້ອງດັດແປງຄ່າທີ່ມີຢູ່, ໃຫ້ໃຊ້ [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// ປ່ຽນໃຈເຫລື້ອມໃສປະເພດນີ້ຈະ ASCII ກໍລະນີຕ່ໍາທຽບເທົ່າຂອງຕົນໃນສະຖານທີ່.
    ///
    /// ຕົວອັກສອນ ASCII 'A' ຫາ 'Z' ຖືກແຕ້ມໃສ່ 'a' ຫາ 'z', ແຕ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII ບໍ່ປ່ຽນແປງ.
    ///
    /// ເພື່ອກັບຄືນມູນຄ່າທີ່ຫຼຸດລົງ ໃໝ່ ໂດຍບໍ່ມີການດັດແປງຂອງທີ່ມີຢູ່, ໃຫ້ໃຊ້ [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// ກວດສອບວ່າຄ່າທີ່ເປັນ ASCII ຕົວອັກສອນເທົ່າ:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' ຫລື
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// ກວດສອບວ່າຄ່າທີ່ເປັນ ASCII ໃຫຍ່ລັກສະນະ:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// ກວດເບິ່ງວ່າມູນຄ່າແມ່ນຕົວອັກສອນຕົວນ້ອຍຂອງ ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// ກວດເບິ່ງວ່າມູນຄ່າແມ່ນຕົວອັກສອນຕົວອັກສອນ ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' ຫລື
    /// - U + 0061 'a' ..=U + 007A 'z' ຫລື
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// ກວດເບິ່ງວ່າມູນຄ່າແມ່ນຕົວເລກອັດຕານິຍົມ ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// ກວດເບິ່ງວ່າມູນຄ່າຂອງມັນແມ່ນຕົວເລກ ASCII hexadecimal:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', ຫຼື
    /// - U + 0041 'A' ..=U + 0046 'F' ຫລື
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// ກວດສອບວ່າຄ່າທີ່ເປັນລັກສະນະ ASCII ເຄື່ອງຫມາຍວັກຕອນ:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, ຫຼື
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` ຫລື
    /// - U + 005B ..=U + 0060 ``[\] ^ _`` ຫລື
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// ກວດເບິ່ງວ່າມູນຄ່າແມ່ນຕົວອັກສອນກາຟິກ ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// ກວດເບິ່ງວ່າມູນຄ່າແມ່ນ ASCII character whitespace character:
    /// U + 0020 SPACE, U + 0009 ນອນ TAB, U + 000A LINE FEED, U + 000C FORM FEED ຫລື U + 000D CARRIAGE ກັບຄືນ.
    ///
    /// Rust ໃຊ້ [definition of ASCII whitespace][infra-aw] ຂອງ WhatWG Infra Standard.ມີຄໍານິຍາມອື່ນໆຈໍານວນຫນຶ່ງໃນການນໍາໃຊ້ກ້ວາງແມ່ນ.
    /// ສໍາລັບການຍົກຕົວຢ່າງ, [the POSIX locale][pct] ປະກອບ U + 000b ແນວຕັ້ງ TAB ເຊັ່ນດຽວກັນກັບທຸກຄົນລັກສະນະຂ້າງເທິງນີ້, ແຕ່, ຈາກ specification-ດຽວກັນຫຼາຍ [ກົດໄວ້ໃນຕອນຕົ້ນສໍາລັບ "field splitting" ໃນ Bourne shell][BFS] ຖື *ເທົ່ານັ້ນ* SPACE, ນອນ, TAB, ແລະ LINE FEED ເປັນຊ່ອງຫວ່າງ.
    ///
    ///
    /// ຖ້າຫາກວ່າທ່ານກໍາລັງຂຽນໂຄງການທີ່ຈະດໍາເນີນການເປັນຮູບແບບເອກະສານທີ່ມີຢູ່ແລ້ວໃຫ້ກວດສອບສິ່ງທີ່ຄໍານິຍາມຮູບແບບທີ່ຂອງຊ່ອງຫວ່າງແມ່ນກ່ອນທີ່ຈະໃຊ້ຫນ້າທີ່ນີ້.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// ກວດສອບວ່າຄ່າທີ່ເປັນລັກສະນະການຄວບຄຸມ ASCII:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR ຫລື U + 007F ລົບ.
    /// ໃຫ້ສັງເກດວ່າ ASCII ທີ່ສຸດລັກສະນະຂອງຊ່ອງຫວ່າງມີລັກສະນະການຄວບຄຸມ, ແຕ່ສະຖານທີ່ແມ່ນບໍ່.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// ເຂົ້າລະຫັດມູນຄ່າ u32 ດິບເປັນ UTF-8 ເຂົ້າໄປໃນ buffer ໄບຕ໌ທີ່ໃຫ້, ແລະຈາກນັ້ນສົ່ງຄືນ subslice ຂອງ buffer ທີ່ປະກອບດ້ວຍຕົວອັກສອນທີ່ຖືກເຂົ້າລະຫັດ.
///
///
/// ບໍ່ຄືກັບ `char::encode_utf8`, ວິທີການນີ້ຍັງຈັດການລະຫັດຈຸດໃນຂອບເຂດຕົວແທນ.
/// (ການສ້າງ `char` ໃນຂອບເຂດຕົວແທນແມ່ນ UB.) ຜົນໄດ້ຮັບແມ່ນ [generalized UTF-8] ທີ່ຖືກຕ້ອງແຕ່ບໍ່ຖືກຕ້ອງ UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics ຖ້າ buffer ແມ່ນບໍ່ພຽງພໍຂະຫນາດໃຫຍ່.
/// A ບັຟເຟີຂອງຄວາມຍາວສີ່ແມ່ນພຽງພໍຂະຫນາດໃຫຍ່ການເຂົ້າລະຫັດ `char` ໃດ.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// ເຂົ້າລະຫັດມູນຄ່າ u32 ດິບເປັນ UTF-16 ເຂົ້າໄປໃນ `u16` buffer ທີ່ໃຫ້, ແລະຫຼັງຈາກນັ້ນສົ່ງຄືນ subslice ຂອງ buffer ທີ່ປະກອບດ້ວຍຕົວອັກສອນທີ່ຖືກເຂົ້າລະຫັດ.
///
///
/// ບໍ່ເຫມືອນກັບ `char::encode_utf16`, ວິທີການນີ້ຍັງຈັບ codepoints ຢູ່ໃນລະດັບຕົວແທນໃດຫນຶ່ງ.
/// (ການສ້າງ `char` ໃນຂອບເຂດຕົວແທນແມ່ນ UB.)
///
/// # Panics
///
/// Panics ຖ້າ buffer ແມ່ນບໍ່ພຽງພໍຂະຫນາດໃຫຍ່.
/// A ບັຟເຟີຂອງຄວາມຍາວ 2 ແມ່ນພຽງພໍຂະຫນາດໃຫຍ່ການເຂົ້າລະຫັດ `char` ໃດ.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SAFETY: ການກວດສອບແຕ່ລະແຂນວ່າມີ bits ພຽງພໍທີ່ຈະຂຽນເປັນ
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP ຕົກ
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // ເຮືອບິນເສີມແຕກແຍກອອກເປັນຕົວແທນໃດຫນຶ່ງ.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}