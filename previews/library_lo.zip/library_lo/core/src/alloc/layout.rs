use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// ໃນຂະນະທີ່ ໜ້າ ທີ່ນີ້ຖືກ ນຳ ໃຊ້ຢູ່ບ່ອນດຽວແລະການຈັດຕັ້ງປະຕິບັດສາມາດສອດຄ່ອງ, ຄວາມພະຍາຍາມໃນການເຮັດກ່ອນ ໜ້າ ນີ້ເຮັດໃຫ້ rustc ຊ້າ:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// ຮູບແບບຂອງທ່ອນໄມ້ຂອງຄວາມຊົງ ຈຳ.
///
/// ຕົວຢ່າງຂອງ `Layout` ອະທິບາຍການຈັດຮູບແບບຂອງ ໜ່ວຍ ຄວາມ ຈຳ ສະເພາະ.
/// ທ່ານສ້າງ `Layout` ຂຶ້ນເປັນວັດສະດຸປ້ອນເພື່ອມອບໃຫ້ຜູ້ຈັດສັນ.
///
/// ການຈັດວາງທັງ ໝົດ ລ້ວນແຕ່ມີຂະ ໜາດ ທີ່ກ່ຽວຂ້ອງແລະມີຄວາມສອດຄ່ອງກັບສອງພະລັງງານ.
///
/// (ໃຫ້ສັງເກດວ່າການຈັດວາງ * ບໍ່ ຈຳ ເປັນຕ້ອງມີຂະ ໜາດ ທີ່ບໍ່ແມ່ນສູນ, ເຖິງແມ່ນວ່າ `GlobalAlloc` ຮຽກຮ້ອງໃຫ້ທຸກໆການຮ້ອງຂໍ ໜ່ວຍ ຄວາມ ຈຳ ບໍ່ແມ່ນຂະ ໜາດ ທີ່ບໍ່ແມ່ນສູນ.
/// ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າເງື່ອນໄຂແບບນີ້ຖືກຕອບສະ ໜອງ, ນຳ ໃຊ້ຜູ້ຈັດສັນສະເພາະກັບຂໍ້ ກຳ ນົດວ່າງຫລືໃຊ້ອິນເຕີເຟດ `Allocator` ທີ່ມີຄວາມອ່ອນແອກວ່າ.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // ຂະ ໜາດ ຂອງບລັອກທີ່ຖືກຮຽກຮ້ອງຂອງ ໜ່ວຍ ຄວາມ ຈຳ, ວັດແທກເປັນໄບ.
    size_: usize,

    // ຄວາມສອດຄ່ອງຂອງທ່ອນໄມ້ທີ່ຖືກຮຽກຮ້ອງຂອງຄວາມຊົງ ຈຳ, ວັດແທກເປັນໄບ.
    // ພວກເຮົາຮັບປະກັນວ່າສິ່ງນີ້ແມ່ນພະລັງງານສະ ເໝີ ໄປ, ເພາະວ່າ API ຄ້າຍຄື `posix_memalign` ຕ້ອງການມັນແລະມັນເປັນຂໍ້ ຈຳ ກັດທີ່ສົມເຫດສົມຜົນທີ່ຈະບັງຄັບໃຊ້ກັບຜູ້ກໍ່ສ້າງ Layout.
    //
    //
    // (ເຖິງຢ່າງໃດກໍ່ຕາມ, ພວກເຮົາບໍ່ຕ້ອງການ `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// ກໍ່ສ້າງ `Layout` ຈາກ `size` ແລະ `align`, ຫຼືສົ່ງຄືນ `LayoutError` ຖ້າມີເງື່ອນໄຂຕໍ່ໄປນີ້ບໍ່ຖືກຕ້ອງ:
    ///
    /// * `align` ບໍ່ຕ້ອງເປັນສູນ,
    ///
    /// * `align` ຕ້ອງເປັນພະລັງຂອງສອງ,
    ///
    /// * `size`, ເມື່ອມົນເຖິງຫລາຍໆ `align` ທີ່ໃກ້ທີ່ສຸດ, ບໍ່ຄວນລົ້ນ (ໝາຍ ຄວາມວ່າມູນຄ່າມົນຈະຕ້ອງນ້ອຍກວ່າຫລືເທົ່າກັບ `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (ພະລັງງານຂອງສອງກໍຫມາຍຄວາມວ່າ align=0)

        // ຂະຫນາດເຖິງມົນແມ່ນ:
        //   size_rounded_up=(ຂະ ໜາດ + ສອດຄ່ອງ, 1)&! (ສອດຄ່ອງ, 1);
        //
        // ພວກເຮົາຮູ້ຈາກຂັ້ນເທິງວ່າແນວນັ້ນ!=0.
        // ຖ້າເພີ່ມ (ຈັດລຽນ, 1) ບໍ່ລົ້ນ, ຫຼັງຈາກນັ້ນຮອບກໍ່ຈະດີ.
        //
        // ກົງກັນຂ້າມ,&-masking ກັບ! (ສອດຄ່ອງ, 1) ຈະຫັກລົບພຽງແຕ່ການສັ່ງຊື້ສິນຄ້າຕໍ່າເທົ່ານັ້ນ.
        // ດັ່ງນັ້ນຈຶ່ງວ່າ overflow ເກີດຂຶ້ນກັບຈໍານວນເງິນເອົາ, ໄດ້&-Mask ບໍ່ສາມາດຫັກລົບພຽງພໍທີ່ຈະຍົກເລີກ overflow ທີ່.
        //
        //
        // ຂ້າງເທິງນີ້ກໍຫມາຍຄວາມວ່າການກວດກາເບິ່ງສໍາລັບ summation overflow ແມ່ນທັງສອງມີຄວາມຈໍາເປັນແລະພຽງພໍ.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // ຄວາມປອດໄພ: ເງື່ອນໄຂຂອງ `from_size_align_unchecked` ໄດ້
        // ຂາງ້ເທງິ.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// ສ້າງຮູບແບບ, ຂ້າມຜ່ານການກວດສອບທັງ ໝົດ.
    ///
    /// # Safety
    ///
    /// ຫນ້ານີ້ແມ່ນບໍ່ປອດໄພຍ້ອນວ່າມັນບໍ່ໄດ້ຢືນຢັນເທື່ອເງື່ອນໄຂຈາກ [`Layout::from_size_align`] ໄດ້.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `align` ໃຫຍ່ກວ່າສູນ.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// ຂະ ໜາດ ຕ່ ຳ ສຸດເປັນໄບຕ໌ ສຳ ລັບບລັອກ ໜ່ວຍ ຄວາມ ຈຳ ຂອງຮູບແບບນີ້.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// ການຈັດຕໍາ ແໜ່ງ ໄບຕ່ ຳ ສຸດ ສຳ ລັບບລັອກຄວາມ ຈຳ ຂອງຮູບແບບນີ້.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// ໂຄງສ້າງ `Layout` ທີ່ເຫມາະສົມສໍາລັບການຖືຄ່າຂອງປະເພດ `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SAFETY: align ໄດ້ຖືກຮັບປະກັນໂດຍ Rust ຈະພະລັງງານຂອງສອງແລະ
        // ຂະຫນາດ + align ໄດ້ເລື່ອນການຮັບປະກັນໃຫ້ພໍດີກັບພື້ນທີ່ທີ່ຢູ່ຂອງພວກເຮົາ.
        // ດ້ວຍເຫດນີ້, ໃຫ້ໃຊ້ຜູ້ກໍ່ສ້າງທີ່ບໍ່ໄດ້ກວດກາຢູ່ນີ້ເພື່ອຫລີກລ້ຽງການໃສ່ລະຫັດທີ່ panics ຖ້າມັນບໍ່ໄດ້ຖືກປັບປຸງໃຫ້ດີພໍ.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ຜະລິດແບບແຜນທີ່ອະທິບາຍບັນທຶກທີ່ສາມາດ ນຳ ໃຊ້ເພື່ອຈັດສັນໂຄງສ້າງຫລັງ ສຳ ລັບ `T` (ເຊິ່ງອາດຈະເປັນ trait ຫຼືປະເພດທີ່ບໍ່ໄດ້ຮັບການຢັ້ງຢືນອື່ນໆເຊັ່ນ: ແຜ່ນບາງໆ).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // ຄວາມປອດໄພ: ເບິ່ງເຫດຜົນໃນ `new` ສຳ ລັບເຫດຜົນທີ່ວ່າການ ນຳ ໃຊ້ຕົວແປທີ່ບໍ່ປອດໄພ
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ຜະລິດແບບແຜນທີ່ອະທິບາຍບັນທຶກທີ່ສາມາດ ນຳ ໃຊ້ເພື່ອຈັດສັນໂຄງສ້າງຫລັງ ສຳ ລັບ `T` (ເຊິ່ງອາດຈະເປັນ trait ຫຼືປະເພດທີ່ບໍ່ໄດ້ຮັບການຢັ້ງຢືນອື່ນໆເຊັ່ນ: ແຜ່ນບາງໆ).
    ///
    /// # Safety
    ///
    /// ຟັງຊັນນີ້ຈະປອດໄພໃນການໂທຫາຖ້າສະພາບດັ່ງຕໍ່ໄປນີ້:
    ///
    /// - ຖ້າ `T` ແມ່ນ `Sized`, ການເຮັດວຽກນີ້ຈະປອດໄພໃນການໂທຫາ.
    /// - ຖ້າຫາງ unsized ຂອງ `T` ແມ່ນ:
    ///     - a [slice], ຫຼັງຈາກນັ້ນຄວາມຍາວຂອງຫາງສ່ວນຕົວຕ້ອງເປັນຕົວເລກເຕັມຕົວ, ແລະຂະ ໜາດ ຂອງ *ຄ່າທັງ ໝົດ*(ຄວາມຍາວຂອງຫາງແບບເຄື່ອນໄຫວ + ຄຳ ນຳ ໜ້າ ຂະ ໜາດ ຕາມສະຖິຕິ) ຕ້ອງ ເໝາະ ສົມກັບ `isize`.
    ///     - a [trait object], ຫຼັງຈາກນັ້ນສ່ວນ vtable ຂອງ pointer ຕ້ອງຊີ້ໃຫ້ເຫັນ vtable ທີ່ຖືກຕ້ອງ ສຳ ລັບຊະນິດ `T` ທີ່ໄດ້ມາໂດຍການບີບບັງຄັບທີ່ບໍ່ແນ່ນອນ, ແລະຂະ ໜາດ ຂອງ *ຄ່າທັງ ໝົດ*(ຄວາມຍາວຂອງຫາງແບບເຄື່ອນໄຫວ + ຄຳ ນຳ ໜ້າ ຂະ ໜາດ) ຕ້ອງ ເໝາະ ສົມກັບ `isize`.
    ///
    ///     - (unstable) [extern type], ຫຼັງຈາກນັ້ນຟັງຊັນນີ້ຈະປອດໄພໃນການໂທ, ແຕ່ panic ອາດຈະສົ່ງຄືນຄ່າທີ່ບໍ່ຖືກຕ້ອງ, ຍ້ອນວ່າຮູບແບບຂອງປະເພດພາຍນອກບໍ່ຮູ້.
    ///     ນີ້ແມ່ນພຶດຕິ ກຳ ດຽວກັນກັບ [`Layout::for_value`] ໂດຍອ້າງອີງໃສ່ຫາງປະເພດພາຍນອກ.
    ///     - ຖ້າບໍ່ດັ່ງນັ້ນ, ມັນບໍ່ໄດ້ຖືກອະນຸຍາດໃຫ້ເອີ້ນຟັງຊັນນີ້.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SAFETY: ພວກເຮົາຜ່ານຕາມກໍາຫນົດເບື້ອງຕົ້ນຂອງການເຮັດວຽກເຫຼົ່ານີ້ເພື່ອແປໄດ້ທຸໄດ້
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // ຄວາມປອດໄພ: ເບິ່ງເຫດຜົນໃນ `new` ສຳ ລັບເຫດຜົນທີ່ວ່າການ ນຳ ໃຊ້ຕົວແປທີ່ບໍ່ປອດໄພ
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ສ້າງ `NonNull` ທີ່ຫ້ອຍ, ແຕ່ມີຄວາມສອດຄ່ອງດີ ສຳ ລັບ Layout ນີ້.
    ///
    /// ໃຫ້ສັງເກດວ່າມູນຄ່າຕົວຊີ້ອາດຈະເປັນຕົວແທນຂອງຕົວຊີ້ຖືກຕ້ອງ, ຊຶ່ງຫມາຍຄວາມວ່າຕ້ອງນີ້ບໍ່ໄດ້ຮັບການນໍາໃຊ້ເປັນມູນຄ່າເປັນ "not yet initialized" sentinel.
    /// ປະເພດທີ່ຂີ້ກຽດຈັດສັນຕ້ອງຕິດຕາມການເລີ່ມຕົ້ນໂດຍວິທີອື່ນ.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // ຄວາມປອດໄພ: ການຈັດລຽນຖືກຮັບປະກັນບໍ່ແມ່ນສູນ
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// ສ້າງຮູບແບບທີ່ອະທິບາຍບັນທຶກທີ່ສາມາດຮັກສາມູນຄ່າຂອງຮູບແບບດຽວກັນກັບ `self`, ແຕ່ວ່າມັນຍັງສອດຄ່ອງກັບຄວາມສອດຄ່ອງ `align` (ວັດແທກເປັນ bytes).
    ///
    ///
    /// ຖ້າ `self` ຕອບສະ ໜອງ ຕາມຄວາມສອດຄ່ອງທີ່ໄດ້ ກຳ ນົດໄວ້ແລ້ວ, ແລ້ວກໍ່ສົ່ງຄືນ `self`.
    ///
    /// ໃຫ້ສັງເກດວ່າວິທີການນີ້ບໍ່ໄດ້ເພີ່ມແຜ່ນຮອງໃດໆໃສ່ຂະ ໜາດ ລວມ, ບໍ່ວ່າຮູບແບບທີ່ສົ່ງຄືນຈະມີຄວາມສອດຄ່ອງແຕກຕ່າງກັນ.
    /// ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ຖ້າຫາກວ່າ `K` ມີຂະຫນາດ 16, `K.align_to(32)` ຈະ *ຍັງ* ມີຂະຫນາດ 16.
    ///
    /// ສົ່ງຄືນຂໍ້ຜິດພາດຖ້າການປະສົມປະສານຂອງ `self.size()` ແລະ `align` ທີ່ລະເມີດເງື່ອນໄຂທີ່ລະບຸໄວ້ໃນ [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// ສົ່ງຄືນ ຈຳ ນວນແຜ່ນທີ່ພວກເຮົາຕ້ອງໃສ່ຫຼັງ `self` ເພື່ອຮັບປະກັນວ່າທີ່ຢູ່ຕໍ່ໄປນີ້ຈະພໍໃຈກັບ `align` (ວັດແທກເປັນໄບ).
    ///
    /// ຕົວຢ່າງ: ຖ້າ `self.size()` ແມ່ນ 9, ຫຼັງຈາກນັ້ນ `self.padding_needed_for(4)` ກັບຄືນ 3, ເພາະວ່ານັ້ນແມ່ນ ຈຳ ນວນຕ່ ຳ ສຸດຂອງໄບຕ໌ທີ່ ຈຳ ເປັນຕ້ອງໄດ້ຮັບທີ່ຢູ່ 4 ແຖວ (ສົມມຸດວ່າທ່ອນຄວາມຊົງ ຈຳ ທີ່ສອດຄ້ອງກັນເລີ່ມຈາກທີ່ຢູ່ 4-aligned).
    ///
    ///
    /// ຄ່າຕອບແທນຂອງການທໍາງານນີ້ບໍ່ມີຄວາມຫມາຍຖ້າຫາກວ່າ `align` ບໍ່ແມ່ນພະລັງງານຂອງສອງ.
    ///
    /// ໃຫ້ສັງເກດວ່າຜົນປະໂຫຍດຂອງມູນຄ່າທີ່ຖືກສົ່ງຄືນຮຽກຮ້ອງໃຫ້ `align` ນ້ອຍກວ່າຫລືເທົ່າກັບການຈັດຕໍາ ແໜ່ງ ທີ່ຢູ່ເລີ່ມຕົ້ນ ສຳ ລັບບລັອກທີ່ຖືກຈັດສັນທັງ ໝົດ.ວິທີການຫນຶ່ງເພື່ອຕອບສະຫນອງຂໍ້ຈໍາກັດນີ້ແມ່ນເພື່ອໃຫ້ແນ່ໃຈວ່າ `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // ມູນຄ່າຮອບແມ່ນ:
        //   len_rounded_up=(len + align, 1)&! (ສອດຄ່ອງ, 1);
        // ແລະຫຼັງຈາກນັ້ນພວກເຮົາສົ່ງຄືນຄວາມແຕກຕ່າງ: `len_rounded_up - len`.
        //
        // ພວກເຮົາໃຊ້ເລກຄະນິດສາດທົ່ວໄປ:
        //
        // 1. align ແມ່ນການຮັບປະກັນທີ່ຈະ> 0, ສະນັ້ນ align, 1 ເປັນສະເຫມີໄປທີ່ຖືກຕ້ອງ.
        //
        // 2.
        // `len + align - 1` ສາມາດ overflow ໂດຍສ່ວນໃຫຍ່ `align - 1`, ດັ່ງນັ້ນ,&-mask ກັບ `!(align - 1)` ຈະຮັບປະກັນວ່າໃນກໍລະນີທີ່ລົ້ນ, `len_rounded_up` ຕົວມັນເອງຈະເປັນ 0.
        //
        //    ດັ່ງນັ້ນແຜ່ນຮອງທີ່ສົ່ງຄືນ, ເມື່ອເພີ່ມໃສ່ `len`, ຜົນຜະລິດ 0, ເຊິ່ງພໍໃຈກັບຄວາມສອດຄ່ອງຂອງ `align`.
        //
        // (ແນ່ນອນ, ພະຍາຍາມທີ່ຈະຈັດສັນບລັອກຫນ່ວຍຄວາມຈໍາທີ່ຂະຫນາດແລະ padding overflow ໃນລັກສະນະຂ້າງເທິງນີ້ສາມາດເຮັດໃຫ້ຕົວຈັດສັນໃຫ້ຜົນຜະລິດຄວາມຜິດພາດແລ້ວ.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// ສ້າງຮູບແບບໂດຍການລວບລວມຂະ ໜາດ ຂອງຮູບແບບນີ້ຈົນເຖິງການຈັດລຽນແບບຫຼາຍຮູບແບບຂອງຮູບແບບ.
    ///
    ///
    /// ນີ້ເທົ່າກັບການເພີ່ມຜົນຂອງ `padding_needed_for` ໃສ່ຂະ ໜາດ ຂອງຮູບແບບໃນປະຈຸບັນ.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // ນີ້ບໍ່ສາມາດ overflow.ການອ້າງອີງຈາກການສະແດງຂອງ Layout:
        // > `size`, ເມື່ອມົນເຖິງຫລາຍໆອັນທີ່ໃກ້ທີ່ສຸດຂອງ `align`,
        // > ຕ້ອງບໍ່ overflow (ie, ມູນຄ່າມົນຕ້ອງຫນ້ອຍກ່ວາ
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// ສ້າງແບບແຜນທີ່ອະທິບາຍບັນທຶກ ສຳ ລັບຕົວຢ່າງ `n` ຂອງ `self`, ດ້ວຍ ຈຳ ນວນຊຸດທີ່ ເໝາະ ສົມລະຫວ່າງແຕ່ລະອັນເພື່ອໃຫ້ແນ່ໃຈວ່າແຕ່ລະຕົວຢ່າງແມ່ນໃຫ້ຂະ ໜາດ ແລະຄວາມສອດຄ່ອງຂອງມັນ.
    /// ໃນຄວາມສໍາເລັດຜົນໄດ້ຮັບ `(k, offs)` ທີ່ `k` ແມ່ນຮູບລັກຂອງ array ແລະ `offs` ແມ່ນໄລຍະຫ່າງລະຫວ່າງການເລີ່ມຕົ້ນຂອງອົງປະກອບໃນອາເລແຕ່ລະຄົນ.
    ///
    /// ກ່ຽວກັບການລົ້ນເລກຄະນິດສາດ, ສົ່ງຄືນ `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // ນີ້ບໍ່ສາມາດ overflow.ການອ້າງອີງຈາກການສະແດງຂອງ Layout:
        // > `size`, ເມື່ອມົນເຖິງຫລາຍໆອັນທີ່ໃກ້ທີ່ສຸດຂອງ `align`,
        // > ຕ້ອງບໍ່ overflow (ie, ມູນຄ່າມົນຕ້ອງຫນ້ອຍກ່ວາ
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SAFETY: self.align ເປັນທີ່ຮູ້ຈັກແລ້ວຈະຖືກຕ້ອງແລະ alloc_size ໄດ້
        // padded ແລ້ວ.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// ສ້າງແບບແຜນທີ່ອະທິບາຍບັນທຶກ ສຳ ລັບ `self` ຕາມດ້ວຍ `next`, ລວມທັງແຜ່ນຮອງທີ່ ຈຳ ເປັນເພື່ອຮັບປະກັນວ່າ `next` ຈະມີຄວາມສອດຄ່ອງຢ່າງຖືກຕ້ອງ, ແຕ່ *ບໍ່ມີແຜ່ນຮອງ*.
    ///
    /// ໃນຄໍາສັ່ງທີ່ຈະມີຄໍາວ່າການເປັນຕົວແທນ C ຮູບລັກ `repr(C)`, ທ່ານຄວນໂທຫາ `pad_to_align` ຫຼັງຈາກການຂະຫຍາຍຮູບແບບທີ່ມີຂົງເຂດທັງຫມົດ.
    /// (ບໍ່ມີວິທີໃດທີ່ຈະກົງກັບຮູບແບບການເປັນຕົວແທນຂອງ Rust ໃນຕອນຕົ້ນ `repr(Rust)`, as it is unspecified.)
    ///
    /// ໃຫ້ສັງເກດວ່າການຈັດຕໍາແຫນ່ງຂອງຮູບລັກທີ່ໄດ້ຮັບການຈະສູງສຸດໃນບັນດາ `self` ແລະ `next`, ໃນຄໍາສັ່ງເພື່ອຮັບປະກັນຄວາມສອດຄ່ອງຂອງທັງສອງພາກສ່ວນ.
    ///
    /// ຜົນຕອບແທນ `Ok((k, offset))`, ບ່ອນທີ່ `k` ແມ່ນຮູບແບບຂອງການບັນທຶກຕັດແບ່ງແລະ `offset` ແມ່ນສະຖານທີ່ພີ່ນ້ອງ, ໃນໄບຂອງການເລີ່ມຕົ້ນຂອງ `next` ທີ່ຝັງຢູ່ພາຍໃນບັນທຶກຕັດແບ່ງ (ສົມມະຕິວ່າການບັນທຶກຕົວຂອງມັນເອງເລີ່ມຕົ້ນທີ່ຊົດເຊີຍ 0).
    ///
    ///
    /// ກ່ຽວກັບການລົ້ນເລກຄະນິດສາດ, ສົ່ງຄືນ `LayoutError`.
    ///
    /// # Examples
    ///
    /// ການຄິດໄລ່ຮູບແບບຂອງໂຄງສ້າງ `#[repr(C)]` ແລະຊົດເຊີຍຂອງເຂດຂໍ້ມູນຈາກຮູບແບບທົ່ງນາຂອງຕົນ 'ໄດ້:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // ຈື່ໄວ້ວ່າຈະເຮັດສຸດທ້າຍກັບ `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // ທົດສອບວ່າມັນເຮັດວຽກໄດ້ແນວໃດ
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// ສ້າງແບບແຜນທີ່ອະທິບາຍບັນທຶກ ສຳ ລັບຕົວຢ່າງ `n` ຂອງ `self`, ໂດຍບໍ່ມີການຕິດຢູ່ລະຫວ່າງຕົວຢ່າງ.
    ///
    /// ໃຫ້ສັງເກດວ່າ, ບໍ່ຄືກັບ `repeat`, `repeat_packed` ບໍ່ໄດ້ຮັບປະກັນວ່າກໍລະນີທີ່ຊ້ ຳ ຊ້ອນຂອງ `self` ຈະຖືກ ນຳ ໃຊ້ຢ່າງຖືກຕ້ອງ, ເຖິງແມ່ນວ່າຕົວຢ່າງ `self` ຈະຖືກຈັດຮຽງຢ່າງຖືກຕ້ອງ.
    /// ເວົ້າອີກຢ່າງ ໜຶ່ງ, ຖ້າຮູບແບບທີ່ສົ່ງຄືນໂດຍ `repeat_packed` ຖືກໃຊ້ເພື່ອຈັດສັນອາເລ, ມັນບໍ່ໄດ້ຮັບປະກັນວ່າທຸກໆອົງປະກອບທີ່ຢູ່ໃນຂບວນຈະຖືກຈັດໃຫ້ຖືກຕ້ອງ.
    ///
    /// ກ່ຽວກັບການລົ້ນເລກຄະນິດສາດ, ສົ່ງຄືນ `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// ສ້າງເປັນຮູບແບບທີ່ອະທິບາຍບັນທຶກການ `self` ຕາມດ້ວຍ `next` ບໍ່ມີ padding ເພີ່ມເຕີມລະຫວ່າງທັງສອງ.
    /// ເນື່ອງຈາກວ່າບໍ່ມີການຕິດແຜ່ນຮອງ, ການຈັດລຽນຂອງ `next` ແມ່ນບໍ່ມີຄວາມກ່ຽວຂ້ອງ, ແລະບໍ່ໄດ້ລວມເຂົ້າກັນ *ຢູ່ທັງ ໝົດ* ເຂົ້າໃນຮູບແບບຜົນທີ່ໄດ້ຮັບ.
    ///
    ///
    /// ກ່ຽວກັບການລົ້ນເລກຄະນິດສາດ, ສົ່ງຄືນ `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// ສ້າງຮູບແບບທີ່ອະທິບາຍບັນທຶກ ສຳ ລັບ `[T; n]`.
    ///
    /// ກ່ຽວກັບການລົ້ນເລກຄະນິດສາດ, ສົ່ງຄືນ `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// ພາລາມິເຕີທີ່ມອບໃຫ້ແກ່ `Layout::from_size_align` ຫຼືຜູ້ກໍ່ສ້າງ `Layout` ບາງອື່ນໆກໍ່ບໍ່ພໍໃຈກັບຂໍ້ ຈຳ ກັດດ້ານເອກະສານ.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ພວກເຮົາຕ້ອງການນີ້ສໍາລັບ impl ເຂດລຸ່ມເຮືອນຈັກ Error trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}