//! API ການຈັດສັນຄວາມ ຈຳ

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// ຂໍ້ຜິດພາດ `AllocError` ສະແດງໃຫ້ເຫັນເຖິງຄວາມລົ້ມເຫຼວຂອງການຈັດສັນທີ່ອາດຈະເປັນຍ້ອນການສິ້ນເປືອງຊັບພະຍາກອນຫຼືບາງສິ່ງບາງຢ່າງທີ່ຜິດພາດເມື່ອສົມທົບການໂຕ້ຖຽງການປ້ອນຂໍ້ມູນທີ່ມີໃຫ້ກັບຜູ້ຈັດສັນນີ້.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (ພວກເຮົາຕ້ອງການນີ້ສໍາລັບ impl ເຂດລຸ່ມເຮືອນຈັກ Error trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// ການຈັດຕັ້ງປະຕິບັດ `Allocator` ສາມາດຈັດສັນ, ຂະຫຍາຍ, ຫົດຕົວ, ແລະຈັດການກັບຂໍ້ມູນທີ່ມີຂໍ້ມູນທີ່ອະທິບາຍຜ່ານ [`Layout`][].
///
/// `Allocator` ຖືກອອກແບບມາເພື່ອຈັດຕັ້ງປະຕິບັດໃນ ZSTs, ເອກະສານອ້າງອີງ, ຫຼືຈຸດຊີ້ບອກທີ່ສະຫຼາດເພາະວ່າມີຜູ້ຈັດສັນເຊັ່ນ `MyAlloc([u8; N])` ບໍ່ສາມາດຍ້າຍໄດ້, ໂດຍບໍ່ຕ້ອງປັບປຸງຈຸດຊີ້ບອກເຖິງຄວາມຊົງ ຈຳ ທີ່ຖືກຈັດສັນ.
///
/// ບໍ່ເຫມືອນກັບ [`GlobalAlloc`][], ການຈັດສັນສູນຂະຫນາດອະນຸຍາດໃຫ້ໃນ `Allocator`.
/// ຖ້າຜູ້ຈັດສັນພື້ນຖານບໍ່ສະ ໜັບ ສະ ໜູນ ສິ່ງນີ້ (ຄືກັບ jemalloc) ຫຼືສົ່ງກັບຕົວຊີ້ທີ່ບໍ່ຖືກຕ້ອງ (ເຊັ່ນ `libc::malloc`), ສິ່ງນີ້ຕ້ອງຖືກຈັບໂດຍການຈັດຕັ້ງປະຕິບັດ.
///
/// ### ປະຈຸບັນຈັດສັນຄວາມຊົງ ຈຳ
///
/// ບາງວິທີການຮຽກຮ້ອງໃຫ້ມີການຈັດສັນຄວາມ ຈຳ *ໃນປັດຈຸບັນ* ຜ່ານຜູ້ຈັດສັນ.ໝາຍ ຄວາມວ່າ:
///
/// * ທີ່ຢູ່ເລີ່ມຕົ້ນສໍາລັບການ block ຄວາມຊົງຈໍາທີ່ໄດ້ກັບຄືນມາໂດຍ [`allocate`], [`grow`] ຫລື [`shrink`] ແລະ
///
/// * ທ່ອນຫນ່ວຍຄວາມ ຈຳ ບໍ່ໄດ້ຖືກຈັດສັນຕໍ່ມາ, ບ່ອນທີ່ທ່ອນໄມ້ຈະຖືກຈັດການໂດຍກົງໂດຍການສົ່ງຜ່ານ [`deallocate`] ຫຼືຖືກປ່ຽນໂດຍການສົ່ງຜ່ານ [`grow`] ຫຼື [`shrink`] ທີ່ສົ່ງຄືນ `Ok`.
///
/// ຖ້າ `grow` ຫຼື `shrink` ໄດ້ສົ່ງ `Err` ຄືນ, ຕົວຊີ້ທີ່ຜ່ານໄປຍັງຄົງຖືກຕ້ອງ.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### ຄວາມ ຈຳ ເໝາະ ສົມ
///
/// ບາງສ່ວນຂອງວິທີການໄດ້ຮຽກຮ້ອງໃຫ້ຮູບແບບການເຫມາະ * * a block ຄວາມຊົງຈໍາ.
/// ມັນ ໝາຍ ຄວາມວ່າແນວໃດ ສຳ ລັບການຈັດຮູບແບບໃຫ້ "fit" ທ່ອນຄວາມ ຈຳ ໝາຍ ຄວາມວ່າ (ຫລືທຽບເທົ່າ ສຳ ລັບທ່ອນ ໜ່ວຍ ຄວາມ ຈຳ ເພື່ອ "fit" ຮູບແບບ ໜຶ່ງ) ແມ່ນວ່າເງື່ອນໄຂຕໍ່ໄປນີ້ຕ້ອງມີ:
///
/// * ທ່ອນໄມ້ຕ້ອງໄດ້ຮັບການຈັດສັນທີ່ມີຄວາມສອດຄ່ອງຄືກັນກັບ [`layout.align()`], ແລະ
///
/// * [`layout.size()`] ທີ່ສະ ໜອງ ໃຫ້ຕ້ອງຕົກຢູ່ໃນຊ່ວງ `min ..= max`, ບ່ອນທີ່:
///   - `min` ແມ່ນຂະຫນາດຂອງຮູບລັກໄດ້ຖືກນໍາໃຊ້ຫຼາຍທີ່ສຸດບໍ່ດົນມານີ້ໃນການຈັດສັນຕັນໄດ້, ແລະ
///   - `max` ແມ່ນຂະຫນາດທີ່ແທ້ຈິງຫລ້າສຸດກັບຄືນຈາກ [`allocate`], [`grow`] ຫລື [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * ທ່ອນຄວາມຊົງ ຈຳ ທີ່ສົ່ງກັບຈາກຜູ້ຈັດສັນຕ້ອງຊີ້ໄປທີ່ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ຖືກຕ້ອງແລະຮັກສາຄວາມຖືກຕ້ອງຂອງມັນຈົນກ່ວາຕົວຢ່າງແລະທັງ ໝົດ ຂອງໂຄນຂອງມັນຖືກລຸດລົງ
///
/// * cloning ຫຼືຍ້າຍການຈັດສັນບໍ່ຕ້ອງເຮັດໃຫ້ຄວາມຊົງຈໍາທີ່ບໍ່ຖືກຕ້ອງກັບມາຈາກຜູ້ຈັດສັນນີ້.ຜູ້ຈັດສັນ cloned ຕ້ອງປະຕິບັດຕົວຄືກັບຜູ້ຈັດສັນດຽວກັນ, ແລະ
///
/// * ຊີ້ໃດກັບ block ຫນ່ວຍຄວາມຈໍາຊຶ່ງເປັນ [*currently allocated*] ຈະຖືກຖ່າຍທອດວິທີການອື່ນໆຂອງຕົວຈັດສັນໄດ້.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// ຄວາມພະຍາຍາມໃນການຈັດສັນທ່ອນໄມ້ຂອງຄວາມຊົງຈໍາ.
    ///
    /// ໃນຄວາມ ສຳ ເລັດ, ໃຫ້ກັບຄືນ [`NonNull<[u8]>`][NonNull] ໃນການຮັບປະກັນຂະ ໜາດ ແລະຄວາມສອດຄ່ອງຂອງ `layout`.
    ///
    /// ການລະງັບການກັບຄືນອາດຈະມີຂະຫນາດຂະຫນາດໃຫຍ່ກ່ວາກໍານົດໄວ້ໂດຍ `layout.size()`, ແລະອາດຈະມີຫຼືອາດຈະບໍ່ມີເນື້ອໃນຂອງຕົນເລີ່ມຕົ້ນ.
    ///
    /// # Errors
    ///
    /// ກັບຄືນ `Err` ຊີ້ໃຫ້ເຫັນວ່າຄວາມຊົງຈໍາບໍ່ວ່າຈະເປັນຫມົດຫຼື `layout` ບໍ່ຕອບສະຫນອງຂະຫນາດຫຼືການຈັດຕໍາແຫນ່ງຕົວຈັດສັນຂອງຈໍາກັດ.
    ///
    /// ການປະຕິບັດໄດ້ຖືກຊຸກຍູ້ໃຫ້ກັບຄືນ `Err` ສະຫາຍຫນ່ວຍຄວາມຈໍາແທນທີ່ຈະກ່ວາການ panicking ຫຼື aborting, ແຕ່ນີ້ບໍ່ແມ່ນຂໍ້ກໍານົດທີ່ເຂັ້ມງວດ.
    /// (ໂດຍສະເພາະ: ມັນເປັນ * * ກົດຫມາຍທີ່ຈະໃຊ້ trait ນີ້ເທິງຍອດການຫໍສະຫມຸດຈັດສັນຕິດພັນພື້ນເມືອງທີ່ສໍາເລັດສະຫາຍຄວາມຊົງຈໍາ.)
    ///
    /// ລູກຄ້າທີ່ຕ້ອງການຍົກເລີກການ ຄຳ ນວນໃນການຕອບສະ ໜອງ ຕໍ່ຂໍ້ຜິດພາດຂອງການຈັດສັນໄດ້ຖືກຊຸກຍູ້ໃຫ້ໂທຫາຟັງຊັນ [`handle_alloc_error`], ແທນທີ່ຈະຮຽກຮ້ອງໂດຍກົງ `panic!` ຫຼືຄ້າຍຄືກັນ.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// ພຶດຕິ ກຳ ຄືກັບ `allocate`, ແຕ່ຍັງຮັບປະກັນວ່າຄວາມຊົງ ຈຳ ທີ່ກັບມາແມ່ນສູນໃນເບື້ອງຕົ້ນ.
    ///
    /// # Errors
    ///
    /// ກັບຄືນ `Err` ຊີ້ໃຫ້ເຫັນວ່າຄວາມຊົງຈໍາບໍ່ວ່າຈະເປັນຫມົດຫຼື `layout` ບໍ່ຕອບສະຫນອງຂະຫນາດຫຼືການຈັດຕໍາແຫນ່ງຕົວຈັດສັນຂອງຈໍາກັດ.
    ///
    /// ການປະຕິບັດໄດ້ຖືກຊຸກຍູ້ໃຫ້ກັບຄືນ `Err` ສະຫາຍຫນ່ວຍຄວາມຈໍາແທນທີ່ຈະກ່ວາການ panicking ຫຼື aborting, ແຕ່ນີ້ບໍ່ແມ່ນຂໍ້ກໍານົດທີ່ເຂັ້ມງວດ.
    /// (ໂດຍສະເພາະ: ມັນເປັນ * * ກົດຫມາຍທີ່ຈະໃຊ້ trait ນີ້ເທິງຍອດການຫໍສະຫມຸດຈັດສັນຕິດພັນພື້ນເມືອງທີ່ສໍາເລັດສະຫາຍຄວາມຊົງຈໍາ.)
    ///
    /// ລູກຄ້າທີ່ຕ້ອງການຍົກເລີກການ ຄຳ ນວນໃນການຕອບສະ ໜອງ ຕໍ່ຂໍ້ຜິດພາດຂອງການຈັດສັນໄດ້ຖືກຊຸກຍູ້ໃຫ້ໂທຫາຟັງຊັນ [`handle_alloc_error`], ແທນທີ່ຈະຮຽກຮ້ອງໂດຍກົງ `panic!` ຫຼືຄ້າຍຄືກັນ.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // ຄວາມປອດໄພ: `alloc` ສົ່ງຄືນຂໍ້ມູນຄວາມ ຈຳ ທີ່ຖືກຕ້ອງ
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// ຈຳ ໜ່າຍ ຄວາມ ຈຳ ທີ່ອ້າງອີງໂດຍ `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` ຕ້ອງ ໝາຍ ເຖິງ [*currently allocated*] X ທີ່ມີຄວາມ ຈຳ ໂດຍຜ່ານຜູ້ຈັດສັນນີ້, ແລະ
    /// * `layout` ຕ້ອງ [*fit*] ທີ່ທ່ອນໄມ້ຂອງຄວາມຊົງຈໍາ.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// ຄວາມພະຍາຍາມທີ່ຈະຂະຫຍາຍ block ຫນ່ວຍຄວາມຈໍາໄດ້.
    ///
    /// ສົ່ງຄືນ [`NonNull<[u8]>`][NonNull] ລຸ້ນ ໃໝ່ ທີ່ມີຕົວຊີ້ແລະຂະ ໜາດ ຕົວຈິງຂອງ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ຈັດສັນໃຫ້.ຕົວຊີ້ແມ່ນ ເໝາະ ສົມ ສຳ ລັບການຖືຂໍ້ມູນທີ່ອະທິບາຍໂດຍ `new_layout`.
    /// ເພື່ອເຮັດສໍາເລັດດັ່ງກ່າວນີ້, ຈັດສັນທີ່ອາດຈະຂະຫຍາຍການຈັດສັນອ້າງອິງໂດຍ `ptr` ໃຫ້ພໍດີກັບຮູບແບບໃຫມ່.
    ///
    /// ຖ້າສິ່ງນີ້ກັບຄືນ `Ok`, ຫຼັງຈາກນັ້ນການເປັນເຈົ້າຂອງຂອງ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ອ້າງອີງໂດຍ `ptr` ໄດ້ຖືກໂອນໄປຫາຜູ້ຈັດສັນນີ້.
    /// ຫນ່ວຍຄວາມຈໍາສາມາດຫຼືອາດຈະບໍ່ໄດ້ຮັບການປົດປ່ອຍ, ແລະຄວນຈະໄດ້ຮັບພິຈາລະນາໃຊ້ເວັ້ນເສຍແຕ່ວ່າມັນໄດ້ຍົກຍ້າຍກັບຄືນໄປບ່ອນທີ່ຈະແປໄດ້ທຸໄດ້ອີກເທື່ອຫນຶ່ງໂດຍຜ່ານການຄ່າຕອບແທນຂອງວິທີການນີ້.
    ///
    /// ຖ້າວິທີການນີ້ກັບຄືນ `Err`, ຫຼັງຈາກນັ້ນການເປັນເຈົ້າຂອງບລັອກຫນ່ວຍຄວາມ ຈຳ ບໍ່ໄດ້ຖືກໂອນໄປຫາຜູ້ຈັດສັນນີ້, ແລະເນື້ອໃນຂອງບລັອກຄວາມ ຈຳ ບໍ່ໄດ້ຖືກປ່ຽນແປງ.
    ///
    /// # Safety
    ///
    /// * `ptr` ຕ້ອງຊີ້ block ຫນ່ວຍຄວາມຈໍາ [*currently allocated*] ທາງຈັດສັນນີ້.
    /// * `old_layout` ຕ້ອງ [*fit*] ທີ່ທ່ອນໄມ້ຂອງຄວາມຊົງຈໍາ (ການໂຕ້ຖຽງ `new_layout` ບໍ່ ຈຳ ເປັນຕ້ອງໃຊ້ມັນ.).
    /// * `new_layout.size()` ຕ້ອງຫຼາຍກ່ວາຫຼືເທົ່າກັບ `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// ກັບຄືນ `Err` ຖ້າຮູບແບບ ໃໝ່ ບໍ່ຕອບສະ ໜອງ ຂະ ໜາດ ແລະຂໍ້ ຈຳ ກັດຂອງຜູ້ຈັດສັນ, ຫຼືຖ້າການຂະຫຍາຍຕົວລົ້ມເຫຼວຖ້າບໍ່ດັ່ງນັ້ນ.
    ///
    /// ການປະຕິບັດໄດ້ຖືກຊຸກຍູ້ໃຫ້ກັບຄືນ `Err` ສະຫາຍຫນ່ວຍຄວາມຈໍາແທນທີ່ຈະກ່ວາການ panicking ຫຼື aborting, ແຕ່ນີ້ບໍ່ແມ່ນຂໍ້ກໍານົດທີ່ເຂັ້ມງວດ.
    /// (ໂດຍສະເພາະ: ມັນເປັນ * * ກົດຫມາຍທີ່ຈະໃຊ້ trait ນີ້ເທິງຍອດການຫໍສະຫມຸດຈັດສັນຕິດພັນພື້ນເມືອງທີ່ສໍາເລັດສະຫາຍຄວາມຊົງຈໍາ.)
    ///
    /// ລູກຄ້າທີ່ຕ້ອງການຍົກເລີກການ ຄຳ ນວນໃນການຕອບສະ ໜອງ ຕໍ່ຂໍ້ຜິດພາດຂອງການຈັດສັນໄດ້ຖືກຊຸກຍູ້ໃຫ້ໂທຫາຟັງຊັນ [`handle_alloc_error`], ແທນທີ່ຈະຮຽກຮ້ອງໂດຍກົງ `panic!` ຫຼືຄ້າຍຄືກັນ.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SAFETY: ເນື່ອງຈາກວ່າ `new_layout.size()` ຕ້ອງຫຼາຍກ່ວາຫຼືເທົ່າກັບ
        // `old_layout.size()`, ທັງການຈັດສັນຄວາມຊົງຈໍາເກົ່າແລະໃຫມ່ແມ່ນຖືກຕ້ອງສໍາລັບອ່ານແລະຂຽນສໍາລັບ `old_layout.size()` ໄບ.
        // ເຊັ່ນດຽວກັນ, ເພາະວ່າການຈັດສັນເກົ່າບໍ່ໄດ້ຮັບການຈັດສັນ, ມັນບໍ່ສາມາດຊໍ້າຊ້ອນ `new_ptr`.
        // ດັ່ງນັ້ນ, ການໂທຫາ `copy_nonoverlapping` ແມ່ນປອດໄພ.
        // ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `dealloc` ຕ້ອງໄດ້ຮັບການຮັກສາຈາກຜູ້ໂທ.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// ປະຕິບັດຕົວຄື `grow`, ແຕ່ຍັງຮັບປະກັນວ່າເນື້ອໃນໃຫມ່ແມ່ນກໍານົດໃຫ້ສູນກ່ອນທີ່ຈະຖືກສົ່ງກັບຄືນ.
    ///
    /// ທ່ອນຄວາມຊົງຈໍາຈະມີເນື້ອໃນຕໍ່ໄປນີ້ຫຼັງຈາກການໂທຫາທີ່ປະສົບຜົນ ສຳ ເລັດ
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` ຖືກຮັກສາໄວ້ຈາກການຈັດສັນເດີມ.
    ///   * Bytes `old_layout.size()..old_size` ຈະຖືກຮັກສາໄວ້ຫລືສູນ, ຂື້ນກັບການຈັດຕັ້ງປະຕິບັດການຈັດສັນ.
    ///   `old_size` ຫມາຍເຖິງຂະຫນາດຂອງຫນ່ວຍຄວາມຈໍາ block ໄດ້ກ່ອນທີ່ຈະໂທ `grow_zeroed`, ເຊິ່ງອາດຈະມີຂະຫນາດໃຫຍ່ກ່ວາຂະຫນາດທີ່ໄດ້ຖືກດັ້ງເດີມຮຽກຮ້ອງເວລາທີ່ມັນໄດ້ຈັດສັນ.
    ///   * Bytes `old_size..new_size` ກໍາລັງ zeroed.`new_size` ຫມາຍເຖິງຂະຫນາດຂອງຫນ່ວຍຄວາມຈໍາ block ທີ່ສົ່ງຄືນໂດຍການໂທ `grow_zeroed` ໄດ້.
    ///
    /// # Safety
    ///
    /// * `ptr` ຕ້ອງຊີ້ block ຫນ່ວຍຄວາມຈໍາ [*currently allocated*] ທາງຈັດສັນນີ້.
    /// * `old_layout` ຕ້ອງ [*fit*] ທີ່ທ່ອນໄມ້ຂອງຄວາມຊົງຈໍາ (ການໂຕ້ຖຽງ `new_layout` ບໍ່ ຈຳ ເປັນຕ້ອງໃຊ້ມັນ.).
    /// * `new_layout.size()` ຕ້ອງຫຼາຍກ່ວາຫຼືເທົ່າກັບ `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// ກັບຄືນ `Err` ຖ້າຮູບແບບ ໃໝ່ ບໍ່ຕອບສະ ໜອງ ຂະ ໜາດ ແລະຂໍ້ ຈຳ ກັດຂອງຜູ້ຈັດສັນ, ຫຼືຖ້າການຂະຫຍາຍຕົວລົ້ມເຫຼວຖ້າບໍ່ດັ່ງນັ້ນ.
    ///
    /// ການປະຕິບັດໄດ້ຖືກຊຸກຍູ້ໃຫ້ກັບຄືນ `Err` ສະຫາຍຫນ່ວຍຄວາມຈໍາແທນທີ່ຈະກ່ວາການ panicking ຫຼື aborting, ແຕ່ນີ້ບໍ່ແມ່ນຂໍ້ກໍານົດທີ່ເຂັ້ມງວດ.
    /// (ໂດຍສະເພາະ: ມັນເປັນ * * ກົດຫມາຍທີ່ຈະໃຊ້ trait ນີ້ເທິງຍອດການຫໍສະຫມຸດຈັດສັນຕິດພັນພື້ນເມືອງທີ່ສໍາເລັດສະຫາຍຄວາມຊົງຈໍາ.)
    ///
    /// ລູກຄ້າທີ່ຕ້ອງການຍົກເລີກການ ຄຳ ນວນໃນການຕອບສະ ໜອງ ຕໍ່ຂໍ້ຜິດພາດຂອງການຈັດສັນໄດ້ຖືກຊຸກຍູ້ໃຫ້ໂທຫາຟັງຊັນ [`handle_alloc_error`], ແທນທີ່ຈະຮຽກຮ້ອງໂດຍກົງ `panic!` ຫຼືຄ້າຍຄືກັນ.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SAFETY: ເນື່ອງຈາກວ່າ `new_layout.size()` ຕ້ອງຫຼາຍກ່ວາຫຼືເທົ່າກັບ
        // `old_layout.size()`, ທັງການຈັດສັນຄວາມຊົງຈໍາເກົ່າແລະໃຫມ່ແມ່ນຖືກຕ້ອງສໍາລັບອ່ານແລະຂຽນສໍາລັບ `old_layout.size()` ໄບ.
        // ເຊັ່ນດຽວກັນ, ເພາະວ່າການຈັດສັນເກົ່າບໍ່ໄດ້ຮັບການຈັດສັນ, ມັນບໍ່ສາມາດຊໍ້າຊ້ອນ `new_ptr`.
        // ດັ່ງນັ້ນ, ການໂທຫາ `copy_nonoverlapping` ແມ່ນປອດໄພ.
        // ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `dealloc` ຕ້ອງໄດ້ຮັບການຮັກສາຈາກຜູ້ໂທ.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// ຄວາມພະຍາຍາມທີ່ຈະນ້ອຍລົງຕັນຄວາມຊົງຈໍາ.
    ///
    /// ສົ່ງຄືນ [`NonNull<[u8]>`][NonNull] ລຸ້ນ ໃໝ່ ທີ່ມີຕົວຊີ້ແລະຂະ ໜາດ ຕົວຈິງຂອງ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ຈັດສັນໃຫ້.ຕົວຊີ້ແມ່ນ ເໝາະ ສົມ ສຳ ລັບການຖືຂໍ້ມູນທີ່ອະທິບາຍໂດຍ `new_layout`.
    /// ເພື່ອເຮັດສໍາເລັດດັ່ງກ່າວນີ້, ຈັດສັນອາດຫົດຈັດສັນໃຫ້ແຍກຕາມ `ptr` ໃຫ້ພໍດີກັບຮູບແບບໃຫມ່.
    ///
    /// ຖ້າສິ່ງນີ້ກັບຄືນ `Ok`, ຫຼັງຈາກນັ້ນການເປັນເຈົ້າຂອງຂອງ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ອ້າງອີງໂດຍ `ptr` ໄດ້ຖືກໂອນໄປຫາຜູ້ຈັດສັນນີ້.
    /// ຫນ່ວຍຄວາມຈໍາສາມາດຫຼືອາດຈະບໍ່ໄດ້ຮັບການປົດປ່ອຍ, ແລະຄວນຈະໄດ້ຮັບພິຈາລະນາໃຊ້ເວັ້ນເສຍແຕ່ວ່າມັນໄດ້ຍົກຍ້າຍກັບຄືນໄປບ່ອນທີ່ຈະແປໄດ້ທຸໄດ້ອີກເທື່ອຫນຶ່ງໂດຍຜ່ານການຄ່າຕອບແທນຂອງວິທີການນີ້.
    ///
    /// ຖ້າວິທີການນີ້ກັບຄືນ `Err`, ຫຼັງຈາກນັ້ນການເປັນເຈົ້າຂອງບລັອກຫນ່ວຍຄວາມ ຈຳ ບໍ່ໄດ້ຖືກໂອນໄປຫາຜູ້ຈັດສັນນີ້, ແລະເນື້ອໃນຂອງບລັອກຄວາມ ຈຳ ບໍ່ໄດ້ຖືກປ່ຽນແປງ.
    ///
    /// # Safety
    ///
    /// * `ptr` ຕ້ອງຊີ້ block ຫນ່ວຍຄວາມຈໍາ [*currently allocated*] ທາງຈັດສັນນີ້.
    /// * `old_layout` ຕ້ອງ [*fit*] ທີ່ທ່ອນໄມ້ຂອງຄວາມຊົງຈໍາ (ການໂຕ້ຖຽງ `new_layout` ບໍ່ ຈຳ ເປັນຕ້ອງໃຊ້ມັນ.).
    /// * `new_layout.size()` ຕ້ອງນ້ອຍກວ່າຫລືເທົ່າກັບ `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// ກັບຄືນ `Err` ຖ້າຮູບແບບ ໃໝ່ ບໍ່ກົງກັບຂະ ໜາດ ຂອງຜູ້ຈັດສັນແລະຂໍ້ ຈຳ ກັດຂອງຜູ້ຈັດສັນຫຼືຖ້າການຫົດຕົວກໍ່ລົ້ມເຫລວບໍ່ໄດ້.
    ///
    /// ການປະຕິບັດໄດ້ຖືກຊຸກຍູ້ໃຫ້ກັບຄືນ `Err` ສະຫາຍຫນ່ວຍຄວາມຈໍາແທນທີ່ຈະກ່ວາການ panicking ຫຼື aborting, ແຕ່ນີ້ບໍ່ແມ່ນຂໍ້ກໍານົດທີ່ເຂັ້ມງວດ.
    /// (ໂດຍສະເພາະ: ມັນເປັນ * * ກົດຫມາຍທີ່ຈະໃຊ້ trait ນີ້ເທິງຍອດການຫໍສະຫມຸດຈັດສັນຕິດພັນພື້ນເມືອງທີ່ສໍາເລັດສະຫາຍຄວາມຊົງຈໍາ.)
    ///
    /// ລູກຄ້າທີ່ຕ້ອງການຍົກເລີກການ ຄຳ ນວນໃນການຕອບສະ ໜອງ ຕໍ່ຂໍ້ຜິດພາດຂອງການຈັດສັນໄດ້ຖືກຊຸກຍູ້ໃຫ້ໂທຫາຟັງຊັນ [`handle_alloc_error`], ແທນທີ່ຈະຮຽກຮ້ອງໂດຍກົງ `panic!` ຫຼືຄ້າຍຄືກັນ.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ຄວາມປອດໄພ: ເພາະວ່າ `new_layout.size()` ຕ້ອງຕ່ ຳ ກວ່າຫຼືເທົ່າກັບ
        // `old_layout.size()`, ທັງການຈັດສັນຄວາມຊົງຈໍາເກົ່າແລະໃຫມ່ແມ່ນຖືກຕ້ອງສໍາລັບອ່ານແລະຂຽນສໍາລັບ `new_layout.size()` ໄບ.
        // ເຊັ່ນດຽວກັນ, ເພາະວ່າການຈັດສັນເກົ່າບໍ່ໄດ້ຮັບການຈັດສັນ, ມັນບໍ່ສາມາດຊໍ້າຊ້ອນ `new_ptr`.
        // ດັ່ງນັ້ນ, ການໂທຫາ `copy_nonoverlapping` ແມ່ນປອດໄພ.
        // ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `dealloc` ຕ້ອງໄດ້ຮັບການຮັກສາຈາກຜູ້ໂທ.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// ສ້າງຕົວອະແດບເຕີ "by reference" ສຳ ລັບຕົວຢ່າງ `Allocator` ນີ້.
    ///
    /// ຂອງຜູ້ດັດແປງຄືນຍັງປະຕິບັດ `Allocator` ແລະພຽງແຕ່ຈະກູ້ຢືມເງິນນີ້.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // ຄວາມປອດໄພ: ສັນຍາດ້ານຄວາມປອດໄພຕ້ອງໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ຈາກຜູ້ໂທ
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ຄວາມປອດໄພ: ສັນຍາດ້ານຄວາມປອດໄພຕ້ອງໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ຈາກຜູ້ໂທ
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ຄວາມປອດໄພ: ສັນຍາດ້ານຄວາມປອດໄພຕ້ອງໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ຈາກຜູ້ໂທ
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ຄວາມປອດໄພ: ສັນຍາດ້ານຄວາມປອດໄພຕ້ອງໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ຈາກຜູ້ໂທ
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}