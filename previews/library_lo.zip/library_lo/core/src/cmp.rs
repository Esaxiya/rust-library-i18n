//! ໜ້າ ທີ່ ສຳ ລັບການຈັດ ລຳ ດັບແລະການປຽບທຽບ.
//!
//! ໂມດູນນີ້ມີຫລາຍເຄື່ອງມື ສຳ ລັບການຈັດ ລຳ ດັບແລະປຽບທຽບຄ່າຕ່າງໆ.ສະຫຼຸບສັງລວມ:
//!
//! * [`Eq`] ແລະ [`PartialEq`] ມີ traits ທີ່ອະນຸຍາດໃຫ້ທ່ານເພື່ອກໍານົດຄວາມສະເຫມີພາບທັງຫມົດແລະບາງສ່ວນລະຫວ່າງຄ່າ, ຕາມລໍາດັບ.
//! ປະຕິບັດໃຫ້ເຂົາເຈົ້າ overloads ທີ່ `==` ແລະ `!=` ຜູ້ປະກອບການ.
//! * [`Ord`] ແລະ [`PartialOrd`] ແມ່ນ traits ທີ່ຊ່ວຍໃຫ້ທ່ານສາມາດ ກຳ ນົດການສັ່ງສິນຄ້າທັງ ໝົດ ແລະບາງສ່ວນລະຫວ່າງຄ່າຕາມ ລຳ ດັບ.
//!
//! ປະຕິບັດໃຫ້ເຂົາເຈົ້າ overloads ຜູ້ປະກອບການ `<`, `<=`, `>` ແລະ `>=`.
//! * [`Ordering`] ເປັນ enum ຄືນໂດຍຫນ້າທີ່ຫລັກຂອງ [`Ord`] ແລະ [`PartialOrd`], ແລະອະທິບາຍການກໍາລັງສັ່ງ.
//! * [`Reverse`] ເປັນ struct ທີ່ອະນຸຍາດໃຫ້ທ່ານໄດ້ຢ່າງງ່າຍດາຍໄດ້ຢ່າງສິ້ນເຊີງເປັນກໍາລັງສັ່ງໄດ້.
//! * [`max`] ແລະ [`min`] ແມ່ນ ໜ້າ ທີ່ທີ່ສ້າງຂື້ນຈາກ [`Ord`] ແລະຊ່ວຍໃຫ້ທ່ານສາມາດຊອກຫາໄດ້ສູງສຸດຫລື ໜ້ອຍ ທີ່ສຸດຂອງສອງຄ່າ.
//!
//! ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ, ເບິ່ງເອກະສານທີ່ກ່ຽວຂ້ອງຂອງແຕ່ລະລາຍການໃນບັນຊີ.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait ສໍາລັບການປຽບທຽບຄວາມສະເຫມີພາບທີ່ [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// trait ນີ້ອະນຸຍາດໃຫ້ສໍາລັບຄວາມສະເຫມີພາບເປັນບາງສ່ວນ, ສໍາລັບປະເພດທີ່ບໍ່ມີຄວາມສໍາພັນເທົ່າທຽມກັນຢ່າງເຕັມທີ່.
/// ສໍາລັບຕົວຢ່າງ, ໃນຈໍານວນຈຸດທີ່ເລື່ອນໄດ້ `NaN != NaN`, ສະນັ້ນປະເພດ floating point ໃຊ້ `PartialEq` ແຕ່ບໍ່ [`trait@Eq`].
///
/// ຢ່າງເປັນທາງການ, ຄວາມສະ ເໝີ ພາບຕ້ອງເປັນ (ສຳ ລັບ `a`, `b`, `c` ທຸກປະເພດ `A`, `B`, `C`):
///
/// - **Symmetric**: ຖ້າ `A: PartialEq<B>` ແລະ `B: PartialEq<A>`, ຫຼັງຈາກນັ້ນ **`ເປັນ==b` ກໍຫມາຍຄວາມວ່າ`b==a`**;ແລະ
///
/// - **ການປ່ຽນແປງ**: ຖ້າ `A: PartialEq<B>` ແລະ `B: PartialEq<C>` ແລະ `A:
///   PartialEq<C>`, ຫຼັງຈາກນັ້ນ **` ເປັນ b`==ແລະ `b == c` ກໍຫມາຍຄວາມວ່າ`ເປັນ==c`**.
///
/// ໃຫ້ສັງເກດວ່າການ `B: PartialEq<A>` (symmetric) ແລະ `A: PartialEq<C>` (transitive) impl ຍັງບໍ່ໄດ້ຖືກບັງຄັບໃຫ້ຢູ່, ແຕ່ຄວາມຕ້ອງການເຫຼົ່ານີ້ເກີດຂື້ນເມື່ອໃດກໍຕາມເຮັດມີ.
///
/// ## Derivable
///
/// trait ນີ້ສາມາດຖືກນໍາໃຊ້ກັບ `#[derive]`.ໃນເວລາທີ່ `derive`d ກ່ຽວກັບ struct, ສອງກໍລະນີແມ່ນເທົ່າທຽມກັນຖ້າຫາກວ່າຂົງເຂດທັງຫມົດແມ່ນເທົ່າທຽມກັນ, ແລະບໍ່ມີຄວາມຫມາຍເທົ່າຖ້າຫາກວ່າທົ່ງນາໃດບໍ່ເທົ່າທຽມກັນ.ໃນເວລາທີ່ `ມາໃນສະຖານທີ່, ແຕ່ລະຕົວປ່ຽນແມ່ນເທົ່າກັບຕົວມັນເອງແລະບໍ່ທຽບເທົ່າກັບຕົວແປອື່ນໆ.
///
/// ## ຂ້ອຍສາມາດປະຕິບັດ `PartialEq` ໄດ້ແນວໃດ?
///
/// `PartialEq` ພຽງແຕ່ຮຽກຮ້ອງໃຫ້ມີວິທີການ [`eq`] ທີ່ຈະປະຕິບັດ;[`ne`] ລະບຸໄວ້ໃນຂໍ້ກໍານົດຂອງມັນຕັ້ງແຕ່ຕອນຕົ້ນ.ທຸກການປະຕິບັດດ້ວຍຕົນເອງຂອງ [`ne`]*ຕ້ອງ* ນັບຖືກົດລະບຽບທີ່ [`eq`] ເປັນກັນທີ່ເຄັ່ງຄັດຂອງ [`ne`];ນັ້ນຄື `!(a == b)` ຖ້າແລະພຽງແຕ່ຖ້າຫາກວ່າ `a != b`.
///
/// ການປະຕິບັດຂອງ `PartialEq`, [`PartialOrd`] ແລະ [`Ord`]*ຕ້ອງ* ຕົກລົງເຫັນດີກັບແຕ່ລະຄົນອື່ນໆ.ມັນງ່າຍທີ່ຈະເຮັດໃຫ້ພວກເຂົາຜິດຖຽງກັນໂດຍບັງເອີນໂດຍການໄດ້ມາຈາກບາງສ່ວນຂອງ traits ແລະປະຕິບັດກັບຄົນອື່ນດ້ວຍຕົນເອງ.
///
/// ການປະຕິບັດຕົວຢ່າງສໍາລັບໂດເມນທີ່ສອງຫນັງສືກໍາລັງພິຈາລະນາຫນັງສືດຽວກັນຖ້າຫາກວ່າຜົນ ISBN ຂອງເຂົາເຈົ້າ, ເຖິງແມ່ນວ່າຖ້າຫາກວ່າຮູບແບບທີ່ແຕກຕ່າງກັນ:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## ແນວໃດຂ້າພະເຈົ້າສາມາດປຽບທຽບສອງປະເພດທີ່ແຕກຕ່າງກັນ?
///
/// ປະເພດທີ່ທ່ານສາມາດປຽບທຽບກັບແມ່ນສາມາດຄວບຄຸມໂດຍ `ພາລາມິເຕີປະເພດ PartialEq` ຂອງ.
/// ຍົກຕົວຢ່າງ, ກະລຸນາປັບປຸງລະຫັດກ່ອນ ໜ້າ ນີ້ຂອງພວກເຮົາ:
///
/// ```
/// // ການປະຕິບັດແນວ Derive<BookFormat>==<BookFormat>ປຽບທຽບ
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // ຈັດຕັ້ງປະຕິບັດ<Book>==<BookFormat>ການປຽບທຽບ
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // ຈັດຕັ້ງປະຕິບັດ<BookFormat>==<Book>ການປຽບທຽບ
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// ໂດຍການປ່ຽນແປງ `impl PartialEq for Book` ກັບ `impl PartialEq<BookFormat> for Book`, ພວກເຮົາອະນຸຍາດໃຫ້ `BookFormat`s ທີ່ຈະປຽບທຽບກັບ`Book`s.
///
/// ການປຽບທຽບທີ່ຄ້າຍຄືຂ້າງເທິງນີ້, ຊຶ່ງຄົມຂົງເຂດຂອງ struct ບາງ, ສາມາດເປັນອັນຕະລາຍ.ມັນສາມາດ ນຳ ໄປສູ່ການລະເມີດທີ່ບໍ່ໄດ້ຕັ້ງໃຈຂອງຂໍ້ ກຳ ນົດກ່ຽວກັບຄວາມ ສຳ ພັນສະ ເໝີ ພາບບາງສ່ວນ.
/// ສໍາລັບຕົວຢ່າງ, ຖ້າຫາກວ່າພວກເຮົາເກັບຮັກສາໄວ້ການປະຕິບັດຂ້າງເທິງຂອງ `PartialEq<Book>` ສໍາລັບ `BookFormat` ແລະເພີ່ມການປະຕິບັດຂອງ `PartialEq<Book>` ສໍາລັບ `Book` (ບໍ່ວ່າຈະຜ່ານ `#[derive]` ຫຼືຜ່ານການປະຕິບັດຄູ່ມືຈາກຕົວຢ່າງທໍາອິດ) ຫຼັງຈາກນັ້ນຜົນໄດ້ຮັບຈະລະເມີດການປ່ຽນແປງ:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// ນີ້ທົດສອບວິທີການສໍາລັບການ `self` ແລະ `other` ຄຸນຄ່າທີ່ຈະເທົ່າທຽມກັນ, ແລະຖືກນໍາໃຊ້ໂດຍ `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// ວິທີການນີ້ທົດສອບສໍາລັບ `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// ສ້າງມາຈາກມະຫາພາກສ້າງແຮງບັນດານໃຈຂອງ trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait ສຳ ລັບການປຽບທຽບຄວາມເທົ່າທຽມກັນເຊິ່ງເປັນ [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// ນີ້ ໝາຍ ຄວາມວ່າ, ນອກ ເໜືອ ຈາກ `a == b` ແລະ `a != b` ແມ່ນການຫັນກັນຢ່າງເຂັ້ມງວດ, ຄວາມສະ ເໝີ ພາບຕ້ອງເປັນ (ສຳ ລັບ `a`, `b` ແລະ `c`):
///
/// - reflexive: `a == a`;
/// - symmetric: `a == b` ແດງໃຫ້ເຫັນເຖິງ `b == a`;ແລະ
/// - transitive: `a == b` ແລະ `b == c` ແດງໃຫ້ເຫັນເຖິງ `a == c`.
///
/// ຄຸນສົມບັດນີ້ບໍ່ສາມາດໄດ້ຮັບການກວດກາໂດຍ compiler, ແລະເພາະສະນັ້ນຈຶ່ງ `Eq` ແດງໃຫ້ເຫັນເຖິງ [`PartialEq`], ແລະບໍ່ມີວິທີການພິເສດ.
///
/// ## Derivable
///
/// trait ນີ້ສາມາດຖືກນໍາໃຊ້ກັບ `#[derive]`.
/// ເມື່ອ `derive`d, ເພາະວ່າ `Eq` ບໍ່ມີວິທີການພິເສດ, ມັນພຽງແຕ່ແຈ້ງໃຫ້ນັກຂຽນຮູ້ວ່ານີ້ແມ່ນຄວາມ ສຳ ພັນທຽບເທົ່າກັນຫຼາຍກວ່າການພົວພັນທຽບເທົ່າສ່ວນ ໜຶ່ງ.
///
/// ໃຫ້ສັງເກດວ່າຍຸດທະສາດ `derive` ຮຽກຮ້ອງໃຫ້ທຸກໆຂົງເຂດແມ່ນ `Eq`, ເຊິ່ງບໍ່ແມ່ນຄວາມຕ້ອງການສະ ເໝີ ໄປ.
///
/// ## ຂ້ອຍສາມາດປະຕິບັດ `Eq` ໄດ້ແນວໃດ?
///
/// ຖ້າທ່ານບໍ່ສາມາດໃຊ້ຍຸດທະສາດ `derive`, ໃຫ້ລະບຸວ່າປະເພດຂອງທ່ານປະຕິບັດ `Eq`, ເຊິ່ງບໍ່ມີວິທີການໃດ:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // ວິທີການນີ້ຖືກນໍາໃຊ້ແຕ່ພຽງຜູ້ດຽວໂດຍ#[ຜັນຂະຫຍາຍ] ໃຫ້ຫມັ້ນໃຈວ່າອົງປະກອບຂອງຊະນິດປະຕິບັດແນວ#ທຸກ [ຜັນຂະຫຍາຍ] ຕົວຂອງມັນເອງ, ໃນປະຈຸບັນຫມາຍຄວາມວ່າໂຄງສ້າງພື້ນຖານອະນຸພັນການດໍາເນີນການຍື່ນຍັນນີ້ໂດຍບໍ່ມີການນໍາໃຊ້ວິທີການກ່ຽວກັບການ trait ນີ້ເປັນເກືອບເພງນຶ່ງໃນດວງ.
    //
    //
    // ສິ່ງນີ້ບໍ່ຄວນຖືກປະຕິບັດດ້ວຍມື.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// ສ້າງມາຈາກມະຫາພາກສ້າງແຮງບັນດານໃຈຂອງ trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: struct ນີ້ຖືກນໍາໃຊ້ແຕ່ພຽງຜູ້ດຽວໂດຍ#[Driv] ກັບ
// ຍືນຍັນວ່າອົງປະກອບຂອງປະເພດການປະຕິບັດ Eq ທຸກ.
//
// ໂຄງສ້າງນີ້ບໍ່ຄວນສະແດງຢູ່ໃນລະຫັດຜູ້ໃຊ້.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// ເປັນ `Ordering` ເປັນຜົນມາຈາກການປຽບທຽບລະຫວ່າງສອງຄ່າໄດ້.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// ການສັ່ງຊື້ບ່ອນທີ່ມີຄ່າທຽບໃສ່ ໜ້ອຍ ກ່ວາບ່ອນອື່ນ.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// ເປັນກໍາລັງສັ່ງທີ່ຄ່າທຽບເທົ່າກັບຄົນອື່ນ.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// ເປັນກໍາລັງສັ່ງທີ່ຄ່າປຽບທຽບຫລາຍກວ່າຄົນອື່ນ.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// ສົ່ງຄືນ `true` ຖ້າການສັ່ງຊື້ແມ່ນລຸ້ນ `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// ຜົນໄດ້ຮັບ `true` ຖ້າຄໍາສັ່ງ, ບໍ່ແມ່ນການທີ່ແຕກຕ່າງ `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// ຜົນໄດ້ຮັບ `true` ຖ້າຄໍາສັ່ງແມ່ນແຕກຕ່າງ `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// ຜົນໄດ້ຮັບ `true` ຖ້າຄໍາສັ່ງແມ່ນແຕກຕ່າງ `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// ສົ່ງຄືນ `true` ຖ້າການສັ່ງແມ່ນທັງລຸ້ນ `Less` ຫຼື `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// ຜົນໄດ້ຮັບ `true` ຖ້າຄໍາສັ່ງແມ່ນບໍ່ວ່າຈະແມ່ນ `Greater` ຫຼື `Equal` ແຕກຕ່າງ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// ປີ້ນກັບກັນ `Ordering`.
    ///
    /// * `Less` ກາຍເປັນ `Greater`.
    /// * `Greater` ກາຍເປັນ `Less`.
    /// * `Equal` ກາຍເປັນ `Equal`.
    ///
    /// # Examples
    ///
    /// ພຶດຕິ ກຳ ພື້ນຖານ:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// ວິທີການນີ້ສາມາດຖືກ ນຳ ໃຊ້ເພື່ອປ່ຽນການປຽບທຽບ:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // ຈັດຮຽງແຖວຈາກໃຫຍ່ທີ່ສຸດຈົນເຖິງຂະ ໜາດ ນ້ອຍສຸດ.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// ຕ່ອງໂສ້ການສັ່ງຊື້ສອງຢ່າງ.
    ///
    /// ສົ່ງຄືນ `self` ເມື່ອມັນບໍ່ແມ່ນ `Equal`.ຖ້າບໍ່ດັ່ງນັ້ນຜົນໄດ້ຮັບ `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// ລະບົບຕ່ອງໂສ້ການຄໍາສັ່ງທີ່ມີຫນ້າທີ່ດັ່ງກ່າວ.
    ///
    /// ຜົນຕອບແທນ `self` ໃນເວລາທີ່ມັນບໍ່ `Equal`.
    /// ຖ້າບໍ່ດັ່ງນັ້ນເອີ້ນ `f` ແລະສົ່ງຜົນໄດ້ຮັບ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// ໂຄງສ້າງຜູ້ຊ່ວຍ ສຳ ລັບການຈັດລຽງ ລຳ ດັບຕາມ ລຳ ດັບ.
///
/// ໂຄງສ້າງນີ້ແມ່ນຕົວຊ່ວຍທີ່ຈະຖືກ ນຳ ໃຊ້ກັບ ໜ້າ ທີ່ຄື [`Vec::sort_by_key`] ແລະສາມາດ ນຳ ໃຊ້ເພື່ອປ່ຽນໃບສັ່ງຊື້ສ່ວນ ໜຶ່ງ ຂອງຄີ.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait ສໍາລັບຊະນິດທີ່ປະກອບເປັນ [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// ຄຳ ສັ່ງແມ່ນ ຄຳ ສັ່ງທັງ ໝົດ ຖ້າມັນແມ່ນ (ສຳ ລັບ `a`, `b` ແລະ `c`):
///
/// - total ແລະ asymmetric: ແທ້ ໜຶ່ງ ຂອງ `a < b`, `a == b` ຫຼື `a > b` ແມ່ນຄວາມຈິງ;ແລະ
/// - transitive, `a < b` ແລະ `b < c` ໝາຍ ຄວາມວ່າ `a < c`.ດຽວກັນຕ້ອງຖື ສຳ ລັບທັງ `==` ແລະ `>`.
///
/// ## Derivable
///
/// trait ນີ້ສາມາດຖືກນໍາໃຊ້ກັບ `#[derive]`.
/// ໃນເວລາທີ່ `derive`d ກ່ຽວກັບ struct, ມັນຈະຜະລິດເປັນກໍາລັງສັ່ງ [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ອີງໃສ່ເທິງ-to-ລຸ່ມເພື່ອການປະກາດຂອງສະມາຊິກ struct ຂອງ.
///
/// ໃນເວລາທີ່ `derive`d ກ່ຽວກັບ ENUM, variants ຕາມສັ່ງມີຄໍາສັ່ງຈໍາແນກຂອງເຂົາເຈົ້າ top-to-ລຸ່ມ.
///
/// ## ການສົມທຽບ lexicographers
///
/// ການປຽບທຽບທາງດ້ານສັບແມ່ນການ ດຳ ເນີນງານທີ່ມີຄຸນສົມບັດຕໍ່ໄປນີ້:
///  - ສອງລໍາດັບເມື່ອປຽບທຽບອົງປະກອບໂດຍອົງປະກອບ.
///  - ອົງປະກອບທີ່ບໍ່ສອດຄ່ອງກັນ ທຳ ອິດ ກຳ ນົດວ່າ ລຳ ດັບໃດ ໜຶ່ງ ທີ່ມີລັກສະນະພາສາທີ່ມີຄວາມ ໝາຍ ໜ້ອຍ ກວ່າຫຼືໃຫຍ່ກວ່າສ່ວນອື່ນໆ.
///  - ຖ້າຫາກວ່າຫນຶ່ງລໍາດັບເປັນຄໍານໍາຫນ້າຂອງຄົນອື່ນ, ການລໍາດັບສັ້ນແມ່ນ lexicographers ຫນ້ອຍກ່ວາອື່ນໆ.
///  - ຖ້າຫາກວ່າທັງສອງລໍາດັບມີອົງປະກອບທຽບເທົ່າແລະມີຄວາມຍາວດຽວກັນ, ຫຼັງຈາກນັ້ນລໍາດັບແມ່ນເທົ່າທຽມກັນ lexicographers.
///  - ເປັນລໍາດັບຫວ່າງແມ່ນ lexicographers ຫນ້ອຍກ່ວາລໍາດັບທີ່ບໍ່ແມ່ນເປົ່າໃດ.
///  - ສອງລໍາດັບເປົ່າແມ່ນເທົ່າທຽມກັນ lexicographers.
///
/// ## ຂ້ອຍສາມາດປະຕິບັດ `Ord` ໄດ້ແນວໃດ?
///
/// `Ord` ຮຽກຮ້ອງໃຫ້ມີທີ່ປະເພດຍັງຈະ [`PartialOrd`] ແລະ [`Eq`] (ທີ່ຮຽກຮ້ອງໃຫ້ມີ [`PartialEq`]).
///
/// ຫຼັງຈາກນັ້ນທ່ານຕ້ອງ ກຳ ນົດການຈັດຕັ້ງປະຕິບັດ ສຳ ລັບ [`cmp`].ທ່ານອາດຈະເຫັນວ່າມັນເປັນປະໂຫຍດທີ່ຈະນໍາໃຊ້ [`cmp`] ເນື້ອທີ່ປູກຝັງປະເພດຂອງທ່ານ.
///
/// ການປະຕິບັດຂອງ [`PartialEq`], [`PartialOrd`], ແລະ `Ord`*ຕ້ອງ* ເຫັນດີ ນຳ ກັນ.
/// ນັ້ນແມ່ນ, `a.cmp(b) == Ordering::Equal` ຖ້າແລະພຽງແຕ່ຖ້າ `a == b` ແລະ `Some(a.cmp(b)) == a.partial_cmp(b)` ສຳ ລັບ `a` ແລະ `b` ທັງ ໝົດ.
/// ມັນງ່າຍທີ່ຈະເຮັດໃຫ້ພວກເຂົາຜິດຖຽງກັນໂດຍບັງເອີນໂດຍການໄດ້ມາຈາກບາງສ່ວນຂອງ traits ແລະປະຕິບັດກັບຄົນອື່ນດ້ວຍຕົນເອງ.
///
/// ນີ້ແມ່ນຕົວຢ່າງ ໜຶ່ງ ທີ່ທ່ານຕ້ອງການຈັດຮຽງຄົນໂດຍຄວາມສູງເທົ່ານັ້ນ, ໂດຍບໍ່ສົນໃຈ `id` ແລະ `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// ວິທີການນີ້ຈະກັບຄືນມາເປັນ [`Ordering`] ລະຫວ່າງ `self` ແລະ `other`.
    ///
    /// ໂດຍສົນທິສັນຍາ, `self.cmp(&other)` ສົ່ງຄືນ ຄຳ ສັ່ງທີ່ກົງກັບ ຄຳ ວ່າ `self <operator> other` ຖ້າຖືກຕ້ອງ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// ປຽບທຽບແລະສົ່ງຄືນຄ່າສູງສຸດຂອງສອງຄ່າ.
    ///
    /// ຜົນໄດ້ຮັບການໂຕ້ຖຽງທີສອງຖ້າຫາກວ່າການປຽບທຽບກໍານົດໃຫ້ເຂົາເຈົ້າມີຄວາມເທົ່າທຽມ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// ປຽບທຽບແລະສົ່ງຄືນຄ່າ ຕຳ ່ສຸດທີ່ສອງຄ່າ.
    ///
    /// ສົ່ງຄືນການໂຕ້ຖຽງຄັ້ງ ທຳ ອິດຖ້າການປຽບທຽບ ກຳ ນົດວ່າມັນເທົ່າທຽມກັນ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// ຈຳ ກັດຄ່າໃນຊ່ວງໄລຍະ ໜຶ່ງ.
    ///
    /// ກັບຄືນ `max` ຖ້າ `self` ໃຫຍ່ກວ່າ `max`, ແລະ `min` ຖ້າ `self` ນ້ອຍກວ່າ `min`.
    /// ຖ້າບໍ່ດັ່ງນັ້ນສິ່ງນີ້ຈະສົ່ງຄືນ `self`.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// ສ້າງມາຈາກມະຫາພາກສ້າງແຮງບັນດານໃຈຂອງ trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait ສໍາລັບຄຸນຄ່າທີ່ສາມາດໄດ້ຮັບການປຽບທຽບສໍາລັບການຈັດລຽງຄໍາສັ່ງ.
///
/// ການສົມທຽບຕ້ອງຕອບສະຫນອງຄວາມ, ສໍາລັບທຸກ `a`, `b` ແລະ `c`:
///
/// - asymmetry: ຖ້າ `a < b` ຫຼັງຈາກນັ້ນ `!(a > b)`, ເຊັ່ນດຽວກັນກັບ `a > b` ທີ່ນໍາໃຊ້ `!(a < b)`;ແລະ
/// - ການຫັນປ່ຽນ: `a < b` ແລະ `b < c` ໝາຍ ຄວາມວ່າ `a < c`.ດຽວກັນຕ້ອງຖື ສຳ ລັບທັງ `==` ແລະ `>`.
///
/// ໃຫ້ສັງເກດວ່າຂໍ້ ກຳ ນົດເຫຼົ່ານີ້ ໝາຍ ຄວາມວ່າ trait ເອງຕ້ອງໄດ້ປະຕິບັດດ້ວຍຮູບແບບທີ່ສົມເຫດສົມຜົນແລະປ່ຽນແປງ: ຖ້າ `T: PartialOrd<U>` ແລະ `U: PartialOrd<V>` ແລ້ວ `U: PartialOrd<T>` ແລະ `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// trait ນີ້ສາມາດໃຊ້ກັບ `#[derive]`.ໃນເວລາທີ່ `ອ້າງອີງໃສ່ໂຄງສ້າງ, ມັນຈະຜະລິດໃບສັ່ງຊື້ທາງດ້ານນິເວດວິທະຍາໂດຍອີງໃສ່ ຄຳ ສັ່ງປະກາດດ້ານເທິງຫາລຸ່ມສຸດຂອງສະມາຊິກຂອງໂຄງສ້າງ.
/// ໃນເວລາທີ່ `derive`d ກ່ຽວກັບ ENUM, variants ຕາມສັ່ງມີຄໍາສັ່ງຈໍາແນກຂອງເຂົາເຈົ້າ top-to-ລຸ່ມ.
///
/// ## ແນວໃດຂ້າພະເຈົ້າສາມາດປະຕິບັດ `PartialOrd`?
///
/// `PartialOrd` ພຽງແຕ່ຮຽກຮ້ອງໃຫ້ມີການປະຕິບັດຂອງວິທີການ [`partial_cmp`], ກັບຄົນອື່ນທີ່ເກີດຈາກການປະຕິບັດໃນຕອນຕົ້ນ.
///
/// ເຖິງຢ່າງໃດກໍ່ຕາມມັນຍັງເປັນໄປໄດ້ທີ່ຈະຈັດຕັ້ງປະຕິບັດແບບອື່ນໆແຍກຕ່າງຫາກ ສຳ ລັບປະເພດທີ່ບໍ່ມີ ຄຳ ສັ່ງທັງ ໝົດ
/// ຍົກຕົວຢ່າງ, ສຳ ລັບຕົວເລກຈຸດລອຍ, `NaN < 0 == false` ແລະ `NaN >= 0 == false` (cf.
/// IEEE 754-2008 ພາກ 5.11).
///
/// `PartialOrd` ຮຽກຮ້ອງໃຫ້ປະເພດຂອງທ່ານເປັນ [`PartialEq`].
///
/// ການປະຕິບັດຂອງ [`PartialEq`], `PartialOrd` ແລະ [`Ord`]*ຕ້ອງ* ຕົກລົງເຫັນດີກັບແຕ່ລະຄົນອື່ນໆ.
/// ມັນງ່າຍທີ່ຈະເຮັດໃຫ້ພວກເຂົາຜິດຖຽງກັນໂດຍບັງເອີນໂດຍການໄດ້ມາຈາກບາງສ່ວນຂອງ traits ແລະປະຕິບັດກັບຄົນອື່ນດ້ວຍຕົນເອງ.
///
/// ຖ້າປະເພດຂອງທ່ານແມ່ນ [`Ord`], ທ່ານສາມາດປະຕິບັດ [`partial_cmp`] ໂດຍໃຊ້ [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// ທ່ານອາດຈະເຫັນວ່າມັນເປັນປະໂຫຍດທີ່ຈະໃຊ້ [`partial_cmp`] ໃນຂົງເຂດປະເພດຂອງທ່ານ.
/// ນີ້ແມ່ນຕົວຢ່າງຂອງ `Person` ປະເພດທີ່ມີສະ ໜາມ ລອຍຟ້າຈຸດ `height` ເຊິ່ງເປັນສະ ໜາມ ດຽວທີ່ໃຊ້ໃນການຈັດຮຽງ:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// ວິທີການນີ້ຈະກັບຄືນມາເປັນກໍາລັງສັ່ງລະຫວ່າງ `self` ແລະ `other` ຄ່າຖ້າມີ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// ເມື່ອການປຽບທຽບເປັນໄປບໍ່ໄດ້:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// ວິທີການນີ້ທົດສອບ ໜ້ອຍ ກວ່າ (ສຳ ລັບ `self` ແລະ `other`) ແລະຖືກ ນຳ ໃຊ້ໂດຍຜູ້ປະຕິບັດການ `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// ການທົດສອບວິທີການນີ້ຫນ້ອຍກ່ວາຫຼືເທົ່າທຽມກັນທີ່ (ສໍາລັບ `self` ແລະ `other`) ແລະຖືກນໍາໃຊ້ໂດຍປະຕິບັດການ `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// ວິທີການນີ້ທົດສອບຫຼາຍກ່ວາ (ສໍາລັບ `self` ແລະ `other`) ແລະຖືກນໍາໃຊ້ໂດຍປະຕິບັດການ `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// ວິທີການນີ້ທົດສອບໃຫຍ່ກວ່າຫລືເທົ່າກັບ (ສຳ ລັບ `self` ແລະ `other`) ແລະຖືກ ນຳ ໃຊ້ໂດຍຜູ້ປະຕິບັດການ `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// ມະຫາພາກ Derive ສ້າງເປັນ impl ຂອງ trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// ປຽບທຽບແລະສົ່ງຄືນຄ່າ ຕຳ ່ສຸດທີ່ສອງຄ່າ.
///
/// ສົ່ງຄືນການໂຕ້ຖຽງຄັ້ງ ທຳ ອິດຖ້າການປຽບທຽບ ກຳ ນົດວ່າມັນເທົ່າທຽມກັນ.
///
/// ໂດຍລວມແລ້ວໃຊ້ນາມແຝງທີ່ຈະ [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// ກັບຄືນຄ່າຕ່ ຳ ສຸດຂອງສອງຄ່າກັບ ໜ້າ ທີ່ການປຽບທຽບທີ່ລະບຸ.
///
/// ສົ່ງຄືນການໂຕ້ຖຽງຄັ້ງ ທຳ ອິດຖ້າການປຽບທຽບ ກຳ ນົດວ່າມັນເທົ່າທຽມກັນ.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// ຜົນຕອບແທນອົງປະກອບທີ່ເຮັດໃຫ້ມູນຄ່າຕ່ໍາສຸດຈາກການທໍາງານທີ່ກໍານົດໄວ້.
///
/// ສົ່ງຄືນການໂຕ້ຖຽງຄັ້ງ ທຳ ອິດຖ້າການປຽບທຽບ ກຳ ນົດວ່າມັນເທົ່າທຽມກັນ.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// ປຽບທຽບແລະສົ່ງຄືນຄ່າສູງສຸດຂອງສອງຄ່າ.
///
/// ຜົນໄດ້ຮັບການໂຕ້ຖຽງທີສອງຖ້າຫາກວ່າການປຽບທຽບກໍານົດໃຫ້ເຂົາເຈົ້າມີຄວາມເທົ່າທຽມ.
///
/// ໂດຍລວມແລ້ວໃຊ້ນາມແຝງທີ່ຈະ [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// ກັບຄືນຄ່າສູງສຸດຂອງສອງຄ່າໂດຍອີງໃສ່ ໜ້າ ທີ່ການປຽບທຽບທີ່ລະບຸ.
///
/// ຜົນໄດ້ຮັບການໂຕ້ຖຽງທີສອງຖ້າຫາກວ່າການປຽບທຽບກໍານົດໃຫ້ເຂົາເຈົ້າມີຄວາມເທົ່າທຽມ.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// ສົ່ງຄືນອົງປະກອບທີ່ໃຫ້ຄຸນຄ່າສູງສຸດຈາກ ໜ້າ ທີ່ທີ່ລະບຸ.
///
/// ຜົນໄດ້ຮັບການໂຕ້ຖຽງທີສອງຖ້າຫາກວ່າການປຽບທຽບກໍານົດໃຫ້ເຂົາເຈົ້າມີຄວາມເທົ່າທຽມ.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// ການຈັດຕັ້ງປະຕິບັດບາງສ່ວນ, Eq, PartialOrd ແລະ Ord ສຳ ລັບປະເພດເດີມ
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // ຄໍາສັ່ງນີ້ເປັນສິ່ງສໍາຄັນທີ່ຈະສ້າງສະພາແຫ່ງທີ່ເຫມາະສົມຫຼາຍ.
                    // ເບິ່ງ <https://github.com/rust-lang/rust/issues/63758> ສໍາລັບຂໍ້ມູນເພີ່ມເຕີມ.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // ສຽງໂຫວດທັງຫມົດກັບ i8 ແລະປ່ຽນຄວາມແຕກຕ່າງກັນໄປສູ່ Ordering ຈະເຮັດໃຫ້ມີການຊຸມນຸມທີ່ດີທີ່ສຸດ.
            //
            // ເບິ່ງ <https://github.com/rust-lang/rust/issues/66780> ສໍາລັບຂໍ້ມູນເພີ່ມເຕີມ.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SAFETY: bool ເປັນ i8 ໃຫ້ຜົນໄດ້ຮັບ 0 ຫລື 1, ສະນັ້ນຄວາມແຕກຕ່າງບໍ່ສາມາດຈະມີສິ່ງໃດອີກແດ່
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &ຈຸດ

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}