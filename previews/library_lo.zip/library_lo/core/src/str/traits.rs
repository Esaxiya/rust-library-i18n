//! ການປະຕິບັດ Trait ສໍາລັບ `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// ປະຕິບັດການຈັດລຽງລໍາດັບຂອງສາຍ.
///
/// ເຊືອກຖືກສັ່ງ [lexicographically](Ord#lexicographical-comparison) ໂດຍຄ່າໄບຕ໌ຂອງພວກເຂົາ.
/// ນີ້ຄໍາສັ່ງລະຫັດ Unicode ຈຸດອີງໃສ່ຕໍາແຫນ່ງຂອງພວກເຂົາໃນຕາຕະລາງລະຫັດ.
/// ນີ້ບໍ່ ຈຳ ເປັນເທົ່າກັບ ຄຳ ສັ່ງ "alphabetical", ເຊິ່ງແຕກຕ່າງກັນໄປຕາມພາສາແລະທ້ອງຖິ່ນ.
/// ການຈັດຮຽງສາຍຕ່າງໆຕາມມາດຕະຖານທີ່ຍອມຮັບທາງດ້ານວັດທະນະ ທຳ ຮຽກຮ້ອງໃຫ້ມີຂໍ້ມູນສະເພາະໃນທ້ອງຖິ່ນທີ່ຢູ່ນອກຂອບເຂດຂອງປະເພດ `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// ປະຕິບັດການປຽບທຽບການປະຕິບັດງານກ່ຽວກັບສາຍ.
///
/// ຊ່ອຍແນ່ໄດ້ເມື່ອປຽບທຽບ [lexicographically](Ord#lexicographical-comparison) ໂດຍຄ່າ byte ຂອງເຂົາເຈົ້າ.
/// ນີ້ປຽບທຽບຈຸດລະຫັດຂອງຢູນີໂຄດໂດຍອີງໃສ່ ຕຳ ແໜ່ງ ຂອງພວກເຂົາໃນຕາຕະລາງລະຫັດ.
/// ນີ້ບໍ່ ຈຳ ເປັນເທົ່າກັບ ຄຳ ສັ່ງ "alphabetical", ເຊິ່ງແຕກຕ່າງກັນໄປຕາມພາສາແລະທ້ອງຖິ່ນ.
/// ການປຽບທຽບສາຍຕ່າງໆຕາມມາດຕະຖານທີ່ຍອມຮັບທາງດ້ານວັດທະນະ ທຳ ຮຽກຮ້ອງໃຫ້ມີຂໍ້ມູນສະເພາະໃນທ້ອງຖິ່ນທີ່ຢູ່ນອກຂອບເຂດຂອງປະເພດ `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// ການປະຕິບັດການໃຊ້ສິ້ນສ່ວນທີ່ໃຊ້ກັບ syntax `&self[..]` ຫຼື `&mut self[..]`.
///
/// ສົ່ງຄືນສ່ວນຂອງສາຍທັງ ໝົດ, ເຊັ່ນ, ສົ່ງຄືນ `&self` ຫຼື `&mut self`.ທຽບເທົ່າກັບ `&ຕົວເອງ [0.
/// len] `ຫຼື`&mut ຕົນເອງ [0.
/// len]`.
/// ບໍ່ຄືກັບການ ດຳ ເນີນການດັດສະນີອື່ນໆ, ນີ້ບໍ່ສາມາດ panic.
///
/// ການປະຕິບັດງານນີ້ແມ່ນ *O*(1).
///
/// ກ່ອນ 1.20.0, ການ ດຳ ເນີນການດັດສະນີເຫຼົ່ານີ້ຍັງໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ຈາກການຈັດຕັ້ງປະຕິບັດໂດຍກົງຂອງ `Index` ແລະ `IndexMut`.
///
/// ເທົ່າກັບ `&self[0 .. len]` ຫຼື `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// ການປະຕິບັດການໃຊ້ສິ້ນສ່ວນທີ່ໃຊ້ກັບ syntax `&self[begin .. end]` ຫຼື `&mut self[begin .. end]`.
///
/// ກັບຄືນສ່ວນຂອງສາຍທີ່ໄດ້ຮັບຈາກຂອບເຂດໄບຕ໌ [`ເລີ່ມຕົ້ນ, `end`).
///
/// ການປະຕິບັດງານນີ້ແມ່ນ *O*(1).
///
/// ກ່ອນ 1.20.0, ການ ດຳ ເນີນການດັດສະນີເຫຼົ່ານີ້ຍັງໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ຈາກການຈັດຕັ້ງປະຕິບັດໂດຍກົງຂອງ `Index` ແລະ `IndexMut`.
///
/// # Panics
///
/// Panics ຖ້າ `begin` ຫຼື `end` ບໍ່ຊີ້ໄປທີ່ໄບເລີ່ມຊົດເຊີຍມີລັກສະນະເປັນ (ຕາມທີ່ກໍາຫນົດໂດຍ `is_char_boundary`), ຖ້າຫາກວ່າ `begin > end`, ຫຼືຖ້າ `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ເຫຼົ່ານີ້ຈະ panic:
/// // byte 2 ເຣັດພາຍໃນ `ö`:
/// // &s [2 ..3];
///
/// // byte 8 ຕົວະພາຍ `老`&s [1 ..
/// // 8];
///
/// // byte 100 ແມ່ນຢູ່ນອກສາຍ&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດເບິ່ງວ່າ `start` ແລະ `end` ແມ່ນຢູ່ໃນເຂດແດນ,
            // ແລະພວກເຮົາໄດ້ຖືກຖ່າຍທອດໃນກະສານອ້າງອີງທີ່ປອດໄພ, ດັ່ງນັ້ນຄ່າຕອບແທນຍັງຈະເປັນຫນຶ່ງ.
            // ພວກເຮົາຍັງກວດກາເຂດແດນ char, ສະນັ້ນນີ້ແມ່ນຖືກຕ້ອງ UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດເບິ່ງວ່າ `start` ແລະ `end` ແມ່ນຢູ່ໃນເຂດແດນ char.
            // ພວກເຮົາຮູ້ວ່າຕົວຊີ້ແມ່ນເປັນເອກະລັກເພາະວ່າພວກເຮົາໄດ້ຮັບມັນຈາກ `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // ຮັບປະກັນການແປໄດ້ທຸທີ່ `self` ແມ່ນຢູ່ໃນຂອບເຂດຂອງ `slice`: SAFETY
        // ທີ່ satisfies ທັງຫມົດເງື່ອນໄຂສໍາລັບການ `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ຄວາມປອດໄພ: ເບິ່ງ ຄຳ ເຫັນ ສຳ ລັບ `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary ກວດສອບວ່າດັດຊະນີແມ່ນຢູ່ໃນ [0, .len()] ບໍ່ສາມາດ ນຳ ໃຊ້ `get` ດັ່ງທີ່ກ່າວມາຂ້າງເທິງ, ເພາະວ່າບັນຫາຂອງ NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດເບິ່ງວ່າ `start` ແລະ `end` ແມ່ນຢູ່ໃນເຂດແດນ,
            // ແລະພວກເຮົາໄດ້ຖືກຖ່າຍທອດໃນກະສານອ້າງອີງທີ່ປອດໄພ, ດັ່ງນັ້ນຄ່າຕອບແທນຍັງຈະເປັນຫນຶ່ງ.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// ການປະຕິບັດການໃຊ້ສິ້ນສ່ວນທີ່ໃຊ້ກັບ syntax `&self[.. end]` ຫຼື `&mut self[.. end]`.
///
/// ກັບຄືນສ່ວນຂອງສາຍທີ່ໃຫ້ຈາກຊ່ວງ byte [`0`, `end`).
/// ເທົ່າກັບ `&self[0 .. end]` ຫຼື `&mut self[0 .. end]`.
///
/// ການປະຕິບັດງານນີ້ແມ່ນ *O*(1).
///
/// ກ່ອນ 1.20.0, ການ ດຳ ເນີນການດັດສະນີເຫຼົ່ານີ້ຍັງໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ຈາກການຈັດຕັ້ງປະຕິບັດໂດຍກົງຂອງ `Index` ແລະ `IndexMut`.
///
/// # Panics
///
/// Panics ຖ້າ `end` ບໍ່ໄດ້ຊີ້ໃຫ້ເຫັນຈຸດເລີ່ມຕົ້ນຂອງການຊົດເຊີຍຂອງຕົວລະຄອນ (ຕາມທີ່ `is_char_boundary`), ຫຼືຖ້າ `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດເບິ່ງວ່າ `end` ແມ່ນຢູ່ໃນເຂດແດນ char,
            // ແລະພວກເຮົາໄດ້ຖືກຖ່າຍທອດໃນກະສານອ້າງອີງທີ່ປອດໄພ, ດັ່ງນັ້ນຄ່າຕອບແທນຍັງຈະເປັນຫນຶ່ງ.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດເບິ່ງວ່າ `end` ແມ່ນຢູ່ໃນເຂດແດນ char,
            // ແລະພວກເຮົາໄດ້ຖືກຖ່າຍທອດໃນກະສານອ້າງອີງທີ່ປອດໄພ, ດັ່ງນັ້ນຄ່າຕອບແທນຍັງຈະເປັນຫນຶ່ງ.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດເບິ່ງວ່າ `end` ແມ່ນຢູ່ໃນເຂດແດນ char,
            // ແລະພວກເຮົາໄດ້ຖືກຖ່າຍທອດໃນກະສານອ້າງອີງທີ່ປອດໄພ, ດັ່ງນັ້ນຄ່າຕອບແທນຍັງຈະເປັນຫນຶ່ງ.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// ການປະຕິບັດການໃຊ້ສິ້ນສ່ວນທີ່ໃຊ້ກັບ syntax `&self[begin ..]` ຫຼື `&mut self[begin ..]`.
///
/// ກັບຄືນສ່ວນຂອງສາຍທີ່ໄດ້ຮັບຈາກຂອບເຂດໄບຕ໌ [`ເລີ່ມຕົ້ນ, `len`).ທຽບເທົ່າກັບ`&ຕົວເອງ [ເລີ່ມຕົ້ນ ..
/// len] `ຫຼື`&mut ຕົນເອງ [ເລີ່ມຕົ້ນ ..
/// len]`.
///
/// ການປະຕິບັດງານນີ້ແມ່ນ *O*(1).
///
/// ກ່ອນ 1.20.0, ການ ດຳ ເນີນການດັດສະນີເຫຼົ່ານີ້ຍັງໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ຈາກການຈັດຕັ້ງປະຕິບັດໂດຍກົງຂອງ `Index` ແລະ `IndexMut`.
///
/// # Panics
///
/// Panics ຖ້າ `begin` ບໍ່ໄດ້ຊີ້ໃຫ້ເຫັນຈຸດເລີ່ມຕົ້ນຂອງການຊົດເຊີຍຂອງຕົວລະຄອນ (ຕາມທີ່ `is_char_boundary`), ຫຼືຖ້າ `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດເບິ່ງວ່າ `start` ແມ່ນຢູ່ໃນເຂດແດນ char,
            // ແລະພວກເຮົາໄດ້ຖືກຖ່າຍທອດໃນກະສານອ້າງອີງທີ່ປອດໄພ, ດັ່ງນັ້ນຄ່າຕອບແທນຍັງຈະເປັນຫນຶ່ງ.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດເບິ່ງວ່າ `start` ແມ່ນຢູ່ໃນເຂດແດນ char,
            // ແລະພວກເຮົາໄດ້ຖືກຖ່າຍທອດໃນກະສານອ້າງອີງທີ່ປອດໄພ, ດັ່ງນັ້ນຄ່າຕອບແທນຍັງຈະເປັນຫນຶ່ງ.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // ຮັບປະກັນການແປໄດ້ທຸທີ່ `self` ແມ່ນຢູ່ໃນຂອບເຂດຂອງ `slice`: SAFETY
        // ທີ່ satisfies ທັງຫມົດເງື່ອນໄຂສໍາລັບການ `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ຄວາມປອດໄພ: ຄືກັນກັບ `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດເບິ່ງວ່າ `start` ແມ່ນຢູ່ໃນເຂດແດນ char,
            // ແລະພວກເຮົາໄດ້ຖືກຖ່າຍທອດໃນກະສານອ້າງອີງທີ່ປອດໄພ, ດັ່ງນັ້ນຄ່າຕອບແທນຍັງຈະເປັນຫນຶ່ງ.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// ການປະຕິບັດການໃຊ້ສິ້ນສ່ວນທີ່ໃຊ້ກັບ syntax `&self[begin ..= end]` ຫຼື `&mut self[begin ..= end]`.
///
/// ກັບຄືນສ່ວນຂອງສາຍທີ່ໄດ້ຈາກແຖວ [`begin`, `end`] byte.ເທົ່າກັບ `&self [begin .. end + 1]` ຫຼື `&mut self[begin .. end + 1]`, ຍົກເວັ້ນຖ້າ `end` ມີມູນຄ່າສູງສຸດ ສຳ ລັບ `usize`.
///
/// ການປະຕິບັດງານນີ້ແມ່ນ *O*(1).
///
/// # Panics
///
/// Panics ຖ້າ `begin` ບໍ່ຊີ້ໄປທີ່ໄບເລີ່ມຊົດເຊີຍມີລັກສະນະເປັນ (ຕາມທີ່ກໍາຫນົດໂດຍ `is_char_boundary`), ຖ້າຫາກວ່າ `end` ບໍ່ຊີ້ໄປທີ່ໄບສິ້ນສຸດການຊົດເຊີຍຂອງຕົວລະຄອນ (`end + 1` ແມ່ນບໍ່ວ່າຈະເປັນ byte ເລີ່ມຊົດເຊີຍຫຼືມີຄວາມຫມາຍເທົ່າກັບ `len`), ຖ້າຫາກວ່າ `begin > end`, ຫຼືຖ້າ `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// ການປະຕິບັດການໃຊ້ສິ້ນສ່ວນທີ່ໃຊ້ກັບ syntax `&self[..= end]` ຫຼື `&mut self[..= end]`.
///
/// ຜົນໄດ້ຮັບຫຼັງຈາກນັ້ນນໍາຂອງ string ໃຫ້ຈາກລະດັບ byte ໄດ້ [0, `end`] ໄດ້.
/// ເທົ່າກັບ `&self [0 .. end + 1]`, ຍົກເວັ້ນຖ້າ `end` ມີມູນຄ່າສູງສຸດ ສຳ ລັບ `usize`.
///
/// ການປະຕິບັດງານນີ້ແມ່ນ *O*(1).
///
/// # Panics
///
/// Panics ຖ້າ `end` ບໍ່ໄດ້ຊີ້ໃຫ້ເຫັນການຊົດເຊີຍ byte ສິ້ນສຸດຂອງຕົວລະຄອນ (`end + 1` ແມ່ນທັງການຊົດເຊີຍ byte ເລີ່ມຕົ້ນທີ່ໄດ້ ກຳ ນົດໂດຍ `is_char_boundary`, ຫຼືເທົ່າກັບ `len`), ຫຼືຖ້າ `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// ແຍກຄ່າຈາກສາຍ
///
/// `ວິທີ [`from_str`] FromStr` ຂອງມັກຖືກນໍາໃຊ້ໂດຍປະລິຍາຍ, ໂດຍຜ່ານການ [`str`] 's ວິທີການ [`parse`].
/// ເບິ່ງເອກະສານຂອງ [`parse`] ສຳ ລັບຕົວຢ່າງ.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ບໍ່ມີພາລາມິເຕີຕະຫຼອດຊີວິດ, ແລະດັ່ງນັ້ນທ່ານພຽງແຕ່ສາມາດແຍກປະເພດທີ່ບໍ່ມີພາລາມິເຕີຕະຫຼອດຊີວິດຕົນເອງ.
///
/// ເວົ້າອີກຢ່າງ ໜຶ່ງ, ທ່ານສາມາດແຍກ `i32` ກັບ `FromStr`, ແຕ່ບໍ່ແມ່ນ `&i32`.
/// ທ່ານສາມາດແຍກໂຄງສ້າງທີ່ປະກອບດ້ວຍ `i32`, ແຕ່ບໍ່ແມ່ນ ໜຶ່ງ ທີ່ມີ `&i32`.
///
/// # Examples
///
/// ການປະຕິບັດຂັ້ນພື້ນຖານຂອງ `FromStr` ໃນຕົວຢ່າງ `Point` ປະເພດ:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// ຂໍ້ຜິດພາດທີ່ກ່ຽວຂ້ອງເຊິ່ງສາມາດກັບຄືນມາຈາກການວິເຄາະ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// ວາງສາຍ `s` ເພື່ອສົ່ງຄືນຄ່າຂອງປະເພດນີ້.
    ///
    /// ຖ້າຫາກວ່າວະຈີວິພາກສົບຜົນສໍາເລັດ, ກັບຄືນມູນຄ່າທີ່ພາຍໃນ [`Ok`], ຖ້າບໍ່ດັ່ງນັ້ນໃນເວລາທີ່ string ແມ່ນກັບຄືນເຈັບປ່ວຍ, ຮູບແບບການສະເພາະໃດຫນຶ່ງຜິດພາດໄປພາຍໃນ [`Err`].
    /// ປະເພດຂໍ້ຜິດພາດແມ່ນສະເພາະໃນການຈັດຕັ້ງປະຕິບັດ trait.
    ///
    /// # Examples
    ///
    /// ການນໍາໃຊ້ພື້ນຖານພ້ອມ [`i32`], ຊະນິດທີ່ປະຕິບັດ `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// ແຍກ `bool` ຈາກສາຍ.
    ///
    /// ໃຫ້ຜົນຜະລິດ `Result<bool, ParseBoolError>`, ເພາະວ່າ `s` ອາດຈະຫຼືບໍ່ສາມາດແຍກຕົວຈິງໄດ້.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// ໝາຍ ເຫດ, ໃນຫລາຍໆກໍລະນີ, ວິທີການ `.parse()` ໃນ `str` ແມ່ນ ເໝາະ ສົມກວ່າ.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}