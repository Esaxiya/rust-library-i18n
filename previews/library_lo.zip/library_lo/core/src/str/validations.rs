//! ການປະຕິບັດງານທີ່ກ່ຽວຂ້ອງກັບຄວາມຖືກຕ້ອງຂອງ UTF-8.

use crate::mem;

use super::Utf8Error;

/// ຜົນໄດ້ຮັບການສະສົມ codepoint ເບື້ອງຕົ້ນສໍາລັບ byte ທໍາອິດ.
/// ໄບຕ໌ ທຳ ອິດແມ່ນພິເສດ, ພຽງແຕ່ຕ້ອງການດ້ານລຸ່ມ 5 ບິດ ສຳ ລັບຄວາມກວ້າງ 2, 4 ບາດ ສຳ ລັບຄວາມກວ້າງ 3, ແລະ 3 ສ່ວນ ສຳ ລັບຄວາມກວ້າງ 4.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// ກັບຄືນມູນຄ່າຂອງ `ch` ທີ່ຖືກປັບປຸງດ້ວຍ byte `byte` ຕໍ່ເນື່ອງ.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// ກວດເບິ່ງວ່າໄບຕ໌ແມ່ນໄບຕ໌ຕໍ່ເນື່ອງ UTF-8 (ໝາຍ ຄວາມວ່າເລີ່ມຕົ້ນຈາກບິດ `10`).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// ອ່ານຈຸດລະຫັດຕໍ່ໄປອອກຈາກຕົວຊີ້ວັດໄບຕ໌ (ສົມມຸດວ່າລະຫັດຄ້າຍຄື UTF-8).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // ຖອດລະຫັດ UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // ກໍລະນີ Multibyte ປະຕິບັດຕາມ Decode ຈາກການປະສົມປະສານ byte ອອກຈາກ: [[[x y] z] w]
    //
    // NOTE: ການປະຕິບັດແມ່ນມີຄວາມອ່ອນໄຫວກັບການສ້າງທີ່ແນ່ນອນຢູ່ທີ່ນີ້
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] ຄະດີ
        // ບິດທີ 5 ໃນ 0xE0 .. 0xEF ແມ່ນຈະແຈ້ງສະ ເໝີ, ສະນັ້ນ `init` ຍັງຖືກຕ້ອງ
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] ກໍລະນີໃຊ້ພຽງແຕ່ 3 ສ່ວນຕ່ ຳ ຂອງ `init` ເທົ່ານັ້ນ
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// ອ່ານຈຸດລະຫັດສຸດທ້າຍອອກຈາກຕົວຊີ້ວັດໄບຕ໌ (ສົມມຸດຖານລະຫັດເຂົ້າຄ້າຍ UTF-8).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // ຖອດລະຫັດ UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // ກໍລະນີ Multibyte ປະຕິບັດຕາມ Decode ຈາກການປະສົມປະສານ byte ອອກຈາກ: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// ໃຊ້ຕັດສັ້ນໃຫ້ພໍດີ u64 ເຂົ້າໄປໃນການ ນຳ ໃຊ້
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// ກັບຄືນ `true` ຖ້າມີ byte ໃນ ຄຳ ວ່າ `x` ແມ່ນ nonascii (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// ຍ່າງຜ່ານ `v` ກວດເບິ່ງວ່າມັນເປັນ UTF-8 ລຳ ດັບທີ່ຖືກຕ້ອງ, ກັບຄືນ `Ok(())` ໃນກໍລະນີດັ່ງກ່າວ, ຫຼືຖ້າມັນບໍ່ຖືກຕ້ອງ, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // ພວກເຮົາຕ້ອງການຂໍ້ມູນ, ແຕ່ວ່າບໍ່ມີຂໍ້ຜິດພາດ: ຂໍ້ຜິດພາດ!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // ການເຂົ້າລະຫັດແບບ 2 ໄບຕ໌ແມ່ນ ສຳ ລັບລະຫັດຈຸດຕ່າງໆ\u {0080} ເຖິງ\u {07ff} ທຳ ອິດ C2 80 ສຸດທ້າຍ DF BF
            // ການເຂົ້າລະຫັດ 3 ໄບຕ໌ແມ່ນ ສຳ ລັບລະຫັດຈຸດຕ່າງໆ\u {0800} ເພື່ອ\u {ffff} ຄັ້ງ ທຳ ອິດ E0 A0 80 ຫຼ້າສຸດ EF BF BF ບໍ່ລວມຕົວແທນ ຈຳ ກັດລະຫັດ\u {d800} ເພື່ອ\u {dfff} ED A0 80 ເຖິງ ED BF BF
            // ການເຂົ້າລະຫັດ 4 ໄບຕ໌ແມ່ນ ສຳ ລັບລະຫັດຈຸດຕ່າງໆ\u {1000} 0 ເຖິງ\u {10ff} ff ທຳ ອິດ F0 90 80 80 ສຸດທ້າຍ F4 8F BF BF
            //
            // ໃຊ້ syntax UTF-8 ຈາກ RFC
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-tail UTF8-3= %xE0% xA0-BF UTF8-tail/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-tail/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // ກໍລະນີ Ascii, ພະຍາຍາມທີ່ຈະກ້າວໄປຂ້າງ ໜ້າ ໂດຍໄວ.
            // ເມື່ອຕົວຊີ້ຖືກສອດຄ່ອງ, ອ່ານ 2 ຂໍ້ມູນຂອງຂໍ້ມູນຕໍ່ ຄຳ ເວົ້າຈົນກວ່າພວກເຮົາຈະພົບ ຄຳ ທີ່ມີເນື້ອໃນທີ່ບໍ່ແມ່ນເນື້ອໃນ.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // ຄວາມປອດໄພ: ຕັ້ງແຕ່ `align - index` ແລະ `ascii_block_size` ແມ່ນ
                    // `usize_bytes`, `block = ptr.add(index)` ແມ່ນສອດຄ່ອງກັບ `usize` ສະນັ້ນມັນປອດໄພໃນການຫັກລົບທັງ `block` ແລະ `block.offset(1)`.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // ແຕກແຍກຖ້າຫາກວ່າມີ byte nonascii
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // ຂັ້ນຕອນຈາກຈຸດທີ່ loop wordwise ຢຸດເຊົາການ
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// ໃຫ້ໄດ້ໄບຕ່ ຳ ທຳ ອິດ, ກຳ ນົດ ຈຳ ນວນໄບຕ໌ໃນລັກສະນະ UTF-8 ນີ້.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// ໜ້າ ກາກຂອງມູນຄ່າຂອງໄບຕ໌ຕໍ່ເນື່ອງ.
const CONT_MASK: u8 = 0b0011_1111;
/// ມູນຄ່າຂອງ bits ໂຄດຄໍາສັ່ງ (ຫນ້າກາກໂຄດຄໍາສັ່ງເປັນ !CONT_MASK) ຂອງ byte ສືບຕໍ່.
const TAG_CONT_U8: u8 = 0b1000_0000;

// ຕັດ `&str` ໃຫ້ຍາວທີ່ສຸດເທົ່າກັບ `max` ກັບຄືນ `true` ຖ້າມັນຖືກຕັດສັ້ນລົງ, ແລະສາຍ ໃໝ່.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}