//! ກຳ ນົດປະເພດຂໍ້ຜິດພາດ utf8.

use crate::fmt;

/// ຂໍ້ຜິດພາດຕ່າງໆທີ່ສາມາດເກີດຂື້ນໄດ້ໃນເວລາທີ່ພະຍາຍາມຕີຄວາມ ໝາຍ ລຳ ດັບຂອງ [`u8`] ເປັນສາຍສະຕິງ.
///
/// ໃນຖານະເປັນດັ່ງກ່າວ, `from_utf8` ຄອບຄົວຂອງຫນ້າທີ່ແລະວິທີການສໍາລັບທັງສອງ [`String`] s ແລະ [`&str`] ໃຊ້ໃນຄວາມຜິດພາດນີ້, ຍົກຕົວຢ່າງ.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// ວິທີການຂອງປະເພດຂໍ້ຜິດພາດນີ້ສາມາດຖືກ ນຳ ໃຊ້ເພື່ອສ້າງຟັງຊັນທີ່ຄ້າຍຄືກັບ `String::from_utf8_lossy` ໂດຍບໍ່ ຈຳ ເປັນຕ້ອງຈັດສັນຄວາມ ຈຳ ຂອງ heap:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// ສົ່ງຄືນດັດຊະນີໃນສາຍສະຕິງທີ່ໃຫ້ UTF-8 ທີ່ຖືກຕ້ອງຖືກຢືນຢັນ.
    ///
    /// ມັນແມ່ນດັດສະນີສູງສຸດທີ່ `from_utf8(&input[..index])` ຈະກັບຄືນ `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::str;
    ///
    /// // ບາງໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງ, ໃນ vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 ກັບຄືນ Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // ໄບຕ໌ທີສອງແມ່ນບໍ່ຖືກຕ້ອງທີ່ນີ້
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// ໃຫ້ຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຄວາມລົ້ມເຫລວ:
    ///
    /// * `None`: ຈຸດສຸດທ້າຍຂອງການປ້ອນຂໍ້ມູນບັນລຸໄດ້ໂດຍບໍ່ຄາດຝັນ.
    ///   `self.valid_up_to()` ແມ່ນ 1 ເຖິງ 3 ບາດຈາກຈຸດສຸດທ້າຍຂອງການປ້ອນຂໍ້ມູນ.
    ///   ຖ້າຫາກວ່ານ້ໍາ byte (ເຊັ່ນ: ໄຟລ໌ຫຼືເຕົ້າເຄືອຂ່າຍ) ຈະຖືກຖອດລະຫັດທີ່ເພີ່ມຂຶ້ນນີ້ອາດຈະເປັນ `char` ຖືກຕ້ອງທີ່ byte ລໍາດັບ UTF-8 ແມ່ນຢຽດ chunks ຫຼາຍ.
    ///
    ///
    /// * `Some(len)`: ພົບບັນຫາທີ່ບໍ່ຄາດຝັນ.
    ///   ຄວາມຍາວທີ່ລະບຸໄວ້ແມ່ນຂອງ ລຳ ດັບໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງເຊິ່ງເລີ່ມຈາກດັດຊະນີທີ່ໃຫ້ໂດຍ `valid_up_to()`.
    ///   ການຖອດລະຫັດຄວນຈະສືບຕໍ່ຫຼັງຈາກ ລຳ ດັບນັ້ນ (ຫຼັງຈາກໃສ່ [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) ໃນກໍລະນີທີ່ມີການຖອດລະຫັດທີ່ສູນເສຍໄປ.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// ຂໍ້ຜິດພາດທີ່ສົ່ງຄືນເມື່ອຄິດໄລ່ `bool` ໂດຍໃຊ້ [`from_str`] ລົ້ມເຫລວ
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}