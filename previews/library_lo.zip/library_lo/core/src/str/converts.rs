//! ວິທີການສ້າງ `str` ຈາກກະດາດໄບ.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// ແປງທ່ອນໄບຕ໌ເປັນທ່ອນຊ່ອຍແນ່.
///
/// ເຊືອກເຊືອກ ([`&str`]) ແມ່ນເຮັດດ້ວຍໄບຕ໌ ([`u8`]), ແລະແຜ່ນ ([`&[u8]`][byteslice]) ທີ່ເປັນ byte ແມ່ນເຮັດຈາກໄບ, ສະນັ້ນ ໜ້າ ທີ່ນີ້ປ່ຽນລະຫວ່າງສອງຢ່າງ.
/// ບໍ່ແມ່ນທຸກຂ໌ໄບຕ໌ແມ່ນແຜ່ນສະຕິງທີ່ຖືກຕ້ອງ, ຢ່າງໃດກໍ່ຕາມ: [`&str`] ຮຽກຮ້ອງໃຫ້ມັນຖືກຕ້ອງ UTF-8.
/// `from_utf8()` ກວດສອບເພື່ອຮັບປະກັນວ່າໄບຕ໌ແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ, ແລະຈາກນັ້ນກໍ່ເຮັດການແປງ.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// ຖ້າທ່ານແນ່ໃຈວ່າແຜ່ນໄບຕ໌ແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ, ແລະທ່ານບໍ່ຕ້ອງການທີ່ຈະເກີດບັນຫາດ້ານ ໜ້າ ຂອງການກວດສອບຄວາມຖືກຕ້ອງ, ມີລຸ້ນທີ່ບໍ່ປອດໄພ, [`from_utf8_unchecked`], ເຊິ່ງມີພຶດຕິ ກຳ ດຽວກັນແຕ່ຂ້າມການກວດສອບ.
///
///
/// ຖ້າທ່ານຕ້ອງການ `String` ແທນ `&str`, ພິຈາລະນາ [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// ເນື່ອງຈາກວ່າທ່ານສາມາດຈັດສັນ `[u8; N]`, ແລະທ່ານສາມາດເອົາ [`&[u8]`][byteslice] ຂອງມັນ, ຟັງຊັນນີ້ແມ່ນວິທີ ໜຶ່ງ ທີ່ຈະມີສະຕິງຈັດສັນ.ມີຕົວຢ່າງຂອງສິ່ງນີ້ໃນພາກຕົວຢ່າງຂ້າງລຸ່ມນີ້.
///
/// [byteslice]: slice
///
/// # Errors
///
/// ກັບຄືນ `Err` ຖ້າຫາກວ່າສ່ວນທີ່ບໍ່ແມ່ນ UTF-8 ກັບ ຄຳ ອະທິບາຍວ່າເປັນຫຍັງສ່ວນທີ່ສະ ໜອງ ໃຫ້ບໍ່ແມ່ນ UTF-8.
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::str;
///
/// // ບາງໄບຕ໌, ໃນ vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ພວກເຮົາຮູ້ວ່າໄບຕ໌ເຫລົ່ານີ້ແມ່ນຖືກຕ້ອງ, ສະນັ້ນພຽງແຕ່ໃຊ້ `unwrap()` ເທົ່ານັ້ນ.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// ໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງ:
///
/// ```
/// use std::str;
///
/// // ບາງໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງ, ໃນ vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// ເບິ່ງເອກະສານ ສຳ ລັບ [`Utf8Error`] ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມກ່ຽວກັບປະເພດຂອງຂໍ້ຜິດພາດທີ່ສາມາດສົ່ງຄືນໄດ້.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // ບາງໄບຕ໌, ໃນແຖວຈັດສັນຕາມ ລຳ ດັບ
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // ພວກເຮົາຮູ້ວ່າໄບຕ໌ເຫລົ່ານີ້ແມ່ນຖືກຕ້ອງ, ສະນັ້ນພຽງແຕ່ໃຊ້ `unwrap()` ເທົ່ານັ້ນ.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: ພຽງແຕ່ ran ການກວດສອບ.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// ປ່ຽນເປັນທ່ອນທີ່ມີການປ່ຽນແປງໄດ້ຂອງໄບຕ໌ເປັນທ່ອນຊ່ອຍແນ່ທີ່ສາມາດປ່ຽນແປງໄດ້.
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" ເປັນ vector ທີ່ສາມາດປ່ຽນແປງໄດ້
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // ດັ່ງທີ່ພວກເຮົາຮູ້ວ່າໄບຕ໌ເຫລົ່ານີ້ຖືກຕ້ອງ, ພວກເຮົາສາມາດໃຊ້ `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// ໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງ:
///
/// ```
/// use std::str;
///
/// // ບາງໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງໃນ vector ທີ່ປ່ຽນແປງໄດ້
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// ເບິ່ງເອກະສານ ສຳ ລັບ [`Utf8Error`] ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມກ່ຽວກັບປະເພດຂອງຂໍ້ຜິດພາດທີ່ສາມາດສົ່ງຄືນໄດ້.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SAFETY: ພຽງແຕ່ ran ການກວດສອບ.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// ແປງທ່ອນໄບຕ໌ເປັນທ່ອນຊ່ອຍແນ່ໂດຍບໍ່ກວດເບິ່ງວ່າສາຍສະຕິງມີ UTF-8 ທີ່ຖືກຕ້ອງ.
///
/// ເບິ່ງເວີຊັນທີ່ປອດໄພ, [`from_utf8`], ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ.
///
/// # Safety
///
/// ຟັງຊັນນີ້ບໍ່ປອດໄພເພາະມັນບໍ່ໄດ້ກວດເບິ່ງວ່າໄບທີ່ຜ່ານໄປມັນແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ.
/// ຖ້າຫາກວ່າຂໍ້ຈໍາກັດນີ້ແມ່ນຖືກລະເມີດ, ຜົນໄດ້ຮັບພຶດຕິກໍາ undefined, ເປັນສ່ວນທີ່ເຫຼືອຂອງ Rust ອະນຸມານວ່າ [`ແລະ str`] s ແມ່ນຖືກຕ້ອງ UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::str;
///
/// // ບາງໄບຕ໌, ໃນ vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SAFETY: ແປໄດ້ທຸໄດ້ຕ້ອງຮັບປະກັນວ່າໄບ `v` ແມ່ນຖືກຕ້ອງ UTF-8.
    // ຍັງຂື້ນກັບ `&str` ແລະ `&[u8]` ມີຮູບແບບດຽວກັນ.
    unsafe { mem::transmute(v) }
}

/// ແປງທ່ອນໄບຕ໌ເປັນທ່ອນຊ່ອຍແນ່ໂດຍບໍ່ກວດເບິ່ງວ່າສາຍສະຕິງມີ UTF-8 ທີ່ຖືກຕ້ອງ;ສະບັບທີ່ປ່ຽນແປງໄດ້.
///
///
/// ເບິ່ງສະບັບບໍ່ປ່ຽນແປງ, [`from_utf8_unchecked()`] ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ.
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ bytes `v`
    // ແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ, ດັ່ງນັ້ນການຫລໍ່ໃຫ້ `*mut str` ແມ່ນປອດໄພ.
    // ນອກຈາກນີ້, ການແຍກຕົວຊີ້ແມ່ນປອດໄພເພາະວ່າຕົວຊີ້ນັ້ນມາຈາກເອກະສານອ້າງອີງເຊິ່ງຮັບປະກັນວ່າມັນຖືກຕ້ອງ ສຳ ລັບການຂຽນ.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}