//! ການ ໝູນ ໃຊ້ສະຕິງ.
//!
//! ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ, ເບິ່ງເອກະສານ [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. ອອກຈາກຂອບເຂດ
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. ເລີ່ມຕົ້ນ <=ສິ້ນສຸດ
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. ເຂດແດນຕົວລະຄອນ
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // ຊອກຫາລັກສະນະ
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` ຈະຕ້ອງນ້ອຍກ່ວາ len ແລະເຂດແດນ char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// ສົ່ງຄືນຄວາມຍາວຂອງ `self`.
    ///
    /// ຄວາມຍາວນີ້ແມ່ນຢູ່ໃນໄບ, ບໍ່ແມ່ນ [`char`] ຫຼື graphemes.
    /// ເວົ້າອີກຢ່າງ ໜຶ່ງ, ມັນອາດຈະບໍ່ແມ່ນສິ່ງທີ່ມະນຸດພິຈາລະນາຄວາມຍາວຂອງສາຍ.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // f f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// ຜົນໄດ້ຮັບ `true` ຖ້າ `self` ມີຄວາມຍາວຂອງສູນ bytes ໄດ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ກວດເບິ່ງວ່າ `index`-th byte ແມ່ນໄບຕອ່ງ ທຳ ອິດໃນລະຫັດຈຸດ UTF-8 ຫຼືຈຸດຈົບຂອງສາຍ.
    ///
    ///
    /// ຈຸດເລີ່ມຕົ້ນແລະສິ້ນສຸດຂອງສາຍສະຕິງ (ເມື່ອ `ດັດສະນີ== self.len()`) ຖືກຖືວ່າເປັນເຂດແດນ.
    ///
    /// ສົ່ງຄືນ `false` ຖ້າ `index` ໃຫຍ່ກວ່າ `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // ເລີ່ມຕົ້ນຂອງ `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // ໄບທີສອງຂອງ `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // ໄບທີສາມຂອງ `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 ແລະ len ແມ່ນສະເຫມີງາມ.
        // ທົດສອບ 0 ຢ່າງຈະແຈ້ງເພື່ອໃຫ້ມັນສາມາດເພີ່ມປະສິດທິພາບໃນການກວດເຊັກໄດ້ງ່າຍແລະຂ້າມການອ່ານຂໍ້ມູນສະຕິງ ສຳ ລັບກໍລະນີນັ້ນ.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // ນີ້ແມ່ນເວດມົນເທົ່າກັບ: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// ປ່ຽນສາຍເຊືອກເປັນທ່ອນໄບ.
    /// ເພື່ອປ່ຽນແຜ່ນໄບໂດຍການກັບຄືນມາເປັນທ່ອນຊ່ອຍແນ່, ໃຫ້ໃຊ້ຟັງຊັນ [`from_utf8`].
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // ຄວາມປອດໄພ: ສຽງດີເພາະວ່າພວກເຮົາສົ່ງສອງແບບດ້ວຍແບບແຜນດຽວກັນ
        unsafe { mem::transmute(self) }
    }

    /// ແປງເປັນຫຼັງຈາກນັ້ນນໍາ string ບໍ່ແນ່ນອນກັບຫຼັງຈາກນັ້ນນໍາ byte ບໍ່ແນ່ນອນ.
    ///
    /// # Safety
    ///
    /// ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າເນື້ອໃນຂອງແຜ່ນແມ່ນຖືກຕ້ອງ UTF-8 ກ່ອນທີ່ເງິນກູ້ຈະສິ້ນສຸດລົງແລະ `str` ທີ່ຕິດພັນຖືກ ນຳ ໃຊ້.
    ///
    ///
    /// ການ ນຳ ໃຊ້ `str` ເຊິ່ງເນື້ອຫາຂອງມັນບໍ່ຖືກຕ້ອງ UTF-8 ແມ່ນພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // ຄວາມປອດໄພ: ການຫລໍ່ຈາກ `&str` ຫາ `&[u8]` ແມ່ນປອດໄພຕັ້ງແຕ່ `str`
        // ມີຮູບລັກເຊັ່ນດຽວກັນກັບ `&[u8]` (libstd ພຽງແຕ່ສາມາດເຮັດໃຫ້ການຄໍ້າປະກັນນີ້).
        // ການອ້າງອິງຕົວຊີ້ແມ່ນປອດໄພເພາະວ່າມັນມາຈາກການອ້າງອິງທີ່ປ່ຽນແປງໄດ້ເຊິ່ງຮັບປະກັນວ່າມັນຖືກຕ້ອງ ສຳ ລັບການຂຽນ.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// ປ່ຽນສາຍເຊືອກເປັນຕົວຊີ້ວັດຖຸດິບ.
    ///
    /// ໃນຖານະເປັນ string ຫຼັງຈາກນັ້ນນໍາແມ່ນເປັນຫຼັງຈາກນັ້ນນໍາຂອງໄບຕ໌, ຈຸດຊີ້ວັດຖຸດິບເພື່ອການ [`u8`].
    /// ຕົວຊີ້ນີ້ຈະຖືກຊີ້ໄປຫາໄບຕິງ ທຳ ອິດຂອງການຕັດສາຍ.
    ///
    /// ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າຕົວຊີ້ທີ່ສົ່ງຄືນຈະບໍ່ຖືກຂຽນຫາ.
    /// ຖ້າທ່ານຕ້ອງການປ່ຽນເນື້ອໃນຂອງການຫຍິບສາຍ, ໃຫ້ໃຊ້ [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// ປ່ຽນສາຍເຊືອກທີ່ປ່ຽນໄດ້ເປັນທ່ອນ.
    ///
    /// ໃນຖານະເປັນ string ຫຼັງຈາກນັ້ນນໍາແມ່ນເປັນຫຼັງຈາກນັ້ນນໍາຂອງໄບຕ໌, ຈຸດຊີ້ວັດຖຸດິບເພື່ອການ [`u8`].
    /// ຕົວຊີ້ນີ້ຈະຖືກຊີ້ໄປຫາໄບຕິງ ທຳ ອິດຂອງການຕັດສາຍ.
    ///
    /// ມັນແມ່ນຄວາມຮັບຜິດຊອບຂອງທ່ານເພື່ອໃຫ້ແນ່ໃຈວ່າການຕັດສະຕິງພຽງແຕ່ໄດ້ຮັບການແກ້ໄຂໃນທາງທີ່ມັນຍັງຄົງຖືກຕ້ອງ UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// ສົ່ງຄືນຄ່າຍ່ອຍຂອງ `str`.
    ///
    /// ນີ້ແມ່ນທາງເລືອກທີ່ບໍ່ມີຄວາມຢ້ານກົວຕໍ່ການດັດສະນີ `str`.
    /// ສົ່ງຄືນ [`None`] ທຸກຄັ້ງທີ່ປະຕິບັດການດັດສະນີທຽບເທົ່າເທົ່າກັບ panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // ຕົວຊີ້ວັດບໍ່ໄດ້ຢູ່ໃນຂອບເຂດ ລຳ ດັບ UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // ອອກຈາກຂອບເຂດ
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// ຜົນໄດ້ຮັບເປັນ subslice ບໍ່ແນ່ນອນຂອງ `str`.
    ///
    /// ນີ້ແມ່ນທາງເລືອກທີ່ບໍ່ມີຄວາມຢ້ານກົວຕໍ່ການດັດສະນີ `str`.
    /// ສົ່ງຄືນ [`None`] ທຸກຄັ້ງທີ່ປະຕິບັດການດັດສະນີທຽບເທົ່າເທົ່າກັບ panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // ຄວາມຍາວທີ່ຖືກຕ້ອງ
    /// assert!(v.get_mut(0..5).is_some());
    /// // ອອກຈາກຂອບເຂດ
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// ກັບຄືນຄ່າຍ່ອຍທີ່ບໍ່ຖືກກວດກາຂອງ `str`.
    ///
    /// ນີ້ແມ່ນທາງເລືອກທີ່ມີການກວດກາການຈັດດັດສະນີການ `str`.
    ///
    /// # Safety
    ///
    /// ຜູ້ໂທຂອງ ໜ້າ ທີ່ນີ້ຮັບຜິດຊອບວ່າຂໍ້ ກຳ ນົດເຫຼົ່ານີ້ພໍໃຈ:
    ///
    /// * ດັດສະນີເລີ່ມຕົ້ນບໍ່ຕ້ອງເກີນດັດຊະນີສິ້ນສຸດ;
    /// * ດັດສະນີຕ້ອງຢູ່ໃນຂອບເຂດຂອງເບື້ອງຕົ້ນ;
    /// * ດັດສະນີຕ້ອງນອນຢູ່ໃນຂອບເຂດ ລຳ ດັບ UTF-8.
    ///
    /// ຖ້າບໍ່ເຮັດດັ່ງນັ້ນ, ສາຍທີ່ຖືກສົ່ງກັບຄືນມາອາດຈະອ້າງເຖິງຄວາມຊົງ ຈຳ ທີ່ບໍ່ຖືກຕ້ອງຫຼືລະເມີດຂໍ້ມູນຕ່າງໆທີ່ຖືກສື່ສານໂດຍປະເພດ `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `get_unchecked`;
        // ຫຼັງຈາກນັ້ນນໍາແມ່ນ dereferencable ເນື່ອງຈາກວ່າ `self` ແມ່ນກະສານອ້າງອີງທີ່ປອດໄພ.
        // ຕົວຊີ້ໄດ້ກັບຄືນມີຄວາມປອດໄພເພາະວ່າ impl ຂອງ `SliceIndex` ຕ້ອງຮັບປະກັນວ່າມັນແມ່ນ.
        unsafe { &*i.get_unchecked(self) }
    }

    /// ສົ່ງຄືນຍ່ອຍທີ່ບໍ່ສາມາດຄວບຄຸມໄດ້ຂອງ `str`.
    ///
    /// ນີ້ແມ່ນທາງເລືອກທີ່ມີການກວດກາການຈັດດັດສະນີການ `str`.
    ///
    /// # Safety
    ///
    /// ຜູ້ໂທຂອງ ໜ້າ ທີ່ນີ້ຮັບຜິດຊອບວ່າຂໍ້ ກຳ ນົດເຫຼົ່ານີ້ພໍໃຈ:
    ///
    /// * ດັດສະນີເລີ່ມຕົ້ນບໍ່ຕ້ອງເກີນດັດຊະນີສິ້ນສຸດ;
    /// * ດັດສະນີຕ້ອງຢູ່ໃນຂອບເຂດຂອງເບື້ອງຕົ້ນ;
    /// * ດັດສະນີຕ້ອງນອນຢູ່ໃນຂອບເຂດ ລຳ ດັບ UTF-8.
    ///
    /// ຖ້າບໍ່ເຮັດດັ່ງນັ້ນ, ສາຍທີ່ຖືກສົ່ງກັບຄືນມາອາດຈະອ້າງເຖິງຄວາມຊົງ ຈຳ ທີ່ບໍ່ຖືກຕ້ອງຫຼືລະເມີດຂໍ້ມູນຕ່າງໆທີ່ຖືກສື່ສານໂດຍປະເພດ `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `get_unchecked_mut`;
        // ຫຼັງຈາກນັ້ນນໍາແມ່ນ dereferencable ເນື່ອງຈາກວ່າ `self` ແມ່ນກະສານອ້າງອີງທີ່ປອດໄພ.
        // ຕົວຊີ້ໄດ້ກັບຄືນມີຄວາມປອດໄພເພາະວ່າ impl ຂອງ `SliceIndex` ຕ້ອງຮັບປະກັນວ່າມັນແມ່ນ.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// ສ້າງເສັ້ນລວດຈາກເຊືອກອື່ນ, ໂດຍຜ່ານການກວດສອບຄວາມປອດໄພ.
    ///
    /// ໂດຍທົ່ວໄປນີ້ບໍ່ໄດ້ຖືກແນະ ນຳ ໃຫ້ໃຊ້, ລະມັດລະວັງ!ສຳ ລັບທາງເລືອກທີ່ປອດໄພເຫັນ [`str`] ແລະ [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// ກະດານລຸ້ນ ໃໝ່ ນີ້ແມ່ນມາຈາກ `begin` ຫາ `end`, ລວມທັງ `begin` ແຕ່ບໍ່ລວມ `end`.
    ///
    /// ເພື່ອໃຫ້ມີການສັບປ່ຽນສາຍສະຕິງແທນ, ເບິ່ງວິທີ [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// ແປໄດ້ທຸຂອງການທໍາງານນີ້ແມ່ນຮັບຜິດຊອບທີ່ສາມເງື່ອນໄຂມີຄວາມພໍໃຈ:
    ///
    /// * `begin` ຕ້ອງບໍ່ເກີນ `end`.
    /// * `begin` ແລະ `end` ຕ້ອງເປັນ ຕຳ ແໜ່ງ byte ພາຍໃນສ່ວນຂອງສະຕິງ.
    /// * `begin` ແລະ `end` ຕ້ອງນອນຢູ່ໃນຂອບເຂດ ລຳ ດັບ UTF-8.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `get_unchecked`;
        // ຫຼັງຈາກນັ້ນນໍາແມ່ນ dereferencable ເນື່ອງຈາກວ່າ `self` ແມ່ນກະສານອ້າງອີງທີ່ປອດໄພ.
        // ຕົວຊີ້ໄດ້ກັບຄືນມີຄວາມປອດໄພເພາະວ່າ impl ຂອງ `SliceIndex` ຕ້ອງຮັບປະກັນວ່າມັນແມ່ນ.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// ສ້າງເສັ້ນລວດຈາກເຊືອກອື່ນ, ໂດຍຜ່ານການກວດສອບຄວາມປອດໄພ.
    /// ໂດຍທົ່ວໄປນີ້ບໍ່ໄດ້ຖືກແນະ ນຳ ໃຫ້ໃຊ້, ລະມັດລະວັງ!ສຳ ລັບທາງເລືອກທີ່ປອດໄພເຫັນ [`str`] ແລະ [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// ກະດານລຸ້ນ ໃໝ່ ນີ້ແມ່ນມາຈາກ `begin` ຫາ `end`, ລວມທັງ `begin` ແຕ່ບໍ່ລວມ `end`.
    ///
    /// ເພື່ອໃຫ້ໄດ້ຊິ້ນເຊືອກທີ່ບໍ່ສາມາດປ່ຽນແປງໄດ້ແທນ, ເບິ່ງວິທີ [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// ແປໄດ້ທຸຂອງການທໍາງານນີ້ແມ່ນຮັບຜິດຊອບທີ່ສາມເງື່ອນໄຂມີຄວາມພໍໃຈ:
    ///
    /// * `begin` ຕ້ອງບໍ່ເກີນ `end`.
    /// * `begin` ແລະ `end` ຕ້ອງເປັນ ຕຳ ແໜ່ງ byte ພາຍໃນສ່ວນຂອງສະຕິງ.
    /// * `begin` ແລະ `end` ຕ້ອງນອນຢູ່ໃນຂອບເຂດ ລຳ ດັບ UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `get_unchecked_mut`;
        // ຫຼັງຈາກນັ້ນນໍາແມ່ນ dereferencable ເນື່ອງຈາກວ່າ `self` ແມ່ນກະສານອ້າງອີງທີ່ປອດໄພ.
        // ຕົວຊີ້ໄດ້ກັບຄືນມີຄວາມປອດໄພເພາະວ່າ impl ຂອງ `SliceIndex` ຕ້ອງຮັບປະກັນວ່າມັນແມ່ນ.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// ແບ່ງສາຍເຊືອກ ໜຶ່ງ ອອກເປັນສອງອັນໃນດັດຊະນີ.
    ///
    /// ການໂຕ້ຖຽງ, `mid`, ຄວນຈະເປັນການຊົດເຊີຍ byte ຈາກການເລີ່ມຕົ້ນຂອງສາຍ.
    /// ມັນຍັງຕ້ອງຢູ່ໃນເຂດແດນຂອງຈຸດລະຫັດ UTF-8.
    ///
    /// ທັງສອງຊິ້ນໄດ້ກັບຄືນໄປຈາກຈຸດເລີ່ມຕົ້ນຂອງການຕັດສາຍສະຕິງໄປເປັນ `mid`, ແລະຈາກ `mid` ຫາທ້າຍຂອງການຕັດຂອງສາຍ.
    ///
    /// ເພື່ອໃຫ້ໄດ້ຮັບຫຼັງຈາກນັ້ນນໍາ string ບໍ່ແນ່ນອນແທນທີ່ຈະ, ເບິ່ງວິທີການ [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `mid` ບໍ່ຢູ່ໃນຂອບເຂດຈຸດລະຫັດ UTF-8, ຫຼືຖ້າມັນຢູ່ ເໜືອ ຈຸດສຸດທ້າຍຂອງຈຸດລະຫັດສຸດທ້າຍຂອງການຕັດສາຍ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary ກວດເບິ່ງວ່າດັດຊະນີແມ່ນຢູ່ໃນ [0, .len()]
        if self.is_char_boundary(mid) {
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດເບິ່ງວ່າ `mid` ແມ່ນຢູ່ໃນເຂດແດນ char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ແບ່ງສາຍເຊືອກທີ່ປ່ຽນແປງໄດ້ ໜຶ່ງ ສ່ວນເປັນສອງອັນໃນດັດຊະນີ.
    ///
    /// ການໂຕ້ຖຽງ, `mid`, ຄວນຈະເປັນການຊົດເຊີຍ byte ຈາກການເລີ່ມຕົ້ນຂອງສາຍ.
    /// ມັນຍັງຕ້ອງຢູ່ໃນເຂດແດນຂອງຈຸດລະຫັດ UTF-8.
    ///
    /// ທັງສອງຊິ້ນໄດ້ກັບຄືນໄປຈາກຈຸດເລີ່ມຕົ້ນຂອງການຕັດສາຍສະຕິງໄປເປັນ `mid`, ແລະຈາກ `mid` ຫາທ້າຍຂອງການຕັດຂອງສາຍ.
    ///
    /// ເພື່ອໃຫ້ໄດ້ຊິ້ນເຊືອກທີ່ບໍ່ປ່ຽນແປງແທນ, ເບິ່ງວິທີ [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `mid` ບໍ່ຢູ່ໃນຂອບເຂດຈຸດລະຫັດ UTF-8, ຫຼືຖ້າມັນຢູ່ ເໜືອ ຈຸດສຸດທ້າຍຂອງຈຸດລະຫັດສຸດທ້າຍຂອງການຕັດສາຍ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary ກວດເບິ່ງວ່າດັດຊະນີແມ່ນຢູ່ໃນ [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // ຄວາມປອດໄພ: ພຽງແຕ່ກວດເບິ່ງວ່າ `mid` ແມ່ນຢູ່ໃນເຂດແດນ char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ສົ່ງຄືນເຄື່ອງປັບໃນ [`char`] ຂອງຊິ້ນເຊືອກ.
    ///
    /// ໃນຖານະເປັນຫຼັງຈາກນັ້ນນໍາ string ປະກອບດ້ວຍ UTF-8 ຖືກຕ້ອງ, ພວກເຮົາສາມາດ iterate ຜ່ານການຫຼັງຈາກນັ້ນນໍາ string ໂດຍ [`char`].
    /// ວິທີການນີ້ຈະສົ່ງຄືນຕົວແກ້ໄຂດັ່ງກ່າວ.
    ///
    /// ມັນເປັນສິ່ງສໍາຄັນເພື່ອຈື່ຈໍາວ່າ [`char`] ເປັນຕົວແທນເປັນເກລາມູນຄ່າ Unicode, ແລະອາດຈະບໍ່ກົງກັບຄວາມຄິດຂອງທ່ານໃນສິ່ງທີ່ເປັນ 'character' ແມ່ນ.
    ///
    /// ການຫລອກລວງກ່ຽວກັບກຸ່ມແກັບອາດຈະເປັນສິ່ງທີ່ທ່ານຕ້ອງການຕົວຈິງ.
    /// ຟັງຊັນນີ້ບໍ່ໄດ້ຖືກສະ ໜອງ ໃຫ້ໂດຍຫ້ອງສະ ໝຸດ ມາດຕະຖານຂອງ Rust, ກວດເບິ່ງ crates.io ແທນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// ຈົ່ງຈື່ໄວ້, [`char`] ອາດຈະບໍ່ກົງກັບເຈດຕະນາຂອງທ່ານກ່ຽວກັບຕົວລະຄອນ:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ບໍ່ 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// ສົ່ງຄືນເຄື່ອງ ໝາຍ ໃສ່ [`char`] ຂອງຊິ້ນເຊືອກ, ແລະ ຕຳ ແໜ່ງ ຂອງພວກມັນ.
    ///
    /// ໃນຖານະເປັນຫຼັງຈາກນັ້ນນໍາ string ປະກອບດ້ວຍ UTF-8 ຖືກຕ້ອງ, ພວກເຮົາສາມາດ iterate ຜ່ານການຫຼັງຈາກນັ້ນນໍາ string ໂດຍ [`char`].
    /// ວິທີການນີ້ຈະສົ່ງຄືນສິ່ງທັງສອງຂອງ [`char`], ພ້ອມທັງ ຕຳ ແໜ່ງ ຂອງພວກເຂົາ.
    ///
    /// The iterator yields Tuples.ຕໍາແຫນ່ງແມ່ນຄັ້ງທໍາອິດ, [`char`] ແມ່ນທີສອງ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// ຈົ່ງຈື່ໄວ້, [`char`] ອາດຈະບໍ່ກົງກັບເຈດຕະນາຂອງທ່ານກ່ຽວກັບຕົວລະຄອນ:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ບໍ່ (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // ສັງເກດ 3 ຢູ່ນີ້, ໂຕອັກສອນສຸດທ້າຍໄດ້ເພີ່ມຂື້ນສອງໄບ
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// ຕົວຊີ້ທິດທາງໃນໄລຍະໄບຂອງເສັ້ນຊ່ອຍແນ່.
    ///
    /// ໃນຖານະເປັນຫຼັງຈາກນັ້ນນໍາ string ປະກອບດ້ວຍລໍາດັບຂອງໄບຕ໌, ພວກເຮົາສາມາດ iterate ຜ່ານການຫຼັງຈາກນັ້ນນໍາ string ໂດຍ byte.
    /// ວິທີການນີ້ຈະສົ່ງຄືນຕົວແກ້ໄຂດັ່ງກ່າວ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// ແບ່ງສາຍເຊືອກເປັນທ່ອນໂດຍ whitespace.
    ///
    /// ຕົວປ່ຽນແປງທີ່ສົ່ງກັບມາຈະສົ່ງກັບຄືນສາຍເຊືອກທີ່ເປັນສ່ວນນ້ອຍໆຂອງສາຍສະຕິງເດີມ, ແຍກອອກຈາກປະລິມານໃດໆ.
    ///
    ///
    /// 'Whitespace' ຖືກ ກຳ ນົດຕາມຂໍ້ ກຳ ນົດຂອງ `White_Space` Unicode Derived Core Property.
    /// ຖ້າທ່ານຕ້ອງການແບ່ງປັນໃນ ASCII whitespace ແທນ, ໃຫ້ໃຊ້ [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ທຸກປະເພດຂອງ whitespace ແມ່ນພິຈາລະນາ:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// ແບ່ງສາຍເຊືອກໂດຍ ASCII whitespace.
    ///
    /// ຕົວປ່ຽນແປງທີ່ສົ່ງກັບມາຈະສົ່ງກັບຄືນແຖວເຊືອກທີ່ເປັນສ່ວນນ້ອຍໆຂອງສາຍສະຕິງເດີມ, ແຍກອອກຈາກ ຈຳ ນວນ ASCII whitespace ໃດໆ.
    ///
    ///
    /// ເພື່ອແຍກໂດຍ Unicode `Whitespace` ແທນ, ໃຫ້ໃຊ້ [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ທຸກປະເພດຂອງ ASCII ຊ່ອງຫວ່າງກໍາລັງພິຈາລະນາ:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// ເຄື່ອງປັບໃນໄລຍະສາຍຂອງເຊືອກ, ເປັນສາຍເຊືອກ.
    ///
    /// ບັນດາສາຍຕ່າງໆໄດ້ສິ້ນສຸດລົງດ້ວຍສາຍ (`\n`) ໃໝ່ ຫລືການກັບຄືນລົດທີ່ມີສາຍ (`\r\n`).
    ///
    /// ການສິ້ນສຸດສາຍສຸດທ້າຍແມ່ນເປັນທາງເລືອກ.
    /// ສາຍທີ່ສິ້ນສຸດລົງດ້ວຍສາຍສຸດທ້າຍຈະກັບຄືນສາຍດຽວກັນກັບສາຍທີ່ຄ້າຍຄືກັນຖ້າບໍ່ມີສາຍສຸດທ້າຍ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// ສາຍສຸດທ້າຍບໍ່ ຈຳ ເປັນຕ້ອງ:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// ຕົວຍີ້ນໃນໄລຍະສາຍຂອງສາຍຊ່ອຍແນ່.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// ສົ່ງຄືນລະຫັດຂອງ `u16` ຜ່ານເຊືອກທີ່ເຂົ້າລະຫັດເປັນ UTF-16.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// ສົ່ງຄືນ `true` ຖ້າຮູບແບບທີ່ຖືກມອບໃຫ້ກົງກັບການແບ່ງສ່ວນຂອງສະຕິງນີ້.
    ///
    /// ສົ່ງຄືນ `false` ຖ້າມັນບໍ່.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// ສົ່ງຄືນ `true` ຖ້າຮູບແບບທີ່ຖືກມອບໃຫ້ກົງກັບ ຄຳ ນຳ ໜ້າ ຂອງ ຄຳ ສັບຊ່ອຍແນ່ນີ້.
    ///
    /// ສົ່ງຄືນ `false` ຖ້າມັນບໍ່.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// ສົ່ງຄືນ `true` ຖ້າຮູບແບບທີ່ໃຫ້ໄວ້ກົງກັບ ຄຳ ສັບຂອງສະຕິງນີ້.
    ///
    /// ສົ່ງຄືນ `false` ຖ້າມັນບໍ່.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// ສົ່ງກັບດັດຊະນີ byte ຂອງໂຕອັກສອນ ທຳ ອິດຂອງສະຕິງນີ້ທີ່ກົງກັບຮູບແບບ.
    ///
    /// ສົ່ງຄືນ [`None`] ຖ້າຮູບແບບບໍ່ກົງກັນ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ຮູບແບບງ່າຍໆ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// ຮູບແບບທີ່ສັບສົນກວ່າເກົ່າໂດຍໃຊ້ຮູບແບບທີ່ບໍ່ມີຈຸດແລະປິດ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// ບໍ່ພົບຮູບແບບ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// ສົ່ງຄືນດັດຊະນີໄບຕ໌ ສຳ ລັບໂຕອັກສອນ ທຳ ອິດຂອງ ຄຳ ທີ່ກົງກັນທີ່ສຸດຂອງຮູບແບບໃນແຖບສະຕິງນີ້.
    ///
    /// ສົ່ງຄືນ [`None`] ຖ້າຮູບແບບບໍ່ກົງກັນ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ຮູບແບບງ່າຍໆ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// ຮູບແບບທີ່ສັບສົນກວ່າເກົ່າດ້ວຍການປິດ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// ບໍ່ພົບຮູບແບບ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// ຕົວຊີ້ທິດທາງເທິງສາຍນ້ອຍໆຂອງສາຍສະຕິງນີ້, ແຍກອອກຈາກຕົວອັກສອນທີ່ສອດຄ່ອງກັບຮູບແບບ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ພຶດຕິ ກຳ ຂອງຜູ້ ນຳ ໃຊ້
    ///
    /// ຕົວປ່ຽນແປງທີ່ສົ່ງຄືນຈະເປັນ [`DoubleEndedIterator`] ຖ້າຮູບແບບດັ່ງກ່າວອະນຸຍາດໃຫ້ມີການຄົ້ນຫາແບບລ້າໆແລະຜົນການຊອກຫາ forward/reverse ກໍ່ໃຫ້ເກີດບັນດາອົງປະກອບດຽວກັນ.
    /// ນີ້ແມ່ນຄວາມຈິງ ສຳ ລັບຕົວຢ່າງ [`char`], ແຕ່ບໍ່ແມ່ນ ສຳ ລັບ `&str`.
    ///
    /// ຖ້າຮູບແບບດັ່ງກ່າວອະນຸຍາດໃຫ້ມີການຄົ້ນຫາແບບລ້າໆແຕ່ວ່າຜົນໄດ້ຮັບຂອງມັນອາດຈະແຕກຕ່າງຈາກການຄົ້ນຫາຕໍ່ ໜ້າ, ວິທີ [`rsplit`] ສາມາດໃຊ້ໄດ້.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// ຮູບແບບງ່າຍໆ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// ຖ້າຮູບແບບເປັນສ່ວນ ໜຶ່ງ ຂອງຕາຕະລາງ, ແບ່ງປັນຕາມແຕ່ລະຕົວອັກສອນທີ່ເກີດຂື້ນ:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// ຮູບແບບທີ່ສັບສົນກວ່າ, ໂດຍໃຊ້ແບບປິດ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// ຖ້າຫາກວ່າສະຕິງມີຕົວແຍກທີ່ຕິດຕໍ່ກັນຫຼາຍທ່ານຈະສິ້ນສຸດດ້ວຍສາຍເປົ່າໃນຜົນຜະລິດ:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// ຕົວແຍກທີ່ຕິດຕໍ່ກັນຖືກແຍກອອກໂດຍສາຍເປົ່າ.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// ສາຍແຍກໃນຕອນເລີ່ມຕົ້ນຫລືປາຍສາຍແມ່ນຢູ່ໃກ້ຄຽງກັບສາຍເປົ່າ.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// ເມື່ອສະຕິງເປົ່າຖືກໃຊ້ເປັນຕົວແຍກ, ມັນຈະແຍກຕົວລະຄອນທຸກຕົວໃນສາຍ, ພ້ອມກັບສາຍເລີ່ມຕົ້ນແລະປາຍ.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// ຕົວແຍກທີ່ຕິດຕໍ່ກັນສາມາດນໍາໄປສູ່ການປະພຶດທີ່ຫນ້າປະຫລາດໃຈໃນເວລາທີ່ whitespace ຖືກນໍາໃຊ້ເປັນຕົວແຍກ.ລະຫັດນີ້ແມ່ນຖືກຕ້ອງ:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// ມັນບໍ່ _not_ ໃຫ້ທ່ານ:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// ໃຊ້ [`split_whitespace`] ສຳ ລັບພຶດຕິ ກຳ ນີ້.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// ຕົວຊີ້ທິດທາງເທິງສາຍນ້ອຍໆຂອງສາຍສະຕິງນີ້, ແຍກອອກຈາກຕົວອັກສອນທີ່ສອດຄ່ອງກັບຮູບແບບ.
    /// ຈຸດທີ່ແຕກຕ່າງຈາກຕົວຊີ້ວັດທີ່ຜະລິດໂດຍ `split` ໃນນັ້ນ `split_inclusive` ອອກຈາກສ່ວນທີ່ຖືກຈັບຄູ່ເປັນຈຸດສິ້ນສຸດຂອງທໍ່ຮອງ.
    ///
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// ຖ້າສ່ວນປະກອບຂອງສະຕິງສຸດທ້າຍຖືກຈັບຄູ່, ອົງປະກອບນັ້ນຈະຖືກພິຈາລະນາເປັນຜູ້ສິ້ນສຸດຂອງສາຍຍ່ອຍກ່ອນຫນ້າ.
    /// ທໍ່ນັ້ນຈະເປັນລາຍການສຸດທ້າຍທີ່ສົ່ງຄືນໂດຍຜູ້ກວດກາ.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// ຕົວຊີ້ທິດທາງເທິງສາຍຍ່ອຍຂອງສ່ວນເຊືອກທີ່ໃຫ້, ແຍກຕາມຕົວອັກສອນທີ່ສອດຄ່ອງກັບຮູບແບບແລະໃຫ້ຜົນຜະລິດຕາມ ລຳ ດັບ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ພຶດຕິ ກຳ ຂອງຜູ້ ນຳ ໃຊ້
    ///
    /// ຕົວປ່ຽນແປງທີ່ສົ່ງກັບຄືນຮຽກຮ້ອງໃຫ້ຮູບແບບດັ່ງກ່າວສະ ໜັບ ສະ ໜູນ ການຄົ້ນຫາດ້ານຫຼັງ, ແລະມັນຈະເປັນ [`DoubleEndedIterator`] ຖ້າການຄົ້ນຫາ forward/reverse ຈະໃຫ້ຜົນຜະລິດຂອງອົງປະກອບດຽວກັນ.
    ///
    ///
    /// ສໍາລັບ iterating ຈາກຫນ້າທີ່, ວິທີການ [`split`] ສາມາດຖືກນໍາໃຊ້.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// ຮູບແບບງ່າຍໆ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// ຮູບແບບທີ່ສັບສົນກວ່າ, ໂດຍໃຊ້ແບບປິດ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// ຕົວຊີ້ທິດທາງເທິງສາຍຍ່ອຍຂອງສ່ວນເຊືອກທີ່ໃຫ້, ແຍກຕາມຕົວອັກສອນທີ່ສອດຄ່ອງກັບຮູບແບບ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// ທຽບເທົ່າກັບ [`split`], ເວັ້ນເສຍແຕ່ວ່າທໍ່ຮອງເສັ້ນທາງຖືກຂ້າມຖ້າເປົ່າ.
    ///
    /// [`split`]: str::split
    ///
    /// ວິທີການນີ້ສາມາດໄດ້ຮັບການນໍາໃຊ້ສໍາລັບຂໍ້ມູນ string ທີ່ _terminated_, ແທນທີ່ຈະກ່ວາ _separated_ ໂດຍຮູບແບບ.
    ///
    /// # ພຶດຕິ ກຳ ຂອງຜູ້ ນຳ ໃຊ້
    ///
    /// ຕົວປ່ຽນແປງທີ່ສົ່ງຄືນຈະເປັນ [`DoubleEndedIterator`] ຖ້າຮູບແບບດັ່ງກ່າວອະນຸຍາດໃຫ້ມີການຄົ້ນຫາແບບລ້າໆແລະຜົນການຊອກຫາ forward/reverse ກໍ່ໃຫ້ເກີດບັນດາອົງປະກອບດຽວກັນ.
    /// ນີ້ແມ່ນຄວາມຈິງ ສຳ ລັບຕົວຢ່າງ [`char`], ແຕ່ບໍ່ແມ່ນ ສຳ ລັບ `&str`.
    ///
    /// ຖ້າຮູບແບບດັ່ງກ່າວອະນຸຍາດໃຫ້ມີການຄົ້ນຫາແບບລ້າໆແຕ່ວ່າຜົນໄດ້ຮັບຂອງມັນອາດຈະແຕກຕ່າງຈາກການຄົ້ນຫາຕໍ່ ໜ້າ, ວິທີ [`rsplit_terminator`] ສາມາດໃຊ້ໄດ້.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// ຕົວຊີ້ທິດທາງໃນໄລຍະ substings ຂອງ `self`, ແຍກອອກໂດຍຕົວອັກສອນທີ່ຈັບຄູ່ກັບຮູບແບບແລະໃຫ້ຜົນຜະລິດຕາມ ລຳ ດັບ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// ທຽບເທົ່າກັບ [`split`], ເວັ້ນເສຍແຕ່ວ່າທໍ່ຮອງເສັ້ນທາງຖືກຂ້າມຖ້າເປົ່າ.
    ///
    /// [`split`]: str::split
    ///
    /// ວິທີການນີ້ສາມາດໄດ້ຮັບການນໍາໃຊ້ສໍາລັບຂໍ້ມູນ string ທີ່ _terminated_, ແທນທີ່ຈະກ່ວາ _separated_ ໂດຍຮູບແບບ.
    ///
    /// # ພຶດຕິ ກຳ ຂອງຜູ້ ນຳ ໃຊ້
    ///
    /// ຕົວປ່ຽນແປງທີ່ສົ່ງກັບຄືນຮຽກຮ້ອງໃຫ້ຮູບແບບດັ່ງກ່າວສະ ໜັບ ສະ ໜູນ ການຄົ້ນຫາແບບລ້າໆ, ແລະມັນຈະຖືກສິ້ນສຸດລົງສອງເທົ່າຖ້າວ່າການຄົ້ນຫາ forward/reverse ໃຫ້ຜົນຜະລິດດຽວກັນ.
    ///
    ///
    /// ສຳ ລັບການຍົກສູງຈາກທາງ ໜ້າ, ວິທີ [`split_terminator`] ສາມາດໃຊ້ໄດ້.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// ເຄື່ອງປັບອາກາດໃນໄລຍະຍ່ອຍຂອງສາຍສະຕິງທີ່ຖືກມອບໃຫ້, ແຍກດ້ວຍຮູບແບບ, ຖືກ ຈຳ ກັດໃນການກັບຄືນສິນຄ້າທີ່ `n` ສ່ວນໃຫຍ່.
    ///
    /// ຖ້າ XRX substings ຖືກສົ່ງກັບຄືນ, ສາຍສຸດທ້າຍ (`n`th ຍ່ອຍ) ຈະມີສ່ວນທີ່ເຫຼືອຂອງສາຍ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ພຶດຕິ ກຳ ຂອງຜູ້ ນຳ ໃຊ້
    ///
    /// ຕົວປະຕິບັດທີ່ສົ່ງຄືນຈະບໍ່ຖືກຢຸດສອງເທື່ອ, ເພາະວ່າມັນບໍ່ມີປະສິດທິພາບໃນການສະ ໜັບ ສະ ໜູນ.
    ///
    /// ຖ້າຮູບແບບດັ່ງກ່າວອະນຸຍາດໃຫ້ມີການຄົ້ນຫາແບບປີ້ນກັບກັນ, ວິທີ [`rsplitn`] ສາມາດໃຊ້ໄດ້.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// ຮູບແບບງ່າຍໆ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// ຮູບແບບທີ່ສັບສົນກວ່າ, ໂດຍໃຊ້ແບບປິດ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// ເຄື່ອງປັບອາກາດໃນໄລຍະສາຍຍ່ອຍຂອງສາຍສະຕິງແບບນີ້, ແຍກອອກໂດຍຮູບແບບ, ເລີ່ມຕົ້ນຈາກສິ້ນຂອງສາຍ, ຖືກ ຈຳ ກັດໃນການກັບຄືນມາທີ່ສິນຄ້າ `n` ສ່ວນໃຫຍ່.
    ///
    ///
    /// ຖ້າ XRX substings ຖືກສົ່ງກັບຄືນ, ສາຍສຸດທ້າຍ (`n`th ຍ່ອຍ) ຈະມີສ່ວນທີ່ເຫຼືອຂອງສາຍ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ພຶດຕິ ກຳ ຂອງຜູ້ ນຳ ໃຊ້
    ///
    /// ຕົວປະຕິບັດທີ່ສົ່ງຄືນຈະບໍ່ຖືກຢຸດສອງເທື່ອ, ເພາະວ່າມັນບໍ່ມີປະສິດທິພາບໃນການສະ ໜັບ ສະ ໜູນ.
    ///
    /// ສຳ ລັບແຍກຈາກທາງ ໜ້າ, ວິທີ [`splitn`] ສາມາດໃຊ້ໄດ້.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// ຮູບແບບງ່າຍໆ:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// ຮູບແບບທີ່ສັບສົນກວ່າ, ໂດຍໃຊ້ແບບປິດ:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// ແຍກສາຍກ່ຽວກັບການປະກົດຕົວຄັ້ງ ທຳ ອິດຂອງຜູ້ ກຳ ນົດຂອບເຂດທີ່ໄດ້ລະບຸແລະສົ່ງຄືນ ຄຳ ນຳ ໜ້າ ກ່ອນການ ກຳ ນົດເວລາແລະຫຼັງຈາກຫຼັງ ກຳ ນົດ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// ແຍກສາຍກ່ຽວກັບການປະກົດຕົວຄັ້ງສຸດທ້າຍຂອງຜູ້ ກຳ ນົດຂອບເຂດທີ່ໄດ້ລະບຸແລະສົ່ງຄືນ ຄຳ ນຳ ໜ້າ ກ່ອນການ ກຳ ນົດເວລາແລະຫຼັງຈາກຫຼັງ ກຳ ນົດ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// ເຄື່ອງປັບໃນໄລຍະການແຂ່ງຂັນທີ່ບໍ່ ເໝາະ ສົມຂອງຮູບແບບທີ່ຢູ່ໃນສ່ວນຂອງສາຍ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ພຶດຕິ ກຳ ຂອງຜູ້ ນຳ ໃຊ້
    ///
    /// ຕົວປ່ຽນແປງທີ່ສົ່ງຄືນຈະເປັນ [`DoubleEndedIterator`] ຖ້າຮູບແບບດັ່ງກ່າວອະນຸຍາດໃຫ້ມີການຄົ້ນຫາແບບລ້າໆແລະຜົນການຊອກຫາ forward/reverse ກໍ່ໃຫ້ເກີດບັນດາອົງປະກອບດຽວກັນ.
    /// ນີ້ແມ່ນຄວາມຈິງ ສຳ ລັບຕົວຢ່າງ [`char`], ແຕ່ບໍ່ແມ່ນ ສຳ ລັບ `&str`.
    ///
    /// ຖ້າຮູບແບບດັ່ງກ່າວອະນຸຍາດໃຫ້ມີການຄົ້ນຫາແບບລ້າໆແຕ່ວ່າຜົນໄດ້ຮັບຂອງມັນອາດຈະແຕກຕ່າງຈາກການຄົ້ນຫາຕໍ່ ໜ້າ, ວິທີ [`rmatches`] ສາມາດໃຊ້ໄດ້.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// ຕົວປ່ຽນແປງໃນໄລຍະການແຂ່ງຂັນທີ່ບໍ່ ເໝາະ ສົມຂອງຮູບແບບພາຍໃນສາຍເຊືອກນີ້, ໃຫ້ຜົນຜະລິດຕາມ ລຳ ດັບ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ພຶດຕິ ກຳ ຂອງຜູ້ ນຳ ໃຊ້
    ///
    /// ຕົວປ່ຽນແປງທີ່ສົ່ງກັບຄືນຮຽກຮ້ອງໃຫ້ຮູບແບບດັ່ງກ່າວສະ ໜັບ ສະ ໜູນ ການຄົ້ນຫາດ້ານຫຼັງ, ແລະມັນຈະເປັນ [`DoubleEndedIterator`] ຖ້າການຄົ້ນຫາ forward/reverse ຈະໃຫ້ຜົນຜະລິດຂອງອົງປະກອບດຽວກັນ.
    ///
    ///
    /// ສຳ ລັບການຍົກສູງຈາກທາງ ໜ້າ, ວິທີ [`matches`] ສາມາດໃຊ້ໄດ້.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// ຕົວປ່ຽນແປງໃນໄລຍະການແຂ່ງຂັນທີ່ບໍ່ສົມເຫດສົມຜົນຂອງຮູບແບບພາຍໃນສາຍສະຕິງນີ້ພ້ອມທັງດັດສະນີທີ່ການແຂ່ງຂັນເລີ່ມຕົ້ນ.
    ///
    /// ສຳ ລັບການຈັບຄູ່ຂອງ `pat` ພາຍໃນ `self` ທີ່ຊ້ ຳ ຊ້ອນກັນ, ມີພຽງແຕ່ຕົວຊີ້ວັດທີ່ສອດຄ້ອງກັນກັບການຈັບຄູ່ຄັ້ງ ທຳ ອິດເທົ່ານັ້ນ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ພຶດຕິ ກຳ ຂອງຜູ້ ນຳ ໃຊ້
    ///
    /// ຕົວປ່ຽນແປງທີ່ສົ່ງຄືນຈະເປັນ [`DoubleEndedIterator`] ຖ້າຮູບແບບດັ່ງກ່າວອະນຸຍາດໃຫ້ມີການຄົ້ນຫາແບບລ້າໆແລະຜົນການຊອກຫາ forward/reverse ກໍ່ໃຫ້ເກີດບັນດາອົງປະກອບດຽວກັນ.
    /// ນີ້ແມ່ນຄວາມຈິງ ສຳ ລັບຕົວຢ່າງ [`char`], ແຕ່ບໍ່ແມ່ນ ສຳ ລັບ `&str`.
    ///
    /// ຖ້າຮູບແບບດັ່ງກ່າວອະນຸຍາດໃຫ້ມີການຄົ້ນຫາແບບລ້າໆແຕ່ວ່າຜົນໄດ້ຮັບຂອງມັນອາດຈະແຕກຕ່າງຈາກການຄົ້ນຫາຕໍ່ ໜ້າ, ວິທີ [`rmatch_indices`] ສາມາດໃຊ້ໄດ້.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // ພຽງແຕ່ `aba` ທຳ ອິດເທົ່ານັ້ນ
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// ຕົວປະຕິບັດໃນໄລຍະການແຂ່ງຂັນທີ່ບໍ່ ເໝາະ ສົມຂອງຮູບແບບພາຍໃນ `self`, ໄດ້ໃຫ້ຜົນຜະລິດຕາມ ລຳ ດັບຍ້ອນພ້ອມກັບດັດສະນີຂອງການແຂ່ງຂັນ.
    ///
    /// ສຳ ລັບການຈັບຄູ່ຂອງ `pat` ພາຍໃນ `self` ທີ່ຊ້ ຳ ຊ້ອນກັນ, ມີພຽງແຕ່ຕົວຊີ້ບອກທີ່ສອດຄ້ອງກັບການແຂ່ງຂັນສຸດທ້າຍເທົ່ານັ້ນ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ພຶດຕິ ກຳ ຂອງຜູ້ ນຳ ໃຊ້
    ///
    /// ຕົວປ່ຽນແປງທີ່ສົ່ງກັບຄືນຮຽກຮ້ອງໃຫ້ຮູບແບບດັ່ງກ່າວສະ ໜັບ ສະ ໜູນ ການຄົ້ນຫາດ້ານຫຼັງ, ແລະມັນຈະເປັນ [`DoubleEndedIterator`] ຖ້າການຄົ້ນຫາ forward/reverse ຈະໃຫ້ຜົນຜະລິດຂອງອົງປະກອບດຽວກັນ.
    ///
    ///
    /// ສຳ ລັບການຍົກສູງຈາກທາງ ໜ້າ, ວິທີ [`match_indices`] ສາມາດໃຊ້ໄດ້.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // ພຽງແຕ່ `aba` ສຸດທ້າຍເທົ່ານັ້ນ
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// ກັບຄືນສ່ວນເຊືອກທີ່ມີ whitespace ຊັ້ນນໍາແລະຕິດຕາມ.
    ///
    /// 'Whitespace' ຖືກ ກຳ ນົດຕາມຂໍ້ ກຳ ນົດຂອງ `White_Space` Unicode Derived Core Property.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// ກັບຄືນສ່ວນເຊືອກທີ່ມີ whitespace ຊັ້ນ ນຳ.
    ///
    /// 'Whitespace' ຖືກ ກຳ ນົດຕາມຂໍ້ ກຳ ນົດຂອງ `White_Space` Unicode Derived Core Property.
    ///
    /// # ທິດທາງຂໍ້ຄວາມ
    ///
    /// ສະຕິງແມ່ນ ລຳ ດັບຂອງໄບຕ໌.
    /// `start` ໃນສະພາບການນີ້ ໝາຍ ເຖິງ ຕຳ ແໜ່ງ ທຳ ອິດຂອງສະຕິງວ່າ;ສຳ ລັບພາສາດ້ານຊ້າຍຫາຂວາເຊັ່ນພາສາອັງກິດຫລືພາສາລັດເຊຍ, ນີ້ຈະເປັນເບື້ອງຊ້າຍ, ແລະ ສຳ ລັບພາສາດ້ານຂວາຫາຊ້າຍເຊັ່ນພາສາອາຣັບຫລືພາສາຍິວ, ນີ້ຈະເປັນຝ່າຍຂວາ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// ກັບຄືນສ່ວນເຊືອກທີ່ມີ whitespace ຖືກຖອດອອກ.
    ///
    /// 'Whitespace' ຖືກ ກຳ ນົດຕາມຂໍ້ ກຳ ນົດຂອງ `White_Space` Unicode Derived Core Property.
    ///
    /// # ທິດທາງຂໍ້ຄວາມ
    ///
    /// ສະຕິງແມ່ນ ລຳ ດັບຂອງໄບຕ໌.
    /// `end` ໃນສະພາບການນີ້ ໝາຍ ເຖິງ ຕຳ ແໜ່ງ ສຸດທ້າຍຂອງສະຕິງວ່າ;ສຳ ລັບພາສາດ້ານຊ້າຍຫາຂວາເຊັ່ນພາສາອັງກິດຫລືພາສາລັດເຊຍ, ນີ້ຈະເປັນຝ່າຍຂວາ, ແລະ ສຳ ລັບພາສາດ້ານຂວາຫາຊ້າຍເຊັ່ນພາສາອາຣັບຫລືພາສາຍິວ, ນີ້ຈະເປັນເບື້ອງຊ້າຍ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// ກັບຄືນສ່ວນເຊືອກທີ່ມີ whitespace ຊັ້ນ ນຳ.
    ///
    /// 'Whitespace' ຖືກ ກຳ ນົດຕາມຂໍ້ ກຳ ນົດຂອງ `White_Space` Unicode Derived Core Property.
    ///
    /// # ທິດທາງຂໍ້ຄວາມ
    ///
    /// ສະຕິງແມ່ນ ລຳ ດັບຂອງໄບຕ໌.
    /// 'Left' ໃນສະພາບການນີ້ ໝາຍ ເຖິງ ຕຳ ແໜ່ງ ທຳ ອິດຂອງສະຕິງວ່າ;ສຳ ລັບພາສາເຊັ່ນພາສາອາຣັບຫລືພາສາເຮັບເຣີເຊິ່ງມີ 'ຂວາຫາຊ້າຍ' ຫລາຍກວ່າ 'ຊ້າຍຫາຂວາ', ນີ້ຈະແມ່ນເບື້ອງ _right_, ບໍ່ແມ່ນດ້ານຊ້າຍ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// ກັບຄືນສ່ວນເຊືອກທີ່ມີ whitespace ຖືກຖອດອອກ.
    ///
    /// 'Whitespace' ຖືກ ກຳ ນົດຕາມຂໍ້ ກຳ ນົດຂອງ `White_Space` Unicode Derived Core Property.
    ///
    /// # ທິດທາງຂໍ້ຄວາມ
    ///
    /// ສະຕິງແມ່ນ ລຳ ດັບຂອງໄບຕ໌.
    /// 'Right' ໃນສະພາບການນີ້ ໝາຍ ເຖິງ ຕຳ ແໜ່ງ ສຸດທ້າຍຂອງສະຕິງວ່າ;ສຳ ລັບພາສາເຊັ່ນພາສາອາຣັບຫລືພາສາເຮັບເຣີເຊິ່ງມີ 'ຂວາຫາຊ້າຍ' ຫລາຍກວ່າ 'ຊ້າຍຫາຂວາ', ນີ້ຈະແມ່ນດ້ານ _left_, ບໍ່ແມ່ນດ້ານຂວາ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// ສົ່ງຄືນສ່ວນທີ່ໃຊ້ຊ່ອຍແນ່ພ້ອມກັບ ຄຳ ນຳ ໜ້າ ແລະ ຄຳ ຕໍ່ທ້າຍທັງ ໝົດ ທີ່ກົງກັບຮູບແບບທີ່ຊ້ ຳ ແລ້ວຊ້ ຳ ອີກ.
    ///
    /// [pattern] ສາມາດເປັນ [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫຼືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ຮູບແບບງ່າຍໆ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// ຮູບແບບທີ່ສັບສົນກວ່າ, ໂດຍໃຊ້ແບບປິດ:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // ຈືຂໍ້ມູນການຈັບຄູ່ທີ່ຮູ້ຈັກກ່ອນ, ແກ້ໄຂມັນຢູ່ດ້ານລຸ່ມຖ້າ
            // ການແຂ່ງຂັນສຸດທ້າຍແມ່ນແຕກຕ່າງກັນ
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ຄວາມປອດໄພ: `Searcher` ແມ່ນເປັນທີ່ຮູ້ຈັກທີ່ຈະກັບຄືນຕົວຊີ້ບອກທີ່ຖືກຕ້ອງ.
        unsafe { self.get_unchecked(i..j) }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ໃຊ້ຊ່ອຍແນ່ກັບ ຄຳ ນຳ ໜ້າ ທັງ ໝົດ ທີ່ກົງກັບຮູບແບບທີ່ຖືກຍ້າຍອອກໄປເລື້ອຍໆ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ທິດທາງຂໍ້ຄວາມ
    ///
    /// ສະຕິງແມ່ນ ລຳ ດັບຂອງໄບຕ໌.
    /// `start` ໃນສະພາບການນີ້ ໝາຍ ເຖິງ ຕຳ ແໜ່ງ ທຳ ອິດຂອງສະຕິງວ່າ;ສຳ ລັບພາສາດ້ານຊ້າຍຫາຂວາເຊັ່ນພາສາອັງກິດຫລືພາສາລັດເຊຍ, ນີ້ຈະເປັນເບື້ອງຊ້າຍ, ແລະ ສຳ ລັບພາສາດ້ານຂວາຫາຊ້າຍເຊັ່ນພາສາອາຣັບຫລືພາສາຍິວ, ນີ້ຈະເປັນຝ່າຍຂວາ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // ຄວາມປອດໄພ: `Searcher` ແມ່ນເປັນທີ່ຮູ້ຈັກທີ່ຈະກັບຄືນຕົວຊີ້ບອກທີ່ຖືກຕ້ອງ.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ໃຊ້ຊ່ອຍແນ່ກັບ ຄຳ ນຳ ໜ້າ ທີ່ຖອດອອກ.
    ///
    /// ຖ້າຫາກວ່າສະຕິງເລີ່ມຕົ້ນດ້ວຍຮູບແບບ `prefix`, ໃຫ້ກັບຄືນຫຼັງຈາກ ຄຳ ນຳ ໜ້າ, ຫໍ່ດ້ວຍ `Some`.
    /// ບໍ່ເຫມືອນກັບ `trim_start_matches`, ວິທີການນີ້ removes prefix ໄດ້ແທ້ດຽວ.
    ///
    /// ຖ້າສາຍບໍ່ເລີ່ມຕົ້ນດ້ວຍ `prefix`, ໃຫ້ຄືນ `None`.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// ສົ່ງຄືນເຊືອກທີ່ມີສ່ວນປະກອບທີ່ຖືກເອົາອອກ.
    ///
    /// ຖ້າຫາກວ່າສະຕິງສິ້ນສຸດລົງດ້ວຍຮູບແບບ `suffix`, ສົ່ງຄືນເສັ້ນທາງສ່ວນຕົວກ່ອນທີ່ຈະຖືກໃສ່ໄວ້, ຫໍ່ດ້ວຍ `Some`.
    /// ບໍ່ຄືກັບ `trim_end_matches`, ວິທີການນີ້ຈະ ກຳ ຈັດເອົາបច្ច័យຢ່າງແນ່ນອນ.
    ///
    /// ຖ້າສາຍບໍ່ສິ້ນສຸດດ້ວຍ `suffix`, ໃຫ້ຄືນ `None`.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// ສົ່ງຄືນສ່ວນທີ່ໃຊ້ຊ່ອຍແນ່ພ້ອມກັບທຸກ ຄຳ ຕອບທີ່ກົງກັບຮູບແບບທີ່ຖືກຍ້າຍອອກໄປເລື້ອຍໆ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ທິດທາງຂໍ້ຄວາມ
    ///
    /// ສະຕິງແມ່ນ ລຳ ດັບຂອງໄບຕ໌.
    /// `end` ໃນສະພາບການນີ້ ໝາຍ ເຖິງ ຕຳ ແໜ່ງ ສຸດທ້າຍຂອງສະຕິງວ່າ;ສຳ ລັບພາສາດ້ານຊ້າຍຫາຂວາເຊັ່ນພາສາອັງກິດຫລືພາສາລັດເຊຍ, ນີ້ຈະເປັນຝ່າຍຂວາ, ແລະ ສຳ ລັບພາສາດ້ານຂວາຫາຊ້າຍເຊັ່ນພາສາອາຣັບຫລືພາສາຍິວ, ນີ້ຈະເປັນເບື້ອງຊ້າຍ.
    ///
    ///
    /// # Examples
    ///
    /// ຮູບແບບງ່າຍໆ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// ຮູບແບບທີ່ສັບສົນກວ່າ, ໂດຍໃຊ້ແບບປິດ:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ຄວາມປອດໄພ: `Searcher` ແມ່ນເປັນທີ່ຮູ້ຈັກທີ່ຈະກັບຄືນຕົວຊີ້ບອກທີ່ຖືກຕ້ອງ.
        unsafe { self.get_unchecked(0..j) }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ໃຊ້ຊ່ອຍແນ່ກັບ ຄຳ ນຳ ໜ້າ ທັງ ໝົດ ທີ່ກົງກັບຮູບແບບທີ່ຖືກຍ້າຍອອກໄປເລື້ອຍໆ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ທິດທາງຂໍ້ຄວາມ
    ///
    /// ສະຕິງແມ່ນ ລຳ ດັບຂອງໄບຕ໌.
    /// 'Left' ໃນສະພາບການນີ້ ໝາຍ ເຖິງ ຕຳ ແໜ່ງ ທຳ ອິດຂອງສະຕິງວ່າ;ສຳ ລັບພາສາເຊັ່ນພາສາອາຣັບຫລືພາສາເຮັບເຣີເຊິ່ງມີ 'ຂວາຫາຊ້າຍ' ຫລາຍກວ່າ 'ຊ້າຍຫາຂວາ', ນີ້ຈະແມ່ນເບື້ອງ _right_, ບໍ່ແມ່ນດ້ານຊ້າຍ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// ສົ່ງຄືນສ່ວນທີ່ໃຊ້ຊ່ອຍແນ່ພ້ອມກັບທຸກ ຄຳ ຕອບທີ່ກົງກັບຮູບແບບທີ່ຖືກຍ້າຍອອກໄປເລື້ອຍໆ.
    ///
    /// [pattern] ສາມາດເປັນ `&str`, [`char`], ສ່ວນຂອງ [`char`], ຫຼື ໜ້າ ທີ່ຫລືການປິດທີ່ ກຳ ນົດວ່າຕົວລະຄອນໃດ ໜຶ່ງ ກົງກັນ.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ທິດທາງຂໍ້ຄວາມ
    ///
    /// ສະຕິງແມ່ນ ລຳ ດັບຂອງໄບຕ໌.
    /// 'Right' ໃນສະພາບການນີ້ ໝາຍ ເຖິງ ຕຳ ແໜ່ງ ສຸດທ້າຍຂອງສະຕິງວ່າ;ສຳ ລັບພາສາເຊັ່ນພາສາອາຣັບຫລືພາສາເຮັບເຣີເຊິ່ງມີ 'ຂວາຫາຊ້າຍ' ຫລາຍກວ່າ 'ຊ້າຍຫາຂວາ', ນີ້ຈະແມ່ນດ້ານ _left_, ບໍ່ແມ່ນດ້ານຂວາ.
    ///
    ///
    /// # Examples
    ///
    /// ຮູບແບບງ່າຍໆ:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// ຮູບແບບທີ່ສັບສົນກວ່າ, ໂດຍໃຊ້ແບບປິດ:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// ຖີ້ມສາຍສະຕິງນີ້ອອກເປັນແບບອື່ນ.
    ///
    /// ເນື່ອງຈາກວ່າ `parse` ແມ່ນທົ່ວໄປຫຼາຍ, ມັນສາມາດເຮັດໃຫ້ເກີດບັນຫາກ່ຽວກັບຄວາມຕ້ອງການຂອງປະເພດ.
    /// ເມື່ອເປັນເຊັ່ນນັ້ນ, `parse` ແມ່ນ ໜຶ່ງ ໃນສອງສາມຄັ້ງທີ່ທ່ານຈະເຫັນໄວຍາກອນທີ່ມີຊື່ສຽງວ່າ 'turbofish': `::<>`.
    ///
    /// ນີ້ຊ່ວຍໃຫ້ algorithm inference ເຂົ້າໃຈໂດຍສະເພາະປະເພດທີ່ທ່ານພະຍາຍາມແຍກ.
    ///
    /// `parse` ສາມາດວິເຄາະເຂົ້າໄປໃນປະເພດທີ່ປະຕິບັດໄດ້ [`FromStr`] trait ໃດ.
    ///

    /// # Errors
    ///
    /// ຈະກັບຄືນ [`Err`] ຖ້າມັນບໍ່ສາມາດແຍກສາຍເຊືອກນີ້ອອກເປັນປະເພດທີ່ຕ້ອງການ.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// ການໃຊ້ 'turbofish' ແທນທີ່ຈະເລົ່າເລື່ອງ `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// ລົ້ມເຫລວໃນການຕີຄວາມ:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// ກວດເບິ່ງວ່າຕົວລະຄອນທັງ ໝົດ ໃນສາຍນີ້ຢູ່ໃນຂອບເຂດ ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // ພວກເຮົາສາມາດປະຕິບັດຕໍ່ byte ເປັນລັກສະນະນີ້: ທັງຫມົດລັກສະນະ multibyte ເລີ່ມຕົ້ນດ້ວຍໄບທີ່ບໍ່ໄດ້ຢູ່ໃນລະດັບ ascii ໄດ້, ດັ່ງນັ້ນພວກເຮົາຈະຢຸດເຊົາການມີແລ້ວ.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// ກວດເບິ່ງວ່າສອງເຊືອກແມ່ນການຈັບຄູ່ກໍລະນີທີ່ບໍ່ມີຄວາມ ໝາຍ ຂອງ ASCII.
    ///
    /// ດຽວກັນກັບ `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ແຕ່ວ່າໂດຍບໍ່ມີການຈັດສັນແລະຄັດລອກຕາຕະລາງເວລາ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// ແປງສະຕິງນີ້ໃຫ້ເປັນ ASCII ໃຫຍ່ໂຕໃຫຍ່ທຽບເທົ່າໃນສະຖານທີ່.
    ///
    /// ຕົວອັກສອນ ASCII 'a' ກັບ 'z' ແມ່ນ mapped ກັບ 'A' ກັບ 'Z', ແຕ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII ແມ່ນບໍ່ປ່ຽນແປງ.
    ///
    /// ເພື່ອກັບຄືນຄ່າ ໃໝ່ ທີ່ບໍ່ມີມູນຄ່າ ໃໝ່ ໂດຍບໍ່ຕ້ອງດັດແປງຄ່າທີ່ມີຢູ່, ໃຫ້ໃຊ້ [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // ຄວາມປອດໄພ: ປອດໄພເພາະວ່າພວກເຮົາສົ່ງສອງແບບດ້ວຍແບບແຜນດຽວກັນ.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// ແປງສະຕິງນີ້ໃຫ້ເປັນ ASCII ໂຕນ້ອຍທີ່ທຽບເທົ່າກັບສະຖານທີ່.
    ///
    /// ຕົວອັກສອນ ASCII 'A' ຫາ 'Z' ຖືກແຕ້ມໃສ່ 'a' ຫາ 'z', ແຕ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII ບໍ່ປ່ຽນແປງ.
    ///
    /// ເພື່ອກັບຄືນມູນຄ່າທີ່ຫຼຸດລົງ ໃໝ່ ໂດຍບໍ່ມີການດັດແປງຂອງທີ່ມີຢູ່, ໃຫ້ໃຊ້ [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // ຄວາມປອດໄພ: ປອດໄພເພາະວ່າພວກເຮົາສົ່ງສອງແບບດ້ວຍແບບແຜນດຽວກັນ.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// ສົ່ງຄືນເຄື່ອງປັບທີ່ປ່ອຍຕົວແຕ່ລະ char ໃນ `self` ກັບ [`char::escape_debug`].
    ///
    ///
    /// Note: ພຽງແຕ່ຈຸດເຂົ້າລະຫັດ grapheme ຂະຫຍາຍທີ່ເລີ່ມຕົ້ນຊ່ອຍແນ່ຈະລອດ.
    ///
    /// # Examples
    ///
    /// ໃນຖານະທີ່ເປັນຜູ້ປັບ:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ການນໍາໃຊ້ `println!` ໂດຍກົງ:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// ທັງສອງເທົ່າກັບ:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// ການໃຊ້ `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// ສົ່ງຄືນເຄື່ອງປັບທີ່ປ່ອຍຕົວແຕ່ລະ char ໃນ `self` ກັບ [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// ໃນຖານະທີ່ເປັນຜູ້ປັບ:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ການນໍາໃຊ້ `println!` ໂດຍກົງ:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// ທັງສອງເທົ່າກັບ:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// ການໃຊ້ `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// ກັບ iterator ທີ່ຈະພົ້ນຈາກແຕ່ລະ char ໃນ `self` ກັບ [`char::escape_unicode`] ເປັນ.
    ///
    ///
    /// # Examples
    ///
    /// ໃນຖານະທີ່ເປັນຜູ້ປັບ:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ການນໍາໃຊ້ `println!` ໂດຍກົງ:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// ທັງສອງເທົ່າກັບ:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// ການໃຊ້ `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// ສ້າງ str ເປົ່າ
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// ສ້າງ str ທີ່ສາມາດປ່ຽນແປງໄດ້
    #[inline]
    fn default() -> Self {
        // SAFETY: The string ເປົ່າແມ່ນຖືກຕ້ອງ UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// ປະເພດ fn ທີ່ມີຊື່ແລະ cloneable
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // ຄວາມປອດໄພ: ບໍ່ປອດໄພ
        unsafe { from_utf8_unchecked(bytes) }
    };
}