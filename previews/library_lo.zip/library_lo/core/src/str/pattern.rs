//! String Pattern API.
//!
//! Pattern API ໃຫ້ມີກົນໄກທົ່ວໄປ ສຳ ລັບການ ນຳ ໃຊ້ປະເພດຮູບແບບທີ່ແຕກຕ່າງກັນເມື່ອຄົ້ນຫາຜ່ານສາຍ.
//!
//! ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ, ເບິ່ງ traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], ແລະ [`DoubleEndedSearcher`].
//!
//! ເຖິງແມ່ນວ່າ API ນີ້ບໍ່ສະຖຽນລະພາບ, ມັນຈະຖືກເປີດເຜີຍຜ່ານ API ທີ່ ໝັ້ນ ຄົງໃນປະເພດ [`str`].
//!
//! # Examples
//!
//! [`Pattern`] ແມ່ນ [implemented][pattern-impls] ໃນ API ຄົງທີ່ ສຳ ລັບ [`&str`][`str`], [`char`], ຊິ້ນຂອງ [`char`], ແລະ ໜ້າ ທີ່ແລະການປະຕິບັດການປິດ `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // ຮູບແບບ char
//! assert_eq!(s.find('n'), Some(2));
//! // ຮູບແບບຂອງຕາຕະລາງ
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // ຮູບແບບການປິດ
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// ຮູບແບບສະຕິງ.
///
/// A `Pattern<'a>` ສະແດງວ່າປະເພດການຈັດຕັ້ງປະຕິບັດສາມາດຖືກ ນຳ ໃຊ້ເປັນແບບສະຕິງ ສຳ ລັບການຄົ້ນຫາໃນ [`&'a str`][str].
///
/// ຍົກຕົວຢ່າງ, ທັງ `'a'` ແລະ `"aa"` ແມ່ນຮູບແບບທີ່ຈະກົງກັບດັດຊະນີ `1` ໃນສາຍ `"baaaab"`.
///
/// trait ຕົວມັນເອງເຮັດຫນ້າທີ່ເປັນຜູ້ສ້າງສໍາລັບປະເພດ [`Searcher`] ທີ່ກ່ຽວຂ້ອງ, ເຊິ່ງເຮັດວຽກຕົວຈິງຂອງການຊອກຫາການປະກົດຕົວຂອງຮູບແບບໃນສາຍ.
///
///
/// ອີງຕາມປະເພດຂອງຮູບແບບ, ພຶດຕິ ກຳ ຂອງວິທີການຕ່າງໆເຊັ່ນ [`str::find`] ແລະ [`str::contains`] ສາມາດປ່ຽນແປງໄດ້.
/// ຕາຕະລາງຂ້າງລຸ່ມນີ້ອະທິບາຍບາງພຶດຕິ ກຳ ເຫຼົ່ານັ້ນ.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// ຄົ້ນຫາທີ່ກ່ຽວຂ້ອງສໍາລັບການຮູບແບບນີ້
    type Searcher: Searcher<'a>;

    /// ໂຄງສ້າງການຄົ້ນຫາທີ່ກ່ຽວຂ້ອງຈາກ `self` ແລະ `haystack` ໃນການຊອກຫາໃນ.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// ກວດເບິ່ງວ່າຮູບແບບດັ່ງກ່າວກົງກັບທຸກບ່ອນໃນເສັ້ນສາຍຕາ
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// ກວດເບິ່ງວ່າຮູບແບບກົງກັນຢູ່ທາງຫນ້າຂອງ haystack ໄດ້
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// ກວດເບິ່ງວ່າຮູບແບບກົງກັບທາງຫລັງຂອງ haystack
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// ເອົາຮູບແບບອອກຈາກດ້ານຫນ້າຂອງ haystack, ຖ້າມັນກົງກັນ.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // ຄວາມປອດໄພ: `Searcher` ແມ່ນເປັນທີ່ຮູ້ຈັກທີ່ຈະກັບຄືນຕົວຊີ້ບອກທີ່ຖືກຕ້ອງ.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// ເອົາຮູບແບບອອກຈາກດ້ານຫລັງຂອງ haystack, ຖ້າມັນກົງກັນ.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // ຄວາມປອດໄພ: `Searcher` ແມ່ນເປັນທີ່ຮູ້ຈັກທີ່ຈະກັບຄືນຕົວຊີ້ບອກທີ່ຖືກຕ້ອງ.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// ຜົນໄດ້ຮັບຂອງການໂທຫາ [`Searcher::next()`] ຫຼື [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// ສະແດງຄວາມວ່າການແຂ່ງຂັນຂອງຮູບແບບທີ່ໄດ້ຮັບການພົບເຫັນຢູ່ໃນ `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// ສະແດງອອກວ່າ `haystack[a..b]` ໄດ້ຖືກປະຕິເສດວ່າເປັນການຈັບຄູ່ແບບທີ່ເປັນໄປໄດ້ຂອງຮູບແບບ.
    ///
    /// ໃຫ້ສັງເກດວ່າອາດຈະມີຫຼາຍກ່ວາຫນຶ່ງ `Reject` ລະຫວ່າງສອງ `Match`es, ມີຄວາມຕ້ອງການທີ່ບໍ່ມີສໍາລັບພວກເຂົາທີ່ຈະໄດ້ຮັບການອະນຸຍາດຂອງເປັນຫນຶ່ງ.
    ///
    ///
    Reject(usize, usize),
    /// ສະແດງໃຫ້ເຫັນວ່າທຸກໆເສັ້ນທາງຂອງ haystack ໄດ້ຖືກໄປຢ້ຽມຢາມ, ສິ້ນສຸດຄວາມຕື່ນຕົວ.
    ///
    Done,
}

/// ຜູ້ຄົ້ນຫາຮູບແບບສະຕິງ.
///
/// trait ນີ້ສະ ໜອງ ວິທີການ ສຳ ລັບການຄົ້ນຫາການຈັບຄູ່ທີ່ບໍ່ຊ້ ຳ ຊ້ອນຂອງຮູບແບບເລີ່ມຕົ້ນຈາກ (left) ດ້ານ ໜ້າ ຂອງສາຍ.
///
/// ມັນຈະຖືກຈັດຕັ້ງປະຕິບັດໂດຍປະເພດ `Searcher` ທີ່ກ່ຽວຂ້ອງຂອງ [`Pattern`] trait.
///
/// trait ແມ່ນຖືກ ໝາຍ ວ່າບໍ່ປອດໄພເພາະວ່າຕົວຊີ້ວັດທີ່ສົ່ງຄືນໂດຍວິທີ [`next()`][Searcher::next] ແມ່ນ ຈຳ ເປັນຕ້ອງນອນຢູ່ໃນຂອບເຂດ utf8 ທີ່ຖືກຕ້ອງໃນສາຍເຫົ່າ.
/// ສິ່ງນີ້ຊ່ວຍໃຫ້ຜູ້ບໍລິໂພກຂອງ trait ສາມາດຕັດພວງມະໄລໄດ້ໂດຍບໍ່ຕ້ອງມີການກວດສອບເພີ່ມ.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter ສໍາລັບ string ທີ່ຕິດພັນກັບໄດ້ຮັບການຊອກຫາຢູ່ໃນ
    ///
    /// ຈະກັບຄືນ [`&str`][str] ດຽວກັນຢູ່ສະ ເໝີ.
    fn haystack(&self) -> &'a str;

    /// ດໍາເນີນການໃນຂັ້ນຕອນການຊອກຫາຕໍ່ໄປເລີ່ມຈາກທາງຫນ້າໄດ້.
    ///
    /// - ສົ່ງຄືນ [`Match(a, b)`][SearchStep::Match] ຖ້າ `haystack[a..b]` ກົງກັບຮູບແບບ.
    /// - ສົ່ງຄືນ [`Reject(a, b)`][SearchStep::Reject] ຖ້າ `haystack[a..b]` ບໍ່ສາມາດກົງກັບຮູບແບບ, ເຖິງແມ່ນວ່າບາງສ່ວນ.
    /// - ສົ່ງຄືນ [`Done`][SearchStep::Done] ຖ້າທຸກໆບາດຂອງ haystack ໄດ້ຖືກໄປຢ້ຽມຢາມ.
    ///
    /// ກະແສຂອງຄ່າ [`Match`][SearchStep::Match] ແລະ [`Reject`][SearchStep::Reject] ສູງເຖິງ [`Done`][SearchStep::Done] ຈະມີລະດັບດັດສະນີທີ່ຢູ່ຕິດກັນ, ບໍ່ຊ້ ຳ ກັນ, ປົກຄຸມເສັ້ນທາງທັງ ໝົດ, ແລະວາງຢູ່ໃນຂອບເຂດ utf8.
    ///
    ///
    /// ຜົນໄດ້ຮັບ [`Match`][SearchStep::Match] ຕ້ອງມີຮູບແບບທີ່ຖືກຕ້ອງທັງ ໝົດ, ເຖິງຢ່າງໃດກໍ່ຕາມຜົນໄດ້ຮັບ [`Reject`][SearchStep::Reject] ອາດຈະແບ່ງອອກເປັນຊິ້ນສ່ວນໃກ້ຄຽງທີ່ບໍ່ມີປະໂຫຍດ.ທັງສອງແຖວອາດມີຄວາມຍາວສູນ.
    ///
    /// ຕົວຢ່າງ, ຮູບແບບ `"aaa"` ແລະ haystack `"cbaaaaab"` ອາດຈະຜະລິດກະແສໄດ້
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// ພົບຜົນ [`Match`][SearchStep::Match] ຕໍ່ໄປ.ເບິ່ງ [`next()`][Searcher::next].
    ///
    /// ບໍ່ຄືກັບ [`next()`][Searcher::next], ບໍ່ມີການຮັບປະກັນວ່າຂອບເຂດທີ່ສົ່ງຄືນຂອງສິ່ງນີ້ແລະ [`next_reject`][Searcher::next_reject] ຈະຊໍ້າຊ້ອນ.
    /// ນີ້ຈະກັບຄືນ `(start_match, end_match)`, ບ່ອນທີ່ start_match ແມ່ນດັດຊະນີບ່ອນທີ່ການແຂ່ງຂັນເລີ່ມຕົ້ນ, ແລະ end_match ແມ່ນດັດຊະນີຫຼັງຈາກສິ້ນສຸດການແຂ່ງຂັນ.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// ພົບຜົນ [`Reject`][SearchStep::Reject] ຕໍ່ໄປ.ເບິ່ງ [`next()`][Searcher::next] ແລະ [`next_match()`][Searcher::next_match].
    ///
    /// ບໍ່ຄືກັບ [`next()`][Searcher::next], ບໍ່ມີການຮັບປະກັນວ່າຂອບເຂດທີ່ສົ່ງຄືນຂອງສິ່ງນີ້ແລະ [`next_match`][Searcher::next_match] ຈະຊໍ້າຊ້ອນ.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// A ຄົ້ນຫາໄດ້ຢ່າງສິ້ນເຊີງສໍາລັບຮູບແບບສະຕິງ.
///
/// trait ນີ້ໃຫ້ວິທີການ ສຳ ລັບການຄົ້ນຫາການຈັບຄູ່ແບບບໍ່ຊ້ ຳ ຊ້ອນຂອງຮູບແບບເລີ່ມຕົ້ນຈາກດ້ານຫຼັງ (right) ຂອງສາຍ.
///
/// ມັນຈະຖືກຈັດຕັ້ງປະຕິບັດໂດຍປະເພດ [`Searcher`] ທີ່ກ່ຽວຂ້ອງຂອງ [`Pattern`] trait ຖ້າຮູບແບບດັ່ງກ່າວສະ ໜັບ ສະ ໜູນ ການຊອກຫາມັນຈາກດ້ານຫຼັງ.
///
///
/// ຂອບເຂດດັດສະນີທີ່ສົ່ງຄືນໂດຍ trait ນີ້ບໍ່ ຈຳ ເປັນຕ້ອງກົງກັບສະເພາະຂອງການຄົ້ນຫາໃນຕໍ່ ໜ້າ.
///
/// ດ້ວຍເຫດຜົນທີ່ວ່າ trait ນີ້ຖືກ ໝາຍ ວ່າບໍ່ປອດໄພ, ເບິ່ງພວກເຂົາວ່າພໍ່ແມ່ trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// ປະຕິບັດຂັ້ນຕອນການຄົ້ນຫາຕໍ່ໄປເລີ່ມຕົ້ນຈາກດ້ານຫລັງ.
    ///
    /// - ສົ່ງຄືນ [`Match(a, b)`][SearchStep::Match] ຖ້າ `haystack[a..b]` ກົງກັບຮູບແບບ.
    /// - ສົ່ງຄືນ [`Reject(a, b)`][SearchStep::Reject] ຖ້າ `haystack[a..b]` ບໍ່ສາມາດກົງກັບຮູບແບບ, ເຖິງແມ່ນວ່າບາງສ່ວນ.
    /// - ຜົນໄດ້ຮັບ [`Done`][SearchStep::Done] ຖ້າ byte ຂອງ haystack ໃນທຸກໆໄດ້ຮັບການໄປຢ້ຽມຢາມ
    ///
    /// ກະແສຂອງຄ່າ [`Match`][SearchStep::Match] ແລະ [`Reject`][SearchStep::Reject] ສູງເຖິງ [`Done`][SearchStep::Done] ຈະມີລະດັບດັດສະນີທີ່ຢູ່ຕິດກັນ, ບໍ່ຊ້ ຳ ກັນ, ປົກຄຸມເສັ້ນທາງທັງ ໝົດ, ແລະວາງຢູ່ໃນຂອບເຂດ utf8.
    ///
    ///
    /// ຜົນໄດ້ຮັບ [`Match`][SearchStep::Match] ຕ້ອງມີຮູບແບບທີ່ຖືກຕ້ອງທັງ ໝົດ, ເຖິງຢ່າງໃດກໍ່ຕາມຜົນໄດ້ຮັບ [`Reject`][SearchStep::Reject] ອາດຈະແບ່ງອອກເປັນຊິ້ນສ່ວນໃກ້ຄຽງທີ່ບໍ່ມີປະໂຫຍດ.ທັງສອງແຖວອາດມີຄວາມຍາວສູນ.
    ///
    /// ຍົກຕົວຢ່າງ, ຮູບແບບ `"aaa"` ແລະ haystack `"cbaaaaab"` ອາດຈະຜະລິດກະແສ `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// ຊອກຫາຜົນໄດ້ຮັບ [`Match`][SearchStep::Match] ຕໍ່ໄປ.
    /// ເບິ່ງ [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// ເຫັນວ່າຜົນ [`Reject`][SearchStep::Reject] ຕໍ່ໄປ.
    /// ເບິ່ງ [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// ເຄື່ອງ ໝາຍ trait ເພື່ອສະແດງວ່າ [`ReverseSearcher`] ສາມາດໃຊ້ ສຳ ລັບການປະຕິບັດ [`DoubleEndedIterator`].
///
/// ສຳ ລັບສິ່ງນີ້, ຄວາມ ໝາຍ ຂອງ [`Searcher`] ແລະ [`ReverseSearcher`] ຈຳ ເປັນຕ້ອງປະຕິບັດຕາມເງື່ອນໄຂດັ່ງນີ້:
///
/// - ຜົນການຄົ້ນຫາທັງຫມົດຂອງ `next()` ຈໍາເປັນຕ້ອງຄືກັນກັບຜົນໄດ້ຮັບຂອງ `next_back()` ໃນຄໍາສັ່ງໄດ້ຢ່າງສິ້ນເຊີງ.
/// - `next()` ແລະ `next_back()` ຈຳ ເປັນຕ້ອງປະພຶດຕົວເປັນສອງສົ້ນຂອງຄ່າຕ່າງໆ, ນັ້ນແມ່ນພວກມັນບໍ່ສາມາດ "walk past each other".
///
/// # Examples
///
/// `char::Searcher` ເປັນ `DoubleEndedSearcher` ເນື່ອງຈາກວ່າການຊອກຫາສໍາລັບການ [`char`] ພຽງແຕ່ຮຽກຮ້ອງໃຫ້ມີການຊອກຫາທີ່ຫນຶ່ງທີ່ເປັນທີ່ໃຊ້ເວລາ, ທີ່ມີພຶດຕິດຽວກັນຈາກທັງສອງສົ້ນ.
///
/// `(&str)::Searcher` ບໍ່ແມ່ນ `DoubleEndedSearcher` ເພາະຮູບແບບ `"aa"` ໃນ haystack `"aaa"` ກົງກັບ `"[aa]a"` ຫຼື `"a[aa]"`, ຂື້ນກັບວ່າມັນຖືກຄົ້ນຫາມາຈາກຂ້າງໃດ.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// ເອົາໃຈໃສ່ ສຳ ລັບ char
/////////////////////////////////////////////////////////////////////////////

/// ປະເພດທີ່ກ່ຽວຂ້ອງ ສຳ ລັບ `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // ຄົງປອດໄພ: `finger`/`finger_back` ຕ້ອງເປັນດັດຊະນີ byte ຖືກຕ້ອງ utf8 ຂອງ `haystack` invariant ນີ້ສາມາດໄດ້ຮັບການແຍກ *ພາຍໃນ next_match* ແລະ next_match_back, ຢ່າງໃດກໍຕາມພວກເຂົາເຈົ້າຕ້ອງອອກຈາກທີ່ມີນິ້ວມືໃນຂອບເຂດຊາຍແດນຈຸດຫັດທີ່ຖືກຕ້ອງ.
    //
    //
    /// `finger` ແມ່ນດັດຊະນີ byte ໃນປະຈຸບັນຂອງການຄົ້ນຫາຕໍ່.
    /// ຈິນຕະນາການວ່າມັນມີຢູ່ກ່ອນໄບຕ໌ຢູ່ທີ່ດັດຊະນີຂອງມັນ, ເຊັ່ນ
    /// `haystack[finger]` ແມ່ນບາດດຽວ ທຳ ອິດທີ່ພວກເຮົາຕ້ອງໄດ້ກວດກາໃນລະຫວ່າງການຄົ້ນຫາຕໍ່ໄປ
    ///
    finger: usize,
    /// `finger_back` ແມ່ນດັດຊະນີໄບຕ໌ໃນປະຈຸບັນຂອງການຄົ້ນຫາດ້ານຫຼັງ.
    /// ຈິນຕະນາການວ່າມັນມີຢູ່ຫຼັງຈາກໄບຕ໌ຢູ່ທີ່ດັດຊະນີຂອງມັນ, ເຊັ່ນ
    /// haystack [finger_back, 1] ແມ່ນໄບຕ໌ສຸດທ້າຍທີ່ພວກເຮົາຕ້ອງໄດ້ກວດກາໃນລະຫວ່າງການຄົ້ນຫາໃນຕໍ່ ໜ້າ (ແລະດັ່ງນັ້ນເສັ້ນທາງ ທຳ ອິດທີ່ໄດ້ຮັບການກວດກາໃນເວລາໂທຫາ next_back()).
    ///
    finger_back: usize,
    /// ລັກສະນະທີ່ຖືກຄົ້ນຫາ
    needle: char,

    // ການບຸກລຸກດ້ານຄວາມປອດໄພ: `utf8_size` ຕ້ອງນ້ອຍກວ່າ 5
    /// ຈຳ ນວນໄບຕ໌ `needle` ໃຊ້ເວລາເຂົ້າລະຫັດໃນ utf8.
    utf8_size: usize,
    /// ສຳ ເນົາ utf8 ຂອງລະຫັດ `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // ຄວາມປອດໄພ: 1-4 ຮັບປະກັນຄວາມປອດໄພຂອງ `get_unchecked`
        // 1. `self.finger` ແລະ `self.finger_back` ຖືກເກັບຮັກສາຢູ່ໃນເຂດແດນ unicode (ນີ້ແມ່ນສະແດງ)
        // 2. `self.finger >= 0` ນັບຕັ້ງແຕ່ມັນເລີ່ມຕົ້ນທີ່ 0 ແລະເພີ່ມຂື້ນເທົ່ານັ້ນ
        // 3. `self.finger < self.finger_back` ເນື່ອງຈາກວ່າຖ້າບໍ່ດັ່ງນັ້ນ char `iter` ກໍ່ຈະກັບຄືນ `SearchStep::Done`
        // 4.
        // `self.finger` ມາກ່ອນໃນຕອນທ້າຍຂອງ haystack ໄດ້ເນື່ອງຈາກວ່າ `self.finger_back` ເປີດໃຫ້ບໍລິສຸດແລະມີພຽງແຕ່ການຫຼຸດລົງ
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // ເພີ່ມຊົດເຊີຍ byte ຂອງຕົວລະຄອນໃນປະຈຸບັນໂດຍບໍ່ຕ້ອງໃສ່ລະຫັດ ໃໝ່ ເປັນ utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // ໄດ້ຮັບ haystack ຫຼັງຈາກລັກສະນະສຸດທ້າຍທີ່ພົບເຫັນ
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // ແຜ່ນໃບຄ້າຍຄືເຂັມສຸດທ້າຍຂອງ utf8 ຢ່າງປອດໄພ: ພວກເຮົາມີຂໍ້ບົກພ່ອງທີ່ `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // ນີ້ວມື ໃໝ່ ແມ່ນດັດສະນີຂອງໄບຕ໌ທີ່ພວກເຮົາພົບ, ບວກກັບອີກອັນ ໜຶ່ງ, ເພາະວ່າພວກເຮົາຈື່ ຈຳ ລັກສະນະຂອງໄບຕ໌ສຸດທ້າຍ.
                //
                // ໃຫ້ສັງເກດວ່າສິ່ງນີ້ບໍ່ໄດ້ເຮັດໃຫ້ພວກເຮົາມີນິ້ວມືຢູ່ໃນເຂດແດນ UTF8.
                // ຖ້າຫາກວ່າພວກເຮົາ * ບໍ່ໄດ້ຊອກຫາລັກສະນະຂອງພວກເຮົາພວກເຮົາອາດຈະໄດ້ດັດສະນີເປັນໄບຕ໌ທີ່ບໍ່ແມ່ນສຸດທ້າຍຂອງ 3-byte ຫຼື 4-byte character.
                // ພວກເຮົາບໍ່ພຽງແຕ່ຂ້າມໄປຫາໄບຕ໌ເລີ່ມຕົ້ນທີ່ຖືກຕ້ອງຕໍ່ໄປເພາະວ່າຕົວລະຄອນຄ້າຍຄືꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` ຈະເຮັດໃຫ້ພວກເຮົາຊອກຫາໄບຕ໌ທີສອງສະ ເໝີ ເມື່ອຄົ້ນຫາທີສາມ.
                //
                //
                // ເຖິງຢ່າງໃດກໍ່ຕາມ, ນີ້ບໍ່ເປັນຫຍັງທັງ ໝົດ.
                // ໃນຂະນະທີ່ພວກເຮົາມີການບຸກລຸກທີ່ self.finger ຢູ່ໃນເຂດແດນ UTF8, ການບຸກລຸກນີ້ບໍ່ໄດ້ອີງໃສ່ພາຍໃນວິທີການນີ້ (ມັນຂື້ນກັບໃນ CharSearcher::next()).
                //
                // ພວກເຮົາພຽງແຕ່ອອກຈາກວິທີການນີ້ເມື່ອພວກເຮົາໄປຮອດຈຸດສຸດທ້າຍຂອງສາຍ, ຫຼືຖ້າພວກເຮົາພົບບາງສິ່ງບາງຢ່າງ.ເມື່ອພວກເຮົາພົບເຫັນບາງສິ່ງບາງຢ່າງ `finger` ຈະຖືກຕັ້ງເປັນເຂດແດນ UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ພົບເຫັນບໍ່ມີຫຍັງ, ອອກ
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // ໃຫ້ next_reject ໃຊ້ການຈັດຕັ້ງປະຕິບັດໃນຕອນຕົ້ນຈາກ Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // ຄວາມປອດໄພ: ເບິ່ງ ຄຳ ເຫັນ ສຳ ລັບ next() ຂ້າງເທິງ
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // ຫັກລົບ byte ຂອງລັກສະນະປັດຈຸບັນໂດຍບໍ່ຕ້ອງໃສ່ລະຫັດຄືນ ໃໝ່ ເປັນ utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // ໄດ້ຮັບ haystack ເຖິງແຕ່ບໍ່ລວມເອົາຕົວອັກສອນສຸດທ້າຍທີ່ຄົ້ນຫາ
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // ແຜ່ນໃບຄ້າຍຄືເຂັມສຸດທ້າຍຂອງ utf8 ຢ່າງປອດໄພ: ພວກເຮົາມີຂໍ້ບົກພ່ອງທີ່ `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // ພວກເຮົາໄດ້ຄົ້ນຫາຊິ້ນສ່ວນທີ່ຖືກຊົດເຊີຍໂດຍ self.finger, ເພີ່ມ self.finger ເພື່ອດັດສະນີດັດສະນີເດີມ
                //
                let index = self.finger + index;
                // memrchr ຈະສົ່ງດັດຊະນີຂອງໄບທີ່ພວກເຮົາຕ້ອງການຊອກຫາ.
                // ໃນກໍລະນີທີ່ມີລັກສະນະ ASCII, ນີ້ແມ່ນພວກເຮົາຕ້ອງການໃຫ້ນິ້ວມື ໃໝ່ ຂອງພວກເຮົາເປັນ ("after" ຂອງ char ທີ່ພົບເຫັນໃນຕົວຢ່າງຂອງການຊໍ້າຊ້ອນ).
                //
                // ສຳ ລັບຕາຕະລາງ multibyte ພວກເຮົາ ຈຳ ເປັນຕ້ອງເລື່ອນລົງດ້ວຍ ຈຳ ນວນໄບຕ໌ທີ່ພວກເຂົາມີຫລາຍກ່ວາ ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // ຍ້າຍນິ້ວມືໄປກ່ອນທີ່ຈະມີລັກສະນະທີ່ພົບເຫັນ (ie, ໃນດັດຊະນີການເລີ່ມຕົ້ນຂອງຕົນ)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // ພວກເຮົາບໍ່ສາມາດນໍາໃຊ້ finger_back=ດັດຊະນີ, ຂະຫນາດ + 1 ທີ່ນີ້.
                // ຖ້າພວກເຮົາພົບເຫັນຈຸດສຸດທ້າຍຂອງຕົວລະຄອນທີ່ມີຂະ ໜາດ ແຕກຕ່າງກັນ (ຫຼືຕົວເລກກາງຂອງຕົວລະຄອນທີ່ແຕກຕ່າງກັນ) ພວກເຮົາ ຈຳ ເປັນຕ້ອງຖີ້ມນິ້ວມືຍ້ອນກັບມາເປັນ `index`.
                // ສິ່ງທີ່ຄ້າຍຄືກັນນີ້ເຮັດໃຫ້ `finger_back` ມີທ່າແຮງທີ່ຈະບໍ່ຢູ່ໃນເຂດແດນອີກຕໍ່ໄປ, ແຕ່ນີ້ແມ່ນບໍ່ເປັນຫຍັງເພາະວ່າພວກເຮົາພຽງແຕ່ອອກຈາກ ໜ້າ ທີ່ນີ້ໃນເຂດແດນຫລືເມື່ອເສັ້ນທາງສາຍຮັດໄດ້ຖືກຄົ້ນຫາຢ່າງສົມບູນ.
                //
                //
                // ບໍ່ຄືກັບ next_match ນີ້ບໍ່ມີປັນຫາຂອງໄບຕ໌ຊ້ ຳ ອີກໃນ utf-8 ເພາະວ່າພວກເຮົາ ກຳ ລັງຄົ້ນຫາໄບຕ໌ສຸດທ້າຍ, ແລະພວກເຮົາສາມາດພົບເຫັນໄບຕ໌ສຸດທ້າຍໃນເວລາທີ່ຄົ້ນຫາໃນທາງກັບກັນ.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ພົບເຫັນບໍ່ມີຫຍັງ, ອອກ
                return None;
            }
        }
    }

    // ໃຫ້ next_reject_back ໃຊ້ການຈັດຕັ້ງປະຕິບັດໃນຕອນຕົ້ນຈາກ Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// ຄົ້ນຫາ ສຳ ລັບ char ທີ່ມີຄ່າເທົ່າກັບ [`char`] ທີ່ໃຫ້.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// ກະລຸນາໃສ່ເຄື່ອງຫຸ້ມຫໍ່ MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // ປຽບທຽບຄວາມຍາວຂອງຕົວຊີ້ວັດກະບອກພາຍໃນເພື່ອຊອກຫາຄວາມຍາວຂອງປະຈຸບັນ
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // ປຽບທຽບຄວາມຍາວຂອງຕົວຊີ້ວັດກະບອກພາຍໃນເພື່ອຊອກຫາຄວາມຍາວຂອງປະຈຸບັນ
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// ວາງແຜນ ສຳ ລັບ&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: ປ່ຽນ/ລຶບອອກຍ້ອນຄວາມບໍ່ແນ່ນອນໃນຄວາມ ໝາຍ.

/// ປະເພດທີ່ກ່ຽວຂ້ອງ ສຳ ລັບ `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// ຊອກຫາຕາຕະລາງທີ່ເທົ່າກັບ [`char`] ຂອງກະດານ.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl for F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// ປະເພດທີ່ກ່ຽວຂ້ອງ ສຳ ລັບ `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// ຄົ້ນຫາສໍາລັບ [`char`] s ທີ່ກົງກັບຢາດັ່ງກ່າວ.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// ສ້າງແບບແຜນ ສຳ ລັບ&&str
/////////////////////////////////////////////////////////////////////////////

/// ຜູ້ແທນເຂົ້າ `&str` X impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// ໃຊ້ ສຳ ລັບ &str
/////////////////////////////////////////////////////////////////////////////

/// ການຈັດສັນການຄົ້ນຫາແບບບໍ່ມີການຈັດສັນ.
///
/// ຈະຈັດການກັບຮູບແບບ `""` ເປັນການກັບຄືນການຈັບຄູ່ທີ່ບໍ່ມີຂອບເຂດແຕ່ລະລັກສະນະ.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// ກວດເບິ່ງວ່າຮູບແບບກົງກັນຢູ່ທາງຫນ້າຂອງ haystack ໄດ້.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// ເອົາຮູບແບບອອກຈາກດ້ານຫນ້າຂອງ haystack, ຖ້າມັນກົງກັນ.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // ຢ່າງປອດໄພ: ຄຳ ນຳ ໜ້າ ໄດ້ຖືກພິສູດແລ້ວວ່າມີຢູ່.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// ການກວດສອບບໍ່ວ່າຈະເປັນຮູບແບບທີ່ກົງກັບທີ່ດ້ານຫລັງຂອງ haystack ໄດ້.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// ເອົາຮູບແບບອອກຈາກດ້ານຫລັງຂອງ haystack, ຖ້າມັນກົງກັນ.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SAFETY: suffix ໄດ້ພຽງແຕ່ມີການຍືນຍັນທີ່ຈະມີ.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// ຜູ້ຊອກຫາທາງເລືອກສອງທາງ
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// ປະເພດທີ່ກ່ຽວຂ້ອງ ສຳ ລັບ `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // ເຂັມເປົ່າປະຕິເສດທຸກໆ char ແລະກົງກັບທຸກສາຍທີ່ຫວ່າງລະຫວ່າງພວກມັນ
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher ສາມາດຜະລິດ *ຖືກຕ້ອງຄໍາວ່າ* ດັດສະນີການແບ່ງປັນທີ່ຢູ່ຂອບເຂດຊາຍແດນ char ຕາບໃດທີ່ມັນບໍ່ກົງກັບທີ່ຖືກຕ້ອງແລະວ່າ haystack ແລະເຂັມແມ່ນຖືກຕ້ອງ UTF-8 *Rejects* ຈາກຂັ້ນຕອນວິທີການສາມາດຕົກລົງກ່ຽວກັບດັດສະນີໃດກໍ່ຕາມ, ແຕ່ພວກເຮົາຈະຍ່າງໃຫ້ເຂົາເຈົ້າດ້ວຍຕົນເອງກັບເຂດແດນມີລັກສະນະຕໍ່ໄປ, ດັ່ງນັ້ນພວກເຂົາເຈົ້າແມ່ນ utf-8 ປອດໄພ.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // ຂ້າມໄປຫາເຂດແດນຕໍ່ໄປ
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // ຂຽນອອກກໍລະນີ `true` ແລະ `false` ເພື່ອກະຕຸ້ນຜູ້ລວບລວມຂໍ້ມູນໃຫ້ສອງຄະດີແຍກຕ່າງຫາກ.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // ຂ້າມໄປຫາເຂດແດນຕໍ່ໄປ
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // ຂຽນອອກ `true` ແລະ `false` ເຊັ່ນ `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// ສະຖານະພາຍໃນຂອງທັງສອງວິທີການຂັ້ນຕອນວິທີການຄົ້ນຫາ substring.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// ດັດຊະນີປັດໄຈສໍາຄັນ
    crit_pos: usize,
    /// ດັດຊະນີປັດໄຈທີ່ ສຳ ຄັນ ສຳ ລັບເຂັມປີ້ນ
    crit_pos_back: usize,
    period: usize,
    /// `byteset` ແມ່ນການຂະຫຍາຍ (ບໍ່ແມ່ນສ່ວນ ໜຶ່ງ ຂອງວິທີການຄິດໄລ່ສອງທາງ);
    /// ມັນເປັນ "fingerprint" 64 ບິດເຊິ່ງແຕ່ລະຊຸດ `j` ນ້ອຍໆແມ່ນກົງກັບ (ໄບຕ໌&63)==j ປະຈຸບັນຢູ່ໃນເຂັມ.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// ດັດຊະນີເປັນເຂັມກ່ອນທີ່ພວກເຮົາໄດ້ຈັບຄູ່ແລ້ວ
    memory: usize,
    /// ດັດສະນີເປັນເຂັມຫລັງຈາກນັ້ນພວກເຮົາໄດ້ຈັບຄູ່ແລ້ວ
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // ຄຳ ອະທິບາຍທີ່ສາມາດອ່ານໄດ້ໂດຍສະເພາະກ່ຽວກັບສິ່ງທີ່ ກຳ ລັງເກີດຂື້ນຢູ່ນີ້ສາມາດພົບເຫັນຢູ່ໃນປື້ມຂອງບໍລິສັດ Crochemore ແລະປື້ມ R00, X 13.
        // ໂດຍສະເພາະເບິ່ງລະຫັດ ສຳ ລັບ "Algorithm CP" ຢູ່ ໜ້າ.
        // 323.
        //
        // ສິ່ງທີ່ ກຳ ລັງເກີດຂື້ນແມ່ນພວກເຮົາມີປັດໄຈການວິເຄາະ (u, v) ຂອງເຂັມ, ແລະພວກເຮົາຕ້ອງການ ກຳ ນົດວ່າຕົວເລກຂອງທ່ານແມ່ນຫຍັງ?
        // ຖ້າມັນແມ່ນ, ພວກເຮົາໃຊ້ "Algorithm CP1".
        // ຖ້າບໍ່ດັ່ງນັ້ນພວກເຮົາໃຊ້ "Algorithm CP2", ເຊິ່ງຈະຖືກປັບໃຫ້ດີຂື້ນເມື່ອໄລຍະເວລາຂອງເຂັມໃຫຍ່.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // ກໍລະນີໄລຍະສັ້ນ-ໄລຍະເວລາແມ່ນແນ່ນອນຄິດໄລ່ປັດໄຈທີ່ ສຳ ຄັນແຍກຕ່າງຫາກ ສຳ ລັບເຂັມປີ້ນກັບກັນ x=u 'v' ບ່ອນທີ່ | v '|<period(x).
            //
            // ສິ່ງນີ້ຈະຖືກປັບປຸງໂດຍໄລຍະເວລາທີ່ຮູ້ຈັກກັນແລ້ວ.
            // ໃຫ້ສັງເກດວ່າເປັນກໍລະນີເຊັ່ນ: x= "acba" ອາດໄດ້ຮັບປັດໃຈແທ້ທາງ Forward (crit_pos=1, ໄລຍະເວລາ=3) ໃນຂະນະທີ່ຖືກປັດໃຈທີ່ມີໄລຍະເວລາໂດຍປະມານໄດ້ຢ່າງສິ້ນເຊີງ (crit_pos=2, ໄລຍະເວລາ=2).
            // ພວກເຮົາໃຊ້ປັດໄຈການປີ້ນກັບກັນແຕ່ໃຫ້ຮັກສາໄລຍະເວລາທີ່ແນ່ນອນ.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // ກໍລະນີໄລຍະເວລາທີ່ຍາວນານ-ພວກເຮົາມີຄວາມໃກ້ຄຽງກັບໄລຍະເວລາຕົວຈິງ, ແລະຢ່າໃຊ້ຄວາມຊົງ ຈຳ.
            //
            //
            // ປະມານໄລຍະເວລາໂດຍ max(|u|, |v|) ຜູກມັດຕ່ໍາກວ່າ + 1.
            // ປັດໄຈ ສຳ ຄັນແມ່ນມີປະສິດທິພາບໃນການ ນຳ ໃຊ້ ສຳ ລັບການຄົ້ນຫາຕໍ່ ໜ້າ ແລະດ້ານຫຼັງ.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // ຄຸນຄ່າ Dummy ເພື່ອເປັນສັນຍານວ່າໄລຍະເວລາແມ່ນຍາວນານ
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // ໜຶ່ງ ໃນແນວຄວາມຄິດຫຼັກໆຂອງ Two-Way ແມ່ນພວກເຮົາປັດໄຈເຂັມເປັນສອງສ່ວນ, (u, v), ແລະເລີ່ມຕົ້ນພະຍາຍາມຊອກຫາ v ໃນ haystack ໂດຍການສະແກນຊ້າຍຫາຂວາ.
    // ຖ້າ v ກົງກັນ, ພວກເຮົາພະຍາຍາມຈັບຄູ່ u ໂດຍການສະແກນຂວາຫາຊ້າຍ.
    // ພວກເຮົາສາມາດໂດດຂ້າມໄດ້ແນວໃດເມື່ອພວກເຮົາພົບກັບຄວາມບໍ່ສອດຄ່ອງກັນທັງ ໝົດ ແມ່ນອີງໃສ່ຄວາມຈິງທີ່ວ່າ (u, v) ແມ່ນປັດໄຈທີ່ ສຳ ຄັນ ສຳ ລັບເຂັມ.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` ໃຊ້ `self.position` ເປັນຕົວກະພິບຂອງມັນ
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // ໃຫ້ກວດເບິ່ງວ່າພວກເຮົາມີຫ້ອງການທີ່ຈະຄົ້ນຫາໃນຕໍາແຫນ່ງ + needle_last ສາມາດເຮັດໄດ້ບໍ່ overflow ຖ້າພວກເຮົາສົມມຸດຫຼັງຈາກນັ້ນນໍາແມ່ນ bounded ໂດຍລະດັບ isize ຂອງ.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // ຂ້າມຢ່າງໄວວາໂດຍສ່ວນຂະ ໜາດ ໃຫຍ່ທີ່ບໍ່ກ່ຽວຂ້ອງກັບທໍ່ຮອງຂອງພວກເຮົາ
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // ເບິ່ງວ່າພາກສ່ວນທີ່ຖືກຕ້ອງຂອງເຂັມກົງກັນ
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // ເບິ່ງວ່າສ່ວນຊ້າຍຂອງເຂັມກົງກັນ
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // ພວກເຮົາໄດ້ພົບກັບການຈັບຄູ່!
            let match_pos = self.position;

            // Note: ເພີ່ມ self.period ແທນ needle.len() ເພື່ອໃຫ້ມີການຈັບຄູ່ກັນ
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // ຕັ້ງເປັນ needle.len(), self.period ສຳ ລັບການຈັບຄູ່ກັນ
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // ຕິດຕາມແນວຄວາມຄິດໃນ `next()`.
    //
    // ຄຳ ນິຍາມແມ່ນສົມມາດ, ມີ period(x) = period(reverse(x)) ແລະ local_period(u, v) = local_period(reverse(v), reverse(u)), ສະນັ້ນຖ້າ (u, v) ແມ່ນປັດໄຈທີ່ ສຳ ຄັນ, ສະນັ້ນ (reverse(v), reverse(u)).
    //
    //
    // ສຳ ລັບກໍລະນີປ່ຽນ ໃໝ່ ພວກເຮົາໄດ້ ຄຳ ນວນປັດໄຈທີ່ ສຳ ຄັນ x=u 'v' (ພາກສະ ໜາມ `crit_pos_back`).ພວກເຮົາຕ້ອງການ | u |<period(x) ສໍາລັບກໍລະນີຕໍ່ແລະດັ່ງນັ້ນຈຶ່ງ | v '|<period(x) ສຳ ລັບປີ້ນກັບກັນ.
    //
    // ເພື່ອຄົ້ນຫາໃນທາງກົງຜ່ານ haystack, ພວກເຮົາຄົ້ນຫາຕໍ່ໄປໂດຍຜ່ານ haystack ທີ່ປີ້ນກັບກັນກັບເຂັມປີ້ນກັບກັນ, ກົງກັບ u ກ່ອນແລະຫຼັງຈາກນັ້ນ v '.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` ໃຊ້ `self.end` ເປັນຕົວກະພິບຂອງມັນ-ເພື່ອໃຫ້ `next()` ແລະ `next_back()` ເປັນເອກະລາດ.
        //
        let old_end = self.end;
        'search: loop {
            // ກວດເບິ່ງວ່າພວກເຮົາມີຫ້ອງທີ່ຈະຄົ້ນຫາໃນທີ່ສຸດ, needle.len() ຈະຫໍ່ຢູ່ໃນເວລາທີ່ບໍ່ມີຫ້ອງຕື່ມອີກ, ແຕ່ເນື່ອງຈາກຂໍ້ ຈຳ ກັດຂອງຄວາມຍາວມັນບໍ່ສາມາດຫໍ່ກັບຄືນໄປບ່ອນຄວາມຍາວຂອງ haystack ໄດ້.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // ຂ້າມຢ່າງໄວວາໂດຍສ່ວນຂະ ໜາດ ໃຫຍ່ທີ່ບໍ່ກ່ຽວຂ້ອງກັບທໍ່ຮອງຂອງພວກເຮົາ
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // ເບິ່ງວ່າສ່ວນຊ້າຍຂອງເຂັມກົງກັນ
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // ເບິ່ງວ່າພາກສ່ວນທີ່ຖືກຕ້ອງຂອງເຂັມກົງກັນ
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // ພວກເຮົາໄດ້ພົບກັບການຈັບຄູ່!
            let match_pos = self.end - needle.len();
            // Note: sub self.period ແທນ needle.len() ເພື່ອໃຫ້ມີການຈັບຄູ່ກັນ
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // ລວບລວມເອົາ ຄຳ ທີ່ມີຜົນສູງສຸດຂອງ `arr`.
    //
    // ປະໂຫຍກສູງສຸດແມ່ນປັດໃຈວິເຄາະທີ່ເປັນໄປໄດ້ (u, v) ຂອງ `arr`.
    //
    // ກັບຄືນ (`i`, `p`) ບ່ອນທີ່ `i` ແມ່ນດັດສະນີເລີ່ມຕົ້ນຂອງ v ແລະ `p` ແມ່ນໄລຍະເວລາຂອງ v.
    //
    // `order_greater` ຕັດສິນກໍານົດວ່າຄໍາສັ່ງ lexical ແມ່ນ `<` ຫຼື `>`.
    // ຄໍາສັ່ງທັງສອງຈະຕ້ອງໄດ້ຮັບການຄໍານວນ-ຄໍາສັ່ງທີ່ມີທີ່ໃຫຍ່ທີ່ສຸດ `i` ເຮັດໃຫ້ເປັນປັດໄຈທີ່ສໍາຄັນ.
    //
    //
    // ສໍາລັບກໍລະນີໄລຍະເວລາດົນນານ, ໄລຍະເວລາທີ່ໄດ້ຮັບແມ່ນບໍ່ຄືກັນອ້ອຍຕ້ອຍ (ມັນສັ້ນເກີນໄປ).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // ກົງກັບ i ໃນເຈ້ຍ
        let mut right = 1; // ກົງກັບ j ໃນເຈ້ຍ
        let mut offset = 0; // ກົງກັບ k ໃນເຈ້ຍ, ແຕ່ເລີ່ມຕົ້ນທີ່ 0
        // ເພື່ອໃຫ້ກົງກັບດັດສະນີທີ່ອີງໃສ່ 0.
        let mut period = 1; // ກົງກັບ p ໃນເຈ້ຍ

        while let Some(&a) = arr.get(right + offset) {
            // `left` ຈະ inbounds ໃນເວລາທີ່ `right` ແມ່ນ.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Suffix ແມ່ນນ້ອຍກວ່າ, ໄລຍະເວລາແມ່ນ ຄຳ ນຳ ໜ້າ ທັງ ໝົດ ຈົນເຖິງປະຈຸບັນ.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // ລ່ວງ ໜ້າ ຜ່ານການຄ້າງຫ້ອງຂອງໄລຍະເວລາປະຈຸບັນ.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffix ແມ່ນໃຫຍ່ກວ່າ, ເລີ່ມຕົ້ນຈາກສະຖານທີ່ປະຈຸບັນ.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // ລວບລວມເອົາຕົວຢ່າງສຸດຍອດສູງສຸດຂອງປີ້ນກັບກັນຂອງ `arr`.
    //
    // ປະໂຫຍກສູງສຸດແມ່ນປັດໃຈວິເຄາະທີ່ເປັນໄປໄດ້ (u ', v') ຂອງ `arr`.
    //
    // ກັບຄືນ `i` ບ່ອນທີ່ `i` ແມ່ນດັດສະນີເລີ່ມຕົ້ນຂອງ v ', ຈາກດ້ານຫລັງ;
    // ກັບຄືນທັນທີເມື່ອໄລຍະເວລາຂອງ `known_period` ຖືກບັນລຸ.
    //
    // `order_greater` ຕັດສິນກໍານົດວ່າຄໍາສັ່ງ lexical ແມ່ນ `<` ຫຼື `>`.
    // ຄໍາສັ່ງທັງສອງຈະຕ້ອງໄດ້ຮັບການຄໍານວນ-ຄໍາສັ່ງທີ່ມີທີ່ໃຫຍ່ທີ່ສຸດ `i` ເຮັດໃຫ້ເປັນປັດໄຈທີ່ສໍາຄັນ.
    //
    //
    // ສໍາລັບກໍລະນີໄລຍະເວລາດົນນານ, ໄລຍະເວລາທີ່ໄດ້ຮັບແມ່ນບໍ່ຄືກັນອ້ອຍຕ້ອຍ (ມັນສັ້ນເກີນໄປ).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // ກົງກັບ i ໃນເຈ້ຍ
        let mut right = 1; // ກົງກັບ j ໃນເຈ້ຍ
        let mut offset = 0; // ກົງກັບ k ໃນເຈ້ຍ, ແຕ່ເລີ່ມຕົ້ນທີ່ 0
        // ເພື່ອໃຫ້ກົງກັບດັດສະນີທີ່ອີງໃສ່ 0.
        let mut period = 1; // ກົງກັບ p ໃນເຈ້ຍ
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Suffix ແມ່ນນ້ອຍກວ່າ, ໄລຍະເວລາແມ່ນ ຄຳ ນຳ ໜ້າ ທັງ ໝົດ ຈົນເຖິງປະຈຸບັນ.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // ລ່ວງ ໜ້າ ຜ່ານການຄ້າງຫ້ອງຂອງໄລຍະເວລາປະຈຸບັນ.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffix ແມ່ນໃຫຍ່ກວ່າ, ເລີ່ມຕົ້ນຈາກສະຖານທີ່ປະຈຸບັນ.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy ອະນຸຍາດໃຫ້ວິທີການຄິດໄລ່ການແຂ່ງຂັນທີ່ບໍ່ກົງກັນໄວເທົ່າທີ່ຈະໄວໄດ້, ຫຼືເຮັດວຽກໃນຮູບແບບທີ່ມັນປະຕິເສດຂ້ອນຂ້າງໄວ.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// ຂ້າມໄປຫາໄລຍະກົງກັບໄວເທົ່າທີ່ຈະໄວໄດ້
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// ປະຕິເສດ Emit ເປັນປະ ຈຳ
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}