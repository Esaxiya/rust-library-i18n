/// ຮຸ່ນຂອງຜູ້ປະຕິບັດການໂທທີ່ໃຊ້ເວລາເຄື່ອງຮັບທີ່ບໍ່ປ່ຽນແປງ.
///
/// ຕົວຢ່າງຂອງ `Fn` ສາມາດຖືກເອີ້ນຊ້ ຳ ອີກໂດຍບໍ່ມີການປ່ຽນແປງ.
///
/// *trait (`Fn`) ນີ້ບໍ່ຄວນສັບສົນກັບ [function pointers] (`fn`).*
///
/// `Fn` ຖືກປະຕິບັດໂດຍອັດຕະໂນມັດໂດຍການປິດເຊິ່ງພຽງແຕ່ເອົາເອກະສານອ້າງອີງທີ່ບໍ່ປ່ຽນແປງໄປສູ່ຕົວແປທີ່ຈັບໄດ້ຫຼືບໍ່ເກັບສິ່ງໃດກໍ່ຕາມ, ເຊັ່ນດຽວກັນກັບ (safe) [function pointers] (ມີຂໍ້ມູນບາງຢ່າງ, ເບິ່ງເອກະສານຂອງພວກເຂົາເພື່ອລາຍລະອຽດ).
///
/// ນອກຈາກນັ້ນ, ສຳ ລັບ `F` ປະເພດໃດກໍ່ຕາມທີ່ປະຕິບັດ `Fn`, `&F` ປະຕິບັດ `Fn`, ເຊັ່ນກັນ.
///
/// ເນື່ອງຈາກທັງ [`FnMut`] ແລະ [`FnOnce`] ແມ່ນ supertraits ຂອງ `Fn`, ຕົວຢ່າງໃດໆຂອງ `Fn` ສາມາດໃຊ້ເປັນພາລາມິເຕີທີ່ [`FnMut`] ຫຼື [`FnOnce`] ຄາດວ່າ.
///
/// ໃຊ້ `Fn` ເປັນຂໍ້ຜູກມັດໃນເວລາທີ່ທ່ານຕ້ອງການຍອມຮັບພາລາມິເຕີຂອງປະເພດທີ່ຄ້າຍຄືກັບ ໜ້າ ທີ່ແລະ ຈຳ ເປັນຕ້ອງໂທຫາມັນເລື້ອຍໆແລະບໍ່ມີການປ່ຽນແປງສະຖານະພາບ (ຕົວຢ່າງເຊັ່ນ, ໃນເວລາໂທຫາມັນພ້ອມໆກັນ).
/// ຖ້າທ່ານບໍ່ຕ້ອງການຂໍ້ ກຳ ນົດທີ່ເຄັ່ງຄັດດັ່ງກ່າວ, ໃຫ້ໃຊ້ [`FnMut`] ຫຼື [`FnOnce`] ເປັນຂໍ້ຜູກມັດ.
///
/// ເບິ່ງ [chapter on closures in *The Rust Programming Language*][book] ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຫົວຂໍ້ນີ້.
///
/// ນອກຈາກນີ້ຂອງບັນທຶກແມ່ນ syntax ພິເສດ ສຳ ລັບ `Fn` traits (ຕົວຢ່າງ
/// `Fn(usize, bool) -> usize`).ຜູ້ທີ່ສົນໃຈລາຍລະອຽດດ້ານວິຊາການຂອງສິ່ງນີ້ສາມາດອ້າງອີງເຖິງ [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ການໂທຫາການປິດ
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## ການ ນຳ ໃຊ້ພາລາມິເຕີ `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ເພື່ອໃຫ້ regex ສາມາດອີງໃສ່ `&str: !FnMut` ນັ້ນ
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// ປະຕິບັດການໂທ.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// ຮຸ່ນຂອງຜູ້ປະຕິບັດການໂທທີ່ໃຊ້ເວລາເຄື່ອງຮັບທີ່ສາມາດສັບປ່ຽນໄດ້.
///
/// ກໍລະນີຂອງ `FnMut` ສາມາດຖືກເອີ້ນວ່າຊ້ ຳ ແລ້ວຊ້ ຳ ອີກແລະອາດຈະຫັນປ່ຽນສະຖານະການ.
///
/// `FnMut` ຖືກປະຕິບັດໂດຍອັດຕະໂນມັດໂດຍການປິດເຊິ່ງໃຊ້ການອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບຕົວແປທີ່ຖືກຈັບ, ເຊັ່ນດຽວກັນກັບທຸກປະເພດທີ່ປະຕິບັດ [`Fn`], ຕົວຢ່າງ, (safe) [function pointers] (ເນື່ອງຈາກ `FnMut` ແມ່ນ supertrait of [`Fn`]).
/// ນອກຈາກນັ້ນ, ສຳ ລັບ `F` ປະເພດໃດກໍ່ຕາມທີ່ປະຕິບັດ `FnMut`, `&mut F` ປະຕິບັດ `FnMut`, ເຊັ່ນກັນ.
///
/// ເນື່ອງຈາກວ່າ [`FnOnce`] ແມ່ນຊຸບເປີສະ ໄໝ ຂອງ `FnMut`, ຕົວຢ່າງໃດໆຂອງ `FnMut` ສາມາດໃຊ້ໄດ້ໃນບ່ອນທີ່ຄາດຫວັງວ່າ [`FnOnce`], ແລະເນື່ອງຈາກ [`Fn`] ແມ່ນຕົວຫຍໍ້ຂອງ `FnMut`, ຕົວຢ່າງໃດໆຂອງ [`Fn`] ສາມາດໃຊ້ໄດ້ໃນບ່ອນທີ່ `FnMut` ຄາດຫວັງ.
///
/// ໃຊ້ `FnMut` ເປັນຂໍ້ຜູກມັດໃນເວລາທີ່ທ່ານຕ້ອງການຍອມຮັບພາລາມິເຕີຂອງປະເພດທີ່ຄ້າຍຄືກັບ ໜ້າ ທີ່ແລະຕ້ອງການເອີ້ນມັນຊ້ ຳ ອີກ, ໃນຂະນະທີ່ປ່ອຍໃຫ້ມັນປ່ຽນສະຖານະພາບ.
/// ຖ້າທ່ານບໍ່ຕ້ອງການໃຫ້ພາລາມິເຕີປ່ຽນແປງລັດ, ໃຊ້ [`Fn`] ເປັນຂໍ້ຜູກມັດ;ຖ້າທ່ານບໍ່ ຈຳ ເປັນຕ້ອງໂທຫາມັນເລື້ອຍໆ, ໃຫ້ໃຊ້ [`FnOnce`].
///
/// ເບິ່ງ [chapter on closures in *The Rust Programming Language*][book] ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຫົວຂໍ້ນີ້.
///
/// ນອກຈາກນີ້ຂອງບັນທຶກແມ່ນ syntax ພິເສດ ສຳ ລັບ `Fn` traits (ຕົວຢ່າງ
/// `Fn(usize, bool) -> usize`).ຜູ້ທີ່ສົນໃຈລາຍລະອຽດດ້ານວິຊາການຂອງສິ່ງນີ້ສາມາດອ້າງອີງເຖິງ [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ການໂທຫາການປິດການຈັບພາບເຊິ່ງກັນແລະກັນ
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## ການ ນຳ ໃຊ້ພາລາມິເຕີ `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ເພື່ອໃຫ້ regex ສາມາດອີງໃສ່ `&str: !FnMut` ນັ້ນ
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// ປະຕິບັດການໂທ.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// ຮຸ່ນຂອງຜູ້ປະຕິບັດການໂທທີ່ໃຊ້ເວລາຜູ້ຮັບໂດຍມູນຄ່າ.
///
/// ກໍລະນີຂອງ `FnOnce` ສາມາດເອີ້ນໄດ້, ແຕ່ອາດຈະບໍ່ສາມາດໂທໄດ້ຫຼາຍຄັ້ງ.ຍ້ອນເຫດນີ້, ຖ້າສິ່ງດຽວທີ່ຮູ້ກ່ຽວກັບປະເພດ ໜຶ່ງ ກໍ່ຄືມັນປະຕິບັດ `FnOnce`, ມັນກໍ່ສາມາດເອີ້ນໄດ້ພຽງຄັ້ງດຽວເທົ່ານັ້ນ.
///
/// `FnOnce` ຖືກປະຕິບັດໂດຍອັດຕະໂນມັດໂດຍການປິດທີ່ອາດຈະ ນຳ ໃຊ້ຕົວແປທີ່ຈັບໄດ້, ເຊັ່ນດຽວກັນກັບທຸກປະເພດທີ່ປະຕິບັດ [`FnMut`], ຕົວຢ່າງ, (safe) [function pointers] (ເນື່ອງຈາກ `FnOnce` ແມ່ນ supertrait of [`FnMut`]).
///
///
/// ເນື່ອງຈາກວ່າທັງສອງ [`Fn`] ແລະ [`FnMut`] ເປັນຕົວຫຍໍ້ຂອງ `FnOnce`, ຕົວຢ່າງໃດໆຂອງ [`Fn`] ຫຼື [`FnMut`] ສາມາດຖືກ ນຳ ໃຊ້ໃນບ່ອນທີ່ຄາດວ່າ `FnOnce`.
///
/// ໃຊ້ `FnOnce` ເປັນຂໍ້ຜູກມັດໃນເວລາທີ່ທ່ານຕ້ອງການຍອມຮັບພາລາມິເຕີຂອງປະເພດທີ່ຄ້າຍຄືກັບ ໜ້າ ທີ່ແລະຕ້ອງການໂທຫາມັນເທື່ອດຽວ.
/// ຖ້າທ່ານຕ້ອງການໂທຫາພາລາມິເຕີຊ້ ຳ ອີກ, ໃຫ້ໃຊ້ [`FnMut`] ເປັນຂີດ ຈຳ ກັດ;ຖ້າທ່ານຍັງຕ້ອງການໃຫ້ມັນບໍ່ຫັນປ່ຽນລັດ, ໃຫ້ໃຊ້ [`Fn`].
///
/// ເບິ່ງ [chapter on closures in *The Rust Programming Language*][book] ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຫົວຂໍ້ນີ້.
///
/// ນອກຈາກນີ້ຂອງບັນທຶກແມ່ນ syntax ພິເສດ ສຳ ລັບ `Fn` traits (ຕົວຢ່າງ
/// `Fn(usize, bool) -> usize`).ຜູ້ທີ່ສົນໃຈລາຍລະອຽດດ້ານວິຊາການຂອງສິ່ງນີ້ສາມາດອ້າງອີງເຖິງ [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ການ ນຳ ໃຊ້ພາລາມິເຕີ `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ກິນຕົວແປທີ່ຈັບໄດ້ຂອງມັນ, ສະນັ້ນມັນບໍ່ສາມາດໃຊ້ໄດ້ຫຼາຍກ່ວາ ໜຶ່ງ ຄັ້ງ.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // ຄວາມພະຍາຍາມທີ່ຈະຂໍເອົາ `func()` ອີກເທື່ອຫນຶ່ງຈະຖິ້ມຂໍ້ຜິດພາດ `use of moved value` ສໍາລັບ `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ບໍ່ສາມາດຮຽກຮ້ອງໄດ້ໃນຈຸດນີ້
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ເພື່ອໃຫ້ regex ສາມາດອີງໃສ່ `&str: !FnMut` ນັ້ນ
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// ປະເພດທີ່ຖືກສົ່ງຄືນຫຼັງຈາກຜູ້ປະກອບການໂທຖືກໃຊ້.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// ປະຕິບັດການໂທ.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}