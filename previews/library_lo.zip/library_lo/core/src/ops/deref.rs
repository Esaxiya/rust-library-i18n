/// ໃຊ້ ສຳ ລັບການປະຕິບັດງານທີ່ບໍ່ສາມາດປ່ຽນແປງໄດ້ເຊັ່ນ `*v`.
///
/// ນອກ ເໜືອ ຈາກການຖືກ ນຳ ໃຊ້ ສຳ ລັບການ ດຳ ເນີນງານທີ່ບໍ່ກ່ຽວຂ້ອງຢ່າງຊັດເຈນກັບຜູ້ປະຕິບັດການ (unary) `*` ໃນສະພາບການທີ່ບໍ່ປ່ຽນແປງ, `Deref` ຍັງຖືກ ນຳ ໃຊ້ໂດຍຜູ້ລວບລວມຂໍ້ມູນໃນຫລາຍໆສະຖານະການ.
/// ກົນໄກນີ້ເອີ້ນວ່າ ['`Deref` coercion'][more].
/// ໃນສະພາບການທີ່ປ່ຽນແປງໄດ້, [`DerefMut`] ຖືກ ນຳ ໃຊ້.
///
/// ການປະຕິບັດ `Deref` ສຳ ລັບຕົວຊີ້ວັດທີ່ສະຫຼາດເຮັດໃຫ້ການເຂົ້າເຖິງຂໍ້ມູນທີ່ຢູ່ເບື້ອງຫຼັງຂອງພວກເຂົາມີຄວາມສະດວກ, ຊຶ່ງເປັນເຫດຜົນທີ່ພວກເຂົາປະຕິບັດ `Deref`.
/// ໃນທາງກົງກັນຂ້າມ, ກົດລະບຽບກ່ຽວກັບ `Deref` ແລະ [`DerefMut`] ໄດ້ຖືກອອກແບບໂດຍສະເພາະເພື່ອຮອງຮັບຈຸດທີ່ສະຫຼາດ.
/// ຍ້ອນເຫດຜົນນີ້,**`Deref` ຄວນຈະຖືກປະຕິບັດ ສຳ ລັບຕົວຊີ້ວັດທີ່ສະຫຼາດເທົ່ານັ້ນ** ເພື່ອຫລີກລ້ຽງຄວາມສັບສົນ.
///
/// ສຳ ລັບເຫດຜົນທີ່ຄ້າຍຄືກັນ,**trait ນີ້ບໍ່ຄວນຫຼົ້ມເຫຼວ**.ຄວາມລົ້ມເຫຼວໃນໄລຍະການປະຕິເສດບໍ່ໄດ້ສາມາດສັບສົນທີ່ສຸດເມື່ອ `Deref` ຖືກຮຽກຮ້ອງຢ່າງຈະແຈ້ງ.
///
/// # ເພີ່ມເຕີມກ່ຽວກັບການບີບບັງຄັບ `Deref`
///
/// ຖ້າ `T` ປະຕິບັດ `Deref<Target = U>`, ແລະ `x` ແມ່ນມູນຄ່າຂອງ `T` ປະເພດ, ຫຼັງຈາກນັ້ນ:
///
/// * ໃນສະພາບການທີ່ບໍ່ປ່ຽນແປງ, `*x` (ບ່ອນທີ່ `T` ບໍ່ແມ່ນເອກະສານອ້າງອີງຫລືຕົວຊີ້ວັດຖຸດິບ) ແມ່ນທຽບເທົ່າກັບ `* Deref::deref(&x)`.
/// * ຄຸນຄ່າຂອງປະເພດ `&T` ແມ່ນຖືກບັງຄັບໃຫ້ມູນຄ່າຂອງປະເພດ `&U`
/// * `T` ປະຕິບັດຕາມວິທີ (immutable) ທັງ ໝົດ ຂອງ `U` ປະເພດ.
///
/// ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ, ເຂົ້າເບິ່ງ [the chapter in *The Rust Programming Language*][book] ພ້ອມທັງພາກສ່ວນອ້າງອິງໃນ [the dereference operator][ref-deref-op], [method resolution] ແລະ [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ໂຄງສ້າງທີ່ມີສະ ໜາມ ດຽວທີ່ສາມາດເຂົ້າເຖິງໄດ້ໂດຍການເຊື່ອມຕໍ່ໂຄງສ້າງ.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// ປະເພດຜົນໄດ້ຮັບຫຼັງຈາກ dereferencing.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// ເອກະສານອ້າງອີງມູນຄ່າ.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// ໃຊ້ ສຳ ລັບການປະຕິບັດງານທີ່ບໍ່ສາມາດປ່ຽນແທນໄດ້, ເຊັ່ນໃນ `*v = 1;`.
///
/// ນອກ ເໜືອ ຈາກການ ນຳ ໃຊ້ ສຳ ລັບການ ດຳ ເນີນງານທີ່ກ່ຽວຂ້ອງກັບຜູ້ ນຳ ໃຊ້ (unary) `*` ໃນສະພາບການທີ່ປ່ຽນແປງໄດ້, `DerefMut` ຍັງຖືກ ນຳ ໃຊ້ຢ່າງຊັດເຈນໂດຍຜູ້ປະກອບຂໍ້ມູນໃນຫລາຍໆສະຖານະການ.
/// ກົນໄກນີ້ເອີ້ນວ່າ ['`Deref` coercion'][more].
/// ໃນສະພາບການທີ່ບໍ່ປ່ຽນແປງ, [`Deref`] ຖືກນໍາໃຊ້.
///
/// ການປະຕິບັດ `DerefMut` ສຳ ລັບຕົວຊີ້ວັດທີ່ສະຫຼາດເຮັດໃຫ້ຂໍ້ມູນທີ່ຢູ່ເບື້ອງຫຼັງປ່ຽນແປງໄດ້ສະດວກ, ນັ້ນແມ່ນເຫດຜົນທີ່ພວກເຂົາປະຕິບັດ `DerefMut`.
/// ໃນທາງກົງກັນຂ້າມ, ກົດລະບຽບກ່ຽວກັບ [`Deref`] ແລະ `DerefMut` ໄດ້ຖືກອອກແບບໂດຍສະເພາະເພື່ອຮອງຮັບຈຸດທີ່ສະຫຼາດ.
/// ເນື່ອງຈາກວ່ານີ້,**`DerefMut` ຄວນຈະຖືກປະຕິບັດພຽງແຕ່ສໍາລັບຜູ້ທີ່ສະຫລາດເທົ່ານັ້ນ** ເພື່ອຫລີກລ້ຽງຄວາມສັບສົນ.
///
/// ສຳ ລັບເຫດຜົນທີ່ຄ້າຍຄືກັນ,**trait ນີ້ບໍ່ຄວນຫຼົ້ມເຫຼວ**.ຄວາມລົ້ມເຫຼວໃນໄລຍະການປະຕິເສດບໍ່ໄດ້ສາມາດສັບສົນທີ່ສຸດເມື່ອ `DerefMut` ຖືກຮຽກຮ້ອງຢ່າງຈະແຈ້ງ.
///
/// # ເພີ່ມເຕີມກ່ຽວກັບການບີບບັງຄັບ `Deref`
///
/// ຖ້າ `T` ປະຕິບັດ `DerefMut<Target = U>`, ແລະ `x` ແມ່ນມູນຄ່າຂອງ `T` ປະເພດ, ຫຼັງຈາກນັ້ນ:
///
/// * ໃນສະພາບການທີ່ປ່ຽນແປງໄດ້, `*x` (ບ່ອນທີ່ `T` ບໍ່ແມ່ນເອກະສານອ້າງອີງຫລືຕົວຊີ້ວັດຖຸດິບ) ທຽບເທົ່າກັບ `* DerefMut::deref_mut(&mut x)`.
/// * ຄຸນຄ່າຂອງປະເພດ `&mut T` ແມ່ນຖືກບັງຄັບໃຫ້ມູນຄ່າຂອງປະເພດ `&mut U`
/// * `T` ປະຕິບັດຕາມວິທີ (mutable) ທັງ ໝົດ ຂອງ `U` ປະເພດ.
///
/// ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ, ເຂົ້າເບິ່ງ [the chapter in *The Rust Programming Language*][book] ພ້ອມທັງພາກສ່ວນອ້າງອິງໃນ [the dereference operator][ref-deref-op], [method resolution] ແລະ [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ໂຄງສ້າງທີ່ມີຂະ ແໜງ ການດຽວທີ່ສາມາດປ່ຽນແປງໄດ້ໂດຍການແຍກໂຄງສ້າງ.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// ການຍຶດຖືເຊິ່ງກັນແລະກັນຄຸນຄ່າ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// ຊີ້ໃຫ້ເຫັນວ່າໂຄງສ້າງສາມາດຖືກ ນຳ ໃຊ້ເປັນຜູ້ຮັບວິທີການ, ໂດຍບໍ່ຕ້ອງມີຄຸນລັກສະນະ `arbitrary_self_types`.
///
/// ນີ້ຖືກປະຕິບັດໂດຍປະເພດຕົວຊີ້ po stdlib ເຊັ່ນ `Box<T>`, `Rc<T>`, `&T`, ແລະ `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}