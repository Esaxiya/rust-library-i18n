use crate::ops::Try;

/// ໃຊ້ໃນການບອກປະຕິບັດງານວ່າມັນຄວນຈະອອກກ່ອນຫຼືໄປຕາມປົກກະຕິ.
///
/// ສິ່ງນີ້ຖືກ ນຳ ໃຊ້ໃນເວລາທີ່ເຜີຍແຜ່ສິ່ງຕ່າງໆ (ເຊັ່ນວ່າເສັ້ນສະແດງກາຟິກຫລືຜູ້ມາຢ້ຽມຢາມ) ບ່ອນທີ່ທ່ານຕ້ອງການໃຫ້ຜູ້ໃຊ້ສາມາດເລືອກໄດ້ວ່າຈະອອກກ່ອນຫຼືບໍ່.
/// ການມີ enum ເຮັດໃຫ້ມັນມີຄວາມຊັດເຈນກວ່າ-ບໍ່ຕ້ອງສົງໄສເລີຍວ່າ "wait, what did `false` mean again?"-ແລະອະນຸຍາດໃຫ້ລວມທັງຄ່າ.
///
/// # Examples
///
/// ເລີ່ມຕົ້ນອອກຈາກ [`Iterator::try_for_each`]:
///
/// ```
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// let r = (2..100).try_for_each(|x| {
///     if 403 % x == 0 {
///         return ControlFlow::Break(x)
///     }
///
///     ControlFlow::Continue(())
/// });
/// assert_eq!(r, ControlFlow::Break(13));
/// ```
///
/// traversal ຂັ້ນພື້ນຖານ:
///
/// ```no_run
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// pub struct TreeNode<T> {
///     value: T,
///     left: Option<Box<TreeNode<T>>>,
///     right: Option<Box<TreeNode<T>>>,
/// }
///
/// impl<T> TreeNode<T> {
///     pub fn traverse_inorder<B>(&self, mut f: impl FnMut(&T) -> ControlFlow<B>) -> ControlFlow<B> {
///         if let Some(left) = &self.left {
///             left.traverse_inorder(&mut f)?;
///         }
///         f(&self.value)?;
///         if let Some(right) = &self.right {
///             right.traverse_inorder(&mut f)?;
///         }
///         ControlFlow::Continue(())
///     }
/// }
/// ```
#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ControlFlow<B, C = ()> {
    /// ກ້າວໄປສູ່ໄລຍະຕໍ່ໄປຂອງການປະຕິບັດງານຕາມປົກກະຕິ.
    Continue(C),
    /// ອອກຈາກການປະຕິບັດງານໂດຍບໍ່ມີການແລ່ນໄລຍະຕໍ່ມາ.
    Break(B),
    // ແມ່ນ, ຄໍາສັ່ງຂອງຕົວແປບໍ່ກົງກັບຕົວກໍານົດການປະເພດ.
    // ພວກມັນຢູ່ໃນ ຄຳ ສັ່ງນີ້ເພື່ອໃຫ້ `ControlFlow<A, B>` <-> `Result<B, A>` ແມ່ນການປ່ຽນໃຈເຫລື້ອມໃສໃນການປະຕິບັດ `Try`.
    //
}

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
impl<B, C> Try for ControlFlow<B, C> {
    type Ok = C;
    type Error = B;
    #[inline]
    fn into_result(self) -> Result<Self::Ok, Self::Error> {
        match self {
            ControlFlow::Continue(y) => Ok(y),
            ControlFlow::Break(x) => Err(x),
        }
    }
    #[inline]
    fn from_error(v: Self::Error) -> Self {
        ControlFlow::Break(v)
    }
    #[inline]
    fn from_ok(v: Self::Ok) -> Self {
        ControlFlow::Continue(v)
    }
}

impl<B, C> ControlFlow<B, C> {
    /// ກັບຄືນ `true` ຖ້ານີ້ແມ່ນຕົວແປ `Break`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(ControlFlow::<i32, String>::Break(3).is_break());
    /// assert!(!ControlFlow::<String, i32>::Continue(3).is_break());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_break(&self) -> bool {
        matches!(*self, ControlFlow::Break(_))
    }

    /// ກັບຄືນ `true` ຖ້ານີ້ແມ່ນຕົວແປ `Continue`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(!ControlFlow::<i32, String>::Break(3).is_continue());
    /// assert!(ControlFlow::<String, i32>::Continue(3).is_continue());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_continue(&self) -> bool {
        matches!(*self, ControlFlow::Continue(_))
    }

    /// ແປງ `ControlFlow` ເປັນ `Option` ເຊິ່ງເປັນ `Some` ຖ້າ `ControlFlow` ແມ່ນ `Break` ແລະ `None` ຖ້າບໍ່ດັ່ງນັ້ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert_eq!(ControlFlow::<i32, String>::Break(3).break_value(), Some(3));
    /// assert_eq!(ControlFlow::<String, i32>::Continue(3).break_value(), None);
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn break_value(self) -> Option<B> {
        match self {
            ControlFlow::Continue(..) => None,
            ControlFlow::Break(x) => Some(x),
        }
    }

    /// ແຜນທີ່ `ControlFlow<B, C>` ເຖິງ `ControlFlow<T, C>` ໂດຍການ ນຳ ໃຊ້ຟັງຊັນຄ່າກັບມູນຄ່າພັກຜ່ອນໃນກໍລະນີທີ່ມັນມີ.
    ///
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn map_break<T, F>(self, f: F) -> ControlFlow<T, C>
    where
        F: FnOnce(B) -> T,
    {
        match self {
            ControlFlow::Continue(x) => ControlFlow::Continue(x),
            ControlFlow::Break(x) => ControlFlow::Break(f(x)),
        }
    }
}

impl<R: Try> ControlFlow<R, R::Ok> {
    /// ສ້າງ `ControlFlow` ຈາກທຸກປະເພດການຈັດຕັ້ງປະຕິບັດ `Try`.
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn from_try(r: R) -> Self {
        match Try::into_result(r) {
            Ok(v) => ControlFlow::Continue(v),
            Err(v) => ControlFlow::Break(Try::from_error(v)),
        }
    }

    /// ປ່ຽນ `ControlFlow` ເປັນ `Try` X ປະເພດໃດກໍ່ຕາມ;
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn into_try(self) -> R {
        match self {
            ControlFlow::Continue(v) => Try::from_ok(v),
            ControlFlow::Break(v) => v,
        }
    }
}

impl<B> ControlFlow<B, ()> {
    /// ມັນມັກຈະເປັນກໍລະນີທີ່ບໍ່ມີຄ່າຫຍັງກັບ `Continue`, ສະນັ້ນສິ່ງນີ້ຈະຊ່ວຍໃຫ້ທ່ານຫລີກລ້ຽງການພິມ `(())`, ຖ້າທ່ານມັກ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// let last_used = (1..10).chain(20..25).try_for_each(|x| {
    ///     partial_sum += x;
    ///     if partial_sum > 100 { ControlFlow::Break(x) }
    ///     else { ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(last_used.break_value(), Some(22));
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const CONTINUE: Self = ControlFlow::Continue(());
}

impl<C> ControlFlow<(), C> {
    /// APIs ເຊັ່ນ `try_for_each` ບໍ່ ຈຳ ເປັນຕ້ອງມີຄ່າກັບ `Break`, ດັ່ງນັ້ນສິ່ງນີ້ຈຶ່ງຊ່ວຍໃຫ້ທ່ານຫລີກລ້ຽງການພິມ `(())`, ຖ້າທ່ານຕ້ອງການ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// (1..10).chain(20..25).try_for_each(|x| {
    ///     if partial_sum > 100 { ControlFlow::BREAK }
    ///     else { partial_sum += x; ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(partial_sum, 108);
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const BREAK: Self = ControlFlow::Break(());
}