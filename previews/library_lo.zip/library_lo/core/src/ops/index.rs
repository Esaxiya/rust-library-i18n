/// ໃຊ້ ສຳ ລັບການ ດຳ ເນີນການດັດສະນີ (`container[index]`) ໃນສະພາບການທີ່ບໍ່ປ່ຽນແປງ.
///
/// `container[index]` ແມ່ນນໍ້າຕານທີ່ເປັນຕົວອ່ອນ ສຳ ລັບ `*container.index(index)`, ແຕ່ເມື່ອໃຊ້ເປັນມູນຄ່າທີ່ບໍ່ປ່ຽນແປງໄດ້.
/// ຖ້າມີການຮ້ອງຂໍມູນຄ່າທີ່ສາມາດປ່ຽນແປງໄດ້, [`IndexMut`] ຖືກໃຊ້ແທນ.
/// ນີ້ອະນຸຍາດໃຫ້ສິ່ງທີ່ງາມເຊັ່ນ `let value = v[index]` ຖ້າປະເພດຂອງ `value` ປະຕິບັດ [`Copy`].
///
/// # Examples
///
/// ຕົວຢ່າງຕໍ່ໄປນີ້ປະຕິບັດ `Index` ໃສ່ຖັງ `NucleotideCount` ທີ່ສາມາດອ່ານໄດ້, ເຮັດໃຫ້ຕົວເລກຂອງແຕ່ລະຄົນສາມາດດຶງຂໍ້ມູນໄດ້ດ້ວຍ syntax ດັດສະນີ.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// ປະເພດທີ່ຖືກສົ່ງຄືນຫຼັງຈາກການດັດສະນີ.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// ປະຕິບັດການ ດຳ ເນີນງານດັດສະນີ (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// ໃຊ້ ສຳ ລັບການ ດຳ ເນີນການດັດສະນີ (`container[index]`) ໃນສະພາບການທີ່ສາມາດປ່ຽນແປງໄດ້.
///
/// `container[index]` ແມ່ນນໍ້າຕານທີ່ເປັນຕົວອ່ອນ ສຳ ລັບ `*container.index_mut(index)`, ແຕ່ເມື່ອໃຊ້ເປັນມູນຄ່າທີ່ສາມາດປ່ຽນແປງໄດ້.
/// ຖ້າມີການຮ້ອງຂໍມູນຄ່າທີ່ບໍ່ສາມາດປ່ຽນແປງໄດ້, [`Index`] trait ຖືກໃຊ້ແທນ.
/// ນີ້ອະນຸຍາດໃຫ້ສິ່ງທີ່ງາມເຊັ່ນ `v[index] = value`.
///
/// # Examples
///
/// ການປະຕິບັດທີ່ງ່າຍດາຍທີ່ສຸດຂອງໂຄງສ້າງ `Balance` ທີ່ມີສອງດ້ານ, ເຊິ່ງແຕ່ລະບ່ອນສາມາດດັດສະນີເຊິ່ງກັນແລະກັນແລະບໍ່ປ່ຽນແປງ.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // ໃນກໍລະນີນີ້, `balance[Side::Right]` ແມ່ນນ້ ຳ ຕານ ສຳ ລັບ `*balance.index(Side::Right)`, ເພາະວ່າພວກເຮົາມີພຽງແຕ່* ອ່ານ * `balance[Side::Right]`, ບໍ່ຂຽນມັນ.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // ເຖິງຢ່າງໃດກໍ່ຕາມ, ໃນກໍລະນີນີ້ `balance[Side::Left]` ແມ່ນນ້ ຳ ຕານ ສຳ ລັບ `*balance.index_mut(Side::Left)`, ເພາະວ່າພວກເຮົາ ກຳ ລັງຂຽນ `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// ປະຕິບັດງານດັດສະນີ (`container[index]`) ທີ່ສາມາດປ່ຽນແປງໄດ້.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}