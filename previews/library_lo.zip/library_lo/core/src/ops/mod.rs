//! ຜູ້ປະຕິບັດງານເກີນຂະ ໜາດ.
//!
//! ການປະຕິບັດ traits ເຫຼົ່ານີ້ຊ່ວຍໃຫ້ທ່ານສາມາດບັນຈຸຜູ້ປະຕິບັດງານທີ່ແນ່ນອນ.
//!
//! ບາງສ່ວນຂອງ traits ເຫຼົ່ານີ້ແມ່ນຖືກ ນຳ ເຂົ້າໂດຍ prelude, ດັ່ງນັ້ນມັນມີຢູ່ໃນທຸກໆໂປແກຼມ Rust.ພຽງແຕ່ຜູ້ປະຕິບັດງານທີ່ສະຫນັບສະຫນູນໂດຍ traits ເທົ່ານັ້ນທີ່ສາມາດໂຫລດໄດ້.
//! ຍົກຕົວຢ່າງ, ຕົວປະຕິບັດການເພີ່ມເຕີມ (`+`) ສາມາດຖືກໂຫຼດເກີນ [`Add`] trait, ແຕ່ວ່ານັບຕັ້ງແຕ່ຜູ້ປະຕິບັດການມອບຫມາຍ (`=`) ບໍ່ມີການສະຫນັບສະຫນູນ trait, ມັນບໍ່ມີວິທີໃດທີ່ຈະໂຫລດເກີນຄວາມຈິງຂອງມັນ.
//! ນອກຈາກນັ້ນ, ໂມດູນນີ້ບໍ່ໄດ້ໃຫ້ກົນໄກໃດໆໃນການສ້າງຜູ້ປະກອບການ ໃໝ່.
//! ຖ້າມີການປະຕິບັດງານເກີນຄວາມ ຈຳ ເປັນຫຼືຜູ້ປະຕິບັດການທີ່ ກຳ ນົດເອງ, ທ່ານຄວນເບິ່ງໄປທີ່ເຄື່ອງຄອມພິວເຕີ້ macro ຫຼື compiler ເພື່ອຂະຫຍາຍ syntax ຂອງ Rust.
//!
//! ການປະຕິບັດຂອງຜູ້ປະຕິບັດງານ traits ຄວນເປັນສິ່ງທີ່ບໍ່ມີປະສິດຕິພາບໃນສະພາບການທີ່ກ່ຽວຂ້ອງ, ໃຫ້ຈື່ໄວ້ໃນຄວາມ ໝາຍ ແລະຄວາມ ໝາຍ ປົກກະຕິຂອງມັນ.
//! ຍົກຕົວຢ່າງ, ເມື່ອປະຕິບັດ [`Mul`], ການປະຕິບັດງານຄວນຈະມີຄວາມຄ້າຍຄືກັນກັບການຄູນ (ແລະແບ່ງປັນຄຸນສົມບັດທີ່ຄາດຫວັງໄວ້ເຊັ່ນກັນ.)
//!
//! ໃຫ້ສັງເກດວ່າຜູ້ປະຕິບັດງານສັ້ນວົງຈອນ `&&` ແລະ `||`, ເຊັ່ນ, ພວກເຂົາຈະປະເມີນຜົນງານຄັ້ງທີສອງຂອງພວກເຂົາເທົ່ານັ້ນຖ້າມັນປະກອບສ່ວນໃຫ້ກັບຜົນໄດ້ຮັບ.ເນື່ອງຈາກວ່າພຶດຕິ ກຳ ນີ້ບໍ່ສາມາດບັງຄັບໃຊ້ໄດ້ໂດຍ traits, `&&` ແລະ `||` ບໍ່ໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ເປັນຜູ້ປະຕິບັດການເກີນຂະ ໜາດ.
//!
//! ຜູ້ປະຕິບັດງານຫຼາຍຄົນຖືເອົາການປະຕິບັດງານຂອງພວກເຂົາໂດຍມູນຄ່າ.ໃນສະພາບການທີ່ບໍ່ແມ່ນແບບທົ່ວໄປທີ່ກ່ຽວຂ້ອງກັບປະເພດທີ່ມີຢູ່, ນີ້ມັກຈະບໍ່ແມ່ນບັນຫາ.
//! ເຖິງຢ່າງໃດກໍ່ຕາມ, ການ ນຳ ໃຊ້ຜູ້ປະຕິບັດງານເຫລົ່ານີ້ໃນລະຫັດທົ່ວໄປ, ຮຽກຮ້ອງໃຫ້ມີຄວາມສົນໃຈບາງຢ່າງຖ້າວ່າມີຄຸນຄ່າທີ່ຈະ ນຳ ໃຊ້ຄືນ ໃໝ່ ເຊິ່ງກົງກັນຂ້າມກັບການປ່ອຍໃຫ້ຜູ້ປະກອບການບໍລິໂພກ.ທາງເລືອກ ໜຶ່ງ ແມ່ນການໃຊ້ [`clone`] ບາງຄັ້ງຄາວ.
//! ທາງເລືອກອື່ນແມ່ນອີງໃສ່ປະເພດທີ່ກ່ຽວຂ້ອງກັບການສະ ໜອງ ການປະຕິບັດການເພີ່ມເຕີມ ສຳ ລັບການອ້າງອີງ.
//! ຕົວຢ່າງເຊັ່ນ ສຳ ລັບ `T` ປະເພດທີ່ ກຳ ນົດໂດຍຜູ້ໃຊ້ທີ່ຄາດວ່າຈະສະ ໜັບ ສະ ໜູນ ການເພີ່ມເຕີມ, ມັນອາດຈະເປັນຄວາມຄິດທີ່ດີທີ່ຈະມີທັງ `T` ແລະ `&T` ປະຕິບັດ traits [`Add<T>`][`Add`] ແລະ [`Add<&T>`][`Add`] ເພື່ອໃຫ້ລະຫັດທົ່ວໄປສາມາດຂຽນໄດ້ໂດຍບໍ່ຕ້ອງກົດປຸ່ມ.
//!
//!
//! # Examples
//!
//! ຕົວຢ່າງນີ້ສ້າງໂຄງສ້າງ `Point` ທີ່ປະຕິບັດ [`Add`] ແລະ [`Sub`], ແລະຫຼັງຈາກນັ້ນສະແດງໃຫ້ເຫັນການເພີ່ມແລະຫັກສອງ `ຈຸດ`.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! ເບິ່ງເອກະສານ ສຳ ລັບແຕ່ລະ trait ເພື່ອການປະຕິບັດຕົວຢ່າງ.
//!
//! [`Fn`], [`FnMut`], ແລະ [`FnOnce`] traits ແມ່ນຖືກຈັດຕັ້ງປະຕິບັດໂດຍປະເພດຕ່າງໆທີ່ສາມາດເອີ້ນໄດ້ຄືກັບ ໜ້າ ທີ່.ໃຫ້ສັງເກດວ່າ [`Fn`] ໃຊ້ `&self`, [`FnMut`] ໃຊ້ `&mut self` ແລະ [`FnOnce`] ໃຊ້ເວລາ `self`.
//! ວິທີການເຫຼົ່ານີ້ກົງກັບສາມວິທີການທີ່ສາມາດຮຽກຮ້ອງໃນຕົວຢ່າງເຊັ່ນ: ການເອີ້ນໂດຍການອ້າງອີງ, ການເອີ້ນໂດຍອ້າງອີງ, ແລະການເອີ້ນໂດຍມູນຄ່າ.
//! ການນໍາໃຊ້ທົ່ວໄປທີ່ສຸດຂອງ traits ເຫຼົ່ານີ້ແມ່ນເພື່ອປະຕິບັດ ໜ້າ ທີ່ໃນລະດັບຊັ້ນສູງທີ່ເອົາ ໜ້າ ທີ່ຫຼືປິດເປັນຂໍ້ໂຕ້ແຍ້ງ.
//!
//! ການເອົາ [`Fn`] ເປັນພາລາມິເຕີ:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! ການເອົາ [`FnMut`] ເປັນພາລາມິເຕີ:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! ການເອົາ [`FnOnce`] ເປັນພາລາມິເຕີ:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ກິນຕົວແປທີ່ຈັບໄດ້ຂອງມັນ, ສະນັ້ນມັນບໍ່ສາມາດໃຊ້ໄດ້ຫຼາຍກ່ວາ ໜຶ່ງ ຄັ້ງ
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // ຄວາມພະຍາຍາມທີ່ຈະຂໍເອົາ `func()` ອີກເທື່ອຫນຶ່ງຈະຖິ້ມຂໍ້ຜິດພາດ `use of moved value` ສໍາລັບ `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ບໍ່ສາມາດຮຽກຮ້ອງໄດ້ໃນຈຸດນີ້
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;