/// A trait ສຳ ລັບການປັບແຕ່ງພຶດຕິ ກຳ ຂອງຜູ້ປະຕິບັດການ `?`.
///
/// ປະເພດການປະຕິບັດ `Try` ແມ່ນ ໜຶ່ງ ທີ່ມີວິທີທາງທີ່ສາມາດເບິ່ງເຫັນໄດ້ໃນແງ່ຂອງ success/failure dichotomy.
/// trait ນີ້ຊ່ວຍໃຫ້ທັງສະກັດເອົາຄຸນຄ່າຄວາມ ສຳ ເລັດຫລືລົ້ມເຫຼວເຫລົ່ານັ້ນຈາກຕົວຢ່າງທີ່ມີຢູ່ແລະສ້າງຕົວຢ່າງ ໃໝ່ ຈາກມູນຄ່າຄວາມ ສຳ ເລັດຫລືລົ້ມເຫຼວ.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// ປະເພດຂອງຄຸນຄ່ານີ້ເມື່ອເບິ່ງວ່າປະສົບຜົນ ສຳ ເລັດ.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// ປະເພດຂອງຄ່ານີ້ເມື່ອຖືກເບິ່ງວ່າລົ້ມເຫລວ.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// ນຳ ໃຊ້ຜູ້ປະຕິບັດການ "?".ການກັບຄືນຂອງ `Ok(t)` ຫມາຍຄວາມວ່າການປະຕິບັດຄວນຈະສືບຕໍ່ເປັນປົກກະຕິ, ແລະຜົນໄດ້ຮັບຂອງ `?` ແມ່ນມູນຄ່າ `t`.
    /// ການກັບຄືນຂອງ `Err(e)` ຫມາຍຄວາມວ່າການປະຕິບັດຄວນ branch ກັບ `catch` ທີ່ຢູ່ພາຍໃນ, ຫຼືກັບຄືນມາຈາກຫນ້າທີ່.
    ///
    /// ຖ້າຜົນໄດ້ຮັບ `Err(e)` ຖືກສົ່ງຄືນ, ມູນຄ່າ `e` ຈະເປັນ "wrapped" ໃນປະເພດຜົນຕອບແທນຂອງຂອບເຂດທີ່ປິດລ້ອມ (ເຊິ່ງຕົວມັນເອງຕ້ອງປະຕິບັດ `Try`).
    ///
    /// ໂດຍສະເພາະ, ມູນຄ່າ `X::from_error(From::from(e))` ຖືກສົ່ງຄືນ, ບ່ອນທີ່ `X` ແມ່ນປະເພດຂອງການກັບມາຂອງ ໜ້າ ທີ່ຫຸ້ມຫໍ່.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// ໃສ່ຄ່າຂໍ້ຜິດພາດໃນການສ້າງຜົນໄດ້ຮັບຂອງອົງປະກອບ.
    /// ຍົກຕົວຢ່າງ, `Result::Err(x)` ແລະ `Result::from_error(x)` ແມ່ນທຽບເທົ່າ.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// ຫໍ່ມູນຄ່າ OK ເພື່ອສ້າງຜົນໄດ້ຮັບຂອງອົງປະກອບ.
    /// ຍົກຕົວຢ່າງ, `Result::Ok(x)` ແລະ `Result::from_ok(x)` ແມ່ນທຽບເທົ່າ.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}