use crate::marker::Unsize;

/// Trait ທີ່ຊີ້ໃຫ້ເຫັນວ່ານີ້ແມ່ນຕົວຊີ້ຫລືເຄື່ອງຫໍ່ ສຳ ລັບ ໜຶ່ງ ບ່ອນທີ່ການປະຕິບັດບໍ່ສາມາດປະຕິບັດໄດ້ຕາມຈຸດ ໝາຍ.
///
/// ເບິ່ງ [DST coercion RFC][dst-coerce] ແລະ [the nomicon entry on coercion][nomicon-coerce] ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
///
/// ສຳ ລັບປະເພດຕົວຊີ້ຕົວທີ່ສ້າງແລ້ວ, ຕົວຊີ້ໄປຫາ `T` ຈະບັງຄັບໃຫ້ຕົວຊີ້ໄປຫາ `U` ຖ້າ `T: Unsize<U>` ໂດຍການປ່ຽນຈາກຕົວຊີ້ບາງໆເປັນຕົວຊີ້ໄຂມັນ.
///
/// ສຳ ລັບປະເພດທີ່ ກຳ ຫນົດເອງ, ການບີບບັງຄັບຢູ່ທີ່ນີ້ເຮັດວຽກໂດຍການບັງຄັບ `Foo<T>` ຫາ `Foo<U>` ສະ ໜອງ ໃຫ້ມີ `CoerceUnsized<Foo<U>> for Foo<T>` ຢູ່.
/// ສິ່ງທີ່ບົ່ງບອກດັ່ງກ່າວສາມາດຂຽນໄດ້ຖ້າ `Foo<T>` ມີສະເພາະພາກສະ ໜາມ ທີ່ບໍ່ແມ່ນ phantomdata ດຽວເທົ່ານັ້ນທີ່ກ່ຽວຂ້ອງກັບ `T`.
/// ຖ້າວ່າປະເພດຂອງສະ ໜາມ ນັ້ນແມ່ນ `Bar<T>`, ຕ້ອງມີການປະຕິບັດ `CoerceUnsized<Bar<U>> for Bar<T>`.
/// ການບີບບັງຄັບຈະເຮັດວຽກໂດຍການບັງຄັບໃຫ້ພາກສະຫນາມ `Bar<T>` ເຂົ້າໄປໃນ `Bar<U>` ແລະການຕື່ມຂໍ້ມູນໃສ່ບ່ອນທີ່ຍັງເຫຼືອຈາກ `Foo<T>` ເພື່ອສ້າງ `Foo<U>`.
/// ສິ່ງນີ້ຈະເຈາະລົງໃນສະ ໜາມ ຕົວຊີ້ທິດທາງແລະບັງຄັບສິ່ງນັ້ນ.
///
/// ໂດຍທົ່ວໄປ, ສຳ ລັບຕົວຊີ້ທີ່ສະຫຼາດທ່ານຈະຈັດຕັ້ງປະຕິບັດ `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, ໂດຍມີ `?Sized` ຜູກມັດ `T` ຕົວມັນເອງ.
/// ສຳ ລັບປະເພດຫໍ່ທີ່ຕິດ `T` ໂດຍກົງເຊັ່ນ `Cell<T>` ແລະ `RefCell<T>`, ທ່ານສາມາດປະຕິບັດ `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` ໂດຍກົງ.
///
/// ນີ້ຈະຊ່ວຍໃຫ້ການບັງຄັບຂອງປະເພດເຊັ່ນ: ການເຮັດວຽກ `Cell<Box<T>>`.
///
/// [`Unsize`][unsize] ຖືກ ນຳ ໃຊ້ເພື່ອ ໝາຍ ປະເພດທີ່ສາມາດຖືກບັງຄັບໃຫ້ DST ຖ້າຢູ່ເບື້ອງຫຼັງຕົວຊີ້ວັດ.ມັນຖືກປະຕິບັດໂດຍອັດຕະໂນມັດໂດຍຜູ້ລວບລວມຂໍ້ມູນ.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// ສິ່ງນີ້ຖືກ ນຳ ໃຊ້ເພື່ອຄວາມປອດໄພຂອງວັດຖຸ, ເພື່ອກວດສອບວ່າປະເພດເຄື່ອງຮັບຂອງວິທີການໃດ ໜຶ່ງ ສາມາດສົ່ງຕໍ່ໄດ້.
///
/// ການປະຕິບັດຕົວຢ່າງຂອງ trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}