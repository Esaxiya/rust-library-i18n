// ignore-tidy-filelength

//! ການບໍລິຫານຈັດການແລະການຫມູນໃຊ້ແບບລຽບ.
//!
//! ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມເບິ່ງ [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// ການປະຕິບັດ memchr rust ທີ່ບໍລິສຸດ, ເອົາມາຈາກ rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// ຫນ້າທີ່ນີ້ແມ່ນສາທາລະນະເທົ່ານັ້ນເພາະວ່າມັນບໍ່ມີວິທີອື່ນໃດທີ່ສາມາດທົດສອບຫົວ ໜ່ວຍ heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// ສົ່ງຄືນ ຈຳ ນວນຂອງສ່ວນປະກອບທີ່ຢູ່ໃນຊິ້ນ.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // ຄວາມປອດໄພ: ສຽງດັງເພາະວ່າພວກເຮົາສົ່ງຕໍ່ພາກສະ ໜາມ ທີ່ເປັນປະໂຫຍດ (ເຊິ່ງມັນຕ້ອງເປັນ)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // ຄວາມປອດໄພ: ສິ່ງນີ້ປອດໄພເພາະ `&[T]` ແລະ `FatPtr<T>` ມີຮູບແບບດຽວກັນ.
            // ພຽງແຕ່ `std` ເທົ່ານັ້ນທີ່ສາມາດຮັບປະກັນນີ້.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: ທົດແທນດ້ວຍ `crate::ptr::metadata(self)` ເມື່ອນັ້ນຄົງທີ່ຄົງທີ່.
            // ໃນຖານະເປັນຂອງລາຍລັກອັກສອນນີ້ເຮັດໃຫ້ເກີດຄວາມຜິດພາດ "Const-stable functions can only call other const-stable functions".
            //

            // ຄວາມປອດໄພ: ການເຂົ້າເຖິງມູນຄ່າຈາກສະຫະພັນ `PtrRepr` ແມ່ນປອດໄພຕັ້ງແຕ່ * const T
            // ແລະ PtrComponents<T>ມີຮູບແບບຄວາມ ຈຳ ຄືກັນ.
            // ພຽງແຕ່ std ເທົ່ານັ້ນທີ່ສາມາດຮັບປະກັນນີ້.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// ສົ່ງຄືນ `true` ຖ້າຊິ້ນມີຄວາມຍາວ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ສົ່ງຄືນສ່ວນປະກອບ ທຳ ອິດຂອງຊອຍ, ຫລື `None` ຖ້າມັນຫວ່າງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// ສົ່ງຄືນຕົວຊີ້ທີ່ສາມາດປ່ຽນແປງໄດ້ກັບສ່ວນປະກອບ ທຳ ອິດຂອງຊິ້ນ, ຫຼື `None` ຖ້າມັນຫວ່າງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// ສົ່ງຄືນສ່ວນ ທຳ ອິດແລະສ່ວນທີ່ເຫຼືອທັງ ໝົດ ຂອງສ່ວນປະກອບ, ຫລື `None` ຖ້າມັນຫວ່າງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// ສົ່ງຄືນສ່ວນ ທຳ ອິດແລະສ່ວນທີ່ເຫຼືອທັງ ໝົດ ຂອງສ່ວນປະກອບ, ຫລື `None` ຖ້າມັນຫວ່າງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອແລະສ່ວນທີ່ເຫຼືອຂອງສ່ວນປະກອບຕ່າງໆຂອງຊິ້ນ, ຫຼື `None` ຖ້າມັນຫວ່າງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອແລະສ່ວນທີ່ເຫຼືອຂອງສ່ວນປະກອບຕ່າງໆຂອງຊິ້ນ, ຫຼື `None` ຖ້າມັນຫວ່າງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// ສົ່ງຄືນສ່ວນປະກອບສຸດທ້າຍຂອງຊອຍ, ຫຼື `None` ຖ້າມັນຫວ່າງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// ສົ່ງຄືນຕົວຊີ້ທີ່ສາມາດປ່ຽນແປງໄດ້ກັບສິ່ງສຸດທ້າຍໃນກະດານ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// ກັບຄືນເອກະສານອ້າງອີງໃສ່ອົງປະກອບຫລື subslice ຂື້ນຢູ່ກັບປະເພດຂອງດັດຊະນີ.
    ///
    /// - ຖ້າໃຫ້ ຕຳ ແໜ່ງ, ໃຫ້ສົ່ງ ຄຳ ອ້າງອີງໃສ່ອົງປະກອບທີ່ ຕຳ ແໜ່ງ ນັ້ນຫລື `None` ຖ້າບໍ່ມີຂໍ້ ຈຳ ກັດ.
    ///
    /// - ຖ້າຫາກວ່າໄດ້ຮັບລະດັບໃດ ໜຶ່ງ, ໃຫ້ຄືນຄ່າ subslice ທີ່ສອດຄ້ອງກັບຊ່ວງນັ້ນ, ຫລື `None` ຖ້າບໍ່ມີຂອບເຂດ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// ກັບຄືນເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບສ່ວນປະກອບຫຼືຄ່າຍ່ອຍຂື້ນຢູ່ກັບປະເພດດັດສະນີ (ເບິ່ງ [`get`]) ຫຼື `None` ຖ້າດັດຊະນີບໍ່ຢູ່ໃນຂອບເຂດ.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// ກັບຄືນເອກະສານອ້າງອີງໃສ່ອົງປະກອບຫຼື subslice, ໂດຍບໍ່ຕ້ອງກວດສອບຂໍ້ຜູກມັດ.
    ///
    /// ສຳ ລັບທາງເລືອກທີ່ປອດໄພເຫັນ [`get`].
    ///
    /// # Safety
    ///
    /// ການໂທຫາວິທີການນີ້ດ້ວຍດັດສະນີທີ່ບໍ່ມີຂອບເຂດແມ່ນ *[ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ]* ເຖິງແມ່ນວ່າການອ້າງອິງຜົນໄດ້ຮັບຈະບໍ່ຖືກ ນຳ ໃຊ້.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SAFETY: ແປໄດ້ທຸໄດ້ຕ້ອງປະຕິບັດຫຼາຍທີ່ສຸດຂອງຄວາມຕ້ອງການຄວາມປອດໄພສໍາລັບ `get_unchecked`;
        // ຫຼັງຈາກນັ້ນນໍາແມ່ນ dereferencable ເນື່ອງຈາກວ່າ `self` ແມ່ນກະສານອ້າງອີງທີ່ປອດໄພ.
        // ຕົວຊີ້ໄດ້ກັບຄືນມີຄວາມປອດໄພເພາະວ່າ impl ຂອງ `SliceIndex` ຕ້ອງຮັບປະກັນວ່າມັນແມ່ນ.
        unsafe { &*index.get_unchecked(self) }
    }

    /// ກັບຄືນເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບສ່ວນປະກອບຫຼືສ່ວນຍ່ອຍ, ໂດຍບໍ່ຕ້ອງກວດສອບຂໍ້ຜູກມັດ.
    ///
    /// ສຳ ລັບທາງເລືອກທີ່ປອດໄພເຫັນ [`get_mut`].
    ///
    /// # Safety
    ///
    /// ການໂທຫາວິທີການນີ້ດ້ວຍດັດສະນີທີ່ບໍ່ມີຂອບເຂດແມ່ນ *[ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ]* ເຖິງແມ່ນວ່າການອ້າງອິງຜົນໄດ້ຮັບຈະບໍ່ຖືກ ນຳ ໃຊ້.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍົກສູງຄວາມຕ້ອງການດ້ານຄວາມປອດໄພຂອງ `get_unchecked_mut`;
        // ຫຼັງຈາກນັ້ນນໍາແມ່ນ dereferencable ເນື່ອງຈາກວ່າ `self` ແມ່ນກະສານອ້າງອີງທີ່ປອດໄພ.
        // ຕົວຊີ້ໄດ້ກັບຄືນມີຄວາມປອດໄພເພາະວ່າ impl ຂອງ `SliceIndex` ຕ້ອງຮັບປະກັນວ່າມັນແມ່ນ.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// ສົ່ງເຄື່ອງຊີ້ວັດຖຸດິບຄືນໃຫ້ແທັບຄວາຍຂອງແຜ່ນ.
    ///
    /// ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າສ່ວນທີ່ເຫຼືອອອກຈະເຮັດໃຫ້ຕົວຊີ້ວຽກນີ້ກັບມາ, ຖ້າບໍ່ດັ່ງນັ້ນມັນຈະ ໝາຍ ເຖິງຂີ້ເຫຍື້ອ.
    ///
    /// ຜູ້ໂທຍັງຕ້ອງຮັບປະກັນວ່າ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ຈຸດ XXXX ທີ່ຈະບໍ່ຖືກຂຽນເຖິງ (ຍົກເວັ້ນພາຍໃນ `UnsafeCell`) ໂດຍໃຊ້ຕົວຊີ້ນີ້ຫລືຕົວຊີ້ທີ່ມາຈາກມັນ.
    /// ຖ້າທ່ານຕ້ອງການປ່ຽນເນື້ອໃນຂອງເນື້ອເຫຍື່ອ, ໃຫ້ໃຊ້ [`as_mut_ptr`].
    ///
    /// ການດັດແປງພາຊະນະທີ່ຖືກກ່າວເຖິງໂດຍຊິ້ນສ່ວນນີ້ອາດຈະເຮັດໃຫ້ພື້ນທີ່ປ້ອງກັນຂອງມັນຖືກຈັດສັນ, ເຊິ່ງມັນກໍ່ຈະເຮັດໃຫ້ຕົວຊີ້ບອກໃດໆບໍ່ຖືກຕ້ອງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// ສົ່ງກັບຄືນທີ່ຕົວປ່ຽນແປງທີ່ບໍ່ປອດໄພກັບຊ່ອງຫວ່າງຂອງແຜ່ນ.
    ///
    /// ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າສ່ວນທີ່ເຫຼືອອອກຈະເຮັດໃຫ້ຕົວຊີ້ວຽກນີ້ກັບມາ, ຖ້າບໍ່ດັ່ງນັ້ນມັນຈະ ໝາຍ ເຖິງຂີ້ເຫຍື້ອ.
    ///
    /// ການດັດແປງພາຊະນະທີ່ຖືກກ່າວເຖິງໂດຍຊິ້ນສ່ວນນີ້ອາດຈະເຮັດໃຫ້ພື້ນທີ່ປ້ອງກັນຂອງມັນຖືກຈັດສັນ, ເຊິ່ງມັນກໍ່ຈະເຮັດໃຫ້ຕົວຊີ້ບອກໃດໆບໍ່ຖືກຕ້ອງ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// ສົ່ງຄືນສອງຈຸດດິບທີ່ຢຽດອອກຈາກທ່ອນ.
    ///
    /// ຊ່ວງທີ່ຖືກກັບມາແມ່ນເປີດເຄິ່ງ ໜຶ່ງ, ນັ້ນ ໝາຍ ຄວາມວ່າຕົວຊີ້ປາຍສຸດທ້າຍ *ໜຶ່ງ ໃນອະດີດ* ສ່ວນປະກອບສຸດທ້າຍຂອງການລອກ.
    /// ວິທີນີ້, ສ່ວນທີ່ເປົ່າແມ່ນເປັນຕົວແທນໂດຍສອງຕົວຊີ້ບອກທີ່ເທົ່າກັນ, ແລະຄວາມແຕກຕ່າງລະຫວ່າງສອງຕົວຊີ້ໃຫ້ເຫັນຂະ ໜາດ ຂອງການຕັດ.
    ///
    /// ເບິ່ງ [`as_ptr`] ສຳ ລັບ ຄຳ ເຕືອນກ່ຽວກັບການໃຊ້ຕົວຊີ້ບອກເຫຼົ່ານີ້.ຊີ້ທີ່ສຸດຮຽກຮ້ອງໃຫ້ລະມັດລະວັງເປັນພິເສດຍ້ອນວ່າມັນບໍ່ໄດ້ຊີ້ໃຫ້ເຫັນເຖິງເປັນອົງປະກອບທີ່ຖືກຕ້ອງໃນຫຼັງຈາກນັ້ນນໍາ.
    ///
    /// ຟັງຊັນນີ້ມີປະໂຫຍດຕໍ່ການໂຕ້ຕອບກັບຕ່າງປະເທດທີ່ໃຊ້ສອງຕົວຊີ້ເພື່ອອ້າງອີງເຖິງລະດັບຂອງອົງປະກອບໃນ ໜ່ວຍ ຄວາມ ຈຳ, ຄືກັນກັບ C++ .
    ///
    ///
    /// ມັນຍັງສາມາດເປັນປະໂຫຍດທີ່ຈະກວດເບິ່ງວ່າຕົວຊີ້ໄປຫາອົງປະກອບໃດ ໜຶ່ງ ໝາຍ ເຖິງອົງປະກອບໃດ ໜຶ່ງ ຂອງກະດາດນີ້:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // ຄວາມປອດໄພ: `add` ຢູ່ທີ່ນີ້ແມ່ນປອດໄພ, ເພາະວ່າ:
        //
        //   - ທັງສອງຕົວຊີ້ແມ່ນສ່ວນ ໜຶ່ງ ຂອງວັດຖຸດຽວກັນ, ຍ້ອນວ່າການຊີ້ໃຫ້ເຫັນຈຸດປະສົງໃນອະດີດໂດຍກົງກໍ່ຈະຖືກນັບ.
        //
        //   - ຂະ ໜາດ ຂອງເສັ້ນລິ້ນບໍ່ໃຫຍ່ກວ່າ isize::MAX ໄບ, ດັ່ງທີ່ກ່າວມານີ້:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - ບໍ່ມີການຫໍ່ອ້ອມຮອບທີ່ກ່ຽວຂ້ອງ, ເນື່ອງຈາກວ່າຊິ້ນສ່ວນຕ່າງໆບໍ່ໄດ້ສິ້ນສຸດລົງໃນຕອນທ້າຍຂອງພື້ນທີ່ຢູ່.
        //
        // ເບິ່ງເອກະສານຂອງ pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// ກັບຄືນສອງຈຸດທີ່ບໍ່ປອດໄພເຊິ່ງສາມາດປ່ຽນເປັນສ່ວນໄດ້.
    ///
    /// ຊ່ວງທີ່ຖືກກັບມາແມ່ນເປີດເຄິ່ງ ໜຶ່ງ, ນັ້ນ ໝາຍ ຄວາມວ່າຕົວຊີ້ປາຍສຸດທ້າຍ *ໜຶ່ງ ໃນອະດີດ* ສ່ວນປະກອບສຸດທ້າຍຂອງການລອກ.
    /// ວິທີນີ້, ສ່ວນທີ່ເປົ່າແມ່ນເປັນຕົວແທນໂດຍສອງຕົວຊີ້ບອກທີ່ເທົ່າກັນ, ແລະຄວາມແຕກຕ່າງລະຫວ່າງສອງຕົວຊີ້ໃຫ້ເຫັນຂະ ໜາດ ຂອງການຕັດ.
    ///
    /// ເບິ່ງ [`as_mut_ptr`] ສໍາລັບການເຕືອນໄພກ່ຽວກັບການນໍາໃຊ້ຄໍາແນະນໍາເຫຼົ່ານີ້.
    /// ຕົວຊີ້ປາຍທີ່ສຸດຮຽກຮ້ອງໃຫ້ມີຄວາມລະມັດລະວັງເປັນພິເສດ, ຍ້ອນວ່າມັນບໍ່ໄດ້ຊີ້ໃຫ້ເຫັນເຖິງອົງປະກອບທີ່ຖືກຕ້ອງໃນກະດານ
    ///
    /// ຟັງຊັນນີ້ມີປະໂຫຍດຕໍ່ການໂຕ້ຕອບກັບຕ່າງປະເທດທີ່ໃຊ້ສອງຕົວຊີ້ເພື່ອອ້າງອີງເຖິງລະດັບຂອງອົງປະກອບໃນ ໜ່ວຍ ຄວາມ ຈຳ, ຄືກັນກັບ C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // ຄວາມປອດໄພ: ເບິ່ງ as_ptr_range() ຂ້າງເທິງ ສຳ ລັບເຫດຜົນທີ່ `add` ຢູ່ທີ່ນີ້ປອດໄພ.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// ແລກປ່ຽນສອງອົງປະກອບໃນຊອຍ.
    ///
    /// # Arguments
    ///
    /// * a, ດັດຊະນີຂອງອົງປະກອບ ທຳ ອິດ
    /// * b, ດັດຊະນີຂອງອົງປະກອບທີສອງ
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `a` ຫຼື `b` ຢູ່ນອກຂອບເຂດ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // ບໍ່ສາມາດເອົາສອງເງິນກູ້ຢືມທີ່ປ່ຽນແປງໄດ້ຈາກ vector, ສະນັ້ນໃຊ້ຕົວຊີ້ວັດຖຸດິບ.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // ຄວາມປອດໄພ: `pa` ແລະ `pb` ໄດ້ຖືກສ້າງຂື້ນຈາກການອ້າງອີງທີ່ປ່ຽນແປງໄດ້ຢ່າງປອດໄພແລະອ້າງອີງ
        // ກັບສ່ວນປະກອບທີ່ຢູ່ໃນສ່ວນແລະດັ່ງນັ້ນຈິ່ງຖືກຮັບປະກັນວ່າຖືກຕ້ອງແລະສອດຄ່ອງ.
        // ໃຫ້ສັງເກດວ່າການເຂົ້າເຖິງອົງປະກອບທີ່ຢູ່ເບື້ອງຫຼັງ `a` ແລະ `b` ແມ່ນຖືກກວດເບິ່ງແລະຈະ panic ເມື່ອບໍ່ມີຂອບເຂດ.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// ປ່ຽນ ໃໝ່ ການຈັດ ລຳ ດັບຂອງສ່ວນປະກອບໃນສ່ວນຕ່າງໆ, ໃນສະຖານທີ່.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // ສຳ ລັບປະເພດນ້ອຍໆ, ທຸກໆຄົນອ່ານໃນເສັ້ນທາງ ທຳ ມະດາເຮັດບໍ່ໄດ້ດີ.
        // ພວກເຮົາສາມາດເຮັດໄດ້ດີກວ່າ, ໂດຍມີ load/store ທີ່ບໍ່ໄດ້ມາດຕະຖານທີ່ມີປະສິດຕິພາບ, ໂດຍການໂຫຼດຂະ ໜາດ ໃຫຍ່ແລະການລົງທະບຽນ ໃໝ່.
        //

        // ໂດຍຫລັກການແລ້ວ LLVM ຈະເຮັດແນວໃດສໍາລັບພວກເຮົາ, ຍ້ອນວ່າມັນຮູ້ດີກ່ວາພວກເຮົາເຮັດແນວໃດບໍ່ວ່າຈະເປັນ unaligned ບອກວ່າມີປະສິດທິພາບ (ນັບຕັ້ງແຕ່ການປ່ຽນແປງທີ່ລະຫວ່າງສະບັບ ARM ທີ່ແຕກຕ່າງກັນ, ສໍາລັບການຍົກຕົວຢ່າງ) ແລະສິ່ງທີ່ຂະຫນາດ chunk ທີ່ດີທີ່ສຸດຈະເປັນ.
        // ແຕ່ຫນ້າເສຍດາຍ, ເປັນຂອງ LLVM 4.0 (2017-05) ມັນພຽງແຕ່ກົດວົງຈອນບໍ່ໄດ້, ສະນັ້ນພວກເຮົາຕ້ອງເຮັດແບບນີ້ດ້ວຍຕົນເອງ.
        // (ສົມມຸດຕິຖານ: ປີ້ນກັບກັນແມ່ນມີບັນຫາເພາະວ່າທັງສອງດ້ານສາມາດສອດຄ່ອງກັນແຕກຕ່າງກັນ-ຈະເປັນໄປໄດ້, ເມື່ອຄວາມຍາວຄີກົ້-ດັ່ງນັ້ນບໍ່ມີວິທີການປ່ອຍຕົວກ່ອນແລະໂພດເພື່ອໃຊ້ຊິມກDອງແບບເຕັມຮູບແບບໃນກາງ.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // ໃຊ້ llvm.bswap intrinsic ເພື່ອປີ້ນກັບກັນ u8s ໃນປະໂຫຍດ
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // ຄວາມປອດໄພ: ມີຫລາຍຢ່າງທີ່ຕ້ອງກວດເບິ່ງຢູ່ນີ້:
                //
                // - ໃຫ້ສັງເກດວ່າ `chunk` ແມ່ນທັງ 4 ຫຼື 8 ອັນເນື່ອງມາຈາກການກວດສອບ cfg ຂ້າງເທິງ.ດັ່ງນັ້ນ `chunk - 1` ເປັນຄ່າບວກ.
                // - ການດັດສະນີທີ່ມີດັດສະນີ `i` ແມ່ນດີຍ້ອນວ່າການຮັບປະກັນການກວດສອບຂອງ loop
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - ການດັດສະນີດ້ວຍດັດສະນີ `ln - i - chunk = ln - (i + chunk)` ແມ່ນດີ:
                //   - `i + chunk > 0` ແມ່ນຄວາມຈິງເລັກໆນ້ອຍໆ.
                //   - ຮັບປະກັນການກວດສອບ loop:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, ດັ່ງນັ້ນການຫັກລົບບໍ່ໄດ້ຮັບການ ເໜັງ ຕີງ.
                // - ການໂທ `read_unaligned` ແລະ `write_unaligned` ແມ່ນດີ:
                //   - `pa` ຊີ້ໃຫ້ເຫັນດັດສະນີ `i` ບ່ອນທີ່ `i < ln / 2 - (chunk - 1)` (ເບິ່ງຂ້າງເທິງ) ແລະ `pb` ຊີ້ໃຫ້ດັດສະນີ `ln - i - chunk`, ດັ່ງນັ້ນທັງສອງຢ່າງ ໜ້ອຍ `chunk` ຫຼາຍໄບຕ໌ຫ່າງຈາກຈຸດ `self`.
                //
                //   - ໜ່ວຍ ຄວາມ ຈຳ ທີ່ເລີ່ມຕົ້ນແມ່ນ `usize` ຖືກຕ້ອງ.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // ໃຊ້ແບບ ໝູນ ວຽນ-16 ເພື່ອປີ້ນກັບ u16s ໃນ u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // ຄວາມປອດໄພ: u32 ທີ່ບໍ່ມີໃບຢັ້ງຢືນສາມາດອ່ານໄດ້ຈາກ `i` ຖ້າ `i + 1 < ln`
                // (ແລະແນ່ນອນ `i < ln`), ເພາະວ່າແຕ່ລະອົງປະກອບແມ່ນ 2 ໄບຕ໌ແລະພວກເຮົາ ກຳ ລັງອ່ານ 4.
                //
                // `i + chunk - 1 < ln / 2` # ໃນຂະນະທີ່ສະພາບ
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // ເນື່ອງຈາກວ່າມັນນ້ອຍກວ່າຄວາມຍາວແບ່ງອອກເປັນ 2, ຫຼັງຈາກນັ້ນມັນຕ້ອງຢູ່ໃນຂອບເຂດ.
                //
                // ນີ້ຫມາຍຄວາມວ່າສະພາບ `0 < i + chunk <= ln` ໄດ້ຖືກເຄົາລົບນັບຖືສະເຫມີ, ຮັບປະກັນການຊີ້ `pb` ສາມາດນໍາໃຊ້ໄດ້ຢ່າງປອດໄພ.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // ຄວາມປອດໄພ: `i` ແມ່ນຕໍ່າກ່ວາເຄິ່ງ ໜຶ່ງ ຂອງຄວາມຍາວເທົ່ານັ້ນ
            // ການເຂົ້າເຖິງ `i` ແລະ `ln - i - 1` ແມ່ນປອດໄພ (`i` ເລີ່ມຕົ້ນທີ່ 0 ແລະຈະບໍ່ໄປອີກຕໍ່ໄປກ່ວາ `ln / 2 - 1`).
            // ຕົວຊີ້ວັດທີ່ໄດ້ຮັບ `pa` ແລະ `pb` ຈຶ່ງຖືກຕ້ອງແລະສອດຄ່ອງ, ແລະສາມາດອ່ານແລະຂຽນຫາ.
            //
            //
            unsafe {
                // ແລກປ່ຽນປະສົບທີ່ບໍ່ປອດໄພເພື່ອຫລີກລ້ຽງການຜູກມັດເຊັກໃນການແລກປ່ຽນທີ່ປອດໄພ.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// ສົ່ງຄືນເຄື່ອງປັ່ນປ່ວນ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// ສົ່ງຄືນຕົວປັບທີ່ອະນຸຍາດໃຫ້ປັບຄ່າຂອງແຕ່ລະຄ່າ.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// ສົ່ງຄືນເຄື່ອງ ໝາຍ ລວດໃນໄລຍະ windows ທີ່ຕິດພັນທັງ ໝົດ ຂອງຄວາມຍາວ `size`.
    /// windows ຊ້ອນກັນ.
    /// ຖ້າຫາກວ່າເສດແມ່ນສັ້ນກວ່າ `size`, ຕົວປ່ຽນແປງຈະສົ່ງຄືນບໍ່ມີຄ່າຫຍັງເລີຍ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `size` ແມ່ນ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ຖ້າເສດແມ່ນສັ້ນກວ່າ `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// ສົ່ງຄືນເຄື່ອງປັບໃນໄລຍະ `chunk_size` ອົງປະກອບຂອງທ່ອນໄມ້ໃນແຕ່ລະຄັ້ງ, ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
    ///
    /// ຊິ້ນສ່ວນແມ່ນຊິ້ນແລະບໍ່ຊ້ອນກັນ.ຖ້າ `chunk_size` ບໍ່ແບ່ງຄວາມຍາວຂອງຊິ້ນ, ຫຼັງຈາກນັ້ນຊິ້ນສຸດທ້າຍຈະບໍ່ມີຄວາມຍາວ `chunk_size`.
    ///
    /// ເບິ່ງ [`chunks_exact`] ສຳ ລັບຕົວປ່ຽນແປງນີ້ທີ່ສົ່ງຄືນຊິ້ນສ່ວນຂອງ `chunk_size` ທີ່ແທ້ຈິງ, ແລະ [`rchunks`] ສຳ ລັບຕົວປ່ຽນເສັ້ນດຽວກັນແຕ່ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງສ່ວນທີ່ເຫຼືອ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `chunk_size` ແມ່ນ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// ສົ່ງຄືນເຄື່ອງປັບໃນໄລຍະ `chunk_size` ອົງປະກອບຂອງທ່ອນໄມ້ໃນແຕ່ລະຄັ້ງ, ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
    ///
    /// ທ່ອນໄມ້ແມ່ນຊິ້ນທີ່ປ່ຽນແປງໄດ້, ແລະຢ່າຊ້ອນກັນ.ຖ້າ `chunk_size` ບໍ່ໄດ້ແບ່ງຄວາມຍາວຂອງຫຼັງຈາກນັ້ນນໍາ, ຫຼັງຈາກນັ້ນໄດ້ chunk ທີ່ຜ່ານມາຈະບໍ່ມີຄວາມຍາວ `chunk_size`.
    ///
    /// ເບິ່ງ [`chunks_exact_mut`] ສຳ ລັບຕົວປ່ຽນແປງນີ້ທີ່ສົ່ງຄືນຊິ້ນສ່ວນຂອງ `chunk_size` ທີ່ແທ້ຈິງ, ແລະ [`rchunks_mut`] ສຳ ລັບຕົວປ່ຽນເສັ້ນດຽວກັນແຕ່ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງສ່ວນທີ່ເຫຼືອ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `chunk_size` ແມ່ນ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// ສົ່ງຄືນເຄື່ອງປັບໃນໄລຍະ `chunk_size` ອົງປະກອບຂອງທ່ອນໄມ້ໃນແຕ່ລະຄັ້ງ, ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
    ///
    /// ຊິ້ນສ່ວນແມ່ນຊິ້ນແລະບໍ່ຊ້ອນກັນ.
    /// ຖ້າ `chunk_size` ບໍ່ແບ່ງຄວາມຍາວຂອງຊິ້ນ, ຫຼັງຈາກນັ້ນສ່ວນປະກອບສຸດທ້າຍເຖິງ `chunk_size-1` ຈະຖືກຍົກເລີກແລະສາມາດເອົາມາຈາກຟັງຊັນ `remainder` ຂອງໂຕປັບ.
    ///
    ///
    /// ເນື່ອງຈາກແຕ່ລະຊິ້ນມີອົງປະກອບ `chunk_size` ຢ່າງແນ່ນອນ, ຜູ້ລວບລວມຂໍ້ມູນມັກຈະສາມາດເພີ່ມລະຫັດຜົນໄດ້ຮັບທີ່ດີກວ່າໃນກໍລະນີຂອງ [`chunks`].
    ///
    /// ເບິ່ງ [`chunks`] ສຳ ລັບຕົວປ່ຽນແປງນີ້ທີ່ຍັງສົ່ງຄືນສ່ວນທີ່ເຫຼືອເປັນທ່ອນນ້ອຍ, ແລະ [`rchunks_exact`] ສຳ ລັບຕົວປ່ຽນທິດທາງດຽວກັນແຕ່ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງສ່ວນທີ່ເຫຼືອ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `chunk_size` ແມ່ນ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// ສົ່ງຄືນເຄື່ອງປັບໃນໄລຍະ `chunk_size` ອົງປະກອບຂອງທ່ອນໄມ້ໃນແຕ່ລະຄັ້ງ, ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
    ///
    /// ທ່ອນໄມ້ແມ່ນຊິ້ນທີ່ປ່ຽນແປງໄດ້, ແລະຢ່າຊ້ອນກັນ.
    /// ຖ້າ `chunk_size` ບໍ່ໄດ້ແບ່ງຄວາມຍາວຂອງຫຼັງຈາກນັ້ນນໍາ, ຫຼັງຈາກນັ້ນໄດ້ເຖິງທີ່ສຸດໃຫ້ທ່ານອົງປະກອບ `chunk_size-1` ຈະໄດ້ຮັບການຍົກເວັ້ນແລະສາມາດດຶງມາຈາກການທໍາງານຂອງ `into_remainder` ຂອງ iterator ໄດ້.
    ///
    ///
    /// ເນື່ອງຈາກແຕ່ລະຊິ້ນມີອົງປະກອບ `chunk_size` ຢ່າງແນ່ນອນ, ຜູ້ລວບລວມຂໍ້ມູນມັກຈະສາມາດເພີ່ມລະຫັດຜົນໄດ້ຮັບທີ່ດີກວ່າໃນກໍລະນີຂອງ [`chunks_mut`].
    ///
    /// ເບິ່ງ [`chunks_mut`] ສຳ ລັບຕົວປ່ຽນແປງນີ້ທີ່ຍັງສົ່ງຄືນສ່ວນທີ່ເຫຼືອເປັນທ່ອນນ້ອຍ, ແລະ [`rchunks_exact_mut`] ສຳ ລັບຕົວປ່ຽນທິດທາງດຽວກັນແຕ່ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງສ່ວນທີ່ເຫຼືອ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `chunk_size` ແມ່ນ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// ແຍກຫຼັງຈາກນັ້ນນໍາເຂົ້າໄປໃນຫຼັງຈາກນັ້ນນໍາຂອງ `ເລ N` ອົງປະກອບເປັນ, ສົມມຸດວ່າບໍ່ມີສ່ວນທີ່ເຫຼືອ.
    ///
    ///
    /// # Safety
    ///
    /// ນີ້ອາດຈະຖືກເອີ້ນວ່າເວລາເທົ່ານັ້ນ
    /// - ສ່ວນຕ່າງໆແມ່ນແຕກອອກເປັນທ່ອນສ່ວນປະກອບຂອງ `N` (`self.len() % N == 0`)).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // ຄວາມປອດໄພ: ຄອກ 1 ອົງປະກອບບໍ່ເຄີຍມີສ່ວນທີ່ເຫຼືອ
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // ຄວາມປອດໄພ: ຄວາມຍາວຂອງ (6) ແມ່ນຄວາມຍາວຂອງ 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // ສິ່ງເຫລົ່ານີ້ຈະບໍ່ມີປະໂຫຍດ:
    /// // ປ່ອຍໃຫ້ເປັນທ່ອນ: &[[_;5]]= slice.as_chunks_unchecked()//ຄວາມຍາວຂອງສ່ວນຕົວບໍ່ແມ່ນສ່ວນໃຫຍ່ຂອງ 5 ອັນໃຫ້ເປັນທ່ອນ:&[[_;0]] chunks= slice.as_chunks_unchecked()//Zero ຂອງຄວາມຍາວປາແມ່ນບໍ່ອະນຸຍາດໃຫ້
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // ຄວາມປອດໄພ: ເງື່ອນໄຂເບື້ອງຕົ້ນຂອງພວກເຮົາແມ່ນສິ່ງທີ່ ຈຳ ເປັນເພື່ອຮຽກຮ້ອງສິ່ງນີ້
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // ຄວາມປອດໄພ: ພວກເຮົາໂຍນອົງປະກອບ `new_len * N` ເຂົ້າ
        // ຫຼັງຈາກນັ້ນນໍາຂອງ `new_len` ຫຼາຍ `N` ອົງປະກອບ chunks.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// ແບ່ງສ່ວນເປັນທ່ອນເປັນສ່ວນປະກອບຂອງ 'N`-Arrays, ເລີ່ມຕົ້ນຈາກເບື້ອງຕົ້ນ, ແລະສ່ວນທີ່ເຫຼືອທີ່ມີຄວາມຍາວ ໜ້ອຍ ກວ່າ `N` ຢ່າງເຂັ້ມງວດ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `N` ແມ່ນ 0. ການກວດສອບນີ້ສ່ວນຫຼາຍອາດຈະປ່ຽນເປັນຂໍ້ຜິດພາດຂອງເວລາທີ່ລວບລວມກ່ອນທີ່ວິທີການນີ້ຈະສະຖຽນລະພາບ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // ຄວາມປອດໄພ: ພວກເຮົາຕົກຕະລຶງ ສຳ ລັບສູນ, ແລະຮັບປະກັນການກໍ່ສ້າງ
        // ວ່າຄວາມຍາວຂອງ subslice ແມ່ນຫຼາຍ N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// ແບ່ງສ່ວນທີ່ເປັນທ່ອນອອກເປັນແຖວ 'N'-Arrays, ເລີ່ມຕົ້ນຈາກສິ້ນສຸດສ່ວນ, ແລະສ່ວນທີ່ເຫຼືອທີ່ມີຄວາມຍາວ ໜ້ອຍ ກວ່າ `N` ຢ່າງເຂັ້ມງວດ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `N` ແມ່ນ 0. ການກວດສອບນີ້ສ່ວນຫຼາຍອາດຈະປ່ຽນເປັນຂໍ້ຜິດພາດຂອງເວລາທີ່ລວບລວມກ່ອນທີ່ວິທີການນີ້ຈະສະຖຽນລະພາບ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // ຄວາມປອດໄພ: ພວກເຮົາຕົກຕະລຶງ ສຳ ລັບສູນ, ແລະຮັບປະກັນການກໍ່ສ້າງ
        // ວ່າຄວາມຍາວຂອງ subslice ແມ່ນຫຼາຍ N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// ສົ່ງຄືນເຄື່ອງປັບໃນໄລຍະ `N` ອົງປະກອບຂອງທ່ອນໄມ້ໃນແຕ່ລະຄັ້ງ, ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
    ///
    /// ທ່ອນໄມ້ແມ່ນການອ້າງອິງຂບວນແລະບໍ່ຊ້ອນກັນ.
    /// ຖ້າ `N` ບໍ່ແບ່ງຄວາມຍາວຂອງຊິ້ນ, ຫຼັງຈາກນັ້ນສ່ວນປະກອບສຸດທ້າຍເຖິງ `N-1` ຈະຖືກຍົກເລີກແລະສາມາດເອົາມາຈາກຟັງຊັນ `remainder` ຂອງໂຕປັບ.
    ///
    ///
    /// ວິທີການນີ້ແມ່ນທຽບເທົ່າ generic const ຂອງ [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `N` ແມ່ນ 0. ການກວດສອບນີ້ສ່ວນຫຼາຍອາດຈະປ່ຽນເປັນຂໍ້ຜິດພາດຂອງເວລາທີ່ລວບລວມກ່ອນທີ່ວິທີການນີ້ຈະສະຖຽນລະພາບ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// ແຍກຫຼັງຈາກນັ້ນນໍາເຂົ້າໄປໃນຫຼັງຈາກນັ້ນນໍາຂອງ `ເລ N` ອົງປະກອບເປັນ, ສົມມຸດວ່າບໍ່ມີສ່ວນທີ່ເຫຼືອ.
    ///
    ///
    /// # Safety
    ///
    /// ນີ້ອາດຈະຖືກເອີ້ນວ່າເວລາເທົ່ານັ້ນ
    /// - ສ່ວນຕ່າງໆແມ່ນແຕກອອກເປັນທ່ອນສ່ວນປະກອບຂອງ `N` (`self.len() % N == 0`)).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // ຄວາມປອດໄພ: ຄອກ 1 ອົງປະກອບບໍ່ເຄີຍມີສ່ວນທີ່ເຫຼືອ
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // ຄວາມປອດໄພ: ຄວາມຍາວຂອງ (6) ແມ່ນຄວາມຍາວຂອງ 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // ສິ່ງເຫລົ່ານີ້ຈະບໍ່ມີປະໂຫຍດ:
    /// // ໃຫ້ chunks: &[[_;5]]= slice.as_chunks_unchecked_mut()//ຄວາມຍາວຫຼັງຈາກນັ້ນນໍາບໍ່ແມ່ນຫຼາຍປະການຂອງ 5 chunks ໃຫ້:&[[_;0]]= slice.as_chunks_unchecked_mut()//ເຄື່ອງຕັດຄວາມຍາວບໍ່ໄດ້ຮັບອະນຸຍາດ
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // ຄວາມປອດໄພ: ເງື່ອນໄຂເບື້ອງຕົ້ນຂອງພວກເຮົາແມ່ນສິ່ງທີ່ ຈຳ ເປັນເພື່ອຮຽກຮ້ອງສິ່ງນີ້
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // ຄວາມປອດໄພ: ພວກເຮົາໂຍນອົງປະກອບ `new_len * N` ເຂົ້າ
        // ຫຼັງຈາກນັ້ນນໍາຂອງ `new_len` ຫຼາຍ `N` ອົງປະກອບ chunks.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// ແບ່ງສ່ວນເປັນທ່ອນເປັນສ່ວນປະກອບຂອງ 'N`-Arrays, ເລີ່ມຕົ້ນຈາກເບື້ອງຕົ້ນ, ແລະສ່ວນທີ່ເຫຼືອທີ່ມີຄວາມຍາວ ໜ້ອຍ ກວ່າ `N` ຢ່າງເຂັ້ມງວດ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `N` ແມ່ນ 0. ການກວດສອບນີ້ສ່ວນຫຼາຍອາດຈະປ່ຽນເປັນຂໍ້ຜິດພາດຂອງເວລາທີ່ລວບລວມກ່ອນທີ່ວິທີການນີ້ຈະສະຖຽນລະພາບ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // ຄວາມປອດໄພ: ພວກເຮົາຕົກຕະລຶງ ສຳ ລັບສູນ, ແລະຮັບປະກັນການກໍ່ສ້າງ
        // ວ່າຄວາມຍາວຂອງ subslice ແມ່ນຫຼາຍ N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// ແບ່ງສ່ວນທີ່ເປັນທ່ອນອອກເປັນແຖວ 'N'-Arrays, ເລີ່ມຕົ້ນຈາກສິ້ນສຸດສ່ວນ, ແລະສ່ວນທີ່ເຫຼືອທີ່ມີຄວາມຍາວ ໜ້ອຍ ກວ່າ `N` ຢ່າງເຂັ້ມງວດ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `N` ແມ່ນ 0. ການກວດສອບນີ້ສ່ວນຫຼາຍອາດຈະປ່ຽນເປັນຂໍ້ຜິດພາດຂອງເວລາທີ່ລວບລວມກ່ອນທີ່ວິທີການນີ້ຈະສະຖຽນລະພາບ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // ຄວາມປອດໄພ: ພວກເຮົາຕົກຕະລຶງ ສຳ ລັບສູນ, ແລະຮັບປະກັນການກໍ່ສ້າງ
        // ວ່າຄວາມຍາວຂອງ subslice ແມ່ນຫຼາຍ N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// ສົ່ງຄືນເຄື່ອງປັບໃນໄລຍະ `N` ອົງປະກອບຂອງທ່ອນໄມ້ໃນແຕ່ລະຄັ້ງ, ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
    ///
    /// ທ່ອນໄມ້ແມ່ນການອ້າງອິງຂບວນທີ່ສາມາດປ່ຽນແປງໄດ້ແລະບໍ່ຊ້ອນກັນ.
    /// ຖ້າ `N` ບໍ່ແບ່ງຄວາມຍາວຂອງຊິ້ນ, ຫຼັງຈາກນັ້ນສ່ວນປະກອບສຸດທ້າຍເຖິງ `N-1` ຈະຖືກຍົກເລີກແລະສາມາດເອົາມາຈາກຟັງຊັນ `into_remainder` ຂອງໂຕປັບ.
    ///
    ///
    /// ວິທີການນີ້ແມ່ນຄ່າທຽບເທົ່າທົ່ວໄປຂອງ [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `N` ແມ່ນ 0. ການກວດສອບນີ້ສ່ວນຫຼາຍອາດຈະປ່ຽນເປັນຂໍ້ຜິດພາດຂອງເວລາທີ່ລວບລວມກ່ອນທີ່ວິທີການນີ້ຈະສະຖຽນລະພາບ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// ສົ່ງຄືນເຄື່ອງວັດແທກທີ່ຊ້ ຳ ຊ້ອນກັນ windows ຂອງ `N` ຂອງຊິ້ນສ່ວນຕ່າງໆ, ເຊິ່ງເລີ່ມຕົ້ນຈາກການເລີ່ມຕົ້ນຂອງຊິ້ນ.
    ///
    ///
    /// ນີ້ແມ່ນຄ່າທຽບເທົ່າທົ່ວໄປຂອງ [`windows`].
    ///
    /// ຖ້າ `N` ໃຫຍ່ກວ່າຂະ ໜາດ ຂອງແຜ່ນ, ມັນຈະບໍ່ກັບຄືນ windows.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `N` ແມ່ນ 0.
    /// ການກວດສອບນີ້ສ່ວນຫຼາຍອາດຈະຖືກປ່ຽນເປັນຂໍ້ຜິດພາດເວລາທີ່ລວບລວມກ່ອນທີ່ວິທີການນີ້ຈະສະຖຽນລະພາບ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// ສົ່ງຄືນເຄື່ອງປັບໃນໄລຍະ `chunk_size` ອົງປະກອບຂອງທ່ອນໄມ້ໃນແຕ່ລະຄັ້ງ, ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງຊິ້ນ.
    ///
    /// ຊິ້ນສ່ວນແມ່ນຊິ້ນແລະບໍ່ຊ້ອນກັນ.ຖ້າ `chunk_size` ບໍ່ແບ່ງຄວາມຍາວຂອງຊິ້ນ, ຫຼັງຈາກນັ້ນຊິ້ນສຸດທ້າຍຈະບໍ່ມີຄວາມຍາວ `chunk_size`.
    ///
    /// ເບິ່ງ [`rchunks_exact`] ສຳ ລັບຕົວປ່ຽນແປງນີ້ທີ່ສົ່ງຄືນຊິ້ນສ່ວນຂອງ `chunk_size` ທີ່ມີຄຸນລັກສະນະສະ ເໝີ, ແລະ [`chunks`] ສຳ ລັບຕົວຊີ້ວັດດຽວກັນແຕ່ເລີ່ມຕົ້ນໃນຕອນຕົ້ນ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `chunk_size` ແມ່ນ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// ສົ່ງຄືນເຄື່ອງປັບໃນໄລຍະ `chunk_size` ອົງປະກອບຂອງທ່ອນໄມ້ໃນແຕ່ລະຄັ້ງ, ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງຊິ້ນ.
    ///
    /// ທ່ອນໄມ້ແມ່ນຊິ້ນທີ່ປ່ຽນແປງໄດ້, ແລະຢ່າຊ້ອນກັນ.ຖ້າ `chunk_size` ບໍ່ໄດ້ແບ່ງຄວາມຍາວຂອງຫຼັງຈາກນັ້ນນໍາ, ຫຼັງຈາກນັ້ນໄດ້ chunk ທີ່ຜ່ານມາຈະບໍ່ມີຄວາມຍາວ `chunk_size`.
    ///
    /// ເບິ່ງ [`rchunks_exact_mut`] ສຳ ລັບຕົວປ່ຽນແປງນີ້ທີ່ສົ່ງຄືນຊິ້ນສ່ວນຂອງ `chunk_size` ທີ່ມີຄຸນລັກສະນະສະ ເໝີ, ແລະ [`chunks_mut`] ສຳ ລັບຕົວຊີ້ວັດດຽວກັນແຕ່ເລີ່ມຕົ້ນໃນຕອນຕົ້ນ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `chunk_size` ແມ່ນ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// ສົ່ງຄືນເຄື່ອງປັບໃນໄລຍະ `chunk_size` ອົງປະກອບຂອງທ່ອນໄມ້ໃນແຕ່ລະຄັ້ງ, ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງຊິ້ນ.
    ///
    /// ຊິ້ນສ່ວນແມ່ນຊິ້ນແລະບໍ່ຊ້ອນກັນ.
    /// ຖ້າ `chunk_size` ບໍ່ແບ່ງຄວາມຍາວຂອງຊິ້ນ, ຫຼັງຈາກນັ້ນສ່ວນປະກອບສຸດທ້າຍເຖິງ `chunk_size-1` ຈະຖືກຍົກເລີກແລະສາມາດເອົາມາຈາກຟັງຊັນ `remainder` ຂອງໂຕປັບ.
    ///
    /// ເນື່ອງຈາກແຕ່ລະຊິ້ນມີອົງປະກອບ `chunk_size` ຢ່າງແນ່ນອນ, ຜູ້ລວບລວມຂໍ້ມູນມັກຈະສາມາດເພີ່ມລະຫັດຜົນໄດ້ຮັບທີ່ດີກວ່າໃນກໍລະນີຂອງ [`chunks`].
    ///
    /// ເບິ່ງ [`rchunks`] ສຳ ລັບຕົວປ່ຽນແປງນີ້ທີ່ຍັງສົ່ງຄືນສ່ວນທີ່ເຫຼືອເປັນທ່ອນນ້ອຍ, ແລະ [`chunks_exact`] ສຳ ລັບຕົວປ່ຽນທິດທາງດຽວກັນແຕ່ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `chunk_size` ແມ່ນ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// ສົ່ງຄືນເຄື່ອງປັບໃນໄລຍະ `chunk_size` ອົງປະກອບຂອງທ່ອນໄມ້ໃນແຕ່ລະຄັ້ງ, ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງຊິ້ນ.
    ///
    /// ທ່ອນໄມ້ແມ່ນຊິ້ນທີ່ປ່ຽນແປງໄດ້, ແລະຢ່າຊ້ອນກັນ.
    /// ຖ້າ `chunk_size` ບໍ່ໄດ້ແບ່ງຄວາມຍາວຂອງຫຼັງຈາກນັ້ນນໍາ, ຫຼັງຈາກນັ້ນໄດ້ເຖິງທີ່ສຸດໃຫ້ທ່ານອົງປະກອບ `chunk_size-1` ຈະໄດ້ຮັບການຍົກເວັ້ນແລະສາມາດດຶງມາຈາກການທໍາງານຂອງ `into_remainder` ຂອງ iterator ໄດ້.
    ///
    /// ເນື່ອງຈາກແຕ່ລະຊິ້ນມີອົງປະກອບ `chunk_size` ຢ່າງແນ່ນອນ, ຜູ້ລວບລວມຂໍ້ມູນມັກຈະສາມາດເພີ່ມລະຫັດຜົນໄດ້ຮັບທີ່ດີກວ່າໃນກໍລະນີຂອງ [`chunks_mut`].
    ///
    /// ເບິ່ງ [`rchunks_mut`] ສຳ ລັບຕົວປ່ຽນແປງນີ້ທີ່ຍັງສົ່ງຄືນສ່ວນທີ່ເຫຼືອເປັນທ່ອນນ້ອຍ, ແລະ [`chunks_exact_mut`] ສຳ ລັບຕົວປ່ຽນທິດທາງດຽວກັນແຕ່ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `chunk_size` ແມ່ນ 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// ສົ່ງຄືນເຄື່ອງປັ່ນປ່ວນໃສ່ຊິ້ນສ່ວນທີ່ຜະລິດແລ່ນທີ່ບໍ່ຊ້ ຳ ຊ້ອນຂອງອົງປະກອບໂດຍໃຊ້ຕົວຊີ້ບອກເພື່ອແຍກພວກມັນອອກ.
    ///
    /// ການຄາດຄະເນໄດ້ຖືກເອີ້ນວ່າມີສອງອົງປະກອບຕິດຕາມດ້ວຍຕົວມັນເອງ, ມັນ ໝາຍ ຄວາມວ່າຕົວ ກຳ ນົດການເອີ້ນວ່າ `slice[0]` ແລະ `slice[1]` ຈາກນັ້ນໃສ່ `slice[1]` ແລະ `slice[2]` ແລະອື່ນໆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ວິທີການນີ້ສາມາດຖືກ ນຳ ໃຊ້ເພື່ອສະກັດລາຍການຍ່ອຍທີ່ຖືກຄັດເລືອກ:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// ສົ່ງຄືນເຄື່ອງປັ່ນປ່ວນໃສ່ຊິ້ນສ່ວນທີ່ຜະລິດການແລ່ນທີ່ບໍ່ປ່ຽນແປງຂອງຊິ້ນສ່ວນຕ່າງໆໂດຍໃຊ້ຕົວຊີ້ບອກເພື່ອແຍກພວກມັນອອກ.
    ///
    /// ການຄາດຄະເນໄດ້ຖືກເອີ້ນວ່າມີສອງອົງປະກອບຕິດຕາມດ້ວຍຕົວມັນເອງ, ມັນ ໝາຍ ຄວາມວ່າຕົວ ກຳ ນົດການເອີ້ນວ່າ `slice[0]` ແລະ `slice[1]` ຈາກນັ້ນໃສ່ `slice[1]` ແລະ `slice[2]` ແລະອື່ນໆ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ວິທີການນີ້ສາມາດຖືກ ນຳ ໃຊ້ເພື່ອສະກັດລາຍການຍ່ອຍທີ່ຖືກຄັດເລືອກ:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// ແບ່ງ ໜຶ່ງ ສ່ວນເປັນສອງອັນໃນດັດຊະນີ.
    ///
    /// ຄັ້ງ ທຳ ອິດຈະມີຕົວຊີ້ບອກທັງ ໝົດ ຈາກ `[0, mid)` (ຍົກເວັ້ນດັດສະນີ `mid` ຕົວມັນເອງ) ແລະອັນທີສອງຈະມີຕົວຊີ້ບອກທັງ ໝົດ ຈາກ `[mid, len)` (ບໍ່ລວມດັດສະນີ `len` ຕົວມັນເອງ).
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // ຄວາມປອດໄພ: `[ptr; mid]` ແລະ `[mid; len]` ແມ່ນຢູ່ພາຍໃນ `self`, ເຊິ່ງ
        // ປະຕິບັດບັນດາຂໍ້ ກຳ ນົດຂອງ `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// ແບ່ງ ໜຶ່ງ ສ່ວນທີ່ສາມາດ ໝູນ ໄດ້ເປັນສອງອັນໃນດັດຊະນີ.
    ///
    /// ຄັ້ງ ທຳ ອິດຈະມີຕົວຊີ້ບອກທັງ ໝົດ ຈາກ `[0, mid)` (ຍົກເວັ້ນດັດສະນີ `mid` ຕົວມັນເອງ) ແລະອັນທີສອງຈະມີຕົວຊີ້ບອກທັງ ໝົດ ຈາກ `[mid, len)` (ບໍ່ລວມດັດສະນີ `len` ຕົວມັນເອງ).
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // ຄວາມປອດໄພ: `[ptr; mid]` ແລະ `[mid; len]` ແມ່ນຢູ່ພາຍໃນ `self`, ເຊິ່ງ
        // ປະຕິບັດບັນດາຂໍ້ ກຳ ນົດຂອງ `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// ແບ່ງເປັນ ໜຶ່ງ ສ່ວນເປັນສອງອັນໃນດັດຊະນີ, ໂດຍບໍ່ຕ້ອງກວດກາຂອບເຂດ.
    ///
    /// ຄັ້ງ ທຳ ອິດຈະມີຕົວຊີ້ບອກທັງ ໝົດ ຈາກ `[0, mid)` (ຍົກເວັ້ນດັດສະນີ `mid` ຕົວມັນເອງ) ແລະອັນທີສອງຈະມີຕົວຊີ້ບອກທັງ ໝົດ ຈາກ `[mid, len)` (ບໍ່ລວມດັດສະນີ `len` ຕົວມັນເອງ).
    ///
    ///
    /// ສຳ ລັບທາງເລືອກທີ່ປອດໄພເຫັນ [`split_at`].
    ///
    /// # Safety
    ///
    /// ການໂທຫາວິທີການນີ້ດ້ວຍດັດສະນີທີ່ບໍ່ມີຂອບເຂດແມ່ນ *[ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ]* ເຖິງແມ່ນວ່າການອ້າງອິງຜົນໄດ້ຮັບຈະບໍ່ຖືກ ນຳ ໃຊ້.ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງກວດເບິ່ງວ່າ `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// ແບ່ງສ່ວນທີ່ສາມາດປ່ຽນເປັນ ໜຶ່ງ ສ່ວນໄດ້ເປັນສອງອັນໃນດັດຊະນີ, ໂດຍບໍ່ຕ້ອງກວດກາຂອບເຂດ.
    ///
    /// ຄັ້ງ ທຳ ອິດຈະມີຕົວຊີ້ບອກທັງ ໝົດ ຈາກ `[0, mid)` (ຍົກເວັ້ນດັດສະນີ `mid` ຕົວມັນເອງ) ແລະອັນທີສອງຈະມີຕົວຊີ້ບອກທັງ ໝົດ ຈາກ `[mid, len)` (ບໍ່ລວມດັດສະນີ `len` ຕົວມັນເອງ).
    ///
    ///
    /// ສຳ ລັບທາງເລືອກທີ່ປອດໄພເຫັນ [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// ການໂທຫາວິທີການນີ້ດ້ວຍດັດສະນີທີ່ບໍ່ມີຂອບເຂດແມ່ນ *[ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ]* ເຖິງແມ່ນວ່າການອ້າງອິງຜົນໄດ້ຮັບຈະບໍ່ຖືກ ນຳ ໃຊ້.ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງກວດເບິ່ງວ່າ `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` ແລະ `[mid; len]` ບໍ່ໄດ້ຊ້ ຳ ຊ້ອນກັນ, ສະນັ້ນການສົ່ງຄືນການອ້າງອິງທີ່ປ່ຽນແປງໄດ້ດີ.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// ສົ່ງຄືນຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍທີ່ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບ `pred`.
    /// ສ່ວນປະກອບທີ່ຈັບຄູ່ບໍ່ໄດ້ບັນຈຸຢູ່ໃນລາຍຍ່ອຍ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ຖ້າອົງປະກອບ ທຳ ອິດຖືກຈັບຄູ່, ສ່ວນເປົ່າຈະແມ່ນລາຍການ ທຳ ອິດທີ່ສົ່ງຄືນໂດຍຕົວປ່ຽນແປງ.
    /// ເຊັ່ນດຽວກັນ, ຖ້າສ່ວນປະກອບສຸດທ້າຍໃນສ່ວນທີ່ຖືກຈັບນັ້ນຖືກຈັບຄູ່, ສ່ວນເປົ່າຈະເປັນລາຍການສຸດທ້າຍທີ່ສົ່ງຄືນໂດຍຜູ້ກວດກາ:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ຖ້າສອງອົງປະກອບທີ່ຈັບຄູ່ຢູ່ຕິດກັນໂດຍກົງ, ສ່ວນທີ່ເປົ່າຈະມີຢູ່ລະຫວ່າງພວກມັນ:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// ສົ່ງຄືນຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍທີ່ສາມາດປ່ຽນແປງໄດ້ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບ `pred`.
    /// ສ່ວນປະກອບທີ່ຈັບຄູ່ບໍ່ໄດ້ບັນຈຸຢູ່ໃນລາຍຍ່ອຍ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// ສົ່ງຄືນຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍທີ່ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບ `pred`.
    /// ສ່ວນປະກອບທີ່ຖືກຈັບນັ້ນແມ່ນບັນຈຸຢູ່ໃນຕອນທ້າຍຂອງ subslice ກ່ອນ ໜ້າ ນີ້ເປັນ ຄຳ ວ່າ terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ຖ້າຫາກວ່າສ່ວນປະກອບສຸດທ້າຍຂອງທ່ອນນັ້ນຖືກກົງກັນ, ສ່ວນປະກອບນັ້ນຈະຖືກພິຈາລະນາເປັນຜູ້ອອກສຽງຂອງຊິ້ນກ່ອນ.
    ///
    /// ຊິ້ນສ່ວນນັ້ນຈະເປັນລາຍການສຸດທ້າຍທີ່ສົ່ງຄືນໂດຍຜູ້ກວດກາ.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// ສົ່ງຄືນຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍທີ່ສາມາດປ່ຽນແປງໄດ້ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບ `pred`.
    /// ສ່ວນປະກອບທີ່ຈັບຄູ່ແມ່ນບັນຈຸຢູ່ໃນ subslice ກ່ອນ ໜ້າ ນີ້ເປັນ ຄຳ ສັບ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// ສົ່ງຄືນຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍທີ່ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບ `pred`, ເລີ່ມຕົ້ນຈາກສິ້ນສ່ວນແລະເຮັດວຽກຫລັງ.
    /// ສ່ວນປະກອບທີ່ຈັບຄູ່ບໍ່ໄດ້ບັນຈຸຢູ່ໃນລາຍຍ່ອຍ.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ເຊັ່ນດຽວກັນກັບ `split()`, ຖ້າວ່າອົງປະກອບ ທຳ ອິດຫລືສຸດທ້າຍຖືກຈັບຄູ່, ສ່ວນເປົ່າຈະເປັນລາຍການ ທຳ ອິດ (ຫລືສຸດທ້າຍ) ທີ່ສົ່ງກັບຄືນໂດຍຜູ້ກວດກາ.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// ສົ່ງຄືນຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍທີ່ສາມາດປ່ຽນແປງໄດ້ແຍກອອກໂດຍອົງປະກອບທີ່ກົງກັບ `pred`, ເລີ່ມຕົ້ນຈາກສິ້ນສຸດຂອງສິ້ນແລະເຮັດວຽກຫລັງ.
    /// ສ່ວນປະກອບທີ່ຈັບຄູ່ບໍ່ໄດ້ບັນຈຸຢູ່ໃນລາຍຍ່ອຍ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// ສົ່ງຄືນຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍທີ່ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບ `pred`, ຈຳ ກັດການກັບຄືນສິນຄ້າທີ່ `n` ສ່ວນໃຫຍ່.
    /// ສ່ວນປະກອບທີ່ຈັບຄູ່ບໍ່ໄດ້ບັນຈຸຢູ່ໃນລາຍຍ່ອຍ.
    ///
    /// ສ່ວນປະກອບສຸດທ້າຍທີ່ສົ່ງຄືນ, ຖ້າມີ, ຈະມີສ່ວນທີ່ເຫຼືອຂອງສ່ວນທີ່ເຫຼືອ.
    ///
    /// # Examples
    ///
    /// ພິມຊິ້ນສ່ວນທີ່ແບ່ງອອກເປັນຄັ້ງດຽວໂດຍ ຈຳ ນວນທີ່ສາມາດແບ່ງອອກເປັນ 3 (ເຊັ່ນ, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// ສົ່ງຄືນຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍທີ່ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບ `pred`, ຈຳ ກັດການກັບຄືນສິນຄ້າທີ່ `n` ສ່ວນໃຫຍ່.
    /// ສ່ວນປະກອບທີ່ຈັບຄູ່ບໍ່ໄດ້ບັນຈຸຢູ່ໃນລາຍຍ່ອຍ.
    ///
    /// ສ່ວນປະກອບສຸດທ້າຍທີ່ສົ່ງຄືນ, ຖ້າມີ, ຈະມີສ່ວນທີ່ເຫຼືອຂອງສ່ວນທີ່ເຫຼືອ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// ສົ່ງຄືນຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍທີ່ຖືກແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບ `pred` ຈຳ ກັດການກັບຄືນມາທີ່ສິນຄ້າ `n` ສ່ວນໃຫຍ່.
    /// ນີ້ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງການສິ້ນແລະເຮັດວຽກຫລັງ.
    /// ສ່ວນປະກອບທີ່ຈັບຄູ່ບໍ່ໄດ້ບັນຈຸຢູ່ໃນລາຍຍ່ອຍ.
    ///
    /// ສ່ວນປະກອບສຸດທ້າຍທີ່ສົ່ງຄືນ, ຖ້າມີ, ຈະມີສ່ວນທີ່ເຫຼືອຂອງສ່ວນທີ່ເຫຼືອ.
    ///
    /// # Examples
    ///
    /// ພິມຊິ້ນສ່ວນທີ່ແບ່ງອອກເປັນຄັ້ງດຽວ, ເລີ່ມຈາກທີ່ສຸດ, ໂດຍຕົວເລກທີ່ສາມາດແບ່ງອອກເປັນ 3 (ເຊັ່ນ, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// ສົ່ງຄືນຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍທີ່ຖືກແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບ `pred` ຈຳ ກັດການກັບຄືນມາທີ່ສິນຄ້າ `n` ສ່ວນໃຫຍ່.
    /// ນີ້ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງການສິ້ນແລະເຮັດວຽກຫລັງ.
    /// ສ່ວນປະກອບທີ່ຈັບຄູ່ບໍ່ໄດ້ບັນຈຸຢູ່ໃນລາຍຍ່ອຍ.
    ///
    /// ສ່ວນປະກອບສຸດທ້າຍທີ່ສົ່ງຄືນ, ຖ້າມີ, ຈະມີສ່ວນທີ່ເຫຼືອຂອງສ່ວນທີ່ເຫຼືອ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// ສົ່ງຄືນ `true` ຖ້າຊິ້ນສ່ວນປະກອບມີອົງປະກອບທີ່ມີມູນຄ່າທີ່ໄດ້ຮັບ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// ຖ້າທ່ານບໍ່ມີ `&T`, ແຕ່ວ່າພຽງແຕ່ `&U` ເທົ່ານັ້ນທີ່ `T: Borrow<U>` (ຕົວຢ່າງ
    /// `ຊ່ອຍແນ່: ຢືມ<str>`), ທ່ານສາມາດໃຊ້ `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // ຫຼັງຈາກນັ້ນນໍາຂອງ `String`
    /// assert!(v.iter().any(|e| e == "hello")); // ຄົ້ນຫາດ້ວຍ `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// ສົ່ງຄືນ `true` ຖ້າ `needle` ແມ່ນ ຄຳ ນຳ ໜ້າ ຂອງ ຄຳ ນຳ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// ກັບຄືນ `true` ສະເຫມີຖ້າ `needle` ແມ່ນຊິ້ນທີ່ບໍ່ມີ:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// ກັບຄືນ `true` ຖ້າ `needle` ແມ່ນຜົນຕໍ່ຂອງສ່ວນທີ່ເຫຼືອ.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// ກັບຄືນ `true` ສະເຫມີຖ້າ `needle` ແມ່ນຊິ້ນທີ່ບໍ່ມີ:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// ສົ່ງຄືນຄ່າຍ່ອຍທີ່ມີ ຄຳ ນຳ ໜ້າ ທີ່ຖືກຍ້າຍອອກ.
    ///
    /// ຖ້າເສດເລີ່ມຕົ້ນດ້ວຍ `prefix`, ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຫຼັງຈາກ ຄຳ ນຳ ໜ້າ, ຫໍ່ດ້ວຍ `Some`.
    /// ຖ້າ `prefix` ຫວ່າງເປົ່າ, ພຽງແຕ່ສົ່ງຄືນຮູບເດີມໆ.
    ///
    /// ຖ້າຫາກວ່າເສດບໍ່ເລີ່ມຕົ້ນດ້ວຍ `prefix`, ໃຫ້ຄືນ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // ຟັງຊັນນີ້ຈະຕ້ອງຂຽນໃຫມ່ວ່າໃນເວລາ SlicePattern ຈະກາຍເປັນ sophisticated ຫຼາຍ.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// ກັບຄືນບັນຊີຍ່ອຍທີ່ມີ ຄຳ ສັ່ງທີ່ເອົາອອກແລ້ວ.
    ///
    /// ຖ້າຫຼັງຈາກນັ້ນນໍາສິ້ນສຸດລົງກັບ `suffix`, ໃຫ້ຜົນໄດ້ຮັບ subslice ກ່ອນທີ່ຈະປະໂຫຍກໄດ້, ຫໍ່ໃນ `Some`.
    /// ຖ້າ `suffix` ຫວ່າງເປົ່າ, ພຽງແຕ່ສົ່ງຄືນຮູບເດີມໆ.
    ///
    /// ຖ້າເສດບໍ່ຈົບດ້ວຍ `suffix`, ສົ່ງຄືນ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // ຟັງຊັນນີ້ຈະຕ້ອງຂຽນໃຫມ່ວ່າໃນເວລາ SlicePattern ຈະກາຍເປັນ sophisticated ຫຼາຍ.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binary ຄົ້ນຫາສ່ວນທີ່ຈັດລຽງ ລຳ ດັບນີ້ ສຳ ລັບອົງປະກອບໃດ ໜຶ່ງ.
    ///
    /// ຖ້າມູນຄ່າພົບແລ້ວ [`Result::Ok`] ກໍ່ຖືກສົ່ງຄືນ, ປະກອບມີດັດຊະນີຂອງອົງປະກອບທີ່ກົງກັນ.
    /// ຖ້າມີຫລາຍນັດ, ການແຂ່ງຂັນນັດໃດອັນ ໜຶ່ງ ກໍ່ສາມາດສົ່ງຄືນໄດ້.
    /// ຖ້າຄ່າບໍ່ພົບເຫັນຫຼັງຈາກນັ້ນ [`Result::Err`] ຖືກສົ່ງຄືນ, ປະກອບມີດັດຊະນີບ່ອນທີ່ອົງປະກອບທີ່ກົງກັນສາມາດຖືກໃສ່ໃນຂະນະທີ່ຮັກສາການຈັດລຽງ ລຳ ດັບ.
    ///
    ///
    /// ເບິ່ງທີ່ [`binary_search_by`], [`binary_search_by_key`], ແລະ [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ເບິ່ງຊຸດຂອງສີ່ອົງປະກອບ.
    /// ຄັ້ງທໍາອິດແມ່ນພົບ, ມີຕໍາແຫນ່ງທີ່ຖືກກໍານົດເປັນເອກະລັກ;ຄັ້ງທີສອງແລະທີສາມແມ່ນບໍ່ພົບ;ສີ່ສາມາດກົງກັບ ຕຳ ແໜ່ງ ໃດ ໜຶ່ງ ໃນ `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// ຖ້າທ່ານຕ້ອງການໃສ່ສິນຄ້າໃສ່ vector ທີ່ມີການຈັດລຽງ, ໃນຂະນະທີ່ຮັກສາການຈັດລຽງ ລຳ ດັບ:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binary ຄົ້ນຫາການຈັດລຽງ ລຳ ດັບແບບນີ້ພ້ອມດ້ວຍຟັງຊັນປຽບທຽບ.
    ///
    /// ຟັງຊັນການປຽບທຽບຄວນປະຕິບັດ ຄຳ ສັ່ງທີ່ສອດຄ່ອງກັບການຈັດລຽງ ລຳ ດັບຂອງສ່ວນທີ່ຕິດພັນ, ສົ່ງຄືນລະຫັດສັ່ງເຊິ່ງສະແດງວ່າການໂຕ້ຖຽງຂອງມັນແມ່ນ `Less`, `Equal` ຫຼື `Greater` ເປົ້າ ໝາຍ ທີ່ຕ້ອງການ.
    ///
    ///
    /// ຖ້າມູນຄ່າພົບແລ້ວ [`Result::Ok`] ກໍ່ຖືກສົ່ງຄືນ, ປະກອບມີດັດຊະນີຂອງອົງປະກອບທີ່ກົງກັນ.ຖ້າມີຫລາຍນັດ, ການແຂ່ງຂັນນັດໃດອັນ ໜຶ່ງ ກໍ່ສາມາດສົ່ງຄືນໄດ້.
    /// ຖ້າຄ່າບໍ່ພົບເຫັນຫຼັງຈາກນັ້ນ [`Result::Err`] ຖືກສົ່ງຄືນ, ປະກອບມີດັດຊະນີບ່ອນທີ່ອົງປະກອບທີ່ກົງກັນສາມາດຖືກໃສ່ໃນຂະນະທີ່ຮັກສາການຈັດລຽງ ລຳ ດັບ.
    ///
    /// ເບິ່ງທີ່ [`binary_search`], [`binary_search_by_key`], ແລະ [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ເບິ່ງຊຸດຂອງສີ່ອົງປະກອບ.ຄັ້ງທໍາອິດແມ່ນພົບ, ມີຕໍາແຫນ່ງທີ່ຖືກກໍານົດເປັນເອກະລັກ;ຄັ້ງທີສອງແລະທີສາມແມ່ນບໍ່ພົບ;ສີ່ສາມາດກົງກັບ ຕຳ ແໜ່ງ ໃດ ໜຶ່ງ ໃນ `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // ຄວາມປອດໄພ: ການໂທໄດ້ຖືກເຮັດໃຫ້ປອດໄພໂດຍການບຸກລຸກດັ່ງຕໍ່ໄປນີ້:
            // - `mid >= 0`
            // - `mid < size`: `mid` ຖືກ ຈຳ ກັດໂດຍ `[left; right)` ຜູກ.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // ເຫດຜົນທີ່ພວກເຮົາ ນຳ ໃຊ້ກະແສຄວບຄຸມ if/else ແທນທີ່ຈະກົງກັບການແຂ່ງຂັນແມ່ນຍ້ອນວ່າການປະຕິບັດການປຽບທຽບການຈັບຄູ່, ເຊິ່ງມີຄວາມລະອຽດອ່ອນ.
            //
            // ນີ້ແມ່ນ x86 asm ສຳ ລັບ u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// ໄບນາລີຊອກຫາຊິ້ນສ່ວນທີ່ຖືກຈັດປະເພດນີ້ພ້ອມດ້ວຍຟັງຊັນການສະກັດເອົາ.
    ///
    /// ສົມມຸດວ່າກະດຸມຖືກຈັດຮຽງໂດຍກຸນແຈ, ຍົກຕົວຢ່າງກັບ [`sort_by_key`] ໂດຍໃຊ້ຟັງຊັນການສະກັດເອົາກຸນແຈດຽວກັນ.
    ///
    /// ຖ້າມູນຄ່າພົບແລ້ວ [`Result::Ok`] ກໍ່ຖືກສົ່ງຄືນ, ປະກອບມີດັດຊະນີຂອງອົງປະກອບທີ່ກົງກັນ.
    /// ຖ້າມີຫລາຍນັດ, ການແຂ່ງຂັນນັດໃດອັນ ໜຶ່ງ ກໍ່ສາມາດສົ່ງຄືນໄດ້.
    /// ຖ້າຄ່າບໍ່ພົບເຫັນຫຼັງຈາກນັ້ນ [`Result::Err`] ຖືກສົ່ງຄືນ, ປະກອບມີດັດຊະນີບ່ອນທີ່ອົງປະກອບທີ່ກົງກັນສາມາດຖືກໃສ່ໃນຂະນະທີ່ຮັກສາການຈັດລຽງ ລຳ ດັບ.
    ///
    ///
    /// ເບິ່ງທີ່ [`binary_search`], [`binary_search_by`], ແລະ [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ເບິ່ງຊຸດຂອງສີ່ອົງປະກອບໃນຊິ້ນສ່ວນຂອງຄູ່ທີ່ຖືກຈັດຮຽງໂດຍອົງປະກອບທີສອງຂອງພວກມັນ.
    /// ຄັ້ງທໍາອິດແມ່ນພົບ, ມີຕໍາແຫນ່ງທີ່ຖືກກໍານົດເປັນເອກະລັກ;ຄັ້ງທີສອງແລະທີສາມແມ່ນບໍ່ພົບ;ສີ່ສາມາດກົງກັບ ຕຳ ແໜ່ງ ໃດ ໜຶ່ງ ໃນ `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links ແມ່ນອະນຸຍາດໃຫ້ເປັນ `slice::sort_by_key` ແມ່ນຢູ່ໃນ crate `alloc`, ແລະດັ່ງນັ້ນບໍ່ໄດ້ຢູ່ຍັງໃນເວລາທີ່ການກໍ່ສ້າງ `core`.
    //
    // ການເຊື່ອມຕໍ່ກັບເຂດລຸ່ມແມ່ນ້ໍາ crate: #74481.ເນື່ອງຈາກວ່າ primitives ເອກະສານພຽງແຕ່ໃນ libstd (#73423) ນີ້ບໍ່ເຄີຍເຮັດໃຫ້ການເຊື່ອມຕໍ່ທີ່ແຕກຫັກໃນການປະຕິບັດ.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// ຈັດຮຽງແຕ່ລະຊິ້ນ, ແຕ່ອາດຈະບໍ່ຮັກສາຄວາມເປັນລະບຽບຂອງອົງປະກອບທີ່ເທົ່າທຽມກັນ.
    ///
    /// ການຈັດລຽງແບບນີ້ແມ່ນບໍ່ສະຖຽນລະພາບ (ໝາຍ ຄວາມວ່າອາດຈະຈັດແຈງອົງປະກອບທີ່ເທົ່າທຽມກັນ), ໃນສະຖານທີ່ (ໝາຍ ຄວາມວ່າບໍ່ໄດ້ຈັດສັນ), ແລະ *O*(*n*\*log(* n*)) ກໍລະນີຮ້າຍແຮງທີ່ສຸດ).
    ///
    /// # ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນ
    ///
    /// ສູດການຄິດໄລ່ໃນປະຈຸບັນແມ່ນອີງໃສ່ [pattern-defeating quicksort][pdqsort] ໂດຍ Orson Peters, ເຊິ່ງປະສົມປະສານກັບກໍລະນີສະເລ່ຍທີ່ລວດໄວຂອງແບບເລັ່ງດ່ວນແບບສຸ່ມພ້ອມກັບກໍລະນີທີ່ຮ້າຍແຮງທີ່ສຸດຂອງ heapsort, ໃນຂະນະທີ່ບັນລຸເວລາເສັ້ນໃນເສັ້ນທີ່ມີຮູບແບບບາງຢ່າງ.
    /// ມັນໃຊ້ບາງແບບແບບສຸ່ມເພື່ອຫລີກລ້ຽງບັນດາກໍລະນີທີ່ເສື່ອມໂຊມ, ແຕ່ວ່າມີ seed ທີ່ຄົງທີ່ເພື່ອໃຫ້ມີພຶດຕິ ກຳ ທີ່ ກຳ ນົດ.
    ///
    /// ໂດຍປົກກະຕິມັນຈະໄວກ່ວາການຈັດຮຽງແບບຄົງທີ່, ຍົກເວັ້ນໃນກໍລະນີພິເສດບໍ່ຫຼາຍປານໃດ, ຕົວຢ່າງ, ເມື່ອແຜ່ນບາງໆປະກອບດ້ວຍຫຼາຍ ລຳ ດັບທີ່ມີການຈັດລຽງກັນ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// ຈັດລຽງ ລຳ ດັບທີ່ມີ ໜ້າ ທີ່ປຽບທຽບ, ແຕ່ອາດຈະບໍ່ຮັກສາຄວາມເປັນລະບຽບຂອງອົງປະກອບທີ່ເທົ່າທຽມກັນ.
    ///
    /// ການຈັດລຽງແບບນີ້ແມ່ນບໍ່ສະຖຽນລະພາບ (ໝາຍ ຄວາມວ່າອາດຈະຈັດແຈງອົງປະກອບທີ່ເທົ່າທຽມກັນ), ໃນສະຖານທີ່ (ໝາຍ ຄວາມວ່າບໍ່ໄດ້ຈັດສັນ), ແລະ *O*(*n*\*log(* n*)) ກໍລະນີຮ້າຍແຮງທີ່ສຸດ).
    ///
    /// ຟັງຊັນການປຽບທຽບຕ້ອງ ກຳ ນົດການຈັດລຽງ ລຳ ດັບທັງ ໝົດ ສຳ ລັບອົງປະກອບທີ່ຢູ່ໃນສ່ວນຕ່າງໆ.ຖ້າການຈັດລຽງ ລຳ ດັບບໍ່ຄົບຖ້ວນ, ຄຳ ສັ່ງຂອງອົງປະກອບຕ່າງໆແມ່ນບໍ່ໄດ້ລະບຸ.ຄຳ ສັ່ງແມ່ນ ຄຳ ສັ່ງທັງ ໝົດ ຖ້າມັນແມ່ນ (ສຳ ລັບ `a`, `b` ແລະ `c`):
    ///
    /// * total ແລະ antisymmetric: ແມ່ນ ໜຶ່ງ ໃນ `a < b`, `a == b` ຫຼື `a > b` ແມ່ນຄວາມຈິງ, ແລະ
    /// * transitive, `a < b` ແລະ `b < c` ໝາຍ ຄວາມວ່າ `a < c`.ດຽວກັນຕ້ອງຖື ສຳ ລັບທັງ `==` ແລະ `>`.
    ///
    /// ຍົກຕົວຢ່າງ, ໃນຂະນະທີ່ [`f64`] ບໍ່ໄດ້ປະຕິບັດ [`Ord`] ເພາະວ່າ `NaN != NaN`, ພວກເຮົາສາມາດໃຊ້ `partial_cmp` ເປັນ ໜ້າ ທີ່ຈັດລຽງ ລຳ ດັບຂອງພວກເຮົາເມື່ອພວກເຮົາຮູ້ວ່າຊິ້ນສ່ວນບໍ່ມີ `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນ
    ///
    /// ສູດການຄິດໄລ່ໃນປະຈຸບັນແມ່ນອີງໃສ່ [pattern-defeating quicksort][pdqsort] ໂດຍ Orson Peters, ເຊິ່ງປະສົມປະສານກັບກໍລະນີສະເລ່ຍທີ່ລວດໄວຂອງແບບເລັ່ງດ່ວນແບບສຸ່ມພ້ອມກັບກໍລະນີທີ່ຮ້າຍແຮງທີ່ສຸດຂອງ heapsort, ໃນຂະນະທີ່ບັນລຸເວລາເສັ້ນໃນເສັ້ນທີ່ມີຮູບແບບບາງຢ່າງ.
    /// ມັນໃຊ້ບາງແບບແບບສຸ່ມເພື່ອຫລີກລ້ຽງບັນດາກໍລະນີທີ່ເສື່ອມໂຊມ, ແຕ່ວ່າມີ seed ທີ່ຄົງທີ່ເພື່ອໃຫ້ມີພຶດຕິ ກຳ ທີ່ ກຳ ນົດ.
    ///
    /// ໂດຍປົກກະຕິມັນຈະໄວກ່ວາການຈັດຮຽງແບບຄົງທີ່, ຍົກເວັ້ນໃນກໍລະນີພິເສດບໍ່ຫຼາຍປານໃດ, ຕົວຢ່າງ, ເມື່ອແຜ່ນບາງໆປະກອບດ້ວຍຫຼາຍ ລຳ ດັບທີ່ມີການຈັດລຽງກັນ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ຄັດກັບຄືນ
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// ຈັດຮຽງສ່ວນປະກອບທີ່ມີ ໜ້າ ທີ່ສະກັດເອົາທີ່ ສຳ ຄັນ, ແຕ່ອາດຈະບໍ່ຮັກສາຄວາມເປັນລະບຽບຂອງອົງປະກອບທີ່ເທົ່າທຽມກັນ.
    ///
    /// ການຈັດລຽງແບບນີ້ແມ່ນບໍ່ສະຖຽນລະພາບ (ໝາຍ ຄວາມວ່າອາດຈະຈັດແຈງອົງປະກອບທີ່ເທົ່າທຽມກັນ), ໃນສະຖານທີ່ (ໝາຍ ເຖິງບໍ່ໄດ້ຈັດສັນ), ແລະ *O*(m\* * n *\* log(*n*)) ກໍລະນີຮ້າຍແຮງທີ່ສຸດ, ເຊິ່ງ ໜ້າ ທີ່ຫຼັກແມ່ນ *O*(*ມ*).
    ///
    /// # ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນ
    ///
    /// ສູດການຄິດໄລ່ໃນປະຈຸບັນແມ່ນອີງໃສ່ [pattern-defeating quicksort][pdqsort] ໂດຍ Orson Peters, ເຊິ່ງປະສົມປະສານກັບກໍລະນີສະເລ່ຍທີ່ລວດໄວຂອງແບບເລັ່ງດ່ວນແບບສຸ່ມພ້ອມກັບກໍລະນີທີ່ຮ້າຍແຮງທີ່ສຸດຂອງ heapsort, ໃນຂະນະທີ່ບັນລຸເວລາເສັ້ນໃນເສັ້ນທີ່ມີຮູບແບບບາງຢ່າງ.
    /// ມັນໃຊ້ບາງແບບແບບສຸ່ມເພື່ອຫລີກລ້ຽງບັນດາກໍລະນີທີ່ເສື່ອມໂຊມ, ແຕ່ວ່າມີ seed ທີ່ຄົງທີ່ເພື່ອໃຫ້ມີພຶດຕິ ກຳ ທີ່ ກຳ ນົດ.
    ///
    /// ຍ້ອນກົນລະຍຸດການໂທທີ່ ສຳ ຄັນຂອງມັນ, [`sort_unstable_by_key`](#method.sort_unstable_by_key) ມີແນວໂນ້ມທີ່ຈະຊ້າກວ່າ [`sort_by_cached_key`](#method.sort_by_cached_key) ໃນກໍລະນີທີ່ ໜ້າ ທີ່ ສຳ ຄັນມີລາຄາແພງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// ຈັດແຈງຊິ້ນສ່ວນດັ່ງກ່າວວ່າສ່ວນປະກອບທີ່ `index` ແມ່ນຢູ່ໃນ ຕຳ ແໜ່ງ ທີ່ຈັດລຽງ ລຳ ດັບສຸດທ້າຍ.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// ຈັດແຈງຊິ້ນສ່ວນ ໃໝ່ ທີ່ມີ ໜ້າ ທີ່ປຽບທຽບເຊັ່ນວ່າອົງປະກອບທີ່ `index` ແມ່ນຢູ່ໃນ ຕຳ ແໜ່ງ ທີ່ຈັດລຽງ ລຳ ດັບສຸດທ້າຍ.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// ຈັດແຈງຊິ້ນສ່ວນ ໃໝ່ ທີ່ມີ ໜ້າ ທີ່ການສະກັດເອົາທີ່ ສຳ ຄັນເຊັ່ນວ່າສ່ວນປະກອບທີ່ `index` ແມ່ນຢູ່ໃນ ຕຳ ແໜ່ງ ທີ່ຈັດລຽງ ລຳ ດັບສຸດທ້າຍ.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// ຈັດແຈງຊິ້ນສ່ວນດັ່ງກ່າວວ່າສ່ວນປະກອບທີ່ `index` ແມ່ນຢູ່ໃນ ຕຳ ແໜ່ງ ທີ່ຈັດລຽງ ລຳ ດັບສຸດທ້າຍ.
    ///
    /// ການປະຕິບັດຕາມນີ້ມີຄຸນສົມບັດເພີ່ມເຕີມວ່າມູນຄ່າໃດໆທີ່ ຕຳ ແໜ່ງ `i < index` ຈະນ້ອຍກວ່າຫຼືເທົ່າກັບມູນຄ່າໃດໆທີ່ ຕຳ ແໜ່ງ `j > index`.
    /// ນອກຈາກນັ້ນ, ການອ້າງອີງນີ້ແມ່ນບໍ່ສະຖຽນລະພາບ (ເຊັ່ນ
    /// ຈຳ ນວນຂອງອົງປະກອບທີ່ເທົ່າທຽມກັນອາດຈະຈົບລົງທີ່ ຕຳ ແໜ່ງ `index`), ໃນສະຖານທີ່ (ເຊັ່ນ
    /// ບໍ່ໄດ້ຈັດສັນ), ແລະ *O*(*n*) ກໍລະນີຮ້າຍແຮງທີ່ສຸດ.
    /// ຟັງຊັນນີ້ຍັງຖືກເອີ້ນວ່າ "kth element" ໃນຫ້ອງສະ ໝຸດ ອື່ນໆ.
    /// ມັນສົ່ງຄືນສາມມິຕິຂອງຄ່າຕໍ່ໄປນີ້: ທຸກໆອົງປະກອບທີ່ນ້ອຍກວ່າ ໜຶ່ງ ໃນດັດຊະນີທີ່ໃຫ້, ມູນຄ່າທີ່ດັດສະນີທີ່ໃຫ້ໄວ້, ແລະສ່ວນປະກອບທັງ ໝົດ ໃຫຍ່ກວ່າ ໜຶ່ງ ໃນດັດຊະນີທີ່ໃຫ້.
    ///
    ///
    /// # ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນ
    ///
    /// ສູດການຄິດໄລ່ໃນປະຈຸບັນແມ່ນອີງໃສ່ສ່ວນທີ່ລວດໄວຂອງລະບົບ algoriths quicksort ດຽວກັນທີ່ໃຊ້ ສຳ ລັບ [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ເມື່ອ `index >= len()`, ໝາຍ ຄວາມວ່າມັນແມ່ນ panics ສະ ເໝີ ຢູ່ໃນບ່ອນຫວ່າງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ຊອກຫາລະດັບປານກາງ
    /// v.select_nth_unstable(2);
    ///
    /// // ພວກເຮົາຮັບປະກັນພຽງແຕ່ສ່ວນ ໜຶ່ງ ເທົ່ານັ້ນທີ່ຈະເປັນ ໜຶ່ງ ໃນສິ່ງຕໍ່ໄປນີ້, ອີງຕາມວິທີທີ່ພວກເຮົາຈັດຮຽງກ່ຽວກັບດັດສະນີທີ່ລະບຸໄວ້.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// ຈັດແຈງຊິ້ນສ່ວນ ໃໝ່ ທີ່ມີ ໜ້າ ທີ່ປຽບທຽບເຊັ່ນວ່າອົງປະກອບທີ່ `index` ແມ່ນຢູ່ໃນ ຕຳ ແໜ່ງ ທີ່ຈັດລຽງ ລຳ ດັບສຸດທ້າຍ.
    ///
    /// ການອ້າງອີງນີ້ມີຄຸນສົມບັດເພີ່ມເຕີມວ່າມູນຄ່າໃດໆທີ່ ຕຳ ແໜ່ງ `i < index` ຈະນ້ອຍກວ່າຫລືເທົ່າກັບຄ່າໃດໆທີ່ ຕຳ ແໜ່ງ `j > index` ໂດຍ ນຳ ໃຊ້ຟັງຊັນປຽບທຽບ.
    /// ນອກຈາກນັ້ນ, ການຈັດລຽງລໍາດັບນີ້ແມ່ນບໍ່ສະຖຽນລະພາບ (ເຊັ່ນວ່າ ຈຳ ນວນຂອງອົງປະກອບທີ່ເທົ່າທຽມກັນອາດຈະສິ້ນສຸດລົງທີ່ ຕຳ ແໜ່ງ `index`), ຢູ່ໃນສະຖານທີ່ (ບໍ່ແມ່ນການຈັດສັນ), ແລະ *O*(*n*) ກໍລະນີຮ້າຍແຮງທີ່ສຸດ.
    /// ຟັງຊັນນີ້ຍັງເອີ້ນວ່າ "kth element" ໃນຫ້ອງສະ ໝຸດ ອື່ນໆ.
    /// ມັນສົ່ງຄືນສາມມິຕິຂອງຄ່າຕໍ່ໄປນີ້: ທຸກໆອົງປະກອບທີ່ນ້ອຍກວ່າ ໜຶ່ງ ໃນດັດຊະນີທີ່ໃຫ້, ມູນຄ່າທີ່ດັດສະນີທີ່ໃຫ້ໄວ້, ແລະສ່ວນປະກອບທັງ ໝົດ ໃຫຍ່ກວ່າ ໜຶ່ງ ໃນດັດຊະນີທີ່ໃຫ້, ໂດຍໃຊ້ຟັງຊັນປຽບທຽບທີ່ໃຫ້.
    ///
    ///
    /// # ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນ
    ///
    /// ສູດການຄິດໄລ່ໃນປະຈຸບັນແມ່ນອີງໃສ່ສ່ວນທີ່ລວດໄວຂອງລະບົບ algoriths quicksort ດຽວກັນທີ່ໃຊ້ ສຳ ລັບ [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ເມື່ອ `index >= len()`, ໝາຍ ຄວາມວ່າມັນແມ່ນ panics ສະ ເໝີ ຢູ່ໃນບ່ອນຫວ່າງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ຊອກຫາເສັ້ນກາງເປັນຖ້າຊິ້ນສ່ວນໄດ້ຖືກຈັດຮຽງຕາມ ລຳ ດັບທີ່ລົງ.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // ພວກເຮົາຮັບປະກັນພຽງແຕ່ສ່ວນ ໜຶ່ງ ເທົ່ານັ້ນທີ່ຈະເປັນ ໜຶ່ງ ໃນສິ່ງຕໍ່ໄປນີ້, ອີງຕາມວິທີທີ່ພວກເຮົາຈັດຮຽງກ່ຽວກັບດັດສະນີທີ່ລະບຸໄວ້.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// ຈັດແຈງຊິ້ນສ່ວນ ໃໝ່ ທີ່ມີ ໜ້າ ທີ່ການສະກັດເອົາທີ່ ສຳ ຄັນເຊັ່ນວ່າສ່ວນປະກອບທີ່ `index` ແມ່ນຢູ່ໃນ ຕຳ ແໜ່ງ ທີ່ຈັດລຽງ ລຳ ດັບສຸດທ້າຍ.
    ///
    /// ການອ້າງອີງນີ້ມີຄຸນສົມບັດເພີ່ມເຕີມວ່າມູນຄ່າໃດໆທີ່ ຕຳ ແໜ່ງ `i < index` ຈະນ້ອຍກວ່າຫລືເທົ່າກັບຄ່າໃດໆທີ່ ຕຳ ແໜ່ງ `j > index` ໂດຍ ນຳ ໃຊ້ຟັງຊັນການສະກັດເອົາຫຼັກ.
    /// ນອກຈາກນັ້ນ, ການຈັດລຽງລໍາດັບນີ້ແມ່ນບໍ່ສະຖຽນລະພາບ (ເຊັ່ນວ່າ ຈຳ ນວນຂອງອົງປະກອບທີ່ເທົ່າທຽມກັນອາດຈະສິ້ນສຸດລົງທີ່ ຕຳ ແໜ່ງ `index`), ຢູ່ໃນສະຖານທີ່ (ບໍ່ແມ່ນການຈັດສັນ), ແລະ *O*(*n*) ກໍລະນີຮ້າຍແຮງທີ່ສຸດ.
    /// ຟັງຊັນນີ້ຍັງເອີ້ນວ່າ "kth element" ໃນຫ້ອງສະ ໝຸດ ອື່ນໆ.
    /// ມັນສົ່ງຄືນສາມມິຕິຂອງຄຸນຄ່າຕໍ່ໄປນີ້: ທຸກໆອົງປະກອບທີ່ນ້ອຍກວ່າ ໜຶ່ງ ໃນດັດຊະນີທີ່ໃຫ້, ມູນຄ່າທີ່ດັດສະນີທີ່ໃຫ້ໄວ້, ແລະສ່ວນປະກອບທັງ ໝົດ ໃຫຍ່ກວ່າ ໜຶ່ງ ໃນດັດຊະນີທີ່ໃຫ້, ໂດຍໃຊ້ຟັງຊັນການສະກັດທີ່ ສຳ ຄັນ.
    ///
    ///
    /// # ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນ
    ///
    /// ສູດການຄິດໄລ່ໃນປະຈຸບັນແມ່ນອີງໃສ່ສ່ວນທີ່ລວດໄວຂອງລະບົບ algoriths quicksort ດຽວກັນທີ່ໃຊ້ ສຳ ລັບ [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics ເມື່ອ `index >= len()`, ໝາຍ ຄວາມວ່າມັນແມ່ນ panics ສະ ເໝີ ຢູ່ໃນບ່ອນຫວ່າງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ກັບຄືນຄ່າປານກາງຄືກັບວ່າອາເລໄດ້ຖືກຈັດຮຽງຕາມຄ່າທີ່ສົມບູນ.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // ພວກເຮົາຮັບປະກັນພຽງແຕ່ສ່ວນ ໜຶ່ງ ເທົ່ານັ້ນທີ່ຈະເປັນ ໜຶ່ງ ໃນສິ່ງຕໍ່ໄປນີ້, ອີງຕາມວິທີທີ່ພວກເຮົາຈັດຮຽງກ່ຽວກັບດັດສະນີທີ່ລະບຸໄວ້.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// ຍ້າຍອົງປະກອບທີ່ຊ້ ຳ ຊ້ອນຕິດຕໍ່ກັນທັງ ໝົດ ໄປສູ່ຈຸດສຸດທ້າຍຕາມການປະຕິບັດ [`PartialEq`] trait.
    ///
    ///
    /// ກັບຄືນສອງຊິ້ນ.ຄັ້ງທໍາອິດບໍ່ມີອົງປະກອບທີ່ຊ້ໍາຊ້ອນກັນ.
    /// ຄັ້ງທີສອງປະກອບມີສິ່ງທີ່ຊ້ ຳ ຊ້ອນກັນທັງ ໝົດ ໂດຍບໍ່ໄດ້ ກຳ ນົດໄວ້.
    ///
    /// ຖ້າຊິ້ນຖືກຈັດຮຽງ, ຊິ້ນທີ່ກັບຄືນມາຄັ້ງ ທຳ ອິດບໍ່ມີຊ້ ຳ ຊ້ອນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// ຍ້າຍທັງ ໝົດ ແຕ່ ທຳ ອິດຂອງສ່ວນປະກອບຕິດຕໍ່ກັນຈົນເຖິງສິ້ນສຸດຂອງຄວາມພໍໃຈຂອງຄວາມ ສຳ ພັນທີ່ເທົ່າທຽມກັນ.
    ///
    /// ກັບຄືນສອງຊິ້ນ.ຄັ້ງທໍາອິດບໍ່ມີອົງປະກອບທີ່ຊ້ໍາຊ້ອນກັນ.
    /// ຄັ້ງທີສອງປະກອບມີສິ່ງທີ່ຊ້ ຳ ຊ້ອນກັນທັງ ໝົດ ໂດຍບໍ່ໄດ້ ກຳ ນົດໄວ້.
    ///
    /// ຟັງຊັນ `same_bucket` ຖືກສົ່ງຜ່ານເອກະສານອ້າງອີງເຖິງສອງອົງປະກອບຈາກສ່ວນຕ່າງໆແລະຕ້ອງ ກຳ ນົດວ່າອົງປະກອບປຽບທຽບເທົ່າກັນຫຼືບໍ່.
    /// ສ່ວນປະກອບຕ່າງໆແມ່ນຖືກສົ່ງຜ່ານທາງກົງກັນຂ້າມຈາກການສັ່ງຊື້ຂອງພວກເຂົາໃນຕອນຄ້ອຍ, ສະນັ້ນຖ້າ `same_bucket(a, b)` ກັບຄືນ `true`, `a` ກໍ່ຈະຖືກຍ້າຍໄປຢູ່ໃນຕອນທ້າຍຂອງສ່ວນທີ່ເຫຼືອ.
    ///
    ///
    /// ຖ້າຊິ້ນຖືກຈັດຮຽງ, ຊິ້ນທີ່ກັບຄືນມາຄັ້ງ ທຳ ອິດບໍ່ມີຊ້ ຳ ຊ້ອນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // ເຖິງແມ່ນວ່າພວກເຮົາມີເອກະສານອ້າງອີງທີ່ສາມາດປ່ຽນແປງໄດ້ກັບ `self`, ພວກເຮົາບໍ່ສາມາດເຮັດການປ່ຽນແປງ *ທີ່ຕົນເອງມັກ*.ການໂທ `same_bucket` ສາມາດ panic, ດັ່ງນັ້ນພວກເຮົາຕ້ອງຮັບປະກັນວ່າສ່ວນຂອງມັນແມ່ນຢູ່ໃນສະພາບທີ່ຖືກຕ້ອງຕະຫຼອດເວລາ.
        //
        // ວິທີທີ່ພວກເຮົາຈັດການກັບສິ່ງນີ້ແມ່ນໂດຍການໃຊ້ການແລກປ່ຽນ;ພວກເຮົາປ່ຽນແປງອົງປະກອບທັງ ໝົດ, ແລກປ່ຽນໃນຂະນະທີ່ພວກເຮົາໄປເພື່ອວ່າໃນທີ່ສຸດອົງປະກອບທີ່ພວກເຮົາຕ້ອງການຈະຮັກສາແມ່ນຢູ່ທາງ ໜ້າ, ແລະສິ່ງທີ່ພວກເຮົາປາດຖະ ໜາ ຈະປະຕິເສດແມ່ນຢູ່ທາງຫລັງ.
        // ຈາກນັ້ນພວກເຮົາສາມາດແຍກອອກເປັນສ່ວນໆ.
        // ການປະຕິບັດງານນີ້ແມ່ນຍັງ `O(n)`.
        //
        // ຕົວຢ່າງ: ພວກເຮົາເລີ່ມຕົ້ນຢູ່ໃນລັດນີ້, ບ່ອນທີ່ `r` ເປັນຕົວແທນ "ຕໍ່ໄປ
        // ອ່ານ "ແລະ `w` ເປັນຕົວແທນ" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // ປຽບທຽບ self[r] ກັບຕົນເອງ [w-1], ນີ້ບໍ່ຊ້ ຳ ກັນ, ດັ່ງນັ້ນພວກເຮົາປ່ຽນ self[r] ແລະ self[w] (ບໍ່ມີຜົນເປັນ r==w) ແລ້ວເພີ່ມຂື້ນທັງ r ແລະ w, ເຮັດໃຫ້ພວກເຮົາມີ:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // ປຽບທຽບ self[r] ກັບຕົນເອງ [w-1], ມູນຄ່ານີ້ແມ່ນຊ້ ຳ ກັນ, ດັ່ງນັ້ນພວກເຮົາເພີ່ມ `r` ແຕ່ປ່ອຍໃຫ້ທຸກຢ່າງບໍ່ປ່ຽນແປງ:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // ປຽບທຽບ self[r] ກັບຕົນເອງ [w-1], ນີ້ບໍ່ຊ້ ຳ ກັນ, ສະນັ້ນແລກປ່ຽນ self[r] ແລະ self[w] ແລະ advance r ແລະ w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // ບໍ່ຊ້ ຳ ກັນ, ເຮັດຊ້ ຳ ອີກ:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // ຊ້ ຳ, advance r. End ຂອງຊິ້ນ.ແບ່ງປັນທີ່ w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // ຄວາມປອດໄພ: ເງື່ອນໄຂ `while` ຮັບປະກັນ `next_read` ແລະ `next_write`
        // ແມ່ນຫນ້ອຍກ່ວາ `len`, ດັ່ງນັ້ນຈຶ່ງຢູ່ພາຍໃນ `self`.
        // `prev_ptr_write` ຊີ້ໃຫ້ເຫັນເຖິງອົງປະກອບໃດ ໜຶ່ງ ກ່ອນ `ptr_write`, ແຕ່ `next_write` ເລີ່ມຕົ້ນທີ່ 1, ສະນັ້ນ `prev_ptr_write` ບໍ່ເຄີຍຕ່ ຳ ກວ່າ 0 ແລະຢູ່ພາຍໃນຊິ້ນ.
        // ນີ້ປະຕິບັດຄວາມຕ້ອງການ ສຳ ລັບການ dereferencing `ptr_read`, `prev_ptr_write` ແລະ `ptr_write`, ແລະ ສຳ ລັບການ ນຳ ໃຊ້ `ptr.add(next_read)`, `ptr.add(next_write - 1)` ແລະ `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` ຍັງມີການເພີ່ມຂື້ນເທື່ອລະເທື່ອຕໍ່ loop ໂດຍສ່ວນໃຫຍ່ ໝາຍ ຄວາມວ່າບໍ່ມີສ່ວນປະກອບໃດໆທີ່ຖືກຂ້າມເມື່ອມັນອາດຈະຕ້ອງໄດ້ຖືກປ່ຽນ.
        //
        // `ptr_read` ແລະ `prev_ptr_write` ບໍ່ເຄີຍຊີ້ໃຫ້ເຫັນອົງປະກອບດຽວກັນ.ສິ່ງນີ້ແມ່ນ ຈຳ ເປັນ ສຳ ລັບ `&mut *ptr_read`, `&mut* prev_ptr_write` ເພື່ອໃຫ້ປອດໄພ.
        // ຄໍາອະທິບາຍແມ່ນພຽງແຕ່ວ່າ `next_read >= next_write` ແມ່ນຄວາມຈິງສະເຫມີ, ດັ່ງນັ້ນ `next_read > next_write - 1` ກໍ່ຄືກັນ.
        //
        //
        //
        //
        //
        unsafe {
            // ຫລີກລ້ຽງການກວດສອບຂອບເຂດໂດຍການໃຊ້ຕົວຊີ້ວັດຖຸດິບ.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// ຍ້າຍທັງ ໝົດ ແຕ່ ທຳ ອິດຂອງສ່ວນປະກອບຕິດຕໍ່ກັນໄປຈົນສຸດທ້າຍຂອງທ່ອນທີ່ແກ້ໄຂບັນຫາໃຫ້ເປັນກຸນແຈດຽວກັນ.
    ///
    ///
    /// ກັບຄືນສອງຊິ້ນ.ຄັ້ງທໍາອິດບໍ່ມີອົງປະກອບທີ່ຊ້ໍາຊ້ອນກັນ.
    /// ຄັ້ງທີສອງປະກອບມີສິ່ງທີ່ຊ້ ຳ ຊ້ອນກັນທັງ ໝົດ ໂດຍບໍ່ໄດ້ ກຳ ນົດໄວ້.
    ///
    /// ຖ້າຊິ້ນຖືກຈັດຮຽງ, ຊິ້ນທີ່ກັບຄືນມາຄັ້ງ ທຳ ອິດບໍ່ມີຊ້ ຳ ຊ້ອນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// ໝູນ ແຜ່ນທີ່ຢູ່ໃນສະຖານທີ່ດັ່ງກ່າວເຊິ່ງ `mid` X ອົງປະກອບ ທຳ ອິດຍ້າຍໄປທາງສຸດໃນຂະນະທີ່ອົງປະກອບ `self.len() - mid` ສຸດທ້າຍຍ້າຍໄປທາງ ໜ້າ.
    /// ຫລັງຈາກໂທຫາ `rotate_left`, ອົງປະກອບກ່ອນ ໜ້າ ນີ້ທີ່ດັດສະນີ `mid` ຈະກາຍເປັນອົງປະກອບ ທຳ ອິດໃນການລອກ.
    ///
    /// # Panics
    ///
    /// ຟັງຊັ່ນນີ້ຈະເປັນ panic ຖ້າ `mid` ໃຫຍ່ກວ່າຄວາມຍາວຂອງການຕັດ.ໃຫ້ສັງເກດວ່າ `mid == self.len()` ເຮັດ _not_ panic ແລະເປັນພືດຫມູນວຽນແບບບໍ່ມີສາຍ.
    ///
    /// # Complexity
    ///
    /// ໃຊ້ເວລາເສັ້ນຊື່ (ໃນເວລາ `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// ໝຸນ ເງີນຍ່ອຍ:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // ຄວາມປອດໄພ: ຊ່ວງລາຄາ `[p.add(mid) - mid, p.add(mid) + k)` ແມ່ນເລັກ ໜ້ອຍ
        // ຖືກຕ້ອງ ສຳ ລັບການອ່ານແລະການຂຽນ, ຕາມຄວາມຕ້ອງການຂອງ `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// ໝູນ ແຜ່ນທີ່ຢູ່ໃນສະຖານທີ່ດັ່ງກ່າວເຊິ່ງ `self.len() - k` X ອົງປະກອບ ທຳ ອິດຍ້າຍໄປທາງສຸດໃນຂະນະທີ່ອົງປະກອບ `k` ສຸດທ້າຍຍ້າຍໄປທາງ ໜ້າ.
    /// ຫລັງຈາກໂທຫາ `rotate_right`, ອົງປະກອບກ່ອນ ໜ້າ ນີ້ທີ່ດັດສະນີ `self.len() - k` ຈະກາຍເປັນອົງປະກອບ ທຳ ອິດໃນການລອກ.
    ///
    /// # Panics
    ///
    /// ຟັງຊັ່ນນີ້ຈະເປັນ panic ຖ້າ `k` ໃຫຍ່ກວ່າຄວາມຍາວຂອງການຕັດ.ໃຫ້ສັງເກດວ່າ `k == self.len()` ເຮັດ _not_ panic ແລະເປັນພືດຫມູນວຽນແບບບໍ່ມີສາຍ.
    ///
    /// # Complexity
    ///
    /// ໃຊ້ເວລາເສັ້ນຊື່ (ໃນເວລາ `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// ໝຸນ ເງີນຍ່ອຍ:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // ຄວາມປອດໄພ: ຊ່ວງລາຄາ `[p.add(mid) - mid, p.add(mid) + k)` ແມ່ນເລັກ ໜ້ອຍ
        // ຖືກຕ້ອງ ສຳ ລັບການອ່ານແລະການຂຽນ, ຕາມຄວາມຕ້ອງການຂອງ `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// ຕື່ມຂໍ້ມູນໃສ່ `self` ດ້ວຍອົງປະກອບໂດຍການກົດ Clone `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Fills `self` ກັບອົງປະກອບກັບຄືນໂດຍການໂທຫາປິດເປັນຊ້ໍາ.
    ///
    /// ວິທີການນີ້ໃຊ້ການປິດເພື່ອສ້າງຄຸນຄ່າ ໃໝ່.ຖ້າທ່ານຕ້ອງການໃຫ້ [`Clone`] ມີຄຸນຄ່າ, ໃຫ້ໃຊ້ [`fill`].
    /// ຖ້າທ່ານຕ້ອງການໃຊ້ [`Default`] trait ເພື່ອສ້າງຄຸນຄ່າ, ທ່ານສາມາດຜ່ານ [`Default::default`] ເປັນການໂຕ້ຖຽງ.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// ສໍາເນົາອົງປະກອບຈາກ `src` ເປັນ `self` ໄດ້.
    ///
    /// ຄວາມຍາວຂອງ `src` ຕ້ອງຄືກັນກັບ `self`.
    ///
    /// ຖ້າ `T` ປະຕິບັດ `Copy`, ມັນສາມາດເປັນນັກສະແດງທີ່ດີກວ່າທີ່ຈະໃຊ້ [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ຈະ panic ຖ້າສອງຫຼັງຈາກນັ້ນນໍາມີຄວາມຍາວທີ່ແຕກຕ່າງກັນ.
    ///
    /// # Examples
    ///
    /// Cloning ສອງອົງປະກອບຈາກຫຼັງຈາກນັ້ນນໍາເຂົ້າໄປໃນອີກ:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // ຍ້ອນວ່າທ່ອນໄມ້ຕ້ອງມີຄວາມຍາວເທົ່າກັນ, ພວກເຮົາຈຶ່ງແຍກສ່ວນທີ່ມາຈາກສີ່ສ່ວນຫາສອງສ່ວນ.
    /// // ມັນຈະ panic ຖ້າພວກເຮົາບໍ່ເຮັດແບບນີ້.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ບັງຄັບໃຫ້ມີພຽງແຕ່ການອ້າງອີງທີ່ສາມາດປ່ຽນແປງໄດ້ໂດຍບໍ່ມີການອ້າງອີງທີ່ບໍ່ປ່ຽນແປງກັບຊິ້ນສ່ວນຂອງຂໍ້ມູນໃນຂອບເຂດໃດ ໜຶ່ງ.
    /// ຍ້ອນເຫດນີ້, ການພະຍາຍາມໃຊ້ `clone_from_slice` ໃສ່ບາດດຽວຈະເຮັດໃຫ້ເກີດການລວບລວມຂໍ້ບົກຜ່ອງ:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ເພື່ອເຮັດວຽກຮອບດ້ານນີ້, ພວກເຮົາສາມາດ ນຳ ໃຊ້ [`split_at_mut`] ເພື່ອສ້າງສອງສ່ວນຍ່ອຍທີ່ແຕກຕ່າງຈາກສ່ວນ ໜຶ່ງ:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// ຄັດລອກອົງປະກອບທັງ ໝົດ ຈາກ `src` ລົງໃນ `self`, ໂດຍໃຊ້ memcpy.
    ///
    /// ຄວາມຍາວຂອງ `src` ຕ້ອງຄືກັນກັບ `self`.
    ///
    /// ຖ້າ `T` ບໍ່ປະຕິບັດ `Copy`, ໃຫ້ໃຊ້ [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ຈະ panic ຖ້າສອງຫຼັງຈາກນັ້ນນໍາມີຄວາມຍາວທີ່ແຕກຕ່າງກັນ.
    ///
    /// # Examples
    ///
    /// ຄັດລອກສອງອົງປະກອບຈາກທ່ອນ ໜຶ່ງ ເຂົ້າໄປໃນອີກ:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // ຍ້ອນວ່າທ່ອນໄມ້ຕ້ອງມີຄວາມຍາວເທົ່າກັນ, ພວກເຮົາຈຶ່ງແຍກສ່ວນທີ່ມາຈາກສີ່ສ່ວນຫາສອງສ່ວນ.
    /// // ມັນຈະ panic ຖ້າພວກເຮົາບໍ່ເຮັດແບບນີ້.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust ບັງຄັບໃຫ້ມີພຽງແຕ່ການອ້າງອີງທີ່ສາມາດປ່ຽນແປງໄດ້ໂດຍບໍ່ມີການອ້າງອີງທີ່ບໍ່ປ່ຽນແປງກັບຊິ້ນສ່ວນຂອງຂໍ້ມູນໃນຂອບເຂດໃດ ໜຶ່ງ.
    /// ຍ້ອນເຫດນີ້, ການພະຍາຍາມໃຊ້ `copy_from_slice` ໃສ່ບາດດຽວຈະເຮັດໃຫ້ເກີດການລວບລວມຂໍ້ບົກຜ່ອງ:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ເພື່ອເຮັດວຽກຮອບດ້ານນີ້, ພວກເຮົາສາມາດ ນຳ ໃຊ້ [`split_at_mut`] ເພື່ອສ້າງສອງສ່ວນຍ່ອຍທີ່ແຕກຕ່າງຈາກສ່ວນ ໜຶ່ງ:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // ເສັ້ນທາງລະຫັດ panic ໄດ້ຖືກ ນຳ ໄປໃຊ້ໃນ ໜ້າ ທີ່ເຢັນເພື່ອບໍ່ເຮັດໃຫ້ເວັບໄຊ້ໂທອອກ.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // ຄວາມປອດໄພ: `self` ແມ່ນຖືກຕ້ອງ ສຳ ລັບອົງປະກອບ `self.len()` ໂດຍ ຄຳ ນິຍາມ, ແລະ `src` ແມ່ນ
        // ກວດເບິ່ງວ່າມີຄວາມຍາວດຽວກັນ.
        // ແຜ່ນບໍ່ສາມາດຊໍ້າກັນໄດ້ເພາະວ່າເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ແມ່ນສະເພາະ.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// ຄັດລອກສ່ວນປະກອບຕ່າງໆຈາກສ່ວນ ໜຶ່ງ ຂອງສ່ວນ ໜຶ່ງ ໄປຫາສ່ວນ ໜຶ່ງ ຂອງຕົວມັນເອງ, ໂດຍ ນຳ ໃຊ້ ໜ້າ ກາກ.
    ///
    /// `src` ແມ່ນຊ່ວງຢູ່ໃນ `self` ເພື່ອຄັດລອກຈາກ.
    /// `dest` ແມ່ນດັດສະນີເລີ່ມຕົ້ນຂອງຊ່ວງຢູ່ໃນ `self` ເພື່ອ ສຳ ເນົາ, ເຊິ່ງຈະມີຄວາມຍາວເທົ່າກັບ `src`.
    /// ທັງສອງຂອບເຂດອາດຈະຊໍ້າຊ້ອນ.
    /// ສົ້ນຂອງສອງຂອບເຂດຕ້ອງນ້ອຍກວ່າຫລືເທົ່າກັບ `self.len()`.
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ຈະ panic ຖ້າວ່າຊ່ວງໃດ ໜຶ່ງ ທີ່ເກີນຂອບເຂດຂອງສ່ວນທີ່ສິ້ນສຸດ, ຫຼືຖ້າວ່າ `src` ສິ້ນສຸດກ່ອນການເລີ່ມຕົ້ນ.
    ///
    ///
    /// # Examples
    ///
    /// ຄັດລອກສີ່ໄບຕ໌ເປັນສ່ວນໆ:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // ຄວາມປອດໄພ: ເງື່ອນໄຂຂອງ `ptr::copy` ໄດ້ຖືກກວດສອບຢູ່ຂ້າງເທິງ,
        // ເປັນມີຜູ້ສໍາລັບ `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// ແລກປ່ຽນອົງປະກອບທັງ ໝົດ ໃນ `self` ກັບສິ່ງທີ່ຢູ່ໃນ `other`.
    ///
    /// ຄວາມຍາວຂອງ `other` ຕ້ອງຄືກັນກັບ `self`.
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ຈະ panic ຖ້າສອງຫຼັງຈາກນັ້ນນໍາມີຄວາມຍາວທີ່ແຕກຕ່າງກັນ.
    ///
    /// # Example
    ///
    /// ການແລກປ່ຽນສອງອົງປະກອບໃນທົ່ວຫຼັງຈາກນັ້ນນໍາ:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust ບັງຄັບໃຫ້ມີພຽງແຕ່ການອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບຊິ້ນສ່ວນ ໜຶ່ງ ຂອງຂໍ້ມູນໃນຂອບເຂດສະເພາະໃດ ໜຶ່ງ.
    ///
    /// ດ້ວຍເຫດນີ້, ພະຍາຍາມທີ່ຈະນໍາໃຊ້ `swap_with_slice` ກ່ຽວກັບຫຼັງຈາກນັ້ນນໍາດຽວຈະສົ່ງຜົນໃຫ້ເກີດຄວາມລົ້ມເຫຼວຂອງການລວບລວມ:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// ເພື່ອເຮັດວຽກຮອບດ້ານນີ້, ພວກເຮົາສາມາດ ນຳ ໃຊ້ [`split_at_mut`] ເພື່ອສ້າງສອງສ່ວນຍ່ອຍທີ່ແຕກຕ່າງກັນໄດ້ຈາກກັນແລະກັນ:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // ຄວາມປອດໄພ: `self` ແມ່ນຖືກຕ້ອງ ສຳ ລັບອົງປະກອບ `self.len()` ໂດຍ ຄຳ ນິຍາມ, ແລະ `src` ແມ່ນ
        // ກວດເບິ່ງວ່າມີຄວາມຍາວດຽວກັນ.
        // ແຜ່ນບໍ່ສາມາດຊໍ້າກັນໄດ້ເພາະວ່າເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ແມ່ນສະເພາະ.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// ມີ ໜ້າ ທີ່ໃນການຄິດໄລ່ຄວາມຍາວຂອງເສັ້ນທາງກາງແລະຫຼັງ ສຳ ລັບ `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // ສິ່ງທີ່ພວກເຮົາຢາກເຮັດກ່ຽວກັບ `rest` ແມ່ນຄິດໄລ່ຫຼາຍອັນທີ່ພວກເຮົາສາມາດໃສ່ ຈຳ ນວນ `T` ທີ່ຕ່ ຳ ສຸດ.
        //
        // ແລະຈໍານວນເທົ່າໃດ `T` ທີ່ພວກເຮົາຕ້ອງການ ສຳ ລັບ "multiple" ດັ່ງກ່າວ.
        //
        // ພິຈາລະນາຍົກຕົວຢ່າງ T=u8 U=u16.ຫຼັງຈາກນັ້ນພວກເຮົາສາມາດໃສ່ 1 U ໃນ 2 Ts.ງ່າຍດາຍ.
        // ໃນປັດຈຸບັນ, ພິຈາລະນາສໍາລັບການຍົກຕົວຢ່າງກໍລະນີທີ່ size_of: :<T>=16, size_of::<U>=24.</u>
        // ພວກເຮົາສາມາດໃສ່ 2 Us ແທນຂອງທຸກໆ 3 Ts ໃນ `rest` slice.
        // ເລັກນ້ອຍສັບສົນຫຼາຍ.
        //
        // ສູດເພື່ອຄິດໄລ່ນີ້ແມ່ນ:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // ຂະຫຍາຍແລະງ່າຍດາຍ:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // ໂຊກດີເພາະວ່າທັງ ໝົດ ນີ້ແມ່ນຖືກປະເມີນຜົນຢ່າງບໍ່ຢຸດຢັ້ງ ... ການປະຕິບັດຢູ່ນີ້ບໍ່ ສຳ ຄັນ!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // ຂັ້ນຕອນວິທີການລຶ້ມຄືນເຊັ່ນ stein ຂອງພວກເຮົາຍັງຄວນຈະເຮັດໃຫ້ `const fn` ນີ້ (ແລະ revert ກັບບົບ recursive ຖ້າພວກເຮົາເຮັດແນວໃດ) ເພາະວ່າອາໄສຢູ່ໃນ llvm ກັບ consteval ທັງຫມົດນີ້ແມ່ນ ... ດີ, ມັນເຮັດໃຫ້ຂ້າພະເຈົ້າບໍ່ສະດວກ.
            //
            //

            // ຄວາມປອດໄພ: `a` ແລະ `b` ຖືກກວດສອບວ່າບໍ່ແມ່ນຄ່າທີ່ບໍ່ແມ່ນສູນ.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // ເອົາທຸກໆປັດໃຈຂອງ 2 ອອກຈາກຂ
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // ຄວາມປອດໄພ: `b` ຖືກກວດສອບວ່າບໍ່ແມ່ນສູນ.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // ປະກອບດ້ວຍຄວາມຮູ້ດັ່ງກ່າວ, ພວກເຮົາສາມາດຄົ້ນພົບວ່າພວກເຮົາສາມາດ ເໝາະ ສົມກັບຫຼາຍປານໃດ!
        let us_len = self.len() / ts * us;
        // ແລະຈະມີ ຈຳ ນວນເທົ່າໃດ `T` ທີ່ຢູ່ໃນໄລຍະຫ່າງໆ!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmute slice to the slice of another ປະເພດ, ຮັບປະກັນຄວາມສອດຄ່ອງຂອງປະເພດໄດ້ຖືກຮັກສາໄວ້.
    ///
    /// ວິທີການນີ້ແບ່ງອອກເປັນສາມສ່ວນທີ່ແຕກຕ່າງກັນ: ຄຳ ນຳ ໜ້າ, ຈັດລຽນເປັນສ່ວນກາງຢ່າງຖືກຕ້ອງຂອງປະເພດ ໃໝ່, ແລະສ່ວນທີ່ ນຳ ມາສະສົມ.
    /// ວິທີການດັ່ງກ່າວອາດຈະເຮັດໃຫ້ສ່ວນກາງເປັນຄວາມຍາວທີ່ຍິ່ງໃຫຍ່ທີ່ສຸດ ສຳ ລັບປະເພດໃດ ໜຶ່ງ ແລະການປ້ອນຂໍ້ມູນເຂົ້າ, ແຕ່ວ່າພຽງແຕ່ການປະຕິບັດງານຂອງສູດການຄິດໄລ່ຂອງທ່ານຄວນຂື້ນກັບມັນ, ບໍ່ແມ່ນຄວາມຖືກຕ້ອງຂອງມັນ.
    ///
    /// ມັນສາມາດອະນຸຍາດໃຫ້ຂໍ້ມູນການປ້ອນຂໍ້ມູນທັງ ໝົດ ກັບຄືນເປັນ ຄຳ ນຳ ໜ້າ ຫຼື ຄຳ ຕໍ່ເນື່ອງ.
    ///
    /// ວິທີການນີ້ບໍ່ມີຈຸດປະສົງຫຍັງເລີຍໃນເວລາທີ່ປັດໃຈ input `T` ຫຼື element output `U` ມີຂະ ໜາດ ສູນແລະຈະກັບຄືນມາຊິ້ນສ່ວນເດີມໂດຍບໍ່ມີການແບ່ງປັນຫຍັງ.
    ///
    /// # Safety
    ///
    /// ວິທີການນີ້ແມ່ນສິ່ງ ຈຳ ເປັນ `transmute` ທີ່ກ່ຽວຂ້ອງກັບອົງປະກອບໃນສ່ວນກາງທີ່ກັບມາ, ສະນັ້ນທຸກສິ່ງທີ່ປົກກະຕິກ່ຽວຂ້ອງກັບ `transmute::<T, U>` ກໍ່ສາມາດ ນຳ ໃຊ້ໄດ້ທີ່ນີ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // ໃຫ້ສັງເກດວ່າສ່ວນໃຫຍ່ຂອງ ໜ້າ ທີ່ນີ້ຈະຖືກປະເມີນຜົນເປັນປະ ຈຳ,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ຈັດການກັບ ZST ໂດຍສະເພາະ, ເຊິ່ງແມ່ນ-ຢ່າຈັດການກັບພວກມັນເລີຍ.
            return (self, &[], &[]);
        }

        // ຫນ້າທໍາອິດ, ຊອກຫາຢູ່ໃນຈຸດໃດທີ່ພວກເຮົາແບ່ງປັນລະຫວ່າງຊິ້ນສ່ວນທໍາອິດແລະທີ 2.
        // ງ່າຍດ້ວຍ ptr.align_offset.
        let ptr = self.as_ptr();
        // ຄວາມປອດໄພ: ເບິ່ງວິທີ `align_to_mut` ສຳ ລັບ ຄຳ ເຫັນກ່ຽວກັບຄວາມປອດໄພລະອຽດ.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SAFETY: ໃນປັດຈຸບັນ `rest` ແມ່ນສອດຄ່ອງຄໍານິຍາມ, ສະນັ້ນ `from_raw_parts` ຕ່ໍາກວ່າແມ່ນຫຍັງ,
            // ເນື່ອງຈາກຜູ້ໂທຮັບປະກັນວ່າພວກເຮົາສາມາດສົ່ງ `T` ໄປ `U` ໄດ້ຢ່າງປອດໄພ.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmute slice to the slice of another ປະເພດ, ຮັບປະກັນຄວາມສອດຄ່ອງຂອງປະເພດໄດ້ຖືກຮັກສາໄວ້.
    ///
    /// ວິທີການນີ້ແບ່ງອອກເປັນສາມສ່ວນທີ່ແຕກຕ່າງກັນ: ຄຳ ນຳ ໜ້າ, ຈັດລຽນເປັນສ່ວນກາງຢ່າງຖືກຕ້ອງຂອງປະເພດ ໃໝ່, ແລະສ່ວນທີ່ ນຳ ມາສະສົມ.
    /// ວິທີການດັ່ງກ່າວອາດຈະເຮັດໃຫ້ສ່ວນກາງເປັນຄວາມຍາວທີ່ຍິ່ງໃຫຍ່ທີ່ສຸດ ສຳ ລັບປະເພດໃດ ໜຶ່ງ ແລະການປ້ອນຂໍ້ມູນເຂົ້າ, ແຕ່ວ່າພຽງແຕ່ການປະຕິບັດງານຂອງສູດການຄິດໄລ່ຂອງທ່ານຄວນຂື້ນກັບມັນ, ບໍ່ແມ່ນຄວາມຖືກຕ້ອງຂອງມັນ.
    ///
    /// ມັນສາມາດອະນຸຍາດໃຫ້ຂໍ້ມູນການປ້ອນຂໍ້ມູນທັງ ໝົດ ກັບຄືນເປັນ ຄຳ ນຳ ໜ້າ ຫຼື ຄຳ ຕໍ່ເນື່ອງ.
    ///
    /// ວິທີການນີ້ບໍ່ມີຈຸດປະສົງຫຍັງເລີຍໃນເວລາທີ່ປັດໃຈ input `T` ຫຼື element output `U` ມີຂະ ໜາດ ສູນແລະຈະກັບຄືນມາຊິ້ນສ່ວນເດີມໂດຍບໍ່ມີການແບ່ງປັນຫຍັງ.
    ///
    /// # Safety
    ///
    /// ວິທີການນີ້ແມ່ນສິ່ງ ຈຳ ເປັນ `transmute` ທີ່ກ່ຽວຂ້ອງກັບອົງປະກອບໃນສ່ວນກາງທີ່ກັບມາ, ສະນັ້ນທຸກສິ່ງທີ່ປົກກະຕິກ່ຽວຂ້ອງກັບ `transmute::<T, U>` ກໍ່ສາມາດ ນຳ ໃຊ້ໄດ້ທີ່ນີ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // ໃຫ້ສັງເກດວ່າສ່ວນໃຫຍ່ຂອງ ໜ້າ ທີ່ນີ້ຈະຖືກປະເມີນຜົນເປັນປະ ຈຳ,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ຈັດການກັບ ZST ໂດຍສະເພາະ, ເຊິ່ງແມ່ນ-ຢ່າຈັດການກັບພວກມັນເລີຍ.
            return (self, &mut [], &mut []);
        }

        // ຫນ້າທໍາອິດ, ຊອກຫາຢູ່ໃນຈຸດໃດທີ່ພວກເຮົາແບ່ງປັນລະຫວ່າງຊິ້ນສ່ວນທໍາອິດແລະທີ 2.
        // ງ່າຍດ້ວຍ ptr.align_offset.
        let ptr = self.as_ptr();
        // ຄວາມປອດໄພ: ໃນທີ່ນີ້ພວກເຮົາຮັບປະກັນວ່າພວກເຮົາຈະ ນຳ ໃຊ້ຕົວຊີ້ທິດທາງທີ່ສອດຄ່ອງ ສຳ ລັບ U ສຳ ລັບ the
        // ສ່ວນທີ່ເຫຼືອຂອງວິທີການ.ນີ້ແມ່ນເຮັດໄດ້ໂດຍການສົ່ງຕົວຊີ້ໄປທີ່&[T] ໂດຍມີການສອດຄ່ອງກັບເປົ້າ ໝາຍ ສຳ ລັບ U.
        // `crate::ptr::align_offset` ຖືກເອີ້ນດ້ວຍຕົວຊີ້ທີ່ຖືກຕ້ອງແລະຖືກຕ້ອງທີ່ `ptr` (ມັນມາຈາກເອກະສານອ້າງອີງເຖິງ `self`) ແລະມີຂະ ໜາດ ທີ່ເປັນພະລັງຂອງສອງ (ນັບແຕ່ມັນມາຈາກການສອດຄ່ອງ ສຳ ລັບ U), ພໍໃຈກັບຂໍ້ ຈຳ ກັດດ້ານຄວາມປອດໄພຂອງມັນ.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // ພວກເຮົາບໍ່ສາມາດໃຊ້ `rest` ອີກເທື່ອ ໜຶ່ງ ຫຼັງຈາກນີ້, ເຊິ່ງຈະເຮັດໃຫ້ນາມແຝງ `mut_ptr` ຂອງມັນບໍ່ຖືກຕ້ອງ!ຄວາມປອດໄພ: ເບິ່ງ ຄຳ ເຫັນ ສຳ ລັບ `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// ໃຫ້ກວດເບິ່ງວ່າອົງປະກອບຂອງສ່ວນປະສົມນີ້ຖືກຈັດຮຽງ.
    ///
    /// ນັ້ນແມ່ນ, ສຳ ລັບແຕ່ລະອົງປະກອບ `a` ແລະອົງປະກອບຕໍ່ໄປນີ້ `b`, `a <= b` ຕ້ອງຖື.ຖ້າຫາກວ່າແຜ່ນໃບມີຜົນຜະລິດສູນຫລືອົງປະກອບໃດ ໜຶ່ງ, `true` ຈະຖືກສົ່ງຄືນ.
    ///
    /// ໃຫ້ສັງເກດວ່າຖ້າຫາກວ່າ `Self::Item` ແມ່ນພຽງແຕ່ `PartialOrd`, ແຕ່ບໍ່ `Ord`, ຄໍານິຍາມຂ້າງເທິງຫມາຍຄວາມວ່າຫນ້າທີ່ນີ້ຈະກັບຄືນມາ `false` ຖ້າມີສອງລາຍການຕິດຕໍ່ກັນບໍ່ໄດ້ການປຽບທຽບ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// ໃຫ້ກວດເບິ່ງວ່າອົງປະກອບຂອງສ່ວນປະສົມນີ້ຖືກຈັດຮຽງໂດຍໃຊ້ຟັງຊັນປຽບທຽບທີ່ໃຫ້.
    ///
    /// ແທນທີ່ຈະນໍາໃຊ້ `PartialOrd::partial_cmp`, ການທໍາງານນີ້ໃຊ້ໃຫ້ການທໍາງານຂອງ `compare` ການກໍານົດຄໍາສັ່ງຂອງສອງອົງປະກອບທີ່.
    /// ນອກຈາກນັ້ນ, ມັນເປັນການທຽບເທົ່າກັບ [`is_sorted`];ເບິ່ງເອກະສານຂອງຕົນສໍາລັບຂໍ້ມູນເພີ່ມເຕີມ.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// ໃຫ້ກວດເບິ່ງວ່າອົງປະກອບຂອງສ່ວນປະສົມນີ້ຖືກຈັດຮຽງໂດຍໃຊ້ ໜ້າ ທີ່ການສະກັດເອົາທີ່ ສຳ ຄັນ.
    ///
    /// ແທນທີ່ຈະປຽບທຽບອົງປະກອບຂອງສ່ວນປະກອບໂດຍກົງ, ຟັງຊັນນີ້ຈະປຽບທຽບຄີຂອງອົງປະກອບດັ່ງທີ່ໄດ້ ກຳ ນົດໂດຍ `f`.
    /// ນອກຈາກນັ້ນ, ມັນເປັນການທຽບເທົ່າກັບ [`is_sorted`];ເບິ່ງເອກະສານຂອງຕົນສໍາລັບຂໍ້ມູນເພີ່ມເຕີມ.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// ສົ່ງຄືນດັດຊະນີຂອງຈຸດແບ່ງຕາມຕົວເລກທີ່ໄດ້ ກຳ ນົດໄວ້ (ດັດຊະນີຂອງອົງປະກອບ ທຳ ອິດຂອງພາທິຊັນທີສອງ).
    ///
    /// ຊິ້ນສ່ວນແມ່ນຄາດວ່າຈະແບ່ງອອກຕາມຕົວເລກທີ່ໄດ້ ກຳ ນົດໄວ້.
    /// ນີ້ ໝາຍ ຄວາມວ່າອົງປະກອບທັງ ໝົດ ທີ່ການຄາດຄະເນຈະກັບມາເປັນຄວາມຈິງແມ່ນຢູ່ໃນຕອນເລີ່ມຕົ້ນແລະສ່ວນປະກອບທັງ ໝົດ ທີ່ຕົວຄາດ ໝາຍ ຈະກັບຄືນມາບໍ່ຖືກຕ້ອງຢູ່ໃນຕອນສຸດທ້າຍ.
    ///
    /// ຕົວຢ່າງ, [7, 15, 3, 5, 4, 12, 6] ແມ່ນການແບ່ງສ່ວນພາຍໃຕ້ຕົວເລກ x% 2!=0 (ຕົວເລກຄີກທັງ ໝົດ ແມ່ນຢູ່ໃນຕອນເລີ່ມຕົ້ນ, ທັງ ໝົດ ແມ່ນແຕ່ໃນຕອນທ້າຍ).
    ///
    /// ຖ້າການແບ່ງສ່ວນນີ້ບໍ່ໄດ້ຖືກແບ່ງອອກ, ຜົນໄດ້ຮັບທີ່ສົ່ງຄືນແມ່ນບໍ່ໄດ້ລະບຸແລະບໍ່ມີຄວາມ ໝາຍ, ເພາະວ່າວິທີການນີ້ປະຕິບັດການຄົ້ນຫາຖານສອງແບບ.
    ///
    /// ເບິ່ງທີ່ [`binary_search`], [`binary_search_by`], ແລະ [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // ຄວາມປອດໄພ: ເມື່ອ `left < right`, `left <= mid < right`.
            // ດັ່ງນັ້ນ `left` ກໍ່ຈະເພີ່ມຂື້ນເລື້ອຍໆແລະ `right` ກໍ່ຈະຄ່ອຍໆຫຼຸດລົງ, ແລະມັນກໍ່ຖືກເລືອກໄວ້.ໃນທັງສອງກໍລະນີ `left <= right` ແມ່ນພໍໃຈ.ດັ່ງນັ້ນຖ້າຫາກວ່າ `left < right` ໃນບາດກ້າວຫນຶ່ງ, `left <= right` ແມ່ນເພິ່ງພໍໃຈຕໍ່ບາດກ້າວຕໍ່ໄປ.
            //
            // ດັ່ງນັ້ນຕາບໃດທີ່ `left != right`, `0 <= left < right <= len` ກໍ່ພໍໃຈແລະຖ້າກໍລະນີນີ້ `0 <= mid < len` ກໍ່ພໍໃຈເຊັ່ນກັນ.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: ພວກເຮົາຈໍາເປັນຕ້ອງໄດ້ຢ່າງຊັດເຈນຫຼັງຈາກນັ້ນນໍາພວກເຂົາກັບຍາວເທົ່າ ໆ ກັນໄດ້
        // ເພື່ອເຮັດໃຫ້ມັນງ່າຍຂຶ້ນສໍາລັບປະສິດທິພາບໃນການ elide ຂອບເຂດກວດສອບ.
        // ແຕ່ຍ້ອນວ່າມັນບໍ່ສາມາດເພິ່ງພາອາໄສພວກເຮົາກໍ່ມີຄວາມຊ່ຽວຊານພິເສດ ສຳ ລັບ T: ສຳ ເນົາ.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// ສ້າງກະດານເປົ່າ.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// ສ້າງກະເປົ່າຫວ່າງທີ່ປ່ຽນແປງໄດ້.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// ຮູບແບບໃນຊິ້ນ, ປະຈຸບັນ, ໃຊ້ໂດຍ `strip_prefix` ແລະ `strip_suffix` ເທົ່ານັ້ນ.
/// ໃນຈຸດ future, ພວກເຮົາຫວັງວ່າຈະ XXXX ໂດຍທົ່ວໄປ (ເຊິ່ງໃນເວລາທີ່ຂຽນແມ່ນຖືກ ຈຳ ກັດ `str`) ເພື່ອຊອດ, ແລະຫຼັງຈາກນັ້ນ trait ນີ້ຈະຖືກປ່ຽນແທນຫລືລົບລ້າງ.
///
pub trait SlicePattern {
    /// ປະເພດຂອງສ່ວນປະກອບຂອງລິ້ນທີ່ຖືກຈັບຄູ່.
    type Item;

    /// ປະຈຸບັນ, ຜູ້ບໍລິໂພກຂອງ `SlicePattern` ຈຳ ເປັນຕ້ອງມີສ່ວນປະສົມ.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}