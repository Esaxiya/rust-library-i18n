// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// ໝູນ ລະດັບ `[mid-left, mid+right)` ເຊັ່ນວ່າອົງປະກອບທີ່ `mid` ກາຍເປັນອົງປະກອບ ທຳ ອິດ.ຢ່າງເທົ່າທຽມກັນ, ໝຸນ ອົງປະກອບ `left` ໄປທາງຊ້າຍຫລື `right` ອົງປະກອບເບື້ອງຂວາ.
///
/// # Safety
///
/// ຂອບເຂດທີ່ລະບຸຈະຕ້ອງຖືກຕ້ອງ ສຳ ລັບການອ່ານແລະການຂຽນ.
///
/// # Algorithm
///
/// ສູດການຄິດໄລ່ 1 ຖືກໃຊ້ ສຳ ລັບຄ່ານ້ອຍໆຂອງ `left + right` ຫຼື ສຳ ລັບ `T` ຂະ ໜາດ ໃຫຍ່.
/// ອົງປະກອບດັ່ງກ່າວຖືກຍ້າຍເຂົ້າ ຕຳ ແໜ່ງ ຕຳ ແໜ່ງ ສຸດທ້າຍຂອງພວກເຂົາ ໜຶ່ງ ເທື່ອໃນເວລາເລີ່ມຕົ້ນທີ່ `mid - left` ແລະກ້າວ ໜ້າ ໂດຍ `right` ຂັ້ນຕອນ modulo `left + right`, ເຊັ່ນວ່າມີພຽງແຕ່ຊົ່ວຄາວເທົ່ານັ້ນທີ່ ຈຳ ເປັນ.
/// ໃນທີ່ສຸດ, ພວກເຮົາມາຮອດ `mid - left`.
/// ເຖິງຢ່າງໃດກໍ່ຕາມ, ຖ້າ `gcd(left + right, right)` ບໍ່ແມ່ນ 1, ຂັ້ນຕອນຂ້າງເທິງນີ້ຂ້າມຜ່ານສ່ວນປະກອບຕ່າງໆ.
/// ຍົກຕົວຢ່າງ:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// ໂຊກດີ, ຈຳ ນວນການຂ້າມຜ່ານອົງປະກອບລະຫວ່າງອົງປະກອບສຸດທ້າຍແມ່ນສະ ເໝີ ພາບ, ສະນັ້ນພວກເຮົາພຽງແຕ່ສາມາດຊົດເຊີຍ ຕຳ ແໜ່ງ ທີ່ເລີ່ມຕົ້ນຂອງພວກເຮົາແລະເຮັດຫຼາຍຮອບ (ຈຳ ນວນຮອບທັງ ໝົດ ແມ່ນ `gcd(left + right, right)` value).
///
/// ຜົນໄດ້ຮັບສຸດທ້າຍແມ່ນວ່າອົງປະກອບທັງຫມົດແມ່ນໄດ້ຖືກເຮັດສຸດທ້າຍຄັ້ງດຽວແລະຄັ້ງດຽວ.
///
/// ສູດການຄິດໄລ່ 2 ຖືກໃຊ້ຖ້າ `left + right` ມີຂະ ໜາດ ໃຫຍ່ແຕ່ `min(left, right)` ມີຂະ ໜາດ ນ້ອຍພໍທີ່ຈະພໍດີກັບແທັບຄວັນ stack.
/// ອົງປະກອບ `min(left, right)` ຖືກຄັດລອກໃສ່ buffer, `memmove` ຖືກ ນຳ ໄປໃຊ້ກັບສິ່ງອື່ນໆ, ແລະເຄື່ອງທີ່ຢູ່ເທິງ buffer ຈະຖືກຍ້າຍກັບເຂົ້າໄປໃນຮູຢູ່ເບື້ອງກົງກັນຂ້າມຂອງບ່ອນທີ່ພວກມັນມາ.
///
/// ສູດການຄິດໄລ່ທີ່ສາມາດຖືກຄວບຄຸມໄດ້ດີກວ່າຂ້າງເທິງນີ້ເມື່ອ `left + right` ກາຍເປັນຂະ ໜາດ ໃຫຍ່ພໍ.
/// ສູດການຄິດໄລ່ 1 ສາມາດຖືກປັບປຸງໂດຍການຈັບແລະປະຕິບັດຫຼາຍຮອບໃນເວລາດຽວກັນ, ແຕ່ວ່າມັນມີການສະເລ່ຍຮອບ ໜ້ອຍ ເກີນໄປຈົນກ່ວາ `left + right` ມີຂະ ໜາດ ໃຫຍ່, ແລະກໍລະນີທີ່ບໍ່ດີທີ່ສຸດຂອງຮອບດຽວກໍ່ມີຢູ່.
/// ແທນທີ່ຈະ, ວິທີການ 3 ຜົນປະໂຫຍດຊ້ໍາການແລກປ່ຽນຂອງອົງປະກອບ `min(left, right)` ຈົນກ່ວາບັນຫາພືດຫມູນວຽນຂະຫນາດນ້ອຍໄດ້ຖືກປະໄວ້.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// ເມື່ອ `left < right` ການແລກປ່ຽນຈະເກີດຂື້ນຈາກເບື້ອງຊ້າຍແທນ.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ສູດການຄິດໄລ່ດ້ານລຸ່ມສາມາດລົ້ມເຫລວຖ້າຫາກວ່າກໍລະນີເຫລົ່ານີ້ບໍ່ຖືກກວດກາ
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks ຊີ້ໃຫ້ເຫັນວ່າການປະຕິບັດໂດຍສະເລ່ຍ ສຳ ລັບການປ່ຽນເສັ້ນທາງແບບສຸ່ມແມ່ນດີກວ່າທຸກວິທີທາງຈົນກ່ວາປະມານ `left + right == 32`, ແຕ່ວ່າການປະຕິບັດກໍລະນີທີ່ຮ້າຍແຮງທີ່ສຸດກໍ່ ທຳ ລາຍເຖິງແມ່ນວ່າປະມານ 16.
            // 24 ຖືກເລືອກເປັນຊັ້ນກາງ.
            // ຖ້າຫາກວ່າຂະຫນາດຂອງ `T` ແມ່ນຂະຫນາດໃຫຍ່ກ່ວາ 4 `usize`s ຂັ້ນຕອນວິທີນີ້ຍັງສູງກວ່າຂັ້ນຕອນວິທີອື່ນໆ.
            //
            //
            let x = unsafe { mid.sub(left) };
            // ການເລີ່ມຕົ້ນຂອງຮອບ ທຳ ອິດ
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` ສາມາດພົບເຫັນດ້ວຍມືກ່ອນໂດຍການຄິດໄລ່ `gcd(left + right, right)`, ແຕ່ວ່າມັນໄວກວ່າທີ່ຈະເຮັດ ໜຶ່ງ loop ທີ່ຄິດໄລ່ gcd ເປັນຜົນຂ້າງຄຽງ, ຈາກນັ້ນເຮັດຊິ້ນສ່ວນທີ່ເຫຼືອ
            //
            //
            let mut gcd = right;
            // ມາດຕະຖານສະແດງໃຫ້ເຫັນວ່າມັນໄວກວ່າທີ່ຈະແລກປ່ຽນພື້ນທີ່ຕະຫຼອດເວລາແທນທີ່ຈະອ່ານຊົ່ວຄາວ ໜຶ່ງ ຄັ້ງ, ຄັດລອກຫລັງແລະຫຼັງຈາກນັ້ນຂຽນຊົ່ວຄາວນັ້ນໃນທີ່ສຸດ.
            // ນີ້ແມ່ນອາດຈະເປັນຍ້ອນຄວາມຈິງທີ່ວ່າການແລກປ່ຽນຫລືປ່ຽນແທນພື້ນທີ່ໃຊ້ເວລາພຽງແຕ່ໃຊ້ທີ່ຢູ່ ໜ່ວຍ ຄວາມ ຈຳ ເທົ່ານັ້ນໃນວົງຈອນແທນທີ່ຈະຕ້ອງການຈັດການສອງຢ່າງ.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // ແທນທີ່ຈະເປັນ incrementing `i` ແລະຫຼັງຈາກນັ້ນການກວດສອບຖ້າຫາກວ່າມັນແມ່ນຢູ່ນອກຂອບເຂດ, ພວກເຮົາກວດສອບວ່າ `i` ຈະໄປຢູ່ນອກຂອບເຂດໃນການເພີ່ມຂຶ້ນຕໍ່ໄປ.
                // ສິ່ງນີ້ຈະປ້ອງກັນບໍ່ໃຫ້ມີການບົ່ງຊີ້ຫລື `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // ໃນຕອນທ້າຍຂອງຮອບທໍາອິດ
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ເງື່ອນໄຂນີ້ຕ້ອງຢູ່ທີ່ນີ້ຖ້າ `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // ສຳ ເລັດຮູບທີ່ມີຮອບຫຼາຍ
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ບໍ່ແມ່ນປະເພດທີ່ມີຂະ ໜາດ ສູນ, ດັ່ງນັ້ນມັນຈຶ່ງ ເໝາະ ສົມທີ່ຈະແບ່ງຕາມຂະ ໜາດ ຂອງມັນ.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 `[T; 0]` ຢູ່ທີ່ນີ້ແມ່ນເພື່ອຮັບປະກັນວ່ານີ້ແມ່ນສອດຄ່ອງຢ່າງ ເໝາະ ສົມ ສຳ ລັບ T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 ມີວິທີອື່ນໃນການແລກປ່ຽນທີ່ກ່ຽວຂ້ອງກັບການຊອກຫາບ່ອນທີ່ການປ່ຽນແປງຄັ້ງສຸດທ້າຍຂອງ algorithm ນີ້ແລະການແລກປ່ຽນໂດຍໃຊ້ chunk ສຸດທ້າຍນັ້ນແທນທີ່ຈະກືນເອົາສ່ວນທີ່ຢູ່ຕິດກັນເຊັ່ນ algorithm ນີ້ ກຳ ລັງເຮັດຢູ່, ແຕ່ວິທີນີ້ຍັງໄວກວ່າເກົ່າ.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // ສູດການຄິດໄລ່ 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}