// ການປະຕິບັດຕົ້ນສະບັບແມ່ນມາຈາກ rust-memchr.
// ລິຂະສິດ 2015 Andrew Gallant, bluss ແລະ Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// ໃຊ້ຕັດ.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// ກັບຄືນ `true` ຖ້າ `x` ມີໄບຕ໌ໃດໆ.
///
/// ຈາກ *Matters Computational*, J. Arndt:
///
/// "ແນວຄວາມຄິດແມ່ນການຫັກອອກຈາກແຕ່ລະໄບຕ໌ແລະຫຼັງຈາກນັ້ນຊອກຫາໄບຕ໌ບ່ອນທີ່ເງິນກູ້ຢືມຈະຂະຫຍາຍອອກໄປໃນລະດັບທີ່ ສຳ ຄັນທີ່ສຸດ
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// ສົ່ງຄືນດັດສະນີ ທຳ ອິດທີ່ກົງກັບໄບຕ໌ `x` ໃນ `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // ເສັ້ນທາງໄວ ສຳ ລັບເສັ້ນນ້ອຍໆ
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // ສະແກນມູນຄ່າໄບຕ໌ດຽວໂດຍການອ່ານສອງ ຄຳ `usize` ໃນແຕ່ລະຄັ້ງ.
    //
    // ແຍກ `text` ເປັນສາມສ່ວນ
    // - ສ່ວນເບື້ອງຕົ້ນທີ່ບໍ່ສົມສ່ວນ, ກ່ອນທີ່ ຄຳ ສັບ ທຳ ອິດຈະຈັດລຽນທີ່ຢູ່ໃນຂໍ້ຄວາມ
    // - ຮ່າງກາຍ, ສະແກນໂດຍ 2 ຄຳ ໃນແຕ່ລະຄັ້ງ
    // - ສ່ວນທີ່ຍັງເຫຼືອສຸດທ້າຍ, <2 ຂະ ໜາດ ຄຳ

    // ຄົ້ນຫາເຂດແດນທີ່ສອດຄ່ອງ
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // ຄົ້ນຫາເນື້ອໃນຂອງຕົວ ໜັງ ສື
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // ຄວາມປອດໄພ: ໃນຂະນະທີ່ຄາດຄະເນໃນຂະນະທີ່ຮັບປະກັນໄລຍະຫ່າງຢ່າງ ໜ້ອຍ 2 * usize_bytes
        // ລະຫວ່າງຊົດເຊີຍແລະໃນຕອນທ້າຍຂອງການຫຼັງຈາກນັ້ນນໍາ.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // ທໍາລາຍຖ້າຫາກວ່າມີ byte ໂຍບາຍຄວາມລັບ
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // ຊອກຫາໄບຕ໌ຫຼັງຈາກທີ່ຈຸດຂອງຮ່າງກາຍຢຸດ.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// ສົ່ງຄືນດັດສະນີສຸດທ້າຍທີ່ກົງກັບໄບຕ໌ `x` ໃນ `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // ສະແກນມູນຄ່າໄບຕ໌ດຽວໂດຍການອ່ານສອງ ຄຳ `usize` ໃນແຕ່ລະຄັ້ງ.
    //
    // ແບ່ງປັນ `text` ເປັນສາມພາກສ່ວນ:
    // - ຫາງທີ່ບໍ່ໄດ້ແຕ່ງຕັ້ງ, ຫຼັງຈາກທີ່ ຄຳ ສຸດທ້າຍຈັດຢູ່ໃນຂໍ້ຄວາມ,
    // - ຮ່າງກາຍ, ສະແກນໂດຍ 2 ຄຳ ໃນແຕ່ລະຄັ້ງ,
    // - ຄັ້ງທີສອງທີ່ເຫຼືອ, <2 ຂະ ໜາດ ຄຳ.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // ພວກເຮົາຮຽກຮ້ອງນີ້ພຽງເພື່ອໃຫ້ຄວາມຍາວຂອງ ຄຳ ນຳ ໜ້າ ແລະ ຄຳ ຕໍ່.
        // ຢູ່ເຄິ່ງກາງພວກເຮົາສະເຫມີໄປປຸງແຕ່ງສອງຄອກໃນເວລາດຽວກັນ.
        // ຄວາມປອດໄພ: ການສົ່ງ `[u8]` ຫາ `[usize]` ປອດໄພຍົກເວັ້ນຄວາມແຕກຕ່າງຂອງຂະ ໜາດ ທີ່ໄດ້ຖືກຈັດການໂດຍ `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // ຄົ້ນຫາເນື້ອໃນຂອງຕົວ ໜັງ ສື, ໃຫ້ແນ່ໃຈວ່າພວກເຮົາບໍ່ຂ້າມ min_aligned_offset.
    // ການຊົດເຊີຍແມ່ນສອດຄ່ອງສະເຫມີ, ສະນັ້ນພຽງແຕ່ການທົດສອບ `>` ແມ່ນພຽງພໍແລະຫລີກລ້ຽງການລົ້ນທີ່ເປັນໄປໄດ້.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // ຄວາມປອດໄພ: ການຊົດເຊີຍເລີ່ມຕົ້ນທີ່ len, suffix.len(), ຕາບໃດທີ່ມັນໃຫຍ່ກວ່າ
        // min_aligned_offset (prefix.len()) ໄລຍະທາງທີ່ເຫລືອແມ່ນຢ່າງ ໜ້ອຍ 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // ແຍກຖ້າມີ byte ທີ່ກົງກັນ.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // ຊອກຫາໄບຕ໌ກ່ອນຈຸດທີ່ຮ່າງກາຍຈະຢຸດ.
    text[..offset].iter().rposition(|elt| *elt == x)
}