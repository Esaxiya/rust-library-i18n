//! ການຈັດຮຽງແບບລວດລາຍ
//!
//! ໂມດູນນີ້ປະກອບດ້ວຍລະບົບການຈັດຮຽງໂດຍອີງໃສ່ຮູບແບບໄວຂອງແບບ Orson Peters, ຈັດພີມມາຢູ່: <https://github.com/orlp/pdqsort>
//!
//!
//! ການຈັດປະເພດທີ່ບໍ່ສະຫມໍ່າສະເຫມີແມ່ນເຫມາະສົມກັບ libcore ເພາະວ່າມັນບໍ່ໄດ້ຈັດສັນຄວາມຊົງຈໍາ, ບໍ່ຄືກັບການຈັດຮຽງແບບຄົງທີ່ຂອງພວກເຮົາ.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// ເມື່ອຫຼຸດລົງ, ສຳ ເນົາຈາກ `src` ລົງເປັນ `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // ຄວາມປອດໄພ: ນີ້ແມ່ນຫ້ອງຮຽນຜູ້ຊ່ວຍ.
        //          ກະລຸນາອ້າງອີງເຖິງການ ນຳ ໃຊ້ຂອງມັນເພື່ອຄວາມຖືກຕ້ອງ.
        //          ຄື, ທ່ານຕ້ອງແນ່ໃຈວ່າ `src` ແລະ `dst` ບໍ່ຊໍ້າຊ້ອນຕາມທີ່ `ptr::copy_nonoverlapping` ຕ້ອງການ.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// ປ່ຽນອົງປະກອບ ທຳ ອິດໄປທາງຂວາຈົນກວ່າມັນຈະພົບກັບອົງປະກອບທີ່ໃຫຍ່ກວ່າຫຼືເທົ່າກັນ.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ຄວາມປອດໄພ: ການປະຕິບັດງານທີ່ບໍ່ປອດໄພຢູ່ລຸ່ມນີ້ກ່ຽວຂ້ອງກັບການດັດສະນີໂດຍບໍ່ມີການກວດສອບທີ່ ຈຳ ກັດ (`get_unchecked` ແລະ `get_unchecked_mut`)
    // ແລະ ສຳ ເນົາ (`ptr::copy_nonoverlapping`) ໜ່ວຍ ຄວາມ ຈຳ.
    //
    // ກ.ດັດສະນີ:
    //  1. ພວກເຮົາໄດ້ກວດເບິ່ງຂະ ໜາດ ຂອງອາເລໄປຫາ==2.
    //  2. ການດັດສະນີທັງ ໝົດ ທີ່ພວກເຮົາຈະເຮັດແມ່ນຢູ່ລະຫວ່າງ {0 <= index < len} ຫຼາຍທີ່ສຸດ.
    //
    // ຂ.ສຳ ເນົາຄວາມ ຈຳ
    //  1. ພວກເຮົາ ກຳ ລັງຊອກຫາຕົວຊີ້ບອກເຖິງເອກະສານອ້າງອີງເຊິ່ງຮັບປະກັນວ່າຖືກຕ້ອງ.
    //  2. ພວກເຂົາບໍ່ສາມາດຊໍ້າຊ້ອນໄດ້ເພາະວ່າພວກເຮົາໄດ້ຮັບຕົວຊີ້ບອກເຖິງຄວາມແຕກຕ່າງຂອງຕົວຊີ້ບອກ.
    //     ຄື, `i` ແລະ `i-1`.
    //  3. ຖ້າຫາກວ່າເສດແມ່ນສອດຄ່ອງຢ່າງຖືກຕ້ອງ, ອົງປະກອບຕ່າງໆແມ່ນສອດຄ່ອງຢ່າງຖືກຕ້ອງ.
    //     ມັນແມ່ນຄວາມຮັບຜິດຊອບຂອງຜູ້ໂທເພື່ອໃຫ້ແນ່ໃຈວ່າຊິ້ນຖືກສອດຄ່ອງຢ່າງຖືກຕ້ອງ.
    //
    // ເບິ່ງ ຄຳ ເຫັນຂ້າງລຸ່ມນີ້ ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
    unsafe {
        // ຖ້າສອງອົງປະກອບ ທຳ ອິດບໍ່ອອກ ກຳ ລັງ ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // ອ່ານອົງປະກອບ ທຳ ອິດເຂົ້າໄປໃນຕົວແປທີ່ຈັດສັນຕາມ ລຳ ດັບ.
            // ຖ້າການປະຕິບັດການປຽບທຽບຕໍ່ໄປນີ້ panics, `hole` ຈະຖືກລຸດລົງແລະຂຽນອົງປະກອບອັດຕະໂນມັດເຂົ້າໄປໃນທ່ອນໄມ້.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // ຍ້າຍສິ່ງທີ່ຂ້ອຍຢູ່ບ່ອນ ໜຶ່ງ ໄປທາງຊ້າຍ, ດັ່ງນັ້ນການຍ້າຍຮູໄປທາງຂວາ.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ໄດ້ຮັບການຫຼຸດລົງແລະດັ່ງນັ້ນການຄັດລອກ `tmp` ເຂົ້າໄປໃນຂຸມທີ່ຍັງເຫຼືອໃນ `v`.
        }
    }
}

/// ປ່ຽນອົງປະກອບສຸດທ້າຍໄປທາງຊ້າຍຈົນກວ່າມັນຈະພົບກັບອົງປະກອບນ້ອຍຫລືເທົ່າກັນ.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ຄວາມປອດໄພ: ການປະຕິບັດງານທີ່ບໍ່ປອດໄພຢູ່ລຸ່ມນີ້ກ່ຽວຂ້ອງກັບການດັດສະນີໂດຍບໍ່ມີການກວດສອບທີ່ ຈຳ ກັດ (`get_unchecked` ແລະ `get_unchecked_mut`)
    // ແລະ ສຳ ເນົາ (`ptr::copy_nonoverlapping`) ໜ່ວຍ ຄວາມ ຈຳ.
    //
    // ກ.ດັດສະນີ:
    //  1. ພວກເຮົາໄດ້ກວດເບິ່ງຂະ ໜາດ ຂອງອາເລໄປຫາ==2.
    //  2. ການດັດສະນີທັງ ໝົດ ທີ່ພວກເຮົາຈະເຮັດແມ່ນຢູ່ລະຫວ່າງ `0 <= index < len-1` ຫຼາຍທີ່ສຸດ.
    //
    // ຂ.ສຳ ເນົາຄວາມ ຈຳ
    //  1. ພວກເຮົາ ກຳ ລັງຊອກຫາຕົວຊີ້ບອກເຖິງເອກະສານອ້າງອີງເຊິ່ງຮັບປະກັນວ່າຖືກຕ້ອງ.
    //  2. ພວກເຂົາບໍ່ສາມາດຊໍ້າຊ້ອນໄດ້ເພາະວ່າພວກເຮົາໄດ້ຮັບຕົວຊີ້ບອກເຖິງຄວາມແຕກຕ່າງຂອງຕົວຊີ້ບອກ.
    //     ຄື, `i` ແລະ `i+1`.
    //  3. ຖ້າຫາກວ່າເສດແມ່ນສອດຄ່ອງຢ່າງຖືກຕ້ອງ, ອົງປະກອບຕ່າງໆແມ່ນສອດຄ່ອງຢ່າງຖືກຕ້ອງ.
    //     ມັນແມ່ນຄວາມຮັບຜິດຊອບຂອງຜູ້ໂທເພື່ອໃຫ້ແນ່ໃຈວ່າຊິ້ນຖືກສອດຄ່ອງຢ່າງຖືກຕ້ອງ.
    //
    // ເບິ່ງ ຄຳ ເຫັນຂ້າງລຸ່ມນີ້ ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
    unsafe {
        // ຖ້າສອງອົງປະກອບສຸດທ້າຍທີ່ບໍ່ມີລະບຽບ ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // ອ່ານອົງປະກອບສຸດທ້າຍເຂົ້າໄປໃນຕົວແປທີ່ຈັດສັນຕາມ ລຳ ດັບ.
            // ຖ້າການປະຕິບັດການປຽບທຽບຕໍ່ໄປນີ້ panics, `hole` ຈະຖືກລຸດລົງແລະຂຽນອົງປະກອບອັດຕະໂນມັດເຂົ້າໄປໃນທ່ອນໄມ້.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // ຍ້າຍ `i`-i ອົງປະກອບ ໜຶ່ງ ໄປທາງຂວາມື, ດັ່ງນັ້ນຈຶ່ງປ່ຽນຮູໄປທາງຊ້າຍ.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ໄດ້ຮັບການຫຼຸດລົງແລະດັ່ງນັ້ນການຄັດລອກ `tmp` ເຂົ້າໄປໃນຂຸມທີ່ຍັງເຫຼືອໃນ `v`.
        }
    }
}

/// ບາງສ່ວນຈັດຮຽງໂດຍຍ້າຍສ່ວນປະກອບອອກນອກຫຼາຍຢ່າງອ້ອມຮອບ.
///
/// ສົ່ງຄືນ `true` ຖ້າຊິ້ນສ່ວນຖືກຈັດຮຽງຢູ່ປາຍສຸດ.ໜ້າ ທີ່ນີ້ແມ່ນ *O*(*n*) ຮ້າຍແຮງທີ່ສຸດ.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // ຈຳ ນວນສູງສຸດຂອງຄູ່ທີ່ອອກ ຄຳ ສັ່ງທີ່ຢູ່ຕິດກັນທີ່ຢູ່ໃກ້ຄຽງເຊິ່ງຈະໄດ້ຮັບການຍົກຍ້າຍ.
    const MAX_STEPS: usize = 5;
    // ຖ້າສ່ວນ ໜຶ່ງ ແມ່ນສັ້ນກວ່ານີ້, ຢ່າປ່ຽນສ່ວນປະກອບໃດໆ.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // ຄວາມປອດໄພ: ພວກເຮົາໄດ້ເຮັດການກວດສອບດ້ວຍ `i < len` ຢ່າງຈະແຈ້ງແລ້ວ.
        // ການດັດສະນີຕໍ່ໆໄປຂອງພວກເຮົາທັງ ໝົດ ແມ່ນຢູ່ໃນລະດັບ `0 <= index < len` ເທົ່ານັ້ນ
        unsafe {
            // ຊອກຫາຄູ່ຕໍ່ໄປຂອງອົງປະກອບທີ່ບໍ່ມີການສັ່ງຊື້ທີ່ຢູ່ຕິດກັນ.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // ພວກເຮົາເຮັດແລ້ວບໍ?
        if i == len {
            return true;
        }

        // ຢ່າປ່ຽນອົງປະກອບໃນການຂຽນສັ້ນ, ທີ່ມີຄ່າໃຊ້ຈ່າຍໃນການປະຕິບັດ.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // ແລກປ່ຽນຄູ່ທີ່ພົບເຫັນຂອງອົງປະກອບ.puts ນີ້ໃຫ້ເຂົາເຈົ້າໃນຄໍາສັ່ງທີ່ຖືກຕ້ອງ.
        v.swap(i - 1, i);

        // ປ່ຽນອົງປະກອບນ້ອຍລົງໄປທາງຊ້າຍ.
        shift_tail(&mut v[..i], is_less);
        // ປ່ຽນອົງປະກອບທີ່ໃຫຍ່ກວ່າໄປທາງຂວາ.
        shift_head(&mut v[i..], is_less);
    }

    // ບໍ່ໄດ້ຈັດການຈັດຮຽງຕາມຂັ້ນຕອນທີ່ ຈຳ ກັດ.
    false
}

/// ຈັດຮຽງເປັນທ່ອນໂດຍໃຊ້ການຈັດລຽງການແຊກ, ເຊິ່ງແມ່ນ *O*(*n*^ 2) ທີ່ຮ້າຍແຮງທີ່ສຸດ.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// ຈັດຮຽງ `v` ໂດຍໃຊ້ heapsort, ເຊິ່ງຮັບປະກັນ *O*(*n*\*log(* n*)) ທີ່ບໍ່ດີທີ່ສຸດ).
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ຖານສອງຊ່ອງນີ້ນັບຖື `parent >= child` ທີ່ບໍ່ມີຕົວຕົນ.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // ເດັກນ້ອຍ `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // ເລືອກເດັກນ້ອຍທີ່ໃຫຍ່ກວ່າ.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // ຢຸດຖ້າການບຸກລຸກຖືຢູ່ທີ່ `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // ແລກປ່ຽນ `node` ກັບລູກທີ່ໃຫຍ່ກວ່າ, ຍ້າຍລົງ 1 ບາດ, ແລະສືບຕໍ່ຍ້າຍ.
            v.swap(node, greater);
            node = greater;
        }
    };

    // ສ້າງ heap ໃນເວລາເສັ້ນ.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // ອົງປະກອບສູງສຸດທີ່ Pop ຈາກ heap.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// ການແບ່ງປັນ `v` ເຂົ້າໄປໃນອົງປະກອບຂະຫນາດນ້ອຍກ່ວາ `pivot`, ຕິດຕາມມາດ້ວຍອົງປະກອບຫຼາຍກ່ວາຫຼືເທົ່າທຽມກັນທີ່ `pivot`.
///
///
/// ສົ່ງ ຈຳ ນວນຂອງອົງປະກອບນ້ອຍກວ່າ `pivot`.
///
/// ການແບ່ງສ່ວນແບ່ງແມ່ນ ດຳ ເນີນການຕໍ່ເນື່ອງເພື່ອຫຼຸດຜ່ອນຄ່າໃຊ້ຈ່າຍໃນການ ດຳ ເນີນງານທີ່ແຕກຕ່າງກັນ.
/// ຄວາມຄິດນີ້ຖືກ ນຳ ສະ ເໜີ ໃນເຈ້ຍ [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // ຈໍານວນຂອງອົງປະກອບໃນທ່ອນໄມ້ປົກກະຕິ.
    const BLOCK: usize = 128;

    // ສູດການຄິດໄລ່ການແບ່ງປັນໄດ້ເຮັດຕາມຂັ້ນຕອນຕໍ່ໄປນີ້ຈົນກວ່າຈະ ສຳ ເລັດ:
    //
    // 1. ຕິດຕາມທ່ອນໄມ້ຈາກເບື້ອງຊ້າຍເພື່ອລະບຸອົງປະກອບທີ່ໃຫຍ່ກວ່າຫຼືເທົ່າກັບຕົວຊີ້ວັດ.
    // 2. ຕິດຕາມ block ຈາກຂ້າງສິດທິໃນການກໍານົດອົງປະກອບຂະຫນາດນ້ອຍກ່ວາ pivot.
    // 3. ແລກປ່ຽນສ່ວນປະກອບທີ່ລະບຸໄວ້ລະຫວ່າງເບື້ອງຊ້າຍແລະຂວາ.
    //
    // ພວກເຮົາຮັກສາຕົວແປດັ່ງຕໍ່ໄປນີ້ ສຳ ລັບທ່ອນໄມ້ຂອງອົງປະກອບ:
    //
    // 1. `block` - ຈໍານວນຂອງອົງປະກອບໃນທ່ອນໄມ້.
    // 2. `start` - ເລີ່ມຕົ້ນຕົວຊີ້ເຂົ້າໄປໃນແຖວ `offsets`.
    // 3. `end` - ສິ້ນສຸດຊີ້ເຂົ້າໄປໃນຂບວນ `offsets`.
    // 4. `ການຊົດເຊີຍ, ການຊີ້ບອກຂອງອົງປະກອບທີ່ບໍ່ອອກ ຄຳ ສັ່ງພາຍໃນທ່ອນໄມ້.

    // ທ່ອນໄມ້ປະຈຸບັນຢູ່ເບື້ອງຊ້າຍ (ຈາກ `l` ເຖິງ `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // ທ່ອນໄມ້ປະຈຸບັນຢູ່ເບື້ອງຂວາ (ຈາກ `r.sub(block_r)` to `r`).
    // ຄວາມປອດໄພ: ເອກະສານ ສຳ ລັບ .add() ກ່າວໂດຍສະເພາະວ່າ `vec.as_ptr().add(vec.len())` ແມ່ນປອດໄພສະເຫມີໄປ `
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: ເມື່ອພວກເຮົາໄດ້ຮັບ VLAs, ລອງສ້າງ ໜຶ່ງ ແຖວຂອງຄວາມຍາວ `min(v.len(), 2 * BLOCK) `ແທນທີ່ຈະ
    // ກ່ວາສອງຂບວນທີ່ມີຂະ ໜາດ ຄົງທີ່ຂອງຄວາມຍາວ `BLOCK`.VLAs ອາດຈະເປັນ cache ຫຼາຍ.

    // ສົ່ງຄືນ ຈຳ ນວນຂອງອົງປະກອບລະຫວ່າງຕົວຊີ້ວັດ `l` (inclusive) ແລະ `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // ພວກເຮົາໄດ້ເຮັດແລ້ວດ້ວຍການແບ່ງປັນ block-by-block ເມື່ອ `l` ແລະ `r` ໃກ້ເຂົ້າມາແລ້ວ.
        // ຈາກນັ້ນພວກເຮົາເຮັດວຽກເພີ້ມຂື້ນເພື່ອແບ່ງປັນສ່ວນປະກອບທີ່ຍັງເຫຼືອຢູ່ໃນລະຫວ່າງ.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // ຈໍານວນອົງປະກອບທີ່ຍັງເຫຼືອ (ຍັງບໍ່ປຽບທຽບກັບ pivot ໄດ້).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // ປັບຂະ ໜາດ ຂອງທ່ອນໄມ້ໄວ້ເພື່ອໃຫ້ທ່ອນໄມ້ຊ້າຍແລະຂວາບໍ່ຊ້ ຳ ກັນ, ແຕ່ໃຫ້ສອດຄ່ອງຢ່າງສົມບູນເພື່ອປົກປິດຊ່ອງຫວ່າງທີ່ຍັງເຫຼືອ.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // ຕິດຕາມອົງປະກອບ `block_l` ຈາກເບື້ອງຊ້າຍ.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // ຄວາມປອດໄພ: ການປະຕິບັດງານທີ່ບໍ່ປອດໄພດ້ານລຸ່ມແມ່ນກ່ຽວຂ້ອງກັບການ ນຳ ໃຊ້ `offset`.
                //         ອີງຕາມເງື່ອນໄຂທີ່ຕ້ອງການໂດຍ ໜ້າ ທີ່, ພວກເຮົາພໍໃຈກັບພວກເຂົາເພາະວ່າ:
                //         1. `offsets_l` ແມ່ນ stack ຈັດສັນໃຫ້, ແລະດັ່ງນັ້ນຈຶ່ງພິຈາລະນາຈຸດປະສົງການຈັດສັນແຍກຕ່າງຫາກ.
                //         2. ການທໍາງານຂອງ `is_less` ຈະກັບຄືນມາເປັນ `bool`.
                //            ການສະແກນ `bool` ຈະບໍ່ XXXX ລົ້ນເກີນໄປ.
                //         3. ພວກເຮົາໄດ້ຮັບປະກັນວ່າ `block_l` ຈະເປັນ `<= BLOCK`.
                //            ຍິ່ງໄປກວ່ານັ້ນ, `end_l` ໄດ້ຖືກຕັ້ງເປັນຈຸດເລີ່ມຕົ້ນຂອງຕົວຊີ້ທິດທາງເລີ່ມຕົ້ນຂອງ `offsets_` ເຊິ່ງໄດ້ຖືກປະກາດໃນຊັ້ນ.
                //            ດັ່ງນັ້ນ, ພວກເຮົາຮູ້ວ່າເຖິງແມ່ນວ່າໃນກໍລະນີທີ່ບໍ່ດີທີ່ສຸດ (ການຮຽກຮ້ອງທຸກຢ່າງຂອງ `is_less` ຈະສົ່ງຄືນບໍ່ຖືກຕ້ອງ) ພວກເຮົາຈະຢູ່ໃນລະດັບ 1 ໄບຕ໌ເທົ່ານັ້ນ.
                //        ການປະຕິບັດງານທີ່ບໍ່ປອດໄພອີກປະການ ໜຶ່ງ ຢູ່ທີ່ນີ້ແມ່ນການ dereferencing `elem`.
                //        ເຖິງຢ່າງໃດກໍ່ຕາມ, ໃນເບື້ອງຕົ້ນ, `elem` ແມ່ນຈຸດເລີ່ມຕົ້ນຂອງຕົວຊີ້ທິດທີ່ຖືກຕ້ອງ.
                unsafe {
                    // ການປຽບທຽບສາຂາ.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // ຕິດຕາມອົງປະກອບ `block_r` ຈາກເບື້ອງຂວາ.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // ຄວາມປອດໄພ: ການປະຕິບັດງານທີ່ບໍ່ປອດໄພດ້ານລຸ່ມແມ່ນກ່ຽວຂ້ອງກັບການ ນຳ ໃຊ້ `offset`.
                //         ອີງຕາມເງື່ອນໄຂທີ່ຕ້ອງການໂດຍ ໜ້າ ທີ່, ພວກເຮົາພໍໃຈກັບພວກເຂົາເພາະວ່າ:
                //         1. `offsets_r` ແມ່ນ stack ຈັດສັນໃຫ້, ແລະດັ່ງນັ້ນຈຶ່ງພິຈາລະນາຈຸດປະສົງການຈັດສັນແຍກຕ່າງຫາກ.
                //         2. ການທໍາງານຂອງ `is_less` ຈະກັບຄືນມາເປັນ `bool`.
                //            ການສະແກນ `bool` ຈະບໍ່ XXXX ລົ້ນເກີນໄປ.
                //         3. ພວກເຮົາໄດ້ຮັບປະກັນວ່າ `block_r` ຈະເປັນ `<= BLOCK`.
                //            ຍິ່ງໄປກວ່ານັ້ນ, `end_r` ໄດ້ຖືກຕັ້ງເປັນຈຸດເລີ່ມຕົ້ນຂອງຕົວຊີ້ທິດທາງເລີ່ມຕົ້ນຂອງ `offsets_` ເຊິ່ງໄດ້ຖືກປະກາດໃນຊັ້ນ.
                //            ດັ່ງນັ້ນ, ພວກເຮົາຮູ້ວ່າເຖິງແມ່ນວ່າໃນກໍລະນີທີ່ບໍ່ດີທີ່ສຸດ (ການຮຽກຮ້ອງທຸກຢ່າງຂອງ `is_less` ຈະກັບຄືນມາເປັນຄວາມຈິງ) ພວກເຮົາຈະມີພຽງແຕ່ 1 ໄບຕ໌ເທົ່ານັ້ນທີ່ສຸດ.
                //        ການປະຕິບັດງານທີ່ບໍ່ປອດໄພອີກປະການ ໜຶ່ງ ຢູ່ທີ່ນີ້ແມ່ນການ dereferencing `elem`.
                //        ເຖິງຢ່າງໃດກໍ່ຕາມ, `elem` ໃນເບື້ອງຕົ້ນແມ່ນ `1 *sizeof(T)` ໃນໄລຍະທີ່ສຸດແລະພວກເຮົາຫຼຸດລົງໂດຍ `1* sizeof(T)` ກ່ອນທີ່ຈະເຂົ້າເຖິງມັນ.
                //        ຍິ່ງໄປກວ່ານັ້ນ, `block_r` ໄດ້ຖືກຮັບຮອງວ່ານ້ອຍກວ່າ `BLOCK` ແລະ `elem` ດັ່ງນັ້ນສ່ວນຫຼາຍຈະຊີ້ໄປທີ່ຈຸດເລີ່ມຕົ້ນ.
                unsafe {
                    // ການປຽບທຽບສາຂາ.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // ຈຳ ນວນຂອງສ່ວນປະກອບທີ່ບໍ່ມີລະບຽບເພື່ອແລກປ່ຽນລະຫວ່າງເບື້ອງຊ້າຍແລະຂວາ.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // ແທນທີ່ຈະແລກປ່ຽນຄູ່ ໜຶ່ງ ໃນເວລານັ້ນ, ມັນຈະມີປະສິດທິພາບຫຼາຍກວ່າທີ່ຈະເຮັດວົງຈອນປິດ.
            // ນີ້ບໍ່ແມ່ນເທົ່າກັບການແລກປ່ຽນຢ່າງເຄັ່ງຄັດ, ແຕ່ກໍ່ໃຫ້ເກີດຜົນທີ່ຄ້າຍຄືກັນໂດຍໃຊ້ການປະຕິບັດງານຄວາມ ຈຳ ໜ້ອຍ ລົງ.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // ທຸກໆອົງປະກອບທີ່ບໍ່ມີການສັ່ງຊື້ໃນທ່ອນໄມ້ຊ້າຍຖືກຍ້າຍໄປ.ຍ້າຍໄປທີ່ທ່ອນໄມ້ຕໍ່ໄປ.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // ທຸກໆອົງປະກອບທີ່ບໍ່ມີການສັ່ງຊື້ໃນທ່ອນໄມ້ທີ່ຖືກຕ້ອງຖືກຍ້າຍໄປ.ຍ້າຍໄປທີ່ທ່ອນໄມ້ກ່ອນຫນ້ານີ້.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // ສິ່ງທີ່ຍັງຄົງຄ້າງຢູ່ໃນປະຈຸບັນນີ້ແມ່ນສ່ວນໃຫຍ່ແມ່ນ ໜຶ່ງ ທ່ອນ (ບໍ່ວ່າຈະເປັນທາງຊ້າຍຫລືດ້ານຂວາ) ທີ່ມີສ່ວນປະກອບທີ່ບໍ່ໄດ້ຮັບການຍົກຍ້າຍ.
    // ອົງປະກອບທີ່ຍັງເຫຼືອດັ່ງກ່າວສາມາດປ່ຽນໄປສູ່ຈຸດຈົບພາຍໃນທ່ອນໄມ້ຂອງພວກມັນ.
    //

    if start_l < end_l {
        // ທ່ອນໄມ້ຊ້າຍຍັງຄົງຢູ່.
        // ຍ້າຍອົງປະກອບທີ່ບໍ່ເປັນລະບຽບຂອງມັນອອກສູ່ເບື້ອງຂວາ.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // ທ່ອນໄມ້ທີ່ຖືກຕ້ອງ.
        // ຍ້າຍອົງປະກອບທີ່ບໍ່ເປັນລະບຽບຂອງມັນອອກສູ່ເບື້ອງຊ້າຍ.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // ບໍ່ມີຫຍັງອີກທີ່ຈະເຮັດ, ພວກເຮົາໄດ້ເຮັດແລ້ວ.
        width(v.as_mut_ptr(), l)
    }
}

/// Partitions `v` ເຂົ້າໄປໃນອົງປະກອບນ້ອຍກວ່າ `v[pivot]`, ຕາມມາດ້ວຍອົງປະກອບທີ່ໃຫຍ່ກວ່າຫຼືເທົ່າກັບ `v[pivot]`.
///
///
/// ສົ່ງກັບຄືນ tuple ຂອງ:
///
/// 1. ຈໍານວນຂອງອົງປະກອບນ້ອຍກວ່າ `v[pivot]`.
/// 2. ຖືກຕ້ອງຖ້າ `v` ຖືກແບ່ງປັນແລ້ວ.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // ວາງຕົວຢ່າງຢູ່ຈຸດເລີ່ມຕົ້ນຂອງທ່ອນ.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // ອ່ານຕົວຊີ້ວັດເຂົ້າໄປໃນຕົວແປທີ່ຈັດສັນໄວ້ເພື່ອປະສິດທິພາບ.
        // ຖ້າການປະຕິບັດການປຽບທຽບດັ່ງຕໍ່ໄປນີ້ panics, ຕົວຊີ້ວັດຈະຖືກຂຽນໂດຍອັດຕະໂນມັດເຂົ້າໄປໃນກະດານ.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // ຊອກຫາຄູ່ ທຳ ອິດຂອງອົງປະກອບທີ່ບໍ່ອອກແບບ.
        let mut l = 0;
        let mut r = v.len();

        // ຄວາມປອດໄພ: ຄວາມບໍ່ປອດໄພຢູ່ດ້ານລຸ່ມກ່ຽວຂ້ອງກັບການດັດສະນີແຖວ.
        // ສໍາລັບການຫນຶ່ງຄັ້ງທໍາອິດ: ພວກເຮົາແລ້ວເຮັດຂອບເຂດການກວດສອບນີ້ກັບ `l < r`.
        // ສຳ ລັບອັນທີ່ສອງ: ໃນເບື້ອງຕົ້ນພວກເຮົາມີ `l == 0` ແລະ `r == v.len()` ແລະພວກເຮົາໄດ້ກວດເບິ່ງວ່າ `l < r` ໃນທຸກໆການ ດຳ ເນີນການດັດສະນີ.
        //                     ຈາກນີ້ພວກເຮົາຮູ້ວ່າ `r` ຈະຕ້ອງເປັນຢ່າງຫນ້ອຍ `r == l` ເຊິ່ງສະແດງໃຫ້ເຫັນວ່າມັນຖືກຕ້ອງຈາກໂຕ ທຳ ອິດ.
        unsafe {
            // ຊອກຫາອົງປະກອບ ທຳ ອິດທີ່ໃຫຍ່ກວ່າຫຼືເທົ່າກັບຕົວຊີ້ວັດ.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // ຊອກຫາອົງປະກອບສຸດທ້າຍທີ່ນ້ອຍກວ່າຕົວຢ່າງ.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` ອອກຈາກຂອບເຂດແລະຂຽນ pivot (ເຊິ່ງແມ່ນຕົວແປທີ່ຈັດສັນໄວ້ເປັນ stack) ກັບເຂົ້າໄປໃນບ່ອນທີ່ມັນຕັ້ງຢູ່ເດີມ.
        // ຂັ້ນຕອນນີ້ແມ່ນມີຄວາມ ສຳ ຄັນໃນການຮັບປະກັນຄວາມປອດໄພ!
        //
    };

    // ວາງຕົວຊີ້ວັດລະຫວ່າງສອງສ່ວນ.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partitions `v` ເຂົ້າໃນອົງປະກອບເທົ່າກັບ `v[pivot]` ຕິດຕາມດ້ວຍອົງປະກອບທີ່ໃຫຍ່ກວ່າ `v[pivot]`.
///
/// ສົ່ງ ຈຳ ນວນຂອງສ່ວນປະກອບເທົ່າກັບ pivot.
/// ມັນສົມມຸດວ່າ `v` ບໍ່ປະກອບດ້ວຍອົງປະກອບຂະຫນາດນ້ອຍກ່ວາ pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // ວາງຕົວຢ່າງຢູ່ຈຸດເລີ່ມຕົ້ນຂອງທ່ອນ.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // ອ່ານຕົວຊີ້ວັດເຂົ້າໄປໃນຕົວແປທີ່ຈັດສັນໄວ້ເພື່ອປະສິດທິພາບ.
    // ຖ້າການປະຕິບັດການປຽບທຽບດັ່ງຕໍ່ໄປນີ້ panics, ຕົວຊີ້ວັດຈະຖືກຂຽນໂດຍອັດຕະໂນມັດເຂົ້າໄປໃນກະດານ.
    // ຄວາມປອດໄພ: ຕົວຊີ້ຢູ່ທີ່ນີ້ແມ່ນຖືກຕ້ອງເພາະມັນໄດ້ຮັບຈາກການອ້າງອິງເຖິງໃບ້.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // ໃນປັດຈຸບັນແບ່ງສ່ວນແບ່ງ.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // ຄວາມປອດໄພ: ຄວາມບໍ່ປອດໄພຢູ່ດ້ານລຸ່ມກ່ຽວຂ້ອງກັບການດັດສະນີແຖວ.
        // ສໍາລັບການຫນຶ່ງຄັ້ງທໍາອິດ: ພວກເຮົາແລ້ວເຮັດຂອບເຂດການກວດສອບນີ້ກັບ `l < r`.
        // ສຳ ລັບອັນທີ່ສອງ: ໃນເບື້ອງຕົ້ນພວກເຮົາມີ `l == 0` ແລະ `r == v.len()` ແລະພວກເຮົາໄດ້ກວດເບິ່ງວ່າ `l < r` ໃນທຸກໆການ ດຳ ເນີນການດັດສະນີ.
        //                     ຈາກນີ້ພວກເຮົາຮູ້ວ່າ `r` ຈະຕ້ອງເປັນຢ່າງຫນ້ອຍ `r == l` ເຊິ່ງສະແດງໃຫ້ເຫັນວ່າມັນຖືກຕ້ອງຈາກໂຕ ທຳ ອິດ.
        unsafe {
            // ຊອກຫາອົງປະກອບ ທຳ ອິດທີ່ໃຫຍ່ກວ່າຕົວຊີ້ວັດ.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // ຊອກຫາອົງປະກອບສຸດທ້າຍເທົ່າກັບ pivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // ພວກເຮົາເຮັດແລ້ວບໍ?
            if l >= r {
                break;
            }

            // ແລກປ່ຽນຄູ່ທີ່ພົບເຫັນຂອງອົງປະກອບທີ່ບໍ່ມີ ຄຳ ສັ່ງ.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // ພວກເຮົາພົບເຫັນອົງປະກອບ `l` ເທົ່າກັບ pivot.ຕື່ມການ 1 ກັບບັນຊີສໍາລັບການຫມຸນຕົວມັນເອງ.
    l + 1

    // `_pivot_guard` ອອກຈາກຂອບເຂດແລະຂຽນ pivot (ເຊິ່ງແມ່ນຕົວແປທີ່ຈັດສັນໄວ້ເປັນ stack) ກັບເຂົ້າໄປໃນບ່ອນທີ່ມັນຕັ້ງຢູ່ເດີມ.
    // ຂັ້ນຕອນນີ້ແມ່ນມີຄວາມ ສຳ ຄັນໃນການຮັບປະກັນຄວາມປອດໄພ!
}

/// ກະແຈກກະຈາຍອົງປະກອບບາງຢ່າງທີ່ຢູ່ອ້ອມຂ້າງໃນຄວາມພະຍາຍາມທີ່ຈະ ທຳ ລາຍຮູບແບບທີ່ອາດຈະເຮັດໃຫ້ເກີດການແບ່ງສ່ວນທີ່ບໍ່ສົມດຸນໃນເຂດວ່ອງໄວ.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // ເຄື່ອງຈັກຜະລິດເລກລະຫັດ Pseudorandom ຈາກເຈ້ຍ "Xorshift RNGs" ໂດຍ George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // ເອົາຕົວເລກແບບສຸ່ມ ຈຳ ນວນ ຈຳ ນວນນີ້.
        // ຈໍານວນການຊັກເຂົ້າໄປໃນ `usize` ເພາະ `len` ບໍ່ແມ່ນຫຼາຍກ່ວາ `isize::MAX`.
        let modulus = len.next_power_of_two();

        // ບັນດາຜູ້ສະ ໝັກ pivot ບາງຄົນຈະຢູ່ໃນດັດຊະນີນີ້.ໃຫ້ຂອງ Random ໃຫ້ເຂົາເຈົ້າ.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // ສ້າງ ຈຳ ນວນແບບ ຈຳ ລອງແບບໂມດູນ `len`.
            // ເຖິງຢ່າງໃດກໍ່ຕາມ, ເພື່ອຫລີກລ້ຽງການ ດຳ ເນີນງານທີ່ມີຄ່າໃຊ້ຈ່າຍ, ພວກເຮົາ ທຳ ອິດຈະເອົາມັນເປັນພະລັງຂອງສອງ, ແລະຈາກນັ້ນຫຼຸດລົງໂດຍ `len` ຈົນກວ່າມັນຈະ ເໝາະ ສົມກັບລະດັບ `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` ການຮັບປະກັນທີ່ຈະຫນ້ອຍກ່ວາ `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// ເລືອກເອົາຕົວ pivot ໃນ `v` ແລະສົ່ງຄືນດັດຊະນີແລະ `true` ຖ້າຫາກວ່າແຜ່ນບາງໆອາດຈະຖືກຈັດຮຽງແລ້ວ.
///
/// ອົງປະກອບໃນ `v` ອາດຈະຖືກ ນຳ ໃຊ້ເຂົ້າໃນຂະບວນການ.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // ຄວາມຍາວຕ່ໍາສຸດທີ່ຈະເລືອກເອົາປານກາງຂອງປານກາງວິທີການໄດ້.
    // ເຄື່ອງຂູດສັ້ນໆໃຊ້ວິທີປານກາງຂອງສາມແບບງ່າຍໆ.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // ຈຳ ນວນສູງສຸດຂອງການແລກປ່ຽນທີ່ສາມາດ ດຳ ເນີນໃນ ໜ້າ ທີ່ນີ້.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // ຕົວຊີ້ວັດສາມໃກ້ທີ່ພວກເຮົາຈະເລືອກເອົາຕົວຊີ້ວັດ.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // ນັບຈໍານວນທັງຫມົດຂອງແລກປ່ຽນປະສົບພວກເຮົາກໍາລັງຈະປະຕິບັດໃນຂະນະທີ່ການຄັດເລືອກດັດສະນີ.
    let mut swaps = 0;

    if len >= 8 {
        // ແລກປ່ຽນຕົວຊີ້ບອກດັ່ງນັ້ນ `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // ແລກປ່ຽນຕົວຊີ້ບອກດັ່ງນັ້ນ `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // ຊອກຫາລະດັບປານກາງຂອງ `v[a - 1], v[a], v[a + 1]` ແລະເກັບຮັກສາດັດສະນີໄວ້ເປັນ `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // ຊອກຫາສື່ກາງໃນເຂດໄກ້ຄຽງຂອງ `a`, `b`, ແລະ `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // ຊອກຫາກາງໃນບັນດາ `a`, `b`, ແລະ `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // ຈຳ ນວນສູງສຸດຂອງການແລກປ່ຽນປະຕິບັດ.
        // ຄວາມເປັນໄປໄດ້ແມ່ນເສັ້ນທາງຂື້ນລົງຫລືສ່ວນຫລາຍແມ່ນລົງມາ, ສະນັ້ນການຖອຍຫລັງອາດຈະຊ່ວຍຈັດຮຽງມັນໄດ້ໄວຂື້ນ.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// ຄັດແບບ `v` ຄືນ ໃໝ່.
///
/// ຖ້າຫາກວ່າຫຼັງຈາກນັ້ນນໍາມີ predecessor ໃນຂບວນຕົ້ນສະບັບ, ມັນໄດ້ຖືກລະບຸເປັນ `pred`.
///
/// `limit` ແມ່ນ ຈຳ ນວນຂອງສ່ວນທີ່ບໍ່ສົມດຸນທີ່ອະນຸຍາດກ່ອນທີ່ຈະປ່ຽນເປັນ `heapsort`.
/// ຖ້າສູນ, ຟັງຊັນນີ້ຈະປ່ຽນເປັນ heapsort ທັນທີ.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // ແຜ່ນບາງສ່ວນເຖິງຄວາມຍາວນີ້ໄດ້ຮັບການຈັດຮຽງໂດຍ ນຳ ໃຊ້ການຈັດລຽງຂອງບ່ອນໃສ່.
    const MAX_INSERTION: usize = 20;

    // ຖືກຕ້ອງຖ້າການແບ່ງສ່ວນສຸດທ້າຍແມ່ນສົມເຫດສົມຜົນ.
    let mut was_balanced = true;
    // ຖືກຕ້ອງຖ້າການແບ່ງສ່ວນສຸດທ້າຍບໍ່ໄດ້ສັ່ນອົງປະກອບ (ສ່ວນແບ່ງແມ່ນແບ່ງອອກແລ້ວ).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // ບັນດາຊິ້ນສ່ວນສັ້ນໆໄດ້ຮັບການຈັດຮຽງໂດຍ ນຳ ໃຊ້ການຄັດປະເພດ.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // ຖ້າມີການເລືອກຕົວ pivot ທີ່ບໍ່ດີຫຼາຍເກີນໄປ, ໃຫ້ທ່ານກັບໄປທີ່ heapsort ເພື່ອຮັບປະກັນກໍລະນີທີ່ຮ້າຍແຮງທີ່ສຸດ.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // ຖ້າການແບ່ງສ່ວນສຸດທ້າຍບໍ່ສົມດຸນ, ພະຍາຍາມ ທຳ ລາຍຮູບແບບຕ່າງໆໃນທ່ອນໄມ້ໂດຍການສັ່ນບາງສ່ວນປະມານ.
        // ຫວັງວ່າພວກເຮົາຈະເລືອກເອົາຕົວຢ່າງທີ່ດີທີ່ສຸດໃນຄັ້ງນີ້.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // ເລືອກຕົວຊີ້ວັດແລະລອງເດົາວ່າໃບລິ້ນໄດ້ຖືກຈັດຮຽງແລ້ວ.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // ຖ້າການແບ່ງປັນສຸດທ້າຍຖືກດຸ່ນດ່ຽງຢ່າງສົມເຫດສົມຜົນແລະບໍ່ໄດ້ແກວ່ງອົງປະກອບ, ແລະຖ້າການເລືອກຕົວຢ່າງຄາດຄະເນຄາດຄະເນວ່າມັນຈະຖືກຈັດຮຽງແລ້ວ ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // ພະຍາຍາມ ກຳ ນົດຫຼາຍໆອົງປະກອບທີ່ບໍ່ມີລະບຽບແລະປ່ຽນພວກມັນໄປ ຕຳ ແໜ່ງ ທີ່ຖືກຕ້ອງ.
            // ຖ້າຫາກວ່າສ່ວນປະກອບສິ້ນສຸດລົງຖືກຈັດແຈງຢ່າງສົມບູນ, ພວກເຮົາກໍ່ເຮັດແລ້ວ.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // ຖ້າຕົວຢ່າງທີ່ຖືກຄັດເລືອກແມ່ນເທົ່າກັບຜູ້ທີ່ມາກ່ອນ, ຫຼັງຈາກນັ້ນມັນກໍ່ແມ່ນອົງປະກອບທີ່ນ້ອຍທີ່ສຸດໃນກະດານ.
        // ແບ່ງສ່ວນເຂົ້າໄປໃນສ່ວນປະກອບເທົ່າກັບແລະສ່ວນປະກອບທີ່ໃຫຍ່ກວ່າຕົວຊີ້ວັດ.
        // ກໍລະນີນີ້ມັກຈະຖືກຕີເມື່ອຊິ້ນມີສ່ວນປະກອບທີ່ຊ້ ຳ ກັນຫຼາຍ.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // ສືບຕໍ່ຈັດຮຽງອົງປະກອບທີ່ໃຫຍ່ກວ່າຕົວຊີ້ວັດ.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // ການແບ່ງສ່ວນ.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // ແບ່ງສ່ວນເສດເປັນ `left`, `pivot`, ແລະ `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // ພະຍາບານເຂົ້າໄປໃນສ່ວນທີ່ສັ້ນກວ່າເທົ່ານັ້ນເພື່ອຫຼຸດຜ່ອນ ຈຳ ນວນການໂທທັງ ໝົດ ໃຫ້ ໜ້ອຍ ທີ່ສຸດແລະບໍລິໂພກພື້ນທີ່ ໜ້ອຍ ກວ່າ.
        // ຫຼັງຈາກນັ້ນ, ພຽງແຕ່ສືບຕໍ່ກັບຂ້າງທີ່ຍາວກວ່າ (ນີ້ແມ່ນຄ້າຍຄືກັບການກວດຄືນຂອງຫາງ).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// ຈັດຮຽງ `v` ໂດຍໃຊ້ quicksort ທີ່ເອົາຊະນະຮູບແບບ, ເຊິ່ງແມ່ນ *O*(*n*\*log(* n*)) ທີ່ບໍ່ດີທີ່ສຸດ).
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ການຈັດປະເພດບໍ່ມີພຶດຕິ ກຳ ທີ່ມີຄວາມ ໝາຍ ກ່ຽວກັບປະເພດທີ່ມີຂະ ໜາດ ສູນ.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // ຈຳ ກັດ ຈຳ ນວນສ່ວນທີ່ບໍ່ສົມດຸນໃຫ້ແກ່ `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // ສໍາລັບຫຼັງຈາກນັ້ນນໍາຂອງເຖິງຄວາມຍາວນີ້ມັນອາດຈະເປັນໄວທີ່ຈະພຽງແຕ່ຄັດໃຫ້ເຂົາເຈົ້າ.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // ເລືອກເອົາ pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // ຖ້າຕົວຢ່າງທີ່ຖືກຄັດເລືອກແມ່ນເທົ່າກັບຜູ້ທີ່ມາກ່ອນ, ຫຼັງຈາກນັ້ນມັນກໍ່ແມ່ນອົງປະກອບທີ່ນ້ອຍທີ່ສຸດໃນກະດານ.
        // ແບ່ງສ່ວນເຂົ້າໄປໃນສ່ວນປະກອບເທົ່າກັບແລະສ່ວນປະກອບທີ່ໃຫຍ່ກວ່າຕົວຊີ້ວັດ.
        // ກໍລະນີນີ້ມັກຈະຖືກຕີເມື່ອຊິ້ນມີສ່ວນປະກອບທີ່ຊ້ ຳ ກັນຫຼາຍ.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // ຖ້າພວກເຮົາໄດ້ຜ່ານດັດຊະນີຂອງພວກເຮົາ, ແລ້ວພວກເຮົາກໍ່ດີ.
                if mid > index {
                    return;
                }

                // ຖ້າບໍ່ດັ່ງນັ້ນ, ສືບຕໍ່ຈັດຮຽງອົງປະກອບທີ່ໃຫຍ່ກວ່າຕົວຊີ້ວັດ.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // ແບ່ງສ່ວນເສດເປັນ `left`, `pivot`, ແລະ `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // ຖ້າກາງ==ດັດສະນີ, ຫຼັງຈາກນັ້ນພວກເຮົາໄດ້ເຮັດແລ້ວ, ເພາະວ່າ partition() ໄດ້ຮັບປະກັນວ່າທຸກໆອົງປະກອບພາຍຫຼັງກາງແມ່ນໃຫຍ່ກວ່າຫຼືເທົ່າກັບກາງ.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // ການຈັດປະເພດບໍ່ມີພຶດຕິ ກຳ ທີ່ມີຄວາມ ໝາຍ ກ່ຽວກັບປະເພດທີ່ມີຂະ ໜາດ ສູນ.ບໍ່ໄດ້ເຮັດຫຍັງ.
    } else if index == v.len() - 1 {
        // ຊອກຫາອົງປະກອບສູງສຸດແລະວາງມັນໄວ້ໃນ ຕຳ ແໜ່ງ ສຸດທ້າຍຂອງອາເລ.
        // ພວກເຮົາສາມາດໃຊ້ `unwrap()` ໄດ້ທີ່ນີ້ເພາະວ່າພວກເຮົາຮູ້ວ່າ v ບໍ່ຕ້ອງເປົ່າຫວ່າງ.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // ຊອກຫາອົງປະກອບ min ແລະວາງມັນໄວ້ໃນ ຕຳ ແໜ່ງ ທຳ ອິດຂອງອາເລ.
        // ພວກເຮົາສາມາດໃຊ້ `unwrap()` ໄດ້ທີ່ນີ້ເພາະວ່າພວກເຮົາຮູ້ວ່າ v ບໍ່ຕ້ອງເປົ່າຫວ່າງ.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}