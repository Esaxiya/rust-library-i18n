// ignore-tidy-filelength
//! ຄໍານິຍາມຂອງຊໍ່ສ່ວນປະກອບສໍາລັບ `[T]`.

#[macro_use] // ນໍາເຂົ້າ iterator!ແລະ forward_iterator!
mod macros;

use crate::cmp;
use crate::cmp::Ordering;
use crate::fmt;
use crate::intrinsics::{assume, exact_div, unchecked_sub};
use crate::iter::{FusedIterator, TrustedLen, TrustedRandomAccess};
use crate::marker::{PhantomData, Send, Sized, Sync};
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

use super::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a [T] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut [T] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

// ໜ້າ ທີ່ຜູ້ຊ່ວຍ Macro
#[inline(always)]
fn size_from_ptr<T>(_: *const T) -> usize {
    mem::size_of::<T>()
}

/// ເຄື່ອງຕັດຊິ້ນສ່ວນທີ່ບໍ່ສາມາດຕ້ານທານໄດ້
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`iter`] ໃນ [slices].
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// // ກ່ອນອື່ນ ໝົດ, ພວກເຮົາປະກາດປະເພດ ໜຶ່ງ ເຊິ່ງມີວິທີ `iter` ເພື່ອໃຫ້ໄດ້ `Iter` struct (`&[usize]` ທີ່ນີ້):
/// let slice = &[1, 2, 3];
///
/// // ຫຼັງຈາກນັ້ນ, ພວກເຮົາກະທົບກະເທືອນຕໍ່ມັນ:
/// for element in slice.iter() {
///     println!("{}", element);
/// }
/// ```
///
/// [`iter`]: slice::iter
/// [slices]: slice
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    ptr: NonNull<T>,
    end: *const T, // ຖ້າ T ແມ່ນ ZST, ນີ້ແມ່ນຕົວຈິງ ptr + len.ການເຂົ້າລະຫັດນີ້ຖືກເກັບເພື່ອວ່າ
    // ptr==end ແມ່ນການທົດສອບຢ່າງໄວວາ ສຳ ລັບ Iterator ວ່າງເປົ່າ, ເຊິ່ງໃຊ້ໄດ້ທັງ ZST ແລະ non-ZST.
    //
    _marker: PhantomData<&'a T>,
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

impl<'a, T> Iter<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a [T]) -> Self {
        let ptr = slice.as_ptr();
        // ຄວາມປອດໄພ: ຄ້າຍຄືກັບ `IterMut::new`.
        unsafe {
            assume(!ptr.is_null());

            let end = if mem::size_of::<T>() == 0 {
                (ptr as *const u8).wrapping_add(slice.len()) as *const T
            } else {
                ptr.add(slice.len())
            };

            Self { ptr: NonNull::new_unchecked(ptr as *mut T), end, _marker: PhantomData }
        }
    }

    /// ເບິ່ງຂໍ້ມູນທີ່ຕິດພັນເປັນຂໍ້ມູນຍ່ອຍຂອງຂໍ້ມູນຕົ້ນສະບັບ.
    ///
    /// ສິ່ງນີ້ມີອາຍຸການໃຊ້ຊີວິດດຽວກັນກັບຊິ້ນເດີມ, ແລະດັ່ງນັ້ນເຄື່ອງປັບສາມາດສືບຕໍ່ ນຳ ໃຊ້ໃນຂະນະທີ່ສິ່ງນີ້ມີຢູ່.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // ກ່ອນອື່ນ ໝົດ, ພວກເຮົາປະກາດປະເພດ ໜຶ່ງ ເຊິ່ງມີວິທີ `iter` ເພື່ອໃຫ້ໄດ້ `Iter` struct (`&[usize]` ທີ່ນີ້):
    /////
    /// let slice = &[1, 2, 3];
    ///
    /// // ຫຼັງຈາກນັ້ນ, ພວກເຮົາໄດ້ຮັບຕົວປ່ຽນແປງ:
    /// let mut iter = slice.iter();
    /// // ສະນັ້ນຖ້າພວກເຮົາພິມວິທີ `as_slice` ກັບມາທີ່ນີ້, ພວກເຮົາມີ "[1, 2, 3]":
    /// println!("{:?}", iter.as_slice());
    ///
    /// // ຕໍ່ໄປ, ພວກເຮົາຍ້າຍອອກໄປໃນອົງປະກອບທີສອງຂອງຫຼັງຈາກນັ້ນນໍາ:
    /// iter.next();
    /// // ດຽວນີ້ `as_slice` ກັບຄືນ "[2, 3]":
    /// println!("{:?}", iter.as_slice());
    /// ```
    #[stable(feature = "iter_to_slice", since = "1.4.0")]
    pub fn as_slice(&self) -> &'a [T] {
        self.make_slice()
    }
}

iterator! {struct Iter -> *const T, &'a T, const, {/* no mut */}, {
    fn is_sorted_by<F>(self, mut compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        self.as_slice().windows(2).all(|w| {
            compare(&&w[0], &&w[1]).map(|o| o != Ordering::Greater).unwrap_or(false)
        })
    }
}}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ptr: self.ptr, end: self.end, _marker: self._marker }
    }
}

#[stable(feature = "slice_iter_as_ref", since = "1.13.0")]
impl<T> AsRef<[T]> for Iter<'_, T> {
    fn as_ref(&self) -> &[T] {
        self.as_slice()
    }
}

/// ເຄື່ອງຕັດ ສຳ ລັບກະເພາະ.
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`iter_mut`] ໃນ [slices].
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// // ກ່ອນອື່ນ ໝົດ, ພວກເຮົາປະກາດປະເພດ ໜຶ່ງ ເຊິ່ງມີວິທີ `iter_mut` ເພື່ອໃຫ້ໄດ້ `IterMut` struct (`&[usize]` ທີ່ນີ້):
/////
/// let mut slice = &mut [1, 2, 3];
///
/// // ຫຼັງຈາກນັ້ນ, ພວກເຮົາປ່ຽນແປງມັນແລະເພີ່ມມູນຄ່າຂອງແຕ່ລະສ່ວນປະກອບ:
/// for element in slice.iter_mut() {
///     *element += 1;
/// }
///
/// // ດຽວນີ້ພວກເຮົາມີ "[2, 3, 4]":
/// println!("{:?}", slice);
/// ```
///
/// [`iter_mut`]: slice::iter_mut
/// [slices]: slice
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    ptr: NonNull<T>,
    end: *mut T, // ຖ້າ T ແມ່ນ ZST, ນີ້ແມ່ນຕົວຈິງ ptr + len.ການເຂົ້າລະຫັດນີ້ຖືກເກັບເພື່ອວ່າ
    // ptr==end ແມ່ນການທົດສອບຢ່າງໄວວາ ສຳ ລັບ Iterator ວ່າງເປົ່າ, ເຊິ່ງໃຊ້ໄດ້ທັງ ZST ແລະ non-ZST.
    //
    _marker: PhantomData<&'a mut T>,
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.make_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

impl<'a, T> IterMut<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T]) -> Self {
        let ptr = slice.as_mut_ptr();
        // ຄວາມປອດໄພ: ມີຫລາຍສິ່ງຫລາຍຢ່າງຢູ່ທີ່ນີ້:
        //
        // `ptr` ໄດ້ຮັບໂດຍ `slice.as_ptr()` ບ່ອນທີ່ `slice` ແມ່ນເອກະສານອ້າງອີງທີ່ຖືກຕ້ອງດັ່ງນັ້ນມັນບໍ່ແມ່ນ NUL ແລະປອດໄພທີ່ຈະໃຊ້ແລະຜ່ານໄປ `NonNull::new_unchecked`.
        //
        //
        // ການເພີ່ມ `slice.len()` ໃສ່ຕົວເລີ່ມຕົ້ນເຮັດໃຫ້ຕົວຊີ້ຢູ່ປາຍ `slice`.
        // `end` ຈະບໍ່ໄດ້ຮັບການ dereferenced, ພຽງແຕ່ກວດກາສໍາລັບຄວາມສະເຫມີພາບຊີ້ກົງກັບ `ptr` ເພື່ອກວດສອບວ່າ iterator ໄດ້ຖືກເຮັດ.
        //
        // ໃນກໍລະນີຂອງ ZST, ຕົວຊີ້ປາຍສຸດທ້າຍແມ່ນພຽງແຕ່ຕົວຊີ້ເລີ່ມຕົ້ນບວກກັບຄວາມຍາວ, ເພື່ອໃຫ້ຍັງສາມາດກວດສອບ `ptr == end` ໄດ້ໄວ.
        //
        // ເບິ່ງແມັກ `next_unchecked!` ແລະ `is_empty!` ພ້ອມທັງວິທີ `post_inc_start` ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ.
        //
        //
        //
        //
        //
        unsafe {
            assume(!ptr.is_null());

            let end = if mem::size_of::<T>() == 0 {
                (ptr as *mut u8).wrapping_add(slice.len()) as *mut T
            } else {
                ptr.add(slice.len())
            };

            Self { ptr: NonNull::new_unchecked(ptr), end, _marker: PhantomData }
        }
    }

    /// ເບິ່ງຂໍ້ມູນທີ່ຕິດພັນເປັນຂໍ້ມູນຍ່ອຍຂອງຂໍ້ມູນຕົ້ນສະບັບ.
    ///
    /// ເພື່ອຫລີກລ້ຽງການສ້າງເອກະສານອ້າງອີງ `&mut` ທີ່ມີນາມແຝງ, ສິ່ງນີ້ຖືກບັງຄັບໃຫ້ບໍລິໂພກຕົວປ່ຽນແປງ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // ກ່ອນອື່ນ ໝົດ, ພວກເຮົາປະກາດປະເພດ ໜຶ່ງ ເຊິ່ງມີວິທີ `iter_mut` ເພື່ອໃຫ້ໄດ້ `IterMut` struct (`&[usize]` ທີ່ນີ້):
    /////
    /// let mut slice = &mut [1, 2, 3];
    ///
    /// {
    ///     // ຫຼັງຈາກນັ້ນ, ພວກເຮົາໄດ້ຮັບຕົວປ່ຽນແປງ:
    ///     let mut iter = slice.iter_mut();
    ///     // ພວກເຮົາຍ້າຍໄປຫາອົງປະກອບຕໍ່ໄປ:
    ///     iter.next();
    ///     // ສະນັ້ນຖ້າພວກເຮົາພິມວິທີ `into_slice` ກັບມາທີ່ນີ້, ພວກເຮົາມີ "[2, 3]":
    ///     println!("{:?}", iter.into_slice());
    /// }
    ///
    /// // ໃນປັດຈຸບັນໃຫ້ຂອງການປັບປຸງແກ້ໄຂຄຸນຄ່າຂອງການຫຼັງຈາກນັ້ນນໍາ:
    /// {
    ///     // ຫນ້າທໍາອິດທີ່ພວກເຮົາໄດ້ຮັບກັບຄືນໄປບ່ອນ iterator ໄດ້:
    ///     let mut iter = slice.iter_mut();
    ///     // ພວກເຮົາປ່ຽນຄຸນຄ່າຂອງສ່ວນປະກອບ ທຳ ອິດຂອງທ່ອນທີ່ສົ່ງກັບຄືນໂດຍວິທີ `next`:
    ///     *iter.next().unwrap() += 1;
    /// }
    /// // ດຽວນີ້ແມ່ນ "[2, 2, 3]":
    /// println!("{:?}", slice);
    /// ```
    #[stable(feature = "iter_to_slice", since = "1.4.0")]
    pub fn into_slice(self) -> &'a mut [T] {
        // ຄວາມປອດໄພ: ຕົວລະບາຍອາກາດໄດ້ຖືກສ້າງຂື້ນຈາກສ່ວນທີ່ສາມາດປ່ຽນແປງໄດ້ດ້ວຍຕົວຊີ້
        // `self.ptr` ແລະຄວາມຍາວ `len!(self)`.
        // ນີ້ຮັບປະກັນວ່າທຸກເງື່ອນໄຂທີ່ຕ້ອງການ ສຳ ລັບ `from_raw_parts_mut` ແມ່ນ ສຳ ເລັດ.
        unsafe { from_raw_parts_mut(self.ptr.as_ptr(), len!(self)) }
    }

    /// ເບິ່ງຂໍ້ມູນທີ່ຕິດພັນເປັນຂໍ້ມູນຍ່ອຍຂອງຂໍ້ມູນຕົ້ນສະບັບ.
    ///
    /// ເພື່ອຫລີກລ້ຽງການສ້າງເອກະສານອ້າງອີງ `&mut [T]` ທີ່ມີນາມແຝງ, ຊິ້ນສ່ວນທີ່ກັບມາເຮັດໃຫ້ຊີວິດຂອງມັນຈາກຕົວປ່ຽນແປງວິທີການດັ່ງກ່າວຖືກ ນຳ ໃຊ້.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// # #![feature(slice_iter_mut_as_slice)]
    /// let mut slice: &mut [usize] = &mut [1, 2, 3];
    ///
    /// // ຫນ້າທໍາອິດ, ພວກເຮົາໄດ້ຮັບ iterator ໄດ້:
    /// let mut iter = slice.iter_mut();
    /// // ສະນັ້ນຖ້າພວກເຮົາກວດເບິ່ງວ່າວິທີ `as_slice` ຈະກັບຄືນມາບ່ອນໃດ, ພວກເຮົາມີ "[1, 2, 3]":
    /// assert_eq!(iter.as_slice(), &[1, 2, 3]);
    ///
    /// // ຕໍ່ໄປ, ພວກເຮົາຍ້າຍອອກໄປໃນອົງປະກອບທີສອງຂອງຫຼັງຈາກນັ້ນນໍາ:
    /// iter.next();
    /// // ດຽວນີ້ `as_slice` ກັບຄືນ "[2, 3]":
    /// assert_eq!(iter.as_slice(), &[2, 3]);
    /// ```
    #[unstable(feature = "slice_iter_mut_as_slice", reason = "recently added", issue = "58957")]
    pub fn as_slice(&self) -> &[T] {
        self.make_slice()
    }
}

iterator! {struct IterMut -> *mut T, &'a mut T, mut, {mut}, {}}

/// ການບໍ່ເອົາໃຈໃສ່ພາຍໃນກ່ຽວກັບຕົວແຍກທີ່ແຕກແຍກ, ດັ່ງນັ້ນການແບ່ງປັນ, ແຍກແລະອື່ນໆສາມາດປະຕິບັດໄດ້ ໜຶ່ງ ຄັ້ງ.
///
#[doc(hidden)]
pub(super) trait SplitIter: DoubleEndedIterator {
    /// ໝາຍ ເຄື່ອງເຈາະພື້ນທີ່ໃຫ້ແລ້ວສົມບູນ, ສະກັດສ່ວນທີ່ເຫຼືອຂອງສ່ວນທີ່ເຫຼືອ.
    ///
    fn finish(&mut self) -> Option<Self::Item>;
}

/// ຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍຍ່ອຍທີ່ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບການ ທຳ ງານຂອງການຄາດຄະເນ.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`split`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let slice = [10, 40, 33, 20];
/// let mut iter = slice.split(|num| num % 3 == 0);
/// ```
///
/// [`split`]: slice::split
/// [slices]: slice
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Split<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    // ນໍາໃຊ້ສໍາລັບ `SplitWhitespace` ແລະ `SplitAsciiWhitespace` `as_str` ວິທີການ
    pub(crate) v: &'a [T],
    pred: P,
    // ໃຊ້ ສຳ ລັບວິທີການ `SplitAsciiWhitespace` `as_str`
    pub(crate) finished: bool,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> Split<'a, T, P> {
    #[inline]
    pub(super) fn new(slice: &'a [T], pred: P) -> Self {
        Self { v: slice, pred, finished: false }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug, P> fmt::Debug for Split<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Split").field("v", &self.v).field("finished", &self.finished).finish()
    }
}

// FIXME(#26925) ເອົາອອກໃນເງື່ອນໄຂຂອງ `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, P> Clone for Split<'_, T, P>
where
    P: Clone + FnMut(&T) -> bool,
{
    fn clone(&self) -> Self {
        Split { v: self.v, pred: self.pred.clone(), finished: self.finished }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, P> Iterator for Split<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.finished {
            return None;
        }

        match self.v.iter().position(|x| (self.pred)(x)) {
            None => self.finish(),
            Some(idx) => {
                let ret = Some(&self.v[..idx]);
                self.v = &self.v[idx + 1..];
                ret
            }
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.finished { (0, Some(0)) } else { (1, Some(self.v.len() + 1)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, P> DoubleEndedIterator for Split<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.finished {
            return None;
        }

        match self.v.iter().rposition(|x| (self.pred)(x)) {
            None => self.finish(),
            Some(idx) => {
                let ret = Some(&self.v[idx + 1..]);
                self.v = &self.v[..idx];
                ret
            }
        }
    }
}

impl<'a, T, P> SplitIter for Split<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn finish(&mut self) -> Option<&'a [T]> {
        if self.finished {
            None
        } else {
            self.finished = true;
            Some(self.v)
        }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T, P> FusedIterator for Split<'_, T, P> where P: FnMut(&T) -> bool {}

/// ຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍຍ່ອຍທີ່ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບການ ທຳ ງານຂອງການຄາດຄະເນ.
/// ບໍ່ຄືກັບ `Split`, ມັນປະກອບດ້ວຍພາກສ່ວນທີ່ຖືກຈັບຄູ່ເປັນ ຄຳ ທ້າຍຂອງການຍ່ອຍ.
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`split_inclusive`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let slice = [10, 40, 33, 20];
/// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
/// ```
///
/// [`split_inclusive`]: slice::split_inclusive
/// [slices]: slice
///
#[stable(feature = "split_inclusive", since = "1.51.0")]
pub struct SplitInclusive<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    v: &'a [T],
    pred: P,
    finished: bool,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> SplitInclusive<'a, T, P> {
    #[inline]
    pub(super) fn new(slice: &'a [T], pred: P) -> Self {
        Self { v: slice, pred, finished: false }
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<T: fmt::Debug, P> fmt::Debug for SplitInclusive<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SplitInclusive")
            .field("v", &self.v)
            .field("finished", &self.finished)
            .finish()
    }
}

// FIXME(#26925) ເອົາອອກໃນເງື່ອນໄຂຂອງ `#[derive(Clone)]`
#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<T, P> Clone for SplitInclusive<'_, T, P>
where
    P: Clone + FnMut(&T) -> bool,
{
    fn clone(&self) -> Self {
        SplitInclusive { v: self.v, pred: self.pred.clone(), finished: self.finished }
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<'a, T, P> Iterator for SplitInclusive<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.finished {
            return None;
        }

        let idx =
            self.v.iter().position(|x| (self.pred)(x)).map(|idx| idx + 1).unwrap_or(self.v.len());
        if idx == self.v.len() {
            self.finished = true;
        }
        let ret = Some(&self.v[..idx]);
        self.v = &self.v[idx..];
        ret
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.finished { (0, Some(0)) } else { (1, Some(self.v.len() + 1)) }
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<'a, T, P> DoubleEndedIterator for SplitInclusive<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.finished {
            return None;
        }

        // ດັດສະນີສຸດທ້າຍຂອງ self.v ແມ່ນການກວດສອບແລ້ວແລະພົບວ່າກົງກັບການອອກສຽງຄັ້ງສຸດທ້າຍ, ດັ່ງນັ້ນພວກເຮົາເລີ່ມຄົ້ນຫາດັດສະນີ ໃໝ່ ໜຶ່ງ ຫາຢູ່ເບື້ອງຊ້າຍ.
        //
        //
        let remainder = if self.v.is_empty() { &[] } else { &self.v[..(self.v.len() - 1)] };
        let idx = remainder.iter().rposition(|x| (self.pred)(x)).map(|idx| idx + 1).unwrap_or(0);
        if idx == 0 {
            self.finished = true;
        }
        let ret = Some(&self.v[idx..]);
        self.v = &self.v[..idx];
        ret
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<T, P> FusedIterator for SplitInclusive<'_, T, P> where P: FnMut(&T) -> bool {}

/// ຕົວແກ້ໄຂໃນໄລຍະການຍ່ອຍຂອງ vector ເຊິ່ງແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບ `pred`.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`split_mut`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let mut v = [10, 40, 30, 20, 60, 50];
/// let iter = v.split_mut(|num| *num % 3 == 0);
/// ```
///
/// [`split_mut`]: slice::split_mut
/// [slices]: slice
#[stable(feature = "rust1", since = "1.0.0")]
pub struct SplitMut<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    v: &'a mut [T],
    pred: P,
    finished: bool,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> SplitMut<'a, T, P> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], pred: P) -> Self {
        Self { v: slice, pred, finished: false }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug, P> fmt::Debug for SplitMut<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SplitMut").field("v", &self.v).field("finished", &self.finished).finish()
    }
}

impl<'a, T, P> SplitIter for SplitMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn finish(&mut self) -> Option<&'a mut [T]> {
        if self.finished {
            None
        } else {
            self.finished = true;
            Some(mem::replace(&mut self.v, &mut []))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, P> Iterator for SplitMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        if self.finished {
            return None;
        }

        let idx_opt = {
            // ເຮັດວຽກຮອບດ້ານຂໍ້ ຈຳ ກັດດ້ານການຢືມ
            let pred = &mut self.pred;
            self.v.iter().position(|x| (*pred)(x))
        };
        match idx_opt {
            None => self.finish(),
            Some(idx) => {
                let tmp = mem::replace(&mut self.v, &mut []);
                let (head, tail) = tmp.split_at_mut(idx);
                self.v = &mut tail[1..];
                Some(head)
            }
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.finished {
            (0, Some(0))
        } else {
            // ຖ້າຫາກວ່າ predicate ບໍ່ກົງກັນກັບສິ່ງໃດ, ພວກເຮົາໃຫ້ຜົນຜະລິດດຽວຖ້າມັນກົງກັບທຸກໆອົງປະກອບ, ພວກເຮົາຈະໃຫ້ຜົນຜະລິດທີ່ບໍ່ມີ + 1 ຊິ້ນ.
            //
            (1, Some(self.v.len() + 1))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, P> DoubleEndedIterator for SplitMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        if self.finished {
            return None;
        }

        let idx_opt = {
            // ເຮັດວຽກຮອບດ້ານຂໍ້ ຈຳ ກັດດ້ານການຢືມ
            let pred = &mut self.pred;
            self.v.iter().rposition(|x| (*pred)(x))
        };
        match idx_opt {
            None => self.finish(),
            Some(idx) => {
                let tmp = mem::replace(&mut self.v, &mut []);
                let (head, tail) = tmp.split_at_mut(idx);
                self.v = head;
                Some(&mut tail[1..])
            }
        }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T, P> FusedIterator for SplitMut<'_, T, P> where P: FnMut(&T) -> bool {}

/// ຕົວແກ້ໄຂໃນໄລຍະການຍ່ອຍຂອງ vector ເຊິ່ງແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບ `pred`.
/// ບໍ່ຄືກັບ `SplitMut`, ມັນມີສ່ວນທີ່ຖືກຈັບຢູ່ໃນຕອນສຸດທ້າຍຂອງການຍ່ອຍ.
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`split_inclusive_mut`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let mut v = [10, 40, 30, 20, 60, 50];
/// let iter = v.split_inclusive_mut(|num| *num % 3 == 0);
/// ```
///
/// [`split_inclusive_mut`]: slice::split_inclusive_mut
/// [slices]: slice
///
#[stable(feature = "split_inclusive", since = "1.51.0")]
pub struct SplitInclusiveMut<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    v: &'a mut [T],
    pred: P,
    finished: bool,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> SplitInclusiveMut<'a, T, P> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], pred: P) -> Self {
        Self { v: slice, pred, finished: false }
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<T: fmt::Debug, P> fmt::Debug for SplitInclusiveMut<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SplitInclusiveMut")
            .field("v", &self.v)
            .field("finished", &self.finished)
            .finish()
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<'a, T, P> Iterator for SplitInclusiveMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        if self.finished {
            return None;
        }

        let idx_opt = {
            // ເຮັດວຽກຮອບດ້ານຂໍ້ ຈຳ ກັດດ້ານການຢືມ
            let pred = &mut self.pred;
            self.v.iter().position(|x| (*pred)(x))
        };
        let idx = idx_opt.map(|idx| idx + 1).unwrap_or(self.v.len());
        if idx == self.v.len() {
            self.finished = true;
        }
        let tmp = mem::replace(&mut self.v, &mut []);
        let (head, tail) = tmp.split_at_mut(idx);
        self.v = tail;
        Some(head)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.finished {
            (0, Some(0))
        } else {
            // ຖ້າຫາກວ່າ predicate ບໍ່ກົງກັນກັບສິ່ງໃດ, ພວກເຮົາໃຫ້ຜົນຜະລິດດຽວຖ້າມັນກົງກັບທຸກໆອົງປະກອບ, ພວກເຮົາຈະໃຫ້ຜົນຜະລິດທີ່ບໍ່ມີ + 1 ຊິ້ນ.
            //
            (1, Some(self.v.len() + 1))
        }
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<'a, T, P> DoubleEndedIterator for SplitInclusiveMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        if self.finished {
            return None;
        }

        let idx_opt = if self.v.is_empty() {
            None
        } else {
            // ເຮັດວຽກຮອບດ້ານຂໍ້ ຈຳ ກັດດ້ານການຢືມ
            let pred = &mut self.pred;

            // ດັດສະນີສຸດທ້າຍຂອງ self.v ແມ່ນການກວດສອບແລ້ວແລະພົບວ່າກົງກັບການອອກສຽງຄັ້ງສຸດທ້າຍ, ດັ່ງນັ້ນພວກເຮົາເລີ່ມຄົ້ນຫາດັດສະນີ ໃໝ່ ໜຶ່ງ ຫາຢູ່ເບື້ອງຊ້າຍ.
            //
            //
            let remainder = &self.v[..(self.v.len() - 1)];
            remainder.iter().rposition(|x| (*pred)(x))
        };
        let idx = idx_opt.map(|idx| idx + 1).unwrap_or(0);
        if idx == 0 {
            self.finished = true;
        }
        let tmp = mem::replace(&mut self.v, &mut []);
        let (head, tail) = tmp.split_at_mut(idx);
        self.v = head;
        Some(tail)
    }
}

#[stable(feature = "split_inclusive", since = "1.51.0")]
impl<T, P> FusedIterator for SplitInclusiveMut<'_, T, P> where P: FnMut(&T) -> bool {}

/// ຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍຍ່ອຍທີ່ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບການ ທຳ ງານທີ່ຄາດຄະເນ, ເຊິ່ງເລີ່ມຕົ້ນຈາກສິ້ນສຸດຂອງສິ້ນ.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`rsplit`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let slice = [11, 22, 33, 0, 44, 55];
/// let iter = slice.rsplit(|num| *num == 0);
/// ```
///
/// [`rsplit`]: slice::rsplit
/// [slices]: slice
#[stable(feature = "slice_rsplit", since = "1.27.0")]
#[derive(Clone)] // ນີ້ແມ່ນຖືກຕ້ອງ, ຫຼືມັນບໍ່ຖືກຕ້ອງມີ `T: Clone` ບໍ?
pub struct RSplit<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    inner: Split<'a, T, P>,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> RSplit<'a, T, P> {
    #[inline]
    pub(super) fn new(slice: &'a [T], pred: P) -> Self {
        Self { inner: Split::new(slice, pred) }
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<T: fmt::Debug, P> fmt::Debug for RSplit<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RSplit")
            .field("v", &self.inner.v)
            .field("finished", &self.inner.finished)
            .finish()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<'a, T, P> Iterator for RSplit<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        self.inner.next_back()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<'a, T, P> DoubleEndedIterator for RSplit<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        self.inner.next()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<'a, T, P> SplitIter for RSplit<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn finish(&mut self) -> Option<&'a [T]> {
        self.inner.finish()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<T, P> FusedIterator for RSplit<'_, T, P> where P: FnMut(&T) -> bool {}

/// ເຄື່ອງປັບປະສິດທິພາບໃນລະດັບຍ່ອຍຂອງ vector ເຊິ່ງແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບ `pred`, ເລີ່ມຕົ້ນຈາກສິ້ນສຸດຂອງສ່ວນທີ່ເຫຼືອ.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`rsplit_mut`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let mut slice = [11, 22, 33, 0, 44, 55];
/// let iter = slice.rsplit_mut(|num| *num == 0);
/// ```
///
/// [`rsplit_mut`]: slice::rsplit_mut
/// [slices]: slice
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub struct RSplitMut<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    inner: SplitMut<'a, T, P>,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> RSplitMut<'a, T, P> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], pred: P) -> Self {
        Self { inner: SplitMut::new(slice, pred) }
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<T: fmt::Debug, P> fmt::Debug for RSplitMut<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RSplitMut")
            .field("v", &self.inner.v)
            .field("finished", &self.inner.finished)
            .finish()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<'a, T, P> SplitIter for RSplitMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn finish(&mut self) -> Option<&'a mut [T]> {
        self.inner.finish()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<'a, T, P> Iterator for RSplitMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        self.inner.next_back()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<'a, T, P> DoubleEndedIterator for RSplitMut<'a, T, P>
where
    P: FnMut(&T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        self.inner.next()
    }
}

#[stable(feature = "slice_rsplit", since = "1.27.0")]
impl<T, P> FusedIterator for RSplitMut<'_, T, P> where P: FnMut(&T) -> bool {}

/// ເຄື່ອງປັບສຽງສ່ວນຕົວໃນໄລຍະການຍ່ອຍຕ່າງໆທີ່ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບການ ທຳ ງານຂອງການຄາດເດົາ, ການແບ່ງປັນສ່ວນໃຫຍ່ຂອງ ຈຳ ນວນເວລາ.
///
///
#[derive(Debug)]
struct GenericSplitN<I> {
    iter: I,
    count: usize,
}

impl<T, I: SplitIter<Item = T>> Iterator for GenericSplitN<I> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        match self.count {
            0 => None,
            1 => {
                self.count -= 1;
                self.iter.finish()
            }
            _ => {
                self.count -= 1;
                self.iter.next()
            }
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let (lower, upper_opt) = self.iter.size_hint();
        (lower, upper_opt.map(|upper| cmp::min(self.count, upper)))
    }
}

/// ຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍຍ່ອຍແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບການ ທຳ ງານທີ່ຄາດຄະເນ, ຈຳ ກັດ ຈຳ ນວນຂອງການແບ່ງປັນ.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`splitn`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let slice = [10, 40, 30, 20, 60, 50];
/// let iter = slice.splitn(2, |num| *num % 3 == 0);
/// ```
///
/// [`splitn`]: slice::splitn
/// [slices]: slice
#[stable(feature = "rust1", since = "1.0.0")]
pub struct SplitN<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    inner: GenericSplitN<Split<'a, T, P>>,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> SplitN<'a, T, P> {
    #[inline]
    pub(super) fn new(s: Split<'a, T, P>, n: usize) -> Self {
        Self { inner: GenericSplitN { iter: s, count: n } }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug, P> fmt::Debug for SplitN<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SplitN").field("inner", &self.inner).finish()
    }
}

/// ຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍຍ່ອຍທີ່ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບການ ທຳ ງານທີ່ຄາດຄະເນ, ຈຳ ກັດ ຈຳ ນວນຂອງການແບ່ງປັນເຊິ່ງເລີ່ມຕົ້ນຈາກສິ້ນສຸດຂອງສ່ວນທີ່ເຫຼືອ.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`rsplitn`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let slice = [10, 40, 30, 20, 60, 50];
/// let iter = slice.rsplitn(2, |num| *num % 3 == 0);
/// ```
///
/// [`rsplitn`]: slice::rsplitn
/// [slices]: slice
///
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RSplitN<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    inner: GenericSplitN<RSplit<'a, T, P>>,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> RSplitN<'a, T, P> {
    #[inline]
    pub(super) fn new(s: RSplit<'a, T, P>, n: usize) -> Self {
        Self { inner: GenericSplitN { iter: s, count: n } }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug, P> fmt::Debug for RSplitN<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RSplitN").field("inner", &self.inner).finish()
    }
}

/// ຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍຍ່ອຍແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບການ ທຳ ງານທີ່ຄາດຄະເນ, ຈຳ ກັດ ຈຳ ນວນຂອງການແບ່ງປັນ.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`splitn_mut`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let mut slice = [10, 40, 30, 20, 60, 50];
/// let iter = slice.splitn_mut(2, |num| *num % 3 == 0);
/// ```
///
/// [`splitn_mut`]: slice::splitn_mut
/// [slices]: slice
#[stable(feature = "rust1", since = "1.0.0")]
pub struct SplitNMut<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    inner: GenericSplitN<SplitMut<'a, T, P>>,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> SplitNMut<'a, T, P> {
    #[inline]
    pub(super) fn new(s: SplitMut<'a, T, P>, n: usize) -> Self {
        Self { inner: GenericSplitN { iter: s, count: n } }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug, P> fmt::Debug for SplitNMut<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SplitNMut").field("inner", &self.inner).finish()
    }
}

/// ຕົວປ່ຽນແປງໃນໄລຍະຍ່ອຍຍ່ອຍທີ່ແຍກອອກໂດຍສ່ວນປະກອບທີ່ກົງກັບການ ທຳ ງານທີ່ຄາດຄະເນ, ຈຳ ກັດ ຈຳ ນວນຂອງການແບ່ງປັນເຊິ່ງເລີ່ມຕົ້ນຈາກສິ້ນສຸດຂອງສ່ວນທີ່ເຫຼືອ.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`rsplitn_mut`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let mut slice = [10, 40, 30, 20, 60, 50];
/// let iter = slice.rsplitn_mut(2, |num| *num % 3 == 0);
/// ```
///
/// [`rsplitn_mut`]: slice::rsplitn_mut
/// [slices]: slice
///
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RSplitNMut<'a, T: 'a, P>
where
    P: FnMut(&T) -> bool,
{
    inner: GenericSplitN<RSplitMut<'a, T, P>>,
}

impl<'a, T: 'a, P: FnMut(&T) -> bool> RSplitNMut<'a, T, P> {
    #[inline]
    pub(super) fn new(s: RSplitMut<'a, T, P>, n: usize) -> Self {
        Self { inner: GenericSplitN { iter: s, count: n } }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: fmt::Debug, P> fmt::Debug for RSplitNMut<'_, T, P>
where
    P: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RSplitNMut").field("inner", &self.inner).finish()
    }
}

forward_iterator! { SplitN: T, &'a [T] }
forward_iterator! { RSplitN: T, &'a [T] }
forward_iterator! { SplitNMut: T, &'a mut [T] }
forward_iterator! { RSplitNMut: T, &'a mut [T] }

/// ເຄື່ອງປັບປະສິດທິພາບໃນໄລຍະ `size` ທີ່ຊ້ອນກັນ.
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`windows`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let slice = ['r', 'u', 's', 't'];
/// let iter = slice.windows(2);
/// ```
///
/// [`windows`]: slice::windows
/// [slices]: slice
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Windows<'a, T: 'a> {
    v: &'a [T],
    size: NonZeroUsize,
}

impl<'a, T: 'a> Windows<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a [T], size: NonZeroUsize) -> Self {
        Self { v: slice, size }
    }
}

// FIXME(#26925) ເອົາອອກໃນເງື່ອນໄຂຂອງ `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Windows<'_, T> {
    fn clone(&self) -> Self {
        Windows { v: self.v, size: self.size }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Windows<'a, T> {
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.size.get() > self.v.len() {
            None
        } else {
            let ret = Some(&self.v[..self.size.get()]);
            self.v = &self.v[1..];
            ret
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.size.get() > self.v.len() {
            (0, Some(0))
        } else {
            let size = self.v.len() - self.size.get() + 1;
            (size, Some(size))
        }
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let (end, overflow) = self.size.get().overflowing_add(n);
        if end > self.v.len() || overflow {
            self.v = &[];
            None
        } else {
            let nth = &self.v[n..end];
            self.v = &self.v[n + 1..];
            Some(nth)
        }
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        if self.size.get() > self.v.len() {
            None
        } else {
            let start = self.v.len() - self.size.get();
            Some(&self.v[start..])
        }
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        // ປອດໄພ: ຍ້ອນຜູ້ໂທຮັບປະກັນວ່າ `i` ຢູ່ໃນຂອບເຂດ,
        // ຊຶ່ງ ໝາຍ ຄວາມວ່າ `i` ບໍ່ສາມາດລົ້ນ `isize` ໄດ້, ແລະສ່ວນທີ່ສ້າງຂື້ນໂດຍ `from_raw_parts` ແມ່ນ ຄຳ ສັ່ງຍ່ອຍຂອງ `self.v` ດັ່ງນັ້ນຈຶ່ງຮັບປະກັນວ່າມັນຖືກຕ້ອງ ສຳ ລັບ `'a` ຕະຫຼອດຊີວິດຂອງ `self.v`.
        //
        //
        unsafe { from_raw_parts(self.v.as_ptr().add(idx), self.size.get()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Windows<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.size.get() > self.v.len() {
            None
        } else {
            let ret = Some(&self.v[self.v.len() - self.size.get()..]);
            self.v = &self.v[..self.v.len() - 1];
            ret
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let (end, overflow) = self.v.len().overflowing_sub(n);
        if end < self.size.get() || overflow {
            self.v = &[];
            None
        } else {
            let ret = &self.v[end - self.size.get()..end];
            self.v = &self.v[..end - 1];
            Some(ret)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Windows<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Windows<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Windows<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for Windows<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ເຄື່ອງປັ່ນປ່ວນໃນຊິ້ນສ່ວນ (non-overlapping) (ສ່ວນປະກອບ `chunk_size` ໃນແຕ່ລະຄັ້ງ), ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
///
///
/// ໃນເວລາທີ່ເສັ້ນລ້ອນຈະບໍ່ຖືກແບ່ງເປັນຂະ ໜາດ ເທົ່າກັນ, ຂະ ໜາດ ຊິ້ນສຸດທ້າຍຂອງການຊັ່ງຊາຈະເປັນສ່ວນທີ່ເຫຼືອ.
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`chunks`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.chunks(2);
/// ```
///
/// [`chunks`]: slice::chunks
/// [slices]: slice
///
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Chunks<'a, T: 'a> {
    v: &'a [T],
    chunk_size: usize,
}

impl<'a, T: 'a> Chunks<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a [T], size: usize) -> Self {
        Self { v: slice, chunk_size: size }
    }
}

// FIXME(#26925) ເອົາອອກໃນເງື່ອນໄຂຂອງ `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Chunks<'_, T> {
    fn clone(&self) -> Self {
        Chunks { v: self.v, chunk_size: self.chunk_size }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Chunks<'a, T> {
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.v.is_empty() {
            None
        } else {
            let chunksz = cmp::min(self.v.len(), self.chunk_size);
            let (fst, snd) = self.v.split_at(chunksz);
            self.v = snd;
            Some(fst)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.v.is_empty() {
            (0, Some(0))
        } else {
            let n = self.v.len() / self.chunk_size;
            let rem = self.v.len() % self.chunk_size;
            let n = if rem > 0 { n + 1 } else { n };
            (n, Some(n))
        }
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let (start, overflow) = n.overflowing_mul(self.chunk_size);
        if start >= self.v.len() || overflow {
            self.v = &[];
            None
        } else {
            let end = match start.checked_add(self.chunk_size) {
                Some(sum) => cmp::min(self.v.len(), sum),
                None => self.v.len(),
            };
            let nth = &self.v[start..end];
            self.v = &self.v[end..];
            Some(nth)
        }
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        if self.v.is_empty() {
            None
        } else {
            let start = (self.v.len() - 1) / self.chunk_size * self.chunk_size;
            Some(&self.v[start..])
        }
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let start = idx * self.chunk_size;
        let end = match start.checked_add(self.chunk_size) {
            None => self.v.len(),
            Some(end) => cmp::min(end, self.v.len()),
        };
        // ຄວາມປອດໄພ: ຜູ້ໂທຮັບປະກັນວ່າ `i` ຢູ່ໃນຂອບເຂດ,
        // ຊຶ່ງຫມາຍຄວາມວ່າ `start` ຕ້ອງຢູ່ໃນຂອບຂອງ `self.v` ທີ່ຕິດພັນ, ແລະພວກເຮົາໃຫ້ແນ່ໃຈວ່າ `end` ແມ່ນຍັງຢູ່ໃນຂອບ `self.v` X.
        // ດັ່ງນັ້ນ, `start` ບໍ່ສາມາດລົ້ນ `isize` ໄດ້, ແລະສ່ວນທີ່ສ້າງໂດຍ `from_raw_parts` ແມ່ນ Xl4X ທີ່ຍ່ອຍເຊິ່ງຮັບປະກັນໃຫ້ຖືກຕ້ອງ ສຳ ລັບ `'a` ຕະຫຼອດຊີວິດຂອງ `self.v`.
        //
        //
        //
        //
        unsafe { from_raw_parts(self.v.as_ptr().add(start), end - start) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Chunks<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.v.is_empty() {
            None
        } else {
            let remainder = self.v.len() % self.chunk_size;
            let chunksz = if remainder != 0 { remainder } else { self.chunk_size };
            let (fst, snd) = self.v.split_at(self.v.len() - chunksz);
            self.v = fst;
            Some(snd)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &[];
            None
        } else {
            let start = (len - 1 - n) * self.chunk_size;
            let end = match start.checked_add(self.chunk_size) {
                Some(res) => cmp::min(res, self.v.len()),
                None => self.v.len(),
            };
            let nth_back = &self.v[start..end];
            self.v = &self.v[..start];
            Some(nth_back)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Chunks<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Chunks<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Chunks<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for Chunks<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ເຄື່ອງປັ່ນປ່ວນໃນຊິ້ນສ່ວນຕ່າງໆໃນ (non-overlapping) chunks ທີ່ສາມາດປ່ຽນແປງໄດ້ (ອົງປະກອບ `chunk_size` ໃນເວລາດຽວກັນ), ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
///
///
/// ໃນເວລາທີ່ເສັ້ນລ້ອນຈະບໍ່ຖືກແບ່ງເປັນຂະ ໜາດ ເທົ່າກັນ, ຂະ ໜາດ ຊິ້ນສຸດທ້າຍຂອງການຊັ່ງຊາຈະເປັນສ່ວນທີ່ເຫຼືອ.
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`chunks_mut`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let mut slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.chunks_mut(2);
/// ```
///
/// [`chunks_mut`]: slice::chunks_mut
/// [slices]: slice
///
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ChunksMut<'a, T: 'a> {
    v: &'a mut [T],
    chunk_size: usize,
}

impl<'a, T: 'a> ChunksMut<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], size: usize) -> Self {
        Self { v: slice, chunk_size: size }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for ChunksMut<'a, T> {
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        if self.v.is_empty() {
            None
        } else {
            let sz = cmp::min(self.v.len(), self.chunk_size);
            let tmp = mem::replace(&mut self.v, &mut []);
            let (head, tail) = tmp.split_at_mut(sz);
            self.v = tail;
            Some(head)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.v.is_empty() {
            (0, Some(0))
        } else {
            let n = self.v.len() / self.chunk_size;
            let rem = self.v.len() % self.chunk_size;
            let n = if rem > 0 { n + 1 } else { n };
            (n, Some(n))
        }
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<&'a mut [T]> {
        let (start, overflow) = n.overflowing_mul(self.chunk_size);
        if start >= self.v.len() || overflow {
            self.v = &mut [];
            None
        } else {
            let end = match start.checked_add(self.chunk_size) {
                Some(sum) => cmp::min(self.v.len(), sum),
                None => self.v.len(),
            };
            let tmp = mem::replace(&mut self.v, &mut []);
            let (head, tail) = tmp.split_at_mut(end);
            let (_, nth) = head.split_at_mut(start);
            self.v = tail;
            Some(nth)
        }
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        if self.v.is_empty() {
            None
        } else {
            let start = (self.v.len() - 1) / self.chunk_size * self.chunk_size;
            Some(&mut self.v[start..])
        }
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let start = idx * self.chunk_size;
        let end = match start.checked_add(self.chunk_size) {
            None => self.v.len(),
            Some(end) => cmp::min(end, self.v.len()),
        };
        // ຄວາມປອດໄພ: ເບິ່ງ ຄຳ ເຫັນ ສຳ ລັບ `Chunks::__iterator_get_unchecked`.
        //
        // ໃຫ້ສັງເກດວ່າຜູ້ໂທຍັງຮັບປະກັນວ່າພວກເຮົາບໍ່ເຄີຍຖືກເອີ້ນດ້ວຍດັດຊະນີດຽວກັນອີກເທື່ອ ໜຶ່ງ, ແລະບໍ່ມີວິທີອື່ນໃດທີ່ຈະເຂົ້າເຖິງການຍ່ອຍນີ້ຖືກເອີ້ນ, ດັ່ງນັ້ນມັນຈຶ່ງຖືກຕ້ອງ ສຳ ລັບສ່ວນທີ່ຖືກສົ່ງກັບຄືນມາແມ່ນສາມາດສັບປ່ຽນໄດ້.
        //
        //
        //
        unsafe { from_raw_parts_mut(self.v.as_mut_ptr().add(start), end - start) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for ChunksMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        if self.v.is_empty() {
            None
        } else {
            let remainder = self.v.len() % self.chunk_size;
            let sz = if remainder != 0 { remainder } else { self.chunk_size };
            let tmp = mem::replace(&mut self.v, &mut []);
            let tmp_len = tmp.len();
            let (head, tail) = tmp.split_at_mut(tmp_len - sz);
            self.v = head;
            Some(tail)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &mut [];
            None
        } else {
            let start = (len - 1 - n) * self.chunk_size;
            let end = match start.checked_add(self.chunk_size) {
                Some(res) => cmp::min(res, self.v.len()),
                None => self.v.len(),
            };
            let (temp, _tail) = mem::replace(&mut self.v, &mut []).split_at_mut(end);
            let (head, nth_back) = temp.split_at_mut(start);
            self.v = head;
            Some(nth_back)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for ChunksMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for ChunksMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for ChunksMut<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for ChunksMut<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ເຄື່ອງປັ່ນປ່ວນໃນຊິ້ນສ່ວນ (non-overlapping) (ສ່ວນປະກອບ `chunk_size` ໃນແຕ່ລະຄັ້ງ), ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
///
/// ໃນເວລາທີ່ len ຫຼັງຈາກນັ້ນນໍາບໍ່ໄດ້ແບ່ງອອກສ່ອງແສງໂດຍຂະຫນາດການ chunk ທີ່, ຂຶ້ນຜ່ານມາກັບອົງປະກອບ `chunk_size-1` ຈະຖືກຍົກເວັ້ນແຕ່ສາມາດດຶງມາຈາກການທໍາງານຂອງ [`remainder`] ຈາກ iterator ໄດ້.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`chunks_exact`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.chunks_exact(2);
/// ```
///
/// [`chunks_exact`]: slice::chunks_exact
/// [`remainder`]: ChunksExact::remainder
/// [slices]: slice
///
///
#[derive(Debug)]
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub struct ChunksExact<'a, T: 'a> {
    v: &'a [T],
    rem: &'a [T],
    chunk_size: usize,
}

impl<'a, T> ChunksExact<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a [T], chunk_size: usize) -> Self {
        let rem = slice.len() % chunk_size;
        let fst_len = slice.len() - rem;
        // ຄວາມປອດໄພ: 0 <=fst_len <= slice.len() ໂດຍການກໍ່ສ້າງຂ້າງເທິງ
        let (fst, snd) = unsafe { slice.split_at_unchecked(fst_len) };
        Self { v: fst, rem: snd, chunk_size }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຂອງຊິ້ນສ່ວນເດີມທີ່ຈະບໍ່ສົ່ງຄືນໂດຍຕົວປ່ຽນແປງ.
    /// ສ່ວນທີ່ຖືກກັບຄືນມາມີສ່ວນປະກອບສ່ວນໃຫຍ່ `chunk_size-1`.
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    pub fn remainder(&self) -> &'a [T] {
        self.rem
    }
}

// FIXME(#26925) ເອົາອອກໃນເງື່ອນໄຂຂອງ `#[derive(Clone)]`
#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<T> Clone for ChunksExact<'_, T> {
    fn clone(&self) -> Self {
        ChunksExact { v: self.v, rem: self.rem, chunk_size: self.chunk_size }
    }
}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<'a, T> Iterator for ChunksExact<'a, T> {
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let (fst, snd) = self.v.split_at(self.chunk_size);
            self.v = snd;
            Some(fst)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = self.v.len() / self.chunk_size;
        (n, Some(n))
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let (start, overflow) = n.overflowing_mul(self.chunk_size);
        if start >= self.v.len() || overflow {
            self.v = &[];
            None
        } else {
            let (_, snd) = self.v.split_at(start);
            self.v = snd;
            self.next()
        }
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let start = idx * self.chunk_size;
        // ຄວາມປອດໄພ: ສ່ວນໃຫຍ່ແມ່ນຄ້າຍຄືກັບ `Chunks::__iterator_get_unchecked`.
        unsafe { from_raw_parts(self.v.as_ptr().add(start), self.chunk_size) }
    }
}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<'a, T> DoubleEndedIterator for ChunksExact<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let (fst, snd) = self.v.split_at(self.v.len() - self.chunk_size);
            self.v = fst;
            Some(snd)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &[];
            None
        } else {
            let start = (len - 1 - n) * self.chunk_size;
            let end = start + self.chunk_size;
            let nth_back = &self.v[start..end];
            self.v = &self.v[..start];
            Some(nth_back)
        }
    }
}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<T> ExactSizeIterator for ChunksExact<'_, T> {
    fn is_empty(&self) -> bool {
        self.v.is_empty()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for ChunksExact<'_, T> {}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<T> FusedIterator for ChunksExact<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for ChunksExact<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ເຄື່ອງປັ່ນປ່ວນໃນຊິ້ນສ່ວນຕ່າງໆໃນ (non-overlapping) chunks ທີ່ສາມາດປ່ຽນແປງໄດ້ (ອົງປະກອບ `chunk_size` ໃນເວລາດຽວກັນ), ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
///
/// ໃນເວລາທີ່ແຜ່ນ len ບໍ່ໄດ້ຖືກແບ່ງອອກເປັນຂະ ໜາດ ເທົ່າກັນ, ຂະ ໜາດ ຂອງຊິ້ນສ່ວນ `chunk_size-1` ສຸດທ້າຍຈະຖືກຍົກເວັ້ນແຕ່ສາມາດເອົາມາຈາກຟັງຊັນ [`into_remainder`] ຈາກຕົວປັບ.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`chunks_exact_mut`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let mut slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.chunks_exact_mut(2);
/// ```
///
/// [`chunks_exact_mut`]: slice::chunks_exact_mut
/// [`into_remainder`]: ChunksExactMut::into_remainder
/// [slices]: slice
///
///
#[derive(Debug)]
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub struct ChunksExactMut<'a, T: 'a> {
    v: &'a mut [T],
    rem: &'a mut [T],
    chunk_size: usize,
}

impl<'a, T> ChunksExactMut<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], chunk_size: usize) -> Self {
        let rem = slice.len() % chunk_size;
        let fst_len = slice.len() - rem;
        // ຄວາມປອດໄພ: 0 <=fst_len <= slice.len() ໂດຍການກໍ່ສ້າງຂ້າງເທິງ
        let (fst, snd) = unsafe { slice.split_at_mut_unchecked(fst_len) };
        Self { v: fst, rem: snd, chunk_size }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຂອງຊິ້ນສ່ວນເດີມທີ່ຈະບໍ່ສົ່ງຄືນໂດຍຕົວປ່ຽນແປງ.
    /// ສ່ວນທີ່ຖືກກັບຄືນມາມີສ່ວນປະກອບສ່ວນໃຫຍ່ `chunk_size-1`.
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    pub fn into_remainder(self) -> &'a mut [T] {
        self.rem
    }
}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<'a, T> Iterator for ChunksExactMut<'a, T> {
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let tmp = mem::replace(&mut self.v, &mut []);
            let (head, tail) = tmp.split_at_mut(self.chunk_size);
            self.v = tail;
            Some(head)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = self.v.len() / self.chunk_size;
        (n, Some(n))
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<&'a mut [T]> {
        let (start, overflow) = n.overflowing_mul(self.chunk_size);
        if start >= self.v.len() || overflow {
            self.v = &mut [];
            None
        } else {
            let tmp = mem::replace(&mut self.v, &mut []);
            let (_, snd) = tmp.split_at_mut(start);
            self.v = snd;
            self.next()
        }
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let start = idx * self.chunk_size;
        // ຄວາມປອດໄພ: ເບິ່ງ ຄຳ ເຫັນ ສຳ ລັບ `ChunksMut::__iterator_get_unchecked`.
        unsafe { from_raw_parts_mut(self.v.as_mut_ptr().add(start), self.chunk_size) }
    }
}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<'a, T> DoubleEndedIterator for ChunksExactMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let tmp = mem::replace(&mut self.v, &mut []);
            let tmp_len = tmp.len();
            let (head, tail) = tmp.split_at_mut(tmp_len - self.chunk_size);
            self.v = head;
            Some(tail)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &mut [];
            None
        } else {
            let start = (len - 1 - n) * self.chunk_size;
            let end = start + self.chunk_size;
            let (temp, _tail) = mem::replace(&mut self.v, &mut []).split_at_mut(end);
            let (head, nth_back) = temp.split_at_mut(start);
            self.v = head;
            Some(nth_back)
        }
    }
}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<T> ExactSizeIterator for ChunksExactMut<'_, T> {
    fn is_empty(&self) -> bool {
        self.v.is_empty()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for ChunksExactMut<'_, T> {}

#[stable(feature = "chunks_exact", since = "1.31.0")]
impl<T> FusedIterator for ChunksExactMut<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for ChunksExactMut<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ເຄື່ອງປັບອາກາດປ່ອງຢ້ຽມເປັນທ່ອນໆໃນຊິ້ນສ່ວນທີ່ຊ້ ຳ ຊ້ອນກັນ (ອົງປະກອບ `N` ໃນແຕ່ລະຄັ້ງ), ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`array_windows`] ໃນ [slices].
///
/// # Example
///
/// ```
/// #![feature(array_windows)]
///
/// let slice = [0, 1, 2, 3];
/// let iter = slice.array_windows::<2>();
/// ```
///
/// [`array_windows`]: slice::array_windows
/// [slices]: slice
#[derive(Debug, Clone, Copy)]
#[unstable(feature = "array_windows", issue = "75027")]
pub struct ArrayWindows<'a, T: 'a, const N: usize> {
    slice_head: *const T,
    num: usize,
    marker: PhantomData<&'a [T; N]>,
}

impl<'a, T: 'a, const N: usize> ArrayWindows<'a, T, N> {
    #[inline]
    pub(super) fn new(slice: &'a [T]) -> Self {
        let num_windows = slice.len().saturating_sub(N - 1);
        Self { slice_head: slice.as_ptr(), num: num_windows, marker: PhantomData }
    }
}

#[unstable(feature = "array_windows", issue = "75027")]
impl<'a, T, const N: usize> Iterator for ArrayWindows<'a, T, N> {
    type Item = &'a [T; N];

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        if self.num == 0 {
            return None;
        }
        // SAFETY:
        // ນີ້ແມ່ນປອດໄພເພາະວ່າມັນຖືກດັດສະນີເປັນທ່ອນທີ່ຮັບປະກັນຄວາມຍາວ> ນ.
        let ret = unsafe { &*self.slice_head.cast::<[T; N]>() };
        // ຄວາມປອດໄພ: ຮັບປະກັນວ່າມີຢ່າງ ໜ້ອຍ 1 ຢ່າງທີ່ຍັງເຫຼືອ
        // ກ່ອນຫນ້ານີ້ branch ຈະໄດ້ຮັບການຕີ
        self.slice_head = unsafe { self.slice_head.add(1) };

        self.num -= 1;
        Some(ret)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.num, Some(self.num))
    }

    #[inline]
    fn count(self) -> usize {
        self.num
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        if self.num <= n {
            self.num = 0;
            return None;
        }
        // SAFETY:
        // ນີ້ແມ່ນປອດໄພເພາະວ່າມັນຖືກດັດສະນີເປັນທ່ອນທີ່ຮັບປະກັນຄວາມຍາວ> ນ.
        let ret = unsafe { &*self.slice_head.add(n).cast::<[T; N]>() };
        // ຄວາມປອດໄພ: ຮັບປະກັນວ່າມີຢ່າງນ້ອຍ n ລາຍການທີ່ຍັງເຫຼືອ
        self.slice_head = unsafe { self.slice_head.add(n + 1) };

        self.num -= n + 1;
        Some(ret)
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.nth(self.num.checked_sub(1)?)
    }
}

#[unstable(feature = "array_windows", issue = "75027")]
impl<'a, T, const N: usize> DoubleEndedIterator for ArrayWindows<'a, T, N> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T; N]> {
        if self.num == 0 {
            return None;
        }
        // ຄວາມປອດໄພ: ຮັບປະກັນວ່າມີສິນຄ້າທີ່ຍັງເຫຼືອ n, n-1 ສຳ ລັບດັດສະນີ 0.
        let ret = unsafe { &*self.slice_head.add(self.num - 1).cast::<[T; N]>() };
        self.num -= 1;
        Some(ret)
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<&'a [T; N]> {
        if self.num <= n {
            self.num = 0;
            return None;
        }
        // ຄວາມປອດໄພ: ຮັບປະກັນວ່າມີສິນຄ້າທີ່ຍັງເຫຼືອ n, n-1 ສຳ ລັບດັດສະນີ 0.
        let ret = unsafe { &*self.slice_head.add(self.num - (n + 1)).cast::<[T; N]>() };
        self.num -= n + 1;
        Some(ret)
    }
}

#[unstable(feature = "array_windows", issue = "75027")]
impl<T, const N: usize> ExactSizeIterator for ArrayWindows<'_, T, N> {
    fn is_empty(&self) -> bool {
        self.num == 0
    }
}

/// ເຄື່ອງປັ່ນປ່ວນໃນຊິ້ນສ່ວນ (non-overlapping) (ສ່ວນປະກອບ `N` ໃນແຕ່ລະຄັ້ງ), ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
///
/// ໃນເວລາທີ່ແຜ່ນ len ບໍ່ໄດ້ຖືກແບ່ງອອກເປັນຂະ ໜາດ ເທົ່າກັນ, ຂະ ໜາດ ຂອງຊິ້ນສ່ວນ `N-1` ສຸດທ້າຍຈະຖືກຍົກເວັ້ນແຕ່ສາມາດເອົາມາຈາກຟັງຊັນ [`remainder`] ຈາກຕົວປັບ.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`array_chunks`] ໃນ [slices].
///
/// # Example
///
/// ```
/// #![feature(array_chunks)]
///
/// let slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.array_chunks::<2>();
/// ```
///
/// [`array_chunks`]: slice::array_chunks
/// [`remainder`]: ArrayChunks::remainder
/// [slices]: slice
///
///
#[derive(Debug)]
#[unstable(feature = "array_chunks", issue = "74985")]
pub struct ArrayChunks<'a, T: 'a, const N: usize> {
    iter: Iter<'a, [T; N]>,
    rem: &'a [T],
}

impl<'a, T, const N: usize> ArrayChunks<'a, T, N> {
    #[inline]
    pub(super) fn new(slice: &'a [T]) -> Self {
        let (array_slice, rem) = slice.as_chunks();
        Self { iter: array_slice.iter(), rem }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຂອງຊິ້ນສ່ວນເດີມທີ່ຈະບໍ່ສົ່ງຄືນໂດຍຕົວປ່ຽນແປງ.
    /// ສ່ວນທີ່ຖືກກັບຄືນມາມີສ່ວນປະກອບສ່ວນໃຫຍ່ `N-1`.
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    pub fn remainder(&self) -> &'a [T] {
        self.rem
    }
}

// FIXME(#26925) ເອົາອອກໃນເງື່ອນໄຂຂອງ `#[derive(Clone)]`
#[unstable(feature = "array_chunks", issue = "74985")]
impl<T, const N: usize> Clone for ArrayChunks<'_, T, N> {
    fn clone(&self) -> Self {
        ArrayChunks { iter: self.iter.clone(), rem: self.rem }
    }
}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<'a, T, const N: usize> Iterator for ArrayChunks<'a, T, N> {
    type Item = &'a [T; N];

    #[inline]
    fn next(&mut self) -> Option<&'a [T; N]> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn count(self) -> usize {
        self.iter.count()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.iter.nth(n)
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        self.iter.last()
    }

    unsafe fn __iterator_get_unchecked(&mut self, i: usize) -> &'a [T; N] {
        // ຄວາມປອດໄພ: ການຮັບປະກັນຄວາມປອດໄພຂອງ `__iterator_get_unchecked` ແມ່ນ
        // ຖືກໂອນໄປຫາຜູ້ໂທ.
        unsafe { self.iter.__iterator_get_unchecked(i) }
    }
}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<'a, T, const N: usize> DoubleEndedIterator for ArrayChunks<'a, T, N> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T; N]> {
        self.iter.next_back()
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.iter.nth_back(n)
    }
}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<T, const N: usize> ExactSizeIterator for ArrayChunks<'_, T, N> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T, const N: usize> TrustedLen for ArrayChunks<'_, T, N> {}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<T, const N: usize> FusedIterator for ArrayChunks<'_, T, N> {}

#[doc(hidden)]
#[unstable(feature = "array_chunks", issue = "74985")]
unsafe impl<'a, T, const N: usize> TrustedRandomAccess for ArrayChunks<'a, T, N> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ເຄື່ອງປັ່ນປ່ວນໃນຊິ້ນສ່ວນຕ່າງໆໃນ (non-overlapping) chunks ທີ່ສາມາດປ່ຽນແປງໄດ້ (ອົງປະກອບ `N` ໃນເວລາດຽວກັນ), ເລີ່ມຕົ້ນໃນຕອນເລີ່ມຕົ້ນຂອງຊິ້ນ.
///
/// ໃນເວລາທີ່ແຜ່ນ len ບໍ່ໄດ້ຖືກແບ່ງອອກເປັນຂະ ໜາດ ເທົ່າກັນ, ຂະ ໜາດ ຂອງຊິ້ນສ່ວນ `N-1` ສຸດທ້າຍຈະຖືກຍົກເວັ້ນແຕ່ສາມາດເອົາມາຈາກຟັງຊັນ [`into_remainder`] ຈາກຕົວປັບ.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`array_chunks_mut`] ໃນ [slices].
///
/// # Example
///
/// ```
/// #![feature(array_chunks)]
///
/// let mut slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.array_chunks_mut::<2>();
/// ```
///
/// [`array_chunks_mut`]: slice::array_chunks_mut
/// [`into_remainder`]: ../../std/slice/struct.ArrayChunksMut.html#method.into_remainder
/// [slices]: slice
///
///
#[derive(Debug)]
#[unstable(feature = "array_chunks", issue = "74985")]
pub struct ArrayChunksMut<'a, T: 'a, const N: usize> {
    iter: IterMut<'a, [T; N]>,
    rem: &'a mut [T],
}

impl<'a, T, const N: usize> ArrayChunksMut<'a, T, N> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T]) -> Self {
        let (array_slice, rem) = slice.as_chunks_mut();
        Self { iter: array_slice.iter_mut(), rem }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຂອງຊິ້ນສ່ວນເດີມທີ່ຈະບໍ່ສົ່ງຄືນໂດຍຕົວປ່ຽນແປງ.
    /// ສ່ວນທີ່ຖືກກັບຄືນມາມີສ່ວນປະກອບສ່ວນໃຫຍ່ `N-1`.
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    pub fn into_remainder(self) -> &'a mut [T] {
        self.rem
    }
}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<'a, T, const N: usize> Iterator for ArrayChunksMut<'a, T, N> {
    type Item = &'a mut [T; N];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T; N]> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn count(self) -> usize {
        self.iter.count()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.iter.nth(n)
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        self.iter.last()
    }

    unsafe fn __iterator_get_unchecked(&mut self, i: usize) -> &'a mut [T; N] {
        // ຄວາມປອດໄພ: ການຮັບປະກັນຄວາມປອດໄພຂອງ `__iterator_get_unchecked` ຖືກໂອນເຂົ້າ
        // ຜູ້ໂທ.
        unsafe { self.iter.__iterator_get_unchecked(i) }
    }
}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<'a, T, const N: usize> DoubleEndedIterator for ArrayChunksMut<'a, T, N> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T; N]> {
        self.iter.next_back()
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.iter.nth_back(n)
    }
}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<T, const N: usize> ExactSizeIterator for ArrayChunksMut<'_, T, N> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T, const N: usize> TrustedLen for ArrayChunksMut<'_, T, N> {}

#[unstable(feature = "array_chunks", issue = "74985")]
impl<T, const N: usize> FusedIterator for ArrayChunksMut<'_, T, N> {}

#[doc(hidden)]
#[unstable(feature = "array_chunks", issue = "74985")]
unsafe impl<'a, T, const N: usize> TrustedRandomAccess for ArrayChunksMut<'a, T, N> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ເຄື່ອງປັ່ນປ່ວນໃນຊິ້ນສ່ວນ (non-overlapping) (ສ່ວນປະກອບ `chunk_size` ໃນແຕ່ລະຄັ້ງ), ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງສ່ວນທີ່ເຫຼືອ.
///
///
/// ໃນເວລາທີ່ເສັ້ນລ້ອນຈະບໍ່ຖືກແບ່ງເປັນຂະ ໜາດ ເທົ່າກັນ, ຂະ ໜາດ ຊິ້ນສຸດທ້າຍຂອງການຊັ່ງຊາຈະເປັນສ່ວນທີ່ເຫຼືອ.
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`rchunks`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.rchunks(2);
/// ```
///
/// [`rchunks`]: slice::rchunks
/// [slices]: slice
///
#[derive(Debug)]
#[stable(feature = "rchunks", since = "1.31.0")]
pub struct RChunks<'a, T: 'a> {
    v: &'a [T],
    chunk_size: usize,
}

impl<'a, T: 'a> RChunks<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a [T], size: usize) -> Self {
        Self { v: slice, chunk_size: size }
    }
}

// FIXME(#26925) ເອົາອອກໃນເງື່ອນໄຂຂອງ `#[derive(Clone)]`
#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> Clone for RChunks<'_, T> {
    fn clone(&self) -> Self {
        RChunks { v: self.v, chunk_size: self.chunk_size }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> Iterator for RChunks<'a, T> {
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.v.is_empty() {
            None
        } else {
            let chunksz = cmp::min(self.v.len(), self.chunk_size);
            let (fst, snd) = self.v.split_at(self.v.len() - chunksz);
            self.v = fst;
            Some(snd)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.v.is_empty() {
            (0, Some(0))
        } else {
            let n = self.v.len() / self.chunk_size;
            let rem = self.v.len() % self.chunk_size;
            let n = if rem > 0 { n + 1 } else { n };
            (n, Some(n))
        }
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let (end, overflow) = n.overflowing_mul(self.chunk_size);
        if end >= self.v.len() || overflow {
            self.v = &[];
            None
        } else {
            // ບໍ່ສາມາດລອກໄດ້ເນື່ອງຈາກການກວດສອບຂ້າງເທິງ
            let end = self.v.len() - end;
            let start = match end.checked_sub(self.chunk_size) {
                Some(sum) => sum,
                None => 0,
            };
            let nth = &self.v[start..end];
            self.v = &self.v[0..start];
            Some(nth)
        }
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        if self.v.is_empty() {
            None
        } else {
            let rem = self.v.len() % self.chunk_size;
            let end = if rem == 0 { self.chunk_size } else { rem };
            Some(&self.v[0..end])
        }
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let end = self.v.len() - idx * self.chunk_size;
        let start = match end.checked_sub(self.chunk_size) {
            None => 0,
            Some(start) => start,
        };
        // ຄວາມປອດໄພ: ສ່ວນໃຫຍ່ແມ່ນຄ້າຍຄືກັບ `Chunks::__iterator_get_unchecked`.
        unsafe { from_raw_parts(self.v.as_ptr().add(start), end - start) }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> DoubleEndedIterator for RChunks<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.v.is_empty() {
            None
        } else {
            let remainder = self.v.len() % self.chunk_size;
            let chunksz = if remainder != 0 { remainder } else { self.chunk_size };
            let (fst, snd) = self.v.split_at(chunksz);
            self.v = snd;
            Some(fst)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &[];
            None
        } else {
            // ບໍ່ສາມາດ underflow ເນື່ອງຈາກວ່າ `n < len`
            let offset_from_end = (len - 1 - n) * self.chunk_size;
            let end = self.v.len() - offset_from_end;
            let start = end.saturating_sub(self.chunk_size);
            let nth_back = &self.v[start..end];
            self.v = &self.v[end..];
            Some(nth_back)
        }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> ExactSizeIterator for RChunks<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for RChunks<'_, T> {}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> FusedIterator for RChunks<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for RChunks<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ເຄື່ອງປັ່ນປ່ວນໃນຊິ້ນສ່ວນຕ່າງໆໃນ (non-overlapping) chunks ທີ່ສາມາດປ່ຽນແປງໄດ້ (ອົງປະກອບ `chunk_size` ໃນແຕ່ລະຄັ້ງ), ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງສ່ວນທີ່ເຫຼືອ.
///
///
/// ໃນເວລາທີ່ເສັ້ນລ້ອນຈະບໍ່ຖືກແບ່ງເປັນຂະ ໜາດ ເທົ່າກັນ, ຂະ ໜາດ ຊິ້ນສຸດທ້າຍຂອງການຊັ່ງຊາຈະເປັນສ່ວນທີ່ເຫຼືອ.
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`rchunks_mut`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let mut slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.rchunks_mut(2);
/// ```
///
/// [`rchunks_mut`]: slice::rchunks_mut
/// [slices]: slice
///
#[derive(Debug)]
#[stable(feature = "rchunks", since = "1.31.0")]
pub struct RChunksMut<'a, T: 'a> {
    v: &'a mut [T],
    chunk_size: usize,
}

impl<'a, T: 'a> RChunksMut<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], size: usize) -> Self {
        Self { v: slice, chunk_size: size }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> Iterator for RChunksMut<'a, T> {
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        if self.v.is_empty() {
            None
        } else {
            let sz = cmp::min(self.v.len(), self.chunk_size);
            let tmp = mem::replace(&mut self.v, &mut []);
            let tmp_len = tmp.len();
            let (head, tail) = tmp.split_at_mut(tmp_len - sz);
            self.v = head;
            Some(tail)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.v.is_empty() {
            (0, Some(0))
        } else {
            let n = self.v.len() / self.chunk_size;
            let rem = self.v.len() % self.chunk_size;
            let n = if rem > 0 { n + 1 } else { n };
            (n, Some(n))
        }
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<&'a mut [T]> {
        let (end, overflow) = n.overflowing_mul(self.chunk_size);
        if end >= self.v.len() || overflow {
            self.v = &mut [];
            None
        } else {
            // ບໍ່ສາມາດລອກໄດ້ເນື່ອງຈາກການກວດສອບຂ້າງເທິງ
            let end = self.v.len() - end;
            let start = match end.checked_sub(self.chunk_size) {
                Some(sum) => sum,
                None => 0,
            };
            let tmp = mem::replace(&mut self.v, &mut []);
            let (head, tail) = tmp.split_at_mut(start);
            let (nth, _) = tail.split_at_mut(end - start);
            self.v = head;
            Some(nth)
        }
    }

    #[inline]
    fn last(self) -> Option<Self::Item> {
        if self.v.is_empty() {
            None
        } else {
            let rem = self.v.len() % self.chunk_size;
            let end = if rem == 0 { self.chunk_size } else { rem };
            Some(&mut self.v[0..end])
        }
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let end = self.v.len() - idx * self.chunk_size;
        let start = match end.checked_sub(self.chunk_size) {
            None => 0,
            Some(start) => start,
        };
        // ຄວາມປອດໄພ: ເບິ່ງ ຄຳ ເຫັນ ສຳ ລັບ `RChunks::__iterator_get_unchecked` ແລະ
        // `ChunksMut::__iterator_get_unchecked`
        unsafe { from_raw_parts_mut(self.v.as_mut_ptr().add(start), end - start) }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> DoubleEndedIterator for RChunksMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        if self.v.is_empty() {
            None
        } else {
            let remainder = self.v.len() % self.chunk_size;
            let sz = if remainder != 0 { remainder } else { self.chunk_size };
            let tmp = mem::replace(&mut self.v, &mut []);
            let (head, tail) = tmp.split_at_mut(sz);
            self.v = tail;
            Some(head)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &mut [];
            None
        } else {
            // ບໍ່ສາມາດ underflow ເນື່ອງຈາກວ່າ `n < len`
            let offset_from_end = (len - 1 - n) * self.chunk_size;
            let end = self.v.len() - offset_from_end;
            let start = end.saturating_sub(self.chunk_size);
            let (tmp, tail) = mem::replace(&mut self.v, &mut []).split_at_mut(end);
            let (_, nth_back) = tmp.split_at_mut(start);
            self.v = tail;
            Some(nth_back)
        }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> ExactSizeIterator for RChunksMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for RChunksMut<'_, T> {}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> FusedIterator for RChunksMut<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for RChunksMut<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ເຄື່ອງປັ່ນປ່ວນໃນຊິ້ນສ່ວນ (non-overlapping) (ສ່ວນປະກອບ `chunk_size` ໃນແຕ່ລະຄັ້ງ), ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງສ່ວນທີ່ເຫຼືອ.
///
/// ໃນເວລາທີ່ len ຫຼັງຈາກນັ້ນນໍາບໍ່ໄດ້ແບ່ງອອກສ່ອງແສງໂດຍຂະຫນາດການ chunk ທີ່, ຂຶ້ນຜ່ານມາກັບອົງປະກອບ `chunk_size-1` ຈະຖືກຍົກເວັ້ນແຕ່ສາມາດດຶງມາຈາກການທໍາງານຂອງ [`remainder`] ຈາກ iterator ໄດ້.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`rchunks_exact`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.rchunks_exact(2);
/// ```
///
/// [`rchunks_exact`]: slice::rchunks_exact
/// [`remainder`]: ChunksExact::remainder
/// [slices]: slice
///
///
#[derive(Debug)]
#[stable(feature = "rchunks", since = "1.31.0")]
pub struct RChunksExact<'a, T: 'a> {
    v: &'a [T],
    rem: &'a [T],
    chunk_size: usize,
}

impl<'a, T> RChunksExact<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a [T], chunk_size: usize) -> Self {
        let rem = slice.len() % chunk_size;
        // ຄວາມປອດໄພ: 0 <=rem <= slice.len() ໂດຍການກໍ່ສ້າງຂ້າງເທິງ
        let (fst, snd) = unsafe { slice.split_at_unchecked(rem) };
        Self { v: snd, rem: fst, chunk_size }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຂອງຊິ້ນສ່ວນເດີມທີ່ຈະບໍ່ສົ່ງຄືນໂດຍຕົວປ່ຽນແປງ.
    /// ສ່ວນທີ່ຖືກກັບຄືນມາມີສ່ວນປະກອບສ່ວນໃຫຍ່ `chunk_size-1`.
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    pub fn remainder(&self) -> &'a [T] {
        self.rem
    }
}

// FIXME(#26925) ເອົາອອກໃນເງື່ອນໄຂຂອງ `#[derive(Clone)]`
#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> Clone for RChunksExact<'a, T> {
    fn clone(&self) -> RChunksExact<'a, T> {
        RChunksExact { v: self.v, rem: self.rem, chunk_size: self.chunk_size }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> Iterator for RChunksExact<'a, T> {
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<&'a [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let (fst, snd) = self.v.split_at(self.v.len() - self.chunk_size);
            self.v = fst;
            Some(snd)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = self.v.len() / self.chunk_size;
        (n, Some(n))
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let (end, overflow) = n.overflowing_mul(self.chunk_size);
        if end >= self.v.len() || overflow {
            self.v = &[];
            None
        } else {
            let (fst, _) = self.v.split_at(self.v.len() - end);
            self.v = fst;
            self.next()
        }
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let end = self.v.len() - idx * self.chunk_size;
        let start = end - self.chunk_size;
        // ຄວາມປອດໄພ: ຄວາມປອດໄພ: ມັກທີ່ສຸດກັບ `Chunks::__iterator_get_unchecked`.
        //
        unsafe { from_raw_parts(self.v.as_ptr().add(start), self.chunk_size) }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> DoubleEndedIterator for RChunksExact<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let (fst, snd) = self.v.split_at(self.chunk_size);
            self.v = snd;
            Some(fst)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &[];
            None
        } else {
            // ໃນປັດຈຸບັນພວກເຮົາຮູ້ວ່າ `n` ກົງກັນກັບທ່ອນໄມ້, ບໍ່ມີການປະຕິບັດງານເຫຼົ່ານີ້ສາມາດ underflow/overflow
            //
            let offset = (len - n) * self.chunk_size;
            let start = self.v.len() - offset;
            let end = start + self.chunk_size;
            let nth_back = &self.v[start..end];
            self.v = &self.v[end..];
            Some(nth_back)
        }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> ExactSizeIterator for RChunksExact<'a, T> {
    fn is_empty(&self) -> bool {
        self.v.is_empty()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for RChunksExact<'_, T> {}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> FusedIterator for RChunksExact<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for RChunksExact<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ເຄື່ອງປັ່ນປ່ວນໃນຊິ້ນສ່ວນຕ່າງໆໃນ (non-overlapping) chunks ທີ່ສາມາດປ່ຽນແປງໄດ້ (ອົງປະກອບ `chunk_size` ໃນແຕ່ລະຄັ້ງ), ເລີ່ມຕົ້ນໃນຕອນທ້າຍຂອງສ່ວນທີ່ເຫຼືອ.
///
/// ໃນເວລາທີ່ແຜ່ນ len ບໍ່ໄດ້ຖືກແບ່ງອອກເປັນຂະ ໜາດ ເທົ່າກັນ, ຂະ ໜາດ ຂອງຊິ້ນສ່ວນ `chunk_size-1` ສຸດທ້າຍຈະຖືກຍົກເວັ້ນແຕ່ສາມາດເອົາມາຈາກຟັງຊັນ [`into_remainder`] ຈາກຕົວປັບ.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`rchunks_exact_mut`] ໃນ [slices].
///
/// # Example
///
/// ```
/// let mut slice = ['l', 'o', 'r', 'e', 'm'];
/// let iter = slice.rchunks_exact_mut(2);
/// ```
///
/// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
/// [`into_remainder`]: ChunksExactMut::into_remainder
/// [slices]: slice
///
///
#[derive(Debug)]
#[stable(feature = "rchunks", since = "1.31.0")]
pub struct RChunksExactMut<'a, T: 'a> {
    v: &'a mut [T],
    rem: &'a mut [T],
    chunk_size: usize,
}

impl<'a, T> RChunksExactMut<'a, T> {
    #[inline]
    pub(super) fn new(slice: &'a mut [T], chunk_size: usize) -> Self {
        let rem = slice.len() % chunk_size;
        // ຄວາມປອດໄພ: 0 <=rem <= slice.len() ໂດຍການກໍ່ສ້າງຂ້າງເທິງ
        let (fst, snd) = unsafe { slice.split_at_mut_unchecked(rem) };
        Self { v: snd, rem: fst, chunk_size }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ເຫຼືອຂອງຊິ້ນສ່ວນເດີມທີ່ຈະບໍ່ສົ່ງຄືນໂດຍຕົວປ່ຽນແປງ.
    /// ສ່ວນທີ່ຖືກກັບຄືນມາມີສ່ວນປະກອບສ່ວນໃຫຍ່ `chunk_size-1`.
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    pub fn into_remainder(self) -> &'a mut [T] {
        self.rem
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> Iterator for RChunksExactMut<'a, T> {
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<&'a mut [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let tmp = mem::replace(&mut self.v, &mut []);
            let tmp_len = tmp.len();
            let (head, tail) = tmp.split_at_mut(tmp_len - self.chunk_size);
            self.v = head;
            Some(tail)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = self.v.len() / self.chunk_size;
        (n, Some(n))
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<&'a mut [T]> {
        let (end, overflow) = n.overflowing_mul(self.chunk_size);
        if end >= self.v.len() || overflow {
            self.v = &mut [];
            None
        } else {
            let tmp = mem::replace(&mut self.v, &mut []);
            let tmp_len = tmp.len();
            let (fst, _) = tmp.split_at_mut(tmp_len - end);
            self.v = fst;
            self.next()
        }
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }

    #[doc(hidden)]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
        let end = self.v.len() - idx * self.chunk_size;
        let start = end - self.chunk_size;
        // ຄວາມປອດໄພ: ເບິ່ງ ຄຳ ເຫັນ ສຳ ລັບ `RChunksMut::__iterator_get_unchecked`.
        unsafe { from_raw_parts_mut(self.v.as_mut_ptr().add(start), self.chunk_size) }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<'a, T> DoubleEndedIterator for RChunksExactMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut [T]> {
        if self.v.len() < self.chunk_size {
            None
        } else {
            let tmp = mem::replace(&mut self.v, &mut []);
            let (head, tail) = tmp.split_at_mut(self.chunk_size);
            self.v = tail;
            Some(head)
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        let len = self.len();
        if n >= len {
            self.v = &mut [];
            None
        } else {
            // ໃນປັດຈຸບັນພວກເຮົາຮູ້ວ່າ `n` ກົງກັນກັບທ່ອນໄມ້, ບໍ່ມີການປະຕິບັດງານເຫຼົ່ານີ້ສາມາດ underflow/overflow
            //
            let offset = (len - n) * self.chunk_size;
            let start = self.v.len() - offset;
            let end = start + self.chunk_size;
            let (tmp, tail) = mem::replace(&mut self.v, &mut []).split_at_mut(end);
            let (_, nth_back) = tmp.split_at_mut(start);
            self.v = tail;
            Some(nth_back)
        }
    }
}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> ExactSizeIterator for RChunksExactMut<'_, T> {
    fn is_empty(&self) -> bool {
        self.v.is_empty()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for RChunksExactMut<'_, T> {}

#[stable(feature = "rchunks", since = "1.31.0")]
impl<T> FusedIterator for RChunksExactMut<'_, T> {}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for RChunksExactMut<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for Iter<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<'a, T> TrustedRandomAccess for IterMut<'a, T> {
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

/// ຕົວຊີ້ວັດທີ່ລື່ນໃນຊິ້ນສ່ວນ (non-overlapping) ທີ່ຖືກແຍກອອກໂດຍຜູ້ລ້າ.
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`group_by`] ໃນ [slices].
///
/// [`group_by`]: slice::group_by
/// [slices]: slice
#[unstable(feature = "slice_group_by", issue = "80552")]
pub struct GroupBy<'a, T: 'a, P> {
    slice: &'a [T],
    predicate: P,
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> GroupBy<'a, T, P> {
    pub(super) fn new(slice: &'a [T], predicate: P) -> Self {
        GroupBy { slice, predicate }
    }
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> Iterator for GroupBy<'a, T, P>
where
    P: FnMut(&T, &T) -> bool,
{
    type Item = &'a [T];

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        if self.slice.is_empty() {
            None
        } else {
            let mut len = 1;
            let mut iter = self.slice.windows(2);
            while let Some([l, r]) = iter.next() {
                if (self.predicate)(l, r) { len += 1 } else { break }
            }
            let (head, tail) = self.slice.split_at(len);
            self.slice = tail;
            Some(head)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.slice.is_empty() { (0, Some(0)) } else { (1, Some(self.slice.len())) }
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> DoubleEndedIterator for GroupBy<'a, T, P>
where
    P: FnMut(&T, &T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        if self.slice.is_empty() {
            None
        } else {
            let mut len = 1;
            let mut iter = self.slice.windows(2);
            while let Some([l, r]) = iter.next_back() {
                if (self.predicate)(l, r) { len += 1 } else { break }
            }
            let (head, tail) = self.slice.split_at(self.slice.len() - len);
            self.slice = head;
            Some(tail)
        }
    }
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> FusedIterator for GroupBy<'a, T, P> where P: FnMut(&T, &T) -> bool {}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a + fmt::Debug, P> fmt::Debug for GroupBy<'a, T, P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("GroupBy").field("slice", &self.slice).finish()
    }
}

/// ຕົວຊີ້ວັດທີ່ລື່ນໃນຊິ້ນສ່ວນ (non-overlapping) ທີ່ສາມາດປ່ຽນແປງໄດ້ແຍກອອກໂດຍຕົວລ້າ.
///
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`group_by_mut`] ໃນ [slices].
///
/// [`group_by_mut`]: slice::group_by_mut
/// [slices]: slice
#[unstable(feature = "slice_group_by", issue = "80552")]
pub struct GroupByMut<'a, T: 'a, P> {
    slice: &'a mut [T],
    predicate: P,
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> GroupByMut<'a, T, P> {
    pub(super) fn new(slice: &'a mut [T], predicate: P) -> Self {
        GroupByMut { slice, predicate }
    }
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> Iterator for GroupByMut<'a, T, P>
where
    P: FnMut(&T, &T) -> bool,
{
    type Item = &'a mut [T];

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        if self.slice.is_empty() {
            None
        } else {
            let mut len = 1;
            let mut iter = self.slice.windows(2);
            while let Some([l, r]) = iter.next() {
                if (self.predicate)(l, r) { len += 1 } else { break }
            }
            let slice = mem::take(&mut self.slice);
            let (head, tail) = slice.split_at_mut(len);
            self.slice = tail;
            Some(head)
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.slice.is_empty() { (0, Some(0)) } else { (1, Some(self.slice.len())) }
    }

    #[inline]
    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> DoubleEndedIterator for GroupByMut<'a, T, P>
where
    P: FnMut(&T, &T) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        if self.slice.is_empty() {
            None
        } else {
            let mut len = 1;
            let mut iter = self.slice.windows(2);
            while let Some([l, r]) = iter.next_back() {
                if (self.predicate)(l, r) { len += 1 } else { break }
            }
            let slice = mem::take(&mut self.slice);
            let (head, tail) = slice.split_at_mut(slice.len() - len);
            self.slice = head;
            Some(tail)
        }
    }
}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a, P> FusedIterator for GroupByMut<'a, T, P> where P: FnMut(&T, &T) -> bool {}

#[unstable(feature = "slice_group_by", issue = "80552")]
impl<'a, T: 'a + fmt::Debug, P> fmt::Debug for GroupByMut<'a, T, P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("GroupByMut").field("slice", &self.slice).finish()
    }
}