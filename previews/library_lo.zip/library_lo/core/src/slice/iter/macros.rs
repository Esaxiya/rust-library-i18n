//! Macros ໃຊ້ໂດຍສ່ວນປະກອບສ່ວນຂອງການຕັດ.

// Inlining is_empty ແລະ len ເຮັດໃຫ້ມີການປະຕິບັດທີ່ແຕກຕ່າງກັນຢ່າງຫຼວງຫຼາຍ
macro_rules! is_empty {
    // ວິທີການທີ່ພວກເຮົາເຂົ້າລະຫັດຄວາມຍາວຂອງ iterator ZST, ມູນຄ່າການເຮັດວຽກທັງສອງສໍາລັບ ZST ແລະບໍ່ແມ່ນ ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// ເພື່ອ ກຳ ຈັດການກວດກາຂອບເຂດບາງຢ່າງ (ເບິ່ງ `position`), ພວກເຮົາຄິດໄລ່ຄວາມຍາວໃນທາງທີ່ບໍ່ຄາດຄິດ.
// (ທົດສອບໂດຍ `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // ບາງຄັ້ງພວກເຮົາໃຊ້ຢູ່ໃນທ່ອນໄມ້ທີ່ບໍ່ປອດໄພ

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ ນີ້ໃຊ້ `unchecked_sub` ເພາະວ່າພວກເຮົາຂື້ນກັບການຫໍ່ເພື່ອເປັນຕົວແທນຂອງຄວາມຍາວຂອງເຄື່ອງຕັດຊິ້ນສ່ວນ ZST ທີ່ຍາວນານ.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // ພວກເຮົາຮູ້ວ່າ `start <= end`, ສະນັ້ນສາມາດເຮັດໄດ້ດີກ່ວາ `offset_from`, ເຊິ່ງ ຈຳ ເປັນຕ້ອງຈັດການກັບການເຊັນ.
            // ໂດຍການຕັ້ງທຸງທີ່ ເໝາະ ສົມຢູ່ນີ້ພວກເຮົາສາມາດບອກ LLVM ນີ້ໄດ້, ເຊິ່ງຊ່ວຍໃຫ້ມັນຖອນການກວດກາຂອບເຂດ.
            // ຄວາມປອດໄພ: ໂດຍປະເພດບຸກລຸກ, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // ໂດຍການບອກກັບ LLVM ອີກວ່າຕົວຊີ້ແມ່ນແຍກຕ່າງຫາກຈາກຫລາຍຂະ ໜາດ ຂອງປະເພດ, ມັນສາມາດເພີ່ມປະສິດທິພາບ `len() == 0` ລົງເປັນ `start == end` ແທນ `(end - start) < size`.
            //
            // ຄວາມປອດໄພ: ໂດຍການຮຸກຮານປະເພດ, ຕົວຊີ້ແມ່ນສອດຄ່ອງສະນັ້ນ
            //         ໄລຍະຫ່າງລະຫວ່າງພວກເຂົາຈະຕ້ອງມີຫຼາຍຂະ ໜາດ ຂອງຈຸດເຂົ້າ
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// ຄໍານິຍາມຮ່ວມຂອງ `Iter` ແລະ `IterMut` iterators
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // ສົ່ງຄືນອົງປະກອບ ທຳ ອິດແລະຍ້າຍຈຸດເລີ່ມຕົ້ນຂອງຕົວຍົກທິດທາງຕໍ່ໄປໂດຍ 1.
        // ປັບປຸງປະສິດຕິພາບດີຫຼາຍເມື່ອທຽບໃສ່ກັບ ໜ້າ ທີ່ທີ່ຕັ້ງຢູ່.
        // ຕົວລະບາຍບໍ່ຕ້ອງເປົ່າ.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // ສົ່ງຄືນອົງປະກອບສຸດທ້າຍແລະຍ້າຍຈຸດສຸດທ້າຍຂອງຕົວຍົກຂື້ນທາງຫລັງໂດຍ 1.
        // ປັບປຸງປະສິດຕິພາບດີຫຼາຍເມື່ອທຽບໃສ່ກັບ ໜ້າ ທີ່ທີ່ຕັ້ງຢູ່.
        // ຕົວລະບາຍບໍ່ຕ້ອງເປົ່າ.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // ຫົດຕົວຕົວເຂັມທິດໃນເວລາທີ່ T ແມ່ນ ZST, ໂດຍການຍ້າຍຈຸດສຸດທ້າຍຂອງຕົວປ່ຽນທາງຫລັງໂດຍ `n`.
        // `n` ຕ້ອງບໍ່ເກີນ `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // ຜູ້ຊ່ວຍເຮັດວຽກ ສຳ ລັບການສ້າງທ່ອນຈາກຊ່າງຕັດ.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // ຄວາມປອດໄພ: ຕົວລະບາຍອາກາດໄດ້ຖືກສ້າງຂື້ນຈາກສ່ວນ ໜຶ່ງ ທີ່ມີຕົວຊີ້
                // `self.ptr` ແລະຄວາມຍາວ `len!(self)`.
                // ນີ້ຮັບປະກັນວ່າທຸກເງື່ອນໄຂທີ່ຕ້ອງການ ສຳ ລັບ `from_raw_parts` ແມ່ນ ສຳ ເລັດ.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // ຜູ້ຊ່ວຍເຮັດວຽກ ສຳ ລັບການເຄື່ອນຍ້າຍຈຸດເລີ່ມຕົ້ນຂອງຕົວຍົກທິດທາງຕໍ່ໂດຍອົງປະກອບ `offset`, ກັບຄືນການເລີ່ມຕົ້ນເກົ່າ.
            //
            // ບໍ່ປອດໄພເພາະວ່າການຊົດເຊີຍຕ້ອງບໍ່ເກີນ `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // ຄວາມປອດໄພ: ຜູ້ໂທຮັບປະກັນວ່າ `offset` ບໍ່ເກີນ `self.len()`,
                    // ສະນັ້ນຕົວຊີ້ທິດທາງ ໃໝ່ ນີ້ແມ່ນຢູ່ໃນ `self` ແລະດັ່ງນັ້ນຈຶ່ງຮັບປະກັນວ່າບໍ່ແມ່ນສິ່ງລົບກວນ.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // ຜູ້ຊ່ວຍເຮັດວຽກ ສຳ ລັບການເຄື່ອນຍ້າຍຈຸດສຸດທ້າຍຂອງຕົວປ່ຽນທາງຫຼັງໂດຍອົງປະກອບ `offset`, ກັບຄືນທ້າຍ ໃໝ່.
            //
            // ບໍ່ປອດໄພເພາະວ່າການຊົດເຊີຍຕ້ອງບໍ່ເກີນ `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // ຄວາມປອດໄພ: ຜູ້ໂທຮັບປະກັນວ່າ `offset` ບໍ່ເກີນ `self.len()`,
                    // ເຊິ່ງຮັບປະກັນບໍ່ໃຫ້ເກີນ `isize`.
                    // ນອກຈາກນີ້, ຕົວຊີ້ທີ່ໄດ້ຮັບແມ່ນຢູ່ໃນຂອບເຂດ `slice`, ເຊິ່ງຕອບສະ ໜອງ ຄວາມຕ້ອງການອື່ນໆ ສຳ ລັບ `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // ສາມາດປະຕິບັດໄດ້ດ້ວຍທ່ອນ, ແຕ່ວ່ານີ້ຈະຫລີກລ້ຽງການກວດກາຂອບເຂດ

                // ຄວາມປອດໄພ: ການໂທ `assume` ແມ່ນປອດໄພຕັ້ງແຕ່ຕົວຊີ້ເລີ່ມຕົ້ນ
                // ຕ້ອງບໍ່ແມ່ນ null, ແລະສ່ວນທີ່ບໍ່ແມ່ນ ZST ກໍ່ຕ້ອງມີຕົວຊີ້ທ້າຍທີ່ບໍ່ແມ່ນ null.
                // ການໂທຫາ `next_unchecked!` ແມ່ນປອດໄພເພາະວ່າພວກເຮົາກວດເບິ່ງວ່າເຄື່ອງປັບປ່ຽນແມ່ນຫຍັງກ່ອນ.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ເຄື່ອງປັບໂຕນີ້ແມ່ນຫວ່າງແລ້ວ.
                    if mem::size_of::<T>() == 0 {
                        // ພວກເຮົາຕ້ອງເຮັດມັນດ້ວຍວິທີນີ້ເພາະວ່າ `ptr` ອາດຈະບໍ່ເຄີຍເປັນ 0, ແຕ່ວ່າ `end` ອາດຈະເປັນ (ຍ້ອນການຫໍ່).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // ຄວາມປອດໄພ: ສິ້ນສຸດບໍ່ສາມາດ 0 ຖ້າ T ບໍ່ແມ່ນ ZST ເພາະວ່າ ptr ບໍ່ແມ່ນ 0 ແລະສິ້ນສຸດ>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // ຄວາມປອດໄພ: ພວກເຮົາຢູ່ໃນຂອບເຂດ.`post_inc_start` ເຮັດສິ່ງທີ່ຖືກຕ້ອງແມ່ນແຕ່ ສຳ ລັບ ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // ພວກເຮົາ override ການປະຕິບັດໃນຕອນຕົ້ນ, ເຊິ່ງໃຊ້ `try_fold`, ເພາະວ່າການປະຕິບັດທີ່ງ່າຍດາຍນີ້ເຮັດໃຫ້ LLVM IR ຫນ້ອຍລົງແລະໄວກວ່າທີ່ຈະລວບລວມ.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // ພວກເຮົາ override ການປະຕິບັດໃນຕອນຕົ້ນ, ເຊິ່ງໃຊ້ `try_fold`, ເພາະວ່າການປະຕິບັດທີ່ງ່າຍດາຍນີ້ເຮັດໃຫ້ LLVM IR ຫນ້ອຍລົງແລະໄວກວ່າທີ່ຈະລວບລວມ.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // ພວກເຮົາ override ການປະຕິບັດໃນຕອນຕົ້ນ, ເຊິ່ງໃຊ້ `try_fold`, ເພາະວ່າການປະຕິບັດທີ່ງ່າຍດາຍນີ້ເຮັດໃຫ້ LLVM IR ຫນ້ອຍລົງແລະໄວກວ່າທີ່ຈະລວບລວມ.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // ພວກເຮົາ override ການປະຕິບັດໃນຕອນຕົ້ນ, ເຊິ່ງໃຊ້ `try_fold`, ເພາະວ່າການປະຕິບັດທີ່ງ່າຍດາຍນີ້ເຮັດໃຫ້ LLVM IR ຫນ້ອຍລົງແລະໄວກວ່າທີ່ຈະລວບລວມ.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // ພວກເຮົາ override ການປະຕິບັດໃນຕອນຕົ້ນ, ເຊິ່ງໃຊ້ `try_fold`, ເພາະວ່າການປະຕິບັດທີ່ງ່າຍດາຍນີ້ເຮັດໃຫ້ LLVM IR ຫນ້ອຍລົງແລະໄວກວ່າທີ່ຈະລວບລວມ.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // ພວກເຮົາ override ການປະຕິບັດໃນຕອນຕົ້ນ, ເຊິ່ງໃຊ້ `try_fold`, ເພາະວ່າການປະຕິບັດທີ່ງ່າຍດາຍນີ້ເຮັດໃຫ້ LLVM IR ຫນ້ອຍລົງແລະໄວກວ່າທີ່ຈະລວບລວມ.
            // ນອກຈາກນີ້, `assume` ຫລີກລ້ຽງການກວດສອບຂອບເຂດ.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // ຄວາມປອດໄພ: ພວກເຮົາໄດ້ຮັບປະກັນວ່າຈະຢູ່ໃນຂອບເຂດໂດຍການຮຸກຮານຂອງ loop:
                        // ເມື່ອ `i >= n`, `self.next()` ກັບຄືນ `None` ແລະວົງຈອນແຕກ.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // ພວກເຮົາ override ການປະຕິບັດໃນຕອນຕົ້ນ, ເຊິ່ງໃຊ້ `try_fold`, ເພາະວ່າການປະຕິບັດທີ່ງ່າຍດາຍນີ້ເຮັດໃຫ້ LLVM IR ຫນ້ອຍລົງແລະໄວກວ່າທີ່ຈະລວບລວມ.
            // ນອກຈາກນີ້, `assume` ຫລີກລ້ຽງການກວດສອບຂອບເຂດ.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // ຄວາມປອດໄພ: `i` ຕ້ອງຕ່ ຳ ກວ່າ `n` ເພາະມັນເລີ່ມຕົ້ນທີ່ `n`
                        // ແລະແມ່ນຫຼຸດລົງເທົ່ານັ້ນ.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `i` ຢູ່ໃນຂອບເຂດ
                // ຊິ້ນສ່ວນທີ່ຕິດພັນ, ສະນັ້ນ `i` ບໍ່ສາມາດລົ້ນ `isize`, ແລະເອກະສານອ້າງອີງທີ່ສົ່ງຄືນແມ່ນຖືກຮັບປະກັນເພື່ອອ້າງອີງເຖິງສ່ວນປະກອບຂອງສ່ວນທີ່ຖືກແລະດັ່ງນັ້ນຈຶ່ງຮັບປະກັນວ່າມັນຖືກຕ້ອງ.
                //
                // ໃຫ້ສັງເກດວ່າຜູ້ໂທຍັງຮັບປະກັນວ່າພວກເຮົາບໍ່ເຄີຍຖືກເອີ້ນດ້ວຍດັດຊະນີດຽວກັນອີກເທື່ອ ໜຶ່ງ, ແລະບໍ່ມີວິທີການອື່ນໃດທີ່ຈະເຂົ້າເຖິງບັນຊີຍ່ອຍນີ້ຖືກເອີ້ນ, ດັ່ງນັ້ນມັນຈຶ່ງຖືກຕ້ອງ ສຳ ລັບເອກະສານອ້າງອີງທີ່ສົ່ງກັບຄືນມາສາມາດສັບປ່ຽນໄດ້ໃນກໍລະນີ
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // ສາມາດປະຕິບັດໄດ້ດ້ວຍທ່ອນ, ແຕ່ວ່ານີ້ຈະຫລີກລ້ຽງການກວດກາຂອບເຂດ

                // ຄວາມປອດໄພ: ການໂທ `assume` ແມ່ນປອດໄພເນື່ອງຈາກຕົວຊີ້ເບື້ອງຕົ້ນຈະຕ້ອງບໍ່ແມ່ນສິ່ງລົບກວນ,
                // ແລະສ່ວນທີ່ບໍ່ແມ່ນ ZST ກໍ່ຕ້ອງມີຕົວຊີ້ທ້າຍທີ່ບໍ່ແມ່ນ null.
                // ການໂທຫາ `next_back_unchecked!` ແມ່ນປອດໄພເພາະວ່າພວກເຮົາກວດເບິ່ງວ່າເຄື່ອງປັບປ່ຽນແມ່ນຫຍັງກ່ອນ.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ເຄື່ອງປັບໂຕນີ້ແມ່ນຫວ່າງແລ້ວ.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // ຄວາມປອດໄພ: ພວກເຮົາຢູ່ໃນຂອບເຂດ.`pre_dec_end` ເຮັດສິ່ງທີ່ຖືກຕ້ອງແມ່ນແຕ່ ສຳ ລັບ ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}