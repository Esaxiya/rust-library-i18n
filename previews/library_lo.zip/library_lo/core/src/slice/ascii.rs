//! ການປະຕິບັດງານກ່ຽວກັບ ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// ໃຫ້ກວດເບິ່ງວ່າໄບ້ທັງ ໝົດ ໃນສ່ວນນີ້ແມ່ນຢູ່ໃນຂອບເຂດ ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// ກວດສອບວ່າສອງທ່ອນແມ່ນການຈັບຄູ່ຄະດີ ASCII.
    ///
    /// ດຽວກັນກັບ `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ແຕ່ວ່າໂດຍບໍ່ມີການຈັດສັນແລະຄັດລອກຕາຕະລາງເວລາ.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// ປ່ຽນຊິ້ນນີ້ເຂົ້າເປັນ ASCII ໂຕໃຫຍ່ທີ່ທຽບເທົ່າກັບສະຖານທີ່.
    ///
    /// ຕົວອັກສອນ ASCII 'a' ກັບ 'z' ແມ່ນ mapped ກັບ 'A' ກັບ 'Z', ແຕ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII ແມ່ນບໍ່ປ່ຽນແປງ.
    ///
    /// ເພື່ອກັບຄືນຄ່າ ໃໝ່ ທີ່ບໍ່ມີມູນຄ່າ ໃໝ່ ໂດຍບໍ່ຕ້ອງດັດແປງຄ່າທີ່ມີຢູ່, ໃຫ້ໃຊ້ [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// ປ່ຽນຊິ້ນນີ້ໃຫ້ເປັນ ASCII ໂຕ ໜັງ ສືຕ່ ຳ ທຽບເທົ່າກັບສະຖານທີ່.
    ///
    /// ຕົວອັກສອນ ASCII 'A' ຫາ 'Z' ຖືກແຕ້ມໃສ່ 'a' ຫາ 'z', ແຕ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII ບໍ່ປ່ຽນແປງ.
    ///
    /// ເພື່ອກັບຄືນມູນຄ່າທີ່ຫຼຸດລົງ ໃໝ່ ໂດຍບໍ່ມີການດັດແປງຂອງທີ່ມີຢູ່, ໃຫ້ໃຊ້ [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// ກັບຄືນ `true` ຖ້າມີ byte ໃນ ຄຳ ວ່າ `v` ແມ່ນ nonascii (>=128).
/// Snarfed ຈາກ `../str/mod.rs`, ເຊິ່ງເຮັດບາງສິ່ງບາງຢ່າງທີ່ຄ້າຍຄືກັນ ສຳ ລັບການພິສູດ utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// ການທົດສອບປະສິດທິພາບ ASCII ທີ່ຈະນໍາໃຊ້ປະຕິບັດງານ usize ຢູ່ທີ່ໃຊ້ເວລາແທນທີ່ຈະເປັນການດໍາເນີນງານ byte ຢູ່ທີ່ໃຊ້ເວລາ (ເວລາທີ່ເປັນໄປໄດ້).
///
/// ສູດການຄິດໄລ່ທີ່ພວກເຮົາໃຊ້ຢູ່ນີ້ແມ່ນງ່າຍດາຍຫຼາຍ.ຖ້າ `s` ສັ້ນເກີນໄປ, ພວກເຮົາພຽງແຕ່ກວດເບິ່ງແຕ່ລະໄບຕ໌ແລະເຮັດກັບມັນ.ຖ້າບໍ່ດັ່ງນັ້ນ:
///
/// - ອ່ານ ຄຳ ທຳ ອິດດ້ວຍການໂຫຼດທີ່ບໍ່ໄດ້ເຊັນ.
/// - ຈັດຮຽງຕົວຊີ້, ອ່ານ ຄຳ ຕໍ່ໆໄປຈົນກ່ວາສິ້ນສຸດດ້ວຍການໂຫຼດທີ່ສອດຄ່ອງ.
/// - ອ່ານ `usize` ສຸດທ້າຍຈາກ `s` ດ້ວຍການໂຫຼດທີ່ບໍ່ໄດ້ຕັ້ງຄ່າ.
///
/// ຖ້າຫາກວ່າບັນດາພາລະເຫຼົ່ານີ້ຜະລິດບາງສິ່ງບາງຢ່າງທີ່ `contains_nonascii` (above) ກັບຄືນມາເປັນຄວາມຈິງ, ແລ້ວພວກເຮົາຮູ້ວ່າ ຄຳ ຕອບແມ່ນບໍ່ຖືກຕ້ອງ.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // ຖ້າພວກເຮົາຈະບໍ່ໄດ້ຮັບຫຍັງຈາກການປະຕິບັດ ຄຳ ສັບໃນເວລາ, ໃຫ້ກັບຄືນໄປຫາວົງກາບ.
    //
    // ພວກເຮົາຍັງເຮັດສິ່ງນີ້ ສຳ ລັບສະຖາປັດຕະຍະ ກຳ ທີ່ `size_of::<usize>()` ບໍ່ມີຄວາມສອດຄ່ອງພຽງພໍ ສຳ ລັບ `usize`, ເພາະວ່າມັນເປັນກໍລະນີ edge ທີ່ແປກ.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // ພວກເຮົາມັກອ່ານ ຄຳ ທຳ ອິດທີ່ບໍ່ໄດ້ລົງນາມ, ໝາຍ ຄວາມວ່າ `align_offset` ແມ່ນ
    // 0, ພວກເຮົາຈະອ່ານຄຸນຄ່າດຽວກັນອີກເທື່ອ ໜຶ່ງ ສຳ ລັບການອ່ານທີ່ສອດຄ່ອງ.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // ຄວາມປອດໄພ: ພວກເຮົາກວດສອບ `len < USIZE_SIZE` ຂ້າງເທິງ.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // ພວກເຮົາໄດ້ກວດກາເບິ່ງຂ້າງເທິງນີ້, ບາງຢ່າງໂດຍສະເພາະ.
    // ໃຫ້ສັງເກດວ່າ `offset_to_aligned` ແມ່ນ `align_offset` ຫຼື `USIZE_SIZE`, ທັງສອງຖືກກວດເບິ່ງຢ່າງຊັດເຈນຂ້າງເທິງ.
    //
    debug_assert!(offset_to_aligned <= len);

    // ຄວາມປອດໄພ: word_ptr ແມ່ນ ptr ທີ່ມີຄວາມສອດຄ່ອງ ເໝາະ ສົມທີ່ພວກເຮົາໃຊ້ເພື່ອອ່ານ
    // ຄອກກາງຂອງຊອຍ.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` ແມ່ນດັດຊະນີ byte ຂອງ `word_ptr`, ໃຊ້ ສຳ ລັບການກວດສອບ loop end.
    let mut byte_pos = offset_to_aligned;

    // Paranoia ກວດເບິ່ງກ່ຽວກັບຄວາມສອດຄ່ອງ, ເນື່ອງຈາກວ່າພວກເຮົາ ກຳ ລັງຈະເຮັດພາລະ ໜັກ ທີ່ບໍ່ໄດ້ມາດຕະຖານ.
    // ໃນການປະຕິບັດສິ່ງນີ້ຄວນຈະເປັນໄປບໍ່ໄດ້ທີ່ຈະກີດຂວາງຂໍ້ບົກພ່ອງໃນ `align_offset` ເຖິງແມ່ນວ່າ.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // ອ່ານ ຄຳ ຕໍ່ໆໄປຈົນກ່ວາ ຄຳ ທີ່ຈັດລຽນສຸດທ້າຍ, ຍົກເວັ້ນ ຄຳ ທີ່ຈັດລຽນສຸດທ້າຍໂດຍຕົວຂອງມັນເອງທີ່ຕ້ອງເຮັດໃນການກວດຫາງໃນພາຍຫລັງ, ເພື່ອຮັບປະກັນວ່າຫາງແມ່ນສະເຫມີເປັນ `usize` ສ່ວນຫຼາຍຈະເປັນພິເສດ branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // ສຸຂາພິບານກວດເບິ່ງວ່າການອ່ານຢູ່ໃນຂອບເຂດ
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // ແລະວ່າການສົມມຸດຕິຖານຂອງພວກເຮົາກ່ຽວກັບ `byte_pos` ຖື.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // ຄວາມປອດໄພ: ພວກເຮົາຮູ້ວ່າ `word_ptr` ຖືກຈັດຮຽງໃຫ້ຖືກຕ້ອງ (ເພາະ
        // `align_offset`), ແລະພວກເຮົາຮູ້ວ່າພວກເຮົາມີໄບຕ໌ພຽງພໍລະຫວ່າງ `word_ptr` ແລະສຸດທ້າຍ
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // ຄວາມປອດໄພ: ພວກເຮົາຮູ້ວ່າ `byte_pos <= len - USIZE_SIZE`, ຊຶ່ງຫມາຍຄວາມວ່າ
        // ຫຼັງຈາກ `add` ນີ້, `word_ptr` ຈະມີຫຼາຍທີ່ສຸດໃນອະດີດ.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // ກວດສຸຂະພາບເພື່ອຮັບປະກັນວ່າມັນມີພຽງແຕ່ `usize` ດຽວເທົ່ານັ້ນ.
    // ນີ້ຄວນຈະຖືກຮັບປະກັນໂດຍສະພາບຂອງ loop ຂອງພວກເຮົາ.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // ຄວາມປອດໄພ: ສິ່ງນີ້ຂື້ນກັບ `len >= USIZE_SIZE`, ເຊິ່ງພວກເຮົາກວດເບິ່ງຕອນເລີ່ມຕົ້ນ.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}