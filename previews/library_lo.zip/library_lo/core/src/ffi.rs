#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! ຜົນປະໂຫຍດທີ່ກ່ຽວຂ້ອງກັບການເຊື່ອມໂຍງການເຮັດວຽກຂອງຕ່າງປະເທດ (FFI) ຜູກມັດ.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// ເທົ່າກັບປະເພດ C ຂອງ `void` ເມື່ອໃຊ້ເປັນ [pointer].
///
/// ໂດຍເນື້ອແທ້ແລ້ວ, `*const c_void` ແມ່ນທຽບເທົ່າກັບຂອງ C `const void*` ແລະ `*mut c_void` ແມ່ນທຽບເທົ່າກັບຂອງ C `void*`.
/// ທີ່ກ່າວມານີ້ແມ່ນ *ບໍ່* ຄືກັນກັບ `void` ປະເພດຜົນຕອບແທນພຣະ C, ຊຶ່ງເປັນ Rust ຂອງປະເພດ `()`.
///
/// ເພື່ອເປັນຕົວແບບຊີ້ໃຫ້ເຫັນປະເພດທີ່ລຽບງ່າຍໃນ FFI, ຈົນກ່ວາ `extern type` ມີສະຖຽນລະພາບ, ມັນໄດ້ຖືກແນະ ນຳ ໃຫ້ໃຊ້ຫໍ່ newtype ປະມານແຖວ byte ເປົ່າ.
///
/// ເບິ່ງ [Nomicon] ສຳ ລັບລາຍລະອຽດ.
///
/// ຫນຶ່ງສາມາດນໍາໃຊ້ `std::os::raw::c_void` ຖ້າຫາກພວກເຂົາຕ້ອງການທີ່ຈະສະຫນັບສະຫນູນອາຍຸ Rust compiler ລົງ 1.1.0.
/// ຫຼັງຈາກ Rust 1.30.0, ມັນໄດ້ສົ່ງອອກໂດຍຄໍານິຍາມນີ້.
/// ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ, ກະລຸນາອ່ານ [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, ເພື່ອໃຫ້ LLVM ຮັບຮູ້ປະເພດຕົວຊີ້ຂາດແລະໂດຍ ໜ້າ ທີ່ຂະຫຍາຍເຊັ່ນ malloc(), ພວກເຮົາຕ້ອງມີຕົວແທນໃຫ້ເປັນ i8 * ໃນລະຫັດບິດ LLVM.
// The enum ທີ່ໃຊ້ຢູ່ນີ້ຮັບປະກັນສິ່ງນີ້ແລະປ້ອງກັນການໃຊ້ "raw" ປະເພດທີ່ບໍ່ຖືກຕ້ອງໂດຍມີພຽງແຕ່ຕົວແປສ່ວນຕົວເທົ່ານັ້ນ.
// ພວກເຮົາຕ້ອງການຕົວແປສອງຢ່າງ, ເພາະວ່ານັກຂຽນຈະຈົ່ມກ່ຽວກັບຄຸນລັກສະນະ repr ຖ້າບໍ່ດັ່ງນັ້ນແລະພວກເຮົາຕ້ອງການຕົວແປຢ່າງ ໜ້ອຍ ໜຶ່ງ ຢ່າງຖ້າບໍ່ດັ່ງນັ້ນ enum ຈະບໍ່ມີຜູ້ຢູ່ອາໄສແລະຢ່າງ ໜ້ອຍ ການອ້າງເຖິງຈຸດດັ່ງກ່າວກໍ່ຈະເປັນ UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// ການປະຕິບັດຂັ້ນພື້ນຖານຂອງ `va_list`.
// ຊື່ແມ່ນ WIP, ໃຊ້ `VaListImpl` ສຳ ລັບດຽວນີ້.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Invariant ຫຼາຍກວ່າ `'f`, ສະນັ້ນແຕ່ລະວັດຖຸ `VaListImpl<'f>` ແມ່ນຖືກຜູກກັບພາກພື້ນຂອງ ໜ້າ ທີ່ທີ່ມັນຖືກ ກຳ ນົດໄວ້
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ການປະຕິບັດ ABI ຂອງ `va_list`.
/// ເບິ່ງ [AArch64 Procedure Call Standard] ສໍາລັບລາຍລະອຽດເພີ່ມເຕີມ.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ການປະຕິບັດ ABI ຂອງ `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ການປະຕິບັດ ABI ຂອງ `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// A wrapper ສໍາລັບ `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// ແປງເປັນ `VaListImpl` ໃນ `VaList` ທີ່ເປັນ binary, ເຫມາະສົມກັບຂອງ C `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// ແປງເປັນ `VaListImpl` ໃນ `VaList` ທີ່ເປັນ binary, ເຫມາະສົມກັບຂອງ C `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// ຕ້ອງມີການໃຊ້ VaArgSafe trait ໃນອິນເຕີເຟດສາທາລະນະ, ເຖິງຢ່າງໃດກໍ່ຕາມ, trait ເອງກໍ່ບໍ່ຄວນຖືກອະນຸຍາດໃຫ້ ນຳ ໃຊ້ນອກໂມດູນນີ້.
// ອະນຸຍາດໃຫ້ຜູ້ໃຊ້ສາມາດປະຕິບັດໄດ້ trait ສໍາລັບຊະນິດໃຫມ່ (ຊຶ່ງມັນໃຫ້ intrinsic va_arg ໃນການໄດ້ຮັບການນໍາໃຊ້ໃນປະເພດໃຫມ່) ອາດຈະເຮັດໃຫ້ພຶດຕິກໍາ undefined.
//
// FIXME(dlrobertson): ໃນຄໍາສັ່ງທີ່ຈະນໍາໃຊ້ໄດ້ VaArgSafe trait ໃນການໂຕ້ຕອບສາທາລະນະແຕ່ຍັງຮັບປະກັນວ່າມັນບໍ່ສາມາດຖືກນໍາໃຊ້ຢູ່ບ່ອນອື່ນ, ການ trait ຕ້ອງສາທາລະນະພາຍໃນໂມດູນສ່ວນຕົວ.
// ເມື່ອ RFC 2145 ໄດ້ຖືກຈັດຕັ້ງປະຕິບັດເຂົ້າໃນການປັບປຸງສິ່ງນີ້.
//
//
//
//
mod sealed_trait {
    /// Trait ທີ່ອະນຸຍາດໃຫ້ໃຊ້ປະເພດທີ່ອະນຸຍາດໃຫ້ໃຊ້ກັບ [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// ຄວາມກ້າວຫນ້າເພື່ອ arg ຕໍ່ໄປ.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `va_arg`.
        unsafe { va_arg(self) }
    }

    /// ສໍາເນົາໄດ້ `va_list` ຢູ່ສະຖານທີ່ໃນປະຈຸບັນ.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // ຄວາມປອດໄພ: ພວກເຮົາຂຽນເຖິງ `MaybeUninit`, ດັ່ງນັ້ນມັນແມ່ນເບື້ອງຕົ້ນແລະ `assume_init` ແມ່ນຖືກກົດ ໝາຍ
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ນີ້ຄວນໂທຫາ `va_end`, ແຕ່ວ່າບໍ່ມີທາງທີ່ສະອາດ
        // ຮັບປະກັນວ່າ `drop` ສະເຫມີໄດ້ຮັບເຂົ້າໄປໃນ inlined ແປໄດ້ທຸຂອງຕົນ, ສະນັ້ນການ `va_end` ຈະໄດ້ຮັບເອີ້ນວ່າໂດຍກົງຈາກການທໍາງານຂອງເຊັ່ນດຽວກັນກັບ `va_copy` ທີ່ສອດຄ້ອງກັນ.
        // `man va_end` ລັດທີ່ຮຽກຮ້ອງໃຫ້ມີ C ດັ່ງກ່າວນີ້, ແລະ LLVM ສາຂັ້ນພື້ນຖານດັ່ງຕໍ່ໄປນີ້ຄວາມຫມາຍ C ໄດ້, ດັ່ງນັ້ນພວກເຮົາຈໍາເປັນຕ້ອງໄດ້ເຮັດໃຫ້ແນ່ໃຈວ່າ `va_end` ສະເຫມີເອີ້ນວ່າມາຈາກການທໍາງານຂອງເຊັ່ນດຽວກັນກັບ `va_copy`.
        //
        // ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // ສິ່ງນີ້ເຮັດວຽກໄດ້ ສຳ ລັບດຽວນີ້, ເພາະວ່າ `va_end` ແມ່ນບໍ່ມີຈຸດປະສົງເປົ້າ ໝາຍ LLVM ທັງ ໝົດ ໃນປະຈຸບັນ.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// ທຳ ລາຍ ຄຳ ໂຕ້ຖຽງ `ap` ຫຼັງຈາກເລີ່ມຕົ້ນດ້ວຍ `va_start` ຫຼື `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// ສໍາເນົາສະຖານທີ່ໃນປະຈຸບັນຂອງ arglist `src` ກັບ arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// ໂຫຼດການໂຕ້ຖຽງຂອງປະເພດ `T` ຈາກ `va_list` `ap` ແລະເພີ່ມທະວີການໂຕ້ຖຽງ `ap` ຊີ້ໄປ.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}