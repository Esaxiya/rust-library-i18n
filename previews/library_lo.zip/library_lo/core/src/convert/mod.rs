//! Traits ສຳ ລັບການແປງລະຫວ່າງປະເພດຕ່າງໆ.
//!
//! traits ໃນໂມດູນນີ້ໃຫ້ວິທີການປ່ຽນຈາກແບບ ໜຶ່ງ ໄປຫາອີກປະເພດ ໜຶ່ງ.
//! ແຕ່ລະ trait ໃຫ້ບໍລິການຈຸດປະສົງທີ່ແຕກຕ່າງກັນ:
//!
//! - ປະຕິບັດ [`AsRef`] trait ສຳ ລັບການປ່ຽນເອກະສານອ້າງອີງລາຄາຖືກ
//! - ຈັດຕັ້ງປະຕິບັດ [`AsMut`] trait ສຳ ລັບການແລກປ່ຽນກັບກັນແລະກັນແລະກັນ
//! - ຈັດຕັ້ງປະຕິບັດ [`From`] trait ສຳ ລັບການປ່ຽນໃຈເຫລື້ອມໃສທີ່ມີມູນຄ່າ
//! - ປະຕິບັດ [`Into`] trait ສໍາລັບການຊົມໃຊ້ການສົນທະນາມູນຄ່າທີ່ຈະມີມູນຄ່າປະເພດພາຍນອກ crate ໃນປະຈຸບັນ
//! - The [`TryFrom`] ແລະ [`TryInto`] traits ປະຕິບັດຕົວຄື [`From`] ແລະ [`Into`], ແຕ່ຄວນໄດ້ຮັບການປະຕິບັດໃນເວລາທີ່ປ່ຽນໃຈເຫລື້ອມໃສສາມາດເຊັ່ນການແລກ.
//!
//! traits ໃນໂມດູນນີ້ມັກຖືກໃຊ້ເປັນ trait bounds ສຳ ລັບ ໜ້າ ທີ່ແບບທົ່ວໆໄປເຊັ່ນວ່າການໂຕ້ຖຽງຂອງຫຼາຍປະເພດແມ່ນຖືກສະ ໜັບ ສະ ໜູນ.ເບິ່ງເອກະສານຂອງແຕ່ລະ trait ສຳ ລັບຕົວຢ່າງ.
//!
//! ໃນຖານະທີ່ເປັນຜູ້ຂຽນຫໍສະ ໝຸດ, ທ່ານຄວນມັກການຈັດຕັ້ງປະຕິບັດ [`From<T>`][`From`] ຫຼື [`TryFrom<T>`][`TryFrom`] ຫຼາຍກ່ວາ [`Into<U>`][`Into`] ຫຼື [`TryInto<U>`][`TryInto`], ເພາະວ່າ [`From`] ແລະ [`TryFrom`] ໃຫ້ຄວາມຍືດຫຍຸ່ນຫຼາຍຂື້ນແລະສະ ເໜີ ການຈັດຕັ້ງປະຕິບັດທຽບເທົ່າ [`Into`] ຫຼື [`TryInto`] ໂດຍບໍ່ເສຍຄ່າ, ຍ້ອນການປະຕິບັດຜ້າຫົ່ມໃນຫໍສະມຸດມາດຕະຖານ.
//! ໃນເວລາທີ່ ກຳ ນົດເປົ້າ ໝາຍ ຮຸ່ນກ່ອນ Rust 1.41, ມັນອາດຈະ ຈຳ ເປັນຕ້ອງຈັດຕັ້ງປະຕິບັດ [`Into`] ຫຼື [`TryInto`] ໂດຍກົງເມື່ອປ່ຽນເປັນປະເພດທີ່ຢູ່ນອກ crate ປັດຈຸບັນ.
//!
//! # generic ການປະຕິບັດ
//!
//! - [`AsRef`] ແລະ [`AsMut`] ອັດຕະໂນມັດ dereference ຖ້າຊະນິດໃນແມ່ນກະສານອ້າງອີງ
//! - [`ຈາກ`] `<U>ສຳ ລັບ T` ໝາຍ ເຖິງ [`ເຂົ້າໄປໃນ]`</u><T><U>ສໍາລັບ U`</u>
//! - [`TryFrom`] `<U>ສຳ ລັບ T` ໝາຍ ຄວາມວ່າ [`TryInto`]`</u><T><U>ສຳ ລັບ U`</u>
//! - [`From`] ແລະ [`Into`] ແມ່ນປີ້ນ, ເຊິ່ງ ໝາຍ ຄວາມວ່າທຸກຊະນິດສາມາດ `into` ຕົວເອງແລະ `from` ດ້ວຍຕົນເອງ
//!
//! ເບິ່ງແຕ່ລະ trait ສໍາລັບຕົວຢ່າງການນໍາໃຊ້.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// ໜ້າ ທີ່ຕົວຕົນ.
///
/// ສອງອັນໃດສໍາຄັນທີ່ຈະສັງເກດກ່ຽວກັບການທໍາງານນີ້:
///
/// - ມັນບໍ່ແມ່ນສະເຫມີໄປທຽບເທົ່າກັບປິດຄື `|x| x` ເປັນ, ນັບຕັ້ງແຕ່ການປິດອາດບັງຄັບ `x` ເຂົ້າໄປໃນປະເພດທີ່ແຕກຕ່າງກັນ.
///
/// - ມັນຍ້າຍວັດສະດຸປ້ອນ `x` ທີ່ສົ່ງຜ່ານໄປທີ່ ໜ້າ ທີ່.
///
/// ໃນຂະນະທີ່ມັນອາດເບິ່ງຄືວ່າເປັນເລື່ອງແປກທີ່ຈະມີ ໜ້າ ທີ່ທີ່ຈະກັບຄືນການປ້ອນຂໍ້ມູນເຂົ້າ, ມັນມີບາງການ ນຳ ໃຊ້ທີ່ ໜ້າ ສົນໃຈ.
///
///
/// # Examples
///
/// ການໃຊ້ `identity` ເພື່ອເຮັດຫຍັງໃນ ລຳ ດັບຂອງ ໜ້າ ທີ່ອື່ນໆ, ໜ້າ ສົນໃຈ,:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // ໃຫ້ທໍາທ່າວ່າເພີ່ມຫນຶ່ງເປັນຟັງຊັ່ນທີ່ຫນ້າສົນໃຈ.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// ການ ນຳ ໃຊ້ `identity` ເປັນກໍລະນີຖານ "do nothing" ໃນເງື່ອນໄຂ:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // ເຮັດ stuff ທີ່ຫນ້າສົນໃຈຫຼາຍ ...
///
/// let _results = do_stuff(42);
/// ```
///
/// ການນໍາໃຊ້ `identity` ທີ່ຈະຮັກສາ `Some` variants ຂອງ iterator ຂອງ `Option<T>` ເປັນ:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// ການນໍາໃຊ້ເພື່ອເຮັດແນວໃດປ່ຽນໃຈເຫລື້ອມໃສກະສານອ້າງອີງ, ການກະສານອ້າງອີງລາຄາຖືກ.
///
/// trait ນີ້ແມ່ນຄ້າຍຄືກັນກັບ [`AsMut`] ທີ່ຖືກນໍາໃຊ້ສໍາລັບການເປັນລະຫວ່າງເອກະສານທີ່ບໍ່ແນ່ນອນ.
/// ຖ້າຫາກວ່າທ່ານຕ້ອງການທີ່ຈະເຮັດແນວໃດປ່ຽນໃຈເຫລື້ອມໃສຄ່າໃຊ້ຈ່າຍມັນເປັນທີ່ດີກວ່າທີ່ຈະໃຊ້ [`From`] ກັບປະເພດ `&T` ຫຼືຂຽນຫນ້າ custom ເປັນ.
///
/// `AsRef` ມີລາຍເຊັນຄືກັນກັບ [`Borrow`], ແຕ່ [`Borrow`] ແມ່ນແຕກຕ່າງກັນໃນສອງສາມດ້ານ:
///
/// - ບໍ່ຄືກັບ `AsRef`, [`Borrow`] ມີຜ້າຫົ່ມທີ່ບົ່ງບອກເຖິງ `T` ໃດໆ, ແລະສາມາດຖືກ ນຳ ໃຊ້ເພື່ອຮັບເອົາເອກະສານອ້າງອີງຫຼືມູນຄ່າ.
/// - [`Borrow`] ພ້ອມທັງຮຽກຮ້ອງໃຫ້ [`Hash`], [`Eq`] ແລະ [`Ord`] ສຳ ລັບມູນຄ່າທີ່ຢືມແມ່ນເທົ່າກັບມູນຄ່າຂອງເຈົ້າຂອງ.
/// ດ້ວຍເຫດຜົນນີ້, ຖ້າທ່ານຕ້ອງການກູ້ຢືມເງິນພຽງແຕ່ສະ ໜາມ ດຽວຂອງໂຄງສ້າງ, ທ່ານສາມາດປະຕິບັດ `AsRef`, ແຕ່ບໍ່ແມ່ນ [`Borrow`].
///
/// **Note: trait ນີ້ຕ້ອງໄດ້ຫຼົ້ມເຫຼວ **.ຖ້າປ່ຽນໃຈເຫລື້ອມໃສສາມາດເຊັ່ນການແລກປ່ຽນ, ການນໍາໃຊ້ວິທີການທີ່ອຸທິດຕົນທີ່ຈະກັບຄືນມາເປັນ [`Option<T>`] ຫຼື [`Result<T, E>`].
///
/// # generic ການປະຕິບັດ
///
/// - `AsRef` ອັດຕະໂນມັດ dereferences ຖ້າຊະນິດໃນແມ່ນກະສານອ້າງອີງຫຼືກະສານອ້າງອີງທີ່ບໍ່ແນ່ນອນ (ເຊັ່ນ: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// ໂດຍການໃຊ້ trait bounds ພວກເຮົາສາມາດຍອມຮັບການໂຕ້ຖຽງຂອງປະເພດຕ່າງໆໄດ້ຕາບໃດທີ່ພວກມັນສາມາດປ່ຽນເປັນ `T` ປະເພດທີ່ລະບຸໄດ້.
///
/// ຕົວຢ່າງ: ໂດຍການສ້າງ ໜ້າ ທີ່ແບບທົ່ວໆໄປທີ່ເອົາ `AsRef<str>` ພວກເຮົາສະແດງວ່າພວກເຮົາຕ້ອງການຍອມຮັບເອົາເອກະສານອ້າງອີງທັງ ໝົດ ທີ່ສາມາດປ່ຽນເປັນ [`&str`] ເປັນການໂຕ້ຖຽງ.
/// ນັບຕັ້ງແຕ່ທັງສອງ [`String`] ແລະ [`&str`] ໃຊ້ `AsRef<str>` ພວກເຮົາສາມາດຍອມຮັບທັງເປັນການໂຕ້ຖຽງວັດສະດຸປ້ອນ.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// ດໍາເນີນການປ່ຽນແປງ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// ການນໍາໃຊ້ເພື່ອເຮັດເປັນບໍ່ແນ່ນອນທີ່ຈະມີການປ່ຽນຮູບປ່ຽນໃຈເຫລື້ອມໃສອ້າງອິງລາຄາຖືກ.
///
/// trait ນີ້ແມ່ນຄ້າຍຄືກັບ [`AsRef`] ແຕ່ຖືກໃຊ້ ສຳ ລັບການປ່ຽນລະຫວ່າງການອ້າງອີງທີ່ປ່ຽນແປງໄດ້.
/// ຖ້າຫາກວ່າທ່ານຕ້ອງການທີ່ຈະເຮັດແນວໃດປ່ຽນໃຈເຫລື້ອມໃສຄ່າໃຊ້ຈ່າຍມັນເປັນທີ່ດີກວ່າທີ່ຈະໃຊ້ [`From`] ກັບປະເພດ `&mut T` ຫຼືຂຽນຫນ້າ custom ເປັນ.
///
/// **Note: trait ນີ້ຕ້ອງໄດ້ຫຼົ້ມເຫຼວ **.ຖ້າປ່ຽນໃຈເຫລື້ອມໃສສາມາດເຊັ່ນການແລກປ່ຽນ, ການນໍາໃຊ້ວິທີການທີ່ອຸທິດຕົນທີ່ຈະກັບຄືນມາເປັນ [`Option<T>`] ຫຼື [`Result<T, E>`].
///
/// # generic ການປະຕິບັດ
///
/// - `AsMut` ອັດຕະໂນມັດ dereferences ຖ້າຊະນິດໃນແມ່ນກະສານອ້າງອີງທີ່ບໍ່ແນ່ນອນ (ເຊັ່ນ: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// ການນໍາໃຊ້ `AsMut` ເປັນ trait bound ສໍາລັບການທໍາງານຂອງ generic ພວກເຮົາສາມາດຮັບເອົາເອກະສານທີ່ບໍ່ແນ່ນອນທັງຫມົດທີ່ສາມາດໄດ້ຮັບການປ່ຽນໃຈເຫລື້ອມໃສພິມ `&mut T`.
/// ເນື່ອງຈາກວ່າ [`Box<T>`] ດໍາເນີນ `AsMut<T>` ພວກເຮົາສາມາດຂຽນເປັນການທໍາງານຂອງ `add_one` ທີ່ໃຊ້ເວລາການໂຕ້ຖຽງທັງຫມົດທີ່ສາມາດໄດ້ຮັບການປ່ຽນໃຈເຫລື້ອມໃສ `&mut u64`.
/// ເນື່ອງຈາກວ່າ [`Box<T>`] ດໍາເນີນ `AsMut<T>`, `add_one` ຮັບການໂຕ້ຖຽງຂອງປະເພດ `&mut Box<u64>` ເຊັ່ນດຽວກັນ:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// ດໍາເນີນການປ່ຽນແປງ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// ການສົນທະນາມູນຄ່າທີ່ຈະມີມູນຄ່າທີ່ consumes ມູນຄ່າວັດຖຸດິບ.ກົງກັນຂ້າມຂອງ [`From`].
///
/// ຫນຶ່ງຄວນຫຼີກເວັ້ນການປະຕິບັດ [`Into`] ແລະໃຊ້ [`From`] ແທນທີ່ຈະ.
/// ການປະຕິບັດ [`From`] ອັດຕະໂນມັດສະຫນອງການປະຕິບັດຫນຶ່ງຂອງ [`Into`] ຂໍຂອບໃຈກັບການປະຕິບັດຜ້າຫົ່ມໃນຫ້ອງສະຫມຸດມາດຕະຖານ.
///
/// ຕ້ອງການການນໍາໃຊ້ໃນໄລຍະ [`Into`] [`From`] ໃນເວລາທີ່ລະບຸ trait bounds ກ່ຽວກັບການທໍາງານຂອງ generic ເພື່ອຮັບປະກັນວ່າຊະນິດທີ່ປະຕິບັດພຽງແຕ່ [`Into`] ສາມາດຖືກນໍາໃຊ້ເຊັ່ນດຽວກັນ.
///
/// **Note: trait ນີ້ຕ້ອງບໍ່ລົ້ມເຫຼວ **.ຖ້າປ່ຽນໃຈເຫລື້ອມໃສສາມາດເຊັ່ນການແລກປ່ຽນ, ການນໍາໃຊ້ [`TryInto`].
///
/// # generic ການປະຕິບັດ
///
/// - [`ຈາກ`] `<T>ສໍາລັບ U` ແດງໃຫ້ເຫັນເຖິງ `Into<U> for T`
/// - [`Into`] ແມ່ນປີ້ນ, ຊຶ່ງຫມາຍຄວາມວ່າ `Into<T> for T` ຖືກປະຕິບັດ
///
/// # ປະຕິບັດ [`Into`] ອັດຕາແລກປ່ຽນກັບປະເພດພາຍນອກໃນສະບັບເກົ່າຂອງ Rust
///
/// ກ່ອນທີ່ຈະ Rust 1.41, ຖ້າປະເພດປາຍທາງບໍ່ແມ່ນສ່ວນ ໜຶ່ງ ຂອງ crate ປັດຈຸບັນທ່ານກໍ່ບໍ່ສາມາດຈັດຕັ້ງປະຕິບັດ [`From`] ໂດຍກົງ.
/// ຍົກຕົວຢ່າງ, ເອົາລະຫັດນີ້:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// ນີ້ຈະບໍ່ສາມາດສັງລວມໃນສະບັບຂຶ້ນໄປຂອງພາສາເນື່ອງຈາກວ່າ Rust ຂອງກົດລະບຽບເປັນເດັກກໍາພ້ານໍາໃຊ້ເພື່ອຈະມີຄວາມນ້ອຍພຽງເລັກນ້ອຍທີ່ເຂັ້ມງວດຫລາຍ.
/// ເພື່ອຂ້າມສິ່ງນີ້, ທ່ານສາມາດຈັດຕັ້ງປະຕິບັດ [`Into`] ໂດຍກົງ:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// ມັນເປັນສິ່ງສໍາຄັນທີ່ຈະເຂົ້າໃຈວ່າ [`Into`] ບໍ່ໃຫ້ການປະຕິບັດ [`From`] (ເປັນ [`From`] ບໍ່ມີ [`Into`]).
/// ສະນັ້ນ, ທ່ານຄວນພະຍາຍາມປະຕິບັດ [`From`] ຢູ່ສະ ເໝີ ແລະຫຼັງຈາກນັ້ນກໍ່ຈະກັບມາ [`Into`] ຖ້າ [`From`] ບໍ່ສາມາດປະຕິບັດໄດ້.
///
/// # Examples
///
/// [`String`] ການປະຕິບັດ [`ເຂົ້າໄປໃນ]` <`[` Vec]] `<` [`u8`] `>:
///
/// ເພື່ອສະແດງອອກວ່າພວກເຮົາຕ້ອງການໃຫ້ ໜ້າ ທີ່ແບບ ທຳ ມະດາເອົາການໂຕ້ຖຽງທັງ ໝົດ ທີ່ສາມາດປ່ຽນເປັນ `T` ປະເພດທີ່ລະບຸໄດ້, ພວກເຮົາສາມາດໃຊ້ trait bound ຂອງ [`ເຂົ້າໄປໃນ`] `<T>`.
///
/// ສໍາລັບຕົວຢ່າງເຊັ່ນ: ການທໍາງານ `is_hello` ໃຊ້ເວລາການໂຕ້ຖຽງທັງຫມົດທີ່ສາມາດໄດ້ຮັບການປ່ຽນແປງໄປສູ່ [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// ດໍາເນີນການປ່ຽນແປງ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// ໃຊ້ເພື່ອເຮັດການສົນທະນາທີ່ມີຄຸນຄ່າໃນຂະນະທີ່ຊົມໃຊ້ມູນຄ່າການປ້ອນຂໍ້ມູນ.ມັນແມ່ນຕ່າງຝ່າຍຕ່າງຂອງ [`Into`].
///
/// ຫນຶ່ງສະເຫມີຄວນຈະຕ້ອງປະຕິບັດໃນໄລຍະ `From` [`Into`] ເນື່ອງຈາກວ່າການປະຕິບັດອັດຕະໂນມັດ `From` ໃຫ້ຫນຶ່ງກັບການປະຕິບັດຂອງ [`Into`] ຂໍຂອບໃຈກັບການປະຕິບັດຜ້າຫົ່ມໃນຫ້ອງສະຫມຸດມາດຕະຖານ.
///
///
/// ປະຕິບັດ [`Into`] ເທົ່ານັ້ນເມື່ອຕັ້ງເປົ້າ ໝາຍ ລຸ້ນກ່ອນ Rust 1.41 ແລະປ່ຽນເປັນປະເພດ ໜຶ່ງ ທີ່ຢູ່ນອກ crate ປະຈຸບັນ.
/// `From` ແມ່ນບໍ່ສາມາດທີ່ຈະເຮັດແນວໃດປະເພດເຫຼົ່ານີ້ຂອງການສົນທະນາໃນສະບັບກ່ອນຫນ້ານີ້ເນື່ອງຈາກວ່າກົດລະບຽບເປັນເດັກກໍາພ້າ Rust ຂອງ.
/// ເບິ່ງ [`Into`] ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
///
/// ຕ້ອງການການນໍາໃຊ້ໃນໄລຍະ [`Into`] ໃຊ້ `From` ໃນເວລາທີ່ລະບຸ trait bounds ກ່ຽວກັບການທໍາງານຂອງທົ່ວໄປ.
/// ວິທີການດັ່ງກ່າວນີ້, ປະເພດທີ່ປະຕິບັດໂດຍກົງ [`Into`] ສາມາດໄດ້ຮັບການນໍາໃຊ້ເປັນການໂຕ້ຖຽງເຊັ່ນດຽວກັນ.
///
/// The `From` ຍັງເປັນປະໂຫຍດຫຼາຍໃນເວລາທີ່ປະຕິບັດຮັກສາຫຼັງຄວາມຜິດພາດ.ໃນເວລາທີ່ການສ້າງການທໍາງານຂອງທີ່ສາມາດເກີດຄວາມລົ້ມເຫລວ, ປະເພດຄືນໂດຍທົ່ວໄປແລ້ວຈະມີຄວາມຮູບແບບ `Result<T, E>` ໄດ້.
/// `From` trait ເຮັດໃຫ້ການຈັດການກັບຄວາມຜິດພາດງ່າຍຂື້ນໂດຍໃຫ້ການເຮັດວຽກກັບຄືນປະເພດຂໍ້ຜິດພາດດຽວທີ່ເກັບ ກຳ ຂໍ້ຜິດພາດຫຼາຍປະເພດ.ເບິ່ງພາກ "Examples" ແລະ [the book][book] ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
///
/// **Note: trait ນີ້ຕ້ອງບໍ່ລົ້ມເຫຼວ **.ຖ້າການປ່ຽນໃຈເຫລື້ອມໃສສາມາດລົ້ມເຫລວ, ໃຊ້ [`TryFrom`].
///
/// # generic ການປະຕິບັດ
///
/// - `From<T> for U` ໝາຍ ເຖິງ [`ເຂົ້າໄປໃນ]` <U>ສຳ ລັບ T`</u>
/// - `From` ແມ່ນປີ້ນ, ຊຶ່ງຫມາຍຄວາມວ່າ `From<T> for T` ຖືກປະຕິບັດ
///
/// # Examples
///
/// [`String`] ປະຕິບັດ `From<&str>`:
///
/// ການປ່ຽນໃຈເຫລື້ອມໃສຢ່າງຊັດເຈນຈາກ `&str` ເປັນ String ແມ່ນເຮັດດັ່ງຕໍ່ໄປນີ້:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// ໃນຂະນະທີ່ປະຕິບັດການແກ້ໄຂຂໍ້ຜິດພາດມັນມັກຈະເປັນປະໂຫຍດທີ່ຈະປະຕິບັດ `From` ສຳ ລັບປະເພດຂໍ້ຜິດພາດຂອງທ່ານເອງ.
/// ໂດຍການປ່ຽນປະເພດຂໍ້ຜິດພາດທີ່ຕິດພັນກັບປະເພດຂໍ້ຜິດພາດທີ່ ກຳ ນົດເອງຂອງພວກເຮົາທີ່ແກ້ໄຂປະເພດຂໍ້ຜິດພາດທີ່ຢູ່ເບື້ອງຕົ້ນ, ພວກເຮົາສາມາດສົ່ງຄືນປະເພດຂໍ້ຜິດພາດດຽວໂດຍບໍ່ເສຍຂໍ້ມູນກ່ຽວກັບສາເຫດ.
/// ຜູ້ປະຕິບັດການ '?' ປ່ຽນປະເພດຂໍ້ຜິດພາດທີ່ຕິດພັນເປັນປະເພດຂໍ້ຜິດພາດຂອງພວກເຮົາໂດຍອັດຕະໂນມັດໂດຍການໂທຫາ `Into<CliError>::into` ເຊິ່ງສະ ໜອງ ໂດຍອັດຕະໂນມັດເມື່ອປະຕິບັດ `From`.
/// ຜູ້ລວບລວມຂໍ້ມູນຈະລະບຸວ່າການຈັດຕັ້ງປະຕິບັດ `Into` ຄວນຈະເປັນແນວໃດ.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// ດໍາເນີນການປ່ຽນແປງ.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// ເປັນພະຍາຍາມແປງທີ່ consumes `self`, ຊຶ່ງອາດແມ່ນຫຼືບໍ່ມີລາຄາແພງ.
///
/// ຜູ້ຂຽນຫໍສະ ໝຸດ ບໍ່ຄວນຈັດຕັ້ງປະຕິບັດ trait ນີ້ໂດຍກົງ, ແຕ່ຄວນມັກການຈັດຕັ້ງປະຕິບັດ [`TryFrom`] trait, ເຊິ່ງມີຄວາມຍືດຫຍຸ່ນຫຼາຍຂື້ນແລະໃຫ້ການປະຕິບັດ `TryInto` ທຽບເທົ່າໂດຍບໍ່ເສຍຄ່າ, ຍ້ອນການປະຕິບັດຜ້າຫົ່ມໃນຫ້ອງສະມຸດມາດຕະຖານ.
/// ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບເລື່ອງນີ້, ເບິ່ງເອກະສານ ສຳ ລັບ [`Into`].
///
/// # ຈັດຕັ້ງປະຕິບັດ `TryInto`
///
/// ນີ້ໄດ້ຍອມໃຫ້ມີຂໍ້ຈໍາກັດຄືກັນແລະສົມເຫດສົມຜົນເປັນການ [`Into`], ເບິ່ງມີລາຍລະອຽດ.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// ປະເພດຄືນໃນກໍລະນີຂອງຄວາມຜິດພາດການແປງໄດ້.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ດໍາເນີນການປ່ຽນແປງ.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Simple ແລະການສົນທະນາປະເພດຄວາມປອດໄພທີ່ອາດຈະຫຼົ້ມເຫຼວໃນວິທີການຄວບຄຸມພາຍໃຕ້ສະຖາ.ມັນເປັນຊຶ່ງກັນແລະກັນຂອງ [`TryInto`] ໄດ້.
///
/// ນີ້ແມ່ນເປັນປະໂຫຍດໃນເວລາທີ່ທ່ານກໍາລັງດໍາເນີນການປ່ຽນໃຈເຫລື້ອມໃສປະເພດທີ່ສໍາຄັນອາດຈະສໍາເລັດແຕ່ຍັງອາດຈະຕ້ອງການຮັກສາຫຼັງພິເສດ.
/// ຕົວຢ່າງ, ບໍ່ມີທາງທີ່ຈະປ່ຽນ [`i64`] ເປັນ [`i32`] ໂດຍໃຊ້ [`From`] trait, ເພາະວ່າ [`i64`] ອາດຈະມີມູນຄ່າທີ່ [`i32`] ບໍ່ສາມາດເປັນຕົວແທນແລະດັ່ງນັ້ນການແປງຈຶ່ງຈະສູນເສຍຂໍ້ມູນ.
///
/// ສິ່ງນີ້ອາດຈະຖືກຈັດການໂດຍການຕັດ [`i64`] ເປັນ [`i32`] (ໂດຍ ຈຳ ເປັນທີ່ຈະໃຫ້ມູນຄ່າມູນຄ່າ [`i64`] ຫຼືໂດຍການກັບຄືນ [`i32::MAX`], ຫຼືໂດຍວິທີອື່ນ).
/// The [`From`] trait ມີຈຸດປະສົງສໍາລັບການສົນທະນາທີ່ສົມບູນແບບ, ດັ່ງນັ້ນການ `TryFrom` trait ແຈ້ງໂປລແກລມໃນເວລາທີ່ປ່ຽນໃຈເຫລື້ອມໃສປະເພດສາມາດໄປບໍ່ດີແລະສາມາດເຮັດໃຫ້ເຂົາເຈົ້າຕັດສິນໃຈວ່າວິທີການຈັດການກັບມັນ.
///
/// # generic ການປະຕິບັດ
///
/// - `TryFrom<T> for U` ຫມາຍຄວາມວ່າ [`TryInto`] `<U>ສຳ ລັບ T`</u>
/// - [`try_from`] ແມ່ນປີ້ນ, ຊຶ່ງຫມາຍຄວາມວ່າ `TryFrom<T> for T` ຈະດໍາເນີນການແລະບໍ່ສາມາດເຊັ່ນການແລກປ່ຽນ-ທີ່ກ່ຽວຂ້ອງປະເພດ `Error` ສໍາລັບການໂທ `T::try_from()` ກ່ຽວກັບຄ່າຂອງປະເພດ `T` ແມ່ນ [`Infallible`].
/// ເມື່ອປະເພດ [`!`] ມີສະຖຽນລະພາບ [`Infallible`] ແລະ [`!`] ຈະທຽບເທົ່າ.
///
/// `TryFrom<T>` ສາມາດໄດ້ຮັບການປະຕິບັດດັ່ງຕໍ່ໄປນີ້:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// ດັ່ງທີ່ໄດ້ອະທິບາຍແລ້ວ, [`i32`] ປະຕິບັດ `TryFrom <` [`i64`] `>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Silently truncates `big_number`, ຮຽກຮ້ອງໃຫ້ມີການກວດສອບແລະການຈັດການຕັດຫຼັງຈາກຄວາມເປັນຈິງໄດ້.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // ສົ່ງຄືນຂໍ້ຜິດພາດເພາະວ່າ `big_number` ໃຫຍ່ເກີນໄປທີ່ຈະບໍ່ ເໝາະ ສົມກັບ `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // ກັບຄືນ `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// ປະເພດຄືນໃນກໍລະນີຂອງຄວາມຜິດພາດການແປງໄດ້.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ດໍາເນີນການປ່ຽນແປງ.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERIC impl
////////////////////////////////////////////////////////////////////////////////

// ໃນຖານະເປັນຍົກໃນໄລຍະ&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// ໃນຖານະເປັນຍົກໃນໄລຍະ &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ທົດແທນສິ່ງທີ່ກ່າວມາຂ້າງເທິງ ສຳ ລັບ&/&mut ດ້ວຍ ຄຳ ຕໍ່ໆໄປທົ່ວໄປ:
// // ໃນຖານະເປັນຍົກໃນໄລຍະ Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U: ຂະຫນາດ> AsRef <U>ສໍາລັບ D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut ຍົກສູງກວ່າ &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// ວັນ (#45742): ທົດແທນການ impl ຂ້າງເທິງນີ້ສໍາລັບ &mut ກັບດັ່ງຕໍ່ໄປນີ້ຫນຶ່ງໂດຍທົ່ວໄປເພີ່ມເຕີມ:
// // ເຊີດຊູ AsMut ໃນໄລຍະ DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? ຂະ ໜາດ> AsMut <U>ສຳ ລັບ D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// ຈາກກໍຫມາຍຄວາມວ່າເຂົ້າໄປໃນ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// ຈາກ (ແລະດັ່ງນັ້ນ Into) ແມ່ນປີ້ນ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **ຫມາຍເຫດສະຖຽນລະພາບ:** impl ນີ້ບໍ່ທັນມີ, ແຕ່ພວກເຮົາມີຄວາມ "reserving space" ຈະເພີ່ມມັນໃນ future.
/// ເບິ່ງ [rust-lang/rust#64715][#64715] ສໍາລັບລາຍລະອຽດ.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ເຮັດແນວໃດສາມາດແກ້ໄຂອາໄສຫຼັກແທນທີ່ຈະເປັນ.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom ໝາຍ ເຖິງ TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// ການປ່ຽນໃຈເຫລື້ອມໃສແບບບໍ່ມີຕົວຕົນແມ່ນທຽບເທົ່າກັບການປ່ຽນໃຈເຫລື້ອມໃສທີ່ສົມເຫດສົມຜົນກັບປະເພດຂໍ້ຜິດພາດທີ່ບໍ່ມີຜູ້ຢູ່ອາໄສ.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// impl CONCRETE
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ການບໍ່ມີຄວາມຜິດພາດປະເພດ ERROR
////////////////////////////////////////////////////////////////////////////////

/// ປະເພດຂໍ້ຜິດພາດ ສຳ ລັບຂໍ້ຜິດພາດທີ່ບໍ່ສາມາດເກີດຂື້ນໄດ້.
///
/// ເນື່ອງຈາກ enum ນີ້ບໍ່ມີຕົວປ່ຽນແປງ, ຄຸນຄ່າຂອງຊະນິດນີ້ບໍ່ສາມາດມີຕົວຈິງໄດ້.
/// ນີ້ສາມາດເປັນປະໂຫຍດສໍາລັບ APIs ທົ່ວໄປທີ່ໃຊ້ [`Result`] ແລະ parameterize ປະເພດຄວາມຜິດພາດໄດ້, ເພື່ອຊີ້ໃຫ້ເຫັນວ່າຜົນໄດ້ຮັບແມ່ນສະເຫມີ [`Ok`].
///
/// ສໍາລັບຕົວຢ່າງ, ໃນ [`TryFrom`] trait (ການປ່ຽນແປງທີ່ຈະກັບຄືນມາເປັນ [`Result`]) ມີການປະຕິບັດຜ້າຫົ່ມສໍາລັບທຸກປະເພດທີ່ເປັນການປະຕິບັດ [`Into`] ໄດ້ຢ່າງສິ້ນເຊີງແລ້ວ.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # ຄວາມເຂົ້າກັນໄດ້ຂອງ Future
///
/// Enum ນີ້ມີບົດບາດຄືກັນກັບ [the `!`“never”type][never], ເຊິ່ງບໍ່ສະຖຽນລະພາບໃນລຸ້ນ Rust ນີ້.
/// ເມື່ອ `!` ມີສະຖຽນລະພາບ, ພວກເຮົາວາງແຜນທີ່ຈະເຮັດໃຫ້ `Infallible` ເປັນນາມແຝງຊະນິດ ໜຶ່ງ ຕໍ່ມັນ:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... ແລະໃນທີ່ສຸດ deprecate `Infallible`.
///
/// ເຖິງຢ່າງໃດກໍ່ຕາມມີກໍລະນີ ໜຶ່ງ ທີ່ syntax `!` ສາມາດ ນຳ ໃຊ້ກ່ອນ `!` ມີສະຖຽນລະພາບເປັນປະເພດເຕັມຮູບແບບ: ໃນ ຕຳ ແໜ່ງ ປະເພດການກັບຄືນຂອງ ໜ້າ ທີ່.
/// ໂດຍສະເພາະ, ມັນແມ່ນການຈັດຕັ້ງປະຕິບັດທີ່ເປັນໄປໄດ້ ສຳ ລັບສອງປະເພດຕົວຊີ້ທິດທາງທີ່ແຕກຕ່າງກັນ:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// ມີ `Infallible` ເປັນ enum, ລະຫັດນີ້ແມ່ນຖືກຕ້ອງ.
/// ເຖິງຢ່າງໃດກໍ່ຕາມເມື່ອ `Infallible` ກາຍເປັນນາມແຝງ ສຳ ລັບ never type, ສອງ `impl`s ຈະເລີ່ມຕົ້ນທີ່ຈະຊໍ້າຊ້ອນແລະດັ່ງນັ້ນມັນຈະຖືກປະຕິເສດໂດຍກົດລະບຽບ trait ຂອງພາສາ.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}