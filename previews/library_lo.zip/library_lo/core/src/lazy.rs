//! ຄ່າ Lazy ແລະຂຽນອັກສອນຫຍໍ້ຫນຶ່ງທີ່ໃຊ້ເວລາຂອງຂໍ້ມູນແບບຄົງ.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// A ສັບມືຖືທີ່ສາມາດໄດ້ຮັບການລາຍລັກອັກສອນທີ່ຈະພຽງແຕ່ຄັ້ງດຽວ.
///
/// ບໍ່ເຫມືອນກັບ `RefCell`, ເປັນ `OnceCell` ພຽງແຕ່ໃຫ້ແບ່ງປັນເອກະສານ `&T` ກັບມູນຄ່າຂອງຕົນ.
/// ບໍ່ຄືກັບ `Cell`, `OnceCell` ບໍ່ ຈຳ ເປັນຕ້ອງ ສຳ ເນົາຫຼືປ່ຽນມູນຄ່າເພື່ອເຂົ້າໃຊ້ມັນ.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: ລາຍລັກອັກສອນທີ່ຈະໄດ້ສູງສຸດຄັ້ງ.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// ສ້າງເປັນຫ້ອງເປົ່າຫວ່າງໃຫມ່.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// ໄດ້ຮັບການສອບຖາມກັບມູນຄ່າທີ່ຕິດພັນ.
    ///
    /// ຜົນໄດ້ຮັບ `None` ຖ້າມືຖືແມ່ນເປົ່າ.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // SAFETY ປອດໄພເນື່ອງຈາກ `ຄົງ inner` ຂອງ
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// ໄດ້ຮັບການກະສານອ້າງອີງບໍ່ແນ່ນອນກັບມູນຄ່າທີ່ຕິດພັນ.
    ///
    /// ຜົນໄດ້ຮັບ `None` ຖ້າມືຖືແມ່ນເປົ່າ.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // SAFETY ປອດໄພເພາະວ່າພວກເຮົາມີການເຂົ້າເຖິງເອກະລັກ
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// ກຳ ນົດເນື້ອໃນຂອງເຊນເປັນ `value`.
    ///
    /// # Errors
    ///
    /// ວິທີການນີ້ຈະສົ່ງຄືນ `Ok(())` ຖ້າວ່າຫ້ອງຫວ່າງແລະ `Err(value)` ຖ້າມັນເຕັມ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // SAFETY ປອດໄພເພາະວ່າພວກເຮົາບໍ່ສາມາດໄດ້ overlapping ກູ້ຢືມເງິນທີ່ບໍ່ແນ່ນອນ
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // SAFETY: ນີ້ແມ່ນສະຖານທີ່ພຽງແຕ່ບ່ອນທີ່ພວກເຮົາກໍານົດໂມ້, ບໍ່ມີເຊື້ອຊາດ
        // ເນື່ອງຈາກ reentrancy/concurrency ແມ່ນເປັນໄປໄດ້, ແລະພວກເຮົາໄດ້ກວດເບິ່ງວ່າສະລັອດຕິງປະຈຸບັນແມ່ນ `None`, ສະນັ້ນລາຍລັກອັກສອນນີ້ຈະຮັກສາສະຖານທີ່ທີ່ບໍ່ມີຕົວຕົນ.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// ໄດ້ເນື້ອໃນຂອງແຕ່ລະຫ້ອງການ, ເລີ່ມຕົ້ນມັນກັບ `f` ຖ້າມືຖືແມ່ນເປົ່າ.
    ///
    /// # Panics
    ///
    /// ຖ້າ `f` panics, ການ panic ແມ່ນຂະຫຍາຍພັນດ້ວຍແປໄດ້ທຸ, ແລະແຕ່ລະຫ້ອງການຍັງ uninitiated.
    ///
    ///
    /// ມັນເປັນຄວາມຜິດພາດທີ່ຈະເລີ່ມຕົ້ນ reentrantly ສັບມືຖືຈາກ `f` ໄດ້.ດໍາເນີນການດັ່ງຜົນໃນ panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// ໄດ້ເນື້ອໃນຂອງແຕ່ລະຫ້ອງການ, ເລີ່ມຕົ້ນມັນກັບ `f` ຖ້າມືຖືແມ່ນເປົ່າ.
    /// ຖ້າຫາກວ່າຫ້ອງແມ່ນຫວ່າງເປົ່າແລະ `f` ສົບຜົນສໍາເລັດ, ຄວາມຜິດພາດຈະຖືກສົ່ງກັບ.
    ///
    /// # Panics
    ///
    /// ຖ້າ `f` panics, ການ panic ແມ່ນຂະຫຍາຍພັນດ້ວຍແປໄດ້ທຸ, ແລະແຕ່ລະຫ້ອງການຍັງ uninitiated.
    ///
    ///
    /// ມັນເປັນຄວາມຜິດພາດທີ່ຈະເລີ່ມຕົ້ນ reentrantly ສັບມືຖືຈາກ `f` ໄດ້.ດໍາເນີນການດັ່ງຜົນໃນ panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // ໃຫ້ສັງເກດວ່າ *ບາງຮູບແບບ* ຂອງການເລີ່ມຕົ້ນ ໃໝ່ ອາດຈະເຮັດໃຫ້ UB (ເບິ່ງ `reentrant_init` ທົດສອບ).
        // ຂ້າພະເຈົ້າເຊື່ອວ່າພຽງແຕ່ຖອນ `assert` ນີ້, ໃນຂະນະທີ່ການຮັກສາ `set/get` ຈະສຽງ, ແຕ່ວ່າມັນເບິ່ງຄືວ່າດີກວ່າທີ່ຈະ panic, ແທນທີ່ຈະກ່ວາເພື່ອ silently ໃຊ້ຄ່າເດີມ.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// ກິນແຕ່ລະຫ້ອງການ, ກັບຄືນມູນຄ່າຫໍ່.
    ///
    /// ສົ່ງຄືນ `None` ຖ້າຫ້ອງບໍ່ຫວ່າງ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // ເນື່ອງຈາກວ່າ `into_inner` ໃຊ້ເວລາ `self` ໂດຍມູນຄ່າຜູ້ແປແບບຄົງພິສູດວ່າມັນບໍ່ໄດ້ຖືກຢືມປະຈຸບັນ.
        // ສະນັ້ນມັນເປັນການປອດພັຍທີ່ຈະຍ້າຍອອກ `Option<T>`.
        self.inner.into_inner()
    }

    /// ໃຊ້ເວລາຄ່າທີ່ອອກຈາກ `OnceCell` ນີ້, ການເຄື່ອນຍ້າຍມັນກັບຄືນໄປບ່ອນສະຖານະ uninitiated.
    ///
    /// ບໍ່ມີຜົນກະທົບແລະຜົນໄດ້ຮັບ `None` ຖ້າ `OnceCell` ຍັງບໍ່ທັນໄດ້ເລີ່ມຕົ້ນໄດ້.
    ///
    /// ຄວາມປອດໄພຂອງການຮັບປະກັນໂດຍການກໍານົດການກະສານອ້າງອີງທີ່ບໍ່ແນ່ນອນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// ມູນຄ່າ A ຊຶ່ງຈະເລີ່ມຕົ້ນໃນການເຂົ້າເຖິງຄັ້ງທໍາອິດ.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   ພ້ອມທີ່ຈະເລີ່ມຕົ້ນ
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// ສ້າງຄ່າ lazy ໃຫມ່ທີ່ມີໃຫ້ການທໍາງານຂອງເລີ່ມຕົ້ນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// ບັງຄັບໃຫ້ການປະເມີນຜົນຄຸນຄ່າ lazy ນີ້ແລະຈະກັບຄືນມາເປັນການອ້າງອີງເຖິງຜົນໄດ້ຮັບ.
    ///
    ///
    /// ນີ້ແມ່ນທຽບເທົ່າກັບ impl `Deref`, ແຕ່ເປັນ explicit.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// ສ້າງຄ່າ lazy ໃຫມ່ໃຊ້ `Default` ເປັນການທໍາງານຂອງເລີ່ມຕົ້ນ.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}