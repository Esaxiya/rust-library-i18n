#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! ປະກອບດ້ວຍ ຄຳ ນິຍາມຂອງໂຄງສ້າງ ສຳ ລັບການຈັດຮູບແບບຂອງຜູ້ລວບລວມຂໍ້ມູນ.
//!
//! ພວກມັນສາມາດຖືກ ນຳ ໃຊ້ເປັນເປົ້າ ໝາຍ ຂອງການສົ່ງຕໍ່ໃນລະຫັດທີ່ບໍ່ປອດໄພ ສຳ ລັບການ ໝູນ ໃຊ້ຕົວແທນດິບໂດຍກົງ.
//!
//!
//! ຄຳ ນິຍາມຂອງພວກມັນຄວນຈະກົງກັບ ABI ທີ່ໄດ້ ກຳ ນົດໄວ້ໃນ `rustc_middle::ty::layout`.
//!

/// ການເປັນຕົວແທນຂອງວັດຖຸ trait ຄ້າຍຄື `&dyn SomeTrait`.
///
/// ໂຄງສ້າງນີ້ມີຮູບແບບດຽວກັນກັບປະເພດເຊັ່ນ `&dyn SomeTrait` ແລະ `Box<dyn AnotherTrait>`.
///
/// `TraitObject` ຖືກຮັບປະກັນໃຫ້ກົງກັບການຈັດວາງ, ແຕ່ມັນບໍ່ແມ່ນປະເພດຂອງວັດຖຸ trait (ຕົວຢ່າງ, ທົ່ງນາບໍ່ສາມາດເຂົ້າເຖິງເສັ້ນ `&dyn SomeTrait` X ໄດ້ໂດຍກົງ) ແລະມັນບໍ່ຄວບຄຸມຮູບແບບນັ້ນ (ການປ່ຽນ ຄຳ ນິຍາມຈະບໍ່ປ່ຽນຮູບແບບຂອງ `&dyn SomeTrait`).
///
/// ມັນຖືກອອກແບບໃຫ້ຖືກ ນຳ ໃຊ້ໂດຍລະຫັດທີ່ບໍ່ປອດໄພເຊິ່ງ ຈຳ ເປັນຕ້ອງໄດ້ ໝູນ ໃຊ້ລາຍລະອຽດລະດັບຕໍ່າ.
///
/// ບໍ່ມີທາງທີ່ຈະ ໝາຍ ເຖິງວັດຖຸ trait ທັງ ໝົດ ໂດຍທົ່ວໄປ, ດັ່ງນັ້ນວິທີດຽວທີ່ຈະສ້າງຄຸນຄ່າຂອງປະເພດນີ້ແມ່ນມີ ໜ້າ ທີ່ຄ້າຍຄື [`std::mem::transmute`][transmute].
/// ເຊັ່ນດຽວກັນ, ວິທີດຽວທີ່ຈະສ້າງວັດຖຸ trait ທີ່ແທ້ຈິງຈາກມູນຄ່າ `TraitObject` ແມ່ນກັບ `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// synthesizing ເປັນວັດຖຸ trait ກັບກົງກັນຊະນິດຫນຶ່ງທີ່ vtable ທີ່ບໍ່ກົງກັນກັບປະເພດຂອງຄ່າໃນການທີ່ໄດ້ຊີ້ຂໍ້ມູນຈຸດແມ່ນສູງທີ່ອາດຈະນໍາໄປສູ່ການປະພຶດ undefined ໄດ້.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ຕົວຢ່າງ trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // ໃຫ້ຜູ້ລວບລວມຂໍ້ມູນເຮັດເປັນວັດຖຸ trait
/// let object: &dyn Foo = &value;
///
/// // ເບິ່ງຕົວແທນວັດຖຸດິບ
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ຕົວຊີ້ຂໍ້ມູນແມ່ນທີ່ຢູ່ຂອງ `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // ສ້າງຈຸດປະສົງ ໃໝ່, ຊີ້ໄປທີ່ `i32` ອື່ນ, ໃຫ້ລະມັດລະວັງໃນການໃຊ້ `i32` vtable ຈາກ `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // ມັນຄວນຈະເຮັດວຽກຄືກັບວ່າພວກເຮົາໄດ້ສ້າງວັດຖຸ trait ອອກຈາກ `other_value` ໂດຍກົງ
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}