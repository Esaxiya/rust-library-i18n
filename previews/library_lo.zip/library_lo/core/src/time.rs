#![stable(feature = "duration_core", since = "1.25.0")]

//! ການ ຄຳ ນວນປະລິມານຂອງເວລາ.
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // ການປະກາດທັງສອງແມ່ນທຽບເທົ່າ
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// ປະເພດ `Duration` ເພື່ອສະແດງໄລຍະເວລາ, ໂດຍປົກກະຕິແມ່ນໃຊ້ ສຳ ລັບເວລາລະບົບ.
///
/// ແຕ່ລະ `Duration` ແມ່ນປະກອບດ້ວຍ ຈຳ ນວນວິນາທີທັງ ໝົດ ແລະສ່ວນທີ່ເປັນສ່ວນ ໜຶ່ງ ທີ່ເປັນຕົວແທນໃນ nanoseconds.
/// ຖ້າຫາກວ່າລະບົບທີ່ຕິດພັນບໍ່ສະ ໜັບ ສະ ໜູນ ຄວາມແມ່ນຍໍາລະດັບ nanosecond, APIs ຖືກຜູກມັດການ ໝົດ ເວລາຂອງລະບົບໂດຍປົກກະຕິຈະເຮັດໃຫ້ ຈຳ ນວນ nanoseconds ເພີ່ມຂື້ນ.
///
/// [`Duration`] s ໃຊ້ຈໍານວນຫຼາຍທົ່ວໄປ traits, ລວມທັງ [`Add`], [`Sub`], ແລະອື່ນໆ [`ops`] traits.ຈະດໍາເນີນ [`Default`] ໂດຍກັບຄືນເປັນສູນຂອງຄວາມຍາວປາ `Duration`.
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # ຄ່າຈັດຮູບແບບ `Duration`
///
/// `Duration` ໂດຍເຈດຕະນາບໍ່ມີ `Display` impl, ຍ້ອນວ່າມັນມີຫລາຍໆວິທີໃນການຈັດຮູບແບບເວລາ ສຳ ລັບການອ່ານຂອງມະນຸດ.
/// `Duration` ສະຫນອງ `Debug` impl ທີ່ສະແດງໃຫ້ເຫັນຄວາມແມ່ນຍໍາເຕັມຂອງມູນຄ່າ.
///
/// ຜົນຜະລິດ `Debug` ໃຊ້ ຄຳ ສັບທີ່ບໍ່ແມ່ນ ASCII "µs" ສຳ ລັບໄມໂຄຣໂຟນ.
/// ຖ້າຜົນຜະລິດຂອງໂປແກຼມຂອງທ່ານປາກົດຂື້ນໃນສະພາບການທີ່ບໍ່ສາມາດອີງໃສ່ຄວາມເຂົ້າກັນໄດ້ກັບ Unicode ຢ່າງເຕັມທີ່, ທ່ານອາດຈະຕ້ອງການຈັດຮູບແບບ `Duration` ຕົວທ່ານເອງຫຼືໃຊ້ crate ເພື່ອເຮັດເຊັ່ນນັ້ນ.
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // ສະເຫມີ 0 <=nanos <NANOS_PER_SEC
}

impl Duration {
    /// ໄລຍະເວລາຂອງ ໜຶ່ງ ວິນາທີ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// ໄລຍະເວລາຂອງການຫນຶ່ງ millisecond.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// ໄລຍະເວລາຂອງ ໜຶ່ງ microsecond.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// ໄລຍະເວລາຂອງຫນຶ່ງ nanosecond.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// ໄລຍະເວລາຂອງເວລາສູນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// ໄລຍະເວລາສູງສຸດ.
    ///
    /// ມັນແມ່ນປະມານເທົ່າກັບໄລຍະເວລາຂອງ 584,942,417,355 ປີ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// ສ້າງ `Duration` ໃໝ່ ຈາກ ຈຳ ນວນວິນາທີທັງ ໝົດ ທີ່ລະບຸແລະວິນາທີເພີ່ມເຕີມ.
    ///
    /// ຖ້າ ຈຳ ນວນ nanoseconds ຫຼາຍກ່ວາ 1 ຕື້ (ຈຳ ນວນ nanoseconds ໃນວິນາທີ), ແລ້ວມັນຈະ ນຳ ໄປສູ່ວິນາທີທີ່ໃຫ້.
    ///
    ///
    /// # Panics
    ///
    /// constructor ນີ້ຈະ panic ຖ້າປະຕິບັດຈາກ nanoseconds ໄດ້ລົ້ນວຽກງານຕ້ານວິນາທີ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// ສ້າງ `Duration` ໃໝ່ ຈາກ ຈຳ ນວນວິນາທີທັງ ໝົດ ທີ່ລະບຸ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// ສ້າງ `Duration` ໃຫມ່ຈາກຈໍານວນທີ່ກໍານົດໄວ້ຂອງວິນາທີ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// ສ້າງ `Duration` ໃໝ່ ຈາກ ຈຳ ນວນ microseconds ທີ່ລະບຸ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// ສ້າງ `Duration` ໃໝ່ ຈາກ ຈຳ ນວນ nanoseconds ທີ່ລະບຸ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// ກັບມາເປັນຄວາມຈິງຖ້າ `Duration` ນີ້ບໍ່ມີເວລາ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// ສົ່ງ ຈຳ ນວນ _whole_ ວິນາທີທີ່ບັນຈຸໂດຍ `Duration` ນີ້.
    ///
    /// ມູນຄ່າທີ່ສົ່ງຄືນບໍ່ໄດ້ລວມເອົາສ່ວນ (nanosecond) ສ່ວນ ໜຶ່ງ ຂອງໄລຍະເວລາ, ເຊິ່ງສາມາດໄດ້ຮັບໂດຍໃຊ້ [`subsec_nanos`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// ເພື່ອ ກຳ ນົດ ຈຳ ນວນວິນາທີທັງ ໝົດ ທີ່ເປັນຕົວແທນໂດຍ `Duration`, ໃຫ້ໃຊ້ `as_secs` ປະສົມປະສານກັບ [`subsec_nanos`]:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// ສົ່ງຄືນສ່ວນທີ່ລະອຽດຂອງ `Duration` ນີ້, ເປັນເງິນທັງ ໝົດ ມິນລິລິດ.
    ///
    /// ວິທີການນີ້ບໍ່ **ບໍ່** ສົ່ງຄືນໄລຍະເວລາໃນເວລາທີ່ສະແດງໂດຍວິນາທີ.
    /// ຕົວເລກທີ່ຖືກສົ່ງຄືນສະ ເໝີ ໄປເປັນຕົວແທນສ່ວນ ໜຶ່ງ ຂອງວິນາທີ (ໝາຍ ຄວາມວ່າມັນ ໜ້ອຍ ກວ່າ ໜຶ່ງ ພັນ).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// ສົ່ງຄືນສ່ວນທີ່ລະອຽດຂອງ `Duration` ນີ້, ໃນ microseconds ທັງ ໝົດ.
    ///
    /// ວິທີການນີ້ບໍ່ **ບໍ່** ສົ່ງຄືນໄລຍະເວລາໃນເວລາທີ່ສະແດງໂດຍ microseconds.
    /// ຕົວເລກທີ່ຖືກສົ່ງຄືນມັກຈະເປັນຕົວແທນສ່ວນ ໜຶ່ງ ຂອງວິນາທີ (ໝາຍ ຄວາມວ່າມັນ ໜ້ອຍ ກວ່າ ໜຶ່ງ ລ້ານ).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// ສົ່ງຄືນສ່ວນທີ່ສ່ວນນ້ອຍໆຂອງ `Duration` ນີ້, ໃນ nanoseconds.
    ///
    /// ວິທີການນີ້ບໍ່ **ບໍ່** ສົ່ງຄືນໄລຍະເວລາໃນເວລາທີ່ສະແດງໂດຍ nanoseconds.
    /// ຈໍານວນກັບຄືນສະເຫມີເປັນຕົວແທນເປັນສ່ວນແຕ່ສ່ວນຫນຶ່ງຂອງສອງ (ie, ມັນແມ່ນຫນ້ອຍກ່ວາຫນຶ່ງຕື້).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// ສົ່ງຄືນ ຈຳ ນວນເງິນທັງ ໝົດ ຂອງ milliseconds ທີ່ບັນຈຸໂດຍ `Duration` ນີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// ຜົນຕອບແທນຈໍານວນທັງຫມົດຂອງ microseconds ທັງຫມົດບັນຈຸໂດຍ `Duration` ນີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// ສົ່ງຄືນ ຈຳ ນວນ nanoseconds ທັງ ໝົດ ທີ່ບັນຈຸໂດຍ `Duration` ນີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// ຕວດສອບ `Duration` ນອກຈາກນັ້ນ.
    /// ຄຳ ນວນ `self + other`, ການກັບຄືນ [`None`] ຖ້າຫາກວ່າເກີດມີການລົ້ນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ເພີ່ມເຕີມ Saturating `Duration`.
    /// ຄອມພິວເຕີ `self + other`, ກັບຄືນ [`Duration::MAX`] ຖ້າ overflow ເກີດຂຶ້ນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// ຄຳ ສັ່ງຫັກລົບ `Duration`.
    /// ຄຳ ນວນ `self - other`, ການກັບຄືນ [`None`] ຖ້າຜົນໄດ້ຮັບຈະເປັນສິ່ງທີ່ບໍ່ດີຫລືຖ້າມີການໄຫຼເກີນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ການຫັກລົບ Saturating `Duration`.
    /// ຄຳ ນວນ `self - other`, ການກັບຄືນ [`Duration::ZERO`] ຖ້າຜົນໄດ້ຮັບຈະເປັນສິ່ງທີ່ບໍ່ດີຫລືຖ້າມີການໄຫຼເກີນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// ກວດເບິ່ງຄູນ `Duration`.
    /// ຄຳ ນວນ `self * other`, ການກັບຄືນ [`None`] ຖ້າຫາກວ່າເກີດມີການລົ້ນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // nanoseconds Multiply ເປັນ u64, ເນື່ອງຈາກວ່າມັນບໍ່ສາມາດລົ້ນວິທີການທີ່.
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// ການຄູນ Xu `Duration` X.
    /// ຄຳ ນວນ `self * other`, ການກັບຄືນ [`Duration::MAX`] ຖ້າຫາກວ່າເກີດມີການລົ້ນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// ກວດກາພະແນກ `Duration`.
    /// ຄຳ ນວນ `self / other`, ການກັບຄືນ [`None`] ຖ້າ `other == 0`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ເອົາ ຈຳ ນວນວິນາທີທີ່ບັນຈຸໂດຍ `Duration` ນີ້ເປັນ `f64`.
    /// ມູນຄ່າທີ່ສົ່ງຄືນບໍ່ໄດ້ລວມເອົາສ່ວນ (nanosecond) ສ່ວນ ໜຶ່ງ ຂອງໄລຍະເວລາ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// ເອົາ ຈຳ ນວນວິນາທີທີ່ບັນຈຸໂດຍ `Duration` ນີ້ເປັນ `f32`.
    /// ມູນຄ່າທີ່ສົ່ງຄືນບໍ່ໄດ້ລວມເອົາສ່ວນ (nanosecond) ສ່ວນ ໜຶ່ງ ຂອງໄລຍະເວລາ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// ສ້າງ `Duration` ໃໝ່ ຈາກ ຈຳ ນວນວິນາທີທີ່ລະບຸເປັນ `f64`.
    ///
    /// # Panics
    /// ຜູ້ກໍ່ສ້າງນີ້ຈະ panic ຖ້າ `secs` ບໍ່ຈົບ, ລົບຫຼືລົ້ນ `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// ສ້າງ `Duration` ໃຫມ່ຈາກຈໍານວນທີ່ກໍານົດໄວ້ຂອງວິນາທີເປັນຕົວແທນເປັນ `f32`.
    ///
    /// # Panics
    /// ຜູ້ກໍ່ສ້າງນີ້ຈະ panic ຖ້າ `secs` ບໍ່ຈົບ, ລົບຫຼືລົ້ນ `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// ຄູນ `Duration` ໂດຍ `f64`.
    /// # Panics
    /// ວິທີການນີ້ຈະ panic ຖ້າຜົນໄດ້ຮັບບໍ່ຈົບ, ລົບຫຼືລົ້ນ `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// ຄູນ `Duration` ໂດຍ `f32`.
    /// # Panics
    /// ວິທີການນີ້ຈະ panic ຖ້າຜົນໄດ້ຮັບບໍ່ຈົບ, ລົບຫຼືລົ້ນ `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // ໃຫ້ສັງເກດວ່າເນື່ອງຈາກຂໍ້ຜິດພາດຮອບວຽນຜົນໄດ້ຮັບແມ່ນແຕກຕ່າງກັນເລັກນ້ອຍຈາກ 8.478 ແລະ 847800.0
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// ແບ່ງ `Duration` ໂດຍ `f64`.
    /// # Panics
    /// ວິທີການນີ້ຈະ panic ຖ້າຜົນໄດ້ຮັບບໍ່ຈົບ, ລົບຫຼືລົ້ນ `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // ຄວນສັງເກດວ່າການຕັດຖືກນໍາໃຊ້, ບໍ່ມົນ
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// ແບ່ງ `Duration` ໂດຍ `f32`.
    /// # Panics
    /// ວິທີການນີ້ຈະ panic ຖ້າຜົນໄດ້ຮັບບໍ່ຈົບ, ລົບຫຼືລົ້ນ `Duration`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // ໃຫ້ສັງເກດວ່າເນື່ອງຈາກຄວາມຜິດພາດຮອບມົນຜົນໄດ້ຮັບແມ່ນແຕກຕ່າງກັນເລັກນ້ອຍຈາກ 0.859_872_611
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // ຄວນສັງເກດວ່າການຕັດຖືກນໍາໃຊ້, ບໍ່ມົນ
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// ແບ່ງ `Duration` ໂດຍ `Duration` ແລະກັບຄືນ `f64`.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// ແບ່ງ `Duration` ໂດຍ `Duration` ແລະສົ່ງ `f32` ຄືນ.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// ປະກອບເປັນ ຈຳ ນວນຈຸດທີ່ລອຍຢູ່ໃນ ຈຳ ນວນທົດສະນິຍົມ.
        ///
        /// ຕົວເລກແມ່ນໃຫ້ເປັນ `integer_part` ແລະສ່ວນ ໜຶ່ງ.
        /// ມູນຄ່າຂອງພາກສ່ວນເສດແມ່ນ `fractional_part / divisor`.
        /// ສະນັ້ນ `integer_part` =3, `fractional_part` =12 ແລະ `divisor` =100 ໝາຍ ເລກ `3.012`.
        /// ສູນຕໍ່ທ້າຍຖືກເອົາອອກ.
        ///
        /// `divisor` ບໍ່ຕ້ອງຢູ່ ເໜືອ 100_000_000.
        /// ມັນຍັງຄວນຈະເປັນພະລັງງານຂອງ 10, ທຸກສິ່ງທຸກຢ່າງອື່ນກໍ່ບໍ່ມີຄວາມຫມາຍ.
        /// `fractional_part` ມີຈະຫນ້ອຍກ່ວາ `10 * divisor`!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // ເຂົ້າລະຫັດສ່ວນທີ່ເປັນສ່ວນປະກອບເຂົ້າໃນ buffer ຊົ່ວຄາວ.
            // buffer ພຽງແຕ່ ຈຳ ເປັນຕ້ອງຖື 9 ອົງປະກອບ, ເພາະ `fractional_part` ຕ້ອງມີຂະ ໜາດ ນ້ອຍກວ່າ 10 ^ 9.
            //
            // buffer ແມ່ນຖືກຕື່ມດ້ວຍຕົວເລກ '0' ເພື່ອງ່າຍຕໍ່ລະຫັດຂ້າງລຸ່ມນີ້.
            let mut buf = [b'0'; 9];

            // ຕົວເລກຕໍ່ໄປແມ່ນລາຍລັກອັກສອນຢູ່ໃນຕໍາແຫນ່ງນີ້
            let mut pos = 0;

            // ພວກເຮົາສືບຕໍ່ຂຽນຕົວເລກເຂົ້າໃນໂຕເຟີໃນຂະນະທີ່ຍັງບໍ່ມີຕົວເລກທີ່ບໍ່ແມ່ນສູນແລະພວກເຮົາຍັງບໍ່ໄດ້ຂຽນຕົວເລກພຽງພໍເທື່ອ.
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // ຂຽນຫລັກໃຫມ່ເຂົ້າໄປໃນບັຟເຟີ
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // ຖ້າຄວາມແມ່ນຍໍາ <9 ໄດ້ຖືກລະບຸ, ມັນອາດຈະມີບາງຕົວເລກທີ່ບໍ່ແມ່ນສູນທີ່ບໍ່ໄດ້ຖືກຂຽນເຂົ້າໃນບັຟເຟີ.
            // ໃນກໍລະນີດັ່ງກ່າວພວກເຮົາ ຈຳ ເປັນຕ້ອງ ດຳ ເນີນການຮອບເພື່ອໃຫ້ກົງກັບ semantics ຂອງການພິມ ຈຳ ນວນຈຸດລອຍຕາມປົກກະຕິ.
            // ເຖິງຢ່າງໃດກໍ່ຕາມ, ພວກເຮົາຕ້ອງການເຮັດວຽກເທົ່ານັ້ນເມື່ອຮອບ.
            // ນີ້ຈະເກີດຫຍັງຂຶ້ນຖ້າຫາກວ່າຕົວເລກທໍາອິດຂອງບໍ່ຍັງເຫຼືອແມ່ນ>=5.
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // ຮວບຮວມ ຈຳ ນວນທີ່ບັນຈຸຢູ່ໃນບັຟເຟີ.
                // ພວກເຮົາຜ່ານຄວາຍຫລັງໄປທາງຫລັງແລະຕິດຕາມກະເປົາ.
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // ຖ້າຕົວເລກຢູ່ໃນ buffer ບໍ່ແມ່ນ '9', ພວກເຮົາພຽງແຕ່ຕ້ອງການເພີ່ມມັນແລະສາມາດຢຸດຫຼັງຈາກນັ້ນ (ເພາະວ່າພວກເຮົາບໍ່ມີກະເປົາອີກ).
                    // ຖ້າບໍ່ດັ່ງນັ້ນ, ພວກເຮົາຕັ້ງຄ່າມັນໃຫ້ '0' (overflow) ແລະສືບຕໍ່.
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // ຖ້າຫາກວ່າພວກເຮົາຍັງມີກໍານົດໄວ້ປະຕິບັດນ້ອຍ, ວິທີການທີ່ວ່າພວກເຮົາກໍານົດບັຟເຟີທັງຫມົດເພື່ອ '0 ແລະຄວາມຕ້ອງການທີ່ຈະເພີ່ມຄ່າສ່ວນຈໍານວນເຕັມ.
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // ກຳ ນົດຈຸດສິ້ນສຸດຂອງ buffer: ຖ້າ ກຳ ນົດຄວາມແມ່ນ ຍຳ, ພວກເຮົາພຽງແຕ່ ນຳ ໃຊ້ຫລາຍຕົວເລກຈາກ buffer (ຕັ້ງໄວ້ເຖິງ 9).
            // ຖ້າມັນບໍ່ໄດ້ ກຳ ນົດ, ພວກເຮົາໃຊ້ພຽງແຕ່ຕົວເລກທັງ ໝົດ ຈົນເຖິງເລກສຸດທ້າຍທີ່ບໍ່ແມ່ນສູນ.
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // ຖ້າຫາກວ່າພວກເຮົາຍັງບໍ່ທັນໄດ້ປ່ອຍອອກມາຕົວເລກເສດສ່ວນດຽວແລະຊັດເຈນໄດ້ບໍ່ໄດ້ກໍານົດເປັນມູນຄ່າທີ່ບໍ່ແມ່ນສູນ, ພວກເຮົາບໍ່ພິມຈຸດອັດຕານິຍົມໄດ້.
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // ຄວາມປອດໄພ: ພວກເຮົາພຽງແຕ່ຂຽນຕົວເລກ ASCII ເຂົ້າໃນບັຟເຟີແລະມັນແມ່ນ
                // ເລີ່ມຕົ້ນດ້ວຍ '0's, ສະນັ້ນມັນມີ UTF8 ທີ່ຖືກຕ້ອງ.
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // ຖ້າຜູ້ໃຊ້ຮ້ອງຂໍໃຫ້ມີຄວາມແມ່ນຍໍາ> 9, ພວກເຮົາລອກ '0 ຢູ່ໃນຕອນທ້າຍ.
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // ພິມຊັ້ນນໍາອາ '+' ຖ້າຖືກຂໍຮ້ອງ
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}