//! `Clone` trait ສຳ ລັບຊະນິດທີ່ບໍ່ສາມາດ 'ຄັດລອກໄດ້ຢ່າງສົມບູນ'.
//!
//! ໃນ Rust, ບາງຊະນິດງ່າຍດາຍແມ່ນ "implicitly copyable" ແລະໃນເວລາທີ່ທ່ານແຕ່ງຕັ້ງໃຫ້ເຂົາຫຼືຜ່ານໃຫ້ເຂົາເຈົ້າເປັນແນວໄດ? ຮັບຈະໄດ້ຮັບສໍາເນົາ, ຊຶ່ງເຮັດໃຫ້ມູນຄ່າຕົ້ນສະບັບໃນສະຖານທີ່.
//! ປະເພດເຫຼົ່ານີ້ບໍ່ຮຽກຮ້ອງໃຫ້ມີການຈັດສັນການສໍາເນົາແລະບໍ່ມີຂັ້ນສຸດທ້າຍ (ie, ພວກເຂົາເຈົ້າບໍ່ປະກອບດ້ວຍຫ້ອງເປັນເຈົ້າຂອງຫຼືປະຕິບັດ [`Drop`]), ສະນັ້ນ compiler ໄດ້ພິຈາລະນາໃຫ້ເຂົາເຈົ້າລາຄາຖືກແລະປອດໄພໃນສໍາເນົາ.
//!
//! ສຳ ລັບປະເພດອື່ນໆ ສຳ ເນົາຕ້ອງໄດ້ເຮັດຂື້ນຢ່າງຈະແຈ້ງ, ໂດຍການປະຕິບັດ [`Clone`] trait ແລະການໂທຫາວິທີ [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! ຕົວຢ່າງການນໍາໃຊ້ຂັ້ນພື້ນຖານ:
//!
//! ```
//! let s = String::new(); // ປະເພດສາຍສະຕິງໃຊ້ Clone
//! let copy = s.clone(); // ສະນັ້ນພວກເຮົາສາມາດໂຄນມັນໄດ້
//! ```
//!
//! ໄປໄດ້ຢ່າງງ່າຍດາຍປະຕິບັດການ Clone trait, ທ່ານຍັງສາມາດນໍາໃຊ້ `#[derive(Clone)]`.ຕົວຢ່າງ:
//!
//! ```
//! #[derive(Clone)] // ພວກເຮົາໄດ້ເພີ່ມການ Clone trait ກັບ Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ແລະໃນປັດຈຸບັນພວກເຮົາສາມາດ clone ມັນ!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait ທົ່ວໄປ ສຳ ລັບຄວາມສາມາດໃນການຊໍ້າຊ້ອນວັດຖຸໃດ ໜຶ່ງ ຢ່າງຈະແຈ້ງ.
///
/// ຄວາມແຕກຕ່າງຈາກ [`Copy`] ໃນນັ້ນ [`Copy`] ແມ່ນມີຄວາມຊັດເຈນແລະມີລາຄາຖືກທີ່ສຸດ, ໃນຂະນະທີ່ `Clone` ແມ່ນມີຄວາມຊັດເຈນຢູ່ສະ ເໝີ ແລະອາດຈະຫລືບໍ່ແພງ.
/// ໃນຄໍາສັ່ງທີ່ຈະບັງຄັບໃຊ້ລັກສະນະເຫຼົ່ານີ້, Rust ບໍ່ອະນຸຍາດໃຫ້ທ່ານ reimplement [`Copy`], ແຕ່ທ່ານອາດຈະ reimplement `Clone` ແລະດໍາເນີນການລະຫັດທີ່ຕົນເອງມັກ.
///
/// ເນື່ອງຈາກວ່າ `Clone` ແມ່ນໂດຍທົ່ວໄປຫຼາຍກ່ວາ [`Copy`], ທ່ານອັດຕະໂນມັດສາມາດເຮັດໃຫ້ສິ່ງໃດແດ່ [`Copy`] ຈະ `Clone` ເຊັ່ນດຽວກັນ.
///
/// ## Derivable
///
/// trait ນີ້ສາມາດໃຊ້ກັບ `#[derive]` ຖ້າທຸກສະຖານທີ່ເປັນ `Clone`.ການປະຕິບັດ `ມາຈາກ [`Clone`] ເອີ້ນ [`clone`] ໃນແຕ່ລະພາກສະ ໜາມ.
///
/// [`clone`]: Clone::clone
///
/// ສຳ ລັບໂຄງສ້າງທົ່ວໄປ, `#[derive]` ປະຕິບັດ `Clone` ທີ່ມີເງື່ອນໄຂໂດຍການເພີ່ມ `Clone` ທີ່ຜູກມັດໃສ່ຕົວ ກຳ ນົດການທົ່ວໄປ.
///
/// ```
/// // `derive` ປະຕິບັດ Clone ສໍາລັບການອ່ານຫນັງສື<T>ໃນເວລາທີ່ T ແມ່ນ Clone.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## ແນວໃດຂ້າພະເຈົ້າສາມາດປະຕິບັດ `Clone`?
///
/// ປະເພດທີ່ມີ [`Copy`] ຄວນມີການປະຕິບັດ trivial ຂອງ `Clone`.ຫຼາຍຢ່າງເປັນທາງການ:
/// ຖ້າ `T: Copy`, `x: T`, ແລະ `y: &T`, ຫຼັງຈາກນັ້ນ `let x = y.clone();` ແມ່ນເທົ່າກັບ `let x = *y;`.
/// ການປະຕິບັດຄູ່ມືຄວນຈະລະມັດລະວັງເພື່ອສະຫນັບສະຫນູນຄົງນີ້;ເຖິງຢ່າງໃດກໍ່ຕາມ, ລະຫັດທີ່ບໍ່ປອດໄພຕ້ອງບໍ່ອີງໃສ່ມັນເພື່ອຮັບປະກັນຄວາມປອດໄພຂອງຄວາມຊົງ ຈຳ.
///
/// ຕົວຢ່າງແມ່ນໂຄງສ້າງທົ່ວໄປທີ່ຖືຕົວຊີ້ທິດ ໜ້າ ທີ່.ໃນກໍລະນີດັ່ງກ່າວນີ້, ການປະຕິບັດຂອງ `Clone` ບໍ່ສາມາດຈະ `derive`d, ແຕ່ສາມາດໄດ້ຮັບການປະຕິບັດເປັນ:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## ຜູ້ປະຕິບັດການເພີ່ມເຕີມ
///
/// ນອກເຫນືອໄປຈາກ [implementors listed below][impls], ປະເພດດັ່ງຕໍ່ໄປນີ້ຍັງໃຊ້ `Clone`:
///
/// * ປະເພດລາຍການ Function (ຕົວຢ່າງ, ປະເພດທີ່ແຕກຕ່າງກັນກໍານົດສໍາລັບແຕ່ລະການທໍາງານ)
/// * ປະເພດຊີ້ Function (ຕົວຢ່າງ: , `fn() -> i32`)
/// * ປະເພດ Array, ສໍາລັບທຸກຂະຫນາດ, ຖ້າຫາກວ່າປະເພດລາຍການທີ່ຍັງປະຕິບັດ `Clone` (ຕົວຢ່າງ: , `[i32; 123456]`)
/// * ປະເພດ Tuple, ຖ້າແຕ່ລະສ່ວນປະກອບກໍ່ປະຕິບັດ `Clone` (ເຊັ່ນ: `()`, `(i32, bool)`)
/// * ປະເພດການປິດ, ຖ້າພວກມັນບໍ່ມີມູນຄ່າໃດໆຈາກສະພາບແວດລ້ອມຫລືຖ້າຄຸນຄ່າທີ່ຈັບໄດ້ທັງ ໝົດ ນັ້ນປະຕິບັດ `Clone` ຕົວເອງ.
///   ໃຫ້ສັງເກດວ່າຕົວແປທີ່ຖືກຈັບໂດຍການອ້າງອີງທີ່ໃຊ້ຮ່ວມກັນສະເຫມີປະຕິບັດ `Clone` (ເຖິງແມ່ນວ່າເອກະສານອ້າງອີງບໍ່ໄດ້), ໃນຂະນະທີ່ຕົວແປທີ່ຖືກຈັບໂດຍການອ້າງອິງທີ່ປ່ຽນແປງບໍ່ເຄີຍປະຕິບັດ `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// ຜົນໄດ້ຮັບສໍາເນົາຂອງມູນຄ່າໄດ້.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ປະຕິບັດ Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// ດໍາເນີນການສໍາເນົາ, ການມອບຫມາຍຈາກ `source`.
    ///
    /// `a.clone_from(&b)` ເທົ່າກັບ `a = b.clone()` ໃນການເຮັດວຽກ, ແຕ່ສາມາດຖືກ overridden ເພື່ອ ນຳ ໃຊ້ຊັບພະຍາກອນຂອງ `a` ເພື່ອຫລີກລ້ຽງການຈັດສັນທີ່ບໍ່ ຈຳ ເປັນ.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// ສ້າງມາຈາກມະຫາພາກສ້າງແຮງບັນດານໃຈຂອງ trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ໂຄງສ້າງເຫຼົ່ານີ້ຖືກ ນຳ ໃຊ້ໂດຍ#[ອ້າງອີງ] ເພື່ອຮັບຮອງວ່າທຸກໆສ່ວນປະກອບຂອງເຄື່ອງຈັກປະເພດໃດ ໜຶ່ງ ປະຕິບັດ Clone ຫຼື Copy.
//
//
// ໂຄງສ້າງເຫຼົ່ານີ້ບໍ່ຄວນສະແດງຢູ່ໃນລະຫັດຜູ້ໃຊ້.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// ການປະຕິບັດຂອງ `Clone` ສໍາລັບປະເພດເບື້ອງຕົ້ນ.
///
/// ການປະຕິບັດທີ່ບໍ່ສາມາດອະທິບາຍໄດ້ໃນ Rust ແມ່ນຖືກປະຕິບັດໃນ `traits::SelectionContext::copy_clone_conditions()` ໃນ `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// ເອກະສານອ້າງອີງທີ່ສາມາດແບ່ງປັນສາມາດເຮັດເປັນ cloned ໄດ້, ແຕ່ການອ້າງອິງທີ່ປ່ຽນແປງໄດ້ *ບໍ່*
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// ເອກະສານອ້າງອີງທີ່ສາມາດແບ່ງປັນສາມາດເຮັດເປັນ cloned ໄດ້, ແຕ່ການອ້າງອິງທີ່ປ່ຽນແປງໄດ້ *ບໍ່*
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}