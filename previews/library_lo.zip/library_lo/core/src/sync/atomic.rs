//! ປະເພດປະລໍາມະນູ
//!
//! ປະເພດປະລໍາມະນູສະ ໜອງ ການສື່ສານຄວາມຊົງ ຈຳ ແບບເດີມໆລະຫວ່າງກະທູ້, ແລະເປັນຕົວສ້າງຂອງປະເພດອື່ນໆພ້ອມກັນ.
//!
//! ໂມດູນນີ້ ກຳ ນົດສະບັບປະລະມານູຂອງ ຈຳ ນວນເລືອກປະເພດເດີມ, ລວມທັງ [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], ແລະອື່ນໆ.
//! ປະເພດປະລໍາມະນູນໍາສະເຫນີການດໍາເນີນງານທີ່, ໃນເວລາທີ່ຖືກນໍາໃຊ້ຢ່າງຖືກຕ້ອງ, synchronize updates ລະຫວ່າງກະທູ້.
//!
//! ວິທີການແຕ່ລະໃຊ້ເວລາເປັນ [`Ordering`] ທີ່ເປັນຕົວແທນຄວາມເຂັ້ມແຂງຂອງອຸປະສັກຄວາມຊົງຈໍາສໍາລັບການປະຕິບັດງານທີ່ໄດ້.ຄໍາສັ່ງເຫຼົ່ານີ້ແມ່ນຄືກັນກັບທີ່ [C++20 atomic orderings][1].ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມໃຫ້ເບິ່ງທີ່ [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! ຕົວແປປະລໍາມະນູມີຄວາມປອດໄພທີ່ຈະແບ່ງປັນລະຫວ່າງກະທູ້ (ພວກມັນປະຕິບັດ [`Sync`]) ແຕ່ພວກມັນບໍ່ໄດ້ໃຫ້ກົນໄກການແບ່ງປັນແລະເຮັດຕາມ [threading model](../../../std/thread/index.html#the-threading-model) ຂອງ Rust.
//!
//! ວິທີທີ່ໃຊ້ທົ່ວໄປທີ່ສຸດໃນການແບ່ງປັນຕົວແປປະລໍາມະນູແມ່ນການເອົາມັນເປັນ [`Arc`][arc] (ຕົວຊີ້ບອກການແບ່ງປັນປະລໍາມະນູ-ອ້າງອີງ).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! ປະເພດປະລໍາມະນູອາດຈະຖືກເກັບໄວ້ໃນຕົວແປທີ່ຄົງທີ່, ເລີ່ມຕົ້ນໂດຍໃຊ້ຕົວເລີ່ມຕົ້ນຄົງທີ່ເຊັ່ນ [`AtomicBool::new`].ສະຖິຕິປະລໍາມະນູມັກຖືກນໍາໃຊ້ເພື່ອການເລີ່ມຕົ້ນຂອງໂລກທີ່ຂີ້ຕົວະ.
//!
//! # Portability
//!
//! ທຸກປະເພດປະລໍາມະນູໃນໂມດູນນີ້ແມ່ນຮັບປະກັນວ່າເປັນ [lock-free] ຖ້າມັນມີ.ນີ້ ໝາຍ ຄວາມວ່າພວກເຂົາບໍ່ໄດ້ຮັບ mutex ທົ່ວໂລກ.ປະເພດແລະການປະຕິບັດງານປະລໍາມະນູບໍ່ໄດ້ຮັບປະກັນວ່າຈະບໍ່ລໍຖ້າ.
//! ນີ້ຫມາຍຄວາມວ່າການດໍາເນີນງານເຊັ່ນ `fetch_or` ອາດຈະຖືກປະຕິບັດດ້ວຍວົງຈອນປຽບທຽບແລະແລກປ່ຽນ.
//!
//! ການປະຕິບັດງານປະລໍາມະນູອາດຈະຖືກຈັດຕັ້ງປະຕິບັດຢູ່ຊັ້ນການສອນດ້ວຍປະລໍາມະນູທີ່ມີຂະ ໜາດ ໃຫຍ່ກວ່າ.ຕົວຢ່າງບາງແພລະຕະຟອມໃຊ້ ຄຳ ແນະ ນຳ ປະລໍາມະນູ 4-byte ເພື່ອປະຕິບັດ `AtomicI8`.
//! ໃຫ້ສັງເກດວ່າການເຮັດຕາມແບບນີ້ບໍ່ຄວນມີຜົນກະທົບຕໍ່ຄວາມຖືກຕ້ອງຂອງລະຫັດ, ມັນເປັນພຽງສິ່ງທີ່ຄວນລະວັງ.
//!
//! ປະເພດປະລໍາມະນູໃນໂມດູນນີ້ອາດຈະບໍ່ມີຢູ່ໃນທຸກແພລະຕະຟອມ.ປະເພດປະລໍາມະນູນີ້ແມ່ນທັງຫມົດທີ່ມີຢູ່ຢ່າງກວ້າງຂວາງ, ຢ່າງໃດກໍຕາມ, ແລະໂດຍທົ່ວໄປສາມາດໄດ້ຮັບການເພິ່ງພາອາໄສຕາມທີ່ມີຢູ່ແລ້ວ.ບາງຂໍ້ຍົກເວັ້ນທີ່ ໜ້າ ສັງເກດແມ່ນ:
//!
//! * PowerPC ແລະແພລະຕະຟອມ MIPS ທີ່ມີຕົວຊີ້ 32 ບິດບໍ່ມີ `AtomicU64` ຫຼື `AtomicI64` ປະເພດ.
//! * ARM ແພລະຕະຟອມເຊັ່ນ `armv5te` ທີ່ບໍ່ແມ່ນ ສຳ ລັບ Linux ພຽງແຕ່ສະ ໜອງ ການ ດຳ ເນີນງານ `load` ແລະ `store`, ແລະບໍ່ສະ ໜັບ ສະ ໜູນ ການ ດຳ ເນີນການປຽບທຽບແລະ Swap (CAS) ເຊັ່ນ `swap`, `fetch_add`, ແລະອື່ນໆ.
//! ເພີ່ມເຕີມກ່ຽວກັບ Linux, ການປະຕິບັດງານຂອງ CAS ເຫຼົ່ານີ້ຖືກປະຕິບັດຜ່ານ [operating system support], ເຊິ່ງອາດຈະມາພ້ອມກັບການລົງໂທດການປະຕິບັດ.
//! * ARM ເປົ້າ ໝາຍ ທີ່ມີ `thumbv6m` ພຽງແຕ່ສະ ໜອງ ການ ດຳ ເນີນງານ `load` ແລະ `store`, ແລະບໍ່ສະ ໜັບ ສະ ໜູນ ການ ດຳ ເນີນການປຽບທຽບແລະ Swap (CAS), ເຊັ່ນ `swap`, `fetch_add`, ແລະອື່ນໆ.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! ໃຫ້ສັງເກດວ່າເວທີ future ອາດຈະເພີ່ມວ່າຍັງບໍ່ມີສະຫນັບສະຫນູນສໍາລັບການປະຕິບັດງານປະລໍາມະນູຈໍານວນຫນຶ່ງ.ລະຫັດແບບພະກະພາສູງສຸດຈະຕ້ອງລະວັງກ່ຽວກັບປະເພດປະລໍາມະນູທີ່ໃຊ້.
//! `AtomicUsize` ແລະ `AtomicIsize` ໂດຍທົ່ວໄປແມ່ນເຄື່ອງທີ່ສາມາດ ນຳ ໃຊ້ໄດ້ຫຼາຍທີ່ສຸດ, ແຕ່ເຖິງແມ່ນວ່າຫຼັງຈາກນັ້ນພວກມັນກໍ່ບໍ່ມີຢູ່ທົ່ວທຸກບ່ອນ.
//! ສຳ ລັບການອ້າງອີງ, ຫ້ອງສະ ໝຸດ `std` ຕ້ອງການປະຕິບັດຕົວຊີ້ຂະ ໜາດ ຕົວຊີ້ວັດ, ເຖິງແມ່ນວ່າ `core` ບໍ່ໄດ້.
//!
//! ໃນປະຈຸບັນທ່ານ ຈຳ ເປັນຕ້ອງໃຊ້ `#[cfg(target_arch)]` ຕົ້ນຕໍເພື່ອການລວບລວມຂໍ້ມູນດ້ວຍລະຫັດກັບປະລໍາມະນູ.ມີ `#[cfg(target_has_atomic)]` ທີ່ບໍ່ຫມັ້ນຄົງເຊັ່ນດຽວກັນເຊິ່ງອາດຈະມີສະຖຽນລະພາບໃນ future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! A spinlock ງ່າຍດາຍ:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // ລໍຖ້າກະທູ້ອື່ນປ່ອຍປົດລັອກ
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! ໃຫ້ເກັບຮັກສາເປັນຈໍານວນທົ່ວໂລກຂອງກະທູ້ທີ່ມີຊີວິດ:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// ປະເພດບູຮານທີ່ສາມາດແບ່ງປັນກັນໄດ້ລະຫວ່າງກະທູ້.
///
/// ປະເພດນີ້ມີຕົວແທນໃນຄວາມ ຈຳ ຄືກັນກັບ [`bool`].
///
/// **ໝາຍ ເຫດ**: ປະເພດນີ້ມີແຕ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການໂຫຼດແລະຮ້ານຂອງປະລໍາມະນູ `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// ສ້າງ `AtomicBool` ເລີ່ມຕົ້ນເປັນ `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// ສົ່ງໄດ້ຖືກຈັດຕັ້ງປະຕິບັດຢ່າງສົມບູນແບບ ສຳ ລັບ AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// ປະເພດຕົວຊີ້ວັດຖຸດິບເຊິ່ງສາມາດແບ່ງປັນລະຫວ່າງກະທູ້ໄດ້ຢ່າງປອດໄພ.
///
/// ປະເພດນີ້ມີຕົວແທນໃນຄວາມ ຈຳ ຄືກັນກັບ `*mut T`.
///
/// **ຫມາຍເຫດ**: ປະເພດນີ້ສາມາດໃຊ້ໄດ້ພຽງແຕ່ໃນເວທີທີ່ສະຫນັບສະຫນູນການໂຫຼດປະລໍາມະນູແລະຮ້ານຂອງ pointers.
/// ຂະຫນາດຂອງມັນຂຶ້ນກັບຂະຫນາດຊີ້ເປົ້າຫມາຍຂອງ.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// ສ້າງ `AtomicPtr<T>` null.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// ການຈັດລໍາດັບຄວາມຈໍາປະລໍາມະນູ
///
/// ການຈັດລໍາດັບຄວາມຊົງຈໍາລະບຸວິທີການປະຕິບັດງານຂອງປະລໍາມະນູ synchronize ຄວາມຈໍາ.
/// ໃນ [`Ordering::Relaxed`] ທີ່ອ່ອນແອທີ່ສຸດ, ມີພຽງແຕ່ຄວາມຊົງ ຈຳ ທີ່ຖືກແຕະຕ້ອງໂດຍກົງຈາກການປະຕິບັດງານເທົ່ານັ້ນ.
/// ໃນອີກດ້ານຫນຶ່ງ, ເປັນຄູ່ຮ້ານການໂຫຼດຂອງການດໍາເນີນງານ [`Ordering::SeqCst`] synchronize ຫນ່ວຍຄວາມຈໍາອື່ນໆໃນຂະນະທີ່ຍັງຮັກສາຄໍາສັ່ງທັງຫມົດຂອງການດໍາເນີນງານດັ່ງກ່າວໃນທົ່ວຫົວຂໍ້ທັງຫມົດ.
///
///
/// ການສັ່ງເຄື່ອງຄວາມ ຈຳ ຂອງ Rust ແມ່ນ [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// ສໍາລັບຂໍ້ມູນເພີ່ມເຕີມເບິ່ງ [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// ບໍ່ມີຂໍ້ ຈຳ ກັດໃນການສັ່ງຊື້, ມີພຽງແຕ່ການປະຕິບັດງານປະລະມານູ.
    ///
    /// ເທົ່າກັບ [`memory_order_relaxed`] ໃນ C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// ເມື່ອສົມທົບກັບຮ້ານ, ທຸກໆການ ດຳ ເນີນງານທີ່ຜ່ານມາກາຍເປັນ ຄຳ ສັ່ງກ່ອນທີ່ຈະມີຄ່າໃດໆກັບການສັ່ງຊື້ [`Acquire`] (ຫຼືເຂັ້ມແຂງກວ່າ).
    ///
    /// ໂດຍສະເພາະ, ຂຽນຜ່ານມາທັງຫມົດເປັນຮູບເປັນຮ່າງເພື່ອກະທູ້ທັງຫມົດທີ່ປະຕິບັດການ [`Acquire`] (ຫຼືແຂງແຮງ) ການໂຫຼດຂອງມູນຄ່ານີ້.
    ///
    /// ສັງເກດເຫັນວ່າການ ນຳ ໃຊ້ ຄຳ ສັ່ງນີ້ ສຳ ລັບການປະຕິບັດງານທີ່ປະສົມປະສານກັບການໂຫຼດແລະຮ້ານຕ່າງໆເຮັດໃຫ້ການ ດຳ ເນີນງານທີ່ມີການໂຫຼດ [`Relaxed`]!
    ///
    /// ການສັ່ງຊື້ສິນຄ້ານີ້ແມ່ນໃຊ້ໄດ້ກັບການປະຕິບັດງານທີ່ສາມາດປະຕິບັດຮ້ານໄດ້ເທົ່ານັ້ນ.
    ///
    /// ກົງກັບ [`memory_order_release`] ໃນ C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// ເມື່ອສົມທົບກັບການໂຫຼດ, ຖ້າມູນຄ່າທີ່ຖືກບັນຈຸຖືກຂຽນໂດຍການປະຕິບັດງານຂອງຮ້ານທີ່ມີ [`Release`] (ຫຼືເຂັ້ມແຂງກວ່າ), ຫຼັງຈາກນັ້ນ, ການ ດຳ ເນີນງານຕໍ່ມາທັງ ໝົດ ກໍ່ຈະຖືກສັ່ງຫຼັງຈາກຮ້ານນັ້ນ.
    /// ໂດຍສະເພາະ, ການໂຫຼດຕໍ່ໆໄປທັງ ໝົດ ຈະເຫັນຂໍ້ມູນທີ່ຂຽນໄວ້ກ່ອນ ໜ້າ ຮ້ານ.
    ///
    /// ສັງເກດເຫັນວ່າການ ນຳ ໃຊ້ ຄຳ ສັ່ງນີ້ ສຳ ລັບການ ດຳ ເນີນງານທີ່ປະສົມປະສານກັບການໂຫຼດແລະຮ້ານຕ່າງໆ ນຳ ໄປສູ່ການ ດຳ ເນີນງານຂອງຮ້ານ [`Relaxed`]!
    ///
    /// ການຈັດລໍາດັບນີ້ແມ່ນໃຊ້ໄດ້ພຽງແຕ່ສໍາລັບການປະຕິບັດງານທີ່ສາມາດປະຕິບັດການໂຫຼດໄດ້.
    ///
    /// ກົງກັບ [`memory_order_acquire`] ໃນ C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// ມີຜົນກະທົບທັງ [`Acquire`] ແລະ [`Release`] ຮ່ວມກັນ:
    /// ສໍາລັບການໂຫຼດມັນໃຊ້ [`Acquire`] ກໍາລັງສັ່ງ.ສຳ ລັບຮ້ານມັນໃຊ້ ຄຳ ສັ່ງ [`Release`].
    ///
    /// ສັງເກດເຫັນວ່າໃນກໍລະນີຂອງ `compare_and_swap`, ມັນເປັນໄປໄດ້ວ່າການປະຕິບັດງານສິ້ນສຸດລົງບໍ່ໄດ້ປະຕິບັດຮ້ານໃດໆແລະເພາະສະນັ້ນມັນມີພຽງແຕ່ສັ່ງ [`Acquire`] ເທົ່ານັ້ນ.
    ///
    /// ເຖິງຢ່າງໃດກໍ່ຕາມ, `AcqRel` ຈະບໍ່ປະຕິບັດການເຂົ້າເຖິງ [`Relaxed`] ເທື່ອ.
    ///
    /// ການຈັດລຽງລໍາດັບນີ້ແມ່ນສາມາດໃຊ້ໄດ້ພຽງແຕ່ສໍາລັບການປະຕິບັດງານເຊິ່ງລວມທັງການໂຫຼດແລະຮ້ານ.
    ///
    /// ກົງກັບ [`memory_order_acq_rel`] ໃນ C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// ເຊັ່ນດຽວກັນກັບ [`Acquire`]/[`ປ່ອຍ`]/[`AcqRel`](ສຳ ລັບການຈັດເກັບ, ເກັບມ້ຽນແລະການປະຕິບັດງານກັບຮ້ານ, ຕາມ ລຳ ດັບ) ດ້ວຍການຄ້ ຳ ປະກັນເພີ່ມເຕີມທີ່ກະທູ້ທັງ ໝົດ ເຫັນການ ດຳ ເນີນງານທີ່ສອດຄ່ອງກັນໃນ ລຳ ດັບດຽວກັນ .
    ///
    ///
    /// ກົງກັບ [`memory_order_seq_cst`] ໃນ C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// ເປັນ [`AtomicBool`] ກຽມເພື່ອ `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// ສ້າງ `AtomicBool` ໃໝ່.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// ສົ່ງຄືນການອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບ [`bool`] ທີ່ຢູ່ເບື້ອງຕົ້ນ.
    ///
    /// ນີ້ແມ່ນປອດໄພເພາະວ່າເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ຮັບປະກັນວ່າບໍ່ມີກະທູ້ອື່ນໃດທີ່ເຂົ້າເຖິງຂໍ້ມູນປະລໍາມະນູພ້ອມໆກັນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // ຄວາມປອດໄພ: ການອ້າງອິງທີ່ປ່ຽນແປງໄດ້ຮັບປະກັນຄວາມເປັນເຈົ້າຂອງທີ່ເປັນເອກະລັກ.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// ໄດ້ຮັບການເຂົ້າເຖິງປະລໍາມະນູກັບ `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // ຄວາມປອດໄພ: ການອ້າງອິງທີ່ປ່ຽນແປງໄດ້ຮັບປະກັນຄວາມເປັນເຈົ້າຂອງ, ແລະ
        // ຄວາມສອດຄ່ອງຂອງທັງສອງ `bool` ແລະ `Self` ແມ່ນ 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// ບໍລິໂພກປະລໍາມະນູແລະສົ່ງຄືນຄ່າທີ່ມີຢູ່.
    ///
    /// ນີ້ແມ່ນປອດໄພເພາະວ່າການຜ່ານ `self` ໂດຍມູນຄ່າຮັບປະກັນວ່າບໍ່ມີກະທູ້ອື່ນໃດທີ່ເຂົ້າເຖິງຂໍ້ມູນປະລໍາມະນູພ້ອມໆກັນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// ໂຫຼດມູນຄ່າຈາກ bool.
    ///
    /// `load` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
    /// ຄ່າທີ່ເປັນໄປໄດ້ແມ່ນ [`SeqCst`], [`Acquire`] ແລະ [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `order` ແມ່ນ [`Release`] ຫຼື [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // ຄວາມປອດໄພ: ຂໍ້ມູນການແຂ່ງຂັນໃດໆຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູແລະວັດຖຸດິບ
        // ຕົວຊີ້ທີ່ຜ່ານເຂົ້າມາແມ່ນຖືກຕ້ອງເພາະວ່າພວກເຮົາໄດ້ຮັບມັນຈາກເອກະສານອ້າງອີງ.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// ເກັບມູນຄ່າເຂົ້າໃນ bool.
    ///
    /// `store` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
    /// ຄ່າທີ່ເປັນໄປໄດ້ແມ່ນ [`SeqCst`], [`Release`] ແລະ [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `order` ແມ່ນ [`Acquire`] ຫຼື [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // ຄວາມປອດໄພ: ຂໍ້ມູນການແຂ່ງຂັນໃດໆຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູແລະວັດຖຸດິບ
        // ຕົວຊີ້ທີ່ຜ່ານເຂົ້າມາແມ່ນຖືກຕ້ອງເພາະວ່າພວກເຮົາໄດ້ຮັບມັນຈາກເອກະສານອ້າງອີງ.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// ເກັບມູນຄ່າເຂົ້າໃນ bool, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// `swap` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
    /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
    ///
    ///
    /// **Note:** ວິທີການນີ້ສາມາດໃຊ້ໄດ້ພຽງແຕ່ໃນເວທີທີ່ສະຫນັບສະຫນູນການປະຕິບັດງານປະລໍາມະນູໃນ `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// ຮ້ານຄ່າເປັນ [`bool`] ຖ້າມູນຄ່າໃນປະຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `current`.
    ///
    /// ມູນຄ່າການສົ່ງຄືນແມ່ນສະເຫມີມູນຄ່າທີ່ຜ່ານມາ.ຖ້າມັນເທົ່າກັບ `current`, ຫຼັງຈາກນັ້ນມູນຄ່າໄດ້ຖືກປັບປຸງ.
    ///
    /// `compare_and_swap` ຍັງໃຊ້ເວລາໂຕ້ຖຽງ [`Ordering`] ເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
    /// ໃຫ້ສັງເກດວ່າເຖິງແມ່ນວ່າໃນເວລາທີ່ການນໍາໃຊ້ [`AcqRel`], ປະຕິບັດງານໄດ້ອາດຈະເຊັ່ນການແລກແລະເພາະສະນັ້ນພຽງແຕ່ປະຕິບັດພາລະ `Acquire`, ແຕ່ບໍ່ມີຄວາມຫມາຍ `Release`.
    /// ການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການປະຕິບັດງານນີ້ [`Relaxed`] ຖ້າມັນເກີດຂື້ນ, ແລະການໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນຂອງ [`Relaxed`] ໂຫຼດ.
    ///
    /// **Note:** ວິທີການນີ້ສາມາດໃຊ້ໄດ້ພຽງແຕ່ໃນເວທີທີ່ສະຫນັບສະຫນູນການປະຕິບັດງານປະລໍາມະນູໃນ `u8`.
    ///
    /// # ການໂຍກຍ້າຍໄປ `compare_exchange` ແລະ `compare_exchange_weak`
    ///
    /// `compare_and_swap` ເທົ່າກັບ `compare_exchange` ກັບແຜນທີ່ຕໍ່ໄປນີ້ ສຳ ລັບການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ:
    ///
    /// ຕົ້ນສະບັບ |ຄວາມ ສຳ ເລັດ |ຄວາມລົ້ມເຫຼວ
    /// -------- | ------- | -------
    /// ສະດວກສະບາຍ |ສະດວກສະບາຍ |ຂອງທີ່ໄດ້ມາສະດວກສະບາຍ |ໄດ້ມາ |ໄດ້ມາວາງຈໍາຫນ່າຍ |ປ່ອຍ |ສະດວກສະບາຍ AcqRel |AcqRel |ຮັບຊື້ SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ແມ່ນອະນຸຍາດໃຫ້ບໍ່ spuriously ເຖິງແມ່ນວ່າໃນເວລາທີ່ສົມທຽບສົບຜົນສໍາເລັດ, ຊຶ່ງອະນຸຍາດໃຫ້ compiler ໃນການສ້າງທີ່ດີກວ່າລະຫັດປະກອບໃນເວລາທີ່ສົມທຽບແລະແລກປ່ຽນປະສົບຖືກນໍາໃຊ້ໃນວົງໄດ້.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// ຮ້ານຄ່າເປັນ [`bool`] ຖ້າມູນຄ່າໃນປະຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `current`.
    ///
    /// ມູນຄ່າການກັບມາແມ່ນຜົນທີ່ຊີ້ບອກວ່າມູນຄ່າ ໃໝ່ ໄດ້ຖືກຂຽນແລະມີມູນຄ່າກ່ອນ ໜ້າ ນີ້.
    /// ໃນຄວາມ ສຳ ເລັດມູນຄ່ານີ້ແມ່ນຮັບປະກັນເທົ່າກັບ `current`.
    ///
    /// `compare_exchange` ໃຊ້ສອງ [`Ordering`] ໂຕ້ຖຽງເພື່ອອະທິບາຍການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
    /// `success` ອະທິບາຍເຖິງການຈັດລຽງ ລຳ ດັບທີ່ ຈຳ ເປັນ ສຳ ລັບການປະຕິບັດການອ່ານແກ້ໄຂການຂຽນທີ່ເກີດຂື້ນຖ້າການສົມທຽບກັບ `current` ສຳ ເລັດ.
    /// `failure` ອະທິບາຍ ຄຳ ສັ່ງທີ່ ຈຳ ເປັນ ສຳ ລັບການປະຕິບັດການໂຫຼດທີ່ເກີດຂື້ນເມື່ອການປຽບທຽບລົ້ມເຫລວ.
    /// ການ ນຳ ໃຊ້ [`Acquire`] ເປັນການຈັດ ລຳ ດັບຄວາມ ສຳ ເລັດເຮັດໃຫ້ຮ້ານເປັນສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ການໂຫຼດ [`Relaxed`] ປະສົບຜົນ ສຳ ເລັດ.
    ///
    /// ຄຳ ສັ່ງລົ້ມເຫລວສາມາດເປັນພຽງ [`SeqCst`], [`Acquire`] ຫລື [`Relaxed`] ແລະຕ້ອງເທົ່າກັບຫລືອ່ອນກວ່າການສັ່ງຊື້ທີ່ປະສົບຜົນ ສຳ ເລັດ.
    ///
    /// **Note:** ວິທີການນີ້ສາມາດໃຊ້ໄດ້ພຽງແຕ່ໃນເວທີທີ່ສະຫນັບສະຫນູນການປະຕິບັດງານປະລໍາມະນູໃນ `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// ຮ້ານຄ່າເປັນ [`bool`] ຖ້າມູນຄ່າໃນປະຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `current`.
    ///
    /// ບໍ່ຄືກັບ [`AtomicBool::compare_exchange`], ຟັງຊັນນີ້ຖືກອະນຸຍາດໃຫ້ລົ້ມເຫຼວຢ່າງໄວວາເຖິງແມ່ນວ່າການປຽບທຽບຈະປະສົບຜົນ ສຳ ເລັດ, ເຊິ່ງສາມາດສົ່ງຜົນໃຫ້ລະຫັດທີ່ມີປະສິດຕິພາບສູງຂື້ນໃນບາງເວທີ.
    ///
    /// ມູນຄ່າການກັບມາແມ່ນຜົນທີ່ຊີ້ບອກວ່າມູນຄ່າ ໃໝ່ ໄດ້ຖືກຂຽນແລະມີມູນຄ່າກ່ອນ ໜ້າ ນີ້.
    ///
    /// `compare_exchange_weak` ໃຊ້ສອງ [`Ordering`] ໂຕ້ຖຽງເພື່ອອະທິບາຍການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
    /// `success` ອະທິບາຍເຖິງການຈັດລຽງ ລຳ ດັບທີ່ ຈຳ ເປັນ ສຳ ລັບການປະຕິບັດການອ່ານແກ້ໄຂການຂຽນທີ່ເກີດຂື້ນຖ້າການສົມທຽບກັບ `current` ສຳ ເລັດ.
    /// `failure` ອະທິບາຍ ຄຳ ສັ່ງທີ່ ຈຳ ເປັນ ສຳ ລັບການປະຕິບັດການໂຫຼດທີ່ເກີດຂື້ນເມື່ອການປຽບທຽບລົ້ມເຫລວ.
    /// ການ ນຳ ໃຊ້ [`Acquire`] ເປັນການຈັດ ລຳ ດັບຄວາມ ສຳ ເລັດເຮັດໃຫ້ຮ້ານເປັນສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ການໂຫຼດ [`Relaxed`] ປະສົບຜົນ ສຳ ເລັດ.
    /// ຄຳ ສັ່ງລົ້ມເຫລວສາມາດເປັນພຽງ [`SeqCst`], [`Acquire`] ຫລື [`Relaxed`] ແລະຕ້ອງເທົ່າກັບຫລືອ່ອນກວ່າການສັ່ງຊື້ທີ່ປະສົບຜົນ ສຳ ເລັດ.
    ///
    /// **Note:** ວິທີການນີ້ສາມາດໃຊ້ໄດ້ພຽງແຕ່ໃນເວທີທີ່ສະຫນັບສະຫນູນການປະຕິບັດງານປະລໍາມະນູໃນ `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logical "and" ທີ່ມີຄ່າ boolean.
    ///
    /// ປະຕິບັດການ ດຳ ເນີນງານຢ່າງມີເຫດຜົນ "and" ກ່ຽວກັບມູນຄ່າປັດຈຸບັນແລະການໂຕ້ຖຽງ `val`, ແລະ ກຳ ນົດມູນຄ່າ ໃໝ່ ໃຫ້ກັບຜົນ.
    ///
    /// ຜົນໄດ້ຮັບມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// `fetch_and` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
    /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
    ///
    ///
    /// **Note:** ວິທີການນີ້ສາມາດໃຊ້ໄດ້ພຽງແຕ່ໃນເວທີທີ່ສະຫນັບສະຫນູນການປະຕິບັດງານປະລໍາມະນູໃນ `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logical "nand" ທີ່ມີຄ່າ boolean.
    ///
    /// ປະຕິບັດການ ດຳ ເນີນງານຢ່າງມີເຫດຜົນ "nand" ກ່ຽວກັບມູນຄ່າປັດຈຸບັນແລະການໂຕ້ຖຽງ `val`, ແລະ ກຳ ນົດມູນຄ່າ ໃໝ່ ໃຫ້ກັບຜົນ.
    ///
    /// ຜົນໄດ້ຮັບມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// `fetch_nand` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
    /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
    ///
    ///
    /// **Note:** ວິທີການນີ້ສາມາດໃຊ້ໄດ້ພຽງແຕ່ໃນເວທີທີ່ສະຫນັບສະຫນູນການປະຕິບັດງານປະລໍາມະນູໃນ `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // ພວກເຮົາບໍ່ສາມາດໃຊ້ atomic_nand ຢູ່ນີ້ໄດ້ເພາະມັນສາມາດສົ່ງຜົນໃຫ້ bool ມີຄ່າບໍ່ຖືກຕ້ອງ.
        // ນີ້ເກີດຂຶ້ນເພາະວ່າປະຕິບັດງານປະລໍາມະນູແມ່ນເຮັດດ້ວຍເປັນຈໍານວນເຕັມ 8-bit ພາຍໃນປະເທດທີ່ຈະຕັ້ງຄ່າເທິງ 7 bits.
        //
        // ສະນັ້ນພວກເຮົາພຽງແຕ່ໃຊ້ fetch_xor ຫລື swap ແທນ.
        if val {
            // ! (x&ຄວາມຈິງ)== !x ພວກເຮົາຕ້ອງປ່ຽນ bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true ພວກເຮົາຕ້ອງຕັ້ງ bool ໃຫ້ເປັນຄວາມຈິງ.
            //
            self.swap(true, order)
        }
    }

    /// Logical "or" ທີ່ມີຄ່າ boolean.
    ///
    /// ປະຕິບັດການ ດຳ ເນີນງານຢ່າງມີເຫດຜົນ "or" ກ່ຽວກັບມູນຄ່າປັດຈຸບັນແລະການໂຕ້ຖຽງ `val`, ແລະ ກຳ ນົດມູນຄ່າ ໃໝ່ ໃຫ້ກັບຜົນ.
    ///
    /// ຜົນໄດ້ຮັບມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// `fetch_or` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
    /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
    ///
    ///
    /// **Note:** ວິທີການນີ້ສາມາດໃຊ້ໄດ້ພຽງແຕ່ໃນເວທີທີ່ສະຫນັບສະຫນູນການປະຕິບັດງານປະລໍາມະນູໃນ `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logical "xor" ທີ່ມີຄ່າ boolean.
    ///
    /// ປະຕິບັດການ ດຳ ເນີນງານຢ່າງມີເຫດຜົນ "xor" ກ່ຽວກັບມູນຄ່າປັດຈຸບັນແລະການໂຕ້ຖຽງ `val`, ແລະ ກຳ ນົດມູນຄ່າ ໃໝ່ ໃຫ້ກັບຜົນ.
    ///
    /// ຜົນໄດ້ຮັບມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// `fetch_xor` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
    /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
    ///
    ///
    /// **Note:** ວິທີການນີ້ສາມາດໃຊ້ໄດ້ພຽງແຕ່ໃນເວທີທີ່ສະຫນັບສະຫນູນການປະຕິບັດງານປະລໍາມະນູໃນ `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// ສົ່ງຄືນຕົວຊີ້ທີ່ສາມາດປ່ຽນແປງໄດ້ກັບ [`bool`] ທີ່ຕິດພັນ.
    ///
    /// ການດໍາເນີນການທີ່ບໍ່ແມ່ນປະລໍາມະນູອ່ານແລະຂຽນກ່ຽວກັບ integer ຜົນທີ່ສາມາດເປັນເຊື້ອຊາດຂໍ້ມູນ.
    /// ວິທີການນີ້ສ່ວນໃຫຍ່ແມ່ນເປັນປະໂຫຍດ ສຳ ລັບ FFI, ບ່ອນທີ່ລາຍເຊັນ ໜ້າ ທີ່ອາດຈະໃຊ້ `*mut bool` ແທນ `&AtomicBool`.
    ///
    /// ກັບຄືນມາຕົວຊີ້ `*mut` ຈາກການອ້າງອີງຮ່ວມກັນກັບປະລໍາມະນູນີ້ແມ່ນປອດໄພເພາະວ່າປະເພດປະລໍາມະນູເຮັດວຽກກັບການປ່ຽນແປງພາຍໃນ.
    /// ການດັດແປງທັງ ໝົດ ຂອງອາຕອມປ່ຽນແປງຄ່າຜ່ານການອ້າງອິງຮ່ວມກັນ, ແລະສາມາດເຮັດໄດ້ຢ່າງປອດໄພຕາບໃດທີ່ພວກເຂົາໃຊ້ການປະຕິບັດງານປະລະມານູ.
    /// ການ ນຳ ໃຊ້ຕົວຊີ້ວັດວັດຖຸດິບທີ່ສົ່ງຄືນໃດ ໜຶ່ງ ຮຽກຮ້ອງໃຫ້ມີ `unsafe` ຕັນແລະຍັງຕ້ອງໄດ້ຍຶດຖືຂໍ້ ຈຳ ກັດຄືກັນ: ການ ດຳ ເນີນງານເທິງມັນຕ້ອງເປັນປະລໍາມະນູ.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// ເອົາໃຈໃສ່ຄຸນຄ່າ, ແລະ ນຳ ໃຊ້ຟັງຊັນທີ່ມັນກັບຄືນຄ່າ ໃໝ່ ທີ່ເປັນທາງເລືອກ.ສົ່ງຄືນ `Result` ຂອງ `Ok(previous_value)` ຖ້າຫນ້າທີ່ກັບຄືນ `Some(_)`, ອື່ນ `Err(previous_value)`.
    ///
    /// Note: ນີ້ອາດຈະໂທຫາທໍາງານຂອງການຫຼາຍເທື່ອຖ້າຫາກວ່າມູນຄ່າໄດ້ມີການປ່ຽນແປງຈາກຫົວຂໍ້ອື່ນ ໆ ໃນຂະນະດຽວກັນ, ຕາບໃດທີ່ການທໍາງານຂອງຜົນໄດ້ຮັບ `Some(_)`, ແຕ່ການເຄື່ອນໄຫວຈະໄດ້ຮັບການນໍາໃຊ້ພຽງແຕ່ຄັ້ງດຽວເພື່ອຄ່າເກັບຮັກສາໄວ້ໄດ້.
    ///
    ///
    /// `fetch_update` ໃຊ້ສອງ [`Ordering`] ໂຕ້ຖຽງເພື່ອອະທິບາຍການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
    /// ຄັ້ງທໍາອິດອະທິບາຍເຖິງການສັ່ງຊື້ທີ່ຕ້ອງການໃນເວລາທີ່ການປະຕິບັດງານສຸດທ້າຍປະສົບຜົນສໍາເລັດໃນຂະນະທີ່ທີສອງອະທິບາຍເຖິງການສັ່ງຊື້ທີ່ຕ້ອງການສໍາລັບການໂຫຼດ.
    /// ສິ່ງເຫຼົ່ານີ້ກົງກັບຜົນ ສຳ ເລັດແລະຄວາມລົ້ມເຫລວຂອງ [`AtomicBool::compare_exchange`] ຕາມ ລຳ ດັບ.
    ///
    /// ການ ນຳ ໃຊ້ [`Acquire`] ເປັນການຈັດ ລຳ ດັບຄວາມ ສຳ ເລັດເຮັດໃຫ້ຮ້ານເປັນສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ການໂຫຼດ [`Relaxed`] ຄັ້ງສຸດທ້າຍປະສົບຜົນ ສຳ ເລັດ.
    /// ການສັ່ງຊື້ແບບ (failed) ສາມາດເປັນ [`SeqCst`], [`Acquire`] ຫຼື [`Relaxed`] ເທົ່ານັ້ນແລະຕ້ອງເທົ່າກັບຫຼືອ່ອນກວ່າການສັ່ງຊື້ທີ່ປະສົບຜົນ ສຳ ເລັດ.
    ///
    /// **Note:** ວິທີການນີ້ສາມາດໃຊ້ໄດ້ພຽງແຕ່ໃນເວທີທີ່ສະຫນັບສະຫນູນການປະຕິບັດງານປະລໍາມະນູໃນ `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// ສ້າງ `AtomicPtr` ໃໝ່.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// ຄືນຄ່າອ້າງອິງບໍ່ແນ່ນອນກັບຊີ້ທີ່ຕິດພັນ.
    ///
    /// ນີ້ແມ່ນປອດໄພເພາະວ່າເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ຮັບປະກັນວ່າບໍ່ມີກະທູ້ອື່ນໃດທີ່ເຂົ້າເຖິງຂໍ້ມູນປະລໍາມະນູພ້ອມໆກັນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// ໄດ້ຮັບການເຂົ້າເຖິງປະລໍາມະນູກັບຕົວຊີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - ກະສານອ້າງອີງບໍ່ແນ່ນອນຮັບປະກັນຄວາມເປັນເຈົ້າຂອງເປັນເອກະລັກ.
        //  - ການຈັດຕໍາແຫນ່ງຂອງ `*mut T` ແລະ `Self` ແມ່ນຄືກັນກ່ຽວກັບເວທີການທັງຫມົດສະຫນັບສະຫນຸນໂດຍ rust, ເປັນການຢັ້ງຢືນຂ້າງເທິງ.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// ບໍລິໂພກປະລໍາມະນູແລະສົ່ງຄືນຄ່າທີ່ມີຢູ່.
    ///
    /// ນີ້ແມ່ນປອດໄພເພາະວ່າການຜ່ານ `self` ໂດຍມູນຄ່າຮັບປະກັນວ່າບໍ່ມີກະທູ້ອື່ນໃດທີ່ເຂົ້າເຖິງຂໍ້ມູນປະລໍາມະນູພ້ອມໆກັນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// ໂຫລດຄ່າຈາກຕົວຊີ້.
    ///
    /// `load` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
    /// ຄ່າທີ່ເປັນໄປໄດ້ແມ່ນ [`SeqCst`], [`Acquire`] ແລະ [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `order` ແມ່ນ [`Release`] ຫຼື [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// ເກັບຄ່າເຂົ້າໃນຕົວຊີ້.
    ///
    /// `store` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
    /// ຄ່າທີ່ເປັນໄປໄດ້ແມ່ນ [`SeqCst`], [`Release`] ແລະ [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `order` ແມ່ນ [`Acquire`] ຫຼື [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// ເກັບຄ່າເປັນຕົວຊີ້, ກັບຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// `swap` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
    /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
    ///
    ///
    /// **Note:** ວິທີການນີ້ແມ່ນມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ສະ ໜັບ ສະ ໜູນ ການ ດຳ ເນີນງານຂອງອາຕອມໃນຕົວຊີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// ເກັບຄ່າເຂົ້າໄປໃນຕົວຊີ້ຖ້າຄ່າປະຈຸບັນແມ່ນເທົ່າກັບຄ່າ `current`.
    ///
    /// ມູນຄ່າການສົ່ງຄືນແມ່ນສະເຫມີມູນຄ່າທີ່ຜ່ານມາ.ຖ້າມັນເທົ່າກັບ `current`, ຫຼັງຈາກນັ້ນມູນຄ່າໄດ້ຖືກປັບປຸງ.
    ///
    /// `compare_and_swap` ຍັງໃຊ້ເວລາໂຕ້ຖຽງ [`Ordering`] ເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
    /// ໃຫ້ສັງເກດວ່າເຖິງແມ່ນວ່າໃນເວລາທີ່ການນໍາໃຊ້ [`AcqRel`], ປະຕິບັດງານໄດ້ອາດຈະເຊັ່ນການແລກແລະເພາະສະນັ້ນພຽງແຕ່ປະຕິບັດພາລະ `Acquire`, ແຕ່ບໍ່ມີຄວາມຫມາຍ `Release`.
    /// ການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການປະຕິບັດງານນີ້ [`Relaxed`] ຖ້າມັນເກີດຂື້ນ, ແລະການໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນຂອງ [`Relaxed`] ໂຫຼດ.
    ///
    /// **Note:** ວິທີການນີ້ແມ່ນມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ສະ ໜັບ ສະ ໜູນ ການ ດຳ ເນີນງານຂອງອາຕອມໃນຕົວຊີ້.
    ///
    /// # ການໂຍກຍ້າຍໄປ `compare_exchange` ແລະ `compare_exchange_weak`
    ///
    /// `compare_and_swap` ເທົ່າກັບ `compare_exchange` ກັບແຜນທີ່ຕໍ່ໄປນີ້ ສຳ ລັບການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ:
    ///
    /// ຕົ້ນສະບັບ |ຄວາມ ສຳ ເລັດ |ຄວາມລົ້ມເຫຼວ
    /// -------- | ------- | -------
    /// ສະດວກສະບາຍ |ສະດວກສະບາຍ |ຂອງທີ່ໄດ້ມາສະດວກສະບາຍ |ໄດ້ມາ |ໄດ້ມາວາງຈໍາຫນ່າຍ |ປ່ອຍ |ສະດວກສະບາຍ AcqRel |AcqRel |ຮັບຊື້ SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ແມ່ນອະນຸຍາດໃຫ້ບໍ່ spuriously ເຖິງແມ່ນວ່າໃນເວລາທີ່ສົມທຽບສົບຜົນສໍາເລັດ, ຊຶ່ງອະນຸຍາດໃຫ້ compiler ໃນການສ້າງທີ່ດີກວ່າລະຫັດປະກອບໃນເວລາທີ່ສົມທຽບແລະແລກປ່ຽນປະສົບຖືກນໍາໃຊ້ໃນວົງໄດ້.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// ເກັບຄ່າເຂົ້າໄປໃນຕົວຊີ້ຖ້າຄ່າປະຈຸບັນແມ່ນເທົ່າກັບຄ່າ `current`.
    ///
    /// ມູນຄ່າການກັບມາແມ່ນຜົນທີ່ຊີ້ບອກວ່າມູນຄ່າ ໃໝ່ ໄດ້ຖືກຂຽນແລະມີມູນຄ່າກ່ອນ ໜ້າ ນີ້.
    /// ໃນຄວາມ ສຳ ເລັດມູນຄ່ານີ້ແມ່ນຮັບປະກັນເທົ່າກັບ `current`.
    ///
    /// `compare_exchange` ໃຊ້ສອງ [`Ordering`] ໂຕ້ຖຽງເພື່ອອະທິບາຍການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
    /// `success` ອະທິບາຍເຖິງການຈັດລຽງ ລຳ ດັບທີ່ ຈຳ ເປັນ ສຳ ລັບການປະຕິບັດການອ່ານແກ້ໄຂການຂຽນທີ່ເກີດຂື້ນຖ້າການສົມທຽບກັບ `current` ສຳ ເລັດ.
    /// `failure` ອະທິບາຍ ຄຳ ສັ່ງທີ່ ຈຳ ເປັນ ສຳ ລັບການປະຕິບັດການໂຫຼດທີ່ເກີດຂື້ນເມື່ອການປຽບທຽບລົ້ມເຫລວ.
    /// ການ ນຳ ໃຊ້ [`Acquire`] ເປັນການຈັດ ລຳ ດັບຄວາມ ສຳ ເລັດເຮັດໃຫ້ຮ້ານເປັນສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ການໂຫຼດ [`Relaxed`] ປະສົບຜົນ ສຳ ເລັດ.
    ///
    /// ຄຳ ສັ່ງລົ້ມເຫລວສາມາດເປັນພຽງ [`SeqCst`], [`Acquire`] ຫລື [`Relaxed`] ແລະຕ້ອງເທົ່າກັບຫລືອ່ອນກວ່າການສັ່ງຊື້ທີ່ປະສົບຜົນ ສຳ ເລັດ.
    ///
    /// **Note:** ວິທີການນີ້ແມ່ນມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ສະ ໜັບ ສະ ໜູນ ການ ດຳ ເນີນງານຂອງອາຕອມໃນຕົວຊີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// ເກັບຄ່າເຂົ້າໄປໃນຕົວຊີ້ຖ້າຄ່າປະຈຸບັນແມ່ນເທົ່າກັບຄ່າ `current`.
    ///
    /// ບໍ່ຄືກັບ [`AtomicPtr::compare_exchange`], ຟັງຊັນນີ້ຖືກອະນຸຍາດໃຫ້ລົ້ມເຫຼວຢ່າງໄວວາເຖິງແມ່ນວ່າການປຽບທຽບຈະປະສົບຜົນ ສຳ ເລັດ, ເຊິ່ງສາມາດສົ່ງຜົນໃຫ້ລະຫັດທີ່ມີປະສິດຕິພາບສູງຂື້ນໃນບາງເວທີ.
    ///
    /// ມູນຄ່າການກັບມາແມ່ນຜົນທີ່ຊີ້ບອກວ່າມູນຄ່າ ໃໝ່ ໄດ້ຖືກຂຽນແລະມີມູນຄ່າກ່ອນ ໜ້າ ນີ້.
    ///
    /// `compare_exchange_weak` ໃຊ້ສອງ [`Ordering`] ໂຕ້ຖຽງເພື່ອອະທິບາຍການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
    /// `success` ອະທິບາຍເຖິງການຈັດລຽງ ລຳ ດັບທີ່ ຈຳ ເປັນ ສຳ ລັບການປະຕິບັດການອ່ານແກ້ໄຂການຂຽນທີ່ເກີດຂື້ນຖ້າການສົມທຽບກັບ `current` ສຳ ເລັດ.
    /// `failure` ອະທິບາຍ ຄຳ ສັ່ງທີ່ ຈຳ ເປັນ ສຳ ລັບການປະຕິບັດການໂຫຼດທີ່ເກີດຂື້ນເມື່ອການປຽບທຽບລົ້ມເຫລວ.
    /// ການ ນຳ ໃຊ້ [`Acquire`] ເປັນການຈັດ ລຳ ດັບຄວາມ ສຳ ເລັດເຮັດໃຫ້ຮ້ານເປັນສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ການໂຫຼດ [`Relaxed`] ປະສົບຜົນ ສຳ ເລັດ.
    /// ຄຳ ສັ່ງລົ້ມເຫລວສາມາດເປັນພຽງ [`SeqCst`], [`Acquire`] ຫລື [`Relaxed`] ແລະຕ້ອງເທົ່າກັບຫລືອ່ອນກວ່າການສັ່ງຊື້ທີ່ປະສົບຜົນ ສຳ ເລັດ.
    ///
    /// **Note:** ວິທີການນີ້ແມ່ນມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ສະ ໜັບ ສະ ໜູນ ການ ດຳ ເນີນງານຂອງອາຕອມໃນຕົວຊີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // ຄວາມປອດໄພ: ສະຕິປັນຍາແບບນີ້ແມ່ນບໍ່ປອດໄພເພາະມັນ ດຳ ເນີນການກັບຕົວຊີ້ວັດຖຸດິບ
        // ແຕ່ພວກເຮົາຮູ້ຢ່າງແນ່ນອນວ່າຕົວຊີ້ແມ່ນຖືກຕ້ອງ (ພວກເຮົາຫາກໍ່ໄດ້ຈາກ `UnsafeCell` ທີ່ພວກເຮົາມີໂດຍອ້າງອີງ) ແລະການປະຕິບັດງານປະລະມານູເອງກໍ່ຊ່ວຍໃຫ້ພວກເຮົາປ່ຽນເນື້ອໃນ `UnsafeCell` ຢ່າງປອດໄພ.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// ເອົາໃຈໃສ່ຄຸນຄ່າ, ແລະ ນຳ ໃຊ້ຟັງຊັນທີ່ມັນກັບຄືນຄ່າ ໃໝ່ ທີ່ເປັນທາງເລືອກ.ສົ່ງຄືນ `Result` ຂອງ `Ok(previous_value)` ຖ້າຫນ້າທີ່ກັບຄືນ `Some(_)`, ອື່ນ `Err(previous_value)`.
    ///
    /// Note: ນີ້ອາດຈະໂທຫາທໍາງານຂອງການຫຼາຍເທື່ອຖ້າຫາກວ່າມູນຄ່າໄດ້ມີການປ່ຽນແປງຈາກຫົວຂໍ້ອື່ນ ໆ ໃນຂະນະດຽວກັນ, ຕາບໃດທີ່ການທໍາງານຂອງຜົນໄດ້ຮັບ `Some(_)`, ແຕ່ການເຄື່ອນໄຫວຈະໄດ້ຮັບການນໍາໃຊ້ພຽງແຕ່ຄັ້ງດຽວເພື່ອຄ່າເກັບຮັກສາໄວ້ໄດ້.
    ///
    ///
    /// `fetch_update` ໃຊ້ສອງ [`Ordering`] ໂຕ້ຖຽງເພື່ອອະທິບາຍການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
    /// ຄັ້ງທໍາອິດອະທິບາຍເຖິງການສັ່ງຊື້ທີ່ຕ້ອງການໃນເວລາທີ່ການປະຕິບັດງານສຸດທ້າຍປະສົບຜົນສໍາເລັດໃນຂະນະທີ່ທີສອງອະທິບາຍເຖິງການສັ່ງຊື້ທີ່ຕ້ອງການສໍາລັບການໂຫຼດ.
    /// ສິ່ງເຫຼົ່ານີ້ກົງກັບຜົນ ສຳ ເລັດແລະຄວາມລົ້ມເຫລວຂອງ [`AtomicPtr::compare_exchange`] ຕາມ ລຳ ດັບ.
    ///
    /// ການ ນຳ ໃຊ້ [`Acquire`] ເປັນການຈັດ ລຳ ດັບຄວາມ ສຳ ເລັດເຮັດໃຫ້ຮ້ານເປັນສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ການໂຫຼດ [`Relaxed`] ຄັ້ງສຸດທ້າຍປະສົບຜົນ ສຳ ເລັດ.
    /// ການສັ່ງຊື້ແບບ (failed) ສາມາດເປັນ [`SeqCst`], [`Acquire`] ຫຼື [`Relaxed`] ເທົ່ານັ້ນແລະຕ້ອງເທົ່າກັບຫຼືອ່ອນກວ່າການສັ່ງຊື້ທີ່ປະສົບຜົນ ສຳ ເລັດ.
    ///
    /// **Note:** ວິທີການນີ້ແມ່ນມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ສະ ໜັບ ສະ ໜູນ ການ ດຳ ເນີນງານຂອງອາຕອມໃນຕົວຊີ້.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// ແປງ `bool` ເປັນ `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // ມະຫາພາກນີ້ສິ້ນສຸດລົງໂດຍບໍ່ໄດ້ໃຊ້ໃນສະຖາປັດຕະຍະ ກຳ ບາງຢ່າງ.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// ເປັນປະເພດຈໍານວນເຕັມຊຶ່ງສາມາດແບ່ງປັນໄດ້ຢ່າງປອດໄພລະຫວ່າງຫົວຂໍ້.
        ///
        /// ປະເພດນີ້ມີຕົວແທນໃນຄວາມຊົງ ຈຳ ຄືກັນກັບປະເພດເລກຍ່ອຍ, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// ສໍາລັບເພີ່ມເຕີມກ່ຽວກັບຄວາມແຕກຕ່າງລະຫວ່າງປະເພດປະລໍາມະນູແລະປະເພດທີ່ບໍ່ແມ່ນປະລໍາມະນູເຊັ່ນດຽວກັນກັບຂໍ້ມູນກ່ຽວກັບການພະກະພາຂອງປະເພດນີ້, ກະລຸນາເບິ່ງ [module-level documentation].
        ///
        ///
        /// **Note:** ປະເພດນີ້ສາມາດໃຊ້ໄດ້ໃນເວທີຕ່າງໆເທົ່ານັ້ນທີ່ສະ ໜັບ ສະ ໜູນ ການໂຫຼດແລະປະເພດຂອງອະຕອມ
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// ຕົວເລກປະລໍາມະນູເລີ່ມຕົ້ນເປັນ `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // ສົ່ງແມ່ນປະຕິບັດຢ່າງສົມບູນ.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// ສ້າງຕົວເລກປະລໍາມະນູ ໃໝ່.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// ຄືນຄ່າອ້າງອິງບໍ່ແນ່ນອນກັບ integer ທີ່ຕິດພັນ.
            ///
            /// ນີ້ແມ່ນປອດໄພເພາະວ່າເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ຮັບປະກັນວ່າບໍ່ມີກະທູ້ອື່ນໃດທີ່ເຂົ້າເຖິງຂໍ້ມູນປະລໍາມະນູພ້ອມໆກັນ.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// let mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (ບາງຢ່າງ, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - ກະສານອ້າງອີງບໍ່ແນ່ນອນຮັບປະກັນຄວາມເປັນເຈົ້າຂອງເປັນເອກະລັກ.
                //  - ຄວາມສອດຄ່ອງຂອງ `$int_type` ແລະ `Self` ແມ່ນຄືກັນ, ຕາມທີ່ໄດ້ສັນຍາໄວ້ໂດຍ $cfg_align ແລະຢືນຢັນຂ້າງເທິງ.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// ບໍລິໂພກປະລໍາມະນູແລະສົ່ງຄືນຄ່າທີ່ມີຢູ່.
            ///
            /// ນີ້ແມ່ນປອດໄພເພາະວ່າການຜ່ານ `self` ໂດຍມູນຄ່າຮັບປະກັນວ່າບໍ່ມີກະທູ້ອື່ນໃດທີ່ເຂົ້າເຖິງຂໍ້ມູນປະລໍາມະນູພ້ອມໆກັນ.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// ໂຫຼດມູນຄ່າຈາກຕົວເລກປະລໍາມະນູ.
            ///
            /// `load` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
            /// ຄ່າທີ່ເປັນໄປໄດ້ແມ່ນ [`SeqCst`], [`Acquire`] ແລະ [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ຖ້າ `order` ແມ່ນ [`Release`] ຫຼື [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// ເກັບມູນຄ່າເຂົ້າໃນຕົວເລກປະລໍາມະນູ.
            ///
            /// `store` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
            ///  ຄ່າທີ່ເປັນໄປໄດ້ແມ່ນ [`SeqCst`], [`Release`] ແລະ [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics ຖ້າ `order` ແມ່ນ [`Acquire`] ຫຼື [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// ເກັບມູນຄ່າເຂົ້າໃນຕົວເລກປະລໍາມະນູ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
            ///
            /// `swap` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
            /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
            ///
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// ເກັບມູນຄ່າເຂົ້າໃນຕົວເລກປະລໍາມະນູຖ້າວ່າມູນຄ່າປັດຈຸບັນແມ່ນເທົ່າກັບຄ່າ `current`.
            ///
            /// ມູນຄ່າການສົ່ງຄືນແມ່ນສະເຫມີມູນຄ່າທີ່ຜ່ານມາ.ຖ້າມັນເທົ່າກັບ `current`, ຫຼັງຈາກນັ້ນມູນຄ່າໄດ້ຖືກປັບປຸງ.
            ///
            /// `compare_and_swap` ຍັງໃຊ້ເວລາໂຕ້ຖຽງ [`Ordering`] ເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
            /// ໃຫ້ສັງເກດວ່າເຖິງແມ່ນວ່າໃນເວລາທີ່ການນໍາໃຊ້ [`AcqRel`], ປະຕິບັດງານໄດ້ອາດຈະເຊັ່ນການແລກແລະເພາະສະນັ້ນພຽງແຕ່ປະຕິບັດພາລະ `Acquire`, ແຕ່ບໍ່ມີຄວາມຫມາຍ `Release`.
            ///
            /// ການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການປະຕິບັດງານນີ້ [`Relaxed`] ຖ້າມັນເກີດຂື້ນ, ແລະການໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນຂອງ [`Relaxed`] ໂຫຼດ.
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # ການໂຍກຍ້າຍໄປ `compare_exchange` ແລະ `compare_exchange_weak`
            ///
            /// `compare_and_swap` ເທົ່າກັບ `compare_exchange` ກັບແຜນທີ່ຕໍ່ໄປນີ້ ສຳ ລັບການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ:
            ///
            /// ຕົ້ນສະບັບ |ຄວາມ ສຳ ເລັດ |ຄວາມລົ້ມເຫຼວ
            /// -------- | ------- | -------
            /// ສະດວກສະບາຍ |ສະດວກສະບາຍ |ຂອງທີ່ໄດ້ມາສະດວກສະບາຍ |ໄດ້ມາ |ໄດ້ມາວາງຈໍາຫນ່າຍ |ປ່ອຍ |ສະດວກສະບາຍ AcqRel |AcqRel |ຮັບຊື້ SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` ແມ່ນອະນຸຍາດໃຫ້ບໍ່ spuriously ເຖິງແມ່ນວ່າໃນເວລາທີ່ສົມທຽບສົບຜົນສໍາເລັດ, ຊຶ່ງອະນຸຍາດໃຫ້ compiler ໃນການສ້າງທີ່ດີກວ່າລະຫັດປະກອບໃນເວລາທີ່ສົມທຽບແລະແລກປ່ຽນປະສົບຖືກນໍາໃຊ້ໃນວົງໄດ້.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// ເກັບມູນຄ່າເຂົ້າໃນຕົວເລກປະລໍາມະນູຖ້າວ່າມູນຄ່າປັດຈຸບັນແມ່ນເທົ່າກັບຄ່າ `current`.
            ///
            /// ມູນຄ່າການກັບມາແມ່ນຜົນທີ່ຊີ້ບອກວ່າມູນຄ່າ ໃໝ່ ໄດ້ຖືກຂຽນແລະມີມູນຄ່າກ່ອນ ໜ້າ ນີ້.
            /// ໃນຄວາມ ສຳ ເລັດມູນຄ່ານີ້ແມ່ນຮັບປະກັນເທົ່າກັບ `current`.
            ///
            /// `compare_exchange` ໃຊ້ສອງ [`Ordering`] ໂຕ້ຖຽງເພື່ອອະທິບາຍການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
            /// `success` ອະທິບາຍເຖິງການຈັດລຽງ ລຳ ດັບທີ່ ຈຳ ເປັນ ສຳ ລັບການປະຕິບັດການອ່ານແກ້ໄຂການຂຽນທີ່ເກີດຂື້ນຖ້າການສົມທຽບກັບ `current` ສຳ ເລັດ.
            /// `failure` ອະທິບາຍ ຄຳ ສັ່ງທີ່ ຈຳ ເປັນ ສຳ ລັບການປະຕິບັດການໂຫຼດທີ່ເກີດຂື້ນເມື່ອການປຽບທຽບລົ້ມເຫລວ.
            /// ການ ນຳ ໃຊ້ [`Acquire`] ເປັນການຈັດ ລຳ ດັບຄວາມ ສຳ ເລັດເຮັດໃຫ້ຮ້ານເປັນສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ການໂຫຼດ [`Relaxed`] ປະສົບຜົນ ສຳ ເລັດ.
            ///
            /// ຄຳ ສັ່ງລົ້ມເຫລວສາມາດເປັນພຽງ [`SeqCst`], [`Acquire`] ຫລື [`Relaxed`] ແລະຕ້ອງເທົ່າກັບຫລືອ່ອນກວ່າການສັ່ງຊື້ທີ່ປະສົບຜົນ ສຳ ເລັດ.
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// ເກັບມູນຄ່າເຂົ້າໃນຕົວເລກປະລໍາມະນູຖ້າວ່າມູນຄ່າປັດຈຸບັນແມ່ນເທົ່າກັບຄ່າ `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// ຟັງຊັນນີ້ຖືກອະນຸຍາດໃຫ້ລົ້ມເຫຼວຢ່າງໄວວາເຖິງແມ່ນວ່າການປຽບທຽບຈະປະສົບຜົນ ສຳ ເລັດ, ເຊິ່ງສາມາດສົ່ງຜົນໃຫ້ລະຫັດທີ່ມີປະສິດຕິພາບສູງຂື້ນໃນບາງເວທີ.
            /// ມູນຄ່າການກັບມາແມ່ນຜົນທີ່ຊີ້ບອກວ່າມູນຄ່າ ໃໝ່ ໄດ້ຖືກຂຽນແລະມີມູນຄ່າກ່ອນ ໜ້າ ນີ້.
            ///
            /// `compare_exchange_weak` ໃຊ້ສອງ [`Ordering`] ໂຕ້ຖຽງເພື່ອອະທິບາຍການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
            /// `success` ອະທິບາຍເຖິງການຈັດລຽງ ລຳ ດັບທີ່ ຈຳ ເປັນ ສຳ ລັບການປະຕິບັດການອ່ານແກ້ໄຂການຂຽນທີ່ເກີດຂື້ນຖ້າການສົມທຽບກັບ `current` ສຳ ເລັດ.
            /// `failure` ອະທິບາຍ ຄຳ ສັ່ງທີ່ ຈຳ ເປັນ ສຳ ລັບການປະຕິບັດການໂຫຼດທີ່ເກີດຂື້ນເມື່ອການປຽບທຽບລົ້ມເຫລວ.
            /// ການ ນຳ ໃຊ້ [`Acquire`] ເປັນການຈັດ ລຳ ດັບຄວາມ ສຳ ເລັດເຮັດໃຫ້ຮ້ານເປັນສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ການໂຫຼດ [`Relaxed`] ປະສົບຜົນ ສຳ ເລັດ.
            ///
            /// ຄຳ ສັ່ງລົ້ມເຫລວສາມາດເປັນພຽງ [`SeqCst`], [`Acquire`] ຫລື [`Relaxed`] ແລະຕ້ອງເທົ່າກັບຫລືອ່ອນກວ່າການສັ່ງຊື້ທີ່ປະສົບຜົນ ສຳ ເລັດ.
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// ໃຫ້ Mut ເກົ່າ= val.load(Ordering::Relaxed);
            /// loop {ປ່ອຍໃຫ້ ໃໝ່=ເກົ່າ * 2;
            ///     ກົງກັບ val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// ຕື່ມໃສ່ມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນມູນຄ່າທີ່ຜ່ານມາ.
            ///
            /// ການປະຕິບັດງານນີ້ຫຸ້ມຫໍ່ທົ່ວໄປ.
            ///
            /// `fetch_add` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
            /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
            ///
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// ການຫັກລົບຈາກມູນຄ່າໃນປະຈຸບັນ, ກັບຄືນມູນຄ່າທີ່ຜ່ານມາ.
            ///
            /// ການປະຕິບັດງານນີ້ຫຸ້ມຫໍ່ທົ່ວໄປ.
            ///
            /// `fetch_sub` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
            /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
            ///
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" ກັບມູນຄ່າປັດຈຸບັນ.
            ///
            /// ປະຕິບັດການປະຕິບັດງານ "and" ເລັກນ້ອຍກ່ຽວກັບມູນຄ່າປັດຈຸບັນແລະການໂຕ້ຖຽງ `val`, ແລະກໍານົດມູນຄ່າໃຫມ່ໃຫ້ກັບຜົນໄດ້ຮັບ.
            ///
            /// ຜົນໄດ້ຮັບມູນຄ່າທີ່ຜ່ານມາ.
            ///
            /// `fetch_and` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
            /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
            ///
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" ກັບມູນຄ່າປັດຈຸບັນ.
            ///
            /// ປະຕິບັດການປະຕິບັດງານ "nand" ເລັກນ້ອຍກ່ຽວກັບມູນຄ່າປັດຈຸບັນແລະການໂຕ້ຖຽງ `val`, ແລະກໍານົດມູນຄ່າໃຫມ່ໃຫ້ກັບຜົນໄດ້ຮັບ.
            ///
            /// ຜົນໄດ້ຮັບມູນຄ່າທີ່ຜ່ານມາ.
            ///
            /// `fetch_nand` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
            /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
            ///
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" ກັບມູນຄ່າປັດຈຸບັນ.
            ///
            /// ປະຕິບັດການປະຕິບັດງານ "or" ເລັກນ້ອຍກ່ຽວກັບມູນຄ່າປັດຈຸບັນແລະການໂຕ້ຖຽງ `val`, ແລະກໍານົດມູນຄ່າໃຫມ່ໃຫ້ກັບຜົນໄດ້ຮັບ.
            ///
            /// ຜົນໄດ້ຮັບມູນຄ່າທີ່ຜ່ານມາ.
            ///
            /// `fetch_or` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
            /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
            ///
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" ກັບມູນຄ່າປັດຈຸບັນ.
            ///
            /// ດໍາເນີນການເປັນຄ່າທີ່ເຫມາະສົມການດໍາເນີນ "xor" ກ່ຽວກັບມູນຄ່າໃນປະຈຸບັນແລະການໂຕ້ຖຽງ `val`, ແລະຊຸດມູນຄ່າໃຫມ່ເພື່ອຜົນໄດ້ຮັບ.
            ///
            /// ຜົນໄດ້ຮັບມູນຄ່າທີ່ຜ່ານມາ.
            ///
            /// `fetch_xor` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
            /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
            ///
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// ເອົາໃຈໃສ່ຄຸນຄ່າ, ແລະ ນຳ ໃຊ້ຟັງຊັນທີ່ມັນກັບຄືນຄ່າ ໃໝ່ ທີ່ເປັນທາງເລືອກ.ສົ່ງຄືນ `Result` ຂອງ `Ok(previous_value)` ຖ້າຫນ້າທີ່ກັບຄືນ `Some(_)`, ອື່ນ `Err(previous_value)`.
            ///
            /// Note: ນີ້ອາດຈະໂທຫາທໍາງານຂອງການຫຼາຍເທື່ອຖ້າຫາກວ່າມູນຄ່າໄດ້ມີການປ່ຽນແປງຈາກຫົວຂໍ້ອື່ນ ໆ ໃນຂະນະດຽວກັນ, ຕາບໃດທີ່ການທໍາງານຂອງຜົນໄດ້ຮັບ `Some(_)`, ແຕ່ການເຄື່ອນໄຫວຈະໄດ້ຮັບການນໍາໃຊ້ພຽງແຕ່ຄັ້ງດຽວເພື່ອຄ່າເກັບຮັກສາໄວ້ໄດ້.
            ///
            ///
            /// `fetch_update` ໃຊ້ສອງ [`Ordering`] ໂຕ້ຖຽງເພື່ອອະທິບາຍການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.
            /// ທໍາອິດອະທິບາຍຄໍາສັ່ງທີ່ກໍານົດໄວ້ສໍາລັບໃນເວລາທີ່ປະຕິບັດງານໃນທີ່ສຸດສົບຜົນສໍາເລັດໃນຂະນະທີ່ສອງອະທິບາຍຄໍາສັ່ງທີ່ກໍານົດໄວ້ສໍາລັບການໂຫຼດ.ກົງກັນເຫຼົ່ານີ້ເພື່ອຄວາມສໍາເລັດແລະຄວາມລົ້ມເຫຼວຂອງຄໍາສັ່ງຂອງ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// ການ ນຳ ໃຊ້ [`Acquire`] ເປັນການຈັດ ລຳ ດັບຄວາມ ສຳ ເລັດເຮັດໃຫ້ຮ້ານເປັນສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ການໂຫຼດ [`Relaxed`] ຄັ້ງສຸດທ້າຍປະສົບຜົນ ສຳ ເລັດ.
            /// ການສັ່ງຊື້ແບບ (failed) ສາມາດເປັນ [`SeqCst`], [`Acquire`] ຫຼື [`Relaxed`] ເທົ່ານັ້ນແລະຕ້ອງເທົ່າກັບຫຼືອ່ອນກວ່າການສັ່ງຊື້ທີ່ປະສົບຜົນ ສຳ ເລັດ.
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (ການສັ່ງຊື້: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (ການສັ່ງຊື້: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// ສູງສຸດທີ່ມີມູນຄ່າໃນປະຈຸບັນ.
            ///
            /// ຊອກຫາມູນຄ່າສູງສຸດຂອງມູນຄ່າປັດຈຸບັນແລະການໂຕ້ຖຽງ `val`, ແລະຕັ້ງຄ່າ ໃໝ່ ໃຫ້ກັບຜົນ.
            ///
            /// ຜົນໄດ້ຮັບມູນຄ່າທີ່ຜ່ານມາ.
            ///
            /// `fetch_max` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
            /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
            ///
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=42;
            /// ໃຫ້ max_foo=foo.fetch_max (ແຖບ, Ordering::SeqCst).max(bar);
            /// ຢືນຢັນ! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// ຂັ້ນຕ່ໍາທີ່ມີມູນຄ່າໃນປະຈຸບັນ.
            ///
            /// ຊອກຫາຕໍາ່ສຸດທີ່ຂອງມູນຄ່າປັດຈຸບັນແລະການໂຕ້ຖຽງ `val`, ແລະກໍານົດມູນຄ່າ ໃໝ່ ໃຫ້ກັບຜົນ.
            ///
            /// ຜົນໄດ້ຮັບມູນຄ່າທີ່ຜ່ານມາ.
            ///
            /// `fetch_min` ໃຊ້ [`Ordering`] ໂຕ້ຖຽງເຊິ່ງອະທິບາຍເຖິງການຈັດ ລຳ ດັບຄວາມຊົງ ຈຳ ຂອງການ ດຳ ເນີນງານນີ້.ທັງຫມົດຮູບແບບການກໍາລັງສັ່ງແມ່ນເປັນໄປໄດ້.
            /// ໃຫ້ສັງເກດວ່າການ ນຳ ໃຊ້ [`Acquire`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການ ດຳ ເນີນງານນີ້ [`Relaxed`], ແລະການ ນຳ ໃຊ້ [`Release`] ເຮັດໃຫ້ສ່ວນ ໜຶ່ງ ຂອງການໂຫຼດ [`Relaxed`].
            ///
            ///
            /// **ໝາຍ ເຫດ**: ວິທີການນີ້ມີຢູ່ໃນເວທີເທົ່ານັ້ນທີ່ຮອງຮັບການປະຕິບັດງານປະລະມານູ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=12;
            /// ໃຫ້ min_foo=foo.fetch_min (ແຖບ, Ordering::SeqCst).min(bar);
            /// ! assert_eq (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // ຄວາມປອດໄພ: ການແຂ່ງຂັນຂໍ້ມູນຖືກປ້ອງກັນໂດຍການບຸກລຸກປະລໍາມະນູ.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// ສົ່ງຄືນຕົວຊີ້ທີ່ສາມາດປ່ຽນແປງໄດ້ກັບຕົວເລກທີ່ຕິດພັນ.
            ///
            /// ການດໍາເນີນການທີ່ບໍ່ແມ່ນປະລໍາມະນູອ່ານແລະຂຽນກ່ຽວກັບ integer ຜົນທີ່ສາມາດເປັນເຊື້ອຊາດຂໍ້ມູນ.
            /// ວິທີການນີ້ສ່ວນໃຫຍ່ແມ່ນເປັນປະໂຫຍດ ສຳ ລັບ FFI, ບ່ອນທີ່ລາຍເຊັນ ໜ້າ ທີ່ອາດຈະໃຊ້
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// ກັບຄືນມາຕົວຊີ້ `*mut` ຈາກການອ້າງອີງຮ່ວມກັນກັບປະລໍາມະນູນີ້ແມ່ນປອດໄພເພາະວ່າປະເພດປະລໍາມະນູເຮັດວຽກກັບການປ່ຽນແປງພາຍໃນ.
            /// ການດັດແປງທັງ ໝົດ ຂອງອາຕອມປ່ຽນແປງຄ່າຜ່ານການອ້າງອິງຮ່ວມກັນ, ແລະສາມາດເຮັດໄດ້ຢ່າງປອດໄພຕາບໃດທີ່ພວກເຂົາໃຊ້ການປະຕິບັດງານປະລະມານູ.
            /// ການ ນຳ ໃຊ້ຕົວຊີ້ວັດວັດຖຸດິບທີ່ສົ່ງຄືນໃດ ໜຶ່ງ ຮຽກຮ້ອງໃຫ້ມີ `unsafe` ຕັນແລະຍັງຕ້ອງໄດ້ຍຶດຖືຂໍ້ ຈຳ ກັດຄືກັນ: ການ ດຳ ເນີນງານເທິງມັນຕ້ອງເປັນປະລໍາມະນູ.
            ///
            ///
            /// # Examples
            ///
            /// `` `ບໍ່ສົນໃຈ (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // ຄວາມປອດໄພ: ປອດໄພຕາບໃດທີ່ `my_atomic_op` ແມ່ນປະລໍາມະນູ.
            /// ທີ່ບໍ່ປອດໄພ {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ (ເຊັ່ນວ່າ __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ (ເຊັ່ນວ່າ __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// ຜົນໄດ້ຮັບມູນຄ່າສູງສຸດທີ່ເຄຍ (ການປຽບທຽບເຊັນ)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SAFETY: ແປໄດ້ທຸໄດ້ຕ້ອງປະຕິບັດສັນຍາຄວາມປອດໄພສໍາລັບ `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// ສົ່ງມູນຄ່າ min (ການປຽບທຽບທີ່ເຊັນຊື່)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// ສົ່ງຄືນມູນຄ່າສູງສຸດ (ການປຽບທຽບທີ່ບໍ່ໄດ້ເຊັນ)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// ຄືນຄ່າ min (ການປຽບທຽບທີ່ບໍ່ໄດ້ເຊັນ)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// ຮົ້ວປະລໍາມະນູ.
///
/// ອີງຕາມ ຄຳ ສັ່ງທີ່ລະບຸໄວ້, ຮົ້ວຈະປ້ອງກັນບໍ່ໃຫ້ຜູ້ລວບລວມຂໍ້ມູນແລະຊີພີຢູປະຕິບັດການຈັດສັນຄືນບາງປະເພດຂອງການເຮັດວຽກຂອງ ໜ່ວຍ ຄວາມ ຈຳ ຮອບມັນ.
/// ນັ້ນສ້າງການພົວພັນກັນ-ກັບຄວາມ ສຳ ພັນລະຫວ່າງມັນແລະການປະຕິບັດງານປະລໍາມະນູຫຼືຮົ້ວໃນກະທູ້ອື່ນໆ.
///
/// ຮົ້ວ 'A' ເຊິ່ງມີ (ຢ່າງ ໜ້ອຍ) [`Release`] ຈັດລຽງລໍາດັບ semantics, ປະສົມປະສານກັບຮົ້ວ 'B' ກັບ (ຢ່າງ ໜ້ອຍ) [`Acquire`] semantics, ຖ້າແລະເທົ່ານັ້ນຖ້າມີການດໍາເນີນງານ X ແລະ Y, ທັງສອງປະຕິບັດງານຢູ່ບາງວັດຖຸປະລໍາມະນູ 'M' ເຊັ່ນວ່າ A ແມ່ນລໍາດັບກ່ອນ X, Y ແມ່ນການປະສານກັນກ່ອນ B ແລະ Y ສັງເກດການປ່ຽນ M.
/// ນີ້ຈະສະຫນອງທີ່ເກີດຂຶ້ນ, ກ່ອນທີ່ຈະເອື່ອຍອີງໃນລະຫວ່າງ A ແລະ B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// ການປະຕິບັດງານປະລໍາມະນູກັບ [`Release`] ຫຼື [`Acquire`] semantics ຍັງສາມາດປະສານກັບຮົ້ວໄດ້.
///
/// ຮົ້ວທີ່ມີການສັ່ງຊື້ [`SeqCst`], ນອກເຫນືອຈາກມີທັງ [`Acquire`] ແລະ [`Release`] semantics, ເຂົ້າຮ່ວມໃນຄໍາສັ່ງໂຄງການທົ່ວໂລກຂອງການດໍາເນີນງານ [`SeqCst`] ອື່ນໆແລະ/ຫຼືຮົ້ວ.
///
/// ຍອມຮັບ ຄຳ ສັ່ງ [`Acquire`], [`Release`], [`AcqRel`] ແລະ [`SeqCst`].
///
/// # Panics
///
/// Panics ຖ້າ `order` ແມ່ນ [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // ການຍົກເວັ້ນເຊິ່ງກັນແລະກັນໂດຍອີງໃສ່ spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // ລໍຖ້າຈົນກວ່າມູນຄ່າເກົ່າແມ່ນ `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // ຮົ້ວນີ້ປະສານກັບຮ້ານໃນ `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // ຄວາມປອດໄພ: ການໃຊ້ຮົ້ວປະລໍາມະນູແມ່ນປອດໄພ.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// ຮົ້ວຄວາມຊົງ ຈຳ ທີ່ລວບລວມ.
///
/// `compiler_fence` ບໍ່ emit ລະຫັດເຄື່ອງໃດ, ແຕ່ຈໍາກັດປະເພດຂອງຄວາມຊົງຈໍາ Re: ສັ່ງ compiler ໄດ້ຖືກອະນຸຍາດໃຫ້ເຮັດແນວໃດ.ໂດຍສະເພາະ, ຂື້ນກັບການໃຫ້ ຄຳ ແນະ ນຳ [`Ordering`], ຜູ້ຂຽນອາດຈະບໍ່ຖືກຍ້າຍຈາກການຍ້າຍອ່ານຫຼືຂຽນຈາກກ່ອນຫຼືຫຼັງຈາກການໂທຫາອີກດ້ານ ໜຶ່ງ ຂອງການໂທຫາ `compiler_fence`.ໃຫ້ສັງເກດວ່າມັນເຮັດ **ບໍ່** ປ້ອງກັນບໍ່ໃຫ້ *ຮາດແວ* ດຳ ເນີນການສັ່ງຊື້ຄືນ ໃໝ່.
///
/// ນີ້ບໍ່ແມ່ນບັນຫາຢູ່ໃນສະພາບການທີ່ໃຊ້ເປັນເສັ້ນດ່ຽວ, ການປະຕິບັດ, ແຕ່ເມື່ອກະທູ້ອື່ນ ໆ ອາດຈະດັດແປງຄວາມຊົງ ຈຳ ໃນເວລາດຽວກັນ, ພື້ນຖານການປະສົມປະສານທີ່ເຂັ້ມແຂງເຊັ່ນ [`fence`] ແມ່ນມີຄວາມ ຈຳ ເປັນ.
///
/// ການສັ່ງຈອງຄືນ ໃໝ່ ທີ່ຖືກປ້ອງກັນຈາກ ຄຳ ສັ່ງທີ່ແຕກຕ່າງກັນແມ່ນ:
///
///  - ກັບ [`SeqCst`], ບໍ່ມີການສັ່ງການອ່ານຄືນ ໃໝ່ ແລະຂຽນທົ່ວຈຸດນີ້ແມ່ນອະນຸຍາດ.
///  - ກັບ [`Release`], ການອ່ານແລະການຂຽນກ່ອນບໍ່ສາມາດຍ້າຍຜ່ານການຂຽນຕໍ່ໄປ.
///  - ກັບ [`Acquire`], ການອ່ານແລະການຂຽນຕໍ່ໆໄປບໍ່ສາມາດຍ້າຍໄປກ່ອນ ໜ້າ ການອ່ານກ່ອນ.
///  - ກັບ [`AcqRel`], ທັງສອງກົດລະບຽບຂ້າງເທິງນີ້ຖືກບັງຄັບໃຊ້.
///
/// `compiler_fence` ໂດຍທົ່ວໄປແມ່ນມີປະໂຫຍດພຽງແຕ່ ສຳ ລັບການປ້ອງກັນກະທູ້ຈາກການແຂ່ງລົດ *ກັບຕົວມັນເອງ*.ຫມາຍຄວາມວ່າ, ຖ້າຫາກວ່າເປັນກະທູ້ໃຫ້ຖືກປະຕິບັດຫນຶ່ງສິ້ນຂອງລະຫັດ, ແລະໄດ້ຖືກລົບກວນແລ້ວ, ແລະຈະເລີ່ມປະຕິບັດລະຫັດຢູ່ບ່ອນອື່ນ (ໃນຂະນະທີ່ຍັງຢູ່ໃນກະທູ້ດຽວກັນ, ແລະຈືຂໍ້ມູນການຍັງຢູ່ໃນຫຼັກດຽວກັນ).ໃນບັນດາໂປແກຼມປະເພນີ, ສິ່ງນີ້ສາມາດເກີດຂື້ນໄດ້ໃນເວລາທີ່ຜູ້ຮັບສັນຍານໄດ້ລົງທະບຽນ.
/// ໃນລະຫັດທີ່ມີລະດັບຕ່ ຳ ກວ່າ, ສະຖານະການດັ່ງກ່າວຍັງສາມາດເກີດຂື້ນໄດ້ໃນເວລາຈັດການການຂັດຂວາງ, ໃນເວລາທີ່ປະຕິບັດກະທູ້ສີຂຽວດ້ວຍການປ່ອຍຕົວກ່ອນ, ແລະອື່ນໆ.
/// ຜູ້ອ່ານທີ່ຢາກຮູ້ຢາກໄດ້ຮັບການຊຸກຍູ້ໃຫ້ອ່ານການສົນທະນາຂອງ Linux ກ່ຽວກັບ [memory barriers].
///
/// # Panics
///
/// Panics ຖ້າ `order` ແມ່ນ [`Relaxed`].
///
/// # Examples
///
/// ຖ້າບໍ່ມີ `compiler_fence`, `assert_eq!` ໃນລະຫັດດັ່ງຕໍ່ໄປນີ້ແມ່ນ *ບໍ່* ຮັບປະກັນໃຫ້ປະສົບຜົນ ສຳ ເລັດ, ເຖິງແມ່ນວ່າທຸກຢ່າງຈະເກີດຂື້ນໃນກະທູ້ດຽວ.
/// ໄປເບິ່ງວ່າເປັນຫຍັງ, ຈື່ໄດ້ວ່າ compiler ແມ່ນບໍ່ເສຍຄ່າເພື່ອແລກປ່ຽນປະສົບຮ້ານເພື່ອ `IMPORTANT_VARIABLE` ແລະ `IS_READ` ນັບຕັ້ງແຕ່ພວກເຂົາເຈົ້າແມ່ນທັງສອງ `Ordering::Relaxed`.ຖ້າມັນເຮັດໄດ້, ແລະຜູ້ຈັດການສັນຍານຈະຖືກຮຽກຮ້ອງທັນທີຫຼັງຈາກທີ່ `IS_READY` ຖືກປັບປຸງ, ຫຼັງຈາກນັ້ນຜູ້ຈັດການສັນຍານຈະເຫັນ `IS_READY=1`, ແຕ່ `IMPORTANT_VARIABLE=0`.
/// ການໃຊ້ `compiler_fence` ແກ້ໄຂສະຖານະການນີ້.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // ປ້ອງກັນບໍ່ໃຫ້ບົດຂຽນກ່ອນ ໜ້າ ນີ້ຖືກຍ້າຍອອກຈາກຈຸດນີ້
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // ຄວາມປອດໄພ: ການໃຊ້ຮົ້ວປະລໍາມະນູແມ່ນປອດໄພ.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// ລົງສັນຍາກັບໂຮງງານຜະລິດວ່າມັນຢູ່ພາຍໃນວົງແຫວນ ໝູນ ວຽນແບບລໍຖ້າ ("ລັອກ ໝຸນ").
///
/// ຟັງຊັນນີ້ຖືກປະຕິເສດໃນເງື່ອນໄຂ [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}