#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // ຂະຫຍາຍການບໍ່ວ່າຈະ `$crate::panic::panic_2015` ຫຼື `$crate::panic::panic_2021` ໂດຍອີງຕາມສະບັບຂອງແປໄດ້ທຸໄດ້.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// ໄດ້ຢືນຢັນວ່າທັງສອງສະແດງອອກມີຄວາມເທົ່າທຽມກັນກັບແຕ່ລະອື່ນໆ (ການນໍາໃຊ້ [`PartialEq`]).
///
/// On panic, ມະຫາພາກນີ້ຈະພິມຄ່າຂອງການສະແດງອອກທີ່ມີຕົວແທນ debug ຂອງເຂົາເຈົ້າ.
///
///
/// ເຊັ່ນດຽວກັນກັບ [`assert!`], ມະຫາພາກນີ້ມີຮູບແບບທີສອງ, ບ່ອນທີ່ຂໍ້ຄວາມ panic custom ສາມາດໄດ້ຮັບການສະຫນອງໃຫ້.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // reborrows ຂ້າງລຸ່ມນີ້ແມ່ນເຈດຕະນາ.
                    // ໂດຍບໍ່ມີການໃຫ້ເຂົາເຈົ້າ, ສະລັອດຕິງ stack ສໍາລັບການກູ້ຢືມເງິນຈະເລີ່ມຕົ້ນເຖິງແມ່ນວ່າກ່ອນທີ່ຈະຄ່າໄດ້ເມື່ອປຽບທຽບ, ອັນເຮັດໃຫ້ມີລົງຊ້າຫນັງສືແຈ້ງການ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // reborrows ຂ້າງລຸ່ມນີ້ແມ່ນເຈດຕະນາ.
                    // ໂດຍບໍ່ມີການໃຫ້ເຂົາເຈົ້າ, ສະລັອດຕິງ stack ສໍາລັບການກູ້ຢືມເງິນຈະເລີ່ມຕົ້ນເຖິງແມ່ນວ່າກ່ອນທີ່ຈະຄ່າໄດ້ເມື່ອປຽບທຽບ, ອັນເຮັດໃຫ້ມີລົງຊ້າຫນັງສືແຈ້ງການ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ໄດ້ຢືນຢັນວ່າທັງສອງສະແດງອອກບໍ່ແມ່ນເທົ່າທຽມກັນກັບແຕ່ລະອື່ນໆ (ການນໍາໃຊ້ [`PartialEq`]).
///
/// On panic, ມະຫາພາກນີ້ຈະພິມຄ່າຂອງການສະແດງອອກທີ່ມີຕົວແທນ debug ຂອງເຂົາເຈົ້າ.
///
///
/// ເຊັ່ນດຽວກັນກັບ [`assert!`], ມະຫາພາກນີ້ມີຮູບແບບທີສອງ, ບ່ອນທີ່ຂໍ້ຄວາມ panic custom ສາມາດໄດ້ຮັບການສະຫນອງໃຫ້.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // reborrows ຂ້າງລຸ່ມນີ້ແມ່ນເຈດຕະນາ.
                    // ໂດຍບໍ່ມີການໃຫ້ເຂົາເຈົ້າ, ສະລັອດຕິງ stack ສໍາລັບການກູ້ຢືມເງິນຈະເລີ່ມຕົ້ນເຖິງແມ່ນວ່າກ່ອນທີ່ຈະຄ່າໄດ້ເມື່ອປຽບທຽບ, ອັນເຮັດໃຫ້ມີລົງຊ້າຫນັງສືແຈ້ງການ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // reborrows ຂ້າງລຸ່ມນີ້ແມ່ນເຈດຕະນາ.
                    // ໂດຍບໍ່ມີການໃຫ້ເຂົາເຈົ້າ, ສະລັອດຕິງ stack ສໍາລັບການກູ້ຢືມເງິນຈະເລີ່ມຕົ້ນເຖິງແມ່ນວ່າກ່ອນທີ່ຈະຄ່າໄດ້ເມື່ອປຽບທຽບ, ອັນເຮັດໃຫ້ມີລົງຊ້າຫນັງສືແຈ້ງການ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ໄດ້ຢືນຢັນວ່າການສະແດງອອກ boolean ເປັນ `true` ຢູ່ runtime.
///
/// ນີ້ຈະຮ້ອງຂໍມະຫາພາກ [`panic!`] ຖ້າການສະແດງອອກໃຫ້ບໍ່ສາມາດໄດ້ຮັບການປະເມີນຜົນເພື່ອ `true` ຢູ່ runtime.
///
/// ເຊັ່ນດຽວກັນກັບ [`assert!`], ມະຫາພາກນີ້ຍັງມີສະບັບພາສາທີສອງ, ບ່ອນທີ່ຂໍ້ຄວາມ panic custom ສາມາດໄດ້ຮັບການສະຫນອງໃຫ້.
///
/// # Uses
///
/// ບໍ່ເຫມືອນກັບ [`assert!`], ຂໍ້ກໍານົດ `debug_assert!` ຖືກເປີດໃຫ້ໃຊ້ງານພຽງແຕ່ໃນບໍ່ເຫມາະສ້າງຕັ້ງແຕ່ຕອນຕົ້ນ.
/// ເປັນເຫມາະສ້າງຈະບໍ່ເຮັດຕາມຂໍ້ກໍານົດ `debug_assert!` ເວັ້ນເສຍແຕ່ວ່າ `-C debug-assertions` ແມ່ນຜ່ານການລວບລວມ.
/// ນີ້ເຮັດໃຫ້ `debug_assert!` ທີ່ເປັນປະໂຫຍດສໍາລັບການກວດສອບວ່າມີລາຄາແພງເກີນໄປທີ່ຈະເປັນປະຈຸບັນໃນການປ່ອຍສ້າງແຕ່ອາດຈະເປັນປະໂຫຍດໃນໄລຍະການພັດທະນາ.
/// ຜົນມາຈາກການຂະຫຍາຍ `debug_assert!` ແມ່ນສະເຫມີໄປປະເພດການກວດກາ.
///
/// ຍື່ນຍັນກວດກາອະນຸຍາດໃຫ້ໂຄງການໃນສະຖານະບໍ່ສອດຄ່ອງກັບຍັງຄົງເຮັດວຽກ, ຊຶ່ງອາດຈະມີຜົນກະທົບທີ່ບໍ່ຄາດຄິດແຕ່ບໍ່ແນະນໍາ unsafety ຕາບໃດທີ່ນີ້ພຽງແຕ່ຈະເກີດຂຶ້ນໃນລະຫັດຄວາມປອດໄພ.
///
/// ເຖິງຢ່າງໃດກໍ່ຕາມ, ຄ່າໃຊ້ຈ່າຍໃນການປະຕິບັດຂອງການຢືນຢັນແມ່ນບໍ່ສາມາດວັດແທກໄດ້ໂດຍທົ່ວໄປ.
/// ປ່ຽນ [`assert!`] ກັບ `debug_assert!` ແມ່ນດັ່ງນັ້ນຈຶ່ງສະຫນັບສະຫນູນພຽງແຕ່ຫຼັງຈາກ profiling thorough, ແລະທີ່ສໍາຄັນຫຼາຍ, ພຽງແຕ່ໃນລະຫັດຄວາມປອດໄພ!
///
/// # Examples
///
/// ```
/// // ຂໍ້ຄວາມ panic ສຳ ລັບ ຄຳ ຢືນຢັນເຫລົ່ານີ້ແມ່ນມູນຄ່າທີ່ຖືກຕ້ອງຂອງການສະແດງອອກ.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // ການທໍາງານຂອງງ່າຍດາຍທີ່ສຸດ
/// debug_assert!(some_expensive_computation());
///
/// // ຫມັ້ນໃຈກັບຂໍ້ຄວາມທີ່ກໍາຫນົດເອງ
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// ໄດ້ຢືນຢັນວ່າທັງສອງສະແດງອອກມີຄວາມເທົ່າທຽມກັນກັບກັນແລະກັນ.
///
/// On panic, ມະຫາພາກນີ້ຈະພິມຄ່າຂອງການສະແດງອອກທີ່ມີຕົວແທນ debug ຂອງເຂົາເຈົ້າ.
///
/// ບໍ່ເຫມືອນກັບ [`assert_eq!`], ຂໍ້ກໍານົດ `debug_assert_eq!` ຖືກເປີດໃຫ້ໃຊ້ງານພຽງແຕ່ໃນບໍ່ເຫມາະສ້າງຕັ້ງແຕ່ຕອນຕົ້ນ.
/// ເປັນເຫມາະສ້າງຈະບໍ່ເຮັດຕາມຂໍ້ກໍານົດ `debug_assert_eq!` ເວັ້ນເສຍແຕ່ວ່າ `-C debug-assertions` ແມ່ນຜ່ານການລວບລວມ.
/// ນີ້ເຮັດໃຫ້ `debug_assert_eq!` ທີ່ເປັນປະໂຫຍດສໍາລັບການກວດສອບວ່າມີລາຄາແພງເກີນໄປທີ່ຈະເປັນປະຈຸບັນໃນການປ່ອຍສ້າງແຕ່ອາດຈະເປັນປະໂຫຍດໃນໄລຍະການພັດທະນາ.
///
/// ຜົນມາຈາກການຂະຫຍາຍ `debug_assert_eq!` ແມ່ນສະເຫມີໄປປະເພດການກວດກາ.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// ໄດ້ຢືນຢັນວ່າທັງສອງສະແດງອອກບໍ່ແມ່ນເທົ່າທຽມກັນກັບກັນແລະກັນ.
///
/// On panic, ມະຫາພາກນີ້ຈະພິມຄ່າຂອງການສະແດງອອກທີ່ມີຕົວແທນ debug ຂອງເຂົາເຈົ້າ.
///
/// ບໍ່ເຫມືອນກັບ [`assert_ne!`], ຂໍ້ກໍານົດ `debug_assert_ne!` ຖືກເປີດໃຫ້ໃຊ້ງານພຽງແຕ່ໃນບໍ່ເຫມາະສ້າງຕັ້ງແຕ່ຕອນຕົ້ນ.
/// ເປັນເຫມາະສ້າງຈະບໍ່ເຮັດຕາມຂໍ້ກໍານົດ `debug_assert_ne!` ເວັ້ນເສຍແຕ່ວ່າ `-C debug-assertions` ແມ່ນຜ່ານການລວບລວມ.
/// ນີ້ເຮັດໃຫ້ `debug_assert_ne!` ທີ່ເປັນປະໂຫຍດສໍາລັບການກວດສອບວ່າມີລາຄາແພງເກີນໄປທີ່ຈະເປັນປະຈຸບັນໃນການປ່ອຍສ້າງແຕ່ອາດຈະເປັນປະໂຫຍດໃນໄລຍະການພັດທະນາ.
///
/// ຜົນມາຈາກການຂະຫຍາຍ `debug_assert_ne!` ແມ່ນສະເຫມີໄປປະເພດການກວດກາ.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// ຜົນຕອບແທນບໍ່ວ່າຈະເປັນການສະແດງອອກໃຫ້ກົງກັບຮູບແບບດັ່ງກ່າວ.
///
/// ເຊັ່ນດຽວກັນກັບໃນການສະແດງອອກ `match`, ຮູບແບບທີ່ສາມາດໄດ້ຮັບການປະຕິບັດຕາມທາງເລືອກໂດຍ `if` ແລະການສະແດງກອງທີ່ສາມາດເຂົ້າເຖິງຊື່ຜູກພັນໂດຍຮູບແບບການ.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Unwraps ຜົນຫຼືຂະຫຍາຍພັນຄວາມຜິດພາດຂອງຕົນ.
///
/// ການປະຕິບັດການ `?` ຖືກບັນທຶກທົດແທນ `try!` ແລະຄວນໄດ້ຮັບການນໍາມາໃຊ້ແທນ.
/// ຍິ່ງໄປກວ່ານັ້ນ, `try` ເປັນຄໍາສະຫງວນໃນ Rust ປີ 2018, ສະນັ້ນຖ້າຫາກວ່າທ່ານຕ້ອງການນໍາໃຊ້ມັນ, ທ່ານຈະຕ້ອງໄດ້ນໍາໃຊ້ [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ກົງກັບທີ່ກໍາຫນົດ [`Result`].ໃນກໍລະນີຂອງຕົວແປ `Ok`, ການສະແດງອອກມີມູນຄ່າຂອງຄ່າຫໍ່ໄດ້.
///
/// ໃນກໍລະນີຂອງຕົວແປ `Err`, ມັນດຶງຄວາມຜິດພາດໃນການ.`try!` ຫຼັງຈາກນັ້ນດໍາເນີນການປ່ຽນແປງການນໍາໃຊ້ `From`.
/// ນີ້ຈະສະຫນອງການປ່ຽນແປງອັດຕະໂນມັດລະຫວ່າງຄວາມຜິດພາດຜູ້ຊ່ຽວຊານແລະບໍ່ວ້າງຂຶ້ນ.
/// ຄວາມຜິດພາດທີ່ໄດ້ຮັບແມ່ນຫຼັງຈາກນັ້ນໄດ້ກັບຄືນທັນທີ.
///
/// ເນື່ອງຈາກວ່າຜົນຕອບແທນຕົ້ນ, `try!` ສາມາດໄດ້ຮັບການນໍາໃຊ້ພຽງແຕ່ຢູ່ໃນປະຕິບັດຫນ້າທີ່ກັບຄືນ [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // ວິທີທີ່ແນະນໍາຂອງຄວາມຜິດພາດທີ່ກັບຄືນໄວ
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // ວິທີການທີ່ຜ່ານມາຂອງຄວາມຜິດພາດທີ່ກັບຄືນໄວ
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // ນີ້ເທົ່າກັບ:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// ຂຽນຂໍ້ມູນໃນຮູບແບບເປັນກັນຊົນ.
///
/// ມະຫາພາກນີ້ສະຫນູນ 'writer', string ຮູບແບບ, ແລະບັນຊີລາຍຊື່ຂອງການໂຕ້ຖຽງໄດ້.
/// ກະທູ້ທີ່ຈະໄດ້ຮັບການຈັດຮູບແບບຕາມຮູບແບບຂອງ string ທີ່ກໍານົດໄວ້ແລະຜົນໄດ້ຮັບຈະໄດ້ຮັບການຜ່ານກັບ writer ໄດ້.
/// ນັກຂຽນອາດຈະມີຄຸນຄ່າໃດໆກັບວິທີ `write_fmt`;ໂດຍທົ່ວໄປນີ້ມາຈາກການປະຕິບັດຂອງທັງ [`fmt::Write`] ຫຼື [`io::Write`] trait.
/// ການຕອບແທນມະຫາພາກໃດກໍ່ຕາມ `write_fmt` ວິທີການຜົນຕອບແທນ;ທົ່ວໄປເປັນ [`fmt::Result`], ຫຼື [`io::Result`].
///
/// ເບິ່ງ [`std::fmt`] ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບ syntax string format.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// ໂມດູນສາມາດນໍາເຂົ້າທັງ `std::fmt::Write` ແລະ `std::io::Write` ແລະໂທ `write!` ກ່ຽວກັບວັດຖຸປະຕິບັດບໍ່ວ່າຈະເປັນວັດຖຸທີ່ບໍ່ປົກກະຕິປະຕິບັດທັງສອງ.
///
/// ຢ່າງໃດກໍຕາມ, ອຸປະກອນນະຕ້ອງນໍາເຂົ້າທີ່ມີຄຸນສົມບັດ traits ນັ້ນຊື່ຂອງເຂົາເຈົ້າບໍ່ຂັດ:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // ໃຊ້ fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // ໃຊ້ io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: ມະຫາພາກສາມາດຖືກນໍາໃຊ້ໃນການຕັ້ງຄ່າ `no_std` ເຊັ່ນດຽວກັນ.
/// ໃນການຕັ້ງຄ່າ `no_std` ທ່ານມີຄວາມຮັບຜິດຊອບຕໍ່ລາຍລະອຽດການຈັດຕັ້ງປະຕິບັດຂອງສ່ວນປະກອບ.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// ຂຽນຂໍ້ມູນໃນຮູບແບບເປັນກັນຊົນ, ມີທັດໃຫມ່ທ້າຍ.
///
/// ໃນເວທີທີ່ທັງຫມົດ, ບັນທັດໃຫມ່ທີ່ເປັນ LINE FEED ລັກສະນະ (`\n`/`U+000A`) ດຽວ (ບໍ່ມີເພີ່ມເຕີມ CARRIAGE ຄືນ (`\r`/`U+000D`).
///
/// ສໍາລັບຂໍ້ມູນເພີ່ມເຕີມ, ເບິ່ງ [`write!`].ສໍາລັບຂໍ້ມູນກ່ຽວກັບໄວຍາກອນສະຕິງຮູບແບບ, ເບິ່ງ [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// ໂມດູນສາມາດນໍາເຂົ້າທັງ `std::fmt::Write` ແລະ `std::io::Write` ແລະໂທ `write!` ກ່ຽວກັບວັດຖຸປະຕິບັດບໍ່ວ່າຈະເປັນວັດຖຸທີ່ບໍ່ປົກກະຕິປະຕິບັດທັງສອງ.
/// ຢ່າງໃດກໍຕາມ, ອຸປະກອນນະຕ້ອງນໍາເຂົ້າທີ່ມີຄຸນສົມບັດ traits ນັ້ນຊື່ຂອງເຂົາເຈົ້າບໍ່ຂັດ:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // ໃຊ້ fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // ໃຊ້ io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// ສະແດງລະຫັດ unreachable.
///
/// ນີ້ແມ່ນເປັນປະໂຫຍດທີ່ໃຊ້ເວລາທີ່ຄອມໄພເລີບໍ່ສາມາດກໍານົດທີ່ລະຫັດບາງເປັນ unreachable.ຍົກຕົວຢ່າງ:
///
/// * ກົງແຂນກັບສະພາບກອງ.
/// * Loops ວ່ານະໂຍບາຍດ້ານຢຸດ.
/// * iterators ວ່ານະໂຍບາຍດ້ານຢຸດ.
///
/// ຖ້າຫາກວ່າການຕັດສິນໃຈທີ່ລະຫັດແມ່ນ unreachable ພິສູດບໍ່ຖືກຕ້ອງ, ໂຄງການໃນທັນທີສິ້ນສຸດລົງດ້ວຍ [`panic!`].
///
/// ຄູ່ຮ່ວມງານທີ່ບໍ່ປອດໄພຂອງມະຫາພາກນີ້ແມ່ນການທໍາງານຂອງ [`unreachable_unchecked`], ເຊິ່ງຈະເຮັດໃຫ້ພຶດຕິກໍາ undefined ຖ້າລະຫັດບັນລຸ.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// ນີ້ຈະສະເຫມີ [`panic!`].
///
/// # Examples
///
/// ແຂນຈັບຄູ່:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // ລວບລວມຂໍ້ຜິດພາດຖ້າມີ ຄຳ ເຫັນອອກມາ
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // ຫນຶ່ງໃນການປະຕິບັດທຸກຍາກທີ່ສຸດຂອງ x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// ສະແດງລະຫັດ unimplemented ໂດຍ panicking ມີຂໍ້ຄວາມຂອງ "not implemented" ໄດ້.
///
/// ນີ້ອະນຸຍາດໃຫ້ລະຫັດຂອງທ່ານຈະປະເພດການກວດກາ, ຊຶ່ງເປັນປະໂຫຍດຖ້າຫາກວ່າທ່ານກໍາລັງ prototyping ຫຼືປະຕິບັດ trait ທີ່ຮຽກຮ້ອງໃຫ້ມີວິທີການທີ່ຫຼາກຫຼາຍທີ່ທ່ານເຮັດບໍ່ໄດ້ວາງແຜນຂອງການນໍາໃຊ້ທັງຫມົດຂອງ.
///
/// ຄວາມແຕກຕ່າງລະຫວ່າງ `unimplemented!` ແລະ [`todo!`] ແມ່ນວ່າໃນຂະນະທີ່ `todo!` ສະແດງຄວາມຕັ້ງໃຈໃນການຈັດຕັ້ງປະຕິບັດ ໜ້າ ທີ່ໃນພາຍຫລັງແລະຂໍ້ຄວາມແມ່ນ "not yet implemented", `unimplemented!` ກໍ່ບໍ່ມີຂໍ້ຮຽກຮ້ອງດັ່ງກ່າວ.
/// ຂໍ້ຄວາມຂອງຕົນເປັນ "not implemented".
/// ນອກຈາກນີ້ IDEs ບາງຈະຫມາຍ `ຢ່າງໃດກໍຕາມ!` s.
///
/// # Panics
///
/// ນີ້ຈະ [`panic!`] ສະເຫມີເນື່ອງຈາກວ່າ `unimplemented!` ແມ່ນພຽງແຕ່ສໍາລັບການຈົດຊະວະເລກ `panic!` ມີການສ້ອມແຊມ, ຂໍ້ສະເພາະໃດຫນຶ່ງ.
///
/// ເຊັ່ນດຽວກັນກັບ `panic!`, ມະຫາພາກນີ້ມີຮູບແບບທີ່ສອງສໍາລັບການສະແດງລາຍຄ່າ custom.
///
/// # Examples
///
/// ເວົ້າວ່າພວກເຮົາມີ trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// ພວກເຮົາຕ້ອງການທີ່ຈະປະຕິບັດ `Foo` ສໍາລັບ 'MyStruct', ແຕ່ສໍາລັບເຫດຜົນບາງຢ່າງມັນພຽງແຕ່ເຮັດໃຫ້ຄວາມຮູ້ສຶກທີ່ໃຊ້ການທໍາງານຂອງ `bar()`.
/// `baz()` ແລະ `qux()` ຈະຍັງຕ້ອງການທີ່ຈະໄດ້ຮັບການກໍານົດໃນການປະຕິບັດຂອງ `Foo` ຂອງພວກເຮົາ, ແຕ່ພວກເຮົາສາມາດນໍາໃຊ້ `unimplemented!` ໃນຄໍານິຍາມຂອງເຂົາເຈົ້າທີ່ຈະອະນຸຍາດໃຫ້ລະຫັດຂອງພວກເຮົາທີ່ຈະສັງລວມ.
///
/// ພວກເຮົາຍັງຕ້ອງການທີ່ຈະມີໂຄງການຢຸດຂອງພວກເຮົາແລ່ນຖ້າຫາກວ່າວິທີການ unimplemented ຖືກບັນລຸໄດ້.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // ມັນເຮັດໃຫ້ຄວາມຮູ້ສຶກທີ່ `baz` ເປັນ `MyStruct` ບໍ່ມີ, ດັ່ງນັ້ນພວກເຮົາບໍ່ມີເຫດຜົນທີ່ນີ້ເລີຍ.
/////
///         // ນີ້ຈະສະແດງ "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // ພວກເຮົາມີເຫດຜົນບາງຢ່າງທີ່ນີ້, ພວກເຮົາສາມາດເພີ່ມຂໍ້ຄວາມກັບ unimplemented!ເພື່ອສະແດງການລົບລ້າງຂອງພວກເຮົາ.
///         // ນີ້ຈະສະແດງ: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// ສະແດງລະຫັດ unfinished.
///
/// ນີ້ສາມາດເປັນປະໂຫຍດຖ້າທ່ານ ກຳ ລັງທົດລອງໃຊ້ແລະ ກຳ ລັງຊອກຫາເຄື່ອງຈັກລະຫັດຂອງທ່ານ.
///
/// ຄວາມແຕກຕ່າງລະຫວ່າງ [`unimplemented!`] ແລະ `todo!` ແມ່ນວ່າໃນຂະນະທີ່ `todo!` ຖ່າຍທອດຄວາມຕັ້ງໃຈຂອງການດໍາເນີນການເຮັດວຽກໃນພາຍຫລັງແລະຂໍ້ຄວາມທີ່ "not yet implemented", `unimplemented!` ເຮັດໃຫ້ບໍ່ມີການຮຽກຮ້ອງດັ່ງກ່າວ.
/// ຂໍ້ຄວາມຂອງຕົນເປັນ "not implemented".
/// ນອກຈາກນີ້ IDEs ບາງຈະຫມາຍ `ຢ່າງໃດກໍຕາມ!` s.
///
/// # Panics
///
/// ນີ້ຈະສະເຫມີ [`panic!`].
///
/// # Examples
///
/// ຕໍ່ໄປນີ້ແມ່ນຕົວຢ່າງຂອງຂໍ້ກໍານົດໃນຄວາມຄືບຫນ້າຈໍານວນຫນຶ່ງໄດ້.ພວກເຮົາມີ trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// ພວກເຮົາຕ້ອງການທີ່ຈະປະຕິບັດ `Foo` ກ່ຽວກັບຫນຶ່ງໃນປະເພດຂອງພວກເຮົາ, ແຕ່ພວກເຮົາຍັງຕ້ອງການທີ່ຈະເຮັດວຽກກ່ຽວກັບການພຽງແຕ່ `bar()` ຄັ້ງທໍາອິດ.ເພື່ອໃຫ້ລະຫັດຂອງພວກເຮົາລວບລວມ, ພວກເຮົາຕ້ອງການຈັດຕັ້ງປະຕິບັດ `baz()`, ດັ່ງນັ້ນພວກເຮົາສາມາດໃຊ້ `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // ການຈັດຕັ້ງປະຕິບັດຢູ່ທີ່ນີ້
///     }
///
///     fn baz(&self) {
///         // ໃຫ້ຂອງບໍ່ຕ້ອງກັງວົນກ່ຽວກັບການປະຕິບັດ baz() ສໍາລັບໃນປັດຈຸບັນ
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ພວກເຮົາຍັງບໍ່ໄດ້ໃຊ້ baz(), ສະນັ້ນສິ່ງນີ້ດີ.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// ນິຍາມຂອງການກໍ່ສ້າງໃນພາກ.
///
/// ສ່ວນໃຫຍ່ຂອງຄຸນສົມບັດມະຫາພາກ (ສະຖຽນລະພາບ, ການເບິ່ງເຫັນ, ແລະອື່ນໆ) ແມ່ນໄດ້ມາຈາກລະຫັດແຫຼ່ງທີ່ນີ້, ມີຂໍ້ຍົກເວັ້ນຂອງການເຄື່ອນໄຫວຂະຫຍາຍຕົວປ່ຽນປັດໄຈນໍາເຂົ້າມະຫາພາກເປັນຜົນໄດ້ຮັບ, ປະຕິບັດຫນ້າທີ່ສະຫນອງໃຫ້ໂດຍ compiler ໄດ້.
///
///
pub(crate) mod builtin {

    /// ເຮັດໃຫ້ການລວບລວມຂໍ້ມູນລົ້ມເຫລວດ້ວຍຂໍ້ຄວາມຜິດພາດທີ່ຖືກປະຕິບັດເມື່ອພົບ.
    ///
    /// ມະຫາພາກນີ້ຄວນໄດ້ຮັບການນໍາໃຊ້ໃນເວລາທີ່ crate ໃຊ້ຍຸດທະສາດການລວບລວມເງື່ອນໄຂເພື່ອສະຫນອງຂໍ້ຄວາມຜິດພາດດີກວ່າສໍາລັບສະພາບການ erroneous.
    ///
    /// ມັນເປັນຮູບແບບ compiler ໃນລະດັບຂອງ [`panic!`], ແຕ່ emits ຄວາມຜິດພາດໃນໄລຍະການລວບລວມ * * ແທນທີ່ຈະກ່ວາໃນ runtime * *.
    ///
    /// # Examples
    ///
    /// ສອງຕົວຢ່າງດັ່ງກ່າວແມ່ນສະພາບແວດລ້ອມມະຫາພາກແລະ `#[cfg]`.
    ///
    /// ປ່ອຍຂໍ້ຜິດພາດຂອງຜູ້ຂຽນທີ່ດີກວ່າຖ້າວ່າມະຫາພາກຖືກຜ່ານຄ່າທີ່ບໍ່ຖືກຕ້ອງ.
    /// ໂດຍບໍ່ມີການສຸດທ້າຍໄດ້ branch, compiler ຈະຍັງຄົງເປ່ງຄວາມຜິດພາດ, ແຕ່ວ່າຂໍ້ຄວາມຄວາມຜິດພາດຂອງຈະບໍ່ເວົ້າເຖິງສອງຄ່າທີ່ຖືກຕ້ອງ.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// ຄວາມຜິດພາດການລວບລວມປ່ອຍຖ້າຫາກວ່າຫນຶ່ງຂອງຈໍານວນຂອງຄຸນສົມບັດບໍ່ສາມາດໃຊ້.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ໂຄງສ້າງພາລາມິເຕີສໍາລັບມະຫາພາກ string, ຮູບແບບອື່ນໆ.
    ///
    /// ນີ້ປະຕິບັດຫນ້າມະຫາພາກໂດຍການສະຕິງຮູບແບບທີ່ຮູ້ຫນັງສືທີ່ມີ `{}` ສໍາລັບແຕ່ລະການໂຕ້ຖຽງເພີ່ມເຕີມຜ່ານ.
    /// `format_args!` ກຽມຕົວກໍານົດເພີ່ມເຕີມເພື່ອຮັບປະກັນຜົນຜະລິດໄດ້ສາມາດໄດ້ຮັບການຕີລາຄາເປັນ string ແລະ canonicalizes ກະທູ້ທີ່ໄດ້ເຂົ້າໄປໃນປະເພດດຽວ.
    /// ມູນຄ່າທີ່ປະຕິບັດໄດ້ [`Display`] trait ສາມາດຜ່ານໄປ `format_args!`, ເປັນສາມາດປະຕິບັດໃດໆ [`Debug`] ຖືກສົ່ງຜ່ານໄປເປັນ `{:?}` ພາຍໃນ string ຮູບແບບ.
    ///
    ///
    /// ມະຫາພາກນີ້ຜະລິດຄ່າຂອງ [`fmt::Arguments`] ປະເພດ.ມູນຄ່ານີ້ສາມາດໄດ້ຮັບການສົ່ງຜ່ານໄປຍັງມະຫາພາກພາຍໃນ [`std::fmt`] ສໍາລັບການປະຕິບັດຕົວຊີ້ທິດທາງທີ່ເປັນປະໂຫຍດ.
    /// ທັງຫມົດ macros ຮູບແບບອື່ນໆ ([`ຮູບແບບ!`], [`write!`], [`println!`], ແລະອື່ນໆ) ໄດ້ຖືກ proxied ຜ່ານນີ້.
    /// `format_args!`, ບໍ່ເຫມືອນກັບມະຫາພາກມາຂອງຕົນ, ຫຼີກເວັ້ນການ heap ຈັດສັນ.
    ///
    /// ທ່ານສາມາດນໍາໃຊ້ມູນຄ່າ [`fmt::Arguments`] ທີ່ `format_args!` ໃຫ້ຜົນໄດ້ຮັບໃນ `Debug` ແລະ `Display` ພາບທີ່ເຫັນຂ້າງລຸ່ມນີ້.
    /// ຕົວຢ່າງຍັງສະແດງໃຫ້ເຫັນວ່າຮູບແບບ `Debug` ແລະ `Display` ກັບສິ່ງດຽວກັນ: ສາຍຮູບແບບທີ່ແປໃນ `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// ສໍາລັບຂໍ້ມູນເພີ່ມເຕີມ, ເບິ່ງເອກະສານໃນ [`std::fmt`] ໄດ້.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// ເຊັ່ນດຽວກັນກັບ `format_args` ແຕ່ເພີ່ມບັນທັດໃຫມ່ໃນຕອນທ້າຍໄດ້.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// ລົງກວດກາເພື່ອເປັນຕົວປ່ຽນແປງສະພາບແວດລ້ອມໃນຂະນະລວບລວມ.
    ///
    /// ມະຫາພາກນີ້ຈະຂະຫຍາຍໄປສູ່ມູນຄ່າຂອງຕົວປ່ຽນສະພາບແວດລ້ອມທີ່ມີຊື່ໃນເວລາທີ່ລວບລວມ, ໃຫ້ຜົນຕອບແທນຂອງປະເພດ `&'static str`.
    ///
    ///
    /// ຖ້າຫາກວ່າຕົວແປສະພາບແວດລ້ອມບໍ່ໄດ້ກໍານົດ, ຫຼັງຈາກນັ້ນເປັນຄວາມຜິດພາດການລວບລວມຈະໄດ້ຮັບການປ່ອຍອອກມາ.
    /// ບໍ່ emit ຄວາມຜິດພາດການລວບລວມ, ການນໍາໃຊ້ມະຫາພາກ [`option_env!`] ແທນທີ່ຈະ.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// ທ່ານສາມາດປັບຂໍ້ຄວາມຄວາມຜິດພາດໂດຍຜ່ານສະຕິງທີ່ເປັນຕົວກໍານົດການທີສອງ:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// ຖ້າຫາກວ່າການປ່ຽນແປງສະພາບແວດລ້ອມ `documentation` ບໍ່ໄດ້ກໍານົດ, ທ່ານຈະໄດ້ຮັບຄວາມຜິດພາດດັ່ງຕໍ່ໄປນີ້:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ທາງເລືອກລົງກວດກາເພື່ອເປັນຕົວປ່ຽນແປງສະພາບແວດລ້ອມໃນຂະນະລວບລວມ.
    ///
    /// ຖ້າຫາກວ່າການປ່ຽນແປງສະພາບແວດລ້ອມທີ່ມີຊື່ໃນປະຈຸບັນທີ່ໃຊ້ເວລາລວບລວມ, ນີ້ຈະຂະຫຍາຍເຂົ້າໄປໃນການສະແດງອອກຂອງປະເພດ `Option<&'static str>` ທີ່ຄ່າ `Some` ຂອງມູນຄ່າຂອງຕົວປ່ຽນແປງສະພາບແວດລ້ອມໄດ້.
    /// ຖ້າຕົວແປສະພາບແວດລ້ອມບໍ່ມີຢູ່, ແລ້ວສິ່ງນີ້ຈະຂະຫຍາຍໄປສູ່ `None`.
    /// ເບິ່ງ [`Option<T>`][Option] ສໍາລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບປະເພດນີ້.
    ///
    /// ຂໍ້ຜິດພາດຂອງການລວບລວມເວລາແມ່ນບໍ່ເຄີຍປ່ອຍອອກມາເມື່ອໃຊ້ມະຫາພາກນີ້ບໍ່ວ່າຕົວແປສິ່ງແວດລ້ອມຈະມີຢູ່ຫລືບໍ່.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Concatenates ຕົວລະບຸຕົວຕົນໃຫ້ເປັນ ໜຶ່ງ ຕົວລະບຸຕົວຕົນ.
    ///
    /// ມະຫາພາກນີ້ໃຊ້ເວລາຈໍານວນໃດຂອງບຸຈຸດ, ແຍກອອກ, ແລະຕັດແບ່ງໃຫ້ເຂົາເຈົ້າທັງຫມົດເປັນຫນຶ່ງ, ຜົນຜະລິດການສະແດງອອກຊຶ່ງເປັນຕົວລະບຸໃຫມ່.
    /// ຫມາຍເຫດ: ອະນາໄມທີ່ເຮັດໃຫ້ມັນດັ່ງກ່າວທີ່ມະຫາພາກນີ້ບໍ່ສາມາດເກັບກໍາຕົວແປໃນທ້ອງຖິ່ນ.
    /// ນອກຈາກນີ້, ເປັນຫຼັກການທົ່ວໄປ, ມະຫາພາກໄດ້ຖືກອະນຸຍາດໃຫ້ພຽງແຕ່ໃນລາຍການ, ຄໍາສັ່ງຫລືຕໍາແຫນ່ງການສະແດງອອກ.
    /// ນັ້ນຫມາຍຄວາມວ່າໃນຂະນະທີ່ທ່ານອາດຈະໃຊ້ມະຫາພາກນີ້ໂດຍອ້າງອີງໃສ່ການປ່ຽນແປງທີ່ມີຢູ່ແລ້ວ, ປະຕິບັດຫນ້າຫຼືໂມດູນແລະອື່ນໆ, ທ່ານບໍ່ສາມາດກໍານົດໃຫມ່ທີ່ມີມັນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // concat_idents fn! (ໃຫມ່, ມ່ວນ, ຊື່) { }//ບໍ່ງາມໃນວິທີການນີ້!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ເຊື່ອມຕົວອັກສອນເຂົ້າໄປໃນຫຼັງຈາກນັ້ນນໍາ string static.
    ///
    /// ມະຫາພາກນີ້ໃຊ້ເວລາຈໍານວນຂອງຕົວອັກສອນຈຸດ, ແຍກໃດໆ, ຜົນຜະລິດການສະແດງອອກຂອງປະເພດ `&'static str` ທີ່ເປັນຕົວແທນທັງຫມົດຂອງຕົວອັກສອນທີ່ concatenated ຊ້າຍໄປຫາຂວາ.
    ///
    ///
    /// Integer ແລະຈຸດທີ່ເລື່ອນໄດ້ຕົວອັກສອນແມ່ນ stringified ໃນຄໍາສັ່ງທີ່ຈະ concatenated.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ຂະຫຍາຍຈໍານວນເສັ້ນທີ່ມັນໄດ້ຍົກຂຶ້ນມາອ້າງ.
    ///
    /// ມີ [`column!`] ແລະ [`file!`] ແມໂຄເຫລົ່ານີ້ສະຫນອງຂໍ້ມູນ debugging ສໍາລັບພັດທະນາປະມານສະຖານທີ່ພາຍໃນຂໍ້ມູນໄດ້.
    ///
    /// ການສະແດງອອກຂະຫຍາຍມີປະເພດ `u32` ແລະ 1 ທີ່, ດັ່ງນັ້ນບັນທັດທໍາອິດໃນແຕ່ລະປະເມີນຜົນເອກະສານ 1, ທີສອງກັບ 2, ແລະອື່ນໆ
    /// ນີ້ແມ່ນສອດຄ່ອງກັບຂໍ້ຄວາມຜິດພາດໂດຍນັກຂຽນທົ່ວໄປຫລືບັນນາທິການທີ່ໄດ້ຮັບຄວາມນິຍົມ.
    /// ເສັ້ນກັບຄືນແມ່ນ *ບໍ່ຈໍາເປັນ* ພາຍໃນ invocation `line!` ຕົວຂອງມັນເອງ, ແຕ່ແທນທີ່ຈະໄດ້ invocation ມະຫາພາກທໍາອິດນໍາໄປສູ່ພາວະນາຂອງມະຫາພາກ `line!` ໄດ້.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// ຂະຫຍາຍຈໍານວນຄໍລໍາທີ່ມັນໄດ້ຍົກຂຶ້ນມາອ້າງ.
    ///
    /// ມີ [`line!`] ແລະ [`file!`] ແມໂຄເຫລົ່ານີ້ສະຫນອງຂໍ້ມູນ debugging ສໍາລັບພັດທະນາປະມານສະຖານທີ່ພາຍໃນຂໍ້ມູນໄດ້.
    ///
    /// ການສະແດງອອກຂະຫຍາຍມີປະເພດ `u32` ແລະ 1 ທີ່, ດັ່ງນັ້ນຄໍລໍາທໍາອິດໃນແຕ່ລະປະເມີນຜົນເສັ້ນ 1, ທີສອງກັບ 2, ແລະອື່ນໆ
    /// ນີ້ແມ່ນສອດຄ່ອງກັບຂໍ້ຄວາມຜິດພາດໂດຍນັກຂຽນທົ່ວໄປຫລືບັນນາທິການທີ່ໄດ້ຮັບຄວາມນິຍົມ.
    /// ຖັນຄືນແມ່ນ *ບໍ່ຈໍາເປັນ* ພາຍໃນ invocation `column!` ຕົວຂອງມັນເອງ, ແຕ່ແທນທີ່ຈະໄດ້ invocation ມະຫາພາກທໍາອິດນໍາໄປສູ່ພາວະນາຂອງມະຫາພາກ `column!` ໄດ້.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// ຂະຫຍາຍການຊື່ໄຟລ໌ທີ່ໄດ້ມີການຍົກຂຶ້ນມາອ້າງ.
    ///
    /// ມີ [`line!`] ແລະ [`column!`] ແມໂຄເຫລົ່ານີ້ສະຫນອງຂໍ້ມູນ debugging ສໍາລັບພັດທະນາປະມານສະຖານທີ່ພາຍໃນຂໍ້ມູນໄດ້.
    ///
    /// ການສະແດງອອກຂະຫຍາຍມີພິມ `&'static str`, ແລະເອກະສານຄືນໄດ້ບໍ່ແມ່ນ invocation ຂອງມະຫາພາກ `file!` ຕົວຂອງມັນເອງ, ແຕ່ແທນທີ່ຈະໄດ້ invocation ມະຫາພາກທໍາອິດນໍາໄປສູ່ພາວະນາຂອງມະຫາພາກ `file!` ໄດ້.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifies ກະທູ້ທີ່ຂອງຕົນ.
    ///
    /// ມະຫາພາກນີ້ຈະໃຫ້ຜົນຜະລິດການສະແດງອອກຂອງປະເພດ `&'static str` ຊຶ່ງເປັນ stringification ຂອງທັງຫມົດ tokens ໄດ້ຜ່ານການມະຫາພາກໄດ້.
    /// ການຈໍາກັດບໍ່ແມ່ນຖືກຈັດໃສ່ໃນໄວຢາກອນຂອງ invocation ມະຫາພາກຕົວຂອງມັນເອງໄດ້.
    ///
    /// ໃຫ້ສັງເກດວ່າຜົນໄດ້ຮັບການຂະຫຍາຍຕົວຂອງວັດສະດຸປ້ອນ tokens ອາດມີການປ່ຽນແປງໃນ future.ທ່ານຄວນຈະລະມັດລະວັງຖ້າຫາກວ່າທ່ານແມ່ນເອື່ອຍອີງໃສ່ຜົນຜະລິດໄດ້.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ປະກອບມີເອກະສານເຂົ້າລະຫັດ UTF-8 ເປັນຊ່ອຍແນ່.
    ///
    /// ເອກະສານດັ່ງກ່າວແມ່ນຕັ້ງເມື່ອທຽບກັບເອກະສານໃນປະຈຸບັນ (ເຊັ່ນດຽວກັນກັບວິທີການລະຫັດທີ່ພົບ).
    /// ເສັ້ນທາງສະຫນອງໃຫ້ແມ່ນການຕີລາຄາໃນທາງທີ່ເວທີສະເພາະໃດຫນຶ່ງໃນເວລາລວບລວມ.
    /// ດັ່ງນັ້ນ, ສໍາລັບການຍົກຕົວຢ່າງ, ເປັນ invocation ມີເສັ້ນທາງ Windows ມີເຄື່ອງຫມາຍທັບຂວາ `\` ຈະບໍ່ສັງລວມຢ່າງຖືກຕ້ອງກ່ຽວກັບ Unix.
    ///
    ///
    /// ມະຫາພາກນີ້ຈະໃຫ້ຜົນຜະລິດການສະແດງອອກຂອງປະເພດ `&'static str` ຊຶ່ງເປັນເນື້ອໃນຂອງເອກະສານດັ່ງກ່າວໄດ້.
    ///
    /// # Examples
    ///
    /// ສົມມຸດມີສອງໄຟລ໌ໃນລະບົບດຽວກັນກັບເນື້ອໃນດັ່ງຕໍ່ໄປນີ້:
    ///
    /// File 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// ສັງລວມ 'main.rs' ແລະແລ່ນ binary ຜົນຈະພິມ "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ປະກອບເອກະສານເພື່ອເປັນບ່ອນອີງໃຫ້ array byte ຕົນເອງໄດ້.
    ///
    /// ເອກະສານດັ່ງກ່າວແມ່ນຕັ້ງເມື່ອທຽບກັບເອກະສານໃນປະຈຸບັນ (ເຊັ່ນດຽວກັນກັບວິທີການລະຫັດທີ່ພົບ).
    /// ເສັ້ນທາງສະຫນອງໃຫ້ແມ່ນການຕີລາຄາໃນທາງທີ່ເວທີສະເພາະໃດຫນຶ່ງໃນເວລາລວບລວມ.
    /// ດັ່ງນັ້ນ, ສໍາລັບການຍົກຕົວຢ່າງ, ເປັນ invocation ມີເສັ້ນທາງ Windows ມີເຄື່ອງຫມາຍທັບຂວາ `\` ຈະບໍ່ສັງລວມຢ່າງຖືກຕ້ອງກ່ຽວກັບ Unix.
    ///
    ///
    /// ມະຫາພາກນີ້ຈະໃຫ້ຜົນຜະລິດການສະແດງອອກຂອງປະເພດ `&'static [u8; N]` ຊຶ່ງເປັນເນື້ອໃນຂອງເອກະສານດັ່ງກ່າວໄດ້.
    ///
    /// # Examples
    ///
    /// ສົມມຸດມີສອງໄຟລ໌ໃນລະບົບດຽວກັນກັບເນື້ອໃນດັ່ງຕໍ່ໄປນີ້:
    ///
    /// File 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// ສັງລວມ 'main.rs' ແລະແລ່ນ binary ຜົນຈະພິມ "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ຂະຫຍາຍໄປຫາສາຍເຊືອກທີ່ສະແດງເສັ້ນທາງໂມດູນໃນປະຈຸບັນ.
    ///
    /// ເສັ້ນທາງໂມດູນໃນປະຈຸບັນສາມາດໄດ້ຮັບການຄິດຂອງເປັນລໍາດັບຊັ້ນຂອງຜູ້ໃຊ້ລະນໍາພາໄປເຖິງການ crate root ໄດ້.
    /// ອົງປະກອບທໍາອິດຂອງເສັ້ນທາງກັບຄືນເປັນຊື່ຂອງ crate ໃນປະຈຸບັນຖືກລວບລວມ.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// ປະເມີນການປະສົມ boolean ຂອງທຸງຊາດການຕັ້ງຄ່າທີ່ລວບລວມທີ່ໃຊ້ເວລາ.
    ///
    /// ນອກເຫນືອໄປຈາກ `#[cfg]` ເຫດຜົນ, ມະຫາພາກທີ່ຖືກເຜີຍແຜ່ອະນຸຍາດໃຫ້ການປະເມີນຜົນສະແດງອອກ boolean ຂອງທຸງຊາດການຕັ້ງຄ່າ.
    /// ນີ້ມັກຈະເຮັດໃຫ້ລະຫັດທີ່ຊ້ ຳ ກັນ ໜ້ອຍ ລົງ.
    ///
    /// syntax ໃຫ້ແກ່ມະຫາພາກນີ້ແມ່ນໄວຍາກອນເຊັ່ນດຽວກັນກັບ [`cfg`] ເຫດຜົນ.
    ///
    /// `cfg!`, ບໍ່ເຫມືອນກັບ `#[cfg]`, ບໍ່ເອົາລະຫັດແລະພຽງແຕ່ປະເມີນເປັນ true ຫຼື false.
    /// ສໍາລັບຕົວຢ່າງ, ທ່ອນໄມ້ທັງຫມົດໃນການສະແດງອອກຄວາມຕ້ອງ if/else ຈະຖືກຕ້ອງໃນເວລາທີ່ `cfg!` ຖືກນໍາໃຊ້ສໍາລັບການສະພາບການ, ບໍ່ຄໍານຶງເຖິງສິ່ງທີ່ `cfg!` ແມ່ນການປະເມີນ.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// parses ໄຟເປັນການສະແດງອອກຫຼືລາຍການອີງຕາມການສະພາບການໄດ້.
    ///
    /// ເອກະສານດັ່ງກ່າວແມ່ນຕັ້ງເມື່ອທຽບກັບເອກະສານໃນປະຈຸບັນ (ເຊັ່ນດຽວກັນກັບວິທີການລະຫັດທີ່ພົບ).ເສັ້ນທາງທີ່ໄດ້ສະ ໜອງ ໃຫ້ຖືກຕີຄວາມ ໝາຍ ໃນແບບເວທີທີ່ສະເພາະໃນເວລາທີ່ລວບລວມ.
    /// ດັ່ງນັ້ນ, ສໍາລັບການຍົກຕົວຢ່າງ, ເປັນ invocation ມີເສັ້ນທາງ Windows ມີເຄື່ອງຫມາຍທັບຂວາ `\` ຈະບໍ່ສັງລວມຢ່າງຖືກຕ້ອງກ່ຽວກັບ Unix.
    ///
    /// ການນໍາໃຊ້ມະຫາພາກນີ້ມັກຈະເປັນຄວາມຄິດທີ່ດີ, ເນື່ອງຈາກວ່າຖ້າຫາກວ່າໄຟລ໌ໄດ້ຖືກວິເຄາະເປັນການສະແດງອອກ, ມັນຈະໄດ້ຮັບການໄວ້ໃນລະຫັດທີ່ອ້ອມຂ້າງ unhygienically.
    /// ນີ້ສາມາດສົ່ງຜົນໃຫ້ຕົວແປຫລື ໜ້າ ທີ່ແຕກຕ່າງຈາກສິ່ງທີ່ຄາດຫວັງໄວ້ໃນເອກະສານຖ້າມີຕົວແປຫລືຫນ້າທີ່ມີຊື່ດຽວກັນໃນເອກະສານປະຈຸບັນ.
    ///
    ///
    /// # Examples
    ///
    /// ສົມມຸດມີສອງໄຟລ໌ໃນລະບົບດຽວກັນກັບເນື້ອໃນດັ່ງຕໍ່ໄປນີ້:
    ///
    /// File 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// File 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// ການລວບລວມ 'main.rs' ແລະການແລ່ນຖານຂໍ້ມູນທີ່ເປັນຜົນມາຈາກການຈະພິມ "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ໄດ້ຢືນຢັນວ່າການສະແດງອອກ boolean ເປັນ `true` ຢູ່ runtime.
    ///
    /// ນີ້ຈະຮ້ອງຂໍມະຫາພາກ [`panic!`] ຖ້າການສະແດງອອກໃຫ້ບໍ່ສາມາດໄດ້ຮັບການປະເມີນຜົນເພື່ອ `true` ຢູ່ runtime.
    ///
    /// # Uses
    ///
    /// ການຍື່ນຍັນມີການກວດກາສະເຫມີໃນທັງສອງ debug ແລະປ່ອຍເສີມສ້າງ, ແລະບໍ່ສາມາດໄດ້ຮັບການພິການ.
    /// ເບິ່ງ [`debug_assert!`] ສໍາລັບການຍື່ນຍັນວ່າຍັງບໍ່ໄດ້ເປີດໃຫ້ໃຊ້ງານໃນການປ່ອຍສ້າງຕັ້ງແຕ່ຕອນຕົ້ນ.
    ///
    /// ລະຫັດທີ່ບໍ່ປອດໄພອາດຈະອີງໃສ່ `assert!` ການບັງຄັບໃຊ້ຄາຄົງດໍາເນີນການທີ່ໃຊ້ເວລາວ່າ, ຖ້າຫາກວ່າລະເມີດສາມາດນໍາໄປສູ່ການ unsafety.
    ///
    /// ການນໍາໃຊ້ໃນກໍລະນີອື່ນໆຂອງ `assert!` ປະກອບມີການທົດສອບແລະການບັງຄັບໃຊ້ຄາຄົງດໍາເນີນງານທີ່ໃຊ້ເວລາໃນລະຫັດຄວາມປອດໄພ (ທີ່ລະເມີດບໍ່ສາມາດສົ່ງຜົນໃນ unsafety).
    ///
    ///
    /// # ຂໍ້ຄວາມ Custom
    ///
    /// ມະຫາພາກນີ້ມີຮູບແບບທີສອງ, ບ່ອນທີ່ຂໍ້ຄວາມ panic custom ສາມາດໄດ້ຮັບການສະຫນອງໃຫ້ມີຫຼືບໍ່ມີການໂຕ້ຖຽງສໍາລັບຮູບແບບ.
    /// ເບິ່ງ [`std::fmt`] ສໍາລັບ syntax ສໍາລັບແບບຟອມນີ້.
    /// ການສະແດງອອກຖືກນໍາໃຊ້ເປັນການໂຕ້ຖຽງຮູບແບບເທົ່ານັ້ນຈະໄດ້ຮັບການປະເມີນຜົນຖ້າຫາກວ່າການຍື່ນຍັນລົ້ມເຫລວ.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ຂໍ້ຄວາມ panic ສຳ ລັບ ຄຳ ຢືນຢັນເຫລົ່ານີ້ແມ່ນມູນຄ່າທີ່ຖືກຕ້ອງຂອງການສະແດງອອກ.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // ການທໍາງານຂອງງ່າຍດາຍທີ່ສຸດ
    ///
    /// assert!(some_computation());
    ///
    /// // ຫມັ້ນໃຈກັບຂໍ້ຄວາມທີ່ກໍາຫນົດເອງ
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// inline ສະພາແຫ່ງ.
    ///
    /// ອ່ານ [unstable book] ສໍາລັບການນໍາໃຊ້ໄດ້.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// ການຊຸມນຸມແບບເສັ້ນແບບແບບ LLVM.
    ///
    /// ອ່ານ [unstable book] ສໍາລັບການນໍາໃຊ້ໄດ້.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// ການປະກອບເສັ້ນໃນລະດັບແບບໂມດູນ.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Prints ຜ່ານ tokens ເຂົ້າໄປໃນການຜະລິດມາດຕະຖານ.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ເຮັດໃຫ້ຫຼືປິດໃຊ້ວຽກການສືບຄົ້ນການທໍາງານການນໍາໃຊ້ສໍາລັບການແກ້ຈຸດບົກພ່ອງ macros ອື່ນໆ.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// ມະຫາພາກໃຫ້ເຫດຜົນຖືກນໍາໃຊ້ເພື່ອສະຫມັກຂໍເອົາມະຫາພາກ Derive.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// ມະຫາພາກໃຫ້ເຫດຜົນນໍາໃຊ້ທີ່ຈະທໍາງານເພື່ອເຮັດໃຫ້ມັນເຂົ້າໄປໃນການທົດສອບຫນ່ວຍ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// ມະຫາພາກໃຫ້ເຫດຜົນນໍາໃຊ້ທີ່ຈະທໍາງານເພື່ອເຮັດໃຫ້ມັນເຂົ້າໄປໃນການທົດສອບມາດຕະຖານ.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// ລາຍລະອຽດການຈັດຕັ້ງປະຕິບັດມະຫາພາກຂອງ `#[test]` ແລະ `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// ມະຫາພາກໃຫ້ເຫດຜົນນໍາໃຊ້ກັບໄຟຟ້າສະຖິດທີ່ຈະລົງທະບຽນມັນເປັນຕົວຈັດສັນໃນທົ່ວໂລກ.
    ///
    /// ເບິ່ງທີ່ [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// ເຮັດໃຫ້ລາຍການມັນນໍາໃຊ້ເພື່ອວ່າເສັ້ນທາງຜ່ານແມ່ນສາມາດເຂົ້າເຖິງ, ແລະມັນ removes ຖ້າບໍ່ດັ່ງນັ້ນ.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// ຂະຫຍາຍທັງຫມົດ `#[cfg]` ແລະ `#[cfg_attr]` ຄຸນລັກສະນະໃນ fragment ລະຫັດມັນນໍາໃຊ້ເພື່ອ.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// ລາຍລະອຽດການປະຕິບັດ Unstable ຂອງ compiler `rustc`, ບໍ່ນໍາໃຊ້.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// ລາຍລະອຽດການປະຕິບັດ Unstable ຂອງ compiler `rustc`, ບໍ່ນໍາໃຊ້.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}