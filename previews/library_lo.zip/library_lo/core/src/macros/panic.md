Panics ກະທູ້ປະຈຸບັນ.

ນີ້ອະນຸຍາດໃຫ້ໂຄງການເພື່ອຢຸດຕິໃນທັນທີແລະໃຫ້ຂໍ້ສະເຫນີແນະທີ່ຈະແປໄດ້ທຸຂອງໂຄງການດັ່ງກ່າວ.
`panic!` ຄວນຈະໃຊ້ໃນເວລາທີ່ໂຄງການໄດ້ບັນລຸລາຍຮັບຂອງລັດກູ້.

ມະຫາພາກນີ້ແມ່ນວິທີການທີ່ສົມບູນແບບກັບສະພາບ ASSERT ໃນລະຫັດຕົວຢ່າງແລະໃນການທົດສອບ.
`panic!` ແມ່ນ tied ຢ່າງໃກ້ຊິດກັບວິທີການ `unwrap` ຂອງທັງສອງ [`Option`][ounwrap] ແລະ [`Result`][runwrap] ENUM.
ທັງສອງປະຕິບັດໂທ `panic!` ໃນເວລາທີ່ພວກເຂົາເຈົ້າແມ່ນກໍານົດໃຫ້ [`None`] ຫຼື [`Err`] variants.

ໃນເວລາທີ່ການນໍາໃຊ້ `panic!()` ທ່ານສາມາດກໍານົດເປັນ payload string, ທີ່ຖືກສ້າງຂຶ້ນໂດຍໃຊ້ໄວຢາກອນ [`format!`].
payload ທີ່ໃຊ້ໃນເວລາທີ່ສັກ panic ເຂົ້າໄປໃນກະທູ້ Rust ໂທຫາ, ເຊິ່ງກໍ່ໃຫ້ເກີດກະທູ້ເພື່ອ panic ທັງຫມົດ.

ພຶດຕິກໍາຂອງໄວ້ໃນຕອນຕົ້ນ `std` hook, ie
ລະຫັດທີ່ເນັ້ນໂດຍກົງຫຼັງຈາກ panic ແມ່ນຍົກຂຶ້ນມາອ້າງ, ແມ່ນເພື່ອພິມ payload ຂໍ້ຄວາມທີ່ຈະ `stderr` ຄຽງຄູ່ກັບການຂໍ້ມູນຂ່າວສານ file/line/column ຂອງ call `panic!()`.

ທ່ານສາມາດຂຽນທັບໄດ້ panic hook ໃຊ້ [`std::panic::set_hook()`].
ພາຍໃນ hook ເປັນ panic ສາມາດໄດ້ຮັບການເຂົ້າເຖິງເປັນ `&dyn Any + Send`, ເຊິ່ງປະກອບດ້ວຍບໍ່ວ່າຈະເປັນ `&str` ຫຼື `String` ສໍາລັບ invocations `panic!()` ປົກກະຕິ.
ໄປ panic ມີມູນຄ່າປະເພດອື່ນໆອີກ, [`panic_any`] ສາມາດຖືກນໍາໃຊ້.

[`Result`] enum ມັກເປັນການແກ້ໄຂທີ່ດີກວ່າສໍາລັບການຟື້ນຈາກຄວາມຜິດພາດກ່ວາການນໍາໃຊ້ມະຫາພາກ `panic!`.
ມະຫາພາກນີ້ຄວນໄດ້ຮັບການນໍາໃຊ້ເພື່ອຫຼີກເວັ້ນການດໍາເນີນການນໍາໃຊ້ຄ່າທີ່ບໍ່ຖືກຕ້ອງ, ເຊັ່ນ: ຈາກແຫຼ່ງຂໍ້ມູນຈາກພາຍນອກ.
ລາຍລະອຽດຂໍ້ມູນກ່ຽວກັບຫຼັງຄວາມຜິດພາດໄດ້ຖືກພົບເຫັນໃນ [book].

ເບິ່ງແມັກ [`compile_error!`], ສຳ ລັບການຍົກຂໍ້ຜິດພາດໃນໄລຍະການລວບລວມ.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນ

ຖ້າຫາກວ່າເທລົດຫລັກ panics ມັນຈະຢຸດຫົວຂໍ້ທັງຫມົດຂອງທ່ານແລະໃນທີ່ສຸດໂຄງການຂອງທ່ານທີ່ມີລະຫັດ `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





