#![stable(feature = "futures_api", since = "1.36.0")]

//! ຄ່າ Asynchronous.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// ປະເພດນີ້ແມ່ນຈໍາເປັນເພາະວ່າ:
///
/// a) ເຄື່ອງປັ່ນໄຟບໍ່ສາມາດປະຕິບັດ `for<'a, 'b> Generator<&'a mut Context<'b>>` ໄດ້, ດັ່ງນັ້ນພວກເຮົາ ຈຳ ເປັນຕ້ອງໄດ້ຜ່ານຕົວຊີ້ວັດຖຸດິບ (ເບິ່ງ <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) ຕົວຊີ້ວັດຖຸດິບແລະ `NonNull` ບໍ່ `Send` ຫຼື `Sync`, ສະນັ້ນທີ່ຈະເຮັດໃຫ້ທຸກດຽວ future non-Send/Sync ເຊັ່ນດຽວກັນ, ແລະພວກເຮົາບໍ່ຕ້ອງການທີ່.
///
/// ມັນຍັງງ່າຍຕໍ່ການຫຼຸດ HIR ຂອງ `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// ຫໍ່ກໍາເນີດໄຟຟ້າໃນ future ໄດ້.
///
/// ຟັງຊັນນີ້ສົ່ງຄືນ `GenFuture` ພາຍໃຕ້, ແຕ່ເຊື່ອງມັນຢູ່ໃນ `impl Trait` ເພື່ອໃຫ້ຂໍ້ຄວາມຜິດພາດທີ່ດີກວ່າ (`impl Future` ກ່ວາ `GenFuture<[closure.....]>`).
///
// ນີ້ແມ່ນ `const` ເພື່ອຫຼີກເວັ້ນຄວາມຜິດພາດພິເສດຫຼັງຈາກທີ່ພວກເຮົາຟື້ນຕົວຈາກ `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // ພວກເຮົາອີງໃສ່ຄວາມຈິງທີ່ວ່າ async/await futures ແມ່ນບໍ່ສາມາດເຄື່ອນໄຫວໄດ້ເພື່ອສ້າງການກູ້ຢືມເງິນທີ່ອ້າງອີງຕົນເອງໃນເຄື່ອງຈັກຜະລິດໄຟຟ້າ.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // SAFETY ປອດໄພເນື່ອງຈາກວ່າພວກເຮົາກໍາລັງ !Unpin + !Drop, ແລະນີ້ແມ່ນພຽງແຕ່ການຄາດຄະເນພາກສະຫນາມ.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // ສືບຕໍ່ການຜະລິດຂອງ, ປ່ຽນເປັນສີ `&mut Context` ເຂົ້າໄປໃນຕົວຊີ້ວັດຖຸດິບ `NonNull`.
            // The `.await` ວິທີຫຼຸດຜ່ອນຈະຂັບໄລ່ພວກທີ່ກັບຄືນໄປບ່ອນ `&mut Context` ຢ່າງປອດໄພ.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SAFETY: ການຄໍ້າປະກັນໂທຕ້ອງທີ່ `cx.0` ເປັນຊີ້ຖືກຕ້ອງ
    // ທີ່ປະຕິບັດບັນດາຂໍ້ ກຳ ນົດທັງ ໝົດ ສຳ ລັບການອ້າງອິງກັນແລະກັນ.
    unsafe { &mut *cx.0.as_ptr().cast() }
}