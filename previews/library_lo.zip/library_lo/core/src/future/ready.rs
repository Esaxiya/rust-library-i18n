use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// ສ້າງ future ທີ່ກຽມພ້ອມທັນທີດ້ວຍມູນຄ່າ.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍ [`ready()`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
#[derive(Debug, Clone)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct Ready<T>(Option<T>);

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Unpin for Ready<T> {}

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Future for Ready<T> {
    type Output = T;

    #[inline]
    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<T> {
        Poll::Ready(self.0.take().expect("Ready polled after completion"))
    }
}

/// ສ້າງ future ທີ່ກຽມພ້ອມທັນທີດ້ວຍມູນຄ່າ.
///
/// Futures ສ້າງໂດຍຜ່ານການທໍາງານນີ້ແມ່ນຕົວຈິງແລ້ວມຄ້າຍຄືກັນກັບຜູ້ສ້າງໂດຍຜ່ານການ `async {}`.
/// ຄວາມແຕກຕ່າງຕົ້ນຕໍແມ່ນວ່າ futures ສ້າງໂດຍຜ່ານການທໍາງານນີ້ແມ່ນມີຊື່ແລະປະຕິບັດ `Unpin`.
///
/// # Examples
///
/// ```
/// use std::future;
///
/// # async fn run() {
/// let a = future::ready(1);
/// assert_eq!(a.await, 1);
/// # }
/// ```
///
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub fn ready<T>(t: T) -> Ready<T> {
    Ready(Some(t))
}