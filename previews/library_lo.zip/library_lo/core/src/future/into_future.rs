use crate::future::Future;

/// ແປງເປັນ `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// ຜົນຜະລິດທີ່ future ຈະຜະລິດເມື່ອ ສຳ ເລັດ.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// ເຊິ່ງປະເພດຂອງ future ພວກເຮົາປ່ຽນເປັນສີນີ້ເຂົ້າໄປໃນ?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// ສ້າງ future ຈາກຄ່າ.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}