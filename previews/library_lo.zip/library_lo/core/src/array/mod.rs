//! ການຈັດຕັ້ງປະຕິບັດສິ່ງຕ່າງໆເຊັ່ນ `Eq` ສຳ ລັບການ ກຳ ນົດໄລຍະເວລາຄົງທີ່ມີຄວາມຍາວແນ່ນອນ.
//! ໃນທີ່ສຸດ, ພວກເຮົາຄວນຈະສາມາດໃຫ້ຄວາມຮູ້ທົ່ວໄປກັບຄວາມຍາວທັງ ໝົດ.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// ແປງເອກະສານອ້າງອີງ `T` X ເຂົ້າໄປໃນເອກະສານອ້າງອີງເຖິງຂບວນທີ່ມີຄວາມຍາວ 1 (ໂດຍບໍ່ຕ້ອງຄັດລອກ).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // ຄວາມປອດໄພ: ການແປງ `&T` ຫາ `&[T; 1]` ແມ່ນສຽງ.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// ປ່ຽນເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບ `T` ເຂົ້າໄປໃນການອ້າງອີງທີ່ສາມາດປ່ຽນແປງໄດ້ກັບແຖວຂອງຄວາມຍາວ 1 (ໂດຍບໍ່ຕ້ອງຄັດລອກ).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // SAFETY: ແປງ `&mut T` ກັບ `&mut [T; 1]` ແມ່ນສຽງ.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// Utility trait ປະຕິບັດໄດ້ພຽງແຕ່ອາຄານທີ່ມີຂະ ໜາດ ຄົງທີ່ເທົ່ານັ້ນ
///
/// trait ນີ້ສາມາດຖືກນໍາໃຊ້ເພື່ອປະຕິບັດ traits ອື່ນໆໃນອາເລຄົງຂະຫນາດໂດຍບໍ່ມີການເຊິ່ງກໍ່ໃຫ້ເກີດຂະຫຍາຍຕົວ metadata ຫຼາຍ.
///
/// The trait ຖືກຫມາຍທີ່ບໍ່ປອດໄພໃນຄໍາສັ່ງເພື່ອຈໍາກັດການ implementor ອາເລຄົງຂະຫນາດ.
/// ຜູ້ໃຊ້ trait ນີ້ສາມາດສົມມຸດວ່າຜູ້ປະຕິບັດມີຮູບແບບທີ່ແນ່ນອນໃນຄວາມຊົງ ຈຳ ຂອງຂະ ໜາດ ຄົງທີ່ (ຕົວຢ່າງ, ສຳ ລັບການເລີ່ມຕົ້ນທີ່ບໍ່ປອດໄພ).
///
///
/// ໃຫ້ສັງເກດວ່າ traits [`AsRef`] ແລະ [`AsMut`] ສະຫນອງວິທີການທີ່ຄ້າຍຄືກັນສໍາລັບປະເພດທີ່ອາດຈະບໍ່ແມ່ນຂບວນຂະ ໜາດ ຄົງທີ່.
/// implementor ຄວນຕ້ອງຜູ້ traits ແທນທີ່ຈະ.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// ແປງແຖວໃຫ້ເປັນທ່ອນທີ່ບໍ່ປ່ຽນແປງ
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// ແປງອາເລໃຫ້ເປັນທ່ອນເຊິ່ງກັນແລະກັນໄດ້
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// ປະເພດຄວາມຜິດພາດກັບຄືນໃນເວລາທີ່ປ່ຽນໃຈເຫລື້ອມໃສຈາກຫຼັງຈາກນັ້ນນໍາໄປຍັງອາເລເປັນລົ້ມເຫລວ.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // SAFETY: ງາມເພາະວ່າພວກເຮົາຈະກວດສອບພຽງທີ່ຊັກຍາວ
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // SAFETY: ງາມເພາະວ່າພວກເຮົາຈະກວດສອບພຽງທີ່ຊັກຍາວ
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: ເຄື່ອງ ໝາຍ ບາງຢ່າງທີ່ບໍ່ ສຳ ຄັນຖືກຍົກເວັ້ນເພື່ອຫຼຸດຜ່ອນການລະຫັດຂອງດອກໄມ້
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// ການສົມທຽບການປະຕິບັດຂອງອາເລ [lexicographically](Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// The Default ບໍ່ສາມາດເຮັດໄດ້ກັບ const generics ເພາະ `[T; 0]` ບໍ່ຕ້ອງການ Default ທີ່ຈະຖືກຈັດຕັ້ງປະຕິບັດ, ແລະມີການສະກັດກັ້ນທີ່ແຕກຕ່າງກັນ ສຳ ລັບຕົວເລກທີ່ແຕກຕ່າງກັນບໍ່ໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ເທື່ອ.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// ກັບຄືນແຖວຂອງຂະ ໜາດ ດຽວກັນກັບ `self`, ດ້ວຍຟັງຊັນ `f` ໃຊ້ກັບແຕ່ລະອົງປະກອບຕາມ ລຳ ດັບ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // ຄວາມປອດໄພ: ພວກເຮົາຮູ້ຢ່າງແນ່ນອນວ່າຕົວຊີ້ວັດນີ້ຈະໃຫ້ຜົນຜະລິດ `N` ຢ່າງແນ່ນອນ
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// 'Zips up' ສອງແຖວເປັນແຖວຂອງຄູ່.
    ///
    /// `zip()` ຜົນໄດ້ຮັບເປັນ array ໃຫມ່ບ່ອນທີ່ອົງປະກອບທຸກເປັນ tuple ເປັນບ່ອນທີ່ອົງປະກອບທໍາອິດທີ່ມາຈາກຂບວນທໍາອິດ, ແລະອົງປະກອບທີສອງມາຈາກຂບວນທີສອງ.
    ///
    /// ເວົ້າອີກຢ່າງ ໜຶ່ງ, ມັນຫຍໍ້ເຂົ້າສອງແຖວເຂົ້າກັນ, ເປັນ ໜຶ່ງ ດຽວ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // ຄວາມປອດໄພ: ພວກເຮົາຮູ້ຢ່າງແນ່ນອນວ່າຕົວຊີ້ວັດນີ້ຈະໃຫ້ຜົນຜະລິດ `N` ຢ່າງແນ່ນອນ
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// ຜົນໄດ້ຮັບຫຼັງຈາກນັ້ນນໍາທີ່ມີຂບວນທັງຫມົດ.ທຽບເທົ່າກັບ `&s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// ຜົນໄດ້ຮັບຫຼັງຈາກນັ້ນນໍາບໍ່ແນ່ນອນທີ່ມີການຂບວນທັງຫມົດ.
    /// ເທົ່າກັບ `&mut s[..]`.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// ກູ້ຢືມເງິນແຕ່ລະອົງປະກອບແລະຜົນໄດ້ຮັບ array ຂອງເອກະສານທີ່ມີຂະຫນາດເຊັ່ນດຽວກັນກັບ `self` ເປັນ.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// ວິທີການນີ້ແມ່ນເປັນປະໂຫຍດໂດຍສະເພາະຖ້າຫາກວ່າອະນຸຍາດຂອງທີ່ມີວິທີການອື່ນໆ, ເຊັ່ນ: [`map`](#method.map).
    /// ວິທີການດັ່ງກ່າວນີ້, ທ່ານສາມາດຫຼີກເວັ້ນການເຄື່ອນຍ້າຍຂອງ array ຕົ້ນສະບັບຖ້າຫາກວ່າອົງປະກອບຂອງຕົນບໍ່ໄດ້ `Copy`.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // ພວກເຮົາຍັງສາມາດເຂົ້າເຖິງແຖວເດີມໄດ້: ມັນບໍ່ໄດ້ຖືກຍ້າຍ.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // ຄວາມປອດໄພ: ພວກເຮົາຮູ້ຢ່າງແນ່ນອນວ່າຕົວຊີ້ວັດນີ້ຈະໃຫ້ຜົນຜະລິດ `N` ຢ່າງແນ່ນອນ
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// ເຊົ່າແຕ່ລະອົງປະກອບທີ່ປ່ຽນແປງໄດ້ແລະສົ່ງຄືນເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ເຊິ່ງມີຂະ ໜາດ ເທົ່າກັບ `self`.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // ຄວາມປອດໄພ: ພວກເຮົາຮູ້ຢ່າງແນ່ນອນວ່າຕົວຊີ້ວັດນີ້ຈະໃຫ້ຜົນຜະລິດ `N` ຢ່າງແນ່ນອນ
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// ລາຍການດຶງ `N` ຈາກ `iter` ແລະຜົນຕອບແທນໃຫ້ເຂົາເຈົ້າເປັນອາເລ.
/// ຖ້າຕົວຊີ້ວັດໃຫ້ຜົນຜະລິດ ໜ້ອຍ ກວ່າ `N`, ໜ້າ ທີ່ນີ້ຈະສະແດງພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ.
///
///
/// ເບິ່ງ [`collect_into_array`] ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ.
///
/// # Safety
///
/// ມັນຂຶ້ນກັບຜູ້ໂທເພື່ອຮັບປະກັນວ່າ `iter` ຈະໃຫ້ລາຍໄດ້ຢ່າງ ໜ້ອຍ `N`.
/// ການລະເມີດເງື່ອນໄຂນີ້ເຮັດໃຫ້ເກີດການປະພຶດທີ່ບໍ່ມີຂອບເຂດ.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: `TrustedLen` ຢູ່ທີ່ນີ້ແມ່ນການທົດລອງບາງຢ່າງ.ນີ້ແມ່ນພຽງແຕ່ເປັນ
    // ໜ້າ ທີ່ພາຍໃນ, ດັ່ງນັ້ນຮູ້ສຶກວ່າບໍ່ເສຍຄ່າທີ່ຈະເອົາອອກຖ້າວ່າສິ່ງທີ່ຜູກມັດນີ້ກາຍເປັນຄວາມຄິດທີ່ບໍ່ດີ.
    // ໃນກໍລະນີນັ້ນ, ຈື່ຈໍາທີ່ຈະຍັງເອົາໄປຜູກຕ່ໍາ `debug_assert!` ຕ່ໍາກວ່າ!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // ຄວາມປອດໄພ: ປົກຄຸມດ້ວຍສັນຍາການເຮັດວຽກ.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// ລາຍການດຶງ `N` ຈາກ `iter` ແລະຜົນຕອບແທນໃຫ້ເຂົາເຈົ້າເປັນອາເລ.ຖ້າ iterator ໄດ້ຜົນຜະລິດຫນ້ອຍກ່ວາລາຍການ `N`, `None` ແມ່ນກັບຄືນແລະລາຍຜົນຜະລິດແລ້ວທັງຫມົດແມ່ນຫຼຸດລົງ.
///
/// ເນື່ອງຈາກຕົວຊີ້ວັດໄດ້ຖືກສົ່ງຜ່ານໄປເປັນເອກະສານອ້າງອິງເຊິ່ງກັນແລະກັນແລະ ໜ້າ ທີ່ນີ້ເອີ້ນວ່າ `next` ໃນຊ່ວງເວລາຫຼາຍທີ່ສຸດ `N`, ຕົວຍີ່ງຍັງສາມາດໃຊ້ຕໍ່ມາເພື່ອດຶງເອົາສິ່ງຂອງທີ່ຍັງເຫຼືອ.
///
///
/// ຖ້າໂຕ00ະ `iter.next()`, ສິນຄ້າທຸກຢ່າງທີ່ໄດ້ຮັບຈາກເຄື່ອງວັດແທກນັ້ນຖືກລຸດລົງ.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // ຄວາມປອດໄພ: ອາຄານຫວ່າງເປົ່າແມ່ນບ່ອນຢູ່ອາໄສສະ ເໝີ ແລະບໍ່ມີສັດຕູທີ່ຖືກຕ້ອງ.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // SAFETY: ນີ້ຫຼັງຈາກນັ້ນນໍາດິບຈະປະກອບດ້ວຍວັດຖຸເລີ່ມຕົ້ນເທົ່ານັ້ນ.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // ຄວາມປອດໄພ: `guard.initialized` ເລີ່ມຕົ້ນທີ່ 0, ແມ່ນເພີ່ມຂື້ນ 1 ໃນ
        // loop ແລະ loop ໄດ້ຖືກຍົກເລີກເມື່ອມັນຮອດ N (ເຊິ່ງແມ່ນ `array.len()`).
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // ກວດເບິ່ງວ່າອາເລທັງ ໝົດ ຖືກເລີ່ມຕົ້ນ.
        if guard.initialized == N {
            mem::forget(guard);

            // ຄວາມປອດໄພ: ສະພາບຂ້າງເທິງຢືນຢັນວ່າທຸກໆອົງປະກອບແມ່ນ
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // ນີ້ບັນລຸໄດ້ພຽງແຕ່ຖ້າວ່າຕົວປ່ຽນແປງແມ່ນຫມົດກ່ອນ `guard.initialized` ຮອດ `N`.
    //
    // ຍັງໄດ້ສັງເກດວ່າ `guard` ຖືກຖີ້ມລົງໃນທີ່ນີ້, ເລີ່ມຫຼຸດລົງເລື້ອຍອົງປະກອບເລີ່ມຕົ້ນແລ້ວທັງຫມົດ.
    None
}