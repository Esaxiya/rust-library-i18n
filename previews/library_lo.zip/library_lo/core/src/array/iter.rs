//! ກຳ ນົດຕົວຊີ້ວັດ `IntoIter` ທີ່ເປັນເຈົ້າຂອງ ສຳ ລັບຂບວນ.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A ໂດຍມີມູນຄ່າ [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// ນີ້ແມ່ນຂບວນທີ່ພວກເຮົາ ກຳ ລັງຊັ່ງຊາ.
    ///
    /// ອົງປະກອບທີ່ມີດັດຊະນີ `i` ທີ່ `alive.start <= i < alive.end` ຍັງບໍ່ທັນໄດ້ຮັບຜົນຜະລິດທັນແລະມີຄໍາ array ທີ່ຖືກຕ້ອງ.
    /// ອົງປະກອບທີ່ມີຕົວຊີ້ວັດ `i < alive.start` ຫຼື `i >= alive.end` ໄດ້ມີຜົນຜະລິດຢູ່ແລ້ວແລະບໍ່ຕ້ອງເຂົ້າເຖິງອີກຕໍ່ໄປ!ອົງປະກອບທີ່ຕາຍເຫຼົ່ານັ້ນແມ່ນອາດຈະຢູ່ໃນສະພາບທີ່ບໍ່ມີການປ່ຽນແປງຢ່າງສົມບູນ!
    ///
    ///
    /// ສະນັ້ນບັນດາສະຖານທີ່ແມ່ນ:
    /// - `data[alive]` ແມ່ນມີຊີວິດຢູ່ (ຫມາຍຄວາມວ່າມີອົງປະກອບທີ່ຖືກຕ້ອງ)
    /// - `data[..alive.start]` ແລະ `data[alive.end..]` ເສຍຊີວິດ (ເຊັ່ນ: ອົງປະກອບຂອງໄດ້ຖືກແລ້ວອ່ານແລະຕ້ອງບໍ່ຖືກສໍາພັດອີກຕໍ່ໄປ!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// ສ່ວນປະກອບຕ່າງໆໃນ `data` ທີ່ຍັງບໍ່ທັນໄດ້ຮັບຜົນຜະລິດເທື່ອ.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// ສ້າງເປັນ iterator ໃຫມ່ໃນໄລຍະ `array` ດັ່ງກ່າວ.
    ///
    /// *ໝາຍ ເຫດ*: ວິທີການນີ້ອາດຈະຖືກປະຕິເສດໃນ future, ຫຼັງຈາກ [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // ປະເພດຂອງ `value` ແມ່ນ `i32` ຢູ່ທີ່ນີ້, ແທນທີ່ຈະເປັນ `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // ຄວາມປອດໄພ: ເຄື່ອງສົ່ງສັນຍານຢູ່ທີ່ນີ້ແມ່ນມີຄວາມປອດໄພແທ້ໆ.ເອກະສານຂອງ `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` ແມ່ນຮັບປະກັນໃຫ້ມີຂະ ໜາດ ແລະຄວາມສອດຄ່ອງກັນ
        // > ເປັນ `T`.
        //
        // ເອກະສານສະແດງເຖິງແມ່ນວ່າຈະສົ່ງຕໍ່ຈາກແຖວ `MaybeUninit<T>` ໄປຫາແຖວ `T`.
        //
        //
        // ດ້ວຍສິ່ງນັ້ນ, ການເລີ່ມຕົ້ນນີ້ຕອບສະ ໜອງ ຄວາມຮຽກຮ້ອງຕ້ອງການຂອງບັນດາສັດຕະຍາບັນ.

        // FIXME(LukasKalbertodt): ຕົວຈິງແລ້ວໃຊ້ `mem::transmute` ຢູ່ທີ່ນີ້, ເມື່ອມັນເຮັດວຽກກັບ const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // ຈົນກ່ວານັ້ນ, ພວກເຮົາສາມາດໃຊ້ `mem::transmute_copy` ເພື່ອສ້າງ ສຳ ເນົາແບບເລັກໆນ້ອຍໆເປັນປະເພດອື່ນ, ແລ້ວລືມ `array` ເພື່ອບໍ່ໃຫ້ມັນລຸດລົງ.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ບໍ່ປ່ຽນແປງຂອງສ່ວນປະກອບທັງ ໝົດ ທີ່ຍັງບໍ່ທັນໄດ້ຮັບຜົນຜະລິດເທື່ອ.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // ຄວາມປອດໄພ: ພວກເຮົາຮູ້ວ່າທຸກໆອົງປະກອບພາຍໃນ `alive` ແມ່ນຖືກເລີ່ມຕົ້ນຢ່າງຖືກຕ້ອງ.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// ສົ່ງຄືນສ່ວນທີ່ສາມາດປ່ຽນແປງໄດ້ຂອງສ່ວນປະກອບທັງ ໝົດ ທີ່ຍັງບໍ່ທັນໄດ້ຮັບຜົນຜະລິດເທື່ອ.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // ຄວາມປອດໄພ: ພວກເຮົາຮູ້ວ່າທຸກໆອົງປະກອບພາຍໃນ `alive` ແມ່ນຖືກເລີ່ມຕົ້ນຢ່າງຖືກຕ້ອງ.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // ໄດ້ຮັບການດັດສະນີຕໍ່ໄປຈາກທາງຫນ້າ.
        //
        // ການເພີ່ມຂື້ນ `alive.start` ໂດຍ 1 ຮັກສາຄວາມແຕກຕ່າງຂອງ `alive`.
        // ເຖິງຢ່າງໃດກໍ່ຕາມ, ຍ້ອນການປ່ຽນແປງດັ່ງກ່າວ, ໃນໄລຍະເວລາສັ້ນໆ, ເຂດທີ່ມີຊີວິດຢູ່ບໍ່ແມ່ນ `data[alive]` ອີກຕໍ່ໄປ, ແຕ່ເປັນ `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // ອ່ານອົງປະກອບຈາກອາເລ.
            // ຄວາມປອດໄພ: `idx` ແມ່ນດັດສະນີ ໜຶ່ງ ໃນອະດີດຂອງພາກພື້ນ "alive" ຂອງ
            // ຂບວນ.ການອ່ານສ່ວນປະກອບນີ້ ໝາຍ ຄວາມວ່າ `data[idx]` ຖືວ່າເປັນຕາຍແລ້ວໃນຕອນນີ້ (ໝາຍ ຄວາມວ່າບໍ່ຕ້ອງຈັບ).
            // ຍ້ອນວ່າ `idx` ແມ່ນຈຸດເລີ່ມຕົ້ນຂອງເຂດທີ່ມີຊີວິດຊີວາ, ເຂດທີ່ມີຊີວິດຢູ່ຕອນນີ້ແມ່ນ `data[alive]` ອີກເທື່ອ ໜຶ່ງ, ເຊິ່ງເປັນການຟື້ນຟູການບຸກລຸກທັງ ໝົດ.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // ໄດ້ຮັບການດັດສະນີຕໍ່ໄປຈາກທາງຫລັງ.
        //
        // ການຫຼຸດລົງຂອງ `alive.end` ໂດຍ 1 ຮັກສາຄວາມແຕກຕ່າງຂອງ `alive`.
        // ເຖິງຢ່າງໃດກໍ່ຕາມ, ຍ້ອນການປ່ຽນແປງດັ່ງກ່າວ, ໃນໄລຍະເວລາສັ້ນໆ, ເຂດທີ່ມີຊີວິດຢູ່ບໍ່ແມ່ນ `data[alive]` ອີກຕໍ່ໄປ, ແຕ່ເປັນ `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // ອ່ານອົງປະກອບຈາກອາເລ.
            // ຄວາມປອດໄພ: `idx` ແມ່ນດັດສະນີ ໜຶ່ງ ໃນອະດີດຂອງພາກພື້ນ "alive" ຂອງ
            // ຂບວນ.ການອ່ານສ່ວນປະກອບນີ້ ໝາຍ ຄວາມວ່າ `data[idx]` ຖືວ່າເປັນຕາຍແລ້ວໃນຕອນນີ້ (ໝາຍ ຄວາມວ່າບໍ່ຕ້ອງຈັບ).
            // ຍ້ອນວ່າ `idx` ແມ່ນຈຸດສິ້ນສຸດຂອງເຂດທີ່ມີຊີວິດຊີວາ, ເຂດທີ່ມີຊີວິດຢູ່ຕອນນີ້ແມ່ນ `data[alive]` ອີກເທື່ອ ໜຶ່ງ, ເຊິ່ງໄດ້ຟື້ນຟູການບຸກລຸກທັງ ໝົດ.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // ຄວາມປອດໄພ: ສິ່ງນີ້ປອດໄພ: `as_mut_slice` ກັບຄືນມາສ່ວນແບ່ງທີ່ແນ່ນອນ
        // ຂອງອົງປະກອບທີ່ຍັງບໍ່ທັນໄດ້ຖືກຍ້າຍອອກທັນແລະທີ່ຍັງຈະຖືກຍົກເລີກ.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // ຈະບໍ່ມີການໄຫຼວຽນເນື່ອງມາຈາກການບຸກລຸກຂອງ `ມີຊີວິດຢູ່ .start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// The iterator ຈິງລາຍງານຄວາມຍາວທີ່ຖືກຕ້ອງ.
// ຈໍານວນຂອງອົງປະກອບ "alive" (ທີ່ຍັງຈະໃຫ້ຜົນຜະລິດຢູ່) ແມ່ນຄວາມຍາວຂອງລະດັບ `alive`.
// ຊ່ວງນີ້ decremented ໃນຄວາມຍາວໃນບໍ່ວ່າຈະ `next` ຫຼື `next_back`.
// ມັນໄດ້ຖືກຫຼຸດລົງສະເຫມີໂດຍ 1 ໃນວິທີການເຫຼົ່ານັ້ນ, ແຕ່ວ່າພຽງແຕ່ຖ້າ `Some(_)` ຖືກສົ່ງຄືນ.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // ໝາຍ ເຫດ, ພວກເຮົາບໍ່ ຈຳ ເປັນຕ້ອງກົງກັບລະດັບຊີວິດທີ່ແນ່ນອນ, ສະນັ້ນພວກເຮົາພຽງແຕ່ສາມາດໂຄນກັບຊົດເຊີຍ 0 ໂດຍບໍ່ ຄຳ ນຶງເຖິງວ່າ `self` ຢູ່ໃສ.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // ໂຄນອົງປະກອບທີ່ມີຊີວິດທັງ ໝົດ.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // ຂຽນ clone ເຂົ້າໄປໃນຂບວນໃຫມ່, ຫຼັງຈາກນັ້ນປັບປຸງຊ່ວງທີ່ມີຊີວິດຢູ່ຂອງມັນ.
            // ຖ້າ cloning panics, ພວກເຮົາຈະຖິ້ມລາຍການທີ່ຜ່ານມາຢ່າງຖືກຕ້ອງ.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ພຽງແຕ່ພິມອົງປະກອບທີ່ບໍ່ໄດ້ຮັບຜົນຜະລິດເທື່ອ: ພວກເຮົາບໍ່ສາມາດເຂົ້າເຖິງອົງປະກອບທີ່ໃຫ້ຜົນຜະລິດອີກຕໍ່ໄປ.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}