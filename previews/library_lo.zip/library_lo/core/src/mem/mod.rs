//! ໜ້າ ທີ່ພື້ນຖານ ສຳ ລັບການຈັດການກັບຄວາມ ຈຳ.
//!
//! ໂມດູນນີ້ມີຫນ້າທີ່ສໍາລັບການສອບຖາມຂະຫນາດແລະຄວາມສອດຄ່ອງຂອງປະເພດ, ເລີ່ມຕົ້ນແລະການຈັດການຫນ່ວຍຄວາມຈໍາ.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// ໃຊ້ເວລາເປັນເຈົ້າຂອງແລະ "forgets" ກ່ຽວກັບຄຸນຄ່າ **ໂດຍບໍ່ມີການແລ່ນ destructor ຂອງຕົນ**.
///
/// ຊັບພະຍາກອນໃດຫນຶ່ງມູນຄ່າການຄຸ້ມຄອງ, ເຊັ່ນ: ຄວາມຊົງຈໍາ heap ຫຼືຈັບເອກະສານ, ຈະ linger ຕະຫຼອດໄປໃນສະຖານະ unreachable.ຢ່າງໃດກໍຕາມ, ມັນບໍ່ໄດ້ຮັບປະກັນວ່າຕົວຊີ້ຫນ່ວຍຄວາມຈໍານີ້ຈະຍັງຄົງຖືກຕ້ອງ.
///
/// * ຖ້າຫາກວ່າທ່ານຕ້ອງການທີ່ຈະຮົ່ວຄວາມຊົງຈໍາ, ເບິ່ງ [`Box::leak`].
/// * ຖ້າຫາກວ່າທ່ານຕ້ອງການທີ່ຈະໄດ້ຮັບການຊີ້ຖຸດິບເພື່ອຄວາມຊົງຈໍາໃຫ້ເບິ່ງ [`Box::into_raw`].
/// * ຖ້າຫາກວ່າທ່ານຕ້ອງການທີ່ຈະຈັດວາງກໍາລັງຂອງຄ່າຢ່າງຖືກຕ້ອງ, ແລ່ນ destructor ຂອງຕົນ, ເບິ່ງ [`mem::drop`].
///
/// # Safety
///
/// `forget` ບໍ່ໄດ້ຫມາຍວ່າເປັນ `unsafe`, ເນື່ອງຈາກວ່າ Rust ຂອງຮັບປະກັນຄວາມປອດໄພບໍ່ມີການຮັບປະກັນວ່າ destructors ຈະດໍາເນີນການສະເຫມີໄດ້.
/// ສໍາລັບຕົວຢ່າງ, ໂຄງການສາມາດສ້າງວົງຈອນກະສານອ້າງອີງການນໍາໃຊ້ [`Rc`][rc], ຫຼືໂທຫາ [`process::exit`][exit] ການການທ່ອງທ່ຽວໂດຍບໍ່ມີການແລ່ນ destructors.
/// ດັ່ງນັ້ນ, ອະນຸຍາດໃຫ້ `mem::forget` ຈາກລະຫັດຄວາມປອດໄພບໍ່ໄດ້ມີພື້ນຖານມີການປ່ຽນແປງຮັບປະກັນຄວາມປອດໄພ Rust ຂອງ.
///
/// ທີ່ເວົ້າວ່າ, ປ່ອຍຊັບພະຍາກອນເຊັ່ນ: ສັດລ້ຽງຫຼືວັດຖຸ I/O ແມ່ນປົກກະຕິແລ້ວບໍ່ພຶງປະສົງ.
/// ຄວາມຕ້ອງການມາເຖິງໃນກໍລະນີການນໍາໃຊ້ບາງສ່ວນພິເສດສໍາລັບການ FFI ຫຼືລະຫັດທີ່ບໍ່ປອດໄພ, ແຕ່ເຖິງແມ່ນວ່າຫຼັງຈາກນັ້ນ, [`ManuallyDrop`] ເປັນທີ່ພໍໃຈຕາມປົກກະຕິ.
///
/// ເນື່ອງຈາກວ່າລືມຄ່າອະນຸຍາດໃຫ້, ທຸກລະຫັດ `unsafe` ທ່ານຂຽນຕ້ອງອະນຸຍາດໃຫ້ສໍາລັບຄວາມເປັນໄປໄດ້ນີ້.ທ່ານບໍ່ສາມາດກັບຄືນຄ່າແລະຄາດຫວັງວ່າແປໄດ້ທຸໄດ້ຈໍາເປັນຈະດໍາເນີນການ destructor ມູນຄ່າຂອງ.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// ການນໍາໃຊ້ຄວາມປອດໄພ canonical ຂອງ `mem::forget` ແມ່ນເພື່ອຫລີກເວັ້ນ destructor ເປັນຂອງມູນຄ່າການປະຕິບັດໂດຍ `Drop` trait.ສໍາລັບຕົວຢ່າງ, ນີ້ຈະຮົ່ວເປັນ `File`, ie
/// ປັບປຸງພື້ນທີ່ປະຕິບັດໂດຍການປ່ຽນແປງແຕ່ບໍ່ເຄີຍໃກ້ໄດ້ຊັບພະຍາກອນລະບົບທີ່ຕິດພັນ:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// ນີ້ແມ່ນເປັນປະໂຫຍດໃນເວລາທີ່ຄວາມເປັນເຈົ້າຂອງຂອງຊັບພະຍາກອນຕິດພັນຖືກຍ້າຍໃນເມື່ອກ່ອນກັບລະຫັດພາຍນອກຂອງ Rust, ສໍາລັບການຍົກຕົວຢ່າງໂດຍ transmitting ໄດ້ອະທິບາຍໄຟເປັນວັດຖຸດິບເພື່ອ code C.
///
/// # ຄວາມສໍາພັນກັບ `ManuallyDrop`
///
/// ໃນຂະນະທີ່ `mem::forget` ຍັງສາມາດຖືກ ນຳ ໃຊ້ເພື່ອໂອນ ກຳ ມະສິດ *ຄວາມ ຈຳ*, ການເຮັດເຊັ່ນນັ້ນແມ່ນມີຄວາມຜິດພາດ.
/// [`ManuallyDrop`] ຄວນໄດ້ຮັບການນໍາມາໃຊ້ແທນ.ພິຈາລະນາ, ສໍາລັບການຍົກຕົວຢ່າງ, ລະຫັດນີ້:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // ການກໍ່ສ້າງ `String` ໃຊ້ເນື້ອໃນຂອງ `v` ໄດ້
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // ຮົ່ວ `v` ເພາະວ່າສັດລ້ຽງຂອງຕົນແມ່ນບໍລິຫານໃນປັດຈຸບັນໂດຍ `s`
/// mem::forget(v);  // ERROR, v ບໍ່ຖືກຕ້ອງແລະຕ້ອງບໍ່ໄດ້ຮັບການສົ່ງຜ່ານໄປຍັງຫນ້າທີ່ເປັນ
/// assert_eq!(s, "Az");
/// // `s` ຖືກຖີ້ມລົງໂດຍປະລິຍາຍແລະຄວາມຊົງຈໍາຂອງຕົນ deallocated.
/// ```
///
/// ມັນມີສອງບັນຫາກັບຕົວຢ່າງຂ້າງເທິງ:
///
/// * ຖ້າຫາກວ່າລະຫັດເພີ່ມເຕີມໄດ້ຮັບການເພີ່ມລະຫວ່າງການກໍ່ສ້າງຂອງ `String` ແລະ invocation ຂອງ `mem::forget()`, ເປັນ panic ໄດ້ພາຍໃນມັນຈະເຮັດໃຫ້ເກີດຄວາມຟຣີ double ເພາະວ່າສັດລ້ຽງດຽວກັນແມ່ນດໍາເນີນການໂດຍທັງ `v` ແລະ `s`.
/// * ຫຼັງຈາກການໂທຫາ `v.as_mut_ptr()` ແລະສົ່ງເປັນເຈົ້າຂອງຂໍ້ມູນທີ່ຈະ `s` ການ, ມູນຄ່າ `v` ບໍ່ຖືກຕ້ອງ.
/// ເຖິງແມ່ນວ່າໃນເວລາທີ່ຄ່າຍ້າຍພຽງແຕ່ເພື່ອ `mem::forget` (ຊຶ່ງຈະບໍ່ກວດກາມັນ), ບາງປະເພດມີຄວາມຕ້ອງການທີ່ເຂັ້ມງວດກ່ຽວກັບຄ່າຂອງເຂົາເຈົ້າທີ່ເຮັດໃຫ້ເຂົາເຈົ້າບໍ່ຖືກຕ້ອງໃນເວລາທີ່ຫ້ອຍຫຼືເປັນເຈົ້າຂອງທີ່ບໍ່ມີຕໍ່ໄປອີກແລ້ວ.
/// ການ ນຳ ໃຊ້ຄຸນຄ່າທີ່ບໍ່ຖືກຕ້ອງໃນວິທີການໃດ ໜຶ່ງ, ລວມທັງການຖ່າຍທອດຫຼືສົ່ງຄືນພວກເຂົາຈາກ ໜ້າ ທີ່, ປະກອບເປັນພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດແລະອາດຈະ ທຳ ລາຍການສົມມຸດຖານຂອງຜູ້ຂຽນ.
///
/// ປ່ຽນເປັນ `ManuallyDrop` ຫລີກລ້ຽງບັນຫາທັງສອງຢ່າງ:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // ກ່ອນທີ່ພວກເຮົາ disassemble `v` ເຂົ້າໄປໃນພາກສ່ວນເປັນວັດຖຸດິບຂອງຕົນ, ເຮັດໃຫ້ແນ່ໃຈວ່າມັນບໍ່ໄດ້ຮັບການຫຼຸດລົງ!
/////
/// let mut v = ManuallyDrop::new(v);
/// // ດຽວນີ້ຖີ້ມ `v`.ການດໍາເນີນງານເຫຼົ່ານີ້ບໍ່ສາມາດ panic, ສະນັ້ນບໍ່ມີບໍ່ສາມາດຈະເປັນການຮົ່ວໄຫລ.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // ສຸດທ້າຍກໍ່ສ້າງ `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ຖືກຖີ້ມລົງໂດຍປະລິຍາຍແລະຄວາມຊົງຈໍາຂອງຕົນ deallocated.
/// ```
///
/// `ManuallyDrop` ປ້ອງກັນຢ່າງປອດໄພແບບບໍ່ເສຍຄ່າສອງເພາະວ່າພວກເຮົາປິດການ ທຳ ລາຍ `v` ກ່ອນທີ່ຈະເຮັດຫຍັງອີກ.
/// `mem::forget()` ບໍ່ອະນຸຍາດສິ່ງນີ້ເພາະມັນກິນຂໍ້ໂຕ້ແຍ້ງຂອງມັນ, ບັງຄັບໃຫ້ພວກເຮົາໂທຫາມັນພຽງແຕ່ຫລັງຈາກສະກັດສິ່ງທີ່ພວກເຮົາຕ້ອງການຈາກ `v`.
/// ເຖິງແມ່ນວ່າ panic ໄດ້ຖືກແນະ ນຳ ລະຫວ່າງການກໍ່ສ້າງ `ManuallyDrop` ແລະການກໍ່ສ້າງສາຍໄຟ (ເຊິ່ງມັນບໍ່ສາມາດເກີດຂື້ນໃນລະຫັດດັ່ງທີ່ສະແດງໄວ້), ມັນຈະສົ່ງຜົນໃຫ້ເກີດການຮົ່ວໄຫຼແລະບໍ່ແມ່ນແບບບໍ່ເສຍຄ່າສອງ.
/// ເວົ້າອີກຢ່າງ ໜຶ່ງ, `ManuallyDrop` ເຮັດຜິດພາດໃນດ້ານຂ້າງຂອງການຮົ່ວໄຫຼແທນທີ່ຈະເຮັດຜິດທາງຂ້າງຂອງ (ສອງ-) ຫຼຸດລົງ.
///
/// ພ້ອມກັນນັ້ນ, `ManuallyDrop` ກໍ່ປ້ອງກັນບໍ່ໃຫ້ພວກເຮົາຕ້ອງມີ "touch" `v` ຫຼັງຈາກໂອນ ກຳ ມະສິດໃຫ້ `s`-ຂັ້ນຕອນສຸດທ້າຍຂອງການໂຕ້ຕອບກັບ `v` ເພື່ອ ກຳ ຈັດມັນໂດຍບໍ່ຕ້ອງແລ່ນຜູ້ ທຳ ລາຍມັນຖືກຫລີກລ້ຽງທັງ ໝົດ.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// ເຊັ່ນດຽວກັນກັບ [`forget`], ແຕ່ຍັງຍອມຮັບຄ່າທີ່ບໍ່ຖືກຕ້ອງ.
///
/// ຟັງຊັນນີ້ແມ່ນພຽງແຕ່ເງົາທີ່ມີຈຸດປະສົງທີ່ຈະເອົາອອກເມື່ອຄຸນລັກສະນະ `unsized_locals` ມີສະຖຽນລະພາບ.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// ສົ່ງຄືນຂະ ໜາດ ຂອງຊະນິດເປັນໄບ.
///
/// ພິເສດ, ນີ້ແມ່ນການຊົດເຊີຍໃນໄບຕ໌ລະຫວ່າງບັນດາອົງປະກອບທີ່ສືບທອດໃນອາເລກັບປະເພດສິນຄ້ານັ້ນລວມທັງການຈັດລຽນແຖວ.
///
/// ດັ່ງນັ້ນ, ສຳ ລັບ `T` ປະເພດໃດແລະຄວາມຍາວ `n`, `[T; n]` ມີຂະ ໜາດ ຂອງ `n * size_of::<T>()`.
///
/// ໂດຍທົ່ວໄປ, ຂະ ໜາດ ຂອງຊະນິດໃດ ໜຶ່ງ ບໍ່ ໝັ້ນ ຄົງໃນການລວບລວມຂໍ້ມູນ, ແຕ່ວ່າປະເພດສະເພາະເຊັ່ນ: ແບບປະຖົມປະຖານ.
///
/// ຕາຕະລາງຕໍ່ໄປນີ້ໃຫ້ຂະ ໜາດ ສຳ ລັບຕົ້ນສະບັບ.
///
/// ປະເພດ |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |.
///
/// ຍິ່ງໄປກວ່ານັ້ນ, `usize` ແລະ `isize` ມີຂະ ໜາດ ດຽວກັນ.
///
/// ປະເພດ `*const T`, `&T`, `Box<T>`, `Option<&T>`, ແລະ `Option<Box<T>>` ລ້ວນແຕ່ມີຂະ ໜາດ ດຽວກັນ.
/// ຖ້າ `T` ແມ່ນຂະ ໜາດ, ທຸກປະເພດເຫຼົ່ານັ້ນມີຂະ ໜາດ ເທົ່າກັບ `usize`.
///
/// ຄວາມສັບສົນຂອງຕົວຊີ້ບໍ່ປ່ຽນແປງຂະ ໜາດ ຂອງມັນ.ດັ່ງນັ້ນ, `&T` ແລະ `&mut T` ມີຂະ ໜາດ ດຽວກັນ.
/// ດຽວກັນນີ້ ສຳ ລັບ `*const T` ແລະ `* mut T`.
///
/// # ຂະ ໜາດ ຂອງສິນຄ້າ `#[repr(C)]`
///
/// ຕົວແທນ `C` ສຳ ລັບລາຍການມີຮູບແບບທີ່ຖືກ ກຳ ນົດ.
/// ດ້ວຍຮູບແບບດັ່ງກ່າວ, ຂະ ໜາດ ຂອງສິນຄ້າກໍ່ມີຄວາມ ໝັ້ນ ຄົງຕາບໃດທີ່ທຸກຂົງເຂດມີຂະ ໜາດ ທີ່ ໝັ້ນ ຄົງ.
///
/// ## ຂະ ໜາດ ຂອງໂຄງສ້າງ
///
/// ສຳ ລັບ `structs`, ຂະ ໜາດ ຖືກ ກຳ ນົດໂດຍວິທີຄິດໄລ່ຕໍ່ໄປນີ້.
///
/// ສຳ ລັບແຕ່ລະຂົງເຂດໃນໂຄງສ້າງຕາມ ຄຳ ສັ່ງປະກາດ:
///
/// 1. ເພີ່ມຂະ ໜາດ ຂອງສະ ໜາມ.
/// 2. ຮວບຮວມຂະ ໜາດ ປະຈຸບັນໄປຫາຫລາຍໆບ່ອນທີ່ໃກ້ທີ່ສຸດຂອງ [alignment] ຂອງສະ ໜາມ ຕໍ່ໄປ.
///
/// ສຸດທ້າຍ, ຮອບຂະ ໜາດ ຂອງໂຄງສ້າງໄປຫາຫລາຍ [alignment] ທີ່ໃກ້ທີ່ສຸດຂອງມັນ.
/// ຄວາມສອດຄ່ອງຂອງໂຄງສ້າງແມ່ນປົກກະຕິແລ້ວແມ່ນການຈັດລຽນທີ່ໃຫຍ່ທີ່ສຸດຂອງທຸກໆຂົງເຂດຂອງມັນ;ນີ້ສາມາດປ່ຽນແປງໄດ້ກັບການໃຊ້ `repr(align(N))`.
///
/// ບໍ່ຄືກັບ `C`, ໂຄງສ້າງທີ່ມີຂະ ໜາດ ສູນບໍ່ມີຮູບມົນຂະ ໜາດ ໜຶ່ງ ໄບ.
///
/// ## ຂະ ໜາດ ຂອງ Enums
///
/// ຫໍສະມຸດທີ່ບໍ່ມີຂໍ້ມູນອື່ນນອກ ເໜືອ ຈາກການ ຈຳ ແນກມີຂະ ໜາດ ເທົ່າກັບ C enums ໃນເວທີທີ່ພວກເຂົາຖືກລວບລວມ.
///
/// ## ຂະ ໜາດ ຂອງສະຫະພັນ
///
/// ຂະ ໜາດ ຂອງສະຫະພັນແມ່ນຂະ ໜາດ ຂອງສະ ໜາມ ທີ່ໃຫຍ່ທີ່ສຸດ.
///
/// ບໍ່ຄືກັບ `C`, ສະຫະພັນທີ່ມີຂະ ໜາດ ສູນບໍ່ມີຂະ ໜາດ ເທົ່າ ໜຶ່ງ ໄບ.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // primitives ບາງ
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // arrays ບາງ
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Pointer ຂະຫນາດເທົ່າທຽມກັນ
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// ການໃຊ້ `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // ຂະຫນາດຂອງພາກສະຫນາມຄັ້ງທໍາອິດແມ່ນ 1, ສະນັ້ນຕື່ມ 1 ຂະຫນາດໄດ້.ຂະ ໜາດ ແມ່ນ 1.
/// // ຄວາມສອດຄ່ອງຂອງພາກສະຫນາມຄັ້ງທີສອງແມ່ນ 2, ສະນັ້ນຕື່ມ 1 ຂະຫນາດສໍາລັບການ padding.ຂະຫນາດເປັນ 2.
/// // ຂະຫນາດຂອງພາກສະຫນາມຄັ້ງທີສອງແມ່ນ 2, ສະນັ້ນເພີ່ມ 2 ຂະຫນາດໄດ້.ຂະ ໜາດ ແມ່ນ 4.
/// // ຄວາມສອດຄ່ອງຂອງພາກສະຫນາມທີສາມແມ່ນ 1, ສະນັ້ນເພີ່ມ 0 ຂະຫນາດສໍາລັບການ padding.ຂະ ໜາດ ແມ່ນ 4.
/// // ຂະຫນາດຂອງພາກສະຫນາມທີສາມແມ່ນ 1, ສະນັ້ນຕື່ມ 1 ຂະຫນາດໄດ້.ຂະຫນາດເປັນ 5.
/// // ທ້າຍສຸດນີ້, ຄວາມສອດຄ່ອງຂອງ struct ໄດ້ເປັນ 2 (ເພາະວ່າການຈັດຕໍາແຫນ່ງທີ່ໃຫຍ່ທີ່ສຸດໃນຈໍານວນຂົງເຂດຂອງຕົນແມ່ນ 2), ດັ່ງນັ້ນເພີ່ມ 1 ຂະຫນາດສໍາລັບການ padding.
/// // ຂະຫນາດແມ່ນ 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // struct tuple ປະຕິບັດຕາມກົດລະບຽບດຽວກັນ.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // ໃຫ້ສັງເກດວ່າ reordering ຂົງເຂດສາມາດຫຼຸດຂະຫນາດໄດ້.
/// // ພວກເຮົາສາມາດເອົາທັງສອງ bytes padding ໂດຍການວາງ `third` ກ່ອນ `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Union ຂະຫນາດແມ່ນຂະຫນາດຂອງພາກສະຫນາມທີ່ໃຫຍ່ທີ່ສຸດໄດ້.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// ສົ່ງຄືນຂະ ໜາດ ຂອງຄ່າ-ກັບຄ່າໃນໄບ.
///
/// ນີ້ແມ່ນປົກກະຕິຄືກັນກັບ `size_of::<T>()`.
/// ເຖິງຢ່າງໃດກໍ່ຕາມ, ເມື່ອ `T`*ມີ* ບໍ່ມີຂະ ໜາດ ທີ່ຮູ້ກັນຕາມກົດ ໝາຍ, ຕົວຢ່າງ, ຊິ້ນສ່ວນ [`[T]`][slice] ຫຼື [trait object], ຫຼັງຈາກນັ້ນ `size_of_val` ສາມາດໃຊ້ເພື່ອໃຫ້ມີຂະ ໜາດ ທີ່ຮູ້ຈັກກັນແບບເຄື່ອນໄຫວ.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // ຄວາມປອດໄພ: `val` ແມ່ນເອກະສານອ້າງອີງ, ສະນັ້ນມັນແມ່ນຕົວຊີ້ວັດຖຸດິບທີ່ຖືກຕ້ອງ
    unsafe { intrinsics::size_of_val(val) }
}

/// ສົ່ງຄືນຂະ ໜາດ ຂອງຄ່າ-ກັບຄ່າໃນໄບ.
///
/// ນີ້ມັກຈະຄືກັນກັບ `size_of::<T>()`.ເຖິງຢ່າງໃດກໍ່ຕາມ, ເມື່ອ `T`*ມີ* ບໍ່ມີຂະ ໜາດ ທີ່ຮູ້ກັນຕາມກົດ ໝາຍ, ຕົວຢ່າງ, ຊິ້ນ [`[T]`][slice] ຫຼື [trait object], ຫຼັງຈາກນັ້ນ `size_of_val_raw` ສາມາດໃຊ້ເພື່ອໃຫ້ມີຂະ ໜາດ ທີ່ຮູ້ຈັກກັນແບບເຄື່ອນໄຫວ.
///
/// # Safety
///
/// ຟັງຊັນນີ້ຈະປອດໄພໃນການໂທຫາຖ້າສະພາບດັ່ງຕໍ່ໄປນີ້:
///
/// - ຖ້າ `T` ແມ່ນ `Sized`, ການເຮັດວຽກນີ້ຈະປອດໄພໃນການໂທຫາ.
/// - ຖ້າຫາງ unsized ຂອງ `T` ແມ່ນ:
///     - a [slice], ຫຼັງຈາກນັ້ນຄວາມຍາວຂອງຫາງສ່ວນຕົວຕ້ອງເປັນຕົວເລກເລີ່ມຕົ້ນ, ແລະຂະ ໜາດ ຂອງ *ຄ່າທັງ ໝົດ*(ຄວາມຍາວຂອງຫາງແບບເຄື່ອນໄຫວ + ຄຳ ນຳ ໜ້າ ຂະ ໜາດ ຕາມສະຖິຕິ) ຕ້ອງ ເໝາະ ສົມກັບ `isize`.
///     - a [trait object], ຫຼັງຈາກນັ້ນສ່ວນ vtable ຂອງຕົວຊີ້ຕ້ອງຊີ້ໃຫ້ເຫັນ vtable ທີ່ຖືກຕ້ອງທີ່ໄດ້ມາຈາກການບີບບັງຄັບທີ່ບໍ່ແນ່ນອນ, ແລະຂະ ໜາດ ຂອງ *ຄ່າທັງ ໝົດ*(ຄວາມຍາວຂອງຫາງແບບເຄື່ອນໄຫວ + ຄຳ ນຳ ໜ້າ ຂະ ໜາດ ທາງສະຖິຕິ) ຕ້ອງ ເໝາະ ສົມກັບ `isize`.
///
///     - (unstable) [extern type], ຫຼັງຈາກນັ້ນຟັງຊັນນີ້ຈະປອດໄພໃນການໂທ, ແຕ່ panic ອາດຈະສົ່ງຄືນຄ່າທີ່ບໍ່ຖືກຕ້ອງ, ຍ້ອນວ່າຮູບແບບຂອງປະເພດພາຍນອກບໍ່ຮູ້.
///     ນີ້ແມ່ນພຶດຕິ ກຳ ດຽວກັນກັບ [`size_of_val`] ໃນການອ້າງອີງເຖິງປະເພດທີ່ມີຫາງປະເພດພາຍນອກ.
///     - ຖ້າບໍ່ດັ່ງນັ້ນ, ມັນບໍ່ໄດ້ຖືກອະນຸຍາດໃຫ້ເອີ້ນຟັງຊັນນີ້.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງໃຫ້ຕົວຊີ້ວັດຖຸດິບທີ່ຖືກຕ້ອງ
    unsafe { intrinsics::size_of_val(val) }
}

/// ກັບຄືນ [ABI] ທີ່ຕ້ອງການຄວາມສອດຄ່ອງຂັ້ນຕ່ ຳ ຂອງປະເພດໃດ ໜຶ່ງ.
///
/// ທຸກໆການອ້າງອີງເຖິງມູນຄ່າຂອງຊະນິດ `T` ຕ້ອງເປັນຕົວເລກຂອງຫລາຍໆຕົວເລກນີ້.
///
/// ນີ້ແມ່ນຄວາມສອດຄ່ອງທີ່ໃຊ້ໃນຂົງເຂດໂຄງສ້າງ.ມັນອາດຈະນ້ອຍກ່ວາການຈັດຕໍາ ແໜ່ງ ທີ່ມັກ.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// ກັບຄືນ [ABI] ທີ່ຕ້ອງການຄວາມສອດຄ່ອງຂັ້ນຕ່ ຳ ຂອງປະເພດຂອງມູນຄ່າທີ່ `val` ຊີ້ໄປ.
///
/// ທຸກໆການອ້າງອີງເຖິງມູນຄ່າຂອງຊະນິດ `T` ຕ້ອງເປັນຕົວເລກຂອງຫລາຍໆຕົວເລກນີ້.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // ຄວາມປອດໄພ: val ແມ່ນເອກະສານອ້າງອີງ, ສະນັ້ນມັນແມ່ນຕົວຊີ້ວັດຖຸດິບທີ່ຖືກຕ້ອງ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// ກັບຄືນ [ABI] ທີ່ຕ້ອງການຄວາມສອດຄ່ອງຂັ້ນຕ່ ຳ ຂອງປະເພດໃດ ໜຶ່ງ.
///
/// ທຸກໆການອ້າງອີງເຖິງມູນຄ່າຂອງຊະນິດ `T` ຕ້ອງເປັນຕົວເລກຂອງຫລາຍໆຕົວເລກນີ້.
///
/// ນີ້ແມ່ນຄວາມສອດຄ່ອງທີ່ໃຊ້ໃນຂົງເຂດໂຄງສ້າງ.ມັນອາດຈະນ້ອຍກ່ວາການຈັດຕໍາ ແໜ່ງ ທີ່ມັກ.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// ກັບຄືນ [ABI] ທີ່ຕ້ອງການຄວາມສອດຄ່ອງຂັ້ນຕ່ ຳ ຂອງປະເພດຂອງມູນຄ່າທີ່ `val` ຊີ້ໄປ.
///
/// ທຸກໆການອ້າງອີງເຖິງມູນຄ່າຂອງຊະນິດ `T` ຕ້ອງເປັນຕົວເລກຂອງຫລາຍໆຕົວເລກນີ້.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // ຄວາມປອດໄພ: val ແມ່ນເອກະສານອ້າງອີງ, ສະນັ້ນມັນແມ່ນຕົວຊີ້ວັດຖຸດິບທີ່ຖືກຕ້ອງ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// ກັບຄືນ [ABI] ທີ່ຕ້ອງການຄວາມສອດຄ່ອງຂັ້ນຕ່ ຳ ຂອງປະເພດຂອງມູນຄ່າທີ່ `val` ຊີ້ໄປ.
///
/// ທຸກໆການອ້າງອີງເຖິງມູນຄ່າຂອງຊະນິດ `T` ຕ້ອງເປັນຕົວເລກຂອງຫລາຍໆຕົວເລກນີ້.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// ຟັງຊັນນີ້ຈະປອດໄພໃນການໂທຫາຖ້າສະພາບດັ່ງຕໍ່ໄປນີ້:
///
/// - ຖ້າ `T` ແມ່ນ `Sized`, ການເຮັດວຽກນີ້ຈະປອດໄພໃນການໂທຫາ.
/// - ຖ້າຫາງ unsized ຂອງ `T` ແມ່ນ:
///     - a [slice], ຫຼັງຈາກນັ້ນຄວາມຍາວຂອງຫາງສ່ວນຕົວຕ້ອງເປັນຕົວເລກເລີ່ມຕົ້ນ, ແລະຂະ ໜາດ ຂອງ *ຄ່າທັງ ໝົດ*(ຄວາມຍາວຂອງຫາງແບບເຄື່ອນໄຫວ + ຄຳ ນຳ ໜ້າ ຂະ ໜາດ ຕາມສະຖິຕິ) ຕ້ອງ ເໝາະ ສົມກັບ `isize`.
///     - a [trait object], ຫຼັງຈາກນັ້ນສ່ວນ vtable ຂອງຕົວຊີ້ຕ້ອງຊີ້ໃຫ້ເຫັນ vtable ທີ່ຖືກຕ້ອງທີ່ໄດ້ມາຈາກການບີບບັງຄັບທີ່ບໍ່ແນ່ນອນ, ແລະຂະ ໜາດ ຂອງ *ຄ່າທັງ ໝົດ*(ຄວາມຍາວຂອງຫາງແບບເຄື່ອນໄຫວ + ຄຳ ນຳ ໜ້າ ຂະ ໜາດ ທາງສະຖິຕິ) ຕ້ອງ ເໝາະ ສົມກັບ `isize`.
///
///     - (unstable) [extern type], ຫຼັງຈາກນັ້ນຟັງຊັນນີ້ຈະປອດໄພໃນການໂທ, ແຕ່ panic ອາດຈະສົ່ງຄືນຄ່າທີ່ບໍ່ຖືກຕ້ອງ, ຍ້ອນວ່າຮູບແບບຂອງປະເພດພາຍນອກບໍ່ຮູ້.
///     ນີ້ແມ່ນພຶດຕິ ກຳ ດຽວກັນກັບ [`align_of_val`] ໃນການອ້າງອີງເຖິງປະເພດທີ່ມີຫາງປະເພດພາຍນອກ.
///     - ຖ້າບໍ່ດັ່ງນັ້ນ, ມັນບໍ່ໄດ້ຖືກອະນຸຍາດໃຫ້ເອີ້ນຟັງຊັນນີ້.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງໃຫ້ຕົວຊີ້ວັດຖຸດິບທີ່ຖືກຕ້ອງ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// ສົ່ງຄືນ `true` ຖ້າຫຼຸດລົງຄ່າຂອງ `T` ປະເພດ.
///
/// ນີ້ແມ່ນ ຄຳ ແນະ ນຳ ກ່ຽວກັບການເພີ່ມປະສິດທິພາບ, ແລະອາດຈະຖືກຈັດຕັ້ງປະຕິບັດແບບອະນຸລັກ:
/// ມັນອາດຈະສົ່ງຄືນ `true` ສຳ ລັບປະເພດທີ່ບໍ່ ຈຳ ເປັນຕ້ອງລຸດລົງ.
/// ໃນຖານະເປັນດັ່ງກ່າວສະເຫມີກັບຄືນ `true` ຈະເປັນການປະຕິບັດທີ່ຖືກຕ້ອງຂອງຫນ້າທີ່ນີ້.ເຖິງຢ່າງໃດກໍ່ຕາມຖ້າວ່າ ໜ້າ ທີ່ນີ້ຈະສົ່ງຄືນ `false` ຢ່າງແທ້ຈິງ, ທ່ານສາມາດແນ່ນອນວ່າການຫຼຸດລົງ `T` ບໍ່ມີຜົນຂ້າງຄຽງ.
///
/// ການຈັດຕັ້ງປະຕິບັດລະດັບຕໍ່າຂອງສິ່ງຕ່າງໆເຊັ່ນ: ການລວບລວມຂໍ້ມູນ, ເຊິ່ງ ຈຳ ເປັນຕ້ອງລຸດຂໍ້ມູນຂອງພວກເຂົາດ້ວຍຕົນເອງ, ຄວນ ນຳ ໃຊ້ ໜ້າ ທີ່ນີ້ເພື່ອຫລີກລ້ຽງບໍ່ໄດ້ໂດຍບໍ່ ຈຳ ເປັນທີ່ພະຍາຍາມລຸດເນື້ອຫາທັງ ໝົດ ຂອງພວກເຂົາເມື່ອພວກເຂົາຖືກ ທຳ ລາຍ
///
/// ນີ້ອາດຈະບໍ່ສ້າງຄວາມແຕກຕ່າງໃນການສ້າງລຸ້ນ (ບ່ອນທີ່ວົງຈອນທີ່ບໍ່ມີຜົນຂ້າງຄຽງສາມາດກວດພົບແລະ ກຳ ຈັດໄດ້ງ່າຍ), ແຕ່ມັກຈະເປັນການຊະນະໃຫຍ່ ສຳ ລັບການສ້າງ debug.
///
/// ໃຫ້ສັງເກດວ່າ [`drop_in_place`] ປະຕິບັດການກວດສອບນີ້ແລ້ວ, ສະນັ້ນຖ້າພາລະຂອງທ່ານສາມາດຫຼຸດລົງເປັນ ຈຳ ນວນນ້ອຍໆຂອງການໂທ [`drop_in_place`], ການ ນຳ ໃຊ້ນີ້ແມ່ນບໍ່ ຈຳ ເປັນ.
/// ໂດຍສະເພາະໃຫ້ສັງເກດວ່າທ່ານສາມາດ [`drop_in_place`] ໄດ້ເປັນຕ່ອນໆ, ແລະນັ້ນຈະເຮັດການກວດສອບຄວາມຕ້ອງການດຽວ ສຳ ລັບຄ່າທັງ ໝົດ.
///
/// ປະເພດເຊັ່ນ Vec ດັ່ງນັ້ນພຽງແຕ່ `drop_in_place(&mut self[..])` ໂດຍບໍ່ຕ້ອງໃຊ້ `needs_drop` ຢ່າງຈະແຈ້ງ.
/// ປະເພດເຊັ່ນ [`HashMap`], ໃນທາງກົງກັນຂ້າມ, ຕ້ອງລຸດຄ່າ ໜຶ່ງ ຄັ້ງຕໍ່ຄັ້ງແລະຄວນໃຊ້ API ນີ້.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// ນີ້ແມ່ນຕົວຢ່າງຂອງວິທີການເກັບ ກຳ ຂໍ້ມູນທີ່ສາມາດ ນຳ ໃຊ້ `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ລົງຂໍ້ມູນ
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// ສົ່ງຄືນຄ່າຂອງປະເພດ `T` ທີ່ເປັນຕົວແທນໂດຍຮູບແບບ byte-all-zero.
///
/// ນີ້ ໝາຍ ຄວາມວ່າ, ຕົວຢ່າງແຜ່ນທີ່ຢູ່ໃນ `(u8, u16)` ບໍ່ ຈຳ ເປັນຕ້ອງສູນ.
///
/// ບໍ່ມີການຮັບປະກັນວ່າຮູບແບບ byte-zero ທັງ ໝົດ ສະແດງເຖິງມູນຄ່າທີ່ຖືກຕ້ອງຂອງ `T` ບາງປະເພດ.
/// ຕົວຢ່າງ, ຮູບແບບ byte ທັງ ໝົດ ສູນບໍ່ແມ່ນຄ່າທີ່ຖືກຕ້ອງ ສຳ ລັບປະເພດອ້າງອີງ (`&T`, `&mut T`) ແລະຕົວຊີ້ວັດ ໜ້າ ທີ່.
/// ການ ນຳ ໃຊ້ `zeroed` ໃສ່ປະເພດດັ່ງກ່າວເຮັດໃຫ້ [undefined behavior][ub] ທັນທີເພາະ [the Rust compiler assumes][inv] ວ່າມີມູນຄ່າທີ່ຖືກຕ້ອງໃນຕົວແປທີ່ມັນຖືວ່າເລີ່ມຕົ້ນ.
///
///
/// ນີ້ມີຜົນດຽວກັນກັບ [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// ມັນເປັນປະໂຫຍດ ສຳ ລັບ FFI ບາງຄັ້ງ, ແຕ່ໂດຍທົ່ວໄປແລ້ວຄວນຫລີກລ້ຽງ.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ທີ່ຖືກຕ້ອງຂອງ ໜ້າ ທີ່ນີ້: ການເລີ່ມຕົ້ນເລກເຕັມກັບເລກສູນ.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// * ການ ນຳ ໃຊ້ທີ່ບໍ່ຖືກຕ້ອງຂອງ ໜ້າ ທີ່ນີ້: ການເລີ່ມຕົ້ນການອ້າງອີງກັບເລກສູນ.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // ພຶດຕິກໍາການລະບຸ!
/// let _y: fn() = unsafe { mem::zeroed() }; // ແລະອີກເທື່ອຫນຶ່ງ!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າມູນຄ່າທັງ ໝົດ ສູນແມ່ນຖືກຕ້ອງ ສຳ ລັບ `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// ການກວດສອບ-ການເລີ່ມຕົ້ນຄວາມຊົງ ຈຳ ທຳ ມະດາຂອງ Bypasses Rust ໂດຍ ທຳ ທ່າວ່າຈະຜະລິດຄ່າຂອງ `T` ຊະນິດ, ໃນຂະນະທີ່ບໍ່ເຮັດຫຍັງເລີຍ.
///
/// **ໜ້າ ທີ່ນີ້ຖືກປະຕິເສດ.** ໃຊ້ [`MaybeUninit<T>`] ແທນ.
///
/// ເຫດຜົນ ສຳ ລັບການເສື່ອມລາຄາແມ່ນ ໜ້າ ທີ່ໂດຍພື້ນຖານແລ້ວບໍ່ສາມາດ ນຳ ໃຊ້ໄດ້ຢ່າງຖືກຕ້ອງ: ມັນມີຜົນຄືກັບ [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// ດັ່ງທີ່ [`assume_init` documentation][assume_init] ອະທິບາຍ, [the Rust compiler assumes][inv] ທີ່ຄຸນຄ່າແມ່ນຖືກເລີ່ມຕົ້ນຢ່າງຖືກຕ້ອງ.
/// ຍ້ອນເຫດນັ້ນ, ການເອີ້ນຕົວຢ່າງເຊັ່ນ
/// `mem::uninitialized::<bool>()` ເຮັດໃຫ້ເກີດພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດທັນທີ ສຳ ລັບການສົ່ງຄືນ `bool` ທີ່ແນ່ນອນບໍ່ວ່າຈະເປັນ `true` ຫຼື `false`.
/// ຮ້າຍແຮງກວ່າເກົ່າ, ຄວາມຊົງຈໍາທີ່ບໍ່ມີການປ່ຽນແປງຢ່າງແທ້ຈິງຄືກັບສິ່ງທີ່ໄດ້ກັບມາຢູ່ທີ່ນີ້ແມ່ນພິເສດທີ່ຜູ້ຂຽນຮູ້ວ່າມັນບໍ່ມີຄ່າຄົງທີ່.
/// ນີ້ເຮັດໃຫ້ມັນມີພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດໃຫ້ມີຂໍ້ມູນແບບບໍ່ມີຕົວຕົນໃນຕົວປ່ຽນແປງເຖິງແມ່ນວ່າຕົວແປນັ້ນຈະມີປະເພດເລກເຕັມ.
/// (ສັງເກດເຫັນວ່າກົດລະບຽບຂອງປະມານຈໍານວນເຕັມ uninitiated ຍັງບໍ່ໄດ້ເຮັດສຸດທ້າຍເທື່ອ, ແຕ່ຈົນກ່ວາພວກເຂົາເຈົ້າແມ່ນ, ມັນເປັນການສົມຄວນທີ່ຈະຫຼີກເວັ້ນການໃຫ້ເຂົາເຈົ້າ.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າມູນຄ່າທີ່ໃຊ້ເປັນຫົວ ໜ່ວຍ ແມ່ນຖືກຕ້ອງ ສຳ ລັບ `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// ແລກປ່ຽນຄ່າຢູ່ສອງສະຖານທີ່ທີ່ສາມາດປ່ຽນແປງໄດ້, ໂດຍບໍ່ມີການຕັດສິນອັນໃດອັນ ໜຶ່ງ.
///
/// * ຖ້າທ່ານຕ້ອງການແລກປ່ຽນກັບຄ່າເລີ່ມຕົ້ນຫລືຄ່າ dummy, ເບິ່ງ [`take`].
/// * ຖ້າທ່ານຕ້ອງການແລກປ່ຽນກັບມູນຄ່າທີ່ຜ່ານໄປ, ສົ່ງຄືນມູນຄ່າເກົ່າ, ເບິ່ງ [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // ຄວາມປອດໄພ: ຕົວຊີ້ວັດຖຸດິບໄດ້ຖືກສ້າງຂື້ນມາຈາກເອກະສານອ້າງອີງທີ່ສາມາດປ່ຽນແປງໄດ້ຢ່າງປອດໄພທີ່ເພິ່ງພໍໃຈທຸກຢ່າງ
    // ຂໍ້ ຈຳ ກັດໃນ `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// ແທນ `dest` ດ້ວຍຄ່າເລີ່ມຕົ້ນຂອງ `T`, ກັບຄືນຄ່າ `dest` ກ່ອນ.
///
/// * ຖ້າທ່ານຕ້ອງການປ່ຽນຄ່າຂອງສອງຕົວແປ, ເບິ່ງ [`swap`].
/// * ຖ້າທ່ານຕ້ອງການປ່ຽນແທນດ້ວຍຄ່າທີ່ຜ່ານໄປແທນທີ່ຈະເປັນຄ່າເລີ່ມຕົ້ນ, ເບິ່ງ [`replace`].
///
/// # Examples
///
/// ຕົວຢ່າງທີ່ງ່າຍດາຍ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` ອະນຸຍາດໃຫ້ມີສິດເປັນເຈົ້າຂອງສະ ໜາມ ໂຄງສ້າງໂດຍການປ່ຽນແທນມັນດ້ວຍມູນຄ່າ "empty".
/// ຖ້າບໍ່ມີ `take` ທ່ານສາມາດເຂົ້າໄປໃນບັນຫາຕ່າງໆເຊັ່ນ:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// ໃຫ້ສັງເກດວ່າ `T` ບໍ່ຈໍາເປັນຕ້ອງປະຕິບັດ [`Clone`], ດັ່ງນັ້ນມັນກໍ່ບໍ່ສາມາດເຮັດໃຫ້ເກີດການກົດແລະປັບ `self.buf` ໄດ້.
/// ແຕ່ `take` ສາມາດຖືກ ນຳ ໃຊ້ເພື່ອ ທຳ ລາຍມູນຄ່າເດີມຂອງ `self.buf` ຈາກ `self`, ອະນຸຍາດໃຫ້ສົ່ງຄືນ:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// ຍ້າຍ `src` ເຂົ້າໄປໃນ `dest` ທີ່ອ້າງອີງ, ກັບຄືນຄ່າ `dest` ທີ່ຜ່ານມາ.
///
/// ຄ່າທັງສອງບໍ່ໄດ້ຫຼຸດລົງ.
///
/// * ຖ້າທ່ານຕ້ອງການປ່ຽນຄ່າຂອງສອງຕົວແປ, ເບິ່ງ [`swap`].
/// * ຖ້າທ່ານຕ້ອງການປ່ຽນແທນດ້ວຍຄ່າເລີ່ມຕົ້ນ, ເບິ່ງ [`take`].
///
/// # Examples
///
/// ຕົວຢ່າງທີ່ງ່າຍດາຍ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` ອະນຸຍາດໃຫ້ ນຳ ໃຊ້ພາກສະ ໜາມ ໂຄງສ້າງໂດຍການປ່ຽນແທນມັນດ້ວຍຄ່າອື່ນ.
/// ຖ້າບໍ່ມີ `replace` ທ່ານສາມາດເຂົ້າໄປໃນບັນຫາຕ່າງໆເຊັ່ນ:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// ໃຫ້ສັງເກດວ່າ `T` ບໍ່ຈໍາເປັນຕ້ອງປະຕິບັດ [`Clone`], ດັ່ງນັ້ນພວກເຮົາກໍ່ບໍ່ສາມາດ clone `self.buf[i]` ເພື່ອຫຼີກເວັ້ນການຍ້າຍ.
/// ແຕ່ `replace` ສາມາດຖືກ ນຳ ໃຊ້ເພື່ອ ທຳ ລາຍມູນຄ່າເດີມໃນດັດຊະນີນັ້ນຈາກ `self`, ອະນຸຍາດໃຫ້ສົ່ງຄືນ:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // ຄວາມປອດໄພ: ພວກເຮົາອ່ານຈາກ `dest` ແຕ່ຂຽນ `src` ໂດຍກົງໃສ່ມັນຫຼັງຈາກນັ້ນ,
    // ເຊັ່ນວ່າຄ່າເກົ່າບໍ່ໄດ້ຊ້ ຳ.
    // ບໍ່ມີຫຍັງຖືກລຸດລົງແລະບໍ່ມີຫຍັງຢູ່ທີ່ນີ້ສາມາດ panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// ການຖິ້ມຄ່າຂອງມູນຄ່າ.
///
/// ນີ້ເຮັດໄດ້ໂດຍການໂທຫາການປະຕິບັດການໂຕ້ຖຽງຂອງ [`Drop`][drop].
///
/// ສິ່ງນີ້ບໍ່ມີປະສິດຕິຜົນຫຍັງ ສຳ ລັບປະເພດທີ່ ນຳ ໃຊ້ `Copy`, ຕົວຢ່າງ
/// integers.
/// ຄ່າດັ່ງກ່າວຖືກຄັດລອກແລະ _then_ ຖືກຍ້າຍເຂົ້າໄປໃນ ໜ້າ ທີ່, ສະນັ້ນມູນຄ່າຍັງຄົງຢູ່ຫລັງຈາກການເອີ້ນຟັງຊັນນີ້.
///
///
/// ໜ້າ ທີ່ນີ້ບໍ່ແມ່ນວິເສດ;ມັນໄດ້ຖືກກໍານົດຕົວຫນັງສືເປັນ
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// ເນື່ອງຈາກວ່າ `_x` ຖືກຍ້າຍເຂົ້າໃນ ໜ້າ ທີ່, ມັນຈະຖືກລຸດລົງໂດຍອັດຕະໂນມັດກ່ອນທີ່ ໜ້າ ທີ່ຈະກັບມາ.
///
/// [drop]: Drop
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // ຢ່າງຊັດເຈນລົງ vector
/// ```
///
/// ເນື່ອງຈາກວ່າ [`RefCell`] ບັງຄັບໃຊ້ກົດລະບຽບການກູ້ຢືມໃນເວລາແລ່ນ, `drop` ສາມາດປ່ອຍເງິນກູ້ຢືມ [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // ຍົກເລີກການກູ້ຢືມເງິນທີ່ບໍ່ແນ່ນອນກ່ຽວກັບການຊ່ອງນີ້
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// ຕົວປະສົມແລະປະເພດອື່ນໆທີ່ປະຕິບັດ [`Copy`] ແມ່ນບໍ່ໄດ້ຮັບຜົນກະທົບຈາກ `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // ສໍາເນົາຂອງ `x` ຖືກຍ້າຍແລະຫຼຸດລົງ
/// drop(y); // ສຳ ເນົາຂອງ `y` ຖືກຍ້າຍແລະລຸດລົງ
///
/// println!("x: {}, y: {}", x, y.0); // ຍັງສາມາດໃຊ້ໄດ້
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// ຕີຄວາມ ໝາຍ `src` ທີ່ມີ `&U` ປະເພດ, ແລະຫຼັງຈາກນັ້ນອ່ານ `src` ໂດຍບໍ່ຕ້ອງຍ້າຍຄ່າທີ່ມີຢູ່.
///
/// ຟັງຊັນນີ້ບໍ່ແນ່ນອນວ່າຕົວຊີ້ `src` ຈະຖືກຕ້ອງ ສຳ ລັບ [`size_of::<U>`][size_of] bytes ໂດຍການສົ່ງ `&T` ໄປ `&U` ແລະຫຼັງຈາກນັ້ນອ່ານ `&U` (ຍົກເວັ້ນວ່ານີ້ເຮັດໃນແບບທີ່ຖືກຕ້ອງເຖິງແມ່ນວ່າ `&U` ເຮັດໃຫ້ຄວາມຕ້ອງການຄວາມສອດຄ່ອງເຂັ້ມງວດກວ່າ `&T`).
/// ມັນຍັງຈະສ້າງ ສຳ ເນົາຂອງມູນຄ່າທີ່ມີຢູ່ແທນທີ່ຈະຍ້າຍອອກຈາກ `src`.
///
/// ມັນບໍ່ແມ່ນຄວາມຜິດພາດໃນການລວບລວມເວລາຖ້າ `T` ແລະ `U` ມີຂະ ໜາດ ທີ່ແຕກຕ່າງກັນ, ແຕ່ມັນໄດ້ຖືກຊຸກຍູ້ຢ່າງຍິ່ງໃຫ້ພຽງແຕ່ຮຽກຮ້ອງຟັງຊັ່ນນີ້ທີ່ `T` ແລະ `U` ມີຂະ ໜາດ ດຽວກັນ.ຟັງຊັນນີ້ກະຕຸ້ນ [undefined behavior][ub] ຖ້າ `U` ໃຫຍ່ກວ່າ `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // ສໍາເນົາຂໍ້ມູນຈາກ 'foo_array' ແລະປິ່ນປົວພະຍາດມັນເປັນ 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // ປັບປຸງແກ້ໄຂຄັດລອກຂໍ້ມູນ
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // ເນື້ອໃນຂອງ 'foo_array' ບໍ່ຄວນມີການປ່ຽນແປງ
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // ຖ້າ U ມີຄວາມຕ້ອງການຄວາມສອດຄ່ອງສູງກວ່າ, src ອາດຈະບໍ່ ເໝາະ ສົມ.
    if align_of::<U>() > align_of::<T>() {
        // ຄວາມປອດໄພ: `src` ແມ່ນເອກະສານອ້າງອີງທີ່ຖືກຮັບປະກັນວ່າຖືກຕ້ອງ ສຳ ລັບການອ່ານ.
        // ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າການສົ່ງສັນຍານຕົວຈິງແມ່ນປອດໄພ.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // ຄວາມປອດໄພ: `src` ແມ່ນເອກະສານອ້າງອີງທີ່ຖືກຮັບປະກັນວ່າຖືກຕ້ອງ ສຳ ລັບການອ່ານ.
        // ພວກເຮົາພຽງແຕ່ກວດເບິ່ງວ່າ `src as *const U` ຖືກຈັດຮຽງຢ່າງຖືກຕ້ອງ.
        // ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າການສົ່ງສັນຍານຕົວຈິງແມ່ນປອດໄພ.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// ປະເພດ Opaque ທີ່ເປັນຕົວແທນໃຫ້ແກ່ການ ຈຳ ແນກຂອງ enum.
///
/// ເບິ່ງ ໜ້າ ທີ່ [`discriminant`] ໃນໂມດູນນີ້ ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. ການຈັດຕັ້ງປະຕິບັດ trait ເຫຼົ່ານີ້ບໍ່ສາມາດເອົາມາຈາກພວກເຮົາໄດ້ເພາະວ່າພວກເຮົາບໍ່ຕ້ອງການຂອບເຂດໃດໆກ່ຽວກັບ T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// ສົ່ງຄືນມູນຄ່າທີ່ເປັນເອກະລັກໃນການລະບຸຕົວແປຂອງ enum ໃນ `v`.
///
/// ຖ້າ `T` ບໍ່ແມ່ນ enum, ການໂທຫາ ໜ້າ ທີ່ນີ້ຈະບໍ່ສົ່ງຜົນໃຫ້ມີພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ, ແຕ່ວ່າມູນຄ່າການກັບມາແມ່ນບໍ່ໄດ້ລະບຸ.
///
///
/// # Stability
///
/// ການ ຈຳ ແນກຄວາມແຕກຕ່າງຂອງ enum ອາດຈະປ່ຽນຖ້າ ຄຳ ນິຍາມຂອງ enum ປ່ຽນແປງ.
/// ການ ຈຳ ແນກຄວາມແຕກຕ່າງບາງຢ່າງຈະບໍ່ປ່ຽນແປງລະຫວ່າງການລວບລວມຂໍ້ມູນກັບຜູ້ລວບລວມຂໍ້ມູນດຽວກັນ.
///
/// # Examples
///
/// ສິ່ງນີ້ສາມາດຖືກ ນຳ ໃຊ້ເພື່ອປຽບທຽບຫໍສະມຸດທີ່ປະຕິບັດຂໍ້ມູນ, ໃນຂະນະທີ່ບໍ່ສົນໃຈຂໍ້ມູນຕົວຈິງ:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// ສົ່ງ ຈຳ ນວນຕົວແປໃນ `T` ປະເພດ enum.
///
/// ຖ້າ `T` ບໍ່ແມ່ນ enum, ການໂທຫາ ໜ້າ ທີ່ນີ້ຈະບໍ່ສົ່ງຜົນໃຫ້ມີພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ, ແຕ່ວ່າມູນຄ່າການກັບມາແມ່ນບໍ່ໄດ້ລະບຸ.
/// ເທົ່າທຽມກັນ, ຖ້າ `T` ແມ່ນ enum ທີ່ມີຕົວປ່ຽນແປງຫຼາຍກ່ວາ `usize::MAX` ມູນຄ່າການກັບຄືນແມ່ນບໍ່ໄດ້ລະບຸ.
/// ຕົວແປທີ່ບໍ່ມີຜູ້ຢູ່ອາໄສຈະຖືກນັບ.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}