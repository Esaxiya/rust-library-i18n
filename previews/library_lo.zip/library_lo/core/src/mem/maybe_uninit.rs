use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// ປະເພດ wrapper ກັບໂຄງການກໍ່ສ້າງກໍລະນີ uninitiated ຂອງ `T`.
///
/// # ຂຽນອັກສອນຫຍໍ້ invariant
///
/// ການລວບລວມ, ໂດຍທົ່ວໄປ, ອະນຸມານວ່າເປັນຕົວແປຖືກກຽມໃຊ້ຢ່າງຖືກຕ້ອງຕາມຄວາມຕ້ອງການຂອງປະເພດຂອງຕົວປ່ຽນແປງຂອງໄດ້.ສໍາລັບຕົວຢ່າງ, ຕົວແປປະເພດອ້າງອິງຕ້ອງໄດ້ຮັບການສອດຄ່ອງແລະບໍ່ແມ່ນ NULL.
/// ນີ້ເປັນຄົງທີ່ຕ້ອງ *ສະເຫມີ* ໄດ້ຮັບການແຕ່ງຕັ້ງ, ແມ້ແຕ່ຢູ່ໃນລະຫັດທີ່ບໍ່ປອດໄພ.
/// ຍ້ອນແນວນັ້ນເປັນ, ສູນ, ເລີ່ມຕົ້ນຂອງຕົວປ່ຽນແປງຂອງຊະນິດອ້າງອິງເປັນສາເຫດຂອງ instantaneous [undefined behavior][ub], ເລື່ອງບໍ່ວ່າຈະເປັນກະສານອ້າງອີງທີ່ເຄີຍຄຸ້ນເຄີຍກັບຄວາມຊົງຈໍາການເຂົ້າເຖິງທີ່ບໍ່ມີ:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // ພຶດຕິກໍາ undefined!⚠️
/// // ລະຫັດທຽບເທົ່າກັບ `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // ພຶດຕິກໍາ undefined!⚠️
/// ```
///
/// ນີ້ແມ່ນຂູດຮີດໂດຍ compiler ໄດ້ດີທີ່ສຸດຕ່າງໆ, ເຊັ່ນ: ການກວດສອບ eliding ການດໍາເນີນງານທີ່ໃຊ້ເວລາແລະປະສິດທິພາບຮູບແບບ `enum`.
///
/// ເຊັ່ນດຽວກັນ, ຄວາມຊົງຈໍາ uninitialized ທັງຫມົດອາດຈະມີເນື້ອໃນໃດກໍ່ຕາມ, ໃນຂະນະທີ່ເປັນ `bool` ສະເຫມີຈະຕ້ອງ `true` ຫຼື `false`.ເພາະສະນັ້ນ, ການສ້າງເປັນ uninitialized `bool` ແມ່ນພຶດຕິກໍາ undefined:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // ພຶດຕິກໍາ undefined!⚠️
/// // ລະຫັດທຽບເທົ່າກັບ `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // ພຶດຕິກໍາ undefined!⚠️
/// ```
///
/// ຍິ່ງໄປກວ່ານັ້ນ, ຄວາມຊົງຈໍາ uninitiated ເປັນພິເສດໃນການທີ່ຈະບໍ່ມີຄ່າຄົງທີ່ ("fixed" ຫມາຍ "it won't change without being written to").ການອ່ານໄບຕ໌ທີ່ບໍ່ໄດ້ຮັບການດັດແປງຫຼາຍຄັ້ງສາມາດໃຫ້ຜົນໄດ້ຮັບທີ່ແຕກຕ່າງກັນ.
/// ນີ້ເຮັດໃຫ້ມັນ undefined ພຶດຕິກໍາທີ່ຈະມີຂໍ້ມູນ uninitiated ໃນຕົວແປເຖິງແມ່ນວ່າຕົວແປທີ່ມີຊະນິດຈໍານວນເຕັມທີ່ຖ້າບໍ່ດັ່ງນັ້ນສາມາດຖືທຸກຮູບແບບ bit * * ການສ້ອມແຊມ:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // ພຶດຕິກໍາ undefined!⚠️
/// // ລະຫັດທຽບເທົ່າກັບ `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // ພຶດຕິກໍາ undefined!⚠️
/// ```
/// (ສັງເກດເຫັນວ່າກົດລະບຽບຂອງປະມານຈໍານວນເຕັມ uninitiated ຍັງບໍ່ໄດ້ເຮັດສຸດທ້າຍເທື່ອ, ແຕ່ຈົນກ່ວາພວກເຂົາເຈົ້າແມ່ນ, ມັນເປັນການສົມຄວນທີ່ຈະຫຼີກເວັ້ນການໃຫ້ເຂົາເຈົ້າ.)
///
/// ສຸດເທິງຂອງທີ່, ຈື່ໄດ້ວ່າເກືອບທຸກຊະນິດມີຄາຄົງເພີ່ມເຕີມນອກເຫນືອວ່າພຽງແຕ່ພິຈາລະນາເລີ່ມຕົ້ນໃນລະດັບປະເພດໄດ້.
/// ສໍາລັບຕົວຢ່າງ, ເປັນ `1`, ກຽມ [`Vec<T>`] ແມ່ນພິຈາລະນາກຽມ (ພາຍໃຕ້ການປະຕິບັດໃນປະຈຸບັນ; ນີ້ບໍ່ໄດ້ປະກອບໃຫ້ການຄໍ້າປະກັນຄວາມຫມັ້ນຄົງກ) ເນື່ອງຈາກວ່າຄວາມຕ້ອງການພຽງແຕ່ compiler ໄດ້ຮູ້ກ່ຽວກັບມັນແມ່ນວ່າຊີ້ຂໍ້ມູນຈະຕ້ອງບໍ່ແມ່ນ null.
/// ການສ້າງດັ່ງກ່າວເປັນ `Vec<T>` ບໍ່ສາເຫດ *ທັນທີທັນໃດພຶດຕິກໍາ undefined*, ແຕ່ຈະເຮັດໃຫ້ເກີດພຶດຕິກໍາ undefined ກັບການດໍາເນີນງານຄວາມປອດໄພທີ່ສຸດ (ລວມທັງຫຼຸດລົງມັນ).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` ໃຫ້ບໍລິການເພື່ອໃຫ້ສາມາດລະຫັດທີ່ບໍ່ປອດໄພທີ່ຈະຈັດການກັບຂໍ້ມູນ uninitiated.
/// ມັນເປັນສັນຍານໃຫ້ກັບຜູ້ປະກອບຂໍ້ມູນທີ່ຊີ້ບອກວ່າຂໍ້ມູນຢູ່ທີ່ນີ້ອາດຈະ *ບໍ່* ໄດ້ເລີ່ມຕົ້ນ:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // ສ້າງອ້າງອິງ uninitialized ຢ່າງຊັດເຈນ.
/// // The compiler ຮູ້ວ່າຂໍ້ມູນພາຍໃນ `MaybeUninit<T>` ອາດຈະບໍ່ຖືກຕ້ອງ, ແລະເພາະສະນັ້ນນີ້ບໍ່ແມ່ນ UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // ກໍານົດໃຫ້ເປັນມູນຄ່າທີ່ຖືກຕ້ອງ.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // ສານສະກັດຈາກຂໍ້ມູນກຽມ-ນີ້ຈະຖືກອະນຸຍາດໃຫ້ພຽງແຕ່ຫຼັງຈາກ * ເຫມາະສົມເລີ່ມຕົ້ນ `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// ການລວບລວມຫຼັງຈາກນັ້ນຮູ້ບໍ່ເຮັດໃຫ້ສົມມຸດຕິຖານທີ່ບໍ່ຖືກຕ້ອງຫຼືດີທີ່ສຸດກ່ຽວກັບລະຫັດນີ້.
///
/// ທ່ານສາມາດຄິດວ່າຂອງ `MaybeUninit<T>` ເປັນ bit ເຊັ່ນ `Option<T>` ແຕ່ໂດຍບໍ່ມີການໃດໆຂອງການຕິດຕາມການດໍາເນີນງານທີ່ໃຊ້ເວລາແລະໂດຍບໍ່ມີການໃດໆຂອງການກວດສອບຄວາມປອດໄພ.
///
/// ## out-pointers
///
/// ທ່ານສາມາດນໍາໃຊ້ `MaybeUninit<T>` ເພື່ອປະຕິບັດ "out-pointers": ແທນທີ່ຈະກັບຄືນຂໍ້ມູນຈາກຫນ້າທີ່ເປັນ, ຜ່ານມັນເປັນຕົວຊີ້ໄປບາງຫນ່ວຍຄວາມຈໍາ (uninitialized) ເພື່ອເຮັດໃຫ້ຜົນໄດ້ຮັບເຂົ້າໄປໃນ.
/// ນີ້ສາມາດເປັນປະໂຫຍດໃນເວລາທີ່ມັນເປັນສິ່ງສໍາຄັນສໍາລັບການແປໄດ້ທຸໃນການຄວບຄຸມວິທີການຫນ່ວຍຄວາມຈໍາທີ່ຜົນໄດ້ຮັບແມ່ນຖືກເກັບໄວ້ໃນໄດ້ຮັບການຈັດສັນ, ແລະທ່ານຕ້ອງການເພື່ອຫຼີກເວັ້ນການເຄື່ອນໄຫວທີ່ບໍ່ຈໍາເປັນ.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ບໍ່ປະຖິ້ມເນື້ອໃນເກົ່າ, ເຊິ່ງເປັນສິ່ງທີ່ ສຳ ຄັນ.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // ໃນປັດຈຸບັນພວກເຮົາຮູ້ວ່າ `v` ຖືກກຽມໃຊ້!ນີ້ຍັງເຮັດໃຫ້ແນ່ໃຈວ່າ vector ຮັບຫຼຸດລົງຢ່າງຖືກຕ້ອງ.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## ການເລີ່ມຕົ້ນ Array Element ໂດຍອົງປະກອບ
///
/// `MaybeUninit<T>` ສາມາດຖືກນໍາໃຊ້ເພື່ອເລີ່ມຕົ້ນການເປັນຂບວນຂະຫນາດໃຫຍ່ອົງປະກອບໂດຍອົງປະກອບ:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // ສ້າງ array uninitiated ຂອງ `MaybeUninit`.
///     // `assume_init` ແມ່ນປອດໄພເພາະວ່າປະເພດທີ່ພວກເຮົາອ້າງວ່າໄດ້ເລີ່ມຕົ້ນໃນທີ່ນີ້ແມ່ນຊໍ່ຂອງ `MaybeUninit`, ເຊິ່ງບໍ່ ຈຳ ເປັນຕ້ອງມີການເລີ່ມຕົ້ນ.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // ວາງ `MaybeUninit` ບໍ່ມີຫຍັງ.
///     // ດັ່ງນັ້ນຈຶ່ງໃຊ້ກໍາຫນົດຊີ້ດິບແທນທີ່ຈະເປັນ `ptr::write` ບໍ່ກໍ່ໃຫ້ເກີດມູນຄ່າ uninitiated ອາຍຸການທີ່ຈະຖືກຍົກເລີກ.
/////
///     // ນອກຈາກນີ້ຖ້າຫາກວ່າມີ panic ໃນໄລຍະວົງນີ້, ພວກເຮົາມີຫນ່ວຍຄວາມຈໍາຮົ່ວ, ແຕ່ບໍ່ມີບັນຫາຄວາມປອດໄພຂອງຄວາມຊົງຈໍາ.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // ທຸກສິ່ງທຸກຢ່າງແມ່ນກຽມ.
///     // Transmute array ໃນປະເພດເລີ່ມຕົ້ນ.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// ນອກນັ້ນທ່ານຍັງສາມາດເຮັດວຽກຮ່ວມກັບອາເລເລີ່ມຕົ້ນບາງສ່ວນ, ຊຶ່ງສາມາດໄດ້ຮັບການພົບເຫັນຢູ່ໃນ datastructures ໃນລະດັບຕ່ໍາ.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // ສ້າງ array uninitiated ຂອງ `MaybeUninit`.
/// // `assume_init` ແມ່ນປອດໄພເພາະວ່າປະເພດທີ່ພວກເຮົາອ້າງວ່າໄດ້ເລີ່ມຕົ້ນໃນທີ່ນີ້ແມ່ນຊໍ່ຂອງ `MaybeUninit`, ເຊິ່ງບໍ່ ຈຳ ເປັນຕ້ອງມີການເລີ່ມຕົ້ນ.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // ນັບ ຈຳ ນວນອົງປະກອບທີ່ພວກເຮົາໄດ້ມອບ ໝາຍ ໃຫ້.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // ສໍາລັບແຕ່ລະລາຍການໃນ array, ລົງຖ້າຫາກວ່າພວກເຮົາຈັດສັນມັນ.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## ເລີ່ມຕົ້ນເປັນ struct ພາກສະຫນາມໂດຍພາກສະຫນາມ
///
/// ທ່ານສາມາດນໍາໃຊ້ `MaybeUninit<T>`, ແລະມະຫາພາກ [`std::ptr::addr_of_mut`], ສາມາດເລີ່ມຕົ້ນພາກສະຫນາມ struct ໂດຍພາກສະຫນາມ:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // ການເລີ່ມຕົ້ນພາກສະຫນາມ `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // ການເລີ່ມຕົ້ນພາກສະຫນາມ `list` ຖ້າຫາກວ່າມີ panic ທີ່ນີ້, ຫຼັງຈາກນັ້ນໄດ້ `String` ໃນ `name` ການຮົ່ວໄຫລພາກສະຫນາມ.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // ທຸກຂົງເຂດທີ່ກໍາລັງເລີ່ມຕົ້ນ, ສະນັ້ນຈຶ່ງເອີ້ນ `assume_init` ເພື່ອໃຫ້ໄດ້ຮັບເປັນເລີ່ມຕົ້ນ Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ການຮັບປະກັນທີ່ຈະມີຂະຫນາດດຽວກັນ, ຄວາມສອດຄ່ອງ, ແລະ ABI ເປັນ `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// ຢ່າງໃດກໍຕາມຈື່ໄດ້ວ່າເປັນຊະນິດ *ມີ* a `MaybeUninit<T>` ບໍ່ແມ່ນຈໍາເປັນທີ່ຮູບລັກດຽວກັນ;Rust ບໍ່ໄດ້ຢູ່ໃນການຮັບປະກັນໂດຍທົ່ວໄປເຫັນວ່າທົ່ງຂອງ `Foo<T>` ໄດ້ມີຄໍາສັ່ງເຊັ່ນດຽວກັນກັບເປັນ `Foo<U>` ເຖິງແມ່ນວ່າຖ້າຫາກວ່າ `T` ແລະ `U` ມີຂະຫນາດດຽວກັນແລະສອດຄ່ອງ.
///
/// ຍິ່ງໄປກວ່ານັ້ນເນື່ອງຈາກວ່າມູນຄ່ານ້ອຍໆແມ່ນຖືກຕ້ອງ ສຳ ລັບ `MaybeUninit<T>` ຕົວແຕ່ງບໍ່ສາມາດ ນຳ ໃຊ້ non-zero/niche-filling ທີ່ດີທີ່ສຸດ, ເຊິ່ງອາດຈະເຮັດໃຫ້ມີຂະ ໜາດ ທີ່ໃຫຍ່ກວ່າ:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// ຖ້າ `T` ແມ່ນ FFI, ຄວາມປອດໄພ, ຫຼັງຈາກນັ້ນສະນັ້ນເປັນ `MaybeUninit<T>`.
///
/// ໃນຂະນະທີ່ `MaybeUninit` ແມ່ນ `#[repr(transparent)]` (ທີ່ຊີ້ບອກວ່າຈະຮັບປະກັນຄືກັນຂະຫນາດ, ຄວາມສອດຄ່ອງ, ແລະ ABI ເປັນ `T`), ນີ້ບໍ່ *ບໍ່* ການປ່ຽນແປງໃດໆຂອງ caveats ທີ່ຜ່ານມາ.
/// `Option<T>` ແລະ `Option<MaybeUninit<T>>` ຍັງອາດຈະມີຂະຫນາດທີ່ແຕກຕ່າງກັນ, ແລະປະເພດທີ່ມີພາກສະຫນາມຂອງປະເພດ `T` ອາດເກີດຂຶ້ນໄດ້ວາງອອກ (ແລະຂະຫນາດ) ທີ່ແຕກຕ່າງກ່ວາຖ້າຫາກວ່າພາກສະຫນາມທີ່ໄດ້ `MaybeUninit<T>`.
/// `MaybeUninit` ເປັນປະເພດສະຫະພາບ, ແລະ `#[repr(transparent)]` ກ່ຽວກັບສະຫະພັນແມ່ນ unstable (ເບິ່ງ [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// ໃນໄລຍະທີ່ໃຊ້ເວລາ, ການຮັບປະກັນຄືກັນອ້ອຍຕ້ອຍຂອງ `#[repr(transparent)]` ກ່ຽວກັບສະຫະພັນອາດເຮັດໃຫ້ເກີດ, ແລະ `MaybeUninit` ອາດຫຼືອາດຈະບໍ່ຍັງຄົງ `#[repr(transparent)]`.
/// ທີ່ເວົ້າວ່າ, `MaybeUninit<T>` ຈະ * ຮັບປະກັນສະ ເໝີ ວ່າມັນມີຂະ ໜາດ, ຄວາມສອດຄ່ອງແລະ ABI ຄືກັນກັບ `T`;ມັນເປັນພຽງແຕ່ວ່າວິທີການປະຕິບັດແນວ `MaybeUninit` ທີ່ຮັບປະກັນອາດເຮັດໃຫ້ເກີດ.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// ລາຍການ Lang ດັ່ງນັ້ນພວກເຮົາສາມາດຫໍ່ປະເພດອື່ນໆໃນມັນ.ນີ້ແມ່ນເປັນປະໂຫຍດສໍາລັບການຜະລິດ.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // ບໍ່ໄດ້ໂທຫາ `T::clone()`, ພວກເຮົາບໍ່ສາມາດຮູ້ຖ້າຫາກວ່າພວກເຮົາກໍາລັງກຽມໃຊ້ວຽກພຽງພໍສໍາລັບທີ່.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// ສ້າງ `MaybeUninit<T>` ໃຫມ່ກຽມກັບມູນຄ່າດັ່ງກ່າວ.
    /// ມັນປອດໄພທີ່ຈະໂທຫາ [`assume_init`] ກ່ຽວກັບຄ່າຕອບແທນຂອງການທໍາງານນີ້.
    ///
    /// ໃຫ້ສັງເກດວ່າການຫຼຸດລົງເປັນ `MaybeUninit<T>` ຈະບໍ່ໂທຫາ `code ເລື່ອນ T` ຂອງ.
    /// ມັນເປັນຄວາມຮັບຜິດຊອບຂອງທ່ານເພື່ອເຮັດໃຫ້ແນ່ໃຈວ່າ `T` ຮັບຫຼຸດລົງຖ້າຫາກວ່າມັນໄດ້ຮັບການເລີ່ມຕົ້ນ.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// ສ້າງ `MaybeUninit<T>` ໃຫມ່ໃນສະຖານະ uninitiated.
    ///
    /// ໃຫ້ສັງເກດວ່າການຫຼຸດລົງເປັນ `MaybeUninit<T>` ຈະບໍ່ໂທຫາ `code ເລື່ອນ T` ຂອງ.
    /// ມັນເປັນຄວາມຮັບຜິດຊອບຂອງທ່ານເພື່ອເຮັດໃຫ້ແນ່ໃຈວ່າ `T` ຮັບຫຼຸດລົງຖ້າຫາກວ່າມັນໄດ້ຮັບການເລີ່ມຕົ້ນ.
    ///
    /// ເບິ່ງ [type-level documentation][MaybeUninit] ສໍາລັບຕົວຢ່າງຈໍານວນຫນຶ່ງ.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// ສ້າງ array ໃຫມ່ຂອງຊະນິດ `MaybeUninit<T>`, ໃນສະຖານະ uninitiated.
    ///
    /// Note: ໃນສະບັບພາສາ future Rust ວິທີການນີ້ອາດຈະກາຍເປັນທີ່ບໍ່ຈໍາເປັນໃນເວລາທີ່ໄວຢາກອນ array ທີ່ຮູ້ຫນັງສືອະນຸຍາດໃຫ້ [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// ຕົວຢ່າງຂ້າງລຸ່ມນີ້ຫຼັງຈາກນັ້ນສາມາດນໍາໃຊ້ `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// ຜົນໄດ້ຮັບການ (ເປັນໄປໄດ້ຂະຫນາດນ້ອຍ) ຫຼັງຈາກນັ້ນນໍາຂອງຂໍ້ມູນທີ່ໄດ້ຕົວຈິງອ່ານ
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SAFETY: ເປັນ uninitialized `[MaybeUninit<_>; LEN]` ແມ່ນຖືກຕ້ອງ.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// ສ້າງ `MaybeUninit<T>` ໃຫມ່ໃນສະຖານະ uninitiated ມີຫນ່ວຍຄວາມຈໍາທີ່ເຕັມໄປດ້ວຍ bytes `0`.ມັນຂຶ້ນຢູ່ກັບ `T` ບໍ່ວ່າຈະເປັນແລ້ວເຮັດໃຫ້ສໍາລັບການຂຽນອັກສອນຫຍໍ້ທີ່ເຫມາະສົມ.
    ///
    /// ສໍາລັບຕົວຢ່າງ, `MaybeUninit<usize>::zeroed()` ຖືກກຽມ, ແຕ່ `MaybeUninit<&'static i32>::zeroed()` ບໍ່ແມ່ນຍ້ອນວ່າເອກະສານບໍ່ຕ້ອງ null.
    ///
    /// ໃຫ້ສັງເກດວ່າການຫຼຸດລົງເປັນ `MaybeUninit<T>` ຈະບໍ່ໂທຫາ `code ເລື່ອນ T` ຂອງ.
    /// ມັນເປັນຄວາມຮັບຜິດຊອບຂອງທ່ານເພື່ອເຮັດໃຫ້ແນ່ໃຈວ່າ `T` ຮັບຫຼຸດລົງຖ້າຫາກວ່າມັນໄດ້ຮັບການເລີ່ມຕົ້ນ.
    ///
    /// # Example
    ///
    /// ການນໍາໃຊ້ທີ່ຖືກຕ້ອງຂອງການທໍາງານນີ້: ເລີ່ມຕົ້ນ struct ທີ່ມີສູນ, ທີ່ນາທັງຫມົດຂອງ struct ສາມາດຖືໄດ້ນ້ອຍຮູບແບບ 0 ເປັນມູນຄ່າທີ່ຖືກຕ້ອງ.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *ການນໍາໃຊ້ທີ່ບໍ່ຖືກຕ້ອງ* ຂອງການທໍາງານນີ້: ໂທຫາ `x.zeroed().assume_init()` ໃນເວລາທີ່ `0` ບໍ່ຖືກຕ້ອງນ້ອຍຮູບແບບສໍາລັບການປະເພດນີ້:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // ພາຍໃນຄູ່, ພວກເຮົາສ້າງ `NotZero` ທີ່ບໍ່ມີຈໍາແນກທີ່ຖືກຕ້ອງ.
    /// // ນີ້ແມ່ນພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // ຄວາມປອດໄພ: `u.as_mut_ptr()` ຊີ້ໃຫ້ເຫັນເຖິງຄວາມ ຈຳ ທີ່ຈັດສັນ.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// ກໍານົດມູນຄ່າຂອງ `MaybeUninit<T>` ໄດ້.
    /// ນີ້ຈະຂຽນທັບຄ່າທີ່ຜ່ານມາໂດຍບໍ່ມີການຫຼຸດລົງມັນ, ດັ່ງນັ້ນຈະລະມັດລະວັງບໍ່ໃຫ້ໃຊ້ສອງຄັ້ງນີ້ເວັ້ນເສຍແຕ່ວ່າທ່ານຕ້ອງການທີ່ຈະຂ້າມແລ່ນ destructor ໄດ້.
    ///
    /// ເພື່ອຄວາມສະດວກຂອງທ່ານ, ນີ້ຍັງຈະກັບຄືນມາກະສານອ້າງອີງບໍ່ແນ່ນອນກັບ (ໃນປັດຈຸບັນເລີ່ມຕົ້ນໄດ້ຢ່າງປອດໄພ) ເນື້ອໃນຂອງ `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SAFETY: ພວກເຮົາພຽງແຕ່ເລີ່ມຕົ້ນຄ່ານີ້.
        unsafe { self.assume_init_mut() }
    }

    /// ໄດ້ຊີ້ໃຫ້ມູນຄ່າບັນຈຸໄດ້.
    /// ອ່ານຈາກຊີ້ນີ້ຫຼືປ່ຽນເປັນສີເປັນກະສານອ້າງອີງເປັນພຶດຕິກໍາ undefined ເວັ້ນເສຍແຕ່ໄດ້ `MaybeUninit<T>` ຖືກກຽມ.
    /// ລັກອັກສອນເພື່ອຄວາມຊົງຈໍາທີ່ຊີ້ນີ້ຈຸດ (non-transitively) ເພື່ອເປັນພຶດຕິກໍາ undefined (ຍົກເວັ້ນພາຍໃນ `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ທີ່ຖືກຕ້ອງຂອງວິທີການນີ້:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // ສ້າງກະສານອ້າງອີງໃນ `MaybeUninit<T>`.ນີ້ບໍ່ເປັນຫຍັງເພາະວ່າພວກເຮົາເລີ່ມຕົ້ນມັນ.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *ການນໍາໃຊ້ທີ່ບໍ່ຖືກຕ້ອງ* ຂອງວິທີການນີ້:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // ພວກເຮົາໄດ້ສ້າງເປັນການອ້າງອີງເຖິງເປັນ uninitiated vector!ນີ້ແມ່ນພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ.⚠️
    /// ```
    ///
    /// (ສັງເກດເຫັນວ່າກົດລະບຽບທີ່ປະມານເອກະສານຂໍ້ມູນ uninitiated ຍັງບໍ່ໄດ້ເຮັດສຸດທ້າຍເທື່ອ, ແຕ່ຈົນກ່ວາພວກເຂົາເຈົ້າແມ່ນ, ມັນເປັນການສົມຄວນທີ່ຈະຫຼີກເວັ້ນການໃຫ້ເຂົາເຈົ້າ.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ແລະ `ManuallyDrop` ມີທັງ `repr(transparent)` ດັ່ງນັ້ນພວກເຮົາສາມາດຂັບໄລ່ຕົວຊີ້.
        self as *const _ as *const T
    }

    /// ເອົາຕົວຊີ້ທີ່ສາມາດປ່ຽນແປງໄດ້ກັບຄ່າທີ່ມີຢູ່.
    /// ອ່ານຈາກຊີ້ນີ້ຫຼືປ່ຽນເປັນສີເປັນກະສານອ້າງອີງເປັນພຶດຕິກໍາ undefined ເວັ້ນເສຍແຕ່ໄດ້ `MaybeUninit<T>` ຖືກກຽມ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ທີ່ຖືກຕ້ອງຂອງວິທີການນີ້:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // ສ້າງເອກະສານອ້າງອີງເຂົ້າໃນ `MaybeUninit<Vec<u32>>`.
    /// // ນີ້ບໍ່ເປັນຫຍັງເພາະວ່າພວກເຮົາເລີ່ມຕົ້ນມັນ.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *ການນໍາໃຊ້ທີ່ບໍ່ຖືກຕ້ອງ* ຂອງວິທີການນີ້:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // ພວກເຮົາໄດ້ສ້າງເປັນການອ້າງອີງເຖິງເປັນ uninitiated vector!ນີ້ແມ່ນພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ.⚠️
    /// ```
    ///
    /// (ສັງເກດເຫັນວ່າກົດລະບຽບທີ່ປະມານເອກະສານຂໍ້ມູນ uninitiated ຍັງບໍ່ໄດ້ເຮັດສຸດທ້າຍເທື່ອ, ແຕ່ຈົນກ່ວາພວກເຂົາເຈົ້າແມ່ນ, ມັນເປັນການສົມຄວນທີ່ຈະຫຼີກເວັ້ນການໃຫ້ເຂົາເຈົ້າ.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ແລະ `ManuallyDrop` ມີທັງ `repr(transparent)` ດັ່ງນັ້ນພວກເຮົາສາມາດຂັບໄລ່ຕົວຊີ້.
        self as *mut _ as *mut T
    }

    /// ສານສະກັດຈາກມູນຄ່າຈາກການບັນຈຸ `MaybeUninit<T>` ໄດ້.ນີ້ເປັນວິທີທີ່ຍິ່ງໃຫຍ່ເພື່ອຮັບປະກັນວ່າຂໍ້ມູນທີ່ຈະໄດ້ຮັບຫຼຸດລົງ, ເນື່ອງຈາກວ່າຜົນໄດ້ `T` ແມ່ນຂຶ້ນກັບການຮັກສາຫຼັງການຫຼຸດລົງປົກກະຕິ.
    ///
    /// # Safety
    ///
    /// ມັນຂຶ້ນຢູ່ກັບໂທໄປຮັບປະກັນວ່າ `MaybeUninit<T>` ກໍ່ແມ່ນຢູ່ໃນສະຖານະໃນເບື້ອງຕົ້ນ.ໂທນີ້ໃນເວລາທີ່ເນື້ອໃນແມ່ນບໍ່ທັນໄດ້ເລີ່ມຕົ້ນໄດ້ຢ່າງເຕັມສ່ວນສາເຫດພຶດຕິກໍາ undefined ທັນທີທັນໃດ.
    /// The [type-level documentation][inv] ປະກອບດ້ວຍຂໍ້ມູນຂ່າວສານເພີ່ມເຕີມກ່ຽວກັບ invariant ຂຽນອັກສອນຫຍໍ້ນີ້.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// ສຸດເທິງຂອງທີ່, ຈື່ໄດ້ວ່າເກືອບທຸກຊະນິດມີຄາຄົງເພີ່ມເຕີມນອກເຫນືອວ່າພຽງແຕ່ພິຈາລະນາເລີ່ມຕົ້ນໃນລະດັບປະເພດໄດ້.
    /// ສໍາລັບຕົວຢ່າງ, ເປັນ `1`, ກຽມ [`Vec<T>`] ແມ່ນພິຈາລະນາກຽມ (ພາຍໃຕ້ການປະຕິບັດໃນປະຈຸບັນ; ນີ້ບໍ່ໄດ້ປະກອບໃຫ້ການຄໍ້າປະກັນຄວາມຫມັ້ນຄົງກ) ເນື່ອງຈາກວ່າຄວາມຕ້ອງການພຽງແຕ່ compiler ໄດ້ຮູ້ກ່ຽວກັບມັນແມ່ນວ່າຊີ້ຂໍ້ມູນຈະຕ້ອງບໍ່ແມ່ນ null.
    ///
    /// ການສ້າງດັ່ງກ່າວເປັນ `Vec<T>` ບໍ່ສາເຫດ *ທັນທີທັນໃດພຶດຕິກໍາ undefined*, ແຕ່ຈະເຮັດໃຫ້ເກີດພຶດຕິກໍາ undefined ກັບການດໍາເນີນງານຄວາມປອດໄພທີ່ສຸດ (ລວມທັງຫຼຸດລົງມັນ).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ທີ່ຖືກຕ້ອງຂອງວິທີການນີ້:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *ການນໍາໃຊ້ທີ່ບໍ່ຖືກຕ້ອງ* ຂອງວິທີການນີ້:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ບໍ່ໄດ້ຮັບການເລີ່ມຕົ້ນທັນ, ສະນັ້ນບັນທັດສຸດທ້າຍນີ້ເກີດມາຈາກພຶດຕິກໍາ undefined.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SAFETY: ການຄໍ້າປະກັນໂທຕ້ອງທີ່ `self` ຖືກກຽມ.
        // ນີ້ຫມາຍຄວາມວ່າ `self` ຕ້ອງເປັນ variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// ອ່ານຄຸນຄ່າຈາກພາຊະນະ `MaybeUninit<T>`.ການສົ່ງຜົນໃຫ້ `T` ແມ່ນຂຶ້ນກັບການຮັກສາຫຼັງການຫຼຸດລົງປົກກະຕິ.
    ///
    /// ເມື່ອໃດກໍ່ຕາມທີ່ເປັນໄປໄດ້, ຄວນໃຊ້ [`assume_init`] ແທນ, ເຊິ່ງປ້ອງກັນບໍ່ໃຫ້ເນື້ອຫາຂອງ `MaybeUninit<T>` ຊ້ ຳ.
    ///
    /// # Safety
    ///
    /// ມັນຂຶ້ນຢູ່ກັບໂທໄປຮັບປະກັນວ່າ `MaybeUninit<T>` ກໍ່ແມ່ນຢູ່ໃນສະຖານະໃນເບື້ອງຕົ້ນ.ໂທນີ້ໃນເວລາທີ່ເນື້ອໃນແມ່ນບໍ່ທັນໄດ້ເລີ່ມຕົ້ນໄດ້ຢ່າງເຕັມສ່ວນສາເຫດພຶດຕິກໍາ undefined.
    /// The [type-level documentation][inv] ປະກອບດ້ວຍຂໍ້ມູນຂ່າວສານເພີ່ມເຕີມກ່ຽວກັບ invariant ຂຽນອັກສອນຫຍໍ້ນີ້.
    ///
    /// ຍິ່ງໄປກວ່ານັ້ນ, ໃບນີ້ສໍາເນົາຂອງຫລັງຂໍ້ມູນດຽວກັນໃນ `MaybeUninit<T>` ໄດ້.
    /// ໃນເວລາທີ່ການນໍາໃຊ້ທີ່ຫຼາກຫຼາຍສໍາເນົາຂອງຂໍ້ມູນ (ໂດຍການໂທຫາ `assume_init_read` ເວລາຫຼາຍ, ຫຼືທໍາອິດໂທຫາ `assume_init_read` ແລະຫຼັງຈາກນັ້ນ [`assume_init`]), ມັນເປັນຄວາມຮັບຜິດຊອບຂອງທ່ານເພື່ອຮັບປະກັນວ່າຂໍ້ມູນທີ່ອາດຈະຈິງໄດ້ຮັບການ duplicated.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ທີ່ຖືກຕ້ອງຂອງວິທີການນີ້:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` ແມ່ນ `Copy`, ດັ່ງນັ້ນພວກເຮົາອາດຈະໄດ້ອ່ານຫຼາຍເທື່ອແລ້ວ.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // ການເຮັດຊໍ້າມູນຄ່າ `None` ແມ່ນບໍ່ເປັນຫຍັງ, ດັ່ງນັ້ນພວກເຮົາອາດຈະອ່ານຫຼາຍໆຄັ້ງ.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *ການນໍາໃຊ້ທີ່ບໍ່ຖືກຕ້ອງ* ຂອງວິທີການນີ້:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // ດຽວນີ້ພວກເຮົາສ້າງ vector ດຽວກັນ 2 ແຜ່ນ, ນຳ ໄປສູ່ການຟຣີແບບບໍ່ມີຄ່າdouble️ເມື່ອພວກເຂົາທັງສອງຖືກລຸດລົງ!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SAFETY: ການຄໍ້າປະກັນໂທຕ້ອງທີ່ `self` ຖືກກຽມ.
        // ການອ່ານຈາກ `self.as_ptr()` ແມ່ນປອດໄພເພາະ `self` ຄວນຈະຖືກເລີ່ມຕົ້ນ.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// ການຢອດຢາຄ່າບັນຈຸໃນສະຖານທີ່.
    ///
    /// ຖ້າຫາກວ່າທ່ານມີຄວາມເປັນເຈົ້າຂອງຂອງ `MaybeUninit`, ທ່ານສາມາດໃຊ້ [`assume_init`] ແທນທີ່ຈະ.
    ///
    /// # Safety
    ///
    /// ມັນຂຶ້ນຢູ່ກັບໂທໄປຮັບປະກັນວ່າ `MaybeUninit<T>` ກໍ່ແມ່ນຢູ່ໃນສະຖານະໃນເບື້ອງຕົ້ນ.ໂທນີ້ໃນເວລາທີ່ເນື້ອໃນແມ່ນບໍ່ທັນໄດ້ເລີ່ມຕົ້ນໄດ້ຢ່າງເຕັມສ່ວນສາເຫດພຶດຕິກໍາ undefined.
    ///
    /// ສຸດເທິງຂອງທີ່, ຄາຄົງເພີ່ມເຕີມທັງຫມົດຂອງປະເພດ `T` ຕ້ອງໄດ້ຮັບຄວາມເພິ່ງພໍໃຈ, ເປັນການປະຕິບັດ `Drop` ຂອງ `T` (ຫຼືສະມາຊິກຂອງຕົນ) ອາດອີງໃສ່ນີ້.
    /// ສໍາລັບຕົວຢ່າງ, ເປັນ `1`, ກຽມ [`Vec<T>`] ແມ່ນພິຈາລະນາກຽມ (ພາຍໃຕ້ການປະຕິບັດໃນປະຈຸບັນ; ນີ້ບໍ່ໄດ້ປະກອບໃຫ້ການຄໍ້າປະກັນຄວາມຫມັ້ນຄົງກ) ເນື່ອງຈາກວ່າຄວາມຕ້ອງການພຽງແຕ່ compiler ໄດ້ຮູ້ກ່ຽວກັບມັນແມ່ນວ່າຊີ້ຂໍ້ມູນຈະຕ້ອງບໍ່ແມ່ນ null.
    ///
    /// ການຫຼຸດລົງດັ່ງກ່າວ `Vec<T>` ຢ່າງໃດກໍ່ຕາມຈະເຮັດໃຫ້ເກີດການປະພຶດທີ່ບໍ່ໄດ້ກໍານົດ.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SAFETY: ການຄໍ້າປະກັນໂທຕ້ອງທີ່ `self` ຖືກກຽມແລະ
        // satisfies ຄາຄົງທັງຫມົດຂອງ `T`.
        // ເລີ່ມຫຼຸດລົງເລື້ອຍຄຸນຄ່າໃນສະຖານທີ່ມີຄວາມປອດໄພຖ້າຫາກວ່າແມ່ນກໍລະນີ.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// ໄດ້ຮັບການກະສານອ້າງອີງໄດ້ແບ່ງປັນກັບມູນຄ່າທີ່ມີການ.
    ///
    /// ນີ້ສາມາດເປັນປະໂຫຍດໃນເວລາທີ່ພວກເຮົາຕ້ອງການທີ່ຈະເຂົ້າເຖິງ `MaybeUninit` ທີ່ໄດ້ຮັບການເລີ່ມຕົ້ນແຕ່ບໍ່ມີຄວາມເປັນເຈົ້າຂອງຂອງ `MaybeUninit` (ການປ້ອງກັນການນໍາໃຊ້ຂອງ `.assume_init()`) ໄດ້.
    ///
    /// # Safety
    ///
    /// ໂທນີ້ໃນເວລາທີ່ເນື້ອໃນແມ່ນບໍ່ທັນໄດ້ເລີ່ມຕົ້ນໄດ້ຢ່າງເຕັມສ່ວນສາເຫດພຶດຕິກໍາ undefined: ມັນຂຶ້ນຢູ່ກັບໂທໄປຮັບປະກັນວ່າ `MaybeUninit<T>` ກໍ່ແມ່ນຢູ່ໃນສະຖານະໃນເບື້ອງຕົ້ນ.
    ///
    ///
    /// # Examples
    ///
    /// ### ການ ນຳ ໃຊ້ທີ່ຖືກຕ້ອງຂອງວິທີການນີ້:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // ຂໍ້ລິເລີ່ມ `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // ໃນປັດຈຸບັນທີ່ `MaybeUninit<_>` ຂອງພວກເຮົາເປັນທີ່ຮູ້ຈັກທີ່ຈະໄດ້ຮັບການເລີ່ມຕົ້ນ, ມັນເປັນຫຍັງບໍທີ່ຈະສ້າງກະສານອ້າງອີງໄດ້ແບ່ງປັນກັບມັນ:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SAFETY: `x` ໄດ້ຮັບການເລີ່ມຕົ້ນ.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### * * ບໍ່ຖືກຕ້ອງ usages ຂອງວິທີການນີ້:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // ພວກເຮົາໄດ້ສ້າງເປັນການອ້າງອີງເຖິງເປັນ uninitiated vector!ນີ້ແມ່ນພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // ກຽມໃຊ້ວຽກ `MaybeUninit` ໃຊ້ `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // ການອ້າງອີງເຖິງ `Cell<bool>` ແບບບໍ່ມີຕົວຕົນ: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SAFETY: ການຄໍ້າປະກັນໂທຕ້ອງທີ່ `self` ຖືກກຽມ.
        // ນີ້ຫມາຍຄວາມວ່າ `self` ຕ້ອງເປັນ variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// ໄດ້ຮັບການກະສານອ້າງອີງ (unique) ບໍ່ແນ່ນອນກັບມູນຄ່າທີ່ມີການ.
    ///
    /// ນີ້ສາມາດເປັນປະໂຫຍດໃນເວລາທີ່ພວກເຮົາຕ້ອງການທີ່ຈະເຂົ້າເຖິງ `MaybeUninit` ທີ່ໄດ້ຮັບການເລີ່ມຕົ້ນແຕ່ບໍ່ມີຄວາມເປັນເຈົ້າຂອງຂອງ `MaybeUninit` (ການປ້ອງກັນການນໍາໃຊ້ຂອງ `.assume_init()`) ໄດ້.
    ///
    /// # Safety
    ///
    /// ໂທນີ້ໃນເວລາທີ່ເນື້ອໃນແມ່ນບໍ່ທັນໄດ້ເລີ່ມຕົ້ນໄດ້ຢ່າງເຕັມສ່ວນສາເຫດພຶດຕິກໍາ undefined: ມັນຂຶ້ນຢູ່ກັບໂທໄປຮັບປະກັນວ່າ `MaybeUninit<T>` ກໍ່ແມ່ນຢູ່ໃນສະຖານະໃນເບື້ອງຕົ້ນ.
    /// ສໍາລັບການຍົກຕົວຢ່າງ, `.assume_init_mut()` ບໍ່ສາມາດຖືກນໍາໃຊ້ເພື່ອເລີ່ມຕົ້ນການ `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### ການ ນຳ ໃຊ້ທີ່ຖືກຕ້ອງຂອງວິທີການນີ້:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// ໃນເບື້ອງຕົ້ນ *ທັງຫມົດ* ໄບປ້ອງກັນການປ້ອນຂໍ້ມູນໄດ້.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // ເລີ່ມ `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // ໃນປັດຈຸບັນພວກເຮົາຮູ້ວ່າ `buf` ໄດ້ຮັບການເລີ່ມຕົ້ນ, ສະນັ້ນພວກເຮົາສາມາດ `.assume_init()` ມັນ.
    /// // ຢ່າງໃດກໍຕາມ, ການນໍາໃຊ້ `.assume_init()` ອາດຜົນກະທົບຕໍ່ `memcpy` ຂອງ 2048 bytes.
    /// // ໃຫ້ຫມັ້ນໃຈປ້ອງກັນຂອງພວກເຮົາໄດ້ຮັບການເລີ່ມຕົ້ນໂດຍບໍ່ມີການເອົາສໍາເນົາມັນ, ພວກເຮົາຍົກລະດັບການ `&mut MaybeUninit<[u8; 2048]>` ກັບ `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // ຄວາມປອດໄພ: `buf` ໄດ້ຖືກເລີ່ມຕົ້ນແລ້ວ.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // ໃນປັດຈຸບັນພວກເຮົາສາມາດນໍາໃຊ້ `buf` ເປັນຫຼັງຈາກນັ້ນນໍາປົກກະຕິ:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### * * ບໍ່ຖືກຕ້ອງ usages ຂອງວິທີການນີ້:
    ///
    /// ທ່ານບໍ່ສາມາດນໍາໃຊ້ `.assume_init_mut()` ສາມາດເລີ່ມຕົ້ນເປັນມູນຄ່າ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // ພວກເຮົາໄດ້ສ້າງເປັນກະສານອ້າງອີງ (mutable) ກັບ uninitiated `bool`!
    ///     // ນີ້ແມ່ນພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ.⚠️
    /// }
    /// ```
    ///
    /// ສໍາລັບການຍົກຕົວຢ່າງ, ທ່ານສາມາດເຮັດໄດ້ບໍ່ [`Read`] ເຂົ້າໄປໃນບັຟເຟີ uninitiated:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ກະສານອ້າງອີງຄວາມຊົງຈໍາ uninitiated!
    ///                             // ນີ້ແມ່ນພຶດຕິກໍາ undefined.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// ຫຼືທ່ານສາມາດນໍາໃຊ້ການເຂົ້າເຖິງພາກສະຫນາມໂດຍກົງຈະເຮັດພາກສະຫນາມໂດຍພາກສະຫນາມຄ່ອຍເປັນຄ່ອຍໄປຂຽນອັກສອນຫຍໍ້:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ກະສານອ້າງອີງຄວາມຊົງຈໍາ uninitiated!
    ///                  // ນີ້ແມ່ນພຶດຕິກໍາ undefined.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ກະສານອ້າງອີງຄວາມຊົງຈໍາ uninitiated!
    ///                  // ນີ້ແມ່ນພຶດຕິກໍາ undefined.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): ປະຈຸບັນພວກເຮົາອີງໃສ່ຂ້າງເທິງນີ້ເປັນທີ່ບໍ່ຖືກຕ້ອງ, ie, ພວກເຮົາມີການອ້າງອິງເຖິງຂໍ້ມູນ uninitiated (ຕົວຢ່າງ: , ໃນ `libcore/fmt/float.rs`).
    // ພວກເຮົາຄວນຈະເຮັດໃຫ້ເປັນການຕັດສິນໃຈຂັ້ນສຸດທ້າຍກ່ຽວກັບກົດລະບຽບກ່ອນທີ່ຈະສະຖຽນລະພາບໄດ້.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SAFETY: ການຄໍ້າປະກັນໂທຕ້ອງທີ່ `self` ຖືກກຽມ.
        // ນີ້ຫມາຍຄວາມວ່າ `self` ຕ້ອງເປັນ variant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// ສານສະກັດຈາກຄ່າຈາກ array ຂອງຕູ້ເກັບມ້ຽນ `MaybeUninit` ເປັນ.
    ///
    /// # Safety
    ///
    /// ມັນຂຶ້ນຢູ່ກັບໂທໄປຄໍ້າປະກັນວ່າອົງປະກອບທັງຫມົດຂອງ array ແມ່ນໃນສະຖານະໃນເບື້ອງຕົ້ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // ຄວາມປອດໄພ: ດຽວນີ້ປອດໄພເມື່ອພວກເຮົາເລີ່ມຕົ້ນທຸກອົງປະກອບ
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * ການຮັບປະກັນແປໄດ້ທຸທີ່ອົງປະກອບທັງຫມົດຂອງ array ແມ່ນກຽມ
        // * `MaybeUninit<T>` ແລະ T ແມ່ນການຮັບປະກັນທີ່ຈະມີຮູບລັກດຽວກັນ
        // * MaybeUnint ບໍ່ລົງ, ສະນັ້ນບໍ່ມີຟຣີ double ແລະດັ່ງນັ້ນຈຶ່ງປ່ຽນໃຈເຫລື້ອມໃສແມ່ນມີຄວາມປອດໄພ
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// ສົມມຸດວ່າທັງຫມົດອົງປະກອບຂອງກໍາລັງເລີ່ມຕົ້ນ, ໄດ້ຮັບຫຼັງຈາກນັ້ນນໍາເພື່ອໃຫ້ເຂົາເຈົ້າ.
    ///
    /// # Safety
    ///
    /// ມັນຂຶ້ນຢູ່ກັບໂທໄປຮັບປະກັນວ່າອົງປະກອບ `MaybeUninit<T>` ແທ້ຢູ່ໃນສະຖານະໃນເບື້ອງຕົ້ນ.
    ///
    /// ໂທນີ້ໃນເວລາທີ່ເນື້ອໃນແມ່ນບໍ່ທັນໄດ້ເລີ່ມຕົ້ນໄດ້ຢ່າງເຕັມສ່ວນສາເຫດພຶດຕິກໍາ undefined.
    ///
    /// ເບິ່ງ [`assume_init_ref`] ສໍາລັບລາຍລະອຽດເພີ່ມເຕີມແລະຕົວຢ່າງ.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SAFETY: casting ຫຼັງຈາກນັ້ນນໍາໄປ `*const [T]` ແມ່ນມີຄວາມປອດໄພນັບຕັ້ງແຕ່ຮັບປະກັນແປໄດ້ທຸທີ່
        // `slice` ແມ່ນເລີ່ມຕົ້ນ, and`MaybeUninit` ແມ່ນການຮັບປະກັນທີ່ຈະມີຮູບລັກເຊັ່ນດຽວກັນກັບ `T`.
        // ຕົວຊີ້ທີ່ໄດ້ຮັບແມ່ນຖືກຕ້ອງເພາະມັນ ໝາຍ ເຖິງ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ເປັນເຈົ້າຂອງ `slice` ເຊິ່ງເປັນເອກະສານອ້າງອີງແລະດັ່ງນັ້ນຈຶ່ງຮັບປະກັນວ່າມັນຈະຖືກຕ້ອງ ສຳ ລັບການອ່ານ.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// ສົມມຸດວ່າທັງຫມົດອົງປະກອບຂອງກໍາລັງເລີ່ມຕົ້ນ, ໄດ້ຮັບຫຼັງຈາກນັ້ນນໍາບໍ່ແນ່ນອນເພື່ອໃຫ້ເຂົາເຈົ້າ.
    ///
    /// # Safety
    ///
    /// ມັນຂຶ້ນຢູ່ກັບໂທໄປຮັບປະກັນວ່າອົງປະກອບ `MaybeUninit<T>` ແທ້ຢູ່ໃນສະຖານະໃນເບື້ອງຕົ້ນ.
    ///
    /// ໂທນີ້ໃນເວລາທີ່ເນື້ອໃນແມ່ນບໍ່ທັນໄດ້ເລີ່ມຕົ້ນໄດ້ຢ່າງເຕັມສ່ວນສາເຫດພຶດຕິກໍາ undefined.
    ///
    /// ເບິ່ງ [`assume_init_mut`] ສໍາລັບລາຍລະອຽດເພີ່ມເຕີມແລະຕົວຢ່າງ.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SAFETY: ຄ້າຍຄືກັນກັບບັນທຶກຄວາມປອດໄພສໍາລັບ `slice_get_ref`, ແຕ່ພວກເຮົາມີ
        // ອ້າງອິງບໍ່ແນ່ນອນຊຶ່ງມີການຮັບປະກັນວ່າຖືກຕ້ອງສໍາລັບການຂຽນ.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// ໄດ້ຊີ້ໃຫ້ອົງປະກອບທໍາອິດຂອງຂບວນການໄດ້.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// ໄດ້ຮັບການຊີ້ບໍ່ແນ່ນອນກັບອົງປະກອບທໍາອິດຂອງຂບວນການ.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// ຄັດລອກອົງປະກອບຕ່າງໆຈາກ `src` ຫາ `this`, ສົ່ງຄືນຂໍ້ອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບເນື້ອຫາທີ່ມີການປ່ຽນແປງ ໃໝ່ ຂອງ `this`.
    ///
    /// ຖ້າ `T` ບໍ່ປະຕິບັດ `Copy`, ໃຫ້ໃຊ້ [`write_slice_cloned`]
    ///
    /// ນີ້ແມ່ນຄ້າຍຄືກັນກັບ [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ຈະ panic ຖ້າສອງຫຼັງຈາກນັ້ນນໍາມີຄວາມຍາວທີ່ແຕກຕ່າງກັນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: ພວກເຮົາໄດ້ຄັດລອກພຽງແຕ່ອົງປະກອບທັງຫມົດຂອງ len ໃນຄວາມອາດສາມາດ
    /// // ອົງປະກອບ src.len() ທໍາອິດຂອງ vec ແມ່ນຖືກຕ້ອງໃນປັດຈຸບັນ.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SAFETY: &[T] ແລະ&[MaybeUninit<T>] ມີຮູບລັກດຽວກັນ
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SAFETY: ອົງປະກອບຖືກຕ້ອງໄດ້ຮັບການພຽງແຕ່ສໍາເນົາເຂົ້າໄປໃນ `this` ສະນັ້ນມັນແມ່ນ initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Clones ອົງປະກອບຈາກ `src` ກັບ `this` ໄດ້, ກັບຄືນກະສານອ້າງອີງບໍ່ແນ່ນອນກັບເນື້ອໃນ initalized ໃນປັດຈຸບັນຂອງ `this`.
    /// ທຸກໆອົງປະກອບທີ່ຖືກກະຕຸ້ນແລ້ວຈະບໍ່ຖືກລຸດລົງ.
    ///
    /// ຖ້າຫາກວ່າປະຕິບັດແນວ `T` `Copy` ໃຊ້ [`write_slice`]
    ///
    /// ນີ້ແມ່ນຄ້າຍຄືກັນກັບ [`slice::clone_from_slice`] ແຕ່ບໍ່ໄດ້ວາງອົງປະກອບທີ່ມີຢູ່ແລ້ວ.
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ຈະ panic ຖ້າສອງຫຼັງຈາກນັ້ນນໍາມີຄວາມຍາວທີ່ແຕກຕ່າງກັນ, ຫຼືຖ້າຫາກວ່າການປະຕິບັດຂອງ `Clone` panics ໄດ້.
    ///
    /// ຖ້າຫາກວ່າມີ panic, ອົງປະກອບ cloned ແລ້ວຈະຖືກຍົກເລີກ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SAFETY: ພວກເຮົາໄດ້ cloned ພຽງແຕ່ອົງປະກອບທັງຫມົດຂອງ len ໃນຄວາມອາດສາມາດ
    /// // ອົງປະກອບ src.len() ທໍາອິດຂອງ vec ແມ່ນຖືກຕ້ອງໃນປັດຈຸບັນ.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // ບໍ່ເຫມືອນກັບ copy_from_slice ນີ້ບໍ່ໄດ້ໂທຫາ clone_from_slice ກ່ຽວກັບຫຼັງຈາກນັ້ນນໍານີ້ແມ່ນຍ້ອນວ່າ `MaybeUninit<T: Clone>` ບໍ່ໃຊ້ Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SAFETY: ນີ້ຫຼັງຈາກນັ້ນນໍາດິບຈະປະກອບດ້ວຍວັດຖຸເລີ່ມຕົ້ນພຽງແຕ່
                // ວ່າເປັນຫຍັງ, ມັນແມ່ນອະນຸຍາດໃຫ້ລົງມັນ.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: ພວກເຮົາຈໍາເປັນຕ້ອງໄດ້ຢ່າງຊັດເຈນຫຼັງຈາກນັ້ນນໍາພວກເຂົາກັບຍາວເທົ່າ ໆ ກັນໄດ້
        // ສໍາລັບຂອບເຂດການກວດສອບເພື່ອຮັບ elided, ແລະດີທີ່ສຸດທີ່ຈະສ້າງຄໍາສັ່ງ memcpy ສໍາລັບກໍລະນີງ່າຍດາຍ (ສໍາລັບຕົວຢ່າງ T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // ກອງທີ່ຈໍາເປັນ b/c panic ອາດເກີດຂຶ້ນໃນລະຫວ່າງການ clone ເປັນ
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SAFETY: ອົງປະກອບຖືກຕ້ອງໄດ້ຮັບການພຽງແຕ່ລາຍລັກອັກສອນໃນ `this` ສະນັ້ນມັນແມ່ນ initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}