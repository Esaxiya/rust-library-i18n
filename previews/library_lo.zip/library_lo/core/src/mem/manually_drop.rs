use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// A wrapper ກັບ compiler inhibit ຈາກໂທອັດຕະໂນມັດ `destructor T` ຂອງ.
/// wrapper ນີ້ແມ່ນ 0 ເສັຽຄ່າ.
///
/// `ManuallyDrop<T>` ແມ່ນຂຶ້ນຢູ່ກັບປະສິດທິພາບຮູບແບບເຊັ່ນດຽວກັນກັບ `T`.
/// ຍ້ອນແນວນັ້ນ, ມັນມີຜົນກະທົບ *ບໍ່ມີ* ໃສ່ຂໍ້ສົມມຸດທີ່ວ່າ compiler ໄດ້ເຮັດໃຫ້ປະມານເນື້ອໃນຂອງຕົນ.
/// ສໍາລັບຕົວຢ່າງ, ເລີ່ມຕົ້ນ `ManuallyDrop<&mut T>` ກັບ [`mem::zeroed`] ເປັນພຶດຕິກໍາ undefined.
/// ຖ້າຫາກວ່າທ່ານຕ້ອງການທີ່ຈະຈັດການຂໍ້ມູນ uninitiated ໃຊ້ [`MaybeUninit<T>`] ແທນທີ່ຈະ.
///
/// ໃຫ້ສັງເກດວ່າການເຂົ້າເຖິງມູນຄ່າທີ່ພາຍໃນ `ManuallyDrop<T>` ແມ່ນມີຄວາມປອດໄພ.
/// ນີ້ຫມາຍຄວາມວ່ານັ້ນ `ManuallyDrop<T>` ທີ່ເນື້ອໃນໄດ້ຮັບການຫຼຸດລົງຕ້ອງບໍ່ໄດ້ຮັບການສໍາຜັດຜ່ານ API ຄວາມປອດໄພສາທາລະນະ.
/// ໄປພ້ອມໆ, `ManuallyDrop::drop` ແມ່ນບໍ່ປອດໄພ.
///
/// # `ManuallyDrop` ແລະຍົກເລີກການສັ່ງຊື້.
///
/// Rust ມີທີ່ດີ defined [drop order] ຂອງຄ່າ.
/// ເພື່ອເຮັດໃຫ້ແນ່ໃຈວ່າທົ່ງນາຫຼືໃນທ້ອງຖິ່ນແມ່ນຫຼຸດລົງໃນຄໍາສັ່ງສະເພາະໃດຫນຶ່ງ, Re: ຄໍາສັ່ງການປະກາດດັ່ງກ່າວວ່າເພື່ອເລື່ອນ implicit ເປັນທີ່ຖືກຕ້ອງຫນຶ່ງ.
///
/// ມັນເປັນໄປໄດ້ທີ່ຈະນໍາໃຊ້ `ManuallyDrop` ໃນການຄວບຄຸມເພື່ອຫຼຸດລົງ, ແຕ່ນີ້ຮຽກຮ້ອງໃຫ້ມີລະຫັດທີ່ບໍ່ປອດໄພແລະເປັນການຍາກທີ່ຈະເຮັດໄດ້ຢ່າງຖືກຕ້ອງໃນທີ່ປະທັບຂອງຄາຍໄດ້.
///
///
/// ສໍາລັບຕົວຢ່າງ, ຖ້າຫາກວ່າທ່ານຕ້ອງການທີ່ຈະເຮັດໃຫ້ແນ່ໃຈວ່າພາກສະຫນາມສະເພາະໃດຫນຶ່ງທີ່ຖືກຖີ້ມລົງຫຼັງຈາກຄົນອື່ນ, ເຮັດໃຫ້ມັນໄດ້ພາກສະຫນາມສຸດທ້າຍຂອງ struct ເປັນ:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` ຈະໄດ້ຮັບການຫຼຸດລົງຫຼັງຈາກທີ່ `children`.
///     // Rust ຮັບປະກັນວ່າຂົງເຂດກໍາລັງຫຼຸດລົງໃນຄໍາສັ່ງຂອງການປະກາດ.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// ຫໍ່ຄ່າທີ່ຈະຫຼຸດລົງດ້ວຍຕົນເອງ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // ທ່ານຍັງສາມາດປະຕິບັດງານໄດ້ຢ່າງປອດໄພກ່ຽວກັບມູນຄ່າຂອງ
    /// assert_eq!(*x, "Hello");
    /// // ແຕ່ `Drop` ຈະບໍ່ໄດ້ຮັບການດໍາເນີນການນີ້
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// ສານສະກັດຈາກມູນຄ່າຈາກການບັນຈຸ `ManuallyDrop` ໄດ້.
    ///
    /// ນີ້ອະນຸຍາດໃຫ້ມູນຄ່າໃນການໄດ້ຮັບການຫຼຸດລົງອີກເທື່ອຫນຶ່ງ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // ນີ້ຕົກລົງການ `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// ໃຊ້ເວລາຄ່າຈາກພາຊະນະອອກ `ManuallyDrop<T>` ໄດ້.
    ///
    /// ວິທີການນີ້ມີຈຸດປະສົງຕົ້ນຕໍສໍາລັບການເຄື່ອນຍ້າຍອອກຄ່າໃນການຫຼຸດລົງ.
    /// ແທນທີ່ຈະນໍາໃຊ້ [`ManuallyDrop::drop`] ກັບຕົນເອງລົງມູນຄ່າ, ທ່ານສາມາດນໍາໃຊ້ວິທີການນີ້ຈະໃຊ້ເວລາຄຸນຄ່າແລະການນໍາໃຊ້ມັນຢ່າງໃດກໍຕາມທີ່ຕ້ອງການ.
    ///
    /// ເມື່ອໃດກໍຕາມທີ່ເປັນໄປໄດ້, ມັນເປັນຄວາມຕ້ອງການນໍາໃຊ້ [`into_inner`][`ManuallyDrop::into_inner`] ແທນທີ່ຈະ, ທີ່ປ້ອງກັນເຮັດຊ້ໍາເນື້ອຫາຂອງ `ManuallyDrop<T>` ໄດ້.
    ///
    ///
    /// # Safety
    ///
    /// ຟັງຊັນນີ້ຫມາຍຍ້າຍອອກມູນຄ່າບັນຈຸໄດ້ໂດຍບໍ່ມີການປ້ອງກັນການນໍາໃຊ້ໃນຕໍ່ຫນ້າ, ຊຶ່ງເຮັດໃຫ້ສະຖານະຂອງພາຊະນະທີ່ບໍ່ປ່ຽນແປງ.
    /// ມັນເປັນຄວາມຮັບຜິດຊອບຂອງທ່ານເພື່ອຮັບປະກັນວ່າ `ManuallyDrop` ນີ້ບໍ່ໄດ້ນໍາໃຊ້ອີກເທື່ອຫນຶ່ງ.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SAFETY: ພວກເຮົາກໍາລັງອ່ານຈາກກະສານອ້າງອີງທີ່ມີການປະກັນ
        // ຈະຖືກຕ້ອງສໍາລັບບອກວ່າ.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// ຫຼຸດລົງດ້ວຍຕົນເອງມູນຄ່າທີ່ບັນຈຸ.ນີ້ແມ່ນແທ້ເທົ່າກັບໂທຫາ [`ptr::drop_in_place`] ກັບຊີ້ໄປມູນຄ່າບັນຈຸໄດ້.
    /// ດັ່ງນັ້ນ, ເວັ້ນເສຍແຕ່ວ່າມູນຄ່າບັນຈຸເປັນ struct ບັນຈຸ, destructor ໄດ້ຈະໄດ້ຮັບການເອີ້ນວ່າໃນສະຖານທີ່ໂດຍບໍ່ມີການເຄື່ອນຍ້າຍມູນຄ່າ, ແລະດັ່ງນັ້ນຈຶ່ງສາມາດນໍາໃຊ້ໄດ້ຢ່າງປອດໄພລົງຂໍ້ມູນ [pinned].
    ///
    /// ຖ້າຫາກວ່າທ່ານມີຄວາມເປັນເຈົ້າຂອງຂອງມູນຄ່າ, ທ່ານສາມາດນໍາໃຊ້ [`ManuallyDrop::into_inner`] ແທນທີ່ຈະ.
    ///
    /// # Safety
    ///
    /// ຟັງຊັນນີ້ເນັ້ນ destructor ຂອງມູນຄ່າບັນຈຸໄດ້.
    /// ອື່ນກ່ວາການປ່ຽນແປງໄດ້ໂດຍ destructor ຕົວມັນເອງ, ຄວາມຊົງຈໍາໄດ້ຖືກປະໄວ້ບໍ່ປ່ຽນແປງ, ແລະອື່ນໆເທົ່າທີ່ compiler ເປັນຫ່ວງຍັງຖື bit ຮູບແບບທີ່ເປັນທີ່ຖືກຕ້ອງສໍາລັບປະເພດ `T` ໄດ້.
    ///
    ///
    /// ຢ່າງໃດກໍຕາມ, ມູນຄ່າ "zombie" ນີ້ບໍ່ຄວນສໍາຜັດກັບລະຫັດຄວາມປອດໄພ, ແລະການທໍາງານຂອງນີ້ບໍ່ຄວນໄດ້ຮັບການເອີ້ນວ່າຫຼາຍກ່ວາຫນຶ່ງຄັ້ງ.
    /// ການນໍາໃຊ້ຄ່າຫຼັງຈາກທີ່ມັນໄດ້ຖືກຫຼຸດລົງ, ຫຼືຫຼຸດລົງເປັນມູນຄ່າຫຼາຍຄັ້ງອາດເຮັດໃຫ້ເກີດພຶດຕິກໍາຫນົດ (ຂຶ້ນຢູ່ກັບສິ່ງທີ່ `drop` ບໍ່).
    /// ນີ້ແມ່ນປ້ອງກັນຕາມປົກກະຕິໂດຍລະບົບການພິມ, ແຕ່ຜູ້ໃຊ້ຂອງ `ManuallyDrop` ຕ້ອງປະຕິບັດຮັບປະກັນຜູ້ທີ່ບໍ່ມີການຊ່ວຍເຫຼືອຈາກ compiler ໄດ້.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SAFETY: ພວກເຮົາກໍາລັງເລີ່ມຫຼຸດລົງເລື້ອຍມູນຄ່າທີ່ຊີ້ໄປຕາມກະສານອ້າງອີງທີ່ບໍ່ແນ່ນອນ
        // ເຊິ່ງການຮັບປະກັນທີ່ຈະຖືກຕ້ອງສໍາລັບການຂຽນ.
        // ມັນຂຶ້ນຢູ່ກັບໂທເພື່ອເຮັດໃຫ້ແນ່ໃຈວ່າ `slot` ບໍ່ໄດ້ຫຼຸດລົງອີກເທື່ອຫນຶ່ງ.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}