//! ອິນເຕີເນັດແບບປະສົມປະສານ.
//!
//! ຄໍານິຍາມທີ່ສອດຄ້ອງກັນຢູ່ໃນ `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! ທີ່ສອດຄ້ອງກັນການປະຕິບັດ const ຢູ່ໃນ `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # ການບຸກລຸກ Const
//!
//! Note: ການປ່ຽນແປງໃດໆກ່ຽວກັບຄວາມ ໝັ້ນ ຄົງຂອງການປະພຶດຄວນຈະຖືກປຶກສາຫາລືກັບທີມງານພາສາ.
//! ນີ້ປະກອບມີການປ່ຽນແປງສະຖຽນລະພາບຂອງຄວາມຄົງຕົວ.
//!
//! ໃນຄໍາສັ່ງເພື່ອເຮັດໃຫ້ການໃຊ້ວຽກທີ່ແທ້ຈິງທີ່ລວບລວມທີ່ໃຊ້ເວລາ, ຫນຶ່ງໃນຄວາມຕ້ອງການທີ່ຈະສໍາເນົາການປະຕິບັດຈາກ <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> ກັບ `compiler/rustc_mir/src/interpret/intrinsics.rs` ແລະເພີ່ມ `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ກັບ intrinsic ໄດ້.
//!
//!
//! ຖ້າຫາກວ່າເປັນທີ່ແທ້ຈິງຄວນຈະໄດ້ຮັບການນໍາໃຊ້ຈາກ `const fn` ມີເຫດຜົນ `rustc_const_stable`, ຄຸນລັກສະນະທີ່ແທ້ຈິງຂອງຈະຕ້ອງ `rustc_const_stable`, ເຊັ່ນດຽວກັນ.
//! ການປ່ຽນແປງດັ່ງກ່າວບໍ່ຄວນເຮັດໂດຍບໍ່ໄດ້ຮັບ ຄຳ ປຶກສາຈາກ T-lang, ເພາະວ່າມັນ ນຳ ເອົາຄຸນລັກສະນະເຂົ້າໃນພາສາທີ່ບໍ່ສາມາດ ນຳ ໄປໃຊ້ໃນລະຫັດຜູ້ໃຊ້ໄດ້ໂດຍບໍ່ຕ້ອງໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ຈາກຜູ້ຂຽນ.
//!
//! # Volatiles
//!
//! ສະຖາປັດຕະຍະ ກຳ ທີ່ມີການ ເໜັງ ຕີງສະ ໜອງ ການ ດຳ ເນີນງານທີ່ມີຈຸດປະສົງເພື່ອປະຕິບັດຄວາມຊົງ ຈຳ I/O, ເຊິ່ງຮັບປະກັນບໍ່ໃຫ້ມີການຄຸ້ມຄອງໂດຍຜູ້ລວບລວມຂໍ້ມູນໃນສະຖາປັດຕະຍະ ກຳ ທີ່ບໍ່ປ່ຽນແປງອື່ນໆ.ເບິ່ງເອກະສານ LLVM ເທິງ [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! ທໍາມະຊາດປະລໍາມະນູໃຫ້ປະຕິບັດງານປະລໍາມະນູທົ່ວໄປກ່ຽວກັບຄໍາສັບຕ່າງໆເຄື່ອງ, ມີຫຼາຍຄໍາສັ່ງຫນ່ວຍຄວາມຈໍາເປັນໄປໄດ້.ເຂົາເຈົ້າເຊື່ອຟັງຄວາມຫມາຍເຊັ່ນດຽວກັນກັບ C++ 11.ເບິ່ງເອກະສານ LLVM ໃນ [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! ການຟື້ນຟູທີ່ວ່ອງໄວໃນການສັ່ງເຄື່ອງຄວາມຊົງ ຈຳ:
//!
//! * ໄດ້ມາ, ສິ່ງກີດຂວາງ ສຳ ລັບການຮັບກະແຈ.ຕໍ່ມາຫຼັງຈາກອ່ານແລະຂຽນຈະໃຊ້ເວລາສະຖານທີ່ພາຍຫຼັງທີ່ອຸປະສັກໄດ້.
//! * ປ່ອຍ, ອຸປະສັກສໍາລັບການປ່ອຍ lock ໄດ້.ກ່ອນຈະອ່ານແລະຂຽນຈະໃຊ້ເວລາສະຖານທີ່ກ່ອນທີ່ຈະອຸປະສັກໄດ້.
//! * ສອດຄ່ອງຕາມລໍາດັບ, ການດໍາເນີນງານທີ່ສອດຄ້ອງກັນ sequentially ແມ່ນຮັບປະກັນທີ່ເກີດຂຶ້ນໃນຄໍາສັ່ງ.ນີ້ແມ່ນຮູບແບບມາດຕະຖານສໍາລັບການເຮັດວຽກຮ່ວມກັບປະເພດປະລະມານູ, ເທົ່າກັບ Java ຂອງ `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// ການນໍາເຂົ້າເຫຼົ່ານີ້ໄດ້ຖືກນໍາໃຊ້ສໍາລັບຄວາມຊັບຊ້ອນຂອງການເຊື່ອມຕໍ່ລະຫວ່າງ doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // ຄວາມປອດໄພ: ເບິ່ງ `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, ແທ້ຈິງເຫຼົ່ານີ້ໃຊ້ເວລາຕົວຊີ້ວັດຖຸດິບເນື່ອງຈາກວ່າພວກເຂົາເຈົ້າ mutate ຫນ່ວຍຄວາມຈໍາ aliased, ທີ່ບໍ່ຖືກຕ້ອງສໍາລັບການບໍ່ວ່າຈະ `&` ຫຼື `&mut`.
    //

    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຕິປັນຍານີ້ມີຢູ່ໃນປະເພດ [`atomic`] ໂດຍຜ່ານວິທີ `compare_exchange` ໂດຍຜ່ານ [`Ordering::SeqCst`] ທັງສອງຕົວກໍານົດ `success` ແລະ `failure`.
    ///
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຕິປັນຍານີ້ມີຢູ່ໃນປະເພດ [`atomic`] ໂດຍຜ່ານວິທີ `compare_exchange` ໂດຍຜ່ານ [`Ordering::Acquire`] ທັງສອງຕົວກໍານົດ `success` ແລະ `failure`.
    ///
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `compare_exchange` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `success` ແລະ [`Ordering::Relaxed`] ເປັນຕົວ ກຳ ນົດ `failure`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `compare_exchange` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `success` ແລະ [`Ordering::Acquire`] ເປັນຕົວ ກຳ ນົດ `failure`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `compare_exchange` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນທັງສອງຕົວກໍານົດການ `success` ແລະ `failure`.
    ///
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `compare_exchange` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `success` ແລະ [`Ordering::Relaxed`] ເປັນຕົວກໍານົດ `failure`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `compare_exchange` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `success` ແລະ [`Ordering::Acquire`] ເປັນຕົວ ກຳ ນົດ `failure`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `compare_exchange` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `success` ແລະ [`Ordering::Relaxed`] ເປັນຕົວກໍານົດ `failure`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `compare_exchange` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `success` ແລະ [`Ordering::Relaxed`] ເປັນຕົວ ກຳ ນົດ `failure`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຕິປັນຍານີ້ມີຢູ່ໃນປະເພດ [`atomic`] ໂດຍຜ່ານວິທີ `compare_exchange_weak` ໂດຍຜ່ານ [`Ordering::SeqCst`] ທັງສອງຕົວກໍານົດ `success` ແລະ `failure`.
    ///
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `compare_exchange_weak` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນທັງສອງຕົວກໍານົດການ `success` ແລະ `failure`.
    ///
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `compare_exchange_weak` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `success` ແລະ [`Ordering::Relaxed`] ເປັນຕົວກໍານົດ `failure`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `compare_exchange_weak` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `success` ແລະ [`Ordering::Acquire`] ເປັນຕົວ ກຳ ນົດ `failure`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `compare_exchange_weak` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນທັງສອງຕົວກໍານົດການ `success` ແລະ `failure`.
    ///
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `compare_exchange_weak` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `success` ແລະ [`Ordering::Relaxed`] ເປັນຕົວກໍານົດ `failure`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `compare_exchange_weak` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `success` ແລະ [`Ordering::Acquire`] ເປັນຕົວກໍານົດ `failure`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `compare_exchange_weak` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `success` ແລະ [`Ordering::Relaxed`] ເປັນຕົວກໍານົດ `failure`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ເກັບຮັກສາມູນຄ່າຖ້າມູນຄ່າປັດຈຸບັນແມ່ນຄືກັນກັບມູນຄ່າ `old`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `compare_exchange_weak` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `success` ແລະ [`Ordering::Relaxed`] ເປັນຕົວກໍານົດ `failure`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// ໂຫລດມູນຄ່າໃນປະຈຸບັນຂອງຕົວຊີ້.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `load` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// ໂຫລດມູນຄ່າໃນປະຈຸບັນຂອງຕົວຊີ້.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `load` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// ໂຫລດມູນຄ່າໃນປະຈຸບັນຂອງຕົວຊີ້.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `load` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// ຮ້ານຄ່າຢູ່ສະຖານທີ່ຫນ່ວຍຄວາມຈໍາທີ່ລະບຸໄດ້.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `store` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// ຮ້ານຄ່າຢູ່ສະຖານທີ່ຫນ່ວຍຄວາມຈໍາທີ່ລະບຸໄດ້.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `store` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// ຮ້ານຄ່າຢູ່ສະຖານທີ່ຫນ່ວຍຄວາມຈໍາທີ່ລະບຸໄດ້.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `store` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// ເກັບຄ່າສະຖານທີ່ຫນ່ວຍຄວາມຈໍາທີ່ກໍານົດໄວ້ໄດ້, ກັບຄືນມູນຄ່າຍຸ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `swap` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// ເກັບຄ່າສະຖານທີ່ຫນ່ວຍຄວາມຈໍາທີ່ກໍານົດໄວ້ໄດ້, ກັບຄືນມູນຄ່າຍຸ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `swap` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ເກັບຄ່າສະຖານທີ່ຫນ່ວຍຄວາມຈໍາທີ່ກໍານົດໄວ້ໄດ້, ກັບຄືນມູນຄ່າຍຸ.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `swap` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ເກັບຄ່າສະຖານທີ່ຫນ່ວຍຄວາມຈໍາທີ່ກໍານົດໄວ້ໄດ້, ກັບຄືນມູນຄ່າຍຸ.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `swap` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ເກັບຄ່າສະຖານທີ່ຫນ່ວຍຄວາມຈໍາທີ່ກໍານົດໄວ້ໄດ້, ກັບຄືນມູນຄ່າຍຸ.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `swap` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ຕື່ມໃສ່ມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_add` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// ຕື່ມໃສ່ມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_add` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ຕື່ມໃສ່ມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_add` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ຕື່ມໃສ່ມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_add` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ຕື່ມໃສ່ມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_add` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ການຫັກລົບຈາກມູນຄ່າໃນປະຈຸບັນ, ກັບຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_sub` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// ການຫັກລົບຈາກມູນຄ່າໃນປະຈຸບັນ, ກັບຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_sub` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ການຫັກລົບຈາກມູນຄ່າໃນປະຈຸບັນ, ກັບຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_sub` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ການຫັກລົບຈາກມູນຄ່າໃນປະຈຸບັນ, ກັບຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_sub` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ການຫັກລົບຈາກມູນຄ່າໃນປະຈຸບັນ, ກັບຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `fetch_sub` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise ແລະກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_and` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ແລະກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_and` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ແລະກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_and` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ແລະກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_and` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ແລະກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_and` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand ກັບມູນຄ່າປັດຈຸບັນ, ກັບຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ສາມາດໃຊ້ໄດ້ກັບປະເພດ [`AtomicBool`] ຜ່ານວິທີການ `fetch_nand` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ກັບມູນຄ່າປັດຈຸບັນ, ກັບຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຕິປັນຍານີ້ມີຢູ່ໃນປະເພດ [`AtomicBool`] ຜ່ານວິທີ `fetch_nand` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ກັບມູນຄ່າປັດຈຸບັນ, ກັບຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ສາມາດໃຊ້ໄດ້ກັບປະເພດ [`AtomicBool`] ຜ່ານວິທີການ `fetch_nand` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ກັບມູນຄ່າປັດຈຸບັນ, ກັບຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ສາມາດໃຊ້ໄດ້ກັບປະເພດ [`AtomicBool`] ຜ່ານວິທີການ `fetch_nand` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand ກັບມູນຄ່າປັດຈຸບັນ, ກັບຄືນມູນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ສາມາດໃຊ້ໄດ້ກັບປະເພດ [`AtomicBool`] ຜ່ານວິທີການ `fetch_nand` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise ຫຼືກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_or` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ຫຼືກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `fetch_or` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ຫຼືກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_or` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ຫຼືກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_or` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise ຫຼືກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_or` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// x Bitwise xor ກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_xor` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// x Bitwise xor ກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_xor` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// x Bitwise xor ກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_xor` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// x Bitwise xor ກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີ `fetch_xor` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// x Bitwise xor ກັບມູນຄ່າປັດຈຸບັນ, ສົ່ງຄືນຄ່າທີ່ຜ່ານມາ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນປະເພດ [`atomic`] ຜ່ານວິທີການ `fetch_xor` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ສູງສຸດທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ການປຽບທຽບເຊັນ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ເຊັນ integer ປະເພດຜ່ານການວິທີການ `fetch_max` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// ສູງສຸດທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ການປຽບທຽບເຊັນ.
    ///
    /// ຮຸ່ນຄົງທີ່ຂອງສະຖາປັດຕະຍະ ກຳ ນີ້ແມ່ນມີຢູ່ໃນປະເພດເລກເຕັມເຊັນທີ່ [`atomic`] ຜ່ານວິທີ `fetch_max` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ສູງສຸດທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ການປຽບທຽບເຊັນ.
    ///
    /// ຮຸ່ນຄົງທີ່ຂອງສະຖາປັດຕະຍະ ກຳ ນີ້ແມ່ນມີຢູ່ໃນປະເພດເລກເຕັມເຊັນທີ່ [`atomic`] ຜ່ານວິທີ `fetch_max` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ສູງສຸດທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ການປຽບທຽບເຊັນ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ເຊັນ integer ປະເພດຜ່ານການວິທີການ `fetch_max` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ສູງສຸດທີ່ມີມູນຄ່າໃນປະຈຸບັນ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ເຊັນ integer ປະເພດຜ່ານການວິທີການ `fetch_max` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ຂັ້ນຕ່ໍາທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ການປຽບທຽບເຊັນ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ເຊັນ integer ປະເພດຜ່ານການວິທີການ `fetch_min` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// ຂັ້ນຕ່ໍາທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ການປຽບທຽບເຊັນ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ເຊັນ integer ປະເພດຜ່ານການວິທີການ `fetch_min` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ຂັ້ນຕ່ໍາທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ການປຽບທຽບເຊັນ.
    ///
    /// ຮຸ່ນຄົງທີ່ຂອງສະຖາປັດຕະຍະ ກຳ ນີ້ແມ່ນມີຢູ່ໃນປະເພດເລກເຕັມເຊັນທີ່ [`atomic`] ຜ່ານວິທີ `fetch_min` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ຂັ້ນຕ່ໍາທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ການປຽບທຽບເຊັນ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ເຊັນ integer ປະເພດຜ່ານການວິທີການ `fetch_min` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ຂັ້ນຕ່ໍາທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ການປຽບທຽບເຊັນ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ເຊັນ integer ປະເພດຜ່ານການວິທີການ `fetch_min` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ຂັ້ນຕ່ໍາທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ເປັນການປຽບທຽບທີ່ບໍ່ໄດ້ລົງ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ປະເພດ integer unsigned ຜ່ານວິທີການ `fetch_min` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// ຂັ້ນຕ່ໍາທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ເປັນການປຽບທຽບທີ່ບໍ່ໄດ້ລົງ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ປະເພດ integer unsigned ຜ່ານວິທີການ `fetch_min` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ຂັ້ນຕ່ໍາທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ເປັນການປຽບທຽບທີ່ບໍ່ໄດ້ລົງ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ປະເພດ integer unsigned ຜ່ານວິທີການ `fetch_min` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ຂັ້ນຕ່ໍາທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ເປັນການປຽບທຽບທີ່ບໍ່ໄດ້ລົງ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ປະເພດ integer unsigned ຜ່ານວິທີການ `fetch_min` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ຂັ້ນຕ່ໍາທີ່ມີມູນຄ່າໃນປະຈຸບັນການນໍາໃຊ້ເປັນການປຽບທຽບທີ່ບໍ່ໄດ້ລົງ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ປະເພດ integer unsigned ຜ່ານວິທີການ `fetch_min` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ສູງສຸດກັບມູນຄ່າປັດຈຸບັນໂດຍໃຊ້ການປຽບທຽບທີ່ບໍ່ໄດ້ລົງນາມ.
    ///
    /// ຮຸ່ນຄົງທີ່ຂອງສະຕິປັນຍານີ້ແມ່ນມີຢູ່ໃນປະເພດເລກເຕັມທີ່ບໍ່ໄດ້ລົງນາມ [`atomic`] ຜ່ານວິທີ `fetch_max` ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// ສູງສຸດກັບມູນຄ່າປັດຈຸບັນໂດຍໃຊ້ການປຽບທຽບທີ່ບໍ່ໄດ້ລົງນາມ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ປະເພດ integer unsigned ຜ່ານວິທີການ `fetch_max` ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ສູງສຸດກັບມູນຄ່າປັດຈຸບັນໂດຍໃຊ້ການປຽບທຽບທີ່ບໍ່ໄດ້ລົງນາມ.
    ///
    /// ຮຸ່ນຄົງທີ່ຂອງສະຕິປັນຍານີ້ແມ່ນມີຢູ່ໃນປະເພດເລກເຕັມທີ່ບໍ່ໄດ້ລົງນາມ [`atomic`] ຜ່ານວິທີ `fetch_max` ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ສູງສຸດກັບມູນຄ່າປັດຈຸບັນໂດຍໃຊ້ການປຽບທຽບທີ່ບໍ່ໄດ້ລົງນາມ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ປະເພດ integer unsigned ຜ່ານວິທີການ `fetch_max` ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ສູງສຸດກັບມູນຄ່າປັດຈຸບັນໂດຍໃຊ້ການປຽບທຽບທີ່ບໍ່ໄດ້ລົງນາມ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ [`atomic`] ປະເພດ integer unsigned ຜ່ານວິທີການ `fetch_max` ໂດຍຜ່ານ [`Ordering::Relaxed`] ເປັນ `order`.
    /// ຍົກຕົວຢ່າງ, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// The `prefetch` intrinsic ເປັນ hint ເປັນໂດຍທົ່ວໄປລະຫັດໃນການສະແດງກິ່ງງ່າສອນ prefetch ເປັນຖ້າຫາກວ່າສະຫນັບສະຫນຸນເປັນ;ຖ້າບໍ່ດັ່ງນັ້ນ, ມັນແມ່ນບໍ່ມີ.
    /// prefetch ມີຜົນກະທົບກ່ຽວກັບການເຮັດວຽກຂອງໂຄງການໄດ້ແຕ່ສາມາດມີການປ່ຽນແປງລັກສະນະປະສິດທິພາບຂອງຕົນ.
    ///
    /// ການອະພິປາຍ `locality` ຕ້ອງເປັນຈໍານວນເຕັມຄົງທີ່ແລະເປັນບຸໂລກທ້ອງຖິ່ນຕັ້ງແຕ່ (0), ທ້ອງຖິ່ນບໍ່ມີ, ເພື່ອ (3), ສຸດ keep ທ້ອງຖິ່ນໃນຖານຄວາມຈໍາ.
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// The `prefetch` intrinsic ເປັນ hint ເປັນໂດຍທົ່ວໄປລະຫັດໃນການສະແດງກິ່ງງ່າສອນ prefetch ເປັນຖ້າຫາກວ່າສະຫນັບສະຫນຸນເປັນ;ຖ້າບໍ່ດັ່ງນັ້ນ, ມັນແມ່ນບໍ່ມີ.
    /// prefetch ມີຜົນກະທົບກ່ຽວກັບການເຮັດວຽກຂອງໂຄງການໄດ້ແຕ່ສາມາດມີການປ່ຽນແປງລັກສະນະປະສິດທິພາບຂອງຕົນ.
    ///
    /// ການອະພິປາຍ `locality` ຕ້ອງເປັນຈໍານວນເຕັມຄົງທີ່ແລະເປັນບຸໂລກທ້ອງຖິ່ນຕັ້ງແຕ່ (0), ທ້ອງຖິ່ນບໍ່ມີ, ເພື່ອ (3), ສຸດ keep ທ້ອງຖິ່ນໃນຖານຄວາມຈໍາ.
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// The `prefetch` intrinsic ເປັນ hint ເປັນໂດຍທົ່ວໄປລະຫັດໃນການສະແດງກິ່ງງ່າສອນ prefetch ເປັນຖ້າຫາກວ່າສະຫນັບສະຫນຸນເປັນ;ຖ້າບໍ່ດັ່ງນັ້ນ, ມັນແມ່ນບໍ່ມີ.
    /// prefetch ມີຜົນກະທົບກ່ຽວກັບການເຮັດວຽກຂອງໂຄງການໄດ້ແຕ່ສາມາດມີການປ່ຽນແປງລັກສະນະປະສິດທິພາບຂອງຕົນ.
    ///
    /// ການອະພິປາຍ `locality` ຕ້ອງເປັນຈໍານວນເຕັມຄົງທີ່ແລະເປັນບຸໂລກທ້ອງຖິ່ນຕັ້ງແຕ່ (0), ທ້ອງຖິ່ນບໍ່ມີ, ເພື່ອ (3), ສຸດ keep ທ້ອງຖິ່ນໃນຖານຄວາມຈໍາ.
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// The `prefetch` intrinsic ເປັນ hint ເປັນໂດຍທົ່ວໄປລະຫັດໃນການສະແດງກິ່ງງ່າສອນ prefetch ເປັນຖ້າຫາກວ່າສະຫນັບສະຫນຸນເປັນ;ຖ້າບໍ່ດັ່ງນັ້ນ, ມັນແມ່ນບໍ່ມີ.
    /// prefetch ມີຜົນກະທົບກ່ຽວກັບການເຮັດວຽກຂອງໂຄງການໄດ້ແຕ່ສາມາດມີການປ່ຽນແປງລັກສະນະປະສິດທິພາບຂອງຕົນ.
    ///
    /// ການອະພິປາຍ `locality` ຕ້ອງເປັນຈໍານວນເຕັມຄົງທີ່ແລະເປັນບຸໂລກທ້ອງຖິ່ນຕັ້ງແຕ່ (0), ທ້ອງຖິ່ນບໍ່ມີ, ເພື່ອ (3), ສຸດ keep ທ້ອງຖິ່ນໃນຖານຄວາມຈໍາ.
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// ຮົ້ວປະລໍາມະນູ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ສາມາດໃຊ້ໄດ້ໃນ [`atomic::fence`] ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    ///
    ///
    pub fn atomic_fence();
    /// ຮົ້ວປະລໍາມະນູ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ສາມາດໃຊ້ໄດ້ໃນ [`atomic::fence`] ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// ຮົ້ວປະລໍາມະນູ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ສາມາດໃຊ້ໄດ້ໃນ [`atomic::fence`] ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// ຮົ້ວປະລໍາມະນູ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ສາມາດໃຊ້ໄດ້ໃນ [`atomic::fence`] ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// A compiler ເທົ່ານັ້ນອຸປະສັກຄວາມຊົງຈໍາ.
    ///
    /// ຈໍານວນຫນ່ວຍຄວາມຈໍາຈະບໍ່ໄດ້ຮັບການ reordered ທົ່ວອຸປະສັກນີ້ໂດຍ compiler ໄດ້, ແຕ່ຄໍາແນະນໍາທີ່ບໍ່ມີຈະໄດ້ຮັບການປ່ອຍອອກມາສໍາລັບການມັນ.
    /// ນີ້ແມ່ນເຫມາະສົມສໍາລັບການປະຕິບັດງານກ່ຽວກັບການກະທູ້ດຽວກັນທີ່ອາດຈະໄດ້ຮັບ preempted ເຊັ່ນໃນເວລາທີ່ປະຕິສໍາພັນກັບຕົວຈັດການສັນຍານ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ສາມາດໃຊ້ໄດ້ໃນ [`atomic::compiler_fence`] ໂດຍຜ່ານ [`Ordering::SeqCst`] ເປັນ `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// A compiler ເທົ່ານັ້ນອຸປະສັກຄວາມຊົງຈໍາ.
    ///
    /// ຈໍານວນຫນ່ວຍຄວາມຈໍາຈະບໍ່ໄດ້ຮັບການ reordered ທົ່ວອຸປະສັກນີ້ໂດຍ compiler ໄດ້, ແຕ່ຄໍາແນະນໍາທີ່ບໍ່ມີຈະໄດ້ຮັບການປ່ອຍອອກມາສໍາລັບການມັນ.
    /// ນີ້ແມ່ນເຫມາະສົມສໍາລັບການປະຕິບັດງານກ່ຽວກັບການກະທູ້ດຽວກັນທີ່ອາດຈະໄດ້ຮັບ preempted ເຊັ່ນໃນເວລາທີ່ປະຕິສໍາພັນກັບຕົວຈັດການສັນຍານ.
    ///
    /// ສະບັບທີ່ມີສະຖຽນລະພາບຂອງກາບກອນນີ້ມີຢູ່ໃນ [`atomic::compiler_fence`] ໂດຍຜ່ານ [`Ordering::Acquire`] ເປັນ `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// A compiler ເທົ່ານັ້ນອຸປະສັກຄວາມຊົງຈໍາ.
    ///
    /// ຈໍານວນຫນ່ວຍຄວາມຈໍາຈະບໍ່ໄດ້ຮັບການ reordered ທົ່ວອຸປະສັກນີ້ໂດຍ compiler ໄດ້, ແຕ່ຄໍາແນະນໍາທີ່ບໍ່ມີຈະໄດ້ຮັບການປ່ອຍອອກມາສໍາລັບການມັນ.
    /// ນີ້ແມ່ນເຫມາະສົມສໍາລັບການປະຕິບັດງານກ່ຽວກັບການກະທູ້ດຽວກັນທີ່ອາດຈະໄດ້ຮັບ preempted ເຊັ່ນໃນເວລາທີ່ປະຕິສໍາພັນກັບຕົວຈັດການສັນຍານ.
    ///
    /// ສະບັບທີ່ມີສະຖຽນລະພາບຂອງກາບກອນນີ້ມີຢູ່ໃນ [`atomic::compiler_fence`] ໂດຍຜ່ານ [`Ordering::Release`] ເປັນ `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// A compiler ເທົ່ານັ້ນອຸປະສັກຄວາມຊົງຈໍາ.
    ///
    /// ຈໍານວນຫນ່ວຍຄວາມຈໍາຈະບໍ່ໄດ້ຮັບການ reordered ທົ່ວອຸປະສັກນີ້ໂດຍ compiler ໄດ້, ແຕ່ຄໍາແນະນໍາທີ່ບໍ່ມີຈະໄດ້ຮັບການປ່ອຍອອກມາສໍາລັບການມັນ.
    /// ນີ້ແມ່ນເຫມາະສົມສໍາລັບການປະຕິບັດງານກ່ຽວກັບການກະທູ້ດຽວກັນທີ່ອາດຈະໄດ້ຮັບ preempted ເຊັ່ນໃນເວລາທີ່ປະຕິສໍາພັນກັບຕົວຈັດການສັນຍານ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ສາມາດໃຊ້ໄດ້ໃນ [`atomic::compiler_fence`] ໂດຍຜ່ານ [`Ordering::AcqRel`] ເປັນ `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// intrinsic Magic ທີ່ມາຄວາມຫມາຍຂອງຕົນຈາກຄຸນລັກສະນະທີ່ຂຶ້ນກັບການເຄື່ອນໄຫວ.
    ///
    /// ຍົກຕົວຢ່າງ, ຂໍ້ມູນການ ນຳ ໃຊ້ຂໍ້ມູນນີ້ເພື່ອສັກເອົາການຢືນຢັນແບບຄົງທີ່ເພື່ອວ່າ `rustc_peek(potentially_uninitialized)` ຈະກວດສອບສອງຄັ້ງວ່າຕົວເລກຂໍ້ມູນຕົວຈິງໄດ້ ຄຳ ນວນວ່າມັນບໍ່ມີຄຸນຄ່າໃນຈຸດນັ້ນໃນກະແສຄວບຄຸມ.
    ///
    ///
    /// ຄວາມຈິງທີ່ວ່ານີ້ບໍ່ຄວນໃຊ້ຢູ່ນອກເຄື່ອງລວບລວມຂໍ້ມູນ.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// ຍົກເລີກການປະຕິບັດຂັ້ນຕອນ.
    ///
    /// A ຫຼາຍຜູ້ເປັນມິດແລະຄວາມຫມັ້ນຄົງສະບັບພາສາຂອງປະຕິບັດງານນີ້ແມ່ນ [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// ແຈ້ງດີທີ່ສຸດທີ່ຈຸດນີ້ໃນລະຫັດແມ່ນບໍ່ສາມາດເຂົ້າເຖິງ, ເຮັດໃຫ້ດີທີ່ສຸດໃນຕໍ່ຫນ້າ.
    ///
    /// NB, ນີ້ແມ່ນແຕກຕ່າງຈາກມະຫາພາກ `unreachable!()`: ແຕກຕ່າງຈາກມະຫາພາກ, ເຊິ່ງ panics ເມື່ອຖືກປະຕິບັດ, ມັນແມ່ນ *ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ* ເພື່ອບັນລຸລະຫັດທີ່ຖືກ ໝາຍ ດ້ວຍ ໜ້າ ທີ່ນີ້.
    ///
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ແມ່ນ [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// ແຈ້ງໃຫ້ຜູ້ທີ່ດີທີ່ສຸດຮູ້ວ່າສະພາບການແມ່ນຖືກຕ້ອງສະ ເໝີ ໄປ.
    /// ຖ້າຫາກວ່າສະພາບທີ່ເປັນທີ່ບໍ່ຖືກຕ້ອງ, ພຶດຕິກໍາໄດ້ຖືກ undefined.
    ///
    /// ລະຫັດບໍ່ຖືກສ້າງຂື້ນສໍາລັບທີ່ແທ້ຈິງດັ່ງກ່າວນີ້, ແຕ່ດີທີ່ສຸດທີ່ຈະພະຍາຍາມປົກປັກຮັກສາມັນ (ແລະສະພາບຂອງຕົນ) ລະຫວ່າງຜ່ານ, ເຊິ່ງອາດຈະແຊກແຊງກັບທີ່ດີທີ່ສຸດຂອງລະຫັດອ້ອມຂ້າງແລະຫຼຸດຜ່ອນປະສິດທິພາບ.
    /// ມັນບໍ່ຄວນຈະໄດ້ຮັບການນໍາໃຊ້ຖ້າຫາກວ່າຄົງສາມາດໄດ້ຮັບການຄົ້ນພົບໂດຍ optimizer ໃນຂອງຕົນເອງ, ຫຼືຖ້າຫາກວ່າມັນບໍ່ໄດ້ເຮັດໃຫ້ດີທີ່ສຸດທີ່ສໍາຄັນ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// ຄໍາແນະນໍາທີ່ຈະລວບລວມທີ່ສະພາບ branch ເປັນແນວໂນ້ມທີ່ຈະເປັນຄວາມຈິງ.
    /// ສົ່ງຄືນຄ່າຜ່ານໄປມັນ.
    ///
    /// ການ ນຳ ໃຊ້ນອກ ເໜືອ ຈາກ ຄຳ ຖະແຫຼງການ `if` ອາດຈະບໍ່ມີຜົນຫຍັງເລີຍ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// ຄຳ ແນະ ນຳ ຕໍ່ຜູ້ຂຽນວ່າສະພາບຂອງ branch ມີແນວໂນ້ມທີ່ຈະບໍ່ຖືກຕ້ອງ.
    /// ສົ່ງຄືນຄ່າຜ່ານໄປມັນ.
    ///
    /// ການ ນຳ ໃຊ້ນອກ ເໜືອ ຈາກ ຄຳ ຖະແຫຼງການ `if` ອາດຈະບໍ່ມີຜົນຫຍັງເລີຍ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// ປະຕິບັດການດັກຈຸດ, ສໍາລັບການກວດກາໂດຍ debugger.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn breakpoint();

    /// ຂະ ໜາດ ຂອງຊະນິດ ໜຶ່ງ ເປັນໄບ.
    ///
    /// ຫຼາຍໂດຍສະເພາະ, ນີ້ແມ່ນການຊົດເຊີຍໃນ bytes ລະຫວ່າງລາຍການຄວາມສໍາເລັດຂອງປະເພດດຽວກັນ, ລວມທັງການຈັດຕໍາແຫນ່ງ padding.
    ///
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ແມ່ນ [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// ການຈັດຕໍາ່ສຸດທີ່ຂອງປະເພດໃດ ໜຶ່ງ.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ແມ່ນ [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// ການຈັດຕໍາແຫນ່ງທີ່ຕ້ອງການຈາກປະເພດນີ້ໄດ້.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// ຂະ ໜາດ ຂອງມູນຄ່າທີ່ອ້າງອີງເປັນໄບ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນ [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// ຄວາມສອດຄ່ອງທີ່ຕ້ອງການຂອງມູນຄ່າທີ່ອ້າງອີງ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນ [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// ໃສ່ຊິ້ນເຊືອກສະຖິດທີ່ມີຊື່ຂອງປະເພດ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນ [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// ໄດ້ຮັບບຸຊຶ່ງເປັນລະດັບໂລກບໍ່ຊ້ໍາກັບປະເພດທີ່ລະບຸໄດ້.
    /// ຟັງຊັນນີ້ຈະກັບຄືນມູນຄ່າດຽວກັນສໍາລັບປະເພດການບໍ່ຄໍານຶງເຖິງອັນໃດກໍໄດ້ crate ມັນແມ່ນຍົກຂຶ້ນມາອ້າງໃນ.
    ///
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ແມ່ນ [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// A ກອງສໍາລັບການເຮັດວຽກທີ່ບໍ່ປອດໄພທີ່ບໍ່ສາມາດເຄີຍໄດ້ຮັບການປະຕິບັດຖ້າຫາກວ່າ `T` ເປັນ uninhabited:
    /// ສິ່ງນີ້ຈະເປັນ panic, ຫຼືບໍ່ເຮັດຫຍັງເລີຍ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// A ກອງສໍາລັບການເຮັດວຽກທີ່ບໍ່ປອດໄພທີ່ບໍ່ສາມາດເຄີຍໄດ້ຮັບການປະຕິບັດຖ້າຫາກວ່າ `T` ບໍ່ອະນຸຍາດໃຫ້ສູນ, ຂຽນອັກສອນຫຍໍ້: ນີ້ຄົງຈະບໍ່ວ່າຈະ panic, ຫຼືເຮັດຫຍັງ.
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn assert_zero_valid<T>();

    /// A ກອງສໍາລັບການເຮັດວຽກທີ່ບໍ່ປອດໄພທີ່ບໍ່ສາມາດເຄີຍໄດ້ຮັບການປະຕິບັດຖ້າຫາກວ່າ `T` ມີຮູບແບບ bit ບໍ່ຖືກຕ້ອງ: ນີ້ຄົງຈະບໍ່ວ່າຈະ panic, ຫຼືເຮັດຫຍັງ.
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn assert_uninit_valid<T>();

    /// ໄດ້ຮັບການກະສານອ້າງອີງເປັນ static `Location` ຊີ້ບອກບ່ອນທີ່ມັນຖືກເອີ້ນ.
    ///
    /// ພິຈາລະນາການນໍາໃຊ້ [`core::panic::Location::caller`](crate::panic::Location::caller) ແທນທີ່ຈະ.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// ຍ້າຍຄ່າອອກຈາກຂອບເຂດໂດຍບໍ່ຕ້ອງໃຊ້ກາວເລື່ອນ.
    ///
    /// ນີ້ລາຄາ: solely ສໍາລັບ [`mem::forget_unsized`];ປົກກະຕິ `forget` ໃຊ້ `ManuallyDrop` ແທນທີ່ຈະ.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Reinterprets bits ຂອງມູນຄ່າຂອງປະເພດຫນຶ່ງເປັນປະເພດອື່ນ.
    ///
    /// ທັງສອງປະເພດຕ້ອງມີຂະຫນາດດຽວກັນ.
    /// ທັງຕົ້ນສະບັບ, ແລະຜົນໄດ້ຮັບ, ອາດຈະບໍ່ແມ່ນ [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` ແມ່ນຫມາຍທຽບເທົ່າກັບການເຄື່ອນໄຫວຄ່າທີ່ເຫມາະສົມຂອງປະເພດຫນຶ່ງໄປຍັງອີກ.ມັນສໍາເນົາ bits ຈາກມູນຄ່າແຫລ່ງເຂົ້າໄປໃນມູນຄ່າຈຸດຫມາຍປາຍທາງໄດ້, ຫຼັງຈາກນັ້ນລືມຕົ້ນສະບັບ.
    /// ມັນທຽບເທົ່າກັບຂອງ C `memcpy` ພາຍໃຕ້ການ Hood, ຄືກັນກັບ `transmute_copy`.
    ///
    /// ເນື່ອງຈາກວ່າ `transmute` ແມ່ນການ ດຳ ເນີນງານທີ່ມີມູນຄ່າ, ການຈັດວາງຄ່າຂອງຄ່າ *transmuted ດ້ວຍຕົນເອງ* ບໍ່ແມ່ນຄວາມກັງວົນໃຈ.
    /// ເຊັ່ນດຽວກັນກັບການທໍາງານຂອງອື່ນໆ, compiler ໄດ້ແລ້ວຮັບປະກັນທັງສອງ `T` ແລະ `U` ແມ່ນສອດຄ່ອງເຫມາະສົມ.
    /// ຢ່າງໃດກໍຕາມ, ໃນເວລາທີ່ transmuting ຄ່າທີ່ຈຸດ *ບ່ອນອື່ນ*(ເຊັ່ນ: ຕົວຊີ້, ເອກະສານ, ຕູ້ ...), ແປໄດ້ທຸມີເພື່ອຮັບປະກັນຄວາມສອດຄ່ອງເຫມາະສົມຂອງຄ່າແຫຼມກັບ.
    ///
    /// `transmute` ເປັນ **incredibly** ບໍ່ປອດໄພ.ມີຫລາຍໆວິທີທີ່ຈະເຮັດໃຫ້ [undefined behavior][ub] ມີ ໜ້າ ທີ່ນີ້.`transmute` ຄວນຈະທີ່ເພິ່ງສຸດທ້າຍຢ່າງແທ້ຈິງ.
    ///
    /// The [nomicon](../../nomicon/transmutes.html) ມີເອກະສານເພີ່ມເຕີມ.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ມີສອງສາມຢ່າງທີ່ `transmute` ມີປະໂຫຍດຫລາຍ ສຳ ລັບ.
    ///
    /// ເປີດຕົວຊີ້ເປັນຊີ້ຫນ້າທີ່ເປັນ.ນີ້ແມ່ນ *ບໍ່* A Portable ເພື່ອໃຫ້ເຄື່ອງທີ່ຊີ້ຫນ້າທີ່ແລະຊີ້ຂໍ້ມູນມີຂະຫນາດທີ່ແຕກຕ່າງກັນ.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// ການຍືດອາຍຸການໃຊ້ງານຕະຫຼອດຊີວິດ, ຫລືຫຼຸດຜ່ອນອາຍຸການສະແດງ.ນີ້ແມ່ນກ້າວຫນ້າ, Rust ທີ່ບໍ່ປອດໄພຫຼາຍ!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// ຢ່າ ໝົດ ຫວັງ: ການໃຊ້ `transmute` ຫຼາຍໆຢ່າງສາມາດເຮັດໄດ້ໂດຍຜ່ານວິທີອື່ນ.
    /// ຂ້າງລຸ່ມນີ້ແມ່ນ ຄຳ ຮ້ອງສະ ໝັກ ທົ່ວໄປຂອງ `transmute` ເຊິ່ງສາມາດທົດແທນໄດ້ດ້ວຍການກໍ່ສ້າງທີ່ປອດໄພກວ່າ.
    ///
    /// ຫັນ bytes(`&[u8]`) ຖຸດິບເພື່ອ `u32`, `f64`, ແລະອື່ນໆ .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // ໃຊ້ `u32::from_ne_bytes` ແທນ
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ຫຼືນໍາໃຊ້ `u32::from_le_bytes` ຫຼື `u32::from_be_bytes` ລະບຸ endian ໄດ້
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// ປ່ຽນຕົວຊີ້ເປັນ `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // ໃຊ້ໂຕລະຄອນ `as` ແທນ
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// ປ່ຽນເປັນສີເປັນ `*mut T` ສູ່ `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // ໃຊ້ reborrow ແທນ
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// ຫັນເປັນ `&mut T` ສູ່ `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // ໃນປັດຈຸບັນ, ເອົາໃຈໃສ່ຮ່ວມກັນ `as` ແລະ reborrowing, ສັງເກດໂສ້ຂອງ `as` `as` ແມ່ນບໍ່ຜ່ານແດນ
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// ປ່ຽນ `&str` ເປັນ `&[u8]`:
    ///
    /// ```
    /// // ນີ້ບໍ່ແມ່ນທາງທີ່ດີທີ່ຈະເຮັດແນວນີ້.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // ທ່ານສາມາດນໍາໃຊ້ `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // ຫຼື, ພຽງແຕ່ນໍາໃຊ້ສະຕິງ byte ເປັນ, ຖ້າຫາກວ່າທ່ານມີການຄວບຄຸມໃນໄລຍະທີ່ຮູ້ຫນັງສືຊ່ອຍແນ່
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// ປ່ຽນເປັນສີເປັນ `Vec<&T>` ໃນ `Vec<Option<&T>>`.
    ///
    /// ການປ່ຽນຊະນິດໃນຂອງເນື້ອໃນຂອງມັນບັນຈຸ, ທ່ານຈະຕ້ອງເຮັດໃຫ້ແນ່ໃຈວ່າຈະບໍ່ລະເມີດຂອງຄາຄົງຊະນະບັນຈຸຂອງ.
    /// ສໍາລັບ `Vec`, ນີ້ຫມາຍຄວາມວ່າທີ່ທັງສອງຂະຫນາດ *ແລະຄວາມສອດຄ່ອງ* ປະເພດໃນຈໍາເປັນຕ້ອງກົງກັນ.
    /// ເຄື່ອງໃຊ້ອື່ນໆອາດຈະແມ່ນເອື່ອຍອີງໃສ່ຂະຫນາດຂອງປະເພດ, ຄວາມສອດຄ່ອງ, ຫຼືແມ້ກະທັ້ງການ `TypeId`, ໃນກໍລະນີໂຈແປງຮ່າງເປນເປັນໄປບໍ່ໄດ້ທີ່ທັງຫມົດໂດຍບໍ່ມີການລະເມີດຄາຄົງຊະນະບັນຈຸ.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone ຂອງ vector ດັ່ງທີ່ພວກເຮົາຈະນໍາມາໃຊ້ໃຫມ່ໃນພາຍຫລັງ
    /// let v_clone = v_orig.clone();
    ///
    /// // ການນໍາໃຊ້ການປ່ຽນ: ນີ້ຕົ້ນຕໍກ່ຽວກັບຮູບລັກຂໍ້ມູນລະບຸຂອງ `Vec`, ຊຶ່ງເປັນຄວາມຄິດທີ່ດີແລະສາມາດເຮັດໃຫ້ເກີດພຶດຕິກໍາຫນົດ.
    /////
    /// // ຢ່າງໃດກໍຕາມ, ມັນແມ່ນບໍ່ມີ, ສໍາເນົາ.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // ນີ້ແມ່ນວິທີທີ່ແນະ ນຳ, ປອດໄພ.
    /// // ມັນບໍ່ສໍາເນົາທັງຫມົດ vector, ເຖິງແມ່ນວ່າ, ໃນ array ໃຫມ່.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // ນີ້ແມ່ນເຫມາະສົມທີ່ບໍ່ມີ, ສໍາເນົາ, ວິທີການທີ່ບໍ່ປອດໄພຂອງ "transmuting" ເປັນ `Vec`, ໂດຍບໍ່ມີການອາໄສຢູ່ໃນຮູບແບບຂໍ້ມູນ.
    /// // ແທນທີ່ຈະອ່ານອອກຂຽນໄດ້ໂທຫາ `transmute`, ພວກເຮົາປະຕິບັດສຽງໂຫວດທັງຫມົດຊີ້, ແຕ່ວ່າໃນແງ່ຂອງການປະເພດໃນຕົ້ນສະບັບ (`&i32`) ກັບໃຫມ່ (`Option<&i32>`) ນີ້ມີ caveats ດຽວກັນທັງຫມົດ.
    /////
    /// // ນອກ ເໜືອ ຈາກຂໍ້ມູນທີ່ກ່າວມາຂ້າງເທິງ, ຍັງປຶກສາເອກະສານ [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME ປັບປຸງນີ້ເມື່ອ vec_into_raw_parts ມີສະຖຽນລະພາບ.
    ///     // ຮັບປະກັນວ່າ vector ເດີມບໍ່ລຸດລົງ.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// ການນໍາ `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // ມີຫຼາຍວິທີທີ່ຈະເຮັດແນວນີ້ແມ່ນ, ແລະບໍ່ມີບັນຫາຫຼາຍກັບວິທີການດັ່ງຕໍ່ໄປນີ້ (transmute).
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // ຄັ້ງທໍາອິດ: transmutation ບໍ່ໄດ້ພິມຄວາມປອດໄພ;ທັງຫມົດການກວດສອບວ່າມັນເປັນທີ່ T ແລະ
    ///         // U ແມ່ນຂະຫນາດດຽວກັນ.
    ///         // ຄັ້ງທີສອງ, ສິດທິໃນທີ່ນີ້, ທ່ານມີສອງເອກະສານທີ່ບໍ່ແນ່ນອນຊີ້ໄປຫາຫນ່ວຍຄວາມຈໍາດຽວກັນ.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // ນີ້ໄດ້ຮັບການກໍາຈັດບັນຫາຄວາມປອດໄພຂອງປະເພດ;`&mut *` ຈະ* ພຽງແຕ່ *ໃຫ້ທ່ານ `&mut T` ຈາກ `&mut T` ຫຼື `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // ເຖິງຢ່າງໃດກໍ່ຕາມ, ທ່ານຍັງມີສອງເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ເຊິ່ງຊີ້ໄປທີ່ຄວາມຊົງ ຈຳ ດຽວກັນ.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // ນີ້ແມ່ນວິທີທີ່ຫ້ອງສະມຸດມາດຕະຖານເຮັດ.
    /// // ນີ້ແມ່ນວິທີການທີ່ດີທີ່ສຸດ, ຖ້າທ່ານຕ້ອງການເຮັດບາງສິ່ງບາງຢ່າງເຊັ່ນນີ້
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // ປະຈຸບັນນີ້ມີເອກະສານອ້າງອີງທີ່ສາມາດປ່ຽນແປງໄດ້ສາມຢ່າງເຊິ່ງເປັນຈຸດດຽວກັນ.`slice`, Rvalue ret.0, ແລະ Rvalue ret.1.
    ///         // `slice` ບໍ່ເຄີຍໃຊ້ຫຼັງຈາກ `let ptr = ...`, ແລະດັ່ງນັ້ນ, ຄົນເຮົາສາມາດປະຕິບັດມັນເປັນ "dead", ແລະເພາະສະນັ້ນ, ທ່ານພຽງແຕ່ມີສອງແຜ່ນທີ່ສາມາດປ່ຽນແປງໄດ້ແທ້ໆ.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: ໃນຂະນະທີ່ນີ້ເຮັດໃຫ້ຄວາມຫມັ້ນຄົງຂອງ const intrinsic, ພວກເຮົາມີລະຫັດທີ່ກໍາຫນົດເອງບາງໃນ fn const
    // ການກວດສອບວ່າປ້ອງກັນບໍ່ໃຫ້ການນໍາໃຊ້ພາຍໃນ `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// ກັບຄືນ `true` ຖ້າປະເພດຕົວຈິງທີ່ມອບໃຫ້ເປັນ `T` ຕ້ອງໃຊ້ກາວຫຼຸດລົງ;ຜົນຕອບແທນ `false` ຖ້າປະເພດທີ່ແທ້ຈິງທີ່ສະຫນອງໃຫ້ສໍາລັບການປະຕິບັດ `T` `Copy`.
    ///
    ///
    /// ຖ້າຫາກວ່າປະເພດທີ່ແທ້ຈິງທີ່ບໍ່ຮຽກຮ້ອງໃຫ້ມີການຫຼຸດລົງກາວຫຼືປະຕິບັດ `Copy`, ຫຼັງຈາກນັ້ນໄດ້ຄ່າຕອບແທນຂອງການທໍາງານນີ້ແມ່ນບໍ່ໄດ້ລະບຸ.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ແມ່ນ [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// ຄິດໄລ່ຊົດເຊີຍຈາກຕົວຊີ້.
    ///
    /// ນີ້ແມ່ນປະຕິບັດເປັນທີ່ແທ້ຈິງເພື່ອຫຼີກເວັ້ນການແປງໄປຫາແລະຈາກ integer ເປັນ, ນັບຕັ້ງແຕ່ປ່ຽນໃຈເຫລື້ອມໃສຈະຖິ້ມທັນທີລົບຮອຍຫຍັກຂໍ້ມູນຂ່າວສານ.
    ///
    /// # Safety
    ///
    /// ທັງເລີ່ມຕົ້ນແລະສົ່ງຜົນໃຫ້ຊີ້ຕ້ອງບໍ່ວ່າຈະຢູ່ໃນຂອບເຂດຫຼືຫນຶ່ງ byte ທີ່ຜ່ານມາໃນຕອນທ້າຍຂອງວັດຖຸທີ່ຈັດສັນ.
    /// ຖ້າຫາກວ່າຕົວຊີ້ຢູ່ນອກຂອບເຂດຫລືການຄິດໄລ່ນ້ ຳ ເລກເລກເກີດຂື້ນ, ການ ນຳ ໃຊ້ມູນຄ່າທີ່ສົ່ງຄືນອີກຕໍ່ໄປຈະ ນຳ ໄປສູ່ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ.
    ///
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນ [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// ການຄິດໄລ່ອອຟເຊັດຕົວຊີ້ອາດຫໍ່.
    ///
    /// ນີ້ແມ່ນປະຕິບັດເປັນທີ່ແທ້ຈິງເພື່ອຫຼີກເວັ້ນການແປງໄປຫາແລະຈາກ integer ເປັນ, ນັບຕັ້ງແຕ່ປ່ຽນໃຈເຫລື້ອມໃສຍັບຍັ້ງການດີທີ່ສຸດສະເພາະໃດຫນຶ່ງ.
    ///
    /// # Safety
    ///
    /// ບໍ່ຄືກັບສະຖາປັດຕະຍະ ກຳ `offset`, ສະຖາປັດຕະຍະ ກຳ ນີ້ບໍ່ໄດ້ ຈຳ ກັດຕົວຊີ້ທີ່ໄດ້ຮັບເພື່ອຊີ້ໃຫ້ເຫັນຈຸດໃດ ໜຶ່ງ ທີ່ຜ່ານໄປໃນຕອນທ້າຍຂອງວັດຖຸທີ່ຖືກຈັດສັນ, ແລະມັນກໍ່ປະກອບດ້ວຍເລກຄະນິດສາດທີ່ສົມບູນສອງຢ່າງ.
    /// ມູນຄ່າທີ່ໄດ້ຮັບແມ່ນບໍ່ ຈຳ ເປັນທີ່ຈະຖືກ ນຳ ໃຊ້ເພື່ອເຂົ້າເຖິງຄວາມ ຈຳ ແທ້.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ແມ່ນ [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// ທຽບເທົ່າກັບທີ່ເຫມາະສົມ `llvm.memcpy.p0i8.0i8.*` intrinsic, ມີຂະຫນາດຂອງ `count`*`size_of::<T>()` ແລະຄວາມສອດຄ່ອງຂອງ
    ///
    /// `min_align_of::<T>()`
    ///
    /// ພາລາມິເຕີການປ່ຽນແປງໄດ້ຖືກກໍານົດທີ່ຈະ `true`, ສະນັ້ນມັນຈະບໍ່ໄດ້ຮັບການປັບໃຫ້ເຫມາະສົມອອກເວັ້ນເສຍແຕ່ວ່າຂະຫນາດເທົ່າກັບສູນ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// ທຽບເທົ່າກັບທີ່ເຫມາະສົມ `llvm.memmove.p0i8.0i8.*` intrinsic, ມີຂະຫນາດຂອງ `count* size_of::<T>()` ແລະຄວາມສອດຄ່ອງຂອງ
    ///
    /// `min_align_of::<T>()`
    ///
    /// ພາລາມິເຕີການປ່ຽນແປງໄດ້ຖືກກໍານົດທີ່ຈະ `true`, ສະນັ້ນມັນຈະບໍ່ໄດ້ຮັບການປັບໃຫ້ເຫມາະສົມອອກເວັ້ນເສຍແຕ່ວ່າຂະຫນາດເທົ່າກັບສູນ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// ທຽບເທົ່າກັບທີ່ເຫມາະສົມທີ່ແທ້ຈິງ `llvm.memset.p0i8.*`, ມີຂະຫນາດຂອງ `count* size_of::<T>()` ແລະຄວາມສອດຄ່ອງຂອງ `min_align_of::<T>()` ໄດ້.
    ///
    ///
    /// ພາລາມິເຕີການປ່ຽນແປງໄດ້ຖືກກໍານົດທີ່ຈະ `true`, ສະນັ້ນມັນຈະບໍ່ໄດ້ຮັບການປັບໃຫ້ເຫມາະສົມອອກເວັ້ນເສຍແຕ່ວ່າຂະຫນາດເທົ່າກັບສູນ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// ປະຕິບັດການໂຫຼດທີ່ບໍ່ປ່ຽນແປງຈາກຕົວຊີ້ `src`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນ [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// ດໍາເນີນການຮ້ານພາບການປ່ຽນແປງກັບຊີ້ `dst`.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ແມ່ນ [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// ດໍາເນີນພາລະເຫີຍທີ່ສະກັດຈາກຊີ້ `src` ຕົວຊີ້ບໍ່ໄດ້ຕ້ອງການທີ່ຈະສອດຄ່ອງ.
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// ດໍາເນີນການຮ້ານພາບການປ່ຽນແປງກັບຊີ້ `dst`.
    /// ຕົວຊີ້ບໍ່ໄດ້ຕ້ອງການທີ່ຈະສອດຄ່ອງ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// ກັບຄືນຮາກຮຽບຮ້ອຍຂອງ `f32`
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// ຜົນໄດ້ຮັບການຮາກທີ່ສອງຂອງ `f64`
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// ຍົກລະດັບ `f32` ໃຫ້ກັບພະລັງງານເລກເຕັມ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// ຈຶ່ງເຮັດໃຫ້ເກີດ `f64` ກັບພະລັງງານຈໍານວນເຕັມ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// ສົ່ງຄືນຊີນຂອງ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// ສົ່ງຄືນຊີນຂອງ `f64`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// ສົ່ງຄືນ cosine ຂອງ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// ຜົນໄດ້ຮັບການໂຄຊີນຂອງ `f64` ໄດ້.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// ຍົກລະດັບ `f32` ເປັນພະລັງງານ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// ຍົກລະດັບ `f64` ເປັນພະລັງງານ `f64`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// ສົ່ງຄືນເລກ ກຳ ລັງຂອງ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// ສົ່ງຄືນເລກ ກຳ ລັງຂອງ `f64`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// ຜົນຕອບແທນ 2 ຂຶ້ນກັບພະລັງງານຂອງ `f32` ໄດ້.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// ຜົນຕອບແທນ 2 ຂຶ້ນກັບພະລັງງານຂອງ `f64` ໄດ້.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// ສົ່ງຄ່າ logarithm ທຳ ມະຊາດຂອງ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// ຜົນໄດ້ຮັບການໂລກາລິດທໍາມະຊາດຂອງ `f64`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// ຜົນໄດ້ຮັບການພື້ນຖານ 10 ໂລກາລິດຂອງ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// ຜົນໄດ້ຮັບການພື້ນຖານ 10 ໂລກາລິດຂອງ `f64`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// ຜົນໄດ້ຮັບການພື້ນຖານ 2 ໂລກາລິດຂອງ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// ຜົນໄດ້ຮັບການພື້ນຖານ 2 ໂລກາລິດຂອງ `f64`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// ຜົນໄດ້ຮັບ `a * b + c` ສໍາລັບຄ່າ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// ຜົນໄດ້ຮັບ `a * b + c` ສໍາລັບຄ່າ `f64`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// ຜົນໄດ້ຮັບມູນຄ່າຢ່າງແທ້ຈິງຂອງ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// ສົ່ງຄືນຄ່າທີ່ແທ້ຈິງຂອງ `f64`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// ສົ່ງຄ່າ ຕຳ ່ສຸດທີ່ສອງຄ່າ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// ຜົນໄດ້ຮັບຕ່ໍາສຸດຂອງສອງຄ່າ `f64` ໄດ້.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// ຜົນໄດ້ຮັບສູງສຸດຂອງທັງສອງຄ່າ `f32` ໄດ້.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// ຜົນໄດ້ຮັບສູງສຸດຂອງທັງສອງຄ່າ `f64` ໄດ້.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// ສໍາເນົາຫມາຍຈາກ `y` ກັບ `x` ສໍາລັບຄ່າ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// ສໍາເນົາຫມາຍຈາກ `y` ກັບ `x` ສໍາລັບຄ່າ `f64`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// ຜົນຕອບແທນຈໍານວນເຕັມທີ່ໃຫຍ່ທີ່ສຸດຫນ້ອຍກ່ວາຫຼືເທົ່າທຽມກັນທີ່ເປັນ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// ຜົນຕອບແທນຈໍານວນເຕັມທີ່ໃຫຍ່ທີ່ສຸດຫນ້ອຍກ່ວາຫຼືເທົ່າທຽມກັນທີ່ເປັນ `f64`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// ຜົນໄດ້ຮັບໄດ້ຫຼາຍກວ່າຈໍານວນເຕັມຂະຫນາດນ້ອຍກ່ວາຫຼືເທົ່າທຽມກັນທີ່ເປັນ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// ສົ່ງເລກເຕັມນ້ອຍທີ່ໃຫຍ່ກວ່າຫຼືເທົ່າກັບ `f64`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// ສົ່ງຄືນສ່ວນເຕັມຂອງ `f32`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// ຜົນໄດ້ຮັບພາກສ່ວນຈໍານວນເຕັມຂອງການ `f64`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// ຜົນໄດ້ຮັບຈໍານວນເຕັມທີ່ໃກ້ທີ່ສຸດກັບ `f32`.
    /// ອາດຍົກສູງບົດບາດບໍ່ແນ່ນອນຂໍ້ຍົກເວັ້ນທີ່ເລື່ອນໄດ້, ຈຸດຖ້າຫາກວ່າການໂຕ້ຖຽງ, ບໍ່ແມ່ນການ integer.
    pub fn rintf32(x: f32) -> f32;
    /// ຜົນໄດ້ຮັບຈໍານວນເຕັມທີ່ໃກ້ທີ່ສຸດກັບ `f64`.
    /// ອາດຍົກສູງບົດບາດບໍ່ແນ່ນອນຂໍ້ຍົກເວັ້ນທີ່ເລື່ອນໄດ້, ຈຸດຖ້າຫາກວ່າການໂຕ້ຖຽງ, ບໍ່ແມ່ນການ integer.
    pub fn rintf64(x: f64) -> f64;

    /// ຜົນໄດ້ຮັບຈໍານວນເຕັມທີ່ໃກ້ທີ່ສຸດກັບ `f32`.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn nearbyintf32(x: f32) -> f32;
    /// ຜົນໄດ້ຮັບຈໍານວນເຕັມທີ່ໃກ້ທີ່ສຸດກັບ `f64`.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn nearbyintf64(x: f64) -> f64;

    /// ຜົນໄດ້ຮັບຈໍານວນເຕັມທີ່ໃກ້ທີ່ສຸດກັບ `f32`.ກໍລະນີຮອບເຄິ່ງທາງຫ່າງຈາກສູນ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// ຜົນໄດ້ຮັບຈໍານວນເຕັມທີ່ໃກ້ທີ່ສຸດກັບ `f64`.ກໍລະນີຮອບເຄິ່ງທາງຫ່າງຈາກສູນ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// ເລື່ອນນອກຈາກນັ້ນທີ່ອະນຸຍາດໃຫ້ດີທີ່ສຸດໂດຍອີງໃສ່ກົດລະບຽບພຶຊະຄະນິດ.
    /// ອາດຈະຖືວ່າການປ້ອນຂໍ້ມູນແມ່ນ ຈຳ ກັດ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// ເລື່ອນການຫັກລົບທີ່ອະນຸຍາດໃຫ້ດີທີ່ສຸດໂດຍອີງໃສ່ກົດລະບຽບພຶຊະຄະນິດ.
    /// ອາດຈະຖືວ່າການປ້ອນຂໍ້ມູນແມ່ນ ຈຳ ກັດ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// ເລື່ອນຫຼາຍວ່າອະນຸຍາດໃຫ້ດີທີ່ສຸດໂດຍອີງໃສ່ກົດລະບຽບພຶຊະຄະນິດ.
    /// ອາດຈະຖືວ່າການປ້ອນຂໍ້ມູນແມ່ນ ຈຳ ກັດ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// ເລື່ອນພະແນກທີ່ອະນຸຍາດໃຫ້ດີທີ່ສຸດໂດຍອີງໃສ່ກົດລະບຽບພຶຊະຄະນິດ.
    /// ອາດຈະຖືວ່າການປ້ອນຂໍ້ມູນແມ່ນ ຈຳ ກັດ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// ສ່ວນທີ່ເຫຼືອຂອງເລື່ອນທີ່ອະນຸຍາດໃຫ້ເພີ່ມປະສິດທິພາບໂດຍອີງໃສ່ກົດລະບຽບກ່ຽວກັບພຶດຊະຄະນິດ.
    /// ອາດຈະຖືວ່າການປ້ອນຂໍ້ມູນແມ່ນ ຈຳ ກັດ.
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// ແປງດ້ວຍ fptoui/fptosi ຂອງ LLVM, ເຊິ່ງອາດຈະກັບຄືນຄ່າທີ່ບໍ່ມີຂອບເຂດ ສຳ ລັບຄ່າອອກຈາກຂອບເຂດ
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// ສະຖຽນລະພາບເປັນ [`f32::to_int_unchecked`] ແລະ [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// ຜົນຕອບແທນຈໍານວນບິດທີ່ກໍານົດໄວ້ໃນປະເພດຈໍານວນເຕັມ `T`
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ມີຢູ່ໃນຕົວປະຖົມສົມບູນຜ່ານວິທີ `count_ones`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// ຜົນໄດ້ຮັບຈໍານວນຂອງຊັ້ນນໍາ bits unset (zeroes) ໃນປະເພດຈໍານວນເຕັມ `T`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `leading_zeros`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// ເປັນ `x` ກັບມູນຄ່າ `0` ກໍ່ຈະສົ່ງ width bit ຂອງ `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// ເຊັ່ນດຽວກັນກັບ `ctlz`, ແຕ່ພິເສດ, ທີ່ບໍ່ປອດໄພຍ້ອນວ່າມັນຈະກັບຄືນມາໃນເວລາທີ່ `undef` ໃຫ້ເປັນ `x` ກັບມູນຄ່າ `0`.
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// ຜົນໄດ້ຮັບຈໍານວນຂອງ trailing bits unset (zeroes) ໃນປະເພດຈໍານວນເຕັມ `T` ໄດ້.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `trailing_zeros`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// ເປັນ `x` ກັບມູນຄ່າ `0` ກໍ່ຈະສົ່ງ width bit ຂອງ `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// ເຊັ່ນດຽວກັນກັບ `cttz`, ແຕ່ພິເສດ, ທີ່ບໍ່ປອດໄພຍ້ອນວ່າມັນຈະກັບຄືນມາໃນເວລາທີ່ `undef` ໃຫ້ເປັນ `x` ກັບມູນຄ່າ `0`.
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// ຝືນ bytes ໃນປະເພດຈໍານວນເຕັມ `T`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `swap_bytes`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// ຝືນ bits ໃນປະເພດຈໍານວນເຕັມ `T`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `reverse_bits`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// ດໍາເນີນການກວດກາຈໍານວນເຕັມນອກຈາກນັ້ນ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `overflowing_add`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ດໍາເນີນການກວດກາຈໍານວນເຕັມລົບ
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `overflowing_sub`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ດຳ ເນີນການຄູນເລກທະວີຄູນ
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `overflowing_mul`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ປະຕິບັດການແບ່ງແຍກທີ່ແນ່ນອນ, ສົ່ງຜົນໃຫ້ມີພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດບ່ອນທີ່ `x % y != 0` ຫຼື `y == 0` ຫຼື `x == T::MIN && y == -1`
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// ດໍາເນີນການພະແນກກວດກາ, ຜົນອອກມາໃນພຶດຕິກໍາ undefined ທີ່ `y == 0` ຫຼື `x == T::MIN && y == -1`
    ///
    ///
    /// wrappers ຄວາມປອດໄພສໍາລັບການທີ່ແທ້ຈິງນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `checked_div`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// ຜົນໄດ້ຮັບສ່ວນທີ່ເຫຼືອຂອງພະແນກການກວດກາໄດ້, ຜົນອອກມາໃນພຶດຕິກໍາ undefined ໃນເວລາທີ່ `y == 0` ຫຼື `x == T::MIN && y == -1`
    ///
    ///
    /// wrappers ຄວາມປອດໄພສໍາລັບການທີ່ແທ້ຈິງນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `checked_rem`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// ປະຕິບັດການເລື່ອນຊ້າຍທີ່ບໍ່ໄດ້ຮັບການກວດ, ສົ່ງຜົນໃຫ້ມີພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດເມື່ອ `y < 0` ຫຼື `y >= N`, ບ່ອນທີ່ N ແມ່ນຄວາມກວ້າງຂອງ T ໃນບິດ.
    ///
    ///
    /// ເຄື່ອງຫໍ່ທີ່ປອດໄພ ສຳ ລັບການເຮັດວຽກທາງອິນເທີເນັດນີ້ແມ່ນມີຢູ່ໃນຕົວປະຖົມສົມບູນແບບໂດຍຜ່ານວິທີ `checked_shl`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// ດໍາເນີນການເປັນການປ່ຽນແປງທີ່ຖືກຕ້ອງມີການກວດກາ, ຜົນອອກມາໃນພຶດຕິກໍາ undefined ໃນເວລາທີ່ `y < 0` ຫຼື `y >= N`, ບ່ອນທີ່ N ແມ່ນ width ຂອງ T ໃນ bits ໄດ້.
    ///
    ///
    /// wrappers ຄວາມປອດໄພສໍາລັບການທີ່ແທ້ຈິງນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `checked_shr`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// ຜົນໄດ້ຮັບຜົນຂອງການນອກຈາກນັ້ນການກວດກາໄດ້, ຜົນອອກມາໃນພຶດຕິກໍາ undefined ໃນເວລາທີ່ `x + y > T::MAX` ຫຼື `x + y < T::MIN`.
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// ສົ່ງຄືນຜົນຂອງການຫັກລົບທີ່ບໍ່ໄດ້ກວດກາ, ສົ່ງຜົນໃຫ້ມີພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດເມື່ອ `x - y > T::MAX` ຫຼື `x - y < T::MIN`.
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// ຜົນໄດ້ຮັບຜົນໄດ້ຮັບຂອງການກວດກາທະວີຄູນ, ຜົນອອກມາໃນພຶດຕິກໍາ undefined ໃນເວລາທີ່ `x *y > T::MAX` ຫຼື `x* y < T::MIN`.
    ///
    ///
    /// ຄວາມເຂັ້ມຂົ້ນນີ້ບໍ່ມີຄູ່ຮ່ວມງານທີ່ຫມັ້ນຄົງ.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// ດໍາເນີນການ rotate ປະໄວ້.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `rotate_left`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// ດໍາເນີນການຫມຸນຖືກຕ້ອງ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `rotate_right`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// ກັບຄືນ (a + b) mod 2 <sup>N</sup>, ເຊິ່ງ N ແມ່ນຄວາມກວ້າງຂອງ T ໃນບິດ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `wrapping_add`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// ຜົນຕອບແທນ (a, b) mod 2 <sup>N,</sup> ບ່ອນທີ່ N ແມ່ນ width ຂອງ T ໃນ bits ໄດ້.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ມີຢູ່ໃນຕົວປະຖົມສົມບູນຜ່ານວິທີ `wrapping_sub`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// ຜົນຕອບແທນ (a b *) MOD 2 <sup>N,</sup> ບ່ອນທີ່ N ແມ່ນ width ຂອງ T ໃນ bits ໄດ້.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ມີຢູ່ໃນຕົວປະຖົມສົມບູນຜ່ານວິທີ `wrapping_mul`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// ຄອມພິວເຕີ `a + b`, ການອີ່ມຕົວທີ່ຂອບເຂດຈໍານວນຫລາຍ.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນມີຢູ່ໃນ primitives integer ຜ່ານວິທີການ `saturating_add`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// ຄອມພິວເຕີ `a - b`, ການອີ່ມຕົວທີ່ຂອບເຂດຈໍານວນຫລາຍ.
    ///
    /// ແບບສະຖຽນລະພາບຂອງສະຖາປັດຕະຍະ ກຳ ແບບນີ້ມີຢູ່ໃນຕົວປະຖົມສົມບູນຜ່ານວິທີ `saturating_sub`.
    /// ຍົກຕົວຢ່າງ,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// ສົ່ງຄືນຄ່າຂອງຈໍາແນກສໍາລັບການທີ່ແຕກຕ່າງໃນ 'v' ໄດ້;
    /// ຖ້າຫາກວ່າ `T` ບໍ່ມີຈໍາແນກ, ໃຫ້ຜົນໄດ້ຮັບ `0`.
    ///
    /// ສະບັບຄົງຂອງ intrinsic ນີ້ແມ່ນ [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// ຜົນຕອບແທນຈໍານວນຂອງ variants ຂອງປະເພດຂອງແມ່ພິມສໍາລັບ `T` ກັບ `usize` ໄດ້;
    /// ຖ້າຫາກວ່າ `T` ບໍ່ມີ variants, ໃຫ້ຜົນໄດ້ຮັບ `0`.variants uninhabited ຈະຖືກນັບ.
    ///
    /// ສະບັບກັບໄດ້ຮັບການສະຖຽນລະພາບຂອງ intrinsic ນີ້ແມ່ນ [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust ຂອງ construct "try catch" ທີ່ເອີ້ນໄດ້ຊີ້ຫນ້າ `try_fn` ກັບຊີ້ຂໍ້ມູນ `data`.
    ///
    /// ການອະພິປາຍທີ່ສາມແມ່ນຕໍາລາຫນຶ່ງເອີ້ນວ່າຖ້າຫາກວ່າເປັນ panic ເກີດຂຶ້ນ.
    /// ຟັງຊັນນີ້ເອົາຕົວຊີ້ຂໍ້ມູນແລະຕົວຊີ້ໄປຫາຈຸດປະສົງຍົກເວັ້ນເປົ້າ ໝາຍ ສະເພາະທີ່ຖືກຈັບ.
    ///
    /// ສໍາລັບຂໍ້ມູນເພີ່ມເຕີມເບິ່ງແຫລ່ງລວບລວມຂອງເຊັ່ນດຽວກັນກັບ std ຂອງການປະຕິບັດຈັບ.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// ປ່ອຍຮ້ານ `!nontemporal` ຕາມ LLVM (ເບິ່ງເອກະສານຂອງພວກເຂົາ).
    /// ອາດຈະບໍ່ ໝັ້ນ ຄົງເລີຍ.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// ເບິ່ງເອກະສານຂອງ `<*const T>::offset_from` ສຳ ລັບລາຍລະອຽດ.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// ເບິ່ງເອກະສານຂອງ `<*const T>::guaranteed_eq` ສໍາລັບລາຍລະອຽດ.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// ເບິ່ງເອກະສານຂອງ `<*const T>::guaranteed_ne` ສໍາລັບລາຍລະອຽດ.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// ຈັດສັນໃນເວລາລວບລວມ.ບໍ່ຄວນໄດ້ຮັບການເອີ້ນວ່າຢູ່ໃນອຸ.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// ບາງຟັງຊັນໄດ້ກໍານົດໄວ້ໃນທີ່ນີ້ເພາະວ່າພວກເຂົາເຈົ້າໂດຍບັງເອີນໄດ້ຮັບການມີຢູ່ໃນໂມດູນນີ້ຫມັ້ນຄົງ.
// ເບິ່ງ <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` ຍັງຕົກຢູ່ໃນ ໝວດ ນີ້, ແຕ່ມັນບໍ່ສາມາດຖືກຫໍ່ຍ້ອນການກວດສອບວ່າ `T` ແລະ `U` ມີຂະ ໜາດ ດຽວກັນ.)
//

/// ກວດເບິ່ງວ່າ `ptr` ມີຄວາມສອດຄ່ອງ ເໝາະ ສົມກັບ `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// ສໍາເນົາ `count *size_of::<T>()` ໄບຈາກ `src` ກັບ `dst`.ແຫລ່ງແລະຈຸດຫມາຍປາຍທາງຕ້ອງ* ບໍ່ * ການຊໍ້າຊ້ອນ.
///
/// ສຳ ລັບພື້ນທີ່ຂອງ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ອາດຈະຊໍ້າຊ້ອນ, ໃຊ້ [`copy`] ແທນ.
///
/// `copy_nonoverlapping` ແມ່ນຫມາຍທຽບເທົ່າກັບຂອງ C [`memcpy`], ແຕ່ມີຄໍາສັ່ງການໂຕ້ຖຽງໄດ້ swapped.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// ພຶດຕິ ກຳ ແມ່ນບໍ່ໄດ້ ກຳ ນົດຖ້າມີເງື່ອນໄຂຕໍ່ໄປນີ້ຖືກລະເມີດ:
///
/// * `src` ຕ້ອງ [valid] ສໍາລັບບອກວ່າຂອງ `count * size_of::<T>()` ໄບ.
///
/// * `dst` ຕ້ອງເປັນ [valid] ສຳ ລັບການຂຽນ `count * size_of::<T>()` bytes.
///
/// * ທັງ `src` ແລະ `dst` ຕ້ອງມີຄວາມສອດຄ່ອງກັນຢ່າງຖືກຕ້ອງ.
///
/// * ໃນພູມິພາກຂອງຄວາມຊົງຈໍາເລີ່ມຕົ້ນທີ່ `src` ກັບຂະຫນາດຂອງ `ນັບ *
///   size_of: :<T>() `bytes ຕ້ອງ *ບໍ່* ຊ້ ຳ ກັບພື້ນທີ່ຂອງຄວາມ ຈຳ ເລີ່ມຕົ້ນທີ່ `dst` ທີ່ມີຂະ ໜາດ ດຽວກັນ.
///
/// ເຊັ່ນດຽວກັນກັບ [`read`], `copy_nonoverlapping` ສ້າງສໍາເນົາຄ່າທີ່ເຫມາະສົມຂອງ `T`, ບໍ່ຄໍານຶງເຖິງວ່າ `T` ແມ່ນ [`Copy`].
/// ຖ້າ `T` ບໍ່ [`Copy`], ການນໍາໃຊ້ *ທັງ* ຄ່າໃນພາກພື້ນເລີ່ມຕົ້ນທີ່ `*src` ແລະພາກພື້ນເລີ່ມຕົ້ນທີ່ສາມາດເຮັດໄດ້ `* dst` [violate memory safety][read-ownership].
///
///
/// ໃຫ້ສັງເກດວ່າເຖິງແມ່ນວ່າຂະ ໜາດ ທີ່ຖືກຄັດລອກຢ່າງມີປະສິດຕິຜົນ (`count * size_of: :<T>()`) ແມ່ນ `0`, ຜູ້ຊີ້ບອກຕ້ອງບໍ່ແມ່ນ NULL ແລະສອດຄ່ອງຢ່າງຖືກຕ້ອງ.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// ປະຕິບັດຄູ່ມື [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// ການເຄື່ອນໄຫວຂອງອົງປະກອບທັງຫມົດຂອງ `src` ເປັນ `dst`, ຊຶ່ງເຮັດໃຫ້ `src` ເປົ່າ.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // ຮັບປະກັນວ່າ `dst` ມີຄວາມສາມາດພຽງພໍໃນການຖື `src` ທັງ ໝົດ.
///     dst.reserve(src_len);
///
///     unsafe {
///         // ໂທເພື່ອຊົດເຊີຍແມ່ນສະເຫມີໄປທີ່ປອດໄພເນື່ອງຈາກວ່າ `Vec` ຈະບໍ່ຈັດສັນຫຼາຍກ່ວາ `isize::MAX` ໄບ.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // ຕັດ `src` ໂດຍບໍ່ລຸດລົງເນື້ອໃນຂອງມັນ.
///         // ພວກເຮົາເຮັດສິ່ງນີ້ກ່ອນ, ເພື່ອຫລີກລ້ຽງບັນຫາໃນກໍລະນີມີບາງສິ່ງບາງຢ່າງຫຼຸດລົງ panics.
///         src.set_len(0);
///
///         // ທັງສອງຂົງເຂດບໍ່ສາມາດຊໍ້າຊ້ອນໄດ້ເພາະວ່າເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ບໍ່ມີນາມແຝງ, ແລະສອງ vectors ທີ່ແຕກຕ່າງກັນບໍ່ສາມາດມີຄວາມຊົງ ຈຳ ດຽວກັນ.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // ແຈ້ງການ `dst` ວ່າມັນມີເນື້ອໃນຂອງ `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: ປະຕິບັດການກວດສອບການເຫຼົ່ານີ້ພຽງແຕ່ຢູ່ທີ່ໃຊ້ເວລາການດໍາເນີນງານ
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // ບໍ່ panicking ເພື່ອຮັກສາຜົນກະທົບໂຊຄອດຂະຫນາດນ້ອຍກວ່າ.
        abort();
    }*/

    // SAFETY: ການສັນຍາຄວາມປອດໄພສໍາລັບ `copy_nonoverlapping` ຕ້ອງ
    // ແຕ່ງຕັ້ງໂດຍແປໄດ້ທຸໄດ້.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// ສໍາເນົາ `count * size_of::<T>()` ໄບຈາກ `src` ກັບ `dst`.ແຫລ່ງແລະຈຸດຫມາຍປາຍທາງອາດຈະມີການຊໍ້າຊ້ອນ.
///
/// ຖ້າຫາກວ່າທາງແລະປາຍທາງຈະ *ບໍ່* ຊ້ອນ [`copy_nonoverlapping`] ສາມາດນໍາໃຊ້ແທນທີ່ຈະເປັນ.
///
/// `copy` ແມ່ນຫມາຍທຽບເທົ່າກັບຂອງ C [`memmove`], ແຕ່ມີຄໍາສັ່ງການໂຕ້ຖຽງໄດ້ swapped.
/// ຄັດລອກໃຊ້ເວລາສະຖານທີ່ເປັນຖ້າຫາກວ່າ bytes ໄດ້ຖືກຄັດລອກມາຈາກ `src` ເປັນ array ຊົ່ວຄາວແລະຫຼັງຈາກນັ້ນຄັດລອກມາຈາກຂບວນທີ່ຈະ `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// ພຶດຕິ ກຳ ແມ່ນບໍ່ໄດ້ ກຳ ນົດຖ້າມີເງື່ອນໄຂຕໍ່ໄປນີ້ຖືກລະເມີດ:
///
/// * `src` ຕ້ອງ [valid] ສໍາລັບບອກວ່າຂອງ `count * size_of::<T>()` ໄບ.
///
/// * `dst` ຕ້ອງເປັນ [valid] ສຳ ລັບການຂຽນ `count * size_of::<T>()` bytes.
///
/// * ທັງ `src` ແລະ `dst` ຕ້ອງມີຄວາມສອດຄ່ອງກັນຢ່າງຖືກຕ້ອງ.
///
/// ເຊັ່ນດຽວກັນກັບ [`read`], `copy` ສ້າງສໍາເນົາຄ່າທີ່ເຫມາະສົມຂອງ `T`, ບໍ່ຄໍານຶງເຖິງວ່າ `T` ແມ່ນ [`Copy`].
/// ຖ້າ `T` ບໍ່ [`Copy`], ການນໍາໃຊ້ຄ່າທັງຢູ່ໃນພາກພື້ນໃນຕອນເລີ່ມຕົ້ນທີ່ `*src` ແລະພາກພື້ນເລີ່ມຕົ້ນທີ່ສາມາດເຮັດໄດ້ `* dst` [violate memory safety][read-ownership].
///
///
/// ໃຫ້ສັງເກດວ່າເຖິງແມ່ນວ່າຂະ ໜາດ ທີ່ຖືກຄັດລອກຢ່າງມີປະສິດຕິຜົນ (`count * size_of: :<T>()`) ແມ່ນ `0`, ຜູ້ຊີ້ບອກຕ້ອງບໍ່ແມ່ນ NULL ແລະສອດຄ່ອງຢ່າງຖືກຕ້ອງ.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// ປະສິດທິຜົນສ້າງ Rust vector ຈາກບັຟເຟີທີ່ບໍ່ປອດໄພ:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` ຕ້ອງໄດ້ຮັບການສອດຄ່ອງຢ່າງຖືກຕ້ອງ ສຳ ລັບປະເພດແລະທີ່ບໍ່ແມ່ນສູນ.
/// /// * `ptr` ຕ້ອງຖືກຕ້ອງສໍາລັບບອກວ່າຂອງ `elts` ອົງປະກອບ contiguous ຂອງປະເພດ `T`.
/// /// * ອົງປະກອບເຫຼົ່ານັ້ນບໍ່ໄດ້ຮັບການນໍາໃຊ້ຫຼັງຈາກທີ່ເອີ້ນໃຊ້ຟັງຊັນນີ້ເວັ້ນເສຍແຕ່ວ່າ `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SAFETY: ຂອງພວກເຮົາເງື່ອນໄຂຮັບປະກັນແຫຼ່ງແມ່ນສອດຄ່ອງແລະຖືກຕ້ອງ,
///     // ແລະ `Vec::with_capacity` ຮັບປະກັນວ່າພວກເຮົາມີພື້ນທີ່ໃຊ້ສອຍທີ່ຈະຂຽນໃຫ້ເຂົາເຈົ້າ.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // ຄວາມປອດໄພ: ພວກເຮົາໄດ້ສ້າງມັນດ້ວຍຄວາມສາມາດຫຼາຍກ່ອນ ໜ້າ ນີ້,
///     // ແລະ `copy` ທີ່ຜ່ານມາໄດ້ເລີ່ມຕົ້ນອົງປະກອບເຫຼົ່ານີ້.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: ປະຕິບັດການກວດສອບການເຫຼົ່ານີ້ພຽງແຕ່ຢູ່ທີ່ໃຊ້ເວລາການດໍາເນີນງານ
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // ບໍ່ panicking ເພື່ອຮັກສາຜົນກະທົບໂຊຄອດຂະຫນາດນ້ອຍກວ່າ.
        abort();
    }*/

    // SAFETY: ການສັນຍາຄວາມປອດໄພສໍາລັບ `copy` ຕ້ອງໄດ້ຮັບການແຕ່ງຕັ້ງໂດຍແປໄດ້ທຸໄດ້.
    unsafe { copy(src, dst, count) }
}

/// ຊຸດ `count * size_of::<T>()` ໄບຂອງຫນ່ວຍຄວາມຈໍາເລີ່ມຕົ້ນທີ່ `dst` ກັບ `val`.
///
/// `write_bytes` ແມ່ນຄ້າຍຄືກັນກັບຂອງ C [`memset`], ແຕ່ຊຸດ `count * size_of::<T>()` ໄບກັບ `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// ພຶດຕິ ກຳ ແມ່ນບໍ່ໄດ້ ກຳ ນົດຖ້າມີເງື່ອນໄຂຕໍ່ໄປນີ້ຖືກລະເມີດ:
///
/// * `dst` ຕ້ອງເປັນ [valid] ສຳ ລັບການຂຽນ `count * size_of::<T>()` bytes.
///
/// * `dst` ຕ້ອງສອດຄ່ອງຢ່າງຖືກຕ້ອງ.
///
/// ນອກຈາກນັ້ນ, ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າການຂຽນ `count * size_of::<T>()` ໄບຕ໌ໄປໃນຂົງເຂດທີ່ໄດ້ຮັບຂອງ ໜ່ວຍ ຄວາມ ຈຳ ເຮັດໃຫ້ມູນຄ່າ `T` ຖືກຕ້ອງ.
/// ການນໍາໃຊ້ພາກພື້ນຂອງຫນ່ວຍຄວາມຈໍາເປັນພິມເປັນ `T` ທີ່ປະກອບດ້ວຍຄ່າທີ່ບໍ່ຖືກຕ້ອງຂອງ `T` ແມ່ນພຶດຕິກໍາ undefined.
///
/// ໃຫ້ສັງເກດວ່າເຖິງແມ່ນວ່າຂະ ໜາດ ທີ່ຖືກຄັດລອກຢ່າງມີປະສິດຕິຜົນ (`count * size_of: :<T>()`) ເປັນ `0`, ຊີ້ຕ້ອງເປັນທີ່ບໍ່ແມ່ນ NULL ແລະສອດຄ່ອງເຫມາະສົມ.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// ການສ້າງມູນຄ່າບໍ່ຖືກຕ້ອງ:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // ຮົ່ວມູນຄ່າໄດ້ຈັດຂຶ້ນໃນເມື່ອກ່ອນໂດຍ overwriting ໄດ້ `Box<T>` ກັບຊີ້ null ໄດ້.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // ໃນຈຸດດັ່ງກ່າວນີ້, ການນໍາໃຊ້ຫຼືຫຼຸດລົງຜົນໄດ້ຮັບ `v` ໃນພຶດຕິກໍາ undefined.
/// // drop(v); // ERROR
///
/// // ເຖິງແມ່ນວ່າການຮົ່ວໄຫຼ `v` "uses" ມັນ, ແລະເພາະສະນັ້ນແມ່ນພຶດຕິກໍາທີ່ບໍ່ໄດ້ກໍານົດ.
/// // mem::forget(v); // ERROR
///
/// // ໃນຄວາມເປັນຈິງ, `v` ແມ່ນບໍ່ຖືກຕ້ອງອີງຕາມການບຸກລຸກການຈັດປະເພດຂັ້ນພື້ນຖານ, ສະນັ້ນ * ການ ດຳ ເນີນງານໃດໆທີ່ແຕະຕ້ອງມັນແມ່ນພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ.
/////
/// // ໃຫ້ v2 =v;//ຜິດພາດ
///
/// unsafe {
///     // ຂໍໃຫ້ພວກເຮົາເອົາໃຈໃສ່ໃນມູນຄ່າທີ່ຖືກຕ້ອງ
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // ໃນປັດຈຸບັນເອົາຫ້ອງດັ່ງກ່າວແມ່ນການປັບໄຫມ
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SAFETY: ການສັນຍາຄວາມປອດໄພສໍາລັບ `write_bytes` ຕ້ອງໄດ້ຮັບການແຕ່ງຕັ້ງໂດຍແປໄດ້ທຸໄດ້.
    unsafe { write_bytes(dst, val, count) }
}