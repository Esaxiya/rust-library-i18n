use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ແຕ່ວ່າບໍ່ແມ່ນສູນແລະ covariant.
///
/// ນີ້ມັກຈະແມ່ນສິ່ງທີ່ຖືກຕ້ອງໃນການ ນຳ ໃຊ້ໃນເວລາສ້າງໂຄງສ້າງຂໍ້ມູນໂດຍໃຊ້ຕົວຊີ້ວັດຖຸດິບ, ແຕ່ສຸດທ້າຍມັນຈະເປັນອັນຕະລາຍຕໍ່ການ ນຳ ໃຊ້ເພາະມີຄຸນສົມບັດເພີ່ມເຕີມ.ຖ້າທ່ານບໍ່ແນ່ໃຈວ່າທ່ານຄວນໃຊ້ `NonNull<T>`, ພຽງແຕ່ໃຊ້ `*mut T`!
///
/// ບໍ່ຄືກັບ `*mut T`, ຕົວຊີ້ຕ້ອງສະ ເໝີ ໄປທີ່ບໍ່ແມ່ນຕົວເລກ, ເຖິງແມ່ນວ່າຕົວຊີ້ຈະບໍ່ເຄີຍຖືກລົບກວນ.ນີ້ແມ່ນເພື່ອໃຫ້ສະຖານທີ່ຕ່າງໆສາມາດ ນຳ ໃຊ້ມູນຄ່າທີ່ຖືກຫ້າມນີ້ເປັນການ ຈຳ ແນກ-`Option<NonNull<T>>` ມີຂະ ໜາດ ເທົ່າກັບ `* mut T`.
/// ເຖິງຢ່າງໃດກໍ່ຕາມຕົວຊີ້ກໍ່ຍັງຄົງຄ້າງຖ້າມັນບໍ່ໄດ້ຮັບການພິຈາລະນາ.
///
/// ບໍ່ຄືກັບ `*mut T`, `NonNull<T>` ໄດ້ຖືກເລືອກໃຫ້ເປັນ covariant ເໜືອ `T`.ນີ້ເຮັດໃຫ້ມັນສາມາດໃຊ້ `NonNull<T>` ໃນເວລາທີ່ການກໍ່ສ້າງປະເພດ covariant, ແຕ່ແນະ ນຳ ຄວາມສ່ຽງຂອງການບໍ່ມີປະໂຫຍດຖ້າຖືກ ນຳ ໃຊ້ໃນປະເພດທີ່ບໍ່ຄວນຈະເປັນຈິງ.
/// (ທາງເລືອກທີ່ກົງກັນຂ້າມໄດ້ຖືກສ້າງຂື້ນ ສຳ ລັບ `*mut T` ເຖິງແມ່ນວ່າທາງວິຊາການຄວາມບໍ່ສົມບູນແບບສາມາດເກີດຈາກການໂທຫາ ໜ້າ ທີ່ທີ່ບໍ່ປອດໄພ.)
///
/// Covariance ແມ່ນຖືກຕ້ອງ ສຳ ລັບການດຶງດູດຄວາມປອດໄພທີ່ສຸດ, ເຊັ່ນ `Box`, `Rc`, `Arc`, `Vec`, ແລະ `LinkedList`.ນີ້ແມ່ນກໍລະນີເພາະວ່າພວກເຂົາສະຫນອງ API ສາທາລະນະທີ່ປະຕິບັດຕາມກົດລະບຽບ XOR ທີ່ປ່ຽນແປງໄດ້ທົ່ວໄປຂອງ Rust.
///
/// ຖ້າປະເພດຂອງທ່ານບໍ່ສາມາດເປັນພັນທະບັດໄດ້, ທ່ານຕ້ອງຮັບປະກັນວ່າມັນມີພາກສະ ໜາມ ເພີ່ມເຕີມເພື່ອສະ ໜອງ ການສະແດງ.ປົກກະຕິແລ້ວພາກສະຫນາມນີ້ຈະເປັນປະເພດ [`PhantomData`] ເຊັ່ນ `PhantomData<Cell<T>>` ຫຼື `PhantomData<&'a mut T>`.
///
/// ສັງເກດວ່າ `NonNull<T>` ມີຕົວຢ່າງ `From` ສຳ ລັບ `&T`.ເຖິງຢ່າງໃດກໍ່ຕາມ, ສິ່ງນີ້ບໍ່ໄດ້ປ່ຽນແປງຄວາມຈິງທີ່ວ່າການກາຍພັນຜ່ານ (ຕົວຊີ້ມາຈາກ a) ການອ້າງອີງຮ່ວມກັນແມ່ນພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດເວັ້ນເສຍແຕ່ວ່າການປ່ຽນແປງເກີດຂື້ນພາຍໃນ [`UnsafeCell<T>`].ສິ່ງດຽວກັນນີ້ແມ່ນ ສຳ ລັບການສ້າງເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ຈາກເອກະສານອ້າງອີງຮ່ວມກັນ.
///
/// ເມື່ອໃຊ້ຕົວຢ່າງ `From` ນີ້ໂດຍບໍ່ມີ `UnsafeCell<T>`, ມັນແມ່ນຄວາມຮັບຜິດຊອບຂອງທ່ານທີ່ຈະຮັບປະກັນວ່າ `as_mut` ບໍ່ເຄີຍຖືກເອີ້ນແລະ `as_ptr` ບໍ່ເຄີຍຖືກໃຊ້ ສຳ ລັບການກາຍພັນ.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ຕົວຊີ້ວັດບໍ່ແມ່ນ `Send` ເພາະວ່າຂໍ້ມູນທີ່ພວກເຂົາອ້າງເຖິງອາດຈະມີຊື່ແຝງ.
// NB, ການອ້າງອີງນີ້ແມ່ນບໍ່ ຈຳ ເປັນ, ແຕ່ຄວນໃຫ້ຂໍ້ຄວາມຜິດພາດທີ່ດີກວ່າ.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ຕົວຊີ້ວັດບໍ່ແມ່ນ `Sync` ເພາະວ່າຂໍ້ມູນທີ່ພວກເຂົາອ້າງເຖິງອາດຈະມີຊື່ແຝງ.
// NB, ການອ້າງອີງນີ້ແມ່ນບໍ່ ຈຳ ເປັນ, ແຕ່ຄວນໃຫ້ຂໍ້ຄວາມຜິດພາດທີ່ດີກວ່າ.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// ສ້າງ `NonNull` ແບບ ໃໝ່ ທີ່ ກຳ ລັງຫ້ອຍ, ແຕ່ມີຄວາມສອດຄ່ອງດີ.
    ///
    /// ນີ້ແມ່ນສິ່ງທີ່ເປັນປະໂຫຍດ ສຳ ລັບການເລີ່ມຕົ້ນປະເພດທີ່ຈັດສັນຢ່າງບໍ່ເປັນລະບຽບ, ເຊັ່ນວ່າ `Vec::new` ເຮັດ.
    ///
    /// ໃຫ້ສັງເກດວ່າຄ່າ pointer ອາດຈະເປັນຕົວແທນຂອງຕົວຊີ້ທີ່ຖືກຕ້ອງເຖິງ `T`, ໝາຍ ຄວາມວ່າສິ່ງນີ້ບໍ່ຄວນຖືກ ນຳ ໃຊ້ເປັນຄ່າ "not yet initialized".
    /// ປະເພດທີ່ຂີ້ກຽດຈັດສັນຕ້ອງຕິດຕາມການເລີ່ມຕົ້ນໂດຍວິທີອື່ນ.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // ຄວາມປອດໄພ: mem::align_of() ກັບຄືນປະໂຫຍດທີ່ບໍ່ແມ່ນສູນເຊິ່ງຖືກໂຍນອອກແລ້ວ
        // ເຖິງ * mut T.
        // ເພາະສະນັ້ນ, `ptr` ບໍ່ແມ່ນ null ແລະເງື່ອນໄຂໃນການໂທ new_unchecked() ແມ່ນຖືກເຄົາລົບ.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// ສົ່ງຄືນເອກະສານອ້າງອີງທີ່ແບ່ງປັນກັບມູນຄ່າ.ໃນທາງກົງກັນຂ້າມກັບ [`as_ref`], ນີ້ບໍ່ໄດ້ຮຽກຮ້ອງໃຫ້ມີຄ່າເລີ່ມຕົ້ນ.
    ///
    /// ສຳ ລັບຄູ່ຮ່ວມງານທີ່ປ່ຽນແປງໄດ້ເບິ່ງ [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// ເມື່ອໂທຫາວິທີການນີ້, ທ່ານຕ້ອງຮັບປະກັນວ່າສິ່ງທັງ ໝົດ ຕໍ່ໄປນີ້ແມ່ນຄວາມຈິງ:
    ///
    /// * ຕົວຊີ້ຕ້ອງຖືກຈັດໃຫ້ຖືກຕ້ອງ.
    ///
    /// * ມັນຕ້ອງເປັນ "dereferencable" ໃນຄວາມ ໝາຍ ທີ່ໄດ້ ກຳ ນົດໄວ້ໃນ [the module documentation].
    ///
    /// * ທ່ານຕ້ອງບັງຄັບໃຊ້ກົດລະບຽບທີ່ປອມແປງຂອງ Rust, ເພາະວ່າ `'a` ຕະຫຼອດຊີວິດທີ່ຖືກກັບມາແມ່ນຖືກເລືອກຢ່າງເດັດຂາດແລະບໍ່ ຈຳ ເປັນຕ້ອງສະທ້ອນໃຫ້ເຫັນເຖິງຊີວິດຈິງຂອງຂໍ້ມູນ.
    ///
    ///   ໂດຍສະເພາະ, ໃນໄລຍະເວລາຂອງຊີວິດນີ້, ຄວາມຊົງ ຈຳ ທີ່ຕົວຊີ້ຊີ້ທີ່ຕ້ອງບໍ່ປ່ຽນແປງ (ຍົກເວັ້ນພາຍໃນ `UnsafeCell`).
    ///
    /// ນີ້ຍັງໃຊ້ໄດ້ເຖິງແມ່ນວ່າຜົນຂອງວິທີການນີ້ບໍ່ໄດ້ຖືກ ນຳ ໃຊ້!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // ປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `self` ຕອບສະ ໜອງ ໄດ້ທຸກຢ່າງ
        // ຄວາມຕ້ອງການ ສຳ ລັບການອ້າງອີງ.
        unsafe { &*self.cast().as_ptr() }
    }

    /// ສົ່ງຄືນເອກະສານອ້າງອີງທີ່ບໍ່ຊ້ ຳ ກັບຄ່າ.ໃນທາງກົງກັນຂ້າມກັບ [`as_mut`], ນີ້ບໍ່ໄດ້ຮຽກຮ້ອງໃຫ້ມີຄ່າເລີ່ມຕົ້ນ.
    ///
    /// ສຳ ລັບຄູ່ຮ່ວມງານທີ່ເຫັນຮ່ວມກັນເບິ່ງ [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// ເມື່ອໂທຫາວິທີການນີ້, ທ່ານຕ້ອງຮັບປະກັນວ່າສິ່ງທັງ ໝົດ ຕໍ່ໄປນີ້ແມ່ນຄວາມຈິງ:
    ///
    /// * ຕົວຊີ້ຕ້ອງຖືກຈັດໃຫ້ຖືກຕ້ອງ.
    ///
    /// * ມັນຕ້ອງເປັນ "dereferencable" ໃນຄວາມ ໝາຍ ທີ່ໄດ້ ກຳ ນົດໄວ້ໃນ [the module documentation].
    ///
    /// * ທ່ານຕ້ອງບັງຄັບໃຊ້ກົດລະບຽບທີ່ປອມແປງຂອງ Rust, ເພາະວ່າ `'a` ຕະຫຼອດຊີວິດທີ່ຖືກກັບມາແມ່ນຖືກເລືອກຢ່າງເດັດຂາດແລະບໍ່ ຈຳ ເປັນຕ້ອງສະທ້ອນໃຫ້ເຫັນເຖິງຊີວິດຈິງຂອງຂໍ້ມູນ.
    ///
    ///   ໂດຍສະເພາະ, ໃນໄລຍະເວລາຂອງຊີວິດນີ້, ຄວາມຊົງ ຈຳ ທີ່ຕົວຊີ້ຊີ້ຕ້ອງບໍ່ໃຫ້ເຂົ້າເຖິງ (ອ່ານຫລືຂຽນ) ຜ່ານຕົວຊີ້ອື່ນໆ.
    ///
    /// ນີ້ຍັງໃຊ້ໄດ້ເຖິງແມ່ນວ່າຜົນຂອງວິທີການນີ້ບໍ່ໄດ້ຖືກ ນຳ ໃຊ້!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // ປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `self` ຕອບສະ ໜອງ ໄດ້ທຸກຢ່າງ
        // ຄວາມຕ້ອງການ ສຳ ລັບການອ້າງອີງ.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// ສ້າງ `NonNull` ໃໝ່.
    ///
    /// # Safety
    ///
    /// `ptr` ຕ້ອງບໍ່ແມ່ນ null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `ptr` ບໍ່ແມ່ນສິ່ງທີ່ບໍ່ແມ່ນ.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// ສ້າງ `NonNull` ໃໝ່ ຖ້າ `ptr` ບໍ່ແມ່ນ null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ຄວາມປອດໄພ: ຕົວຊີ້ໄດ້ຖືກກວດເບິ່ງແລ້ວແລະບໍ່ແມ່ນສິ່ງທີ່ບໍ່ເປັນປະໂຫຍດ
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// ປະຕິບັດຫນ້າທີ່ຄືກັນກັບ [`std::ptr::from_raw_parts`], ຍົກເວັ້ນວ່າຕົວຊີ້ `NonNull` ຖືກສົ່ງຄືນ, ເຊິ່ງກົງກັນຂ້າມກັບຕົວຊີ້ວັດ `*const` ດິບ.
    ///
    ///
    /// ເບິ່ງເອກະສານຂອງ [`std::ptr::from_raw_parts`] ສໍາລັບລາຍລະອຽດເພີ່ມເຕີມ.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // ຄວາມປອດໄພ: ຜົນຂອງ `ptr::from::raw_parts_mut` ແມ່ນບໍ່ແມ່ນຍ້ອນວ່າ `data_address` ແມ່ນ.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// ແຍກຕົວຊີ້ (ອາດຈະກວ້າງກ່ວາ) ເຂົ້າໄປໃນທີ່ຢູ່ແລະສ່ວນປະກອບຂອງເມຕາເດຕາ.
    ///
    /// ຕົວຊີ້ສາມາດຕໍ່ມາກໍ່ສ້າງ ໃໝ່ ດ້ວຍ [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// ຊື້ຕົວຊີ້ `*mut` X ທີ່ຕິດພັນ.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// ສົ່ງຄືນເອກະສານອ້າງອີງທີ່ແບ່ງປັນກັບມູນຄ່າ.ຖ້າວ່າມູນຄ່າອາດຈະບໍ່ມີການປ່ຽນແປງ, [`as_uninit_ref`] ຕ້ອງໃຊ້ແທນ.
    ///
    /// ສຳ ລັບຄູ່ຮ່ວມງານທີ່ປ່ຽນແປງໄດ້ເບິ່ງ [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// ເມື່ອໂທຫາວິທີການນີ້, ທ່ານຕ້ອງຮັບປະກັນວ່າສິ່ງທັງ ໝົດ ຕໍ່ໄປນີ້ແມ່ນຄວາມຈິງ:
    ///
    /// * ຕົວຊີ້ຕ້ອງຖືກຈັດໃຫ້ຖືກຕ້ອງ.
    ///
    /// * ມັນຕ້ອງເປັນ "dereferencable" ໃນຄວາມ ໝາຍ ທີ່ໄດ້ ກຳ ນົດໄວ້ໃນ [the module documentation].
    ///
    /// * ຕົວຊີ້ຕ້ອງຕ້ອງຊີ້ໃຫ້ເຫັນຕົວຢ່າງເລີ່ມຕົ້ນຂອງ `T`.
    ///
    /// * ທ່ານຕ້ອງບັງຄັບໃຊ້ກົດລະບຽບທີ່ປອມແປງຂອງ Rust, ເພາະວ່າ `'a` ຕະຫຼອດຊີວິດທີ່ຖືກກັບມາແມ່ນຖືກເລືອກຢ່າງເດັດຂາດແລະບໍ່ ຈຳ ເປັນຕ້ອງສະທ້ອນໃຫ້ເຫັນເຖິງຊີວິດຈິງຂອງຂໍ້ມູນ.
    ///
    ///   ໂດຍສະເພາະ, ໃນໄລຍະເວລາຂອງຊີວິດນີ້, ຄວາມຊົງ ຈຳ ທີ່ຕົວຊີ້ຊີ້ທີ່ຕ້ອງບໍ່ປ່ຽນແປງ (ຍົກເວັ້ນພາຍໃນ `UnsafeCell`).
    ///
    /// ນີ້ຍັງໃຊ້ໄດ້ເຖິງແມ່ນວ່າຜົນຂອງວິທີການນີ້ບໍ່ໄດ້ຖືກ ນຳ ໃຊ້!
    /// (ພາກສ່ວນກ່ຽວກັບການເລີ່ມຕົ້ນແມ່ນຍັງບໍ່ທັນໄດ້ຕັດສິນໃຈຢ່າງເຕັມທີ່, ແຕ່ຈົນກ່ວາມັນ, ວິທີການທີ່ປອດໄພພຽງແຕ່ແມ່ນເພື່ອຮັບປະກັນວ່າພວກເຂົາໄດ້ຖືກເລີ່ມຕົ້ນຢ່າງແທ້ຈິງ.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `self` ຕອບສະ ໜອງ ໄດ້ທຸກຢ່າງ
        // ຄວາມຕ້ອງການ ສຳ ລັບການອ້າງອີງ.
        unsafe { &*self.as_ptr() }
    }

    /// ສົ່ງຄືນເອກະສານອ້າງອີງທີ່ບໍ່ຊ້ ຳ ກັບຄ່າ.ຖ້າວ່າມູນຄ່າອາດຈະບໍ່ມີການປ່ຽນແປງ, [`as_uninit_mut`] ຕ້ອງໃຊ້ແທນ.
    ///
    /// ສຳ ລັບຄູ່ຮ່ວມງານທີ່ເຫັນຮ່ວມກັນເບິ່ງ [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// ເມື່ອໂທຫາວິທີການນີ້, ທ່ານຕ້ອງຮັບປະກັນວ່າສິ່ງທັງ ໝົດ ຕໍ່ໄປນີ້ແມ່ນຄວາມຈິງ:
    ///
    /// * ຕົວຊີ້ຕ້ອງຖືກຈັດໃຫ້ຖືກຕ້ອງ.
    ///
    /// * ມັນຕ້ອງເປັນ "dereferencable" ໃນຄວາມ ໝາຍ ທີ່ໄດ້ ກຳ ນົດໄວ້ໃນ [the module documentation].
    ///
    /// * ຕົວຊີ້ຕ້ອງຕ້ອງຊີ້ໃຫ້ເຫັນຕົວຢ່າງເລີ່ມຕົ້ນຂອງ `T`.
    ///
    /// * ທ່ານຕ້ອງບັງຄັບໃຊ້ກົດລະບຽບທີ່ປອມແປງຂອງ Rust, ເພາະວ່າ `'a` ຕະຫຼອດຊີວິດທີ່ຖືກກັບມາແມ່ນຖືກເລືອກຢ່າງເດັດຂາດແລະບໍ່ ຈຳ ເປັນຕ້ອງສະທ້ອນໃຫ້ເຫັນເຖິງຊີວິດຈິງຂອງຂໍ້ມູນ.
    ///
    ///   ໂດຍສະເພາະ, ໃນໄລຍະເວລາຂອງຊີວິດນີ້, ຄວາມຊົງ ຈຳ ທີ່ຕົວຊີ້ຊີ້ຕ້ອງບໍ່ໃຫ້ເຂົ້າເຖິງ (ອ່ານຫລືຂຽນ) ຜ່ານຕົວຊີ້ອື່ນໆ.
    ///
    /// ນີ້ຍັງໃຊ້ໄດ້ເຖິງແມ່ນວ່າຜົນຂອງວິທີການນີ້ບໍ່ໄດ້ຖືກ ນຳ ໃຊ້!
    /// (ພາກສ່ວນກ່ຽວກັບການເລີ່ມຕົ້ນແມ່ນຍັງບໍ່ທັນໄດ້ຕັດສິນໃຈຢ່າງເຕັມທີ່, ແຕ່ຈົນກ່ວາມັນ, ວິທີການທີ່ປອດໄພພຽງແຕ່ແມ່ນເພື່ອຮັບປະກັນວ່າພວກເຂົາໄດ້ຖືກເລີ່ມຕົ້ນຢ່າງແທ້ຈິງ.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `self` ຕອບສະ ໜອງ ໄດ້ທຸກຢ່າງ
        // ຄວາມຕ້ອງການ ສຳ ລັບການອ້າງອີງທີ່ປ່ຽນແປງໄດ້.
        unsafe { &mut *self.as_ptr() }
    }

    /// ໂຍນໄປຫາຕົວຊີ້ຂອງປະເພດອື່ນ.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SAFETY: `self` ເປັນຊີ້ `NonNull` ຊຶ່ງເປັນຈໍາເປັນທີ່ບໍ່ແມ່ນ null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// ສ້າງເສັ້ນລ້ອນດິບທີ່ບໍ່ມີມົນຈາກຕົວຊີ້ບາງໆແລະລວງຍາວ.
    ///
    /// ການໂຕ້ຖຽງ `len` ແມ່ນ ຈຳ ນວນຂອງ **ອົງປະກອບ**, ບໍ່ແມ່ນ ຈຳ ນວນໄບຕ໌.
    ///
    /// ຟັງຊັນນີ້ແມ່ນປອດໄພ, ແຕ່ການປະຕິບັດມູນຄ່າກັບຄືນແມ່ນບໍ່ປອດໄພ.
    /// ເບິ່ງເອກະສານຂອງ [`slice::from_raw_parts`] ສຳ ລັບຄວາມຕ້ອງການດ້ານຄວາມປອດໄພ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ສ້າງຕົວຊີ້ຫຼັງຈາກທີ່ເລີ່ມຕົ້ນດ້ວຍຕົວຊີ້ໄປຫາອົງປະກອບ ທຳ ອິດ
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (ໃຫ້ສັງເກດວ່າຕົວຢ່າງນີ້ປອມສະແດງໃຫ້ເຫັນການ ນຳ ໃຊ້ວິທີການນີ້, ແຕ່ `ປ່ອຍໃຫ້ຊິ້ນ= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // ຄວາມປອດໄພ: `data` ແມ່ນຕົວຊີ້ `NonNull` ເຊິ່ງ ຈຳ ເປັນທີ່ບໍ່ແມ່ນສິ່ງລົບກວນ
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// ຜົນຕອບແທນຄວາມຍາວຂອງທີ່ບໍ່ແມ່ນ null ຫຼັງຈາກນັ້ນນໍາຂອງວັດຖຸດິບ.
    ///
    /// ມູນຄ່າທີ່ສົ່ງຄືນແມ່ນ ຈຳ ນວນ **ອົງປະກອບ** ບໍ່ແມ່ນ ຈຳ ນວນໄບຕ໌.
    ///
    /// ຟັງຊັ່ນນີ້ມີຄວາມປອດໄພ, ເຖິງແມ່ນວ່າແຜ່ນດິບທີ່ບໍ່ແມ່ນ null ບໍ່ສາມາດຖືກຕັດເປັນສ່ວນ ໜຶ່ງ ໄດ້ເພາະວ່າຕົວຊີ້ບໍ່ມີທີ່ຢູ່ທີ່ຖືກຕ້ອງ.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// ສົ່ງກັບຄືນທີ່ບໍ່ແມ່ນ null ກັບ buffer ຂອງຊິ້ນ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // ຄວາມປອດໄພ: ພວກເຮົາຮູ້ວ່າ `self` ແມ່ນບໍ່ແມ່ນ.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// ສົ່ງເຄື່ອງຊີ້ວັດຖຸດິບຄືນໃຫ້ແທັບຄວາຍຂອງແຜ່ນ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// ສົ່ງຄືນເອກະສານອ້າງອີງທີ່ແບ່ງປັນໃຫ້ກັບສ່ວນ ໜຶ່ງ ຂອງຄ່າທີ່ບໍ່ມີການປ່ຽນແປງ.ໃນທາງກົງກັນຂ້າມກັບ [`as_ref`], ນີ້ບໍ່ໄດ້ຮຽກຮ້ອງໃຫ້ມີຄ່າເລີ່ມຕົ້ນ.
    ///
    /// ສຳ ລັບຄູ່ຮ່ວມງານທີ່ປ່ຽນແປງໄດ້ເບິ່ງ [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// ເມື່ອໂທຫາວິທີການນີ້, ທ່ານຕ້ອງຮັບປະກັນວ່າສິ່ງທັງ ໝົດ ຕໍ່ໄປນີ້ແມ່ນຄວາມຈິງ:
    ///
    /// * ຕົວຊີ້ຕ້ອງເປັນ [valid] ສຳ ລັບອ່ານ ສຳ ລັບ `ptr.len() * mem::size_of::<T>()` ຫລາຍໄບຕ໌, ແລະມັນຕ້ອງຖືກຈັດໃຫ້ຖືກຕ້ອງ.ນີ້ ໝາຍ ຄວາມວ່າໂດຍສະເພາະ:
    ///
    ///     * ຂອບເຂດຄວາມຊົງ ຈຳ ທັງ ໝົດ ຂອງໃບຂະ ໜາດ ນີ້ຕ້ອງມີຢູ່ໃນວັດຖຸຈັດສັນດຽວ!
    ///       ແຜ່ນສະໄລ້ບໍ່ສາມາດແຜ່ໄປທົ່ວວັດຖຸທີ່ຈັດສັນໄວ້ໄດ້ຫລາຍຢ່າງ.
    ///
    ///     * ຕົວຊີ້ຕ້ອງຖືກຈັດຮຽງເຖິງແມ່ນວ່າຈະມີຄວາມຍາວເທົ່າກັບສູນ.
    ///     ເຫດຜົນ ໜຶ່ງ ສຳ ລັບສິ່ງນີ້ແມ່ນວ່າການເພີ່ມປະສິດທິພາບໃນການຈັດຮູບແບບ enum ອາດຈະອີງໃສ່ເອກະສານອ້າງອີງ (ລວມທັງຄວາມຍາວຂອງຄວາມຍາວໃດໆ) ທີ່ສອດຄ່ອງແລະບໍ່ມີຄວາມ ໝາຍ ເພື່ອແຍກແຍະພວກເຂົາຈາກຂໍ້ມູນອື່ນໆ.
    ///
    ///     ທ່ານສາມາດເອົາຕົວຊີ້ທີ່ສາມາດໃຊ້ໄດ້ເປັນ `data` ສຳ ລັບຊິ້ນສ່ວນຄວາມຍາວສູນໂດຍໃຊ້ [`NonNull::dangling()`].
    ///
    /// * ຂະ ໜາດ `ptr.len() * mem::size_of::<T>()` ຂອງຂະ ໜາດ ທັງ ໝົດ ຕ້ອງບໍ່ເກີນ `isize::MAX`.
    ///   ເບິ່ງເອກະສານກ່ຽວກັບຄວາມປອດໄພຂອງ [`pointer::offset`].
    ///
    /// * ທ່ານຕ້ອງບັງຄັບໃຊ້ກົດລະບຽບທີ່ປອມແປງຂອງ Rust, ເພາະວ່າ `'a` ຕະຫຼອດຊີວິດທີ່ຖືກກັບມາແມ່ນຖືກເລືອກຢ່າງເດັດຂາດແລະບໍ່ ຈຳ ເປັນຕ້ອງສະທ້ອນໃຫ້ເຫັນເຖິງຊີວິດຈິງຂອງຂໍ້ມູນ.
    ///   ໂດຍສະເພາະ, ໃນໄລຍະເວລາຂອງຊີວິດນີ້, ຄວາມຊົງ ຈຳ ທີ່ຕົວຊີ້ຊີ້ທີ່ຕ້ອງບໍ່ປ່ຽນແປງ (ຍົກເວັ້ນພາຍໃນ `UnsafeCell`).
    ///
    /// ນີ້ຍັງໃຊ້ໄດ້ເຖິງແມ່ນວ່າຜົນຂອງວິທີການນີ້ບໍ່ໄດ້ຖືກ ນຳ ໃຊ້!
    ///
    /// ເບິ່ງທີ່ [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// ສົ່ງຄືນເອກະສານອ້າງອີງທີ່ເປັນເອກະລັກສະເພາະກັບຄຸນຄ່າທີ່ບໍ່ມີການປ່ຽນແປງ.ໃນທາງກົງກັນຂ້າມກັບ [`as_mut`], ນີ້ບໍ່ໄດ້ຮຽກຮ້ອງໃຫ້ມີຄ່າເລີ່ມຕົ້ນ.
    ///
    /// ສຳ ລັບຄູ່ຮ່ວມງານທີ່ເຫັນຮ່ວມກັນເບິ່ງ [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// ເມື່ອໂທຫາວິທີການນີ້, ທ່ານຕ້ອງຮັບປະກັນວ່າສິ່ງທັງ ໝົດ ຕໍ່ໄປນີ້ແມ່ນຄວາມຈິງ:
    ///
    /// * ຕົວຊີ້ຕ້ອງເປັນ [valid] ສຳ ລັບການອ່ານແລະຂຽນ ສຳ ລັບ `ptr.len() * mem::size_of::<T>()` ຫລາຍໄບຕ໌, ແລະມັນຕ້ອງຖືກຈັດໃຫ້ຖືກຕ້ອງ.ນີ້ ໝາຍ ຄວາມວ່າໂດຍສະເພາະ:
    ///
    ///     * ຂອບເຂດຄວາມຊົງ ຈຳ ທັງ ໝົດ ຂອງໃບຂະ ໜາດ ນີ້ຕ້ອງມີຢູ່ໃນວັດຖຸຈັດສັນດຽວ!
    ///       ແຜ່ນສະໄລ້ບໍ່ສາມາດແຜ່ໄປທົ່ວວັດຖຸທີ່ຈັດສັນໄວ້ໄດ້ຫລາຍຢ່າງ.
    ///
    ///     * ຕົວຊີ້ຕ້ອງຖືກຈັດຮຽງເຖິງແມ່ນວ່າຈະມີຄວາມຍາວເທົ່າກັບສູນ.
    ///     ເຫດຜົນ ໜຶ່ງ ສຳ ລັບສິ່ງນີ້ແມ່ນວ່າການເພີ່ມປະສິດທິພາບໃນການຈັດຮູບແບບ enum ອາດຈະອີງໃສ່ເອກະສານອ້າງອີງ (ລວມທັງຄວາມຍາວຂອງຄວາມຍາວໃດໆ) ທີ່ສອດຄ່ອງແລະບໍ່ມີຄວາມ ໝາຍ ເພື່ອແຍກແຍະພວກເຂົາຈາກຂໍ້ມູນອື່ນໆ.
    ///
    ///     ທ່ານສາມາດເອົາຕົວຊີ້ທີ່ສາມາດໃຊ້ໄດ້ເປັນ `data` ສຳ ລັບຊິ້ນສ່ວນຄວາມຍາວສູນໂດຍໃຊ້ [`NonNull::dangling()`].
    ///
    /// * ຂະ ໜາດ `ptr.len() * mem::size_of::<T>()` ຂອງຂະ ໜາດ ທັງ ໝົດ ຕ້ອງບໍ່ເກີນ `isize::MAX`.
    ///   ເບິ່ງເອກະສານກ່ຽວກັບຄວາມປອດໄພຂອງ [`pointer::offset`].
    ///
    /// * ທ່ານຕ້ອງບັງຄັບໃຊ້ກົດລະບຽບທີ່ປອມແປງຂອງ Rust, ເພາະວ່າ `'a` ຕະຫຼອດຊີວິດທີ່ຖືກກັບມາແມ່ນຖືກເລືອກຢ່າງເດັດຂາດແລະບໍ່ ຈຳ ເປັນຕ້ອງສະທ້ອນໃຫ້ເຫັນເຖິງຊີວິດຈິງຂອງຂໍ້ມູນ.
    ///   ໂດຍສະເພາະ, ໃນໄລຍະເວລາຂອງຊີວິດນີ້, ຄວາມຊົງ ຈຳ ທີ່ຕົວຊີ້ຊີ້ຕ້ອງບໍ່ໃຫ້ເຂົ້າເຖິງ (ອ່ານຫລືຂຽນ) ຜ່ານຕົວຊີ້ອື່ນໆ.
    ///
    /// ນີ້ຍັງໃຊ້ໄດ້ເຖິງແມ່ນວ່າຜົນຂອງວິທີການນີ້ບໍ່ໄດ້ຖືກ ນຳ ໃຊ້!
    ///
    /// ເບິ່ງທີ່ [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // ນີ້ແມ່ນປອດໄພທີ່ `memory` ແມ່ນຖືກຕ້ອງ ສຳ ລັບການອ່ານແລະຂຽນ ສຳ ລັບ `memory.len()` ຫຼາຍໄບຕ໌.
    /// // ໃຫ້ສັງເກດວ່າການໂທຫາ `memory.as_mut()` ບໍ່ໄດ້ຖືກອະນຸຍາດຢູ່ທີ່ນີ້ຍ້ອນວ່າເນື້ອຫາອາດຈະບໍ່ເປັນເອກະພາບ.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຍຶດ ໝັ້ນ ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// ສົ່ງຄືນຕົວຊີ້ວັດຖຸດິບໄປຫາສ່ວນປະກອບຫລືການຍ່ອຍ, ໂດຍບໍ່ຕ້ອງກວດສອບຂໍ້ຜູກມັດ.
    ///
    /// ການໂທຫາວິທີການນີ້ດ້ວຍດັດສະນີທີ່ບໍ່ມີຂອບເຂດຫລືເມື່ອ `self` ບໍ່ຍອມຮັບແມ່ນ *[ພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ]* ເຖິງແມ່ນວ່າຕົວຊີ້ຜົນທີ່ບໍ່ໄດ້ຖືກໃຊ້.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // ຄວາມປອດໄພ: ຜູ້ໂທຮັບປະກັນວ່າ `self` ແມ່ນບໍ່ສາມາດຍອມຮັບໄດ້ແລະ `index` ໃນການຜູກມັດ.
        // ຍ້ອນເຫດນັ້ນ, ຕົວຊີ້ຊີ້ຜົນທີ່ບໍ່ສາມາດເປັນ NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // ຄວາມປອດໄພ: ຕົວຊີ້ທີ່ບໍ່ເປັນເອກະລັກບໍ່ສາມາດຖືກດຶງດູດໄດ້, ສະນັ້ນເງື່ອນໄຂ ສຳ ລັບ
        // new_unchecked() ແມ່ນເຄົາລົບນັບຖື.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ຄວາມປອດໄພ: ເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ບໍ່ສາມາດຖືກປະຕິເສດ.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // ຄວາມປອດໄພ: ເອກະສານອ້າງອີງບໍ່ສາມາດຖືກດຶງດູດ, ສະນັ້ນເງື່ອນໄຂ ສຳ ລັບ
        // new_unchecked() ແມ່ນເຄົາລົບນັບຖື.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}