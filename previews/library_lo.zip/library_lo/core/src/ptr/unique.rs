use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// ເຄື່ອງຫໍ່ອ້ອມຮອບ `*mut T` ວັດຖຸດິບທີ່ບໍ່ແມ່ນ null ເຊິ່ງຊີ້ໃຫ້ເຫັນວ່າຜູ້ຄອບຄອງເຄື່ອງຫໍ່ນີ້ເປັນເຈົ້າຂອງເອກະສານອ້າງອີງ.
/// ທີ່ເປັນປະໂຫຍດສໍາລັບການກໍ່ສ້າງມີຕົວຕົນເຊັ່ນ: `Box<T>`, `Vec<T>`, `String` ແລະ `HashMap<K, V>`.
///
/// ຕ່າງຈາກ `*mut T`, `Unique<T>` ປະພຶດຕົວ "as if" ມັນແມ່ນຕົວຢ່າງຂອງ `T`.
/// ມັນປະຕິບັດ `Send`/`Sync` ຖ້າ `T` ແມ່ນ `Send`/`Sync`.
/// ມັນຍັງ ໝາຍ ເຖິງປະເພດຂອງການຮັບປະກັນນາມແຝງທີ່ເຂັ້ມແຂງຕົວຢ່າງຂອງ `T` ສາມາດຄາດຫວັງໄດ້:
/// ເອກະສານອ້າງອີງຂອງຕົວຊີ້ບໍ່ຄວນຈະຖືກດັດແກ້ໂດຍບໍ່ມີເສັ້ນທາງທີ່ເປັນເອກະລັກໄປສູ່ການເປັນເອກະລັກຂອງມັນ.
///
/// ຖ້າທ່ານບໍ່ແນ່ໃຈວ່າມັນຖືກຕ້ອງທີ່ຈະໃຊ້ `Unique` ເພື່ອຈຸດປະສົງຂອງທ່ານ, ໃຫ້ພິຈາລະນາໃຊ້ `NonNull`, ເຊິ່ງມີ semantics ທີ່ອ່ອນແອກວ່າ.
///
///
/// ບໍ່ຄືກັບ `*mut T`, ຕົວຊີ້ຕ້ອງສະ ເໝີ ໄປທີ່ບໍ່ແມ່ນສິ່ງລົບກວນ, ເຖິງແມ່ນວ່າຕົວຊີ້ຈະບໍ່ຖືກລົບກວນ.
/// ນີ້ແມ່ນເພື່ອໃຫ້ສະຖານທີ່ຕ່າງໆສາມາດ ນຳ ໃຊ້ມູນຄ່າທີ່ຖືກຫ້າມນີ້ເປັນການ ຈຳ ແນກ-`Option<Unique<T>>` ມີຂະ ໜາດ ເທົ່າກັບ `Unique<T>`.
/// ເຖິງຢ່າງໃດກໍ່ຕາມຕົວຊີ້ກໍ່ຍັງຄົງຄ້າງຖ້າມັນບໍ່ໄດ້ຮັບການພິຈາລະນາ.
///
/// ບໍ່ຄືກັບ `*mut T`, `Unique<T>` ແມ່ນ covariant ເກີນ `T`.
/// ສິ່ງນີ້ຄວນຈະຖືກຕ້ອງສະ ເໝີ ໄປ ສຳ ລັບປະເພດໃດ ໜຶ່ງ ທີ່ຍຶດ ໝັ້ນ ຄວາມຮຽກຮ້ອງຕ້ອງການນາມແຝງຂອງເອກະລັກ.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ເຄື່ອງ ໝາຍ ນີ້ບໍ່ມີຜົນສະທ້ອນຕໍ່ຄວາມແຕກຕ່າງ, ແຕ່ມີຄວາມ ຈຳ ເປັນ
    // ສໍາລັບການຫຼຸດລົງທີ່ຈະເຂົ້າໃຈວ່າພວກເຮົາເປັນເຈົ້າຂອງ `T` ຢ່າງມີເຫດຜົນ.
    //
    // ສຳ ລັບລາຍລະອຽດ, ເບິ່ງ:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` ຕົວຊີ້ແມ່ນ `Send` ຖ້າ `T` ແມ່ນ `Send` ເພາະວ່າຂໍ້ມູນທີ່ພວກເຂົາອ້າງອີງແມ່ນບໍ່ມີຊື່ສຽງ.
/// ໃຫ້ສັງເກດວ່າການບຸກລຸກທີ່ປອມແປງນີ້ແມ່ນບໍ່ໄດ້ບັງຄັບໃຊ້ໂດຍລະບົບປະເພດ;ບົດສະຫຼຸບການ ນຳ ໃຊ້ `Unique` ຕ້ອງບັງຄັບໃຊ້ມັນ.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` ຕົວຊີ້ແມ່ນ `Sync` ຖ້າ `T` ແມ່ນ `Sync` ເພາະວ່າຂໍ້ມູນທີ່ພວກເຂົາອ້າງອີງແມ່ນບໍ່ມີຊື່ສຽງ.
/// ໃຫ້ສັງເກດວ່າການບຸກລຸກທີ່ປອມແປງນີ້ແມ່ນບໍ່ໄດ້ບັງຄັບໃຊ້ໂດຍລະບົບປະເພດ;ບົດສະຫຼຸບການ ນຳ ໃຊ້ `Unique` ຕ້ອງບັງຄັບໃຊ້ມັນ.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// ສ້າງ `Unique` ແບບ ໃໝ່ ທີ່ ກຳ ລັງຫ້ອຍ, ແຕ່ມີຄວາມສອດຄ່ອງດີ.
    ///
    /// ນີ້ແມ່ນສິ່ງທີ່ເປັນປະໂຫຍດ ສຳ ລັບການເລີ່ມຕົ້ນປະເພດທີ່ຈັດສັນຢ່າງບໍ່ເປັນລະບຽບ, ເຊັ່ນວ່າ `Vec::new` ເຮັດ.
    ///
    /// ໃຫ້ສັງເກດວ່າຄ່າ pointer ອາດຈະເປັນຕົວແທນຂອງຕົວຊີ້ທີ່ຖືກຕ້ອງເຖິງ `T`, ໝາຍ ຄວາມວ່າສິ່ງນີ້ບໍ່ຄວນຖືກ ນຳ ໃຊ້ເປັນຄ່າ "not yet initialized".
    /// ປະເພດທີ່ຂີ້ກຽດຈັດສັນຕ້ອງຕິດຕາມການເລີ່ມຕົ້ນໂດຍວິທີອື່ນ.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // ຄວາມປອດໄພ: mem::align_of() ສົ່ງຄືນຕົວຊີ້ທີ່ຖືກຕ້ອງແລະບໍ່ມີສຽງ.ທ
        // ເງື່ອນໄຂທີ່ຈະໂທຫາ new_unchecked() ແມ່ນຖືກເຄົາລົບ.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// ສ້າງ `Unique` ໃໝ່.
    ///
    /// # Safety
    ///
    /// `ptr` ຕ້ອງບໍ່ແມ່ນ null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ຄວາມປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `ptr` ບໍ່ແມ່ນສິ່ງທີ່ບໍ່ແມ່ນ.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// ສ້າງ `Unique` ໃໝ່ ຖ້າ `ptr` ບໍ່ແມ່ນ null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ຄວາມປອດໄພ: ຕົວຊີ້ໄດ້ຖືກກວດກາແລ້ວແລະບໍ່ແມ່ນສິ່ງທີ່ບໍ່ໄດ້ໃຊ້.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// ຊື້ຕົວຊີ້ `*mut` X ທີ່ຕິດພັນ.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// ອ້າງອີງເນື້ອໃນ.
    ///
    /// ອາຍຸການທີ່ໄດ້ຮັບຈະຖືກຜູກມັດກັບຕົວເອງດັ່ງນັ້ນສິ່ງນີ້ປະຕິບັດຕົວຈິງ "as if" ມັນແມ່ນຕົວຢ່າງຂອງ T ທີ່ໄດ້ຮັບການຢືມ.
    /// ຖ້າຕ້ອງການຊີວິດ (unbound) ທີ່ຍາວກວ່າ, ໃຊ້ `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `self` ຕອບສະ ໜອງ ໄດ້ທຸກຢ່າງ
        // ຄວາມຕ້ອງການ ສຳ ລັບການອ້າງອີງ.
        unsafe { &*self.as_ptr() }
    }

    /// ການອ້າງອິງເນື້ອຫາເຊິ່ງກັນແລະກັນ.
    ///
    /// ອາຍຸການທີ່ໄດ້ຮັບຈະຖືກຜູກມັດກັບຕົວເອງດັ່ງນັ້ນສິ່ງນີ້ປະຕິບັດຕົວຈິງ "as if" ມັນແມ່ນຕົວຢ່າງຂອງ T ທີ່ໄດ້ຮັບການຢືມ.
    /// ຖ້າຕ້ອງການຊີວິດ (unbound) ທີ່ຍາວກວ່າ, ໃຊ້ `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ປອດໄພ: ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `self` ຕອບສະ ໜອງ ໄດ້ທຸກຢ່າງ
        // ຄວາມຕ້ອງການ ສຳ ລັບການອ້າງອີງທີ່ປ່ຽນແປງໄດ້.
        unsafe { &mut *self.as_ptr() }
    }

    /// ໂຍນໄປຫາຕົວຊີ້ຂອງປະເພດອື່ນ.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // ຄວາມປອດໄພ: Unique::new_unchecked() ສ້າງຄວາມເປັນເອກະລັກແລະຄວາມຕ້ອງການ ໃໝ່
        // ຕົວຊີ້ບອກທີ່ໃຫ້ໄວ້ເພື່ອບໍ່ໃຫ້ເປັນໂມຄະ.
        // ເນື່ອງຈາກວ່າພວກເຮົາ ກຳ ລັງຖ່າຍທອດຕົນເອງເປັນຕົວຊີ້, ມັນບໍ່ສາມາດເຮັດໄດ້.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ຄວາມປອດໄພ: ເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ບໍ່ສາມາດຖືກປະຕິເສດ
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}