#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// ສະ ໜອງ ຂໍ້ມູນ metadata ຂອງຕົວຊີ້ຂອງປະເພດທີ່ຊີ້ໄປຫາຈຸດໃດ ໜຶ່ງ.
///
/// # metadata ຕົວຊີ້
///
/// ປະເພດຕົວຊີ້ວັດຖຸດິບແລະປະເພດກະສານອ້າງອີງໃນ Rust ສາມາດຄິດໄດ້ວ່າເປັນສອງສ່ວນຄື:
/// ຕົວຊີ້ວັດຂໍ້ມູນທີ່ມີທີ່ຢູ່ຂອງຄວາມຊົງ ຈຳ ຂອງມູນຄ່າແລະບາງຂໍ້ມູນ metadata.
///
/// ສຳ ລັບຊະນິດທີ່ມີຂະ ໜາດ ທາງດ້ານສະຖິຕິ (ທີ່ປະຕິບັດ `Sized` traits) ແລະ ສຳ ລັບປະເພດ `extern`, ຕົວຊີ້ບອກໄດ້ຖືກກ່າວວ່າ "ເບົາ": ເມຕາດາຕາແມ່ນຂະ ໜາດ ສູນແລະປະເພດຂອງມັນແມ່ນ `()`.
///
///
/// ຕົວຊີ້ໃຫ້ເຫັນເຖິງ [dynamically-sized types][dst] ໄດ້ຖືກກ່າວເຖິງວ່າ "ກວ້າງ" ຫຼື "ໄຂມັນ", ພວກມັນມີເມຕາດາຕາທີ່ບໍ່ແມ່ນຂະ ໜາດ:
///
/// * ສຳ ລັບໂຄງສ້າງທີ່ມີສະ ໜາມ ຄັ້ງສຸດທ້າຍແມ່ນ DST, ຂໍ້ມູນ metadata ແມ່ນເມຕາເດຕາ ສຳ ລັບພາກສະ ໜາມ ສຸດທ້າຍ
/// * ສຳ ລັບປະເພດ `str`, ເມຕາເດຕາແມ່ນຄວາມຍາວທີ່ເປັນໄບເປັນ `usize`
/// * ສຳ ລັບປະເພດ ຄຳ ສັບຄ້າຍຄື `[T]`, ເມຕາເດຕາແມ່ນຄວາມຍາວຂອງສິນຄ້າຄື `usize`
/// * ສຳ ລັບວັດຖຸ trait ເຊັ່ນ `dyn SomeTrait`, ເມຕາເດຕາແມ່ນ [`DynMetadata<Self>`][DynMetadata] (ຕົວຢ່າງ `DynMetadata<dyn SomeTrait>`)
///
/// ໃນພາສາ future, ພາສາ Rust ອາດຈະໄດ້ຮັບປະເພດແບບ ໃໝ່ ທີ່ມີເມຕາທິຖານຕົວຊີ້ທີ່ແຕກຕ່າງກັນ.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # The `Pointee` trait
///
/// ຈຸດ ສຳ ຄັນຂອງ trait ແມ່ນປະເພດທີ່ກ່ຽວຂ້ອງ `Metadata` ຂອງມັນ, ເຊິ່ງມັນແມ່ນ `()` ຫຼື `usize` ຫຼື `DynMetadata<_>` ດັ່ງທີ່ໄດ້ອະທິບາຍຂ້າງເທິງ.
/// ມັນຖືກປະຕິບັດໂດຍອັດຕະໂນມັດສໍາລັບທຸກໆປະເພດ.
/// ມັນສາມາດຄາດວ່າຈະຖືກຈັດຕັ້ງປະຕິບັດໃນສະພາບການທົ່ວໄປ, ເຖິງແມ່ນວ່າບໍ່ມີຂອບເຂດທີ່ສອດຄ້ອງກັນ.
///
/// # Usage
///
/// ຕົວຊີ້ວັດຖຸດິບສາມາດເນົ່າເປື່ອຍລົງໃນທີ່ຢູ່ຂໍ້ມູນແລະສ່ວນປະກອບຂໍ້ມູນເມຕາພ້ອມດ້ວຍວິທີ [`to_raw_parts`] ຂອງພວກມັນ.
///
/// ອີກທາງເລືອກ, ຂໍ້ມູນ metadata ຢ່າງດຽວສາມາດຖືກສະກັດດ້ວຍຟັງຊັນ [`metadata`].
/// ເອກະສານອ້າງອີງສາມາດຖືກສົ່ງໄປຫາ [`metadata`] ແລະຖືກບັງຄັບຢ່າງແທ້ຈິງ.
///
/// ຕົວຊີ້ຕົວ (possibly-wide) ສາມາດໃສ່ກັບຄືນຈາກທີ່ຢູ່ແລະເມຕາເດຕາຂອງມັນດ້ວຍ [`from_raw_parts`] ຫຼື [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// ປະເພດ ສຳ ລັບ metadata ໃນ pointers ແລະເອກະສານອ້າງອີງເຖິງ `Self`.
    #[lang = "metadata_type"]
    // NOTE: ເກັບຮັກສາ trait bounds ໃນ `static_assert_expected_bounds_for_metadata`
    //
    // ໃນ `library/core/src/ptr/metadata.rs` ໃນການຊິ້ງຂໍ້ມູນກັບທີ່ນີ້:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// ຕົວຊີ້ບອກປະເພດທີ່ປະຕິບັດການໃສ່ຊື່ trait ນີ້ແມ່ນ`ບາງ`.
///
/// ນີ້ປະກອບມີປະເພດແບບສະຖິຕິ-`Sized` ແລະປະເພດ `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: ບໍ່ເຮັດໃຫ້ສະຖຽນລະພາບນີ້ກ່ອນທີ່ຈະມີນາມແຝງ trait ມີຄວາມ ໝັ້ນ ຄົງໃນພາສາບໍ?
pub trait Thin = Pointee<Metadata = ()>;

/// ສະກັດສ່ວນປະກອບຂໍ້ມູນຂອງເມຕາ.
///
/// ຄຸນຄ່າຂອງປະເພດ `*mut T`, `&T`, ຫຼື `&mut T` ສາມາດຖືກສົ່ງຜ່ານ ໜ້າ ທີ່ນີ້ໂດຍກົງຍ້ອນວ່າພວກມັນຖືກບັງຄັບໂດຍ `* const T` X.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // ຄວາມປອດໄພ: ການເຂົ້າເຖິງມູນຄ່າຈາກສະຫະພັນ `PtrRepr` ແມ່ນປອດໄພຕັ້ງແຕ່ * const T
    // ແລະ PtrComponents<T>ມີຮູບແບບຄວາມ ຈຳ ຄືກັນ.
    // ພຽງແຕ່ std ເທົ່ານັ້ນທີ່ສາມາດຮັບປະກັນນີ້.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// ປະກອບເປັນຕົວຊີ້ວັດຖຸດິບ (possibly-wide) ຈາກທີ່ຢູ່ຂໍ້ມູນແລະເມຕາເດຕາ.
///
/// ຟັງຊັນນີ້ແມ່ນປອດໄພແຕ່ວ່າຕົວຊີ້ທິດທາງທີ່ຖືກສົ່ງຄືນບໍ່ ຈຳ ເປັນຕ້ອງປອດໄພໃນການເສີຍເມີຍ.
/// ສຳ ລັບຊິ້ນສ່ວນ, ເບິ່ງເອກະສານຂອງ [`slice::from_raw_parts`] ສຳ ລັບຄວາມຕ້ອງການດ້ານຄວາມປອດໄພ.
/// ສຳ ລັບວັດຖຸ trait, ເມຕາເດຕາຕ້ອງມາຈາກຕົວຊີ້ໄປຫາປະເພດພື້ນຖານທີ່ອີງໃສ່ດຽວກັນ.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // ຄວາມປອດໄພ: ການເຂົ້າເຖິງມູນຄ່າຈາກສະຫະພັນ `PtrRepr` ແມ່ນປອດໄພຕັ້ງແຕ່ * const T
    // ແລະ PtrComponents<T>ມີຮູບແບບຄວາມ ຈຳ ຄືກັນ.
    // ພຽງແຕ່ std ເທົ່ານັ້ນທີ່ສາມາດຮັບປະກັນນີ້.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// ປະຕິບັດຫນ້າທີ່ຄືກັນກັບ [`from_raw_parts`], ຍົກເວັ້ນວ່າຕົວຊີ້ `*mut` ວັດຖຸດິບຖືກສົ່ງຄືນ, ເຊິ່ງກົງກັນຂ້າມກັບຕົວຊີ້ວັດ `* const` ດິບ.
///
///
/// ເບິ່ງເອກະສານຂອງ [`from_raw_parts`] ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // ຄວາມປອດໄພ: ການເຂົ້າເຖິງມູນຄ່າຈາກສະຫະພັນ `PtrRepr` ແມ່ນປອດໄພຕັ້ງແຕ່ * const T
    // ແລະ PtrComponents<T>ມີຮູບແບບຄວາມ ຈຳ ຄືກັນ.
    // ພຽງແຕ່ std ເທົ່ານັ້ນທີ່ສາມາດຮັບປະກັນນີ້.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// ຄູ່ມືການໃຊ້ຕ້ອງການເພື່ອຫລີກລ້ຽງການຜູກມັດ `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// ຄູ່ມືການໃຊ້ຕ້ອງການເພື່ອຫລີກລ້ຽງການຜູກມັດ `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// metadata ສຳ ລັບ `Dyn = dyn SomeTrait` trait ປະເພດວັດຖຸ.
///
/// ມັນແມ່ນຕົວຊີ້ໄປທີ່ vtable (ຕາຕະລາງການໂທຫາແບບເສມືນ) ເຊິ່ງສະແດງຂໍ້ມູນທີ່ ຈຳ ເປັນທັງ ໝົດ ເພື່ອຈັດການປະເພດສີມັງທີ່ເກັບໄວ້ພາຍໃນວັດຖຸ trait.
/// vtable ໂດຍສະເພາະແມ່ນມັນປະກອບດ້ວຍ:
///
/// * ຂະ ໜາດ ປະເພດ
/// * ຄວາມສອດຄ່ອງຂອງປະເພດ
/// * ຕົວຊີ້ໄປທີ່ `drop_in_place` ຂອງປະເພດ (ອາດຈະບໍ່ມີຂໍ້ມູນ ສຳ ລັບຂໍ້ມູນທີ່ເກົ່າແກ່)
/// * ຊີ້ໃຫ້ເຫັນເຖິງທຸກວິທີການ ສຳ ລັບການຈັດຕັ້ງປະຕິບັດປະເພດ trait
///
/// ໃຫ້ສັງເກດວ່າສາມອັນດັບ ທຳ ອິດແມ່ນພິເສດເພາະວ່າພວກເຂົາ ຈຳ ເປັນຕ້ອງຈັດສັນ, ລຸດລົງແລະຈັດສັນວັດຖຸໃດ ໜຶ່ງ ຂອງ trait.
///
/// ມັນເປັນໄປໄດ້ທີ່ຈະຕັ້ງຊື່ໂຄງສ້າງນີ້ດ້ວຍພາລາມິເຕີປະເພດທີ່ບໍ່ແມ່ນວັດຖຸ `dyn` trait (ຕົວຢ່າງ `DynMetadata<u64>`) ແຕ່ບໍ່ໄດ້ຮັບມູນຄ່າທີ່ມີຄວາມ ໝາຍ ຂອງໂຄງສ້າງນັ້ນ.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// ຄຳ ນຳ ໜ້າ ທຳ ມະດາຂອງ vtables ທັງ ໝົດ.ມັນຖືກຕິດຕາມດ້ວຍຕົວຊີ້ວັດ ໜ້າ ທີ່ ສຳ ລັບວິທີການ trait.
///
/// ລາຍລະອຽດການຈັດຕັ້ງປະຕິບັດເອກະຊົນຂອງ `DynMetadata::size_of` ແລະອື່ນໆ.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// ສົ່ງຄືນຂະ ໜາດ ຂອງຊະນິດທີ່ກ່ຽວຂ້ອງກັບ vtable ນີ້.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// ສົ່ງຄືນຄວາມສອດຄ່ອງຂອງປະເພດທີ່ກ່ຽວຂ້ອງກັບ vtable ນີ້.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// ສົ່ງຄືນຂະ ໜາດ ແລະຄວາມສອດຄ່ອງກັນເປັນ `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // ຄວາມປອດໄພ: ນັກລວບລວມຂໍ້ມູນໄດ້ອອກແບບໂລໂກ້ນີ້ ສຳ ລັບປະເພດ Rust ທີ່ເປັນຊີມັງ
        // ເປັນທີ່ຮູ້ກັນວ່າມີຮູບແບບທີ່ຖືກຕ້ອງ.ເຫດຜົນດຽວກັນກັບໃນ `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// ຄູ່ມື ໝາຍ ເຖິງຄວາມ ຈຳ ເປັນເພື່ອຫລີກລ້ຽງການຜູກພັນ `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}