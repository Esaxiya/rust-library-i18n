use crate::iter::FromIterator;

/// ຍຸບລາຍການທຸກ ໜ່ວຍ ຈາກເຄື່ອງປັບກາຍເປັນ ໜຶ່ງ.
///
/// ນີ້ແມ່ນເປັນປະໂຫຍດຫຼາຍໃນເວລາທີ່ອະນຸຍາດຂອງທີ່ມີຕົວຕົນໃນລະດັບສູງເຊັ່ນ: ການເກັບເປັນ `Result<(), E>` ບ່ອນທີ່ທ່ານພຽງແຕ່ບົວລະບັດໃນກ່ຽວກັບຄວາມຜິດພາດ:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}