//! ເຄື່ອງໃຊ້ ສຳ ລັບການຈັດຮູບແບບແລະການພິມສາຍ.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// ການຈັດຕໍາແຫນ່ງທີ່ເປັນໄປໄດ້ກັບຄືນມາໂດຍ `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ສະແດງເຖິງມູນທີ່ເນື້ອຫາຄວນຈະຊ້າຍສອດຄ່ອງ.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ສະແດງໃຫ້ເຫັນວ່າເນື້ອໃນຄວນສອດຄ່ອງກັນ.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ສະແດງເຖິງມູນທີ່ເນື້ອຫາຄວນຈະສູນສອດຄ່ອງ.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// ປະເພດທີ່ສົ່ງຄືນໂດຍວິທີການແບບຟອມ.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// ປະເພດຂໍ້ຜິດພາດທີ່ສົ່ງຄືນຈາກການຈັດຮູບແບບຂໍ້ຄວາມລົງໃນກະແສ.
///
/// ປະເພດນີ້ບໍ່ຮອງຮັບການສົ່ງຕໍ່ຂໍ້ຜິດພາດນອກ ເໜືອ ຈາກຂໍ້ຜິດພາດທີ່ເກີດຂື້ນ.
/// ຂໍ້ມູນພິເສດຕ້ອງໄດ້ຮັບການຈັດລຽງເພື່ອໄດ້ຮັບການຕິດຕໍ່ໂດຍຜ່ານວິທີການອື່ນໆຈໍານວນຫນຶ່ງ.
///
/// ເປັນສິ່ງທີ່ສໍາຄັນແມ່ນໃຫ້ຈື່ໄວ້ວ່າປະເພດ `fmt::Error` ທີ່ບໍ່ຄວນສັບສົນກັບ [`std::io::Error`] ຫຼື [`std::error::Error`], ທີ່ທ່ານອາດຈະມີຢູ່ໃນຂອບເຂດ.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// A trait ສຳ ລັບການຂຽນຫລືການຈັດຮູບແບບເຂົ້າໃນການຮັບເອົາສັນຍາລັກຂອງ buffers ຫຼືສາຍນ້ ຳ.
///
/// trait ນີ້ພຽງແຕ່ຮັບຂໍ້ມູນ UTF-8 ເຂົ້າລະຫັດແລະບໍ່ແມ່ນ [flushable].
/// ຖ້າຫາກວ່າທ່ານພຽງແຕ່ຕ້ອງການທີ່ຈະຍອມຮັບ Unicode ແລະທ່ານບໍ່ຈໍາເປັນຕ້ອງລ້າງ, ທ່ານຄວນປະຕິບັດ trait ນີ້;
/// ຖ້າບໍ່ດັ່ງນັ້ນທ່ານຄວນຈະປະຕິບັດ [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// ຂຽນສາຍສະຕິງເຂົ້າໄປໃນນັກຂຽນນີ້, ກັບມາບໍ່ວ່າການຂຽນຈະປະສົບຜົນ ສຳ ເລັດ.
    ///
    /// ວິທີການນີ້ພຽງແຕ່ສາມາດສໍາເລັດຖ້າຫຼັງຈາກນັ້ນນໍາ string ທັງຫມົດໄດ້ລາຍລັກອັກສອນຢ່າງສໍາເລັດຜົນ, ແລະວິທີການນີ້ຈະບໍ່ກັບຄືນຈົນກ່ວາຂໍ້ມູນທັງຫມົດໄດ້ຮັບການລາຍລັກອັກສອນຫຼືຄວາມຜິດພາດເກີດຂຶ້ນ.
    ///
    ///
    /// # Errors
    ///
    /// ຟັງຊັນນີ້ຈະກັບຄືນຕົວຢ່າງຂອງ [`Error`] ກ່ຽວກັບຄວາມຜິດພາດ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// ຂຽນ [`char`] ເຂົ້າໃນນັກຂຽນນີ້, ກັບຄືນວ່າການຂຽນນັ້ນປະສົບຜົນ ສຳ ເລັດຫຼືບໍ່.
    ///
    /// A [`char`] ດຽວອາດໄດ້ຮັບການເຂົ້າລະຫັດເປັນຫຼາຍກ່ວາຫນຶ່ງ byte.
    /// ວິທີການນີ້ພຽງແຕ່ສາມາດສໍາເລັດຖ້າລໍາດັບ byte ທັງຫມົດໄດ້ລາຍລັກອັກສອນຢ່າງສໍາເລັດຜົນ, ແລະວິທີການນີ້ຈະບໍ່ກັບຄືນຈົນກ່ວາຂໍ້ມູນທັງຫມົດໄດ້ຮັບການລາຍລັກອັກສອນຫຼືຄວາມຜິດພາດເກີດຂຶ້ນ.
    ///
    ///
    /// # Errors
    ///
    /// ຟັງຊັນນີ້ຈະກັບຄືນຕົວຢ່າງຂອງ [`Error`] ກ່ຽວກັບຄວາມຜິດພາດ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// ກາວສໍາລັບການນໍາໃຊ້ຂອງມະຫາພາກ [`write!`] ກັບ implementor ຂອງ trait ນີ້.
    ///
    /// ວິທີການນີ້ໂດຍທົ່ວໄປບໍ່ຄວນຈະຖືກເອີ້ນດ້ວຍຕົນເອງ, ແຕ່ແທນທີ່ຈະຜ່ານມະຫາພາກ [`write!`] ຕົວຂອງມັນເອງ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// ການຕັ້ງຄ່າ ສຳ ລັບການຈັດຮູບແບບ.
///
/// A `Formatter` ສະແດງຕົວເລືອກຕ່າງໆທີ່ກ່ຽວຂ້ອງກັບການຈັດຮູບແບບ.
/// ຜູ້ໃຊ້ບໍ່ໄດ້ສ້າງ `ຮູບແບບ` ໂດຍກົງ;ກະສານອ້າງອີງບໍ່ແນ່ນອນກັບຫນຶ່ງແມ່ນຜ່ານການວິທີການ `fmt` ຂອງທັງຫມົດ traits ຮູບແບບເຊັ່ນ: [`Debug`] ແລະ [`Display`].
///
///
/// ເພື່ອພົວພັນກັບ `Formatter`, ທ່ານຈະໂທຫາວິທີການຕ່າງໆເພື່ອປ່ຽນຕົວເລືອກຕ່າງໆທີ່ກ່ຽວຂ້ອງກັບການຈັດຮູບແບບ.
/// ສຳ ລັບຕົວຢ່າງ, ກະລຸນາເບິ່ງເອກະສານຂອງວິທີການທີ່ໄດ້ ກຳ ນົດໄວ້ໃນ `Formatter` ຂ້າງລຸ່ມນີ້.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// ການໂຕ້ຖຽງເປັນສິ່ງຈໍາເປັນທີ່ດີທີ່ສຸດການນໍາໃຊ້ບາງສ່ວນການທໍາງານຂອງການຈັດຮູບແບບ, ທຽບເທົ່າກັບ `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// ໂຄງສ້າງນີ້ເປັນຕົວແທນ "argument" ແບບທົ່ວໆໄປເຊິ່ງປະຕິບັດໂດຍຄອບຄົວ Xprintf ທີ່ມີ ໜ້າ ທີ່.ມັນປະກອບດ້ວຍການເຮັດວຽກກັບຮູບແບບຄ່າດັ່ງກ່າວ.
/// ໃນເວລາລວບລວມມັນໄດ້ຮັບປະກັນວ່າ ໜ້າ ທີ່ແລະມູນຄ່າມີປະເພດທີ່ຖືກຕ້ອງ, ແລະຫຼັງຈາກນັ້ນໂຄງສ້າງນີ້ແມ່ນໃຊ້ໃນການໂຕ້ຖຽງກັບປະເພດ ໜຶ່ງ.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// ນີ້ຮັບປະກັນຄ່າຄົງທີ່ດຽວຊີ້ຫນ້າທີ່ກ່ຽວຂ້ອງກັບ indices/counts ໃນໂຄງສ້າງພື້ນຖານການຈັດຮູບແບບ.
//
// ໃຫ້ສັງເກດວ່າ ໜ້າ ທີ່ທີ່ຖືກ ກຳ ນົດເປັນດັ່ງກ່າວຈະບໍ່ຖືກຕ້ອງຍ້ອນວ່າ ໜ້າ ທີ່ຖືກ ໝາຍ ເອົາຊື່ສະ ເໝີ ໄປທີ່ບໍ່ມີຊື່ກັບ LLVM IR, ດັ່ງນັ້ນທີ່ຢູ່ຂອງມັນບໍ່ຖືວ່າມີຄວາມ ສຳ ຄັນຕໍ່ LLVM ແລະເຊັ່ນວ່າສຽງໂຫວດທັງ ໝົດ as_usize ອາດຈະຖືກສັບຊ້ອນ.
//
// ໃນການປະຕິບັດ, ພວກເຮົາບໍ່ເຄີຍໂທຫາ as_usize ກ່ຽວກັບທີ່ບໍ່ແມ່ນ usize ມີຂໍ້ມູນ (ເປັນເລື່ອງຂອງການຜະລິດໄຟຟ້າສະຖິດຂອງຮູບແບບການໂຕ້ຖຽງກ), ສະນັ້ນນີ້ເປັນພຽງການກວດສອບເພີ່ມເຕີມ.
//
// ພວກເຮົາຕ້ອງການໃຫ້ແນ່ໃຈວ່າຕົວຊີ້ບອກຟັງຊັນທີ່ `USIZE_MARKER` ມີທີ່ຢູ່ທີ່ສອດຄ້ອງກັນ *ພຽງແຕ່* ໃຫ້ກັບ ໜ້າ ທີ່ທີ່ຖື `&usize` ເປັນການໂຕ້ຖຽງຄັ້ງ ທຳ ອິດຂອງພວກເຂົາ.
// The read_volatile ນີ້ຮັບປະກັນວ່າພວກເຮົາສາມາດເຮັດໄດ້ຢ່າງປອດໄພພ້ອມອອກ usize ຈາກກະສານອ້າງອີງຜ່ານໄດ້ແລະທີ່ຢູ່ນີ້ບໍ່ໄດ້ຈຸດທີ່ເປັນທີ່ບໍ່ແມ່ນ usize ຫນ້າທີ່ເອົາມາ.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // SAFETY: ptr ແມ່ນກະສານອ້າງອີງ
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // ຄວາມປອດໄພ: `mem::transmute(x)` ປອດໄພເພາະ
        //     1. `&'b T` ເຮັດໃຫ້ຊີວິດຂອງມັນມາກັບ `'b` (ນັ້ນເປັນທີ່ຈະບໍ່ມີຕະຫຼອດຊີວິດບໍ່ມີຂອບເຂດ)
        //     2.
        //     `&'b T` ແລະ `&'b Opaque` ມີຮູບແບບຄວາມ ຈຳ ແບບດຽວກັນ (ເມື່ອ `T` ແມ່ນ `Sized`, ຄືກັບທີ່ນີ້) `mem::transmute(f)` ແມ່ນປອດໄພເພາະ `fn(&T, &mut Formatter<'_>) -> Result` ແລະ `fn(&Opaque, &mut Formatter<'_>) -> Result` ມີ ABI ດຽວກັນ (ຕາບເທົ່າທີ່ `T` ແມ່ນ `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // SAFETY: ການພາກສະຫນາມ `formatter` ຖືກຕັ້ງແຕເພື່ອ USIZE_MARKER ຖ້າ
            // ມູນຄ່າແມ່ນ usize ເປັນ, ສະນັ້ນນີ້ແມ່ນປອດໄພ
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// ທຸງທີ່ມີຢູ່ໃນຮູບແບບ v1 ຂອງ format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// ເມື່ອ ນຳ ໃຊ້ format_args! () ມະຫາພາກ, ໜ້າ ທີ່ນີ້ຖືກ ນຳ ໃຊ້ເພື່ອສ້າງໂຄງສ້າງ Arguments.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// ຟັງຊັນນີ້ໄດ້ຖືກນໍາໃຊ້ເພື່ອກໍານົດຕົວກໍານົດການຈັດຮູບແບບເປັນມາດຕະຖານ.
    /// The `pieces` array ຈະຕ້ອງຢູ່ຢ່າງຫນ້ອຍເປັນ `fmt` ການກໍ່ສ້າງໂຄງປະກອບການໂຕ້ຖຽງທີ່ຖືກຕ້ອງ.
    /// ເຊັ່ນດຽວກັນ, `Count` ໃດໆພາຍໃນ `fmt` ທີ່ເປັນ `CountIsParam` ຫຼື `CountIsNextParam` ຕ້ອງໄດ້ຊີ້ໃຫ້ເຫັນການໂຕ້ຖຽງທີ່ສ້າງຂື້ນກັບ `argumentusize`.
    ///
    /// ເຖິງຢ່າງໃດກໍ່ຕາມ, ການບໍ່ເຮັດເຊັ່ນນັ້ນບໍ່ໄດ້ເຮັດໃຫ້ບໍ່ປອດໄພ, ແຕ່ຈະບໍ່ສົນໃຈທີ່ບໍ່ຖືກຕ້ອງ.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// ຄາດຄະເນຄວາມຍາວຂອງຂໍ້ຄວາມໃນຮູບແບບດັ່ງກ່າວ.
    ///
    /// ນີ້ແມ່ນເພື່ອ ນຳ ໃຊ້ເພື່ອ ກຳ ນົດຄວາມສາມາດ `String` ເບື້ອງຕົ້ນເມື່ອ ນຳ ໃຊ້ `format!`.
    /// Note: ນີ້ບໍ່ແມ່ນທາງລຸ່ມຫລືທາງເທິງ.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // ຖ້າສະຕິງຮູບແບບເລີ່ມຕົ້ນດ້ວຍການໂຕ້ຖຽງ, ຢ່າຈັດສັນສິ່ງໃດສິ່ງ ໜຶ່ງ ໄວ້, ເວັ້ນເສຍແຕ່ວ່າຄວາມຍາວຂອງຕ່ອນມີຄວາມ ສຳ ຄັນ.
            //
            //
            0
        } else {
            // ມີການໂຕ້ຖຽງບາງຢ່າງ, ດັ່ງນັ້ນການຊຸກຍູ້ເພີ່ມເຕີມໃດໆກໍ່ຈະຊ່ວຍຈັດສັນສາຍບື.
            //
            // ເພື່ອຫຼີກເວັ້ນການວ່າ, ພວກເຮົາກໍາລັງ "pre-doubling" ຄວາມອາດສາມາດໃນທີ່ນີ້.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// ໂຄງປະກອບການນີ້ເປັນຕົວແທນເປັນສະບັບພາສາ precompiled ປອດໄພຂອງສະຕິງຮູບແບບແລະການໂຕ້ຖຽງຂອງຕົນ.
/// ສິ່ງນີ້ບໍ່ສາມາດຜະລິດໄດ້ໃນເວລາແລ່ນເນື່ອງຈາກວ່າມັນບໍ່ສາມາດເຮັດໄດ້ຢ່າງປອດໄພ, ສະນັ້ນບໍ່ມີຜູ້ສ້າງໃຫ້ແລະພື້ນທີ່ເປັນສ່ວນຕົວເພື່ອປ້ອງກັນການດັດແປງ.
///
///
/// ມະຫາພາກ [`format_args!`] ຈະສ້າງຕົວຢ່າງຂອງໂຄງສ້າງນີ້ຢ່າງປອດໄພ.
/// ມະຫາພາກຈະຊ່ວຍຢືນຢັນສາຍຮູບແບບໃນເວລາທີ່ລວບລວມເພື່ອໃຫ້ການ ນຳ ໃຊ້ [`write()`] ແລະ [`format()`] ເຮັດວຽກໄດ້ຢ່າງປອດໄພ.
///
/// ທ່ານສາມາດໃຊ້ `Arguments<'a>` ທີ່ [`format_args!`] ກັບຄືນມາໃນສະພາບການ `Debug` ແລະ `Display` ດັ່ງທີ່ເຫັນຢູ່ຂ້າງລຸ່ມ.
/// ຕົວຢ່າງຍັງສະແດງໃຫ້ເຫັນວ່າຮູບແບບ `Debug` ແລະ `Display` ກັບສິ່ງດຽວກັນ: ສາຍຮູບແບບທີ່ແປໃນ `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // ຈັດວາງຊິ້ນສ່ວນຊ່ອຍແນ່ເພື່ອພິມ.
    pieces: &'a [&'static str],

    // specs Placeholder ຫລື `None` ຖ້າ specs ທັງຫມົດແມ່ນເລີ່ມຕົ້ນ (ໃນ "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // ກະທູ້ທີ່ແບບເຄື່ອນໄຫວສໍາລັບການແກ້ໄຂ, ເຊິ່ງຈະຕ້ອງ interleaved ມີຕ່ອນ string.
    // (ທຸກການໂຕ້ຖຽງແມ່ນ preceded ໂດຍສິ້ນຊ່ອຍແນ່.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// ໄດ້ຮັບ string ຮູບແບບ, ຖ້າຫາກວ່າມັນມີການໂຕ້ຖຽງທີ່ຈະຈັດຮູບແບບທີ່ບໍ່ມີ.
    ///
    /// ສິ່ງນີ້ສາມາດໃຊ້ເພື່ອຫລີກລ້ຽງການຈັດສັນໃນກໍລະນີທີ່ບໍ່ຄ່ອຍດີທີ່ສຸດ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` ຄວນຈັດຮູບແບບຜົນຜະລິດໃນ programmer ໃບຫນ້າໄດ້, ແກ້ຈຸດບົກພ່ອງບໍລິບົດ.
///
/// ໂດຍທົ່ວໄປໃນການເວົ້າ, ທ່ານພຽງແຕ່ຄວນດໍາເນີນ `derive` ເປັນ `Debug`.
///
/// ໃນເວລາທີ່ຖືກນໍາໃຊ້ກັບຮູບແບບສະຫຼັບລະບຸ `#?`, ຜົນຜະລິດແມ່ນ pretty, ພິມ.
///
/// ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຮູບແບບ, ເບິ່ງ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// trait ນີ້ສາມາດຖືກນໍາໃຊ້ກັບ `#[derive]` ຖ້າຂົງເຂດທັງຫມົດໃຊ້ `Debug`.
/// ໃນເວລາທີ່ `derive`d ສໍາລັບ struct, ມັນຈະນໍາໃຊ້ຊື່ຂອງ `struct`, ຫຼັງຈາກນັ້ນ `{`, ຫຼັງຈາກນັ້ນບັນຊີລາຍຊື່ຈຸດ, ແຍກອອກຈາກຊື່ຂອງແຕ່ລະພາກສະຫນາມແລະຄ່າ `Debug`, ຫຼັງຈາກນັ້ນ `}` ໄດ້.
/// ສຳ ລັບ `enum`s, ມັນຈະໃຊ້ຊື່ຂອງຕົວແປແລະຖ້າສາມາດໃຊ້ໄດ້, `(`, ຫຼັງຈາກນັ້ນຄ່າ `Debug` ຂອງທົ່ງນາ, ຫຼັງຈາກນັ້ນ `)`.
///
/// # Stability
///
/// ຜັນຂະຫຍາຍຮູບແບບ `Debug` ບໍ່ຫມັ້ນຄົງ, ແລະອື່ນໆອາດຈະມີການປ່ຽນແປງກັບສະບັບ future Rust.
/// ນອກຈາກນັ້ນ, ການຈັດຕັ້ງປະຕິບັດ `Debug` ຂອງປະເພດທີ່ສະ ໜອງ ໂດຍຫໍສະມຸດມາດຕະຖານ (`libstd`, `libcore`, `liballoc`, ແລະອື່ນໆ) ແມ່ນບໍ່ ໝັ້ນ ຄົງ, ແລະຍັງອາດຈະປ່ຽນກັບລຸ້ນ future Rust.
///
///
/// # Examples
///
/// ມາຈາກການຈັດຕັ້ງປະຕິບັດ:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// ການຈັດຕັ້ງປະຕິບັດຄູ່ມື:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// ມີຫລາຍໆວິທີການກ່ຽວກັບຜູ້ຊ່ວຍໃນໂຄງສ້າງ [`Formatter`] ເພື່ອຊ່ວຍທ່ານໃນການຈັດຕັ້ງປະຕິບັດຄູ່ມື, ເຊັ່ນວ່າ [`debug_struct`].
///
/// `Debug` ການປະຕິບັດການນໍາໃຊ້ບໍ່ວ່າຈະ `derive` ຫຼື builder debug API ກ່ຽວກັບສະຫນັບສະຫນູນ [`Formatter`] pretty, ພິມການນໍາໃຊ້ທຸງຈັບສະຫລັບ: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Pretty, ພິມດ້ວຍ `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// ຮູບແບບຄ່າໃຊ້ formatter ດັ່ງກ່າວ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// ລະຕ່າງຫາກເພື່ອ reexport ການມະຫາພາກ `Debug` ຈາກ prelude ໂດຍບໍ່ມີການ trait `Debug`.
pub(crate) mod macros {
    /// ມະຫາພາກ Derive ສ້າງເປັນ impl ຂອງ trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// ຮູບແບບ trait ສຳ ລັບຮູບແບບທີ່ບໍ່ມີຮູບຮ່າງ, `{}`.
///
/// `Display` ແມ່ນຄ້າຍຄືກັບ [`Debug`], ແຕ່ `Display` ແມ່ນ ສຳ ລັບຜົນຜະລິດທີ່ປະເຊີນ ໜ້າ ກັບຜູ້ໃຊ້, ແລະດັ່ງນັ້ນຈຶ່ງບໍ່ສາມາດເອົາມາໃຊ້ໄດ້.
///
///
/// ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຮູບແບບ, ເບິ່ງ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ປະຕິບັດ `Display` ກ່ຽວກັບປະເທດຝລັ່ງເສດ:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// ຮູບແບບຄ່າໃຊ້ formatter ດັ່ງກ່າວ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait ຄວນຈັດຮູບແບບຜົນຜະລິດຂອງມັນເປັນຕົວເລກໃນ base-8.
///
/// ສໍາລັບ primitive ເຊັນຈໍານວນເຕັມ (`i8` ກັບ `i128` ແລະ `isize`), ຄ່າລົບແມ່ນຮູບແບບເປັນຕົວແທນສົມບູນທັງສອງຂອງ.
///
///
/// ທຸງຊາດສະຫລັບ, `#`, ເພີ້ມ `0o` ຢູ່ທາງຫນ້າຂອງຜົນຜະລິດ.
///
/// ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຮູບແບບ, ເບິ່ງ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ການນໍາໃຊ້ພື້ນຖານພ້ອມ `i32`:
///
/// ```
/// let x = 42; // 42 ແມ່ນ '52' ໃນ octal
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// ການປະຕິບັດ `Octal` ໃນປະເພດ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // ມອບການປະຕິບັດ i32 ຂອງ
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// ຮູບແບບຄ່າໃຊ້ formatter ດັ່ງກ່າວ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait ຄວນຈັດຮູບແບບຜົນຜະລິດຂອງມັນເປັນເລກໃນຖານສອງ.
///
/// ສຳ ລັບເລກເຕັມທີ່ເຊັນຊື່ເບື້ອງຕົ້ນ ([`i8`] ຫາ [`i128`], ແລະ [`isize`]), ຄຸນຄ່າທາງລົບແມ່ນຖືກຈັດເປັນຕົວແທນທີ່ສົມບູນແບບຂອງສອງ.
///
///
/// ທຸງຊາດສະຫລັບ, `#`, ເພີ້ມ `0b` ຢູ່ທາງຫນ້າຂອງຜົນຜະລິດ.
///
/// ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຮູບແບບ, ເບິ່ງ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ພື້ນຖານກັບ [`i32`]:
///
/// ```
/// let x = 42; // 42 ແມ່ນ '101010' ໃນຖານສອງ
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// ປະຕິບັດ `Binary` ກ່ຽວກັບປະເທດຝລັ່ງເສດ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // ມອບການປະຕິບັດ i32 ຂອງ
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// ຮູບແບບຄ່າໃຊ້ formatter ດັ່ງກ່າວ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// The `LowerHex` trait ຄວນຈັດຮູບແບບຜົນຜະລິດຂອງຕົນເປັນຈໍານວນໃນເລກຖານສິບຫົກເປັນ, ກັບ `a` ຜ່ານ `f` ໃນກໍລະນີຕ່ໍາ.
///
/// ສໍາລັບ primitive ເຊັນຈໍານວນເຕັມ (`i8` ກັບ `i128` ແລະ `isize`), ຄ່າລົບແມ່ນຮູບແບບເປັນຕົວແທນສົມບູນທັງສອງຂອງ.
///
///
/// ທຸງຊາດສະຫລັບ, `#`, ເພີ້ມ `0x` ຢູ່ທາງຫນ້າຂອງຜົນຜະລິດ.
///
/// ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຮູບແບບ, ເບິ່ງ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ການນໍາໃຊ້ພື້ນຖານພ້ອມ `i32`:
///
/// ```
/// let x = 42; // 42 ແມ່ນ '2a' ໃນ hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// ການປະຕິບັດ `LowerHex` ໃນປະເພດ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // ມອບການປະຕິບັດ i32 ຂອງ
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// ຮູບແບບຄ່າໃຊ້ formatter ດັ່ງກ່າວ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// The `UpperHex` trait ຄວນຈັດຮູບແບບຜົນຜະລິດຂອງຕົນເປັນຈໍານວນໃນເລກຖານສິບຫົກເປັນ, ກັບ `A` ຜ່ານ `F` ໃນກໍລະນີເທິງ.
///
/// ສໍາລັບ primitive ເຊັນຈໍານວນເຕັມ (`i8` ກັບ `i128` ແລະ `isize`), ຄ່າລົບແມ່ນຮູບແບບເປັນຕົວແທນສົມບູນທັງສອງຂອງ.
///
///
/// ທຸງຊາດສະຫລັບ, `#`, ເພີ້ມ `0x` ຢູ່ທາງຫນ້າຂອງຜົນຜະລິດ.
///
/// ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຮູບແບບ, ເບິ່ງ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ການນໍາໃຊ້ພື້ນຖານພ້ອມ `i32`:
///
/// ```
/// let x = 42; // 42 ແມ່ນ '2A' ໃນ hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// ປະຕິບັດ `UpperHex` ກ່ຽວກັບປະເທດຝລັ່ງເສດ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // ມອບການປະຕິບັດ i32 ຂອງ
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// ຮູບແບບຄ່າໃຊ້ formatter ດັ່ງກ່າວ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait ຄວນຈັດຮູບແບບຜົນຜະລິດຂອງມັນໃຫ້ເປັນທີ່ຢູ່ຂອງ ໜ່ວຍ ຄວາມ ຈຳ.
/// ນີ້ຖືກ ນຳ ສະ ເໜີ ໂດຍທົ່ວໄປເປັນ hexadecimal.
///
/// ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຮູບແບບ, ເບິ່ງ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ພື້ນຖານກັບ `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // ນີ້ສາມາດຜະລິດບາງສິ່ງບາງຢ່າງເຊັ່ນ: '0x7f06092ac6d0'
/// ```
///
/// ປະຕິບັດ `Pointer` ກ່ຽວກັບປະເທດຝລັ່ງເສດ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // ການນໍາໃຊ້ `as` ເພື່ອປ່ຽນໃຈເຫລື້ອມໃສເປັນ `*const T` ຊຶ່ງດໍາເນີນ Pointer, ຊຶ່ງພວກເຮົາສາມາດນໍາໃຊ້
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// ຮູບແບບຄ່າໃຊ້ formatter ດັ່ງກ່າວ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// The `LowerExp` trait ຄວນຈັດຮູບແບບຜົນຜະລິດຂອງຕົນໃນ notation ວິທະຍາສາດທີ່ມີຕ່ໍາກໍລະນີ `e`.
///
/// ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຮູບແບບ, ເບິ່ງ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ການນໍາໃຊ້ພື້ນຖານພ້ອມ `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ແມ່ນ '4.2e1' ໃນ notation ວິທະຍາສາດ
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// ການປະຕິບັດ `LowerExp` ໃນປະເພດ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // ມອບການປະຕິບັດ F64 ຂອງ
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// ຮູບແບບຄ່າໃຊ້ formatter ດັ່ງກ່າວ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// The `UpperExp` trait ຄວນຈັດຮູບແບບຜົນຜະລິດຂອງຕົນໃນ notation ວິທະຍາສາດທີ່ມີເທິງກໍລະນີ `E`.
///
/// ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຮູບແບບ, ເບິ່ງ [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ການນໍາໃຊ້ພື້ນຖານພ້ອມ `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ແມ່ນ '4.2E1' ໃນແນວຄິດວິທະຍາສາດ
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// ການປະຕິບັດ `UpperExp` ໃນປະເພດ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // ມອບການປະຕິບັດ F64 ຂອງ
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// ຮູບແບບຄ່າໃຊ້ formatter ດັ່ງກ່າວ.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// ຟັງຊັນ `write` ໃຊ້ເວລາກະແສຜົນຜະລິດ, ແລະໂຄງສ້າງ `Arguments` ທີ່ສາມາດໄດ້ຮັບການ precompiled ກັບມະຫາພາກ `format_args!`.
///
///
/// ກະທູ້ທີ່ຈະມີຮູບແບບຕາມຮູບແບບຂອງ string ທີ່ລະບຸໄວ້ໃນນ້ໍາຜົນຜະລິດໄດ້ສະຫນອງໃຫ້.
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// ກະລຸນາສັງເກດວ່າການນໍາໃຊ້ [`write!`] ອາດຈະມັກ.ຕົວຢ່າງ:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // ພວກເຮົາສາມາດນໍາໃຊ້ຕົວກໍານົດການໄວ້ໃນຕອນຕົ້ນຮູບແບບສໍາລັບການກະທູ້ທີ່ທັງຫມົດ.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // ທຸກ spec ມີການໂຕ້ຖຽງກ່ຽວຂ້ອງທີ່ນໍາຫນ້າດ້ວຍສິ້ນຊ່ອຍແນ່.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // SAFETY: arg ແລະ args.args ມາຈາກການໂຕ້ຖຽງດຽວກັນ,
                // ເຊິ່ງ guarantees ດັດຊະນີແມ່ນສະເຫມີໄປພາຍໃນຂອບເຂດ.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // ມັນສາມາດມີພຽງແຕ່ຊິ້ນສ່ວນຕິດຕາມຊ້າຍເທົ່ານັ້ນ.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // SAFETY: arg ແລະ args ມາຈາກການໂຕ້ຖຽງດຽວກັນ,
    // ເຊິ່ງ guarantees ດັດຊະນີແມ່ນສະເຫມີໄປພາຍໃນຂອບເຂດ.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // ສານສະກັດຈາກການໂຕ້ຖຽງທີ່ຖືກຕ້ອງ
    debug_assert!(arg.position < args.len());
    // SAFETY: arg ແລະ args ມາຈາກການໂຕ້ຖຽງດຽວກັນ,
    // ເຊິ່ງ guarantees ດັດຊະນີຂອງຕົນເປັນສະເຫມີໄປພາຍໃນຂອບເຂດ.
    let value = unsafe { args.get_unchecked(arg.position) };

    // ຫຼັງຈາກນັ້ນ, ຕົວຈິງແລ້ວເຮັດການພິມບາງຢ່າງ
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // SAFETY: cnt ແລະ args ມາຈາກການໂຕ້ຖຽງດຽວກັນ,
            // ເຊິ່ງຮັບປະກັນດັດຊະນີນີ້ແມ່ນຢູ່ໃນຂອບເຂດສະ ເໝີ.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// padding ຫຼັງຈາກສິ້ນສຸດຂອງບາງສິ່ງບາງຢ່າງໄດ້.ກັບຄືນໂດຍ `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// ຂຽນໃສ່ກະດານປະກາດນີ້.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // ພວກເຮົາຕ້ອງການປ່ຽນແປງສິ່ງນີ້
            buf: wrap(self.buf),

            // ແລະຮັກສາສິ່ງເຫລົ່ານີ້
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // ວິທີການຊ່ວຍໃນການ ນຳ ໃຊ້ແຜ່ນຮອງແລະການປະມວນຜົນການໂຕ້ຖຽງການສ້າງຮູບແບບທີ່ທຸກຮູບແບບຂອງ traits ສາມາດ ນຳ ໃຊ້ໄດ້.
    //

    /// ດໍາເນີນການ padding ທີ່ຖືກຕ້ອງສໍາລັບຈໍານວນເຕັມທີ່ໄດ້ຮັບການປ່ອຍອອກມາເຂົ້າໄປໃນ str ການ.
    /// str ຄວນ *ບໍ່* ມີປ້າຍ ສຳ ລັບເລກເຕັມ, ນັ້ນຈະຖືກເພີ່ມໂດຍວິທີນີ້.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, ບໍ່ວ່າຈະເປັນເລກເຕັມເດີມແມ່ນທັງບວກຫຼືສູນ.
    /// * ຄຳ ນຳ ໜ້າ, ຖ້າມີ '#' X ຕົວອັກສອນ (Alternate) ຖືກສະ ໜອງ, ນີ້ແມ່ນ ຄຳ ນຳ ໜ້າ ທີ່ເອົາຢູ່ຂ້າງ ໜ້າ ຂອງຕົວເລກ.
    ///
    /// * buf, ຂບວນໄບຕ໌ທີ່ຕົວເລກໄດ້ຖືກຈັດເຂົ້າໃນ
    ///
    /// ຟັງຊັນນີ້ຢ່າງຖືກຕ້ອງຈະກວມເອົາທຸງຊາດສະຫນອງໃຫ້ເຊັ່ນດຽວກັນກັບຄວາມກວ້າງຂອງຕໍາ່ສຸດທີ່.
    /// ມັນຈະບໍ່ ຄຳ ນຶງເຖິງຄວາມແມ່ນ ຍຳ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // ພວກເຮົາ ຈຳ ເປັນຕ້ອງເອົາ "-" ອອກຈາກ ຈຳ ນວນຜົນຜະລິດ.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // ຂຽນສັນຍະລັກຖ້າຫາກວ່າມັນລາຄາ: , ແລະຫຼັງຈາກນັ້ນຄໍານໍາຫນ້າທີ່ຖ້າຫາກວ່າມັນໄດ້ຮຽກຮ້ອງໃຫ້
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // ການພາກສະຫນາມ `width` ແມ່ນຫຼາຍຂອງຕົວກໍານົດການ `min-width` ຢູ່ຈຸດນີ້.
        match self.width {
            // ຖ້າຫາກວ່າມີບໍ່ມີຄວາມຕ້ອງການຄວາມຍາວຕ່ໍາສຸດແລ້ວພວກເຮົາພຽງແຕ່ສາມາດຂຽນໄບ.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // ກວດເບິ່ງວ່າພວກເຮົາມີຄວາມກວ້າງຕ່ ຳ ສຸດ, ຖ້າເປັນດັ່ງນັ້ນ, ພວກເຮົາຍັງສາມາດຂຽນໄບຕ໌ໄດ້.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // ອາການແລະຄໍານໍາຫນ້າໄປກ່ອນ padding ໄດ້ຖ້າຫາກວ່າມີລັກສະນະຕື່ມຂໍ້ມູນໃສ່ເປັນສູນ
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // ຖ້າບໍ່ດັ່ງນັ້ນ, ສັນຍາລັກແລະ ຄຳ ນຳ ໜ້າ ຈະໄປຕໍ່ພາຍຫຼັງທີ່ປ້າຍ ກຳ ກັບ
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// ຟັງຊັນນີ້ໃຊ້ເວລາຫຼັງຈາກນັ້ນນໍາ string ແລະ emits ໄປບັຟເຟີພາຍຫຼັງຈາກຍື່ນຄໍາຮ້ອງຂໍທຸງຮູບແບບທີ່ກ່ຽວຂ້ອງທີ່ລະບຸໄວ້.
    /// ທຸງຊາດຮັບຮູ້ສໍາລັບການຊ່ອຍແນ່ງເຄມີແມ່ນ:
    ///
    /// * width, width ຕ່ ຳ ສຸດຂອງສິ່ງທີ່ຄວນສະແດງ
    /// * fill/align - ສິ່ງທີ່ຄວນເອົາອອກແລະບ່ອນໃດທີ່ຈະປ່ອຍມັນໄວ້ຖ້າວ່າເຊືອກທີ່ສະ ໜອງ ໃຫ້ຕ້ອງມີການຕອກ
    /// * ຄວາມແມ່ນຍໍາ, ຄວາມຍາວສູງສຸດທີ່ຈະອອກ, ສາຍສະຕິງຈະຖືກຕັດລົງຖ້າຍາວກວ່າຄວາມຍາວນີ້
    ///
    /// ໂດຍສະເພາະ ໜ້າ ທີ່ນີ້ຈະບໍ່ສົນໃຈພາລາມິເຕີ `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // ເຮັດໃຫ້ແນ່ໃຈວ່າມີເສັ້ນທາງໄວຂຶ້ນຫນ້າ
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // ພາກສະຫນາມ `precision` ສາມາດຖືກຕີຄວາມວ່າເປັນ `max-width` ສໍາລັບສາຍທີ່ຖືກຈັດຮູບແບບ.
        //
        let s = if let Some(max) = self.precision {
            // ຖ້າວ່າເຊືອກຂອງພວກເຮົາແມ່ນຕໍ່ໄປອີກແລ້ວທີ່ຈະໄດ້, ຫຼັງຈາກນັ້ນພວກເຮົາຕ້ອງໄດ້ມີການຕັດ.
            // ເຖິງຢ່າງໃດກໍ່ຕາມທຸງອື່ນໆເຊັ່ນ `fill`, `width` ແລະ `align` ຕ້ອງປະຕິບັດຄືເກົ່າ.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM ຢູ່ທີ່ນີ້ບໍ່ສາມາດພິສູດໄດ້ວ່າ `..i` ຈະບໍ່ panic `&s[..i]`, ແຕ່ພວກເຮົາຮູ້ວ່າມັນບໍ່ສາມາດ panic.
                // ໃຊ້ `get` + `unwrap_or` ເພື່ອຫລີກລ້ຽງ `unsafe` ແລະຖ້າບໍ່ດັ່ງນັ້ນຢ່າປ່ອຍຕົວລະຫັດທີ່ກ່ຽວຂ້ອງກັບ panic ຢູ່ບ່ອນນີ້.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // ການພາກສະຫນາມ `width` ແມ່ນຫຼາຍຂອງຕົວກໍານົດການ `min-width` ຢູ່ຈຸດນີ້.
        match self.width {
            // ຖ້າພວກເຮົາຢູ່ພາຍໃຕ້ຄວາມຍາວສູງສຸດ, ແລະບໍ່ມີຄວາມຕ້ອງການຄວາມຍາວຕ່ ຳ ສຸດ, ຫຼັງຈາກນັ້ນພວກເຮົາພຽງແຕ່ສາມາດປ່ອຍສາຍ
            //
            None => self.buf.write_str(s),
            // ຖ້າພວກເຮົາຢູ່ພາຍໃຕ້ຄວາມກວ້າງສູງສຸດ, ໃຫ້ກວດເບິ່ງວ່າພວກເຮົາມີຄວາມກວ້າງຕ່ ຳ ສຸດ, ຖ້າເປັນດັ່ງນັ້ນມັນງ່າຍເທົ່າກັບການປ່ອຍສາຍ.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // ຖ້າພວກເຮົາຢູ່ພາຍໃຕ້ຄວາມກວ້າງສູງສຸດແລະຄວາມກວ້າງຕ່ ຳ ສຸດ, ຫຼັງຈາກນັ້ນຈົ່ງຕື່ມຂໍ້ມູນໃສ່ຄວາມກວ້າງຕ່ ຳ ສຸດດ້ວຍສະຕິງທີ່ລະບຸໄວ້ + ບາງເສັ້ນຄວາມສອດຄ່ອງ
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// ຂຽນທາງສ່ວນຫນ້າຂອງ padding ແລະສົ່ງຄືນບໍ່ໄດ້ຂຽນໄວ້ຫຼັງ padding.
    /// ແປໄດ້ທຸມີຄວາມຮັບຜິດຊອບສໍາລັບການຮັບປະກັນສະນີ, padding ແມ່ນລາຍລັກອັກສອນຫຼັງຈາກສິ່ງທີ່ຖືກ padded.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// ເອົາພາກສ່ວນທີ່ຖືກຈັດຮູບແບບແລະໃຊ້ແຜ່ນຮອງ.
    /// ອະນຸມານວ່າແປໄດ້ທຸໄດ້ແລ້ວໄດ້ສະແດງພາກສ່ວນທີ່ມີຄວາມແມ່ນຍໍາຕ້ອງ, ດັ່ງນັ້ນ `self.precision` ສາມາດໄດ້ຮັບການໃສ່ໃຈ.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // ສຳ ລັບແຜ່ນຮອງສູນທີ່ມີການຮັບຮູ້, ພວກເຮົາສະ ເໜີ ເຄື່ອງ ໝາຍ ກ່ອນແລະປະພຶດຕົວຄືກັບວ່າພວກເຮົາບໍ່ມີສັນຍານຕັ້ງແຕ່ຕົ້ນ.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ອາການສະ ເໝີ ໄປກ່ອນ
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // ເອົາເຂົ້າຈາກພາກສ່ວນຮູບແບບການ
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // ສ່ວນທີ່ຍັງເຫຼືອແມ່ນຜ່ານຂັ້ນຕອນ ທຳ ມະດາ.
            let len = formatted.len();
            let ret = if width <= len {
                // ບໍ່ padding
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // ນີ້ແມ່ນກໍລະນີ ທຳ ມະດາແລະພວກເຮົາລົງທາງລັດ
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // SAFETY: ນີ້ຖືກນໍາໃຊ້ສໍາລັບການ `flt2dec::Part::Num` ແລະ `flt2dec::Part::Copy`.
            // ມັນປອດໄພທີ່ຈະໃຊ້ ສຳ ລັບ `flt2dec::Part::Num` ເນື່ອງຈາກທຸກໆ char `c` ຢູ່ລະຫວ່າງ `b'0'` ແລະ `b'9'`, ນັ້ນ ໝາຍ ຄວາມວ່າ `s` ແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ.
            // ມັນຍັງອາດຈະມີຄວາມປອດໄພໃນການປະຕິບັດທີ່ຈະນໍາໃຊ້ສໍາລັບການ `flt2dec::Part::Copy(buf)` ນັບຕັ້ງແຕ່ `buf` ຄວນຈະ ASCII ທໍາມະດາ, ແຕ່ວ່າມັນເປັນໄປໄດ້ສໍາລັບໃຜຜູ້ຫນຶ່ງທີ່ຈະບັງເກີດຂຶ້ນໃນຄ່າທີ່ບໍ່ດີສໍາລັບ `buf` ເປັນ `flt2dec::to_shortest_str` ນັບຕັ້ງແຕ່ມັນແມ່ນຫນ້າທີ່ສາທາລະນະ.
            //
            // FIXME: ກໍານົດວ່ານີ້ອາດຈະສົ່ງຜົນໃນ UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 ສູນ
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// ຂຽນຂໍ້ມູນບາງຢ່າງທີ່ຈະບັຟເຟີທີ່ຕິດພັນບັນຈຸພາຍໃນ formatter ນີ້.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // ນີ້ເທົ່າກັບ:
    ///         // ຂຽນ! (formatter, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// ຂຽນບາງຂໍ້ມູນທີ່ມີຮູບແບບເຂົ້າໃນຕົວຢ່າງນີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// ທຸງ ສຳ ລັບການຈັດຮູບແບບ
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// ລັກສະນະການນໍາໃຊ້ເປັນ 'fill' ທຸກຄັ້ງທີ່ມີແມ່ນສອດຄ່ອງ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // ພວກເຮົາກໍານົດຄວາມສອດຄ່ອງກັບສິດທິໃນການມີ ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// ທົງລະບຸສິ່ງທີ່ຮູບແບບຂອງການຈັດຕໍາແຫນ່ງໄດ້ຮຽກຮ້ອງໃຫ້.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// ຄວາມກວ້າງຂອງເລກເຕັມທີ່ລະບຸໄວ້ວ່າຜົນຜະລິດຄວນຈະເປັນແນວໃດ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // ຖ້າພວກເຮົາໄດ້ຮັບຄວາມກວ້າງ, ພວກເຮົາໃຊ້ມັນ
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // ຖ້າບໍ່ດັ່ງນັ້ນພວກເຮົາເຮັດແນວໃດມີຫຍັງພິເສດ
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// ລະບຸທາງເລືອກແມ່ນຍໍາປະເພດຈໍານວນຫລາຍ.
    /// ເຊັ່ນດຽວກັນ, ໄດ້ width ສູງສຸດສໍາລັບການປະເພດ string.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // ຖ້າພວກເຮົາໄດ້ຮັບຄວາມແມ່ນຍໍາ, ພວກເຮົາຈະໃຊ້ມັນ.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // ຖ້າບໍ່ດັ່ງນັ້ນພວກເຮົາເລີ່ມຕົ້ນທີ່ຈະ 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// ກຳ ນົດວ່າທຸງ `+` ຖືກລະບຸ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// ກຳ ນົດວ່າທຸງ `-` ຖືກລະບຸ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // ທ່ານຕ້ອງການເຄື່ອງຫມາຍລົບ?ມີ!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// ຕັດສິນກໍານົດຖ້າທຸງ `#` ໄດ້ກໍານົດໄວ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// ຕັດສິນກໍານົດຖ້າທຸງ `0` ໄດ້ກໍານົດໄວ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // ພວກເຮົາບໍ່ສົນໃຈຕົວເລືອກຂອງແບບຟອມ.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: ຕັດສິນໃຈວ່າສິ່ງທີ່ API ສາທາລະນະພວກເຮົາຕ້ອງການສໍາລັບການເຫຼົ່ານີ້ທັງສອງທຸງຊາດ.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// ສ້າງເປັນ builder [`DebugStruct`] ອອກແບບມາເພື່ອຊ່ວຍໃນການສ້າງຂອງການໃຊ້ວຽກ [`fmt::Debug`] ສໍາລັບ struct.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// ສ້າງເປັນ builder `DebugTuple` ອອກແບບມາເພື່ອຊ່ວຍໃນການສ້າງຂອງການໃຊ້ວຽກ `fmt::Debug` ສໍາລັບ struct tuple.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// ສ້າງຜູ້ສ້າງ `DebugList` ທີ່ຖືກອອກແບບມາເພື່ອຊ່ວຍໃນການສ້າງການປະຕິບັດ `fmt::Debug` ສຳ ລັບໂຄງສ້າງທີ່ຄ້າຍຄືກັບລາຍຊື່.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// ສ້າງເປັນ builder `DebugSet` ອອກແບບມາເພື່ອຊ່ວຍໃນການສ້າງຂອງການໃຊ້ວຽກ `fmt::Debug` ສໍາລັບກໍານົດໄວ້ເຊັ່ນ: ໂຄງສ້າງ.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// ໃນຕົວຢ່າງສະລັບສັບຊ້ອນເພີ່ມເຕີມດັ່ງກ່າວນີ້, ພວກເຮົານໍາໃຊ້ [`format_args!`] ແລະ `.debug_set()` ເພື່ອສ້າງບັນຊີລາຍຊື່ຂອງແຂນການແຂ່ງຂັນ:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// ສ້າງຜູ້ສ້າງ `DebugMap` ທີ່ຖືກອອກແບບມາເພື່ອຊ່ວຍໃນການສ້າງການປະຕິບັດ `fmt::Debug` ສຳ ລັບໂຄງສ້າງທີ່ຄ້າຍຄືກັບແຜນທີ່.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// ການປະຕິບັດຮູບແບບຫຼັກ traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // ຖ້າຫາກວ່າຄວາມຕ້ອງການຖ່ານ escaping, backlog flush ມາເຖິງຕອນນັ້ນແລະຂຽນ, ອື່ນ skip
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // ທຸງຮອງຮັບການປິ່ນປົວແລ້ວໂດຍ LowerHex ເປັນ special-ມັນຫມາຍເຖິງການບໍ່ວ່າຈະເປັນຄໍານໍາຫນ້າດ້ວຍ 0x.
        // ພວກເຮົານໍາໃຊ້ມັນເພື່ອເຮັດວຽກອອກບໍ່ວ່າຈະເປັນຫຼືບໍ່ທີ່ຈະສູນຂະຫຍາຍ, ແລະຫຼັງຈາກນັ້ນບໍ່ມີເງື່ອນໄຂກໍານົດມັນເພື່ອໃຫ້ໄດ້ຮັບຄໍານໍາຫນ້າໄດ້.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// ການຈັດຕັ້ງປະຕິບັດ Display/Debug ສຳ ລັບຫລາຍປະເພດຫຼັກ

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell ແມ່ນຢືມກັນແລະກັນສະນັ້ນພວກເຮົາບໍ່ສາມາດເບິ່ງມູນຄ່າຂອງມັນຢູ່ທີ່ນີ້.
                // ສະແດງໃຫ້ເຫັນຕົວຍຶດແທນ.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// ຖ້າທ່ານຄາດຫວັງວ່າການທົດສອບຈະມາຢູ່ນີ້, ເບິ່ງເອກະສານ core/tests/fmt.rs ແທນ, ມັນຈະງ່າຍກວ່າການສ້າງໂຄງສ້າງ rt::Piece ທັງ ໝົດ ຢູ່ທີ່ນີ້.
//
// ຍັງມີການທົດສອບໃນ crate ການຈັດສັນ, ສຳ ລັບຜູ້ທີ່ຕ້ອງການຈັດສັນ.