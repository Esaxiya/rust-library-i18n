//! ນີ້ແມ່ນໂມດູນພາຍໃນທີ່ໃຊ້ໂດຍ ifmt!ເວລາແລ່ນ.ໂຄງການເຫຼົ່ານີ້ແມ່ນ emitted ກັບ arrays ຄົງຊ່ອຍແນ່ຮູບແບບ precompiled ລ່ວງຫນ້າຂອງທີ່ໃຊ້ເວລາ.
//!
//! ຄໍານິຍາມເຫຼົ່ານີ້ແມ່ນຄ້າຍຄືກັນກັບການທຽບເທົ່າ `ct` ຂອງເຂົາເຈົ້າ, ແຕ່ວ່າມີຄວາມແຕກຕ່າງໃນທີ່ນີ້ສາມາດໄດ້ຮັບການຈັດສັນແບບຄົງແລະເຫມາະເລັກນ້ອຍສໍາລັບການ runtime ໄດ້
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// ການດັດປັບທີ່ເປັນໄປໄດ້ທີ່ສາມາດຮຽກຮ້ອງໃຫ້ເປັນສ່ວນ ໜຶ່ງ ຂອງທິດທາງການຈັດຮູບແບບ.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// ສະແດງເຖິງມູນທີ່ເນື້ອຫາຄວນຈະຊ້າຍສອດຄ່ອງ.
    Left,
    /// ສະແດງໃຫ້ເຫັນວ່າເນື້ອໃນຄວນສອດຄ່ອງກັນ.
    Right,
    /// ສະແດງເຖິງມູນທີ່ເນື້ອຫາຄວນຈະສູນສອດຄ່ອງ.
    Center,
    /// ບໍ່ມີການຮ້ອງຂໍຄວາມສອດຄ່ອງ.
    Unknown,
}

/// ນໍາໃຊ້ໂດຍ [width](https://doc.rust-lang.org/std/fmt/#width) ແລະ [precision](https://doc.rust-lang.org/std/fmt/#precision) specifiers.
#[derive(Copy, Clone)]
pub enum Count {
    /// ລະບຸດ້ວຍຕົວເລກຕົວ ໜັງ ສື, ເກັບຄ່າ
    Is(usize),
    /// ລະບຸການນໍາໃຊ້ `$` ແລະ `*` ໄວຢາກອນ, ເກັບດັດຊະນີເຂົ້າໄປໃນ `args` ໄດ້
    Param(usize),
    /// ບໍ່ໄດ້ລະບຸ
    Implied,
}