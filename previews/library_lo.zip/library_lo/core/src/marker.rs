//! Primitive traits ແລະປະເພດທີ່ເປັນຕົວແທນຄຸນສົມບັດພື້ນຖານຂອງປະເພດ.
//!
//! ປະເພດ Rust ສາມາດໄດ້ຮັບການຈັດໃນຮູບແບບທີ່ເປັນປະໂຫຍດຕ່າງໆຕາມຄຸນສົມບັດທີ່ແທ້ຈິງຂອງເຂົາເຈົ້າ.
//! ຈໍາແນກປະເພດເຫຼົ່ານີ້ເປັນຕົວແທນເປັນ traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// ປະເພດທີ່ສາມາດໄດ້ຮັບການໂອນຂ້າມເຂດແດນກະທູ້.
///
/// trait ນີ້ຖືກປະຕິບັດອັດຕະໂນມັດໃນເວລາທີ່ compiler ໄດ້ກໍານົດວ່າມັນເປັນທີ່ເຫມາະສົມ.
///
/// ຕົວຢ່າງຂອງປະເພດທີ່ບໍ່ແມ່ນ `Send` ເປັນຊີ້ອ້າງອິງ, ນັບ [`rc::Rc`][`Rc`].
/// ຖ້າຫາກວ່າທັງສອງກະທູ້ພະຍາຍາມທີ່ຈະ clone [`Rc`] ຈຸດມູນຄ່າອ້າງອິງ, ນັບຄືກັນວ່າ, ພວກເຂົາເຈົ້າອາດຈະພະຍາຍາມປັບປຸງຈໍານວນກະສານອ້າງອີງໃນເວລາດຽວກັນ, ຊຶ່ງເປັນ [undefined behavior][ub] ເພາະ [`Rc`] ບໍ່ໄດ້ໃຊ້ການດໍາເນີນງານປະລໍາມະນູ.
///
/// ພີ່ນ້ອງຂອງຕົນ [`sync::Arc`][arc] ບໍ່ໃຊ້ການດໍາເນີນງານປະລໍາມະນູ (ເກີດຂຶ້ນຄ່າໃຊ້ຈ່າຍຈໍານວນຫນຶ່ງ) ແລະດັ່ງນັ້ນຈຶ່ງເປັນ `Send`.
///
/// ເບິ່ງ [the Nomicon](../../nomicon/send-and-sync.html) ສໍາລັບລາຍລະອຽດເພີ່ມເຕີມ.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// ປະເພດທີ່ມີຂະຫນາດຄົງຮູ້ຈັກໃນເວລາລວບລວມ.
///
/// ຕົວກໍານົດການປະເພດທັງຫມົດມີ implicit ຜູກພັນຂອງ `Sized`.ໄວຢາກອນພິເສດ `?Sized` ສາມາດຖືກນໍາໃຊ້ເພື່ອເອົານີ້ຜູກພັນຖ້າຫາກວ່າມັນບໍ່ເຫມາະສົມ.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//ຂໍ້ຜິດພາດ: ຂະ ໜາດ Sized ບໍ່ຖືກປະຕິບັດ ສຳ ລັບ [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// ມີຂໍ້ຍົກເວັ້ນຫນຶ່ງແມ່ນປະເພດ `Self` implicit ຂອງ trait.
/// A trait ບໍ່ມີ implicit `Sized` ຜູກພັນນີ້ບໍ່ຮອງຮັບ [trait object] ຄືບ່ອນທີ່, ໂດຍຄໍານິຍາມ, ການ trait ຕ້ອງການເຮັດວຽກກັບ implementor ເປັນໄປໄດ້ທັງຫມົດ, ແລະດັ່ງນັ້ນຈຶ່ງສາມາດຂະຫນາດໃດ.
///
///
/// ເຖິງແມ່ນວ່າ Rust ຈະໃຫ້ທ່ານເຊື່ອມໂຍງ `Sized` ກັບ trait, ທ່ານຈະບໍ່ສາມາດທີ່ຈະນໍາໃຊ້ມັນເພື່ອປະກອບເປັນວັດຖຸ trait ຕໍ່ມາ:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // let y: &dyn Bar= &Impl;//ຄວາມຜິດພາດ: ການ trait `Bar` ບໍ່ສາມາດເຮັດໃຫ້ເປັນວັດຖຸ
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // ສໍາລັບມາດຕະຖານ, ສໍາລັບການຍົກຕົວຢ່າງ, ເຊິ່ງຮຽກຮ້ອງໃຫ້ `[T]: !Default` ຈະ evaluatable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// ປະເພດທີ່ສາມາດຈະ "unsized" ກັບຊະນິດນະໂຍບາຍດ້ານຂະຫນາດ.
///
/// ສໍາລັບຕົວຢ່າງ, ຂະຫນາດປະເພດ array `[i8; 2]` ດໍາເນີນ `Unsize<[i8]>` ແລະ `Unsize<dyn fmt::Debug>`.
///
/// ການປະຕິບັດທັງຫມົດຂອງ `Unsize` ແມ່ນສະຫນອງໃຫ້ໂດຍອັດໂນມັດໂດຍ compiler ໄດ້.
///
/// `Unsize` ຈະດໍາເນີນການສໍາລັບການ:
///
/// - `[T; N]` ແມ່ນ `Unsize<[T]>`
/// - `T` ແມ່ນ `Unsize<dyn Trait>` ໃນເວລາທີ່ `T: Trait`
/// - `Foo<..., T, ...>` ແມ່ນ `Unsize<Foo<..., U, ...>>` ຖ້າ:
///   - `T: Unsize<U>`
///   - Foo ເປັນ struct ເປັນ
///   - ມີພຽງແຕ່ພາກສະຫນາມສຸດທ້າຍຂອງ `Foo` ມີປະເພດທີ່ກ່ຽວຂ້ອງກັບ `T` ເປັນ
///   - `T` ມັນບໍ່ແມ່ນສ່ວນ ໜຶ່ງ ຂອງປະເພດຂອງຂົງເຂດອື່ນ
///   - `Bar<T>: Unsize<Bar<U>>`, ຖ້າຫາກວ່າພາກສະຫນາມສຸດທ້າຍຂອງ `Foo` ມີເພດ `Bar<T>`
///
/// `Unsize` ຖືກນໍາໃຊ້ຄຽງຄູ່ກັບ [`ops::CoerceUnsized`] ອະນຸຍາດໃຫ້ບັນຈຸ "user-defined" ເຊັ່ນ [`Rc`] ເພື່ອປະກອບດ້ວຍປະເພດນະໂຍບາຍດ້ານຂະຫນາດ.
/// ເບິ່ງ [DST coercion RFC][RFC982] ແລະ [the nomicon entry on coercion][nomicon-coerce] ສໍາລັບລາຍລະອຽດເພີ່ມເຕີມ.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// ທີ່ກໍານົດໄວ້ trait ສໍາລັບຄົງໃຊ້ໃນການແຂ່ງຂັນຮູບແບບ.
///
/// ປະເພດທີ່ອະນຸພັນ `PartialEq` ອັດຕະໂນມັດດໍາເນີນ trait ນີ້,*ໂດຍບໍ່ຄໍານຶງ* ບໍ່ວ່າຈະເປັນປະເພດ, ຕົວກໍານົດການຂອງຕົນປະຕິບັດ `Eq`.
///
/// ຖ້າສິນຄ້າ `const` ມີບາງປະເພດທີ່ບໍ່ປະຕິບັດ trait ນີ້, ປະເພດນັ້ນກໍ່ຈະບໍ່ (1.) ບໍ່ປະຕິບັດ `PartialEq` (ຊຶ່ງ ໝາຍ ຄວາມວ່າຄົງທີ່ຈະບໍ່ສະ ໜອງ ວິທີການປຽບທຽບດັ່ງກ່າວ, ເຊິ່ງລະຫັດການຜະລິດລະຫັດໃດ ໜຶ່ງ ຖືວ່າມີ), ຫຼື (2.) ມັນປະຕິບັດ *ມັນເອງ ສະບັບພາສາຂອງ `PartialEq` (ທີ່ພວກເຮົາສົມມຸດບໍ່ສອດຄ່ອງກັບການປຽບທຽບໂຄງສ້າງ, ຄວາມສະເຫມີພາບ)*.
///
///
/// ໃນຫຼາຍກ່ວາທັງສອງສະຖານະການຂ້າງເທິງນີ້, ພວກເຮົາປະຕິເສດການນໍາໃຊ້ຂອງດັ່ງກ່າວຄົງທີ່ໃນການແຂ່ງຂັນຮູບແບບ.
///
/// ກະລຸນາເບິ່ງ [structural match RFC][RFC1445] ແລະ [issue 63438] ທີ່ໂຍກຍ້າຍແຮງບັນດານໃຈຈາກການອອກແບບຄຸນສົມບັດທີ່ຈະ trait ນີ້.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// ທີ່ກໍານົດໄວ້ trait ສໍາລັບຄົງໃຊ້ໃນການແຂ່ງຂັນຮູບແບບ.
///
/// ປະເພດທີ່ອະນຸພັນ `Eq` ອັດຕະໂນມັດດໍາເນີນ trait ນີ້,*ໂດຍບໍ່ຄໍານຶງ* ບໍ່ວ່າຈະເປັນຕົວກໍານົດປະເພດຂອງຕົນປະຕິບັດ `Eq`.
///
/// ນີ້ແມ່ນ hack ເຮັດວຽກປະມານຈໍາກັດໃນລະບົບການພິມຂອງພວກເຮົາ.
///
/// # Background
///
/// ພວກເຮົາຕ້ອງການທີ່ຈະຮຽກຮ້ອງໃຫ້ປະເພດຂອງ const ໃຊ້ໃນການແຂ່ງຂັນຮູບແບບມີເຫດຜົນວ່າ `#[derive(PartialEq, Eq)]` ໄດ້.
///
/// ໃນໂລກທີ່ເຫມາະສົມຫຼາຍ, ພວກເຮົາສາມາດກວດເບິ່ງຂໍ້ກໍານົດວ່າດ້ວຍພຽງແຕ່ການກວດສອບວ່າໄດ້ຮັບການປະຕິບັດປະເພດທັງ `StructuralPartialEq` trait *ແລະ* ການ `Eq` trait.
/// ຢ່າງໃດກໍຕາມ, ທ່ານສາມາດມີ ADTs ວ່າ *ເຮັດ*`derive(PartialEq, Eq)`, ແລະເປັນກໍລະນີທີ່ພວກເຮົາຕ້ອງການ compiler ໃນການຍອມຮັບ, ແລະຍັງປະເພດຄົງທີ່ຂອງບໍ່ສາມາດທີ່ຈະປະຕິບັດ `Eq`.
///
/// ຊື່ສາມັນ, ເປັນກໍລະນີຄ້າຍຄືນີ້:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (ບັນຫາໃນລະຫັດຂ້າງເທິງນີ້ແມ່ນວ່າ `Wrap<fn(&())>` ບໍ່ໃຊ້ `PartialEq`, ຫຼື `Eq`, ເນື່ອງຈາກວ່າ `ສໍາລັບ < 'ເປັນ> fn(&'a _)` does not implement those traits.)
///
/// ດັ່ງນັ້ນ, ພວກເຮົາບໍ່ສາມາດອີງໃສ່ການກວດສອບ naive ສໍາລັບ `StructuralPartialEq` ແລະແຕ່ `Eq`.
///
/// ໃນຖານະ hack ເພື່ອເຮັດວຽກປະມານນີ້, ພວກເຮົານໍາໃຊ້ທັງສອງແຍກຕ່າງຫາກ traits ສັກໂດຍແຕ່ລະຂອງສອງອະນຸພັນ (`#[derive(PartialEq)]` ແລະ `#[derive(Eq)]`) ແລະກວດເບີ່ງວ່າທັງສອງຂອງພວກເຂົາແມ່ນປັດຈຸບັນເປັນສ່ວນຫນຶ່ງຂອງການກວດສອບໂຄງສ້າງ, ການແຂ່ງຂັນ.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// ປະເພດທີ່ຄ່າສາມາດໄດ້ຮັບການ duplicated ພຽງແຕ່ໂດຍການຄັດລອກ bits.
///
/// ຕັ້ງແຕ່ຕອນຕົ້ນ, ຜູກມັດຕົວປ່ຽນແປງມີ 'ຄວາມຫມາຍຍ້າຍ.ໃນຄໍາສັບຕ່າງໆອື່ນໆ:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` ໄດ້ຍ້າຍເຂົ້າໄປໃນ `y`, ແລະອື່ນໆບໍ່ສາມາດໄດ້ຮັບການນໍາໃຊ້
///
/// // println ("{: ?}", x)!//ຄວາມຜິດພາດ: ການນໍາໃຊ້ມູນຄ່າຍ້າຍ
/// ```
///
/// ຢ່າງໃດກໍຕາມ, ຖ້າຫາກວ່າປະເພດການປະຕິບັດ `Copy`, ມັນແທນທີ່ຈະມີ 'ສໍາເນົາຄວາມຫມາຍ':
///
/// ```
/// // ພວກເຮົາສາມາດມາຈາກການປະຕິບັດ `Copy`.
/// // `Clone` ແມ່ນຍັງຕ້ອງການ, ຍ້ອນວ່າມັນເປັນ supertrait ຂອງ `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` ແມ່ນສໍາເນົາຂອງ `x` ເປັນ
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// ມັນເປັນສິ່ງສໍາຄັນທີ່ຈະສັງເກດວ່າໃນການເຫຼົ່ານີ້ທັງສອງຕົວຢ່າງ, ຄວາມແຕກຕ່າງກັນພຽງແຕ່ແມ່ນວ່າທ່ານກໍາລັງອະນຸຍາດໃຫ້ເຂົ້າເຖິງ `x` ຫຼັງຈາກການແຕ່ງຕັ້ງ.
/// ພາຍໃຕ້ຜ້າຄຸມ, ທັງ ສຳ ເນົາແລະການເຄື່ອນໄຫວສາມາດສົ່ງຜົນເຮັດໃຫ້ບິດຖືກຄັດລອກໃນຄວາມຊົງ ຈຳ, ເຖິງແມ່ນວ່າບາງເທື່ອສິ່ງນີ້ຈະຖືກປັບປຸງໃຫ້ດີຂື້ນ.
///
/// ## ຂ້ອຍສາມາດປະຕິບັດ `Copy` ໄດ້ແນວໃດ?
///
/// ມີສອງວິທີເພື່ອປະຕິບັດ `Copy` ກ່ຽວກັບປະເທດຂອງທ່ານແມ່ນ.ການງ່າຍທີ່ສຸດຄືການໃຊ້ `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// ນອກນັ້ນທ່ານຍັງສາມາດໃຊ້ `Copy` ແລະ `Clone` ດ້ວຍຕົນເອງ:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// ມີຄວາມແຕກຕ່າງຂະຫນາດນ້ອຍລະຫວ່າງສອງແມ່ນ: ຍຸດທະສາດການ `derive` ຍັງຈະວາງ `Copy` ຜູກພັນກ່ຽວກັບຕົວກໍານົດການປະເພດ, ຊຶ່ງກໍບໍ່ແມ່ນຕ້ອງການສະເຫມີໄປ.
///
/// ## ສິ່ງທີ່ແຕກຕ່າງລະຫວ່າງ `Copy` ແລະ `Clone` ແນວໃດ?
///
/// ສໍາເນົາເກີດຂຶ້ນໂດຍປະລິຍາຍ, ສໍາລັບການຍົກຕົວຢ່າງເປັນສ່ວນຫນຶ່ງຂອງການມອບຫມາຍ `y = x`.ພຶດຕິ ກຳ ຂອງ `Copy` ແມ່ນບໍ່ສາມາດໂຫຼດໄດ້ເກີນ;ມັນເປັນສະເຫມີໄປສໍາເນົາ bit ສະຫລາດງ່າຍດາຍ.
///
/// Cloning ການປະຕິບັດຢ່າງຊັດເຈນ, `x.clone()`.ການປະຕິບັດຂອງ [`Clone`] ສາມາດສະຫນອງພຶດຕິກໍາປະເພດສະເພາະໃດຫນຶ່ງມີຄວາມຈໍາເປັນທີ່ຈະຊ້ໍາຄ່າໄດ້ຢ່າງປອດໄພ.
/// ສໍາລັບຕົວຢ່າງ, ການປະຕິບັດຂອງ [`Clone`] ສໍາລັບ [`String`] ຕ້ອງສໍາເນົາແຫຼມກັບ string buffer ໃນ heap ໄດ້.
/// ສໍາເນົາຄ່າທີ່ເຫມາະສົມງ່າຍດາຍຂອງຄ່າ [`String`] ແຕ່ຈະສໍາເນົາຕົວຊີ້, ອັນເຮັດໃຫ້ມີສອງລົງເສັ້ນ.
/// ສໍາລັບເຫດຜົນດັ່ງກ່າວນີ້, [`String`] ແມ່ນ [`Clone`] ແຕ່ບໍ່ `Copy`.
///
/// [`Clone`] ເປັນ supertrait ຂອງ `Copy`, ສະນັ້ນທຸກສິ່ງທຸກຢ່າງຊຶ່ງເປັນ `Copy` ຍັງຈະຕ້ອງດໍາເນີນ [`Clone`].
/// ຖ້າຫາກວ່າປະເພດແມ່ນ `Copy` ຫຼັງຈາກນັ້ນການປະຕິບັດຂອງຕົນ [`Clone`] ພຽງແຕ່ຕ້ອງການທີ່ຈະກັບຄືນ `*self` (ເບິ່ງຕົວຢ່າງຂ້າງເທິງນີ້).
///
/// ## ໃນເວລາທີ່ປະເພດຂອງຂ້າພະເຈົ້າສາມາດ `Copy`?
///
/// ປະເພດສາມາດໃຊ້ `Copy` ຖ້າທັງຫມົດຂອງອົງປະກອບຂອງຕົນປະຕິບັດ `Copy`.ສໍາລັບຕົວຢ່າງ, struct ນີ້ສາມາດ `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// A struct ສາມາດ `Copy` ແລະ [`i32`] ແມ່ນ `Copy`, ເພາະສະນັ້ນຈຶ່ງ `Point` ແມ່ນມີສິດໄດ້ຮັບຈະ `Copy`.
/// ໂດຍທາງກົງກັນຂ້າມ, ພິຈາລະນາ
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// The struct `PointList` ບໍ່ສາມາດປະຕິບັດ `Copy`, ເນື່ອງຈາກວ່າ [`Vec<T>`] ບໍ່ `Copy`.ຖ້າພວກເຮົາພະຍາຍາມຫາການປະຕິບັດ `Copy`, ພວກເຮົາຈະມີຂໍ້ຜິດພາດ:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// ເອກະສານທີ່ໃຊ້ຮ່ວມກັນ (`&T`) ແມ່ນຍັງ `Copy`, ສະນັ້ນເປັນປະເພດສາມາດ `Copy`, ເຖິງແມ່ນວ່າໃນເວລາທີ່ມັນຖືເອກະສານປະເພດ `T` ທີ່ມີ *ບໍ່*`Copy` ແບ່ງປັນ.
/// ພິຈາລະນາໄດ້ struct ດັ່ງຕໍ່ໄປນີ້, ເຊິ່ງສາມາດປະຕິບັດ `Copy`, ເນື່ອງຈາກວ່າມັນພຽງແຕ່ຖື *ອ້າງອິງແບ່ງປັນ* ກັບພວກເຮົາປະເພດທີ່ບໍ່ແມ່ນ `Copy` `PointList` ຈາກຂ້າງເທິງ:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## ໃນເວລາທີ່ *ບໍ່ສາມາດ* ປະເພດຂອງຂ້າພະເຈົ້າເປັນ `Copy`?
///
/// ບາງຊະນິດບໍ່ສາມາດໄດ້ຮັບການຄັດລອກໄດ້ຢ່າງປອດໄພ.ສໍາລັບຕົວຢ່າງ, ການສໍາເນົາ `&mut T` ຈະສ້າງກະສານອ້າງອີງບໍ່ແນ່ນອນ aliased.
/// ການຄັດລອກ [`String`] ຈະຊ້ໍາກັນຄວາມຮັບຜິດຊອບສໍາລັບການຄຸ້ມຄອງຂອງ [`String`] 's ປ້ອງກັນ, ອັນເຮັດໃຫ້ມີ double ຟຣີ.
///
/// Generalizing ກໍລະນີກໍ, ປະເພດໃດປະຕິບັດ [`Drop`] ບໍ່ສາມາດຈະ `Copy`, ເນື່ອງຈາກວ່າມັນໄດ້ຈັດການຊັບພະຍາກອນຈໍານວນຫນຶ່ງນອກຈາກ [`size_of::<T>`] ຂອງຕົນເອງໄບ.
///
/// ຖ້າຫາກວ່າທ່ານພະຍາຍາມທີ່ຈະປະຕິບັດ `Copy` ສຸດ struct ຫຼື enum ມີຂໍ້ມູນທີ່ບໍ່ແມ່ນ `Copy`, ທ່ານຈະໄດ້ຮັບຄວາມຜິດພາດ [E0204] ໄດ້.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## ໃນເວລາທີ່ * * ປະເພດຂອງຂ້າພະເຈົ້າຄວນຈະ `Copy`?
///
/// ໂດຍທົ່ວໄປໃນການເວົ້າ, ຖ້າຫາກວ່າປະເພດ _can_ ທ່ານໃຊ້ `Copy`, ມັນຄວນ.
/// ໃຫ້ເກັບຮັກສາໃນຈິດໃຈ, ເຖິງແມ່ນວ່າ, ທີ່ປະຕິບັດ `Copy` ເປັນສ່ວນຫນຶ່ງຂອງ API ສາທາລະນະຂອງປະເທດຂອງທ່ານ.
/// ຖ້າຫາກວ່າປະເພດອາດຈະກາຍເປັນທີ່ບໍ່ແມ່ນ `Copy` ໃນ future, ມັນອາດຈະລະມັດລະວັງທີ່ຈະລະເວັ້ນການປະຕິບັດໃນປັດຈຸບັນ `Copy`, ເພື່ອຫຼີກເວັ້ນການມີການປ່ຽນແປງ API ລາຍ.
///
/// ## ຜູ້ປະຕິບັດການເພີ່ມເຕີມ
///
/// ນອກເຫນືອໄປຈາກ [implementors listed below][impls], ປະເພດດັ່ງຕໍ່ໄປນີ້ຍັງໃຊ້ `Copy`:
///
/// * ປະເພດລາຍການ Function (ຕົວຢ່າງ, ປະເພດທີ່ແຕກຕ່າງກັນກໍານົດສໍາລັບແຕ່ລະການທໍາງານ)
/// * ປະເພດຊີ້ Function (ຕົວຢ່າງ: , `fn() -> i32`)
/// * ປະເພດ Array, ສໍາລັບທຸກຂະຫນາດ, ຖ້າຫາກວ່າປະເພດລາຍການທີ່ຍັງປະຕິບັດ `Copy` (ຕົວຢ່າງ: , `[i32; 123456]`)
/// * ປະເພດ tuple, ຖ້າຫາກວ່າໃນແຕ່ລະອົງປະກອບຍັງປະຕິບັດ `Copy` (ຕົວຢ່າງ: , `()`, `(i32, bool)`)
/// * ປະເພດປິດ, ຖ້າຫາກວ່າພວກເຂົາເຈົ້າເກັບກໍາມູນຄ່າບໍ່ມີຈາກສະພາບແວດລ້ອມຫຼືຖ້າຫາກວ່າຄ່າ captured ທັງຫມົດດັ່ງກ່າວໃຊ້ `Copy` ເຂົາເຈົ້າເອງ.
///   ໃຫ້ສັງເກດວ່າຕົວແປທີ່ຖືກຈັບໂດຍການອ້າງອີງທີ່ໃຊ້ຮ່ວມກັນສະເຫມີປະຕິບັດ `Copy` (ເຖິງແມ່ນວ່າເອກະສານອ້າງອີງບໍ່ໄດ້), ໃນຂະນະທີ່ຕົວແປທີ່ຖືກຈັບໂດຍການອ້າງອິງທີ່ປ່ຽນແປງບໍ່ເຄີຍປະຕິບັດ `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) ນີ້ອະນຸຍາດໃຫ້ເອົາສໍາເນົາປະເພດທີ່ບໍ່ໃຊ້ `Copy` ເນື່ອງຈາກວ່າຂອບເຂດຕະຫຼອດຊີວິດບໍ່ພໍໃຈເປັນ (ສໍາເນົາ `A<'_>` ໃນເວລາທີ່ພຽງແຕ່ `A<'static>: Copy` ແລະ `A<'_>: Clone`).
// ພວກເຮົາມີເຫດຜົນນີ້ທີ່ນີ້ສໍາລັບໃນປັດຈຸບັນພຽງແຕ່ເນື່ອງຈາກວ່າມີບໍ່ຫຼາຍປານໃດພິເສດທີ່ມີຢູ່ແລ້ວກ່ຽວກັບ `Copy` ທີ່ມີຢູ່ແລ້ວໃນຫ້ອງສະຫມຸດມາດຕະຖານ, ແລະມີວິທີການໄດ້ຢ່າງປອດໄພມີພຶດຕິກໍານີ້ໃນຂະນະນີ້ບໍ່ມີ.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// ມະຫາພາກ Derive ສ້າງເປັນ impl ຂອງ trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// ປະເພດທີ່ມັນປອດໄພທີ່ຈະແບ່ງປັນການອ້າງອີງລະຫວ່າງກະທູ້.
///
/// trait ນີ້ຖືກປະຕິບັດອັດຕະໂນມັດໃນເວລາທີ່ compiler ໄດ້ກໍານົດວ່າມັນເປັນທີ່ເຫມາະສົມ.
///
/// ຄໍານິຍາມຊັດເຈນແມ່ນ: ຊະນິດ `T` ແມ່ນ [`Sync`] ຖ້າແລະພຽງແຕ່ຖ້າຫາກວ່າ `&T` ແມ່ນ [`Send`].
/// ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ຖ້າຫາກວ່າມີຄວາມເປັນໄປໄດ້ຂອງ [undefined behavior][ub] ບໍ່ມີ (ລວມທັງເຊື້ອຊາດຂໍ້ມູນ) ໃນເວລາທີ່ຜ່ານເອກະສານ `&T` ລະຫວ່າງຫົວຂໍ້.
///
/// ໃນຖານະເປັນຫນຶ່ງກໍ່ຈະຄາດຫວັງ, ປະເພດ primitive ຄື [`u8`] ແລະ [`f64`] ມີ [`Sync`] ທັງຫມົດ, ແລະດັ່ງນັ້ນແມ່ນປະເພດລວມງ່າຍດາຍທີ່ມີໃຫ້ເຂົາເຈົ້າ, ເຊັ່ນ: Tuples, struct ແລະ ENUM.
/// ຕົວຢ່າງເພີ່ມເຕີມປະເພດ [`Sync`] ພື້ນຖານປະກອບມີປະເພດ "immutable" ຄື `&T`, ແລະຜູ້ທີ່ມີງ່າຍດາຍຮັບມໍລະດົກທີ່ບໍ່ແນ່ນອນເຊັ່ນ [`Box<T>`][box], [`Vec<T>`][vec] ແລະສ່ວນໃຫຍ່ປະເພດການເກັບຄ່າອື່ນໆ.
///
/// (ຕົວກໍານົດການທົ່ວໄປຈໍາເປັນຕ້ອງ [`Sync`] ສໍາລັບບັນຈຸຂອງເຂົາເຈົ້າຈະ [`Sync`].)
///
/// A ຜົນສິ່ງທີ່ແປກໃຈຂອງຄໍານິຍາມແມ່ນວ່າ `&mut T` ແມ່ນ `Sync` (ຖ້າ `T` ແມ່ນ `Sync`) ເຖິງແມ່ນວ່າມັນເບິ່ງຄືວ່າຄ້າຍຄືວ່າອາດຈະສະຫນອງ mutation unsynchronized.
/// ສິ່ງທີ່ສໍາຄັນແມ່ນວ່າກະສານອ້າງອີງບໍ່ແນ່ນອນທາງຫລັງຂອງການອ້າງອິງແບ່ງປັນ (ຫມາຍຄວາມວ່າ, `& &mut T`) ກາຍເປັນອ່ານເທົ່ານັ້ນ, ເປັນຖ້າຫາກວ່າມັນໄດ້ເປັນ `& &T`.
/// ເພາະສະນັ້ນມີຄວາມສ່ຽງຕໍ່ການເປັນເຊື້ອຊາດຂໍ້ມູນທີ່ບໍ່ມີ.
///
/// ປະເພດທີ່ບໍ່ແມ່ນ `Sync` ແມ່ນຜູ້ທີ່ມີ "interior mutability" ໃນຮູບແບບທີ່ບໍ່ແມ່ນກະທູ້, ຄວາມປອດໄພ, ເຊັ່ນ: [`Cell`][cell] ແລະ [`RefCell`][refcell].
/// ປະເພດເຫຼົ່ານີ້ອະນຸຍາດໃຫ້ສໍາລັບການກາຍພັນຂອງເນື້ອຫາຂອງເຂົາເຈົ້າເຖິງແມ່ນວ່າຜ່ານການປ່ຽນແປງ, ກະສານອ້າງອີງການແບ່ງປັນ.
/// ຕົວຢ່າງ: ວິທີ `set` ໃນ [`Cell<T>`][cell] ໃຊ້ `&self`, ສະນັ້ນມັນຮຽກຮ້ອງໃຫ້ມີເອກະສານອ້າງອີງ [`&Cell<T>`][cell] ທີ່ໃຊ້ຮ່ວມກັນເທົ່ານັ້ນ.
/// ວິທີການດໍາເນີນການທີ່ບໍ່ມີການປະສານ, ດັ່ງນັ້ນຈຶ່ງ [`Cell`][cell] ບໍ່ສາມາດຈະ `Sync`.
///
/// ຕົວຢ່າງຂອງປະເພດທີ່ບໍ່ແມ່ນ `Sync` ອື່ນເປັນຊີ້ອ້າງອິງ, ນັບ [`Rc`][rc].
/// ໃຫ້ກະສານອ້າງອີງໃດໆ [`&Rc<T>`][rc], ທ່ານສາມາດ clone ເປັນ [`Rc<T>`][rc] ໃຫມ່, ການປັບປຸງນັບອ້າງອິງໃນວິທີການທີ່ບໍ່ແມ່ນປະລໍາມະນູ.
///
/// ສໍາລັບກໍລະນີໃນເວລາທີ່ຫນຶ່ງບໍ່ຈໍາເປັນຕ້ອງກະທູ້, ຄວາມປອດໄພທີ່ບໍ່ແນ່ນອນພາຍໃນ, Rust ໃຫ້ [atomic data types], ເຊັ່ນດຽວກັນກັບລັອກຢ່າງຊັດເຈນໂດຍຜ່ານ [`sync::Mutex`][mutex] ແລະ [`sync::RwLock`][rwlock].
/// ປະເພດເຫຼົ່ານີ້ຮັບປະກັນວ່າການກາຍພັນໃດສາມາດບໍ່ແມ່ນສາເຫດເຊື້ອຊາດຂໍ້ມູນ, ເພາະສະນັ້ນປະເພດແມ່ນ `Sync`.
/// ເຊັ່ນດຽວກັນ, [`sync::Arc`][arc] ສະຫນອງຮ່ວມກະທູ້, ຄວາມປອດໄພຂອງ [`Rc`][rc].
///
/// ຂໍອະນຸຍາດກັບບໍ່ແນ່ນອນພາຍໃນຍັງຕ້ອງໃຊ້ wrapper [`cell::UnsafeCell`][unsafecell] ປະມານ value(s) ທີ່ສາມາດໄດ້ຮັບການ mutated ໂດຍຜ່ານກະສານອ້າງອີງການແບ່ງປັນ.
/// ລົ້ມເຫລວໃນການດໍາເນີນການນີ້ແມ່ນ [undefined behavior][ub].
/// ສໍາລັບຕົວຢ່າງ, [`transmute`][transmutation]-ing ຈາກ `&T` ກັບ `&mut T` ບໍ່ຖືກຕ້ອງ.
///
/// ເບິ່ງ [the Nomicon][nomicon-send-and-sync] ສໍາລັບລາຍລະອຽດເພີ່ມເຕີມກ່ຽວກັບ `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): ເມື່ອສະຫນັບສະຫນູນການເພີ່ມອ່ືໃນ `rustc_on_unimplemented` ດິນໃນທົດລອງ, ແລະມັນໄດ້ຮັບການຂະຫຍາຍການກວດສອບບໍ່ວ່າຈະເປັນການປິດເປັນທຸກແຫ່ງຫົນໃນລະບົບຕ່ອງໂສ້ຄວາມຕ້ອງການ, ຂະຫຍາຍມັນເປັນ (#48534) ເຊັ່ນ:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// ສູນຂະຫນາດປະເພດຖືກນໍາໃຊ້ເພື່ອຫມາຍສິ່ງທີ່ "act like" ພວກເຂົາເຈົ້າເປັນເຈົ້າຂອງ `T`.
///
/// ເພີ່ມພາກສະຫນາມ `PhantomData<T>` ກັບປະເທດຂອງທ່ານບອກ compiler ທີ່ປະເທດຂອງທ່ານເຮັດຫນ້າທີ່ເປັນເຖິງແມ່ນວ່າມັນເກັບຄ່າປະເພດ `T`, ເຖິງແມ່ນວ່າມັນບໍ່ໄດ້ແທ້.
/// ຂໍ້ມູນນີ້ແມ່ນໃຊ້ໃນເວລາທີ່ຄິດໄລ່ຄຸນສົມບັດດ້ານຄວາມປອດໄພບາງຢ່າງ.
///
/// ສໍາລັບຄໍາອະທິບາຍເພີ່ມເຕີມໃນຄວາມເລິກຂອງວິທີການທີ່ຈະນໍາໃຊ້ `PhantomData<T>`, ກະລຸນາເບິ່ງ [the Nomicon](../../nomicon/phantom-data.html).
///
/// # ບັນທຶກ ghastly 👻👻👻
///
/// ເຖິງແມ່ນວ່າພວກເຂົາເຈົ້າທັງສອງມີຊື່ຢ້ານ, `PhantomData` ແລະ 'ປະເພດ phantom' ກໍາລັງທີ່ກ່ຽວຂ້ອງ, ແຕ່ບໍ່ຄືກັນ.A ພາລາມິເຕີປະເພດ phantom ແມ່ນພຽງແຕ່ເປັນຕົວກໍານົດປະເພດທີ່ບໍ່ເຄີຍນໍາໃຊ້.
/// ໃນ Rust ເລື່ອງນີ້ມັກຈະເຮັດໃຫ້ compiler ທີ່ຈະຈົ່ມ, ແລະການແກ້ບັນຫາຄືການເພີ່ມການນໍາໃຊ້ "dummy" ໂດຍວິທີການຂອງ `PhantomData`.
///
/// # Examples
///
/// ## ຕົວກໍານົດການຕະຫຼອດຊີວິດທີ່ບໍ່ໄດ້ໃຊ້
///
/// ບາງທີອາດມີຫຼາຍທີ່ສຸດກໍລະນີການນໍາໃຊ້ທົ່ວໄປສໍາລັບ `PhantomData` ເປັນ struct ທີ່ມີພາລາມິເຕີຕະຫຼອດຊີວິດທີ່ບໍ່ໄດ້ໃຊ້, ປົກກະຕິເປັນສ່ວນຫນຶ່ງຂອງລະຫັດທີ່ບໍ່ປອດໄພຈໍານວນຫນຶ່ງ.
/// ສໍາລັບຕົວຢ່າງ, ໃນທີ່ນີ້ແມ່ນເປັນ struct `Slice` ທີ່ມີສອງຄໍາແນະນໍາຂອງປະເພດ `*const T`, ສັນນິຖານວ່າຊີ້ເຂົ້າໄປໃນບ່ອນ array:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// ຈຸດປະສົງແມ່ນວ່າຂໍ້ມູນທີ່ຕິດພັນແມ່ນພຽງແຕ່ຖືກຕ້ອງສໍາລັບການຕະຫຼອດຊີວິດ `'a`, ສະນັ້ນ `Slice` ບໍ່ຄວນ outlive `'a`.
/// ຢ່າງໃດກໍຕາມ, ຈຸດປະສົງນີ້ແມ່ນບໍ່ສະແດງໃນລະຫັດ, ນັບຕັ້ງແຕ່ມີການນໍາໃຊ້ຂອງຕະຫຼອດຊີວິດ `'a` ບໍ່ມີແລະເພາະສະນັ້ນມັນບໍ່ໄດ້ຖືກອະນາໄມສິ່ງທີ່ຂໍ້ມູນມັນໃຊ້ໄດ້ກັບ.
/// ພວກເຮົາສາມາດແກ້ໄຂໄດ້ໂດຍການບອກ compiler ໃນການປະຕິບັດ *ເປັນຖ້າຫາກວ່າ* ໄດ້ struct `Slice` ບັນຈຸກະສານອ້າງອີງ `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// ນີ້ແລະເຮັດໃຫ້ການຮຽກຮ້ອງໃຫ້ບັນທຶກຫຍໍ້ `T: 'a` ໄດ້, ຊີ້ໃຫ້ເຫັນວ່າເອກະສານໃດຫນຶ່ງໃນ `T` ແມ່ນຖືກຕ້ອງໃນໄລຍະຕະຫຼອດຊີວິດ `'a`.
///
/// ໃນເວລາທີ່ເລີ່ມຕົ້ນເປັນ `Slice` ທ່ານພຽງແຕ່ສະຫນອງການ `PhantomData` ຄ່າພາກສະຫນາມ `phantom` ໄດ້:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## ຕົວກໍານົດການປະເພດທີ່ບໍ່ໄດ້ໃຊ້
///
/// ບາງຄັ້ງມັນເກີດຂຶ້ນວ່າທ່ານມີພາລາມິເຕີປະເພດທີ່ບໍ່ໄດ້ໃຊ້ທີ່ຊີ້ໃຫ້ເຫັນສິ່ງທີ່ປະເພດຂອງຂໍ້ມູນ struct ເປັນ "tied" ກັບ, ເຖິງແມ່ນວ່າຂໍ້ມູນທີ່ບໍ່ໄດ້ພົບເຫັນຕົວຈິງໃນ struct ຕົວຂອງມັນເອງ.
/// ຕໍ່ໄປນີ້ແມ່ນຕົວຢ່າງທີ່ນີ້ເກີດຂື້ນກັບ [FFI] ເປັນ.
/// ການນໍາໃຊ້ໃນການໂຕ້ຕອບຕ່າງປະເທດຈັບຂອງປະເພດ `*mut ()` ທີ່ຈະກ່າວເຖິງຄ່າ Rust ຂອງປະເພດທີ່ແຕກຕ່າງກັນ.
/// ພວກເຮົາຕິດຕາມປະເພດ Rust ໂດຍໃຊ້ພາລາມິເຕີປະເພດ phantom ເທິງ `ExternalResource` X ໂຄງສ້າງເຊິ່ງຫໍ່ຈັບ.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## ຄວາມເປັນເຈົ້າຂອງແລະການກວດສອບການຫຼຸດລົງຂອງ
///
/// ເພີ່ມພາກສະຫນາມຂອງປະເພດ `PhantomData<T>` ຊີ້ໃຫ້ເຫັນວ່າປະເພດຂອງທ່ານເປັນເຈົ້າຂອງຂໍ້ມູນຂອງປະເພດ `T`.ນີ້ແລະເຮັດໃຫ້ການຫມາຍຄວາມວ່າໃນເວລາທີ່ປະເທດຂອງທ່ານແມ່ນຫຼຸດລົງ, ມັນອາດຈະລຸດລົງຫນຶ່ງຫຼືຫຼາຍກວ່ານັ້ນກໍລະນີຂອງປະເພດ `T` ໄດ້.
/// ນີ້ມີຮັບຜິດຊອບກ່ຽວກັບການວິເຄາະ [drop check] ໄດ້ compiler Rust ຂອງ.
///
/// ຖ້າ struct ຂອງທ່ານບໍ່ໄດ້ໃນຄວາມເປັນຈິງ *ເອງ* ຂໍ້ມູນຈາກປະເພດນີ້ `T` ໄດ້, ມັນເປັນທີ່ດີກວ່າທີ່ຈະນໍາໃຊ້ປະເພດກະສານອ້າງອີງ, ເຊັ່ນ `PhantomData<&'a T>` (ideally) ຫຼື `PhantomData<*const T>` (ຖ້າຫາກວ່າຕະຫຼອດຊີວິດບໍ່ມີໃຊ້), ສະນັ້ນເປັນທີ່ຈະບໍ່ລະບຸຄວາມເປັນເຈົ້າຂອງ.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler, ພາຍໃນ trait ຖືກນໍາໃຊ້ເພື່ອຊີ້ບອກປະເພດຂອງການຈໍາແນກທີ່ enum ໄດ້.
///
/// trait ນີ້ຖືກປະຕິບັດອັດຕະໂນມັດສໍາລັບທຸກປະເພດແລະບໍ່ເພີ່ມການຮັບປະກັນທີ່ຈະ [`mem::Discriminant`].
/// ມັນເປັນພຶດຕິກໍາ undefined ** ** ກັບປ່ຽນລະຫວ່າງ `DiscriminantKind::Discriminant` ແລະ `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// ປະເພດຂອງຈໍາແນກ, ເຊິ່ງຕ້ອງຕອບສະຫນອງຄວາມ trait bounds ຕ້ອງໂດຍ `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-internal trait ເຄີຍໃຊ້ໃນການ ກຳ ນົດວ່າປະເພດໃດ ໜຶ່ງ ມີ `UnsafeCell` ພາຍໃນ, ແຕ່ບໍ່ແມ່ນຜ່ານການປັກຫຼັກ ໝາຍ.
///
/// ນີ້ມີຜົນກະທົບ, ສໍາລັບການຍົກຕົວຢ່າງ, ບໍ່ວ່າຈະເປັນ `static` ຂອງປະເພດທີ່ແມ່ນຖືກຈັດໃສ່ໃນອ່ານເທົ່ານັ້ນຄວາມຊົງຈໍາແບບຄົງທີ່ຫລືຄວາມຊົງຈໍາ static ຂຽນ.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// ປະເພດທີ່ສາມາດໄດ້ຮັບການຍ້າຍໄດ້ຢ່າງປອດໄພພາຍຫຼັງທີ່ຖືກ pinned.
///
/// Rust ຕົວຂອງມັນເອງມີແນວຄິດທີ່ເລື່ອງຂອງປະເພດບໍ່ຫວັ່ນໄຫວບໍ່ມີ, ແລະພິຈາລະນາການເຄື່ອນໄຫວ (ຕົວຢ່າງ: , ໂດຍຜ່ານການມອບຫມາຍຫຼື [`mem::replace`]) ເພື່ອຄວາມປອດໄພສະເຫມີໄປ.
///
/// ປະເພດ [`Pin`][Pin] ຖືກໃຊ້ແທນເພື່ອປ້ອງກັນການຍ້າຍຜ່ານລະບົບປະເພດ.ຊີ້ `P<T>` ຫໍ່ໃນ wrapper [`Pin<P<T>>`][Pin] ບໍ່ສາມາດໄດ້ຮັບການຍ້າຍອອກຈາກ.
/// ເບິ່ງເອກະສານ [`pin` module] ສໍາລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບ pinning.
///
/// ການປະຕິບັດ `Unpin` trait ສໍາລັບ `T` lifts ຂໍ້ຈໍາກັດຂອງ pinning ອອກປະເພດ, ເຊິ່ງຫຼັງຈາກນັ້ນອະນຸຍາດໃຫ້ຍ້າຍ `T` ອອກຈາກ [`Pin<P<T>>`][Pin] ທີ່ມີຫນ້າທີ່ດັ່ງກ່າວເປັນ [`mem::replace`] ໄດ້.
///
///
/// `Unpin` ມັນບໍ່ມີຜົນສະທ້ອນຫຍັງເລີຍ ສຳ ລັບຂໍ້ມູນທີ່ບໍ່ແມ່ນ pinned.
/// ໂດຍສະເພາະ, [`mem::replace`] ຢ່າງມີຄວາມສຸກຍ້າຍຂໍ້ມູນ `!Unpin` (ມັນເຮັດວຽກສໍາລັບການ `&mut T` ໃດ, ບໍ່ພຽງແຕ່ໃນເວລາທີ່ `T: Unpin`).
/// ຢ່າງໃດກໍຕາມ, ທ່ານບໍ່ສາມາດນໍາໃຊ້ [`mem::replace`] ຂໍ້ມູນຫໍ່ພາຍໃນ [`Pin<P<T>>`][Pin] ເນື່ອງຈາກວ່າທ່ານບໍ່ສາມາດໄດ້ຮັບ `&mut T` ທີ່ທ່ານຕ້ອງການສໍາລັບການນັ້ນ, ແລະ *ທີ່* ແມ່ນສິ່ງທີ່ເຮັດໃຫ້ການເຮັດວຽກລະບົບນີ້.
///
/// ດັ່ງນັ້ນ, ນີ້, ສໍາລັບການຍົກຕົວຢ່າງ, ສາມາດເຮັດໄດ້ກ່ຽວກັບປະເພດການປະຕິບັດ `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // ພວກເຮົາຕ້ອງການເອກະສານອ້າງອີງທີ່ສາມາດປ່ຽນແປງໄດ້ເພື່ອເອີ້ນ `mem::replace`.
/// // ພວກເຮົາສາມາດໄດ້ຮັບການດັ່ງກ່າວອ້າງອິງໂດຍ (implicitly) invoking `Pin::deref_mut`, ແຕ່ວ່າເປັນໄປໄດ້ພຽງແຕ່ເນື່ອງຈາກວ່າປະຕິບັດແນວ `String` `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait ນີ້ຈະດໍາເນີນການສໍາລັບການເກືອບທຸກປະເພດອັດຕະໂນມັດ.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// ປະເພດເຄື່ອງ ໝາຍ ເຊິ່ງບໍ່ປະຕິບັດ `Unpin`.
///
/// ຖ້າຫາກວ່າຊະນິດປະກອບດ້ວຍເປັນ `PhantomPinned`, ມັນຈະບໍ່ໃຊ້ `Unpin` ຕັ້ງແຕ່ຕອນຕົ້ນ.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// ການປະຕິບັດຂອງ `Copy` ສໍາລັບປະເພດ primitive.
///
/// ການປະຕິບັດທີ່ບໍ່ສາມາດອະທິບາຍໄດ້ໃນ Rust ແມ່ນຖືກປະຕິບັດໃນ `traits::SelectionContext::copy_clone_conditions()` ໃນ `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// ເອກະສານອ້າງອີງທີ່ໃຊ້ຮ່ວມກັນສາມາດຄັດລອກໄດ້, ແຕ່ເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ *ບໍ່*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}