use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // ນີ້ບໍ່ແມ່ນພື້ນທີ່ ໜ້າ ດິນທີ່ ໝັ້ນ ຄົງ, ແຕ່ຊ່ວຍໃຫ້ `?` ລາຄາຖືກລະຫວ່າງພວກມັນ, ເຖິງແມ່ນວ່າ LLVM ກໍ່ບໍ່ສາມາດໃຊ້ປະໂຫຍດຈາກມັນໄດ້ໃນຕອນນີ້.
    //
    // (ຜົນໄດ້ຮັບທີ່ຫນ້າເສົ້າໃຈແລະຕົວເລືອກແມ່ນບໍ່ສອດຄ່ອງ, ດັ່ງນັ້ນ ControlFlow ບໍ່ສາມາດກົງກັບທັງສອງ.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}