use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri ແມ່ນຊ້າເກີນໄປ
fn exact_sanity_test() {
    // ການທົດສອບນີ້ສິ້ນສຸດການແລ່ນສິ່ງທີ່ຂ້ອຍພຽງແຕ່ສາມາດຖືໄດ້ວ່າແມ່ນບາງກໍລະນີທີ່ເປັນຕາ ໜ້າ ສົນໃຈຂອງ ໜ້າ ທີ່ຫ້ອງສະ ໝຸດ `exp2`, ຖືກ ກຳ ນົດໃນສິ່ງທີ່ C ເວລາແລ່ນພວກເຮົາ ກຳ ລັງໃຊ້.
    // ໃນ VS 2013 ໜ້າ ທີ່ນີ້ເບິ່ງຄືວ່າມີຂໍ້ບົກຜ່ອງເພາະວ່າການທົດສອບນີ້ລົ້ມເຫລວເມື່ອເຊື່ອມໂຍງ, ແຕ່ວ່າກັບ VS 2015, ຂໍ້ບົກຜ່ອງຈະຖືກແກ້ໄຂຍ້ອນວ່າການທົດສອບ ດຳ ເນີນໄປໄດ້ດີ.
    //
    // ຂໍ້ບົກພ່ອງເບິ່ງຄືວ່າມັນເປັນຄວາມແຕກຕ່າງໃນມູນຄ່າການກັບຄືນຂອງ `exp2(-1057)`, ເຊິ່ງໃນປີ VS 2013 ມັນຈະກັບຄືນມາສອງເທົ່າກັບຮູບແບບ 0x2 ນ້ອຍແລະໃນປີ 2015 ມັນກັບຄືນ 0x20000.
    //
    //
    // ສໍາລັບໃນປັດຈຸບັນພຽງແຕ່ບໍ່ສົນໃຈການທົດສອບນີ້ທັງຫມົດ MSVC ເປັນມັນທົດສອບຢູ່ບ່ອນອື່ນແລ້ວແລະພວກເຮົາກໍາລັງບໍ່ມີຄວາມສົນໃຈ super ໃນການທົດສອບແຕ່ລະເວທີຂອງການປະຕິບັດ exp2.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}