use backtrace::Backtrace;

// ການທົດສອບນີ້ໃຊ້ໄດ້ສະເພາະເວທີທີ່ມີ `symbol_address` ທີ່ເຮັດວຽກ ສຳ ລັບເຟຣມເຊິ່ງລາຍງານທີ່ຢູ່ເລີ່ມຕົ້ນຂອງສັນຍາລັກ.
// ເປັນຜົນມາຈາກມັນໄດ້ຖືກເປີດໃຊ້ໃນສອງສາມແພລະຕະຟອມເທົ່ານັ້ນ.
//
const ENABLED: bool = cfg!(all(
    // Windows ບໍ່ໄດ້ຖືກທົດສອບແທ້ໆ, ແລະ OSX ບໍ່ໄດ້ສະ ໜັບ ສະ ໜູນ ການຊອກຫາກອບທີ່ຖືກປິດລ້ອມ, ດັ່ງນັ້ນການປິດການໃຊ້ງານນີ້
    //
    target_os = "linux",
    // ກ່ຽວກັບ ARM ການຊອກຫາ ໜ້າ ທີ່ປິດລ້ອມແມ່ນພຽງແຕ່ກັບ ip ຕົວຂອງມັນເອງ.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}