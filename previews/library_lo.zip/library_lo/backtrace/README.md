# backtrace-rs

[Documentation](https://docs.rs/backtrace)

ຫ້ອງສະມຸດ ສຳ ລັບການຮັບເອົາ backtraces ໃນເວລາແລ່ນ ສຳ ລັບ Rust.
ນີ້ມີຈຸດປະສົງຫ້ອງສະຫມຸດເພື່ອເສີມຂະຫຍາຍສະຫນັບສະຫນູນຂອງຫ້ອງສະຫມຸດມາດຕະຖານທີ່ໂດຍການສະຫນອງການໂຕ້ຕອບໂຄງການທີ່ຈະເຮັດວຽກຮ່ວມກັບ, ແຕ່ວ່າມັນຍັງສະຫນັບສະຫນູນພຽງແຕ່ໄດ້ຢ່າງງ່າຍດາຍພິມໄດ້ backtrace ໃນປະຈຸບັນເຊັ່ນ: libstd ຂອງ panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

ເພື່ອພຽງແຕ່ຈັບພາບຫຼັງແລະແກ້ໄຂບັນຫາກັບມັນຈົນກ່ວາເວລາຕໍ່ມາ, ທ່ານສາມາດໃຊ້ປະເພດ `Backtrace` ທີ່ມີລະດັບສູງສຸດ.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

ເຖິງຢ່າງໃດກໍ່ຕາມ, ຖ້າທ່ານຕ້ອງການການເຂົ້າເຖິງວັດຖຸດິບທີ່ແທ້ຈິງ, ທ່ານສາມາດໃຊ້ `trace` ແລະ `resolve` ໂດຍກົງ.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // ແກ້ໄຂຈຸດຊີ້ ນຳ ນີ້ໃຫ້ເປັນເຄື່ອງ ໝາຍ
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // ສືບຕໍ່ໄປຫາກອບຕໍ່ໄປ
    });
}
```

# License

ໂຄງການນີ້ແມ່ນໄດ້ຮັບອະນຸຍາດພາຍໃຕ້ສອງຂອງໂຄງການ

 * ໃບອະນຸຍາດ Apache, ລຸ້ນ 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ຫຼື http://www.apache.org/licenses/LICENSE-2.0)
 * ໃບອະນຸຍາດ MIT ([LICENSE-MIT](LICENSE-MIT) ຫຼື http://opensource.org/licenses/MIT)

ທີ່ທ່ານເລືອກ.

### Contribution

ເວັ້ນເສຍແຕ່ວ່າທ່ານລະບຸຢ່າງຈະແຈ້ງຖ້າບໍ່ດັ່ງນັ້ນ, ການປະກອບສ່ວນໃດໆທີ່ສົ່ງໂດຍເຈດຕະນາ ສຳ ລັບການລວມເຂົ້າໃນ backtrace-rs ໂດຍທ່ານ, ທີ່ໄດ້ ກຳ ນົດໄວ້ໃນໃບອະນຸຍາດ Apache-2.0, ຈະຕ້ອງໄດ້ຮັບອະນຸຍາດສອງຢ່າງຄືຂ້າງເທິງ, ໂດຍບໍ່ມີເງື່ອນໄຂເພີ່ມເຕີມ.







