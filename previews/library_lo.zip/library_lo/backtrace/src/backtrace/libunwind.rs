//! ສະຫນັບສະຫນູນ Backtrace ໂດຍໃຊ້ libunwind/gcc_s/etc APIs.
//!
//! ໂມດູນນີ້ປະກອບມີຄວາມສາມາດໃນການລຸດຂັ້ນໄດໂດຍໃຊ້ APIs ແບບ libunwind.
//! ໃຫ້ສັງເກດວ່າມີການຈັດຕັ້ງປະຕິບັດທັງ ໝົດ ຂອງ API ທີ່ຄ້າຍຄື libunwind, ແລະນີ້ແມ່ນພຽງແຕ່ພະຍາຍາມທີ່ຈະເຂົ້າກັນໄດ້ກັບສ່ວນໃຫຍ່ຂອງພວກມັນທັງ ໝົດ ໃນເວລາດຽວແທນທີ່ຈະເປັນສິ່ງທີ່ລ້າໆ.
//!
//!
//! libunwind API ແມ່ນຂັບເຄື່ອນໂດຍ `_Unwind_Backtrace` ແລະໃນພາກປະຕິບັດຕົວຈິງແມ່ນມີຄວາມ ໜ້າ ເຊື່ອຖືຫຼາຍໃນການສ້າງສະຖານະພາບຫຼັງ.
//! ມັນບໍ່ຈະແຈ້ງວ່າມັນເຮັດໄດ້ແນວໃດ (ຕົວຊີ້ວັດຂໍ້ມູນ? ຂໍ້ມູນຂ່າວສານ? ທັງສອງ?) ແຕ່ມັນເບິ່ງຄືວ່າຈະເຮັດວຽກ!
//!
//! ຄວາມສັບສົນສ່ວນໃຫຍ່ຂອງໂມດູນນີ້ແມ່ນການຈັດການກັບຄວາມແຕກຕ່າງຂອງເວທີຕ່າງໆໃນທົ່ວການຈັດຕັ້ງປະຕິບັດ libunwind.
//! ຖ້າບໍ່ດັ່ງນັ້ນ, ນີ້ແມ່ນ Rust ທີ່ກົງໄປກົງມາທີ່ຖືກຕ້ອງກັບ API libunwind.
//!
//! ນີ້ແມ່ນ API ທີ່ບໍ່ສາມາດປົດປ່ອຍໄດ້ ສຳ ລັບແພລະຕະຟອມທີ່ບໍ່ແມ່ນ Windows ໃນປະຈຸບັນ.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// ມີຕົວຊີ້ libunwind ດິບມັນພຽງແຕ່ຄວນຈະເປັນການເຂົ້າເຖິງໃນຮູບແບບ threadsafe ແບບອ່ານເທົ່ານັ້ນ, ສະນັ້ນມັນເປັນ `Sync`.
// ເມື່ອສົ່ງຕໍ່ກະທູ້ອື່ນຜ່ານທາງ `Clone` ພວກເຮົາປ່ຽນເປັນແບບທີ່ບໍ່ເກັບເຄື່ອງພາຍໃນ, ດັ່ງນັ້ນພວກເຮົາຄວນຈະເປັນ `Send` ເຊັ່ນດຽວກັນ.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // ມັນເບິ່ງຄືວ່າໃນ OSX `_Unwind_FindEnclosingFunction` ສົ່ງຕົວຊີ້ໄປຫາ ... ບາງສິ່ງບາງຢ່າງທີ່ບໍ່ຈະແຈ້ງ.
        // ມັນແນ່ນອນວ່າມັນບໍ່ແມ່ນ ໜ້າ ທີ່ທີ່ເຕັມໄປດ້ວຍເຫດຜົນໃດກໍ່ຕາມ.
        // ມັນບໍ່ແມ່ນທັງຫມົດທີ່ຈະແຈ້ງໃຫ້ຂ້າພະເຈົ້າສິ່ງທີ່ເຮົາໄດ້ທີ່ນີ້, ສະນັ້ນ pessimize ນີ້ໃນປັດຈຸບັນແລະພຽງແຕ່ສະເຫມີກັບຄືນ ip ໄດ້.
        //
        // ໃຫ້ສັງເກດວ່າການທົດສອບ `skip_inner_frames.rs` ຖືກຂ້າມຜ່ານ OSX ເນື່ອງຈາກຂໍ້ປະໂຫຍກນີ້, ແລະຖ້າວ່າມັນຖືກແກ້ໄຂນັ້ນການທົດສອບທາງທິດສະດີສາມາດໃຊ້ໄດ້ໃນ OSX!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// ໃນການໂຕ້ຕອບສະຫມຸດ Unwind ໃຊ້ backtrace
///
/// ໃຫ້ສັງເກດວ່າລະຫັດທີ່ຕາຍແລ້ວແມ່ນຖືກອະນຸຍາດຍ້ອນວ່ານີ້ແມ່ນພຽງແຕ່ການຜູກມັດ iOS ບໍ່ໄດ້ໃຊ້ມັນທັງ ໝົດ ແຕ່ວ່າການເພີ່ມຂໍ້ມູນທີ່ແນ່ນອນໃນເວທີຫຼາຍກໍ່ຈະເຮັດໃຫ້ລະຫັດລະຫັດຫຼາຍເກີນໄປ
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // ໃຊ້ໂດຍ ARM EABI ເທົ່ານັ້ນ
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // ບໍ່ມີ _Unwind_Backtrace ໃນ iOS
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // ສາມາດໃຊ້ໄດ້ຕັ້ງແຕ່ GCC 4.2.0, ຄວນປັບ ໄໝ ເພື່ອຈຸດປະສົງຂອງພວກເຮົາ
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // ຟັງຊັນນີ້ແມ່ນຜິດພາດ: ແທນທີ່ຈະໄດ້ຮັບທີ່ຢູ່ຂອງ Canonical Frame Address (aka the caller frame's SP) ມັນຈະກັບຄືນ SP ຂອງກອບນີ້.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x ໃຊ້ຄ່າ CFA ທີ່ມີອະຄະຕິ, ດັ່ງນັ້ນພວກເຮົາ ຈຳ ເປັນຕ້ອງໃຊ້ _Unwind_GetGR ເພື່ອໃຫ້ໄດ້ລົງທະບຽນ pointer stack (%r15) ແທນທີ່ຈະອີງໃສ່ _Unwind_GetCFA.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // On android ແລະແຂນ, ການທໍາງານຂອງ `_Unwind_GetIP` ແລະຊໍ່ຂອງຄົນອື່ນແມ່ນມະຫາພາກ, ດັ່ງນັ້ນພວກເຮົາກໍານົດປະຕິບັດຫນ້າທີ່ມີການຂະຫຍາຍຕົວຂອງມະຫາພາກໄດ້.
    //
    //
    // TODO: ການເຊື່ອມຕໍ່ກັບເອກະສານ header ທີ່ໄດ້ກໍານົດມະຫາພາກເຫຼົ່ານີ້, ຖ້າຫາກວ່າທ່ານສາມາດຊອກຫາມັນ.
    // (ຂ້າພະເຈົ້າ, ບໍ່ສາມາດຊອກຫາເອກະສານຫົວຂໍ້ທີ່ບາງສ່ວນຂອງການຂະຫຍາຍຕົວມະຫາພາກເຫຼົ່ານີ້ແມ່ນໄດ້ຖືກຢືມມາຈາກເດີມ.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 ແມ່ນຕົວຊີ້ຊີ້ຢູ່ເທິງແຂນ.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // ຟັງຊັນນີ້ຍັງບໍ່ມີການກ່ຽວກັບ Android ຫຼື ARM/Linux, ສະນັ້ນເຮັດໃຫ້ມັນບໍ່ມີ op.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}