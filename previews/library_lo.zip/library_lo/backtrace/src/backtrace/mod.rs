use core::ffi::c_void;
use core::fmt;

/// ກວດສອບປະຈຸບັນເອີ້ນ stack, ຜ່ານເຟມມີການເຄື່ອນໄຫວທັງຫມົດເຂົ້າໄປໃນປິດສະຫນອງໃຫ້ແກ່ຄິດໄລ່ເປັນຮ່ອງຮອຍ stack.
///
/// ຟັງຊັນນີ້ແມ່ນວຽກຂອງຫ້ອງສະມຸດນີ້ໃນການຄິດໄລ່ຮ່ອງຮອຍ stack ສຳ ລັບໂປແກຼມ.`cb` ປິດທີ່ໄດ້ຮັບແມ່ນໃຫ້ຜົນຜະລິດຂອງ `Frame` ເຊິ່ງເປັນຕົວແທນຂອງຂໍ້ມູນກ່ຽວກັບກອບການໂທນັ້ນ.
/// ການປິດການຜະລິດແມ່ນເຮັດໃຫ້ເຟຣມຢູ່ໃນແບບເທິງລົງ (ສ່ວນຫຼາຍເອີ້ນວ່າ ໜ້າ ທີ່ກ່ອນ ໜ້າ ນີ້).
///
/// ມູນຄ່າການກັບມາຂອງການປິດແມ່ນການສະແດງໃຫ້ເຫັນວ່າແຜນວາດຂອງສະຖານທີ່ຄວນຈະສືບຕໍ່.ມູນຄ່າການກັບຄືນຂອງ `false` ຈະຢຸດຕິສະພາບຫລັງແລະກັບມາທັນທີ.
///
/// ເມື່ອໄດ້ຮັບ `Frame` ແລ້ວທ່ານຄົງຈະຕ້ອງການໂທຫາ `backtrace::resolve` ເພື່ອປ່ຽນ `ip` (ຕົວຊີ້ທິດທາງການສອນ) ຫຼືທີ່ຢູ່ສັນຍາລັກໃຫ້ເປັນ `Symbol` ໂດຍຜ່ານຊື່ແລະ/ຫຼືຊື່ filename/line ເບີສາມາດຮຽນຮູ້ໄດ້.
///
///
/// ໃຫ້ສັງເກດວ່ານີ້ແມ່ນ ໜ້າ ທີ່ທີ່ມີລະດັບຂ້ອນຂ້າງຕ່ ຳ ແລະຖ້າທ່ານຕ້ອງການ, ຍົກຕົວຢ່າງ, ເກັບຮູບພາບຫລັງເພື່ອກວດກາພາຍຫຼັງ, ຫຼັງຈາກນັ້ນ, ປະເພດ `Backtrace` ອາດຈະ ເໝາະ ສົມກວ່າ.
///
/// # ລັກສະນະທີ່ຕ້ອງການ
///
/// ຟັງຊັນນີ້ຮຽກຮ້ອງໃຫ້ຄຸນລັກສະນະ `std` ຂອງ `backtrace` crate ສາມາດໃຊ້ງານໄດ້, ແລະຄຸນລັກສະນະ `std` ຖືກເປີດໃຊ້ໂດຍຄ່າເລີ່ມຕົ້ນ.
///
/// # Panics
///
/// ຟັງຊັນນີ້ພະຍາຍາມບໍ່ເຄີຍ panic, ແຕ່ຖ້າ `cb` ສະ ໜອງ panics ແລ້ວບາງເວທີກໍ່ຈະບັງຄັບ panic ສອງຂັ້ນຕອນເພື່ອຍົກເລີກຂະບວນການ.
/// ບາງແພລະຕະຟອມໃຊ້ຫ້ອງສະ ໝຸດ C ເຊິ່ງໃຊ້ກັບການໂທຄືນພາຍໃນເຊິ່ງບໍ່ສາມາດຜ່ານຜ່າໄດ້, ສະນັ້ນການຊັ່ງຊາຈາກ `cb` ອາດຈະກໍ່ໃຫ້ເກີດການເລີກລົ້ມຂະບວນການ.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // ສືບຕໍ່ສະຖານະການ
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// ເຊັ່ນດຽວກັນກັບ `trace`, ພຽງແຕ່ບໍ່ປອດໄພຍ້ອນວ່າມັນເປັນ unsynchronized.
///
/// ຟັງຊັນນີ້ບໍ່ມີ guarentees ທີ່ຊິ້ງຂໍ້ມູນແຕ່ມີຢູ່ໃນເວລາທີ່ຄຸນລັກສະນະ `std` ຂອງ crate ນີ້ບໍ່ຖືກລວບລວມເຂົ້າ.
/// ເບິ່ງ ໜ້າ ທີ່ `trace` ສຳ ລັບເອກະສານແລະຕົວຢ່າງເພີ່ມເຕີມ.
///
/// # Panics
///
/// ເບິ່ງຂໍ້ມູນກ່ຽວກັບ `trace` ສຳ ລັບຖ້ ຳ ທີ່ `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// A trait ທີ່ເປັນຕົວແທນຫນຶ່ງກອບຂອງ backtrace ເປັນ, ຜົນຜະລິດໄປຍັງຟັງຊັນ `trace` ຂອງ crate ນີ້.
///
/// ການປິດການເຮັດວຽກຂອງການຕິດຕາມຈະໄດ້ຮັບຜົນຜະລິດ, ແລະກອບໄດ້ຖືກສົ່ງອອກຢ່າງແນ່ນອນເນື່ອງຈາກວ່າການປະຕິບັດທີ່ຕິດພັນບໍ່ໄດ້ເປັນທີ່ຮູ້ຈັກຕະຫຼອດເວລາ.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// ກັບຄືນຕົວຊີ້ທິດທາງຂອງກອບນີ້.
    ///
    /// ນີ້ແມ່ນປົກກະຕິຄໍາແນະນໍາຕໍ່ໄປເພື່ອປະຕິບັດໃນກອບການ, ແຕ່ບໍ່ແມ່ນການປະຕິບັດທັງຫມົດລາຍການນີ້ມີຄວາມຖືກຕ້ອງ 100% (ແຕ່ມັນເປັນໂດຍທົ່ວໄປ pretty ປິດ).
    ///
    ///
    /// ຂໍແນະ ນຳ ໃຫ້ສົ່ງຄ່າດັ່ງກ່າວໄປ `backtrace::resolve` ເພື່ອປ່ຽນເປັນຊື່ສັນຍາລັກ.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// ຜົນໄດ້ຮັບການຊີ້ stack ໃນປະຈຸບັນຂອງພານີ້.
    ///
    /// ໃນກໍລະນີທີ່ backend ບໍ່ສາມາດກູ້ຄືນ pointer stack ສຳ ລັບກອບນີ້, ຕົວ pointer null ໄດ້ຖືກສົ່ງຄືນ.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// ກັບຄືນທີ່ຢູ່ສັນຍາລັກເລີ່ມຕົ້ນຂອງກອບຂອງ ໜ້າ ທີ່ນີ້.
    ///
    /// ນີ້ຈະພະຍາຍາມເພື່ອ rewind ທີ່ຊີ້ສອນທີ່ສົ່ງຄືນໂດຍ `ip` ການເລີ່ມຕົ້ນຂອງການທໍາງານຂອງໄດ້, ກັບຄືນມູນຄ່າທີ່.
    ///
    /// ໃນບາງກໍລະນີ, ຢ່າງໃດກໍຕາມ, backends ພຽງແຕ່ຈະກັບຄືນ `ip` ຈາກຫນ້າທີ່ນີ້.
    ///
    /// ບາງຄັ້ງມູນຄ່າທີ່ສົ່ງຄືນກໍ່ສາມາດ ນຳ ໃຊ້ໄດ້ຖ້າ `backtrace::resolve` ລົ້ມເຫລວໃນ `ip` ທີ່ກ່າວມາຂ້າງເທິງ.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// ກັບຄືນທີ່ຢູ່ພື້ນຖານຂອງໂມດູນທີ່ກອບເປັນຂອງ.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // ສິ່ງນີ້ ຈຳ ເປັນຕ້ອງມາກ່ອນ, ເພື່ອຮັບປະກັນວ່າ Miri ຖືຄວາມ ສຳ ຄັນກວ່າເວທີການເປັນເຈົ້າພາບ
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // ໃຊ້ໃນ dbghelp ເປັນສັນຍາລັກເທົ່ານັ້ນ
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}