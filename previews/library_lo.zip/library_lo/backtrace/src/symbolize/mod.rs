use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// ແກ້ໄຂບັນຫາທີ່ຢູ່ກັບສັນຍາລັກ, ສັນຍາລັກຜ່ານໃນການປິດທີ່ລະບຸ.
///
/// ຟັງຊັນນີ້ຈະເບິ່ງໄປທີ່ຢູ່ໃຫ້ຢູ່ໃນພື້ນທີ່ດັ່ງກ່າວເປັນຕາຕະລາງທ້ອງຖິ່ນສັນຍາລັກ, ສັນຍາລັກຕາຕະລາງເຄື່ອນໄຫວ, ຂໍ້ມູນຫຼືການແກ້ບັນຫາ Dwarfs (ຂຶ້ນຢູ່ກັບການປະຕິບັດວຽກໄດ້) ເພື່ອຊອກຫາສັນຍາລັກໃຫ້ຜົນຜະລິດ.
///
///
/// ການປິດອາດຈະບໍ່ຖືກຮຽກຮ້ອງຖ້າການແກ້ໄຂບັນຫາບໍ່ສາມາດປະຕິບັດໄດ້, ແລະມັນກໍ່ອາດຈະຖືກຮຽກຮ້ອງຫຼາຍກວ່າ ໜຶ່ງ ຄັ້ງໃນກໍລະນີທີ່ມີ ໜ້າ ທີ່ຢູ່.
///
/// ສັນຍາລັກທີ່ສະແດງໃຫ້ເຫັນເຖິງການປະຕິບັດຢູ່ທີ່ `addr` ທີ່ລະບຸ, ກັບຄືນ file/line ຄູ່ ສຳ ລັບທີ່ຢູ່ນັ້ນ (ຖ້າມີ).
///
/// ໃຫ້ສັງເກດວ່າຖ້າທ່ານມີ `Frame` ແລ້ວມັນແນະນໍາໃຫ້ໃຊ້ຫນ້າທີ່ `resolve_frame` ແທນທີ່ຈະເປັນສິ່ງນີ້.
///
/// # ລັກສະນະທີ່ຕ້ອງການ
///
/// ຟັງຊັນນີ້ຮຽກຮ້ອງໃຫ້ຄຸນລັກສະນະ `std` ຂອງ `backtrace` crate ສາມາດໃຊ້ງານໄດ້, ແລະຄຸນລັກສະນະ `std` ຖືກເປີດໃຊ້ໂດຍຄ່າເລີ່ມຕົ້ນ.
///
/// # Panics
///
/// ຟັງຊັນນີ້ພະຍາຍາມບໍ່ເຄີຍ panic, ແຕ່ຖ້າ `cb` ສະ ໜອງ panics ແລ້ວບາງເວທີກໍ່ຈະບັງຄັບ panic ສອງຂັ້ນຕອນເພື່ອຍົກເລີກຂະບວນການ.
/// ບາງແພລະຕະຟອມໃຊ້ຫ້ອງສະ ໝຸດ C ເຊິ່ງໃຊ້ກັບການໂທຄືນພາຍໃນເຊິ່ງບໍ່ສາມາດຜ່ານຜ່າໄດ້, ສະນັ້ນການຊັ່ງຊາຈາກ `cb` ອາດຈະກໍ່ໃຫ້ເກີດການເລີກລົ້ມຂະບວນການ.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // ພຽງແຕ່ຊອກຫາຢູ່ໃນກອບດ້ານເທີງຂອງ
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// ແກ້ໄຂກອບການຈັບພາບກ່ອນ ໜ້າ ນີ້ໃຫ້ເປັນສັນຍາລັກ, ຖ່າຍທອດສັນຍາລັກໄປສູ່ການປິດທີ່ລະບຸໄວ້.
///
/// Functin ນີ້ເຮັດ ໜ້າ ທີ່ຄືກັບ `resolve` ຍົກເວັ້ນວ່າມັນຈະເອົາ `Frame` ເປັນການໂຕ້ຖຽງແທນທີ່ຢູ່.
/// ນີ້ສາມາດອະນຸຍາດໃຫ້ມີການຈັດຕັ້ງປະຕິບັດການ ນຳ ໃຊ້ເວທີຂອງ backtracing ເພື່ອໃຫ້ຂໍ້ມູນສັນຍາລັກທີ່ຖືກຕ້ອງຫຼືຂໍ້ມູນກ່ຽວກັບກອບພາຍໃນຕົວຢ່າງ.
///
/// ມັນແນະນໍາໃຫ້ໃຊ້ສິ່ງນີ້ຖ້າທ່ານສາມາດເຮັດໄດ້.
///
/// # ລັກສະນະທີ່ຕ້ອງການ
///
/// ຟັງຊັນນີ້ຮຽກຮ້ອງໃຫ້ຄຸນລັກສະນະ `std` ຂອງ `backtrace` crate ສາມາດໃຊ້ງານໄດ້, ແລະຄຸນລັກສະນະ `std` ຖືກເປີດໃຊ້ໂດຍຄ່າເລີ່ມຕົ້ນ.
///
/// # Panics
///
/// ຟັງຊັນນີ້ພະຍາຍາມບໍ່ເຄີຍ panic, ແຕ່ຖ້າ `cb` ສະ ໜອງ panics ແລ້ວບາງເວທີກໍ່ຈະບັງຄັບ panic ສອງຂັ້ນຕອນເພື່ອຍົກເລີກຂະບວນການ.
/// ບາງແພລະຕະຟອມໃຊ້ຫ້ອງສະ ໝຸດ C ເຊິ່ງໃຊ້ກັບການໂທຄືນພາຍໃນເຊິ່ງບໍ່ສາມາດຜ່ານຜ່າໄດ້, ສະນັ້ນການຊັ່ງຊາຈາກ `cb` ອາດຈະກໍ່ໃຫ້ເກີດການເລີກລົ້ມຂະບວນການ.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // ພຽງແຕ່ຊອກຫາຢູ່ໃນກອບດ້ານເທີງຂອງ
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// ຄ່າ IP ຈາກກອບ stack ແມ່ນປົກກະຕິ (always?) ຄຳ ແນະ ນຳ *ຫຼັງຈາກການໂທ* ນັ້ນແມ່ນຮອຍຕາມ ລຳ ດັບຂອງຈິງ.
// ເປັນສັນຍະລັກນີ້ກ່ຽວກັບສາເຫດທີ່ຈໍານວນ filename/line ຈະເປັນຫນຶ່ງກ່ອນກ່ອນເວລາແລະບາງທີອາດເປັນ void ຖ້າຫາກວ່າມັນເປັນຢູ່ໃກ້ໃນຕອນທ້າຍຂອງການທໍາງານໄດ້.
//
// ປະກົດວ່າໂດຍພື້ນຖານແລ້ວສະເຫມີນີ້ເປັນກໍລະນີໃນເວທີການທັງຫມົດ, ດັ່ງນັ້ນພວກເຮົາສະເຫມີໄປຫັກລົບຫນຶ່ງຈາກ ip ແກ້ໄຂເພື່ອແກ້ໄຂບັນຫາໃຫ້ຄໍາແນະນໍາແລະການໂທຜ່ານມາແທນທີ່ຈະເປັນຄໍາແນະນໍາທີ່ຖືກສົ່ງກັບຄືນໄປ.
//
//
// ໂດຍຫລັກການແລ້ວພວກເຮົາຈະບໍ່ເຮັດແນວນີ້.
// ໂດຍຫລັກການແລ້ວພວກເຮົາຕ້ອງການໃຫ້ຜູ້ໂທຂອງ `resolve` APIs ຢູ່ທີ່ນີ້ເພື່ອເຮັດ -1 ດ້ວຍຕົນເອງແລະບັນຊີວ່າພວກເຂົາຕ້ອງການຂໍ້ມູນສະຖານທີ່ ສຳ ລັບ ຄຳ ແນະ ນຳ *ກ່ອນ*, ບໍ່ແມ່ນໃນປະຈຸບັນ.
// ໂດຍຫລັກການແລ້ວພວກເຮົາຍັງຈະເປີດເຜີຍໃນ `Frame` ຖ້າພວກເຮົາແມ່ນທີ່ຢູ່ຂອງ ຄຳ ແນະ ນຳ ຕໍ່ໄປຫລືປະຈຸບັນ.
//
// ສໍາລັບໃນປັດຈຸບັນເຖິງແມ່ນວ່ານີ້ແມ່ນບັນຫາ niche pretty ດັ່ງນັ້ນພວກເຮົາພຽງແຕ່ພາຍໃນສະເຫມີຫັກລົບຫນຶ່ງ.
// ຜູ້ບໍລິໂພກຄວນສືບຕໍ່ເຮັດວຽກແລະໄດ້ຮັບ ໝາກ ຜົນທີ່ດີ, ສະນັ້ນພວກເຮົາຄວນຈະດີພໍ.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// ດຽວກັນກັບ `resolve`, ພຽງແຕ່ບໍ່ປອດໄພຍ້ອນວ່າມັນບໍ່ໄດ້ຖືກເຊື່ອມຕໍ່.
///
/// ຟັງຊັນນີ້ບໍ່ມີ guarentees ທີ່ຊິ້ງຂໍ້ມູນແຕ່ມີຢູ່ໃນເວລາທີ່ຄຸນລັກສະນະ `std` ຂອງ crate ນີ້ບໍ່ຖືກລວບລວມເຂົ້າ.
/// ເບິ່ງ ໜ້າ ທີ່ `resolve` ສຳ ລັບເອກະສານແລະຕົວຢ່າງເພີ່ມເຕີມ.
///
/// # Panics
///
/// ເບິ່ງຂໍ້ມູນກ່ຽວກັບ `resolve` ສຳ ລັບຖ້ ຳ ທີ່ `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// ເຊັ່ນດຽວກັນກັບ `resolve_frame`, ພຽງແຕ່ບໍ່ປອດໄພຍ້ອນວ່າມັນເປັນ unsynchronized.
///
/// ຟັງຊັນນີ້ບໍ່ມີ guarentees ທີ່ຊິ້ງຂໍ້ມູນແຕ່ມີຢູ່ໃນເວລາທີ່ຄຸນລັກສະນະ `std` ຂອງ crate ນີ້ບໍ່ຖືກລວບລວມເຂົ້າ.
/// ເບິ່ງ ໜ້າ ທີ່ `resolve_frame` ສຳ ລັບເອກະສານແລະຕົວຢ່າງເພີ່ມເຕີມ.
///
/// # Panics
///
/// ເບິ່ງຂໍ້ມູນກ່ຽວກັບ `resolve_frame` ສຳ ລັບຖ້ ຳ ທີ່ `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// A trait ສະແດງຄວາມລະອຽດຂອງສັນຍາລັກໃນເອກະສານ.
///
/// trait ນີ້ຜົນຜະລິດເປັນວັດຖຸ trait ເພື່ອປິດໃຫ້ແກ່ການເຄື່ອນໄຫວ `backtrace::resolve`, ແລະມັນໄດ້ຖືກສົ່ງ virtually ເປັນຂອງທີ່ບໍ່ຮູ້ຈັກຊຶ່ງການປະຕິບັດເປັນທາງຫລັງຂອງມັນ.
///
///
/// ເປັນສັນຍາລັກສາມາດໃຫ້ຂໍ້ມູນສະພາບເງື່ອນໄຂກ່ຽວກັບຫນ້າທີ່ເປັນ, ສໍາລັບການຍົກຕົວຢ່າງຊື່ໄດ້, filenames, ຈໍານວນເສັ້ນ, ຢູ່ທີ່ຊັດເຈນ, ແລະອື່ນໆ
/// ບໍ່ຂໍ້ມູນທັງຫມົດແມ່ນສະເຫມີມີຢູ່ໃນສັນຍາລັກ, ຢ່າງໃດກໍຕາມ, ສະນັ້ນວິທີການທັງຫມົດກັບຄືນເປັນ `Option`.
///
///
pub struct Symbol {
    // TODO: ຄວາມຜູກພັນຕະຫຼອດຊີວິດນີ້ຕ້ອງມີຄວາມທົນນານໃນທີ່ສຸດເຖິງ `Symbol`,
    // ແຕ່ວ່າ, ປະຈຸບັນການປ່ຽນແປງ breaking.
    // ສຳ ລັບດຽວນີ້ມັນປອດໄພຕັ້ງແຕ່ `Symbol` ພຽງແຕ່ຖືກສົ່ງເອກະສານອ້າງອີງມາແລ້ວແລະບໍ່ສາມາດເຮັດເປັນຫີນໄດ້.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// ກັບຄືນຊື່ຂອງຟັງຊັນນີ້.
    ///
    /// ໂຄງສ້າງທີ່ສົ່ງຄືນສາມາດຖືກ ນຳ ໃຊ້ເພື່ອສອບຖາມຄຸນສົມບັດຕ່າງໆກ່ຽວກັບຊື່ສັນຍາລັກ:
    ///
    ///
    /// * ການປະຕິບັດ `Display` ຈະພິມອອກສັນຍາລັກ demangled.
    /// * ມູນຄ່າ `str` ດິບຂອງສັນຍາລັກສາມາດເຂົ້າເຖິງໄດ້ (ຖ້າມັນຖືກຕ້ອງ utf-8).
    /// * ວັດຖຸດິບ ສຳ ລັບຊື່ສັນຍາລັກສາມາດເຂົ້າເບິ່ງໄດ້.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// ກັບຄືນທີ່ຢູ່ເລີ່ມຕົ້ນຂອງ ໜ້າ ທີ່ນີ້.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// ຜົນໄດ້ຮັບຊື່ໄຟເປັນວັດຖຸດິບເປັນຫຼັງຈາກນັ້ນນໍາ.
    /// ນີ້ແມ່ນປະໂຫຍດສ່ວນໃຫຍ່ ສຳ ລັບສະພາບແວດລ້ອມ `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// ກັບຄືນເລກ ລຳ ດັບ ສຳ ລັບບ່ອນທີ່ສັນຍາລັກນີ້ ກຳ ລັງ ດຳ ເນີນຢູ່.
    ///
    /// ມີພຽງແຕ່ປະຈຸບັນ gimli ເທົ່ານັ້ນທີ່ໃຫ້ຄຸນຄ່າຢູ່ທີ່ນີ້ແລະແມ້ແຕ່ຫຼັງຈາກນັ້ນຖ້າ `filename` ກັບຄືນ `Some`, ແລະດັ່ງນັ້ນມັນຈຶ່ງເປັນເຫດຜົນທີ່ຈະເຮັດໃຫ້ຄ້າຍຄືກັນ.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// ກັບຄືນເບີໂທ ສຳ ລັບບ່ອນທີ່ສັນຍາລັກນີ້ ກຳ ລັງ ດຳ ເນີນຢູ່.
    ///
    /// ມູນຄ່າການກັບຄືນນີ້ແມ່ນປົກກະຕິ `Some` ຖ້າ `filename` ກັບຄືນ `Some`, ແລະເປັນເຫດຜົນທີ່ຈະເຮັດໃຫ້ຄ້າຍຄືກັນ.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// ຜົນໄດ້ຮັບຊື່ໄຟທີ່ຟັງຊັນນີ້ໄດ້ຖືກກໍານົດ.
    ///
    /// ປະຈຸບັນນີ້ສາມາດໃຊ້ໄດ້ພຽງແຕ່ໃນເວລາທີ່ libbacktrace ຫຼື Gimli ຖືກນໍາໃຊ້ (ຕົວຢ່າງ:
    /// unix ເວທີການອື່ນໆ) ແລະໃນເວລາທີ່ຄູ່ຈະຖືກລວບລວມກັບ DebugInfo.
    /// ຖ້າຫາກວ່າທັງເງື່ອນໄຂດັ່ງກ່າວໄດ້ພົບຫຼັງຈາກນັ້ນນີ້ຈະມີໂອກາດກັບຄືນ `None`.
    ///
    /// # ລັກສະນະທີ່ຕ້ອງການ
    ///
    /// ຟັງຊັນນີ້ຮຽກຮ້ອງໃຫ້ຄຸນລັກສະນະ `std` ຂອງ `backtrace` crate ສາມາດໃຊ້ງານໄດ້, ແລະຄຸນລັກສະນະ `std` ຖືກເປີດໃຊ້ໂດຍຄ່າເລີ່ມຕົ້ນ.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // ບາງທີວະຈີວິພາກ C++ ສັນຍາລັກ, ຖ້າຫາກວ່າການແຍກວິເຄາະສັນຍາລັກ mangled ເປັນ Rust ສົບຜົນສໍາເລັດ.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // ເຮັດໃຫ້ແນ່ໃຈວ່າຈະຮັກສານີ້ເປັນສູນຂະຫນາດ, ດັ່ງນັ້ນຄຸນນະສົມບັດ `cpp_demangle` ບໍ່ມີຄ່າໃຊ້ຈ່າຍພິໃນເວລາທີ່.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// ເຄື່ອງຫໍ່ອ້ອມຮອບຊື່ສັນຍາລັກເພື່ອໃຫ້ຜູ້ເຂົ້າໃຊ້ ergonomic ເຂົ້າຫາຊື່ທີ່ຖືກຫລອກ, ໄບ, ວັດຖຸດິບ, ແລະອື່ນໆ.
///
// ອະນຸຍາດໃຫ້ລະຫັດເສຍຊີວິດສໍາລັບໃນເວລາທີ່ຄຸນນະສົມບັດ `cpp_demangle` ບໍ່ໄດ້ເປີດໃຫ້ໃຊ້ງານ.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// ສ້າງຊື່ສັນຍາລັກ ໃໝ່ ຈາກພື້ນຖານວັດຖຸດິບ.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// ຜົນໄດ້ຮັບຊື່ສັນຍາລັກ (mangled) ຖຸດິບເປັນ `str` ຖ້າສັນຍາລັກແມ່ນຖືກຕ້ອງ utf-8.
    ///
    /// ໃຊ້ການຈັດຕັ້ງປະຕິບັດ `Display` ຖ້າທ່ານຕ້ອງການລຸ້ນທີ່ຖືກຍົກເລີກ.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// ຜົນໄດ້ຮັບຊື່ສັນຍາລັກເປັນວັດຖຸດິບເປັນບັນຊີລາຍຊື່ຂອງໄບຕ໌ໄດ້
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // ສິ່ງນີ້ອາດຈະພິມຖ້າສັນຍາລັກທີ່ຖືກຍົກເລີກບໍ່ຖືກຕ້ອງ, ສະນັ້ນຈັດການຂໍ້ຜິດພາດຢູ່ທີ່ນີ້ໂດຍການບໍ່ເຜີຍແຜ່ມັນອອກໄປຂ້າງນອກ.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// ພະຍາຍາມເພື່ອປັບປຸງຄວາມຊົງຈໍາຈາກຖານຄວາມຈໍາທີ່ຖືກນໍາໃຊ້ເພື່ອຢູ່ສັນຍາລັກ.
///
/// ວິທີການນີ້ຈະພະຍາຍາມທີ່ຈະປ່ອຍໂຄງສ້າງຂໍ້ມູນທົ່ວໂລກທີ່ໄດ້ຖືກເກັບໄວ້ໂດຍທົ່ວໄປຫລືໃນກະທູ້ເຊິ່ງປົກກະຕິຈະເປັນຕົວແທນຂອງຂໍ້ມູນ DWARF ທີ່ຖືກແຍກອອກມາຫລືຄ້າຍຄືກັນ.
///
///
/// # Caveats
///
/// ໃນຂະນະທີ່ການທໍາງານນີ້ແມ່ນສະເຫມີໄປສາມາດໃຊ້ໄດ້ມັນບໍ່ເປັນເຮັດຫຍັງກ່ຽວກັບການປະຕິບັດຫຼາຍທີ່ສຸດ.
/// ຫ້ອງສະຫມຸດຄື dbghelp ຫຼື libbacktrace ບໍ່ໃຫ້ສະຖານທີ່ລັດ deallocation ແລະຈັດການຫນ່ວຍຄວາມຈໍາທີ່ຈັດສັນ.
/// ສຳ ລັບດຽວນີ້ຄຸນລັກສະນະ `gimli-symbolize` ຂອງ crate ນີ້ແມ່ນຄຸນສົມບັດດຽວທີ່ເຮັດວຽກນີ້ມີຜົນສະທ້ອນ.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}