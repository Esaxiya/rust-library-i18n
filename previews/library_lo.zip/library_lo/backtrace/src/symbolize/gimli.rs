//! ຮອງຮັບເຄື່ອງ ໝາຍ ໂດຍໃຊ້ `gimli` crate ເທິງ crates.io
//!
//! ນີ້ແມ່ນການປະຕິບັດສັນຍາລັກໃນຕອນຕົ້ນ ສຳ ລັບ Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'ຕະຫຼອດຊີວິດທີ່ສະຖຽນລະພາບແມ່ນການຂີ້ຕົວະເພື່ອ hack ປະມານການຂາດການສະຫນັບສະຫນູນໂຄງສ້າງທີ່ອ້າງອີງຕົນເອງ.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // ປ່ຽນເປັນ 'ໄລຍະເວລາທີ່ຄົງທີ່ນັບຕັ້ງແຕ່ສັນຍາລັກຄວນຢືມ `map` ແລະ `stash` ເທົ່ານັ້ນແລະພວກເຮົາ ກຳ ລັງຮັກສາພວກມັນໄວ້ຢູ່ຂ້າງລຸ່ມນີ້.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // ສໍາລັບຊື່ສາຫ້ອງສະຫມຸດພື້ນເມືອງກ່ຽວກັບການ Windows, ເບິ່ງການສົນທະນາບາງຢ່າງກ່ຽວກັບ rust-lang/rust#71060 ສໍາລັບຍຸດທະສາດຕ່າງໆໄດ້ທີ່ນີ້.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // ຫໍສະ ໝຸດ MinGW ປະຈຸບັນບໍ່ສະ ໜັບ ສະ ໜູນ ASLR (rust-lang/rust#16514), ແຕ່ວ່າຫໍສະ ໝຸດ ດິຈິຕອລຍັງສາມາດຍົກຍ້າຍປະມານໃນທີ່ຢູ່ທີ່ຢູ່.
            // ມັນປະກົດວ່າທີ່ຢູ່ໃນຂໍ້ມູນ debug ທັງ ໝົດ ແມ່ນຖ້າຫໍສະ ໝຸດ ນີ້ຖືກໂຫລດຢູ່ທີ່ "image base" ຂອງມັນ, ມັນແມ່ນບ່ອນຢູ່ໃນຫົວຂໍ້ໄຟລ໌ COFF ຂອງມັນ.
            // ເນື່ອງຈາກວ່ານີ້ແມ່ນສິ່ງທີ່ debuginfo ເບິ່ງຄືວ່າຈະບອກພວກເຮົາແຍກຕາຕະລາງສັນຍາລັກແລະທີ່ຢູ່ຂອງຮ້ານຄືກັບວ່າຫ້ອງສະ ໝຸດ ຖືກໂຫລດຢູ່ "image base" ເຊັ່ນກັນ.
            //
            // ຫໍສະຫມຸດບໍ່ສາມາດໄດ້ຮັບການ loaded ໃນ "image base", ຢ່າງໃດກໍຕາມ.
            // (ສົມມຸດວ່າບາງສິ່ງບາງຢ່າງອາດຈະຖືກໂຫລດຢູ່ທີ່ນັ້ນ?) ນີ້ແມ່ນບ່ອນທີ່ສະ ໜາມ `bias` ເຂົ້າມາຫຼີ້ນ, ແລະພວກເຮົາຕ້ອງຄິດໄລ່ມູນຄ່າຂອງ `bias` ຢູ່ທີ່ນີ້.ແຕ່ຫນ້າເສຍດາຍເຖິງແມ່ນວ່າມັນບໍ່ຈະແຈ້ງກ່ຽວກັບວິທີທີ່ຈະໄດ້ມາຈາກໂມດູນທີ່ໂຫລດ.
            // ສິ່ງທີ່ພວກເຮົາມີ, ຢ່າງໃດກໍ່ຕາມ, ແມ່ນທີ່ຢູ່ການໂຫຼດຕົວຈິງ (`modBaseAddr`).
            //
            // ໃນຖານະເປັນການລວບລວມຂໍ້ມູນເລັກໆນ້ອຍໆ ສຳ ລັບດຽວນີ້ພວກເຮົາ mmap ໄຟລ໌, ອ່ານຂໍ້ມູນສ່ວນຫົວ, ຫຼັງຈາກນັ້ນລົງ mmap.ນີ້ແມ່ນສິ່ງເສດເຫຼືອເນື່ອງຈາກວ່າພວກເຮົາອາດຈະເປີດ mmap ຕໍ່ມາ, ແຕ່ນີ້ຄວນຈະເຮັດວຽກໄດ້ດີພຽງພໍສໍາລັບໃນປັດຈຸບັນ.
            //
            // ເມື່ອພວກເຮົາມີ `image_base` (ສະຖານທີ່ການໂຫຼດທີ່ຕ້ອງການ) ແລະ `base_addr` (ສະຖານທີ່ການໂຫຼດຕົວຈິງ) ທີ່ພວກເຮົາສາມາດຕື່ມຂໍ້ມູນໃສ່ໃນ `bias` (ຄວາມແຕກຕ່າງລະຫວ່າງຕົວຈິງແລະຄວາມຕ້ອງການ) ແລະຫຼັງຈາກນັ້ນຢູ່ທີ່ໄດ້ກ່າວໄວ້ຂອງແຕ່ລະກຸ່ມແມ່ນ `image_base` ນັບຕັ້ງແຕ່ທີ່ວ່າເອກະສານເວົ້າວ່າ.
            //
            //
            // ສຳ ລັບດຽວນີ້ມັນປາກົດວ່າບໍ່ຄືກັບ ELF/MachO ພວກເຮົາສາມາດເຮັດໄດ້ກັບຕອນ ໜຶ່ງ ຕໍ່ຫໍສະ ໝຸດ, ໂດຍໃຊ້ `modBaseSize` ຂະ ໜາດ ທັງ ໝົດ.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS ໃຊ້ຮູບແບບເອກະສານ Mach-O ແລະໃຊ້ API ທີ່ສະເພາະຂອງ DYLD ເພື່ອໂຫລດບັນຊີລາຍຊື່ຫໍສະ ໝຸດ ທີ່ເປັນສ່ວນ ໜຶ່ງ ຂອງແອັບພລິເຄຊັນ.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // ມາດດຶງຂໍ້ມູນຊື່ຂອງຫໍສະຫມຸດນີ້ເຊິ່ງເທົ່າກັບເສັ້ນທາງຂອງບ່ອນທີ່ຈະໂຫຼດມັນເຊັ່ນດຽວກັນໄດ້.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // ໂຫລດ header ພາບຂອງຫໍສະຫມຸດນີ້ແລະຄະນະຜູ້ແທນທີ່ຈະ `object` ການ parse ທັງຫມົດຄໍາສັ່ງການໂຫຼດໄດ້ດັ່ງນັ້ນພວກເຮົາສາມາດສະສ່ວນທັງຫມົດໄດ້ມີສ່ວນຮ່ວມໃນທີ່ນີ້.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // ແບ່ງສ່ວນເຂົ້າໃນສ່ວນຕ່າງໆແລະລົງທະບຽນເຂດທີ່ຮູ້ຈັກ ສຳ ລັບສ່ວນທີ່ພວກເຮົາພົບ.
            // ນອກຈາກນັ້ນ, ບັນທຶກຂໍ້ມູນກ່ຽວກັບພາກສ່ວນຂໍ້ຄວາມ ສຳ ລັບການປຸງແຕ່ງຕໍ່ມາ, ເບິ່ງ ຄຳ ເຫັນຂ້າງລຸ່ມນີ້.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // ກຳ ນົດ "slide" ສຳ ລັບຫໍສະມຸດນີ້ເຊິ່ງຈົບລົງແມ່ນຄວາມ ລຳ ອຽງທີ່ພວກເຮົາໃຊ້ເພື່ອຄິດອອກວ່າບ່ອນໃດທີ່ຢູ່ໃນວັດຖຸ ໜ່ວຍ ຄວາມ ຈຳ ຖືກໂຫລດ.
            // ນີ້ແມ່ນການ ຄຳ ນວນທີ່ແປກປະຫຼາດເຖິງແມ່ນວ່າແລະເປັນຜົນມາຈາກການພະຍາຍາມຫລາຍຢ່າງໃນ ທຳ ມະຊາດແລະເບິ່ງວ່າມັນຕິດຫຍັງ.
            //
            // ຄວາມຄິດທົ່ວໄປແມ່ນວ່າ `bias` ບວກກັບ `stated_virtual_memory_address` ຂອງຕອນ ໜຶ່ງ ຈະເປັນບ່ອນທີ່ຢູ່ໃນພື້ນທີ່ຢູ່ຈິງຂອງສ່ວນທີ່ຢູ່.
            // ສິ່ງອື່ນທີ່ພວກເຮົາອີງໃສ່ແມ່ນວ່າທີ່ຢູ່ທີ່ແທ້ຈິງລົບ `bias` ແມ່ນດັດສະນີທີ່ຈະຊອກຫາຢູ່ໃນຕາຕະລາງສັນຍາລັກແລະ debuginfo.
            //
            // ເຖິງຢ່າງໃດກໍ່ຕາມ, ມັນບອກວ່າ ສຳ ລັບຫ້ອງສະ ໝຸດ ທີ່ມີລະບົບບັນຈຸການຄິດໄລ່ເຫຼົ່ານີ້ແມ່ນບໍ່ຖືກຕ້ອງ.ສໍາລັບການບໍລິຫານພື້ນເມືອງ, ຢ່າງໃດກໍຕາມ, ມັນປະກົດໃຫ້ຖືກຕ້ອງ.
            // ຍົກບາງເຫດຜົນຈາກແຫຼ່ງຂອງ LLDB ມັນມີບາງກໍລະນີພິເສດ ສຳ ລັບສ່ວນ `__TEXT` ທຳ ອິດທີ່ຖືກໂຫລດຈາກການຊົດເຊີຍແຟ້ມ 0 ດ້ວຍຂະ ໜາດ ຂອງເຄື່ອງ nonzero.
            // ບໍ່ວ່າເຫດຜົນໃດກໍ່ຕາມເມື່ອມີຢູ່ນີ້ມັນປະກົດວ່າ ໝາຍ ຄວາມວ່າຕາຕະລາງສັນຍາລັກແມ່ນກ່ຽວຂ້ອງກັບພຽງແຕ່ slide vmaddr ສຳ ລັບຫໍສະມຸດ.
            // ຖ້າມັນບໍ່ມີຢູ່ໃນປະຈຸບັນຕາຕະລາງສັນຍາລັກແມ່ນກ່ຽວຂ້ອງກັບແຜ່ນສະໄລ້ vmaddr ບວກກັບທີ່ຢູ່ທີ່ລະບຸໄວ້ຂອງຕອນ.
            //
            // ເພື່ອຈັດການກັບສະຖານະການດັ່ງກ່າວຖ້າພວກເຮົາ * ບໍ່ພົບພາກສ່ວນຂໍ້ຄວາມທີ່ເອກະສານຊົດເຊີຍສູນ, ຫຼັງຈາກນັ້ນພວກເຮົາກໍ່ຈະເພີ່ມຄວາມ ລຳ ອຽງໂດຍທີ່ຢູ່ຂໍ້ຄວາມ ທຳ ອິດຂອງຂໍ້ຄວາມແລະລະບຸທີ່ຢູ່ທີ່ລະບຸໄວ້ທັງ ໝົດ ໂດຍ ຈຳ ນວນນັ້ນ.
            //
            // ວິທີນັ້ນຕາຕະລາງສັນຍາລັກຈະປາກົດຂື້ນສະ ເໝີ ກັບ ຈຳ ນວນອະຄະຕິຂອງຫໍສະ ໝຸດ.
            // ນີ້ປະກົດວ່າມີຜົນໄດ້ຮັບທີ່ຖືກຕ້ອງ ສຳ ລັບການເປັນສັນຍາລັກຜ່ານຕາຕະລາງສັນຍາລັກ.
            //
            // ດ້ວຍຄວາມຊື່ສັດຂ້ອຍບໍ່ແນ່ໃຈວ່າມັນຖືກຫຼືບໍມີສິ່ງອື່ນອີກທີ່ຄວນສະແດງໃຫ້ເຫັນວ່າຈະເຮັດແນວໃດ.
            // ສໍາລັບໃນປັດຈຸບັນເຖິງແມ່ນວ່ານີ້ເບິ່ງຄືວ່າຈະເຮັດວຽກໄດ້ດີພຽງພໍ (?) ແລະພວກເຮົາສະເຫມີໄປຄວນຈະສາມາດປັບແຕ່ງທີ່ໃຊ້ເວລາໃນໄລຍະນີ້ຖ້າຫາກວ່າມີຄວາມຈໍາເປັນ.
            //
            // ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມເບິ່ງ #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Unix ອື່ນໆ (ຕົວຢ່າງ
        // Linux) ເວທີໃຊ້ ELF ເປັນຮູບແບບເອກະສານວັດຖຸແລະໂດຍປົກກະຕິໃຊ້ເປັນ API ເອີ້ນວ່າ `dl_iterate_phdr` ໂຫລດຫ້ອງສະຫມຸດພື້ນເມືອງ.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` ຄວນຈະເປັນຕົວຊີ້ບອກທີ່ຖືກຕ້ອງ.
        // `vec` ຄວນເປັນຕົວຊີ້ທີ່ຖືກຕ້ອງເຖິງ `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ບໍ່ບໍ່ native ສະຫນັບສະຫນູນຂໍ້ມູນ debug, ແຕ່ການກໍ່ສ້າງລະບົບຈະເຮັດການຂໍ້ມູນເພີ່ມ debug ຢູ່ເສັ້ນທາງ `romfs:/debug_info.elf` ໄດ້.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // ທຸກສິ່ງທຸກຢ່າງອື່ນຄວນໃຊ້ ELF, ແຕ່ບໍ່ຮູ້ວິທີການໂຫຼດຫໍສະມຸດພື້ນເມືອງ.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// ຫ້ອງສະຫມຸດທີ່ໃຊ້ຮ່ວມກັນທັງ ໝົດ ທີ່ຮູ້ຈັກທີ່ຖືກໂຫລດແລ້ວ.
    libraries: Vec<Library>,

    /// ແມ cache ບ່ອນທີ່ພວກເຮົາຍັງຄົງສາວິເຄາະຂໍ້ມູນຂ່າວສານ dwarf.
    ///
    /// ບັນຊີລາຍຊື່ນີ້ມີຄວາມສາມາດຄົງທີ່ ສຳ ລັບເຄື່ອງຍົກທັງ ໝົດ ຂອງມັນທີ່ບໍ່ເຄີຍເພີ່ມຂື້ນ.
    /// ອົງປະກອບ `usize` ຂອງແຕ່ລະຄູ່ແມ່ນດັດສະນີເຂົ້າໃນ `libraries` ຂ້າງເທິງບ່ອນທີ່ `usize::max_value()` ເປັນຕົວແທນໃຫ້ສາມາດປະຕິບັດໄດ້ໃນປະຈຸບັນ.
    ///
    /// The `Mapping` ແມ່ນກ່ຽວຂ້ອງຂໍ້ມູນ dwarf ວະຈີວິພາກ.
    ///
    /// ໃຫ້ສັງເກດວ່ານີ້ໂດຍພື້ນຖານແລ້ວແມ່ນຖານຄວາມຈໍາ LRU ແລະພວກເຮົາຈະປ່ຽນສິ່ງຕ່າງໆຢູ່ບ່ອນນີ້ໃນຂະນະທີ່ພວກເຮົາເປັນສັນຍາລັກທີ່ຢູ່.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// ບາງສ່ວນຂອງຫໍສະມຸດນີ້ທີ່ຖືກໂຫລດໄປໃນ ໜ່ວຍ ຄວາມ ຈຳ ແລະບ່ອນທີ່ພວກມັນຈະໂຫລດ.
    segments: Vec<LibrarySegment>,
    /// "bias" ຂອງຫໍສະມຸດແຫ່ງນີ້, ໂດຍປົກກະຕິແມ່ນບ່ອນທີ່ມັນຖືກເກັບໄວ້ໃນ ໜ່ວຍ ຄວາມ ຈຳ.
    /// ມູນຄ່ານີ້ແມ່ນເພີ່ມໄປຫາທີ່ຢູ່ລະບຸໄວ້ໃນແຕ່ລະກຸ່ມຂອງເພື່ອໃຫ້ໄດ້ຮັບທີ່ຢູ່ຫນ່ວຍຄວາມຈໍາ virtual ທີ່ແທ້ຈິງວ່າສ່ວນແມ່ນ loaded ເຂົ້າໄປໃນ.
    /// ນອກຈາກນັ້ນຄວາມ ລຳ ອຽງນີ້ຖືກຫັກອອກຈາກທີ່ຢູ່ຂອງ ໜ່ວຍ ຄວາມ ຈຳ ເສມືນທີ່ແທ້ຈິງເພື່ອດັດສະນີເປັນ debuginfo ແລະຕາຕະລາງສັນຍາລັກ.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// ທີ່ຢູ່ທີ່ລະບຸໄວ້ຂອງສ່ວນນີ້ໃນເອກະສານວັດຖຸ.
    /// ນີ້ບໍ່ແມ່ນບ່ອນທີ່ບ່ອນທີ່ ກຳ ລັງໂຫລດ, ແຕ່ແທນທີ່ຢູ່ນີ້ບວກກັບ `bias` ຂອງຫໍສະມຸດບ່ອນທີ່ຈະຊອກຫາມັນ.
    ///
    stated_virtual_memory_address: usize,
    /// ຂະຫນາດຂອງກຸ່ມ ths ໃນຫນ່ວຍຄວາມຈໍາ.
    len: usize,
}

// ບໍ່ປອດໄພເພາະວ່າມັນ ຈຳ ເປັນຕ້ອງມີການຊິ້ງຂໍ້ມູນພາຍນອກ
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // ບໍ່ປອດໄພເພາະວ່າມັນ ຈຳ ເປັນຕ້ອງມີການຊິ້ງຂໍ້ມູນພາຍນອກ
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // LRU ຂະ ໜາດ ນ້ອຍແລະງ່າຍດາຍທີ່ສຸດ ສຳ ລັບການຫາຂໍ້ມູນການແກ້ໄຂຂໍ້ມູນ.
        //
        // ອັດຕາ hit ຄວນຈະສູງທີ່ສຸດ, ນັບຕັ້ງແຕ່ການ stack ປົກກະຕິບໍ່ໄດ້ຂ້າມລະຫວ່າງຫ້ອງສະຫມຸດໄດ້ແບ່ງປັນຈໍານວນຫຼາຍ.
        //
        // ໂຄງສ້າງ `addr2line::Context` ແມ່ນ pretty ລາຄາແພງເພື່ອສ້າງ.
        // ຄ່າໃຊ້ຈ່າຍຂອງຕົນຄາດວ່າຈະໄດ້ຮັບການຕັດໂດຍການສອບຖາມ `locate` ຕໍ່ໆມາ, ເຊິ່ງອໍານາດຕໍ່ລອງໂຄງສ້າງທີ່ສ້າງຂຶ້ນໃນເວລາທີ່ການກໍ່ສ້າງ `addr2line: : Context`s ເພື່ອໃຫ້ໄດ້ຮັບກົດຫມາຍກໍາຫນົດງາມ.
        //
        // ຖ້າຫາກວ່າພວກເຮົາບໍ່ໄດ້ມີຄວາມຈໍາດັ່ງກ່າວນີ້, ໃຊ້ຫນີ້ທີ່ຈະບໍ່ເຄີຍມີຫຍັງເກີດຂຶ້ນ, ແລະ backtrace symbolicating ຈະ ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // ເຖິງຫນ້າທໍາອິດ, ການທົດສອບຖ້າຫາກວ່າ `lib` ນີ້ມີກຸ່ມໃດທີ່ມີການ (ການຍົກຍ້າຍຈັດ) `addr`.ຖ້າການກວດການີ້ຜ່ານໄປ, ພວກເຮົາສາມາດສືບຕໍ່ຢູ່ທາງລຸ່ມແລະແປທີ່ຢູ່.
                //
                // ໃຫ້ສັງເກດວ່າພວກເຮົາ ກຳ ລັງໃຊ້ `wrapping_add` ຢູ່ທີ່ນີ້ເພື່ອຫລີກລ້ຽງການກວດສອບເກີນ ກຳ ນົດ.ມັນໄດ້ຖືກເຫັນໃນປ່າທໍາມະຊາດທີ່ການປຽບທຽບການຄິດໄລ່ດ້ານອະນາຄົດຂອງ SVMA + ລົ້ນ.
                // ມັນເບິ່ງຄືວ່າເປັນເລື່ອງແປກທີ່ຈະເກີດຂື້ນແຕ່ວ່າມັນບໍ່ມີ ຈຳ ນວນຫລວງຫລາຍທີ່ພວກເຮົາສາມາດເຮັດກ່ຽວກັບມັນໄດ້ນອກ ເໜືອ ຈາກພຽງແຕ່ບໍ່ສົນໃຈສ່ວນເຫລົ່ານັ້ນເພາະວ່າພວກເຂົາອາດຈະ ກຳ ລັງຊີ້ໄປສູ່ອະວະກາດ.
                //
                // ນີ້ໃນເບື້ອງຕົ້ນເກີດຂຶ້ນມາໃນ rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // ໃນປັດຈຸບັນທີ່ພວກເຮົາຮູ້ວ່າ `lib` ມີ `addr`, ພວກເຮົາສາມາດຊົດເຊີຍດ້ວຍການລໍາອຽງໃນການຊອກຫາທີ່ຢູ່ຄວາມຊົງຈໍາໄວລັດໄດ້ລະບຸໄວ້.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: ຫຼັງຈາກເງື່ອນໄຂນີ້ ສຳ ເລັດໂດຍບໍ່ມີການກັບມາໄວ
        // ຈາກຂໍ້ຜິດພາດ, ການເຂົ້າຖານຄວາມ ຈຳ ສຳ ລັບເສັ້ນທາງນີ້ແມ່ນຢູ່ໃນດັດຊະນີ 0.

        if let Some(idx) = idx {
            // ໃນເວລາທີ່ການສ້າງແຜນທີ່ທີ່ມີຢູ່ແລ້ວໃນຖານຄວາມຈໍາໄດ້, ຍ້າຍໄປທາງຫນ້າໄດ້.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // ເມື່ອການສ້າງແຜນທີ່ບໍ່ຢູ່ໃນບ່ອນເກັບມ້ຽນ, ສ້າງແຜນທີ່ ໃໝ່, ໃສ່ມັນໄວ້ທາງ ໜ້າ ຂອງບ່ອນເກັບມ້ຽນ, ແລະຂັບໄລ່ຂໍ້ມູນເກົ່າເຂົ້າເກົ່າຖ້າ ຈຳ ເປັນ.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ຢ່າຮົ່ວໄຫລຕະຫຼອດຊີວິດ `'static`, ໃຫ້ແນ່ໃຈວ່າມັນຖືກປັບຕົວໃຫ້ກັບຕົວເຮົາເອງ
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // ການຂະຫຍາຍຕະຫຼອດຊີວິດຂອງ `sym` ເພື່ອ `'static` ນັບຕັ້ງແຕ່ພວກເຮົາກໍາລັງຕ້ອງການແຕ່ຫນ້າເສຍດາຍທີ່ນີ້, ແຕ່ວ່າມັນ ONY ເຄີຍໄປອອກເພື່ອເປັນບ່ອນອີງນັ້ນບໍ່ມີການອ້າງອີງເຖິງມັນຄວນຈະຍັງຄົງຢູ່ນອກເຫນືອພານີ້ແລ້ວ.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // ສຸດທ້າຍ, ຂໍໃຫ້ມີແຜນທີ່ທີ່ຕັ້ງໄວ້ຫຼືສ້າງແຜນທີ່ ໃໝ່ ສຳ ລັບເອກະສານນີ້, ແລະປະເມີນຂໍ້ມູນ DWARF ເພື່ອຊອກຫາ file/line/name ສຳ ລັບທີ່ຢູ່ນີ້.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// ພວກເຮົາສາມາດຊອກຫາສະຖານຂໍ້ມູນກອບສໍາລັບສັນຍາລັກດັ່ງກ່າວນີ້, ແລະ `ກອບ addr2line` ຂອງພາຍໃນມີທັງຫມົດລາຍລະອຽດ nitty gritty ໄດ້.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// ບໍ່ສາມາດຊອກຫາຂໍ້ມູນຂ່າວສານ debug, ແຕ່ພວກເຮົາພົບເຫັນມັນຢູ່ໃນຕາຕະລາງສັນຍາລັກຂອງການບໍລິຫານ elf ໄດ້.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}