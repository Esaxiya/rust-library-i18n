//! ຍຸດທະສາດການໃຊ້ສັນຍາລັກໂດຍໃຊ້ລະຫັດ DWARF-parsing ໃນ libbacktrace.
//!
//! ຫ້ອງສະຫມຸດ libbacktrace C, ໂດຍປົກກະຕິແຈກຢາຍກັບ gcc, ບໍ່ພຽງແຕ່ສະ ໜັບ ສະ ໜູນ ການຜະລິດແຜນວາດ (ເຊິ່ງພວກເຮົາບໍ່ໄດ້ໃຊ້ຕົວຈິງ) ແຕ່ຍັງເປັນສັນຍາລັກຂອງ backtrace ແລະຈັດການກັບຂໍ້ມູນ debug dwarf ກ່ຽວກັບສິ່ງຕ່າງໆເຊັ່ນ: ເຟຣມເສັ້ນແລະບໍ່ແມ່ນຫຍັງ.
//!
//!
//! ນີ້ແມ່ນຂ້ອນຂ້າງສັບສົນຍ້ອນມີຄວາມກັງວົນຫຼາຍຢ່າງຢູ່ທີ່ນີ້, ແຕ່ແນວຄິດພື້ນຖານແມ່ນ:
//!
//! * ຫນ້າທໍາອິດທີ່ພວກເຮົາໂທຫາ `backtrace_syminfo`.ນີ້ໄດ້ຮັບຂໍ້ມູນຂ່າວສານສັນຍາລັກຈາກຕາຕະລາງສັນຍາລັກແບບໄດນາມິກຖ້າພວກເຮົາສາມາດເຮັດໄດ້.
//! * ຕໍ່ໄປພວກເຮົາໂທຫາ `backtrace_pcinfo`.ນີ້ຈະແຍກ DebugInfo ຕາຕະລາງຖ້າຫາກວ່າພວກເຂົາເຈົ້າກໍາລັງທີ່ມີຢູ່ແລະອະນຸຍາດໃຫ້ພວກເຮົາຈະຟື້ນຂໍ້ມູນຂ່າວສານກ່ຽວກັບການສະແດງເຟມ, filenames, ຈໍານວນເສັ້ນ, ແລະອື່ນໆ
//!
//! ມີຈໍານວນຫລາຍໃຊ້ກົນອຸບາຍກ່ຽວກັບການຕາຕະລາງ dwarf ເປັນ libbacktrace ເປັນ, ແຕ່ຫວັງເປັນຢ່າງຍິ່ງມັນບໍ່ແມ່ນທີ່ສຸດຂອງໂລກແລະເປັນທີ່ຈະແຈ້ງພຽງພໍໃນເວລາທີ່ການອ່ານຂ້າງລຸ່ມນີ້.
//!
//! ນີ້ແມ່ນຍຸດທະສາດສັນຍາລັກໄວ້ໃນຕອນຕົ້ນສໍາລັບການທີ່ບໍ່ແມ່ນ MSVC ແລະເວທີທີ່ບໍ່ແມ່ນ OSX.ໃນ libstd ເຖິງແມ່ນວ່ານີ້ແມ່ນຍຸດທະສາດ ສຳ ລັບ OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // ຖ້າເປັນໄປໄດ້ຕ້ອງການຊື່ `function` ທີ່ມາຈາກ debuginfo ແລະໂດຍປົກກະຕິສາມາດຖືກຕ້ອງກວ່າ ສຳ ລັບຕົວຢ່າງໃນອິນເຕີເນັດ.
                // ຖ້າຫາກວ່າບໍ່ປະຈຸບັນເຖິງແມ່ນວ່າຫຼຸດລົງກັບຄືນໄປບ່ອນຊື່ຕາຕະລາງສັນຍາລັກທີ່ລະບຸໄວ້ໃນ `symname`.
                //
                // ໃຫ້ສັງເກດວ່າບາງຄັ້ງ `function` ສາມາດຮູ້ສຶກບໍ່ຖືກຕ້ອງບາງຢ່າງ, ຕົວຢ່າງເຊັ່ນຖືກລະບຸວ່າບໍ່ແມ່ນ `try<i32,closure>` ຂອງ `std::panicking::try::do_call`.
                //
                // ມັນບໍ່ແນ່ນອນວ່າເປັນຫຍັງແທ້, ແຕ່ໂດຍລວມຊື່ `function` ເບິ່ງຄືວ່າມີຄວາມຖືກຕ້ອງຫຼາຍ.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ບໍ່ເຮັດຫຍັງເລີຍດຽວນີ້
}

/// ປະເພດຂອງຕົວຊີ້ `data` ຜ່ານເຂົ້າ `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // ເມື່ອການໂທຄືນນີ້ຖືກເອີ້ນຈາກ `backtrace_syminfo` ເມື່ອພວກເຮົາເລີ່ມຕົ້ນແກ້ໄຂພວກເຮົາຈະຕ້ອງໄດ້ໂທຫາ `backtrace_pcinfo` ຕື່ມອີກ.
    // ຟັງຊັນ `backtrace_pcinfo` ຈະປຶກສາຂໍ້ມູນແກ້ໄຂແລະອະໄວຍະວະເພດເພື່ອເຮັດສິ່ງຕ່າງໆເຊັ່ນການກູ້ຂໍ້ມູນ file/line ພ້ອມທັງຂອບໃນຂອບ.
    // ໃຫ້ສັງເກດວ່າ `backtrace_pcinfo` ສາມາດລົ້ມເຫລວຫລືບໍ່ໄດ້ເຮັດຫຍັງຫລາຍຖ້າບໍ່ມີຂໍ້ມູນຜິດພາດ, ດັ່ງນັ້ນຖ້າສິ່ງນັ້ນເກີດຂື້ນພວກເຮົາແນ່ໃຈວ່າຈະໂທຫາການໂທກັບຄືນຢ່າງ ໜ້ອຍ ມີສັນຍາລັກ ໜຶ່ງ ຈາກ `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// ປະເພດຂອງຕົວຊີ້ `data` ຜ່ານເຂົ້າ `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// libbacktrace API ສະ ໜັບ ສະ ໜູນ ການສ້າງລັດ, ແຕ່ມັນບໍ່ສະ ໜັບ ສະ ໜູນ ການ ທຳ ລາຍລັດ.
// ຂ້າພະເຈົ້າເອງເອົາເລື່ອງນີ້ ໝາຍ ຄວາມວ່າລັດໃດ ໜຶ່ງ ມີຄວາມ ໝາຍ ທີ່ຈະຖືກສ້າງຂື້ນແລະມີຊີວິດຢູ່ຕະຫຼອດໄປ.
//
// ຂ້ອຍຢາກລົງທະບຽນຜູ້ຈັດການ at_exit() ທີ່ເຮັດຄວາມສະອາດຂອງລັດນີ້, ແຕ່ libbacktrace ບໍ່ມີທາງທີ່ຈະເຮັດແນວນັ້ນ.
//
// ດ້ວຍຂໍ້ ຈຳ ກັດເຫຼົ່ານີ້, ໜ້າ ທີ່ນີ້ມີສະຖານະທີ່ມີການ ກຳ ນົດໄວ້ຢ່າງເປັນທາງການເຊິ່ງຄິດໄລ່ເປັນຄັ້ງ ທຳ ອິດທີ່ຕ້ອງການ.
//
// ຈື່ໄວ້ວ່າ backtracing ທັງຫມົດຈະເກີດຂື້ນຢ່າງເປັນລະບົບ (ໜຶ່ງ ກະແຈທົ່ວໂລກ).
//
// ໃຫ້ສັງເກດວ່າການຂາດການຊິ້ງຂໍ້ມູນຢູ່ນີ້ແມ່ນຍ້ອນຄວາມຕ້ອງການທີ່ `resolve` ຖືກປະສົມປະສານພາຍນອກ.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // ຢ່າປະຕິບັດຄວາມສາມາດຂອງ threadsafe ຂອງ libbacktrace ນັບຕັ້ງແຕ່ພວກເຮົາມັກຈະໂທຫາມັນຢູ່ໃນຮູບແບບທີ່ຖືກຕ້ອງ.
        //
        0,
        error_cb,
        ptr::null_mut(), // ບໍ່ມີຂໍ້ມູນພິເສດ
    );

    return STATE;

    // ໃຫ້ສັງເກດວ່າ ສຳ ລັບ libbacktrace ເພື່ອເຮັດວຽກຢູ່ທັງ ໝົດ ມັນ ຈຳ ເປັນຕ້ອງຊອກຫາຂໍ້ມູນ debug DWARF ສຳ ລັບການໃຊ້ງານໃນປະຈຸບັນ.ມັນປົກກະຕິບໍ່ວ່າຜ່ານຫລາຍກົນໄກລວມທັງ, ແຕ່ບໍ່ ຈຳ ກັດ:
    //
    // * /proc/self/exe ໃນເວທີທີ່ຮອງຮັບ
    // * ຊື່ filename ໄດ້ຜ່ານເຂົ້າໄປຢ່າງຊັດເຈນເມື່ອສ້າງສະຖານະ
    //
    // ຫ້ອງສະຫມຸດ libbacktrace ແມ່ນ wad ໃຫຍ່ຂອງລະຫັດ C.ນີ້ໂດຍ ທຳ ມະຊາດ ໝາຍ ຄວາມວ່າມັນມີຄວາມສ່ຽງດ້ານຄວາມປອດໄພຂອງຄວາມ ຈຳ, ໂດຍສະເພາະເມື່ອຈັດການກັບ debuginfo ທີ່ບໍ່ຖືກຕ້ອງ.
    // ປະຫວັດສາດ Libstd ໄດ້ແລ່ນເຂົ້າໄປໃນຫລາຍໆປະວັດສາດ.
    //
    // ຖ້າ /proc/self/exe ຖືກໃຊ້ແລ້ວພວກເຮົາສາມາດບໍ່ສົນໃຈສິ່ງເຫຼົ່ານີ້ດັ່ງທີ່ພວກເຮົາສົມມຸດວ່າ libbacktrace ແມ່ນ "mostly correct" ແລະຖ້າບໍ່ດັ່ງນັ້ນບໍ່ໄດ້ເຮັດຫຍັງແປກໆກັບຂໍ້ມູນ debug dwarf "attempted to be correct".
    //
    //
    // ຖ້າຫາກວ່າພວກເຮົາບັງເກີດຂຶ້ນໃນ filename ເປັນ, ຢ່າງໃດກໍຕາມ, ຫຼັງຈາກນັ້ນມັນເປັນທີ່ເປັນໄປໄດ້ກ່ຽວກັບບາງເວທີ (ຄື BSDs) ບ່ອນທີ່ເປັນນັກສະແດງເປັນອັນຕະລາຍສາມາດເຮັດໃຫ້ໄຟລ໌ທີ່ຕົນເອງມັກໄດ້ຖືກບັນຈຸຢູ່ໃນສະຖານທີ່.
    // ນີ້ຫມາຍຄວາມວ່າຖ້າຫາກພວກເຮົາບອກ libbacktrace ກ່ຽວກັບຊື່ໄຟມັນອາດຈະນໍາໃຊ້ໄຟລ໌ທີ່ຕົນເອງມັກ, ເປັນໄປໄດ້ເຊິ່ງກໍ່ໃຫ້ເກີດ segfaults.
    // ຖ້າພວກເຮົາບໍ່ບອກ libbacktrace ເຖິງແມ່ນວ່າມັນຈະບໍ່ເຮັດຫຍັງໃນເວທີທີ່ບໍ່ສະ ໜັບ ສະ ໜູນ ເສັ້ນທາງເຊັ່ນ /proc/self/exe!
    //
    // ເນື່ອງຈາກທຸກສິ່ງທີ່ພວກເຮົາພະຍາຍາມເທົ່າທີ່ຈະເຮັດໄດ້ເພື່ອບໍ່ໃຫ້ຜ່ານຊື່, ແຕ່ພວກເຮົາຕ້ອງລົງເທິງເວທີທີ່ບໍ່ຮອງຮັບ /proc/self/exe ເລີຍ.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // ໃຫ້ສັງເກດວ່າໂດຍສະເພາະພວກເຮົານໍາໃຊ້ `std::env::current_exe`, ແຕ່ພວກເຮົາບໍ່ສາມາດຮຽກຮ້ອງໃຫ້ມີ `std` ນີ້.
            //
            // ໃຊ້ `_NSGetExecutablePath` ເພື່ອໂຫຼດເສັ້ນທາງທີ່ສາມາດປະຕິບັດໄດ້ໃນປະຈຸບັນເຂົ້າໄປໃນພື້ນທີ່ສະຖິດ (ເຊິ່ງຖ້າມັນນ້ອຍເກີນໄປພຽງແຕ່ຍອມແພ້).
            //
            //
            // ໃຫ້ສັງເກດວ່າພວກເຮົາ ກຳ ລັງໄວ້ວາງໃຈ libbacktrace ຢູ່ທີ່ນີ້ຢ່າງຈິງຈັງເພື່ອບໍ່ໃຫ້ເສຍຊີວິດໃນການບໍລິຫານທີ່ສໍ້ລາດບັງຫຼວງ, ແຕ່ມັນແນ່ນອນ ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ມີຮູບແບບຂອງການເປີດແຟ້ມບ່ອນທີ່ຫຼັງຈາກທີ່ມັນຖືກເປີດມັນບໍ່ສາມາດຖືກລຶບອອກ.
            // ນັ້ນແມ່ນໂດຍທົ່ວໄປສິ່ງທີ່ພວກເຮົາຕ້ອງການຢູ່ທີ່ນີ້ເພາະວ່າພວກເຮົາຕ້ອງການຮັບປະກັນວ່າການບໍລິຫານງານຂອງພວກເຮົາບໍ່ໄດ້ປ່ຽນແປງຈາກພາຍໃຕ້ພວກເຮົາຫລັງຈາກທີ່ພວກເຮົາສົ່ງໄປ libbacktrace, ຫວັງວ່າຈະຫຼຸດຜ່ອນຄວາມສາມາດໃນການສົ່ງຂໍ້ມູນທີ່ບໍ່ເປັນລະບຽບເຂົ້າໃນ libbacktrace (ເຊິ່ງອາດຈະເຮັດໃຫ້ຫຼົງຜິດ).
            //
            //
            // ເນື່ອງຈາກວ່າພວກເຮົາເຮັດນ້ອຍຂອງເຕັ້ນທີ່ນີ້ເພື່ອພະຍາຍາມເພື່ອໃຫ້ໄດ້ຮັບການຈັດລຽງຂອງ Lock ກ່ຽວກັບຮູບພາບຂອງພວກເຮົາເອງ:
            //
            // * ໄດ້ຮັບການຈັດການກັບຂະບວນການໃນປະຈຸບັນ, ໂຫລດຊື່ filename ຂອງມັນ.
            // * ເປີດແຟ້ມເອກະສານນັ້ນກັບທຸງຂວາ.
            // * ໂຫລດຊື່ແຟ້ມຂອງຂະບວນການໃນປະຈຸບັນ, ໃຫ້ແນ່ໃຈວ່າມັນຄືກັນ
            //
            // ຖ້າວ່າທັງຫມົດຜ່ານພວກເຮົາໃນທິດສະດີໄດ້ເປີດແທ້ຈິງເອກະສານຂະບວນການຂອງພວກເຮົາແລະພວກເຮົາກໍາລັງຮັບປະກັນວ່າມັນຈະບໍ່ມີການປ່ຽນແປງ.FWIW ຊໍ່ຂອງສິ່ງນີ້ແມ່ນຖືກຄັດລອກມາຈາກ libstd ທາງປະຫວັດສາດ, ສະນັ້ນນີ້ແມ່ນການຕີຄວາມ ໝາຍ ທີ່ດີທີ່ສຸດຂອງຂ້ອຍກ່ຽວກັບສິ່ງທີ່ ກຳ ລັງເກີດຂື້ນ.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // ນີ້ອາໃສຢູ່ໃນຄວາມຊົງຈໍາທີ່ຄົງທີ່ດັ່ງນັ້ນພວກເຮົາສາມາດສົ່ງມັນຄືນໄດ້ ..
                static mut BUF: [i8; N] = [0; N];
                // ... ແລະຊີວິດນີ້ໃນ stack ໄດ້ນັບຕັ້ງແຕ່ມັນເປັນຊົ່ວຄາວ
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ໂດຍເຈດຕະນາຮົ່ວ `handle` ຢູ່ທີ່ນີ້ເພາະວ່າການເປີດນັ້ນຄວນຮັກສາລັອກຂອງພວກເຮົາໃສ່ຊື່ແຟ້ມເອກະສານນີ້.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // ພວກເຮົາຕ້ອງການທີ່ຈະກັບຄືນຫຼັງຈາກສິ້ນສຸດທີ່ບໍ່ໄດ້ສິ້ນສຸດລົງ, ສະນັ້ນຖ້າທຸກສິ່ງທຸກຢ່າງໄດ້ເຕີມລົງໄປແລະມັນເທົ່າກັບຄວາມຍາວທັງ ໝົດ ແລ້ວກໍ່ເທົ່າກັບຄວາມລົ້ມເຫຼວ.
                //
                //
                // ຖ້າບໍ່ດັ່ງນັ້ນເມື່ອກັບມາປະສົບຜົນ ສຳ ເລັດໃຫ້ແນ່ໃຈວ່າ nte byte ຖືກລວມເຂົ້າໃນສ່ວນທີ່ເປັນກ້ອນ.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // ຄວາມຜິດພາດ backtrace ຖືກກວາດຂະນະນີ້ພາຍໃຕ້ rug ໄດ້
    let state = init_state();
    if state.is_null() {
        return;
    }

    // ໂທຫາ `backtrace_syminfo` API ເຊິ່ງ (ຈາກການອ່ານລະຫັດ) ຄວນໂທຫາ `syminfo_cb` ຢ່າງແນ່ນອນ (ຫຼືລົ້ມເຫລວດ້ວຍຂໍ້ຜິດພາດທີ່ສົມມຸດຕິຖານ).
    // ພວກເຮົາຈັດການກັບ `syminfo_cb` ຫຼາຍຂື້ນ.
    //
    // ໃຫ້ສັງເກດວ່າພວກເຮົາເຮັດສິ່ງນີ້ນັບຕັ້ງແຕ່ `syminfo` ຈະປຶກສາຕາຕະລາງສັນຍາລັກ, ຊອກຫາຊື່ສັນຍາລັກເຖິງແມ່ນວ່າບໍ່ມີຂໍ້ມູນທີ່ຖືກລົບກວນໃນຖານສອງ.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}