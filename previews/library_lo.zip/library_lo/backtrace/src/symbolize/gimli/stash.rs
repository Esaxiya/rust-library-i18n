// ນໍາໃຊ້ພຽງແຕ່ໃນ Linux ສິດທິໃນປັດຈຸບັນ, ສະນັ້ນອະນຸຍາດໃຫ້ລະຫັດເສຍຊີວິດຢູ່ບ່ອນອື່ນ
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// ການຈັດສັນລະດັບງ່າຍໆ ສຳ ລັບ buffers byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// ຈັດແບ່ງ buffer ຂອງຂະ ໜາດ ທີ່ລະບຸໄວ້ແລະສົ່ງຄືນການອ້າງອີງທີ່ປ່ຽນແປງໄດ້.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SAFETY: ນີ້ແມ່ນການທໍາງານຂອງທີ່ເຄີຍສ້າງບໍ່ແນ່ນອນເປັນ
        // ການອ້າງອີງເຖິງ `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SAFETY: ພວກເຮົາບໍ່ເຄີຍເອົາອົງປະກອບຈາກ `self.buffers`, ສະນັ້ນກະສານອ້າງອີງ
        // ກັບຂໍ້ມູນພາຍໃນ buffer ໃດກໍ່ຈະມີຊີວິດຢູ່ເທົ່າກັບ `self`.
        &mut buffers[i]
    }
}