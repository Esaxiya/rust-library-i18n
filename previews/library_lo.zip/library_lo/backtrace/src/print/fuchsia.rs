use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr ໃຊ້ເວລາໂທກັບທີ່ຈະໄດ້ຮັບຊີ້ dl_phdr_info ສໍາລັບທຸກ DSO ທີ່ໄດ້ຮັບການເຊື່ອມຕໍ່ເຂົ້າໄປໃນຂະບວນການດັ່ງກ່າວ.
    // dl_iterate_phdr ຍັງຮັບປະກັນວ່າ linker ແບບໄດນາມິກໄດ້ຖືກລັອກຈາກການເລີ່ມຕົ້ນໃຫ້ສໍາເລັດຮູບຂອງ iteration ໄດ້.
    // ຖ້າການໂທກັບຄືນມູນຄ່າທີ່ບໍ່ແມ່ນສູນ, ການຟື້ນຟູຈະຖືກຢຸດໃນຕອນຕົ້ນ.
    // 'data' ຈະໄດ້ຮັບການຜ່ານເປັນການໂຕ້ຖຽງທີ່ສາມໂທໃນແຕ່ລະໂທ.
    // 'size' ໃຫ້ຂະ ໜາດ ຂອງ dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// ພວກເຮົາ ຈຳ ເປັນຕ້ອງແຍກອອກ ID ສ້າງແລະຂໍ້ມູນບາງສ່ວນຂອງໂປແກຼມພື້ນຖານເຊິ່ງ ໝາຍ ຄວາມວ່າພວກເຮົາຕ້ອງການເຄື່ອງຂອງ ຈຳ ນວນ ໜຶ່ງ ຈາກຊຸດ ELF ເຊັ່ນກັນ.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// ໃນປັດຈຸບັນພວກເຮົາຕ້ອງເຮັດແບບທົດແທນ, ເລັກໆນ້ອຍໆ, ໂຄງສ້າງຂອງປະເພດ dl_phdr_info ທີ່ຖືກ ນຳ ໃຊ້ໂດຍຕົວເຊື່ອມຕໍ່ແບບເຄື່ອນໄຫວໃນປະຈຸບັນຂອງ fuchsia.
// Chromium ຍັງມີເຂດແດນ ABI ນີ້ເຊັ່ນດຽວກັນກັບ crashpad.
// Eventully ພວກເຮົາຕ້ອງການທີ່ຈະຍ້າຍກໍລະນີເຫຼົ່ານີ້ເພື່ອນໍາໃຊ້ elf, ຄົ້ນຫາແຕ່ພວກເຮົາຈໍາເປັນຕ້ອງໄດ້ສະຫນອງທີ່ໃນ SDK ແລະທີ່ຍັງບໍ່ທັນໄດ້ຮັບການປະຕິບັດ.
//
// ດັ່ງນັ້ນພວກເຮົາ (ແລະພວກເຂົາ) ຈຶ່ງມີຄວາມຫຍຸ້ງຍາກໃນການ ນຳ ໃຊ້ວິທີການນີ້ທີ່ປະສົມປະສານກັບການເຊື່ອມໂຍງເຂົ້າກັນຢ່າງໃກ້ຊິດກັບ libc fuchsia.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // ພວກເຮົາມີວິທີການຮູ້ຂອງການກວດສອບຖ້າຫາກວ່າ e_phoff ບໍ່ມີແລະ e_phnum ແມ່ນຖືກຕ້ອງ.
    // libc ຄວນຮັບປະກັນສິ່ງນີ້ ສຳ ລັບພວກເຮົາຢ່າງໃດກໍ່ຕາມສະນັ້ນມັນປອດໄພທີ່ຈະຈັດແຈງບ່ອນນີ້.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr ເປັນຕົວແທນໃຫ້ແກ່ຫົວ ໜ້າ ໂຄງການ ELF 64-bit ໃນຄວາມອົດທົນຂອງສະຖາປັດຕະຍະ ກຳ ເປົ້າ ໝາຍ.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr ເປັນຕົວແທນຫົວຂໍ້ໂຄງການ ELF ທີ່ຖືກຕ້ອງແລະເນື້ອໃນຂອງມັນ.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // ພວກເຮົາບໍ່ມີວິທີການກວດສອບຖ້າ p_addr ຫຼື p_memsz ແມ່ນຖືກຕ້ອງ.
    // libc ຂອງ Fuchsia ແຍກບົດບັນທຶກກ່ອນແຕ່ຢ່າງໃດກໍ່ຕາມໂດຍຄຸນງາມຄວາມດີຢູ່ທີ່ນີ້ຫົວຂໍ້ເຫຼົ່ານີ້ຕ້ອງຖືກຕ້ອງ.
    //
    // NoteIter ບໍ່ໄດ້ຮຽກຮ້ອງໃຫ້ຂໍ້ມູນພື້ນຖານຖືກຕ້ອງແຕ່ມັນກໍ່ຮຽກຮ້ອງໃຫ້ມີຂໍ້ຜູກມັດທີ່ຖືກຕ້ອງ.
    // ພວກເຮົາເຊື່ອວ່າ libc ໄດ້ຮັບປະກັນວ່ານີ້ແມ່ນກໍລະນີ ສຳ ລັບພວກເຮົາທີ່ນີ້.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// ປະເພດ ໝາຍ ເຫດ ສຳ ລັບການສ້າງ ID.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr ເປັນຕົວແທນໃຫ້ຫົວບົດບັນທຶກ ELF ໃນຄວາມຍືນຍົງຂອງເປົ້າ ໝາຍ.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// ໝາຍ ເຫດສະແດງໃຫ້ເຫັນບັນທຶກ ELF (ຫົວຂໍ້ + ເນື້ອໃນ).
// ຊື່ແມ່ນຖືກປ່ອຍເປັນຊິ້ນ u8 ເພາະວ່າມັນບໍ່ໄດ້ຖືກຢຸດຢູ່ສະ ເໝີ ແລະ rust ເຮັດໃຫ້ມັນງ່າຍພຽງພໍທີ່ຈະກວດເບິ່ງວ່າໄບຕ໌ຈະກົງກັນຢ່າງໃດກໍ່ຕາມ.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter ຊ່ວຍໃຫ້ທ່ານສາມາດປັບຕົວໄດ້ຢ່າງປອດໄພຜ່ານສ່ວນບັນທຶກ.
// ມັນຈະສິ້ນສຸດລົງທັນທີທີ່ມີຂໍ້ຜິດພາດເກີດຂື້ນຫຼືບໍ່ມີບັນທຶກຫຍັງອີກ.
// ຖ້າຫາກວ່າທ່ານ iterate ທີ່ບໍ່ຖືກຕ້ອງໃນໄລຍະຂໍ້ມູນຈະເຮັດຄືກັບວ່າບໍ່ມີຂໍ້ຄວາມໄດ້ຖືກພົບເຫັນ.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // ມັນແມ່ນຄວາມລ້ ຳ ໜ້າ ທີ່ຂອງຕົວຊີ້ບອກແລະຂະ ໜາດ ທີ່ໄດ້ສະແດງໃຫ້ເຫັນລະດັບຂອງໄບຕ໌ທີ່ຖືກຕ້ອງເຊິ່ງສາມາດອ່ານໄດ້ທັງ ໝົດ.
    // ເນື້ອໃນຂອງໄບຕ໌ເຫຼົ່ານີ້ສາມາດເປັນສິ່ງອື່ນໄດ້ແຕ່ຂອບເຂດຕ້ອງຖືກຕ້ອງ ສຳ ລັບສິ່ງນີ້ເພື່ອໃຫ້ປອດໄພ.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to ສອດຄ່ອງ 'x' ກັບ 'to'-byte alignment ສົມມຸດວ່າ 'to' ແມ່ນພະລັງຂອງ 2.
// ນີ້ປະຕິບັດຕາມແບບແຜນມາດຕະຖານໃນລະຫັດການແຍກ C/C ++ ELF ທີ່ (x + ເຖິງ, 1)&-to ຖືກ ນຳ ໃຊ້.
// Rust ບໍ່ໃຫ້ທ່ານລົບລ້າງການ ນຳ ໃຊ້ດັ່ງນັ້ນຂ້ອຍໃຊ້
// 2's ປ່ຽນໃຈເຫລື້ອມໃສທີ່ສົມບູນແບບເພື່ອສ້າງສິ່ງນັ້ນຄືນໃຫມ່.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 ບໍລິໂພກຫລາຍບາດຈາກສ່ວນຕ່າງໆ (ຖ້າມີ) ແລະຮັບປະກັນວ່າສ່ວນສຸດທ້າຍແມ່ນສອດຄ່ອງກັນ.
// ຖ້າຫາກວ່າເປັນບໍ່ວ່າຈະຈໍານວນຂອງໄບຕ໌ຮຽກຮ້ອງໃຫ້ມີຂະຫນາດໃຫຍ່ເກີນໄປຫຼືຫຼັງຈາກນັ້ນນໍາບໍ່ສາມາດໄດ້ຮັບການດັດປັບຫລັງຈາກນັ້ນເນື່ອງຈາກການ bytes ບໍ່ພຽງພໍຍັງເຫຼືອທີ່ມີຢູ່ແລ້ວ, ບໍ່ມີແມ່ນກັບຄືນແລະຫຼັງຈາກນັ້ນນໍາບໍ່ໄດ້ຖືກແກ້ໄຂເທື່ອ.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// ຟັງຊັນນີ້ບໍ່ມີຄາຄົງທີ່ແທ້ຈິງແປໄດ້ທຸໄດ້ຕ້ອງປະຕິບັດອື່ນທີ່ບໍ່ແມ່ນບາງທີອາດມີທີ່ 'bytes' ຄວນໄດ້ຮັບການສອດຄ່ອງສໍາລັບປະສິດທິພາບ (ແລະບາງສະຖາປັດຍະການກວດແກ້).
// ຄ່າຢູ່ໃນທົ່ງນາ Elf_Nhdr ອາດຈະບໍ່ມີປະໂຫຍດຫຍັງເລີຍແຕ່ວ່າ ໜ້າ ທີ່ນີ້ຮັບປະກັນບໍ່ມີສິ່ງໃດເລີຍ.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // ນີ້ປອດໄພຕາບໃດທີ່ມີພື້ນທີ່ພຽງພໍແລະພວກເຮົາພຽງແຕ່ຢືນຢັນວ່າໃນ ຄຳ ຖະແຫຼງຖ້າຂ້າງເທິງສະນັ້ນສິ່ງນີ້ບໍ່ຄວນປອດໄພ.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // ໃຫ້ສັງເກດວ່າ sice_of: :<Elf_Nhdr>() ແມ່ນສະເຫມີ 4-byte ສອດຄ່ອງ.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // ກວດເບິ່ງວ່າພວກເຮົາໄດ້ຮອດຈຸດສຸດທ້າຍແລ້ວບໍ.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // ພວກເຮົາສົ່ງອອກຈາກ nhdr ແຕ່ພວກເຮົາພິຈາລະນາຢ່າງລະມັດລະວັງກ່ຽວກັບໂຄງສ້າງທີ່ໄດ້ຮັບ.
        // ພວກເຮົາບໍ່ເຊື່ອຖື namesz ຫຼື descsz ແລະພວກເຮົາບໍ່ຕັດສິນໃຈທີ່ບໍ່ປອດໄພໂດຍອີງຕາມປະເພດ.
        //
        // ສະນັ້ນເຖິງແມ່ນວ່າພວກເຮົາຈະອອກຂີ້ເຫຍື້ອທີ່ສົມບູນແລ້ວພວກເຮົາກໍ່ຄວນຈະປອດໄພ.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// ຊີ້ໃຫ້ເຫັນວ່າສ່ວນໃດສາມາດປະຕິບັດໄດ້.
const PERM_X: u32 = 0b00000001;
/// ຊີ້ໃຫ້ເຫັນວ່າສ່ວນແມ່ນສາມາດຂຽນໄດ້.
const PERM_W: u32 = 0b00000010;
/// ຊີ້ໃຫ້ເຫັນວ່າສ່ວນ ໜຶ່ງ ແມ່ນສາມາດອ່ານໄດ້.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// ສະແດງໃຫ້ເຫັນສ່ວນ ELF ຢູ່ runtime.
struct Segment {
    /// ເຮັດໃຫ້ທີ່ຢູ່ virtual runtime ຂອງເນື້ອໃນຂອງຕອນນີ້.
    addr: usize,
    /// ເຮັດໃຫ້ຂະຫນາດຫນ່ວຍຄວາມຈໍາຂອງເນື້ອໃນຂອງກຸ່ມນີ້.
    size: usize,
    /// ໃຫ້ທີ່ຢູ່ virtual module ຂອງສ່ວນນີ້ດ້ວຍເອກະສານ ELF.
    mod_rel_addr: usize,
    /// ເຮັດໃຫ້ການອະນຸຍາດທີ່ພົບເຫັນໃນເອກະສານ ELF.
    /// ການອະນຸຍາດເຫຼົ່ານີ້ບໍ່ ຈຳ ເປັນຕ້ອງໄດ້ຮັບອະນຸຍາດໃນປະຈຸບັນ.
    flags: Perm,
}

/// ສາມາດເຮັດໃຫ້ຫນຶ່ງ iterate ໃນໄລຍະ Seem ຈາກ DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ເປັນຕົວແທນໃຫ້ແກ່ ELF DSO (Dynamic Shared Object).
/// ປະເພດນີ້ເອກະສານຂໍ້ມູນທີ່ເກັບໄວ້ໃນ DSO ຕົວຈິງແທນທີ່ຈະກ່ວາເຮັດໃຫ້ສໍາເນົາຂອງຕົນເອງ.
struct Dso<'a> {
    /// ຕົວເຊື່ອມຕໍ່ແບບເຄື່ອນໄຫວສະເຫມີໃຫ້ພວກເຮົາຊື່, ເຖິງແມ່ນວ່າຊື່ແມ່ນຫວ່າງເປົ່າ.
    /// ໃນກໍລະນີຂອງການບໍລິຫານຕົ້ນຕໍຊື່ນີ້ຈະຫວ່າງເປົ່າ.
    /// ໃນກໍລະນີຂອງວັດຖຸທີ່ໃຊ້ຮ່ວມກັນມັນຈະເປັນນາມສະກຸນ (ເບິ່ງ DT_SONAME).
    name: &'a str,
    /// ໃນ Fuchsia ເກືອບທັງສອງພາສີມີການສ້າງ ID ແຕ່ວ່ານີ້ບໍ່ແມ່ນຄວາມຕ້ອງການທີ່ເຄັ່ງຄັດ.
    /// ບໍ່ມີທາງທີ່ຈະສາມາດປະກອບຂໍ້ມູນຂ່າວສານ DSO ກັບເອກະສານ ELF ທີ່ແທ້ຈິງຫລັງຈາກນັ້ນຖ້າບໍ່ມີ build_id ດັ່ງນັ້ນພວກເຮົາຮຽກຮ້ອງໃຫ້ DSO ທຸກໆຄົນມີທີ່ນີ້.
    ///
    /// DSO ຂອງໂດຍບໍ່ມີການ build_id ເປັນຖືກຫລີກເວັ້ນທັ້ງ.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// ສົ່ງຄືນເຄື່ອງ ໝາຍ ໃນສ່ວນຕ່າງໆໃນ DSO ນີ້.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// ຂໍ້ຜິດພາດເຫລົ່ານີ້ຈະເຂົ້າລະຫັດບັນຫາທີ່ເກີດຂື້ນໃນຂະນະທີ່ ກຳ ລັງແຍກຂໍ້ມູນກ່ຽວກັບແຕ່ລະ DSO.
///
enum Error {
    /// NameError ຫມາຍຄວາມວ່າຄວາມຜິດພາດເກີດຂຶ້ນໃນຂະນະທີ່ການເປັນ string ແບບ C ເຂົ້າໄປໃນສະຕິງ rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError ຫມາຍຄວາມວ່າພວກເຮົາບໍ່ໄດ້ຊອກຫາການກໍ່ສ້າງລະຫັດ.
    /// ນີ້ອາດຈະແມ່ນຍ້ອນວ່າ DSO ບໍ່ມີບັດສ້າງ ID ຫຼືຍ້ອນວ່າສ່ວນທີ່ບັນຈຸບັດ ID ບໍ່ຖືກຕ້ອງ.
    ///
    BuildIDError,
}

/// ໂທຫາເຄືອຂ່າຍບໍ່ວ່າຈະ 'dso' ຫຼື 'error' ສໍາລັບແຕ່ລະ DSO ເຊື່ອມໂຍງເຂົ້າໄປໃນຂະບວນການໂດຍ linker ແບບໄດນາມິກໄດ້.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter ທີ່ຈະມີ ໜຶ່ງ ໃນວິທີການກິນທີ່ເອີ້ນວ່າ foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr ຮັບປະກັນວ່າ info.name ຈະຊີ້ໃຫ້ເຫັນເຖິງສະຖານທີ່ທີ່ຖືກຕ້ອງ.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// ຟັງຊັນນີ້ພິມເຄື່ອງ ໝາຍ ສັນຍາລັກ Fuchsia ສຳ ລັບຂໍ້ມູນທັງ ໝົດ ທີ່ມີຢູ່ໃນ DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}