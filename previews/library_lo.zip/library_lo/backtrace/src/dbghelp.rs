//! ໂມດູນການຊ່ວຍເຫຼືອໃນການຄຸ້ມຄອງລວມ dbghelp ກ່ຽວກັບ Windows
//!
//! backtrace ກ່ຽວກັບ Windows (ຢ່າງຫນ້ອຍສໍາລັບ MSVC) ກໍາລັງຂັບເຄື່ອນຢ່າງກວ້າງຂວາງໂດຍຜ່ານການ `dbghelp.dll` ແລະຫນ້າທີ່ຕ່າງໆທີ່ມັນປະກອບດ້ວຍ.
//! ໜ້າ ທີ່ເຫຼົ່ານີ້ຖືກໂຫລດໃນປະຈຸບັນ *ແບບເຄື່ອນໄຫວ* ແທນທີ່ຈະເຊື່ອມໂຍງກັບ `dbghelp.dll` ຢ່າງສະ ໝໍ່າ ສະ ເໝີ.
//! ປະຈຸບັນນີ້ແມ່ນເຮັດໂດຍຫ້ອງສະມຸດມາດຕະຖານ (ແລະຕາມທິດສະດີທີ່ຕ້ອງການຢູ່ທີ່ນັ້ນ), ແຕ່ວ່າມັນແມ່ນຄວາມພະຍາຍາມທີ່ຈະຊ່ວຍຫຼຸດຜ່ອນຄວາມເພິ່ງພາອາໄສຂອງຫໍສະ ໝຸດ ນັບຕັ້ງແຕ່ backtraces ແມ່ນປົກກະຕິທີ່ເປັນທາງເລືອກ.
//!
//! ທີ່ຖືກເວົ້າວ່າ, `dbghelp.dll` ເກືອບຈະປະສົບຜົນ ສຳ ເລັດໃນການໂຫຼດ Windows X.
//!
//! ໃຫ້ສັງເກດວ່າເນື່ອງຈາກວ່າພວກເຮົາ ກຳ ລັງໂຫລດການສະ ໜັບ ສະ ໜູນ ທັງ ໝົດ ນີ້ຢ່າງຄ່ອງແຄ້ວ, ພວກເຮົາບໍ່ສາມາດໃຊ້ ຄຳ ນິຍາມວັດຖຸດິບໃນ `winapi`, ແຕ່ພວກເຮົາ ຈຳ ເປັນຕ້ອງ ກຳ ນົດຕົວຊີ້ບອກປະເພດຕົວເຮົາເອງແລະໃຊ້ນັ້ນ.
//! ພວກເຮົາບໍ່ຕ້ອງການຢາກເຮັດທຸລະກິດກັບ winapi ທີ່ຊໍ້າຊ້ອນກັນ, ດັ່ງນັ້ນພວກເຮົາມີ Cargo ຄຸນນະສົມບັດ `verify-winapi` ເຊິ່ງຢືນຢັນວ່າການຜູກມັດທັງ ໝົດ ກົງກັບສິ່ງທີ່ຢູ່ໃນ winapi ແລະຄຸນສົມບັດນີ້ຖືກເປີດໃຊ້ໃນ CI.
//!
//! ສຸດທ້າຍ, ທ່ານຈະສັງເກດທີ່ນີ້ວ່າ Dll ສຳ ລັບ `dbghelp.dll` ແມ່ນບໍ່ເຄີຍໂຫລດ, ແລະນັ້ນແມ່ນເຈດຕະນາ.
//! ແນວຄິດແມ່ນວ່າພວກເຮົາສາມາດເກັບມັນຢູ່ທົ່ວໂລກແລະສາມາດໃຊ້ລະຫວ່າງການໂທຫາ API, ຫລີກລ້ຽງ loads/unloads ລາຄາແພງ.
//! ຖ້າສິ່ງນີ້ເປັນປັນຫາ ສຳ ລັບເຄື່ອງກວດຈັບຮົ່ວຫລືບາງສິ່ງບາງຢ່າງເຊັ່ນນັ້ນພວກເຮົາສາມາດຂ້າມຂົວໄດ້ເມື່ອພວກເຮົາໄປທີ່ນັ້ນ.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// ເຮັດວຽກຮອບ `SymGetOptions` ແລະ `SymSetOptions` ບໍ່ມີຢູ່ໃນ winapi ເອງ.
// ຖ້າບໍ່ດັ່ງນັ້ນສິ່ງນີ້ຈະຖືກ ນຳ ໃຊ້ໃນເວລາທີ່ພວກເຮົາ ກຳ ລັງກວດສອງຄັ້ງກັບຊະນິດ winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // ບໍ່ໄດ້ກໍານົດໃນ winapi ທັນ
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // ສິ່ງນີ້ຖືກ ກຳ ນົດໄວ້ໃນ winapi, ແຕ່ມັນບໍ່ຖືກຕ້ອງ (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // ບໍ່ໄດ້ກໍານົດໃນ winapi ທັນ
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// ມະຫາພາກນີ້ຖືກ ນຳ ໃຊ້ເພື່ອ ກຳ ນົດໂຄງສ້າງ `Dbghelp` ເຊິ່ງພາຍໃນປະກອບດ້ວຍຕົວຊີ້ວັດ ໜ້າ ທີ່ທັງ ໝົດ ທີ່ພວກເຮົາອາດຈະໂຫລດ.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL ທີ່ຖືກໂຫລດ ສຳ ລັບ `dbghelp.dll`
            dll: HMODULE,

            // ຕົວຊີ້ຕົວແຕ່ລະ ໜ້າ ທີ່ ສຳ ລັບແຕ່ລະ ໜ້າ ທີ່ພວກເຮົາອາດຈະໃຊ້
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // ໃນເບື້ອງຕົ້ນພວກເຮົາບໍ່ໄດ້ໂຫລດ DLL
            dll: 0 as *mut _,
            // ຊື່ຫຍໍ້ຫນ້າທັງຫມົດແມ່ນກໍານົດໃຫ້ສູນເພື່ອເວົ້າວ່າພວກເຂົາຈໍາເປັນຕ້ອງໄດ້ຮັບການ loaded ນະໂຍບາຍດ້ານ.
            //
            $($name: 0,)*
        };

        // ປະເພດຄວາມສະດວກສະບາຍ ສຳ ລັບແຕ່ລະປະເພດ ໜ້າ ທີ່.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// ຄວາມພະຍາຍາມທີ່ຈະເປີດ `dbghelp.dll`.
            /// ຜົນໄດ້ຮັບຜົນສໍາເລັດຖ້າຫາກວ່າມັນເຮັດວຽກຫຼືຄວາມຜິດພາດຖ້າຫາກວ່າ `LoadLibraryW` ລົ້ມເຫລວ.
            ///
            /// Panics ຖ້າຫ້ອງສະ ໝຸດ ຖືກໂຫລດແລ້ວ.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // ໃຊ້ ສຳ ລັບແຕ່ລະວິທີທີ່ພວກເຮົາຕ້ອງການໃຊ້.
            // ເມື່ອຖືກເອີ້ນມັນກໍ່ຈະສາມາດອ່ານຕົວຊີ້ທີ່ເຮັດວຽກຢູ່ໃນຖານຄວາມ ຈຳ ຫລືໂຫລດມັນແລະສົ່ງຄືນຄ່າທີ່ ກຳ ລັງໂຫລດ.
            // ພາລະ ກຳ ລັງຮັບຮອງວ່າປະສົບຜົນ ສຳ ເລັດ.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // ຕົວແທນຄວາມສະດວກໃນການໃຊ້ກະແຈ ທຳ ຄວາມສະອາດເພື່ອອ້າງອີງເຖິງ ໜ້າ ທີ່ dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// ເລີ່ມຕົ້ນສະຫນັບສະຫນູນທັງຫມົດທີ່ຈໍາເປັນໃນການເຂົ້າເຖິງ `dbghelp` ຫນ້າ API ຈາກ crate ນີ້.
///
///
/// ໃຫ້ສັງເກດວ່າການທໍາງານນີ້ແມ່ນມີຄວາມປອດໄພ ** **, ມັນພາຍໃນມີ synchronization ຂອງຕົນເອງ.
/// ໃຫ້ສັງເກດອີກວ່າມັນປອດໄພທີ່ຈະໂທຫາຟັງຊັ່ນນີ້ຫຼາຍຄັ້ງ.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // ສິ່ງ ທຳ ອິດທີ່ພວກເຮົາຕ້ອງເຮັດກໍ່ຄືການເຮັດວຽກນີ້ໃຫ້ ສຳ ເລັດ.ນີ້ສາມາດຖືກເອີ້ນວ່າພ້ອມກັນຈາກກະທູ້ອື່ນຫລືເອີ້ນຄືນກັນພາຍໃນກະທູ້ດຽວ.
        // ໃຫ້ສັງເກດວ່າມັນເປັນ trickier ກ່ວາທີ່ວ່າເນື່ອງຈາກວ່າສິ່ງທີ່ພວກເຮົາກໍາລັງໃຊ້ຢູ່ທີ່ນີ້, `dbghelp`,*ຍັງ* ຄວາມຕ້ອງການທີ່ຈະໃຫ້ສອດຄ່ອງກັບແປໄດ້ທຸອື່ນໆທັງຫມົດທີ່ຈະ `dbghelp` ໃນຂະບວນການນີ້.
        //
        // ໂດຍປົກກະຕິແລ້ວບໍ່ມີການໂທຫຼາຍຢ່າງໃຫ້ກັບ `dbghelp` ໃນຂະບວນການດຽວກັນແລະພວກເຮົາອາດຈະຖືວ່າພວກເຮົາເປັນຄົນດຽວທີ່ເຂົ້າເຖິງມັນຢ່າງປອດໄພ.
        // ເຖິງຢ່າງໃດກໍ່ຕາມ, ມີຜູ້ ນຳ ໃຊ້ຄົນ ທຳ ອິດທີ່ພວກເຮົາຕ້ອງກັງວົນວ່າຕົວເອງແມ່ນຫຍັງ, ແຕ່ຢູ່ໃນຫໍສະມຸດມາດຕະຖານ.
        // ຫ້ອງສະຫມຸດມາດຕະຖານ Rust ຂື້ນກັບ crate ນີ້ ສຳ ລັບການສະ ໜັບ ສະ ໜູນ ດ້ານຫລັງ, ແລະ crate ນີ້ຍັງມີຢູ່ໃນ crates.io.
        // ນີ້ຫມາຍຄວາມວ່າຖ້າຫ້ອງສະຫມຸດມາດຕະຖານກໍາລັງພິມຮູບພາບ panic backtrace ມັນອາດຈະແຂ່ງກັບ crate ນີ້ມາຈາກ crates.io, ເຊິ່ງກໍ່ໃຫ້ເກີດຄວາມສັບສົນ.
        //
        // ກັບການຊ່ວຍເຫຼືອແກ້ໄຂບັນຫາການປະສານນີ້ພວກເຮົາມີພະນັກງານ trick Windows ສະເພາະຢູ່ທີ່ນີ້ (ມັນເປັນ, ຫຼັງຈາກທັງຫມົດ, ເປັນຂໍ້ຈໍາກັດ Windows ສະເພາະກ່ຽວກັບການປະສານ).
        // ພວກເຮົາສ້າງ *session-local* ຊື່ mutex ເພື່ອປົກປ້ອງການໂທນີ້.
        // ຈຸດປະສົງໃນທີ່ນີ້ແມ່ນວ່າຫ້ອງສະມຸດມາດຕະຖານແລະ crate ນີ້ບໍ່ ຈຳ ເປັນຕ້ອງແບ່ງປັນລະດັບ Rust ເພື່ອເຮັດ synchronize ຢູ່ບ່ອນນີ້ແຕ່ແທນທີ່ຈະສາມາດເຮັດວຽກຢູ່ເບື້ອງຫຼັງເພື່ອໃຫ້ແນ່ໃຈວ່າພວກເຂົາ ກຳ ລັງຊິ້ງຂໍ້ມູນກັບກັນແລະກັນ.
        //
        // ວິທີການທີ່ໃນເວລາທີ່ການທໍາງານນີ້ແມ່ນເອີ້ນວ່າໂດຍຜ່ານຫໍສະຫມຸດມາດຕະຖານຫລືຜ່ານ crates.io ພວກເຮົາສາມາດໃຫ້ແນ່ໃຈວ່າວ່າ Mutex ດຽວກັນຖືກທີ່ໄດ້ມາ.
        //
        // ດັ່ງນັ້ນທັງຫມົດນັ້ນແມ່ນການເວົ້າວ່າສິ່ງທໍາອິດທີ່ພວກເຮົາເຮັດແນວໃດນີ້ແມ່ນພວກເຮົາ atomically ສ້າງ `HANDLE` ຊຶ່ງເປັນທີ່ມີຊື່ Mutex ໃນ Windows.
        // ພວກເຮົາຊິ້ງຂໍ້ມູນເລັກໆນ້ອຍໆກັບກະທູ້ອື່ນແບ່ງປັນ ໜ້າ ທີ່ນີ້ໂດຍສະເພາະແລະຮັບປະກັນວ່າມີພຽງແຕ່ມືດຽວທີ່ຖືກສ້າງຂື້ນໃນຕົວຢ່າງຂອງ ໜ້າ ທີ່ນີ້.
        // ໃຫ້ສັງເກດວ່າການຈັບບໍ່ເຄີຍປິດເມື່ອມັນຖືກເກັບໄວ້ໃນທົ່ວໂລກ.
        //
        // ຫຼັງຈາກທີ່ພວກເຮົາລົງລັອກຕົວຈິງແລ້ວພວກເຮົາພຽງແຕ່ໄດ້ຮັບມັນ, ແລະ `Init` ຂອງພວກເຮົາຈັດການກັບພວກເຮົາຈະຮັບຜິດຊອບໃນການລຸດມັນໃນທີ່ສຸດ.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // ໂອເຄ, ປ້າ!ໃນປັດຈຸບັນທີ່ພວກເຮົາທັງຫມົດໄດ້ຖືກປະສານກັນຢ່າງປອດໄພ, ໃຫ້ພວກເຮົາເລີ່ມຕົ້ນປະມວນຜົນທຸກຢ່າງ.
        // ຫນ້າທໍາອິດທີ່ພວກເຮົາຕ້ອງການເພື່ອຮັບປະກັນວ່າ `dbghelp.dll` ຖືກໂຫລດແທ້ໃນຂະບວນການນີ້.
        // ພວກເຮົາເຮັດແບບໄດນາມິກນີ້ເພື່ອຫຼີກເວັ້ນການເພິ່ງພາອາໄສແບບຄົງທີ່.
        // ນີ້ໄດ້ຮັບການທາງປະຫວັດສາດເຮັດໃຫ້ການເຮັດວຽກປະມານບັນຫາການເຊື່ອມໂຍງ weird ແລະມີຈຸດປະສົງທີ່ເຮັດໃຫ້ໄບນາລີເປັນ bit portable ຫຼາຍນັບຕັ້ງແຕ່ນີ້ເປັນສ່ວນໃຫຍ່ພຽງແຕ່ຜົນປະໂຫຍດ debugging.
        //
        //
        // ເມື່ອພວກເຮົາໄດ້ເປີດ `dbghelp.dll` ແລ້ວພວກເຮົາ ຈຳ ເປັນຕ້ອງໂທຫາບາງ ໜ້າ ທີ່ເລີ່ມຕົ້ນຢູ່ໃນນັ້ນ, ແລະນັ້ນແມ່ນລາຍລະອຽດຢູ່ດ້ານລຸ່ມ.
        // ພວກເຮົາພຽງແຕ່ເຮັດສິ່ງນີ້ເມື່ອ, ເຖິງແມ່ນວ່າ, ສະນັ້ນພວກເຮົາໄດ້ຮັບ boolean ທົ່ວໂລກລະບຸວ່າພວກເຮົາກໍາລັງເຮັດຍັງຫຼືບໍ່.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // ຮັບປະກັນວ່າທຸງ `SYMOPT_DEFERRED_LOADS` ຖືກຕັ້ງ, ເພາະວ່າອີງຕາມເອກະສານຂອງ MSVC ເອງກ່ຽວກັບເລື່ອງນີ້: "This is the fastest, most efficient way to use the symbol handler.", ສະນັ້ນໃຫ້ເຮັດແນວນັ້ນ!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // ຕົວຈິງເລີ່ມຕົ້ນສັນຍາລັກກັບ MSVC.ຈົ່ງສັງເກດວ່ານີ້ສາມາດລົ້ມເຫລວ, ແຕ່ພວກເຮົາບໍ່ສົນໃຈມັນ.
        // ບໍ່ມີສິນລະປະກ່ອນນີ້ ສຳ ລັບສິນຄ້ານີ້, ແຕ່ວ່າພາຍໃນ LLVM ເບິ່ງຄືວ່າຈະບໍ່ສົນໃຈກັບມູນຄ່າການກັບຄືນຢູ່ບ່ອນນີ້ແລະຫ້ອງສະ ໝຸດ ສຸຂາພິບານ ໜຶ່ງ ໃນ LLVM ພິມ ຄຳ ເຕືອນທີ່ ໜ້າ ຢ້ານຖ້າສິ່ງນີ້ລົ້ມເຫລວແຕ່ໂດຍພື້ນຖານແລ້ວຈະບໍ່ສົນໃຈມັນໃນໄລຍະຍາວ.
        //
        //
        // ກໍລະນີ ໜຶ່ງ ທີ່ເກີດຂື້ນຫຼາຍ ສຳ ລັບ Rust ແມ່ນວ່າຫ້ອງສະມຸດມາດຕະຖານແລະ crate ນີ້ຢູ່ crates.io ທັງສອງຕ້ອງການແຂ່ງຂັນ ສຳ ລັບ `SymInitializeW`.
        // ປະຫວັດສາດຫໍສະມຸດຕ້ອງການເລີ່ມຕົ້ນຫຼັງຈາກນັ້ນ ທຳ ຄວາມສະອາດເປັນສ່ວນໃຫຍ່, ແຕ່ດຽວນີ້ມັນ ກຳ ລັງໃຊ້ crate ນີ້ມັນ ໝາຍ ຄວາມວ່າຜູ້ໃດຜູ້ ໜຶ່ງ ຈະໄດ້ຮັບການເລີ່ມຕົ້ນກ່ອນອື່ນແລະອີກເບື້ອງ ໜຶ່ງ ຈະເລືອກເອົາການເລີ່ມຕົ້ນນັ້ນ.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}