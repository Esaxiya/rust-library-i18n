//! ປະເພດທີ່ຂື້ນກັບແພລະຕະຟອມ.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// ການສະແດງເອກະລາດຂອງເວທີ.
/// ເມື່ອເຮັດວຽກກັບ `std` ທີ່ເປີດໃຊ້ມັນໄດ້ຖືກແນະ ນຳ ໃຫ້ໃຊ້ວິທີການທີ່ສະດວກໃນການໃຫ້ການແປງເປັນ `std` ປະເພດ.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// ຫຼັງຈາກນັ້ນນໍາ, ສະຫນອງໃຫ້ຕາມປົກກະຕິໃນເວທີ Unix.
    Bytes(&'a [u8]),
    /// ສາຍເຊືອກກວ້າງປົກກະຕິຈາກ Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Lossy ປ່ຽນເປັນ `Cow<str>`, ຈະຈັດສັນຖ້າ `Bytes` ບໍ່ຖືກຕ້ອງ UTF-8 ຫຼືຖ້າ `BytesOrWideString` ແມ່ນ `Wide`.
    ///
    /// # ລັກສະນະທີ່ຕ້ອງການ
    ///
    /// ຟັງຊັນນີ້ຮຽກຮ້ອງໃຫ້ຄຸນລັກສະນະ `std` ຂອງ `backtrace` crate ສາມາດໃຊ້ງານໄດ້, ແລະຄຸນລັກສະນະ `std` ຖືກເປີດໃຊ້ໂດຍຄ່າເລີ່ມຕົ້ນ.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// ໃຫ້ຕົວແທນ `Path` ຂອງ `BytesOrWideString`.
    ///
    /// # ລັກສະນະທີ່ຕ້ອງການ
    ///
    /// ຟັງຊັນນີ້ຮຽກຮ້ອງໃຫ້ຄຸນລັກສະນະ `std` ຂອງ `backtrace` crate ສາມາດໃຊ້ງານໄດ້, ແລະຄຸນລັກສະນະ `std` ຖືກເປີດໃຊ້ໂດຍຄ່າເລີ່ມຕົ້ນ.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}