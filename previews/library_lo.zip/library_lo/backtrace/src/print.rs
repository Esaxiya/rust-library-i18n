#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// ຮູບແບບ ສຳ ລັບ backtraces.
///
/// ແບບນີ້ສາມາດຖືກ ນຳ ໃຊ້ໃນການພິມພາບຫລັງໂດຍບໍ່ວ່າສະຖານະພາບຕົວຂອງມັນເອງມາຈາກໃສ.
/// ຖ້າທ່ານມີປະເພດ `Backtrace` ແລ້ວການປະຕິບັດ `Debug` ຂອງມັນໃຊ້ຮູບແບບການພິມນີ້ແລ້ວ.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// ຮູບແບບຂອງການພິມທີ່ພວກເຮົາສາມາດພິມອອກໄດ້
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// ພິມແຜນວາດທີ່ຢູ່ເບື້ອງຫຼັງເຊິ່ງພຽງແຕ່ມີຂໍ້ມູນທີ່ກ່ຽວຂ້ອງເທົ່ານັ້ນ
    Short,
    /// ພິມ backtrace ທີ່ປະກອບດ້ວຍຂໍ້ມູນຂ່າວສານທີ່ເປັນໄປໄດ້ທັງຫມົດເປັນ
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// ສ້າງ `BacktraceFmt` ໃຫມ່ທີ່ຈະຂຽນຂໍ້ມູນຜົນການ `fmt` ສະຫນອງໃຫ້.
    ///
    /// ການໂຕ້ຖຽງ `format` ຈະຄວບຄຸມຮູບແບບທີ່ພື້ນຫລັງຂອງຖືກພິມ, ແລະການໂຕ້ຖຽງ `print_path` ຈະຖືກ ນຳ ໃຊ້ເພື່ອພິມຕົວຢ່າງ `BytesOrWideString` ຂອງຊື່ແຟ້ມ.
    /// ປະເພດນີ້ຕົວຂອງມັນເອງບໍ່ໄດ້ເຮັດການພິມຂອງ filenames ໃດ, ແຕ່ໂທນີ້ຈໍາເປັນຕ້ອງມີເພື່ອເຮັດແນວນັ້ນ.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// ພິມຮູບພາບເບື້ອງຕົ້ນກ່ຽວກັບສະຖານະພາບຫລັງທີ່ຈະຖືກພິມອອກ.
    ///
    /// ນີ້ແມ່ນ ຈຳ ເປັນໃນບາງເວທີ ສຳ ລັບ backtraces ເພື່ອເປັນສັນຍາລັກຢ່າງເຕັມທີ່ຕໍ່ມາ, ແລະຖ້າບໍ່ດັ່ງນັ້ນນີ້ຄວນເປັນວິທີ ທຳ ອິດທີ່ທ່ານເອີ້ນຫຼັງຈາກສ້າງ `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// ເພີ່ມກອບໃຫ້ກັບຜົນຜະລິດຫລັງ.
    ///
    /// ນີ້ຄໍາຫມັ້ນສັນຍາກັບການຍົກຕົວຢ່າງ RAII ຂອງ `BacktraceFrameFmt` ທີ່ສາມາດຖືກນໍາໃຊ້ໃນຕົວຈິງແມ່ນພິມກອບ, ແລະການທໍາລາຍມັນຈະເພີ່ມຄ່າວຽກງານຕ້ານການໃນກອບຂອງ.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// ສຳ ເລັດຜົນຜົນການສະແດງ backtrace.
    ///
    /// ປະຈຸບັນນີ້ແມ່ນບໍ່ມີ op ແຕ່ເພີ່ມຄວາມເຂົ້າກັນໄດ້ future ກັບຮູບແບບ backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // ປະຈຸບັນບໍ່ມີ-ລວມທັງ hook ນີ້ເພື່ອອະນຸຍາດໃຫ້ເພີ່ມເຕີມ future.
        Ok(())
    }
}

/// ຮູບແບບ ສຳ ລັບພຽງແຕ່ຮູບ ໜຶ່ງ ຂອງແຜນວາດ.
///
/// ປະເພດນີ້ຖືກສ້າງຂື້ນໂດຍການເຮັດວຽກຂອງ `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// ພິມ `BacktraceFrame` ພ້ອມຮູບແບບກອບນີ້.
    ///
    /// ສິ່ງນີ້ຈະພິມຕົວຢ່າງ `BacktraceSymbol` ທັງ ໝົດ ພາຍໃນ `BacktraceFrame`.
    ///
    /// # ລັກສະນະທີ່ຕ້ອງການ
    ///
    /// ຟັງຊັນນີ້ຮຽກຮ້ອງໃຫ້ຄຸນລັກສະນະ `std` ຂອງ `backtrace` crate ສາມາດໃຊ້ງານໄດ້, ແລະຄຸນລັກສະນະ `std` ຖືກເປີດໃຊ້ໂດຍຄ່າເລີ່ມຕົ້ນ.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// ພິມເປັນ `BacktraceSymbol` ພາຍໃນ `BacktraceFrame`.
    ///
    /// # ລັກສະນະທີ່ຕ້ອງການ
    ///
    /// ຟັງຊັນນີ້ຮຽກຮ້ອງໃຫ້ຄຸນລັກສະນະ `std` ຂອງ `backtrace` crate ສາມາດໃຊ້ງານໄດ້, ແລະຄຸນລັກສະນະ `std` ຖືກເປີດໃຊ້ໂດຍຄ່າເລີ່ມຕົ້ນ.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ນີ້ບໍ່ແມ່ນສິ່ງທີ່ດີທີ່ພວກເຮົາບໍ່ຕ້ອງການພິມຫຍັງເລີຍ
            // ກັບ filenames ທີ່ບໍ່ແມ່ນ utf8.
            // ໂຊກດີເກືອບທຸກສິ່ງທຸກຢ່າງແມ່ນ utf8 ນັ້ນນີ້ບໍ່ຄວນຈະເກີນໄປບໍ່ດີເກີນໄປ.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// ພິມ `Frame` ແລະ `Symbol` ທີ່ຕິດຕາມວັດຖຸດິບ, ໂດຍປົກກະຕິຈາກພາຍໃນເອີ້ນຄືນດິບຂອງ crate ນີ້.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// ເພີ່ມກອບດິບໃຫ້ກັບຜົນຜະລິດຫລັງ.
    ///
    /// ວິທີການດັ່ງກ່າວນີ້, ບໍ່ເຫມືອນກັບທີ່ຜ່ານມາ, ໃຊ້ເວລາການໂຕ້ຖຽງດິບໃນກໍລະນີທີ່ເຂົາເຈົ້າກໍາລັງເປັນທີ່ມາຈາກສະຖານທີ່ທີ່ແຕກຕ່າງກັນ.
    /// ໃຫ້ສັງເກດວ່າສິ່ງນີ້ອາດຈະຖືກເອີ້ນຫຼາຍຄັ້ງຕໍ່ ໜຶ່ງ ກອບ.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// ເພີ່ມກອບວັດຖຸດິບໃຫ້ກັບຜົນຜະລິດຫລັງ, ລວມທັງຂໍ້ມູນຄໍ ລຳ.
    ///
    /// ວິທີການນີ້, ເຊັ່ນ: ການທີ່ຜ່ານມາ, ໃຊ້ເວລາການໂຕ້ຖຽງດິບໃນກໍລະນີທີ່ເຂົາເຈົ້າກໍາລັງເປັນທີ່ມາຈາກສະຖານທີ່ທີ່ແຕກຕ່າງກັນ.
    /// ໃຫ້ສັງເກດວ່າສິ່ງນີ້ອາດຈະຖືກເອີ້ນຫຼາຍຄັ້ງຕໍ່ ໜຶ່ງ ກອບ.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia ບໍ່ສາມາດເປັນສັນຍາລັກໃນຂະບວນການດັ່ງນັ້ນມັນມີຮູບແບບພິເສດເຊິ່ງສາມາດຖືກ ນຳ ໃຊ້ເພື່ອເປັນສັນຍາລັກໃນພາຍຫລັງ.
        // ພິມວ່າແທນທີ່ຈະພິມທີ່ຢູ່ໃນຮູບແບບຂອງພວກເຮົາເອງຢູ່ທີ່ນີ້.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // ບໍ່ຈໍາເປັນຕ້ອງພິມເຟຣມ "null", ມັນໂດຍທົ່ວໄປພຽງແຕ່ມີຄວາມຫມາຍວ່າການ backtrace ລະບົບແມ່ນການຊ່ວຍກະຕືລືລົ້ນທີ່ຈະຕິດຕາມໄປ super ໄກ.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // ເພື່ອຫຼຸດຜ່ອນຂະ ໜາດ TCB ໃນ Sgx enclave, ພວກເຮົາບໍ່ຕ້ອງການປະຕິບັດ ໜ້າ ທີ່ແກ້ໄຂສັນຍາລັກ.
        // ແທນທີ່ຈະ, ພວກເຮົາສາມາດພິມຊົດເຊີຍຂອງທີ່ຢູ່ທີ່ນີ້, ເຊິ່ງສາມາດໄດ້ຮັບການແມຕໍ່ມາທີ່ຈະທໍາງານໃຫ້ຖືກຕ້ອງ.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // ພິມດັດຊະນີຂອງພາເຊັ່ນດຽວກັນກັບຄໍາແນະນໍາແລະຊີ້ທາງເລືອກຂອງພາໄດ້.
        // ຖ້າພວກເຮົາຢູ່ ເໜືອ ສັນຍາລັກ ທຳ ອິດຂອງກອບນີ້ເຖິງແມ່ນວ່າພວກເຮົາພຽງແຕ່ພິມ whitespace ທີ່ ເໝາະ ສົມ.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // ເຖິງຂຽນໄປອອກຊື່ສັນຍາລັກ, ການນໍາໃຊ້ທາງເລືອກໄດ້ຮູບແບບສໍາລັບຂໍ້ມູນເພີ່ມເຕີມຖ້າຫາກວ່າພວກເຮົາກໍາລັງເປັນ backtrace ຢ່າງເຕັມທີ່.
        // ນີ້ພວກເຮົາຍັງຈັດການເຄ່ືທີ່ບໍ່ມີຊື່,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // ແລະສຸດທ້າຍ, ພິມ ຈຳ ນວນ filename/line ຖ້າມີ.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line ຖືກພິມໃສ່ບັນດາສາຍຢູ່ພາຍໃຕ້ຊື່ສັນຍາລັກ, ສະນັ້ນພິມສະຖານທີ່ທີ່ ເໝາະ ສົມເພື່ອຈັດຮຽງແບບທີ່ຖືກຕ້ອງ.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // ສົ່ງຕົວແທນໃຫ້ກັບການໂທພາຍໃນຂອງພວກເຮົາເພື່ອພິມຊື່ແລະຫຼັງຈາກນັ້ນພິມເບີໂທລະສັບອອກ.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // ເພີ່ມ ໝາຍ ເລກຖັນ, ຖ້າມີ.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // ພວກເຮົາເອົາໃຈໃສ່ພຽງແຕ່ສັນຍາລັກ ທຳ ອິດຂອງກອບ
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}