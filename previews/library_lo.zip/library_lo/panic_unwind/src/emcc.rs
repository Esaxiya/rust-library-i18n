//! ຄວາມບໍ່ປາດຖະ ໜາ ສຳ ລັບເປົ້າ ໝາຍ *emscripten*.
//!
//! ໃນຂະນະທີ່ການປະຕິບັດ unwinding Rust ຂອງປົກກະຕິສໍາລັບ Unix ເວທີການໂທເຂົ້າໄປໃນ APIs libunwind ໂດຍກົງ, ໃນ Emscripten ພວກເຮົາແທນທີ່ຈະປຸກລະດົມ C ໄດ້ ++ ຄາຍ APIs.
//! ນີ້ແມ່ນພຽງແຕ່ການເລັ່ງລັດນັບຕັ້ງແຕ່ເວລາແລ່ນຂອງ Emscripten ສະເຫມີປະຕິບັດ API ເຫຼົ່ານັ້ນແລະບໍ່ປະຕິບັດ libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// ນີ້ກົງກັບຮູບລັກຂອງ std::type_info ໃນ C ທີ່ ++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // ຕົວເລກ `\x01` ຊັ້ນ ນຳ ໃນທີ່ນີ້ແມ່ນສັນຍານອັນມະຫັດສະຈັນໃຫ້ LLVM ເຖິງ *ບໍ່* ໃຊ້ວິທີການອື່ນໆທີ່ຄ້າຍຄືກັບ ຄຳ ນຳ ໜ້າ ທີ່ມີຕົວລະຫັດ `_`.
    //
    //
    // ສັນຍາລັກນີ້ແມ່ນ vtable ທີ່ໃຊ້ໂດຍ `std::type_info` s C++ .
    // ຈຸດປະສົງຂອງປະເພດ `std::type_info`, ປະເພດການອະທິບາຍມີຕົວຊີ້ໄປຕາຕະລາງນີ້.
    // ອະທິບາຍປະເພດມີການອ້າງອິງໂດຍໂຄງສ້າງຂອງ C++ EH ກໍານົດຂ້າງເທິງນີ້ແລະພວກເຮົາກໍ່ສ້າງຕ່ໍາກວ່າ.
    //
    // ໃຫ້ສັງເກດວ່າຂະ ໜາດ ທີ່ແທ້ຈິງມີຂະ ໜາດ ໃຫຍ່ກ່ວາ 3 ຂະ ໜາດ, ແຕ່ພວກເຮົາຕ້ອງການພຽງວັກຂອງພວກເຮົາເພື່ອຊີ້ໄປຫາອົງປະກອບທີສາມ.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info ສຳ ລັບຊັ້ນຮຽນ rust_panic
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // ຕາມປົກກະຕິພວກເຮົາຈະໃຊ້ .as_ptr().add(2) ແຕ່ນີ້ບໍ່ໄດ້ເຮັດວຽກຢູ່ໃນບໍລິບົດ const.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // ນີ້ມີເຈດຕະນາບໍ່ໄດ້ໃຊ້ລະບົບຊື່ mangled ປົກກະຕິເພາະວ່າພວກເຮົາບໍ່ຕ້ອງການ C++ ເພື່ອໃຫ້ສາມາດຜະລິດຫຼືຈັບ Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // ນີ້ແມ່ນມີຄວາມຈໍາເປັນເນື່ອງຈາກວ່າ C++ ລະຫັດສາມາດເກັບກໍາ execption ຂອງພວກເຮົາກັບ std::exception_ptr ແລະ rethrow ເວລາຫຼາຍ, ເປັນໄປໄດ້ແມ້ແຕ່ຢູ່ໃນກະທູ້ອື່ນ.
    //
    //
    caught: AtomicBool,

    // ນີ້ ຈຳ ເປັນຕ້ອງເປັນ Option ເພາະວ່າອາຍຸການໃຊ້ງານຂອງວັດຖຸປະຕິບັດຕາມ C++ semantics: ເມື່ອຈັບ_unwindຍ້າຍ Box ອອກຈາກຂໍ້ຍົກເວັ້ນມັນຍັງຕ້ອງປ່ອຍວັດຖຸທີ່ຍົກເວັ້ນໄວ້ໃນສະພາບທີ່ຖືກຕ້ອງເພາະຜູ້ ທຳ ລາຍຂອງມັນຍັງຈະຖືກເອີ້ນໂດຍ __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try ໃນຕົວຈິງແມ່ນໃຫ້ພວກເຮົາຊີ້ແຈງໂຄງສ້າງນີ້.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // ເນື່ອງຈາກວ່າ cleanup() ບໍ່ໄດ້ອະນຸຍາດໃຫ້ panic, ພວກເຮົາພຽງແຕ່ຈະເອົາລູກອອກແທນທີ່ຈະເປັນ.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}