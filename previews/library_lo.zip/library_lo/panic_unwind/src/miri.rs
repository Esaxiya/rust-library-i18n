//! unwinding panics ສໍາລັບລີ.
use alloc::boxed::Box;
use core::any::Any;

// ປະເພດຂອງເຄື່ອງຈ່າຍເງິນທີ່ເຄື່ອງຈັກ Miri ຂະຫຍາຍພັນໂດຍບໍ່ຕ້ອງການຂອງພວກເຮົາ.
// ຕ້ອງມີຂະ ໜາດ ຕົວຊີ້.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// ຟັງຊັນພາຍນອກທີ່ໃຫ້ໂດຍ Miri ເພື່ອເລີ່ມຕົ້ນການບໍ່ປາດຖະ ໜາ.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // ການຈ່າຍເງິນທີ່ພວກເຮົາສົ່ງໄປ `miri_start_panic` ຈະເປັນການໂຕ້ຖຽງທີ່ພວກເຮົາໄດ້ຮັບໃນ `cleanup` ຢູ່ດ້ານລຸ່ມ.
    // ດັ່ງນັ້ນພວກເຮົາພຽງແຕ່ຫມາຍໃສ່ໃນປ່ອງມັນຂຶ້ນເມື່ອ, ເພື່ອໃຫ້ໄດ້ຮັບບາງສິ່ງບາງຢ່າງຊີ້ຂະຫນາດ.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // ກູ້ຄືນພື້ນຖານ `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}