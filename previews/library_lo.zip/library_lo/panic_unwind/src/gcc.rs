//! ການປະຕິບັດຂອງ panics ສະຫນັບສະຫນູນໂດຍ libgcc/libunwind (ໃນບາງຮູບແບບ).
//!
//! ສຳ ລັບພື້ນຖານກ່ຽວກັບການຈັດການຍົກເວັ້ນແລະການລອກແບບກະລຸນາເບິ່ງ "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) ແລະເອກະສານທີ່ເຊື່ອມໂຍງຈາກມັນ.
//! ເຫຼົ່ານີ້ແມ່ນຍັງອ່ານທີ່ດີ:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## ສະຫຼຸບໂດຍຫຍໍ້
//!
//! ການຈັດການຍົກເວັ້ນເກີດຂື້ນໃນສອງໄລຍະ: ໄລຍະການຄົ້ນຫາແລະໄລຍະ ທຳ ຄວາມສະອາດ.
//!
//! ໃນທັງສອງໄລຍະຜ່ອນຄາຍການຍ່າງເຟຣມ stack ແຕ່ເທິງລົງຫາການນໍາໃຊ້ຂໍ້ມູນຂ່າວສານທາງລຸ່ມຈາກພາ stack ພາກສ່ວນຜ່ອນຄາຍຂອງໂມດູນຂະບວນການໃນປະຈຸບັນຂອງ ("module" ທີ່ນີ້ຫມາຍເຖິງການລະບົບປະຕິບັດ, ie, ເປັນການບໍລິຫານຫຼືຫໍສະຫມຸດເຄື່ອນໄຫວ).
//!
//!
//! ສໍາລັບກອບ stack ແຕ່ລະ, ມັນຈະເອີ້ນໄດ້ກ່ຽວຂ້ອງ "personality routine", ທີ່ຢູ່ແມ່ນຖືກເກັບໄວ້ໃນພາກຂໍ້ມູນ unwind.
//!
//! ໃນໄລຍະຊອກຫາ, ວຽກເຮັດງານທໍາຂອງເປັນປົກກະຕິບຸກຄະລິກກະແມ່ນການສຶກສາຈຸດປະສົງຍົກເວັ້ນຖືກຖີ້ມ, ແລະຕັດສິນໃຈວ່າຄວນຈະໄດ້ຮັບຈັບໄດ້ຢູ່ໃນພາ stack ວ່າ.ເມື່ອລະບຸເຄື່ອງມືຂອງຜູ້ຈັດການແລ້ວ, ໄລຍະ ທຳ ຄວາມສະອາດເລີ່ມຕົ້ນ.
//!
//! ໃນໄລຍະທໍາຄວາມສະອາດ, ຜ່ອນຄາຍການເອີ້ນແຕ່ລະບຸກຄະລິກກະປົກກະຕິອີກເທື່ອຫນຶ່ງ.
//! ເວລານີ້ມັນຈະຕັດສິນໃຈວ່າລະຫັດໃດ (ຖ້າມີ) ລະຫັດການ ທຳ ຄວາມສະອາດ ຈຳ ເປັນຕ້ອງໄດ້ ດຳ ເນີນການ ສຳ ລັບກອບ stack ໃນປະຈຸບັນຖ້າເປັນດັ່ງນັ້ນ, ການຄວບຄຸມຈະຖືກໂອນໄປຫາ branch ພິເສດໃນຮ່າງກາຍທີ່ເຮັດວຽກ, "landing pad", ເຊິ່ງຮຽກຮ້ອງຜູ້ ທຳ ລາຍ, ປົດປ່ອຍຄວາມ ຈຳ, ແລະອື່ນໆ.
//! ໃນຕອນທ້າຍຂອງກະດານທີ່ດິນ, ການຄວບຄຸມໄດ້ຖືກໂອນກັບຄືນໄປບ່ອນຊີວະປະຫວັດຫຍໍ້ແລະຖີ້ມ.
//!
//! ເມື່ອ stack ໄດ້ຖືກ unwound ລົງໃນລະດັບພາ handler, ຢຸດເຊົາການຢຸດເຊົາການແລະບຸກຄົນສຸດທ້າຍການໂອນການຄວບຄຸມການຄວບຄຸມການກັບຕັນຈັບໄດ້.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// ຕົວລະບຸຊັ້ນຍົກເວັ້ນຂອງ Rust.
// ສິ່ງນີ້ຖືກ ນຳ ໃຊ້ໂດຍນິໄສບຸກຄະລິກກະພາບເພື່ອ ກຳ ນົດວ່າຂໍ້ຍົກເວັ້ນຖືກຖີ້ມໂດຍເວລາແລ່ນຂອງຕົວເອງ.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-ຜູ້ຂາຍ, ພາສາ
    0x4d4f5a_00_52555354
}

// ລົງທະບຽນ ids ໄດ້ຮັບການຍົກຈາກ LLVM ຂອງ TargetLowering::getExceptionPointerRegister() ແລະ TargetLowering::getExceptionSelectorRegister() ສໍາລັບແຕ່ລະສະຖາປັດຕະ, ແມຫຼັງຈາກນັ້ນຈໍານວນສະມາຊິກ dwarf ຜ່ານຕາຕະລາງຄໍານິຍາມລົງທະບຽນ (ຕາມປົກກະຕິ<arch>RegisterInfo.td, ຄົ້ນຫາສໍາລັບ "DwarfRegNum").
//
// ເບິ່ງທີ່ http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// ລະຫັດດັ່ງຕໍ່ໄປນີ້ແມ່ນອີງໃສ່ GCC ຂອງ C ແລະ C++ ປົກກະຕິບຸກຄະລິກ.ສໍາລັບອ້າງອິງ, ເບິ່ງ:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM ນິໄສບຸກຄະລິກກະພາບ EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS ນໍາໃຊ້ປົກກະໄວ້ໃນຕອນຕົ້ນແທນທີ່ຈະນັບຕັ້ງແຕ່ມັນໃຊ້ SjLj unwinding.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // Backtraces ກ່ຽວກັບ ARM ຈະໂທຫານິໄສບຸກຄະລິກກະພາບກັບລັດ==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // ໃນກໍລະນີທີ່ພວກເຮົາຕ້ອງການທີ່ຈະສືບຕໍ່ຄາຍ stack ໄດ້, backtrace ຂອງພວກເຮົາຖ້າບໍ່ດັ່ງນັ້ນທັງຫມົດຈະສິ້ນສຸດຢູ່ __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // ການຜ່ອນຄາຍ dwarf ອະນຸມານວ່າ _Unwind_Context ຖືສິ່ງຕ່າງໆເຊັ່ນວ່າການທໍາງານແລະ pointers LSDA, ຢ່າງໃດກໍຕາມ ARM EHABI places ໃຫ້ເຂົາເຈົ້າເຂົ້າໄປໃນວັດຖຸມີຂໍ້ຍົກເວັ້ນ.
            // ເພື່ອປົກປັກຮັກສາລາຍເຊັນຂອງປະຕິບັດຫນ້າເຊັ່ນ: _Unwind_GetLanguageSpecificData(), ເຊິ່ງໃຊ້ເວລາພຽງແຕ່ຊີ້ສະພາບການ, GCC ປະຕິບັດບຸກຄະລິກກະ stash ຕົວຊີ້ໄປຍັງ exception_object ໃນສະພາບການ, ການນໍາໃຊ້ສະຖານທີ່ສະຫງວນສໍາລັບ ARM ຂອງ "scratch register" (r12).
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... ວິທີການອາໄສຫຼັກຫຼາຍຈະເປັນການສະຫນອງຄໍານິຍາມເຕັມໄປດ້ວຍ ARM ຂອງ _Unwind_Context ໃນການຈັບ libunwind ຂອງພວກເຮົາແລະດຶງຂໍ້ມູນຂໍ້ມູນທີ່ກໍານົດໄວ້ຈາກມີໂດຍກົງ, bypassing ປະຕິບັດຫນ້າທີ່ເຫມາະສົມ dwarf.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI ຮຽກຮ້ອງໃຫ້ມີການປັບປຸງຄຸນລັກສະນະຂອງບຸກຄະລິກກະພາບໃຫ້ມີການປັບປຸງຄຸນຄ່າ SP ໃນບ່ອນເກັບມ້ຽນອຸປະສັກຂອງວັດຖຸທີ່ຍົກເວັ້ນ.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // On ARM EHABI ປົກກະຕິບຸກຄະລິກກະແມ່ນຮັບຜິດຊອບສໍາລັບການຕົວຈິງຄາຍພາ stack ດຽວກ່ອນກັບຄືນ (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // ກໍານົດໃນ libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // ຄວາມເປັນປົກກະຕິຂອງບຸກຄະລິກລັກສະນະ, ເຊິ່ງຖືກ ນຳ ໃຊ້ໂດຍກົງກັບເປົ້າ ໝາຍ ສ່ວນໃຫຍ່ແລະທາງອ້ອມໃນ Windows x86_64 ຜ່ານ SEH.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // ກ່ຽວກັບຄາດຫມາຍສູ້ຊົນ x86_64 MinGW, ກົນໄກຄາຍແມ່ນ SEH ຢ່າງໃດກໍຕາມຂໍ້ມູນ handler ຜ່ອນຄາຍ (aka LSDA) ໃຊ້ການເຂົ້າລະຫັດ GCC, ເຫມາະສົມ.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // ນິດໄສໃຈຄໍປົກກະຕິສໍາລັບການຫຼາຍທີ່ສຸດຂອງເປົ້າຫມາຍຂອງພວກເຮົາ.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // ທີ່ຢູ່ກັບຄືນຊີ້ 1 byte ທີ່ຜ່ານມາຄໍາແນະນໍາແລະການໂທຊຶ່ງອາດຈະຢູ່ໃນລະດັບ IP ຕໍ່ໄປໃນຕາຕະລາງລະດັບ LSDA.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// ຂອບການລົງທະບຽນຂໍ້ມູນ
//
// ຮູບພາບແຕ່ລະໂມດູນຂອງປະກອບດ້ວຍພາຜ່ອນຄາຍສ່ວນຂໍ້ມູນ (ຕາມປົກກະຕິ ".eh_frame").ໃນເວລາທີ່ໂມດູນ loaded/unloaded ເຂົ້າໄປໃນຂະບວນການ, ຜ່ອນຄາຍໄດ້ຕ້ອງໄດ້ຮັບການແຈ້ງໃຫ້ຊາບກ່ຽວກັບສະຖານທີ່ຂອງພາກນີ້ໃນຄວາມຊົງຈໍາໄດ້.ວິທີການຂອງການບັນລຸທີ່ແຕກຕ່າງກັນໂດຍທີ່ເວທີ.
// ໃນບາງ (eg, Linux), ຜ່ອນຄາຍສາມາດຄົ້ນພົບພາກສ່ວນຂໍ້ມູນຜ່ອນຄາຍເທິງຂອງຕົນເອງ (ໂດຍນະໂຍບາຍດ້ານການຈາລະໄນໂມດູນໂຫລດໃນປັດຈຸບັນໂດຍຜ່ານການ dl_iterate_phdr() API and finding their ".eh_frame" sections); ອື່ນໆເຊັ່ນ: Windows, ຮຽກຮ້ອງໃຫ້ມີລະຫັດຢ່າງຈິງຈັງລົງທະບຽນພາກສ່ວນຂໍ້ມູນຜ່ອນຄາຍຂອງພວກເຂົາຜ່ານຜ່ອນຄາຍ API.
//
//
// ໂມດູນນີ້ໄດ້ກໍານົດສອງສັນຍາລັກທີ່ມີການອ້າງອິງແລະໄດ້ຮຽກຮ້ອງຈາກ rsbegin.rs ລົງທະບຽນຂໍ້ມູນຂ່າວສານຂອງພວກເຮົາກັບ runtime GCC.
// ການປະຕິບັດຂອງ stack unwinding ແມ່ນ (ສໍາລັບໃນປັດຈຸບັນ) ເລື່ອນກັບ libgcc_eh, ຢ່າງໃດກໍຕາມ Rust crates ໃຊ້ເຫຼົ່ານີ້ຈຸດເຂົ້າ Rust ສະເພາະເພື່ອຫຼີກເວັ້ນການປະທະກັນອາດເກີດຂຶ້ນກັບທຸກ runtime GCC.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}