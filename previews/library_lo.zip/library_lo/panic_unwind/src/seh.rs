//! Windows SEH
//!
//! ໃນ Windows (ປະຈຸບັນມີຢູ່ໃນ MSVC ເທົ່ານັ້ນ), ກົນໄກການຈັດການຍົກເວັ້ນຄ່າເລີ່ມຕົ້ນແມ່ນ Structured Exception Handling (SEH).
//! ນີ້ແມ່ນແຕກຕ່າງກັນຫຼາຍກ່ວາການຈັດການການຍົກເວັ້ນທີ່ອີງໃສ່ Dwarf (ຕົວຢ່າງ, ສິ່ງທີ່ unix ອື່ນໆໃຊ້) ໃນແງ່ຂອງນັກຂຽນພາຍໃນ, ດັ່ງນັ້ນ LLVM ຈຳ ເປັນຕ້ອງມີການສະ ໜັບ ສະ ໜູນ ທີ່ດີຕໍ່ SEH.
//!
//! ໃນ nutshell ເປັນ, ສິ່ງທີ່ເກີດຂຶ້ນນີ້ແມ່ນ:
//!
//! 1. ຟັງຊັນ `panic` ເອີ້ນການເຮັດວຽກ Windows ມາດຕະຖານ `_CxxThrowException` ໃຫ້ຖິ້ມ C++ -ຄ້າຍຄືກັບຂໍ້ຍົກເວັ້ນ, ເຮັດໃຫ້ຂະບວນການບໍ່ສົມຄວນ.
//! 2.
//! ທັງຫມົດ pads ເຊື່ອມໂຍງໄປເຖິງສ້າງຂຶ້ນໂດຍ compiler ໄດ້ນໍາໃຊ້ການທໍາງານຂອງບຸກຄະລິກກະ `__CxxFrameHandler3`, ການທໍາງານຂອງໃນ CRT ແລະລະຫັດຄາຍໃນ Windows ຈະນໍາໃຊ້ການທໍາງານຂອງບຸກຄົນນີ້ປະຕິບັດລະຫັດອະນາໄມຄາບທັງຫມົດໃນ stack ໄດ້.
//!
//! 3. ທຸກໆການໂທທີ່ສ້າງຂື້ນມາເພື່ອ `invoke` ມີແຜ່ນດິນທີ່ ກຳ ນົດໄວ້ເປັນ ຄຳ ແນະ ນຳ `cleanuppad` LLVM, ເຊິ່ງສະແດງເຖິງການເລີ່ມຕົ້ນຂອງການ ທຳ ຄວາມສະອາດປົກກະຕິ.
//! ນິດໄສໃຈຄໍ (ໃນຂັ້ນຕອນທີ່ 2, ກໍານົດໃນ CRT ໄດ້) ຮັບຜິດຊອບສໍາລັບການເຮັດວຽກປົກກະຕິທໍາຄວາມສະອາດໄດ້.
//! 4. ໃນທີ່ສຸດລະຫັດ "catch" ໃນ `try` intrinsic (ສ້າງໂດຍຜູ້ຂຽນ) ຖືກປະຕິບັດແລະຊີ້ໃຫ້ເຫັນວ່າການຄວບຄຸມຄວນຈະກັບມາ Rust.
//! ນີ້ແມ່ນເຮັດໄດ້ໂດຍຜ່ານການ `catchswitch` ບວກຄໍາແນະນໍາ `catchpad` ໃນຂໍ້ກໍານົດ LLVM IR, ສຸດທ້າຍກັບຄືນການຄວບຄຸມປົກກະຕິຂອງໂຄງການທີ່ມີຄໍາແນະນໍາແລະ `catchret`.
//!
//! ບາງຄວາມແຕກຕ່າງສະເພາະໃດຫນຶ່ງຈາກການຮັກສາຫຼັງຍົກເວັ້ນ gcc ທີ່ມີ:
//!
//! * Rust ບໍ່ມີ ໜ້າ ທີ່ບຸກຄະລິກລັກສະນະ, ມັນແທນທີ່ຈະ *ສະ ເໝີ*`__CxxFrameHandler3`.ນອກຈາກນີ້, ບໍ່ມີການກັ່ນຕອງເປັນພິເສດແມ່ນປະຕິບັດ, ດັ່ງນັ້ນພວກເຮົາໃນທີ່ສຸດຫມາຍເຖິງການຈັບ C++ ຍົກເວັ້ນທີ່ເກີດຂຶ້ນກັບລັກສະນະເຊັ່ນຊະນິດທີ່ພວກເຮົາກໍາລັງ throwing.
//! ໃຫ້ສັງເກດວ່າການຍົກເວັ້ນການຍົກເວັ້ນເຂົ້າໄປໃນ Rust ແມ່ນພຶດຕິກໍາທີ່ບໍ່ໄດ້ກໍານົດຢ່າງໃດກໍ່ຕາມ, ດັ່ງນັ້ນນີ້ຄວນຈະດີ.
//! * ພວກເຮົາໄດ້ຮັບຂໍ້ມູນບາງຢ່າງທີ່ຈະສົ່ງຂ້າມຊາຍແດນຄາຍ, ໂດຍສະເພາະເປັນ `Box<dyn Any + Send>`.ເຊັ່ນດຽວກັນກັບຂໍ້ຍົກເວັ້ນຂອງ Dwarf ສອງຕົວຊີ້ບອກນີ້ຖືກເກັບໄວ້ເປັນໃບເກັບເງິນໃນຂໍ້ຍົກເວັ້ນຂອງມັນເອງ.
//! ໃນ MSVC, ຢ່າງໃດກໍຕາມ, ມີຄວາມຕ້ອງການສໍາລັບການຈັດສັນ heap ພິເສດທີ່ບໍ່ມີເພາະວ່າແຕກການເອີ້ນຖືກຮັກສາໄວ້ໃນຂະນະທີ່ປະຕິບັດຫນ້າກອງກໍາລັງຖືກປະຕິບັດ.
//! ນີ້ຫມາຍຄວາມວ່າຕົວຊີ້ຖືກສົ່ງໂດຍກົງໄປທີ່ `_CxxThrowException` ເຊິ່ງຫຼັງຈາກນັ້ນໄດ້ຖືກເກັບຄືນໃນຫນ້າທີ່ການກັ່ນຕອງທີ່ຈະຖືກຂຽນເຂົ້າໄປໃນກອບ stack ຂອງ `try` intrinsic.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // ຄວາມຕ້ອງການນີ້ຈະເປັນທາງເລືອກເພາະວ່າພວກເຮົາຈັບຍົກເວັ້ນໂດຍອ້າງອິງແລະ destructor ຂອງຕົນຖືກດໍາເນີນການໂດຍ C runtime ໄດ້ ++.
    // ໃນເວລາທີ່ພວກເຮົາໃຊ້ເວລາໃນກ່ອງຈາກຂໍ້ຍົກເວັ້ນ, ພວກເຮົາຈໍາເປັນຕ້ອງໄດ້ອອກຈາກຂໍ້ຍົກເວັ້ນໃນສະຖານະທີ່ຖືກຕ້ອງສໍາລັບ destructor ຂອງຕົນໃນການດໍາເນີນການໂດຍບໍ່ມີການ double ເລີ່ມຫຼຸດລົງເລື້ອຍຕູ້ໄດ້.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// ເຖິງຄັ້ງທໍາອິດ, ເປັນຊໍ່ທັງຫມົດຂອງປະເພດຄໍານິຍາມ.ມີບໍ່ຫຼາຍປານໃດ oddities ເວທີສະເພາະໃດຫນຶ່ງຢູ່ທີ່ນີ້, ແລະຫຼາຍທີ່ຄັດລອກພຽງແຕ່ blatantly ຈາກ LLVM ເປັນເປັນ.ຈຸດປະສົງຂອງທັງຫມົດນີ້ແມ່ນເພື່ອປະຕິບັດການທໍາງານຂອງ `panic` ຕ່ໍາກວ່າໂດຍຜ່ານການໂທກັບ `_CxxThrowException` ໄດ້.
//
// ຟັງຊັນນີ້ໃຊ້ເວລາທັງສອງກະທູ້.ທໍາອິດເປັນຕົວຊີ້ເຖິງຂໍ້ມູນທີ່ພວກເຮົາກໍາລັງຜ່ານ, ຊຶ່ງໃນກໍລະນີນີ້ແມ່ນວັດຖຸ trait ຂອງພວກເຮົາໄດ້.pretty ໄດ້ງ່າຍເພື່ອຊອກຫາ!ຕໍ່ໄປ, ຢ່າງໃດກໍຕາມ, ແມ່ນສັບສົນຫຼາຍ.
// ນີ້ແມ່ນຕົວຊີ້ໄປຫາໂຄງສ້າງ `_ThrowInfo`, ແລະໂດຍທົ່ວໄປແລ້ວມັນມີຈຸດປະສົງພຽງແຕ່ອະທິບາຍຂໍ້ຍົກເວັ້ນທີ່ຖືກຖີ້ມ.
//
// ໃນປະຈຸບັນ ຄຳ ນິຍາມຂອງ [1] ຊະນິດນີ້ແມ່ນມີຂົນ ໜ້ອຍ ໜຶ່ງ, ແລະຄວາມແປກທີ່ ສຳ ຄັນ (ແລະຄວາມແຕກຕ່າງຈາກບົດຂຽນ online) ແມ່ນວ່າໃນ 32-bit ຕົວຊີ້ແມ່ນຈຸດແຕ່ວ່າ 64-bit ຕົວຊີ້ແມ່ນສະແດງອອກເປັນ 32-bit outets ຈາກ `__ImageBase` ສັນຍາລັກ.
//
// ມະຫາພາກ `ptr_t` ແລະ `ptr!` ໃນໂມດູນຂ້າງລຸ່ມນີ້ຖືກໃຊ້ເພື່ອສະແດງສິ່ງນີ້.
//
// ຄວາມສັບສົນຂອງ ຄຳ ນິຍາມປະເພດຍັງປະຕິບັດຕາມຢ່າງໃກ້ຊິດກັບສິ່ງທີ່ LLVM ເຮັດໃນການ ດຳ ເນີນງານແບບນີ້.ຍົກຕົວຢ່າງ, ຖ້າທ່ານລວບລວມລະຫັດ C++ ນີ້ໃນ MSVC ແລະປ່ອຍຕົວ LLVM IR:
//
//      #include <stdint.h>
//
//      ໂຄງສ້າງ rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      void foo() { rust_panic a = {0, 1};
//          ຖິ້ມ a;}
//
// ນັ້ນແມ່ນສິ່ງທີ່ພວກເຮົາ ກຳ ລັງພະຍາຍາມເຮັດຕາມ.ສ່ວນໃຫຍ່ຂອງຄ່າຄົງທີ່ຕ່ໍາກວ່າໄດ້ຖືກຄັດລອກມາຈາກ LLVM,
//
// ໃນກໍລະນີໃດກໍ່ຕາມ, ໂຄງການເຫຼົ່ານີ້ແມ່ນການກໍ່ສ້າງທັງຫມົດໃນລັກສະນະທີ່ຄ້າຍຄືກັນ, ແລະມັນເປັນພຽງແຕ່ຮ່ອງ verbose ສໍາລັບພວກເຮົາ.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// ໝາຍ ເຫດ: ພວກເຮົາບໍ່ສົນໃຈກົດລະບຽບຂອງການຕັ້ງຊື່ທີ່ນີ້ໂດຍເຈດຕະນາ: ພວກເຮົາບໍ່ຕ້ອງການໃຫ້ C++ ສາມາດຈັບ Rust panics ໂດຍການປະກາດ `struct rust_panic`.
//
//
// ເມື່ອດັດແປງ, ໃຫ້ແນ່ໃຈວ່າສາຍຊື່ປະເພດກົງກັບຊື່ທີ່ໃຊ້ໃນ `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // ຕົວເລກ `\x01` ຊັ້ນ ນຳ ໃນທີ່ນີ້ແມ່ນສັນຍານອັນມະຫັດສະຈັນໃຫ້ LLVM ເຖິງ *ບໍ່* ໃຊ້ວິທີການອື່ນໆທີ່ຄ້າຍຄືກັບ ຄຳ ນຳ ໜ້າ ທີ່ມີຕົວລະຫັດ `_`.
    //
    //
    // ສັນຍາລັກນີ້ແມ່ນ vtable ທີ່ໃຊ້ໂດຍ `std::type_info` s C++ .
    // ຈຸດປະສົງຂອງປະເພດ `std::type_info`, ປະເພດການອະທິບາຍມີຕົວຊີ້ໄປຕາຕະລາງນີ້.
    // ອະທິບາຍປະເພດມີການອ້າງອິງໂດຍໂຄງສ້າງຂອງ C++ EH ກໍານົດຂ້າງເທິງນີ້ແລະພວກເຮົາກໍ່ສ້າງຕ່ໍາກວ່າ.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// ຜູ້ບັນຍາຍປະເພດນີ້ແມ່ນໃຊ້ໃນເວລາທີ່ມີການຍົກເວັ້ນ.
// ການຈັບສ່ວນຈັດການໂດຍ intrinsic ພະຍາຍາມທີ່ຈະສ້າງ TypeDescriptor ຂອງຕົນເອງ.
//
// ນີ້ແມ່ນດີນັບຕັ້ງແຕ່ເວລາແລ່ນຂອງ MSVC ໃຊ້ການປຽບທຽບສາຍເທິງຊື່ປະເພດເພື່ອໃຫ້ກົງກັບ TypeDescriptors ແທນທີ່ຈະທຽບເທົ່າກັບຕົວຊີ້.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor ໃຊ້ຖ້າລະຫັດ C++ ຕັດສິນໃຈຈັບຂໍ້ຍົກເວັ້ນແລະວາງລົງໂດຍບໍ່ຕ້ອງເຜີຍແຜ່ມັນ.
// ການຈັບສ່ວນຫນຶ່ງຂອງການຊໍາລະພະຍາຍາມທີ່ຈະກໍານົດຄໍາທໍາອິດຂອງວັດຖຸຂໍ້ຍົກເວັ້ນທີ່ຈະ 0 ດັ່ງນັ້ນມັນແມ່ນຂ້າມໂດຍ destructor ໄດ້.
//
// ໃຫ້ສັງເກດວ່າ x86 Windows ໃຊ້ສົນທິສັນຍາການໂທ "thiscall" ສຳ ລັບ ໜ້າ ທີ່ຂອງສະມາຊິກ C++ ແທນທີ່ຈະມີສົນທິສັນຍາການໂທ "C" ໃນຕອນຕົ້ນ.
//
// ຟັງຊັນ exception_copy ແມ່ນພິເສດທີ່ນີ້: ມັນຖືກຮຽກຮ້ອງໂດຍເວລາແລ່ນ MSVC ພາຍໃຕ້ທ່ອນ try/catch ແລະ panic ທີ່ພວກເຮົາຜະລິດຢູ່ນີ້ຈະຖືກ ນຳ ໃຊ້ເປັນຜົນມາຈາກການ ສຳ ເນົາຍົກເວັ້ນ.
//
// ນີ້ໄດ້ຖືກນໍາໃຊ້ໂດຍ C runtime++ ເພື່ອສະຫນັບສະຫນູນການຍົກເວັ້ນຍາດເອົາກັບ std::exception_ptr, ຊຶ່ງພວກເຮົາບໍ່ສາມາດສະຫນັບສະຫນູນເນື່ອງຈາກວ່າກ່ອງ<dyn Any>ບໍ່ແມ່ນ clonable.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException ການບໍລິຫານທັງຫມົດກອບ stack ນີ້, ສະນັ້ນມີຄວາມຈໍາເປັນຕ້ອງຖ້າບໍ່ດັ່ງນັ້ນໂອນ `data` ກັບ heap ໄດ້.
    // ພວກເຮົາພຽງແຕ່ສົ່ງຕົວຊີ້ຊີ້ກະບອກໃສ່ ໜ້າ ທີ່ນີ້.
    //
    // The ManuallyDrop ແມ່ນມີຄວາມ ຈຳ ເປັນຢູ່ທີ່ນີ້ຍ້ອນວ່າພວກເຮົາບໍ່ຕ້ອງການຍົກເວັ້ນທີ່ຈະຖືກຍົກເລີກເມື່ອບໍ່ຕ້ອງການ.
    // ແທນທີ່ມັນຈະຖືກຖີ້ມໂດຍ exception_cleanup ເຊິ່ງຈະຖືກເອີ້ນໂດຍ C++ ເວລາແລ່ນ.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // ນີ້ ... ອາດເບິ່ງຄືວ່າ ໜ້າ ແປກໃຈ, ແລະສົມເຫດສົມຜົນ.ກ່ຽວກັບ MSVC 32 ບິດ, ຕົວຊີ້ວັດລະຫວ່າງໂຄງສ້າງເຫຼົ່ານີ້ແມ່ນພຽງແຕ່ເທົ່ານັ້ນ, ຜູ້ຊີ້ ນຳ.
    // ກ່ຽວກັບ MSVC 64 ບິດ, ແນວໃດກໍ່ຕາມ, ຕົວຊີ້ວັດລະຫວ່າງໂຄງສ້າງແມ່ນສະແດງອອກເປັນ 32-bit ຈາກ `__ImageBase`.
    //
    // ຜົນສະທ້ອນ, ໃນ 32-bit MSVC ພວກເຮົາສາມາດປະກາດ pointers ທັງຫມົດເຫຼົ່ານີ້ຢູ່ໃນ `static`s ຂ້າງເທິງ.
    // ກ່ຽວກັບ MSVC 64 ບິດ, ພວກເຮົາຈະຕ້ອງສະແດງການຫັກລົບຂອງຕົວຊີ້ຢູ່ໃນສະຖິຕິ, ເຊິ່ງ Rust ບໍ່ອະນຸຍາດໃຫ້ປະຈຸບັນ, ດັ່ງນັ້ນພວກເຮົາບໍ່ສາມາດເຮັດສິ່ງນັ້ນໄດ້.
    //
    // ສິ່ງທີ່ດີທີ່ສຸດຕໍ່ໄປ, ຫຼັງຈາກນັ້ນແມ່ນການຕື່ມຂໍ້ມູນໃສ່ໂຄງສ້າງເຫຼົ່ານີ້ໃນເວລາແລ່ນ (ການຕົກຕະລຶງແມ່ນ "slow path" ຢູ່ແລ້ວ).
    // ດັ່ງນັ້ນໃນທີ່ນີ້ພວກເຮົາ reinterpret ທັງຫມົດຂອງທົ່ງນາຊີ້ເຫລົ່ານີ້ເປັນຈໍານວນເຕັມ 32-bit ແລະຫຼັງຈາກນັ້ນເກັບຮັກສາມູນຄ່າທີ່ກ່ຽວຂ້ອງເຂົ້າໄປໃນມັນ (atomically, ເປັນ concurrent panics ອາດຈະເກີດຂຶ້ນ).
    //
    // ດ້ານວິຊາການ runtime ທີ່ອາດຈະດໍາເນີນການອ່ານ nonatomic ຂອງຂົງເຂດເຫຼົ່ານີ້, ແຕ່ວ່າໃນທິດສະດີທີ່ເຂົາເຈົ້າບໍ່ເຄີຍອ່ານຜິດພາດ * * ມູນຄ່າສະນັ້ນມັນບໍ່ຄວນຈະເປັນດີເກີນໄປ ...
    //
    // ໃນກໍລະນີໃດກໍ່ຕາມ, ພວກເຮົາໂດຍພື້ນຖານແລ້ວຕ້ອງເຮັດບາງສິ່ງບາງຢ່າງເຊັ່ນນີ້ຈົນກວ່າພວກເຮົາສາມາດສະແດງການປະຕິບັດງານຫຼາຍຂື້ນໃນສະຖິຕິ (ແລະພວກເຮົາອາດຈະບໍ່ສາມາດເຮັດໄດ້)
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // A payload NULL ຢູ່ທີ່ນີ້ ໝາຍ ຄວາມວ່າພວກເຮົາມາທີ່ນີ້ຈາກ (...) ຂອງ __rust_try.
    // ນີ້ເກີດຂື້ນເມື່ອການຍົກເວັ້ນຕ່າງປະເທດທີ່ບໍ່ແມ່ນ Rust ຖືກຈັບ.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// ນີ້ທີ່ກໍານົດໄວ້ໂດຍ compiler ເພື່ອມີ (eg, ມັນເປັນລາຍການ lang), ແຕ່ວ່າມັນບໍ່ເຄີຍເອີ້ນວ່າຕົວຈິງໂດຍ compiler ໄດ້ເນື່ອງຈາກວ່າ __C_specific_handler ຫຼື _except_handler3 ແມ່ນຫນ້າທີ່ບຸກຄົນທີ່ຖືກນໍາໃຊ້ສະເຫມີໄປ.
//
// ເພາະສະນັ້ນນີ້ແມ່ນພຽງແຕ່ເປັນຫົວສົ້ນໃບຮັບ aborting.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}