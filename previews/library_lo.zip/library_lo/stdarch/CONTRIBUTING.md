# ປະກອບສ່ວນໃຫ້ stdarch

The `stdarch` crate ແມ່ນຫຼາຍກ່ວາມຸ່ງຫມັ້ນທີ່ຈະຍອມຮັບການປະກອບສ່ວນ!ກ່ອນອື່ນທ່ານອາດຈະຕ້ອງການກວດເບິ່ງຫ້ອງສະ ໝຸດ ແລະໃຫ້ແນ່ໃຈວ່າການທົດສອບຈະຜ່ານ ສຳ ລັບທ່ານ:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

ບ່ອນທີ່ `<your-target-arch>` ແມ່ນເປົ້າ ໝາຍ 3 ເທົ່າທີ່ໃຊ້ໂດຍ `rustup`, ຕົວຢ່າງ `x86_x64-unknown-linux-gnu` (ໂດຍບໍ່ມີ `nightly-` ກ່ອນຫຼືຄ້າຍຄືກັນ).
ຍັງຈື່ໄດ້ວ່າຫໍສະມຸດແຫ່ງນີ້ຕ້ອງໃຊ້ຊ່ອງທາງໃນຕອນກາງຄືນຂອງ Rust!
ການທົດສອບຂ້າງເທິງນີ້ເຮັດໃນຄວາມເປັນຈິງຮຽກຮ້ອງໃຫ້ມີຄືນ rust ຈະເລີ່ມຕົ້ນໃນລະບົບຂອງທ່ານ, ເພື່ອກໍານົດວ່າການນໍາໃຊ້ `rustup default nightly` (ແລະ `rustup default stable` ກັບ revert).

ຖ້າຄົນໃດໃນຂັ້ນຕອນຂ້າງເທິງນີ້ບໍ່ໄດ້ເຮັດວຽກ, [please let us know][new]!

ຕໍ່ໄປທ່ານສາມາດ [find an issue][issues] ເພື່ອຊ່ວຍພວກເຮົາ, ພວກເຮົາໄດ້ເລືອກເອົາສອງສາມປ້າຍທີ່ມີ [`help wanted`][help] ແລະ [`impl-period`][impl] ເຊິ່ງໂດຍສະເພາະແມ່ນສາມາດໃຊ້ການຊ່ວຍເຫຼືອບາງຢ່າງ. 
ທ່ານອາດຈະສົນໃຈຫລາຍທີ່ສຸດໃນ [#40][vendor], ຈັດຕັ້ງປະຕິບັດການຂາຍຂອງຜູ້ຂາຍທັງ ໝົດ ໃນ x86.ວ່າບັນຫາຂອງມາບາງຄໍາແນະນໍາທີ່ດີກ່ຽວກັບບ່ອນທີ່ຈະເລີ່ມຕົ້ນໄດ້?

ຖ້າທ່ານມີ ຄຳ ຖາມທົ່ວໄປຮູ້ສຶກບໍ່ເສຍຄ່າກັບ [join us on gitter][gitter] ແລະຖາມໄປທົ່ວ!ມີຄວາມຮູ້ສຶກບໍ່ເສຍຄ່າເພື່ອ ping ບໍ່ວ່າຈະ@BurntSushi ຫຼື@alexcrichton ກັບຄໍາຖາມ.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# ວິທີການຂຽນຕົວຢ່າງ ສຳ ລັບ strarch intrinsics

ມີຄຸນລັກສະນະ ຈຳ ນວນ ໜຶ່ງ ທີ່ຕ້ອງໄດ້ເປີດໃຫ້ໃຊ້ງານ ສຳ ລັບຄວາມສະດວກສະບາຍໃນການເຮັດວຽກຢ່າງຖືກຕ້ອງແລະຕົວຢ່າງຕ້ອງໄດ້ ດຳ ເນີນການໂດຍ `cargo test --doc` ເທົ່ານັ້ນເມື່ອຄຸນລັກສະນະດັ່ງກ່າວຖືກສະ ໜັບ ສະ ໜູນ ໂດຍ CPU.

ດັ່ງນັ້ນ, ໄດ້ເລີ່ມຕົ້ນ `fn main` ທີ່ຖືກສ້າງຂຶ້ນໂດຍ `rustdoc` ຈະບໍ່ເຮັດວຽກ (ໃນກໍລະນີຫຼາຍທີ່ສຸດ).
ພິຈາລະນາໃຊ້ສິ່ງຕໍ່ໄປນີ້ເປັນຄູ່ມືເພື່ອຮັບປະກັນຕົວຢ່າງຂອງທ່ານໃຫ້ປະຕິບັດຕາມຄາດ ໝາຍ.

```rust
/// # // ພວກເຮົາຈໍາເປັນຕ້ອງ cfg_target_feature ເພື່ອຮັບປະກັນຍົກຕົວຢ່າງແມ່ນພຽງແຕ່
/// # // ດໍາເນີນການໂດຍ `cargo test --doc` ໃນເວລາທີ່ CPU ສະຫນັບສະຫນູນຄຸນນະສົມບັດ
/// # #![feature(cfg_target_feature)]
/// # // ພວກເຮົາຕ້ອງການ target_feature ສຳ ລັບຄວາມສາມາດໃນການເຮັດວຽກ
/// # #![feature(target_feature)]
/// #
/// # // rustdoc ໂດຍຄ່າເລີ່ມຕົ້ນໃຊ້ `extern crate stdarch`, ແຕ່ພວກເຮົາຕ້ອງການ
/// # // `#[macro_use]`
/// # # [macro_use] ພາຍນອກ crate ທາດແປ້ງ;
/// #
/// # // ຫນ້າທີ່ຕົ້ນຕໍທີ່ແທ້ຈິງ
/// # fn main() {
/// #     // ພຽງແຕ່ດໍາເນີນການນີ້ຖ້າ `<target feature>` ສະຫນັບສະຫນູນ
/// #     ຖ້າຫາກວ່າ cfg_feature_enabled! ("<target feature>"){
/// #         // ສ້າງການທໍາງານຂອງ `worker` ທີ່ຈະໄດ້ຮັບການດໍາເນີນການພຽງແຕ່ຖ້າຫາກວ່າຄຸນນະສົມບັດເປົ້າຫມາຍດັ່ງກ່າວ
/// #         // ໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ແລະຮັບປະກັນວ່າ `target_feature` ຖືກເປີດໃຊ້ ສຳ ລັບພະນັກງານຂອງທ່ານ
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         ບໍ່ປອດໄພ fn worker() {
/// // ຂຽນຕົວຢ່າງຂອງທ່ານທີ່ນີ້.ຄຸນລັກສະນະສະເພາະເຈາະຈົງແບບສະເພາະຈະເຮັດວຽກຢູ່ນີ້!ໄປ ທຳ ມະຊາດ!
///
/// #         }
///
/// #         ບໍ່ປອດໄພ { worker(); }
/// #     }
/// # }
```

ຖ້າບາງ syntax ຂ້າງເທິງເບິ່ງຄືບໍ່ຄຸ້ນເຄີຍ, ພາກ [Documentation as tests] ຂອງ [Rust Book] ອະທິບາຍເຖິງ syntax `rustdoc` ຂ້ອນຂ້າງດີ.
ໃນຖານະເປັນສະເຫມີໄປ, ມີຄວາມຮູ້ສຶກບໍ່ເສຍຄ່າເພື່ອ [join us on gitter][gitter] ແລະຮ້ອງຂໍໃຫ້ພວກເຮົາຖ້າຫາກວ່າທ່ານມົນຕີ snag ໃດ, ແລະຂໍຂອບໃຈທ່ານສໍາລັບການຊ່ວຍເຫຼືອໃນການປັບປຸງເອກະສານຂອງ `stdarch` ໄດ້!

# ຄໍາແນະນໍາໃນການທົດສອບທາງເລືອກ

ໂດຍທົ່ວໄປແລ້ວທ່ານຄວນໃຊ້ `ci/run.sh` ເພື່ອ ດຳ ເນີນການທົດສອບ.
ເຖິງຢ່າງໃດກໍ່ຕາມມັນອາດຈະບໍ່ມີປະໂຫຍດ ສຳ ລັບທ່ານ, ຕົວຢ່າງຖ້າທ່ານຢູ່ Windows.

ໃນກໍລະນີດັ່ງກ່າວທ່ານສາມາດກັບໄປແລ່ນ `cargo +nightly test` ແລະ `cargo +nightly test --release -p core_arch` ເພື່ອທົດສອບການສ້າງລະຫັດ.
ໃຫ້ສັງເກດວ່າສິ່ງເຫລົ່ານີ້ຮຽກຮ້ອງໃຫ້ມີການຕິດຕັ້ງ toolchain ໃນຕອນກາງຄືນແລະເພື່ອໃຫ້ `rustc` ຮູ້ກ່ຽວກັບ triple ເປົ້າ ໝາຍ ແລະ CPU ຂອງມັນ.
ໂດຍສະເພາະທ່ານ ຈຳ ເປັນຕ້ອງ ກຳ ນົດຕົວປ່ຽນແປງສະພາບແວດລ້ອມ `TARGET` ຄືກັບທີ່ທ່ານຕ້ອງການ ສຳ ລັບ `ci/run.sh`.
ນອກຈາກນັ້ນທ່ານຈໍາເປັນຕ້ອງໄດ້ກໍານົດ `RUSTCFLAGS` (ຕ້ອງໄດ້ `C`) ເພື່ອບົ່ງບອກຄຸນນະສົມບັດເປົ້າຫມາຍ, ເຊັ່ນ `RUSTCFLAGS="-C -target-features=+avx2"`.
ນອກນັ້ນທ່ານຍັງສາມາດຕັ້ງຄ່າ `-C -target-cpu=native` ຖ້າຫາກວ່າທ່ານກໍາລັງພັດທະນາ "just" ກັບ CPU ໃນປະຈຸບັນຂອງທ່ານ.

ໄດ້ຮັບການເຕືອນວ່າເມື່ອທ່ານໃຊ້ ຄຳ ແນະ ນຳ ທາງເລືອກເຫຼົ່ານີ້, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], ຕົວຢ່າງ
ການທົດສອບຄໍາແນະນໍາແລະການຜະລິດອາດຈະລົ້ມເຫລວເພາະ disassembler ທີ່ມີຊື່ໃຫ້ເຂົາເຈົ້າແຕກຕ່າງກັນ, ຕົວຢ່າງ:
ມັນອາດຈະຜະລິດ `vaesenc` ແທນ ຄຳ ແນະ ນຳ `aesenc` ເຖິງວ່າມັນຈະມີພຶດຕິ ກຳ ຄືກັນ.
ຄຳ ແນະ ນຳ ເຫຼົ່ານີ້ຍັງເຮັດການທົດສອບ ໜ້ອຍ ກ່ວາທີ່ຈະເຮັດຕາມປົກກະຕິ, ສະນັ້ນຢ່າແປກໃຈວ່າເມື່ອໃດທີ່ທ່ານດຶງຂໍ້ຜິດພາດບາງຢ່າງອາດຈະສະແດງໃຫ້ເຫັນ ສຳ ລັບການທົດສອບທີ່ບໍ່ມີຢູ່ໃນນີ້.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






