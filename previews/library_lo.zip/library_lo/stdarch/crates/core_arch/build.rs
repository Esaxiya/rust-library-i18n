use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // ໃຊ້ເພື່ອບອກ ຄຳ ບັນຍາຍ `#[assert_instr]` ຂອງພວກເຮົາວ່າມີການບຸກລຸກແບບ simd ທັງ ໝົດ ເພື່ອທົດສອບລະຫັດລະຫັດຂອງເຂົາເຈົ້າ, ເພາະວ່າບາງບ່ອນແມ່ນຢູ່ເບື້ອງຫຼັງ `-Ctarget-feature=+unimplemented-simd128` ພິເສດທີ່ບໍ່ມີຄ່າທຽບເທົ່າໃດໆໃນ `#[target_feature]` ດຽວນີ້.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}