`core::arch` - Rust ຂອງຫ້ອງສະຫມຸດຫຼັກທີ່ແທ້ຈິງສະຖາປັດຕະສະເພາະ
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

ໂມດູນ `core::arch` ປະຕິບັດຕາມສະຖາປັດຕະທີ່ຂຶ້ນກັບສະຖາປັດຕະຍະ ກຳ (ເຊັ່ນ: SIMD).

# Usage 

`core::arch` ສາມາດໃຊ້ໄດ້ເປັນສ່ວນຫນຶ່ງຂອງ `libcore` ແລະມັນແມ່ນສົ່ງອອກໂດຍ `libstd`.ຕ້ອງການການນໍາໃຊ້ມັນໂດຍຜ່ານ `core::arch` ຫຼື `std::arch` ກ່ວາຜ່ານ crate ນີ້.
ຄຸນນະສົມບັດ Unstable ແມ່ນມັກຈະສາມາດໃຊ້ໄດ້ໃນ Rust ຄືນຜ່ານ `feature(stdsimd)`.

ການນໍາໃຊ້ `core::arch` ຜ່ານ crate ນີ້ຮຽກຮ້ອງໃຫ້ມີຄືນ Rust, ແລະມັນສາມາດເຮັດໄດ້ (ແລະບໍ່) ທໍາລາຍມັກ.ໃນກໍລະນີເທົ່ານັ້ນທີ່ທ່ານຄວນພິຈາລະນາການນໍາໃຊ້ມັນໂດຍຜ່ານ crate ນີ້ແມ່ນ:

* ຖ້າທ່ານ ຈຳ ເປັນຕ້ອງລວບລວມ `core::arch` ຕົວທ່ານເອງ, ຕົວຢ່າງ, ໂດຍສະເພາະຄຸນລັກສະນະເປົ້າ ໝາຍ ທີ່ຖືກເປີດໃຊ້ ສຳ ລັບ `libcore`/`libstd`.
Note: ຖ້າທ່ານ ຈຳ ເປັນຕ້ອງໄດ້ລວບລວມມັນຄືນ ໃໝ່ ສຳ ລັບເປົ້າ ໝາຍ ທີ່ບໍ່ໄດ້ມາດຕະຖານ, ກະລຸນາເລືອກໃຊ້ `xargo` ແລະຂຽນຄືນ `libcore`/`libstd` ໃຫ້ ເໝາະ ສົມແທນທີ່ຈະໃຊ້ crate ນີ້.
  
* ໃຊ້ບາງລັກສະນະທີ່ອາດຈະບໍ່ມີເຖິງແມ່ນວ່າຢູ່ເບື້ອງຫຼັງຄຸນລັກສະນະ Rust ທີ່ບໍ່ຫມັ້ນຄົງ.ພວກເຮົາພະຍາຍາມຮັກສາສິ່ງເຫຼົ່ານີ້ໃຫ້ເປັນຢ່າງ ໜ້ອຍ.
ຖ້າທ່ານຕ້ອງການ ນຳ ໃຊ້ບາງລັກສະນະດັ່ງກ່າວ, ກະລຸນາເປີດປະເດັນດັ່ງນັ້ນພວກເຮົາສາມາດເຜີຍແຜ່ມັນໄດ້ໃນເວລາກາງຄືນ Rust ແລະທ່ານສາມາດໃຊ້ມັນຈາກນັ້ນ.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` ໄດ້ຖືກແຈກຢາຍຕົ້ນຕໍພາຍໃຕ້ຂໍ້ກໍານົດຂອງທັງໃບອະນຸຍາດ MIT ແລະໃບອະນຸຍາດ Apache (Version 2.0), ມີບາງສ່ວນປົກຄຸມດ້ວຍ BSD ຄ້າຍຄືໃບອະນຸຍາດຕ່າງໆ.

ເບິ່ງໃບອະນຸຍາດ, APACHE ແລະໃບອະນຸຍາດ, MIT ສໍາລັບລາຍລະອຽດ.

# Contribution

ເວັ້ນເສຍແຕ່ວ່າທ່ານລະບຸຢ່າງຈະແຈ້ງຖ້າບໍ່ດັ່ງນັ້ນ, ການປະກອບສ່ວນໃດໆທີ່ສົ່ງໂດຍເຈດຕະນາ ສຳ ລັບການລວມເອົາ `core_arch` X ໂດຍທ່ານ, ຕາມທີ່ໄດ້ ກຳ ນົດໄວ້ໃນໃບອະນຸຍາດ Apache-2.0, ຈະຕ້ອງໄດ້ຮັບອະນຸຍາດສອງຢ່າງຄືຂ້າງເທິງ, ໂດຍບໍ່ມີເງື່ອນໄຂເພີ່ມເຕີມ.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












