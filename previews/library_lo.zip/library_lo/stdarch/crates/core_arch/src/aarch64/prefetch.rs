#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// ເບິ່ງ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// ເບິ່ງ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// ເບິ່ງ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// ເບິ່ງ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// ເບິ່ງ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// ເບິ່ງ [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// ມາດດຶງຂໍ້ມູນເສັ້ນ cache ທີ່ປະກອບດ້ວຍ address `p` ໂດຍນໍາໃຊ້ໃຫ້ `rw` ແລະ `locality`.
///
/// `rw` ຕ້ອງແມ່ນ ໜຶ່ງ ໃນ:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): prefetch ແມ່ນການກະກຽມສໍາລັບການອ່ານ.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): prefetch ແມ່ນການກະກຽມສໍາລັບການຂຽນ.
///
/// `locality` ຕ້ອງແມ່ນ ໜຶ່ງ ໃນ:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): ນ້ໍາຫຼືບໍ່ມີທາງໂລກ prefetch, ສໍາລັບຂໍ້ມູນທີ່ຖືກນໍາໃຊ້ພຽງແຕ່ຄັ້ງດຽວ.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): ດຶງຂໍ້ມູນເຂົ້າໃນຖານຄວາມຈໍາລະດັບ 3.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): ດຶງຂໍ້ມູນເຂົ້າໃນ cache ຊັ້ນ 2.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): ດຶງຂໍ້ມູນເຂົ້າໃນ cache ຊັ້ນ 1.
///
/// ຄຳ ແນະ ນຳ ກ່ຽວກັບຄວາມ ຈຳ ຂອງການ ນຳ ໜ້າ ຈະເປັນສັນຍານຕໍ່ລະບົບ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ການເຂົ້າເຖິງຄວາມຊົງ ຈຳ ຈາກທີ່ຢູ່ທີ່ ກຳ ນົດຈະມີຂື້ນໃນ future ໃກ້ໆ.
/// ລະບົບຫນ່ວຍຄວາມ ຈຳ ສາມາດຕອບສະ ໜອງ ໄດ້ໂດຍການກະ ທຳ ທີ່ຄາດວ່າຈະຊ່ວຍເພີ່ມຄວາມໄວໃນການເຂົ້າເຖິງຄວາມ ຈຳ ໃນເວລາທີ່ມັນເກີດຂື້ນ, ເຊັ່ນວ່າການຈັດສົ່ງທີ່ຢູ່ທີ່ລະບຸໄວ້ໃນບ່ອນເກັບມ້ຽນ ໜຶ່ງ ຫຼືຫຼາຍ.
///
/// ເນື່ອງຈາກວ່າສັນຍານເຫຼົ່ານີ້ແມ່ນຄໍາແນະນໍາເທົ່ານັ້ນ, ມັນເປັນທີ່ຖືກຕ້ອງສໍາລັບການ CPU ໂດຍສະເພາະການປິ່ນປົວຄໍາແນະນໍາ prefetch ຫນຶ່ງຫຼືທັງຫມົດເປັນ NOP ໄດ້.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // ພວກເຮົານໍາໃຊ້ instrinsic `llvm.prefetch` ກັບ `cache type` =1 (cache ຂໍ້ມູນ).
    // `rw` ແລະ `strategy` ແມ່ນອີງໃສ່ຕົວ ກຳ ນົດການເຮັດວຽກ.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}