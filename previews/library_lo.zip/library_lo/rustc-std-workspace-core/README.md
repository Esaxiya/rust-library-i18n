# The `rustc-std-workspace-core` crate

crate ນີ້ເປັນ shim ແລະເປົ່າ crate ທີ່ພຽງແຕ່ຂຶ້ນກັບ `libcore` ແລະ reexports ທັງຫມົດຂອງເນື້ອໃນຂອງຕົນ.
The crate ແມ່ນ crux ຂອງເພີ່ມຂີດຄວາມສາຫ້ອງສະຫມຸດມາດຕະຖານທີ່ຈະຂຶ້ນກັບ crates ຈາກ crates.io ໄດ້

Crates ກ່ຽວກັບ crates.io ວ່າຫ້ອງສະຫມຸດມາດຕະຖານຂຶ້ນກັບຄວາມຕ້ອງການທີ່ຈະຂຶ້ນກັບການ `rustc-std-workspace-core` crate ຈາກ crates.io, ເຊິ່ງແມ່ນຫວ່າງເປົ່າ.

ພວກເຮົານໍາໃຊ້ `[patch]` ມາດຂຽນທັບໄປ crate ນີ້ໃນ repository ນີ້.
ດັ່ງນັ້ນ, crates ກ່ຽວກັບ crates.io ຈະແຕ້ມເພິ່ງພາອາໄສ edge ກັບ `libcore`, ສະບັບພາສາໄດ້ກໍານົດໄວ້ໃນ repository ນີ້.
ທີ່ຄວນແຕ້ມທັງຫມົດແຄມເພິ່ງພາອາໄສເພື່ອຮັບປະກັນ Cargo ສ້າງ crates ສົບຜົນສໍາເລັດ!

ໃຫ້ສັງເກດວ່າ crates ກ່ຽວກັບ crates.io ຕ້ອງອີງໃສ່ crate ນີ້ດ້ວຍຊື່ `core` ເພື່ອໃຫ້ທຸກຢ່າງເຮັດວຽກຢ່າງຖືກຕ້ອງ.ເພື່ອເຮັດໃຫ້ພວກເຂົາເຈົ້າສາມາດນໍາໃຊ້:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

ໂດຍຜ່ານການນໍາໃຊ້ຂອງທີ່ສໍາຄັນ `package` ໄດ້ crate ແມ່ນ renamed ກັບ `core`, ຊຶ່ງຫມາຍຄວາມວ່າມັນຈະເບິ່ງຄື

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

ໃນເວລາທີ່ Cargo invokes compiler ໄດ້, ຄວາມພຶງພໍໃຈ `extern crate core` ສັ່ງ implicit ສັກໂດຍ compiler ໄດ້.




