// rsbegin.o ແລະ rsend.o ແມ່ນເອີ້ນວ່າດັ່ງນັ້ນ "compiler runtime startup objects".
// ພວກເຂົາເຈົ້າປະກອບດ້ວຍລະຫັດທີ່ຈໍາເປັນເພື່ອຢ່າງຖືກຕ້ອງເລີ່ມຕົ້ນ runtime compiler ໄດ້.
//
// ເມື່ອຮູບພາບທີ່ສາມາດປະຕິບັດງານຫລື dylib ເຊື່ອມໂຍງໄດ້, ລະຫັດຂອງຜູ້ໃຊ້ແລະຫ້ອງສະ ໝຸດ ທັງ ໝົດ ແມ່ນ "sandwiched" ລະຫວ່າງເອກະສານວັດຖຸສອງຢ່າງນີ້, ສະນັ້ນລະຫັດຫລືຂໍ້ມູນຈາກ rsbegin.o ກາຍເປັນອັນດັບ ທຳ ອິດໃນພາກສ່ວນຕ່າງໆຂອງຮູບ, ຂະນະທີ່ລະຫັດແລະຂໍ້ມູນຈາກ rsend.o ກາຍເປັນຕົວເລກສຸດທ້າຍ.
// ຜົນກະທົບນີ້ສາມາດຖືກນໍາໃຊ້ເພື່ອສັນຍາລັກສະຖານທີ່ຢູ່ໃນຕອນຕົ້ນຫຼືໃນຕອນທ້າຍຂອງພາກໃດຫນຶ່ງ, ເຊັ່ນດຽວກັນກັບສະແດງກິ່ງງ່າຫົວຄ່າຝຶກອົບຮົມຫຼື footers.
//
// ໃຫ້ສັງເກດວ່າຈຸດເຂົ້າຂອງໂມດູນຕົວຈິງແມ່ນຕັ້ງຢູ່ໃນວັດຖຸເລີ່ມຕົ້ນ C runtime (ໂດຍປົກກະຕິເອີ້ນວ່າ `crtX.o`), ເຊິ່ງຕໍ່ມາກໍ່ຈະເອີ້ນການເອີ້ນຄືນຂອງສ່ວນປະກອບອື່ນໆ (ລົງທະບຽນຜ່ານພາກສ່ວນຮູບພາບພິເສດອື່ນໆ).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // ເຄື່ອງຫມາຍເລີ່ມຕົ້ນຂອງພາ stack ຂໍ້ມູນຜ່ອນຄາຍພາກນີ້
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // ຊ່ອງ Scratch ສໍາລັບຜ່ອນຄາຍຂອງພາຍໃນ book, ການຮັກສາ.
    // ນີ້ແມ່ນກໍານົດເປັນ `struct object` ໃນ $ GCC/libgcc/ຜ່ອນຄາຍ, dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // ຍົກເລີກຂໍ້ມູນປົກກະຕິ registration/deregistration.
    // ເບິ່ງເອກະສານຂອງ libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // ລົງທະບຽນຂໍ້ມູນຜ່ອນຄາຍເທິງເລີ່ມຕົ້ນລະບົບໂມດູນ
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ບໍ່ລົງທະບຽນໃນການປິດ
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // ການລົງທະບຽນປົກກະຕິຂອງ MinGW init/uninit
    pub mod mingw_init {
        // ວັດຖຸເລີ່ມຕົ້ນຂອງ MinGW (crt0.o/dllcrt0.o) ຈະຮຽກຮ້ອງຜູ້ກໍ່ສ້າງທົ່ວໂລກໃນພາກ .ctors ແລະ .dtors ໃນເວລາເລີ່ມຕົ້ນແລະອອກ.
        // ໃນກໍລະນີຂອງ DLL, ສິ່ງນີ້ຈະເຮັດໄດ້ເມື່ອ DLL ຖືກໂຫລດແລະບໍ່ໄດ້ໂຫລດ.
        //
        // ການ linker ຈະຈັດຮຽງພາກສ່ວນ, ຊຶ່ງຮັບປະກັນວ່າ callbacks ຂອງພວກເຮົາກໍາລັງຕັ້ງຢູ່ໃນຕອນທ້າຍຂອງບັນຊີລາຍການ.
        // ນັບຕັ້ງແຕ່ການກໍ່ສ້າງກໍາລັງດໍາເນີນການຢູ່ໃນຄໍາສັ່ງໄດ້ຢ່າງສິ້ນເຊີງ, ຮັບປະກັນນີ້ວ່າ callbacks ຂອງພວກເຮົາແມ່ນກຸ່ມທໍາອິດແລະສຸດທ້າຍການປະຕິບັດ.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors *: . callbacks C ຂຽນອັກສອນຫຍໍ້
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors *: . callbacks ເປັນ C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}