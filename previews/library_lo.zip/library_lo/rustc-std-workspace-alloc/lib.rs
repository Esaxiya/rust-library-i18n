#![feature(no_core)]
#![no_core]

// ເບິ່ງ rustc-std-workspace-core ສຳ ລັບເຫດຜົນທີ່ວ່າ crate ນີ້ ຈຳ ເປັນ.

// ປ່ຽນຊື່ crate ເພື່ອຫລີກລ້ຽງການຂັດແຍ້ງກັບໂມດູນການຈັດສັນໃນ liballoc.
extern crate alloc as foo;

pub use foo::*;