//! ຫໍສະ ໝຸດ ສະ ໜັບ ສະ ໜູນ ສຳ ລັບຜູ້ຂຽນມະຫາພາກເມື່ອ ກຳ ນົດມະຫາພາກ ໃໝ່.
//!
//! ຫໍສະຫມຸດດັ່ງກ່າວນີ້, ສະຫນອງໃຫ້ໂດຍການແຜ່ກະຈາຍມາດຕະຖານ, ສະຫນອງປະເພດການບໍລິໂພກໃນການໂຕ້ຕອບຂອງກໍານົດຂັ້ນຕອນຄໍານິຍາມມະຫາພາກເຊັ່ນ: ການທໍາງານຂອງຄ້າຍຄືມະຫາພາກ `#[proc_macro]`, ຄຸນລັກສະນະມະຫາພາກ `#[proc_macro_attribute]` ແລະອະນຸກໍາຫນົດເອງ attributes`#[proc_macro_derive]`ໄດ້.
//!
//!
//! ເບິ່ງ [the book] ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// ຕັດສິນກໍານົດວ່າ proc_macro ໄດ້ຮັບການເຮັດສາມາດເຂົ້າເຖິງກັບໂຄງການແລ່ນປັດຈຸບັນ.
///
/// The proc_macro crate ແມ່ນມີຈຸດປະສົງພຽງແຕ່ ສຳ ລັບການ ນຳ ໃຊ້ພາຍໃນການຈັດຕັ້ງປະຕິບັດລະບຽບມະຫາພາກ.ທຸກການເຄື່ອນໄຫວໃນນີ້ crate panic ໄດ້ຖ້າຫາກວ່າຍົກຂຶ້ນມາອ້າງຈາກພາຍນອກຂອງມະຫາພາກລະບຽບ, ເຊັ່ນ: ຈາກການກໍ່ສ້າງ script ຫຼືການທົດສອບຫນ່ວຍຫຼືທໍາມະດາຄູ່ Rust.
///
/// ມີພິຈາລະນາສໍາລັບການຫ້ອງສະຫມຸດ Rust ທີ່ອອກແບບມາເພື່ອສະຫນັບສະຫນູນທັງສອງມະຫາພາກແລະກໍລະນີການນໍາໃຊ້ທີ່ບໍ່ແມ່ນມະຫາພາກ, `proc_macro::is_available()` ສະຫນອງວິທີການທີ່ບໍ່ແມ່ນການ panicking ເພື່ອກວດສອບວ່າໂຄງສ້າງພື້ນຖານທີ່ຈໍາເປັນໃນການນໍາໃຊ້ API ຂອງ proc_macro ທີ່ສາມາດໃຊ້ໄດ້ໃນປັດຈຸບັນ.
/// ຜົນຕອບແທນທີ່ແທ້ຈິງຖ້າຫາກວ່າຍົກຂຶ້ນມາອ້າງຈາກພາຍໃນຂອງມະຫາພາກລະບຽບ, false ຖ້າຍົກຂຶ້ນມາອ້າງຈາກຄູ່ອື່ນໆ.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// ປະເພດຕົ້ນຕໍທີ່ໃຫ້ໂດຍ crate ນີ້, ເຊິ່ງເປັນຕົວແທນຂອງກະແສ tokens, ຫຼືໂດຍສະເພາະ, ລຳ ດັບຂອງຕົ້ນໄມ້ token.
/// ປະເພດໃຫ້ການໂຕ້ຕອບສໍາລັບ iterating ໃນໄລຍະທີ່ຕົ້ນໄມ້ token ແລະທາງກັບກັນ, ການເກັບກໍາຈໍານວນຂອງຕົ້ນໄມ້ token ເຂົ້າໄປໃນຫນຶ່ງນ້ໍາ.
///
///
/// ນີ້ແມ່ນທັງການປ້ອນຂໍ້ມູນແລະຜົນຜະລິດຂອງ ຄຳ ນິຍາມ `#[proc_macro]`, `#[proc_macro_attribute]` ແລະ `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Error ກັບຄືນຈາກ `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// ສົ່ງຄືນ `TokenStream` ເປົ່າທີ່ບໍ່ມີຕົ້ນໄມ້ token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// ກວດສອບວ່າ `TokenStream` ນີ້ແມ່ນຫວ່າງເປົ່າ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// ຄວາມພະຍາຍາມທີ່ຈະທໍາລາຍເຂົ້າໄປໃນ string tokens ແລະແຍກ tokens ຜູ້ເປັນກະແສ token.
/// ອາດເຊັ່ນການແລກປ່ຽນສໍາລັບການຈໍານວນຂອງເຫດຜົນ, ສໍາລັບການຍົກຕົວຢ່າງ, ຖ້າຫາກວ່າ string ທີ່ປະກອບດ້ວຍຕົວຄັ່ນບໍ່ສົມດຸນຫລືຕົວອັກສອນບໍ່ໄດ້ທີ່ມີຢູ່ແລ້ວໃນພາສາ.
///
/// tokens ທັງ ໝົດ ໃນກະແສທີ່ມີການແຍກແມ່ນໄດ້ຮັບ `Span::call_site()` ກວ້າງ.
///
/// NOTE: ຄວາມຜິດພາດບາງຢ່າງອາດເຮັດໃຫ້ panics ແທນທີ່ຈະກັບຄືນ `LexError`.ພວກເຮົາສະຫງວນສິດທີ່ຈະປ່ຽນຂໍ້ຜິດພາດເຫລົ່ານີ້ເປັນ `LexError`s ພາຍຫລັງ.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, ຂົວພຽງແຕ່ສະຫນອງ `to_string`, ໃຊ້ `fmt::Display` ອີງໃສ່ມັນ (ຢ່າງສິ້ນເຊີງຂອງສາຍພົວພັນປົກກະຕິລະຫວ່າງສອງ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// ພິມກະແສ token ເປັນສະຕິງທີ່ສົມມຸດວ່າເປັນການປ່ຽນແປງແບບບໍ່ມີຕົວຕົນກັບຄືນສູ່ກະແສ token ດຽວກັນ (ແບບໂມດູນຂະຫຍາຍ), ຍົກເວັ້ນວ່າເປັນໄປໄດ້ `TokenTree: : Group` ກັບ `Delimiter::None` delimiters ແລະຕົວ ໜັງ ສືຕົວເລກລົບ.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ການພິມ token ໃນຮູບແບບທີ່ສະດວກ ສຳ ລັບການ debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// ສ້າງກະແສ token ທີ່ມີຕົ້ນໄມ້ token ດຽວ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// ເກັບກໍາຈໍານວນຂອງຕົ້ນໄມ້ token ເຂົ້າໄປໃນກະແສດຽວ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// ການປະຕິບັດງານ "flattening" ໃນສາຍນ້ ຳ token, ເກັບເອົາຕົ້ນໄມ້ token ຈາກສາຍນ້ ຳ token ຫຼາຍສາຍເຂົ້າໄປໃນກະແສດຽວ.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) ໃຊ້ເຫມາະດໍາເນີນ if/when ເປັນໄປໄດ້.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// ລາຍລະອຽດການຈັດຕັ້ງປະຕິບັດຂອງສາທາລະນະ ສຳ ລັບປະເພດ `TokenStream`, ເຊັ່ນ: ເຄື່ອງແທກ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// ເປັນ iterator ໃນໄລຍະ `TokenStream` ຂອງ`TokenTree`s.
    /// ຍ້ໍາແມ່ນ "shallow", ເຊັ່ນ, ການ iterator ບໍ່ recurse ເຂົ້າໄປໃນກຸ່ມ delimited, ແລະຜົນຕອບແທນກຸ່ມທັງຫມົດເປັນຕົ້ນໄມ້ token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` ຮັບທີ່ຕົນເອງມັກ tokens ແລະຂະຫຍາຍເຂົ້າໄປໃນ `TokenStream` ອະທິບາຍວັດຖຸດິບ.
/// ສໍາລັບຕົວຢ່າງ, `quote!(a + b)` ຈະຜະລິດເປັນການສະແດງອອກ, ທີ່, ໃນເວລາທີ່ການປະເມີນຜົນ, ສ້າງການ `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting ແມ່ນເຮັດດ້ວຍ `$`, ແລະເຮັດວຽກໂດຍການຂໍ້ມູນສ່ວນຕົວຕໍ່ໄປດຽວເປັນໄລຍະ unquoted.
/// ເພື່ອອ້າງເຖິງ `$` ເອງ, ໃຫ້ໃຊ້ `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// ພາກພື້ນຂອງລະຫັດແຫຼ່ງຂໍ້ມູນພ້ອມກັບຂໍ້ມູນການຂະຫຍາຍມະຫາພາກ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// ສ້າງ `Diagnostic` ລຸ້ນ ໃໝ່ ທີ່ມີ `message` ຢູ່ໃນ `self` span.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// A span ທີ່ແກ້ໄຂຢູ່ໃນເວັບໄຊຄໍານິຍາມມະຫາພາກ.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// ເປີດກວ້າງຂອງ invocation ຂອງມະຫາພາກລະບຽບການປັດຈຸບັນໄດ້.
    /// ຕົວລະບຸຕົວສ້າງທີ່ມີຂອບເຂດນີ້ຈະໄດ້ຮັບການແກ້ໄຂຄືກັບວ່າພວກເຂົາຖືກຂຽນໂດຍກົງຢູ່ທີ່ສະຖານທີ່ໂທຫາມະຫາພາກ (ສະຖານທີ່ໂທຫາສະຖານທີ່) ແລະລະຫັດອື່ນໆທີ່ເວັບໄຊທ໌ທີ່ເອີ້ນວ່າມະຫາພາກຈະສາມາດອ້າງອີງເຖິງພວກເຂົາເຊັ່ນກັນ.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// A span ວ່າເປັນຕົວແທນ `macro_rules` ອະນາໄມ, ແລະບາງຄັ້ງຈະຊ່ວຍແກ້ໄຂຢູ່ໃນເວັບໄຊມະຫາພາກຄໍານິຍາມ (ຕົວແປໃນທ້ອງຖິ່ນ, ສະຫຼາກ, `$crate`) ແລະບາງຄັ້ງຢູ່ໃນເວັບໄຊໂທມະຫາພາກ (ທຸກສິ່ງທຸກຢ່າງອື່ນ).
    ///
    /// ສະຖານທີ່ເປີດກວ້າງແມ່ນເອົາມາຈາກເວັບໄຊ້ໂທ.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// ເອກະສານແຫຼ່ງຕົ້ນສະບັບທີ່ເນື້ອຫານີ້ຊີ້.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// The `Span` ສໍາລັບ tokens ໃນການຂະຫຍາຍຕົວມະຫາພາກທີ່ຜ່ານມາທີ່ `self` ແມ່ນໄດ້ມາຈາກ, ຖ້າມີ.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// ເປີດກວ້າງສໍາລັບການລະຫັດແຫຼ່ງຕົ້ນກໍາເນີດທີ່ `self` ແມ່ນໄດ້ມາຈາກ.
    /// ຖ້າ `Span` ນີ້ບໍ່ໄດ້ສ້າງຂຶ້ນຈາກການຂະຫຍາຍມະຫາພາກອື່ນໆຫຼັງຈາກນັ້ນຄ່າຕອບແທນແມ່ນຄືກັນກັບ `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// ໄດ້ຮັບການເລີ່ມຕົ້ນ line/column ໃນເອກະສານສະແດງຂໍ້ມູນສໍາລັບ span ນີ້.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// ເອົາ line/column ສິ້ນສຸດລົງໃນເອກະສານແຫຼ່ງຂໍ້ມູນ ສຳ ລັບຂອບເຂດນີ້.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// ສ້າງຂອບເຂດ ໃໝ່ ທີ່ລວມເອົາ `self` ແລະ `other`.
    ///
    /// ກັບຄືນ `None` ຖ້າ `self` ແລະ `other` ແມ່ນມາຈາກເອກະສານຕ່າງກັນ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// ສ້າງ span ໃຫມ່ທີ່ມີຂໍ້ມູນຂ່າວສານ line/column ເຊັ່ນດຽວກັນກັບ `self` ແຕ່ວ່າສັນຍາລັກແກ້ໄຂຄືກັບວ່າມັນແມ່ນຢູ່ໃນ `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// ສ້າງຂອບເຂດ ໃໝ່ ທີ່ມີພຶດຕິ ກຳ ການແກ້ໄຂຊື່ດຽວກັນກັບ `self` ແຕ່ມີຂໍ້ມູນ line/column ຂອງ `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// ປຽບທຽບກັບການເປີດກວ້າງເພື່ອເບິ່ງວ່າພວກເຂົາເຈົ້າກໍາລັງເທົ່າທຽມກັນ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// ຜົນໄດ້ຮັບຂໍ້ຄວາມມາທາງຫລັງຂອງ span ໄດ້.
    /// ນີ້ປົກປັກຮັກສາລະຫັດແຫຼ່ງຕົ້ນສະບັບ, ລວມທັງສະຖານທີ່ແລະຄວາມຄິດເຫັນ.
    /// ມັນຈະສົ່ງຜົນໄດ້ຮັບເທົ່ານັ້ນຖ້າຫາກວ່າຂອບເຂດນັ້ນກົງກັບລະຫັດແຫຼ່ງທີ່ແທ້ຈິງ.
    ///
    /// Note: ຜົນໄດ້ຮັບການສັງເກດການຂອງມະຫາພາກເທົ່ານັ້ນຄວນອີງໃສ່ການ tokens ແລະບໍ່ໄດ້ຢູ່ໃນຂໍ້ຄວາມແຫຼ່ງດັ່ງກ່າວນີ້.
    ///
    /// ຜົນໄດ້ຮັບຂອງຫນ້າທີ່ນີ້ແມ່ນຄວາມພະຍາຍາມທີ່ດີທີ່ສຸດທີ່ຈະໃຊ້ໃນການວິນິດໄສເທົ່ານັ້ນ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// ພິມຂອບເຂດໃນຮູບແບບທີ່ສະດວກ ສຳ ລັບການ ກຳ ຈັດ debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// A ຄູ່ສາຍຖັນເປັນຕົວແທນຂອງການເລີ່ມຕົ້ນຫຼືໃນຕອນທ້າຍຂອງ `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// ເສັ້ນ 1 ດັດຊະນີໃນເອກະສານສະແດງຂໍ້ມູນທີ່ໄດ້ span ເລີ້ມຕົ້ນຫຼືສິ້ນສຸດລົງ (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// ຖັນ 0, ດັດຊະນີ (ໂຕອັກສອນ UTF-8) ໃນເອກະສານສະແດງຂໍ້ມູນທີ່ໄດ້ span ເລີ້ມຕົ້ນຫຼືສິ້ນສຸດລົງ (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// ເອກະສານແຫຼ່ງຂໍ້ມູນຂອງ `Span` ທີ່ໃຫ້.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// ເສັ້ນທາງໄປຫາເອກະສານແຫຼ່ງຂໍ້ມູນນີ້.
    ///
    /// ### Note
    /// ຖ້າ span ລະຫັດທີ່ກ່ຽວຂ້ອງກັບ `SourceFile` ນີ້ຖືກສ້າງຂຶ້ນໂດຍການມະຫາພາກພາຍນອກ, ມະຫາພາກດັ່ງກ່າວນີ້, ນີ້ອາດຈະບໍ່ເປັນໄປຕາມເສັ້ນທາງທີ່ແທ້ຈິງກ່ຽວກັບລະບົບໄຟລ໌ໄດ້.
    /// ໃຊ້ [`is_real`] ການກວດສອບ.
    ///
    /// ນອກຈາກນີ້ຄວນສັງເກດວ່າເຖິງແມ່ນວ່າຖ້າຫາກວ່າຜົນໄດ້ຮັບ `is_real` `true` ຖ້າ `--remap-path-prefix` ໄດ້ຜ່ານເສັ້ນຄໍາສັ່ງ, ເສັ້ນທາງເປັນດັ່ງກ່າວອາດຈະບໍ່ຈິງຈະຖືກຕ້ອງ.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// ຜົນໄດ້ຮັບ `true` ຖ້າເອກະສານແຫຼ່ງດັ່ງກ່າວນີ້ແມ່ນເປັນເອກະສານແຫຼ່ງທີ່ແທ້ຈິງ, ແລະບໍ່ສ້າງຂຶ້ນໂດຍການຂະຫຍາຍຕົວເປັນມະຫາພາກພາຍນອກຂອງ.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // ນີ້ແມ່ນ hack ເປັນຈົນກ່ວາການເປີດກວ້າງ intercrate ຖືກປະຕິບັດແລະພວກເຮົາສາມາດມີໄຟລ໌ແຫຼ່ງທີ່ແທ້ຈິງສໍາລັບການເປີດກວ້າງສ້າງໃນພາກພາຍນອກ.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// A token ດຽວຫຼືລໍາດັບ delimited ຂອງຕົ້ນໄມ້ token (ຕົວຢ່າງ: , `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// ກະແສ token ອ້ອມຮອບດ້ວຍເຄື່ອງຍັບຍັ້ງຍຶດວົງເລັບ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// ເປັນຕົວຊີ້ບອກ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// A ເຄື່ອງຫມາຍວັກຕອນມີລັກສະນະດຽວ (`+`, `,`, `$`, ແລະອື່ນໆ).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// ຕົວ ໜັງ ສື (`'a'`) ຕົວ ໜັງ ສື, ສາຍ (`"hello"`), ເລກ (`2.3`), ແລະອື່ນໆ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// ຜົນຕອບແທນ span ຂອງຕົ້ນໄມ້ນີ້, ກະຈາຍກັບວິທີການ `span` ຂອງ token ບັນຈຸຫຼືນ້ໍາ delimited.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// ກໍາຫນົດຄ່າ span ສໍາລັບ *ພຽງນີ້ token*.
    ///
    /// ໃຫ້ສັງເກດວ່າຖ້າ token ນີ້ແມ່ນ `Group` ແລ້ວວິທີການນີ້ຈະບໍ່ ກຳ ນົດຄ່າໄລຍະເວລາຂອງແຕ່ລະ tokens, ມັນຈະມອບສິດໃຫ້ກັບວິທີ `set_span` ຂອງແຕ່ລະຕົວແປ.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// ພິມຕົ້ນໄມ້ token ໃນຮູບແບບທີ່ສະດວກສະບາຍ ສຳ ລັບການ debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ແຕ່ລະສິ່ງເຫລົ່ານີ້ມີຊື່ຢູ່ໃນປະເພດໂຄງສ້າງທີ່ຢູ່ໃນເຄື່ອງ ກຳ ຈັດທີ່ໄດ້ມາ, ສະນັ້ນຢ່າລົບກວນກັບຊັ້ນຂອງການຊົດເຊີຍ
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, ຂົວພຽງແຕ່ສະຫນອງ `to_string`, ໃຊ້ `fmt::Display` ອີງໃສ່ມັນ (ຢ່າງສິ້ນເຊີງຂອງສາຍພົວພັນປົກກະຕິລະຫວ່າງສອງ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// ພິມຕົ້ນໄມ້ token ເປັນສາຍເຊືອກທີ່ສົມມຸດວ່າບໍ່ສາມາດປ່ຽນເປັນຕົວປ່ຽນໄດ້ກັບຄືນເປັນຕົ້ນໄມ້ token ດຽວກັນ (ມີການຂະຫຍາຍໂມເດັມ), ຍົກເວັ້ນຕົວຢ່າງທີ່ເປັນໄປໄດ້ `TokenTree: : Group` ກັບ `Delimiter::None` ຂອບເຂດແລະວັນນະຄະດີຕົວເລກລົບ.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ກະແສ token ທີ່ມີຄວາມ ຈຳ ກັດ.
///
/// A `Group` ພາຍໃນມີ `TokenStream` ເຊິ່ງຖືກອ້ອມຮອບດ້ວຍ `Delimiter`.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// ອະທິບາຍວິທີການລໍາດັບຂອງຕົ້ນໄມ້ token ແມ່ນ delimited.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// ຕົວຊີ້ບອກທີ່ຖືກຕ້ອງ, ເຊິ່ງຕົວຢ່າງອາດຈະປະກົດຢູ່ອ້ອມຮອບ tokens ທີ່ມາຈາກ "macro variable" `$var`.
    /// ມັນເປັນສິ່ງສໍາຄັນທີ່ຈະຮັກສາບູລິມະສິດຂອງຜູ້ປະຕິບັດງານໃນກໍລະນີເຊັ່ນ `$var * 3` ທີ່ `$var` ແມ່ນ `1 + 2`.
    /// ຜູ້ ກຳ ນົດຂອບເຂດທີ່ສົມບູນອາດຈະບໍ່ລອດຊີວິດຮອບຂອງກະແສ token ຜ່ານສາຍສະຕິງ.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// ສ້າງ `Group` ແບບ ໃໝ່ ໂດຍມີຂອບເຂດ ຈຳ ກັດແລະ token.
    ///
    /// constructor ນີ້ຈະຕັ້ງ span ສໍາລັບກຸ່ມນີ້ຈະ `Span::call_site()`.
    /// ເພື່ອປ່ຽນຂອບເຂດທີ່ທ່ານສາມາດໃຊ້ວິທີ `set_span` ຂ້າງລຸ່ມນີ້.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// ຜົນໄດ້ຮັບຕົວຄັ່ນຂອງ `Group` ນີ້
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// ສົ່ງຄືນ `TokenStream` ຂອງ tokens ທີ່ຖືກ ກຳ ນົດໃນ `Group` ນີ້.
    ///
    /// ໃຫ້ສັງເກດວ່າກະແສ token ທີ່ຖືກສົ່ງກັບຄືນບໍ່ປະກອບມີຜູ້ ຈຳ ກັດທີ່ສົ່ງຄືນຂ້າງເທິງ.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// ຜົນໄດ້ຮັບເປີດກວ້າງສໍາລັບຄັ່ນຂອງນ້ໍາ token ນີ້, ການຢຽດທັງຫມົດ `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ຜົນໄດ້ຮັບ span ທີ່ຊີ້ໄປທີ່ຄັ່ນເປີດຂອງກຸ່ມນີ້.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// ຜົນຕອບແທນ span ໄດ້ຊີ້ໄປທີ່ຄັ່ນປິດຂອງກຸ່ມນີ້.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// ຕັ້ງຄາເປີດກວ້າງສໍາລັບການນີ້ `ຄັ່ນ Group` ຂອງ, ແຕ່ບໍ່ແມ່ນ tokens ພາຍໃນຂອງຕົນ.
    ///
    /// ວິທີການນີ້ຈະ **ບໍ່** ກໍານົດການເປີດກວ້າງຂອງທັງຫມົດ tokens ພາຍໃນວັດໂດຍກຸ່ມນີ້, ແຕ່ແທນທີ່ຈະຈະຕັ້ງແຕ່ການເປີດກວ້າງຂອງຕົວຄັ່ນ tokens ໄດ້ໃນລະດັບຂອງ `Group` ໄດ້.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, ຂົວພຽງແຕ່ສະຫນອງ `to_string`, ໃຊ້ `fmt::Display` ອີງໃສ່ມັນ (ຢ່າງສິ້ນເຊີງຂອງສາຍພົວພັນປົກກະຕິລະຫວ່າງສອງ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ພິມກຸ່ມດັ່ງກ່າວເປັນສະຕິງທີ່ຄວນປ່ຽນເປັນແບບເກົ່າໂດຍບໍ່ມີການປ່ຽນແປງເປັນກຸ່ມດຽວກັນ (ມີການຂະຫຍາຍໂມເດັມ), ຍົກເວັ້ນບາງທີອາດມີ `TokenTree: : Group` ກັບ `Delimiter::None` delimiters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` ແມ່ນຕົວອັກສອນເຄື່ອງ ໝາຍ ວັກດຽວຄື `+`, `-` ຫຼື `#`.
///
/// ຜູ້ປະຕິບັດງານທີ່ມີຫຼາຍແບບເຊັ່ນ `+=` ແມ່ນຕົວແທນເປັນສອງຕົວຢ່າງຂອງ `Punct` ທີ່ມີຮູບແບບ `Spacing` ທີ່ແຕກຕ່າງກັນ.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// ບໍ່ວ່າຈະເປັນ `Punct` ແມ່ນປະຕິບັດຕາມທັນທີໂດຍ `Punct` ອື່ນຫຼືປະຕິບັດຕາມໂດຍ token ຫຼືຊ່ອງອື່ນ.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ຕົວຢ່າງ: , `+` ແມ່ນ `Alone` ໃນ `+ =`, `+ident` ຫຼື `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ຕົວຢ່າງ: `+` ແມ່ນ `Joint` ໃນ `+=` ຫຼື `'#`.
    /// ນອກຈາກນັ້ນ, ຄຳ ອ້າງອີງ `'` ດຽວສາມາດເຂົ້າຮ່ວມກັບຕົວລະບຸຕົວຕົນເພື່ອປະກອບອາຍຸ `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// ສ້າງ `Punct` ໃໝ່ ຈາກໂຕອັກສອນແລະໄລຍະຫ່າງທີ່ໃຫ້.
    /// ການໂຕ້ຖຽງ `ch` ຕ້ອງເປັນຕົວອັກສອນວັກທີ່ຖືກຕ້ອງອະນຸຍາດໂດຍພາສາ, ຖ້າບໍ່ດັ່ງນັ້ນ ໜ້າ ທີ່ຈະເປັນ panic.
    ///
    /// ການກັບຄືນ `Punct` ຈະມີ span ໄວ້ໃນຕອນຕົ້ນຂອງ `Span::call_site()` ທີ່ສາມາດໄດ້ຮັບການ configured ຕໍ່ກັບວິທີການ `set_span` ຕ່ໍາກວ່າ.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// ສົ່ງຄືນຄ່າຂອງຕົວເຄື່ອງຫມາຍວັກຕອນນີ້ເປັນ `char` ໄດ້.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// ກັບຄືນສະຖານທີ່ຂອງຕົວອັກສອນເຄື່ອງ ໝາຍ ວັກນີ້, ສະແດງວ່າມັນຕິດຕາມໂດຍທັນທີໂດຍ `Punct` ອື່ນໃນກະແສ token, ດັ່ງນັ້ນພວກມັນອາດຈະຖືກລວມເຂົ້າໄປໃນຕົວປະຕິບັດການ (`Joint`) ທີ່ມີຫຼາຍຕົວອັກສອນ, ຫຼືມັນຕິດຕາມດ້ວຍບາງ token ຫຼື whitespace (`Alone`) ເພື່ອໃຫ້ຜູ້ປະຕິບັດງານແນ່ນອນ ສິ້ນສຸດລົງ.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// ຜົນໄດ້ຮັບເປີດກວ້າງສໍາລັບການລັກສະນະເຄື່ອງຫມາຍວັກຕອນນີ້.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ກຳ ນົດໄລຍະເວລາ ສຳ ລັບຕົວອັກສອນເຄື່ອງ ໝາຍ ວັກນີ້.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ຂົວພຽງແຕ່ສະຫນອງ `to_string`, ໃຊ້ `fmt::Display` ອີງໃສ່ມັນ (ຢ່າງສິ້ນເຊີງຂອງສາຍພົວພັນປົກກະຕິລະຫວ່າງສອງ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ພິມລັກສະນະເຄື່ອງຫມາຍວັກຕອນເປັນສະຕິງທີ່ຄວນຈະກັບຄືນໄປບ່ອນແປງ losslessly ເຂົ້າໄປໃນລັກສະນະດຽວກັນໄດ້.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// ຕົວລະບຸ (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// ສ້າງ `Ident` ລຸ້ນ ໃໝ່ ທີ່ມີ `string` ພ້ອມທັງ `span` ທີ່ລະບຸ.
    /// ການອະພິປາຍ `string` ຕ້ອງເປັນບຸຖືກຕ້ອງອະນຸຍາດໃຫ້ໂດຍພາສາ (ລວມທັງຄໍາ, ເຊັ່ນ `self` ຫຼື `fn`).ຖ້າບໍ່ດັ່ງນັ້ນ, ການທໍາງານຂອງຈະ panic.
    ///
    /// ໃຫ້ສັງເກດວ່າ `span`, ປະຈຸບັນໃນ rustc, configures ຂໍ້ມູນຂ່າວສານການອະນາໄມສໍາລັບຕົວຊີ້ບອກນີ້.
    ///
    /// ໃນຖານະເປັນຂອງທີ່ໃຊ້ເວລານີ້ `Span::call_site()` ຢ່າງຊັດເຈນ opts ໃນການ "call-site" ຫມາຍອະນາໄມທີ່ລະບຸສ້າງຂຶ້ນດ້ວຍ span ນີ້ຈະໄດ້ຮັບການແກ້ໄຂເປັນຖ້າຫາກວ່າພວກເຂົາເຈົ້າໄດ້ຖືກລາຍລັກອັກສອນໂດຍກົງໃນສະຖານທີ່ຂອງການໂທມະຫາພາກ, ແລະລະຫັດອື່ນໆຢູ່ໃນເວັບໄຊໂທມະຫາພາກຈະສາມາດອ້າງເຖິງ ໃຫ້ເຂົາເຈົ້າເຊັ່ນດຽວກັນ.
    ///
    ///
    /// ເປີດກວ້າງຕໍ່ມາຄື `Span::def_site()` ຈະອະນຸຍາດໃຫ້ເລືອກໃນການທີ່ຈະອະນາໄມ "definition-site" ຊຶ່ງຫມາຍຄວາມວ່າຕົວລະບຸສ້າງຂຶ້ນດ້ວຍ span ນີ້ຈະໄດ້ຮັບການແກ້ໄຂຢູ່ໃນສະຖານທີ່ຂອງຄວາມຫມາຍມະຫາພາກແລະລະຫັດອື່ນໆຢູ່ໃນເວັບໄຊໂທມະຫາພາກຈະບໍ່ສາມາດເບິ່ງໃຫ້ເຂົາເຈົ້າ.
    ///
    /// ເນື່ອງຈາກຄວາມ ສຳ ຄັນຂອງການອະນາໄມໃນປະຈຸບັນຜູ້ກໍ່ສ້າງນີ້, ບໍ່ຄືກັບ tokens ອື່ນໆ, ຈຳ ເປັນຕ້ອງໄດ້ ກຳ ນົດ `Span` ໃນການກໍ່ສ້າງ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// ດຽວກັນກັບ `Ident::new`, ແຕ່ສ້າງ (`r#ident`) ລະບຸວັດຖຸດິບ.
    /// ການອະພິປາຍ `string` ເປັນບຸຖືກຕ້ອງອະນຸຍາດໃຫ້ໂດຍພາສາ (ລວມທັງຄໍາ, ເຊັ່ນ `fn`).
    /// ຄຳ ທີ່ໃຊ້ໄດ້ໃນສ່ວນທີ່ເປັນເສັ້ນທາງ (ຕົວຢ່າງ
    /// `self`, `super`) ຍັງບໍ່ໄດ້ສະຫນັບສະຫນຸນແລະຈະເຮັດໃຫ້ເກີດ panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// ສົ່ງຄືນໄລຍະເວລາຂອງ `Ident` ນີ້, ລວມເອົາສາຍເຊືອກທັງ ໝົດ ທີ່ສົ່ງຄືນໂດຍ [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ຕັ້ງຄາ span ຂອງ `Ident` ນີ້ຖ້າເປັນໄປໄດ້ການປ່ຽນແປງສະພາບການອະນາໄມຂອງຕົນ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ຂົວພຽງແຕ່ສະຫນອງ `to_string`, ໃຊ້ `fmt::Display` ອີງໃສ່ມັນ (ຢ່າງສິ້ນເຊີງຂອງສາຍພົວພັນປົກກະຕິລະຫວ່າງສອງ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ພິມຕົວລະບຸເປັນສະຕິງທີ່ຄວນຈະກັບຄືນໄປບ່ອນແປງ losslessly ເປັນບຸດຽວກັນໄດ້.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// A ຫນັງສື string (`"hello"`), ສະຕິງ byte (`b"hello"`), ມີລັກສະນະ (`'a'`), ອັກຂະລະໄບ (`b'a'`), ຈໍານວນເຕັມຫລືຈໍານວນຈຸດທີ່ເລື່ອນໄດ້ມີຫຼືບໍ່ມີຕໍ່ທ້າຍ (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// ຕົວອັກສອນແບບບູລະຄື `true` ແລະ `false` ບໍ່ເປັນທີ່ນີ້, ພວກເຂົາເຈົ້າແມ່ນ `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// ສ້າງໃຫມ່ Suffix integer ທີ່ຮູ້ຫນັງສືທີ່ມີມູນຄ່າທີ່ກໍານົດໄວ້.
        ///
        /// ຟັງຊັນນີ້ຈະສ້າງ integer ຄື `1u32` ເປັນທີ່ຄ່າຈໍານວນເຕັມທີ່ລະບຸໄວ້ເປັນສ່ວນທໍາອິດຂອງ token ແລະປະການແມ່ນພາຢູ່ໃນຕອນທ້າຍໄດ້.
        /// ຕົວອັກສອນສ້າງຈາກຈໍານວນລົບອາດຈະບໍ່ລອດຕະຫຼອດການເດີນທາງໂດຍຜ່ານ `TokenStream` ຫຼືຊ່ອຍແນ່ແລະອາດຈະໄດ້ຮັບການແຍກອອກເປັນສອງ tokens (`-` ແລະຮູ້ຫນັງສືບວກ).
        ///
        ///
        /// ຕົວອັກສອນສ້າງໂດຍຜ່ານວິທີການນີ້ມີ span `Span::call_site()` ຕັ້ງແຕ່ຕອນຕົ້ນ, ຊຶ່ງສາມາດໄດ້ຮັບການ configured ກັບວິທີການ `set_span` ຕ່ໍາກວ່າ.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// ສ້າງຕົວເລກທີ່ບໍ່ຖືກລະບຸຕົວ ໜັງ ສືແບບ ໃໝ່ ທີ່ມີຕົວຕົນຕາມມູນຄ່າທີ່ລະບຸ.
        ///
        /// ຟັງຊັນນີ້ຈະສ້າງຕົວເລກເຕັມຄ້າຍຄື `1` ເຊິ່ງຄຸນຄ່າຂອງເລກເຕັມທີ່ ກຳ ນົດໄວ້ແມ່ນພາກ ທຳ ອິດຂອງ token.
        /// No ທ້າຍແມ່ນກໍານົດໄວ້ໃນ token ນີ້, ຊຶ່ງຫມາຍຄວາມວ່າ invocations ຄື `Literal::i8_unsuffixed(1)` ແມ່ນທຽບເທົ່າກັບ `Literal::u32_unsuffixed(1)`.
        /// ຕົວ ໜັງ ສືທີ່ສ້າງຂື້ນຈາກຕົວເລກລົບອາດຈະບໍ່ລອດຊີວິດຈາກລາງວັນໂດຍຜ່ານ `TokenStream` ຫລືຊ່ອຍແນ່ແລະອາດຈະຖືກແຍກອອກເປັນສອງ tokens (`-` ແລະຕົວ ໜັງ ສືໃນທາງບວກ).
        ///
        ///
        /// ຕົວອັກສອນສ້າງໂດຍຜ່ານວິທີການນີ້ມີ span `Span::call_site()` ຕັ້ງແຕ່ຕອນຕົ້ນ, ຊຶ່ງສາມາດໄດ້ຮັບການ configured ກັບວິທີການ `set_span` ຕ່ໍາກວ່າ.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// ສ້າງຈຸດລອຍນ້ ຳ ທີ່ບໍ່ມີຕົວຕົນ ໃໝ່.
    ///
    /// constructor ນີ້ແມ່ນຄ້າຍຄືກັນກັບທີ່ຄ້າຍຄື `Literal::i8_unsuffixed` ທີ່ມູນຄ່າທີ່ເລື່ອນໄດ້ຖືກປ່ອຍອອກມາໂດຍກົງເຂົ້າໄປໃນ token ແຕ່ບໍ່ທ້າຍຖືກນໍາໃຊ້, ດັ່ງນັ້ນມັນອາດຈະໄດ້ຮັບການອະນຸມານຈະເປັນ `f64` ຕໍ່ມາໃນ compiler ໄດ້.
    ///
    /// ຕົວ ໜັງ ສືທີ່ສ້າງຂື້ນຈາກຕົວເລກລົບອາດຈະບໍ່ລອດຊີວິດຈາກລາງວັນໂດຍຜ່ານ `TokenStream` ຫລືຊ່ອຍແນ່ແລະອາດຈະຖືກແຍກອອກເປັນສອງ tokens (`-` ແລະຕົວ ໜັງ ສືໃນທາງບວກ).
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ຮຽກຮ້ອງໃຫ້ມີທີ່ເລື່ອນໄດ້ລະບຸແມ່ນຈໍາກັດ, ສໍາລັບການຍົກຕົວຢ່າງຖ້າຫາກວ່າມັນເປັນອະນັນຫຼື NaN function ນີ້ຈະ panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// ສ້າງຕົວອັກສອນຈຸດ ໃໝ່ ທີ່ມີຕົວອັກສອນ ໃໝ່.
    ///
    /// constructor ນີ້ຈະສ້າງຫນັງສືຄື `1.0f32` ທີ່ມູນຄ່າທີ່ກໍານົດໄວ້ແມ່ນສ່ວນຫນຶ່ງກ່ອນຂອງ token ແລະ `f32` ເປັນຄໍາຕໍ່ທ້າຍຂອງ token ໄດ້.
    /// token ນີ້ຈະສະເຫມີໄດ້ຮັບການອະນຸມານຈະເປັນ `f32` ໃນ compiler ໄດ້.
    /// ຕົວ ໜັງ ສືທີ່ສ້າງຂື້ນຈາກຕົວເລກລົບອາດຈະບໍ່ລອດຊີວິດຈາກລາງວັນໂດຍຜ່ານ `TokenStream` ຫລືຊ່ອຍແນ່ແລະອາດຈະຖືກແຍກອອກເປັນສອງ tokens (`-` ແລະຕົວ ໜັງ ສືໃນທາງບວກ).
    ///
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ຮຽກຮ້ອງໃຫ້ມີທີ່ເລື່ອນໄດ້ລະບຸແມ່ນຈໍາກັດ, ສໍາລັບການຍົກຕົວຢ່າງຖ້າຫາກວ່າມັນເປັນອະນັນຫຼື NaN function ນີ້ຈະ panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// ສ້າງຈຸດລອຍນ້ ຳ ທີ່ບໍ່ມີຕົວຕົນ ໃໝ່.
    ///
    /// constructor ນີ້ແມ່ນຄ້າຍຄືກັນກັບທີ່ຄ້າຍຄື `Literal::i8_unsuffixed` ທີ່ມູນຄ່າທີ່ເລື່ອນໄດ້ຖືກປ່ອຍອອກມາໂດຍກົງເຂົ້າໄປໃນ token ແຕ່ບໍ່ທ້າຍຖືກນໍາໃຊ້, ດັ່ງນັ້ນມັນອາດຈະໄດ້ຮັບການອະນຸມານຈະເປັນ `f64` ຕໍ່ມາໃນ compiler ໄດ້.
    ///
    /// ຕົວ ໜັງ ສືທີ່ສ້າງຂື້ນຈາກຕົວເລກລົບອາດຈະບໍ່ລອດຊີວິດຈາກລາງວັນໂດຍຜ່ານ `TokenStream` ຫລືຊ່ອຍແນ່ແລະອາດຈະຖືກແຍກອອກເປັນສອງ tokens (`-` ແລະຕົວ ໜັງ ສືໃນທາງບວກ).
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ຮຽກຮ້ອງໃຫ້ມີທີ່ເລື່ອນໄດ້ລະບຸແມ່ນຈໍາກັດ, ສໍາລັບການຍົກຕົວຢ່າງຖ້າຫາກວ່າມັນເປັນອະນັນຫຼື NaN function ນີ້ຈະ panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// ສ້າງຕົວອັກສອນຈຸດ ໃໝ່ ທີ່ມີຕົວອັກສອນ ໃໝ່.
    ///
    /// constructor ນີ້ຈະສ້າງຫນັງສືຄື `1.0f64` ທີ່ມູນຄ່າທີ່ກໍານົດໄວ້ແມ່ນສ່ວນຫນຶ່ງກ່ອນຂອງ token ແລະ `f64` ເປັນຄໍາຕໍ່ທ້າຍຂອງ token ໄດ້.
    /// token ນີ້ສະເຫມີຈະຖືກ inferred ທີ່ຈະເປັນ `f64` ໃນເຄື່ອງແຕ່ງ.
    /// ຕົວ ໜັງ ສືທີ່ສ້າງຂື້ນຈາກຕົວເລກລົບອາດຈະບໍ່ລອດຊີວິດຈາກລາງວັນໂດຍຜ່ານ `TokenStream` ຫລືຊ່ອຍແນ່ແລະອາດຈະຖືກແຍກອອກເປັນສອງ tokens (`-` ແລະຕົວ ໜັງ ສືໃນທາງບວກ).
    ///
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ຮຽກຮ້ອງໃຫ້ມີທີ່ເລື່ອນໄດ້ລະບຸແມ່ນຈໍາກັດ, ສໍາລັບການຍົກຕົວຢ່າງຖ້າຫາກວ່າມັນເປັນອະນັນຫຼື NaN function ນີ້ຈະ panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// ຊ່ອຍແນ່.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// ຕົວ ໜັງ ສືຕົວ ໜັງ ສື.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// ໄບຕ໌ string ທີ່ຮູ້ຫນັງສື.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// ກັບຄືນຂອບເຂດທີ່ລວມເອົາຕົວ ໜັງ ສືນີ້.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ຕັ້ງຄາ span ທີ່ກ່ຽວຂ້ອງສໍາລັບການຮູ້ຫນັງສືນີ້.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// ຜົນໄດ້ຮັບເປັນ `Span` ທີ່ສິ່ງປີກຍ່ອຍຂອງ `self.span()` ມີພຽງແຕ່ຂໍ້ມູນໄບໃນລະດັບ `range`.
    /// ຜົນໄດ້ຮັບ `None` ຖ້າ span ຈະ, ໄດ້ຮັບການ trimmed ແມ່ນຢູ່ນອກຂອບເຂດຂອງ `self` ໄດ້.
    ///
    // FIXME(SergioBenitez): ກວດເບິ່ງວ່າຊ່ວງ byte ເລີ່ມຕົ້ນແລະສິ້ນສຸດຢູ່ຂອບເຂດ UTF-8 ຂອງແຫຼ່ງ.
    // ຖ້າບໍ່ດັ່ງນັ້ນ, ມັນເປັນໄປໄດ້ວ່າເປັນ panic ຈະເກີດຂຶ້ນຢູ່ບ່ອນອື່ນໃນເວລາທີ່ຂໍ້ຄວາມແຫລ່ງທີ່ມາຖືກພິມ.
    // FIXME(SergioBenitez): ມັນບໍ່ມີທາງໃຫ້ຜູ້ໃຊ້ຮູ້ວ່າ `self.span()` ມີແຜນທີ່ຕົວຈິງແນວໃດ, ສະນັ້ນວິທີການນີ້ສາມາດຖືກເອີ້ນວ່າຕາບອດເທົ່ານັ້ນ.
    // ຍົກຕົວຢ່າງ, `to_string()` ສຳ ລັບຕົວລະຄອນ 'c' ກັບຄືນ "'\u{63}'";ບໍ່ມີທາງໃດ ສຳ ລັບຜູ້ໃຊ້ທີ່ຈະຮູ້ວ່າຕົວ ໜັງ ສືແຫຼ່ງຂໍ້ມູນແມ່ນ 'c' ຫລືວ່າມັນແມ່ນ '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) ບາງສິ່ງບາງຢ່າງ akin ກັບ `Option::cloned`, ແຕ່ສໍາລັບ `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, ຂົວພຽງແຕ່ສະຫນອງ `to_string`, ໃຊ້ `fmt::Display` ອີງໃສ່ມັນ (ຢ່າງສິ້ນເຊີງຂອງສາຍພົວພັນປົກກະຕິລະຫວ່າງສອງ).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ການພິມຫນັງສືເປັນ string ທີ່ຄວນຈະກັບຄືນໄປບ່ອນແປງ losslessly ເປັນທີ່ຮູ້ຫນັງສືດຽວກັນ (ຍົກເວັ້ນສໍາລັບການໄດ້ຕະຫຼອດໄປໄດ້ສໍາລັບຕົວອັກສອນຈຸດທີ່ເລື່ອນໄດ້) ໄດ້.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// ການເຂົ້າເຖິງການຕິດຕາມການປ່ຽນແປງສະພາບແວດລ້ອມ.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// ດຶງຂໍ້ມູນຕົວແປສະພາບແວດລ້ອມແລະເພີ່ມມັນກັບສ້າງຂໍ້ມູນເພິ່ງພາອາໄສ.
    /// ສ້າງລະບົບການປະຕິບັດການລວບລວມຂໍ້ມູນຈະຮູ້ວ່າຕົວແປໄດ້ຖືກເຂົ້າເຖິງໃນລະຫວ່າງການລວບລວມຂໍ້ມູນແລະຈະສາມາດເຮັດການກໍ່ສ້າງຄືນ ໃໝ່ ເມື່ອຄ່າຂອງຕົວປ່ຽນນັ້ນປ່ຽນແປງ.
    ///
    /// ນອກຈາກເພີ່ງພາອາໃສການຕິດຕາມຫນ້າທີ່ນີ້ຄວນຈະທຽບເທົ່າກັບ `env::var` ຈາກຫ້ອງສະຫມຸດມາດຕະຖານ, ຍົກເວັ້ນວ່າການໂຕ້ຖຽງທີ່ຈະຕ້ອງ UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}