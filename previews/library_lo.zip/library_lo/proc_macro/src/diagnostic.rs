use crate::Span;

/// enum ເປັນຕົວແທນຂອງລະດັບການວິນິດໄສ.
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
#[derive(Copy, Clone, Debug)]
#[non_exhaustive]
pub enum Level {
    /// ຄວາມຜິດພາດ.
    Error,
    /// A ເຕືອນ.
    Warning,
    /// ໝາຍ ເຫດ.
    Note,
    /// ຂໍ້ຄວາມຊ່ວຍເຫຼືອ.
    Help,
}

/// Trait ປະຕິບັດໂດຍປະເພດທີ່ສາມາດປ່ຽນເປັນຊຸດຂອງ `Span`s.
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub trait MultiSpan {
    /// ແປງ `self` ເປັນ `Vec<Span>`.
    fn into_spans(self) -> Vec<Span>;
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl MultiSpan for Span {
    fn into_spans(self) -> Vec<Span> {
        vec![self]
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl MultiSpan for Vec<Span> {
    fn into_spans(self) -> Vec<Span> {
        self
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl<'a> MultiSpan for &'a [Span] {
    fn into_spans(self) -> Vec<Span> {
        self.to_vec()
    }
}

/// ໂຄງສ້າງທີ່ເປັນຕົວແທນຂອງຂໍ້ຄວາມບົ່ງມະຕິແລະຂໍ້ຄວາມເດັກນ້ອຍທີ່ກ່ຽວຂ້ອງ.
///
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
#[derive(Clone, Debug)]
pub struct Diagnostic {
    level: Level,
    message: String,
    spans: Vec<Span>,
    children: Vec<Diagnostic>,
}

macro_rules! diagnostic_child_methods {
    ($spanned:ident, $regular:ident, $level:expr) => {
        /// ເພີ່ມລູກຂໍ້ບົ່ງມະຕິໃຫມ່ທີ່ຈະ `self` ກັບລະດັບທີ່ໄດ້ກໍານົດໂດຍຊື່ຂອງວິທີການນີ້ມີ `spans` ຮັບແລະ `message`.
        ///
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $spanned<S, T>(mut self, spans: S, message: T) -> Diagnostic
        where
            S: MultiSpan,
            T: Into<String>,
        {
            self.children.push(Diagnostic::spanned(spans, $level, message));
            self
        }

        /// ເພີ່ມລູກຂໍ້ບົ່ງມະຕິໃຫມ່ທີ່ຈະ `self` ກັບລະດັບທີ່ໄດ້ກໍານົດໂດຍຊື່ຂອງວິທີການນີ້ກັບ `message` ດັ່ງກ່າວ.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $regular<T: Into<String>>(mut self, message: T) -> Diagnostic {
            self.children.push(Diagnostic::new($level, message));
            self
        }
    };
}

/// Iterator ໃນໄລຍະເດັກນ້ອຍການບົ່ງມະຕິຂອງ `Diagnostic`.
#[derive(Debug, Clone)]
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub struct Children<'a>(std::slice::Iter<'a, Diagnostic>);

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl<'a> Iterator for Children<'a> {
    type Item = &'a Diagnostic;

    fn next(&mut self) -> Option<Self::Item> {
        self.0.next()
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl Diagnostic {
    /// ສ້າງເປັນການວິເຄາະຂອງໃຫມ່ມີ `level` ຮັບແລະ `message`.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn new<T: Into<String>>(level: Level, message: T) -> Diagnostic {
        Diagnostic { level, message: message.into(), spans: vec![], children: vec![] }
    }

    /// ສ້າງເປັນການວິເຄາະຂອງໃຫມ່ມີໃຫ້ `level` ແລະ `message` ຊີ້ໄປຫາທີ່ກໍານົດໄວ້ໃຫ້ຂອງ `spans`.
    ///
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn spanned<S, T>(spans: S, level: Level, message: T) -> Diagnostic
    where
        S: MultiSpan,
        T: Into<String>,
    {
        Diagnostic { level, message: message.into(), spans: spans.into_spans(), children: vec![] }
    }

    diagnostic_child_methods!(span_error, error, Level::Error);
    diagnostic_child_methods!(span_warning, warning, Level::Warning);
    diagnostic_child_methods!(span_note, note, Level::Note);
    diagnostic_child_methods!(span_help, help, Level::Help);

    /// ສົ່ງຄືນການວິນິດໄສ `level` ສຳ ລັບ `self`.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn level(&self) -> Level {
        self.level
    }

    /// ຕັ້ງຄ່າລະດັບໃນ `self` ເຖິງ `level`.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_level(&mut self, level: Level) {
        self.level = level;
    }

    /// ສົ່ງຄືນຂໍ້ຄວາມໃນ `self`.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn message(&self) -> &str {
        &self.message
    }

    /// ກໍານົດຂໍ້ຄວາມໃນ `self` ກັບ `message` ໄດ້.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_message<T: Into<String>>(&mut self, message: T) {
        self.message = message.into();
    }

    /// ສົ່ງຄືນ `Span`s ໃນ `self`.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn spans(&self) -> &[Span] {
        &self.spans
    }

    /// ຕັ້ງຄ່າ `Span`s ໃນ `self` ຫາ `spans`.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_spans<S: MultiSpan>(&mut self, spans: S) {
        self.spans = spans.into_spans();
    }

    /// ຜົນໄດ້ຮັບເປັນ iterator ໃນໄລຍະເດັກນ້ອຍການບົ່ງມະຕິຂອງ `self`.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn children(&self) -> Children<'_> {
        Children(self.children.iter())
    }

    /// ປ່ອຍໄດ້ບົ່ງມະຕິ.
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn emit(self) {
        fn to_internal(spans: Vec<Span>) -> crate::bridge::client::MultiSpan {
            let mut multi_span = crate::bridge::client::MultiSpan::new();
            for span in spans {
                multi_span.push(span.0);
            }
            multi_span
        }

        let mut diag = crate::bridge::client::Diagnostic::new(
            self.level,
            &self.message[..],
            to_internal(self.spans),
        );
        for c in self.children {
            diag.sub(c.level, &c.message[..], to_internal(c.spans));
        }
        diag.emit();
    }
}