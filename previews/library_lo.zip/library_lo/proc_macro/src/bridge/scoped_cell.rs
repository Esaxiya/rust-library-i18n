//! `Cell` ແຕກຕ່າງສໍາລັບ (scoped) lifetimes existential.

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// ພິມຄໍາຮ້ອງສະຫມັກ lambda, ມີຕະຫຼອດຊີວິດໄດ້.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// ພິມ lambda ການ lifetime ເປັນ, ຕົວຢ່າງ, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) ເຮັດວຽກຮອບດ້ານຂໍ້ ຈຳ ກັດການຄາດຄະເນດ້ວຍ newtype FIXME(#52812) ທົດແທນດ້ວຍ `&'a mut <T as ApplyL<'b>>::Out`
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// ກຳ ນົດຄ່າໃນ `self` ຫາ `replacement` ໃນຂະນະທີ່ແລ່ນ `f`, ເຊິ່ງໄດ້ຮັບຄ່າເກົ່າ, ເຊິ່ງກັນແລະກັນ.
    /// ມູນຄ່າເກົ່າຈະໄດ້ຮັບການຟື້ນຟູຫຼັງຈາກ `f` ອອກ, ເຖິງແມ່ນວ່າໂດຍ panic, ລວມທັງການດັດແປງທີ່ເຮັດໂດຍ `f`.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// Wrapper ຮັບປະກັນວ່າວ່າແຕ່ລະຫ້ອງການສະເຫມີໄດ້ຮັບການເຕີມລົງໄປ (ກັບລັດຕົ້ນສະບັບ, ການປ່ຽນແປງທາງເລືອກໂດຍ `f`), ເຖິງແມ່ນວ່າຖ້າຫາກວ່າ `f` ໄດ້ພາກັນຢ້ານກົວ.
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// ກຳ ນົດຄ່າໃນ `self` ຫາ `value` ໃນຂະນະທີ່ແລ່ນ `f`.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}