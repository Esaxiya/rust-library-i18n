#![stable(feature = "rust1", since = "1.0.0")]

//! ກະທູ້, ຄວາມປອດໄພ pointers ອ້າງອິງ, ນັບ.
//!
//! ເບິ່ງເອກະສານ [`Arc<T>`][Arc] ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// ຂໍ້ ຈຳ ກັດທີ່ອ່ອນຂອງ ຈຳ ນວນເອກະສານອ້າງອີງທີ່ອາດຈະຖືກ ນຳ ໄປສູ່ `Arc`.
///
/// ການໄປຂ້າງເທິງຂີດ ຈຳ ກັດນີ້ຈະຍົກເລີກໂຄງການຂອງທ່ານ (ເຖິງແມ່ນວ່າບໍ່ ຈຳ ເປັນ) ທີ່ _exactly_ `MAX_REFCOUNT + 1` ອ້າງອີງ.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ບໍ່ຮອງຮັບຮົ້ວຄວາມ ຈຳ.
// ເພື່ອຫຼີກເວັ້ນການລາຍງານໃນທາງບວກບໍ່ຖືກຕ້ອງໃນ Arc/ອ່ອນແອນໍາໃຊ້ປະຕິບັດການໂຫຼດປະລໍາມະນູສໍາລັບ synchronization ແທນທີ່ຈະ.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// ຕົວຊີ້ບອກການນັບ-ການນັບ-ກະທູ້ທີ່ປອດໄພ.'Arc' ຫຍໍ້ມາຈາກ 'ການອ້າງອີງເຖິງປະລໍາມະນູ.'
///
/// ປະເພດ `Arc<T>` ສະ ໜອງ ຄວາມເປັນເຈົ້າຂອງຮ່ວມກັນຂອງມູນຄ່າຂອງປະເພດ `T`, ຈັດສັນເປັນຫ້າງ.ການສະ ເໜີ [`clone`][clone] ໃນ `Arc` ຜະລິດຕົວຢ່າງ `Arc` ໃໝ່, ເຊິ່ງຊີ້ໃຫ້ເຫັນເຖິງການຈັດສັນອັນດຽວກັນຢູ່ໃນ heap ຄືກັບແຫຼ່ງ `Arc`, ໃນຂະນະທີ່ເພີ່ມ ຈຳ ນວນການອ້າງອີງ.
/// ເມື່ອຕົວຊີ້ `Arc` X ສຸດທ້າຍໄປຫາການຈັດສັນທີ່ຖືກມອບໃຫ້ຖືກ ທຳ ລາຍ, ມູນຄ່າທີ່ເກັບໄວ້ໃນການຈັດສັນນັ້ນ (ມັກຈະເອີ້ນວ່າ "inner value") ກໍ່ຖືກຫຼຸດລົງເຊັ່ນກັນ.
///
/// ເອກະສານອ້າງອີງທີ່ແບ່ງປັນໃນ Rust ບໍ່ອະນຸຍາດໃຫ້ມີການກາຍພັນໂດຍຄ່າເລີ່ມຕົ້ນ, ແລະ `Arc` ບໍ່ມີຂໍ້ຍົກເວັ້ນ: ໂດຍທົ່ວໄປທ່ານບໍ່ສາມາດຮັບເອົາການອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບບາງສິ່ງບາງຢ່າງພາຍໃນ `Arc`.ຖ້າທ່ານຕ້ອງການປ່ຽນສາຍພັນຜ່ານ `Arc`, ໃຫ້ໃຊ້ [`Mutex`][mutex], [`RwLock`][rwlock], ຫຼື ໜຶ່ງ ໃນປະເພດ [`Atomic`][atomic].
///
/// ## ຄວາມປອດໄພຂອງກະທູ້
///
/// ບໍ່ຄືກັບ [`Rc<T>`], `Arc<T>` ໃຊ້ການປະຕິບັດງານປະລໍາມະນູເພື່ອການນັບຄໍາອ້າງອີງຂອງມັນ.ນີ້ຫມາຍຄວາມວ່າມັນແມ່ນຄວາມປອດໄພຂອງກະທູ້.ຂໍ້ເສຍປຽບແມ່ນວ່າການປະຕິບັດງານປະລະມານູມີລາຄາແພງກ່ວາການເຂົ້າເຖິງຄວາມຊົງ ຈຳ ທຳ ມະດາ.ຖ້າທ່ານບໍ່ໄດ້ແບ່ງປັນການຈັດສັນການອ້າງອີງລະຫວ່າງກະທູ້, ໃຫ້ພິຈາລະນາໃຊ້ [`Rc<T>`] ສຳ ລັບລາຍຈ່າຍທີ່ຕ່ ຳ ກວ່າ.
/// [`Rc<T>`] ແມ່ນຄ່າເລີ່ມຕົ້ນທີ່ປອດໄພ, ເພາະວ່ານັກຂຽນຈະຈັບຄວາມພະຍາຍາມໃດໆທີ່ຈະສົ່ງ [`Rc<T>`] ລະຫວ່າງກະທູ້.
/// ເຖິງຢ່າງໃດກໍ່ຕາມ, ຫ້ອງສະ ໝຸດ ອາດຈະເລືອກ `Arc<T>` ເພື່ອໃຫ້ຜູ້ບໍລິໂພກຫໍສະ ໝຸດ ມີຄວາມຄ່ອງຕົວຫຼາຍຂື້ນ.
///
/// `Arc<T>` ຈະໃຊ້ [`Send`] ແລະ [`Sync`] ຕາບໃດທີ່ `T` ປະຕິບັດ [`Send`] ແລະ [`Sync`].
/// ເປັນຫຍັງທ່ານຈຶ່ງບໍ່ສາມາດໃສ່ `T` ແບບທີ່ບໍ່ມີຄວາມປອດໄພໃນ `Arc<T>` ເພື່ອເຮັດໃຫ້ມັນປອດໄພ?ນີ້ອາດຈະເປັນເລື່ອງເລັກນ້ອຍໃນຕອນ ທຳ ອິດ: ຫຼັງຈາກທີ່ທັງ ໝົດ, ມັນບໍ່ແມ່ນຄວາມປອດໄພຂອງກະທູ້ `Arc<T>` ບໍ?ສິ່ງ ສຳ ຄັນແມ່ນສິ່ງນີ້: `Arc<T>` ເຮັດໃຫ້ມັນກະທູ້ປອດໄພທີ່ຈະມີຄວາມເປັນເຈົ້າຂອງຫຼາຍຂໍ້ມູນດຽວກັນ, ແຕ່ມັນບໍ່ໄດ້ເພີ່ມຄວາມປອດໄພຂອງກະທູ້ໃຫ້ກັບຂໍ້ມູນຂອງມັນ.
///
/// ພິຈາລະນາ `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] ບໍ່ແມ່ນ [`Sync`], ແລະຖ້າຫາກວ່າ `Arc<T>` ແມ່ນສະເຫມີ [`Send`], `Arc <` [`RefCell<T>`]`>`ກໍ່ຈະເປັນເຊັ່ນກັນ.
/// ແຕ່ຫຼັງຈາກນັ້ນພວກເຮົາມີບັນຫາ:
/// [`RefCell<T>`] ບໍ່ແມ່ນກະທູ້ທີ່ປອດໄພ;ມັນຕິດຕາມ ຈຳ ນວນການກູ້ຢືມໂດຍ ນຳ ໃຊ້ການປະຕິບັດງານທີ່ບໍ່ແມ່ນປະລໍາມະນູ.
///
/// ໃນທີ່ສຸດ, ນີ້ຫມາຍຄວາມວ່າທ່ານອາດຈະຕ້ອງການຄູ່ `Arc<T>` ກັບບາງປະເພດ [`std::sync`], ໂດຍປົກກະຕິແມ່ນ [`Mutex<T>`][mutex].
///
/// ## ວົງຈອນການລະເມີດກັບ `Weak`
///
/// ວິທີ [`downgrade`][downgrade] ສາມາດໃຊ້ເພື່ອສ້າງຕົວຊີ້ [`Weak`] ທີ່ບໍ່ເປັນເຈົ້າຂອງ.ຕົວຊີ້ [`Weak`] ສາມາດເປັນ [`ຍົກລະດັບ`][ຍົກລະດັບ] d ໃຫ້ເປັນ `Arc`, ແຕ່ສິ່ງນີ້ຈະສົ່ງຄືນ [`None`] ຖ້າມູນຄ່າທີ່ເກັບໄວ້ໃນການຈັດສັນໄດ້ຖືກລຸດລົງແລ້ວ.
/// ເວົ້າອີກຢ່າງ ໜຶ່ງ, ຜູ້ຊີ້ບອກ `Weak` ບໍ່ໄດ້ຮັກສາມູນຄ່າພາຍໃນການຈັດສັນໃຫ້ມີຊີວິດ;ເຖິງຢ່າງໃດກໍ່ຕາມ, ພວກເຂົາເຮັດ * ຮັກສາການຈັດສັນ (ຮ້ານຫລັງ ສຳ ລັບມູນຄ່າ) ທີ່ມີຊີວິດຢູ່.
///
/// ວົງຈອນລະຫວ່າງຈຸດຊີ້ `Arc` X ຈະບໍ່ມີການຈັດການກັບຈຸດໃດເລີຍ.
/// ດ້ວຍເຫດຜົນນີ້, [`Weak`] ຖືກໃຊ້ເພື່ອ ທຳ ລາຍຮອບວຽນ.ຍົກຕົວຢ່າງ, ຕົ້ນໄມ້ສາມາດມີຈຸດຊີ້ `Arc` ທີ່ເຂັ້ມແຂງຈາກຂໍ້ຂອງພໍ່ແມ່ເຖິງເດັກ, ແລະ [`Weak`] ຊີ້ຈາກເດັກກັບຄືນຫາພໍ່ແມ່.
///
/// # ການອ້າງອິງ Cloning
///
/// ການສ້າງເອກະສານອ້າງອິງ ໃໝ່ ຈາກຕົວຊີ້ທີ່ນັບມາແລ້ວທີ່ມີຢູ່ແລ້ວແມ່ນເຮັດໂດຍໃຊ້ `Clone` trait ທີ່ປະຕິບັດ ສຳ ລັບ [`Arc<T>`][Arc] ແລະ [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // ສອງ syntaxes ຂ້າງລຸ່ມນີ້ແມ່ນທຽບເທົ່າ.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b ແລະ foo ມີ Arcs ທັງຫມົດທີ່ຊີ້ໃຫ້ເຫັນເຖິງສະຖານທີ່ຫນ່ວຍຄວາມຈໍາດຽວກັນ
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` ການອ້າງອິງອັດຕະໂນມັດຕໍ່ `T` (ຜ່ານ [`Deref`][deref] trait), ດັ່ງນັ້ນທ່ານສາມາດໂທຫາວິທີຂອງ `T ໃນມູນຄ່າຂອງປະເພດ `Arc<T>`.ເພື່ອຫລີກລ້ຽງການປະທະກັນຊື່ກັບວິທີການຂອງ`T`, ວິທີການຂອງ `Arc<T>` ເອງແມ່ນ ໜ້າ ທີ່ທີ່ກ່ຽວຂ້ອງ, ເອີ້ນວ່າການໃຊ້ [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `ປະຕູໂຄ້ງ<T>ການປະຕິບັດ`` ຂອງ traits ເຊັ່ນ `Clone` ອາດຈະຖືກເອີ້ນວ່າການ ນຳ ໃຊ້ syntax ທີ່ມີຄຸນນະພາບເຕັມ.
/// ບາງຄົນມັກໃຊ້ syntax ທີ່ມີຄຸນນະພາບເຕັມສ່ວນ, ໃນຂະນະທີ່ຄົນອື່ນມັກໃຊ້ syntax-call-method.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // syntax ແບບວິທີການໂທ
/// let arc2 = arc.clone();
/// // syntax ທີ່ມີຄຸນນະພາບຄົບຖ້ວນ
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ບໍ່ເອົາໃຈໃສ່ໂດຍອັດຕະໂນມັດຕໍ່ `T`, ເພາະວ່າຄ່າພາຍໃນອາດຈະຖືກຫຼຸດລົງແລ້ວ.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// ການແລກປ່ຽນຂໍ້ມູນທີ່ບໍ່ປ່ຽນແປງບາງຢ່າງລະຫວ່າງກະທູ້:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// ໃຫ້ສັງເກດວ່າພວກເຮົາ **ບໍ່** ດຳ ເນີນການກວດເຫຼົ່ານີ້ຢູ່ບ່ອນນີ້.
// ຜູ້ກໍ່ສ້າງ windows ໄດ້ຮັບຄວາມບໍ່ສະບາຍໃຈທີ່ສຸດຖ້າກະທູ້ມີກະທູ້ຫຼາຍກວ່າເກົ່າແລະຫຼັງຈາກນັ້ນກໍ່ຈະອອກໄປໃນເວລາດຽວກັນ (ບາງສິ່ງບາງຢ່າງທີ່ລົ້ມລະລາຍ) ດັ່ງນັ້ນພວກເຮົາພຽງແຕ່ຫລີກລ້ຽງສິ່ງນີ້ໂດຍການບໍ່ທົດສອບເຫຼົ່ານີ້.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// ການແລກປ່ຽນ [`AtomicUsize`] ທີ່ສາມາດປ່ຽນແປງໄດ້:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// ເບິ່ງ [`rc` documentation][rc_examples] ສຳ ລັບຕົວຢ່າງເພີ່ມເຕີມຂອງການນັບການອ້າງອີງໂດຍທົ່ວໄປ.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` ແມ່ນຮຸ່ນຂອງ [`Arc`] ທີ່ຖືເອກະສານອ້າງອີງທີ່ບໍ່ເປັນເຈົ້າຂອງໃນການຈັດສັນການຄຸ້ມຄອງ.
/// ການຈັດສັນແມ່ນເຂົ້າເຖິງໂດຍການໂທຫາ [`upgrade`] ໃສ່ຕົວຊີ້ `Weak`, ເຊິ່ງຈະກັບຄືນ [`Option`] `<` [`Arc`] `<T>>`.
///
/// ເນື່ອງຈາກເອກະສານອ້າງອີງ `Weak` ບໍ່ໄດ້ນັບໃສ່ການເປັນເຈົ້າຂອງ, ມັນຈະບໍ່ປ້ອງກັນມູນຄ່າທີ່ເກັບໄວ້ໃນການຈັດສັນຈາກການລຸດລົງ, ແລະ `Weak` ເອງກໍ່ບໍ່ມີການຄ້ ຳ ປະກັນໃດໆກ່ຽວກັບມູນຄ່າທີ່ຍັງມີຢູ່.
///
/// ດັ່ງນັ້ນມັນອາດຈະສົ່ງຄືນ [`None`] ເມື່ອ [`ຍົກລະດັບ`] ງ.
/// ໃຫ້ສັງເກດຢ່າງໃດກໍຕາມທີ່ເປັນກະສານອ້າງອີງ `Weak`*ບໍ່* ປ້ອງກັນບໍ່ໃຫ້ການຈັດສັນຕົວຂອງມັນເອງ (ຮ້ານສໍາຮອງ) ຈາກຖືກ deallocated.
///
/// A `Weak` ຊີ້ເປັນປະໂຫຍດສໍາລັບການຮັກສາກະສານອ້າງອີງຊົ່ວຄາວເພື່ອການຈັດສັນຄຸ້ມຄອງໂດຍ [`Arc`] ໂດຍບໍ່ມີການປ້ອງກັນການມູນຄ່າຂອງຕົນໃນຈາກການຖືກປ່ອຍຕົວ.
/// ມັນໄດ້ຖືກນໍາໃຊ້ເພື່ອປ້ອງກັນບໍ່ໃຫ້ເອກະສານວົງລະຫວ່າງຕົວຊີ້ [`Arc`], ນັບຕັ້ງແຕ່ເອກະສານການເປັນເຈົ້າຂອງເຊິ່ງກັນແລະກັນຈະບໍ່ອະນຸຍາດໃຫ້ບໍ່ວ່າຈະ [`Arc`] ກັບຖືກຍົກເລີກ.
/// ຍົກຕົວຢ່າງ, ຕົ້ນໄມ້ສາມາດມີຕົວຊີ້ [`Arc`] X ທີ່ເຂັ້ມແຂງຈາກຂໍ້ຂອງພໍ່ແມ່ເຖິງເດັກ, ແລະ `Weak` ຊີ້ຈາກເດັກກັບຄືນຫາພໍ່ແມ່.
///
/// ວິທີປົກກະຕິທີ່ຈະໄດ້ຕົວຊີ້ `Weak` ແມ່ນການໂທຫາ [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // ນີ້ແມ່ນ `NonNull` ເພື່ອອະນຸຍາດໃຫ້ເພີ່ມປະສິດທິພາບຂະ ໜາດ ຂອງປະເພດນີ້ໃນຫໍສັງຄົມ, ແຕ່ມັນບໍ່ ຈຳ ເປັນຕ້ອງເປັນຕົວຊີ້ທີ່ຖືກຕ້ອງ.
    //
    // `Weak::new` ຕັ້ງຄ່ານີ້ໃຫ້ `usize::MAX` ເພື່ອວ່າມັນບໍ່ ຈຳ ເປັນຕ້ອງຈັດສັນພື້ນທີ່ຢູ່ເທິງ heap.
    // ນັ້ນບໍ່ແມ່ນຄຸນຄ່າທີ່ຕົວຊີ້ຕົວຈິງຈະມີເພາະວ່າ RcBox ມີຄວາມສອດຄ່ອງຢ່າງ ໜ້ອຍ 2.
    // ນີ້ເປັນໄປໄດ້ພຽງແຕ່ເມື່ອ `T: Sized`;`T` ທີ່ບໍ່ຖືກຕ້ອງ
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// ນີ້ແມ່ນ repr(C) ຫາ future-proof ຕໍ່ກັບການໂອນຄືນພາກສະ ໜາມ ທີ່ອາດຈະເປັນໄປໄດ້, ເຊິ່ງຈະແຊກແຊງ [into|from]_raw() ທີ່ປອດໄພຖ້າບໍ່ດັ່ງນັ້ນຂອງປະເພດພາຍໃນທີ່ຖ່າຍທອດໄດ້.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // ມູນຄ່າ usize::MAX ເຮັດ ໜ້າ ທີ່ເປັນຈຸດພິເສດ ສຳ ລັບ "locking" ຊົ່ວຄາວຄວາມສາມາດໃນການຍົກລະດັບຈຸດອ່ອນຫລືການຫຼຸດລົງຂອງຈຸດແຂງ;ນີ້ໄດ້ຖືກນໍາໃຊ້ເພື່ອຫຼີກເວັ້ນການເຊື້ອຊາດໃນ `make_mut` ແລະ `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// ກໍ່ສ້າງ `Arc<T>` ໃໝ່.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // ເລີ່ມນັບຊີ້ອ່ອນແອເປັນ 1 ຊຶ່ງເປັນຕົວຊີ້ອ່ອນແອທີ່ໄດ້ຈັດຂຶ້ນໂດຍການທັງຫມົດຄໍາແນະນໍາທີ່ເຂັ້ມແຂງ (kinda), ເບິ່ງ std/rc.rs ສໍາລັບຂໍ້ມູນເພີ່ມເຕີມ
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// ກໍ່ສ້າງ `Arc<T>` ໃໝ່ ໂດຍໃຊ້ຂໍ້ອ້າງອີງທີ່ອ່ອນແອຕໍ່ຕົວມັນເອງ.
    /// ຄວາມພະຍາຍາມທີ່ຈະຍົກລະດັບການອ້າງອິງທີ່ອ່ອນແອກ່ອນທີ່ ໜ້າ ທີ່ຈະກັບມານີ້ຈະສົ່ງຜົນໃຫ້ມູນຄ່າ `None`.
    /// ເຖິງຢ່າງໃດກໍ່ຕາມ, ເອກະສານອ້າງອີງທີ່ອ່ອນແອອາດຈະຖືກ cloned ໂດຍບໍ່ເສຍຄ່າແລະເກັບຮັກສາໄວ້ເພື່ອໃຊ້ໃນເວລາຕໍ່ມາ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // ກໍ່ສ້າງພາຍໃນລັດ "uninitialized" ດ້ວຍເອກະສານອ້າງອີງອ່ອນໆ.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // ມັນເປັນສິ່ງ ສຳ ຄັນທີ່ພວກເຮົາບໍ່ຄວນປະຖິ້ມຄວາມເປັນເຈົ້າຂອງຂອງເຄື່ອງຊີ້ທີ່ອ່ອນແອ, ຫຼືຖ້າບໍ່ດັ່ງນັ້ນຄວາມ ຈຳ ອາດຈະຖືກປ່ອຍຕົວໂດຍເວລາ `data_fn` ຈະກັບມາ.
        // ຖ້າພວກເຮົາຕ້ອງການຢາກເປັນເຈົ້າຂອງຢ່າງແທ້ຈິງ, ພວກເຮົາສາມາດສ້າງຕົວຊີ້ທີ່ອ່ອນແອເພີ່ມເຕີມ ສຳ ລັບຕົວເຮົາເອງ, ແຕ່ສິ່ງນີ້ຈະສົ່ງຜົນໃຫ້ມີການປັບປຸງເພີ່ມເຕີມຕໍ່ກັບ ຈຳ ນວນການອ້າງອີງທີ່ອ່ອນແອເຊິ່ງອາດຈະບໍ່ ຈຳ ເປັນຖ້າບໍ່ດັ່ງນັ້ນ.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // ດຽວນີ້ພວກເຮົາສາມາດຕັ້ງຄ່າພາຍໃນໃຫ້ຖືກຕ້ອງແລະຫັນກະສານອ້າງອີງທີ່ອ່ອນແອຂອງພວກເຮົາໄປສູ່ການອ້າງອີງທີ່ເຂັ້ມແຂງ.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // ຂໍ້ຄວາມຂ້າງເທິງນີ້ທີ່ຂຽນໃສ່ພາກສະ ໜາມ ຂໍ້ມູນຈະຕ້ອງສາມາດເບິ່ງເຫັນກະທູ້ຕ່າງໆເຊິ່ງສັງເກດເຫັນຕົວເລກທີ່ບໍ່ເຂັ້ມແຂງທີ່ບໍ່ແມ່ນສູນ.
            // ເພາະສະນັ້ນພວກເຮົາຕ້ອງການຢ່າງ ໜ້ອຍ "Release" ສັ່ງເພື່ອໃຫ້ຊິ້ງຂໍ້ມູນກັບ `compare_exchange_weak` ໃນ `Weak::upgrade`.
            //
            // "Acquire" ການສັ່ງສິນຄ້າແມ່ນບໍ່ຕ້ອງການ.
            // ເມື່ອພິຈາລະນາພຶດຕິ ກຳ ທີ່ເປັນໄປໄດ້ຂອງ `data_fn` ພວກເຮົາພຽງແຕ່ຕ້ອງການເບິ່ງສິ່ງທີ່ມັນສາມາດເຮັດໄດ້ດ້ວຍການອ້າງອີງເຖິງ `Weak` ທີ່ບໍ່ສາມາດຍົກລະດັບໄດ້:
            //
            // - ມັນສາມາດ *clone*`Weak`, ເພີ່ມຈໍານວນການອ້າງອີງທີ່ອ່ອນແອ.
            // - ມັນສາມາດຫຼຸດລົງ clones ເຫຼົ່ານັ້ນ, ຫຼຸດລົງຂອງຈໍານວນກະສານອ້າງອີງອ່ອນແອ (ແຕ່ຈະບໍ່ສູນ).
            //
            // ຜົນຂ້າງຄຽງເຫຼົ່ານີ້ບໍ່ສົ່ງຜົນກະທົບໃຫ້ພວກເຮົາໃນວິທີການໃດກໍ່ຕາມ, ແລະບໍ່ມີຜົນຂ້າງຄຽງອື່ນໆທີ່ເປັນໄປໄດ້ທີ່ມີລະຫັດຄວາມປອດໄພຢ່າງດຽວ.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // ເອກະສານທີ່ເຂັ້ມແຂງລວມຫມູ່ຄວນເປັນເຈົ້າຂອງກະສານອ້າງອີງອ່ອນແອແບ່ງປັນ, ສະນັ້ນບໍ່ດໍາເນີນການ destructor ສໍາລັບອ້າງອິງອ່ອນແອຂອງພວກເຮົາມີອາຍຸ.
        //
        mem::forget(weak);
        strong
    }

    /// ກໍ່ສ້າງ `Arc` ໃໝ່ ທີ່ມີເນື້ອໃນທີ່ບໍ່ມີການປ່ຽນແປງ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ການເລີ່ມຕົ້ນທີ່ ນຳ ສົ່ງ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// ກໍ່ສ້າງ `Arc` ໃໝ່ ທີ່ມີເນື້ອໃນທີ່ບໍ່ມີການຄວບຄຸມ, ດ້ວຍ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ເຕັມໄປດ້ວຍ `0` ໄບ.
    ///
    ///
    /// ເບິ່ງ [`MaybeUninit::zeroed`][zeroed] ສຳ ລັບຕົວຢ່າງຂອງການ ນຳ ໃຊ້ທີ່ຖືກຕ້ອງແລະບໍ່ຖືກຕ້ອງຂອງວິທີການນີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// ໂຄງສ້າງ `Pin<Arc<T>>` ໃຫມ່.
    /// ຖ້າ `T` ບໍ່ປະຕິບັດ `Unpin`, ຫຼັງຈາກນັ້ນ `data` ຈະຖືກໃສ່ໄວ້ໃນ ໜ່ວຍ ຄວາມ ຈຳ ແລະບໍ່ສາມາດເຄື່ອນຍ້າຍໄດ້.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// ກໍ່ສ້າງ `Arc<T>` ໃໝ່, ສົ່ງຄືນຂໍ້ຜິດພາດຖ້າການຈັດສັນລົ້ມເຫລວ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // ເລີ່ມນັບຊີ້ອ່ອນແອເປັນ 1 ຊຶ່ງເປັນຕົວຊີ້ອ່ອນແອທີ່ໄດ້ຈັດຂຶ້ນໂດຍການທັງຫມົດຄໍາແນະນໍາທີ່ເຂັ້ມແຂງ (kinda), ເບິ່ງ std/rc.rs ສໍາລັບຂໍ້ມູນເພີ່ມເຕີມ
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// ກໍ່ສ້າງ `Arc` ໃໝ່ ທີ່ມີເນື້ອໃນທີ່ບໍ່ໄດ້ຕັ້ງໃຈ, ສົ່ງຄືນຂໍ້ຜິດພາດຖ້າການຈັດສັນລົ້ມເຫລວ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ການເລີ່ມຕົ້ນທີ່ ນຳ ສົ່ງ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// ກໍ່ສ້າງ `Arc` ໃໝ່ ທີ່ມີເນື້ອໃນທີ່ບໍ່ໄດ້ຕັ້ງໃຈ, ດ້ວຍ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ເຕັມໄປດ້ວຍ `0` bytes, ສົ່ງຄືນຂໍ້ຜິດພາດຖ້າການຈັດສັນບໍ່ ສຳ ເລັດ.
    ///
    ///
    /// ເບິ່ງ [`MaybeUninit::zeroed`][zeroed] ສຳ ລັບຕົວຢ່າງຂອງການ ນຳ ໃຊ້ທີ່ຖືກຕ້ອງແລະບໍ່ຖືກຕ້ອງຂອງວິທີການນີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// ສົ່ງຄືນມູນຄ່າພາຍໃນ, ຖ້າ `Arc` ມີເອກະສານອ້າງອິງ ໜຶ່ງ ທີ່ແນ່ນອນ.
    ///
    /// ຖ້າບໍ່ດັ່ງນັ້ນ, ເປັນ [`Err`] ແມ່ນກັບຄືນກັບ `Arc` ດຽວກັນທີ່ໄດ້ຖືກຮັບຮອງໃນ.
    ///
    ///
    /// ສິ່ງນີ້ຈະປະສົບຜົນ ສຳ ເລັດເຖິງແມ່ນວ່າຈະມີເອກະສານອ້າງອີງທີ່ອ່ອນແອທີ່ໂດດເດັ່ນ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // ສ້າງຕົວຊີ້ທີ່ອ່ອນແອເພື່ອ ທຳ ຄວາມສະອາດເອກະສານອ້າງອິງທີ່ເຂັ້ມແຂງ
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// ກໍ່ສ້າງຊິ້ນສ່ວນດ້ານການອ້າງອິງປະລໍາມະນູໃຫມ່ທີ່ມີເນື້ອໃນທີ່ບໍ່ມີຕົວຕົນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ການເລີ່ມຕົ້ນທີ່ ນຳ ສົ່ງ:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// ກໍ່ສ້າງຊິ້ນສ່ວນທີ່ອ້າງອິງຄິດໄລ່ປະລໍາມະນູໃຫມ່ທີ່ມີເນື້ອໃນທີ່ບໍ່ມີການກວດສອບ, ດ້ວຍຫນ່ວຍຄວາມຈໍາທີ່ເຕັມໄປດ້ວຍ `0` bytes.
    ///
    ///
    /// ເບິ່ງ [`MaybeUninit::zeroed`][zeroed] ສຳ ລັບຕົວຢ່າງຂອງການ ນຳ ໃຊ້ທີ່ຖືກຕ້ອງແລະບໍ່ຖືກຕ້ອງຂອງວິທີການນີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// ແປງເປັນ `Arc<T>`.
    ///
    /// # Safety
    ///
    /// ເຊັ່ນດຽວກັບ [`MaybeUninit::assume_init`], ມັນຂຶ້ນກັບຜູ້ໂທເພື່ອຮັບປະກັນວ່າມູນຄ່າພາຍໃນແມ່ນຢູ່ໃນສະພາບເດີມ.
    ///
    /// ການໂທຫານີ້ເມື່ອເນື້ອຫາຍັງບໍ່ໄດ້ເລີ່ມຕົ້ນເຕັມເຮັດໃຫ້ມີພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດທັນທີ.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ການເລີ່ມຕົ້ນທີ່ ນຳ ສົ່ງ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// ແປງເປັນ `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// ເຊັ່ນດຽວກັບ [`MaybeUninit::assume_init`], ມັນຂຶ້ນກັບຜູ້ໂທເພື່ອຮັບປະກັນວ່າມູນຄ່າພາຍໃນແມ່ນຢູ່ໃນສະພາບເດີມ.
    ///
    /// ການໂທຫານີ້ເມື່ອເນື້ອຫາຍັງບໍ່ໄດ້ເລີ່ມຕົ້ນເຕັມເຮັດໃຫ້ມີພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດທັນທີ.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ການເລີ່ມຕົ້ນທີ່ ນຳ ສົ່ງ:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// ກິນໄດ້ `Arc`, ກັບຄືນໄດ້ຊີ້ຫໍ່.
    ///
    /// ເພື່ອຫລີກລ້ຽງການຮົ່ວໄຫລຂອງຄວາມຊົງ ຈຳ, ຕົວຊີ້ຕ້ອງຖືກປ່ຽນກັບ `Arc` ໂດຍໃຊ້ [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ສະ ໜອງ ຕົວຊີ້ວັດຖຸດິບໃຫ້ກັບຂໍ້ມູນ.
    ///
    /// ການນັບບໍ່ໄດ້ຮັບຜົນກະທົບໃນທາງໃດກໍ່ຕາມແລະ `Arc` ບໍ່ໄດ້ຖືກບໍລິໂພກ.
    /// ຕົວຊີ້ແມ່ນຖືກຕ້ອງສໍາລັບການເປັນມີນັບເຂັ້ມແຂງໃນ `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // ຄວາມປອດໄພ: ສິ່ງນີ້ບໍ່ສາມາດຜ່ານ Deref::deref ຫຼື RcBoxPtr::inner ເພາະ
        // ນີ້ເປັນສິ່ງຈໍາເປັນເພື່ອຮັກສາ raw/mut provenance ເຊັ່ນວ່າເຊັ່ນ
        // `get_mut` ສາມາດຂຽນຜ່ານຕົວຊີ້ຫຼັງຈາກ Rc ຖືກເກັບຄືນໂດຍຜ່ານ `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// ກໍ່ສ້າງ `Arc<T>` ຈາກຕົວຊີ້ວັດຖຸດິບ.
    ///
    /// ຕົວຊີ້ວັດຖຸດິບຕ້ອງໄດ້ຮັບການກັບຄືນມາໂດຍການໂທໄປ [`Arc<U>::into_raw`][into_raw] ທີ່ `U` ຕ້ອງມີຂະຫນາດດຽວກັນແລະການຈັດຕໍາແຫນ່ງເປັນ `T` ໄດ້.
    /// ນີ້ແມ່ນຄວາມຈິງເລັກໆນ້ອຍໆຖ້າ `U` ແມ່ນ `T`.
    /// ໃຫ້ສັງເກດວ່າຖ້າ `U` ບໍ່ແມ່ນ `T` ແຕ່ມີຂະ ໜາດ ແລະຄວາມສອດຄ່ອງກັນ, ນີ້ແມ່ນພື້ນຖານຄືກັບການສົ່ງຕໍ່ການອ້າງອີງຂອງປະເພດຕ່າງໆ.
    /// ເບິ່ງ [`mem::transmute`][transmute] ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມກ່ຽວກັບຂໍ້ ຈຳ ກັດໃດທີ່ໃຊ້ໃນກໍລະນີນີ້.
    ///
    /// ຜູ້ໃຊ້ `from_raw` ຕ້ອງຮັບປະກັນວ່າມູນຄ່າສະເພາະຂອງ `T` ຫຼຸດລົງພຽງຄັ້ງດຽວເທົ່ານັ້ນ.
    ///
    /// ຟັງຊັນນີ້ບໍ່ປອດໄພເພາະວ່າການ ນຳ ໃຊ້ທີ່ບໍ່ຖືກຕ້ອງອາດຈະເຮັດໃຫ້ຄວາມ ຈຳ ບໍ່ປອດໄພ, ເຖິງແມ່ນວ່າ `Arc<T>` ທີ່ສົ່ງຄືນຈະບໍ່ມີການເຂົ້າເຖິງ.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // ສັບປ່ຽນໄປເປັນ `Arc` ເພື່ອປ້ອງກັນການຮົ່ວໄຫລ.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // ການໂທຕໍ່ໄປຍັງ `Arc::from_raw(x_ptr)` ອາດຈະບໍ່ປອດໄພ.
    /// }
    ///
    /// // ຄວາມຊົງ ຈຳ ໄດ້ຖືກປ່ອຍອອກມາເມື່ອ `x` ບໍ່ມີຂອບເຂດຂ້າງເທິງ, ສະນັ້ນ `x_ptr` ຕອນນີ້ ກຳ ລັງຫ້ອຍ!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // ປີ້ນກັບກັນການຊົດເຊີຍເພື່ອຊອກຫາ ArcInner ເດີມ.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// ສ້າງຕົວຊີ້ [`Weak`] X ໃໝ່ ເຂົ້າໃນການຈັດສັນນີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // ການພັກຜ່ອນແບບນີ້ແມ່ນບໍ່ເປັນຫຍັງເພາະວ່າພວກເຮົາ ກຳ ລັງກວດສອບຄຸນຄ່າໃນ CAS ຂ້າງລຸ່ມນີ້.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // ກວດເບິ່ງວ່າບັດຕ້ານທີ່ອ່ອນແອຢູ່ປະຈຸບັນແມ່ນ "locked";ຖ້າເປັນດັ່ງນັ້ນ, ປັ່ນ.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ລະຫັດນີ້ປະຈຸບັນບໍ່ສົນໃຈຄວາມເປັນໄປໄດ້ຂອງການໄຫຼວຽນ
            // into usize::MAX;ໂດຍທົ່ວໄປທັງ Rc ແລະ Arc ຕ້ອງມີການດັດປັບເພື່ອຮັບມືກັບຄວາມລົ້ນ.
            //

            // ບໍ່ຄືກັບ Clone(), ພວກເຮົາຕ້ອງການສິ່ງນີ້ເພື່ອເປັນ Acquire read ເພື່ອປະສານກັບການຂຽນທີ່ມາຈາກ `is_unique`, ເພື່ອໃຫ້ເຫດການກ່ອນການຂຽນນັ້ນເກີດຂື້ນກ່ອນການອ່ານນີ້.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // ໃຫ້ແນ່ໃຈວ່າພວກເຮົາບໍ່ໄດ້ສ້າງ Weak ຫ້ອຍ
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// ເອົາ ຈຳ ນວນຕົວຊີ້ບອກ [`Weak`] ເຂົ້າໃນການຈັດສັນນີ້.
    ///
    /// # Safety
    ///
    /// ວິທີການນີ້ດ້ວຍຕົວມັນເອງແມ່ນປອດໄພ, ແຕ່ວ່າການໃຊ້ມັນຢ່າງຖືກຕ້ອງຮຽກຮ້ອງໃຫ້ມີການດູແລພິເສດ.
    /// ກະທູ້ອື່ນສາມາດປ່ຽນການນັບທີ່ອ່ອນແອໄດ້ທຸກເວລາ, ລວມທັງທ່າແຮງລະຫວ່າງການໂທຫາວິທີການນີ້ແລະການກະ ທຳ ຕາມຜົນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // ຍື່ນຍັນນີ້ແມ່ນສາດເພາະວ່າພວກເຮົາຍັງບໍ່ທັນໄດ້ແບ່ງປັນ `Arc` ຫຼື `Weak` ລະຫວ່າງຫົວຂໍ້.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // ຖ້ານັບອ່ອນແອຖືກລັອກໃນປະຈຸບັນ, ມູນຄ່າຂອງຈໍານວນດັ່ງກ່າວນີ້ແມ່ນ 0 ພຽງແຕ່ກ່ອນທີ່ຈະລັອກໄດ້.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// ເອົາ ຈຳ ນວນຕົວຊີ້ບອກ (`Arc`) ທີ່ເຂັ້ມແຂງເຂົ້າໃນການຈັດສັນນີ້.
    ///
    /// # Safety
    ///
    /// ວິທີການນີ້ດ້ວຍຕົວມັນເອງແມ່ນປອດໄພ, ແຕ່ວ່າການໃຊ້ມັນຢ່າງຖືກຕ້ອງຮຽກຮ້ອງໃຫ້ມີການດູແລພິເສດ.
    /// ກະທູ້ອື່ນສາມາດປ່ຽນການນັບທີ່ເຂັ້ມແຂງໄດ້ທຸກເວລາ, ລວມທັງທ່າແຮງລະຫວ່າງການໂທຫາວິທີການນີ້ແລະການກະ ທຳ ຕາມຜົນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // ການຢືນຢັນນີ້ແມ່ນສິ່ງທີ່ຕັດສິນເພາະວ່າພວກເຮົາບໍ່ໄດ້ແບ່ງປັນ `Arc` ລະຫວ່າງກະທູ້.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// ເພີ່ມ ຈຳ ນວນການອ້າງອີງທີ່ເຂັ້ມແຂງໃນ `Arc<T>` ທີ່ກ່ຽວຂ້ອງກັບຕົວຊີ້ທີ່ສະ ໜອງ ໃຫ້ໂດຍ ໜຶ່ງ.
    ///
    /// # Safety
    ///
    /// ຕົວຊີ້ຕ້ອງໄດ້ຮັບການໄດ້ຮັບໂດຍຜ່ານການ `Arc::into_raw`, ແລະຍົກຕົວຢ່າງ `Arc` ທີ່ກ່ຽວຂ້ອງຈະຕ້ອງຖືກຕ້ອງ (ie
    /// ການນັບເຂັ້ມແຂງຈະຕ້ອງຢູ່ຢ່າງຫນ້ອຍ 1) ສໍາລັບໄລຍະເວລາຂອງວິທີການນີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ການຢືນຢັນນີ້ແມ່ນສິ່ງທີ່ຕັດສິນເພາະວ່າພວກເຮົາບໍ່ໄດ້ແບ່ງປັນ `Arc` ລະຫວ່າງກະທູ້.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // ຮັກສາ Arc, ແຕ່ບໍ່ຕ້ອງ ສຳ ພັດກັບເງິນຄືນໂດຍການຫໍ່ເຂົ້າໃນ ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // ໃນປັດຈຸບັນເພີ່ມ ຈຳ ນວນເງິນຈ່າຍຄືນ, ແຕ່ຢ່າລຸດເອົາເງິນຄືນ ໃໝ່ ນຳ ອີກ
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// ການຫຼຸດລົງຂອງການອ້າງອີງທີ່ເຂັ້ມແຂງກ່ຽວກັບ `Arc<T>` ທີ່ກ່ຽວຂ້ອງກັບຕົວຊີ້ທີ່ສະຫນອງໃຫ້ໂດຍຫນຶ່ງ.
    ///
    /// # Safety
    ///
    /// ຕົວຊີ້ຕ້ອງໄດ້ຮັບການໄດ້ຮັບໂດຍຜ່ານການ `Arc::into_raw`, ແລະຍົກຕົວຢ່າງ `Arc` ທີ່ກ່ຽວຂ້ອງຈະຕ້ອງຖືກຕ້ອງ (ie
    /// ຈຳ ນວນທີ່ເຂັ້ມແຂງຈະຕ້ອງເປັນຢ່າງ ໜ້ອຍ 1) ເມື່ອເວົ້າເຖິງວິທີການນີ້.
    /// ວິທີການນີ້ສາມາດຖືກນໍາໃຊ້ເພື່ອປ່ອຍສຸດທ້າຍ `Arc` ແລະສະຫນັບສະຫນູນການເກັບຮັກສາ, ແຕ່ **ຄວນບໍ່** ຖືກເອີ້ນຕາມສຸດທ້າຍ `Arc` ໄດ້ຮັບການປ່ອຍອອກມາເມື່ອ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ການຢືນຢັນເຫລົ່ານັ້ນແມ່ນສິ່ງທີ່ຕັດສິນເພາະວ່າພວກເຮົາບໍ່ໄດ້ແບ່ງປັນ `Arc` ລະຫວ່າງກະທູ້.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // unsafety ນີ້ແມ່ນແລ້ວງາມເນື່ອງຈາກວ່າໃນຂະນະທີ່ໄຟຟ້ານີ້ແມ່ນມີຊີວິດຢູ່ພວກເຮົາກໍາລັງຮັບປະກັນວ່າຊີ້ໃນທີ່ຖືກຕ້ອງ.
        // ຍິ່ງໄປກວ່ານັ້ນ, ພວກເຮົາຮູ້ວ່າໂຄງສ້າງ `ArcInner` ຕົວມັນເອງແມ່ນ `Sync` ເພາະວ່າຂໍ້ມູນພາຍໃນແມ່ນ `Sync` ເຊັ່ນດຽວກັນ, ດັ່ງນັ້ນພວກເຮົາກໍ່ຍອມປ່ອຍຕົວຊີ້ທີ່ບໍ່ປ່ຽນແປງໄປສູ່ເນື້ອໃນເຫຼົ່ານີ້.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // ສ່ວນທີ່ບໍ່ແມ່ນສາຍຂອງ `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // ທຳ ລາຍຂໍ້ມູນໃນເວລານີ້, ເຖິງແມ່ນວ່າພວກເຮົາອາດຈະບໍ່ປົດປ່ອຍການຈັດສັນກ່ອງເອງ (ອາດຈະມີຕົວຊີ້ຈຸດອ່ອນໆຢູ່ອ້ອມຕົວ).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // ວາງກະສານອ້າງອີງອ່ອນແອໄດ້ຈັດຂຶ້ນລວມໂດຍການອ້າງອິງທີ່ເຂັ້ມແຂງທັງຫມົດ
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// ສົ່ງຄືນ `true` ຖ້າສອງ `Arc ຊີ້ໃຫ້ເຫັນເຖິງການຈັດສັນອັນດຽວກັນ (ໃນເສັ້ນກ່າງຄ້າຍຄືກັບ [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// ຈັດສັນ `ArcInner<T>` ທີ່ມີພື້ນທີ່ພຽງພໍ ສຳ ລັບຄ່າພາຍໃນທີ່ອາດຈະເປັນການ ກຳ ນົດທີ່ມູນຄ່າມີການຈັດວາງໃຫ້.
    ///
    /// ການທໍາງານຂອງ `mem_to_arcinner` ຖືກເອີ້ນວ່າກັບຊີ້ຂໍ້ມູນແລະຕ້ອງໄດ້ກັບຄືນກັບຄືນໄປບ່ອນເປັນ (ໄຂມັນທີ່ມີທ່າແຮງ)-pointer ສໍາລັບ `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // ຄິດໄລ່ຮູບແບບໂດຍໃຊ້ຮູບແບບມູນຄ່າທີ່ໃຫ້.
        // ກ່ອນ ໜ້າ ນີ້, ການຈັດຮູບແບບຖືກ ຄຳ ນວນກ່ຽວກັບ ຄຳ ສະແດງ `&*(ptr as* const ArcInner<T>)`, ແຕ່ສິ່ງນີ້ໄດ້ສ້າງເອກະສານອ້າງອີງທີ່ບໍ່ຖືກຕ້ອງ (ເບິ່ງ #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// ຈັດສັນ `ArcInner<T>` ທີ່ມີພື້ນທີ່ພຽງພໍ ສຳ ລັບມູນຄ່າພາຍໃນທີ່ອາດຈະເປັນການ ກຳ ນົດທີ່ມູນຄ່າມີການຈັດວາງ, ໃຫ້ຂໍ້ຜິດພາດຖ້າການຈັດສັນລົ້ມເຫຼວ.
    ///
    ///
    /// ການທໍາງານຂອງ `mem_to_arcinner` ຖືກເອີ້ນວ່າກັບຊີ້ຂໍ້ມູນແລະຕ້ອງໄດ້ກັບຄືນກັບຄືນໄປບ່ອນເປັນ (ໄຂມັນທີ່ມີທ່າແຮງ)-pointer ສໍາລັບ `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // ຄິດໄລ່ຮູບແບບໂດຍໃຊ້ຮູບແບບມູນຄ່າທີ່ໃຫ້.
        // ກ່ອນ ໜ້າ ນີ້, ການຈັດຮູບແບບຖືກ ຄຳ ນວນກ່ຽວກັບ ຄຳ ສະແດງ `&*(ptr as* const ArcInner<T>)`, ແຕ່ສິ່ງນີ້ໄດ້ສ້າງເອກະສານອ້າງອີງທີ່ບໍ່ຖືກຕ້ອງ (ເບິ່ງ #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ເລີ່ມຕົ້ນ ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// ຈັດສັນ `ArcInner<T>` ທີ່ມີພື້ນທີ່ພຽງພໍ ສຳ ລັບມູນຄ່າພາຍໃນທີ່ບໍ່ຖືກຕ້ອງ.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // ຈັດສັນສໍາຫລັບການ `ArcInner<T>` ໃຊ້ມູນຄ່າດັ່ງກ່າວ.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // ສຳ ເນົາຄ່າເປັນໄບ
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // ຈັດສັນການຟຣີໂດຍບໍ່ຕ້ອງເສີຍເນື້ອໃນຂອງມັນ
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// ຈັດສັນ `ArcInner<[T]>` ດ້ວຍຄວາມຍາວທີ່ໃຫ້.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// ສໍາເນົາອົງປະກອບຈາກຫຼັງຈາກນັ້ນນໍາເຂົ້າໄປໃນການຈັດສັນໃຫມ່ Arc <\[T\]>
    ///
    /// ບໍ່ປອດໄພເພາະຜູ້ໂທຕ້ອງຖືຄວາມເປັນເຈົ້າຂອງຫລືຜູກມັດ `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// ກໍ່ສ້າງ `Arc<[T]>` ຈາກຕົວປັບທີ່ຮູ້ຈັກວ່າມີຂະ ໜາດ ໃດ ໜຶ່ງ.
    ///
    /// ພຶດຕິກໍາແມ່ນ undefined ຂະຫນາດທີ່ຄວນຈະເປັນຜິດພາດ.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // ກອງ Panic ໃນຂະນະທີ່ cling ອົງປະກອບ T.
        // ໃນກໍລະນີຂອງ panic, ອົງປະກອບທີ່ໄດ້ຖືກຂຽນລົງໃນ ArcInner ໃຫມ່ຈະຖືກລຸດລົງ, ຫຼັງຈາກນັ້ນຄວາມຊົງ ຈຳ ໄດ້ຖືກປ່ອຍອອກມາ.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // ຕົວຊີ້ໄປຫາອົງປະກອບ ທຳ ອິດ
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // ທັງຫມົດທີ່ຈະແຈ້ງ.ລືມກອງເພື່ອມັນຈະບໍ່ປ່ອຍ ArcInner ໃໝ່.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// ພິເສດ trait ໃຊ້ ສຳ ລັບ `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// ເຮັດໃຫ້ໂຄນຂອງຕົວຊີ້ `Arc` X.
    ///
    /// ນີ້ສ້າງຕົວຊີ້ທິດທາງອື່ນໃນການຈັດສັນດຽວກັນ, ເພີ່ມ ຈຳ ນວນການອ້າງອີງທີ່ເຂັ້ມແຂງ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // ການ ນຳ ໃຊ້ການສັ່ງຈອງແບບສະບາຍໆແມ່ນຖືກຕ້ອງຢູ່ທີ່ນີ້, ເພາະວ່າຄວາມຮູ້ກ່ຽວກັບເອກະສານອ້າງອີງຕົ້ນສະບັບປ້ອງກັນກະທູ້ອື່ນໆຈາກການລຶບວັດຖຸຜິດພາດ.
        //
        // ດັ່ງທີ່ໄດ້ອະທິບາຍໄວ້ໃນ [Boost documentation][1], ການເພີ່ມໂຕອ້າງອີງສາມາດເຮັດໄດ້ກັບ memory_order_relaxed ສະ ເໝີ: ການອ້າງອິງ ໃໝ່ ຕໍ່ວັດຖຸສາມາດສ້າງຂື້ນຈາກການອ້າງອິງທີ່ມີຢູ່ແລ້ວ, ແລະການຖ່າຍທອດເອກະສານອ້າງອີງທີ່ມີຢູ່ຈາກກະທູ້ ໜຶ່ງ ໄປຫາອີກຄັ້ງ ໜຶ່ງ ກໍ່ຕ້ອງສະ ໜອງ ການປະສານງານທີ່ຕ້ອງການແລ້ວ.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // ເຖິງຢ່າງໃດກໍ່ຕາມພວກເຮົາ ຈຳ ເປັນຕ້ອງໄດ້ປ້ອງກັນການຜ່ອນຜັນ ຈຳ ນວນມະຫາສານໃນກໍລະນີທີ່ຜູ້ໃດຜູ້ ໜຶ່ງ ເປັນ `mem: : ລືມ` Arcs.
        // ຖ້າຫາກວ່າພວກເຮົາບໍ່ເຮັດສິ່ງນີ້ນັບສາມາດລົ້ນແລະຜູ້ຊົມໃຊ້ຈະໃຊ້, ຫຼັງຈາກຟຣີ.
        // ພວກເຮົາ saturate racily ກັບ `isize::MAX` ກ່ຽວກັບການສົມມຸດຕິຖານວ່າບໍ່ມີ ~2 ຕື້ກະທູ້ເພີ່ມການນັບກະສານອ້າງອີງໃນເວລາດຽວກັນ.
        //
        // branch ນີ້ຈະບໍ່ຖືກ ນຳ ເຂົ້າໃນໂຄງການຕົວຈິງໃດໆເລີຍ.
        //
        // ພວກເຮົາເອົາລູກອອກເພາະວ່າໂຄງການດັ່ງກ່າວຊຸດໂຊມລົງຢ່າງບໍ່ ໜ້າ ເຊື່ອ, ແລະພວກເຮົາກໍ່ບໍ່ສົນໃຈທີ່ຈະສະ ໜັບ ສະ ໜູນ ມັນ.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// ເຮັດໃຫ້ມີການອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບ `Arc` ທີ່ໄດ້ຮັບ.
    ///
    /// ຖ້າມີ XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxXXX2
    /// ນີ້ຍັງຖືກກ່າວເຖິງວ່າເປັນ clone-on-write.
    ///
    /// ໃຫ້ສັງເກດວ່າສິ່ງນີ້ແຕກຕ່າງກັບພຶດຕິ ກຳ ຂອງ [`Rc::make_mut`] ທີ່ເຮັດໃຫ້ບໍ່ມີຈຸດຢືນ `Weak` ທີ່ເຫລືອ.
    ///
    /// ເບິ່ງຍັງ [`get_mut`][get_mut], ເຊິ່ງຈະບໍ່ແທນທີ່ຈະກ່ວາ cloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // ຈະບໍ່ clone ຫຍັງ
    /// let mut other_data = Arc::clone(&data); // ຈະບໍ່ clone ຂໍ້ມູນພາຍໃນ
    /// *Arc::make_mut(&mut data) += 1;         // Clones ຂໍ້ມູນພາຍໃນ
    /// *Arc::make_mut(&mut data) += 1;         // ຈະບໍ່ clone ຫຍັງ
    /// *Arc::make_mut(&mut other_data) *= 2;   // ຈະບໍ່ clone ຫຍັງ
    ///
    /// // ດຽວນີ້ `data` ແລະ `other_data` ຊີ້ໃຫ້ເຫັນເຖິງການຈັດສັນທີ່ແຕກຕ່າງກັນ.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // ໃຫ້ສັງເກດວ່າພວກເຮົາຖືທັງເອກະສານອ້າງອີງທີ່ເຂັ້ມແຂງແລະຂໍ້ອ້າງອີງທີ່ອ່ອນແອ.
        // ດັ່ງນັ້ນ, ການປ່ອຍຂໍ້ອ້າງອີງທີ່ເຂັ້ມແຂງຂອງພວກເຮົາພຽງແຕ່ຈະບໍ່ເຮັດໃຫ້ຄວາມຊົງ ຈຳ ເກີດຂື້ນ.
        //
        // ໃຊ້ Acquire ເພື່ອຮັບປະກັນວ່າພວກເຮົາຈະເຫັນການຂຽນໃດໆທີ່ `weak` ທີ່ເກີດຂື້ນກ່ອນການປ່ອຍຂຽນ (ໝາຍ ຄວາມວ່າການຫຼຸດລົງ) ເຖິງ `strong`.
        // ເນື່ອງຈາກວ່າພວກເຮົາຖືເປັນຈໍານວນອ່ອນແອ, ມີໂອກາດ ArcInner ຕົວຂອງມັນເອງສາມາດໄດ້ຮັບການ deallocated ບໍ່.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // ຕົວຊີ້ທີ່ແຂງແຮງອີກອັນ ໜຶ່ງ ມີຢູ່, ດັ່ງນັ້ນພວກເຮົາຕ້ອງໄດ້ກົດ.
            // ຈັດສັນຄວາມ ຈຳ ໄວ້ລ່ວງ ໜ້າ ເພື່ອອະນຸຍາດໃຫ້ຂຽນຄ່າ cloned ໂດຍກົງ.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // suffices ສະດວກສະບາຍໃນຂ້າງເທິງນີ້ເພາະວ່ານີ້ແມ່ນພື້ນຖານທີ່ດີທີ່ສຸດເປັນ: ພວກເຮົາກໍາລັງສະເຫມີໄປແຂ່ງລົດທີ່ມີຄໍາແນະນໍາທີ່ອ່ອນແອຈະຖືກຫຼຸດລົງ.
            // ກໍລະນີຮ້າຍແຮງທີ່ສຸດ, ພວກເຮົາສິ້ນສຸດການຈັດສັນ Arc ໃໝ່ ໂດຍບໍ່ ຈຳ ເປັນ.
            //

            // ພວກເຮົາໄດ້ເອົາບ່ອນອ້າງອີງທີ່ແຂງແຮງສຸດທ້າຍອອກມາ, ແຕ່ວ່າຍັງມີຕົວແທນທີ່ອ່ອນແອຕື່ມອີກ.
            // ພວກເຮົາຈະຍ້າຍເນື້ອຫາໄປໃສ່ Arc ໃໝ່, ແລະບໍ່ໃຫ້ຂໍ້ມູນອື່ນທີ່ອ່ອນແອລົງ.
            //

            // ໃຫ້ສັງເກດວ່າມັນບໍ່ສາມາດເຮັດໃຫ້ການອ່ານ `weak` ສາມາດຜະລິດ usize::MAX (ຫມາຍຄວາມວ່າຖືກລັອກ), ເນື່ອງຈາກວ່າຕົວເລກທີ່ອ່ອນແອສາມາດຖືກລັອກໂດຍກະທູ້ທີ່ມີເອກະສານອ້າງອີງທີ່ເຂັ້ມແຂງ.
            //
            //

            // ປະຕິບັດຕົວຊີ້ທີ່ອ່ອນແອຂອງຕົວເຮົາເອງ, ເພື່ອໃຫ້ມັນສາມາດເຮັດຄວາມສະອາດ ArcInner ໄດ້ຕາມຄວາມຕ້ອງການ.
            //
            let _weak = Weak { ptr: this.ptr };

            // ພຽງແຕ່ສາມາດລັກຂໍ້ມູນໄດ້, ສິ່ງທີ່ເຫລືອແມ່ນ Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // ພວກເຮົາເປັນຜູ້ອ້າງອີງຢ່າງດຽວຂອງຊະນິດທັງສອງຢ່າງ;ຕຳ ກັບການນັບ ຈຳ ນວນທີ່ເຂັ້ມແຂງ.
            //
            this.inner().strong.store(1, Release);
        }

        // ເຊັ່ນດຽວກັບ `get_mut()`, ຄວາມບໍ່ປອດໄພແມ່ນບໍ່ເປັນຫຍັງເພາະວ່າການອ້າງອິງຂອງພວກເຮົາແມ່ນເປັນເອກະລັກທີ່ຈະເລີ່ມຕົ້ນ, ຫຼືກາຍເປັນ ໜຶ່ງ ໃນການປິດເນື້ອຫາ.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// ສົ່ງຄືນເອກະສານອ້າງອີງທີ່ປ່ຽນໄປໃນ `Arc` ທີ່ໄດ້ມອບໃຫ້, ຖ້າບໍ່ມີຈຸດຊີ້ `Arc` ຫຼື [`Weak`] ອື່ນໆໃນການຈັດສັນດຽວກັນ.
    ///
    ///
    /// ສົ່ງຄືນ [`None`] ຖ້າບໍ່ດັ່ງນັ້ນ, ເພາະວ່າມັນບໍ່ປອດໄພໃນການແລກປ່ຽນມູນຄ່າຮ່ວມກັນ.
    ///
    /// ເບິ່ງອີກ [`make_mut`][make_mut], ເຊິ່ງຈະເປັນ [`clone`][clone] ມູນຄ່າພາຍໃນເມື່ອມີຈຸດຊີ້ບອກອື່ນໆ.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // ຄວາມບໍ່ປອດໄພນີ້ແມ່ນບໍ່ເປັນຫຍັງເພາະວ່າພວກເຮົາຮັບປະກັນວ່າຕົວຊີ້ກັບຄືນມາແມ່ນຕົວຊີ້ * ** ເທົ່ານັ້ນທີ່ຈະຖືກສົ່ງກັບ T.
            // ການອ້າງອີງການອ້າງອີງຂອງພວກເຮົາແມ່ນຮັບປະກັນໃຫ້ເປັນ 1 ໃນຈຸດນີ້, ແລະພວກເຮົາຮຽກຮ້ອງໃຫ້ Arc ຕົວເອງເປັນ `mut`, ດັ່ງນັ້ນພວກເຮົາ ກຳ ລັງສົ່ງຄືນເອກະສານອ້າງອີງທີ່ເປັນໄປໄດ້ກັບຂໍ້ມູນພາຍໃນເທົ່ານັ້ນ.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// ຜົນໄດ້ຮັບກະສານອ້າງອີງທີ່ບໍ່ແນ່ນອນເປັນ `Arc` ດັ່ງກ່າວ, ໂດຍບໍ່ມີການກວດສອບໃດໆ.
    ///
    /// ເບິ່ງຍັງ [`get_mut`], ຊຶ່ງເປັນຄວາມປອດໄພແລະບໍ່ກວດສອບທີ່ເຫມາະສົມ.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// ຕົວຊີ້ບອກ `Arc` ຫຼື [`Weak`] ອື່ນໆໃນການຈັດສັນອັນດຽວກັນນັ້ນບໍ່ຕ້ອງຖືກອະນຸຍາດໃນໄລຍະເວລາຂອງການກູ້ຢືມທີ່ກັບມາ.
    ///
    /// ນີ້ແມ່ນກໍລະນີທີ່ບໍ່ຄ່ອຍດີຖ້າບໍ່ມີຕົວຊີ້ບອກດັ່ງກ່າວ, ຍົກຕົວຢ່າງທັນທີຫລັງ `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // ພວກເຮົາມີຄວາມລະມັດລະວັງທີ່ຈະບໍ່ * ສ້າງເອກະສານອ້າງອີງທີ່ກວມເອົາເຂດ "count", ເພາະວ່າມັນຈະມີການປ່ຽນແປງການເຂົ້າເຖິງຂໍ້ມູນການອ້າງອີງ (ພ້ອມກັນ)
        // ໂດຍ `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// ກຳ ນົດວ່ານີ້ແມ່ນເອກະສານອ້າງອີງທີ່ເປັນເອກະລັກ (ລວມທັງຂໍ້ມູນອ້າງອີງທີ່ອ່ອນແອ) ຕໍ່ຂໍ້ມູນທີ່ຕິດພັນ.
    ///
    ///
    /// ໃຫ້ສັງເກດວ່າສິ່ງນີ້ຮຽກຮ້ອງໃຫ້ມີການລັອກການນັບ ຈຳ ນວນທີ່ ຈຳ ກັດ.
    fn is_unique(&mut self) -> bool {
        // ລັອກນັບຊີ້ອ່ອນແອຖ້າພວກເຮົາປະກົດວ່າຈະໄດ້ແຕ່ພຽງຜູ້ດຽວຖືຊີ້ອ່ອນແອ.
        //
        // ປ້າຍ ກຳ ກັບທີ່ນີ້ຮັບປະກັນຄວາມ ສຳ ພັນທີ່ເກີດຂື້ນ-ກ່ອນການພົວພັນກັບສິ່ງໃດທີ່ຂຽນເຖິງ `strong` (ໂດຍສະເພາະໃນ `Weak::upgrade`) ກ່ອນການຫຼຸດລົງຂອງ ຈຳ ນວນ `weak` (ຜ່ານ `Weak::drop`, ເຊິ່ງໃຊ້ການປ່ອຍ).
        // ຖ້າການປັບປຸງທີ່ອ່ອນແອທີ່ຖືກຍົກລະດັບບໍ່ເຄີຍຖືກຫຼຸດລົງ, CAS ຢູ່ທີ່ນີ້ຈະລົ້ມເຫລວສະນັ້ນພວກເຮົາບໍ່ສົນໃຈທີ່ຈະປະສານກັນ.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // ນີ້ ຈຳ ເປັນຕ້ອງເປັນ `Acquire` ເພື່ອປະສົມປະສານກັບການຫຼຸດລົງຂອງວຽກງານຕ້ານກັບ `strong` ໃນ `drop`-ການເຂົ້າເຖິງເທົ່ານັ້ນທີ່ເກີດຂື້ນເມື່ອມີແຕ່ເອກະສານອ້າງອີງສຸດທ້າຍ ກຳ ລັງຖືກລຸດລົງ.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // ການປ່ອຍບົດຂຽນຢູ່ທີ່ນີ້ປະສານກັບການອ່ານໃນ `downgrade`, ປ້ອງກັນການອ່ານ `strong` ຂ້າງເທິງຢ່າງມີປະສິດທິຜົນຈາກການເກີດຂື້ນຫຼັງຈາກຂຽນ.
            //
            //
            self.inner().weak.store(1, Release); // ປ່ອຍລັອກໄດ້
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// ຫຼຸດລົງ `Arc`.
    ///
    /// ນີ້ຈະຫຼຸດລົງການນັບກະສານອ້າງອີງທີ່ເຂັ້ມແຂງ.
    /// ຖ້າການອ້າງອີງທີ່ແຂງແຮງນັບຮອດສູນຫຼັງຈາກນັ້ນເອກະສານອ້າງອີງອື່ນໆ (ຖ້າມີ) ແມ່ນ [`Weak`], ດັ່ງນັ້ນພວກເຮົາ `drop` ມູນຄ່າພາຍໃນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // ບໍ່ໄດ້ພິມຫຍັງເລີຍ
    /// drop(foo2);   // ພິມ "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // ເນື່ອງຈາກວ່າ `fetch_sub` ແມ່ນອະຕອມແລ້ວ, ພວກເຮົາບໍ່ ຈຳ ເປັນຕ້ອງປະສານກັບກະທູ້ອື່ນເວັ້ນເສຍແຕ່ວ່າພວກເຮົາ ກຳ ລັງຈະລຶບວັດຖຸ.
        // ເຫດຜົນດຽວກັນນີ້ໃຊ້ກັບ `fetch_sub` ຂ້າງລຸ່ມນີ້ເພື່ອນັບ `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // ຮົ້ວນີ້ແມ່ນ ຈຳ ເປັນເພື່ອປ້ອງກັນການ ນຳ ໃຊ້ຂໍ້ມູນແລະການລຶບຂໍ້ມູນ.
        // ເນື່ອງຈາກວ່າມັນຖືກ ໝາຍ ເປັນ `Release`, ການຫຼຸດລົງຂອງການນັບກະສານອ້າງອີງຈະປະສານກັບຮົ້ວ `Acquire` ນີ້.
        // ນີ້ຫມາຍຄວາມວ່າທີ່ການນໍາໃຊ້ຂໍ້ມູນທີ່ເກີດຂຶ້ນກ່ອນທີ່ຈະຫຼຸດລົງໄດ້ນັບອ້າງອິງທີ່ເກີດຂຶ້ນກ່ອນທີ່ຈະຮົ້ວນີ້, ທີ່ເກີດຂຶ້ນກ່ອນທີ່ຈະລຶບຂໍ້ມູນໄດ້.
        //
        // ດັ່ງທີ່ໄດ້ອະທິບາຍໄວ້ໃນ [Boost documentation][1],
        //
        // > ມັນເປັນສິ່ງສໍາຄັນເພື່ອບັງຄັບໃຊ້ການເຂົ້າເຖິງທີ່ເປັນໄປໄດ້ເພື່ອຈຸດປະສົງໃນຫນຶ່ງ
        // > ກະທູ້ (ຜ່ານການອ້າງອິງທີ່ມີຢູ່) ເພື່ອ *ເກີດຂື້ນກ່ອນ* ລຶບ
        // > ຈຸດປະສົງໃນກະທູ້ທີ່ແຕກຕ່າງກັນ.ນີ້ແມ່ນບັນລຸໄດ້ໂດຍ "release"
        // > ປະຕິບັດງານຫຼັງຈາກທີ່ຫຼຸດລົງເປັນກະສານອ້າງອີງ (ການເຂົ້າເຖິງວັດຖຸ
        // > ໂດຍຜ່ານການອ້າງອີງນີ້ຕ້ອງໄດ້ເກີດຂື້ນກ່ອນ ໜ້າ ນີ້), ແລະ
        // > "acquire" ການປະຕິບັດງານກ່ອນທີ່ຈະລຶບວັດຖຸ.
        //
        // ໂດຍສະເພາະ, ໃນຂະນະທີ່ເນື້ອໃນຂອງ Arc ມັກຈະບໍ່ສາມາດປ່ຽນແປງໄດ້, ມັນກໍ່ເປັນໄປໄດ້ທີ່ຈະມີການຂຽນພາຍໃນໃສ່ສິ່ງທີ່ຄ້າຍຄືກັບ Mutex<T>.
        // ເນື່ອງຈາກວ່າ Mutex ບໍ່ໄດ້ຮັບໃນເວລາທີ່ມັນຖືກລຶບ, ພວກເຮົາບໍ່ສາມາດອີງໃສ່ເຫດຜົນການປະສົມປະສານຂອງມັນເພື່ອເຮັດໃຫ້ການຂຽນໃນກະທູ້ສາມາດເບິ່ງເຫັນໄດ້ກັບຜູ້ ທຳ ລາຍທີ່ແລ່ນໃນກະທູ້ B.
        //
        //
        // ນອກຈາກນີ້ຍັງສັງເກດວ່າຮົ້ວ Acquire ທີ່ນີ້ອາດຈະຖືກແທນທີ່ດ້ວຍ Acquire load, ເຊິ່ງສາມາດປັບປຸງການປະຕິບັດງານໃນສະຖານະການທີ່ມີການໂຕ້ຖຽງກັນຫຼາຍ.ເບິ່ງ [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// ພະຍາຍາມທີ່ຈະລຸດ `Arc<dyn Any + Send + Sync>` X ລົງສູ່ປະເພດຄອນກີດ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// ກໍ່ສ້າງ `Weak<T>` ໃໝ່, ໂດຍບໍ່ ຈຳ ກັດຫນ່ວຍຄວາມ ຈຳ ໃດໆ.
    /// ການໂທຫາ [`upgrade`] ໃນມູນຄ່າການສົ່ງຄືນສະເຫມີໃຫ້ [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// ປະເພດຜູ້ຊ່ວຍອະນຸຍາດໃຫ້ເຂົ້າເຖິງຂໍ້ອ້າງອີງໂດຍບໍ່ໄດ້ຮັບການຢືນຢັນໃດໆກ່ຽວກັບພາກສະ ໜາມ ຂໍ້ມູນ.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// ສົ່ງຄືນຕົວຊີ້ວັດຖຸດິບໄປຫາວັດຖຸ `T` ທີ່ຊີ້ໄປຫາໂດຍ `Weak<T>` ນີ້.
    ///
    /// ຕົວຊີ້ແມ່ນຖືກຕ້ອງຖ້າມີບາງເອກະສານອ້າງອີງທີ່ເຂັ້ມແຂງ.
    /// ຕົວຊີ້ອາດຈະຖືກຫ້ອຍ, ບໍ່ສະ ໝັກ ຫລືແມ້ແຕ່ [`null`] ຖ້າບໍ່ດັ່ງນັ້ນ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // ທັງສອງຊີ້ໃຫ້ເຫັນຈຸດປະສົງດຽວກັນ
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // ຄົນທີ່ເຂັ້ມແຂງຢູ່ທີ່ນີ້ເຮັດໃຫ້ມັນມີຊີວິດຢູ່, ສະນັ້ນພວກເຮົາຍັງສາມາດເຂົ້າເຖິງວັດຖຸໄດ້.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // ແຕ່ບໍ່ມີອີກແລ້ວ.
    /// // ພວກເຮົາສາມາດເຮັດໄດ້ weak.as_ptr(), ແຕ່ການເຂົ້າເຖິງຕົວຊີ້ຈະເຮັດໃຫ້ມີພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ.
    /// // assert_eq! ("ສະບາຍດີ", ບໍ່ປອດໄພ {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // ຖ້າຕົວຊີ້ຖືກຫ້ອຍ, ພວກເຮົາສົ່ງຜູ້ສົ່ງໂດຍກົງ.
            // ນີ້ບໍ່ສາມາດເປັນທີ່ຢູ່ payload ທີ່ຖືກຕ້ອງ, ຍ້ອນວ່າຄ່າຂົນສົ່ງແມ່ນຢ່າງ ໜ້ອຍ ກໍ່ຄືກັນກັບ ArcInner (usize).
            ptr as *const T
        } else {
            // ຄວາມປອດໄພ: ຖ້າ is_dangling ກັບຄືນທີ່ບໍ່ຖືກຕ້ອງ, ຫຼັງຈາກນັ້ນຕົວຊີ້ຈະໃຊ້ໄດ້.
            // ການຈ່າຍເງິນອາດຈະຖືກລຸດລົງໃນຈຸດນີ້, ແລະພວກເຮົາຕ້ອງຮັກສາຫຼັກຖານ, ສະນັ້ນໃຊ້ການ ໝູນ ໃຊ້ຕົວຊີ້ວັດຖຸດິບ.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// ບໍລິໂພກ `Weak<T>` ແລະປ່ຽນເປັນຕົວຊີ້ວັດຖຸດິບ.
    ///
    /// ນີ້ປ່ຽນຊີ້ອ່ອນແອເຂົ້າໄປໃນຕົວຊີ້ວັດຖຸດິບ, ໃນຂະນະທີ່ຍັງຮັກສາຄວາມເປັນເຈົ້າຂອງຂອງກະສານອ້າງອີງອ່ອນແອຫນຶ່ງ (ນັບອ່ອນແອບໍ່ໄດ້ຖືກແກ້ໄຂເທື່ອປະຕິບັດງານນີ້).
    /// ມັນສາມາດຫັນກັບຄືນສູ່ `Weak<T>` ກັບ [`from_raw`].
    ///
    /// ຂໍ້ ຈຳ ກັດດຽວກັນໃນການເຂົ້າເຖິງເປົ້າ ໝາຍ ຂອງຕົວຊີ້ຄືກັບ [`as_ptr`] ນຳ ໃຊ້.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// ແປງຕົວຊີ້ວັດຖຸດິບທີ່ເຄີຍສ້າງໂດຍ [`into_raw`] ກັບມາເປັນ `Weak<T>`.
    ///
    /// ສິ່ງນີ້ສາມາດໃຊ້ເພື່ອໃຫ້ມີການອ້າງອີງທີ່ເຂັ້ມແຂງ (ໂດຍການໂທຫາ [`upgrade`] ຕໍ່ມາ) ຫຼືຈັດການກັບການນັບ ຈຳ ນວນທີ່ອ່ອນແອໂດຍການລຸດ `Weak<T>`.
    ///
    /// ມັນຕ້ອງເປັນເຈົ້າຂອງເອກະສານອ້າງອິງ ໜຶ່ງ ທີ່ອ່ອນແອ (ໂດຍມີຂໍ້ຍົກເວັ້ນຂອງຕົວຊີ້ບອກທີ່ຖືກສ້າງຂື້ນໂດຍ [`new`], ຍ້ອນວ່າສິ່ງເຫຼົ່ານີ້ບໍ່ເປັນເຈົ້າຂອງຫຍັງເລີຍ;
    ///
    /// # Safety
    ///
    /// ຕົວຊີ້ຕ້ອງຕ້ອງມີຕົ້ນ ກຳ ເນີດມາຈາກ [`into_raw`] ແລະຍັງຕ້ອງເປັນເຈົ້າຂອງຂໍ້ອ້າງອີງທີ່ອ່ອນແອຂອງມັນ.
    ///
    /// ມັນໄດ້ຖືກອະນຸຍາດໃຫ້ນັບທີ່ເຂັ້ມແຂງແມ່ນ 0 ໃນເວລາທີ່ທ່ານໂທຫານີ້.
    /// ເຖິງຢ່າງໃດກໍ່ຕາມ, ສິ່ງນີ້ຈະເປັນເຈົ້າຂອງເອກະສານອ້າງອິງ ໜຶ່ງ ທີ່ອ່ອນແອເຊິ່ງປະຈຸບັນເປັນຕົວຊີ້ວັດຖຸດິບ (ຕົວເລກທີ່ອ່ອນແອບໍ່ໄດ້ຖືກດັດແກ້ໂດຍການປະຕິບັດງານນີ້) ແລະດັ່ງນັ້ນມັນຕ້ອງຖືກຄວບຄູ່ກັບການເອີ້ນກ່ອນ ໜ້າ ໃຫ້ [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // ຫຼຸດລົງນັບອ່ອນແອສຸດທ້າຍ.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ເບິ່ງ Weak::as_ptr ສຳ ລັບສະພາບການກ່ຽວກັບວິທີການຕົວຊີ້ວັດທີ່ປ້ອນເຂົ້າມາ.

        let ptr = if is_dangling(ptr as *mut T) {
            // ນີ້ແມ່ນ Weak ຫ້ອຍ.
            ptr as *mut ArcInner<T>
        } else {
            // ຖ້າບໍ່ດັ່ງນັ້ນ, ພວກເຮົາຮັບປະກັນຕົວຊີ້ແມ່ນມາຈາກຈຸດອ່ອນທີ່ບໍ່ມີຕົວຕົນ.
            // ຄວາມປອດໄພ: data_offset ແມ່ນການໂທທີ່ປອດໄພ, ຍ້ອນວ່າເອກະສານອ້າງອີງຂອງ ptr ເປັນຈິງ (ຖືກຫຼຸດລົງ) T.
            let offset = unsafe { data_offset(ptr) };
            // ດັ່ງນັ້ນ, ພວກເຮົາປະຕິເສດການຊົດເຊີຍເພື່ອໃຫ້ໄດ້ຮັບ RcBox ທັງ ໝົດ.
            // ຄວາມປອດໄພ: ຕົວຊີ້ແມ່ນມາຈາກ Weak, ສະນັ້ນການຊົດເຊີຍນີ້ແມ່ນປອດໄພ.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ຄວາມປອດໄພ: ດຽວນີ້ພວກເຮົາໄດ້ຊອກຫາຕົວຊີ້ Weak ເດີມ, ສະນັ້ນສາມາດສ້າງ Weak.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// ຄວາມພະຍາຍາມທີ່ຈະຍົກລະດັບຕົວຊີ້ `Weak` ໃຫ້ເປັນ [`Arc`], ການລ່າຊ້າລົງຂອງມູນຄ່າພາຍໃນຖ້າປະສົບຜົນ ສຳ ເລັດ.
    ///
    ///
    /// ສົ່ງຄືນ [`None`] ຖ້າມູນຄ່າພາຍໃນໄດ້ຖືກລຸດລົງ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // ທຳ ລາຍທຸກຈຸດທີ່ເຂັ້ມແຂງ.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // ພວກເຮົານໍາໃຊ້ເປັນ loop CAS ກັບ increment ການນັບເຂັ້ມແຂງແທນທີ່ຈະເປັນ fetch_add ເປັນຫນ້າທີ່ນີ້ບໍ່ຄວນໃຊ້ເວລານັບອ້າງອິງຈາກສູນເປັນຫນຶ່ງ.
        //
        //
        let inner = self.inner()?;

        // load ສະດວກສະບາຍເພາະວ່າຂຽນຂອງ 0 ທີ່ພວກເຮົາສາມາດສັງເກດເຫັນໃບພາກສະຫນາມຢູ່ໃນລັດຢ່າງຖາວອນສູນ (ນັ້ນເປັນ "stale" ອ່ານຈາກ 0 ແມ່ນດີ), ແລະຄ່າອື່ນໆໄດ້ຖືກຢືນຢັນໂດຍຜ່ານ CAS ຂ້າງລຸ່ມນີ້.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // ເບິ່ງ ຄຳ ເຫັນໃນ `Arc::clone` ຍ້ອນຫຍັງພວກເຮົາເຮັດສິ່ງນີ້ (ສຳ ລັບ `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // ພັກຜ່ອນແມ່ນດີ ສຳ ລັບກໍລະນີລົ້ມເຫຼວເພາະວ່າພວກເຮົາບໍ່ມີຄວາມຄາດຫວັງຫຍັງກ່ຽວກັບລັດ ໃໝ່.
            // ການໄດ້ມາແມ່ນມີຄວາມ ຈຳ ເປັນ ສຳ ລັບກໍລະນີຄວາມ ສຳ ເລັດເພື່ອຊິ້ງຂໍ້ມູນກັບ `Arc::new_cyclic`, ເມື່ອຄ່າພາຍໃນສາມາດເລີ່ມຕົ້ນໄດ້ຫຼັງຈາກການອ້າງອີງ `Weak` ໄດ້ຖືກສ້າງຂື້ນມາແລ້ວ.
            // ໃນກໍລະນີດັ່ງກ່າວ, ພວກເຮົາຄາດວ່າຈະສັງເກດເຫັນມູນຄ່າເລີ່ມຕົ້ນຢ່າງເຕັມສ່ວນ.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null ທີ່ຖືກກວດເບິ່ງຂ້າງເທິງ
                Err(old) => n = old,
            }
        }
    }

    /// ເອົາ ຈຳ ນວນຕົວຊີ້ບອກ (`Arc`) ທີ່ເຂັ້ມແຂງທີ່ຊີ້ໄປຈາກການຈັດສັນນີ້.
    ///
    /// ຖ້າ `self` ຖືກສ້າງຂື້ນໂດຍໃຊ້ [`Weak::new`], ນີ້ຈະກັບຄືນ 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// ໄດ້ຮັບການປະມານຂອງຕົວເລກຂອງ `Weak` ທີ່ຊີ້ໄປຫາການຈັດສັນນີ້.
    ///
    /// ຖ້າ `self` ໄດ້ສ້າງການນໍາໃຊ້ [`Weak::new`], ຫຼືຖ້າຫາກວ່າບໍ່ມີຄໍາແນະນໍາທີ່ເຂັ້ມແຂງທີ່ຍັງເຫຼືອນີ້ຈະກັບຄືນ 0.
    ///
    /// # Accuracy
    ///
    /// ເນື່ອງຈາກລາຍລະອຽດການຈັດຕັ້ງປະຕິບັດ, ມູນຄ່າທີ່ສົ່ງຄືນສາມາດຖືກປິດລົງໂດຍ 1 ໃນທິດທາງທັງໃນເວລາທີ່ກະທູ້ອື່ນ ກຳ ລັງຈັດການກັບ `Arc`s ຫຼື`Weak` ໃດທີ່ຊີ້ໄປເຖິງການຈັດສັນອັນດຽວກັນ.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // ເນື່ອງຈາກພວກເຮົາສັງເກດເຫັນວ່າມີຢ່າງ ໜ້ອຍ ໜຶ່ງ ຕົວຊີ້ທີ່ແຂງແຮງຫຼັງຈາກອ່ານ ຈຳ ນວນທີ່ອ່ອນແອ, ພວກເຮົາຮູ້ວ່າເອກະສານອ້າງອີງທີ່ອ່ອນແອ (ມີຢູ່ທຸກຄັ້ງທີ່ມີການອ້າງອີງທີ່ເຂັ້ມແຂງ) ຍັງຄົງຢູ່ໃນເວລາທີ່ພວກເຮົາສັງເກດການນັບທີ່ອ່ອນແອ, ແລະດັ່ງນັ້ນຈິ່ງສາມາດຫັກອອກໄດ້ຢ່າງປອດໄພ.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// ກັບຄືນ `None` ເມື່ອຕົວຊີ້ຖືກຫ້ອຍແລະບໍ່ມີ `ArcInner` ທີ່ຖືກຈັດສັນ, (ໝາຍ ຄວາມວ່າເມື່ອ `Weak` ນີ້ຖືກສ້າງຂື້ນໂດຍ `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ພວກເຮົາມີຄວາມລະມັດລະວັງທີ່ຈະບໍ່ * ສ້າງເອກະສານອ້າງອີງທີ່ກ່ຽວຂ້ອງກັບສະ ໜາມ "data", ເນື່ອງຈາກວ່າພາກສະ ໜາມ ອາດຈະມີການປ່ຽນແປງໄປພ້ອມໆກັນ (ຕົວຢ່າງ, ຖ້າ `Arc` ສຸດທ້າຍຖືກຫຼຸດລົງ, ຂໍ້ມູນຂໍ້ມູນຈະຖືກຖິ້ມຢູ່ບ່ອນເກົ່າ)
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// ກັບຄືນ `true` ຖ້າສອງ `Weak` ຊີ້ໄປໃນການຈັດສັນອັນດຽວກັນ (ຄ້າຍຄືກັນກັບ [`ptr::eq`]), ຫຼືຖ້າທັງສອງບໍ່ໄດ້ ໝາຍ ເຖິງການຈັດສັນໃດໆ (ເພາະວ່າມັນຖືກສ້າງຂື້ນດ້ວຍ `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// ເນື່ອງຈາກວ່ານີ້ປຽບທຽບຕົວຊີ້ມັນ ໝາຍ ຄວາມວ່າ `Weak::new()` ຈະເທົ່າກັນ, ເຖິງແມ່ນວ່າພວກເຂົາບໍ່ໄດ້ ໝາຍ ເຖິງການຈັດສັນໃດໆ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// ປຽບທຽບ `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// ເຮັດໃຫ້ໂຄນຂອງຕົວຊີ້ `Weak` X ທີ່ຊີ້ໃຫ້ເຫັນເຖິງການຈັດສັນແບບດຽວກັນ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // ເບິ່ງ ຄຳ ເຫັນໃນ Arc::clone() ສຳ ລັບເຫດຜົນທີ່ເຮັດໃຫ້ຜ່ອນຄາຍລົງ.
        // ສິ່ງນີ້ສາມາດໃຊ້ fetch_add (ບໍ່ສົນໃຈກັບການລັອກ) ເພາະວ່າຕົວເລກທີ່ອ່ອນແອຈະຖືກລັອກໄວ້ຢູ່ບ່ອນທີ່ * ບໍ່ມີຈຸດອ່ອນອື່ນໆທີ່ມີຢູ່.
        //
        // (ດັ່ງນັ້ນພວກເຮົາບໍ່ສາມາດໃຊ້ລະຫັດນີ້ໃນກໍລະນີດັ່ງກ່າວ).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // ເບິ່ງ ຄຳ ເຫັນໃນ Arc::clone() ຍ້ອນຫຍັງພວກເຮົາເຮັດສິ່ງນີ້ (ສຳ ລັບ mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// ກໍ່ສ້າງ `Weak<T>` ແບບ ໃໝ່, ໂດຍບໍ່ ຈຳ ກັດຄວາມ ຈຳ.
    /// ການໂທຫາ [`upgrade`] ໃນມູນຄ່າການສົ່ງຄືນສະເຫມີໃຫ້ [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// ຫຼຸດລົງຕົວຊີ້ `Weak` X.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ບໍ່ໄດ້ພິມຫຍັງເລີຍ
    /// drop(foo);        // ພິມ "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // ຖ້າຫາກວ່າພວກເຮົາຊອກຫາວ່າພວກເຮົາໄດ້ຊີ້ອ່ອນແອສຸດທ້າຍ, ຫຼັງຈາກນັ້ນໃຊ້ເວລາຂອງຕົນໃນການ deallocate ຂໍ້ມູນທັງຫມົດ.ເບິ່ງການສົນທະນາໃນ Arc::drop() ກ່ຽວກັບການຈັດ ລຳ ດັບຄວາມ ຈຳ
        //
        // ມັນບໍ່ ຈຳ ເປັນຕ້ອງກວດສອບສະຖານະການທີ່ຖືກລັອກຢູ່ບ່ອນນີ້, ເພາະວ່າ ຈຳ ນວນທີ່ອ່ອນແອສາມາດຖືກລັອກໄດ້ຖ້າຫາກວ່າມີການອ້າງອີງທີ່ອ່ອນແອຢ່າງແນ່ນອນ ໝາຍ ຄວາມວ່າການລຸດລົງພຽງແຕ່ສາມາດ ດຳ ເນີນການຕໍ່ມາກ່ຽວກັບການກັ່ນຕອງທີ່ອ່ອນແອທີ່ຍັງເຫຼືອ, ເຊິ່ງສາມາດເກີດຂື້ນໄດ້ຫຼັງຈາກທີ່ລັອກຖືກປ່ອຍອອກມາ.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// ພວກເຮົາ ກຳ ລັງເຮັດຄວາມຊ່ຽວຊານນີ້ຢູ່ທີ່ນີ້, ແລະບໍ່ແມ່ນການເພີ່ມປະສິດທິພາບທົ່ວໄປໃນ `&T`, ເພາະວ່າຖ້າບໍ່ດັ່ງນັ້ນມັນຈະເພີ່ມຄ່າໃຊ້ຈ່າຍໃຫ້ກັບການກວດສອບຄວາມສະ ເໝີ ພາບທັງ ໝົດ.
/// ພວກເຮົາສົມມຸດວ່າ `Arc` ຖືກ ນຳ ໃຊ້ເພື່ອເກັບມ້ຽນຄຸນຄ່າທີ່ໃຫຍ່, ນັ້ນແມ່ນຄ່ອຍໆທີ່ຈະໂຄນ, ແຕ່ຍັງ ໜັກ ໃນການກວດສອບຄວາມສະ ເໝີ ພາບ, ເຮັດໃຫ້ຕົ້ນທຶນນີ້ຈ່າຍງ່າຍກວ່າ.
///
/// ມັນຍັງມີແນວໂນ້ມທີ່ຈະມີ Clones ສອງ `Arc`, ເຊິ່ງຊີ້ໃຫ້ເຫັນເຖິງມູນຄ່າດຽວກັນ, ກ່ວາສອງ `&T`s.
///
/// ພວກເຮົາພຽງແຕ່ສາມາດເຮັດສິ່ງນີ້ໄດ້ເມື່ອ `T: Eq` ເປັນ `PartialEq` ອາດຈະບໍ່ມີເຈດຕະນາໃດໆ.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// ຄວາມເທົ່າທຽມກັນ ສຳ ລັບສອງ `Arc`.
    ///
    /// ສອງ `Arc` ເທົ່າທຽມກັນຖ້າວ່າຄ່າພາຍໃນຂອງພວກມັນເທົ່າທຽມກັນ, ເຖິງແມ່ນວ່າພວກມັນຈະຖືກເກັບຢູ່ໃນການຈັດສັນທີ່ແຕກຕ່າງກັນ.
    ///
    /// ຖ້າ `T` ຍັງປະຕິບັດ `Eq` (ເຊິ່ງສະແດງການສະທ້ອນກັບຄວາມສະ ເໝີ ພາບ), ສອງ `Arc ທີ່ຊີ້ໄປເຖິງການຈັດສັນອັນດຽວກັນແມ່ນສະເຫມີກັນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// ຄວາມບໍ່ສະເຫມີພາບ ສຳ ລັບສອງ `Arc.
    ///
    /// ສອງ `Arc` ແມ່ນບໍ່ເທົ່າກັນຖ້າວ່າຄ່າພາຍໃນຂອງພວກມັນບໍ່ເທົ່າກັນ.
    ///
    /// ຖ້າ `T` ຍັງປະຕິບັດ `Eq` (ສະທ້ອນໃຫ້ເຫັນເຖິງຄວາມສະທ້ອນຂອງຄວາມສະ ເໝີ ພາບ), ສອງ `Arc ທີ່ຊີ້ໃຫ້ເຫັນຄ່າດຽວກັນບໍ່ເຄີຍມີຄວາມແຕກຕ່າງເລີຍ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// ການປຽບທຽບບາງສ່ວນສໍາລັບສອງ `Arc`s.
    ///
    /// ທັງສອງຖືກປຽບທຽບໂດຍການໂທຫາ `partial_cmp()` ກ່ຽວກັບຄ່າພາຍໃນຂອງພວກເຂົາ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// ການປຽບທຽບ ໜ້ອຍ ກວ່າສອງ `Arc`.
    ///
    /// ທັງສອງຖືກປຽບທຽບໂດຍການໂທຫາ `<` ກ່ຽວກັບຄ່າພາຍໃນຂອງພວກເຂົາ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// ການປຽບທຽບ 'ນ້ອຍກວ່າຫລືເທົ່າກັບ' ສຳ ລັບສອງ `Arc`.
    ///
    /// ທັງສອງຖືກປຽບທຽບໂດຍການໂທຫາ `<=` ກ່ຽວກັບຄ່າພາຍໃນຂອງພວກເຂົາ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// ການປຽບທຽບທີ່ດີກວ່າ ສຳ ລັບສອງ `Arc`.
    ///
    /// ທັງສອງຖືກປຽບທຽບໂດຍການໂທຫາ `>` ກ່ຽວກັບຄ່າພາຍໃນຂອງພວກເຂົາ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// ການປຽບທຽບ 'ໃຫຍ່ກວ່າຫລືເທົ່າກັບ' ສຳ ລັບສອງ `Arc`.
    ///
    /// ທັງສອງຖືກປຽບທຽບໂດຍການໂທຫາ `>=` ກ່ຽວກັບຄ່າພາຍໃນຂອງພວກເຂົາ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// ປຽບທຽບ ສຳ ລັບສອງ `Arc`.
    ///
    /// ທັງສອງກໍາລັງປຽບທຽບໂດຍການໂທຫາ `cmp()` ກ່ຽວກັບຄ່າຂອງເຂົາເຈົ້າ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// ສ້າງ `Arc<T>` ລຸ້ນ ໃໝ່, ມີມູນຄ່າ `Default` ສຳ ລັບ `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// ຈັດແຈງຊິ້ນສ່ວນທີ່ອ້າງອີງໃສ່ການອ້າງອີງແລະຕື່ມຂໍ້ມູນໃສ່ໂດຍການກົດປຸ່ມລາຍການ `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// ຈັດສັນເອກະສານອ້າງອີງ `str` ແລະ ສຳ ເນົາ `v` ໃສ່ມັນ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// ຈັດສັນເອກະສານອ້າງອີງ `str` ແລະ ສຳ ເນົາ `v` ໃສ່ມັນ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// ຍ້າຍວັດຖຸທີ່ໃສ່ໃນປ່ອງໄປບ່ອນຈັດສັນ ໃໝ່ ທີ່ອີງໃສ່ການອ້າງອີງ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// ຈັດແຈງຊິ້ນສ່ວນທີ່ອ້າງອີງໃສ່ການອ້າງອີງແລະຍ້າຍລາຍການຂອງ `v` ລົງໃນນັ້ນ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // ອະນຸຍາດໃຫ້ Vec ເພື່ອຄວາມຊົງຈໍາຂອງຕົນ, ແຕ່ບໍ່ທໍາລາຍເນື້ອໃນຂອງຕົນ
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// ໃຊ້ເວລາໃນແຕ່ລະອົງປະກອບໃນ `Iterator` ແລະເກັບມັນເຂົ້າໄປໃນ `Arc<[T]>`.
    ///
    /// # ຄຸນລັກສະນະການປະຕິບັດ
    ///
    /// ## ກໍລະນີທົ່ວໄປ
    ///
    /// ໃນກໍລະນີທົ່ວໄປ, ການລວບລວມເຂົ້າ `Arc<[T]>` ແມ່ນເຮັດໂດຍການເກັບຄັ້ງ ທຳ ອິດເຂົ້າໃນ `Vec<T>`.ນັ້ນແມ່ນ, ໃນເວລາທີ່ຂຽນສິ່ງຕໍ່ໄປນີ້:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ນີ້ປະຕິບັດຕົວຄືກັບວ່າພວກເຮົາຂຽນວ່າ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // ການຈັດສັນຊຸດ ທຳ ອິດເກີດຂື້ນທີ່ນີ້.
    ///     .into(); // ການຈັດສັນຄັ້ງທີສອງ ສຳ ລັບ `Arc<[T]>` ເກີດຂື້ນທີ່ນີ້.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ສິ່ງນີ້ຈະຈັດສັນ ຈຳ ນວນຫຼາຍເທົ່າທີ່ຕ້ອງການ ສຳ ລັບການກໍ່ສ້າງ `Vec<T>` ແລະຫຼັງຈາກນັ້ນມັນຈະຈັດສັນຄັ້ງດຽວ ສຳ ລັບປ່ຽນ `Vec<T>` ເປັນ `Arc<[T]>`.
    ///
    ///
    /// ## ເຄື່ອງຕັດຄວາມຍາວທີ່ຮູ້ຈັກ
    ///
    /// ເມື່ອ `Iterator` ຂອງທ່ານປະຕິບັດ `TrustedLen` ແລະມີຂະ ໜາດ ທີ່ແນ່ນອນ, ການຈັດສັນ ໜຶ່ງ ສຳ ລັບ `Arc<[T]>`.ຍົກຕົວຢ່າງ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // ພຽງແຕ່ເປັນການຈັດສັນດຽວເກີດຂຶ້ນຢູ່ທີ່ນີ້.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// ຄວາມຊ່ຽວຊານ trait ໃຊ້ ສຳ ລັບເກັບເຂົ້າ `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // ນີ້ແມ່ນກໍລະນີ ສຳ ລັບເຄື່ອງປັບ `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ຄວາມປອດໄພ: ພວກເຮົາຕ້ອງຮັບປະກັນວ່າຕົວປັບມີຄວາມຍາວທີ່ແນ່ນອນແລະພວກເຮົາມີ.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // ຕົກລົງກັບການຈັດຕັ້ງປະຕິບັດຕາມປົກກະຕິ.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// ໄດ້ຮັບການຊົດເຊີຍພາຍໃນ `ArcInner` ສໍາລັບ payload ທີ່ຢູ່ເບື້ອງຫລັງຕົວຊີ້.
///
/// # Safety
///
/// ຕົວຊີ້ຕ້ອງຕ້ອງຊີ້ໃຫ້ເຫັນ (ແລະມີຂໍ້ມູນ metadata ທີ່ຖືກຕ້ອງ ສຳ ລັບ) ຕົວຢ່າງທີ່ຖືກຕ້ອງໃນເມື່ອກ່ອນຂອງ T, ແຕ່ T ຖືກອະນຸຍາດໃຫ້ລຸດລົງ.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // ຈັດລຽນມູນຄ່າທີ່ບໍ່ຖືກຕ້ອງຈົນເຖິງປາຍ ArcInner.
    // ເນື່ອງຈາກວ່າ RcBox ແມ່ນ repr(C), ມັນສະເຫມີໄປຈະເປັນພາກສະຫນາມສຸດທ້າຍໃນຫນ່ວຍຄວາມຈໍາ.
    // ຄວາມປອດໄພ: ເນື່ອງຈາກມີພຽງແຕ່ປະເພດທີ່ບໍ່ໄດ້ມາດຕະຖານເທົ່ານັ້ນທີ່ສາມາດເຮັດໄດ້ແມ່ນຊິ້ນ, trait,
    // ແລະປະເພດພາຍນອກ, ຄວາມຕ້ອງການຄວາມປອດໄພໃນການປ້ອນຂໍ້ມູນແມ່ນພຽງພໍກັບຄວາມຕ້ອງການຂອງ align_of_val_raw;ນີ້ແມ່ນລາຍລະອຽດການປະຕິບັດຂອງພາສາທີ່ອາດຈະບໍ່ໄດ້ຮັບການອີງອາໃສຕາມນອກ std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}