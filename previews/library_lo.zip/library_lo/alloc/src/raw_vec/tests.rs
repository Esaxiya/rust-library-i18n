use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // ການຂຽນບົດທົດສອບການລວມຕົວລະຫວ່າງຜູ້ຈັດສັນຂອງບຸກຄົນທີສາມແລະ `RawVec` ແມ່ນເປັນເລື່ອງເລັກໆນ້ອຍໆເພາະວ່າ `RawVec` API ບໍ່ໄດ້ເປີດເຜີຍວິທີການຈັດສັນທີ່ບໍ່ຖືກຕ້ອງ, ດັ່ງນັ້ນພວກເຮົາບໍ່ສາມາດກວດສອບວ່າຈະມີຫຍັງເກີດຂື້ນໃນເວລາທີ່ຜູ້ຈັດສັນ ໝົດ ອາຍຸ (ນອກ ເໜືອ ຈາກການກວດພົບ panic).
    //
    //
    // ແທນທີ່ຈະ, ນີ້ພຽງແຕ່ກວດເບິ່ງວ່າວິທີການ `RawVec` ຢ່າງ ໜ້ອຍ ຈະຜ່ານ Allocator API ເມື່ອມັນສະຫງວນບ່ອນເກັບມ້ຽນ.
    //
    //
    //
    //
    //

    // ຜູ້ຈັດສັນທີ່ບໍ່ດີທີ່ບໍລິໂພກນ້ ຳ ມັນເຊື້ອໄຟຄົງທີ່ກ່ອນການພະຍາຍາມຈັດສັນຈະເລີ່ມລົ້ມເຫລວ.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (ສາເຫດທີ່ເກີດຂື້ນຈິງ, ດັ່ງນັ້ນການ ນຳ ໃຊ້ນໍ້າມັນເຊື້ອໄຟ 50 + 150=200 ໜ່ວຍ)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // ຫນ້າທໍາອິດ, `reserve` ຈັດສັນຄື `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 ແມ່ນຫຼາຍກ່ວາສອງເທົ່າຂອງ 7, ດັ່ງນັ້ນ `reserve` ຄວນເຮັດວຽກຄື `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 ແມ່ນ ໜ້ອຍ ກ່ວາເຄິ່ງ ໜຶ່ງ ຂອງ 12, ສະນັ້ນ `reserve` ຕ້ອງເຕີບໃຫຍ່ແບບເລັ່ງລັດ.
        // ໃນເວລາຂຽນການຂະຫຍາຍຕົວຂອງປັດໃຈການທົດສອບນີ້ແມ່ນ 2, ສະນັ້ນຄວາມສາມາດ ໃໝ່ ແມ່ນ 24, ເຖິງຢ່າງໃດກໍ່ຕາມ, ປັດໄຈການເຕີບໃຫຍ່ຂອງ 1.5 ກໍ່ເປັນໄປໄດ້ເຊັ່ນກັນ.
        //
        // ເພາະສະນັ້ນ `>= 18` ໃນການຍືນຍັນ.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}