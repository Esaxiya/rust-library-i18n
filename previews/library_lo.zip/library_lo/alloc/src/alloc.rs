//! API ການຈັດສັນຄວາມ ຈຳ

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // ນີ້ແມ່ນສັນຍາລັກມະຫັດສະຈັນເພື່ອເອີ້ນຜູ້ຈັດສັນທົ່ວໂລກ.rustc ສ້າງໃຫ້ພວກເຂົາເອີ້ນ `__rg_alloc` ແລະອື່ນໆ.
    // ຖ້າມີຄຸນລັກສະນະ `#[global_allocator]` (ລະຫັດຂະຫຍາຍວ່າຄຸນລັກສະນະມະຫາພາກສ້າງ ໜ້າ ທີ່ເຫຼົ່ານັ້ນ), ຫຼືເອີ້ນການປະຕິບັດທີ່ບໍ່ຖືກຕ້ອງໃນ libstd (`__rdl_alloc` ແລະອື່ນໆ)
    //
    // ໃນ `library/std/src/alloc.rs`) ຖ້າບໍ່ດັ່ງນັ້ນ.
    // rustc fork ຂອງ LLVM ຍັງມີກໍລະນີພິເສດຊື່ການເຮັດວຽກເຫຼົ່ານີ້ເພື່ອໃຫ້ສາມາດເພີ່ມປະສິດທິພາບຂອງມັນເຊັ່ນ: `malloc`, `realloc`, ແລະ `free` ຕາມ ລຳ ດັບ.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// ຜູ້ຈັດສັນຄວາມ ຈຳ ທົ່ວໂລກ.
///
/// ປະເພດນີ້ປະຕິບັດ [`Allocator`] trait ໂດຍການສົ່ງຕໍ່ການໂທຫາຜູ້ຈັດສັນທີ່ລົງທະບຽນກັບຄຸນລັກສະນະ `#[global_allocator]` ຖ້າມີ, ຫຼືຄ່າເລີ່ມຕົ້ນຂອງ `std` crate.
///
///
/// Note: ໃນຂະນະທີ່ປະເພດນີ້ບໍ່ສະຖຽນລະພາບ, ຟັງຊັນທີ່ມັນສະ ໜອງ ໃຫ້ສາມາດເຂົ້າເຖິງ [free functions in `alloc`](self#functions) ໄດ້.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// ຈັດສັນຄວາມຊົງ ຈຳ ກັບຜູ້ຈັດສັນທົ່ວໂລກ.
///
/// ໜ້າ ທີ່ນີ້ຈະໂທຫາວິທີ [`GlobalAlloc::alloc`] ຂອງຜູ້ຈັດສັນທີ່ລົງທະບຽນກັບ `#[global_allocator]` attribute ຖ້າມີ, ຫຼືຄ່າເລີ່ມຕົ້ນຂອງ `std` crate.
///
///
/// ຟັງຊັນນີ້ຄາດວ່າຈະຖືກປະຕິເສດໃນຄວາມໂປດປານຂອງວິທີ `alloc` ຂອງປະເພດ [`Global`] ເມື່ອມັນແລະ [`Allocator`] trait ມີຄວາມ ໝັ້ນ ຄົງ.
///
/// # Safety
///
/// ເບິ່ງ [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// ຈັດສັນຄວາມຊົງ ຈຳ ກັບຜູ້ຈັດສັນທົ່ວໂລກ.
///
/// ໜ້າ ທີ່ນີ້ຈະໂທຫາວິທີ [`GlobalAlloc::dealloc`] ຂອງຜູ້ຈັດສັນທີ່ລົງທະບຽນກັບ `#[global_allocator]` attribute ຖ້າມີ, ຫຼືຄ່າເລີ່ມຕົ້ນຂອງ `std` crate.
///
///
/// ຟັງຊັນນີ້ຄາດວ່າຈະຖືກປະຕິເສດໃນຄວາມໂປດປານຂອງວິທີ `dealloc` ຂອງປະເພດ [`Global`] ເມື່ອມັນແລະ [`Allocator`] trait ມີຄວາມ ໝັ້ນ ຄົງ.
///
/// # Safety
///
/// ເບິ່ງ [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// ຈັດສັນຄວາມຊົງ ຈຳ ຢ່າງແທ້ຈິງກັບຜູ້ຈັດສັນທົ່ວໂລກ.
///
/// ໜ້າ ທີ່ນີ້ຈະໂທຫາວິທີ [`GlobalAlloc::realloc`] ຂອງຜູ້ຈັດສັນທີ່ລົງທະບຽນກັບ `#[global_allocator]` attribute ຖ້າມີ, ຫຼືຄ່າເລີ່ມຕົ້ນຂອງ `std` crate.
///
///
/// ຟັງຊັນນີ້ຄາດວ່າຈະຖືກປະຕິເສດໃນຄວາມໂປດປານຂອງວິທີ `realloc` ຂອງປະເພດ [`Global`] ເມື່ອມັນແລະ [`Allocator`] trait ມີຄວາມ ໝັ້ນ ຄົງ.
///
/// # Safety
///
/// ເບິ່ງ [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// ຈັດສັນຄວາມຊົງ ຈຳ ທີ່ມີຈຸດເລີ່ມຕົ້ນສູນກັບຜູ້ຈັດສັນທົ່ວໂລກ.
///
/// ໜ້າ ທີ່ນີ້ຈະໂທຫາວິທີ [`GlobalAlloc::alloc_zeroed`] ຂອງຜູ້ຈັດສັນທີ່ລົງທະບຽນກັບ `#[global_allocator]` attribute ຖ້າມີ, ຫຼືຄ່າເລີ່ມຕົ້ນຂອງ `std` crate.
///
///
/// ຟັງຊັນນີ້ຄາດວ່າຈະຖືກປະຕິເສດໃນຄວາມໂປດປານຂອງວິທີ `alloc_zeroed` ຂອງປະເພດ [`Global`] ເມື່ອມັນແລະ [`Allocator`] trait ມີຄວາມ ໝັ້ນ ຄົງ.
///
/// # Safety
///
/// ເບິ່ງ [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // ຄວາມປອດໄພ: `layout` ບໍ່ມີຂະ ໜາດ,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // ຄວາມປອດໄພ: ຄືກັນກັບ `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // ຄວາມປອດໄພ: `new_size` ບໍ່ແມ່ນສູນຍ້ອນ `old_size` ໃຫຍ່ກວ່າຫຼືເທົ່າກັບ `new_size`
            // ຕາມຄວາມຕ້ອງການຂອງສະພາບຄວາມປອດໄພ.ເງື່ອນໄຂອື່ນໆຕ້ອງໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ຈາກຜູ້ໂທ
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` ອາດຈະກວດເບິ່ງ `new_size >= old_layout.size()` ຫຼືບາງສິ່ງບາງຢ່າງທີ່ຄ້າຍຄືກັນ.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // ຄວາມປອດໄພ: ເພາະວ່າ `new_layout.size()` ຕ້ອງຈະໃຫຍ່ກວ່າຫຼືເທົ່າກັບ `old_size`,
            // ທັງການຈັດສັນຄວາມ ຈຳ ເກົ່າແລະ ໃໝ່ ແມ່ນຖືກຕ້ອງ ສຳ ລັບການອ່ານແລະຂຽນ ສຳ ລັບ `old_size` ໄບ.
            // ເຊັ່ນດຽວກັນ, ເພາະວ່າການຈັດສັນເກົ່າບໍ່ໄດ້ຮັບການຈັດສັນ, ມັນບໍ່ສາມາດຊໍ້າຊ້ອນ `new_ptr`.
            // ດັ່ງນັ້ນ, ການໂທຫາ `copy_nonoverlapping` ແມ່ນປອດໄພ.
            // ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `dealloc` ຕ້ອງໄດ້ຮັບການຮັກສາຈາກຜູ້ໂທ.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // ຄວາມປອດໄພ: `layout` ບໍ່ມີຂະ ໜາດ,
            // ເງື່ອນໄຂອື່ນໆຕ້ອງໄດ້ຮັບການຮັກສາໂດຍຜູ້ໂທ
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ປອດໄພ: ທຸກເງື່ອນໄຂຕ້ອງໄດ້ຮັບການຮັກສາຈາກຜູ້ໂທ
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ປອດໄພ: ທຸກເງື່ອນໄຂຕ້ອງໄດ້ຮັບການຮັກສາຈາກຜູ້ໂທ
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // ຄວາມປອດໄພ: ເງື່ອນໄຂຕ້ອງໄດ້ຮັບການຮັກສາໂດຍຜູ້ໂທ
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // ຄວາມປອດໄພ: `new_size` ບໍ່ແມ່ນສູນ.ເງື່ອນໄຂອື່ນໆຕ້ອງໄດ້ຮັບການສະ ໜັບ ສະ ໜູນ ຈາກຜູ້ໂທ
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` ອາດຈະກວດເບິ່ງ `new_size <= old_layout.size()` ຫຼືບາງສິ່ງບາງຢ່າງທີ່ຄ້າຍຄືກັນ.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // ຄວາມປອດໄພ: ເພາະວ່າ `new_size` ຕ້ອງນ້ອຍກວ່າຫຼືເທົ່າກັບ `old_layout.size()`,
            // ທັງການຈັດສັນຄວາມ ຈຳ ເກົ່າແລະ ໃໝ່ ແມ່ນຖືກຕ້ອງ ສຳ ລັບການອ່ານແລະຂຽນ ສຳ ລັບ `new_size` ໄບ.
            // ເຊັ່ນດຽວກັນ, ເພາະວ່າການຈັດສັນເກົ່າບໍ່ໄດ້ຮັບການຈັດສັນ, ມັນບໍ່ສາມາດຊໍ້າຊ້ອນ `new_ptr`.
            // ດັ່ງນັ້ນ, ການໂທຫາ `copy_nonoverlapping` ແມ່ນປອດໄພ.
            // ສັນຍາຄວາມປອດໄພ ສຳ ລັບ `dealloc` ຕ້ອງໄດ້ຮັບການຮັກສາຈາກຜູ້ໂທ.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// ຜູ້ຈັດສັນເພື່ອຈຸດພິເສດ.
// ໜ້າ ທີ່ນີ້ຕ້ອງບໍ່ຫລຸດລົງ.ຖ້າມັນເຮັດ, code MIR ຈະລົ້ມເຫລວ.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// ລາຍເຊັນນີ້ຕ້ອງຄືກັນກັບ `Box`, ຖ້າບໍ່ດັ່ງນັ້ນ ICE ຈະເກີດຂື້ນ.
// ໃນເວລາທີ່ພາລາມິເຕີເພີ່ມເຕີມຕໍ່ `Box` ຈະຖືກເພີ່ມ (ເຊັ່ນ `A: Allocator`), ນີ້ກໍ່ຕ້ອງໄດ້ຖືກເພີ່ມຢູ່ທີ່ນີ້ເຊັ່ນກັນ.
// ຕົວຢ່າງເຊັ່ນຖ້າ `Box` ຖືກປ່ຽນເປັນ `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, ໜ້າ ທີ່ນີ້ຕ້ອງໄດ້ປ່ຽນເປັນ `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` ເຊັ່ນກັນ.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # ຜູ້ຈັດການຜິດພາດການຈັດສັນ

extern "Rust" {
    // ນີ້ແມ່ນສັນຍາລັກມະຫັດສະຈັນທີ່ຈະເອີ້ນຜູ້ຈັດການຄວາມຜິດພາດດ້ານການຈັດສັນທົ່ວໂລກ.
    // rustc ສ້າງມັນໃຫ້ເອີ້ນ `__rg_oom` ຖ້າມີ `#[alloc_error_handler]`, ຫຼືເອີ້ນການປະຕິບັດທີ່ບໍ່ຖືກຕ້ອງຢູ່ລຸ່ມ (`__rdl_oom`) ຖ້າບໍ່ດັ່ງນັ້ນ.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// ຍົກເລີກຂໍ້ຜິດພາດຫລືຄວາມລົ້ມເຫລວໃນການຈັດສັນຄວາມ ຈຳ.
///
/// ຜູ້ໂທຂອງ API ການຈັດສັນຄວາມ ຈຳ ທີ່ຕ້ອງການຍົກເລີກການ ຄຳ ນວນໃນການຕອບສະ ໜອງ ຕໍ່ຂໍ້ຜິດພາດຂອງການຈັດສັນໄດ້ຖືກຊຸກຍູ້ໃຫ້ໂທຫາຟັງຊັນນີ້, ແທນທີ່ຈະຮຽກຮ້ອງໂດຍກົງ `panic!` ຫຼືຄ້າຍຄືກັນ.
///
///
/// ພຶດຕິ ກຳ ໃນຕອນຕົ້ນຂອງ ໜ້າ ທີ່ນີ້ແມ່ນການພິມຂໍ້ຄວາມເຖິງຂໍ້ຜິດພາດມາດຕະຖານແລະປະຕິບັດຂັ້ນຕອນ.
/// ມັນສາມາດຖືກທົດແທນດ້ວຍ [`set_alloc_error_hook`] ແລະ [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// ສຳ ລັບການທົດສອບການຈັດສັນ `std::alloc::handle_alloc_error` ສາມາດ ນຳ ໃຊ້ໄດ້ໂດຍກົງ.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // ເອີ້ນໂດຍຜ່ານ `__rust_alloc_error_handler` ທີ່ຜະລິດ

    // ຖ້າບໍ່ມີ `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // ຖ້າມີ `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// ຄວາມຊ່ຽວຊານຂອງ clones ເຂົ້າໄປໃນການຈັດສັນຄວາມຊົງ ຈຳ ທີ່ບໍ່ໄດ້ຮັບການຈັດສັນໄວ້ກ່ອນ.
/// ໃຊ້ໂດຍ `Box::clone` ແລະ `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // ມີການຈັດສັນ *ຄັ້ງ ທຳ ອິດ* ອາດຈະເຮັດໃຫ້ຜູ້ເພີ່ມປະສິດທິພາບສາມາດສ້າງມູນຄ່າທີ່ຖືກກົດຂື້ນ, ຂ້າມພື້ນທີ່ແລະຍ້າຍອອກໄປ.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // ພວກເຮົາສາມາດຄັດລອກສະຖານທີ່ຢູ່ສະ ເໝີ, ໂດຍບໍ່ເຄີຍມີສ່ວນກ່ຽວຂ້ອງກັບມູນຄ່າຂອງທ້ອງຖິ່ນ.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}