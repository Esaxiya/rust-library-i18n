#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// ເນື້ອໃນຂອງຄວາມຊົງ ຈຳ ໃໝ່ ແມ່ນບໍ່ມີການປ່ຽນແປງ.
    Uninitialized,
    /// ຄວາມຊົງ ຈຳ ໃໝ່ ໄດ້ຮັບປະກັນວ່າຈະສູນ.
    Zeroed,
}

/// ຜົນປະໂຫຍດລະດັບຕ່ ຳ ສຳ ລັບການຈັດສັນ, ຈັດສັນ, ຈັດສັນແລະຈັດສັນຄວາມ ຈຳ ຂອງຂໍ້ ຈຳ ກັດທີ່ບໍ່ຖືກຕ້ອງຫຼາຍຂື້ນໂດຍບໍ່ຕ້ອງກັງວົນກ່ຽວກັບທຸກໆກໍລະນີທີ່ກ່ຽວຂ້ອງ.
///
/// ປະເພດນີ້ແມ່ນດີເລີດ ສຳ ລັບການສ້າງໂຄງສ້າງຂໍ້ມູນຂອງທ່ານເອງເຊັ່ນ: Vec ແລະ VecDeque.
/// ໂດຍສະເພາະ:
///
/// * ຜະລິດ `Unique::dangling()` ຕາມປະເພດທີ່ມີຂະ ໜາດ ສູນ.
/// * ຜະລິດ `Unique::dangling()` ກ່ຽວກັບການຈັດສັນຄວາມຍາວສູນ.
/// * ຫລີກລ້ຽງການຟຣີ `Unique::dangling()`.
/// * ຈັບລາຍໄດ້ທັງ ໝົດ ທີ່ລົ້ນໃນການ ຄຳ ນວນຄວາມສາມາດ (ສົ່ງເສີມໃຫ້ "capacity overflow" panics).
/// * ກອງຕໍ່ຕ້ານລະບົບ 32 ບິດຈັດສັນຫຼາຍກ່ວາ isize::MAX bytes.
/// * ກອງຕໍ່ຕ້ານຄວາມຍາວຂອງທ່ານ.
/// * ໂທຫາ `handle_alloc_error` ສຳ ລັບການຈັດສັນທີ່ຫຼຸດລົງ.
/// * ປະກອບມີ `ptr::Unique` ແລະດັ່ງນັ້ນຈຶ່ງເຮັດໃຫ້ຜູ້ໃຊ້ມີຜົນປະໂຫຍດທີ່ກ່ຽວຂ້ອງທັງຫມົດ.
/// * ໃຊ້ສ່ວນເກີນທີ່ໄດ້ກັບມາຈາກຜູ້ຈັດສັນເພື່ອໃຊ້ຄວາມສາມາດທີ່ມີຢູ່ທີ່ໃຫຍ່ທີ່ສຸດ.
///
/// ປະເພດນີ້ບໍ່ໄດ້ກວດກາຄວາມຊົງ ຈຳ ທີ່ມັນຄຸ້ມຄອງ.ໃນເວລາທີ່ຫຼຸດລົງ * * ຈະບໍ່ເສຍຄ່າຄວາມຊົງຈໍາຂອງຕົນ, ແຕ່ວ່າມັນ *ຈະບໍ່* ພະຍາຍາມຈະລຸດລົງເນື້ອໃນຂອງຕົນ.
/// ມັນຂື້ນກັບຜູ້ໃຊ້ `RawVec` ໃນການຈັດການກັບສິ່ງທີ່ແທ້ຈິງ *ເກັບໄວ້* ພາຍໃນຂອງ `RawVec`.
///
/// ໃຫ້ສັງເກດວ່າການເກີນປະເພດທີ່ມີຂະ ໜາດ ສູນແມ່ນບໍ່ມີນິດຕະຫຼອດ, ສະນັ້ນ `capacity()` ກໍ່ຈະກັບຄືນ `usize::MAX` ຢູ່ສະ ເໝີ.
/// ນີ້ ໝາຍ ຄວາມວ່າທ່ານ ຈຳ ເປັນຕ້ອງລະມັດລະວັງໃນເວລາທີ່ໂບກປະເພດນີ້ດ້ວຍ `Box<[T]>`, ເພາະວ່າ `capacity()` ຈະບໍ່ໃຫ້ຄວາມຍາວ.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): ສິ່ງນີ້ມີຢູ່ເພາະວ່າ `#[unstable]` `const fn` ບໍ່ ຈຳ ເປັນຕ້ອງສອດຄ່ອງກັບ `min_const_fn` ແລະສະນັ້ນພວກມັນບໍ່ສາມາດຖືກເອີ້ນໃນ `min_const_fn`s ກໍ່ໄດ້.
    ///
    /// ຖ້າທ່ານປ່ຽນ `RawVec<T>::new` ຫຼືຄວາມເພິ່ງພາອາໄສ, ກະລຸນາລະມັດລະວັງເພື່ອບໍ່ແນະ ນຳ ສິ່ງໃດທີ່ຈະລະເມີດ `min_const_fn` ຢ່າງແທ້ຈິງ.
    ///
    /// NOTE: ພວກເຮົາສາມາດຫລີກລ້ຽງການລັກລອບນີ້ແລະກວດສອບຄວາມສອດຄ່ອງກັບບາງຄຸນລັກສະນະ `#[rustc_force_min_const_fn]` ເຊິ່ງຮຽກຮ້ອງໃຫ້ມີຄວາມສອດຄ່ອງກັບ `min_const_fn` ແຕ່ບໍ່ ຈຳ ເປັນຕ້ອງເອີ້ນມັນຢູ່ໃນລະຫັດ `stable(...) const fn`/ລະຫັດຜູ້ໃຊ້ບໍ່ສາມາດເຮັດໃຫ້ `foo` ເມື່ອມີ `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// ສ້າງ `RawVec` ທີ່ໃຫຍ່ທີ່ສຸດທີ່ເປັນໄປໄດ້ (ຢູ່ໃນ heap ລະບົບ) ໂດຍບໍ່ຕ້ອງມີການຈັດສັນ.
    /// ຖ້າ `T` ມີຂະ ໜາດ ໃນແງ່ບວກ, ແລ້ວສິ່ງນີ້ກໍ່ເຮັດໃຫ້ `RawVec` ມີຄວາມສາມາດ `0`.
    /// ຖ້າ `T` ມີຂະ ໜາດ ສູນ, ຫຼັງຈາກນັ້ນມັນກໍ່ເຮັດໃຫ້ `RawVec` ມີຄວາມຈຸ `usize::MAX`.
    /// ເປັນປະໂຫຍດ ສຳ ລັບການຈັດຕັ້ງປະຕິບັດການຈັດສັນຊັກຊ້າ.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// ສ້າງ `RawVec` (ເທິງກະແສໄຟຟ້າຂອງລະບົບ) ດ້ວຍຄວາມສາມາດແລະຄວາມຕ້ອງການທີ່ສອດຄ່ອງ ສຳ ລັບ `[T; capacity]`.
    /// ນີ້ເທົ່າກັບການໂທ `RawVec::new` ເມື່ອ `capacity` ແມ່ນ `0` ຫຼື `T` ແມ່ນຂະ ໜາດ ສູນ.
    /// ຈົ່ງສັງເກດວ່າຖ້າ `T` ມີຂະ ໜາດ ສູນ, ນີ້ ໝາຍ ຄວາມວ່າທ່ານຈະບໍ່ໄດ້ຮັບ `RawVec` ທີ່ມີຄວາມສາມາດທີ່ຕ້ອງການ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຄວາມສາມາດທີ່ຕ້ອງການເກີນ `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// ສໍາເລັດໃນ OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// ເຊັ່ນດຽວກັບ `with_capacity`, ແຕ່ຮັບປະກັນວ່າ buffer ແມ່ນສູນ.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// ປັບ ໃໝ່ `RawVec` ຈາກຕົວຊີ້ແລະຄວາມສາມາດ.
    ///
    /// # Safety
    ///
    /// ຕ້ອງມີການຈັດສັນ `ptr` (ຢູ່ໃນຮວບຮວມຂອງລະບົບ), ແລະດ້ວຍ `capacity` ທີ່ໄດ້ມອບໃຫ້.
    /// `capacity` ບໍ່ສາມາດເກີນ `isize::MAX` ສຳ ລັບປະເພດທີ່ມີຂະ ໜາດ.(ເປັນພຽງຄວາມກັງວົນຕໍ່ລະບົບ 32 ບິດ).
    /// ZST vectors ອາດຈະມີຄວາມຈຸສູງເຖິງ `usize::MAX`.
    /// ຖ້າ `ptr` ແລະ `capacity` ມາຈາກ `RawVec`, ຫຼັງຈາກນັ້ນ, ນີ້ແມ່ນການຮັບປະກັນ.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // ຂະ ໜາດ ນ້ອຍໆ Vecs ບໍ່ສະຫຼາດ.ຂ້າມໄປຫາ:
    // - 8 ຖ້າວ່າຂະ ໜາດ ຂອງອົງປະກອບແມ່ນ 1, ເພາະວ່າຜູ້ຈັດສັນຂໍ້ມູນ heap ມີແນວໂນ້ມທີ່ຈະເຮັດໃຫ້ ຄຳ ຮ້ອງຂໍທີ່ນ້ອຍກວ່າ 8 bytes ຫາຢ່າງ ໜ້ອຍ 8 bytes.
    //
    // - 4 ຖ້າອົງປະກອບມີຂະ ໜາດ ປານກາງ (<=1 KiB).
    // - 1 ຖ້າບໍ່ດັ່ງນັ້ນ, ເພື່ອຫລີກລ້ຽງການສູນເສຍພື້ນທີ່ຫຼາຍເກີນໄປ ສຳ ລັບ Vecs ທີ່ສັ້ນຫຼາຍ.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// ເຊັ່ນດຽວກັນກັບ `new`, ແຕ່ມີຕົວກໍານົດໃນໄລຍະທາງເລືອກຂອງຜູ້ຈັດສັນສໍາລັບ `RawVec` ທີ່ສົ່ງຄືນ.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` ຫມາຍຄວາມວ່າ "unallocated".ປະເພດທີ່ມີຂະ ໜາດ ສູນແມ່ນບໍ່ສົນໃຈ.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// ເຊັ່ນດຽວກັນກັບ `with_capacity`, ແຕ່ parameterized ໃນໄລຍະທາງເລືອກຂອງຕົວຈັດສັນສໍາລັບ `RawVec` ກັບຄືນໄດ້.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// ເຊັ່ນດຽວກັນກັບ `with_capacity_zeroed`, ແຕ່ມີຕົວກໍານົດໃນໄລຍະທາງເລືອກຂອງຜູ້ຈັດສັນສໍາລັບ `RawVec` ທີ່ສົ່ງຄືນ.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// ແປງ `Box<[T]>` ເປັນ `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// ແປງ buffer ທັງ ໝົດ ໃຫ້ເປັນ `Box<[MaybeUninit<T>]>` ກັບ `len` ທີ່ລະບຸ.
    ///
    /// ໃຫ້ສັງເກດວ່າສິ່ງນີ້ຈະເຮັດໄດ້ຢ່າງຖືກຕ້ອງການປ່ຽນແປງໃດໆຂອງ `cap` ທີ່ອາດຈະຖືກປະຕິບັດ.(ເບິ່ງລາຍລະອຽດຂອງປະເພດ ສຳ ລັບລາຍລະອຽດ.)
    ///
    /// # Safety
    ///
    /// * `len` ຕ້ອງຫຼາຍກ່ວາຫຼືເທົ່າກັບຄວາມອາດສາມາດທີ່ສຸດຮຽກຮ້ອງໃຫ້ບໍ່ດົນມານີ້, ແລະ
    /// * `len` ຕ້ອງຫນ້ອຍກ່ວາຫຼືເທົ່າທຽມກັນທີ່ `self.capacity()`.
    ///
    /// ໝາຍ ເຫດ, ຄວາມສາມາດທີ່ຕ້ອງການແລະ `self.capacity()` ສາມາດແຕກຕ່າງກັນ, ເພາະວ່າຜູ້ຈັດສັນສາມາດຈັດສັນແລະຈັດສັນຄວາມ ຈຳ ຫຼາຍກ່ວາທີ່ຮ້ອງຂໍ.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // ຄວາມປອດໄພ-ກວດເບິ່ງເຄິ່ງ ໜຶ່ງ ຂອງຂໍ້ ກຳ ນົດດ້ານຄວາມປອດໄພ (ພວກເຮົາບໍ່ສາມາດກວດສອບອີກເຄິ່ງ ໜຶ່ງ).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // ພວກເຮົາຫລີກລ້ຽງ `unwrap_or_else` ຢູ່ທີ່ນີ້ເພາະວ່າມັນເຮັດໃຫ້ປະລິມານຂອງ LLVM IR ທີ່ຜະລິດອອກມາ.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// ປັບ ໃໝ່ `RawVec` ຈາກຕົວຊີ້, ຄວາມສາມາດແລະຜູ້ຈັດສັນ.
    ///
    /// # Safety
    ///
    /// `ptr` ຕ້ອງໄດ້ຮັບການຈັດສັນ (ຜ່ານ `alloc` ການມອບເງິນ), ແລະກັບ `capacity` ທີ່ໄດ້ມອບໃຫ້.
    /// `capacity` ບໍ່ສາມາດເກີນ `isize::MAX` ສຳ ລັບປະເພດທີ່ມີຂະ ໜາດ.
    /// (ເປັນພຽງຄວາມກັງວົນຕໍ່ລະບົບ 32 ບິດ).
    /// ZST vectors ອາດຈະມີຄວາມຈຸສູງເຖິງ `usize::MAX`.
    /// ຖ້າ `ptr` ແລະ `capacity` ແມ່ນມາຈາກ `RawVec` ທີ່ສ້າງຂື້ນຜ່ານ `alloc`, ນີ້ຈະຖືກຮັບປະກັນ.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// ຈັບຕົວຊີ້ວັດຖຸດິບໃນການເລີ່ມຕົ້ນຂອງການຈັດສັນ.
    /// ໃຫ້ສັງເກດວ່ານີ້ແມ່ນ `Unique::dangling()` ຖ້າ `capacity == 0` ຫຼື `T` ແມ່ນຂະຫນາດສູນ.
    /// ໃນກໍລະນີໃນອະດີດ, ທ່ານຕ້ອງລະມັດລະວັງ.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// ໄດ້ຮັບຄວາມສາມາດໃນການຈັດສັນ.
    ///
    /// ສິ່ງນີ້ຈະເປັນ `usize::MAX` ສະເຫມີຖ້າ `T` ແມ່ນຂະ ໜາດ ສູນ.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// ສົ່ງຄືນເອກະສານອ້າງອີງທີ່ແບ່ງປັນໃຫ້ຜູ້ຈັດສັນທີ່ສະ ໜັບ ສະ ໜູນ `RawVec` ນີ້.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // ພວກເຮົາມີຄວາມຊົງ ຈຳ ທີ່ຈັດສັນໄວ້, ດັ່ງນັ້ນພວກເຮົາສາມາດຂ້າມຜ່ານການກວດສອບໄລຍະເວລາເພື່ອໃຫ້ໄດ້ຮູບແບບປະຈຸບັນຂອງພວກເຮົາ.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// ຮັບປະກັນວ່າ buffer ມີຢ່າງ ໜ້ອຍ ພື້ນທີ່ພຽງພໍທີ່ຈະຖືອົງປະກອບ `len + additional`.
    /// ຖ້າມັນບໍ່ມີຄວາມສາມາດພຽງພໍ, ຈະຈັດສັນພື້ນທີ່ໃຫ້ພຽງພໍແລະບວກກັບສະຖານທີ່ທີ່ມີຄວາມສະດວກສະບາຍເພື່ອໃຫ້ໄດ້ຮັບການຫລຸດຜ່ອນການປະພຶດ *O*(1).
    ///
    /// ຈະ ຈຳ ກັດພຶດຕິ ກຳ ນີ້ຖ້າມັນອາດຈະເຮັດໃຫ້ຕົວເອງກັບ panic.
    ///
    /// ຖ້າ `len` ເກີນ `self.capacity()`, ນີ້ອາດຈະລົ້ມເຫລວໃນການຈັດສັນພື້ນທີ່ທີ່ຕ້ອງການ.
    /// ນີ້ບໍ່ແມ່ນຄວາມປອດໄພແທ້ໆ, ແຕ່ລະຫັດທີ່ບໍ່ປອດໄພ *ທ່ານ* ຂຽນທີ່ຂື້ນກັບພຶດຕິ ກຳ ຂອງ ໜ້າ ທີ່ນີ້ອາດຈະແຕກ.
    ///
    /// ນີ້ແມ່ນສິ່ງທີ່ ເໝາະ ສົມ ສຳ ລັບການຈັດຕັ້ງປະຕິບັດການຊຸກຍູ້ເປັນ ຈຳ ນວນຫຼາຍເຊັ່ນ `extend`.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຄວາມສາມາດໃຫມ່ເກີນ bytes `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// ສໍາເລັດໃນ OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // ການສະຫງວນຈະໄດ້ຮັບການຍົກເລີກຫຼືຕົກຕະລຶງຖ້າວ່າ len ເກີນ `isize::MAX` ສະນັ້ນມັນປອດໄພທີ່ຈະເຮັດການກວດສອບຕອນນີ້.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// ດຽວກັນກັບ `reserve`, ແຕ່ກັບຄືນມາກ່ຽວກັບຂໍ້ຜິດພາດແທນທີ່ຈະເຮັດໃຫ້ເກີດຄວາມວຸ້ນວາຍຫຼືການເອົາລູກອອກ.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// ຮັບປະກັນວ່າ buffer ມີຢ່າງ ໜ້ອຍ ພື້ນທີ່ພຽງພໍທີ່ຈະຖືອົງປະກອບ `len + additional`.
    /// ຖ້າມັນຍັງບໍ່ແລ້ວ, ຈະຈັດ ຈຳ ນວນ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ ໜ້ອຍ ທີ່ສຸດທີ່ ຈຳ ເປັນ.
    /// ໂດຍທົ່ວໄປແລ້ວນີ້ຈະເປັນ ຈຳ ນວນ ຈຳ ນວນທີ່ ຈຳ ເປັນ, ແຕ່ຕາມຫຼັກການແລ້ວຜູ້ຈັດສັນແມ່ນໃຫ້ໂດຍບໍ່ເສຍຄ່າຫຼາຍກວ່າທີ່ພວກເຮົາຮ້ອງຂໍ.
    ///
    ///
    /// ຖ້າ `len` ເກີນ `self.capacity()`, ນີ້ອາດຈະລົ້ມເຫລວໃນການຈັດສັນພື້ນທີ່ທີ່ຕ້ອງການ.
    /// ນີ້ບໍ່ແມ່ນຄວາມປອດໄພແທ້ໆ, ແຕ່ລະຫັດທີ່ບໍ່ປອດໄພ *ທ່ານ* ຂຽນທີ່ຂື້ນກັບພຶດຕິ ກຳ ຂອງ ໜ້າ ທີ່ນີ້ອາດຈະແຕກ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຄວາມສາມາດໃຫມ່ເກີນ bytes `isize::MAX`.
    ///
    /// # Aborts
    ///
    /// ສໍາເລັດໃນ OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// ດຽວກັນກັບ `reserve_exact`, ແຕ່ກັບຄືນມາກ່ຽວກັບຂໍ້ຜິດພາດແທນທີ່ຈະເຮັດໃຫ້ເກີດຄວາມວຸ້ນວາຍຫຼືການເອົາລູກອອກ.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// ຫຼຸດຜ່ອນການຈັດສັນລົງໃຫ້ເປັນ ຈຳ ນວນທີ່ລະບຸໄວ້.
    /// ຖ້າ ຈຳ ນວນເງິນທີ່ໃຫ້ໄວ້ແມ່ນ 0, ຕົວຈິງແມ່ນຈັດການ ໝົດ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ ຈຳ ນວນທີ່ໄດ້ຮັບແມ່ນ *ໃຫຍ່ກວ່າ* ທຽບໃສ່ຄວາມຈຸໃນປະຈຸບັນ.
    ///
    /// # Aborts
    ///
    /// ສໍາເລັດໃນ OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// ກັບຄືນຖ້າ buffer ຕ້ອງການຈະເລີນເຕີບໂຕເພື່ອຕອບສະ ໜອງ ຄວາມສາມາດພິເສດທີ່ ຈຳ ເປັນ.
    /// ສ່ວນໃຫຍ່ແມ່ນໃຊ້ໃນການໂທສາຍສະຫງວນທີ່ເປັນໄປໄດ້ໂດຍບໍ່ຕ້ອງໃສ່ `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // ວິທີນີ້ມັກຈະຖືກ ນຳ ໃຊ້ຫຼາຍຄັ້ງ.ສະນັ້ນພວກເຮົາຕ້ອງການໃຫ້ມັນມີຂະ ໜາດ ນ້ອຍເທົ່າທີ່ຈະເປັນໄປໄດ້, ເພື່ອປັບປຸງເວລາລວບລວມ.
    // ແຕ່ພວກເຮົາຍັງຕ້ອງການໃຫ້ເນື້ອໃນຂອງມັນມີຂະ ໜາດ ໃຫຍ່ເທົ່າທີ່ເປັນໄປໄດ້, ເພື່ອເຮັດໃຫ້ລະຫັດທີ່ຜະລິດອອກໄວຂື້ນ.
    // ເພາະສະນັ້ນ, ວິທີການນີ້ແມ່ນລາຍລັກອັກສອນຢ່າງລະອຽດດັ່ງນັ້ນທັງຫມົດຂອງລະຫັດທີ່ຂຶ້ນກັບ `T` ຢູ່ພາຍໃນມັນ, ໃນຂະນະທີ່ເປັນຫຼາຍຂອງຂໍ້ກໍານົດທີ່ບໍ່ຂຶ້ນກັບ `T` ເປັນໄປໄດ້ແມ່ນຢູ່ໃນປະຕິບັດຫນ້າທີ່ທີ່ບໍ່ແມ່ນ generic ໃນໄລຍະ `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // ນີ້ໄດ້ຖືກຮັບປະກັນໂດຍສະພາບການໂທ.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // ນັບຕັ້ງແຕ່ພວກເຮົາສົ່ງຄືນຄວາມສາມາດຂອງ `usize::MAX` ເມື່ອ `elem_size` ແມ່ນ
            // 0, ການມາເຖິງນີ້ແມ່ນ ໝາຍ ຄວາມວ່າ `RawVec` ແມ່ນເກີນ ກຳ ນົດ.
            return Err(CapacityOverflow);
        }

        // ບໍ່ມີຫຍັງທີ່ພວກເຮົາສາມາດເຮັດໄດ້ຢ່າງແທ້ຈິງກ່ຽວກັບການກວດສອບເຫຼົ່ານີ້, ໜ້າ ເສຍໃຈ.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // ນີ້ຮັບປະກັນການຂະຫຍາຍຕົວທີ່ບໍ່ມີຕົວຕົນ.
        // ການເພີ່ມຂື້ນສອງເທົ່າບໍ່ສາມາດລົ້ນໄດ້ເພາະ `cap <= isize::MAX` ແລະ `cap` ແມ່ນ `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ແມ່ນບໍ່ທົ່ວໄປທົ່ວ `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // ຂໍ້ ຈຳ ກັດໃນວິທີການນີ້ແມ່ນເທົ່າກັບຫຼາຍຢ່າງທີ່ມີຢູ່ໃນ `grow_amortized`, ແຕ່ວິທີການນີ້ມັກຈະຖືກກະຕຸ້ນໄວຂື້ນເລື້ອຍໆສະນັ້ນມັນຈຶ່ງມີຄວາມ ສຳ ຄັນ ໜ້ອຍ.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // ນັບຕັ້ງແຕ່ພວກເຮົາສົ່ງຄືນຄວາມສາມາດຂອງ `usize::MAX` ເມື່ອຂະ ໜາດ ຂອງປະເພດ
            // 0, ການມາເຖິງນີ້ແມ່ນ ໝາຍ ຄວາມວ່າ `RawVec` ແມ່ນເກີນ ກຳ ນົດ.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ແມ່ນບໍ່ທົ່ວໄປທົ່ວ `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// ຟັງຊັນນີ້ຢູ່ນອກ `RawVec` ເພື່ອຫຼຸດຜ່ອນເວລາທີ່ລວບລວມ.ເບິ່ງ ຄຳ ເຫັນຂ້າງເທິງ `RawVec::grow_amortized` ສຳ ລັບລາຍລະອຽດ.
// (ຕົວກໍານົດການ `A` ແມ່ນບໍ່ສໍາຄັນ, ເພາະວ່າຈໍານວນ `A` ປະເພດທີ່ແຕກຕ່າງກັນທີ່ເຫັນໃນການປະຕິບັດແມ່ນມີຂະຫນາດນ້ອຍກວ່າຈໍານວນ `T` ປະເພດ.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // ກວດເບິ່ງຂໍ້ຜິດພາດທີ່ນີ້ເພື່ອຫຼຸດຂະ ໜາດ ຂອງ `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // ຜູ້ຈັດສັນກວດສອບຄວາມສະ ເໝີ ພາບສອດຄ່ອງ
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// ຍິນດີກັບຄວາມຊົງ ຈຳ ທີ່ເປັນເຈົ້າຂອງໂດຍ `RawVec` * ໂດຍບໍ່ຕ້ອງພະຍາຍາມລຸດເນື້ອຫາຂອງມັນ.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// ໜ້າ ທີ່ກາງ ສຳ ລັບການຈັດການກັບຂໍ້ຜິດພາດ ສຳ ຮອງ.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// ພວກເຮົາຕ້ອງຮັບປະກັນດັ່ງຕໍ່ໄປນີ້:
// * ພວກເຮົາບໍ່ເຄີຍຈັດສັນວັດຖຸທີ່ມີຂະ ໜາດ `> isize::MAX`.
// * ພວກເຮົາບໍ່ເກີນ `usize::MAX` ແລະຕົວຈິງແລ້ວຈັດສັນ ໜ້ອຍ ເກີນໄປ.
//
// ກ່ຽວກັບ 64 ບິດ, ພວກເຮົາພຽງແຕ່ຕ້ອງການກວດສອບການໄຫຼເກີນຍ້ອນວ່າພະຍາຍາມຈັດສັນ `> isize::MAX` bytes ແນ່ນອນຈະລົ້ມເຫລວ.
// 32-bit ແລະ 16-bit ພວກເຮົາ ຈຳ ເປັນຕ້ອງເພີ່ມກອງພິເສດ ສຳ ລັບເລື່ອງນີ້ໃນກໍລະນີທີ່ພວກເຮົາ ກຳ ລັງແລ່ນເທິງເວທີເຊິ່ງສາມາດ ນຳ ໃຊ້ 4GB ທັງ ໝົດ ໃນພື້ນທີ່ຂອງຜູ້ໃຊ້, ເຊັ່ນ: PAE ຫຼື x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// ໜ້າ ທີ່ ໜຶ່ງ ທີ່ຮັບຜິດຊອບໃນການລາຍງານຄວາມສາມາດເກີນ ກຳ ນົດ.
// ນີ້ຈະຮັບປະກັນວ່າການສ້າງລະຫັດທີ່ກ່ຽວຂ້ອງກັບ panics ເຫຼົ່ານີ້ແມ່ນມີ ໜ້ອຍ ທີ່ສຸດເພາະວ່າມີສະຖານທີ່ດຽວເທົ່ານັ້ນທີ່ panics ແທນທີ່ຈະເປັນຊໍ່ທົ່ວໂມດູນ.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}