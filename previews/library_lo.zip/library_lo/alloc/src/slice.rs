//! ມຸມມອງທີ່ມີຂະ ໜາດ ແບບເຄື່ອນໄຫວເປັນ ລຳ ດັບ, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! ແຜ່ນສະໄລ້ແມ່ນມຸມມອງເຂົ້າໄປໃນທ່ອນໄມ້ຂອງຄວາມຊົງ ຈຳ ທີ່ສະແດງເປັນຕົວຊີ້ແລະຄວາມຍາວ.
//!
//! ```
//! // sling Vec ໄດ້
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // ບັງຄັບຂບວນໃຫ້ເປັນທ່ອນໆ
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! ແຜ່ນບາງສ່ວນທີ່ສາມາດແລກປ່ຽນກັນໄດ້ຫຼືແບ່ງປັນກັນ.
//! ປະເພດການແບ່ງປັນແມ່ນ `&[T]`, ໃນຂະນະທີ່ປະເພດການແບ່ງປັນທີ່ປ່ຽນແປງໄດ້ແມ່ນ `&mut [T]`, ເຊິ່ງ `T` ເປັນຕົວແທນຂອງປະເພດທາດ.
//! ຍົກຕົວຢ່າງ, ທ່ານສາມາດຫັນປ່ຽນທ່ອນໄມ້ຂອງຄວາມຊົງ ຈຳ ທີ່ການແບ່ງປັນທີ່ປ່ຽນແປງໄດ້ຊີ້ໄປທີ່:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! ຕໍ່ໄປນີ້ແມ່ນບາງສ່ວນຂອງສິ່ງທີ່ໂມດູນນີ້ປະກອບດ້ວຍ:
//!
//! ## Structs
//!
//! ມີຫລາຍໂຄງສ້າງທີ່ເປັນປະໂຫຍດ ສຳ ລັບຊິ້ນ, ເຊັ່ນ [`Iter`], ເຊິ່ງເປັນຕົວແທນຂອງຄວາມຊື້ນ້ ຳ ລື່ນ.
//!
//! ## ການປະຕິບັດ Trait
//!
//! ມີຫຼາຍການປະຕິບັດຂອງທົ່ວໄປ traits ສໍາລັບຫຼັງຈາກນັ້ນນໍາແມ່ນ.ຕົວຢ່າງບາງປະກອບມີ:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], ສຳ ລັບຊິ້ນທີ່ປະເພດຂອງມັນແມ່ນ [`Eq`] ຫຼື [`Ord`].
//! * [`Hash`] - ສຳ ລັບຊິ້ນທີ່ອົງປະກອບແມ່ນ [`Hash`].
//!
//! ## Iteration
//!
//! The slices ປະຕິບັດ `IntoIterator`.ຕົວຊີ້ວັດເຮັດໃຫ້ມີການອ້າງອີງເຖິງສ່ວນປະກອບຕ່າງໆ.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! ສ່ວນທີ່ມີການປ່ຽນແປງໄດ້ໃຫ້ຜົນຜະລິດອ້າງອີງທີ່ສາມາດປ່ຽນແປງໄດ້:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! ຕົວຊີ້ວັດນີ້ໃຫ້ຜົນຜະລິດອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບສ່ວນປະກອບຂອງແຜ່ນ, ດັ່ງນັ້ນໃນຂະນະທີ່ປະເພດຂອງສ່ວນປະກອບຂອງແຜ່ນແມ່ນ `i32`, ປະເພດອົງປະກອບຂອງໂຕປັບແມ່ນ `&mut i32`.
//!
//!
//! * [`.iter`] ແລະ [`.iter_mut`] ແມ່ນວິທີການທີ່ຈະແຈ້ງເພື່ອກັບຄືນຄ່າປັບ ໃໝ່.
//! * ວິທີການຕໍ່ໄປທີ່ສົ່ງຄືນເຄື່ອງ ໝາຍ ສົ່ງຄືນແມ່ນ [`.split`], [`.splitn`], [`.chunks`], [`.windows`] ແລະອື່ນໆ.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// ຈໍານວນຫຼາຍຂອງ usings ໃນໂມດູນນີ້ໄດ້ຖືກນໍາໃຊ້ພຽງແຕ່ໃນການຕັ້ງຄ່າການທົດສອບໄດ້.
// ມັນເຮັດຄວາມສະອາດໃຫ້ພຽງແຕ່ປິດການເຕືອນໄພທີ່ບໍ່ໄດ້ ນຳ ໃຊ້ເປັນການແກ້ໄຂຫຼາຍກວ່າການແກ້ໄຂ.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// ວິທີການຂະຫຍາຍຫຼັງຈາກນັ້ນນໍາ Basic
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) ຕ້ອງການ ສຳ ລັບການຈັດຕັ້ງປະຕິບັດມະຫາພາກ `vec!` ໃນລະຫວ່າງການທົດສອບ NB, ເບິ່ງເອກະສານ `hack` ໃນເອກະສານນີ້ ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) ຕ້ອງການ ສຳ ລັບການຈັດຕັ້ງປະຕິບັດ `Vec::clone` ໃນລະຫວ່າງການທົດສອບ NB, ເບິ່ງເອກະສານ `hack` ໃນເອກະສານນີ້ ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): ດ້ວຍ cfg(test) `impl [T]` ບໍ່ສາມາດໃຊ້ໄດ້, ສາມ ໜ້າ ທີ່ນີ້ແມ່ນວິທີການທີ່ມີຢູ່ໃນ `impl [T]` ແຕ່ບໍ່ແມ່ນໃນ `core::slice::SliceExt`, ພວກເຮົາ ຈຳ ເປັນຕ້ອງສະ ໜອງ ບັນດາ ໜ້າ ທີ່ເຫລົ່ານີ້ ສຳ ລັບການທົດສອບ `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // ພວກເຮົາບໍ່ຄວນເພີ່ມຄຸນລັກສະນະເສັ້ນໃນນີ້ເພາະວ່າມັນຖືກ ນຳ ໃຊ້ໃນ `vec!` ມະຫາພາກສ່ວນໃຫຍ່ແລະເປັນສາເຫດຂອງການຕົກທີ່ດີເລີດ.
    // ເບິ່ງ #71204 ສຳ ລັບການສົນທະນາແລະຜົນໄດ້ຮັບທີ່ດີເລີດ.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // ບັນດາລາຍການໄດ້ຖືກ ໝາຍ ໄວ້ໃນວົງຈອນຂ້າງລຸ່ມ
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ແມ່ນມີຄວາມ ຈຳ ເປັນ ສຳ ລັບ LLVM ທີ່ຈະ ກຳ ຈັດການກວດກາຂໍ້ຜູກມັດແລະມີ codegen ດີກ່ວາ zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec ໄດ້ຖືກຈັດສັນແລະເລີ່ມຕົ້ນຢູ່ຂ້າງເທິງຢ່າງຫນ້ອຍຄວາມຍາວນີ້.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // ການຈັດສັນເທິງທີ່ມີຄວາມຈຸ `s`, ແລະເລີ່ມຕົ້ນທີ່ຈະ `s.len()` ໃນ ptr::copy_to_non_overlapping ຕ່ໍາກວ່າ.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// ຈັດຮຽງຕາມ ລຳ ດັບ.
    ///
    /// ການຈັດລຽງແບບນີ້ແມ່ນມີຄວາມ ໝັ້ນ ຄົງ (ໝາຍ ຄວາມວ່າບໍ່ໄດ້ຈັດຮຽງອົງປະກອບທີ່ເທົ່າທຽມກັນ) ແລະ *O*(*n*\*log(* n*)) ທີ່ບໍ່ດີທີ່ສຸດ).
    ///
    /// ເມື່ອ ນຳ ໃຊ້ໄດ້, ການຈັດຮຽງທີ່ບໍ່ ໝັ້ນ ຄົງແມ່ນມັກເພາະວ່າໂດຍທົ່ວໄປມັນໄວກວ່າການຈັດລຽງແບບຄົງທີ່ແລະມັນບໍ່ໄດ້ຈັດສັນຄວາມ ຈຳ ຊ່ວຍ.
    /// ເບິ່ງ [`sort_unstable`](slice::sort_unstable).
    ///
    /// # ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນ
    ///
    /// ສູດການຄິດໄລ່ໃນປະຈຸບັນແມ່ນການປັບຕົວເຂົ້າກັນແລະການຮວບຮວມຜົນກະທົບທີ່ໄດ້ຮັບແຮງບັນດານໃຈຈາກ [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// ມັນໄດ້ຖືກອອກແບບທີ່ຈະຫຼາຍໄວໃນກໍລະນີທີ່ຫຼັງຈາກນັ້ນນໍາໄດ້ຖືກຈັດຮຽງເກືອບຫລືປະກອບດ້ວຍສອງຫຼືລໍາດັບຮຽງຫຼາຍ concatenated ຫນຶ່ງຫຼັງຈາກທີ່ອື່ນ.
    ///
    ///
    /// ພ້ອມກັນນີ້, ມັນຈັດສັນການຈັດເກັບຊົ່ວຄາວເຄິ່ງ ໜຶ່ງ ຂອງຂະ ໜາດ ຂອງ `self`, ແຕ່ ສຳ ລັບຊິ້ນສ່ວນສັ້ນການຈັດລຽງບ່ອນທີ່ບໍ່ມີການຈັດສັນຖືກ ນຳ ໃຊ້ແທນ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// ຈັດຮຽງສ່ວນປະກອບທີ່ມີ ໜ້າ ທີ່ປຽບທຽບ.
    ///
    /// ການຈັດລຽງແບບນີ້ແມ່ນມີຄວາມ ໝັ້ນ ຄົງ (ໝາຍ ຄວາມວ່າບໍ່ໄດ້ຈັດຮຽງອົງປະກອບທີ່ເທົ່າທຽມກັນ) ແລະ *O*(*n*\*log(* n*)) ທີ່ບໍ່ດີທີ່ສຸດ).
    ///
    /// ຟັງຊັນການປຽບທຽບຕ້ອງ ກຳ ນົດການຈັດລຽງ ລຳ ດັບທັງ ໝົດ ສຳ ລັບອົງປະກອບທີ່ຢູ່ໃນສ່ວນຕ່າງໆ.ຖ້າການຈັດລຽງ ລຳ ດັບບໍ່ຄົບຖ້ວນ, ຄຳ ສັ່ງຂອງອົງປະກອບຕ່າງໆແມ່ນບໍ່ໄດ້ລະບຸ.
    /// ຄຳ ສັ່ງແມ່ນ ຄຳ ສັ່ງທັງ ໝົດ ຖ້າມັນແມ່ນ (ສຳ ລັບ `a`, `b` ແລະ `c`):
    ///
    /// * total ແລະ antisymmetric: ແມ່ນ ໜຶ່ງ ໃນ `a < b`, `a == b` ຫຼື `a > b` ແມ່ນຄວາມຈິງ, ແລະ
    /// * transitive, `a < b` ແລະ `b < c` ໝາຍ ຄວາມວ່າ `a < c`.ດຽວກັນຕ້ອງຖື ສຳ ລັບທັງ `==` ແລະ `>`.
    ///
    /// ຍົກຕົວຢ່າງ, ໃນຂະນະທີ່ [`f64`] ບໍ່ໄດ້ປະຕິບັດ [`Ord`] ເພາະວ່າ `NaN != NaN`, ພວກເຮົາສາມາດໃຊ້ `partial_cmp` ເປັນ ໜ້າ ທີ່ຈັດລຽງ ລຳ ດັບຂອງພວກເຮົາເມື່ອພວກເຮົາຮູ້ວ່າຊິ້ນສ່ວນບໍ່ມີ `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// ເມື່ອ ນຳ ໃຊ້ໄດ້, ການຈັດຮຽງທີ່ບໍ່ ໝັ້ນ ຄົງແມ່ນມັກເພາະວ່າໂດຍທົ່ວໄປມັນໄວກວ່າການຈັດລຽງແບບຄົງທີ່ແລະມັນບໍ່ໄດ້ຈັດສັນຄວາມ ຈຳ ຊ່ວຍ.
    /// ເບິ່ງ [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນ
    ///
    /// ສູດການຄິດໄລ່ໃນປະຈຸບັນແມ່ນການປັບຕົວເຂົ້າກັນແລະການຮວບຮວມຜົນກະທົບທີ່ໄດ້ຮັບແຮງບັນດານໃຈຈາກ [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// ມັນໄດ້ຖືກອອກແບບທີ່ຈະຫຼາຍໄວໃນກໍລະນີທີ່ຫຼັງຈາກນັ້ນນໍາໄດ້ຖືກຈັດຮຽງເກືອບຫລືປະກອບດ້ວຍສອງຫຼືລໍາດັບຮຽງຫຼາຍ concatenated ຫນຶ່ງຫຼັງຈາກທີ່ອື່ນ.
    ///
    /// ພ້ອມກັນນີ້, ມັນຈັດສັນການຈັດເກັບຊົ່ວຄາວເຄິ່ງ ໜຶ່ງ ຂອງຂະ ໜາດ ຂອງ `self`, ແຕ່ ສຳ ລັບຊິ້ນສ່ວນສັ້ນການຈັດລຽງບ່ອນທີ່ບໍ່ມີການຈັດສັນຖືກ ນຳ ໃຊ້ແທນ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ຄັດກັບຄືນ
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// ຈັດຮຽງສ່ວນປະກອບທີ່ມີຫນ້າທີ່ສະກັດເອົາທີ່ສໍາຄັນ.
    ///
    /// ການຈັດລຽງແບບນີ້ແມ່ນມີຄວາມ ໝັ້ນ ຄົງ (ໝາຍ ຄວາມວ່າບໍ່ໄດ້ຈັດລຽງອົງປະກອບທີ່ເທົ່າທຽມກັນ) ແລະ *O*(*m*\* * n *\* log(*n*)) ຮ້າຍແຮງທີ່ສຸດ, ບ່ອນທີ່ ໜ້າ ທີ່ ສຳ ຄັນແມ່ນ *O*(*m*).
    ///
    /// ສຳ ລັບ ໜ້າ ທີ່ ສຳ ຄັນລາຄາແພງ (ຕົວຢ່າງ
    /// ຟັງຊັນທີ່ບໍ່ແມ່ນການເຂົ້າເຖິງຊັບສິນງ່າຍໆຫລືການ ດຳ ເນີນງານຂັ້ນພື້ນຖານ), [`sort_by_cached_key`](slice::sort_by_cached_key) ມີແນວໂນ້ມທີ່ຈະໄວຂື້ນຢ່າງຫຼວງຫຼາຍ, ຍ້ອນວ່າມັນບໍ່ໄດ້ແນະ ນຳ ໃຫ້ໃຊ້ຄີ.
    ///
    ///
    /// ເມື່ອ ນຳ ໃຊ້ໄດ້, ການຈັດຮຽງທີ່ບໍ່ ໝັ້ນ ຄົງແມ່ນມັກເພາະວ່າໂດຍທົ່ວໄປມັນໄວກວ່າການຈັດລຽງແບບຄົງທີ່ແລະມັນບໍ່ໄດ້ຈັດສັນຄວາມ ຈຳ ຊ່ວຍ.
    /// ເບິ່ງ [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນ
    ///
    /// ສູດການຄິດໄລ່ໃນປະຈຸບັນແມ່ນການປັບຕົວເຂົ້າກັນແລະການຮວບຮວມຜົນກະທົບທີ່ໄດ້ຮັບແຮງບັນດານໃຈຈາກ [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// ມັນໄດ້ຖືກອອກແບບທີ່ຈະຫຼາຍໄວໃນກໍລະນີທີ່ຫຼັງຈາກນັ້ນນໍາໄດ້ຖືກຈັດຮຽງເກືອບຫລືປະກອບດ້ວຍສອງຫຼືລໍາດັບຮຽງຫຼາຍ concatenated ຫນຶ່ງຫຼັງຈາກທີ່ອື່ນ.
    ///
    /// ພ້ອມກັນນີ້, ມັນຈັດສັນການຈັດເກັບຊົ່ວຄາວເຄິ່ງ ໜຶ່ງ ຂອງຂະ ໜາດ ຂອງ `self`, ແຕ່ ສຳ ລັບຊິ້ນສ່ວນສັ້ນການຈັດລຽງບ່ອນທີ່ບໍ່ມີການຈັດສັນຖືກ ນຳ ໃຊ້ແທນ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// ຈັດຮຽງສ່ວນປະກອບທີ່ມີຫນ້າທີ່ສະກັດເອົາທີ່ສໍາຄັນ.
    ///
    /// ໃນລະຫວ່າງການຄັດເລືອກ, ການທໍາງານຂອງທີ່ສໍາຄັນຖືກເອີ້ນວ່າພຽງແຕ່ຄັ້ງດຽວຕໍ່ອົງປະກອບ.
    ///
    /// ການຈັດລຽງແບບນີ້ແມ່ນມີຄວາມ ໝັ້ນ ຄົງ (ໝາຍ ຄວາມວ່າບໍ່ໄດ້ຈັດລຽງອົງປະກອບທີ່ເທົ່າທຽມກັນ) ແລະ *O*(*m*\* * n *+* n *\* log(*n*)) ຮ້າຍແຮງທີ່ສຸດ, ບ່ອນທີ່ ໜ້າ ທີ່ ສຳ ຄັນແມ່ນ *O*(*m*) .
    ///
    /// ສຳ ລັບຟັງຊັນທີ່ ສຳ ຄັນງ່າຍໆ (ເຊັ່ນ: ໜ້າ ທີ່ການເຂົ້າເຖິງຊັບສິນຫລືການ ດຳ ເນີນງານຂັ້ນພື້ນຖານ), [`sort_by_key`](slice::sort_by_key) ມີແນວໂນ້ມທີ່ຈະໄວກວ່າ.
    ///
    /// # ການຈັດຕັ້ງປະຕິບັດໃນປະຈຸບັນ
    ///
    /// ສູດການຄິດໄລ່ໃນປະຈຸບັນແມ່ນອີງໃສ່ [pattern-defeating quicksort][pdqsort] ໂດຍ Orson Peters, ເຊິ່ງປະສົມປະສານກັບກໍລະນີສະເລ່ຍທີ່ລວດໄວຂອງແບບເລັ່ງດ່ວນແບບສຸ່ມພ້ອມກັບກໍລະນີທີ່ຮ້າຍແຮງທີ່ສຸດຂອງ heapsort, ໃນຂະນະທີ່ບັນລຸເວລາເສັ້ນໃນເສັ້ນທີ່ມີຮູບແບບບາງຢ່າງ.
    /// ມັນໃຊ້ບາງແບບແບບສຸ່ມເພື່ອຫລີກລ້ຽງບັນດາກໍລະນີທີ່ເສື່ອມໂຊມ, ແຕ່ວ່າມີ seed ທີ່ຄົງທີ່ເພື່ອໃຫ້ມີພຶດຕິ ກຳ ທີ່ ກຳ ນົດ.
    ///
    /// ໃນກໍລະນີທີ່ຮ້າຍແຮງທີ່ສຸດ, ສູດການຄິດໄລ່ຈັດການການເກັບຮັກສາຊົ່ວຄາວໃນ `Vec<(K, usize)>` ຄວາມຍາວຂອງການຕັດ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // ຜູ້ຊ່ວຍມະຫາພາກ ສຳ ລັບດັດສະນີ vector ຂອງພວກເຮົາໂດຍປະເພດທີ່ນ້ອຍທີ່ສຸດ, ເພື່ອຫຼຸດຜ່ອນການຈັດສັນ.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // ສ່ວນປະກອບຕ່າງໆຂອງ `indices` ແມ່ນມີເອກະລັກສະເພາະ, ຍ້ອນວ່າມັນຖືກດັດສະນີ, ດັ່ງນັ້ນການຈັດລຽງແບບໃດກໍ່ຈະ ໝັ້ນ ຄົງໂດຍອີງຕາມສ່ວນປະກອບເດີມ.
                // ພວກເຮົາໃຊ້ `sort_unstable` ຢູ່ທີ່ນີ້ເພາະມັນຕ້ອງການການຈັດສັນຄວາມ ຈຳ ໜ້ອຍ.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// ສໍາເນົາ `self` ໃນ `Vec` ໃຫມ່.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // ໃນທີ່ນີ້, `s` ແລະ `x` ສາມາດດັດແກ້ເອກະລາດ.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// ຄັດລອກ `self` ເຂົ້າ `Vec` ໃໝ່ ທີ່ມີຜູ້ຈັດສັນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // ໃນທີ່ນີ້, `s` ແລະ `x` ສາມາດດັດແກ້ເອກະລາດ.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, ເບິ່ງໂມດູນ `hack` ໃນເອກະສານນີ້ ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
        hack::to_vec(self, alloc)
    }

    /// ແປງ `self` ເຂົ້າໄປໃນ vector ໂດຍບໍ່ມີຂໍ້ມູນຫຼືການຈັດສັນ.
    ///
    /// ຜົນໄດ້ຮັບ vector ສາມາດປ່ຽນເປັນກ່ອງຜ່ານ `Vec<T>`ເປັນວິທີ `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ບໍ່ສາມາດໄດ້ຮັບການນໍາໃຊ້ອີກຕໍ່ໄປເນື່ອງຈາກວ່າມັນໄດ້ຮັບການປ່ຽນໃຈເຫລື້ອມໃສເຂົ້າໄປໃນ `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, ເບິ່ງໂມດູນ `hack` ໃນເອກະສານນີ້ ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
        hack::into_vec(self)
    }

    /// ສ້າງ vector ໂດຍການຊ້ ຳ ຊ້ ຳ `n` ເທື່ອ.
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ຈະ panic ຖ້າຄວາມສາມາດຈະລົ້ນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic ເມື່ອລົ້ນ:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // ຖ້າ `n` ໃຫຍ່ກວ່າສູນ, ມັນສາມາດແບ່ງອອກເປັນ `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` ແມ່ນຕົວເລກທີ່ເປັນຕົວແທນໂດຍ '1' ນ້ອຍທີ່ສຸດຂອງ `n`, ແລະ `rem` ແມ່ນສ່ວນທີ່ເຫຼືອຂອງ `n`.
        //
        //

        // ການໃຊ້ `Vec` ໃນການເຂົ້າເຖິງ `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` ການຄ້າງຫ້ອງທີ່ເຮັດໄດ້ໂດຍ `buf` `expn`-ເທົ່າຕົວ.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // ຖ້າ `m > 0`, ມີກໍາລັງທີ່ຍັງເຫຼືອ bits ຂຶ້ນກັບຊ້າຍ '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` ມີຄວາມສາມາດຂອງ `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) ການຄ້າງຫ້ອງທີ່ເຮັດໄດ້ໂດຍການຄັດລອກ ຄຳ ສັບ `rem` ຄັ້ງ ທຳ ອິດຈາກ `buf` ເອງ.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // ນີ້ບໍ່ແມ່ນການຊໍ້າຊ້ອນຕັ້ງແຕ່ `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` ເທົ່າກັບ `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// ແປ `T` ສ່ວນ ໜຶ່ງ ເປັນ `Self::Output` ມູນຄ່າດຽວ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// ແປ `T` ສ່ວນ ໜຶ່ງ ເປັນ `Self::Output` ມູນຄ່າດຽວ, ວາງແຍກຕ່າງຫາກລະຫວ່າງແຕ່ລະແຜ່ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// ແປ `T` ສ່ວນ ໜຶ່ງ ເປັນ `Self::Output` ມູນຄ່າດຽວ, ວາງແຍກຕ່າງຫາກລະຫວ່າງແຕ່ລະແຜ່ນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// ກັບຄືນ vector ບັນຈຸ ສຳ ເນົາຂອງແຜ່ນໃບນີ້ບ່ອນທີ່ແຕ່ລະແຜ່ນຈະຖືກ ໝາຍ ໃສ່ກັບ ASCII ໂຕໃຫຍ່ຂອງມັນທຽບເທົ່າ.
    ///
    ///
    /// ຕົວອັກສອນ ASCII 'a' ກັບ 'z' ແມ່ນ mapped ກັບ 'A' ກັບ 'Z', ແຕ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII ແມ່ນບໍ່ປ່ຽນແປງ.
    ///
    /// ເພື່ອຍົກສູງມູນຄ່າທີ່ຢູ່ໃນສະຖານທີ່, ໃຫ້ໃຊ້ [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// ກັບຄືນ vector ທີ່ບັນຈຸ ສຳ ເນົາຂອງແຜ່ນໃບນີ້ບ່ອນທີ່ແຕ່ລະແຜ່ນຈະຖືກແຕ້ມໃສ່ກັບໂຕເລກ ASCII ທີ່ນ້ອຍກວ່າ.
    ///
    ///
    /// ຕົວອັກສອນ ASCII 'A' ຫາ 'Z' ຖືກແຕ້ມໃສ່ 'a' ຫາ 'z', ແຕ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII ບໍ່ປ່ຽນແປງ.
    ///
    /// ເພື່ອເຮັດໃຫ້ຄຸນຄ່າໃນສະຖານທີ່ນ້ອຍລົງ, ໃຫ້ໃຊ້ [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// ການຂະຫຍາຍ traits ສຳ ລັບຕັດຂໍ້ມູນປະເພດຕ່າງໆ
////////////////////////////////////////////////////////////////////////////////

/// Helper trait ສຳ ລັບ [`[T]: : concat`](slice::concat).
///
/// Note: ຕົວກໍານົດການປະເພດ `Item` ບໍ່ໄດ້ຖືກນໍາໃຊ້ໃນ trait ນີ້, ແຕ່ມັນອະນຸຍາດໃຫ້ມີຄວາມສັບສົນຫຼາຍ.
/// ຖ້າບໍ່ມີມັນ, ພວກເຮົາຈະໄດ້ຮັບຂໍ້ຜິດພາດນີ້:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// ນີ້ແມ່ນຍ້ອນວ່າມັນສາມາດມີ `V` ຊະນິດທີ່ມີ `Borrow<[_]>` ຫຼາຍ, ເຊິ່ງວ່າ `T` ຫຼາຍປະເພດຈະ ນຳ ໃຊ້:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// ປະເພດຜົນໄດ້ຮັບຫຼັງຈາກ concatenation
    type Output;

    /// ການດໍາເນີນການ [`[T]: : concat`](ຫຼັງຈາກນັ້ນນໍາ::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait ສຳ ລັບ [`[T]: : join`](ຊິ້ນ::ເຂົ້າຮ່ວມ)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// ປະເພດຜົນໄດ້ຮັບຫຼັງຈາກ concatenation
    type Output;

    /// ການຈັດຕັ້ງປະຕິບັດຂອງ [`[T]: : join`](slice::ເຂົ້າຮ່ວມ)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// ການປະຕິບັດມາດຕະຖານ trait ສຳ ລັບຊິ້ນ
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // ຖິ້ມສິ່ງໃດສິ່ງ ໜຶ່ງ ໃນເປົ້າ ໝາຍ ທີ່ຈະບໍ່ຖືກຂຽນທັບ
        target.truncate(self.len());

        // target.len <= self.len ເນື່ອງຈາກຕັດຢູ່ຂ້າງເທິງ, ສະນັ້ນສ່ວນທີ່ເຫຼືອຢູ່ບ່ອນນີ້ແມ່ນມີຂອບເຂດສະ ເໝີ.
        //
        let (init, tail) = self.split_at(target.len());

        // ໃຊ້ຄືນຄ່າທີ່ມີ allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// ໃສ່ `v[0]` ເຂົ້າໃນ `v[1..]` ລຳ ດັບທີ່ຈັດໄວ້ກ່ອນເພື່ອໃຫ້ `v[..]` ທັງ ໝົດ ກາຍເປັນການຈັດຮຽງ.
///
/// ນີ້ແມ່ນ subroutine ສຳ ຄັນຂອງການຈັດລຽງການແຊກ.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // ມີສາມວິທີໃນການປະຕິບັດການແຊກບ່ອນນີ້:
            //
            // 1. ແລກປ່ຽນສ່ວນປະກອບທີ່ຢູ່ຕິດກັນຈົນກວ່າຄົນ ທຳ ອິດຈະໄປຮອດຈຸດ ໝາຍ ປາຍທາງສຸດທ້າຍຂອງມັນ.
            //    ເຖິງຢ່າງໃດກໍ່ຕາມ, ວິທີນີ້ພວກເຮົາຄັດລອກຂໍ້ມູນປະມານຫຼາຍກວ່າທີ່ ຈຳ ເປັນ.
            //    ຖ້າອົງປະກອບຕ່າງໆແມ່ນໂຄງສ້າງໃຫຍ່ (ມີຄ່າໃຊ້ຈ່າຍໃນການ ສຳ ເນົາ), ວິທີການນີ້ຈະຊ້າ.
            //
            // 2. Iterate ຈົນກ່ວາສະຖານທີ່ທີ່ເຫມາະສົມສໍາລັບອົງປະກອບທໍາອິດທີ່ພົບ.
            // ຫຼັງຈາກນັ້ນ, ປ່ຽນອົງປະກອບທີ່ປະສົບຜົນ ສຳ ເລັດມາເຮັດໃຫ້ມັນເປັນບ່ອນຫວ່າງ ສຳ ລັບມັນແລະສຸດທ້າຍກໍ່ເອົາລົງໃນຂຸມທີ່ຍັງເຫຼືອ.
            // ນີ້ແມ່ນວິທີການທີ່ດີ.
            //
            // 3. ຄັດລອກອົງປະກອບ ທຳ ອິດເຂົ້າໃນຕົວແປຊົ່ວຄາວ.ປະສົມຈົນກ່ວາສະຖານທີ່ທີ່ ເໝາະ ສົມ ສຳ ລັບມັນຖືກພົບເຫັນ.
            // ໃນຂະນະທີ່ພວກເຮົາເດີນທາງໄປ, ຄັດລອກທຸກໆສ່ວນທີ່ເຄື່ອນຍ້າຍເຂົ້າໄປໃນຊ່ອງກ່ອນທີ່ມັນຈະ.
            // ສຸດທ້າຍ, ຄັດລອກຂໍ້ມູນຈາກຕົວແປຊົ່ວຄາວລົງໃນຂຸມທີ່ຍັງເຫຼືອ.
            // ວິທີການນີ້ແມ່ນດີຫຼາຍ.
            // ມາດຕະຖານໄດ້ສະແດງໃຫ້ເຫັນເຖິງການປະຕິບັດທີ່ດີກວ່າເລັກນ້ອຍກ່ວາດ້ວຍວິທີທີ 2.
            //
            // ທຸກໆວິທີການໄດ້ຖືກຕີລາຄາ, ແລະທີ 3 ໄດ້ສະແດງໃຫ້ເຫັນຜົນໄດ້ຮັບທີ່ດີທີ່ສຸດ.ດັ່ງນັ້ນພວກເຮົາເລືອກທີ່ຫນຶ່ງ.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // ສະຖານະການປານກາງຂອງຂັ້ນຕອນການແຊກໄດ້ຖືກຕິດຕາມສະເຫມີໂດຍ `hole`, ເຊິ່ງໃຫ້ບໍລິການສອງຈຸດປະສົງ:
            // 1. ປົກປ້ອງຄວາມສົມບູນຂອງ `v` ຈາກ panics ໃນ `is_less`.
            // 2. ຕື່ມຂໍ້ມູນໃສ່ຂຸມທີ່ຍັງເຫຼືອໃນ `v` ໃນທີ່ສຸດ.
            //
            // ຄວາມປອດໄພຂອງ Panic:
            //
            // ຖ້າ `is_less` panics ໃນຈຸດໃດກໍ່ຕາມໃນລະຫວ່າງຂັ້ນຕອນ, `hole` ຈະຖືກລຸດລົງແລະຕື່ມຂໍ້ມູນໃສ່ຂຸມໃນ `v` ກັບ `tmp`, ດັ່ງນັ້ນການຮັບປະກັນວ່າ `v` ຍັງຄົງຖືວັດຖຸທຸກໆຢ່າງທີ່ມັນຈັດຂຶ້ນໃນເບື້ອງຕົ້ນຢ່າງແນ່ນອນ.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` ໄດ້ຮັບການຫຼຸດລົງແລະດັ່ງນັ້ນການຄັດລອກ `tmp` ເຂົ້າໄປໃນຂຸມທີ່ຍັງເຫຼືອໃນ `v`.
        }
    }

    // ເມື່ອຫຼຸດລົງ, ສຳ ເນົາຈາກ `src` ລົງເປັນ `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// ປະສົມປະສານການແລ່ນທີ່ບໍ່ຫຼຸດລົງ `v[..mid]` ແລະ `v[mid..]` ໂດຍໃຊ້ `buf` ເປັນບ່ອນເກັບຮັກສາຊົ່ວຄາວ, ແລະເກັບຂໍ້ມູນເຂົ້າໃນ `v[..]`.
///
/// # Safety
///
/// ທັງສອງແຜ່ນຕ້ອງບໍ່ແມ່ນເປົ່າແລະ `mid` ຕ້ອງຢູ່ໃນຂອບ.
/// Buffer `buf` ຕ້ອງມີຄວາມຍາວພໍທີ່ຈະຖື ສຳ ເນົາຂອງແຜ່ນທີ່ສັ້ນກວ່າ.
/// ເຊັ່ນດຽວກັນ, `T` ບໍ່ຕ້ອງເປັນປະເພດທີ່ມີຂະ ໜາດ ສູນ.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // ຂະບວນການໂຮມເຂົ້າກັນ ທຳ ອິດຈະແລ່ນສັ້ນເຂົ້າສູ່ `buf`.
    // ຫຼັງຈາກນັ້ນມັນກໍ່ຈະຕິດຕາມການແລ່ນທີ່ຖືກຄັດລອກ ໃໝ່ ແລະການແລ່ນທີ່ຍາວກວ່າໄປຂ້າງ ໜ້າ (ຫລືດ້ານຫຼັງ), ປຽບທຽບອົງປະກອບທີ່ບໍ່ໄດ້ລະບຸຕໍ່ໄປຂອງພວກມັນແລະຄັດລອກສິ່ງທີ່ນ້ອຍກວ່າ (ຫລືໃຫຍ່ກວ່າ) ໃສ່ `v`.
    //
    // ທັນທີທີ່ໄດ້ແລ່ນສັ້ນແມ່ນການບໍລິໂພກຢ່າງເຕັມສ່ວນ, ຂະບວນການແມ່ນການເຮັດ.ຖ້າການແລ່ນທີ່ຍາວກວ່າຈະໄດ້ຮັບການບໍລິໂພກກ່ອນ, ຫຼັງຈາກນັ້ນພວກເຮົາຕ້ອງຄັດລອກສິ່ງໃດທີ່ຍັງເຫຼືອຈາກການແລ່ນສັ້ນລົງໄປໃນຮູທີ່ຍັງເຫຼືອຢູ່ໃນ `v`.
    //
    // ສະພາບລະດັບປານກາງຂອງຂະບວນການແມ່ນຖືກຕິດຕາມສະ ເໝີ ໂດຍ `hole`, ເຊິ່ງເຮັດ ໜ້າ ທີ່ສອງຈຸດປະສົງ:
    // 1. ປົກປ້ອງຄວາມສົມບູນຂອງ `v` ຈາກ panics ໃນ `is_less`.
    // 2. ຕື່ມຂໍ້ມູນໃສ່ຂຸມທີ່ຍັງເຫຼືອໃນ `v` ຖ້າການແລ່ນທີ່ຍາວກວ່າຈະໄດ້ຮັບການບໍລິໂພກກ່ອນ.
    //
    // ຄວາມປອດໄພຂອງ Panic:
    //
    // ຖ້າ `is_less` panics ໃນຈຸດເວລາໃດກໍ່ຕາມໃນຂະບວນການ, `hole` ຈະຖືກລຸດລົງແລະຕື່ມຂໍ້ມູນໃສ່ຂຸມໃນ `v` ດ້ວຍຂອບເຂດທີ່ບໍ່ໄດ້ຮັບການພິຈາລະນາໃນ `buf`, ດັ່ງນັ້ນການຮັບປະກັນວ່າ `v` ຍັງຄົງຖືວັດຖຸທຸກໆຢ່າງທີ່ມັນຈັດຂຶ້ນໃນເບື້ອງຕົ້ນຢ່າງແນ່ນອນ.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // ການແລ່ນທາງຊ້າຍແມ່ນສັ້ນກວ່າ.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // ໃນເບື້ອງຕົ້ນ, ຕົວຊີ້ວັດເຫຼົ່ານີ້ຊີ້ໃຫ້ເຫັນເຖິງການເລີ່ມຕົ້ນຂອງອາຄານຂອງພວກເຂົາ.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // ບໍລິໂພກດ້ານທີ່ນ້ອຍກວ່າ.
            // ຖ້າເທົ່າກັນ, ມັກການແລ່ນຊ້າຍເພື່ອຮັກສາສະຖຽນລະພາບ.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // ການແລ່ນທີ່ຖືກຕ້ອງແມ່ນສັ້ນກວ່າ.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // ໃນເບື້ອງຕົ້ນ, ຕົວຊີ້ວັດເຫຼົ່ານີ້ຊີ້ໃຫ້ເຫັນຈຸດຈົບຂອງອາຄານຂອງພວກເຂົາ.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // ບໍລິໂພກຂ້າງຫຼາຍກວ່າເກົ່າ.
            // ຖ້າເທົ່າກັນ, ມັກການແລ່ນທີ່ຖືກຕ້ອງເພື່ອຮັກສາສະຖຽນລະພາບ.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // ສຸດທ້າຍ, `hole` ຖືກລຸດລົງ.
    // ຖ້າການແລ່ນສັ້ນໆບໍ່ໄດ້ຖືກບໍລິໂພກຢ່າງເຕັມສ່ວນ, ສິ່ງໃດທີ່ຍັງເຫຼືອຢູ່ໃນປັດຈຸບັນຈະຖືກຄັດລອກເຂົ້າໄປໃນຮູ `v` X.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // ເມື່ອຫຼຸດລົງ, ຄັດລອກຊ່ວງ `start..end` ລົງເປັນ `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ບໍ່ແມ່ນປະເພດທີ່ມີຂະ ໜາດ ສູນ, ດັ່ງນັ້ນມັນຈຶ່ງ ເໝາະ ສົມທີ່ຈະແບ່ງຕາມຂະ ໜາດ ຂອງມັນ.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// ການປະສົມປະສານແບບນີ້ເຮັດໃຫ້ບາງແນວຄວາມຄິດ (ແຕ່ບໍ່ແມ່ນທັງ ໝົດ) ຈາກ TimSort, ເຊິ່ງຖືກອະທິບາຍເປັນລາຍລະອຽດ [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// ການກໍານົດຂັ້ນຕອນວິທີຢ່າງເຂັ້ມງວດຫລາຍໄປຫານ້ອຍແລະບໍ່ແມ່ນຫລາຍໄປຫານ້ອຍຕິດຕໍ່ກັນ, ຊຶ່ງສາມາດເອີ້ນວ່າເນັ້ນທໍາມະຊາດ.ມີການແລ່ນທີ່ຍັງຄ້າງຢູ່ທີ່ຍັງບໍ່ໄດ້ຖືກລວມເຂົ້າກັນເທື່ອ.
/// ແຕ່ລະການແລ່ນທີ່ຫາກໍ່ພົບ ໃໝ່ ແມ່ນຖືກຍູ້ລົງເທິງຂັ້ນໄດ, ແລະຫຼັງຈາກນັ້ນ, ການແລ່ນທີ່ຕິດກັນບາງຄູ່ກໍ່ຖືກລວມເຂົ້າກັນຈົນກະທັ້ງສອງບ່ອນທີ່ພໍໃຈ:
///
/// 1. ສຳ ລັບທຸກໆ `i` ໃນ `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. ສຳ ລັບທຸກໆ `i` ໃນ `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// ການຄາຄົງຮັບປະກັນວ່າໃນເວລາເຮັດວຽກທັງຫມົດແມ່ນ *O*(*n*\*log(* n*)) ຮ້າຍແຮງທີ່ສຸດ, ກໍລະນີ.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ແຜ່ນບາງສ່ວນເຖິງຄວາມຍາວນີ້ໄດ້ຮັບການຈັດຮຽງໂດຍ ນຳ ໃຊ້ການຈັດລຽງຂອງບ່ອນໃສ່.
    const MAX_INSERTION: usize = 20;
    // ເນັ້ນສັ້ນຫຼາຍໄດ້ເດ່ອອກມານໍາໃຊ້ບ່ອນຄັດກັບ span ອົງປະກອບຫຼາຍຢ່າງຫນ້ອຍນີ້.
    const MIN_RUN: usize = 10;

    // ການຈັດປະເພດບໍ່ມີພຶດຕິ ກຳ ທີ່ມີຄວາມ ໝາຍ ກ່ຽວກັບປະເພດທີ່ມີຂະ ໜາດ ສູນ.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // ປ້າຍສັ້ນໆໄດ້ຮັບການຈັດລຽງຕາມສະຖານທີ່ໂດຍຜ່ານການຈັດລຽງບ່ອນໃສ່ເພື່ອຫລີກລ້ຽງການຈັດສັນ.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // ຈັດສັນຂໍ້ມູນບັຟເຟີເພື່ອໃຊ້ເປັນຄວາມ ຈຳ ທີ່ຂູດ.ພວກເຮົາຮັກສາຄວາມຍາວ 0 ດັ່ງນັ້ນພວກເຮົາສາມາດເກັບຮັກສາເນື້ອໃນຂອງ `v` ສຳ ເນົາໄວ້ຕື້ນໂດຍບໍ່ມີຄວາມສ່ຽງຕໍ່ກັບ dtors ທີ່ແລ່ນໃນ ສຳ ເນົາຖ້າ `is_less` panics.
    //
    // ໃນເວລາທີ່ລວມເອົາການຈັດລຽງ ລຳ ດັບສອງຢ່າງ, buffer ນີ້ຈະເກັບ ສຳ ເນົາຂອງການແລ່ນສັ້ນກວ່າເຊິ່ງມັນຈະມີຄວາມຍາວເກືອບທຸກຢ່າງທີ່ `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // ເພື່ອ ກຳ ນົດການແລ່ນທີ່ແລ່ນຕາມ ທຳ ມະຊາດໃນ `v`, ພວກເຮົາຫັນກັບມາທາງຫລັງ.
    // ນັ້ນອາດເບິ່ງຄືວ່າເປັນການຕັດສິນໃຈທີ່ແປກ, ແຕ່ພິຈາລະນາຄວາມຈິງທີ່ວ່າການໂຮມເຂົ້າກັນມັກຈະໄປໃນທິດທາງກົງກັນຂ້າມ (forwards).
    // ອີງຕາມເກນມາດຕະຖານ, ການໂຮມເຂົ້າກັນແມ່ນໄວກ່ວາການລວມຕົວຖອຍຫລັງ.
    // ເພື່ອສະຫລຸບ, ການ ກຳ ນົດການແລ່ນໂດຍການຫັນຫລັງກັບຄືນມາເຮັດໃຫ້ການປະຕິບັດງານດີຂື້ນ.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // ຊອກຫາການ ດຳ ເນີນງານແບບ ທຳ ມະຊາດຕໍ່ໄປ, ແລະປີ້ນກັບກັນຖ້າມັນລົງຢ່າງເຂັ້ມງວດ.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // ໃສ່ບາງອົງປະກອບເພີ່ມເຕີມເຂົ້າໃນການແລ່ນຖ້າມັນສັ້ນເກີນໄປ.
        // ການຈັດຮຽງການແຊກແມ່ນໄວກວ່າການຮວບຮວມເຂົ້າກັນໃນ ລຳ ດັບສັ້ນ, ສະນັ້ນສິ່ງນີ້ຈະຊ່ວຍປັບປຸງການປະຕິບັດໄດ້ດີຂື້ນ.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // ຍູ້ໄລຍະນີ້ໄປສູ່ຂັ້ນໄດ.
        runs.push(Run { start, len: end - start });
        end = start;

        // ສົມທົບບາງສາຍແລ່ນຕິດກັນເພື່ອຕອບສະ ໜອງ ສັດຕູ.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // ສຸດທ້າຍ, ແນ່ນອນການແລ່ນ ໜຶ່ງ ຕ້ອງຢູ່ໃນຂັ້ນໄດ.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // ວິເຄາະ stack ຂອງການເຮັດວຽກແລະລະບຸຄູ່ຕໍ່ໄປຂອງການເຮັດວຽກທີ່ຈະ merge ໄດ້.
    // ຫຼາຍໂດຍສະເພາະ, ຖ້າຫາກວ່າ `Some(r)` ຈະຖືກສົ່ງກັບນັ້ນຫມາຍຄວາມວ່າ `runs[r]` ແລະ `runs[r + 1]` ຕ້ອງໄດ້ຮັບການປະທານຕໍ່ໄປ.
    // ຖ້າສູດການຄິດໄລ່ຄວນສືບຕໍ່ສ້າງລະບົບ ໃໝ່ ແທນ, `None` ຈະຖືກສົ່ງຄືນ.
    //
    // TimSort ແມ່ນບໍ່ດີ ສຳ ລັບການຈັດຕັ້ງປະຕິບັດ buggy, ດັ່ງທີ່ໄດ້ອະທິບາຍຢູ່ນີ້:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // ຄວາມເປັນຈິງຂອງເລື່ອງແມ່ນ: ພວກເຮົາຕ້ອງໄດ້ບັງຄັບໃຊ້ການບຸກລຸກເທິງສີ່ແຖວເທິງທີ່ແລ່ນເທິງຂັ້ນໄດ.
    // ການບັງຄັບໃຫ້ພວກເຂົາຢູ່ເທິງພຽງສາມອັນດັບແມ່ນບໍ່ພຽງພໍເພື່ອຮັບປະກັນວ່າການບຸກລຸກຈະຍັງຄົງຢູ່ ສຳ ລັບ *ທັງ ໝົດ* ແລ່ນໃນຂັ້ນໄດ.
    //
    // ຟັງຊັນນີ້ຢ່າງຖືກຕ້ອງກວດສອບຄາຄົງສໍາລັບການເທິງສີ່ເນັ້ນ.
    // ນອກຈາກນັ້ນ, ຖ້າການແລ່ນສູງສຸດເລີ່ມຕົ້ນຈາກດັດຊະນີ 0, ມັນຈະຮຽກຮ້ອງໃຫ້ມີການປະຕິບັດງານລວມເຂົ້າກັນເລື້ອຍໆຈົນກ່ວາຂັ້ນໄດຖືກຍຸບລົງຢ່າງເຕັມທີ່, ເພື່ອເຮັດການຈັດຮຽງໃຫ້ສົມບູນ.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}