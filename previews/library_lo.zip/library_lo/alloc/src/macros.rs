/// ສ້າງ [`Vec`] ທີ່ມີຂໍ້ໂຕ້ແຍ້ງ.
///
/// `vec!` ອະນຸຍາດໃຫ້ `Vec`s ຖືກ ກຳ ນົດດ້ວຍໄວຍາກອນດຽວກັບການສະແດງອອກຂອງອາເລ.
/// ມະຫາພາກນີ້ມີສອງຮູບແບບ:
///
/// - ສ້າງ [`Vec`] ມີບັນຊີລາຍຊື່ຂອງອົງປະກອບ:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - ສ້າງ [`Vec`] ຈາກອົງປະກອບແລະຂະ ໜາດ ໃດ ໜຶ່ງ:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// ໃຫ້ສັງເກດວ່າບໍ່ຄືກັບການສະແດງອອກຂອງອາເລມ syntax ນີ້ສະ ໜັບ ສະ ໜູນ ອົງປະກອບທັງ ໝົດ ທີ່ປະຕິບັດ [`Clone`] ແລະ ຈຳ ນວນຂອງອົງປະກອບບໍ່ ຈຳ ເປັນຕ້ອງຄົງທີ່.
///
/// ນີ້ຈະໃຊ້ `clone` ເພື່ອເຮັດຊໍ້າກັບການສະແດງອອກ, ດັ່ງນັ້ນທ່ານຄວນລະມັດລະວັງໃນການ ນຳ ໃຊ້ແບບນີ້ກັບປະເພດທີ່ມີການປະຕິບັດ `Clone` ທີ່ບໍ່ໄດ້ມາດຕະຖານ.
/// ຕົວຢ່າງ, `vec![Rc::new(1);5] `ຈະສ້າງ vector ຂອງຫ້າເອກະສານອ້າງອີງໃສ່ມູນຄ່າເລກເຕັມກ່ອງດຽວກັນ, ບໍ່ແມ່ນເອກະສານອ້າງອີງ 5 ຢ່າງທີ່ຊີ້ໄປໃສ່ຕົວເລກໃສ່ປ່ອງທີ່ເປັນອິດສະຫຼະ.
///
///
/// ນອກຈາກນີ້, ໃຫ້ສັງເກດວ່າ `vec![expr; 0]` ຖືກອະນຸຍາດ, ແລະຜະລິດ vector ທີ່ເປົ່າຫວ່າງ.
/// ນີ້ຍັງຈະປະເມີນ `expr`, ເຖິງຢ່າງໃດກໍ່ຕາມ, ແລະຫຼຸດລົງມູນຄ່າທີ່ໄດ້ຮັບຜົນທັນທີ, ສະນັ້ນຈົ່ງລະວັງກ່ຽວກັບຜົນຂ້າງຄຽງ.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): ກັບ cfg(test) ວິທີການປະກົດຂຶ້ນ `[T]::into_vec`, ເຊິ່ງມີຄວາມ ຈຳ ເປັນ ສຳ ລັບ ຄຳ ນິຍາມມະຫາພາກນີ້, ບໍ່ມີ.
// ແທນທີ່ຈະໃຊ້ຟັງຊັນ `slice::into_vec` ເຊິ່ງມີພຽງແຕ່ cfg(test) NB ເບິ່ງໂມດູນ slice::hack ໃນ slice.rs ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// ສ້າງ `String` ໂດຍໃຊ້ການຕີຄວາມ ໝາຍ ຂອງການສະແດງອອກໃນໄລຍະເວລາ.
///
/// ການໂຕ້ຖຽງຄັ້ງ ທຳ ອິດທີ່ `format!` ໄດ້ຮັບແມ່ນສາຍຮູບແບບ.ນີ້ຕ້ອງແມ່ນສາຍອັກສອນທີ່ຮູ້ຫນັງສື.ພະລັງງານຂອງສະຕິງແບບຟອມແມ່ນຢູ່ໃນ ``{}`s.
///
/// ຕົວກໍານົດການເພີ່ມເຕີມທີ່ສົ່ງຜ່ານ `format!` ທົດແທນ ``{}`s ພາຍໃນສະຕິງຮູບແບບໃນຄໍາສັ່ງທີ່ໄດ້ຮັບເວັ້ນເສຍແຕ່ວ່າຕົວກໍານົດການທີ່ມີຊື່ຫຼືຕໍາແຫນ່ງຖືກນໍາໃຊ້;ເບິ່ງ [`std::fmt`] ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ.
///
///
/// ການນໍາໃຊ້ທົ່ວໄປສໍາລັບ `format!` ແມ່ນ concatenation ແລະ interpolation ຂອງຊ່ອຍແນ່.
/// ສົນທິສັນຍາອັນດຽວກັນນີ້ແມ່ນໃຊ້ກັບ [`print!`] ແລະ [`write!`] ມະຫາພາກ, ຂື້ນກັບຈຸດ ໝາຍ ປາຍທາງຂອງສາຍ.
///
/// ເພື່ອປ່ຽນຄ່າດຽວກັບສາຍ, ໃຫ້ໃຊ້ວິທີ [`to_string`].ນີ້ຈະໃຊ້ຮູບແບບ [`Display`] ຮູບແບບ trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics ຖ້າການຈັດຕັ້ງປະຕິບັດ trait ຮູບແບບຈະມີຂໍ້ຜິດພາດ.
/// ນີ້ສະແດງໃຫ້ເຫັນເຖິງການຈັດຕັ້ງປະຕິບັດທີ່ບໍ່ຖືກຕ້ອງເນື່ອງຈາກວ່າ `fmt::Write for String` ບໍ່ເຄີຍສົ່ງຂໍ້ຜິດພາດກັບຕົວເອງ.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// ບັງຄັບໃຫ້ໂຫນດ AST ສະແດງອອກເພື່ອປັບປຸງການວິນິດໄສໃນ ຕຳ ແໜ່ງ ຮູບແບບ.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}