//! ແຜ່ນສະຕິງ Unicode.
//!
//! *[See also the `str` primitive type](str).*
//!
//! ປະເພດ `&str` ແມ່ນ ໜຶ່ງ ໃນສອງປະເພດຫລັກ, ອີກປະເພດ ໜຶ່ງ ແມ່ນ `String`.
//! ບໍ່ຄືກັບຄູ່ຮ່ວມງານ `String` ຂອງມັນ, ເນື້ອຫາຂອງມັນຖືກຢືມ.
//!
//! # ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ
//!
//! ການປະກາດສະຕິງແບບພື້ນຖານຂອງປະເພດ `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! ທີ່ນີ້ພວກເຮົາໄດ້ປະກາດເປັນທີ່ຮູ້ຫນັງສື string, ຊຶ່ງເອີ້ນກັນວ່າຫຼັງຈາກນັ້ນນໍາ string.
//! ການຮູ້ຫນັງສືສະຕິງມີຊີວິດທີ່ຄົງທີ່, ຊຶ່ງຫມາຍຄວາມວ່າສາຍ `hello_world` ຖືກຮັບປະກັນໃຫ້ຖືກຕ້ອງໃນໄລຍະເວລາຂອງໂປແກຼມທັງ ໝົດ.
//!
//! ພວກເຮົາສາມາດ ກຳ ນົດຊີວິດຂອງສະບາຍດີ 'ສະບາຍດີ' ເຊັ່ນດຽວກັນ:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// ຈໍານວນຫຼາຍຂອງ usings ໃນໂມດູນນີ້ໄດ້ຖືກນໍາໃຊ້ພຽງແຕ່ໃນການຕັ້ງຄ່າການທົດສອບໄດ້.
// ມັນເຮັດຄວາມສະອາດໃຫ້ພຽງແຕ່ປິດການເຕືອນໄພທີ່ບໍ່ໄດ້ ນຳ ໃຊ້ເປັນການແກ້ໄຂຫຼາຍກວ່າການແກ້ໄຂ.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` ໃນ `Concat<str>` ແມ່ນບໍ່ມີຄວາມຫມາຍຢູ່ທີ່ນີ້.
/// ພາລາມິເຕີປະເພດນີ້ຂອງ trait ມີພຽງແຕ່ສາມາດ ນຳ ໃຊ້ impl ອື່ນ.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // ວົງແຫວນທີ່ມີຂະ ໜາດ hardcoded ແລ່ນໄວຫຼາຍພິເສດກໍລະນີທີ່ມີຄວາມຍາວແຍກຂະ ໜາດ ນ້ອຍ
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // ການຫຼຸດລົງຂອງຂະ ໜາດ ທີ່ບໍ່ແມ່ນເລກສູນ
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// ການປະຕິບັດການເຂົ້າຮ່ວມທີ່ດີທີ່ສຸດທີ່ເຮັດວຽກສໍາລັບທັງ Vec<T>(T: ສຳ ເນົາ) ແລະ vec ພາຍໃນຂອງ String ປະຈຸບັນນີ້ (2018-05-13) ມີຂໍ້ບົກພ່ອງທີ່ມີຄວາມມັກແລະຄວາມຊ່ຽວຊານດ້ານປະເພດ (ເບິ່ງບັນຫາ #36262) ສຳ ລັບເຫດຜົນນີ້ SliceConcat<T>ບໍ່ແມ່ນຊ່ຽວຊານ ສຳ ລັບ T: Copy ແລະ SliceConcat<str>ແມ່ນຜູ້ໃຊ້ດຽວທີ່ໃຊ້ໃນ ໜ້າ ທີ່ນີ້.
// ມັນຖືກປະໄວ້ໃນສະຖານທີ່ ສຳ ລັບເວລາທີ່ມີການສ້ອມແຊມ.
//
// ຜູກມັດ ສຳ ລັບ String-join ແມ່ນ S: ຢືມ<str>ແລະສໍາລັບ Vec ຄືນເຂົ້າຮ່ວມການກູ້ຍືມ <[T]> [T] ແລະ Str ທັງ impl AsRef <[T]> ສໍາລັບ T ບາງ
// => s.borrow().as_ref() ແລະພວກເຮົາມີສະເຫມີ
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // ທ່ອນໄມ້ ທຳ ອິດແມ່ນພຽງໂຕດຽວທີ່ບໍ່ມີເຄື່ອງແຍກກ່ອນມັນ
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // ຄິດໄລ່ຄວາມຍາວທັງ ໝົດ ທີ່ແນ່ນອນຂອງ Vec ທີ່ເຂົ້າຮ່ວມຖ້າການຄິດໄລ່ `len` ລົ້ນ, ພວກເຮົາຈະ panic ພວກເຮົາອາດຈະ ໝົດ ຄວາມຊົງ ຈຳ ແລ້ວແລະສ່ວນທີ່ເຫຼືອຂອງ ໜ້າ ທີ່ຮຽກຮ້ອງໃຫ້ Vec ທັງ ໝົດ ຈັດສັນໄວ້ກ່ອນເພື່ອຄວາມປອດໄພ
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // ກະກຽມບັຟເຟີທີ່ບໍ່ມີປະສິດຕິພາບ
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // ສໍາເນົາແຍກແລະຫຼັງຈາກນັ້ນນໍາໃນໄລຍະໂດຍບໍ່ມີການຂອບເຂດການກວດສອບສ້າງ loops ກັບຊົດເຊີຍ hardcoded ສໍາລັບການແຍກຂະຫນາດນ້ອຍການປັບປຸງ massive ເປັນໄປໄດ້ (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // ການຈັດຕັ້ງປະຕິບັດການກູ້ຢືມທີ່ແປກອາດຈະກັບຄືນມາແຕກຕ່າງກັນ ສຳ ລັບການຄິດໄລ່ຄວາມຍາວແລະ ສຳ ເນົາຕົວຈິງ.
        //
        // ໃຫ້ແນ່ໃຈວ່າພວກເຮົາບໍ່ເຜີຍແຜ່ໄບຕ໌ທີ່ບໍ່ມີຊື່ສຽງກັບຜູ້ໂທ.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// ວິທີການ ສຳ ລັບຕັດສາຍເຊືອກ.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// ແປງ `Box<str>` ເປັນ `Box<[u8]>` ໂດຍບໍ່ຕ້ອງຄັດລອກຫລືຈັດສັນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// ແທນທີ່ທຸກຮູບແບບຂອງຮູບແບບດ້ວຍສາຍອື່ນ.
    ///
    /// `replace` ສ້າງເປັນ [`String`] ໃຫມ່, ແລະສໍາເນົາຂໍ້ມູນຈາກຫຼັງຈາກນັ້ນນໍາ string ນີ້ເຂົ້າໄປໃນມັນ.
    /// ໃນຂະນະທີ່ເຮັດເຊັ່ນນັ້ນ, ມັນພະຍາຍາມຊອກຫາການຈັບຄູ່ຂອງຮູບແບບ.
    /// ຖ້າເຫັນວ່າມີອັນໃດອັນ ໜຶ່ງ, ມັນຈະປ່ຽນແທນພວກມັນດ້ວຍຊິ້ນເຊືອກທີ່ຖືກປ່ຽນແທນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// ເມື່ອຮູບແບບບໍ່ກົງກັບ:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// ແທນ N ໂຕ ທຳ ອິດຂອງຮູບແບບທີ່ມີສາຍອື່ນ.
    ///
    /// `replacen` ສ້າງເປັນ [`String`] ໃຫມ່, ແລະສໍາເນົາຂໍ້ມູນຈາກຫຼັງຈາກນັ້ນນໍາ string ນີ້ເຂົ້າໄປໃນມັນ.
    /// ໃນຂະນະທີ່ເຮັດເຊັ່ນນັ້ນ, ມັນພະຍາຍາມຊອກຫາການຈັບຄູ່ຂອງຮູບແບບ.
    /// ຖ້າຫາກວ່າມັນເຫັນວ່າໃດ, ມັນປ່ຽນແທນໃຫ້ເຂົາເຈົ້າມີຫຼັງຈາກນັ້ນນໍາຂໍ້ຄວາມແທນທີ່ຫຼາຍທີ່ສຸດເວລາ `count`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// ເມື່ອຮູບແບບບໍ່ກົງກັບ:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // ຫວັງວ່າຈະຫຼຸດຜ່ອນເວລາໃດຫນຶ່ງ, ການຈັດສັນ
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// ສົ່ງຄືນຄ່າທຽບເທົ່າຂອງຕົວນ້ອຍກວ່າຂອງສະຕິງນີ້, ເປັນ [`String`] ໃໝ່.
    ///
    /// 'Lowercase' ຖືກ ກຳ ນົດຕາມຂໍ້ ກຳ ນົດຂອງ `Lowercase` Unicode Derived Core Property.
    ///
    /// ເນື່ອງຈາກລັກສະນະບາງຢ່າງສາມາດຂະຫຍາຍເຂົ້າໄປໃນລັກສະນະທີ່ຫຼາກຫຼາຍໃນເວລາທີ່ມີການປ່ຽນແປງກໍລະນີ, ການທໍາງານນີ້ຈະກັບຄືນມາເປັນ [`String`] ແທນທີ່ຈະເປັນການປັບປຸງຕົວກໍານົດການໃນສະຖານທີ່.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// ຕົວຢ່າງທີ່ຫຼອກລວງ, ດ້ວຍ sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // ແຕ່ໃນຕອນທ້າຍຂອງ ຄຳ ສັບ, ມັນແມ່ນς, ບໍ່ແມ່ນσ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// ພາສາທີ່ບໍ່ມີກໍລະນີແມ່ນບໍ່ມີການປ່ຽນແປງ:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σແຜນທີ່ເປັນσ, ຍົກເວັ້ນໃນຕອນທ້າຍຂອງ ຄຳ ທີ່ມັນວາງແຜນທີ່ຈະς.
                // ນີ້ແມ່ນ (contextual) ທີ່ມີເງື່ອນໄຂເທົ່ານັ້ນແຕ່ການສ້າງແຜນທີ່ທີ່ເປັນເອກະລາດກ່ຽວກັບພາສາໃນ `SpecialCasing.txt`, ສະນັ້ນມັນຍາກທີ່ຈະເປັນລະຫັດແທນທີ່ຈະມີກົນໄກ "condition" ທົ່ວໄປ.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // ສໍາລັບຄໍານິຍາມຂອງ `Final_Sigma` ໄດ້.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// ສົ່ງຄືນຄ່າທຽບເທົ່າທີ່ໃຫຍ່ທີ່ສຸດຂອງຊິ້ນເຊືອກນີ້, ເປັນ [`String`] ໃໝ່.
    ///
    /// 'Uppercase' ຖືກ ກຳ ນົດຕາມຂໍ້ ກຳ ນົດຂອງ `Uppercase` Unicode Derived Core Property.
    ///
    /// ເນື່ອງຈາກລັກສະນະບາງຢ່າງສາມາດຂະຫຍາຍເຂົ້າໄປໃນລັກສະນະທີ່ຫຼາກຫຼາຍໃນເວລາທີ່ມີການປ່ຽນແປງກໍລະນີ, ການທໍາງານນີ້ຈະກັບຄືນມາເປັນ [`String`] ແທນທີ່ຈະເປັນການປັບປຸງຕົວກໍານົດການໃນສະຖານທີ່.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// ສະຄິບທີ່ບໍ່ມີກໍລະນີບໍ່ມີການປ່ຽນແປງ:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// ລັກສະນະ ໜຶ່ງ ສາມາດກາຍເປັນຫຼາຍ:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// ແປງ [`Box<str>`] ເປັນ [`String`] ໂດຍບໍ່ຕ້ອງຄັດລອກຫລືຈັດສັນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// ສ້າງ [`String`] ແບບ ໃໝ່ ໂດຍການເຮັດຊໍ້າ `n` ເທື່ອ.
    ///
    /// # Panics
    ///
    /// ຟັງຊັນນີ້ຈະ panic ຖ້າຄວາມສາມາດຈະລົ້ນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// A panic ເມື່ອລົ້ນ:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// ສົ່ງຄືນ ສຳ ເນົາຂອງສະບັບນີ້ບ່ອນທີ່ແຕ່ລະຕົວອັກສອນຖືກສ້າງເປັນເອກະສານຂະ ໜາດ ໃຫຍ່ ASCII.
    ///
    ///
    /// ຕົວອັກສອນ ASCII 'a' ກັບ 'z' ແມ່ນ mapped ກັບ 'A' ກັບ 'Z', ແຕ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII ແມ່ນບໍ່ປ່ຽນແປງ.
    ///
    /// ເພື່ອຍົກສູງມູນຄ່າທີ່ຢູ່ໃນສະຖານທີ່, ໃຫ້ໃຊ້ [`make_ascii_uppercase`].
    ///
    /// ເພື່ອໃຫ້ຕົວອັກສອນໃຫຍ່ ASCII ເພີ່ມເຕີມໃສ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII, ໃຫ້ໃຊ້ [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() ປົກປັກຮັກສາການບຸກລຸກ UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// ສົ່ງຄືນ ສຳ ເນົາສາຍສະບັບນີ້ທີ່ຕົວອັກສອນແຕ່ລະສະບັບຖືກ ໝາຍ ໃສ່ໃນກໍລະນີທີ່ນ້ອຍກວ່າ ASCII.
    ///
    ///
    /// ຕົວອັກສອນ ASCII 'A' ຫາ 'Z' ຖືກແຕ້ມໃສ່ 'a' ຫາ 'z', ແຕ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII ບໍ່ປ່ຽນແປງ.
    ///
    /// ເພື່ອເຮັດໃຫ້ຄຸນຄ່າໃນສະຖານທີ່ນ້ອຍລົງ, ໃຫ້ໃຊ້ [`make_ascii_lowercase`].
    ///
    /// ເພື່ອໃຫ້ຕົວອັກສອນນ້ອຍ ASCII ເພີ່ມເຕີມໃສ່ຕົວອັກສອນທີ່ບໍ່ແມ່ນ ASCII, ໃຫ້ໃຊ້ [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() ປົກປັກຮັກສາການບຸກລຸກ UTF-8.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// ແປງທ່ອນທີ່ມີກ່ອງໃສ່ບາດເປັນທ່ອນໃສ່ກະດານໂດຍບໍ່ກວດເບິ່ງວ່າສາຍສະຕິງມີ UTF-8 ທີ່ຖືກຕ້ອງ.
///
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}