//! ການຈັດສັນ Preclus
//!
//! ຈຸດປະສົງຂອງໂມດູນນີ້ແມ່ນເພື່ອຫຼຸດຜ່ອນການ ນຳ ເຂົ້າສິນຄ້າທີ່ຖືກ ນຳ ໃຊ້ໂດຍທົ່ວໄປຂອງ `alloc` crate ໂດຍການເພີ່ມການ ນຳ ເຂົ້າຂອງເຂົ້າສູ່ລະດັບສູງສຸດ:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;