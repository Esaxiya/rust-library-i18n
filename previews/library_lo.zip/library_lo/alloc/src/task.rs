#![stable(feature = "wake_trait", since = "1.51.0")]
//! ປະເພດແລະ Traits ສຳ ລັບເຮັດວຽກກັບວຽກງານທີ່ບໍ່ສະ ໝັກ ໃຈ.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// ການຈັດຕັ້ງປະຕິບັດການຕື່ນຕົວຕໍ່ຜູ້ປະຕິບັດງານ.
///
/// trait ນີ້ສາມາດຖືກນໍາໃຊ້ເພື່ອສ້າງ [`Waker`].
/// ຜູ້ປະຕິບັດງານສາມາດ ກຳ ນົດການຈັດຕັ້ງປະຕິບັດຂອງ trait ນີ້, ແລະໃຊ້ສິ່ງນັ້ນເພື່ອກໍ່ສ້າງ Waker ເພື່ອສົ່ງຕໍ່ວຽກທີ່ຖືກປະຕິບັດຕໍ່ຜູ້ປະຕິບັດງານນັ້ນ.
///
/// trait ນີ້ເປັນຄວາມຊົງຈໍາ, ຄວາມປອດໄພແລະທາງເລືອກທີ່ເຫມາະທີ່ຈະສ້າງ [`RawWaker`].
/// ມັນສະ ໜັບ ສະ ໜູນ ການອອກແບບຜູ້ບໍລິຫານແບບ ທຳ ມະດາເຊິ່ງຂໍ້ມູນທີ່ໃຊ້ໃນການປຸກວຽກແມ່ນເກັບໄວ້ໃນ [`Arc`].
/// ຜູ້ປະຕິບັດງານບາງຄົນ (ໂດຍສະເພາະຜູ້ທີ່ໃຊ້ ສຳ ລັບລະບົບທີ່ຝັງຢູ່) ບໍ່ສາມາດໃຊ້ API ນີ້ໄດ້, ເຊິ່ງເປັນເຫດຜົນທີ່ [`RawWaker`] ມີຕົວເລືອກ ສຳ ລັບລະບົບເຫລົ່ານັ້ນ.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// ຟັງຊັນ `block_on` ຂັ້ນພື້ນຖານທີ່ໃຊ້ເວລາ future ແລະເຮັດວຽກໃຫ້ມັນ ສຳ ເລັດຕາມກະແສປະຈຸບັນ.
///
/// **Note:** ຕົວຢ່າງນີ້ການຄ້າຖືກຕ້ອງສໍາລັບການລະນາ.
/// ເພື່ອປ້ອງກັນການປິດບັງ, ການຈັດຕັ້ງປະຕິບັດການຜະລິດ-ລະດັບການຜະລິດຍັງຈະຕ້ອງໄດ້ຈັດການໂທລະດັບກາງໃຫ້ແກ່ `thread::unpark` ພ້ອມທັງການຮຽກເຊີນທີ່ຮວບຮວມ.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// waker ຜູ້ທີ່ຕື່ນຕົວກະທູ້ປັດຈຸບັນເມື່ອຖືກເອີ້ນ.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// ດໍາເນີນການ future ເພື່ອໃຫ້ສໍາເລັດໃນກະທູ້ປັດຈຸບັນ.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // PIN ຂອງ future ນັ້ນມັນສາມາດຕອບແບບສອບຖາມ.
///     let mut fut = Box::pin(fut);
///
///     // ສ້າງສະພາບການ ໃໝ່ ທີ່ຈະສົ່ງໄປທີ່ future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // ດຳ ເນີນງານ future ໃຫ້ ສຳ ເລັດ.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// ຕື່ນວຽກນີ້.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// ຕື່ນຕົວວຽກນີ້ໂດຍບໍ່ຕ້ອງກິນຜູ້ລ້ຽງ.
    ///
    /// ຖ້າຜູ້ປະຕິບັດການສະ ໜັບ ສະ ໜູນ ວິທີການທີ່ມີລາຄາຖືກກວ່າທີ່ຈະຕື່ນຕົວໂດຍບໍ່ຕ້ອງໃຊ້ waker, ມັນຄວນຈະປະຕິເສດວິທີການນີ້.
    /// ໂດຍຄ່າເລີ່ມຕົ້ນ, ມັນ clones [`Arc`] ແລະເອີ້ນ [`wake`] ໃສ່ clone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // ຄວາມປອດໄພ: ສິ່ງນີ້ປອດໄພເພາະວ່າຜູ້ຜະລິດວັດຖຸດິບກໍ່ສ້າງຢ່າງປອດໄພ
        // RawWaker ຈາກ Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: ໜ້າ ທີ່ສ່ວນຕົວນີ້ ສຳ ລັບການກໍ່ສ້າງ RawWaker ແມ່ນຖືກ ນຳ ໃຊ້, ແທນທີ່ຈະແມ່ນ
// inlining ນີ້ເຂົ້າໄປໃນ `From<Arc<W>> for RawWaker` impl, ເພື່ອໃຫ້ແນ່ໃຈວ່າຄວາມປອດໄພຂອງ `From<Arc<W>> for Waker` ບໍ່ໄດ້ຂື້ນກັບການສົ່ງ trait ທີ່ຖືກຕ້ອງ, ແທນທີ່ທັງສອງ ໝາຍ ເຖິງການເອີ້ນຟັງຊັນນີ້ໂດຍກົງແລະຊັດເຈນ.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // ເພີ່ມ ຈຳ ນວນເອກະສານອ້າງອີງຂອງປະຕູໂຄ້ງເພື່ອໂຄນມັນ.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // ຕື່ນດ້ວຍຄ່າ, ຍ້າຍ Arc ເຂົ້າໃນ ໜ້າ ທີ່ Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // ຕື່ນນອນໂດຍອ້າງອີງໃສ່, ຫໍ່ຜູ້ເຮັດໃນ ManuallyDrop ເພື່ອຫຼີກລ້ຽງການລຸດລົງ
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // ຫຼຸດຜ່ອນການນັບກະສານອ້າງອີງຂອງ Arc ຕໍ່ການລຸດລົງ
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}