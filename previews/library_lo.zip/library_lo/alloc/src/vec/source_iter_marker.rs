use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// ເຄື່ອງ ໝາຍ ຄວາມຊ່ຽວຊານ ສຳ ລັບການເກັບທໍ່ສົ່ງທິດທາງເຂົ້າໄປໃນ Vec ໃນຂະນະທີ່ ນຳ ໃຊ້ການຈັດສັນແຫຼ່ງຂໍ້ມູນ, ເຊັ່ນ
/// ປະຕິບັດທໍ່ຢູ່ສະຖານທີ່.
///
/// ພໍ່ແມ່ຂອງ SourceIter trait ແມ່ນມີຄວາມ ຈຳ ເປັນ ສຳ ລັບ ໜ້າ ທີ່ທີ່ຊ່ຽວຊານໃນການເຂົ້າເຖິງການຈັດສັນທີ່ຈະ ນຳ ໃຊ້ຄືນ.
/// ແຕ່ມັນບໍ່ພຽງພໍ ສຳ ລັບຄວາມຊ່ຽວຊານທີ່ຖືກຕ້ອງ.
/// ເບິ່ງຂອບເຂດເພີ່ມເຕີມກ່ຽວກັບ impl ໄດ້.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// The std, ພາຍໃນ SourceIter/InPlaceIterable traits ກໍາລັງດໍາເນີນການໂດຍລະບົບຕ່ອງໂສ້ຂອງຜູ້ດັດແປງພຽງແຕ່ <Adapter<Adapter<IntoIter>>> (ເປັນເຈົ້າຂອງທັງຫມົດໂດຍ core/std).
// ຂອບເຂດເພີ່ມເຕີມກ່ຽວກັບການປະຕິບັດຕົວອະແດບເຕີ (ເກີນ `impl<I: Trait> Trait for Adapter<I>`) ພຽງແຕ່ຂື້ນກັບ traits ອື່ນໆທີ່ຖືກ ໝາຍ ໄວ້ແລ້ວວ່າເປັນຜູ້ຊ່ຽວຊານ traits (ສຳ ເນົາ, TrustedRandomAccess, FusedIterator).
//
// I.e. ເຄື່ອງຫມາຍບໍ່ຂຶ້ນກັບຊີວິດຂອງປະເພດໃຊ້ສະຫນອງ.Modulo the Copy ຂຸມ, ເຊິ່ງຄວາມຊ່ຽວຊານຫລາຍຢ່າງອື່ນໆແມ່ນຂື້ນກັບ.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // ຄວາມຕ້ອງການເພີ່ມເຕີມທີ່ບໍ່ສາມາດສະແດງອອກຜ່ານ trait bounds.ພວກເຮົາອີງໃສ່ການ eval ແທນ:
        // a) ZSTs ເປັນມີຈະເປັນການຈັດສັນທີ່ບໍ່ມີການນໍາມາໃຊ້ໃຫມ່ແລະຊີ້ທາງຄະນິດສາດ panic b) ການແຂ່ງຂັນຂະຫນາດຕາມຄວາມຕ້ອງການໂດຍການຈັດສັນສັນຍາ c) ຈັດລຽນຈະມີຄໍາວ່າເປັນທີ່ຕ້ອງການໂດຍສັນຍາການຈັດສັນທີ່ບໍ່ມີ
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // ຍ້ອນກັບການຈັດຕັ້ງປະຕິບັດແບບທົ່ວໆໄປ
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // ໃຊ້ພັບທົດລອງຕັ້ງແຕ່ນັ້ນມາ
        // - ມັນ vectorizes ດີກວ່າສໍາລັບການອະແດບເຕີ iterator ບາງ
        // - ບໍ່ຄືກັບວິທີການປັບປ່ຽນພາຍໃນເກືອບທັງ ໝົດ, ມັນຕ້ອງໃຊ້ &mut ຕົວເອງເທົ່ານັ້ນ
        // - ມັນສາມາດເຮັດໃຫ້ພວກເຮົາກະທູ້ຕົວຊີ້ຂຽນຜ່ານທາງໃນຂອງມັນແລະເຮັດໃຫ້ມັນກັບມາໃນທີ່ສຸດ
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteration ສົບຜົນສໍາເລັດ, ບໍ່ລຸດຫົວ
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // ກວດເບິ່ງວ່າສັນຍາ SourceIter ໄດ້ຮັບການອະນຸມັດບໍ່: ຖ້າພວກມັນບໍ່ແມ່ນພວກເຮົາອາດຈະບໍ່ເຮັດໃຫ້ມັນເຖິງຈຸດນີ້
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // ກວດສອບສັນຍາ InPlaceIterable.ມັນເປັນໄປໄດ້ພຽງແຕ່ຖ້າຕົວປ່ຽນແປງໄດ້ກ້າວ ໜ້າ ໄປຫາຕົວຊີ້ທິດທາງທັງ ໝົດ.
        // ຖ້າມັນໃຊ້ການເຂົ້າເຖິງທີ່ບໍ່ໄດ້ກວດກາຜ່ານ TrustedRandomAccess ແລ້ວຕົວຊີ້ບອກແຫຼ່ງຂໍ້ມູນຈະຢູ່ໃນ ຕຳ ແໜ່ງ ເບື້ອງຕົ້ນແລະພວກເຮົາບໍ່ສາມາດໃຊ້ມັນເປັນເອກະສານອ້າງອີງ
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ຫຼຸດລົງຄ່າໃດໆທີ່ຍັງເຫຼືອຢູ່ຫາງຂອງແຫຼ່ງຂໍ້ມູນແຕ່ປ້ອງກັນການຫຼຸດລົງຂອງການຈັດສັນຕົວມັນເອງເມື່ອ IntoIter ໝົດ ໄປໃນຂອບເຂດຖ້າການຫຼຸດລົງ panics ແລ້ວພວກເຮົາກໍ່ຈະຮົ່ວໄຫລເອົາອົງປະກອບໃດ ໜຶ່ງ ທີ່ເກັບລວບລວມເຂົ້າໄປໃນ dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // ສັນຍາ InPlaceIterable ບໍ່ສາມາດຢືນຢັນໄດ້ທີ່ນີ້ເນື່ອງຈາກ try_fold ມີເອກະສານອ້າງອີງສະເພາະກັບຕົວຊີ້ວັດທີ່ພວກເຮົາສາມາດເຮັດໄດ້ແມ່ນກວດເບິ່ງວ່າມັນຍັງຢູ່ໃນຂອບເຂດ
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}