use core::ptr::{self};
use core::slice::{self};

// ໂຄງສ້າງຂອງຜູ້ຊ່ວຍ ສຳ ລັບການເວົ້າທີ່ຢູ່ໃນສະຖານທີ່ທີ່ລຸດລົງຈາກຈຸດ ໝາຍ ປາຍທາງຂອງການປົດປ່ອຍ, ຄືຫົວ.
// ສ່ວນທີ່ເປັນແຫລ່ງ (ຫາງ) ແມ່ນລົງໂດຍ IntoIter.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}