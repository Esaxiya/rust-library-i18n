// ກຳ ນົດຄວາມຍາວຂອງເສັ້ນໃນເວລາທີ່ມູນຄ່າ `SetLenOnDrop` ບໍ່ມີຂອບເຂດ.
//
// ແນວຄວາມຄິດແມ່ນ: ຂົງເຂດຄວາມຍາວໃນ SetLenOnDrop ແມ່ນຕົວແປທ້ອງຖິ່ນທີ່ຕົວເລືອກທີ່ດີທີ່ສຸດຈະເຫັນບໍ່ມີຊື່ສຽງກັບຮ້ານໃດກໍ່ຕາມຜ່ານຕົວຊີ້ວັດຂໍ້ມູນຂອງ Vec.
// ນີ້ແມ່ນວິທີການເຮັດວຽກ ສຳ ລັບບັນຫາການວິເຄາະນາມແຝງ #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}