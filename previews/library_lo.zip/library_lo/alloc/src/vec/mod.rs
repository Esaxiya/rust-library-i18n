//! ປະເພດຂບວນທີ່ສາມາດເຕີບໃຫຍ່ໄດ້ຢ່າງຕໍ່ເນື່ອງໂດຍມີເນື້ອຫາທີ່ຈັດສັນເປັນກຸ່ມ, ຂຽນເປັນ `Vec<T>`.
//!
//! Vectors ມີການດັດສະນີ `O(1)`, ຍົກເລີກການຊຸກຍູ້ `O(1)` (ຈົນເຖິງທີ່ສຸດ) ແລະ `O(1)` pop (ຈາກທີ່ສຸດ).
//!
//!
//! Vectors ໃຫ້ແນ່ໃຈວ່າພວກເຂົາເຈົ້າບໍ່ເຄີຍຈັດສັນຫຼາຍກ່ວາ `isize::MAX` ໄບ.
//!
//! # Examples
//!
//! ທ່ານສາມາດສ້າງ [`Vec`] ກັບ [`Vec::new`] ຢ່າງຈະແຈ້ງ:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... ຫຼືໂດຍການ ນຳ ໃຊ້ມະຫາພາກ [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // ສິບສູນ
//! ```
//!
//! ທ່ານສາມາດເຮັດໄດ້ [`push`] ໃຫ້ຄຸນຄ່າໃສ່ໃນຕອນທ້າຍຂອງ vector (ຊຶ່ງຈະຂະຫຍາຍຕົວໄດ້ vector ຖ້າຈໍາເປັນ):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! ຄຸນຄ່າ Popping ເຮັດວຽກໄດ້ຫຼາຍວິທີດຽວກັນ:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors ຍັງສະຫນັບສະຫນູນການດັດສະນີ (ຜ່ານ [`Index`] ແລະ [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// ປະເພດຂບວນທີ່ສາມາດເຕີບໃຫຍ່ໄດ້ຢ່າງຕໍ່ເນື່ອງ, ຂຽນເປັນ `Vec<T>` ແລະອອກສຽງ 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// ມະຫາພາກ [`vec!`] ໄດ້ຖືກຈັດຫາເພື່ອເຮັດໃຫ້ການເລີ່ມຕົ້ນງ່າຍຂຶ້ນ:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// ມັນຍັງສາມາດເລີ່ມຕົ້ນແຕ່ລະອົງປະກອບຂອງ `Vec<T>` ດ້ວຍມູນຄ່າທີ່ໄດ້ຮັບ.
/// ນີ້ອາດຈະມີປະສິດທິພາບຫຼາຍກ່ວາປະຕິບັດການຈັດສັນແລະຂຽນອັກສອນຫຍໍ້ໃນຂັ້ນຕອນແຍກຕ່າງຫາກ, ໂດຍສະເພາະໃນເວລາທີ່ເລີ່ມຕົ້ນເປັນ vector ຂອງສູນ:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // ຕໍ່ໄປນີ້ແມ່ນທຽບເທົ່າ, ແຕ່ອາດຈະຊ້າລົງ:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ, ເບິ່ງ [Capacity and Reallocation](#capacity-and-reallocation).
///
/// ໃຊ້ `Vec<T>` ເປັນ stack ທີ່ມີປະສິດຕິພາບ:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Prints 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// ປະເພດ `Vec` ອະນຸຍາດໃຫ້ເຂົ້າເຖິງຄ່າຕ່າງໆໂດຍດັດສະນີ, ເພາະວ່າມັນປະຕິບັດກັບ [`Index`] trait.ຕົວຢ່າງຈະຊັດເຈນຫຼາຍຂຶ້ນ:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // ມັນຈະສະແດງ '2'
/// ```
///
/// ເຖິງຢ່າງໃດກໍ່ຕາມຈົ່ງລະວັງ: ຖ້າທ່ານພະຍາຍາມເຂົ້າເຖິງດັດສະນີທີ່ບໍ່ຢູ່ໃນ `Vec`, ຊອບແວຂອງທ່ານຈະເປັນ panic!ທ່ານບໍ່ສາມາດເຮັດສິ່ງນີ້ໄດ້:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// ໃຊ້ [`get`] ແລະ [`get_mut`] ຖ້າທ່ານຕ້ອງການກວດສອບວ່າດັດຊະນີຢູ່ໃນ `Vec`.
///
/// # Slicing
///
/// A `Vec` ສາມາດແລກປ່ຽນໄດ້.ໃນທາງກົງກັນຂ້າມ, ບັນດາຊິ້ນສ່ວນແມ່ນວັດຖຸທີ່ອ່ານເທົ່ານັ້ນ.
/// ເພື່ອໃຫ້ໄດ້ຮັບເປັນ [slice][prim@slice] ໃຊ້ [`&`].ຕົວຢ່າງ:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... ແລະນັ້ນແມ່ນທັງຫມົດ!
/// // ທ່ານຍັງສາມາດເຮັດມັນໄດ້ເຊັ່ນນີ້:
/// let u: &[usize] = &v;
/// // ຫຼືຄ້າຍຄືນີ້:
/// let u: &[_] = &v;
/// ```
///
/// ໃນ Rust, ມັນເປັນເລື່ອງ ທຳ ມະດາທີ່ຈະຖ່າຍທອດເປັນການໂຕ້ຖຽງຫຼາຍກວ່າ vectors ເມື່ອທ່ານພຽງແຕ່ຕ້ອງການໃຫ້ການເຂົ້າເຖິງອ່ານ.ສິ່ງດຽວກັນ ສຳ ລັບ [`String`] ແລະ [`&str`].
///
/// # ຄວາມສາມາດແລະການຈັດສັນທີ່ແທ້ຈິງ
///
/// ຄວາມອາດສາມາດຂອງ vector ແມ່ນຈໍານວນເງິນຂອງຊ່ອງທີ່ຈັດສັນສໍາລັບອົງປະກອບໃດ future ທີ່ຈະໄດ້ຮັບການເພີ່ມໃສ່ໄດ້ vector.ນີ້ບໍ່ຄວນສັບສົນກັບຄວາມຍາວ * ຂອງ vector, ເຊິ່ງລະບຸ ຈຳ ນວນຂອງສ່ວນປະກອບຕົວຈິງພາຍໃນ vector.
/// ຖ້າຫາກວ່າໄລຍະເວລາຂອງ vector ເກີນຄວາມສາມາດຂອງຕົນ, ຄວາມສາມາດຂອງຕົນຈະໄດ້ຮັບການເພີ່ມຂຶ້ນອັດຕະໂນມັດ, ແຕ່ອົງປະກອບຂອງຕົນຈະຕ້ອງໄດ້ຮັບການຈັດສັນ.
///
/// ສໍາລັບຕົວຢ່າງ, ເປັນ vector ທີ່ມີຄວາມຈຸ 10 ແລະຄວາມຍາວ 0 ຈະເປັນເປົ່າ vector ກັບຊ່ອງສໍາລັບການ 10 ອົງປະກອບເພີ່ມເຕີມ.ການຊຸກຍູ້ 10 ອົງປະກອບຫຼື ໜ້ອຍ ກວ່ານັ້ນໃສ່ vector ຈະບໍ່ປ່ຽນແປງຄວາມອາດສາມາດຂອງມັນຫລືເຮັດໃຫ້ການຈັດສັນທີ່ແທ້ຈິງເກີດຂື້ນ.
/// ເຖິງຢ່າງໃດກໍ່ຕາມ, ຖ້າຄວາມຍາວຂອງ vector ເພີ່ມຂື້ນເປັນ 11, ມັນຈະຕ້ອງໄດ້ຈັດສັນທີ່ຢູ່ອາໃສ, ເຊິ່ງສາມາດຊ້າໄດ້.ດ້ວຍເຫດຜົນນີ້, ແນະ ນຳ ໃຫ້ໃຊ້ [`Vec::with_capacity`] ທຸກຄັ້ງທີ່ເປັນໄປໄດ້ເພື່ອລະບຸວ່າ vector ຄາດວ່າຈະໄດ້ຮັບເທົ່າໃດ.
///
/// # Guarantees
///
/// ເນື່ອງຈາກລັກສະນະພື້ນຖານທີ່ບໍ່ ໜ້າ ເຊື່ອ, `Vec` ເຮັດໃຫ້ມີການຮັບປະກັນຫຼາຍຢ່າງກ່ຽວກັບການອອກແບບຂອງມັນ.ນີ້ຮັບປະກັນວ່າມັນມີຄ່າໃຊ້ຈ່າຍຕ່ ຳ ທີ່ສຸດເທົ່າທີ່ເປັນໄປໄດ້ໃນກໍລະນີທົ່ວໄປ, ແລະສາມາດຈັດການໄດ້ຢ່າງຖືກຕ້ອງໃນທາງເດີມໂດຍລະຫັດທີ່ບໍ່ປອດໄພ.ໃຫ້ສັງເກດວ່າການຄ້ ຳ ປະກັນເຫລົ່ານີ້ ໝາຍ ເຖິງ `Vec<T>` ທີ່ບໍ່ມີເງື່ອນໄຂ.
/// ຖ້າຕົວກໍານົດປະເພດເພີ່ມເຕີມຖືກເພີ່ມ (ຕົວຢ່າງ, ເພື່ອສະຫນັບສະຫນູນຜູ້ຈັດສັນທີ່ກໍາຫນົດເອງ), ການເອົາຊະນະຄ່າເລີ່ມຕົ້ນຂອງພວກເຂົາອາດຈະປ່ຽນແປງພຶດຕິກໍາ.
///
/// ໂດຍພື້ນຖານແລ້ວ, `Vec` ແມ່ນແລະເປັນສະຖານທີ່ເດີນທາງ (ຕົວຊີ້, ຄວາມສາມາດ, ຄວາມຍາວ).ບໍ່ມີອີກແລ້ວ, ບໍ່ ໜ້ອຍ.ຄໍາສັ່ງຂອງຂົງເຂດເຫຼົ່ານີ້ແມ່ນບໍ່ໄດ້ກໍານົດຢ່າງສົມບູນ, ແລະທ່ານຄວນໃຊ້ວິທີການທີ່ ເໝາະ ສົມເພື່ອດັດແປງຂໍ້ມູນເຫຼົ່ານີ້.
/// ຕົວຊີ້ຈະບໍ່ຖືກ null, ດັ່ງນັ້ນປະເພດນີ້ແມ່ນບໍ່ມີຕົວຕົນ.
///
/// ເຖິງຢ່າງໃດກໍ່ຕາມ, ຕົວຊີ້ຕົວຈິງອາດຈະບໍ່ຊີ້ໃຫ້ເຫັນເຖິງຄວາມຊົງ ຈຳ ທີ່ຖືກຈັດສັນ.
/// ໂດຍສະເພາະ, ຖ້າທ່ານສ້າງ `Vec` ທີ່ມີຄວາມສາມາດ 0 ຜ່ານ [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], ຫຼືໂດຍການໂທຫາ [`shrink_to_fit`] ໃນ Vec ເປົ່າ, ມັນຈະບໍ່ຈັດສັນຄວາມ ຈຳ ໄດ້.ເຊັ່ນດຽວກັນ, ຖ້າທ່ານເກັບປະເພດທີ່ມີຂະ ໜາດ ສູນພາຍໃນ `Vec`, ມັນຈະບໍ່ຈັດສັນພື້ນທີ່ໃຫ້ພວກມັນ.
/// *ໃຫ້ສັງເກດວ່າໃນກໍລະນີນີ້ `Vec` ອາດຈະບໍ່ລາຍງານວ່າ [`capacity`] ຂອງ 0*.
/// `Vec` ຈະຈັດສັນຖ້າແລະເທົ່ານັ້ນຖ້າ [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// ໂດຍທົ່ວໄປ, ລາຍລະອຽດການຈັດສັນຂອງ `Vec` ແມ່ນມີຄວາມລະອຽດອ່ອນຫຼາຍ-ຖ້າທ່ານຕັ້ງໃຈຈັດສັນຄວາມຊົງ ຈຳ ໂດຍໃຊ້ `Vec` ແລະໃຊ້ມັນ ສຳ ລັບສິ່ງອື່ນ (ບໍ່ວ່າຈະຜ່ານລະຫັດທີ່ບໍ່ປອດໄພຫລືສ້າງລະບົບເກັບ ກຳ ຂໍ້ມູນທີ່ເກັບຄວາມຊົງ ຈຳ ຂອງທ່ານເອງ), ໃຫ້ແນ່ໃຈວ່າ ເພື່ອ deallocate ຄວາມຊົງຈໍານີ້ໂດຍການນໍາໃຊ້ `from_raw_parts` ຈະຟື້ນຕົວຂອງ `Vec` ແລະຫຼັງຈາກນັ້ນຫຼຸດລົງມັນ.
///
/// ຖ້າ `Vec`*ມີ* ຈັດສັນຄວາມ ຈຳ, ຫຼັງຈາກນັ້ນ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ມັນ ໝາຍ ເຖິງຢູ່ໃນຮວບຮວມ (ຕາມທີ່ ກຳ ນົດໂດຍຜູ້ຈັດສັນ Rust ຖືກ ກຳ ນົດໃຫ້ໃຊ້ໂດຍຄ່າເລີ່ມຕົ້ນ), ແລະຕົວຊີ້ຂອງມັນຊີ້ໃຫ້ [`len`] ເລີ່ມຕົ້ນ, ອົງປະກອບທີ່ຕິດຕໍ່ກັນ (ຕາມທີ່ທ່ານຕ້ອງການ ເບິ່ງວ່າທ່ານໄດ້ບັງຄັບມັນເປັນທ່ອນໆ), ຕາມດ້ວຍ [`ຄວາມສາມາດ`] `,` [`len`] ຢ່າງມີເຫດຜົນ, ອົງປະກອບທີ່ຕິດຕໍ່ກັນ.
///
///
/// A vector ປະກອບດ້ວຍອົງປະກອບ `'a'` ແລະ `'b'` ທີ່ມີຄວາມສາມາດ 4 ສາມາດເບິ່ງເຫັນໄດ້ດັ່ງລຸ່ມນີ້.ສ່ວນເທິງແມ່ນໂຄງສ້າງ `Vec`, ມັນມີຕົວຊີ້ໄປທີ່ຫົວຂອງການຈັດສັນໃນຄວາມຍາວ, ຄວາມຍາວແລະຄວາມສາມາດ.
/// ສ່ວນລຸ່ມແມ່ນການຈັດສັນໃຫ້ຢູ່ເທິງ heap, ທ່ອນຄວາມຊົງ ຈຳ ທີ່ຕິດຕໍ່ກັນ.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** ສະແດງຄວາມ ຈຳ ທີ່ບໍ່ໄດ້ເລີ່ມຕົ້ນ, ເບິ່ງ [`MaybeUninit`].
/// - Note: ABI ບໍ່ມີຄວາມ ໝັ້ນ ຄົງແລະ `Vec` ບໍ່ມີການຄ້ ຳ ປະກັນໃດໆກ່ຽວກັບຮູບແບບຄວາມ ຈຳ ຂອງມັນ (ລວມທັງ ຄຳ ສັ່ງຂອງທົ່ງນາ).
///
/// `Vec` ຈະບໍ່ປະຕິບັດ "small optimization" ບ່ອນທີ່ສ່ວນປະກອບຕ່າງໆຖືກເກັບຮັກສາໄວ້ໃນຊັ້ນວາງດ້ວຍເຫດຜົນສອງຢ່າງ:
///
/// * ມັນຈະເຮັດໃຫ້ມັນຍາກກວ່າ ສຳ ລັບລະຫັດທີ່ບໍ່ປອດໄພໃນການຈັດການກັບ `Vec` ຢ່າງຖືກຕ້ອງ.ເນື້ອໃນຂອງ `Vec` ຈະບໍ່ມີທີ່ຢູ່ທີ່ ໝັ້ນ ຄົງຖ້າມັນຖືກຍ້າຍພຽງເທົ່ານັ້ນ, ແລະມັນກໍ່ຈະເປັນການຍາກທີ່ຈະ ກຳ ນົດວ່າ `Vec` ໄດ້ຈັດສັນຄວາມຊົງ ຈຳ ຢ່າງແທ້ຈິງຫຼືບໍ່.
///
/// * ມັນຈະລົງໂທດຄະດີທົ່ວໄປ, ເຊິ່ງເກີດຂື້ນກັບ branch ເພີ່ມເຕີມໃນທຸກໆການເຂົ້າເຖິງ.
///
/// `Vec` ຈະບໍ່ຫົດຕົວຂອງມັນເອງໂດຍອັດຕະໂນມັດ, ເຖິງແມ່ນວ່າມັນຈະບໍ່ ໝົດ ກໍ່ຕາມ.ນີ້ຮັບປະກັນບໍ່ມີການຈັດສັນຫລືການຈັດສັນທີ່ບໍ່ ຈຳ ເປັນເກີດຂື້ນ.ການຖິ້ມ `Vec` ແລະການຕື່ມຂໍ້ມູນໃສ່ [`len`] ດຽວກັນກໍ່ຄວນຈະບໍ່ມີການໂທຫາຜູ້ຈັດສັນ.ຖ້າຫາກວ່າທ່ານຕ້ອງການທີ່ຈະບໍ່ເສຍຄ່າຂຶ້ນຄວາມຊົງຈໍາທີ່ບໍ່ໄດ້ໃຊ້, ໃຊ້ [`shrink_to_fit`] ຫຼື [`shrink_to`].
///
/// [`push`] ແລະ [`insert`] ຈະບໍ່ (re) ຈັດສັນຖ້າຫາກວ່າຄວາມອາດສາມາດລາຍງານໄດ້ເປັນພຽງພໍ.[`push`] ແລະ [`insert`]*ຈະ*(re) ຈັດສັນຖ້າຫາກວ່າ [`len`]`==`[`capacity`].ນັ້ນແມ່ນ, ຄວາມສາມາດໃນການລາຍງານແມ່ນຖືກຕ້ອງຄົບຖ້ວນ, ແລະສາມາດອີງໃສ່ໄດ້.ມັນສາມາດເຖິງແມ່ນວ່າຈະໄດ້ຮັບການນໍາໃຊ້ດ້ວຍຕົນເອງເສຍຄ່າຫນ່ວຍຄວາມຈໍາທີ່ຈັດສັນໂດຍ `Vec` ຖ້າຕ້ອງການ.
/// ບັນດາວິທີການແຊກຊືມມະຫາຊົນ *ອາດຈະ* ຈັດສັນທີ່ຢູ່ເຖິງແມ່ນວ່າບໍ່ ຈຳ ເປັນກໍ່ຕາມ.
///
/// `Vec` ບໍ່ຮັບປະກັນຍຸດທະສາດການຂະຫຍາຍຕົວໂດຍສະເພາະໃນເວລາທີ່ການຈັດສັນເວລາເຕັມ, ຫຼືເມື່ອ [`reserve`] ຖືກເອີ້ນ.ຍຸດທະສາດໃນປະຈຸບັນແມ່ນພື້ນຖານແລະມັນອາດຈະພິສູດຄວາມປາຖະ ໜາ ທີ່ຈະ ນຳ ໃຊ້ປັດໄຈການເຕີບໂຕທີ່ບໍ່ ໝັ້ນ ຄົງ.ຍຸດທະສາດໃດກໍ່ຕາມທີ່ຖືກ ນຳ ໃຊ້ແນ່ນອນຈະຮັບປະກັນ *O*(1) ຫຼຸດຜ່ອນ [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]` ແລະ [`Vec::with_capacity(n)`][`Vec::with_capacity`], ທັງຫມົດຈະຜະລິດເປັນ `Vec` ມີແທ້ຄວາມສາມາດໃນການຮ້ອງຂໍ.
/// ຖ້າ [`len`]`==`[`ຄວາມສາມາດ`], (ຄືກັບກໍລະນີມະຫາພາກ [`vec!`]), ຫຼັງຈາກນັ້ນ `Vec<T>` ສາມາດປ່ຽນເປັນແລະຈາກ [`Box<[T]>`][owned slice] ໂດຍບໍ່ຕ້ອງຍ້າຍຫຼືຍ້າຍອົງປະກອບ.
///
/// `Vec` ຈະບໍ່ຂຽນຂໍ້ມູນໃດໆທີ່ຖືກລຶບອອກຈາກມັນໂດຍສະເພາະ, ແຕ່ວ່າມັນຈະບໍ່ເກັບຮັກສາໄວ້ໂດຍສະເພາະ.ຄວາມຊົງ ຈຳ ທີ່ບໍ່ໄດ້ຕັ້ງໃຈຂອງມັນແມ່ນພື້ນທີ່ທີ່ມັນອາດຈະໃຊ້ຢ່າງໃດກໍ່ຕາມມັນຕ້ອງການ.ໂດຍທົ່ວໄປມັນພຽງແຕ່ຈະເຮັດສິ່ງໃດກໍ່ຕາມທີ່ມີປະສິດທິພາບຫຼາຍທີ່ສຸດຫຼືຖ້າບໍ່ດັ່ງນັ້ນງ່າຍຕໍ່ການຈັດຕັ້ງປະຕິບັດຢ່າອີງໃສ່ຂໍ້ມູນທີ່ຖືກລຶບອອກເພື່ອຖືກລຶບລ້າງເພື່ອຈຸດປະສົງຄວາມປອດໄພ.
/// ເຖິງແມ່ນວ່າທ່ານຈະລຸດ `Vec`, ຊ່ອງຫວ່າງຂອງມັນກໍ່ອາດຈະຖືກໃຊ້ຄືນໂດຍ `Vec` ອື່ນ.
/// ເຖິງແມ່ນວ່າທ່ານຈະ ທຳ ຄວາມຊົງ ຈຳ ຂອງ `Vec` ກ່ອນ, ມັນອາດຈະບໍ່ເກີດຂື້ນແທ້ເພາະວ່າຕົວເພີ່ມປະສິດທິພາບບໍ່ໄດ້ພິຈາລະນາວ່ານີ້ແມ່ນຜົນຂ້າງຄຽງທີ່ຕ້ອງໄດ້ຮັບການຮັກສາໄວ້.
/// ມີກໍລະນີ ໜຶ່ງ ທີ່ພວກເຮົາຈະບໍ່ ທຳ ລາຍ, ເຖິງຢ່າງໃດກໍ່ຕາມ: ການໃຊ້ລະຫັດ `unsafe` ເພື່ອຂຽນໃສ່ຄວາມສາມາດເກີນ, ແລະຈາກນັ້ນເພີ່ມຄວາມຍາວໃຫ້ກົງກັບ, ມັນຖືກຕ້ອງສະ ເໝີ ໄປ.
///
/// ໃນປະຈຸບັນ, `Vec` ບໍ່ໄດ້ຮັບປະກັນຄວາມເປັນລະບຽບຮຽບຮ້ອຍທີ່ອົງປະກອບຖືກລຸດລົງ.
/// ຄຳ ສັ່ງດັ່ງກ່າວໄດ້ປ່ຽນແປງໃນອະດີດແລະອາດຈະປ່ຽນ ໃໝ່ ອີກຄັ້ງ.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// ວິທີການປະກົດຂຶ້ນ
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// ກໍ່ສ້າງ `Vec<T>` ເປົ່າ ໃໝ່.
    ///
    /// The vector ຈະບໍ່ຈັດສັນຈົນກ່ວາອົງປະກອບຖືກຍູ້ໃສ່ມັນ.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// ກໍ່ສ້າງ `Vec<T>` ແບບ ໃໝ່, ຫວ່າງເປົ່າທີ່ມີຄວາມສາມາດລະບຸ.
    ///
    /// vector ຈະສາມາດຍຶດອົງປະກອບ `capacity` ຢ່າງແນ່ນອນໂດຍບໍ່ ຈຳ ເປັນຕ້ອງແບ່ງປັນ.
    /// ຖ້າ `capacity` ແມ່ນ 0, vector ຈະບໍ່ຈັດສັນ.
    ///
    /// ມັນເປັນສິ່ງສໍາຄັນທີ່ຈະສັງເກດວ່າເຖິງແມ່ນວ່າການກັບຄືນ vector ມີຄວາມສາມາດ * * ກໍານົດໄວ້, ໄດ້ vector ຈະມີຄວາມຍາວ *ສູນ*.
    ///
    /// ສຳ ລັບ ຄຳ ອະທິບາຍກ່ຽວກັບຄວາມແຕກຕ່າງລະຫວ່າງຄວາມຍາວແລະຄວາມສາມາດ, ໃຫ້ເບິ່ງ *[ຄວາມອາດສາມາດແລະການຈັດສັນທີ່ແທ້ຈິງ]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // The vector ບໍ່ມີສິນຄ້າ, ເຖິງແມ່ນວ່າມັນມີຄວາມສາມາດຫຼາຍ
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ສິ່ງເຫລົ່ານີ້ລ້ວນແຕ່ເຮັດໄດ້ໂດຍບໍ່ຕ້ອງແບ່ງປັນ ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ແຕ່ນີ້ອາດຈະເຮັດໃຫ້ vector ຈັດສັນທີ່ຢູ່
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// ສ້າງ `Vec<T>` ໂດຍກົງຈາກສ່ວນປະກອບດິບຂອງ vector ອື່ນ.
    ///
    /// # Safety
    ///
    /// ນີ້ບໍ່ປອດໄພສູງ, ຍ້ອນ ຈຳ ນວນທະຫານທີ່ບໍ່ໄດ້ຖືກກວດກາ:
    ///
    /// * `ptr` ຕ້ອງການໄດ້ຮັບການຈັດສັນຜ່ານມາຜ່ານ [`String`]/`Vec<T>`(ຢ່າງ ໜ້ອຍ ມັນອາດຈະບໍ່ຖືກຕ້ອງຖ້າບໍ່ແມ່ນ).
    /// * `T` ຕ້ອງມີຂະ ໜາດ ແລະຄວາມສອດຄ່ອງຄືກັນກັບສິ່ງທີ່ `ptr` ຖືກຈັດສັນໄວ້.
    ///   (`T` ມີການຈັດຕໍາ ແໜ່ງ ທີ່ເຂັ້ມງວດ ໜ້ອຍ ກວ່ານີ້ແມ່ນບໍ່ພຽງພໍ, ການຈັດຕໍາ ແໜ່ງ ກໍ່ຕ້ອງມີຄວາມເທົ່າທຽມກັນເພື່ອຕອບສະ ໜອງ ກັບຄວາມຕ້ອງການຂອງ [`dealloc`] ທີ່ຄວາມຈໍາຕ້ອງໄດ້ຈັດສັນແລະຈັດການກັບຮູບແບບດຽວກັນ.)
    ///
    /// * `length` ຄວາມຕ້ອງການທີ່ຈະຫນ້ອຍກ່ວາຫຼືເທົ່າທຽມກັນທີ່ `capacity`.
    /// * `capacity` ຕ້ອງເປັນຄວາມອາດສາມາດທີ່ຕົວຊີ້ບອກໄດ້ຖືກຈັດສັນໄວ້ກັບ.
    ///
    /// ການລະເມີດສິ່ງເຫລົ່ານີ້ອາດຈະເຮັດໃຫ້ເກີດບັນຫາເຊັ່ນການສໍ້ລາດບັງຫຼວງໂຄງສ້າງຂໍ້ມູນພາຍໃນຂອງຜູ້ຈັດສັນ.ຕົວຢ່າງມັນບໍ່ແມ່ນ ** ປອດໄພທີ່ຈະສ້າງ `Vec<u8>` ຈາກຕົວຊີ້ໄປຫາຂບວນ C `char` ທີ່ມີຄວາມຍາວ `size_t`.
    /// ມັນກໍ່ບໍ່ປອດໄພທີ່ຈະສ້າງ ໜຶ່ງ ຈາກ `Vec<u16>` ແລະຄວາມຍາວຂອງມັນ, ເພາະວ່າຜູ້ຈັດສັນສົນໃຈກັບຄວາມສອດຄ່ອງ, ແລະສອງປະເພດນີ້ມີຄວາມສອດຄ່ອງແຕກຕ່າງກັນ.
    /// buffer ໄດ້ຖືກຈັດສັນກັບການຈັດຕໍາ ແໜ່ງ 2 (ສຳ ລັບ `u16`), ແຕ່ຫຼັງຈາກປ່ຽນເປັນ `Vec<u8>` ມັນຈະມີການຈັດສັນກັບການຈັດຕໍາ ແໜ່ງ 1.
    ///
    /// ຄວາມເປັນເຈົ້າຂອງ `ptr` ໄດ້ຖືກຍົກຍ້າຍປະສິດທິພາບກັບ `Vec<T>` ຊຶ່ງຫຼັງຈາກນັ້ນອາດຈະ deallocate, Reallocation ຫຼືມີການປ່ຽນແປງເນື້ອໃນຂອງຄວາມຊົງຈໍາທີ່ຊີ້ໄປຕາມຊີ້ໄດ້ທີ່ຈະ.
    /// ຮັບປະກັນວ່າບໍ່ມີຫຍັງອີກທີ່ໃຊ້ຕົວຊີ້ຫຼັງຈາກໂທຫາຟັງຊັ່ນນີ້.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME ປັບປຸງນີ້ເມື່ອ vec_into_raw_parts ມີສະຖຽນລະພາບ.
    ///     // ປ້ອງກັນການແລ່ນຂອງຜູ້ ທຳ ລາຍ `v` ດັ່ງນັ້ນພວກເຮົາຢູ່ໃນການຄວບຄຸມການຈັດສັນທີ່ສົມບູນ.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // ດຶງຊິ້ນສ່ວນ ສຳ ຄັນຕ່າງໆຂອງຂໍ້ມູນກ່ຽວກັບ `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // ທັບຊ້ອນຄວາມຊົງ ຈຳ ດ້ວຍ 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // ເອົາທຸກສິ່ງທຸກຢ່າງກັບກັນເຂົ້າໄປໃນ Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// ກໍ່ສ້າງ `Vec<T, A>` ເປົ່າ ໃໝ່.
    ///
    /// The vector ຈະບໍ່ຈັດສັນຈົນກ່ວາອົງປະກອບຖືກຍູ້ໃສ່ມັນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// ໂຄງສ້າງໃຫມ່, empty `Vec<T, A>` ກັບຄວາມອາດສາມາດລະບຸໄດ້ດ້ວຍຕົວຈັດສັນໃຫ້.
    ///
    /// vector ຈະສາມາດຍຶດອົງປະກອບ `capacity` ຢ່າງແນ່ນອນໂດຍບໍ່ ຈຳ ເປັນຕ້ອງແບ່ງປັນ.
    /// ຖ້າ `capacity` ແມ່ນ 0, vector ຈະບໍ່ຈັດສັນ.
    ///
    /// ມັນເປັນສິ່ງສໍາຄັນທີ່ຈະສັງເກດວ່າເຖິງແມ່ນວ່າການກັບຄືນ vector ມີຄວາມສາມາດ * * ກໍານົດໄວ້, ໄດ້ vector ຈະມີຄວາມຍາວ *ສູນ*.
    ///
    /// ສຳ ລັບ ຄຳ ອະທິບາຍກ່ຽວກັບຄວາມແຕກຕ່າງລະຫວ່າງຄວາມຍາວແລະຄວາມສາມາດ, ໃຫ້ເບິ່ງ *[ຄວາມອາດສາມາດແລະການຈັດສັນທີ່ແທ້ຈິງ]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // The vector ບໍ່ມີສິນຄ້າ, ເຖິງແມ່ນວ່າມັນມີຄວາມສາມາດຫຼາຍ
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ສິ່ງເຫລົ່ານີ້ລ້ວນແຕ່ເຮັດໄດ້ໂດຍບໍ່ຕ້ອງແບ່ງປັນ ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... ແຕ່ນີ້ອາດຈະເຮັດໃຫ້ vector ຈັດສັນທີ່ຢູ່
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// ສ້າງ `Vec<T, A>` ໂດຍກົງຈາກອົງປະກອບເປັນວັດຖຸດິບຂອງ vector ອື່ນ.
    ///
    /// # Safety
    ///
    /// ນີ້ບໍ່ປອດໄພສູງ, ຍ້ອນ ຈຳ ນວນທະຫານທີ່ບໍ່ໄດ້ຖືກກວດກາ:
    ///
    /// * `ptr` ຕ້ອງການໄດ້ຮັບການຈັດສັນຜ່ານມາຜ່ານ [`String`]/`Vec<T>`(ຢ່າງ ໜ້ອຍ ມັນອາດຈະບໍ່ຖືກຕ້ອງຖ້າບໍ່ແມ່ນ).
    /// * `T` ຕ້ອງມີຂະ ໜາດ ແລະຄວາມສອດຄ່ອງຄືກັນກັບສິ່ງທີ່ `ptr` ຖືກຈັດສັນໄວ້.
    ///   (`T` ມີການຈັດຕໍາ ແໜ່ງ ທີ່ເຂັ້ມງວດ ໜ້ອຍ ກວ່ານີ້ແມ່ນບໍ່ພຽງພໍ, ການຈັດຕໍາ ແໜ່ງ ກໍ່ຕ້ອງມີຄວາມເທົ່າທຽມກັນເພື່ອຕອບສະ ໜອງ ກັບຄວາມຕ້ອງການຂອງ [`dealloc`] ທີ່ຄວາມຈໍາຕ້ອງໄດ້ຈັດສັນແລະຈັດການກັບຮູບແບບດຽວກັນ.)
    ///
    /// * `length` ຄວາມຕ້ອງການທີ່ຈະຫນ້ອຍກ່ວາຫຼືເທົ່າທຽມກັນທີ່ `capacity`.
    /// * `capacity` ຕ້ອງເປັນຄວາມອາດສາມາດທີ່ຕົວຊີ້ບອກໄດ້ຖືກຈັດສັນໄວ້ກັບ.
    ///
    /// ການລະເມີດສິ່ງເຫລົ່ານີ້ອາດຈະເຮັດໃຫ້ເກີດບັນຫາເຊັ່ນການສໍ້ລາດບັງຫຼວງໂຄງສ້າງຂໍ້ມູນພາຍໃນຂອງຜູ້ຈັດສັນ.ຕົວຢ່າງມັນບໍ່ແມ່ນ ** ປອດໄພທີ່ຈະສ້າງ `Vec<u8>` ຈາກຕົວຊີ້ໄປຫາຂບວນ C `char` ທີ່ມີຄວາມຍາວ `size_t`.
    /// ມັນກໍ່ບໍ່ປອດໄພທີ່ຈະສ້າງ ໜຶ່ງ ຈາກ `Vec<u16>` ແລະຄວາມຍາວຂອງມັນ, ເພາະວ່າຜູ້ຈັດສັນສົນໃຈກັບຄວາມສອດຄ່ອງ, ແລະສອງປະເພດນີ້ມີຄວາມສອດຄ່ອງແຕກຕ່າງກັນ.
    /// buffer ໄດ້ຖືກຈັດສັນກັບການຈັດຕໍາ ແໜ່ງ 2 (ສຳ ລັບ `u16`), ແຕ່ຫຼັງຈາກປ່ຽນເປັນ `Vec<u8>` ມັນຈະມີການຈັດສັນກັບການຈັດຕໍາ ແໜ່ງ 1.
    ///
    /// ຄວາມເປັນເຈົ້າຂອງ `ptr` ໄດ້ຖືກຍົກຍ້າຍປະສິດທິພາບກັບ `Vec<T>` ຊຶ່ງຫຼັງຈາກນັ້ນອາດຈະ deallocate, Reallocation ຫຼືມີການປ່ຽນແປງເນື້ອໃນຂອງຄວາມຊົງຈໍາທີ່ຊີ້ໄປຕາມຊີ້ໄດ້ທີ່ຈະ.
    /// ຮັບປະກັນວ່າບໍ່ມີຫຍັງອີກທີ່ໃຊ້ຕົວຊີ້ຫຼັງຈາກໂທຫາຟັງຊັ່ນນີ້.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME ປັບປຸງນີ້ເມື່ອ vec_into_raw_parts ມີສະຖຽນລະພາບ.
    ///     // ປ້ອງກັນການແລ່ນຂອງຜູ້ ທຳ ລາຍ `v` ດັ່ງນັ້ນພວກເຮົາຢູ່ໃນການຄວບຄຸມການຈັດສັນທີ່ສົມບູນ.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // ດຶງຊິ້ນສ່ວນ ສຳ ຄັນຕ່າງໆຂອງຂໍ້ມູນກ່ຽວກັບ `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // ທັບຊ້ອນຄວາມຊົງ ຈຳ ດ້ວຍ 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // ເອົາທຸກສິ່ງທຸກຢ່າງກັບກັນເຂົ້າໄປໃນ Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Decomposes `Vec<T>` ເປັນສ່ວນປະກອບວັດຖຸດິບຂອງມັນ.
    ///
    /// ສົ່ງຄືນຕົວຊີ້ວັດຖຸດິບກັບຂໍ້ມູນທີ່ຢູ່ເບື້ອງຕົ້ນ, ຄວາມຍາວຂອງ vector (ໃນອົງປະກອບ), ແລະຄວາມສາມາດໃນການຈັດສັນຂອງຂໍ້ມູນ (ໃນອົງປະກອບ).
    /// ເຫຼົ່ານີ້ແມ່ນການໂຕ້ຖຽງດຽວກັນໃນຄໍາສັ່ງດຽວກັນກັບການໂຕ້ຖຽງກັບ [`from_raw_parts`].
    ///
    /// ຫຼັງຈາກການເອີ້ນຟັງຊັນນີ້, ຜູ້ໂທຈະຕ້ອງຮັບຜິດຊອບຕໍ່ຄວາມຊົງ ຈຳ ທີ່ຈັດການໂດຍ `Vec` ກ່ອນ ໜ້າ ນີ້.
    /// ວິທີດຽວທີ່ຈະເຮັດຄືການແປງຕົວຊີ້ວັດ, ຄວາມຍາວແລະຄວາມສາມາດໃຫ້ກັບມາເປັນ `Vec` ກັບຟັງຊັນ [`from_raw_parts`], ເຮັດໃຫ້ຜູ້ ທຳ ລາຍ ທຳ ລາຍຄວາມສະອາດ.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // ດຽວນີ້ພວກເຮົາສາມາດປ່ຽນແປງອົງປະກອບຕ່າງໆ, ເຊັ່ນ: ການສົ່ງຕົວຊີ້ວັດຖຸດິບໄປສູ່ປະເພດທີ່ ເໝາະ ສົມ.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Decomposes `Vec<T>` ເປັນສ່ວນປະກອບວັດຖຸດິບຂອງມັນ.
    ///
    /// ສົ່ງຄືນຕົວຊີ້ວັດຖຸດິບກັບຂໍ້ມູນທີ່ຢູ່ເບື້ອງຕົ້ນ, ຄວາມຍາວຂອງ vector (ໃນອົງປະກອບ), ຄວາມສາມາດໃນການຈັດສັນຂໍ້ມູນ (ໃນອົງປະກອບ), ແລະຜູ້ຈັດສັນ.
    /// ເຫຼົ່ານີ້ແມ່ນການໂຕ້ຖຽງດຽວກັນໃນຄໍາສັ່ງດຽວກັນກັບການໂຕ້ຖຽງກັບ [`from_raw_parts_in`].
    ///
    /// ຫຼັງຈາກການເອີ້ນຟັງຊັນນີ້, ຜູ້ໂທຈະຕ້ອງຮັບຜິດຊອບຕໍ່ຄວາມຊົງ ຈຳ ທີ່ຈັດການໂດຍ `Vec` ກ່ອນ ໜ້າ ນີ້.
    /// ວິທີດຽວທີ່ຈະເຮັດຄືການແປງຕົວຊີ້ວັດ, ຄວາມຍາວແລະຄວາມສາມາດໃຫ້ກັບມາເປັນ `Vec` ກັບຟັງຊັນ [`from_raw_parts_in`], ເຮັດໃຫ້ຜູ້ ທຳ ລາຍ ທຳ ລາຍຄວາມສະອາດ.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // ດຽວນີ້ພວກເຮົາສາມາດປ່ຽນແປງອົງປະກອບຕ່າງໆ, ເຊັ່ນ: ການສົ່ງຕົວຊີ້ວັດຖຸດິບໄປສູ່ປະເພດທີ່ ເໝາະ ສົມ.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// ກັບຄືນ ຈຳ ນວນຂອງສ່ວນປະກອບທີ່ vector ສາມາດຖືໄດ້ໂດຍບໍ່ ຈຳ ແນກ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// ສະຫງວນຄວາມອາດສາມາດໃຫ້ຢ່າງ ໜ້ອຍ `additional` ອົງປະກອບເພີ່ມເຕີມທີ່ຈະເອົາເຂົ້າໃນ `Vec<T>` ທີ່ໃຫ້.
    /// ການເກັບ ກຳ ຂໍ້ມູນດັ່ງກ່າວອາດຈະສະຫງວນເນື້ອທີ່ຫຼາຍຂື້ນເພື່ອຫລີກລ້ຽງການຈັດສັນທີ່ຢູ່ເລື້ອຍໆ.
    /// ຫຼັງຈາກການໂທຫາ `reserve`, ຄວາມສາມາດຈະຫຼາຍກ່ວາຫຼືເທົ່າກັບ `self.len() + additional`.
    /// ບໍ່ມີຫຍັງເຮັດຖ້າຄວາມສາມາດພຽງພໍແລ້ວ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຄວາມສາມາດໃຫມ່ເກີນ bytes `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// ສະຫງວນຄວາມອາດສາມາດຕ່ ຳ ສຸດ ສຳ ລັບອົງປະກອບເພີ່ມເຕີມ `additional` ທີ່ຈະຖືກໃສ່ເຂົ້າໃນ `Vec<T>` ທີ່ໃຫ້.
    ///
    /// ຫຼັງຈາກການໂທຫາ `reserve_exact`, ຄວາມສາມາດຈະຫຼາຍກ່ວາຫຼືເທົ່າກັບ `self.len() + additional`.
    /// ບໍ່ມີຫຍັງເຮັດຖ້າຄວາມສາມາດພຽງພໍແລ້ວ.
    ///
    /// ຈົ່ງສັງເກດວ່າຜູ້ຈັດສັນອາດຈະໃຫ້ຫ້ອງເກັບຫຼາຍກວ່າທີ່ມັນຮ້ອງຂໍ.
    /// ສະນັ້ນ, ຄວາມສາມາດບໍ່ສາມາດເພິ່ງພາໄດ້ຢ່າງ ໜ້ອຍ ແນ່ນອນ.
    /// ມັກ `reserve` ຖ້າມີຄວາມຄາດຫວັງຂອງ future.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຄວາມສາມາດ ໃໝ່ ລົ້ນ `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// ພະຍາຍາມສະຫງວນຄວາມສາມາດໃຫ້ຢ່າງ ໜ້ອຍ `additional` ອົງປະກອບເພີ່ມເຕີມທີ່ຈະເອົາເຂົ້າໃນ `Vec<T>` ທີ່ໄດ້ມອບໃຫ້.
    /// ການເກັບ ກຳ ຂໍ້ມູນດັ່ງກ່າວອາດຈະສະຫງວນເນື້ອທີ່ຫຼາຍຂື້ນເພື່ອຫລີກລ້ຽງການຈັດສັນທີ່ຢູ່ເລື້ອຍໆ.
    /// ຫຼັງຈາກການໂທຫາ `try_reserve`, ຄວາມສາມາດຈະຫຼາຍກ່ວາຫຼືເທົ່າກັບ `self.len() + additional`.
    /// ບໍ່ມີຫຍັງເຮັດຖ້າຄວາມສາມາດພຽງພໍແລ້ວ.
    ///
    /// # Errors
    ///
    /// ຖ້າຄວາມສາມາດລົ້ນ, ຫຼືຜູ້ຈັດລາຍງານລາຍງານຄວາມລົ້ມເຫລວ, ຫຼັງຈາກນັ້ນຄວາມຜິດພາດຈະຖືກສົ່ງຄືນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // ຈັດເກັບຄວາມຊົງ ຈຳ ໄວ້ກ່ອນ, ຖ້າພວກເຮົາບໍ່ສາມາດເຮັດໄດ້
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ໃນປັດຈຸບັນພວກເຮົາຮູ້ວ່ານີ້ບໍ່ສາມາດ OOM ຢູ່ເຄິ່ງກາງຂອງວຽກງານທີ່ສັບສົນຂອງພວກເຮົາ
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ສັບສົນຫຼາຍ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// ພະຍາຍາມສະຫງວນຄວາມອາດສາມາດຕ່ ຳ ສຸດ ສຳ ລັບອົງປະກອບ `additional` ຢ່າງແນ່ນອນທີ່ຈະເອົາເຂົ້າໃນ `Vec<T>` ທີ່ໄດ້ມອບໃຫ້.
    /// ຫລັງຈາກໂທຫາ `try_reserve_exact`, ຄວາມສາມາດຈະໃຫຍ່ກວ່າຫລືເທົ່າກັບ `self.len() + additional` ຖ້າມັນກັບຄືນ `Ok(())`.
    ///
    /// ບໍ່ມີຫຍັງເຮັດຖ້າຄວາມສາມາດພຽງພໍແລ້ວ.
    ///
    /// ຈົ່ງສັງເກດວ່າຜູ້ຈັດສັນອາດຈະໃຫ້ຫ້ອງເກັບຫຼາຍກວ່າທີ່ມັນຮ້ອງຂໍ.
    /// ສະນັ້ນ, ຄວາມສາມາດບໍ່ສາມາດເພິ່ງພາໄດ້ຢ່າງ ໜ້ອຍ ແນ່ນອນ.
    /// ມັກ `reserve` ຖ້າມີຄວາມຄາດຫວັງຂອງ future.
    ///
    /// # Errors
    ///
    /// ຖ້າຄວາມສາມາດລົ້ນ, ຫຼືຜູ້ຈັດລາຍງານລາຍງານຄວາມລົ້ມເຫລວ, ຫຼັງຈາກນັ້ນຄວາມຜິດພາດຈະຖືກສົ່ງຄືນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // ຈັດເກັບຄວາມຊົງ ຈຳ ໄວ້ກ່ອນ, ຖ້າພວກເຮົາບໍ່ສາມາດເຮັດໄດ້
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // ໃນປັດຈຸບັນພວກເຮົາຮູ້ວ່ານີ້ບໍ່ສາມາດ OOM ຢູ່ເຄິ່ງກາງຂອງວຽກງານທີ່ສັບສົນຂອງພວກເຮົາ
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ສັບສົນຫຼາຍ
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// ຫຼຸດຄວາມສາມາດຂອງ vector ໃຫ້ຫຼາຍເທົ່າທີ່ເປັນໄປໄດ້.
    ///
    /// ມັນຈະລຸດລົງຢ່າງໃກ້ຊິດທີ່ສຸດເທົ່າທີ່ຈະເປັນໄປໄດ້ກັບຄວາມຍາວແຕ່ຜູ້ຈັດສັນອາດຈະແຈ້ງໃຫ້ vector ຮູ້ວ່າມັນມີພື້ນທີ່ ສຳ ລັບອົງປະກອບອີກສອງສາມຢ່າງ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // ຄວາມສາມາດບໍ່ຕໍ່າກວ່າຄວາມຍາວ, ແລະບໍ່ມີຫຍັງເຮັດເມື່ອພວກເຂົາເທົ່າທຽມກັນ, ດັ່ງນັ້ນພວກເຮົາສາມາດຫລີກລ້ຽງກໍລະນີ panic ໃນ `RawVec::shrink_to_fit` ໂດຍພຽງແຕ່ເອີ້ນມັນດ້ວຍຄວາມສາມາດສູງກວ່າ.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// ຫຼຸດຜ່ອນຄວາມສາມາດຂອງ vector ດ້ວຍຄວາມຜູກພັນຕ່ໍາ.
    ///
    /// ຄວາມອາດສາມາດຈະຍັງຄົງຢູ່ຢ່າງຫນ້ອຍທັງຄວາມຍາວແລະມູນຄ່າການສະ ໜອງ.
    ///
    ///
    /// ຖ້າຄວາມສາມາດໃນປະຈຸບັນຕ່ ຳ ກ່ວາຂີດ ຈຳ ກັດຕ່ ຳ, ນີ້ແມ່ນສິ່ງທີ່ບໍ່ມີ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// ແປງ vector ເປັນ [`Box<[T]>`][owned slice].
    ///
    /// ໃຫ້ສັງເກດວ່ານີ້ຈະລຸດລົງຄວາມອາດສາມາດເກີນ.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// ຄວາມອາດສາມາດເກີນທີ່ຖືກຍ້າຍອອກ:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// ເຮັດໃຫ້ vector ສັ້ນລົງ, ຮັກສາ `len` ທຳ ອິດແລະລຸດສ່ວນທີ່ເຫຼືອ.
    ///
    /// ຖ້າ `len` ໃຫຍ່ກວ່າຄວາມຍາວໃນປະຈຸບັນຂອງ vector, ນີ້ບໍ່ມີຜົນຫຍັງເລີຍ.
    ///
    /// ວິທີການ [`drain`] ສາມາດເຮັດຕາມຕົວຢ່າງ `truncate`, ແຕ່ເຮັດໃຫ້ອົງປະກອບສ່ວນເກີນທີ່ຈະກັບຄືນມາແທນທີ່ຈະຫຼຸດລົງ.
    ///
    ///
    /// ໃຫ້ສັງເກດວ່າວິທີການນີ້ບໍ່ມີຜົນກະທົບຕໍ່ຄວາມສາມາດຈັດສັນຂອງ vector.
    ///
    /// # Examples
    ///
    /// Truncating ເປັນອົງປະກອບຫ້າ vector ສອງອົງປະກອບ:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// ບໍ່ມີການຕັດສັ້ນໆເກີດຂື້ນເມື່ອ `len` ໃຫຍ່ກວ່າຄວາມຍາວໃນປະຈຸບັນຂອງ vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Truncating ໃນເວລາທີ່ `len == 0` ແມ່ນທຽບເທົ່າກັບໂທຫາໄດ້ວິທີ [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // ນີ້ປອດໄພເພາະວ່າ:
        //
        // * ຫຼັງຈາກນັ້ນ ນຳ ສົ່ງໃຫ້ `drop_in_place` ແມ່ນຖືກຕ້ອງ;ການ `len > self.len` ກໍລະນີຫຼີກເວັ້ນການສ້າງເປັນຫຼັງຈາກນັ້ນນໍາທີ່ບໍ່ຖືກຕ້ອງ, ແລະ
        // * `len` ຂອງ vector ແມ່ນຫົດຕົວກ່ອນທີ່ຈະໂທຫາ `drop_in_place`, ເຊັ່ນວ່າບໍ່ມີມູນຄ່າໃດໆທີ່ຈະຖືກລຸດລົງສອງຄັ້ງໃນກໍລະນີ `drop_in_place` ແມ່ນໄປ panic ຫນຶ່ງຄັ້ງ (ຖ້າມັນ panics ສອງຄັ້ງ, ໂຄງການກໍ່ຈະປະຖິ້ມ).
        //
        //
        //
        unsafe {
            // Note: ມັນມີເຈດຕະນາທີ່ວ່ານີ້ແມ່ນ `>` ແລະບໍ່ແມ່ນ `>=`.
            //       ການປ່ຽນແປງໄປ `>=` ມີຜົນສະທ້ອນການປະຕິບັດໃນທາງລົບໃນບາງກໍລະນີ.
            //       ເບິ່ງ #78884 ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// ສະກັດສ່ວນທີ່ມີ vector ທັງ ໝົດ.
    ///
    /// ເທົ່າກັບ `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// ສະກັດສ່ວນທີ່ສາມາດປ່ຽນແປງໄດ້ຂອງ vector ທັງ ໝົດ.
    ///
    /// ເທົ່າກັບ `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// ສົ່ງເຄື່ອງຊີ້ວັດຖຸດິບໃຫ້ກັບຕົວປ້ອງກັນຂອງ vector.
    ///
    /// ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ vector outlives pointer ຫນ້າທີ່ນີ້ກັບຄືນມາ, ຫຼືຖ້າບໍ່ດັ່ງນັ້ນມັນກໍ່ຈະເປັນຈຸດສິ້ນສຸດທີ່ຊີ້ໃຫ້ເຫັນຂີ້ເຫຍື້ອ.
    /// ການດັດແປງ vector ອາດຈະເຮັດໃຫ້ພື້ນທີ່ປ້ອງກັນຂອງມັນຖືກຈັດສັນ, ເຊິ່ງມັນກໍ່ຈະເຮັດໃຫ້ຕົວຊີ້ບອກໃດໆບໍ່ຖືກຕ້ອງ.
    ///
    /// ຜູ້ໂທຍັງຕ້ອງຮັບປະກັນວ່າ ໜ່ວຍ ຄວາມ ຈຳ ທີ່ຈຸດ XXXX ທີ່ຈະບໍ່ຖືກຂຽນເຖິງ (ຍົກເວັ້ນພາຍໃນ `UnsafeCell`) ໂດຍໃຊ້ຕົວຊີ້ນີ້ຫລືຕົວຊີ້ທີ່ມາຈາກມັນ.
    /// ຖ້າທ່ານຕ້ອງການປ່ຽນເນື້ອໃນຂອງເນື້ອເຫຍື່ອ, ໃຫ້ໃຊ້ [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // ພວກເຮົາເງົາວິທີຫຼັງຈາກນັ້ນນໍາຂອງຊື່ດຽວກັນໄດ້ເພື່ອຫຼີກເວັ້ນການໄປໂດຍຜ່ານການ `deref`, ເຊິ່ງສ້າງເປັນກະສານອ້າງອີງລະດັບປານກາງ.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// ສົ່ງຄືນຕົວຊີ້ທີ່ສາມາດປ່ຽນແປງໄດ້ທີ່ບໍ່ປອດໄພກັບ Zerve0Z's buffer.
    ///
    /// ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ vector outlives pointer ຫນ້າທີ່ນີ້ກັບຄືນມາ, ຫຼືຖ້າບໍ່ດັ່ງນັ້ນມັນກໍ່ຈະເປັນຈຸດສິ້ນສຸດທີ່ຊີ້ໃຫ້ເຫັນຂີ້ເຫຍື້ອ.
    ///
    /// ການດັດແປງ vector ອາດຈະເຮັດໃຫ້ພື້ນທີ່ປ້ອງກັນຂອງມັນຖືກຈັດສັນ, ເຊິ່ງມັນກໍ່ຈະເຮັດໃຫ້ຕົວຊີ້ບອກໃດໆບໍ່ຖືກຕ້ອງ.
    ///
    /// # Examples
    ///
    /// ```
    /// // ຈັດສັນ vector ໃຫຍ່ພໍ ສຳ ລັບ 4 ອົງປະກອບ.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // ເລີ່ມຕົ້ນອົງປະກອບຕ່າງໆຜ່ານຕົວຊີ້ວັດຖຸດິບ, ຈາກນັ້ນໃຫ້ ກຳ ນົດຄວາມຍາວ.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // ພວກເຮົາຮົ່ມວິທີການຕັດຂອງຊື່ດຽວກັນເພື່ອຫລີກລ້ຽງການຍ່າງຜ່ານ `deref_mut`, ເຊິ່ງສ້າງການອ້າງອີງລະດັບກາງ.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// ກັບຄືນເອກະສານອ້າງອີງກັບຜູ້ຈັດສັນພື້ນຖານ.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// ຜົນບັງຄັບໃຊ້ຄວາມຍາວຂອງ vector ກັບ `new_len` ໄດ້.
    ///
    /// ນີ້ແມ່ນການປະຕິບັດງານໃນລະດັບຕໍ່າເຊິ່ງບໍ່ສາມາດຮັກສາປະເພດປົກກະຕິໃດໆຂອງຊະນິດ.
    /// ປົກກະຕິການປ່ຽນແປງຄວາມຍາວຂອງ vector ແມ່ນເຮັດນໍາໃຊ້ຫນຶ່ງໃນການດໍາເນີນງານຄວາມປອດໄພແທນທີ່ຈະເປັນເຊັ່ນ [`truncate`], [`resize`], [`extend`] ຫລື [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` ຕ້ອງຫນ້ອຍກ່ວາຫຼືເທົ່າທຽມກັນທີ່ [`capacity()`].
    /// - ອົງປະກອບທີ່ `old_len..new_len` ຕ້ອງໄດ້ຮັບການເລີ່ມຕົ້ນ.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// ວິທີການນີ້ສາມາດເປັນປະໂຫຍດ ສຳ ລັບສະຖານະການທີ່ vector ກຳ ລັງເຮັດ ໜ້າ ທີ່ປ້ອງກັນລະຫັດອື່ນໆ, ໂດຍສະເພາະໃນໄລຍະ FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // ນີ້ແມ່ນພຽງແຕ່ໂຄງກະດູກ ໜ້ອຍ ທີ່ສຸດ ສຳ ລັບຕົວຢ່າງ doc;
    /// # // ຢ່າໃຊ້ສິ່ງນີ້ເປັນຈຸດເລີ່ມຕົ້ນຂອງຫ້ອງສະມຸດຕົວຈິງ.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // ອີງຕາມເອກະສານຂອງວິທີການຂອງ FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // ຄວາມປອດໄພ: ເມື່ອ `deflateGetDictionary` ກັບຄືນ `Z_OK`, ມັນຖືວ່າ:
    ///     // 1. `dict_length` ອົງປະກອບໄດ້ເລີ່ມຕົ້ນ.
    ///     // 2.
    ///     // `dict_length` <=ຄວາມຈຸ (32_768) ເຊິ່ງເຮັດໃຫ້ `set_len` ປອດໄພໃນການໂທ.
    ///     unsafe {
    ///         // ເຮັດໃຫ້ FFI ໂທຫາ ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... ແລະປັບປຸງຄວາມຍາວໃຫ້ກັບສິ່ງທີ່ໄດ້ເລີ່ມຕົ້ນ.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// ໃນຂະນະທີ່ຕົວຢ່າງຕໍ່ໄປນີ້ແມ່ນມີສຽງ, ມີການຮົ່ວໄຫລຂອງຄວາມຊົງຈໍາເນື່ອງຈາກວ່າ vectors ພາຍໃນບໍ່ໄດ້ຖືກປ່ອຍຕົວກ່ອນການໂທ `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` ແມ່ນຫວ່າງເປົ່າດັ່ງນັ້ນບໍ່ມີອົງປະກອບໃດທີ່ ຈຳ ເປັນຕ້ອງໄດ້ເລີ່ມຕົ້ນ.
    /// // 2. `0 <= capacity` ສະເຫມີຖືສິ່ງໃດກໍ່ຕາມ `capacity` ແມ່ນ.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// ຕາມປົກກະຕິ, ໃນທີ່ນີ້, ຫນຶ່ງຈະໃຊ້ [`clear`] ແທນທີ່ຈະຖືກລົງເນື້ອໃນແລະຄວາມຊົງຈໍາດັ່ງນັ້ນຈຶ່ງບໍ່ຮົ່ວ.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Removes ອົງປະກອບຈາກ vector ແລະຜົນຕອບແທນມັນເປັນ.
    ///
    /// ອົງປະກອບທີ່ຖືກໂຍກຍ້າຍຖືກທົດແທນໂດຍອົງປະກອບສຸດທ້າຍຂອງ vector.
    ///
    /// ນີ້ບໍ່ໄດ້ຮັກສາຄວາມເປັນລະບຽບຮຽບຮ້ອຍ, ແຕ່ແມ່ນ O(1).
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `index` ບໍ່ມີຂອບເຂດ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // ພວກເຮົາທົດແທນຕົນເອງ [ດັດສະນີ] ດ້ວຍອົງປະກອບສຸດທ້າຍ.
            // ໃຫ້ສັງເກດວ່າຖ້າການກວດກາຂອບເຂດຂ້າງເທິງປະສົບຜົນ ສຳ ເລັດຕ້ອງມີອົງປະກອບສຸດທ້າຍ (ເຊິ່ງສາມາດເປັນຕົວມັນເອງ [ດັດສະນີ] ເອງ).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// ໃສ່ອົງປະກອບທີ່ ຕຳ ແໜ່ງ `index` ພາຍໃນ vector, ປ່ຽນທຸກອົງປະກອບຫຼັງຈາກທີ່ມັນຢູ່ທາງຂວາ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // ພື້ນທີ່ສໍາລັບອົງປະກອບຂອງໃຫມ່
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infallible ຈຸດທີ່ຕ້ອງໃສ່ຄ່າ ໃໝ່
            //
            {
                let p = self.as_mut_ptr().add(index);
                // ປ່ຽນທຸກຢ່າງເພື່ອເຮັດພື້ນທີ່.
                // (ເຮັດຊ້ ຳ ຊ້ອນຂອງສ່ວນປະກອບ `ດັດສະນີເປັນສອງສະຖານທີ່ຕິດຕໍ່ກັນ.)
                ptr::copy(p, p.offset(1), len - index);
                // ຂຽນໃສ່, ຂຽນທັບບົດ ສຳ ເນົາຕົ້ນຂອງ `index`th element.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// ລົບແລະຜົນຕອບແທນອົງປະກອບທີ່ຢູ່ໃນຕໍາແຫນ່ງ `index` ພາຍໃນ vector, ສົມການເຄື່ອນຍ້າຍອົງປະກອບທັງຫມົດຫລັງຈາກມັນໄປທາງຊ້າຍ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `index` ບໍ່ມີຂອບເຂດ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // ສະຖານທີ່ທີ່ພວກເຮົາ ກຳ ລັງມາຈາກ.
                let ptr = self.as_mut_ptr().add(index);
                // ສໍາເນົາເອົາມັນອອກ, ບໍ່ປອດໄພມີສໍາເນົາຂອງມູນຄ່າໃນ stack ແລະໃນ vector ແລະໃນເວລາດຽວກັນ.
                //
                ret = ptr::read(ptr);

                // ປ່ຽນທຸກຢ່າງລົງເພື່ອຕື່ມຈຸດນັ້ນ.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// ຮັກສາພຽງແຕ່ອົງປະກອບທີ່ລະບຸໄວ້ໂດຍຜູ້ຄາດຄະເນ.
    ///
    /// ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ເອົາທັງຫມົດອົງປະກອບ `e` ເຊັ່ນວ່າ `f(&e)` ກັບຄືນ `false`.
    /// ວິທີການນີ້ ດຳ ເນີນງານຢູ່ສະຖານທີ່, ຢ້ຽມຢາມແຕ່ລະອົງປະກອບຢ່າງແນ່ນອນເທື່ອ ໜຶ່ງ ຕາມ ລຳ ດັບເດີມ, ແລະຮັກສາຄວາມເປັນລະບຽບຂອງອົງປະກອບທີ່ເກັບຮັກສາໄວ້.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// ເນື່ອງຈາກວ່າອົງປະກອບແມ່ນໄດ້ໄປຢ້ຽມຢາມຢູ່ຄັ້ງຫນຶ່ງໃນການສັ່ງຊື້ຂອງໄດ້, ລັດພາຍນອກອາດຈະຖືກນໍາໃຊ້ເພື່ອຕັດສິນໃຈວ່າອົງປະກອບທີ່ຈະຮັກສາ.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // ຫລີກລ້ຽງການຫຼຸດລົງສອງເທົ່າຖ້າວ່າເຄື່ອງປ້ອງກັນບໍ່ໄດ້ຖືກປະຕິບັດ, ເພາະວ່າພວກເຮົາອາດຈະເຮັດບາງຂຸມໃນລະຫວ່າງຂັ້ນຕອນ.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-len ທີ່ຜ່ານການປຸງແຕ່ງ-> |-ຕໍ່ການກວດສອບ
        //                  | <-ຖືກລຶບອອກ cnt-> |
        //      | <-ຕົ້ນສະບັບ _>-ເກັບຮັກສາໄວ້: ອົງປະກອບທີ່ຄາດຄະເນຜົນຕອບແທນທີ່ແທ້ຈິງ.
        //
        // ຮູຂຸມຂົນ: ຍ້າຍຫລືລຸດລົງໃນສ່ວນປະກອບຂອງແຜ່ນ.
        // ການກວດສອບ: ບໍ່ຖືກກວດສອບອົງປະກອບທີ່ຖືກຕ້ອງ.
        //
        // ກອງຫຼຸດລົງນີ້ຈະຖືກຮຽກຮ້ອງເມື່ອຄາດຄະເນຫຼື `drop` ຂອງອົງປະກອບທີ່ຕົກຕະລຶງ.
        // ມັນ shifts ອົງປະກອບມີການກວດກາກັບຂຸມກວມເອົາແລະ `set_len` ກັບຄວາມຍາວທີ່ຖືກຕ້ອງ.
        // ໃນກໍລະນີເມື່ອຄາດຄະເນແລະ `drop` ບໍ່ເຄີຍແປກ, ມັນຈະຖືກປັບປຸງໃຫ້ດີທີ່ສຸດ.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // ຄວາມປອດໄພ: ຕິດຕາມສິນຄ້າທີ່ບໍ່ຖືກກວດກາຕ້ອງຖືກຕ້ອງເພາະວ່າພວກເຮົາບໍ່ເຄີຍແຕະຕ້ອງ.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // ຄວາມປອດໄພ: ຫຼັງຈາກຖົມຂຸມ, ລາຍການທັງ ໝົດ ແມ່ນຢູ່ໃນຄວາມຊົງ ຈຳ ຕິດຕໍ່ກັນ.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // ຄວາມປອດໄພ: ອົງປະກອບທີ່ບໍ່ຖືກກວດກາຕ້ອງຖືກຕ້ອງ.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // ລ່ວງຫນ້າກ່ອນເພື່ອຫລີກລ້ຽງການຫຼຸດລົງສອງເທົ່າຖ້າ `drop_in_place` ຕົກໃຈ.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // ຄວາມປອດໄພ: ພວກເຮົາບໍ່ເຄີຍ ສຳ ພັດກັບສ່ວນປະກອບນີ້ອີກຕໍ່ໄປຫລັງຈາກຖືກລຸດລົງ.
                unsafe { ptr::drop_in_place(cur) };
                // ພວກເຮົາແລ້ວກ້າວຫນ້າທາງດ້ານວຽກງານຕ້ານການ.
                continue;
            }
            if g.deleted_cnt > 0 {
                // ຄວາມປອດໄພ: `deleted_cnt`> 0, ສະນັ້ນຊ່ອງສຽບຂຸມບໍ່ຕ້ອງຊ້ ຳ ຊ້ອນກັບອົງປະກອບປັດຈຸບັນ.
                // ພວກເຮົາໃຊ້ ສຳ ເນົາ ສຳ ລັບຍ້າຍ, ແລະບໍ່ຕ້ອງ ສຳ ພັດກັບສ່ວນປະກອບນີ້ອີກຕໍ່ໄປ.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // ລາຍການທັງ ໝົດ ຖືກປະມວນຜົນ.ນີ້ສາມາດເພີ່ມປະສິດຕິພາບໃຫ້ເປັນ `set_len` ໂດຍ LLVM.
        drop(g);
    }

    /// ລົບອອກທັງ ໝົດ ແຕ່ ທຳ ອິດຂອງອົງປະກອບຕິດຕໍ່ກັນໃນ vector ທີ່ແກ້ໄຂໃຫ້ເປັນກຸນແຈດຽວກັນ.
    ///
    ///
    /// ຖ້າ vector ຖືກຈັດຮຽງ, ມັນຈະເອົາຊໍ້າທັງ ໝົດ ອອກ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// ເອົາທັງ ໝົດ ແຕ່ ທຳ ອິດຂອງອົງປະກອບຕິດຕໍ່ກັນໃນ vector ທີ່ເພິ່ງພໍໃຈໃນຄວາມ ສຳ ພັນສະ ເໝີ ພາບ.
    ///
    /// ຟັງຊັນ `same_bucket` ຖືກສົ່ງຜ່ານເອກະສານອ້າງອີງເຖິງສອງອົງປະກອບຈາກ vector ແລະຕ້ອງ ກຳ ນົດວ່າອົງປະກອບໃດທຽບເທົ່າກັນ.
    /// ອົງປະກອບທີ່ຖືກສົ່ງຜ່ານທາງກົງກັນຂ້າມຈາກການສັ່ງຊື້ຂອງພວກເຂົາໃນສ່ວນຕ່າງໆ, ດັ່ງນັ້ນຖ້າ `same_bucket(a, b)` ກັບຄືນ `true`, `a` ຈະຖືກຍ້າຍອອກ.
    ///
    ///
    /// ຖ້າ vector ຖືກຈັດຮຽງ, ມັນຈະເອົາຊໍ້າທັງ ໝົດ ອອກ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// ຂື້ນສ່ວນປະກອບໄປທາງຫຼັງຂອງການເກັບ ກຳ ຂໍ້ມູນ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຄວາມສາມາດໃຫມ່ເກີນ bytes `isize::MAX`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // ນີ້ຈະ panic ຫຼືຍົກເລີກຖ້າພວກເຮົາຈະຈັດສັນ> isize::MAX bytes ຫຼືຖ້າຄວາມຍາວຈະເພີ່ມຂື້ນ ສຳ ລັບປະເພດທີ່ມີຂະ ໜາດ ສູນ.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// ເອົາອົງປະກອບສຸດທ້າຍອອກຈາກ vector ແລະສົ່ງມັນຄືນ, ຫຼື [`None`] ຖ້າມັນຫວ່າງ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// ຍ້າຍອົງປະກອບທັງ ໝົດ ຂອງ `other` ລົງເປັນ `Self`, ເຮັດໃຫ້ `other` ຫວ່າງເປົ່າ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ ຈຳ ນວນຂອງທາດໃນ vector ລົ້ນ `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// ຂື້ນສ່ວນປະກອບໃສ່ `Self` ຈາກ buffer ອື່ນໆ.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// ສ້າງທໍ່ລະບາຍນ້ ຳ ທີ່ ກຳ ຈັດຂອບເຂດທີ່ລະບຸໄວ້ໃນ vector ແລະໃຫ້ຜົນຜະລິດທີ່ຖືກລົບອອກ.
    ///
    /// ໃນເວລາທີ່ຕົວປ່ຽນແປງ **ຖືກຫຼຸດລົງ**, ທຸກໆອົງປະກອບທີ່ຢູ່ໃນຂອບເຂດຖືກຍ້າຍອອກຈາກ vector, ເຖິງແມ່ນວ່າເຄື່ອງປັບໂຕຍັງບໍ່ໄດ້ຮັບການບໍລິໂພກຢ່າງເຕັມສ່ວນ.
    /// ຖ້າຕົວປ່ຽນທິດທາງ **ບໍ່ແມ່ນ** ຖືກລຸດລົງ (ດ້ວຍຕົວຢ່າງ [`mem::forget`]), ມັນບໍ່ໄດ້ລະບຸວ່າມີ ຈຳ ນວນອົງປະກອບໃດທີ່ຖືກຍ້າຍອອກ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຈຸດເລີ່ມຕົ້ນໃຫຍ່ກວ່າຈຸດສິ້ນສຸດຫລືຖ້າຈຸດຈົບສູງກວ່າຄວາມຍາວຂອງ vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // ຊ່ວງເຕັມເກັບກູ້ vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // ຄວາມປອດໄພຂອງຄວາມ ຈຳ
        //
        // ໃນເວລາທີ່ Drain ຖືກສ້າງຕັ້ງຂື້ນຄັ້ງທໍາອິດ, ມັນສັ້ນລົງຄວາມຍາວຂອງແຫຼ່ງ vector ໄດ້ເພື່ອເຮັດໃຫ້ແນ່ໃຈວ່າບໍ່ມີ uninitialized ຫຼືຍ້າຍຈາກອົງປະກອບແມ່ນສາມາດເຂົ້າເຖິງທີ່ທຸກຄົນຖ້າ destructor ໄດ້ Drain ຂອງບໍ່ເຄີຍໄດ້ຮັບການດໍາເນີນການ.
        //
        //
        // Drain ຈະ ptr::read ອອກຄ່າທີ່ຈະເອົາອອກ.
        // ເມື່ອເຮັດ ສຳ ເລັດແລ້ວ, ຫາງທີ່ຍັງເຫຼືອຂອງ vec ແມ່ນຖືກຄັດລອກໄປເພື່ອປົກປິດຮູ, ແລະຄວາມຍາວຂອງ vector ແມ່ນຖືກກັບຄືນສູ່ຄວາມຍາວ ໃໝ່.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // ຕັ້ງຄວາມຍາວ self.vec ເພື່ອເລີ່ມຕົ້ນ, ເພື່ອໃຫ້ປອດໄພໃນກໍລະນີ Drain ຈະຮົ່ວໄຫຼ
            self.set_len(start);
            // ໃຊ້ເງິນກູ້ໃນ IterMut ເພື່ອຊີ້ບອກເຖິງພຶດຕິ ກຳ ການກູ້ຢືມເງິນຂອງຕົວປ່ຽນແປງທັງ ໝົດ ຂອງ Drain (ເຊັ່ນ &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// ລ້າງ vector, ກຳ ຈັດຄ່າທັງ ໝົດ.
    ///
    /// ໃຫ້ສັງເກດວ່າວິທີການນີ້ບໍ່ມີຜົນກະທົບຕໍ່ຄວາມສາມາດຈັດສັນຂອງ vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// ກັບຄືນ ຈຳ ນວນຂອງສ່ວນປະກອບໃນ vector, ຍັງເອີ້ນວ່າ 'length' ຂອງມັນ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// ກັບຄືນ `true` ຖ້າ vector ບໍ່ມີສ່ວນປະກອບ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ແຍກການເກັບລວບລວມເປັນສອງອັນໃນດັດຊະນີທີ່ໃຫ້.
    ///
    /// ສົ່ງຄືນ vector ທີ່ຖືກຈັດສັນ ໃໝ່ ທີ່ບັນຈຸສ່ວນປະກອບໃນລະດັບ `[at, len)`.
    /// ຫຼັງຈາກການໂທ, vector ຕົ້ນສະບັບຈະຖືກປະໄວ້ປະກອບມີອົງປະກອບ `[0, at)` ດ້ວຍຄວາມສາມາດທີ່ຜ່ານມາບໍ່ປ່ຽນແປງ.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // vector ໃໝ່ ສາມາດຄອບຄອງ buffer ເດີມແລະຫລີກລ້ຽງການ ສຳ ເນົາ
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // ທີ່ບໍ່ປອດໄພ `set_len` ແລະສໍາເນົາລາຍການ `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// ປັບຂະ ໜາດ `Vec` ຢູ່ໃນສະຖານທີ່ເພື່ອໃຫ້ `len` ເທົ່າກັບ `new_len`.
    ///
    /// ຖ້າ `new_len` ໃຫຍ່ກ່ວາ `len`, `Vec` ໄດ້ຖືກຂະຫຍາຍໂດຍຄວາມແຕກຕ່າງ, ໂດຍແຕ່ລະຊ່ອງເພີ່ມເຕີມຈະເຕັມໄປດ້ວຍຜົນຂອງການໂທຫາການປິດ `f`.
    ///
    /// ມູນຄ່າການກັບຄືນມາຈາກ `f` ຈະສິ້ນສຸດລົງໃນ `Vec` ໃນຄໍາສັ່ງທີ່ພວກເຂົາຖືກຜະລິດ.
    ///
    /// ຖ້າ `new_len` ນ້ອຍກວ່າ `len`, `Vec` ແມ່ນຕັດສັ້ນໆ.
    ///
    /// ວິທີການນີ້ໃຊ້ການປິດເພື່ອສ້າງຄຸນຄ່າ ໃໝ່ ໃນທຸກໆການຊຸກຍູ້.ຖ້າຫາກວ່າທ່ານສັ່ງແທນທີ່ຈະ [`Clone`] ຄ່າໃຫ້ໃຊ້ [`Vec::resize`].
    /// ຖ້າທ່ານຕ້ອງການໃຊ້ [`Default`] trait ເພື່ອສ້າງຄຸນຄ່າ, ທ່ານສາມາດຜ່ານ [`Default::default`] ເປັນການໂຕ້ຖຽງທີສອງ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// ບໍລິໂພກແລະຮົ່ວໄຫລຂອງ `Vec`, ສົ່ງຄືນການອ້າງອິງເນື້ອຫາ, `&'a mut [T]`.
    /// ໃຫ້ສັງເກດວ່າປະເພດ `T` ຕ້ອງມີຊີວິດຊີວາທີ່ເລືອກໄດ້ສູງກວ່າ `'a`.
    /// ຖ້າປະເພດມີພຽງແຕ່ເອກະສານອ້າງອີງຄົງທີ່, ຫຼືບໍ່ມີເລີຍ, ຫຼັງຈາກນັ້ນ, ນີ້ອາດຈະຖືກເລືອກໃຫ້ເປັນ `'static`.
    ///
    /// ຟັງຊັນນີ້ຄ້າຍກັບຟັງຊັນ [`leak`][Box::leak] ໃນ [`Box`] ຍົກເວັ້ນວ່າບໍ່ມີທາງໃດທີ່ຈະສາມາດກູ້ຄືນຄວາມຊົງ ຈຳ ທີ່ຮົ່ວໄຫລອອກມາໄດ້.
    ///
    ///
    /// ໜ້າ ທີ່ນີ້ສ່ວນໃຫຍ່ຈະເປັນປະໂຫຍດ ສຳ ລັບຂໍ້ມູນທີ່ມີຊີວິດຢູ່ຕະຫຼອດຊີວິດຂອງໂປແກມ.
    /// ການຫຼຸດລົງເອກະສານອ້າງອີງທີ່ສົ່ງຄືນຈະເຮັດໃຫ້ມີການຮົ່ວໄຫລຂອງຄວາມຊົງຈໍາ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ງ່າຍດາຍ:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// ສົ່ງຄືນ ກຳ ລັງທີ່ເຫຼືອຂອງ vector ໃຫ້ເປັນ `MaybeUninit<T>`.
    ///
    /// ຊິ້ນທີ່ຖືກກັບຄືນມາສາມາດຖືກນໍາໃຊ້ເພື່ອເຕີມຂໍ້ມູນ vector (ຕົວຢ່າງ
    /// ໂດຍການອ່ານຈາກແຟ້ມເອກະສານ) ກ່ອນທີ່ຈະ ໝາຍ ຂໍ້ມູນທີ່ໄດ້ເລີ່ມຕົ້ນໂດຍໃຊ້ວິທີ [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Allocate vector ໃຫຍ່ພໍ ສຳ ລັບ 10 ອົງປະກອບ.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // ຕື່ມຂໍ້ມູນໃສ່ໃນ 3 ອົງປະກອບ ທຳ ອິດ.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // ໝາຍ ເອົາ 3 ອົງປະກອບ ທຳ ອິດຂອງ vector ວ່າ ກຳ ລັງເລີ່ມຕົ້ນ.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // ວິທີການນີ້ບໍ່ໄດ້ຖືກປະຕິບັດໃນແງ່ຂອງ `split_at_spare_mut`, ເພື່ອປ້ອງກັນການ ນຳ ໃຊ້ຕົວຊີ້ໄປຍັງເຂດບໍ່ຖືກຕ້ອງ.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// ສົ່ງຄືນເນື້ອໃນ vector ເປັນຊິ້ນຂອງ `T`, ພ້ອມກັບຄວາມສາມາດໃນການເກັບຮັກສາທີ່ຍັງເຫຼືອຂອງ vector ເປັນຊິ້ນຂອງ `MaybeUninit<T>`.
    ///
    /// ຊິ້ນສ່ວນຄວາມສາມາດໃນການເກັບຮັກສາທີ່ສົ່ງກັບມາສາມາດຖືກ ນຳ ໃຊ້ເພື່ອເຕີມຂໍ້ມູນ vector (ຕົວຢ່າງໂດຍການອ່ານຈາກແຟ້ມເອກະສານ) ກ່ອນທີ່ຈະ ໝາຍ ຂໍ້ມູນດັ່ງທີ່ໄດ້ເລີ່ມຕົ້ນໂດຍໃຊ້ວິທີ [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// ໃຫ້ສັງເກດວ່ານີ້ແມ່ນເປັນ API ໃນລະດັບຕ່ໍາ, ທີ່ຄວນຈະໄດ້ຮັບການນໍາໃຊ້ກັບການດູແລສໍາລັບຈຸດປະສົງທີ່ດີທີ່ສຸດ.
    /// ຖ້າທ່ານຕ້ອງການຕື່ມຂໍ້ມູນໃສ່ `Vec` ທ່ານສາມາດໃຊ້ [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] ຫຼື [`resize_with`], ຂື້ນກັບຄວາມຕ້ອງການທີ່ແນ່ນອນຂອງທ່ານ.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // ສຳ ຮອງພື້ນທີ່ເພີ່ມເຕີມໃຫຍ່ພໍ ສຳ ລັບ 10 ອົງປະກອບ.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // ຕື່ມຂໍ້ມູນໃສ່ 4 ປັດໃຈຕໍ່ໄປ.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // ໝາຍ ເອົາ 4 ອົງປະກອບຂອງ vector ວ່າ ກຳ ລັງເລີ່ມຕົ້ນ.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len ແມ່ນບໍ່ສົນໃຈແລະສະນັ້ນບໍ່ເຄີຍປ່ຽນແປງ
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// ຄວາມປອດໄພ: ການປ່ຽນແປງກັບຄືນມາ .2 (&mut ຂະ ໜາດ ໃຫຍ່) ຖືວ່າຄືກັນກັບການໂທຫາ `.set_len(_)`.
    ///
    /// ວິທີການນີ້ແມ່ນໄດ້ຖືກນໍາໃຊ້ເພື່ອສາມາດເຂົ້າເຖິງເອກະລັກທີ່ຈະພາກສ່ວນ vec ທັງຫມົດໃນເວລາດຽວໃນ `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` ຖືກຮັບປະກັນວ່າມັນຖືກຕ້ອງ ສຳ ລັບອົງປະກອບ `len`
        // - `spare_ptr` ແມ່ນ ກຳ ລັງຊີ້ ໜຶ່ງ ອົງປະກອບທີ່ຢູ່ ເໜືອ buffer, ດັ່ງນັ້ນມັນບໍ່ຊ້ ຳ ກັບ `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// ປັບຂະ ໜາດ `Vec` ຢູ່ໃນສະຖານທີ່ເພື່ອໃຫ້ `len` ເທົ່າກັບ `new_len`.
    ///
    /// ຖ້າ `new_len` ແມ່ນຫຼາຍກ່ວາ `len`, ການ `Vec` ໄດ້ຖືກຂະຫຍາຍໂດຍແຕກຕ່າງກັນ, ມີແຕ່ລະຊ່ອງເພີ່ມເຕີມເຕັມໄປດ້ວຍ `value`.
    ///
    /// ຖ້າ `new_len` ນ້ອຍກວ່າ `len`, `Vec` ແມ່ນຕັດສັ້ນໆ.
    ///
    /// ວິທີການນີ້ຮຽກຮ້ອງໃຫ້ `T` ປະຕິບັດ [`Clone`], ເພື່ອໃຫ້ສາມາດ clone ຄ່າຜ່ານ.
    /// ຖ້າທ່ານຕ້ອງການຄວາມຍືດຍຸ່ນຫຼາຍ (ຫລືຕ້ອງການທີ່ຈະອີງໃສ່ [`Default`] ແທນ [`Clone`]), ໃຫ້ໃຊ້ [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clones ແລະຜນວກອົງປະກອບທັງຫມົດໃນຫຼັງຈາກນັ້ນນໍາໄປ `Vec` ໄດ້.
    ///
    /// Iterates ຫຼາຍກວ່າຫຼັງຈາກນັ້ນນໍາ `other`, clones ແຕ່ລະອົງປະກອບ, ແລະຫຼັງຈາກນັ້ນ appends ມັນກັບ `Vec` ນີ້.
    /// `other` vector ແມ່ນການຊື້-ຂາຍແບບເປັນລະບຽບຮຽບຮ້ອຍ.
    ///
    /// ໃຫ້ສັງເກດວ່າການທໍາງານນີ້ແມ່ນຄືກັນກັບ [`extend`] ເວັ້ນເສຍແຕ່ວ່າມັນເປັນຜູ້ຊ່ຽວຊານທີ່ຈະເຮັດວຽກກັບຫຼັງຈາກນັ້ນນໍາແທນທີ່ຈະເປັນ.
    ///
    /// ຖ້າແລະໃນເວລາທີ່ Rust ໄດ້ຮັບຄວາມຊ່ຽວຊານ, ໜ້າ ທີ່ນີ້ຈະຖືກປະຕິເສດ (ແຕ່ຍັງມີຢູ່).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// ຄັດລອກອົງປະກອບຕ່າງໆຈາກ `src` ຮອດປາຍຂອງ vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` ຮັບປະກັນວ່າຊ່ວງທີ່ ກຳ ນົດໄວ້ແມ່ນຖືກຕ້ອງ ສຳ ລັບການດັດສະນີຕົວເອງ
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// ລະຫັດນີ້ມີຄວາມ ໝາຍ `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// ຂະຫຍາຍ vector ໂດຍຄ່າ `n`, ໂດຍໃຊ້ເຄື່ອງ ກຳ ເນີດທີ່ໃຫ້.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // ໃຊ້ SetLenOnDrop ເພື່ອເຮັດວຽກອ້ອມບbugອກບ່ອນທີ່ນັກລວບລວມຂໍ້ມູນອາດຈະບໍ່ຮູ້ຮ້ານຜ່ານ `ptr` ຜ່ານ self.set_len() ບໍ່ມີຊື່ປອມ.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // ຂຽນທຸກອົງປະກອບຍົກເວັ້ນແຕ່ຫົວຂໍ້ສຸດທ້າຍ
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // ເພີ່ມຄວາມຍາວໃນທຸກໆບາດກ້າວໃນກໍລະນີ next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // ພວກເຮົາສາມາດຂຽນອົງປະກອບສຸດທ້າຍໂດຍກົງໂດຍບໍ່ຕ້ອງກົດປຸ່ມໂດຍບໍ່ ຈຳ ເປັນ
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // ທີ່ກໍານົດໄວ້ len ໂດຍຂອບເຂດກອງ
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// ເອົາອົງປະກອບທີ່ຊ້ ຳ ຊ້ອນຕິດຕໍ່ກັນໃນ vector ອີງຕາມການຈັດຕັ້ງປະຕິບັດ [`PartialEq`] trait.
    ///
    ///
    /// ຖ້າ vector ຖືກຈັດຮຽງ, ມັນຈະເອົາຊໍ້າທັງ ໝົດ ອອກ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// ວິທີການແລະ ໜ້າ ທີ່ພາຍໃນ
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` ຕ້ອງມີດັດສະນີທີ່ຖືກຕ້ອງ
    /// - `self.capacity() - self.len()` ຕ້ອງເປັນ `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len ແມ່ນເພີ່ມຂື້ນພຽງແຕ່ຫລັງຈາກເລີ່ມຕົ້ນອົງປະກອບຕ່າງໆ
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - ຜູ້ໂທຫາວ່າ src ແມ່ນດັດສະນີທີ່ຖືກຕ້ອງ
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element ພຽງແຕ່ເລີ່ມຕົ້ນດ້ວຍ `MaybeUninit::write` ເທົ່ານັ້ນ, ສະນັ້ນມັນບໍ່ເປັນຫຍັງດອກ
            // - len ແມ່ນເພີ່ມຂື້ນຫຼັງຈາກແຕ່ລະອົງປະກອບເພື່ອປ້ອງກັນການຮົ່ວໄຫລ (ເບິ່ງບັນຫາ #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - ຜູ້ໂທຫາວ່າ `src` ແມ່ນດັດສະນີທີ່ຖືກຕ້ອງ
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - pointers ທັງສອງໄດ້ຖືກສ້າງຕັ້ງຂື້ນຈາກເອກະສານຫຼັງຈາກນັ້ນນໍາເອກະລັກ (`ແລະ Mut [_]`) ດັ່ງນັ້ນພວກເຂົາເຈົ້າແມ່ນຖືກຕ້ອງແລະບໍ່ຊ້ໍາຊ້ອນ.
            //
            // - ອົງປະກອບແມ່ນ: ສຳ ເນົາສະນັ້ນມັນບໍ່ເປັນຫຍັງທີ່ຈະຄັດລອກມັນ, ໂດຍບໍ່ຕ້ອງເຮັດຫຍັງກັບຄ່າເດີມ
            // - `count` ແມ່ນເທົ່າທຽມກັນກັບ len ຂອງ `source` ໄດ້, ສະນັ້ນແຫຼ່ງແມ່ນຖືກຕ້ອງສໍາລັບ `count` ອ່ານ
            // - `.reserve(count)` ຮັບປະກັນວ່າ `spare.len() >= count` ສະນັ້ນອາໄຫຼ່ແມ່ນຖືກຕ້ອງ ສຳ ລັບ `count` ຂຽນ
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - ອົງປະກອບດັ່ງກ່າວໄດ້ຖືກເລີ່ມຕົ້ນໂດຍ `copy_nonoverlapping` ເທົ່ານັ້ນ
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// ການປະຕິບັດ trait ທົ່ວໄປສໍາລັບ Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): ກັບ cfg(test) ວິທີການປະກົດຂຶ້ນ `[T]::to_vec`, ທີ່ຕ້ອງການ ສຳ ລັບ ຄຳ ນິຍາມຂອງວິທີການນີ້, ແມ່ນບໍ່ມີ.
    // ແທນທີ່ຈະໃຊ້ຟັງຊັນ `slice::to_vec` ເຊິ່ງມີພຽງແຕ່ cfg(test) NB ເບິ່ງໂມດູນ slice::hack ໃນ slice.rs ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // ຫຼຸດລົງສິ່ງໃດແດ່ທີ່ຈະບໍ່ຖືກຂຽນທັບ
        self.truncate(other.len());

        // self.len <= other.len ເນື່ອງຈາກຕັດຂ້າງເທິງ, ສະນັ້ນຫຼັງຈາກນັ້ນນໍານີ້ແມ່ນສະເຫມີໄປໃນຂອບເຂດ.
        //
        let (init, tail) = other.split_at(self.len());

        // ໃຊ້ຄືນຄ່າທີ່ມີ allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// ສ້າງຕົວຊີ້ວັດທີ່ມີການຊົມໃຊ້, ນັ້ນແມ່ນ ໜຶ່ງ ທີ່ຍ້າຍແຕ່ລະຄ່າອອກຈາກ vector (ຕັ້ງແຕ່ເລີ່ມຕົ້ນ).
    /// ບໍ່ສາມາດໃຊ້ vector ຫຼັງຈາກການໂທຫານີ້.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s ມີ String ປະເພດ, ບໍ່ແມ່ນ &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // ວິທີການໃບໄມ້ທີ່ການຈັດຕັ້ງປະຕິບັດ SpecFrom/SpecExtend ຕ່າງໆມອບ ໝາຍ ໃຫ້ເມື່ອພວກເຂົາບໍ່ມີການເພີ່ມປະສິດທິພາບຕື່ມອີກໃນການ ນຳ ໃຊ້
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // ນີ້ແມ່ນກໍລະນີສໍາລັບການ iterator ໂດຍທົ່ວໄປ.
        //
        // ໜ້າ ທີ່ນີ້ຄວນຈະເທົ່າກັບສົມບັດສິນ ທຳ ຂອງ:
        //
        //      ສຳ ລັບລາຍການໃນ iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ບໍ່ສາມາດລົ້ນນ້ ຳ ໄດ້ເພາະພວກເຮົາຈະຕ້ອງຈັດສັນທີ່ຢູ່
                self.set_len(len + 1);
            }
        }
    }

    /// ສ້າງຕົວປ່ຽນແປງຊໍ້າທີ່ປ່ຽນແທນຂອບເຂດທີ່ລະບຸໄວ້ໃນ vector ກັບຕົວຊີ້ວັດ `replace_with` ທີ່ໃຫ້ແລະໃຫ້ຜົນຜະລິດທີ່ຖືກຍ້າຍອອກ.
    ///
    /// `replace_with` ບໍ່ ຈຳ ເປັນຕ້ອງມີຄວາມຍາວເທົ່າກັບ `range`.
    ///
    /// `range` ຖືກຖອດອອກເຖິງແມ່ນວ່າໂຕເກຍບໍ່ໄດ້ຖືກບໍລິໂພກຈົນເຖິງທີ່ສຸດ.
    ///
    /// ມັນຍັງບໍ່ໄດ້ລະບຸວ່າມີ ຈຳ ນວນອົງປະກອບໃດທີ່ຖືກຍ້າຍອອກຈາກ vector ຖ້າວ່າມູນຄ່າ `Splice` ຖືກຮົ່ວໄຫຼ.
    ///
    /// ຕົວປະກອບວັດສະດຸປ້ອນ `replace_with` ຖືກບໍລິໂພກເມື່ອມູນຄ່າ `Splice` ຖືກລຸດລົງ.
    ///
    /// ນີ້ແມ່ນດີທີ່ສຸດຖ້າ:
    ///
    /// * ສະມຸດ (ອົງປະກອບໃນ vector ຫຼັງຈາກ `range`) ແມ່ນຫວ່າງເປົ່າ,
    /// * ຫຼື `replace_with` ໃຫ້ຜົນຜະລິດ ໜ້ອຍ ຫລືເທົ່າກັບຄວາມຍາວຂອງ `range`
    /// * ຫຼືຂອບເຂດຕ່ ຳ ຂອງ `size_hint()` ຂອງມັນແມ່ນຖືກຕ້ອງ.
    ///
    /// ຖ້າບໍ່ດັ່ງນັ້ນ, ເປັນຊົ່ວຄາວ vector ຖືກຈັດສັນແລະຫາງໄດ້ຖືກຍ້າຍສອງຄັ້ງ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຈຸດເລີ່ມຕົ້ນໃຫຍ່ກວ່າຈຸດສິ້ນສຸດຫລືຖ້າຈຸດຈົບສູງກວ່າຄວາມຍາວຂອງ vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// ສ້າງຕົວຊີ້ວັດເຊິ່ງໃຊ້ການປິດເພື່ອ ກຳ ນົດວ່າຄວນເອົາອົງປະກອບໃດ ໜຶ່ງ ອອກ.
    ///
    /// ຖ້າການປິດຈະກັບມາເປັນຄວາມຈິງ, ຫຼັງຈາກນັ້ນ, ອົງປະກອບດັ່ງກ່າວຈະຖືກຍ້າຍອອກແລະໃຫ້ຜົນຜະລິດ.
    /// ຖ້າການປິດຈະກັບມາບໍ່ຖືກຕ້ອງ, ອົງປະກອບຈະຍັງຄົງຢູ່ໃນ vector ແລະຈະບໍ່ໄດ້ຮັບຜົນຕອບແທນຈາກຜູ້ຄວບຄຸມ.
    ///
    /// ການ ນຳ ໃຊ້ວິທີນີ້ແມ່ນເທົ່າກັບລະຫັດຕໍ່ໄປນີ້:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // ລະຫັດຂອງທ່ານທີ່ນີ້
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// ແຕ່ `drain_filter` ໃຊ້ງ່າຍກວ່າ.
    /// `drain_filter` ແມ່ນຍັງປະສິດທິພາບຫຼາຍ, ເນື່ອງຈາກວ່າມັນສາມາດ backshift ອົງປະກອບຂອງຂບວນຢູ່ໃນຫຼາຍໄດ້.
    ///
    /// ໃຫ້ສັງເກດວ່າ `drain_filter` ຍັງສາມາດເຮັດໃຫ້ທ່ານກາຍທຸກອົງປະກອບໃນການປິດການກັ່ນຕອງ, ບໍ່ຄໍານຶງເຖິງວ່າທ່ານເລືອກທີ່ຈະຮັກສາຫລືເອົາມັນ.
    ///
    ///
    /// # Examples
    ///
    /// ການແບ່ງປັນອາເລເປັນ evens ແລະບໍ່ລົງຮອຍກັນ, reusing ການຈັດສັນເດີມ:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // ກອງຕໍ່ຕ້ານພວກເຮົາໄດ້ຮັບການຮົ່ວໄຫລ (ການຂະຫຍາຍສຽງທີ່ຮົ່ວໄຫຼ)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// ຂະຫຍາຍການຈັດຕັ້ງປະຕິບັດທີ່ຄັດລອກອົງປະກອບຕ່າງໆອອກຈາກການອ້າງອິງກ່ອນທີ່ຈະຍູ້ພວກເຂົາໃສ່ Vec.
///
/// ການຈັດຕັ້ງປະຕິບັດນີ້ແມ່ນຊ່ຽວຊານ ສຳ ລັບເຄື່ອງຕັດສະເກັດ, ເຊິ່ງມັນໃຊ້ [`copy_from_slice`] ເພື່ອເພີ່ມເຕີມເສັ້ນທັງ ໝົດ ພ້ອມໆກັນ.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// ການປຽບທຽບການປຽບທຽບຂອງ vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// ການປະຕິບັດຄໍາສັ່ງຂອງ vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // ການ ນຳ ໃຊ້ຫຼຸດລົງ ສຳ ລັບ [T] ໃຊ້ຊິ້ນສ່ວນດິບເພື່ອອີງໃສ່ອົງປະກອບຂອງ vector ເປັນປະເພດທີ່ ຈຳ ເປັນທີ່ອ່ອນແອທີ່ສຸດ;
            //
            // ສາມາດຫລີກລ້ຽງ ຄຳ ຖາມກ່ຽວກັບຄວາມຖືກຕ້ອງໃນບາງກໍລະນີ
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec ຈັດການການຈັດສັນ
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// ສ້າງ `Vec<T>` ເປົ່າ.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test pulls ໃນ libstd, ເຊິ່ງກໍ່ໃຫ້ເກີດຂໍ້ຜິດພາດຢູ່ທີ່ນີ້
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test pulls ໃນ libstd, ເຊິ່ງກໍ່ໃຫ້ເກີດຂໍ້ຜິດພາດຢູ່ທີ່ນີ້
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// ເອົາເນື້ອຫາທັງ ໝົດ ຂອງ `Vec<T>` ເປັນອາເລ, ຖ້າຂະ ໜາດ ຂອງມັນກົງກັບຂອງຂບວນທີ່ຮ້ອງຂໍ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// ຖ້າຄວາມຍາວບໍ່ກົງກັນ, ວັດສະດຸປ້ອນຈະກັບມາເປັນ `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// ຖ້າທ່ານດີກັບພຽງແຕ່ໄດ້ຮັບ ຄຳ ນຳ ໜ້າ ຂອງ `Vec<T>`, ທ່ານສາມາດໂທຫາ [`.truncate(N)`](Vec::truncate) ກ່ອນ.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SAFETY: `.set_len(0)` ເປັນສຽງສະເຫມີ.
        unsafe { vec.set_len(0) };

        // ຄວາມປອດໄພ: ຕົວຊີ້ຂອງ `Vec` ແມ່ນສອດຄ່ອງສະ ເໝີ ໄປ, ແລະ
        // ຄວາມສອດຄ່ອງຂອງຄວາມຕ້ອງການຂອງອາເລແມ່ນຄືກັນກັບລາຍການ.
        // ພວກເຮົາໄດ້ກວດເບິ່ງກ່ອນ ໜ້າ ນີ້ວ່າພວກເຮົາມີສິນຄ້າພຽງພໍ.
        // ບັນດາລາຍການຈະບໍ່ລຸດລົງເປັນສອງເທົ່າຄືກັບທີ່ `set_len` ບອກໃຫ້ `Vec` ບໍ່ໃຫ້ເອົາລົງ.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}