use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// ພິເສດ trait ໃຊ້ ສຳ ລັບ Vec::from_iter
///
/// ## ເສັ້ນສະແດງຄະນະຜູ້ແທນ:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // ກໍລະນີທົ່ວໄປແມ່ນການຖ່າຍທອດ vector ເຂົ້າໃນ ໜ້າ ທີ່ເຊິ່ງການເກັບ ກຳ ຂໍ້ມູນ ໃໝ່ ໃນ vector ທັນທີ.
        // ພວກເຮົາສາມາດສະຫຼຸບວົງຈອນນີ້ໄດ້ຖ້າ IntoIter ບໍ່ໄດ້ກ້າວ ໜ້າ ເລີຍ.
        // ເມື່ອມັນມີຄວາມກ້າວ ໜ້າ ແລ້ວພວກເຮົາຍັງສາມາດ ນຳ ໃຊ້ຫນ່ວຍຄວາມ ຈຳ ຄືນ ໃໝ່ ແລະຍ້າຍຂໍ້ມູນໄປທາງ ໜ້າ.
        // ແຕ່ພວກເຮົາພຽງແຕ່ເຮັດແນວນັ້ນໃນເວລາທີ່ຜົນໄດ້ Vec ຈະບໍ່ມີຄວາມສາມາດໃຊ້ຫຼາຍກ່ວາການສ້າງມັນໂດຍຜ່ານການປະຕິບັດ FromIterator generic ຈະ.
        //
        // ຂໍ້ຈໍາກັດທີ່ບໍ່ແມ່ນຢ່າງເຂັ້ມງວດມີຄວາມຈໍາເປັນເປັນພຶດຕິກໍາການຈັດສັນ Vec ແມ່ນມີເຈດຕະນາບໍ່ໄດ້ລະບຸ.
        // ແຕ່ມັນແມ່ນການເລືອກແບບອະນຸລັກ.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // ຕ້ອງມອບຫມາຍໃຫ້ spec_extend() ນັບຕັ້ງແຕ່ extend() ຕົວຂອງມັນເອງຄະນະຜູ້ແທນທີ່ຈະ spec_from ສໍາລັບເປົ່າ Vecses
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// ນີ້ໃຊ້ `iterator.as_slice().to_vec()` ນັບຕັ້ງແຕ່ spec_extend ຕ້ອງໃຊ້ຫຼາຍບາດກ້າວເພື່ອຫາເຫດຜົນກ່ຽວກັບຄວາມສາມາດສຸດທ້າຍ + ຄວາມຍາວແລະດັ່ງນັ້ນຈຶ່ງເຮັດວຽກໄດ້ຫຼາຍ.
// `to_vec()` ຈັດສັນ ຈຳ ນວນເງິນທີ່ຖືກຕ້ອງໂດຍກົງແລະເຕີມເຕັມໃຫ້ຖືກຕ້ອງ.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): ກັບ cfg(test) ວິທີການປະກົດຂຶ້ນ `[T]::to_vec`, ທີ່ຕ້ອງການ ສຳ ລັບ ຄຳ ນິຍາມຂອງວິທີການນີ້, ແມ່ນບໍ່ມີ.
    // ແທນທີ່ຈະໃຊ້ຟັງຊັນ `slice::to_vec` ເຊິ່ງມີພຽງແຕ່ cfg(test) NB ເບິ່ງໂມດູນ slice::hack ໃນ slice.rs ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}