use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// ພິເສດອີກຢ່າງ ໜຶ່ງ trait ສຳ ລັບ Vec::from_iter ມີຄວາມ ຈຳ ເປັນໃນການຈັດ ລຳ ດັບຄວາມ ຊຳ ນານພິເສດດ້ວຍຕົນເອງເບິ່ງ [`SpecFromIter`](super::SpecFromIter) ສຳ ລັບລາຍລະອຽດ.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // ລົງທະບຽນການອອກສຽງຄັ້ງ ທຳ ອິດ, ເນື່ອງຈາກວ່າ vector ກຳ ລັງຈະຂະຫຍາຍຂື້ນໄປຕາມຄວາມເວົ້ານີ້ໃນທຸກໆກໍລະນີເມື່ອ iterable ບໍ່ຫວ່າງ, ແຕ່ວ່າ loop ໃນ extend_desugared() ຈະບໍ່ເຫັນ vector ເຕັມໄປດ້ວຍການເພີ່ມຂື້ນສອງສາມທິດຕໍ່ມາ.
        //
        // ດັ່ງນັ້ນພວກເຮົາໄດ້ຮັບການຄາດຄະເນ branch ທີ່ດີກວ່າ.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // ຕ້ອງມອບຫມາຍໃຫ້ spec_extend() ນັບຕັ້ງແຕ່ extend() ຕົວຂອງມັນເອງຄະນະຜູ້ແທນທີ່ຈະ spec_from ສໍາລັບເປົ່າ Vecses
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // ຕ້ອງມອບຫມາຍໃຫ້ spec_extend() ນັບຕັ້ງແຕ່ extend() ຕົວຂອງມັນເອງຄະນະຜູ້ແທນທີ່ຈະ spec_from ສໍາລັບເປົ່າ Vecses
        //
        vector.spec_extend(iterator);
        vector
    }
}