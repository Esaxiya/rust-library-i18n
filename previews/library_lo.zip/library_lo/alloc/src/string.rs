//! ສາຍ UTF-8 - ທີ່ຖືກເຂົ້າລະຫັດ, ສາມາດເຕີບໃຫຍ່ໄດ້.
//!
//! ໂມດູນນີ້ມີປະເພດ [`String`], [`ToString`] trait ເພື່ອປ່ຽນເປັນເຊືອກ, ແລະຫລາຍປະເພດຂໍ້ຜິດພາດທີ່ອາດຈະເປັນຜົນມາຈາກການເຮັດວຽກກັບ [`String`] s.
//!
//!
//! # Examples
//!
//! ມີຫຼາຍວິທີທີ່ຈະສ້າງເປັນ [`String`] ໃຫມ່ຈາກຫນັງສື string ແມ່ນ:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! ທ່ານສາມາດສ້າງ [`String`] ໃໝ່ ຈາກທີ່ມີຢູ່ແລ້ວໂດຍການປະສົມປະສານກັບ
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! ຖ້າທ່ານມີ vector ຂອງໄບ UTF-8 ທີ່ຖືກຕ້ອງ, ທ່ານສາມາດເຮັດ [`String`] ອອກຈາກມັນໄດ້.ທ່ານສາມາດເຮັດໄດ້ຢ່າງສິ້ນເຊີງເຊັ່ນກັນ.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // ພວກເຮົາຮູ້ວ່າໄບຕ໌ເຫລົ່ານີ້ແມ່ນຖືກຕ້ອງ, ດັ່ງນັ້ນພວກເຮົາຈະໃຊ້ `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// ສາຍ UTF-8 - ທີ່ຖືກເຂົ້າລະຫັດ, ສາມາດເຕີບໃຫຍ່ໄດ້.
///
/// ປະເພດ `String` ແມ່ນປະເພດສະຕິງທີ່ພົບເລື້ອຍທີ່ສຸດທີ່ມີສິດເປັນເຈົ້າຂອງເນື້ອຫາຂອງສາຍ.ມັນມີຄວາມ ສຳ ພັນໃກ້ຊິດກັບຄູ່ຮ່ວມງານທີ່ຢືມມາ, [`str`] ເບື້ອງຕົ້ນ.
///
/// # Examples
///
/// ທ່ານສາມາດສ້າງ `String` ຈາກ [a literal string][`str`] ກັບ [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// ທ່ານສາມາດຕື່ມ [`char`] ເປັນ `String` ດ້ວຍວິທີ [`push`], ແລະຕື່ມໃສ່ [`&str`] ດ້ວຍວິທີ [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// ຖ້າທ່ານມີ vector ຂອງ UTF-8 bytes, ທ່ານສາມາດສ້າງ `String` ຈາກມັນດ້ວຍວິທີ [`from_utf8`]:
///
/// ```
/// // ບາງໄບຕ໌, ໃນ vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ພວກເຮົາຮູ້ວ່າໄບຕ໌ເຫລົ່ານີ້ແມ່ນຖືກຕ້ອງ, ດັ່ງນັ້ນພວກເຮົາຈະໃຊ້ `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `ສະຕິງ` ແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງສະ ເໝີ ໄປ.ນີ້ມີຜົນສະທ້ອນຫຼາຍປານໃດ, ຄັ້ງທໍາອິດຂອງຊຶ່ງໃນນັ້ນແມ່ນຖ້າຫາກວ່າທ່ານຕ້ອງການທີ່ບໍ່ແມ່ນ UTF-8 string, ພິຈາລະນາ [`OsString`].ມັນກໍ່ຄ້າຍຄືກັນ, ແຕ່ບໍ່ມີຂໍ້ ຈຳ ກັດ UTF-8.ຜົນສະທ້ອນທີ່ສອງແມ່ນທ່ານບໍ່ສາມາດດັດສະນີເປັນ `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// ການດັດສະນີມີຈຸດປະສົງເພື່ອເປັນການ ດຳ ເນີນງານທີ່ໃຊ້ເວລາຄົງທີ່, ແຕ່ການເຂົ້າລະຫັດ UTF-8 ບໍ່ໄດ້ໃຫ້ພວກເຮົາເຮັດສິ່ງນີ້.ຍິ່ງໄປກວ່ານັ້ນ, ມັນບໍ່ຈະແຈ້ງວ່າປະເພດໃດແດ່ທີ່ດັດຊະນີຄວນຈະກັບມາ: ໄບຕ໌, ລະຫັດຈຸດ, ຫຼືກຸ່ມທີ່ເປັນເຄືອ.
/// ວິທີການ [`bytes`] ແລະ [`chars`] ສົ່ງຄືນຕົວປ່ຽນທິດໃນສອງ ທຳ ອິດຕາມ ລຳ ດັບ.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String` s ປະຕິບັດ [`Deref`]`<Target=str>`, ແລະດັ່ງນັ້ນຈົ່ງສືບທອດທຸກໆວິທີການຂອງ [`str`].ນອກຈາກນັ້ນ, ນີ້ ໝາຍ ຄວາມວ່າທ່ານສາມາດຜ່ານ `String` ໄປທີ່ ໜ້າ ທີ່ທີ່ໃຊ້ [`&str`] ໂດຍໃຊ້ ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// ນີ້ຈະສ້າງ [`&str`] ຈາກ `String` ແລະສົ່ງມັນເຂົ້າ. ການແປງນີ້ແມ່ນລາຄາຖືກຫຼາຍ, ແລະດັ່ງນັ້ນ, ໂດຍທົ່ວໄປແລ້ວ, ໜ້າ ທີ່ຈະຍອມຮັບ [`&str`] ເປັນການໂຕ້ຖຽງເວັ້ນເສຍແຕ່ວ່າພວກເຂົາຕ້ອງການ `String` ດ້ວຍເຫດຜົນສະເພາະ.
///
/// ໃນບາງກໍລະນີ Rust ບໍ່ມີຂໍ້ມູນພຽງພໍທີ່ຈະເຮັດໃຫ້ການປ່ຽນແປງດັ່ງກ່າວນີ້, ເປັນທີ່ຮູ້ຈັກເປັນການບີບບັງຄັບ [`Deref`].ໃນຕົວຢ່າງຕໍ່ໄປນີ້ຊິ້ນເຊືອກ [`&'a str`][`&str`] ປະຕິບັດ trait `TraitExample`, ແລະຟັງຊັນ `example_func` ເອົາສິ່ງໃດທີ່ປະຕິບັດກັບ trait.
/// ໃນກໍລະນີນີ້ Rust ຈະຕ້ອງມີການແປງສອງຢ່າງທີ່ສົມບູນແບບ, ເຊິ່ງ Rust ບໍ່ມີທາງທີ່ຈະເຮັດ.
/// ດ້ວຍເຫດຜົນນັ້ນ, ຕົວຢ່າງຕໍ່ໄປນີ້ຈະບໍ່ລວບລວມ.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// ມີສອງທາງເລືອກໃນການທີ່ຈະເຮັດວຽກແທນທີ່ຈະມີ.ທໍາອິດຈະມີການປ່ຽນແປງເສັ້ນ `example_func(&example_string);` ກັບ `example_func(example_string.as_str());`, ການນໍາໃຊ້ວິທີການ [`as_str()`] ໄດ້ຢ່າງຊັດເຈນສະກັດຫຼັງຈາກນັ້ນນໍາສະຕິງທີ່ມີການຊ່ອຍແນ່.
/// ວິທີທີສອງປ່ຽນ `example_func(&example_string);` ເປັນ `example_func(&*example_string);`.
/// ໃນກໍລະນີນີ້ພວກເຮົາ ກຳ ລັງຍົກລະດັບ `String` ເປັນ [`str`][`&str`], ຈາກນັ້ນ ໝາຍ ເຖິງ [`str`][`&str`] ກັບຄືນສູ່ [`&str`].
/// ວິທີທີສອງແມ່ນ idiomatic ຫຼາຍ, ຢ່າງໃດກໍຕາມທັງສອງເຮັດວຽກເພື່ອເຮັດການປ່ຽນໃຈເຫລື້ອມໃສຢ່າງຊັດເຈນກ່ວາອາໄສການປ່ຽນໃຈເຫລື້ອມໃສທີ່ສົມບູນແບບ.
///
/// # Representation
///
/// A `String` ປະກອບດ້ວຍສາມສ່ວນປະກອບ: ຕົວຊີ້ໄປຫາບາງໄບຕ໌, ຄວາມຍາວແລະຄວາມສາມາດ.ຈຸດຊີ້ໄປຍັງບັຟເຟີພາຍໃນ `String` ໃຊ້ເພື່ອເກັບຮັກສາຂໍ້ມູນຂອງຕົນ.ຄວາມຍາວແມ່ນ ຈຳ ນວນໄບຕ໌ທີ່ປະຈຸບັນເກັບໄວ້ໃນ buffer, ແລະຄວາມອາດສາມາດແມ່ນຂະ ໜາດ ຂອງ buffer ໃນ bytes.
///
/// ດັ່ງນັ້ນ, ຄວາມຍາວສະເຫມີໄປຈະມີຫນ້ອຍກ່ວາຫຼືເທົ່າທຽມກັນທີ່ຄວາມສາມາດ.
///
/// buffer ນີ້ຈະຖືກເກັບຢູ່ໃນ heap ສະ ເໝີ.
///
/// ທ່ານສາມາດເບິ່ງສິ່ງເຫຼົ່ານີ້ດ້ວຍວິທີ [`as_ptr`], [`len`], ແລະ [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME ປັບປຸງນີ້ເມື່ອ vec_into_raw_parts ມີສະຖຽນລະພາບ.
/// // ປ້ອງກັນການລຸດຂໍ້ມູນຂອງ String ໂດຍອັດຕະໂນມັດ
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // ເລື່ອງມີເກົ້າສິບເກົ້າ
/// assert_eq!(19, len);
///
/// // ພວກເຮົາສາມາດສ້າງ String ອອກຈາກ ptr, len, ແລະຄວາມອາດສາມາດ.
/// // ນີ້ແມ່ນທັງ ໝົດ ທີ່ບໍ່ປອດໄພເພາະວ່າພວກເຮົາຮັບຜິດຊອບໃນການຮັບປະກັນວ່າສ່ວນປະກອບແມ່ນຖືກຕ້ອງ:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// ຖ້າ `String` ມີຄວາມສາມາດພຽງພໍ, ການເພີ່ມອົງປະກອບໃຫ້ມັນກໍ່ຈະບໍ່ຈັດສັນອີກ.ຍົກຕົວຢ່າງ, ພິຈາລະນາໂຄງການນີ້:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// ນີ້ຈະມີຜົນຕໍ່ໄປນີ້:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// ໃນຕອນ ທຳ ອິດ, ພວກເຮົາບໍ່ມີຄວາມຊົງ ຈຳ ທີ່ຈັດສັນໄວ້ແຕ່ຢ່າງໃດ, ແຕ່ເມື່ອພວກເຮົາເອົາໃຈໃສ່ເບິ່ງຊ່ອຍແນ່, ມັນຈະເພີ່ມຄວາມສາມາດຂອງມັນໃຫ້ ເໝາະ ສົມ.ຖ້າຫາກວ່າພວກເຮົາແທນທີ່ຈະນໍາໃຊ້ວິທີການ [`with_capacity`] ການຈັດສັນຄວາມສາມາດທີ່ຖືກຕ້ອງໃນເບື້ອງຕົ້ນ:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// ພວກເຮົາສິ້ນສຸດດ້ວຍຜົນຜະລິດທີ່ແຕກຕ່າງກັນ:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// ໃນທີ່ນີ້, ບໍ່ ຈຳ ເປັນຕ້ອງຈັດສັນຄວາມ ຈຳ ພາຍໃນວົງຈອນຕື່ມອີກ.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// ມູນຄ່າຄວາມຜິດພາດທີ່ເປັນໄປໄດ້ໃນເວລາທີ່ປ່ຽນ `String` ຈາກ UTF-8 byte vector.
///
/// ປະເພດນີ້ແມ່ນປະເພດຂໍ້ຜິດພາດ ສຳ ລັບວິທີ [`from_utf8`] ໃນ [`String`].
/// ມັນຖືກອອກແບບມາເພື່ອບໍ່ໃຫ້ມີການຕັ້ງຖິ່ນຖານຢ່າງລະມັດລະວັງ: ວິທີ [`into_bytes`] ຈະໃຫ້ກັບຄືນ byte vector ທີ່ຖືກ ນຳ ໃຊ້ໃນຄວາມພະຍາຍາມປ່ຽນໃຈເຫລື້ອມໃສ.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// ປະເພດ [`Utf8Error`] ທີ່ສະ ໜອງ ໂດຍ [`std::str`] ສະແດງເຖິງຄວາມຜິດພາດທີ່ອາດຈະເກີດຂື້ນໃນເວລາທີ່ປ່ຽນເປັນ [`u8`] ເປັນ [`&str`].
/// ໃນຄວາມຮູ້ສຶກດັ່ງກ່າວນີ້, ມັນເປັນການຮ່ວມກັບ `FromUtf8Error`, ແລະທ່ານສາມາດໄດ້ຮັບຈາກການ `FromUtf8Error` ຜ່ານວິທີການ [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// // ບາງໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງ, ໃນ vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// ມູນຄ່າຄວາມຜິດພາດທີ່ອາດເກີດຂື້ນເມື່ອປ່ຽນ `String` ຈາກ UTF-16 byte slice.
///
/// ປະເພດນີ້ແມ່ນປະເພດຂໍ້ຜິດພາດ ສຳ ລັບວິທີ [`from_utf16`] ໃນ [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// ສ້າງ `String` ເປົ່າ ໃໝ່.
    ///
    /// ເນື່ອງຈາກວ່າການ `String` ແມ່ນຫວ່າງເປົ່າ, ນີ້ຈະບໍ່ຈັດສັນບັຟເຟີໃນເບື້ອງຕົ້ນໃດໆ.ໃນຂະນະທີ່ວິທີການທີ່ວ່ານີ້ປະຕິບັດງານໃນເບື້ອງຕົ້ນແມ່ນລາຄາຖືກຫຼາຍ, ມັນອາດຈະເຮັດໃຫ້ການຈັດສັນຫຼາຍເກີນໄປຕໍ່ມາໃນເວລາທີ່ທ່ານຕື່ມຂໍ້ມູນ.
    ///
    /// ຖ້າທ່ານມີຄວາມຄິດກ່ຽວກັບຂໍ້ມູນຫຼາຍປານໃດທີ່ `String` ຈະມີ, ໃຫ້ພິຈາລະນາວິທີ [`with_capacity`] ເພື່ອປ້ອງກັນການຈັດສັນຄືນ ໃໝ່ ຫຼາຍເກີນໄປ.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// ສ້າງ `String` ເປົ່າ ໃໝ່ ທີ່ມີຄວາມສາມາດສະເພາະ.
    ///
    /// `String`s ມີ buffer ພາຍໃນເພື່ອຈັບຂໍ້ມູນຂອງພວກເຂົາ.
    /// ຄວາມອາດສາມາດແມ່ນຄວາມຍາວຂອງ buffer ນັ້ນ, ແລະສາມາດສອບຖາມກັບວິທີ [`capacity`].
    /// ວິທີການນີ້ຈະສ້າງ `String` ເປົ່າ, ແຕ່ວິທີ ໜຶ່ງ ທີ່ມີ buffer ເບື້ອງຕົ້ນທີ່ສາມາດຖື `capacity` bytes.
    /// ນີ້ແມ່ນສິ່ງທີ່ເປັນປະໂຫຍດເມື່ອທ່ານອາດຈະສະ ເໜີ ຂໍ້ມູນເພີ່ມເຕີມເປັນ `String`, ຫຼຸດຜ່ອນ ຈຳ ນວນບ່ອນທີ່ຕ້ອງເຮັດ.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// ຖ້າຄວາມສາມາດທີ່ໄດ້ຮັບແມ່ນ `0`, ບໍ່ມີການຈັດສັນໃດໆ, ແລະວິທີການນີ້ແມ່ນຄືກັນກັບວິທີ [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // The String ບໍ່ມີ chars, ເຖິງແມ່ນວ່າມັນມີຄວາມສາມາດຫຼາຍ
    /// assert_eq!(s.len(), 0);
    ///
    /// // ສິ່ງເຫລົ່ານີ້ລ້ວນແຕ່ເຮັດໄດ້ໂດຍບໍ່ຕ້ອງແບ່ງປັນ ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ແຕ່ສິ່ງນີ້ອາດຈະເຮັດໃຫ້ສະຕິງປ່ຽນແປງ ໃໝ່
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): ກັບ cfg(test) ວິທີການປະກົດຂຶ້ນ `[T]::to_vec`, ທີ່ຕ້ອງການ ສຳ ລັບ ຄຳ ນິຍາມຂອງວິທີການນີ້, ແມ່ນບໍ່ມີ.
    // ເນື່ອງຈາກວ່າພວກເຮົາບໍ່ຕ້ອງການວິທີການນີ້ເພື່ອຈຸດປະສົງການທົດສອບ, ຂ້າພະເຈົ້າພຽງແຕ່ຈະກັກ NB ເບິ່ງໂມດູນ slice::hack ໃນ slice.rs ສຳ ລັບຂໍ້ມູນເພີ່ມເຕີມ
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// ແປງ vector ຂອງໄບຕ໌ເປັນ `String`.
    ///
    /// A string ([`String`]) ແມ່ນຂອງໄບຕ໌ ([`u8`]), ແລະ vector ຂອງໄບຕ໌ ([`Vec<u8>`]) ແມ່ນຂອງໄບຕ໌, ສະນັ້ນຫນ້າທີ່ນີ້ປ່ຽນໃຈເຫລື້ອມໃສລະຫວ່າງທັງສອງ.
    /// ບໍ່ແມ່ນທຸກຂ໌ໄບຕ໌ແມ່ນຖືກຕ້ອງ `ສະຕິງ` ຢ່າງໃດກໍ່ຕາມ: `String` ຮຽກຮ້ອງວ່າມັນຖືກຕ້ອງ UTF-8.
    /// `from_utf8()` ກວດສອບເພື່ອຮັບປະກັນວ່າໄບຕ໌ແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ, ແລະຈາກນັ້ນກໍ່ເຮັດການແປງ.
    ///
    /// ຖ້າທ່ານແນ່ໃຈວ່າແຜ່ນໄບຕ໌ແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ, ແລະທ່ານບໍ່ຕ້ອງການທີ່ຈະເກີດບັນຫາດ້ານ ໜ້າ ຂອງການກວດສອບຄວາມຖືກຕ້ອງ, ມີລຸ້ນທີ່ບໍ່ປອດໄພ, [`from_utf8_unchecked`], ເຊິ່ງມີພຶດຕິ ກຳ ດຽວກັນແຕ່ຂ້າມການກວດສອບ.
    ///
    ///
    /// ວິທີການນີ້ຈະລະມັດລະວັງເພື່ອບໍ່ເຮັດ ສຳ ເນົາ vector, ເພື່ອປະສິດທິພາບ.
    ///
    /// ຖ້າທ່ານຕ້ອງການ [`&str`] ແທນ `String`, ພິຈາລະນາ [`str::from_utf8`].
    ///
    /// ຄວາມສັບສົນຂອງວິທີການນີ້ແມ່ນ [`into_bytes`].
    ///
    /// # Errors
    ///
    /// ກັບຄືນ [`Err`] ຖ້າຫາກວ່າສ່ວນທີ່ບໍ່ແມ່ນ UTF-8 ກັບ ຄຳ ອະທິບາຍກ່ຽວກັບເຫດຜົນວ່າເປັນຫຍັງ bytes ທີ່ສະ ໜອງ ບໍ່ແມ່ນ UTF-8.The vector ທີ່ທ່ານຍ້າຍເຂົ້າມາແມ່ນລວມຢູ່ ນຳ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // ບາງໄບຕ໌, ໃນ vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // ພວກເຮົາຮູ້ວ່າໄບຕ໌ເຫລົ່ານີ້ແມ່ນຖືກຕ້ອງ, ດັ່ງນັ້ນພວກເຮົາຈະໃຊ້ `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// ໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງ:
    ///
    /// ```
    /// // ບາງໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງ, ໃນ vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// ເບິ່ງເອກະສານ ສຳ ລັບ [`FromUtf8Error`] ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມກ່ຽວກັບສິ່ງທີ່ທ່ານສາມາດເຮັດກັບຄວາມຜິດພາດນີ້.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// ແປງໄບຕ໌ເປັນແຖວ, ລວມທັງໂຕອັກສອນທີ່ບໍ່ຖືກຕ້ອງ.
    ///
    /// ເຊືອກແມ່ນເຮັດດ້ວຍໄບຕ໌ ([`u8`]), ແລະສ່ວນຂອງໄບ ([`&[u8]`][byteslice]) ແມ່ນເຮັດຈາກໄບ, ສະນັ້ນ ໜ້າ ທີ່ນີ້ປ່ຽນລະຫວ່າງສອງ.ບໍ່ແມ່ນທຸກຂ໌ໄບຕ໌ແມ່ນສາຍທີ່ຖືກຕ້ອງ, ແຕ່ຢ່າງໃດກໍ່ຕາມ: ເຊືອກ ຈຳ ເປັນຕ້ອງມີ UTF-8 ທີ່ຖືກຕ້ອງ.
    /// ໃນລະຫວ່າງການປ່ຽນໃຈເຫລື້ອມໃສນີ້, `from_utf8_lossy()` ຈະປ່ຽນ UTF-8 ລຳ ດັບທີ່ບໍ່ຖືກຕ້ອງກັບ [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], ເຊິ່ງມີລັກສະນະດັ່ງນີ້:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// ຖ້າທ່ານແນ່ໃຈວ່າແຜ່ນໄບຕ໌ແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ, ແລະທ່ານບໍ່ຕ້ອງການທີ່ຈະເກີດບັນຫາການປ່ຽນໃຈເຫລື້ອມໃສ, ມີລຸ້ນທີ່ບໍ່ປອດໄພ, [`from_utf8_unchecked`], ເຊິ່ງມີພຶດຕິ ກຳ ດຽວກັນແຕ່ຂ້າມການກວດສອບ.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// ຟັງຊັນນີ້ເອົາຄືນ [`Cow<'a, str>`].ຖ້າຫາກວ່າຫຼັງຈາກນັ້ນນໍາ byte ຂອງພວກເຮົາແມ່ນບໍ່ຖືກຕ້ອງ UTF-8, ຫຼັງຈາກນັ້ນພວກເຮົາຈໍາເປັນຕ້ອງໄດ້ໃສ່ລັກສະນະທົດແທນ, ເຊິ່ງຈະມີການປ່ຽນແປງຂະຫນາດຂອງສາຍອັກຂະລະ, ແລະເພາະສະນັ້ນ, ຮຽກຮ້ອງໃຫ້ `String`.
    /// ແຕ່ຖ້າມັນຖືກຕ້ອງແລ້ວ UTF-8, ພວກເຮົາບໍ່ ຈຳ ເປັນຕ້ອງມີການຈັດສັນ ໃໝ່.
    /// ປະເພດການກັບຄືນນີ້ຊ່ວຍໃຫ້ພວກເຮົາຈັດການທັງສອງຄະດີ.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // ບາງໄບຕ໌, ໃນ vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// ໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງ:
    ///
    /// ```
    /// // ບາງໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງ
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// ຖອດລະຫັດລະຫັດ UTF-16 - ລະຫັດ vector `v` ເຂົ້າ `String` X, ກັບຄືນ [`Err`] ຖ້າ `v` ມີຂໍ້ມູນທີ່ບໍ່ຖືກຕ້ອງ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // ນີ້ບໍ່ໄດ້ເຮັດໄດ້ໂດຍຜ່ານການເກັບກໍາ: : <Result<_, _>> () ດ້ວຍເຫດຜົນການປະຕິບັດ.
        // FIXME: ຫນ້າທີ່ສາມາດງ່າຍດາຍອີກເທື່ອຫນຶ່ງເມື່ອ #48994 ຖືກປິດ.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// ຖອດລະຫັດຊິ້ນສ່ວນ UTF-16 - ທີ່ຖືກເຂົ້າລະຫັດ `v` ລົງເປັນ `String`, ປ່ຽນຂໍ້ມູນທີ່ບໍ່ຖືກຕ້ອງກັບ [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// ບໍ່ເຫມືອນກັບ [`from_utf8_lossy`] ທີ່ຈະກັບຄືນມາເປັນ [`Cow<'a, str>`], `from_utf16_lossy` ຈະກັບຄືນມາເປັນ `String` ນັບຕັ້ງແຕ່ UTF-16 ກັບ UTF-8 ແປງຮຽກຮ້ອງໃຫ້ມີການຈັດສັນຄວາມຊົງຈໍາເປັນ.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Decomposes `String` ເປັນສ່ວນປະກອບວັດຖຸດິບຂອງມັນ.
    ///
    /// ຜົນຕອບແທນທີ່ຊີ້ດິບເຖິງຂໍ້ມູນທີ່ຕິດພັນໃນ, ຄວາມຍາວຂອງ string (ໃນ bytes), ແລະຄວາມສາມາດໃນການຈັດສັນຂໍ້ມູນ (ໃນ bytes).
    /// ເຫຼົ່ານີ້ແມ່ນການໂຕ້ຖຽງດຽວກັນໃນຄໍາສັ່ງດຽວກັນກັບການໂຕ້ຖຽງກັບ [`from_raw_parts`].
    ///
    /// ຫຼັງຈາກການເອີ້ນຟັງຊັນນີ້, ຜູ້ໂທຈະຕ້ອງຮັບຜິດຊອບຕໍ່ຄວາມຊົງ ຈຳ ທີ່ຈັດການໂດຍ `String` ກ່ອນ ໜ້າ ນີ້.
    /// ວິທີດຽວທີ່ຈະເຮັດຄືການແປງຕົວຊີ້ວັດ, ຄວາມຍາວແລະຄວາມສາມາດໃຫ້ກັບມາເປັນ `String` ກັບຟັງຊັນ [`from_raw_parts`], ເຮັດໃຫ້ຜູ້ ທຳ ລາຍ ທຳ ລາຍຄວາມສະອາດ.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// ສ້າງ `String` ໃຫມ່ຈາກຄວາມຍາວ, ຄວາມສາມາດ, ແລະຊີ້.
    ///
    /// # Safety
    ///
    /// ນີ້ບໍ່ປອດໄພສູງ, ຍ້ອນ ຈຳ ນວນທະຫານທີ່ບໍ່ໄດ້ຖືກກວດກາ:
    ///
    /// * ຄວາມຊົງ ຈຳ ທີ່ `buf` ຈຳ ເປັນຕ້ອງມີການຈັດສັນກ່ອນ ໜ້າ ນີ້ໂດຍຜູ້ຈັດສັນດຽວກັນການ ນຳ ໃຊ້ຫໍສະມຸດມາດຕະຖານ, ໂດຍມີການຈັດລຽນທີ່ ຈຳ ເປັນຢ່າງແນ່ນອນ 1.
    /// * `length` ຄວາມຕ້ອງການທີ່ຈະຫນ້ອຍກ່ວາຫຼືເທົ່າທຽມກັນທີ່ `capacity`.
    /// * `capacity` ຕ້ອງມີຄຸນຄ່າທີ່ຖືກຕ້ອງ.
    /// * `length` ໄບ ທຳ ອິດທີ່ `buf` ຕ້ອງມີ UTF-8 ທີ່ຖືກຕ້ອງ.
    ///
    /// ການລະເມີດສິ່ງເຫລົ່ານີ້ອາດຈະເຮັດໃຫ້ເກີດບັນຫາເຊັ່ນການສໍ້ລາດບັງຫຼວງໂຄງສ້າງຂໍ້ມູນພາຍໃນຂອງຜູ້ຈັດສັນ.
    ///
    /// ການເປັນເຈົ້າຂອງຂອງ `buf` ຖືກໂອນເຂົ້າ `String` ຢ່າງມີປະສິດຕິຜົນເຊິ່ງຫຼັງຈາກນັ້ນອາດຈະຈັດການ, ຈັດສັນ, ປ່ຽນ ໃໝ່ ຫຼືປ່ຽນເນື້ອໃນຂອງຄວາມຊົງ ຈຳ ທີ່ຊີ້ໄປໂດຍຕົວຊີ້ທີ່ຈະ.
    /// ຮັບປະກັນວ່າບໍ່ມີຫຍັງອີກທີ່ໃຊ້ຕົວຊີ້ຫຼັງຈາກໂທຫາຟັງຊັ່ນນີ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME ປັບປຸງນີ້ເມື່ອ vec_into_raw_parts ມີສະຖຽນລະພາບ.
    ///     // ປ້ອງກັນການລຸດຂໍ້ມູນຂອງ String ໂດຍອັດຕະໂນມັດ
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// ແປງ vector ຂອງໄບຕ໌ເປັນ `String` ໂດຍບໍ່ຕ້ອງກວດສອບວ່າສາຍສະຕິງມີ UTF-8 ທີ່ຖືກຕ້ອງ.
    ///
    /// ເບິ່ງສະບັບທີ່ປອດໄພ, [`from_utf8`], ສຳ ລັບລາຍລະອຽດເພີ່ມເຕີມ.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// ຟັງຊັນນີ້ບໍ່ປອດໄພເພາະມັນບໍ່ໄດ້ກວດເບິ່ງວ່າໄບທີ່ຜ່ານໄປມັນແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ.
    /// ຖ້າຂໍ້ ຈຳ ກັດນີ້ຖືກລະເມີດ, ມັນອາດຈະກໍ່ໃຫ້ເກີດບັນຫາກ່ຽວກັບຄວາມຊົງ ຈຳ ທີ່ບໍ່ປອດໄພກັບຜູ້ໃຊ້ `String` ຂອງ future, ເພາະວ່າຫ້ອງສະ ໝຸດ ມາດຕະຖານອື່ນໆສົມມຸດວ່າ `String`s ແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // ບາງໄບຕ໌, ໃນ vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// ແປງ `String` ເປັນໄບຕ໌ vector.
    ///
    /// ນີ້ກິນ `String`, ດັ່ງນັ້ນພວກເຮົາບໍ່ຈໍາເປັນຕ້ອງຄັດລອກເນື້ອຫາຂອງມັນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// ສະກັດສ່ວນເຊືອກທີ່ບັນຈຸທັງ `String` ທັງ ໝົດ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// ແປງ `String` ເປັນທ່ອນຊ່ອຍແນ່ທີ່ປ່ຽນແປງໄດ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// ໃສ່ສາຍເຊືອກທີ່ຫຍໍ້ໃສ່ປາຍ `String` ນີ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// ສົ່ງຄືນຄວາມສາມາດຂອງ `String` ນີ້ໃນໄບ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// ຮັບປະກັນວ່າຄວາມສາມາດຂອງ `String` ນີ້ຢ່າງ ໜ້ອຍ `additional` ໄບໃຫຍ່ກ່ວາຄວາມຍາວຂອງມັນ.
    ///
    /// ຄວາມອາດສາມາດອາດຈະໄດ້ຮັບການເພີ່ມຂື້ນຫຼາຍກ່ວາ `additional` bytes ຖ້າມັນເລືອກ, ເພື່ອປ້ອງກັນການຕັ້ງຖິ່ນຖານຢູ່ເລື້ອຍໆ.
    ///
    ///
    /// ຖ້າທ່ານບໍ່ຕ້ອງການພຶດຕິ ກຳ "at least" ນີ້, ໃຫ້ເບິ່ງວິທີ [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຄວາມສາມາດ ໃໝ່ ລົ້ນ [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// ນີ້ອາດຈະບໍ່ເພີ່ມຂີດຄວາມສາມາດ:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ດຽວນີ້ມີຄວາມຍາວ 2 ແລະຄວາມຈຸ 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // ເນື່ອງຈາກພວກເຮົາມີຄວາມສາມາດພິເສດ 8 ແລ້ວ, ໂທຫານີ້ ...
    /// s.reserve(8);
    ///
    /// // ... ບໍ່ໄດ້ເພີ່ມຂື້ນຢ່າງແທ້ຈິງ.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// ຮັບປະກັນວ່າຄວາມສາມາດຂອງ `String` ນີ້ແມ່ນ `additional` bytes ໃຫຍ່ກວ່າຄວາມຍາວຂອງມັນ.
    ///
    /// ພິຈາລະນາໃຊ້ວິທີການ [`reserve`] ເວັ້ນເສຍແຕ່ວ່າທ່ານຮູ້ດີກ່ວາຜູ້ຈັດສັນ.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຄວາມສາມາດ ໃໝ່ ລົ້ນ `usize`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// ນີ້ອາດຈະບໍ່ເພີ່ມຂີດຄວາມສາມາດ:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ດຽວນີ້ມີຄວາມຍາວ 2 ແລະຄວາມຈຸ 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // ເນື່ອງຈາກພວກເຮົາມີຄວາມສາມາດພິເສດ 8 ແລ້ວ, ໂທຫານີ້ ...
    /// s.reserve_exact(8);
    ///
    /// // ... ບໍ່ໄດ້ເພີ່ມຂື້ນຢ່າງແທ້ຈິງ.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// ພະຍາຍາມສະຫງວນຄວາມສາມາດໃຫ້ຢ່າງ ໜ້ອຍ `additional` ອົງປະກອບເພີ່ມເຕີມທີ່ຈະເອົາເຂົ້າໃນ `String` ທີ່ໄດ້ມອບໃຫ້.
    /// ການເກັບ ກຳ ຂໍ້ມູນດັ່ງກ່າວອາດຈະສະຫງວນເນື້ອທີ່ຫຼາຍຂື້ນເພື່ອຫລີກລ້ຽງການຈັດສັນທີ່ຢູ່ເລື້ອຍໆ.
    /// ຫຼັງຈາກການໂທຫາ `reserve`, ຄວາມສາມາດຈະຫຼາຍກ່ວາຫຼືເທົ່າກັບ `self.len() + additional`.
    /// ບໍ່ມີຫຍັງເຮັດຖ້າຄວາມສາມາດພຽງພໍແລ້ວ.
    ///
    /// # Errors
    ///
    /// ຖ້າຄວາມສາມາດລົ້ນ, ຫຼືຜູ້ຈັດລາຍງານລາຍງານຄວາມລົ້ມເຫລວ, ຫຼັງຈາກນັ້ນຄວາມຜິດພາດຈະຖືກສົ່ງຄືນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // ຈັດເກັບຄວາມຊົງ ຈຳ ໄວ້ກ່ອນ, ຖ້າພວກເຮົາບໍ່ສາມາດເຮັດໄດ້
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ໃນປັດຈຸບັນພວກເຮົາຮູ້ວ່ານີ້ບໍ່ສາມາດ OOM ຢູ່ເຄິ່ງກາງຂອງວຽກງານທີ່ສັບສົນຂອງພວກເຮົາ
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// ພະຍາຍາມສະຫງວນຄວາມອາດສາມາດຕ່ ຳ ສຸດ ສຳ ລັບອົງປະກອບເພີ່ມເຕີມ `additional` ທີ່ຈະຖືກໃສ່ເຂົ້າໃນ `String` ທີ່ໃຫ້.
    ///
    /// ຫຼັງຈາກການໂທຫາ `reserve_exact`, ຄວາມສາມາດຈະຫຼາຍກ່ວາຫຼືເທົ່າກັບ `self.len() + additional`.
    /// ບໍ່ມີຫຍັງເຮັດຖ້າຄວາມສາມາດພຽງພໍແລ້ວ.
    ///
    /// ຈົ່ງສັງເກດວ່າຜູ້ຈັດສັນອາດຈະໃຫ້ຫ້ອງເກັບຫຼາຍກວ່າທີ່ມັນຮ້ອງຂໍ.
    /// ສະນັ້ນ, ຄວາມສາມາດບໍ່ສາມາດເພິ່ງພາໄດ້ຢ່າງ ໜ້ອຍ ແນ່ນອນ.
    /// ມັກ `reserve` ຖ້າມີຄວາມຄາດຫວັງຂອງ future.
    ///
    /// # Errors
    ///
    /// ຖ້າຄວາມສາມາດລົ້ນ, ຫຼືຜູ້ຈັດລາຍງານລາຍງານຄວາມລົ້ມເຫລວ, ຫຼັງຈາກນັ້ນຄວາມຜິດພາດຈະຖືກສົ່ງຄືນ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // ຈັດເກັບຄວາມຊົງ ຈຳ ໄວ້ກ່ອນ, ຖ້າພວກເຮົາບໍ່ສາມາດເຮັດໄດ້
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ໃນປັດຈຸບັນພວກເຮົາຮູ້ວ່ານີ້ບໍ່ສາມາດ OOM ຢູ່ເຄິ່ງກາງຂອງວຽກງານທີ່ສັບສົນຂອງພວກເຮົາ
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// ຫຼຸດຄວາມຈຸຂອງ `String` ນີ້ໃຫ້ກົງກັບຄວາມຍາວຂອງມັນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// ນ້ອຍລົງຄວາມສາມາດຂອງ `String` ນີ້ດ້ວຍຂອບທີ່ຕ່ໍາກວ່າ.
    ///
    /// ຄວາມອາດສາມາດຈະຍັງຄົງຢູ່ຢ່າງຫນ້ອຍທັງຄວາມຍາວແລະມູນຄ່າການສະ ໜອງ.
    ///
    ///
    /// ຖ້າຄວາມສາມາດໃນປະຈຸບັນຕ່ ຳ ກ່ວາຂີດ ຈຳ ກັດຕ່ ຳ, ນີ້ແມ່ນສິ່ງທີ່ບໍ່ມີ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// ຕິດຕັ້ງ [`char`] ໃຫ້ທ້າຍ `String` ນີ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// ສົ່ງຄືນເນື້ອໃນຂອງ `String` ນີ້.
    ///
    /// ຄວາມສັບສົນຂອງວິທີການນີ້ແມ່ນ [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// ສັ້ນ `String` ນີ້ໃຫ້ຍາວຕາມຄວາມຍາວທີ່ລະບຸ.
    ///
    /// ຖ້າ `new_len` ໃຫຍ່ກວ່າຄວາມຍາວຂອງສະຕິງ, ມັນບໍ່ມີຜົນຫຍັງເລີຍ.
    ///
    ///
    /// ໃຫ້ສັງເກດວ່າວິທີການນີ້ບໍ່ມີຜົນຕໍ່ຄວາມສາມາດຈັດສັນຂອງສາຍສະຕິງ
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `new_len` ບໍ່ນອນຢູ່ໃນເຂດແດນ [`char`].
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// ເອົາຕົວອັກສອນສຸດທ້າຍອອກຈາກ buffer string ແລະສົ່ງມັນຄືນ.
    ///
    /// ສົ່ງຄືນ [`None`] ຖ້າ `String` ນີ້ຫວ່າງເປົ່າ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// ຖອດ [`char`] ອອກຈາກ `String` ນີ້ຢູ່ທີ່ຕໍາແຫນ່ງ byte ແລະສົ່ງຄືນມັນ.
    ///
    /// ນີ້ແມ່ນການ ດຳ ເນີນງານ *O*(*n*), ເພາະມັນ ຈຳ ເປັນຕ້ອງເຮັດ ສຳ ເນົາທຸກໆອົງປະກອບໃນ buffer.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `idx` ໃຫຍ່ກວ່າຫຼືເທົ່າກັບຄວາມຍາວຂອງ `String`, ຫຼືຖ້າວ່າມັນບໍ່ນອນຢູ່ໃນຂອບເຂດ [`char`].
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// ຖອດທຸກ ຄຳ ທີ່ກົງກັນຂອງຮູບແບບ `pat` ໃນ `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// ການຈັບຄູ່ຈະຖືກກວດພົບແລະລຶບອອກໄປເລື້ອຍໆ, ດັ່ງນັ້ນໃນກໍລະນີທີ່ຮູບແບບການຊ້ອນກັນ, ມີພຽງແຕ່ຮູບແບບ ທຳ ອິດ:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // ຄວາມປອດໄພ: ການເລີ່ມຕົ້ນແລະສິ້ນສຸດຈະຢູ່ໃນຂອບເຂດ utf8 byte ຕໍ່
        // ເອກສານ Searcher
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// ຮັກສາພຽງແຕ່ຕົວອັກສອນທີ່ລະບຸໄວ້ໂດຍຜູ້ຄາດຄະເນ.
    ///
    /// ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ເອົາຕົວອັກສອນທັງຫມົດ `c` ເຊັ່ນວ່າ `f(c)` ກັບຄືນ `false`.
    /// ວິທີການນີ້ ດຳ ເນີນງານຢູ່ສະຖານທີ່, ຢ້ຽມຢາມແຕ່ລະຕົວລະຄອນຢ່າງຖືກຕ້ອງຕາມ ລຳ ດັບເດີມ, ແລະຮັກສາຄວາມເປັນລະບຽບຮຽບຮ້ອຍຂອງຕົວອັກສອນທີ່ຍັງຮັກສາໄວ້.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// ຄໍາສັ່ງທີ່ແນ່ນອນອາດຈະເປັນປະໂຫຍດຕໍ່ການຕິດຕາມສະພາບພາຍນອກ, ຄືກັບດັດສະນີ.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // ຊີ້ idx ກັບ char ຕໍ່ໄປ
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// ສະແດງກິ່ງງ່າມີລັກສະນະເປັນ `String` ນີ້ຢູ່ໃນຕໍາແຫນ່ງ byte ຕົນເອງໄດ້.
    ///
    /// ນີ້ແມ່ນການປະຕິບັດງານ *O*(*n*) ຍ້ອນວ່າມັນ ຈຳ ເປັນຕ້ອງເຮັດ ສຳ ເນົາທຸກໆອົງປະກອບໃນ buffer.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `idx` ໃຫຍ່ກວ່າຄວາມຍາວຂອງ `String`, ຫຼືຖ້າວ່າມັນບໍ່ນອນຢູ່ໃນເຂດແດນ [`char`].
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// ໃສ່ສາຍເຊືອກເຂົ້າໄປໃນ `String` ນີ້ທີ່ຕໍາ ແໜ່ງ ໄບຕ໌.
    ///
    /// ນີ້ແມ່ນການປະຕິບັດງານ *O*(*n*) ຍ້ອນວ່າມັນ ຈຳ ເປັນຕ້ອງເຮັດ ສຳ ເນົາທຸກໆອົງປະກອບໃນ buffer.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `idx` ໃຫຍ່ກວ່າຄວາມຍາວຂອງ `String`, ຫຼືຖ້າວ່າມັນບໍ່ນອນຢູ່ໃນເຂດແດນ [`char`].
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// ສົ່ງຄືນເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບເນື້ອໃນຂອງ `String` ນີ້.
    ///
    /// # Safety
    ///
    /// ຟັງຊັນນີ້ບໍ່ປອດໄພເພາະມັນບໍ່ໄດ້ກວດເບິ່ງວ່າໄບທີ່ຜ່ານໄປມັນແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ.
    /// ຖ້າຂໍ້ ຈຳ ກັດນີ້ຖືກລະເມີດ, ມັນອາດຈະກໍ່ໃຫ້ເກີດບັນຫາກ່ຽວກັບຄວາມຊົງ ຈຳ ທີ່ບໍ່ປອດໄພກັບຜູ້ໃຊ້ `String` ຂອງ future, ເພາະວ່າຫ້ອງສະ ໝຸດ ມາດຕະຖານອື່ນໆສົມມຸດວ່າ `String`s ແມ່ນ UTF-8 ທີ່ຖືກຕ້ອງ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// ສົ່ງຄືນຄວາມຍາວຂອງ `String` ນີ້, ໃນໄບ, ບໍ່ແມ່ນ [`char`] ຫຼື graphemes.
    /// ເວົ້າອີກຢ່າງ ໜຶ່ງ, ມັນອາດຈະບໍ່ແມ່ນສິ່ງທີ່ມະນຸດພິຈາລະນາຄວາມຍາວຂອງສາຍ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// ສົ່ງຄືນ `true` ຖ້າ `String` ນີ້ມີຄວາມຍາວຂອງສູນ, ແລະຖ້າບໍ່ດັ່ງນັ້ນ `false`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ແບ່ງປັນເຊືອກອອກເປັນສອງອັນທີ່ດັດສະນີໄບຕ໌ໃຫ້.
    ///
    /// ສົ່ງຄືນ `String` ທີ່ຖືກຈັດສັນ ໃໝ່.
    /// `self` ບັນຈຸມີໄບຕ໌ `[0, at)`, ແລະ `String` ທີ່ສົ່ງຄືນກໍ່ປະກອບມີໄບຕ໌ `[at, len)`.
    /// `at` ຕ້ອງຢູ່ໃນເຂດແດນຂອງຈຸດລະຫັດ UTF-8.
    ///
    /// ໃຫ້ສັງເກດວ່າຄວາມສາມາດຂອງ `self` ບໍ່ປ່ຽນແປງ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າ `at` ບໍ່ໄດ້ຢູ່ເຂດແດນຈຸດ code `UTF-8`, ຫຼືຖ້າຫາກວ່າມັນແມ່ນຫຼັງຈາກຈຸດລະຫັດສຸດທ້າຍຂອງການຊ່ອຍແນ່.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// ຕັດ `String` ນີ້, ກຳ ຈັດເນື້ອຫາທັງ ໝົດ.
    ///
    /// ໃນຂະນະທີ່ນີ້ ໝາຍ ຄວາມວ່າ `String` ຈະມີຄວາມຍາວຂອງສູນ, ມັນບໍ່ໄດ້ ສຳ ພັດກັບຄວາມສາມາດຂອງມັນ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// ສ້າງທໍ່ລະບາຍນ້ ຳ ທີ່ ກຳ ຈັດຂອບເຂດທີ່ລະບຸໄວ້ໃນ `String` ແລະໃຫ້ຜົນຜະລິດ `chars` ທີ່ຖືກຖອດອອກມາ.
    ///
    ///
    /// Note: ລະດັບຂອງອົງປະກອບຖືກຖອດອອກເຖິງແມ່ນວ່າຕົວປ່ຽນຈະບໍ່ໄດ້ຮັບການບໍລິໂພກຈົນເຖິງທີ່ສຸດ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຈຸດເລີ່ມຕົ້ນຫຼືຈຸດສິ້ນສຸດບໍ່ນອນຢູ່ໃນເຂດແດນ [`char`], ຫຼືຖ້າພວກມັນບໍ່ມີຂອບເຂດ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // ຖອດຂອບເຂດອອກຈົນກ່ວາβຈາກສາຍ
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // ລະດັບເຕັມລ້າງສາຍເຊືອກ
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // ຄວາມປອດໄພຂອງຄວາມ ຈຳ
        //
        // ຮຸ່ນ String ຂອງ Drain ບໍ່ມີບັນຫາກ່ຽວກັບຄວາມປອດໄພຂອງຄວາມຊົງ ຈຳ ຂອງລຸ້ນ vector.
        // ຂໍ້ມູນແມ່ນພຽງແຕ່ໄບຕ໌ ທຳ ມະດາ.
        // ເນື່ອງຈາກວ່າການ ກຳ ຈັດຊ່ວງລະດັບເກີດຂື້ນໃນ Drop, ຖ້າວ່າຕົວເລັ່ງລັດ Drain ຮົ່ວໄຫຼ, ການ ກຳ ຈັດມັນຈະບໍ່ເກີດຂື້ນ.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // ເອົາເງິນກູ້ອອກພ້ອມໆກັນສອງຕົວ.
        // &mut String ຈະບໍ່ສາມາດເຂົ້າເຖິງໄດ້ຈົນກວ່າມັນຈະ ໝົດ ແລ້ວ, ໃນ Drop.
        let self_ptr = self as *mut _;
        // SAFETY: `slice::range` ແລະ `is_char_boundary` ເຮັດການກວດສອບຂອບເຂດທີ່ເຫມາະສົມ.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// ຖອດຂອບເຂດທີ່ ກຳ ນົດໄວ້ໃນສາຍ, ແລະປ່ຽນມັນ ໃໝ່ ດ້ວຍສາຍເຊືອກທີ່ລະບຸໄວ້.
    /// ສາຍທີ່ໃຫ້ໄວ້ບໍ່ ຈຳ ເປັນຕ້ອງມີຄວາມຍາວເທົ່າກັບຂອບເຂດ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຈຸດເລີ່ມຕົ້ນຫຼືຈຸດສິ້ນສຸດບໍ່ນອນຢູ່ໃນເຂດແດນ [`char`], ຫຼືຖ້າພວກມັນບໍ່ມີຂອບເຂດ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // ປ່ຽນລະດັບ ໃໝ່ ຈົນກ່ວາβຈາກສາຍ
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // ຄວາມປອດໄພຂອງຄວາມ ຈຳ
        //
        // Replace_range ບໍ່ມີປັນຫາກ່ຽວກັບຄວາມປອດໄພຂອງ vector Splice.
        // ຂອງລຸ້ນ vector.ຂໍ້ມູນແມ່ນພຽງແຕ່ໄບຕ໌ ທຳ ມະດາ.

        // ຄຳ ເຕືອນ: ການໃສ່ຕົວປ່ຽນແປງນີ້ອາດຈະບໍ່ມີຜົນດີຕໍ່ (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ຄຳ ເຕືອນ: ການໃສ່ຕົວປ່ຽນແປງນີ້ອາດຈະບໍ່ມີຜົນດີຕໍ່ (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // ການ ນຳ ໃຊ້ `range` ອີກຄັ້ງກໍ່ຈະບໍ່ຖືກຕ້ອງ (#81138) ພວກເຮົາສົມມຸດວ່າຂອບເຂດທີ່ລາຍງານໂດຍ `range` ຍັງຄົງຄືເກົ່າ, ແຕ່ການປະຕິບັດທີ່ກົງກັນຂ້າມສາມາດປ່ຽນແປງລະຫວ່າງການໂທ
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// ແປງ `String` ນີ້ໃຫ້ກາຍເປັນ [`Box`]`<`[`str`] `>.
    ///
    /// ນີ້ຈະລຸດລົງຄວາມອາດສາມາດເກີນ.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// ສົ່ງຄືນທ່ອນສ່ວນຂອງ [`u8`] ທີ່ພະຍາຍາມປ່ຽນເປັນ `String`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // ບາງໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງ, ໃນ vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// ສົ່ງຄືນໄບຕ໌ທີ່ພະຍາຍາມຈະປ່ຽນເປັນ `String`.
    ///
    /// ວິທີການນີ້ແມ່ນການກໍ່ສ້າງຢ່າງລະອຽດເພື່ອຫຼີກເວັ້ນການຈັດສັນ.
    /// ມັນຈະບໍລິໂພກຂໍ້ຜິດພາດ, ການຍ້າຍອອກໄປຈາກໄບ, ສະນັ້ນບໍ່ ຈຳ ເປັນຕ້ອງເຮັດ ສຳ ເນົາໄບ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // ບາງໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງ, ໃນ vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// ເອົາ `Utf8Error` ເພື່ອເອົາລາຍລະອຽດເພີ່ມເຕີມກ່ຽວກັບຄວາມລົ້ມເຫຼວຂອງການແປງ.
    ///
    /// ປະເພດ [`Utf8Error`] ທີ່ສະ ໜອງ ໂດຍ [`std::str`] ສະແດງເຖິງຄວາມຜິດພາດທີ່ອາດຈະເກີດຂື້ນໃນເວລາທີ່ປ່ຽນເປັນ [`u8`] ເປັນ [`&str`].
    /// ໃນຄວາມຮູ້ສຶກນີ້, ມັນເປັນການປຽບທຽບກັບ `FromUtf8Error`.
    /// ເບິ່ງເອກະສານຂອງຕົນສໍາລັບລາຍລະອຽດເພີ່ມເຕີມກ່ຽວກັບການນໍາໃຊ້ມັນ.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// // ບາງໄບຕ໌ທີ່ບໍ່ຖືກຕ້ອງ, ໃນ vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ໄບທໍາອິດແມ່ນບໍ່ຖືກຕ້ອງທີ່ນີ້
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // ເນື່ອງຈາກວ່າພວກເຮົາ ກຳ ລັງແກ້ແຄ້ນກ່ຽວກັບ `String`s, ພວກເຮົາສາມາດຫລີກລ້ຽງການຈັດສັນຢ່າງ ໜ້ອຍ ໜຶ່ງ ຄັ້ງໂດຍໄດ້ຮັບສາຍ ທຳ ອິດຈາກຕົວຍຶດແລະໃສ່ສາຍຕໍ່ໆໄປ.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // ເນື່ອງຈາກວ່າພວກເຮົາມີຄວາມກະທົບກະເທືອນຫຼາຍກວ່າ CoWs, ພວກເຮົາສາມາດ (potentially) ຫລີກລ້ຽງການຈັດສັນຢ່າງ ໜ້ອຍ ໜຶ່ງ ຄັ້ງໂດຍການໄດ້ຮັບສິນຄ້າ ທຳ ອິດແລະຂໍເອົາມັນໃສ່ທຸກໆລາຍການຕໍ່ໄປ.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// ຄວາມສະດວກສະບາຍ ໝາຍ ຄວາມວ່າຜູ້ແທນທີ່ຈະໄປ `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// ສ້າງ `String` ເປົ່າ.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// ປະຕິບັດການປະຕິບັດການ `+` ສໍາລັບ concatenating ສອງເຊືອກ.
///
/// ສິ່ງນີ້ມັນຈະໃຊ້ `String` ຢູ່ເບື້ອງຊ້າຍແລະ ນຳ ໃຊ້ໂຕໂຕ້ຕອບຂອງມັນຄືນ ໃໝ່ (ປູກມັນຖ້າ ຈຳ ເປັນ).
/// ນີ້ແມ່ນເຮັດເພື່ອຫຼີກເວັ້ນການຈັດສັນ `String` ໃໝ່ ແລະຄັດລອກເນື້ອໃນທັງ ໝົດ ໃນທຸກໆການ ດຳ ເນີນງານເຊິ່ງຈະເຮັດໃຫ້ເວລາແລ່ນ *O*(*n*^ 2) ເມື່ອສ້າງສາຍ *n*-byte ໂດຍການສະຫລຸບແບບຊ້ ຳ ອີກ.
///
///
/// ສາຍອັກຂະລະຢູ່ເບື້ອງຂວາມືແມ່ນຢືມພຽງແຕ່;ເນື້ອໃນຂອງມັນຖືກຄັດລອກເຂົ້າ `String` ທີ່ສົ່ງຄືນ.
///
/// # Examples
///
/// ການຕີລາຄາສອງແຖວ `ສອງໃຊ້ເວລາ ທຳ ອິດໂດຍມູນຄ່າແລະການກູ້ຢືມຄັ້ງທີສອງ:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ຖືກຍ້າຍໄປແລະບໍ່ສາມາດໃຊ້ຢູ່ບ່ອນນີ້ອີກຕໍ່ໄປ.
/// ```
///
/// ຖ້າຫາກວ່າທ່ານຕ້ອງການທີ່ຈະຮັກສາການນໍາໃຊ້ `String` ທໍາອິດ, ທ່ານສາມາດ clone ມັນແລະຜນວກກັບ clone ແທນ:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ແມ່ນຍັງຖືກຕ້ອງຢູ່ທີ່ນີ້.
/// ```
///
/// Concatenating `&str` slices ສາມາດເຮັດໄດ້ໂດຍການປ່ຽນໂຕ ທຳ ອິດເປັນ `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// ປະຕິບັດການປະຕິບັດການ `+=` ສໍາລັບການຕໍ່ກັບ `String`.
///
/// ນີ້ມີພຶດຕິ ກຳ ດຽວກັນກັບວິທີ [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// ນາມແຝງຊະນິດ ໜຶ່ງ ສຳ ລັບ [`Infallible`].
///
/// ນາມແຝງນີ້ຢູ່ຫລັງເຂົ້າກັນໄດ້, ແລະອາດຈະໄດ້ຮັບການຄັດຄ້ານໃນທີ່ສຸດ.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// A trait ສຳ ລັບປ່ຽນມູນຄ່າໃຫ້ເປັນ `String`.
///
/// trait ນີ້ຖືກປະຕິບັດໂດຍອັດຕະໂນມັດ ສຳ ລັບປະເພດໃດກໍ່ຕາມທີ່ປະຕິບັດກັບ [`Display`] trait.
/// ໃນຖານະດັ່ງກ່າວ, `ToString` ບໍ່ຄວນຖືກປະຕິບັດໂດຍກົງ:
/// [`Display`] ຄວນໄດ້ຮັບການປະຕິບັດແທນ, ແລະທ່ານໄດ້ຮັບການຈັດຕັ້ງປະຕິບັດ `ToString` ໂດຍບໍ່ເສຍຄ່າ.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// ແປງມູນຄ່າທີ່ມອບໃຫ້ເປັນ `String`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// ໃນການຈັດຕັ້ງປະຕິບັດນີ້, ວິທີ `to_string` panics ຖ້າການປະຕິບັດ `Display` ກັບຄືນຂໍ້ຜິດພາດ.
/// ນີ້ສະແດງໃຫ້ເຫັນການປະຕິບັດ `Display` ທີ່ບໍ່ຖືກຕ້ອງເນື່ອງຈາກວ່າ `fmt::Write for String` ບໍ່ເຄີຍສົ່ງຂໍ້ຜິດພາດກັບຕົວເອງ.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // ແນວທາງທົ່ວໄປຄືການບໍ່ເຂົ້າຮ່ວມໃນ ໜ້າ ທີ່ວຽກງານທົ່ວໄປ.
    // ຢ່າງໃດກໍຕາມ, ຖອນ `#[inline]` ຈາກວິທີການນີ້ຈະເຮັດໃຫ້ regressions ທີ່ບໍ່ແມ່ນເລີຍ.
    // ເບິ່ງ <https://github.com/rust-lang/rust/pull/74852>, ຄວາມພະຍາຍາມສຸດທ້າຍທີ່ຈະພະຍາຍາມເອົາມັນອອກ.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// ແປງ `&mut str` ເປັນ `String`.
    ///
    /// ຜົນໄດ້ຮັບແມ່ນຖືກຈັດສັນໄວ້ຢູ່ໃນ heap.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test pulls ໃນ libstd, ເຊິ່ງກໍ່ໃຫ້ເກີດຂໍ້ຜິດພາດຢູ່ທີ່ນີ້
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// ແປງຊິ້ນສ່ວນ `str` ທີ່ຖືກມອບໃຫ້ເປັນ `String`.
    /// ມັນເປັນທີ່ຫນ້າສັງເກດວ່າຊິ້ນ `str` ແມ່ນເປັນເຈົ້າຂອງ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// ແປງ `String` ທີ່ມອບໃຫ້ເປັນທ່ອນ `str` ທີ່ເປັນຂອງທີ່ມີຢູ່.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// ແປງສະຕິງເປັນສາຍພັນທີ່ຢືມ.
    /// ບໍ່ມີການຈັດສັນ heap, ແລະສາຍບໍ່ໄດ້ຖືກຄັດລອກ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// ແປງສະຕິງເປັນຕົວປ່ຽນເປັນເຈົ້າຂອງ.
    /// ບໍ່ມີການຈັດສັນ heap, ແລະສາຍບໍ່ໄດ້ຖືກຄັດລອກ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// ແປງກະສານອ້າງອີງສະຕິງເຂົ້າໄປໃນຕົວປ່ຽນເງີນຢືມ.
    /// ບໍ່ມີການຈັດສັນ heap, ແລະສາຍບໍ່ໄດ້ຖືກຄັດລອກ.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// ແປງ `String` ທີ່ໃຫ້ກັບ vector `Vec` ທີ່ຖືຄ່າຂອງ `u8` ປະເພດ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// ຕົວລະບາຍນ້ ຳ ສຳ ລັບ `String`.
///
/// ໂຄງສ້າງນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`drain`] ໃນ [`String`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// ຈະຖືກ ນຳ ໃຊ້ເປັນ&'mut mut String ໃນຜູ້ ທຳ ລາຍ
    string: *mut String,
    /// ເລີ່ມຕົ້ນຂອງສ່ວນ ໜຶ່ງ ເພື່ອ ກຳ ຈັດ
    start: usize,
    /// ສິ້ນສຸດຂອງສ່ວນທີ່ຈະເອົາອອກ
    end: usize,
    /// ຊ່ວງທີ່ຍັງເຫຼືອໃນປະຈຸບັນທີ່ຈະເອົາອອກ
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // ໃຊ້ Vec::drain.
            // "Reaffirm" ຂອບເຂດການກວດສອບເພື່ອຫຼີກເວັ້ນການ panic ລະຫັດຖືກໃສ່ອີກເທື່ອຫນຶ່ງ.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// ສົ່ງຄືນສ່ວນທີ່ຍັງເຫຼືອ (ຍ່ອຍ) ຂອງໂຕປັບນີ້ເປັນສ່ວນ ໜຶ່ງ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: ຄວາມບໍ່ພໍໃຈຂອງ ASRef ແມ່ນຢູ່ຂ້າງລຸ່ມນີ້ເມື່ອມີສະຖຽນລະພາບ.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// ຄວາມບໍ່ພໍໃຈເມື່ອສະຖຽນລະພາບ `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>ສໍາລັບ Drain <'ເປັນ> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> ສຳ ລັບ Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}