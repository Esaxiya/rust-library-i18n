use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ສະສົມຂໍ້ມູນທີ່ບໍ່ສາມາດເຮັດໄດ້ໂດຍການໂຮມເຂົ້າກັນຫຼືລັກຈາກອ້າຍເອື້ອຍນ້ອງ.
    /// ຖ້າປະສົບຜົນ ສຳ ເລັດແຕ່ມີຄ່າໃຊ້ຈ່າຍໃນການຫົດຕົວຂໍ້ຂອງຜູ້ປົກຄອງ, ໃຫ້ກັບຄືນຂໍ້ຂອງພໍ່ແມ່ທີ່ນ້ອຍລົງ.
    /// ສົ່ງຄືນ `Err` ຖ້າ node ແມ່ນຮາກເປົ່າ.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ຫຸ້ນຂຶ້ນເປັນ node underfull ທີ່ເປັນໄປໄດ້, ແລະຖ້າວ່າມັນເຮັດໃຫ້ຂໍ້ຂອງພໍ່ແມ່ຂອງມັນຫົດຕົວລົງ, ຫຸ້ນພໍ່ແມ່, ໃຫ້ກັບຄືນ.
    /// ສົ່ງຄືນ `true` ຖ້າມັນຄົງຕົ້ນໄມ້, `false` ຖ້າມັນບໍ່ສາມາດເຮັດໄດ້ເພາະວ່າ node ຮາກຈະກາຍເປັນຫວ່າງ.
    ///
    /// ວິທີການນີ້ບໍ່ໄດ້ຄາດຫວັງວ່າບັນພະບຸລຸດຈະຢູ່ພາຍໃຕ້ການເຂົ້າແລະ panics ຖ້າມັນພົບກັບບັນພະບຸລຸດທີ່ເປົ່າຫວ່າງ.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// ກຳ ຈັດລະດັບທີ່ຫວ່າງຢູ່ເທິງສຸດ, ແຕ່ຮັກສາໃບທີ່ຫວ່າງໄວ້ຖ້າວ່າຕົ້ນໄມ້ທັງ ໝົດ ເປົ່າ.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// ຫຸ້ນຂຶ້ນຫລືລວມເອົາຂໍ້ຂອງ underfull ໃດໆທີ່ຢູ່ເບື້ອງຂວາຂອງຕົ້ນໄມ້.
    /// ຂໍ້ອື່ນໆ, ທີ່ບໍ່ແມ່ນຮາກຫລື edge ທີ່ຖືກຕ້ອງ, ຕ້ອງມີຢ່າງ ໜ້ອຍ MIN_LEN ແລ້ວ.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// ໂຄນຂອງ symmetric ຂອງ `fix_right_border`.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// ສະສົມຂໍ້ທີ່ຢູ່ໃຕ້ພວງມະໄລຂອງຕົ້ນໄມ້.
    /// ເສັ້ນປະສາດອື່ນໆ, ທີ່ບໍ່ແມ່ນຮາກຫລື edge ທີ່ຖືກຕ້ອງ, ຕ້ອງກຽມຕົວເພື່ອມີສ່ວນປະກອບທີ່ຖືກລັກລອບເອົາເຖິງ MIN_LEN.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // ກວດເບິ່ງວ່າເດັກນ້ອຍທີ່ຖືກຕ້ອງທີ່ສຸດແມ່ນ underfull.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // ພວກເຮົາ ຈຳ ເປັນຕ້ອງລັກ.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // ລົງຕໍ່ໄປ.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// ສະສົມເດັກເບື້ອງຊ້າຍ, ສົມມຸດວ່າເດັກທີ່ຖືກຕ້ອງບໍ່ແມ່ນສິ່ງທີ່ບໍ່ຄວນ, ແລະມີສ່ວນປະກອບພິເສດທີ່ຈະຊ່ວຍໃຫ້ເດັກນ້ອຍລວມເຂົ້າກັນໂດຍບໍ່ຕ້ອງເປັນເດັກນ້ອຍ.
    ///
    /// ສົ່ງຄືນເດັກທີ່ຊ້າຍ.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` ເພື່ອຫລີກລ້ຽງການແກ້ໄຂງ່າຍຂື້ນຖ້າການລວມຕົວເກີດຂື້ນໃນລະດັບຕໍ່ໄປ.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// ສະສົມເດັກນ້ອຍທີ່ຖືກຕ້ອງ, ສົມມຸດວ່າເດັກນ້ອຍຊ້າຍແມ່ນບໍ່ມີຄວາມ ຈຳ ເປັນ, ແລະມີຂໍ້ ກຳ ນົດທີ່ມີສ່ວນປະກອບພິເສດເພື່ອອະນຸຍາດໃຫ້ເຕົ້າໂຮມລູກຫຼານຂອງຕົນໂດຍບໍ່ຕ້ອງເປັນເດັກນ້ອຍ.
    ///
    /// ກັບຄືນທຸກບ່ອນທີ່ເດັກທີ່ ເໝາະ ສົມສິ້ນສຸດລົງ.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` ເພື່ອຫລີກລ້ຽງການແກ້ໄຂງ່າຍຂື້ນຖ້າການລວມຕົວເກີດຂື້ນໃນລະດັບຕໍ່ໄປ.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}