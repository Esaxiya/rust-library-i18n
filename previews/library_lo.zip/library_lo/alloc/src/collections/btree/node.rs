// ນີ້ແມ່ນຄວາມພະຍາຍາມໃນການຈັດຕັ້ງປະຕິບັດຕາມທີ່ ເໝາະ ສົມ
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// ເນື່ອງຈາກວ່າ Rust ຕົວຈິງແລ້ວບໍ່ມີປະເພດທີ່ເພິ່ງພາອາໄສແລະການເອີ້ນຄືນແບບ polymorphic, ພວກເຮົາເຮັດດ້ວຍຄວາມປອດໄພຫຼາຍ.
//

// ເປົ້າ ໝາຍ ສຳ ຄັນຂອງໂມດູນນີ້ແມ່ນເພື່ອຫລີກລ້ຽງຄວາມສັບສົນໂດຍການຮັກສາຕົ້ນໄມ້ວ່າເປັນຖັງທີ່ມີລັກສະນະທົ່ວໄປ (ຖ້າຮູບຊົງແປກປະຫຼາດ) ແລະຫລີກລ້ຽງການຈັດການກັບສັດປ່າ B-Tree.
//
// ໃນຖານະດັ່ງກ່າວ, ໂມດູນນີ້ບໍ່ສົນໃຈວ່າລາຍການຈະຖືກຈັດຮຽງ, ຂໍ້ໃດສາມາດເປັນ underfull, ຫຼືແມ່ນແຕ່ສິ່ງທີ່ບໍ່ມີຄວາມ ໝາຍ.ເຖິງຢ່າງໃດກໍ່ຕາມ, ພວກເຮົາອີງໃສ່ການບຸກລຸກ ຈຳ ນວນ ໜຶ່ງ:
//
// - ຕົ້ນໄມ້ຕ້ອງມີເອກະພາບ depth/height.ນີ້ ໝາຍ ຄວາມວ່າທຸກໆເສັ້ນທາງທີ່ລົງໄປຫາໃບຈາກຂໍ້ທີ່ໃຫ້ນັ້ນມີຄວາມຍາວເທົ່າກັນ.
// - Node ຂອງຄວາມຍາວ `n` ມີຄີ `n`, ຄ່າ `n`, ແລະ `n + 1` ແຄມ.
//   ນີ້ຫມາຍຄວາມວ່າເຖິງແມ່ນວ່າ node ເປົ່າກໍ່ມີຢ່າງຫນ້ອຍຫນຶ່ງ edge.
//   ສຳ ລັບຂໍ້ມູນໃບໄມ້, "having an edge" ໝາຍ ຄວາມວ່າພວກເຮົາສາມາດ ກຳ ນົດ ຕຳ ແໜ່ງ ໃນໂຫນດ, ເນື່ອງຈາກວ່າໃບຂອງໃບແມ່ນຫວ່າງແລະບໍ່ ຈຳ ເປັນຕ້ອງມີຕົວແທນຂໍ້ມູນ.
// ໃນໂຫນດພາຍໃນ, edge ທັງລະບຸ ຕຳ ແໜ່ງ ແລະມີຕົວຊີ້ໄປທີ່ຂໍ້ຂອງເດັກ.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// ການເປັນຕົວແທນທີ່ຕິດພັນຂອງຂໍ້ຂອງໃບແລະສ່ວນ ໜຶ່ງ ຂອງການເປັນຕົວແທນຂອງຂໍ້ຂອງພາຍໃນ.
struct LeafNode<K, V> {
    /// ພວກເຮົາຕ້ອງການເປັນ covariant ໃນ `K` ແລະ `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// ດັດສະນີຂອງ node ນີ້ເຂົ້າໄປໃນແຖວ `edges` ຂອງ node ຂອງພໍ່ແມ່.
    /// `*node.parent.edges[node.parent_idx]` ຄວນຈະເປັນຄືກັນກັບ `node`.
    /// ນີ້ແມ່ນການຮັບປະກັນພຽງແຕ່ເລີ່ມຕົ້ນໃນເວລາທີ່ `parent` ບໍ່ແມ່ນ.
    parent_idx: MaybeUninit<u16>,

    /// ຈຳ ນວນກະແຈແລະຄຸນຄ່າຂອງຮ້ານນີ້.
    len: u16,

    /// ຂບວນການເກັບຮັກສາຂໍ້ມູນຕົວຈິງຂອງ node.
    /// ມີພຽງແຕ່ອົງປະກອບ `len` ທຳ ອິດຂອງແຕ່ລະອາເລທີ່ຖືກເລີ່ມຕົ້ນແລະຖືກຕ້ອງ.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// ເລີ່ມ X-X ໃນສະຖານທີ່ ໃໝ່.
    unsafe fn init(this: *mut Self) {
        // ໃນຖານະເປັນນະໂຍບາຍທົ່ວໄປ, ພວກເຮົາອອກຈາກເຂດຂໍ້ມູນທີ່ບໍ່ໄດ້ຮັບການພິຈາລະນາຖ້າພວກເຂົາສາມາດເປັນໄປໄດ້, ຍ້ອນວ່ານີ້ຄວນຈະເປັນທັງສອງໄວແລະງ່າຍຕໍ່ການຕິດຕາມໃນ Valgrind.
        //
        unsafe {
            // parent_idx, ກຸນແຈ, ແລະ vals ແມ່ນທັງ ໝົດ ແມ່ນບາງທີ UsUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// ສ້າງ `LeafNode` ກ່ອງ ໃໝ່.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// ການເປັນຕົວແທນທີ່ຕິດພັນຂອງຂໍ້ຂອງພາຍໃນ.ເຊັ່ນດຽວກັນກັບ `LeafNode`s, ສິ່ງເຫລົ່ານີ້ຄວນຈະຖືກປິດບັງຢູ່ຫລັງ`BoxedNode`ເພື່ອປ້ອງກັນການຖີ້ມປຸ່ມແລະຄຸນຄ່າທີ່ບໍ່ມີຈຸດປະສົງ.
/// ຕົວຊີ້ໃດໆເຖິງ `InternalNode` ສາມາດຖືກໂຍນລົງໄປຫາ pointer ໂດຍກົງໄປຫາສ່ວນ `LeafNode` ທີ່ຢູ່ໃຕ້ຂອງຂໍ້, ເຮັດໃຫ້ລະຫັດປະຕິບັດຢູ່ໃນໃບແລະຂໍ້ຂອງພາຍໃນໂດຍທົ່ວໄປໂດຍບໍ່ ຈຳ ເປັນຕ້ອງກວດເບິ່ງວ່າສອງຂອງຕົວຊີ້ຊີ້ຢູ່ຈຸດໃດ.
///
/// ຊັບສິນນີ້ຖືກເປີດໃຊ້ໂດຍການໃຊ້ `repr(C)`.
///
#[repr(C)]
// gdb_providers.py ໃຊ້ຊື່ປະເພດນີ້ ສຳ ລັບການຄົ້ນຄວ້າພິສູດ.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// ຜູ້ຊີ້ບອກເຖິງເດັກນ້ອຍຂອງຂໍ້ນີ້.
    /// `len + 1` ສິ່ງເຫລົ່ານີ້ຖືກພິຈາລະນາໃນເບື້ອງຕົ້ນແລະຖືກຕ້ອງ, ຍົກເວັ້ນວ່າໃກ້ຈະສິ້ນສຸດລົງ, ໃນຂະນະທີ່ຕົ້ນໄມ້ຖືກຍຶດໂດຍປະເພດເງິນກູ້ `Dying`, ບາງຈຸດເຫຼົ່ານີ້ແມ່ນຫ້ອຍ.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// ສ້າງ `InternalNode` ກ່ອງ ໃໝ່.
    ///
    /// # Safety
    /// ການບຸກລຸກຂອງຂໍ້ມູນພາຍໃນແມ່ນວ່າພວກເຂົາມີຢ່າງນ້ອຍ ໜຶ່ງ ໂຕທີ່ຖືກຕ້ອງໃນເບື້ອງຕົ້ນແລະຖືກຕ້ອງ edge.
    /// ຟັງຊັນນີ້ບໍ່ໄດ້ຕັ້ງ edge ແບບນີ້.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // ພວກເຮົາຕ້ອງການເລີ່ມຕົ້ນຂໍ້ມູນເທົ່ານັ້ນ;ແຄມແມ່ນໂພດຢູນິນິທິ.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// ຕົວຊີ້ທີ່ຖືກຈັດການ, ບໍ່ແມ່ນ ໜ້າ ມືດໄປຫາຂໍ້.ນີ້ແມ່ນຕົວຊີ້ທີ່ເປັນເຈົ້າຂອງເຖິງ `LeafNode<K, V>` ຫຼືຕົວຊີ້ຊີ້ທີ່ເປັນເຈົ້າຂອງເຖິງ `InternalNode<K, V>`.
///
/// ເຖິງຢ່າງໃດກໍ່ຕາມ, `BoxedNode` ບໍ່ມີຂໍ້ມູນກ່ຽວກັບຂໍ້ມູນສອງປະເພດທີ່ມັນປະກອບດ້ວຍຕົວຈິງແລະສ່ວນ ໜຶ່ງ ແມ່ນຍ້ອນຂໍ້ມູນທີ່ຂາດນີ້ບໍ່ແມ່ນປະເພດແຍກຕ່າງຫາກແລະບໍ່ມີຜູ້ ທຳ ລາຍ.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// ຂໍ້ຮາກຂອງຕົ້ນໄມ້ທີ່ເປັນເຈົ້າຂອງ.
///
/// ໃຫ້ສັງເກດວ່າສິ່ງນີ້ບໍ່ມີຜູ້ ທຳ ລາຍ, ແລະຕ້ອງໄດ້ ທຳ ຄວາມສະອາດດ້ວຍຕົນເອງ.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// ສົ່ງຕົ້ນໄມ້ທີ່ເປັນເຈົ້າຂອງ ໃໝ່, ກັບຮາກຂອງມັນເອງເຊິ່ງໃນເບື້ອງຕົ້ນແມ່ນຫວ່າງເປົ່າ.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` ບໍ່ຕ້ອງເປັນສູນ.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// ກູ້ຢືມກັນເຊິ່ງກັນແລະກັນຂອງຂໍ້ມູນຮາກທີ່ເປັນເຈົ້າຂອງ.
    /// ບໍ່ຄືກັບ `reborrow_mut`, ມັນປອດໄພເພາະວ່າຄ່າທີ່ກັບມາບໍ່ສາມາດໃຊ້ເພື່ອ ທຳ ລາຍຮາກ, ແລະບໍ່ມີເອກະສານອ້າງອີງອື່ນໆກ່ຽວກັບຕົ້ນໄມ້.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ເລັກນ້ອຍເຊິ່ງກັນແລະກັນຍ້ອຍຂໍ້ຂອງຮາກທີ່ເປັນເຈົ້າຂອງ.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ການຫັນປ່ຽນທີ່ບໍ່ປ່ຽນແປງໄດ້ກັບເອກະສານອ້າງອີງທີ່ອະນຸຍາດໃຫ້ມີການປ່ຽນເສັ້ນທາງແລະສະ ເໜີ ວິທີການທີ່ ທຳ ລາຍແລະອື່ນໆອີກ ໜ້ອຍ ໜຶ່ງ.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// ເພີ່ມ node ພາຍໃນ ໃໝ່ ທີ່ມີ edge ດຽວທີ່ຊີ້ໄປທີ່ຂໍ້ມູນຮາກທີ່ຜ່ານມາ, ເຮັດໃຫ້ຂໍ້ ໃໝ່ ນັ້ນເປັນ node ຮາກ, ແລະສົ່ງມັນຄືນ.
    /// ນີ້ເພີ່ມລະດັບຄວາມສູງໂດຍ 1 ແລະກົງກັນຂ້າມກັບ `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, ເວັ້ນເສຍແຕ່ວ່າພວກເຮົາພຽງແຕ່ລືມພວກເຮົາຢູ່ພາຍໃນດຽວນີ້:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ກຳ ຈັດຮາກຂໍ້ມູນພາຍໃນ, ນຳ ໃຊ້ລູກ ທຳ ອິດຂອງມັນເປັນຂໍ້ ກຳ ນົດຮາກ ໃໝ່.
    /// ຍ້ອນວ່າມັນມີຈຸດປະສົງພຽງແຕ່ຖືກເອີ້ນໃນເວລາທີ່ຮາກຂອງເດັກມີພຽງເດັກນ້ອຍເທົ່ານັ້ນ, ບໍ່ມີການເຮັດຄວາມສະອາດໃດໆກ່ຽວກັບກະແຈ, ຄ່າແລະເດັກນ້ອຍອື່ນໆ.
    ///
    /// ນີ້ຫຼຸດລົງລະດັບຄວາມສູງ 1 ແລະກົງກັນຂ້າມກັບ `push_internal_level`.
    ///
    /// ຮຽກຮ້ອງໃຫ້ມີການເຂົ້າເຖິງສະເພາະວັດຖຸ `Root` ແຕ່ບໍ່ແມ່ນຂໍ້ມູນຂອງຮາກ;
    /// ມັນຈະບໍ່ເຮັດໃຫ້ມືຖືອື່ນບໍ່ຖືກຕ້ອງຫລືອ້າງອີງໃສ່ຂໍ້ມູນຮາກ.
    ///
    /// Panics ຖ້າບໍ່ມີລະດັບພາຍໃນ, ຕົວຢ່າງ, ຖ້າວ່າຮາກຂອງຕົ້ນແມ່ນໃບໄມ້.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // ຄວາມປອດໄພ: ພວກເຮົາຮັບຮອງວ່າເປັນພາຍໃນ.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // ຄວາມປອດໄພ: ພວກເຮົາໄດ້ຢືມ `self` ສະເພາະແລະປະເພດການກູ້ຢືມຂອງມັນແມ່ນສະເພາະ.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // ຄວາມປອດໄພ: edge ທຳ ອິດແມ່ນເລີ່ມຕົ້ນສະ ເໝີ.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` ແມ່ນສະເຫມີໄປ covariant ໃນ `K` ແລະ `V`, ເຖິງແມ່ນວ່າໃນເວລາທີ່ `BorrowType` ແມ່ນ `Mut`.
// ນີ້ແມ່ນທາງດ້ານເຕັກນິກທີ່ຜິດພາດ, ແຕ່ບໍ່ສາມາດສົ່ງຜົນໃຫ້ບໍ່ປອດໄພໃດໆຍ້ອນການ ນຳ ໃຊ້ພາຍໃນຂອງ `NodeRef` ເພາະວ່າພວກເຮົາມີຄວາມທົ່ວໄປທົ່ວ `K` ແລະ `V`.
//
// ຢ່າງໃດກໍ່ຕາມ, ທຸກຄັ້ງທີ່ປະເພດສາທາລະນະຫໍ່ `NodeRef`, ໃຫ້ແນ່ໃຈວ່າມັນມີຕົວແປທີ່ຖືກຕ້ອງ.
//
/// ການອ້າງອິງເຖິງຂໍ້.
///
/// ປະເພດນີ້ມີຕົວກໍານົດການຈໍານວນຫນຶ່ງທີ່ຄວບຄຸມວິທີການປະຕິບັດງານຂອງມັນ:
/// - `BorrowType`: ປະເພດ dummy ທີ່ອະທິບາຍປະເພດຂອງການກູ້ຢືມເງິນແລະປະຕິບັດຕະຫຼອດຊີວິດ.
///    - ເມື່ອນີ້ແມ່ນ `Immut<'a>`, `NodeRef` ເຮັດ ໜ້າ ທີ່ຄ້າຍຄືກັບ `&'a Node`.
///    - ເມື່ອນີ້ແມ່ນ `ValMut<'a>`, `NodeRef` ເຮັດ ໜ້າ ທີ່ຄ້າຍຄືກັບ `&'a Node` ກ່ຽວກັບຄີແລະໂຄງສ້າງຂອງຕົ້ນໄມ້, ແຕ່ຍັງຊ່ວຍໃຫ້ການອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບຄຸນຄ່າຕະຫຼອດຕົ້ນໄມ້ເພື່ອຢູ່ຮ່ວມກັນ.
///    - ເມື່ອນີ້ແມ່ນ `Mut<'a>`, `NodeRef` ເຮັດ ໜ້າ ທີ່ຄ້າຍຄືກັບ `&'a mut Node`, ເຖິງແມ່ນວ່າວິທີການແຊກຈະຊ່ວຍໃຫ້ຕົວຊີ້ປ່ຽນທີ່ປ່ຽນແປງໄດ້ກັບຄ່າທີ່ຈະຢູ່ຮ່ວມກັນ.
///    - ເມື່ອນີ້ແມ່ນ `Owned`, `NodeRef` ເຮັດ ໜ້າ ທີ່ຄ້າຍຄື `Box<Node>`, ແຕ່ບໍ່ມີຜູ້ ທຳ ລາຍ, ແລະຕ້ອງໄດ້ ທຳ ຄວາມສະອາດດ້ວຍຕົນເອງ.
///    - ເມື່ອນີ້ແມ່ນ `Dying`, `NodeRef` ຍັງເຮັດ ໜ້າ ທີ່ຄ້າຍຄື `Box<Node>`, ແຕ່ມີວິທີການ ທຳ ລາຍຕົ້ນໄມ້ເລັກນ້ອຍ, ແລະວິທີການ ທຳ ມະດາ, ໃນຂະນະທີ່ບໍ່ໄດ້ ໝາຍ ວ່າບໍ່ປອດໄພທີ່ຈະໂທ, ສາມາດຮຽກຮ້ອງ UB ຖ້າຖືກເອີ້ນວ່າບໍ່ຖືກຕ້ອງ.
///
///   ເນື່ອງຈາກວ່າ `NodeRef` ໃດອະນຸຍາດໃຫ້ ນຳ ທາງຜ່ານຕົ້ນໄມ້, `BorrowType` ໃຊ້ໄດ້ກັບຕົ້ນໄມ້ທັງ ໝົດ ຢ່າງມີປະສິດຕິພາບ, ບໍ່ພຽງແຕ່ຢູ່ໃນຂໍ້ຂອງມັນເທົ່ານັ້ນ.
/// - `K` ແລະ `V`: ເຫຼົ່ານີ້ແມ່ນປະເພດຂອງຄີແລະຄ່າທີ່ເກັບຢູ່ໃນຂໍ້.
/// - `Type`: ນີ້ສາມາດເປັນ `Leaf`, `Internal`, ຫຼື `LeafOrInternal`.
/// ເມື່ອນີ້ແມ່ນ `Leaf`, `NodeRef` ຊີ້ໃສ່ຂໍ້ໃບໃບ, ເວລານີ້ແມ່ນ `Internal`, `NodeRef` ຊີ້ໃສ່ຂໍ້ຂໍ້ພາຍໃນ, ແລະເມື່ອນີ້ແມ່ນ `LeafOrInternal`, `NodeRef` ອາດຈະຊີ້ໄປທີ່ node ປະເພດໃດກໍ່ໄດ້.
///   `Type` ມີຊື່ວ່າ `NodeType` ເມື່ອໃຊ້ນອກ `NodeRef`.
///
/// ທັງ `BorrowType` ແລະ `NodeType` ຈຳ ກັດວິທີການທີ່ພວກເຮົາປະຕິບັດ, ເພື່ອຂູດຮີດຄວາມປອດໄພຂອງຊະນິດທີ່ຄົງທີ່.ມີຂໍ້ ຈຳ ກັດໃນວິທີທີ່ພວກເຮົາສາມາດ ນຳ ໃຊ້ຂໍ້ ຈຳ ກັດດັ່ງກ່າວ:
/// - ສຳ ລັບພາລາມິເຕີຂອງແຕ່ລະປະເພດ, ພວກເຮົາພຽງແຕ່ສາມາດ ກຳ ນົດວິທີການ ໜຶ່ງ ໂດຍທົ່ວໄປຫຼື ສຳ ລັບປະເພດໃດ ໜຶ່ງ ໂດຍສະເພາະ.
/// ຍົກຕົວຢ່າງ, ພວກເຮົາບໍ່ສາມາດ ກຳ ນົດວິທີການໃດ ໜຶ່ງ ເຊັ່ນ `into_kv` ໂດຍທົ່ວໄປ ສຳ ລັບ `BorrowType` ທັງ ໝົດ, ຫຼືຄັ້ງດຽວ ສຳ ລັບທຸກໆປະເພດທີ່ມີຊີວິດຕະຫຼອດຊີວິດ, ເພາະວ່າພວກເຮົາຕ້ອງການໃຫ້ມັນກັບຄືນ `&'a` ອ້າງອີງ.
///   ດັ່ງນັ້ນ, ພວກເຮົາ ກຳ ນົດມັນ ສຳ ລັບ `Immut<'a>` ຊະນິດທີ່ມີປະສິດທິພາບ ໜ້ອຍ ທີ່ສຸດ.
/// - ພວກເຮົາບໍ່ສາມາດໄດ້ຮັບການບັງຄັບແບບບັງຄັບຈາກ `Mut<'a>` ຫາ `Immut<'a>`.
///   ສະນັ້ນ, ພວກເຮົາຕ້ອງໄດ້ໂທຫາ `reborrow` ຢ່າງຊັດເຈນກ່ຽວກັບ `NodeRef` ທີ່ມີປະສິດທິພາບສູງກວ່າເກົ່າເພື່ອໃຫ້ໄດ້ມາດຕະການເຊັ່ນ `into_kv`.
///
/// ທຸກໆວິທີການໃນ `NodeRef` ທີ່ສົ່ງເອກະສານອ້າງອີງບາງປະເພດ, ທັງ:
/// - ເອົາ `self` ໂດຍມູນຄ່າ, ແລະສົ່ງຄືນຊີວິດທີ່ປະຕິບັດໂດຍ `BorrowType`.
///   ບາງຄັ້ງ, ເພື່ອຮຽກຮ້ອງວິທີການດັ່ງກ່າວ, ພວກເຮົາ ຈຳ ເປັນຕ້ອງໂທຫາ `reborrow_mut`.
/// - ເອົາ `self` ໂດຍເອກະສານອ້າງອີງ, ແລະ (implicitly) ກັບຄືນອາຍຸການອ້າງອີງນັ້ນ, ແທນທີ່ຈະໃຊ້ຊີວິດໂດຍ `BorrowType`.
/// ໂດຍວິທີນັ້ນ, ຜູ້ກວດສອບເງິນກູ້ຮັບປະກັນວ່າ `NodeRef` ຍັງຄົງຖືກຢືມຢູ່ຕາບເທົ່າທີ່ຈະມີການ ນຳ ໃຊ້ເອກະສານອ້າງອີງທີ່ສົ່ງຄືນ
///   ວິທີການໃນການສະ ໜັບ ສະ ໜູນ ການໃສ່ກົດລະບຽບນີ້ໂດຍການສົ່ງຕົວຊີ້ວັດຖຸດິບ, ຕົວຢ່າງ, ການອ້າງອີງໂດຍບໍ່ມີອາຍຸການໃຊ້ງານໃດໆ.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// ຈຳ ນວນລະດັບທີ່ຂໍ້ແລະລະດັບຂອງໃບແຕກຕ່າງກັນ, ຈຳ ນວນຂໍ້ຄົງທີ່ທີ່ບໍ່ສາມາດອະທິບາຍໄດ້ທັງ ໝົດ ໂດຍ `Type`, ແລະຂໍ້ດັ່ງກ່າວເອງກໍ່ບໍ່ໄດ້ເກັບໄວ້.
    /// ພວກເຮົາພຽງແຕ່ຕ້ອງການເກັບຮັກສາລະດັບຄວາມສູງຂອງຂໍ້ມູນຂອງຮາກ, ແລະມາຈາກລະດັບຄວາມສູງຂອງຂໍ້ອື່ນໆຈາກມັນ.
    /// ຕ້ອງເປັນສູນຖ້າ `Type` ແມ່ນ `Leaf` ແລະບໍ່ແມ່ນສູນຖ້າ `Type` ແມ່ນ `Internal`.
    ///
    ///
    height: usize,
    /// ຕົວຊີ້ໄປທີ່ໃບຫຼືຂໍ້ພາຍໃນ.
    /// ຄໍານິຍາມຂອງ `InternalNode` ຮັບປະກັນວ່າຕົວຊີ້ແມ່ນຖືກຕ້ອງໂດຍວິທີໃດກໍ່ຕາມ.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ຖີ້ມເອກະສານອ້າງອີງຂໍ້ທີ່ຖືກບັນຈຸເປັນ `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ສະແດງຂໍ້ມູນຂອງຂໍ້ມູນພາຍໃນ.
    ///
    /// ສົ່ງຄືນ ptr ຜົງດິບເພື່ອຫລີກລ້ຽງການອ້າງອີງອື່ນໆທີ່ບໍ່ຖືກຕ້ອງກັບ node ນີ້.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // ຄວາມປອດໄພ: ປະເພດ node static ແມ່ນ `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// ເຮັດໃຫ້ການເຂົ້າເຖິງຂໍ້ມູນຂອງຂໍ້ມູນພາຍໃນເປັນພິເສດ.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ຊອກຫາຄວາມຍາວຂອງຂໍ້.ນີ້ແມ່ນ ຈຳ ນວນກຸນແຈຫລືຄ່າຕ່າງໆ.
    /// ຈຳ ນວນຂອບແມ່ນ `len() + 1`.
    /// ໃຫ້ສັງເກດວ່າ, ເຖິງວ່າຈະມີຄວາມປອດໄພ, ການໂທຫາ ໜ້າ ທີ່ນີ້ສາມາດມີຜົນຂ້າງຄຽງຂອງການອ້າງອີງການປ່ຽນແປງທີ່ບໍ່ຖືກຕ້ອງທີ່ລະຫັດບໍ່ປອດໄພໄດ້ສ້າງຂື້ນ.
    ///
    pub fn len(&self) -> usize {
        // ສິ່ງ ສຳ ຄັນ, ພວກເຮົາເຂົ້າເຖິງສະ ໜາມ `len` ເທົ່ານັ້ນ.
        // ຖ້າ BorrowType ແມ່ນ marker::ValMut, ອາດຈະມີເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບຄຸນຄ່າທີ່ພວກເຮົາຕ້ອງບໍ່ໄດ້ລົບລ້າງ.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// ເອົາ ຈຳ ນວນຂອງລະດັບທີ່ຂໍ້ແລະໃບໃບແຍກ.
    /// ລະດັບຄວາມສູງສູນ ໝາຍ ເຖິງຂໍ້ຂອງຂໍ້ແມ່ນໃບຂອງມັນເອງ.
    /// ຖ້າທ່ານເຫັນຕົ້ນໄມ້ທີ່ມີຮາກຢູ່ເທິງສຸດ, ຕົວເລກບອກວ່າບ່ອນໃດທີ່ຍົກສູງຂື້ນຂອງຂໍ້.
    /// ຖ້າທ່ານເຫັນຕົ້ນໄມ້ທີ່ມີໃບຢູ່ດ້ານເທິງ, ຕົວເລກບອກວ່າຕົ້ນໄມ້ໃຫຍ່ສູງກ່ວາ node.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// ຊົ່ວຄາວເອົາເອກະສານອ້າງອີງອື່ນທີ່ບໍ່ປ່ຽນແປງໄປສູ່ໂຫນດດຽວກັນ.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ເອົາຊິ້ນສ່ວນຂອງໃບຫຼືໃບພາຍໃນ.
    ///
    /// ສົ່ງຄືນ ptr ຜົງດິບເພື່ອຫລີກລ້ຽງການອ້າງອີງອື່ນໆທີ່ບໍ່ຖືກຕ້ອງກັບ node ນີ້.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // ໂຫນດຕ້ອງຖືກຕ້ອງຢ່າງ ໜ້ອຍ ສ່ວນຂອງ LeafNode.
        // ນີ້ບໍ່ແມ່ນເອກະສານອ້າງອີງໃນປະເພດ NodeRef ເພາະວ່າພວກເຮົາບໍ່ຮູ້ວ່າມັນຄວນຈະເປັນເອກະລັກຫລືແບ່ງປັນກັນ.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ຊອກຫາພໍ່ແມ່ຂອງ node ໃນປະຈຸບັນ.
    /// ກັບຄືນ `Ok(handle)` ຖ້າ node ປັດຈຸບັນມີພໍ່ແມ່, ບ່ອນທີ່ `handle` ຊີ້ໄປ edge ຂອງພໍ່ແມ່ທີ່ຊີ້ໄປທີ່ node ປັດຈຸບັນ.
    ///
    /// ສົ່ງຄືນ `Err(self)` ຖ້າ node ປັດຈຸບັນບໍ່ມີພໍ່ແມ່, ໃຫ້ `NodeRef` ເດີມ.
    ///
    /// ຊື່ວິທີການຄາດເດົາວ່າທ່ານເບິ່ງຮູບພາບຕົ້ນໄມ້ທີ່ມີ node ຮາກຢູ່ເທິງສຸດ.
    ///
    /// `edge.descend().ascend().unwrap()` ແລະ `node.ascend().unwrap().descend()` ຄວນທັງສອງ, ເມື່ອປະສົບຜົນ ສຳ ເລັດ, ບໍ່ຕ້ອງເຮັດຫຍັງເລີຍ.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // ພວກເຮົາ ຈຳ ເປັນຕ້ອງໃຊ້ຕົວຊີ້ວັດຖຸດິບໃຫ້ກັບຂໍ້ເພາະວ່າຖ້າ BorrowType ແມ່ນ marker::ValMut, ອາດຈະມີການອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກ່ຽວກັບຄຸນຄ່າທີ່ພວກເຮົາບໍ່ຕ້ອງ ທຳ ລາຍ.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// ໃຫ້ສັງເກດວ່າ `self` ຕ້ອງບໍ່ແມ່ນຄວາມຫມາຍ.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// ໃຫ້ສັງເກດວ່າ `self` ຕ້ອງບໍ່ແມ່ນຄວາມຫມາຍ.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// ເອົາສ່ວນຂອງໃບຫຼືຂໍ້ພາຍໃນຂອງຕົ້ນໄມ້ທີ່ບໍ່ປ່ຽນແປງ.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // ຄວາມປອດໄພ: ບໍ່ມີເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບຕົ້ນໄມ້ທີ່ຢືມເປັນ `Immut` ນີ້.
        unsafe { &*ptr }
    }

    /// ໂຍນມຸມມອງເຂົ້າໄປໃນຄີທີ່ເກັບໄວ້ໃນ node.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// ຄ້າຍຄືກັນກັບ `ascend`, ໄດ້ຮັບເອກະສານອ້າງອີງເຖິງຂໍ້ຂອງ node ຂອງພໍ່ແມ່, ແຕ່ຍັງມີການຈັດການກັບ node ປັດຈຸບັນໃນຂັ້ນຕອນ.
    /// ນີ້ແມ່ນບໍ່ປອດໄພເພາະວ່າ node ປັດຈຸບັນຍັງສາມາດເຂົ້າເຖິງໄດ້ເຖິງວ່າຈະມີການຈັດການກັບບ້ານ.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ບໍ່ມີຄວາມ ໝັ້ນ ໃຈຕໍ່ຜູ້ລວບລວມຂໍ້ມູນທີ່ສະຖຽນລະພາບທີ່ຂໍ້ນີ້ແມ່ນ `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ບໍ່ມີຄວາມ ໝັ້ນ ໃຈຕໍ່ຜູ້ລວບລວມຂໍ້ມູນທີ່ສະຖິດວ່າຂໍ້ນີ້ແມ່ນ `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// ຊົ່ວຄາວເອົາຂໍ້ອ້າງອີງອື່ນທີ່ປ່ຽນແປງໄດ້ກັບ node ດຽວກັນ.ລະວັງ, ເພາະວ່າວິທີການນີ້ແມ່ນອັນຕະລາຍຫຼາຍ, ສອງເທື່ອເພາະວ່າມັນອາດຈະບໍ່ເປັນອັນຕະລາຍທັນທີ.
    ///
    /// ເນື່ອງຈາກວ່າຕົວຊີ້ຊີ້ທີ່ສາມາດປ່ຽນໄດ້ສາມາດແລ່ນໄປທົ່ວທຸກບ່ອນອ້ອມຕົ້ນໄມ້, ຕົວຊີ້ວັດທີ່ສົ່ງຄືນສາມາດໃຊ້ໄດ້ງ່າຍເພື່ອເຮັດໃຫ້ຕົວຊີ້ຕົ້ນເດີມຫ້ອຍ, ອອກຈາກຂອບ, ຫຼືບໍ່ຖືກຕ້ອງຕາມກົດລະບຽບການຢືມ.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) ພິຈາລະນາເພີ່ມພາລາມິເຕີປະເພດອື່ນໃຫ້ແກ່ `NodeRef` ທີ່ ຈຳ ກັດການ ນຳ ໃຊ້ວິທີການ ນຳ ທາງໄປຫາຕົວຊີ້ບອກທີ່ໄດ້ຮັບການຕອບແທນ, ປ້ອງກັນຄວາມປອດໄພນີ້.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ເລັ່ງການເຂົ້າເຖິງສ່ວນຂອງໃບຂອງສ່ວນໃດສ່ວນ ໜື່ງ ຂອງໃບຫຼືພາຍໃນ.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // ຄວາມປອດໄພ: ພວກເຮົາມີການເຂົ້າເຖິງຂໍ້ສະເພາະ.
        unsafe { &mut *ptr }
    }

    /// ສະ ເໜີ ການເຂົ້າເຖິງສ່ວນສະເພາະຂອງສ່ວນຂອງໃບຫຼືຂໍ້ພາຍໃນ.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // ຄວາມປອດໄພ: ພວກເຮົາມີການເຂົ້າເຖິງຂໍ້ສະເພາະ.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// ບັງຄັບການເຂົ້າເຖິງສະເພາະກັບສ່ວນປະກອບຂອງພື້ນທີ່ເກັບມ້ຽນທີ່ ສຳ ຄັນ.
    ///
    /// # Safety
    /// `index` ແມ່ນຢູ່ໃນຂອບເຂດຂອງ 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // ປອດໄພ: ຜູ້ໂທຈະບໍ່ສາມາດໂທຫາວິທີການດ້ວຍຕົນເອງຕື່ມອີກ
        // ຈົນກ່ວາກະສານອ້າງອີງທີ່ ສຳ ຄັນຈະຖືກລຸດລົງ, ດັ່ງທີ່ພວກເຮົາມີການເຂົ້າເຖິງທີ່ເປັນເອກະລັກ ສຳ ລັບອາຍຸການກູ້ຢືມ.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// ເລັ່ງການເຂົ້າເຖິງອົງປະກອບສະເພາະຫຼືສ່ວນ ໜຶ່ງ ຂອງພື້ນທີ່ເກັບຂໍ້ມູນຄ່າຂອງຂໍ້.
    ///
    /// # Safety
    /// `index` ແມ່ນຢູ່ໃນຂອບເຂດຂອງ 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // ປອດໄພ: ຜູ້ໂທຈະບໍ່ສາມາດໂທຫາວິທີການດ້ວຍຕົນເອງຕື່ມອີກ
        // ຈົນກ່ວາການອ້າງອິງມູນຄ່າຖືກຫຼຸດລົງ, ຍ້ອນວ່າພວກເຮົາມີການເຂົ້າເຖິງທີ່ເປັນເອກະລັກຕະຫຼອດຊີວິດຂອງຜູ້ກູ້ຢືມ.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// ເລັ່ງການເຂົ້າເຖິງສ່ວນປະກອບສະເພາະຫຼືສ່ວນຂອງພື້ນທີ່ເກັບຂໍ້ມູນຂອງ node ສຳ ລັບເນື້ອໃນຂອງ edge.
    ///
    /// # Safety
    /// `index` ແມ່ນຢູ່ໃນຂອບເຂດຂອງ 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // ປອດໄພ: ຜູ້ໂທຈະບໍ່ສາມາດໂທຫາວິທີການດ້ວຍຕົນເອງຕື່ມອີກ
        // ຈົນກ່ວາການອ້າງອິງ edge ແມ່ນຖືກລຸດລົງ, ຍ້ອນວ່າພວກເຮົາມີການເຂົ້າເຖິງທີ່ເປັນເອກະລັກ ສຳ ລັບອາຍຸການກູ້ຢືມ.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - node ມີຫຼາຍກວ່າ `idx` ອົງປະກອບທີ່ເລີ່ມຕົ້ນ.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // ພວກເຮົາພຽງແຕ່ສ້າງເອກະສານອ້າງອີງເຖິງອົງປະກອບ ໜຶ່ງ ທີ່ພວກເຮົາສົນໃຈ, ເພື່ອຫລີກລ້ຽງການອ້າງຊື່ສຽງທີ່ມີການອ້າງອີງທີ່ໂດດເດັ່ນຕໍ່ກັບອົງປະກອບອື່ນໆ, ໂດຍສະເພາະ, ຜູ້ທີ່ກັບຄືນໄປຫາຜູ້ໂທໃນເວລາກ່າວເຖິງກ່ອນ ໜ້າ ນີ້.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // ພວກເຮົາຕ້ອງໄດ້ບີບບັງຄັບໃຫ້ກັບຕົວຊີ້ວັດຂບວນທີ່ບໍ່ຖືກຕ້ອງເພາະວ່າ Rust ສະບັບ #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// ເຮັດໃຫ້ການເຂົ້າເຖິງສະເພາະກັບຄວາມຍາວຂອງຂໍ້.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ກໍານົດການເຊື່ອມໂຍງຂອງ node ກັບພໍ່ແມ່ edge ຂອງມັນ, ໂດຍບໍ່ຕ້ອງເຮັດໃຫ້ການອ້າງອິງອື່ນເຂົ້າໄປໃນ node.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// ລ້າງລິ້ງຂອງຮາກກັບ edge ແມ່ຂອງມັນ.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// ເພີ່ມຄູ່ຄ່າທີ່ມີຄ່າ ສຳ ຄັນໃຫ້ຈົບຂອງຂໍ້.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// ທຸກໆລາຍການທີ່ສົ່ງຄືນໂດຍ `range` ແມ່ນດັດສະນີ edge ທີ່ຖືກຕ້ອງ ສຳ ລັບ node.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// ເພີ່ມຄູ່ທີ່ມີຄ່າ, ແລະ edge ໄປທາງຂວາຂອງຄູ່ນັ້ນ, ຈົນຮອດປາຍຂອງຂໍ້.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ກວດເບິ່ງວ່າ node ແມ່ນ node `Internal` ຫຼື n `Leaf` node.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// ການອ້າງອີງເຖິງຄູ່ ສຳ ຄັນທີ່ມີຄ່າ ສຳ ຄັນຫຼື edge ພາຍໃນຂໍ້.
/// ຕົວກໍານົດການ `Node` ຕ້ອງເປັນ `NodeRef`, ໃນຂະນະທີ່ `Type` ອາດຈະເປັນ `KV` (ຫມາຍໃສ່ຕົວຈັບໃສ່ຄູ່ຄ່າທີ່ມີຄ່າ-key) ຫຼື `Edge` (ໝາຍ ໃສ່ຈັບຢູ່ໃນ edge).
///
/// ໃຫ້ສັງເກດວ່າແມ້ແຕ່ຂໍ້ຂອງ `Leaf` ສາມາດມີ `Edge` ຈັບໄດ້.
/// ແທນທີ່ຈະເປັນຕົວແທນໃຫ້ຕົວຊີ້ໄປທີ່ຂໍ້ເດັກ, ສິ່ງເຫຼົ່ານີ້ເປັນຕົວແທນສະຖານທີ່ທີ່ເດັກນ້ອຍຈະໄປຫາລະຫວ່າງຄູ່ທີ່ມີຄ່າ.
/// ຍົກຕົວຢ່າງ, ໃນ node ທີ່ມີຄວາມຍາວ 2, ອາດຈະມີ 3 ສະຖານທີ່ edge ທີ່ເປັນໄປໄດ້, ໜຶ່ງ ຢູ່ເບື້ອງຊ້າຍຂອງ node, ໜຶ່ງ ຢູ່ລະຫວ່າງສອງຄູ່, ແລະຢູ່ເບື້ອງຂວາຂອງ node.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// ພວກເຮົາບໍ່ຕ້ອງການ `#[derive(Clone)]` ໂດຍທົ່ວໄປ, ເພາະວ່າເວລາດຽວເທົ່ານັ້ນທີ່ `Node` ຈະເປັນ 'Clone`able ແມ່ນເມື່ອມັນເປັນເອກະສານອ້າງອີງທີ່ບໍ່ສາມາດປ່ຽນແປງໄດ້ແລະດັ່ງນັ້ນ `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// ດຶງເອົາຂໍ້ທີ່ຂໍ້ມູນທີ່ປະກອບດ້ວຍ edge ຫຼືຄູ່ທີ່ມີຄ່າ-key handle ນີ້.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// ກັບຄືນ ຕຳ ແໜ່ງ ຂອງໂຕຈັບນີ້ໃນ node.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// ສ້າງຕົວຈັດການ ໃໝ່ ໃຫ້ກັບຄູ່ທີ່ມີຄ່າ ສຳ ຄັນໃນ `node`.
    /// ບໍ່ປອດໄພເພາະຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// ອາດຈະເປັນການຈັດຕັ້ງປະຕິບັດສາທາລະນະຂອງພາກສ່ວນບາງສ່ວນ, ແຕ່ໃຊ້ໃນໂມດູນນີ້ເທົ່ານັ້ນ.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// ຊົ່ວຄາວເອົາຕົວຈັບອື່ນທີ່ບໍ່ປ່ຽນແປງໄດ້ຢູ່ບ່ອນດຽວກັນ.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // ພວກເຮົາບໍ່ສາມາດໃຊ້ Handle::new_kv ຫຼື Handle::new_edge ເພາະວ່າພວກເຮົາບໍ່ຮູ້ປະເພດຂອງພວກເຮົາ
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// ບໍ່ມີຄວາມ ໝັ້ນ ໃຈຕໍ່ຜູ້ລວບລວມຂໍ້ມູນທີ່ສະຖຽນລະພາບທີ່ຂໍ້ມືຂອງມືຈັບແມ່ນ `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// ໃຊ້ເວລາອີກຊົ່ວຄາວ, ຈັບຈັບທີ່ສາມາດປ່ຽນແປງໄດ້ໃນສະຖານທີ່ດຽວກັນ.
    /// ລະວັງ, ເພາະວ່າວິທີການນີ້ແມ່ນອັນຕະລາຍຫຼາຍ, ສອງເທື່ອເພາະວ່າມັນອາດຈະບໍ່ເປັນອັນຕະລາຍທັນທີ.
    ///
    ///
    /// ສຳ ລັບລາຍລະອຽດເບິ່ງທີ່ `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // ພວກເຮົາບໍ່ສາມາດໃຊ້ Handle::new_kv ຫຼື Handle::new_edge ເພາະວ່າພວກເຮົາບໍ່ຮູ້ປະເພດຂອງພວກເຮົາ
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// ສ້າງຕົວຈັດການ ໃໝ່ ໃຫ້ກັບ edge ໃນ `node`.
    /// ບໍ່ປອດໄພເພາະຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// ໃຫ້ດັດສະນີ edge ທີ່ພວກເຮົາຕ້ອງການທີ່ຈະເອົາເຂົ້າໃນໂຫນດທີ່ເຕັມໄປດ້ວຍຄວາມສາມາດ, ລວບລວມດັດສະນີ KV ທີ່ມີປະສິດຕິພາບຂອງຈຸດແບ່ງປັນແລະບ່ອນທີ່ຕ້ອງປະຕິບັດການແຊກ.
///
/// ເປົ້າ ໝາຍ ຂອງຈຸດແບ່ງປັນແມ່ນເພື່ອໃຫ້ກຸນແຈແລະຄຸນຄ່າຂອງມັນສິ້ນສຸດລົງໃນ node ພໍ່ແມ່;
/// ກະແຈ, ຄ່າແລະຂອບດ້ານຊ້າຍຂອງຈຸດແບ່ງປັນກາຍເປັນເດັກນ້ອຍຊ້າຍ;
/// ກະແຈ, ຄ່າແລະຂອບດ້ານຂວາຂອງຈຸດແບ່ງປັນກາຍເປັນເດັກທີ່ຖືກຕ້ອງ.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // ບັນຫາ Rust #74834 ພະຍາຍາມອະທິບາຍກົດລະບຽບເຫລົ່ານີ້.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ສະແດງກິ່ງງ່າຄູ່ທີ່ມີຄ່າ ສຳ ຄັນ ໃໝ່ ລະຫວ່າງຄູ່ທີ່ມີຄ່າ ສຳ ຄັນໄປທາງຂວາແລະຊ້າຍຂອງ edge ນີ້.
    /// ວິທີການນີ້ສົມມຸດວ່າມັນມີພື້ນທີ່ພຽງພໍໃນ node ສຳ ລັບຄູ່ ໃໝ່ ພໍດີ.
    ///
    /// ຕົວຊີ້ຊີ້ທີ່ສົ່ງຄືນມາໃສ່ກັບມູນຄ່າທີ່ໃສ່ໄວ້.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ສະແດງກິ່ງງ່າຄູ່ທີ່ມີຄ່າ ສຳ ຄັນ ໃໝ່ ລະຫວ່າງຄູ່ທີ່ມີຄ່າ ສຳ ຄັນໄປທາງຂວາແລະຊ້າຍຂອງ edge ນີ້.
    /// ວິທີການນີ້ຈະແຍກອອກຈາກ node ຖ້າບໍ່ມີຫ້ອງພຽງພໍ.
    ///
    /// ຕົວຊີ້ຊີ້ທີ່ສົ່ງຄືນມາໃສ່ກັບມູນຄ່າທີ່ໃສ່ໄວ້.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ແກ້ໄຂຕົວຊີ້ແລະຈຸດດັດແກ້ຂອງພໍ່ແມ່ທີ່ຢູ່ໃນຂໍ້ ກຳ ນົດເດັກທີ່ edge ນີ້ເຊື່ອມໂຍງກັບ.
    /// ນີ້ແມ່ນສິ່ງທີ່ເປັນປະໂຫຍດເມື່ອການຈັດແຈງແຄມຂອງໄດ້ຖືກປ່ຽນແປງ,
    fn correct_parent_link(self) {
        // ສ້າງແຜ່ນຮອງໂດຍບໍ່ຕ້ອງໃຊ້ເອກະສານອ້າງອິງອື່ນໆຕໍ່ node.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ສະແດງກິ່ງງ່າຄູ່ ສຳ ຄັນແລະ edge ເຊິ່ງຈະໄປທາງຂວາຂອງຄູ່ ໃໝ່ ລະຫວ່າງ edge ນີ້ແລະຄູ່ທີ່ມີຄ່າ ສຳ ຄັນຢູ່ເບື້ອງຂວາຂອງ edge ນີ້.
    /// ວິທີການນີ້ສົມມຸດວ່າມັນມີພື້ນທີ່ພຽງພໍໃນ node ສຳ ລັບຄູ່ ໃໝ່ ພໍດີ.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// ສະແດງກິ່ງງ່າຄູ່ ສຳ ຄັນແລະ edge ເຊິ່ງຈະໄປທາງຂວາຂອງຄູ່ ໃໝ່ ລະຫວ່າງ edge ນີ້ແລະຄູ່ທີ່ມີຄ່າ ສຳ ຄັນຢູ່ເບື້ອງຂວາຂອງ edge ນີ້.
    /// ວິທີການນີ້ຈະແຍກອອກຈາກ node ຖ້າບໍ່ມີຫ້ອງພຽງພໍ.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ສະແດງກິ່ງງ່າຄູ່ທີ່ມີຄ່າ ສຳ ຄັນ ໃໝ່ ລະຫວ່າງຄູ່ທີ່ມີຄ່າ ສຳ ຄັນໄປທາງຂວາແລະຊ້າຍຂອງ edge ນີ້.
    /// ວິທີການນີ້ຈະແຍກອອກຈາກ node ຖ້າບໍ່ມີຫ້ອງພຽງພໍ, ແລະພະຍາຍາມເອົາສ່ວນທີ່ແຍກອອກມາເຂົ້າໄປໃນ node ຂອງຜູ້ປົກຄອງຄືນ, ຈົນກວ່າຈະຮອດຮາກ.
    ///
    ///
    /// ຖ້າຜົນໄດ້ຮັບທີ່ສົ່ງຄືນແມ່ນ `Fit`, ຂໍ້ຈັບຂອງມັນສາມາດເປັນຂໍ້ຂອງ edge ນີ້ຫຼືບັນພະບູລຸດ.
    /// ຖ້າຜົນໄດ້ຮັບທີ່ສົ່ງຄືນແມ່ນ `Split`, `left` ພາກສະຫນາມຈະເປັນຂໍ້ມູນຮາກ.
    /// ຕົວຊີ້ຊີ້ທີ່ສົ່ງຄືນມາໃສ່ກັບມູນຄ່າທີ່ໃສ່ໄວ້.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// ຊອກຫາຂໍ້ທີ່ຊີ້ບອກໂດຍ edge ນີ້.
    ///
    /// ຊື່ວິທີການຄາດເດົາວ່າທ່ານເບິ່ງຮູບພາບຕົ້ນໄມ້ທີ່ມີ node ຮາກຢູ່ເທິງສຸດ.
    ///
    /// `edge.descend().ascend().unwrap()` ແລະ `node.ascend().unwrap().descend()` ຄວນທັງສອງ, ເມື່ອປະສົບຜົນ ສຳ ເລັດ, ບໍ່ຕ້ອງເຮັດຫຍັງເລີຍ.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // ພວກເຮົາ ຈຳ ເປັນຕ້ອງໃຊ້ຕົວຊີ້ວັດຖຸດິບໃຫ້ກັບຂໍ້ເພາະວ່າຖ້າ BorrowType ແມ່ນ marker::ValMut, ອາດຈະມີການອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກ່ຽວກັບຄຸນຄ່າທີ່ພວກເຮົາບໍ່ຕ້ອງ ທຳ ລາຍ.
        // ບໍ່ມີຄວາມກັງວົນໃຈໃນການເຂົ້າເຖິງສະ ໜາມ ຄວາມສູງເພາະວ່າມູນຄ່ານັ້ນຖືກຄັດລອກ.
        // ຈົ່ງລະວັງວ່າ, ເມື່ອຕົວຊີ້ວັດຂໍ້ໄດ້ຮັບການພິຈາລະນາ, ພວກເຮົາເຂົ້າເຖິງຂອບແຖວໂດຍມີເອກະສານອ້າງອີງ (Rust ສະບັບ #73987) ແລະເຮັດໃຫ້ຂໍ້ມູນອ້າງອີງອື່ນໆທີ່ບໍ່ຖືກຕ້ອງຫຼືຢູ່ພາຍໃນອາຄານຄວນຢູ່ອ້ອມຮອບ.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // ພວກເຮົາບໍ່ສາມາດເອີ້ນວິທີການທີ່ ສຳ ຄັນແລະມູນຄ່າແຍກຕ່າງຫາກ, ເພາະວ່າການໂທຄັ້ງທີສອງເຮັດໃຫ້ການອ້າງອິງສົ່ງຄືນໂດຍ ທຳ ອິດ.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// ປ່ຽນຄີແລະຄ່າທີ່ KV handle ໝາຍ ເຖິງ.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// ຊ່ວຍການຈັດຕັ້ງປະຕິບັດ `split` ສຳ ລັບ `NodeType` ໂດຍສະເພາະ, ໂດຍການເບິ່ງແຍງຂໍ້ມູນໃບ.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// ແບ່ງປັນຂໍ້ມູນທີ່ຕິດພັນເປັນສາມສ່ວນ:
    ///
    /// - ໂຫນດຖືກຕັດໃຫ້ສັ້ນລົງພຽງແຕ່ມີຄູ່ ສຳ ຄັນທີ່ຢູ່ເບື້ອງຊ້າຍຂອງມືຈັບນີ້.
    /// - ກຸນແຈແລະມູນຄ່າທີ່ຊີ້ໃຫ້ເຫັນໂດຍການຈັດການນີ້ຈະຖືກສະກັດອອກ.
    /// - ທຸກໆຄູ່ທີ່ມີຄ່າ ສຳ ຄັນຢູ່ເບື້ອງຂວາຂອງມືຈັບນີ້ແມ່ນຖືກຈັດເຂົ້າໃນຂໍ້ທີ່ຖືກຈັດສັນ ໃໝ່.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// ຖອດຄູ່ ຄຳ ທີ່ມີຄ່າ ສຳ ຄັນທີ່ຊີ້ໄປໂດຍຈັບນີ້ແລະສົ່ງມັນຄືນ, ພ້ອມກັບ edge ທີ່ຄູ່ຄ່າ ສຳ ຄັນຖືກລົ້ມລົງ.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// ແບ່ງປັນຂໍ້ມູນທີ່ຕິດພັນເປັນສາມສ່ວນ:
    ///
    /// - ໂຫນດຖືກຕັດອອກໄປພຽງແຕ່ປະກອບດ້ວຍຂອບແລະຄູ່ທີ່ສໍາຄັນທີ່ມີມູນຄ່າທາງດ້ານຊ້າຍຂອງຈັບນີ້.
    /// - ກຸນແຈແລະມູນຄ່າທີ່ຊີ້ໃຫ້ເຫັນໂດຍການຈັດການນີ້ຈະຖືກສະກັດອອກ.
    /// - ທຸກຂອບແລະຄູ່ທີ່ມີຄ່າ ສຳ ຄັນຢູ່ເບື້ອງຂວາຂອງຕົວຈັດການນີ້ແມ່ນຖືກຈັດເຂົ້າໃນຂໍ້ທີ່ຖືກຈັດສັນ ໃໝ່.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// ເປັນຕົວແທນໃຫ້ແກ່ກອງປະຊຸມ ສຳ ລັບການປະເມີນແລະປະຕິບັດການດຸ່ນດ່ຽງຮອບຄູ່ຄູ່ມູນຄ່າພາຍໃນ.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ເລືອກສະພາບການສົມດຸນທີ່ກ່ຽວຂ້ອງກັບຂໍ້ທີ່ເປັນເດັກນ້ອຍ, ດັ່ງນັ້ນ, ລະຫວ່າງ KV ທັນທີໄປທາງຊ້າຍຫຼືເບື້ອງຂວາໃນ node ພໍ່ແມ່.
    /// ສົ່ງຄືນ `Err` ຖ້າບໍ່ມີພໍ່ແມ່.
    /// Panics ຖ້າພໍ່ແມ່ເປົ່າ.
    ///
    /// ມັກເບື້ອງຊ້າຍ, ເພື່ອໃຫ້ ເໝາະ ສົມທີ່ສຸດຖ້າ node ທີ່ໃຫ້ໄວ້ແມ່ນ underfull, ໝາຍ ຄວາມວ່ານີ້ມີພຽງແຕ່ມັນມີສ່ວນປະກອບ ໜ້ອຍ ກວ່າອ້າຍເອື້ອຍນ້ອງເບື້ອງຊ້າຍແລະກ່ວາອ້າຍເອື້ອຍນ້ອງທີ່ຖືກຕ້ອງ, ຖ້າມີ.
    /// ໃນກໍລະນີດັ່ງກ່າວ, ການລວມຕົວກັບອ້າຍເອື້ອຍນ້ອງຊ້າຍແມ່ນໄວກວ່າ, ເພາະວ່າພວກເຮົາພຽງແຕ່ຕ້ອງການຍ້າຍອົງປະກອບ N ຂອງ node, ແທນທີ່ຈະປ່ຽນພວກມັນໄປທາງຂວາແລະຍ້າຍຫຼາຍກ່ວາອົງປະກອບ N ຢູ່ທາງ ໜ້າ.
    /// ການລັກຂະໂມຍຈາກອ້າຍເອື້ອຍນ້ອງຊ້າຍແມ່ນຍັງໄວກວ່າປົກກະຕິ, ເພາະວ່າພວກເຮົາພຽງແຕ່ຕ້ອງການປ່ຽນອົງປະກອບ N ຂອງ Node ໄປທາງຂວາ, ແທນທີ່ຈະປ່ຽນຢ່າງ ໜ້ອຍ N ຂອງອົງປະກອບຂອງອ້າຍເອື້ອຍນ້ອງໄປທາງຊ້າຍ.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// ຜົນຕອບແທນບໍ່ວ່າຈະເປັນການໂຮມເປັນໄປໄດ້, ie, ບໍ່ວ່າຈະມີຫ້ອງພຽງພໍໃນ node ເພື່ອສົມທົບການ KV ກາງກັບທັງສອງຂໍ້ຂອງລູກຕິດກັນ.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// ປະຕິບັດການລວມຕົວແລະຊ່ວຍໃຫ້ການປິດຕັດສິນໃຈວ່າຈະກັບຄືນຫຍັງ.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // ຄວາມປອດໄພ: ລະດັບຄວາມສູງຂອງຂໍ້ທີ່ຖືກປະສົມເຂົ້າກັນແມ່ນ ໜຶ່ງ ລຸ່ມຄວາມສູງ
                // ຂອງຂໍ້ຂອງ edge ນີ້, ດັ່ງນັ້ນຢູ່ຂ້າງເທິງສູນ, ດັ່ງນັ້ນພວກມັນຈຶ່ງຢູ່ພາຍໃນ.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// ຜະສົມຜະສານຂອງຄູ່ທີ່ມີຄ່າ ສຳ ຄັນຂອງພໍ່ແມ່ແລະທັງສອງຂໍ້ຂອງເດັກທີ່ຢູ່ຕິດກັນເຂົ້າໄປໃນຂໍ້ຄວາມເດັກເບື້ອງຊ້າຍແລະກັບຄືນຂໍ້ຂອງພໍ່ແມ່ທີ່ຫົດຕົວ.
    ///
    ///
    /// Panics ເວັ້ນເສຍແຕ່ວ່າພວກເຮົາ `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// ຜະສົມຜະສານຂອງຄູ່ທີ່ມີຄ່າ ສຳ ຄັນຂອງພໍ່ແມ່ແລະທັງຂໍ້ຂອງເດັກທີ່ຢູ່ຕິດກັນເຂົ້າໄປໃນຂໍ້ຄວາມເດັກເບື້ອງຊ້າຍແລະກັບຄືນຂໍ້ມູນຂອງເດັກນັ້ນ.
    ///
    ///
    /// Panics ເວັ້ນເສຍແຕ່ວ່າພວກເຮົາ `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// ຜະສົມຜະສານຂອງຄູ່ທີ່ມີຄ່າ ສຳ ຄັນຂອງພໍ່ແມ່ແລະທັງເດັກນ້ອຍທີ່ຢູ່ຕິດກັນເຂົ້າໄປໃນຂໍ້ ກຳ ນົດເດັກນ້ອຍທີ່ຢູ່ເບື້ອງຊ້າຍແລະສົ່ງກັບຄືນ edge ຈັບຢູ່ໃນຂໍ້ເດັກນັ້ນບ່ອນທີ່ edge ເດັກຕິດຕາມຈົບລົງ,
    ///
    ///
    /// Panics ເວັ້ນເສຍແຕ່ວ່າພວກເຮົາ `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// ຖອດຄູ່ຄູ່ທີ່ມີຄ່າ ສຳ ຄັນອອກຈາກລູກຊ້າຍແລະວາງມັນໄວ້ໃນບ່ອນເກັບມ້ຽນທີ່ ສຳ ຄັນຂອງພໍ່ແມ່, ໃນຂະນະທີ່ ກຳ ລັງຊຸກຍູ້ຄູ່ຂອງຄ່າ ສຳ ຄັນຂອງຜູ້ປົກຄອງເກົ່າເຂົ້າໄປໃນເດັກທີ່ຖືກຕ້ອງ.
    ///
    /// ກັບຄືນຈັບກັບ edge ໃນເດັກທີ່ຖືກຕ້ອງກົງກັບບ່ອນທີ່ edge ຕົ້ນສະບັບທີ່ລະບຸໂດຍ `track_right_edge_idx` ສິ້ນສຸດລົງ.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// ຖອດຄູ່ຄູ່ທີ່ມີຄ່າ ສຳ ຄັນອອກຈາກເດັກນ້ອຍທີ່ຖືກຕ້ອງແລະວາງມັນໄວ້ໃນບ່ອນເກັບມ້ຽນທີ່ ສຳ ຄັນຂອງພໍ່ແມ່, ໃນຂະນະທີ່ ກຳ ລັງຊຸກຍູ້ຄູ່ຂອງຄ່າ ສຳ ຄັນຂອງພໍ່ແມ່ເກົ່າໃສ່ລູກເບື້ອງຊ້າຍ.
    ///
    /// ສົ່ງຄືນເຄື່ອງມືຈັບກັບ edge ໃນເດັກຊ້າຍທີ່ລະບຸໄວ້ໂດຍ `track_left_edge_idx`, ເຊິ່ງບໍ່ໄດ້ຍ້າຍ.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// ນີ້ລັກຂະໂມຍຄ້າຍຄືກັນກັບ `steal_left` ແຕ່ລັກເອົາຫຼາຍໆອົງປະກອບດຽວກັນ.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ໃຫ້ແນ່ໃຈວ່າພວກເຮົາອາດຈະລັກໄດ້ຢ່າງປອດໄພ.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // ຍ້າຍຂໍ້ມູນໃບ.
            {
                // ເຮັດໃຫ້ຫ້ອງ ສຳ ລັບອົງປະກອບທີ່ຖືກລັກໃນເດັກທີ່ຖືກຕ້ອງ.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // ຍ້າຍອົງປະກອບຕ່າງໆຈາກເດັກນ້ອຍຊ້າຍຫາຂວາ.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // ຍ້າຍຄູ່ທີ່ຖືກລັກໄປທາງຊ້າຍໄປຫາພໍ່ແມ່.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // ຍ້າຍຄູ່ຄ່າ ສຳ ຄັນຂອງພໍ່ແມ່ໄປຫາເດັກທີ່ຖືກຕ້ອງ.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // ເຮັດໃຫ້ມີບ່ອນຫວ່າງ ສຳ ລັບຖືກລັກ.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // ລັກລອກ.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// ໂຄນຂອງ symmetric ຂອງ `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ໃຫ້ແນ່ໃຈວ່າພວກເຮົາອາດຈະລັກໄດ້ຢ່າງປອດໄພ.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // ຍ້າຍຂໍ້ມູນໃບ.
            {
                // ຍ້າຍຄູ່ທີ່ຖືກລັກທີ່ສຸດໄປຫາພໍ່ແມ່.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // ຍ້າຍຄູ່ຄ່າ ສຳ ຄັນຂອງພໍ່ແມ່ໄປຫາລູກຊ້າຍ.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // ຍ້າຍອົງປະກອບຈາກເດັກທີ່ຖືກຕ້ອງໄປທາງຊ້າຍ.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // ຕື່ມຂໍ້ມູນໃສ່ຊ່ອງຫວ່າງທີ່ອົງປະກອບຖືກລັກມາ.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // ລັກລອກ.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // ຕື່ມຊ່ອງຫວ່າງບ່ອນທີ່ຖືກລັກມາກ່ອນ.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// ກຳ ຈັດຂໍ້ມູນສະຖຽນລະພາບໃດໆອອກມາໂດຍຢືນຢັນວ່າ node ນີ້ແມ່ນ N `Leaf` X node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ກຳ ຈັດຂໍ້ມູນສະຖຽນລະພາບໃດໆອອກມາໂດຍຢືນຢັນວ່າ node ນີ້ແມ່ນຂໍ້ `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// ກວດເບິ່ງວ່າ node ທີ່ຕິດພັນແມ່ນ node `Internal` ຫຼື node `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// ຍ້າຍຕົວຕໍ່ຫຼັງຈາກ `self` ຈາກ node ໄປຫາອີກອັນ ໜຶ່ງ.`right` ຕ້ອງຫວ່າງເປົ່າ.
    /// edge ທຳ ອິດຂອງ `right` ຍັງບໍ່ປ່ຽນແປງ.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// ຜົນໄດ້ຮັບຂອງການແຊກ, ເມື່ອ node ຕ້ອງການເພື່ອຂະຫຍາຍອອກເກີນຄວາມສາມາດຂອງມັນ.
pub struct SplitResult<'a, K, V, NodeType> {
    // ປ່ຽນເສັ້ນປະສາດໃນຕົ້ນໄມ້ທີ່ມີຢູ່ແລ້ວເຊິ່ງມີສ່ວນປະກອບແລະຂອບທີ່ຢູ່ເບື້ອງຊ້າຍຂອງ `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // ບາງກະແຈແລະຄຸນຄ່າແຕກແຍກອອກ, ເພື່ອເອົາໄປໃສ່ບ່ອນອື່ນ.
    pub kv: (K, V),
    // ເປັນເຈົ້າຂອງ, ບໍ່ມີການຕິດຕັ້ງ, node ໃຫມ່ທີ່ມີສ່ວນປະກອບແລະຂອບທີ່ເປັນສິດຂອງ `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // ບໍ່ວ່າຈະເປັນການອ້າງອິງຂໍ້ມູນຂອງປະເພດການກູ້ຢືມເງິນນີ້ອະນຸຍາດໃຫ້ເດີນທາງໄປຫາຂໍ້ອື່ນໃນຕົ້ນໄມ້.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal ບໍ່ແມ່ນຄວາມ ຈຳ ເປັນ, ມັນເກີດຂື້ນໂດຍໃຊ້ຜົນຂອງ `borrow_mut`.
        // ໂດຍການປິດການຜ່ານຜ່າ, ແລະພຽງແຕ່ສ້າງເອກະສານອ້າງອີງ ໃໝ່ໆ ໃຫ້ແກ່ຮາກ, ພວກເຮົາຮູ້ວ່າທຸກໆການອ້າງອີງຂອງປະເພດ `Owned` ແມ່ນຢູ່ໃນຂໍ້ຮາກ.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// ໃສ່ຄ່າເຂົ້າໄປໃນສ່ວນຂອງສ່ວນປະກອບທີ່ເລີ່ມຕົ້ນຕາມດ້ວຍອົງປະກອບທີ່ບໍ່ມີຕົວຕົນ.
///
/// # Safety
/// ສ່ວນປະກອບມີຫຼາຍກ່ວາ `idx` ອົງປະກອບ.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// ກຳ ຈັດແລະສົ່ງຄືນຄ່າຈາກສ່ວນປະກອບທີ່ເລີ່ມຕົ້ນທັງ ໝົດ, ເຮັດໃຫ້ອົງປະກອບທີ່ບໍ່ມີການປ່ຽນແປງຕິດຕາມ.
///
///
/// # Safety
/// ສ່ວນປະກອບມີຫຼາຍກ່ວາ `idx` ອົງປະກອບ.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// ປ່ຽນອົງປະກອບໃນຕໍາ ແໜ່ງ `distance` ທີ່ລຽບໄປທາງຊ້າຍ.
///
/// # Safety
/// ສ່ວນປະກອບມີຢ່າງນ້ອຍ `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// ປ່ຽນອົງປະກອບໃນຕໍາ ແໜ່ງ `distance` ທີ່ລຽບໄປທາງຂວາ.
///
/// # Safety
/// ສ່ວນປະກອບມີຢ່າງນ້ອຍ `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// ຍ້າຍຄຸນຄ່າທັງ ໝົດ ຈາກສ່ວນປະກອບທີ່ເລີ່ມຕົ້ນໄປເປັນສ່ວນປະກອບທີ່ບໍ່ມີການປ່ຽນແປງ, ເຮັດໃຫ້ `src` ເປັນສິ່ງທີ່ບໍ່ມີການປ່ຽນແປງທັງ ໝົດ.
///
/// ເຮັດວຽກຄື `dst.copy_from_slice(src)` ແຕ່ບໍ່ ຈຳ ເປັນຕ້ອງໃຫ້ `T` ເປັນ `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;