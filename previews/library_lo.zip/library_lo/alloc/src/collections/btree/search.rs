use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// ເປັນເອກະສານຜູກມັດໃນການຊອກຫາ, ຄືກັນກັບ `Bound::Included(T)`.
    Included(T),
    /// ຜູກພັນພິເສດເພື່ອຊອກຫາ, ຄືກັນກັບ `Bound::Excluded(T)`.
    Excluded(T),
    /// ຂໍ້ຜູກມັດທີ່ບໍ່ມີເງື່ອນໄຂ, ຄືກັບ `Bound::Unbounded`.
    AllIncluded,
    /// ຂໍ້ຜູກມັດທີ່ບໍ່ມີເງື່ອນໄຂ.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ເບິ່ງກະແຈທີ່ໃຫ້ຢູ່ໃນຕົ້ນໄມ້ຍ່ອຍ (ຍ່ອຍ) ທີ່ຖືກມຸ່ງໄປຈາກຂໍ້, ຢືນຢັນ.
    /// ສົ່ງຄືນ `Found` ດ້ວຍການຈັບຂອງ KV ທີ່ກົງກັນ, ຖ້າມີ.
    /// ຖ້າບໍ່ດັ່ງນັ້ນ, ສົ່ງຄືນ `GoDown` ພ້ອມຈັບຂອງໃບ edge ບ່ອນທີ່ກຸນແຈເປັນຂອງ.
    ///
    /// ຜົນໄດ້ຮັບແມ່ນມີຄວາມ ໝາຍ ເທົ່ານັ້ນຖ້າຕົ້ນໄມ້ຖືກສັ່ງໂດຍຄີ, ຄືກັບຕົ້ນໄມ້ໃນ `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// ລົງໄປຫາຂໍ້ທີ່ຢູ່ໃກ້ທີ່ສຸດບ່ອນທີ່ edge ກົງກັບຂອບເຂດຕ່ ຳ ຂອງລະດັບຄວາມແຕກຕ່າງຈາກ edge ກົງກັບຂອບເທິງ, ໝາຍ ເຖິງຂໍ້ທີ່ຢູ່ໃກ້ທີ່ສຸດທີ່ມີຢ່າງ ໜ້ອຍ ໜຶ່ງ ຫຼັກທີ່ມີຢູ່ໃນຂອບເຂດ.
    ///
    ///
    /// ຖ້າພົບເຫັນ, ສົ່ງຄືນ `Ok` ກັບ node ນັ້ນ, ຄູ່ຂອງຕົວຊີ້ວັດ edge ໃນມັນ ກຳ ນົດຂອບເຂດ, ແລະຄູ່ທີ່ສອດຄ້ອງກັນ ສຳ ລັບການສືບຕໍ່ຊອກຫາຢູ່ໃນຂໍ້ເດັກ, ໃນກໍລະນີທີ່ node ຢູ່ພາຍໃນ.
    ///
    /// ຖ້າບໍ່ພົບ, ສົ່ງຄືນ `Err` ພ້ອມໃບ edge ທີ່ກົງກັບຂອບເຂດທັງ ໝົດ.
    ///
    /// ຜົນໄດ້ຮັບແມ່ນມີຄວາມຫມາຍພຽງແຕ່ຖ້າຕົ້ນໄມ້ຖືກສັ່ງໂດຍຄີ.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Inlining ຕົວແປເຫຼົ່ານີ້ຄວນຫຼີກເວັ້ນ.
        // ພວກເຮົາສົມມຸດວ່າຂອບເຂດທີ່ລາຍງານໂດຍ `range` ຍັງຄົງຄືເກົ່າ, ແຕ່ການປະຕິບັດທີ່ກົງກັນຂ້າມສາມາດປ່ຽນແປງລະຫວ່າງການໂທ (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// ຊອກຫາ edge ໃນໂຫນດທີ່ ກຳ ນົດຂອບເຂດທີ່ຕ່ ຳ ກວ່າລະດັບ.
    /// ພ້ອມທັງສົ່ງຄືນຂໍ້ຜູກມັດທີ່ຕ່ ຳ ກວ່າເພື່ອໃຊ້ໃນການສືບຕໍ່ຊອກຫາຢູ່ໃນ node ເດັກທີ່ກົງກັນ, ຖ້າ `self` ແມ່ນ Node ພາຍໃນ.
    ///
    ///
    /// ຜົນໄດ້ຮັບແມ່ນມີຄວາມຫມາຍພຽງແຕ່ຖ້າຕົ້ນໄມ້ຖືກສັ່ງໂດຍຄີ.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Clone ຂອງ `find_lower_bound_edge` ສຳ ລັບຂອບເທິງ.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ເບິ່ງປຸ່ມທີ່ໄດ້ຮັບໃນ node, ໂດຍບໍ່ມີການເອີ້ນຄືນ.
    /// ສົ່ງຄືນ `Found` ດ້ວຍການຈັບຂອງ KV ທີ່ກົງກັນ, ຖ້າມີ.
    /// ຖ້າບໍ່ດັ່ງນັ້ນ, ສົ່ງຄືນ `GoDown` ດ້ວຍການຈັບຂອງ edge ບ່ອນທີ່ປຸ່ມອາດຈະພົບ (ຖ້າ node ຢູ່ພາຍໃນ) ຫຼືບ່ອນທີ່ສາມາດເອົາຄີໄດ້.
    ///
    ///
    /// ຜົນໄດ້ຮັບແມ່ນມີຄວາມ ໝາຍ ເທົ່ານັ້ນຖ້າຕົ້ນໄມ້ຖືກສັ່ງໂດຍຄີ, ຄືກັບຕົ້ນໄມ້ໃນ `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// ສົ່ງຄືນທັງດັດສະນີ KV ຢູ່ໃນ node ທີ່ກຸນແຈ (ຫລືທຽບເທົ່າທຽບເທົ່າ), ຫຼືດັດສະນີ edge ບ່ອນທີ່ກຸນແຈມີ.
    ///
    ///
    /// ຜົນໄດ້ຮັບແມ່ນມີຄວາມ ໝາຍ ເທົ່ານັ້ນຖ້າຕົ້ນໄມ້ຖືກສັ່ງໂດຍຄີ, ຄືກັບຕົ້ນໄມ້ໃນ `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// ຊອກຫາດັດສະນີ edge ໃນໂຫນດທີ່ ກຳ ນົດຂອບເຂດທີ່ຕ່ ຳ ກວ່າລະດັບ.
    /// ພ້ອມທັງສົ່ງຄືນຂໍ້ຜູກມັດທີ່ຕ່ ຳ ກວ່າເພື່ອໃຊ້ໃນການສືບຕໍ່ຊອກຫາຢູ່ໃນ node ເດັກທີ່ກົງກັນ, ຖ້າ `self` ແມ່ນ Node ພາຍໃນ.
    ///
    ///
    /// ຜົນໄດ້ຮັບແມ່ນມີຄວາມຫມາຍພຽງແຕ່ຖ້າຕົ້ນໄມ້ຖືກສັ່ງໂດຍຄີ.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Clone ຂອງ `find_lower_bound_index` ສຳ ລັບຂອບເທິງ.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}