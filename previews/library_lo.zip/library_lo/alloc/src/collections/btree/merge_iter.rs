use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// ຫຼັກຂອງຕົວປ່ຽນແປງທີ່ລວມເອົາຜົນຜະລິດຂອງສອງຕົວຕັ້ງຊັນຂຶ້ນ, ຢ່າງເຂັ້ມງວດ, ຍົກຕົວຢ່າງສະຫະພາບແຮງຫຼືຄວາມແຕກຕ່າງທາງດ້ານ symmetric.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// ມາດຕະຖານໄວກ່ວາການຫໍ່ທັງສອງທິດໃນ Peekable, ອາດຈະເປັນຍ້ອນວ່າພວກເຮົາສາມາດທີ່ຈະບັງຄັບໃຊ້ FusedIterator ຜູກມັດ.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// ສ້າງຫຼັກການ ໃໝ່ ສຳ ລັບຕົວຊີ້ວັດການລວມຕົວແຫຼ່ງຄູ່.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// ສົ່ງຄືນລາຍການຄູ່ຕໍ່ໆໄປທີ່ມາຈາກຄູ່ຂອງແຫຼ່ງທີ່ຖືກລວມເຂົ້າກັນ.
    /// ຖ້າທັງສອງຕົວເລືອກທີ່ສົ່ງຄືນມີມູນຄ່າ, ມູນຄ່ານັ້ນຈະເທົ່າກັນແລະເກີດຂື້ນໃນທັງສອງແຫຼ່ງ.
    /// ຖ້າ ໜຶ່ງ ໃນຕົວເລືອກທີ່ຖືກສົ່ງຄືນມີມູນຄ່າ, ມູນຄ່ານັ້ນຈະບໍ່ເກີດຂື້ນໃນແຫຼ່ງອື່ນ (ຫຼືແຫຼ່ງຂໍ້ມູນບໍ່ໄດ້ຖືກຂື້ນຢ່າງເຂັ້ມງວດ).
    ///
    /// ຖ້າທາງເລືອກທີ່ບໍ່ໄດ້ກັບຄືນມາມີມູນຄ່າ, ການໂທຄືນໄດ້ ສຳ ເລັດແລ້ວແລະການໂທຕໍ່ໆໄປກໍ່ຈະກັບຄືນຫາຄູ່ທີ່ບໍ່ມີສາຍດຽວກັນ.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// ສົ່ງຄືນຮ່ອງຂ້າງເທິງຂອງຄູ່ ສຳ ລັບ `size_hint` ຂອງຕົວປັບສຸດທ້າຍ.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}