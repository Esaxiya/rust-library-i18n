use core::borrow::Borrow;
use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, RangeBounds};
use core::ptr;

use super::borrow::DormantMutRef;
use super::navigate::LeafRange;
use super::node::{self, marker, ForceResult::*, Handle, NodeRef, Root};
use super::search::SearchResult::*;

mod entry;
pub use entry::{Entry, OccupiedEntry, OccupiedError, VacantEntry};
use Entry::*;

/// ຈໍານວນຕໍາ່ສຸດທີ່ຂອງອົງປະກອບໃນຂໍ້ທີ່ບໍ່ແມ່ນຮາກ.
/// ພວກເຮົາອາດຈະມີສ່ວນປະກອບ ໜ້ອຍ ໃນໄລຍະວິທີການຕ່າງໆ.
pub(super) const MIN_LEN: usize = node::MIN_LEN_AFTER_SPLIT;

// ເປັນໄມ້ຢືນຕົ້ນໃນ `BTreeMap` ເປັນຕົ້ນໄມ້ໃນໂມດູນ `node` ກັບຄາຄົງເພີ່ມເຕີມ:
// - ຄີຕ້ອງປາກົດຕາມ ລຳ ດັບທີ່ຂຶ້ນ (ອີງຕາມປະເພດຂອງຄີ).
// - ຖ້າໂຫນດແມ່ນພາຍໃນ, ມັນຈະຕ້ອງປະກອບດ້ວຍຢ່າງຫນ້ອຍ 1 ອົງປະກອບ.
// - ທຸກໆຂໍ້ທີ່ບໍ່ແມ່ນຮາກປະກອບມີຢ່າງ ໜ້ອຍ MIN_LEN ອົງປະກອບ.
//
// ແຜນທີ່ທີ່ຫວ່າງເປົ່າອາດຈະເປັນຕົວແທນທັງໂດຍບໍ່ມີຮາກຂອງຮາກຫຼືຈາກຮາກທີ່ເປັນໃບເປົ່າ.
//

/// ແຜນທີ່ອີງໃສ່ [B-Tree].
///
/// B-Tree ເປັນຕົວແທນຂອງການປະນີປະນອມຂັ້ນພື້ນຖານລະຫວ່າງການເພີ່ມປະສິດທິພາບຂອງຖານຄວາມ ຈຳ ແລະການຫຼຸດຜ່ອນ ຈຳ ນວນວຽກທີ່ເຮັດໃນການຄົ້ນຫາ.ໃນທາງທິດສະດີ, ຕົ້ນໄມ້ຄົ້ນຫາຖານສອງ (BST) ແມ່ນທາງເລືອກທີ່ດີທີ່ສຸດ ສຳ ລັບແຜນທີ່ຈັດລຽງຕາມ, ເພາະວ່າ BST ທີ່ສົມດຸນສົມບູນປະຕິບັດ ຈຳ ນວນ ຕຳ ່ສຸດທາງທິດສະດີທີ່ ຈຳ ເປັນໃນການຄົ້ນຫາອົງປະກອບ (log<sub>2</sub>n).
/// ເຖິງຢ່າງໃດກໍ່ຕາມ, ໃນທາງປະຕິບັດວິທີການທີ່ເຮັດນີ້ແມ່ນ *ຫຼາຍ* ບໍ່ມີປະສິດທິພາບ ສຳ ລັບສະຖາປັດຕະຍະ ກຳ ຄອມພິວເຕີທີ່ທັນສະ ໄໝ.
/// ໂດຍສະເພາະ, ທຸກໆອົງປະກອບຈະຖືກເກັບໄວ້ໃນຂໍ້ທີ່ຖືກຈັດສັນໄວ້ເປັນສ່ວນບຸກຄົນ.
/// ນີ້ ໝາຍ ຄວາມວ່າທຸກໆການແຊກແຊກຄັ້ງດຽວເຮັດໃຫ້ມີການຈັດສັນ heap, ແລະການປຽບທຽບທຸກຢ່າງຄວນຈະເປັນການເກັບຂໍ້ມູນ.
/// ເນື່ອງຈາກສິ່ງເຫຼົ່ານີ້ທັງສອງແມ່ນສິ່ງທີ່ມີລາຄາແພງທີ່ຄວນຈະປະຕິບັດໃນການປະຕິບັດຕົວຈິງ, ພວກເຮົາຖືກບັງຄັບໃຫ້ຄິດຄືນ ໃໝ່ ຢ່າງ ໜ້ອຍ ຍຸດທະສາດ BST.
///
/// A B-Tree ແທນທີ່ຈະເຮັດໃຫ້ແຕ່ລະ node ປະກອບມີ B-1 ຫາ 2B-1 ອົງປະກອບໃນແຖວຕິດຕໍ່ກັນ.ໂດຍການເຮັດສິ່ງນີ້, ພວກເຮົາຫຼຸດຜ່ອນ ຈຳ ນວນການຈັດສັນໂດຍປັດໃຈຂອງ B, ແລະປັບປຸງປະສິດທິພາບຂອງ cache ໃນການຄົ້ນຫາ.ເຖິງຢ່າງໃດກໍ່ຕາມ, ມັນ ໝາຍ ຄວາມວ່າການຄົ້ນຫາຈະຕ້ອງເຮັດຫຼາຍຂື້ນ * ປຽບທຽບໂດຍສະເລ່ຍ.
/// ຈຳ ນວນການປຽບທຽບທີ່ແນ່ນອນແມ່ນຂື້ນກັບຍຸດທະສາດການຄົ້ນຫາຂໍ້ທີ່ໃຊ້.ສຳ ລັບປະສິດທິພາບທີ່ດີທີ່ສຸດຂອງຖານຄວາມ ຈຳ, ທ່ານສາມາດຄົ້ນຫາຂໍ້ຂອງຂໍ້ມູນເປັນແຖວສໍາລັບການປຽບທຽບທີ່ດີທີ່ສຸດ, ຫນຶ່ງສາມາດຄົ້ນຫາ node ໂດຍໃຊ້ການຄົ້ນຫາຖານສອງ.ໃນຖານະເປັນການປະນີປະນອມ, ທ່ານຍັງສາມາດປະຕິບັດການຄົ້ນຫາເສັ້ນຊື່ເຊິ່ງໃນເບື້ອງຕົ້ນພຽງແຕ່ກວດເບິ່ງທຸກໆອົງປະກອບ <sup>ທີ</sup> I ສຳ ລັບຕົວເລືອກ i.
///
/// ໃນປະຈຸບັນ, ການຈັດຕັ້ງປະຕິບັດຂອງພວກເຮົາພຽງແຕ່ ດຳ ເນີນການຄົ້ນຫາແບບບໍ່ມີສາຍ.ນີ້ສະຫນອງການປະຕິບັດທີ່ດີເລີດກ່ຽວກັບ *ຂໍ້* ຂະຫນາດນ້ອຍ *ຂອງອົງປະກອບທີ່ມີລາຄາຖືກທີ່ຈະປຽບທຽບ.ເຖິງຢ່າງໃດກໍ່ຕາມໃນ future ພວກເຮົາຢາກຄົ້ນຄວ້າຕື່ມກ່ຽວກັບການເລືອກຍຸດທະສາດການຄົ້ນຫາທີ່ດີທີ່ສຸດໂດຍອີງໃສ່ຕົວເລືອກຂອງ B, ແລະອາດຈະມີປັດໃຈອື່ນໆ.ການ ນຳ ໃຊ້ການຄົ້ນຫາແບບເສັ້ນ, ການຄົ້ນຫາອົງປະກອບແບບສຸ່ມຄາດວ່າຈະມີການປຽບທຽບ O(B* log(n)), ເຊິ່ງໂດຍທົ່ວໄປແລ້ວມັນຈະຮ້າຍແຮງກວ່າ BST.
///
/// ໃນການປະຕິບັດຕົວຈິງ, ການປະຕິບັດແມ່ນດີເລີດ.
///
/// ມັນແມ່ນຂໍ້ຜິດພາດທີ່ມີເຫດຜົນ ສຳ ລັບກຸນແຈທີ່ຈະຖືກປັບປ່ຽນໃນລັກສະນະທີ່ການສັ່ງຊື້ຂອງຄີແມ່ນກ່ຽວຂ້ອງກັບຄີອື່ນໆ, ຕາມທີ່ໄດ້ ກຳ ນົດໂດຍ [`Ord`] trait, ມີການປ່ຽນແປງໃນຂະນະທີ່ມັນຢູ່ໃນແຜນທີ່.ໂດຍປົກກະຕິແລ້ວສິ່ງນີ້ສາມາດເຮັດໄດ້ໂດຍຜ່ານ [`Cell`], [`RefCell`], ສະພາບທົ່ວໂລກ, I/O, ຫຼືລະຫັດທີ່ບໍ່ປອດໄພ.
/// ພຶດຕິ ກຳ ທີ່ເກີດຈາກຄວາມຜິດພາດຕາມເຫດຜົນດັ່ງກ່າວບໍ່ໄດ້ຖືກລະບຸ, ແຕ່ຈະບໍ່ສົ່ງຜົນໃຫ້ມີພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ.ນີ້ສາມາດປະກອບມີ panics, ຜົນໄດ້ຮັບທີ່ບໍ່ຖືກຕ້ອງ, ການເອົາລູກອອກ, ການຮົ່ວໄຫລຂອງຄວາມຊົງຈໍາແລະການບໍ່ຢຸດ.
///
/// [B-Tree]: https://en.wikipedia.org/wiki/B-tree
/// [`Cell`]: core::cell::Cell
/// [`RefCell`]: core::cell::RefCell
///
/// # Examples
///
/// ```
/// use std::collections::BTreeMap;
///
/// // inference type ຊ່ວຍໃຫ້ພວກເຮົາຍົກເລີກລາຍເຊັນປະເພດທີ່ຈະແຈ້ງ (ເຊິ່ງຈະເປັນ `BTreeMap<&str, &str>` ໃນຕົວຢ່າງນີ້).
/////
/// let mut movie_reviews = BTreeMap::new();
///
/// // ທົບທວນບາງຮູບເງົາ.
/// movie_reviews.insert("Office Space",       "Deals with real issues in the workplace.");
/// movie_reviews.insert("Pulp Fiction",       "Masterpiece.");
/// movie_reviews.insert("The Godfather",      "Very enjoyable.");
/// movie_reviews.insert("The Blues Brothers", "Eye lyked it a lot.");
///
/// // ກວດເບິ່ງສໍາລັບສະເພາະໃດຫນຶ່ງຫນຶ່ງໄດ້.
/// if !movie_reviews.contains_key("Les Misérables") {
///     println!("We've got {} reviews, but Les Misérables ain't one.",
///              movie_reviews.len());
/// }
///
/// // ໂອ້ຍ, ການທົບທວນຄືນນີ້ມີຂໍ້ຜິດພາດທີ່ສະກົດຫຼາຍ, ໃຫ້ພວກເຮົາລຶບມັນ.
/// movie_reviews.remove("The Blues Brothers");
///
/// // ຊອກຫາຄຸນຄ່າທີ່ກ່ຽວຂ້ອງກັບຄີບາງ.
/// let to_find = ["Up!", "Office Space"];
/// for movie in &to_find {
///     match movie_reviews.get(movie) {
///        Some(review) => println!("{}: {}", movie, review),
///        None => println!("{} is unreviewed.", movie)
///     }
/// }
///
/// // ຊອກຫາຄ່າ ສຳ ລັບຄີ (ຈະ panic ຖ້າບໍ່ພົບກຸນແຈ).
/// println!("Movie review: {}", movie_reviews["Office Space"]);
///
/// // iterate ຫຼາຍກວ່າທຸກສິ່ງທຸກຢ່າງ.
/// for (movie, review) in &movie_reviews {
///     println!("{}: \"{}\"", movie, review);
/// }
/// ```
///
/// `BTreeMap` ຍັງປະຕິບັດ [`Entry API`], ເຊິ່ງອະນຸຍາດໃຫ້ມີຫຼາຍວິທີທີ່ສັບສົນໃນການໄດ້ຮັບ, ຕັ້ງ, ປັບປຸງແລະຖອດຄີແລະຄ່າຂອງມັນ:
///
/// [`Entry API`]: BTreeMap::entry
///
/// ```
/// use std::collections::BTreeMap;
///
/// // inference type ຊ່ວຍໃຫ້ພວກເຮົາຍົກເລີກລາຍເຊັນປະເພດທີ່ຈະແຈ້ງ (ເຊິ່ງຈະເປັນ `BTreeMap<&str, u8>` ໃນຕົວຢ່າງນີ້).
/////
/// let mut player_stats = BTreeMap::new();
///
/// fn random_stat_buff() -> u8 {
///     // ຕົວຈິງສາມາດກັບຄືນມູນຄ່າແບບສຸ່ມບາງຢ່າງຢູ່ທີ່ນີ້, ຂໍພຽງແຕ່ສົ່ງຄືນຄ່າຄົງທີ່ ສຳ ລັບດຽວນີ້
/////
///     42
/// }
///
/// // ໃສ່ປຸ່ມດຽວເທົ່ານັ້ນຖ້າມັນບໍ່ມີຢູ່
/// player_stats.entry("health").or_insert(100);
///
/// // ໃສ່ປຸ່ມໂດຍໃຊ້ຟັງຊັນທີ່ໃຫ້ຄຸນຄ່າ ໃໝ່ ເທົ່ານັ້ນຖ້າມັນບໍ່ມີຢູ່ແລ້ວ
/////
/// player_stats.entry("defence").or_insert_with(random_stat_buff);
///
/// // ປັບປຸງກະແຈ ໃໝ່, ປ້ອງກັນຄີທີ່ອາດຈະບໍ່ຖືກຕັ້ງຄ່າ
/// let stat = player_stats.entry("attack").or_insert(100);
/// *stat += random_stat_buff();
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BTreeMap")]
pub struct BTreeMap<K, V> {
    root: Option<Root<K, V>>,
    length: usize,
}

#[stable(feature = "btree_drop", since = "1.7.0")]
unsafe impl<#[may_dangle] K, #[may_dangle] V> Drop for BTreeMap<K, V> {
    fn drop(&mut self) {
        if let Some(root) = self.root.take() {
            Dropper { front: root.into_dying().first_leaf_edge(), remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Clone, V: Clone> Clone for BTreeMap<K, V> {
    fn clone(&self) -> BTreeMap<K, V> {
        fn clone_subtree<'a, K: Clone, V: Clone>(
            node: NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal>,
        ) -> BTreeMap<K, V>
        where
            K: 'a,
            V: 'a,
        {
            match node.force() {
                Leaf(leaf) => {
                    let mut out_tree = BTreeMap { root: Some(Root::new()), length: 0 };

                    {
                        let root = out_tree.root.as_mut().unwrap(); // unwrap ສົບຜົນສໍາເລັດເພາະວ່າພວກເຮົາພຽງແຕ່ຫໍ່
                        let mut out_node = match root.borrow_mut().force() {
                            Leaf(leaf) => leaf,
                            Internal(_) => unreachable!(),
                        };

                        let mut in_edge = leaf.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            out_node.push(k.clone(), v.clone());
                            out_tree.length += 1;
                        }
                    }

                    out_tree
                }
                Internal(internal) => {
                    let mut out_tree = clone_subtree(internal.first_edge().descend());

                    {
                        let out_root = BTreeMap::ensure_is_owned(&mut out_tree.root);
                        let mut out_node = out_root.push_internal_level();
                        let mut in_edge = internal.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            let k = (*k).clone();
                            let v = (*v).clone();
                            let subtree = clone_subtree(in_edge.descend());

                            // ພວກເຮົາບໍ່ສາມາດ ທຳ ລາຍລັດຖະບັນຍັດໂດຍກົງໄດ້ເພາະວ່າ BTreeMap ປະຕິບັດການລຸດລົງ
                            //
                            let (subroot, sublength) = unsafe {
                                let subtree = ManuallyDrop::new(subtree);
                                let root = ptr::read(&subtree.root);
                                let length = subtree.length;
                                (root, length)
                            };

                            out_node.push(k, v, subroot.unwrap_or_else(Root::new));
                            out_tree.length += 1 + sublength;
                        }
                    }

                    out_tree
                }
            }
        }

        if self.is_empty() {
            // ໂດຍຫລັກການແລ້ວພວກເຮົາຈະໂທຫາ `BTreeMap::new` ຢູ່ທີ່ນີ້, ແຕ່ວ່າມັນມີ `K:
            // ຂໍ້ ຈຳ ກັດ, ເຊິ່ງວິທີນີ້ຂາດ.
            BTreeMap { root: None, length: 0 }
        } else {
            clone_subtree(self.root.as_ref().unwrap().reborrow()) // unwrap ສົບຜົນສໍາເລັດເພາະວ່າບໍ່ແມ່ນຫວ່າງເປົ່າ
        }
    }
}

impl<K, Q: ?Sized> super::Recover<Q> for BTreeMap<K, ()>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Key = K;

    fn get(&self, key: &Q) -> Option<&K> {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().0),
            GoDown(_) => None,
        }
    }

    fn take(&mut self, key: &Q) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_kv().0)
            }
            GoDown(_) => None,
        }
    }

    fn replace(&mut self, key: K) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree::<K>(&key) {
            Found(mut kv) => Some(mem::replace(kv.key_mut(), key)),
            GoDown(handle) => {
                VacantEntry { key, handle, dormant_map, _marker: PhantomData }.insert(());
                None
            }
        }
    }
}

/// ຜູ້ລະບາຍຂໍ້ມູນກ່ຽວກັບລາຍການຂອງ `BTreeMap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`iter`] ໃນ [`BTreeMap`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`iter`]: BTreeMap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, K: 'a, V: 'a> {
    range: Range<'a, K, V>,
    length: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Iter<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// ຕົວປ່ຽນແປງທີ່ປ່ຽນແປງໄດ້ໃນໄລຍະເຂົ້າຂອງ `BTreeMap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`iter_mut`] ໃນ [`BTreeMap`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`iter_mut`]: BTreeMap::iter_mut
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, K: 'a, V: 'a> {
    range: RangeMut<'a, K, V>,
    length: usize,
}

/// ເປັນເຈົ້າຂອງຕົວຊີ້ວັດ ເໜືອ ລາຍການຂອງ `BTreeMap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`into_iter`] ໃນ [`BTreeMap`] (ສະ ໜອງ ໂດຍ `IntoIterator` trait).
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`into_iter`]: IntoIterator::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<K, V> {
    range: LeafRange<marker::Dying, K, V>,
    length: usize,
}

impl<K, V> IntoIter<K, V> {
    /// ສົ່ງຄືນຜູ້ອ້າງອີງໃສ່ລາຍການທີ່ຍັງເຫຼືອ.
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        let range = Range { inner: self.range.reborrow() };
        Iter { range: range, length: self.length }
    }
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for IntoIter<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

/// ຮຸ່ນ `IntoIter` ແບບ ທຳ ມະດາທີ່ບໍ່ໄດ້ສິ້ນສຸດລົງສອງເທົ່າແລະມີຈຸດປະສົງດຽວເທົ່ານັ້ນ: ເພື່ອລຸດສ່ວນທີ່ເຫຼືອຂອງ `IntoIter`.
/// ສະນັ້ນມັນຍັງເຮັດໃຫ້ຕົ້ນໄມ້ ໝົດ ໃບໂດຍບໍ່ ຈຳ ເປັນຕ້ອງຊອກຫາໃບ `back` ໃບ X0X edge.
///
struct Dropper<K, V> {
    front: Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge>,
    remaining_length: usize,
}

/// ຕົວຊີ້ວັດຂື້ນເທິງກະແຈຂອງ `BTreeMap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`keys`] ໃນ [`BTreeMap`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`keys`]: BTreeMap::keys
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Keys<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V> fmt::Debug for Keys<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// ຕົວຊີ້ວັດ ເໜືອ ຄ່າຂອງ `BTreeMap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`values`] ໃນ [`BTreeMap`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`values`]: BTreeMap::values
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Values<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K, V: fmt::Debug> fmt::Debug for Values<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// ຕົວປ່ຽນແປງທີ່ປ່ຽນແປງໄດ້ກ່ຽວກັບຄຸນຄ່າຂອງ `BTreeMap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`values_mut`] ໃນ [`BTreeMap`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`values_mut`]: BTreeMap::values_mut
#[stable(feature = "map_values_mut", since = "1.10.0")]
pub struct ValuesMut<'a, K: 'a, V: 'a> {
    inner: IterMut<'a, K, V>,
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V: fmt::Debug> fmt::Debug for ValuesMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// ເປັນເຈົ້າຂອງຕົວຊີ້ບອກກ່ຽວກັບກະແຈຂອງ `BTreeMap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`into_keys`] ໃນ [`BTreeMap`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`into_keys`]: BTreeMap::into_keys
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoKeys<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K: fmt::Debug, V> fmt::Debug for IntoKeys<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(key, _)| key)).finish()
    }
}

/// ເປັນເຈົ້າຂອງຕົວຊີ້ວັດ ເໜືອ ຄ່າຂອງ `BTreeMap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`into_values`] ໃນ [`BTreeMap`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`into_values`]: BTreeMap::into_values
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoValues<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V: fmt::Debug> fmt::Debug for IntoValues<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// ຜູ້ຕິດຕໍ່ຜ່ານໄລຍະຍ່ອຍຂອງລາຍການໃນ `BTreeMap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`range`] ໃນ [`BTreeMap`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`range`]: BTreeMap::range
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct Range<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::Immut<'a>, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Range<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// ຕົວປ່ຽນແປງທີ່ປ່ຽນແປງໄດ້ໃນໄລຍະປະເພດຍ່ອຍຂອງ `BTreeMap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`range_mut`] ໃນ [`BTreeMap`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`range_mut`]: BTreeMap::range_mut
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct RangeMut<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::ValMut<'a>, K, V>,

    // ເປັນຄົນບໍ່ສະຫຼາດໃນ `K` ແລະ `V`
    _marker: PhantomData<&'a mut (K, V)>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for RangeMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let range = Range { inner: self.inner.reborrow() };
        f.debug_list().entries(range).finish()
    }
}

impl<K, V> BTreeMap<K, V> {
    /// ເຮັດ `BTreeMap` ແບບ ໃໝ່, ເປົ່າ.
    ///
    /// ບໍ່ໄດ້ຈັດສັນສິ່ງໃດສິ່ງ ໜຶ່ງ ດ້ວຍຕົນເອງ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    ///
    /// // ລາຍການສາມາດໃສ່ເຂົ້າໃນແຜນທີ່ຫວ່າງໄດ້ແລ້ວ
    /// map.insert(1, "a");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn new() -> BTreeMap<K, V>
    where
        K: Ord,
    {
        BTreeMap { root: None, length: 0 }
    }

    /// ລ້າງແຜນທີ່, ກຳ ຈັດອົງປະກອບທັງ ໝົດ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.clear();
    /// assert!(a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = BTreeMap { root: None, length: 0 };
    }

    /// ສົ່ງຂໍ້ມູນອ້າງອີງໃສ່ຄ່າທີ່ກົງກັບຄີ.
    ///
    /// ກຸນແຈອາດຈະແມ່ນຮູບແບບທີ່ຢືມມາຈາກປະເພດທີ່ ສຳ ຄັນຂອງແຜນທີ່, ແຕ່ການສັ່ງຊື້ໃນແບບຟອມທີ່ຖືກຢືມ *ຕ້ອງ* ກົງກັບການສັ່ງຊື້ໃນປະເພດຫຼັກ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get(&1), Some(&"a"));
    /// assert_eq!(map.get(&2), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get<Q: ?Sized>(&self, key: &Q) -> Option<&V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().1),
            GoDown(_) => None,
        }
    }

    /// ສົ່ງຄືນຄ່າຄູ່ທີ່ມີຄ່າ ສຳ ຄັນທີ່ສອດຄ້ອງກັບຄີທີ່ສະ ໜອງ ໃຫ້.
    ///
    /// ຄີທີ່ສະ ໜອງ ໃຫ້ອາດຈະແມ່ນຮູບແບບທີ່ຢືມມາຈາກປະເພດທີ່ ສຳ ຄັນຂອງແຜນທີ່, ແຕ່ການສັ່ງຊື້ໃນແບບຟອມທີ່ຢືມມານັ້ນຕ້ອງແມ່ນ * ກົງກັບການສັ່ງຊື້ໃນປະເພດຫຼັກ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get_key_value(&1), Some((&1, &"a")));
    /// assert_eq!(map.get_key_value(&2), None);
    /// ```
    #[stable(feature = "map_get_key_value", since = "1.40.0")]
    pub fn get_key_value<Q: ?Sized>(&self, k: &Q) -> Option<(&K, &V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(k) {
            Found(handle) => Some(handle.into_kv()),
            GoDown(_) => None,
        }
    }

    /// ສົ່ງຄືນຄູ່ ຄຳ ທີ່ມີຄ່າ ສຳ ຄັນ ທຳ ອິດໃນແຜນທີ່.
    /// ຄີໃນຄູ່ນີ້ແມ່ນກຸນແຈຂັ້ນຕ່ ຳ ໃນແຜນທີ່.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.first_key_value(), None);
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.first_key_value(), Some((&1, &"b")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.first_leaf_edge().right_kv().ok().map(Handle::into_kv)
    }

    /// ກັບຄືນລາຍການ ທຳ ອິດໃນແຜນທີ່ ສຳ ລັບການ ໝູນ ໃຊ້ສະຖານທີ່.
    /// ກະແຈ ສຳ ຄັນຂອງການປ້ອນຂໍ້ມູນນີ້ແມ່ນກຸນແຈຂັ້ນຕ່ ຳ ໃນແຜນທີ່.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.first_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("first");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "first");
    /// assert_eq!(*map.get(&2).unwrap(), "b");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.first_leaf_edge().right_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// ເອົາແລະສົ່ງຄືນສ່ວນປະກອບ ທຳ ອິດໃນແຜນທີ່.
    /// ກະແຈ ສຳ ຄັນຂອງອົງປະກອບນີ້ແມ່ນລະຫັດ ຕຳ ່ສຸດທີ່ຢູ່ໃນແຜນທີ່.
    ///
    /// # Examples
    ///
    /// ບັນດາອົງປະກອບທີ່ຫລັ່ງໄຫລເຂົ້າໄປໃນລະດັບທີ່ຕັ້ງຊັນຂຶ້ນ, ໃນຂະນະທີ່ຮັກສາແຜນທີ່ທີ່ໃຊ້ໄດ້ໃນແຕ່ລະຈຸດ.
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_first() {
    ///     assert!(map.iter().all(|(k, _v)| *k > key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_first(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.first_entry().map(|entry| entry.remove_entry())
    }

    /// ກັບຄືນຄູ່ຄູ່ ສຳ ຄັນສຸດທ້າຍໃນແຜນທີ່.
    /// ຄີໃນຄູ່ນີ້ແມ່ນກຸນແຈສູງສຸດໃນແຜນທີ່.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.last_key_value(), Some((&2, &"a")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.last_leaf_edge().left_kv().ok().map(Handle::into_kv)
    }

    /// ກັບຄືນລາຍການສຸດທ້າຍໃນແຜນທີ່ ສຳ ລັບການ ໝູນ ໃຊ້ສະຖານທີ່.
    /// ກະແຈ ສຳ ຄັນຂອງການປ້ອນຂໍ້ມູນນີ້ແມ່ນກຸນແຈສູງສຸດໃນແຜນທີ່.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.last_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("last");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "a");
    /// assert_eq!(*map.get(&2).unwrap(), "last");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.last_leaf_edge().left_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// ເອົາແລະສົ່ງຄືນສ່ວນປະກອບສຸດທ້າຍໃນແຜນທີ່.
    /// ກະແຈ ສຳ ຄັນຂອງອົງປະກອບນີ້ແມ່ນກຸນແຈສູງສຸດທີ່ມີຢູ່ໃນແຜນທີ່.
    ///
    /// # Examples
    ///
    /// ບັນຈຸອົງປະກອບຕ່າງໆຕາມ ລຳ ດັບລົງ, ໃນຂະນະທີ່ຮັກສາແຜນທີ່ທີ່ໃຊ້ໄດ້ໃນແຕ່ລະຈຸດ.
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_last() {
    ///     assert!(map.iter().all(|(k, _v)| *k < key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_last(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.last_entry().map(|entry| entry.remove_entry())
    }

    /// ສົ່ງຄືນ `true` ຖ້າແຜນທີ່ມີຄ່າ ສຳ ລັບລະຫັດທີ່ລະບຸ.
    ///
    /// ກຸນແຈອາດຈະແມ່ນຮູບແບບທີ່ຢືມມາຈາກປະເພດທີ່ ສຳ ຄັນຂອງແຜນທີ່, ແຕ່ການສັ່ງຊື້ໃນແບບຟອມທີ່ຖືກຢືມ *ຕ້ອງ* ກົງກັບການສັ່ງຊື້ໃນປະເພດຫຼັກ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.contains_key(&1), true);
    /// assert_eq!(map.contains_key(&2), false);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn contains_key<Q: ?Sized>(&self, key: &Q) -> bool
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.get(key).is_some()
    }

    /// ສົ່ງຄືນການອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບມູນຄ່າທີ່ສອດຄ້ອງກັບຄີ.
    ///
    /// ກຸນແຈອາດຈະແມ່ນຮູບແບບທີ່ຢືມມາຈາກປະເພດທີ່ ສຳ ຄັນຂອງແຜນທີ່, ແຕ່ການສັ່ງຊື້ໃນແບບຟອມທີ່ຖືກຢືມ *ຕ້ອງ* ກົງກັບການສັ່ງຊື້ໃນປະເພດຫຼັກ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// if let Some(x) = map.get_mut(&1) {
    ///     *x = "b";
    /// }
    /// assert_eq!(map[&1], "b");
    /// ```
    // ເບິ່ງ `get` ສຳ ລັບບົດບັນທຶກການຈັດຕັ້ງປະຕິບັດ, ນີ້ແມ່ນພື້ນຖານ ສຳ ເນົາທີ່ມີການເພີ່ມຂອງ mut
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut<Q: ?Sized>(&mut self, key: &Q) -> Option<&mut V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_val_mut()),
            GoDown(_) => None,
        }
    }

    /// ສະແດງກິ່ງງ່າຄູ່ ສຳ ຄັນໃສ່ໃນແຜນທີ່.
    ///
    /// ຖ້າແຜນທີ່ບໍ່ມີປະຈຸບັນນີ້, `None` ຈະຖືກສົ່ງຄືນ.
    ///
    /// ຖ້າແຜນທີ່ມີປະຈຸບັນນີ້ທີ່ ສຳ ຄັນ, ມູນຄ່າຈະຖືກປັບປຸງ, ແລະມູນຄ່າເກົ່າກໍ່ຖືກສົ່ງຄືນ.
    /// ສິ່ງ ສຳ ຄັນບໍ່ໄດ້ຖືກປັບປຸງ, ເຖິງແມ່ນວ່າ;ເລື່ອງນີ້ ສຳ ຄັນ ສຳ ລັບຊະນິດທີ່ສາມາດເປັນ `==` ໂດຍບໍ່ຕ້ອງມີຄືກັນ.
    ///
    /// ເບິ່ງ [module-level documentation] ສຳ ລັບເພີ່ມເຕີມ.
    ///
    /// [module-level documentation]: index.html#insert-and-complex-keys
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.insert(37, "a"), None);
    /// assert_eq!(map.is_empty(), false);
    ///
    /// map.insert(37, "b");
    /// assert_eq!(map.insert(37, "c"), Some("b"));
    /// assert_eq!(map[&37], "c");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, key: K, value: V) -> Option<V>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(mut entry) => Some(entry.insert(value)),
            Vacant(entry) => {
                entry.insert(value);
                None
            }
        }
    }

    /// ພະຍາຍາມທີ່ຈະໃສ່ຄູ່ທີ່ມີຄ່າ ສຳ ຄັນເຂົ້າໃນແຜນທີ່, ແລະສົ່ງຄືນການອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບຄ່າໃນການເຂົ້າ.
    ///
    /// ຖ້າແຜນທີ່ມີປະຈຸບັນທີ່ ສຳ ຄັນນີ້ແລ້ວ, ບໍ່ມີຫຍັງຖືກປັບປຸງ, ແລະຂໍ້ຜິດພາດທີ່ບັນຈຸການ ນຳ ເຂົ້າແລະຄ່າຈະຖືກສົ່ງຄືນ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(map_try_insert)]
    ///
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.try_insert(37, "a").unwrap(), &"a");
    ///
    /// let err = map.try_insert(37, "b").unwrap_err();
    /// assert_eq!(err.entry.key(), &37);
    /// assert_eq!(err.entry.get(), &"a");
    /// assert_eq!(err.value, "b");
    /// ```
    ///
    #[unstable(feature = "map_try_insert", issue = "82766")]
    pub fn try_insert(&mut self, key: K, value: V) -> Result<&mut V, OccupiedError<'_, K, V>>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(entry) => Err(OccupiedError { entry, value }),
            Vacant(entry) => Ok(entry.insert(value)),
        }
    }

    /// ຖອດກຸນແຈອອກຈາກແຜນທີ່, ສົ່ງຄືນມູນຄ່າທີ່ປຸ່ມຖ້າຫາກວ່າກະແຈຢູ່ໃນແຜນທີ່ກ່ອນ ໜ້າ ນີ້.
    ///
    /// ກຸນແຈອາດຈະແມ່ນຮູບແບບທີ່ຢືມມາຈາກປະເພດທີ່ ສຳ ຄັນຂອງແຜນທີ່, ແຕ່ການສັ່ງຊື້ໃນແບບຟອມທີ່ຖືກຢືມ *ຕ້ອງ* ກົງກັບການສັ່ງຊື້ໃນປະເພດຫຼັກ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove(&1), Some("a"));
    /// assert_eq!(map.remove(&1), None);
    /// ```
    ///
    #[doc(alias = "delete")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove<Q: ?Sized>(&mut self, key: &Q) -> Option<V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.remove_entry(key).map(|(_, v)| v)
    }

    /// ຖອດກຸນແຈອອກຈາກແຜນທີ່, ສົ່ງຄືນລະຫັດແລະມູນຄ່າທີ່ເກັບໄວ້ຖ້າຫາກວ່າກະແຈຢູ່ໃນແຜນທີ່ກ່ອນ ໜ້າ ນີ້.
    ///
    /// ກຸນແຈອາດຈະແມ່ນຮູບແບບທີ່ຢືມມາຈາກປະເພດທີ່ ສຳ ຄັນຂອງແຜນທີ່, ແຕ່ການສັ່ງຊື້ໃນແບບຟອມທີ່ຖືກຢືມ *ຕ້ອງ* ກົງກັບການສັ່ງຊື້ໃນປະເພດຫຼັກ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove_entry(&1), Some((1, "a")));
    /// assert_eq!(map.remove_entry(&1), None);
    /// ```
    ///
    #[stable(feature = "btreemap_remove_entry", since = "1.45.0")]
    pub fn remove_entry<Q: ?Sized>(&mut self, key: &Q) -> Option<(K, V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_entry())
            }
            GoDown(_) => None,
        }
    }

    /// ຮັກສາພຽງແຕ່ອົງປະກອບທີ່ລະບຸໄວ້ໂດຍຜູ້ຄາດຄະເນ.
    ///
    /// ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ເອົາທັງຫມົດຄູ່ `(k, v)` ເຊັ່ນວ່າ `f(&k, &mut v)` ກັບຄືນ `false`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(btree_retain)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x*10)).collect();
    /// // ຮັກສາພຽງແຕ່ອົງປະກອບທີ່ມີຄີທີ່ມີຕົວເລກ.
    /// map.retain(|&k, _| k % 2 == 0);
    /// assert!(map.into_iter().eq(vec![(0, 0), (2, 20), (4, 40), (6, 60)]));
    /// ```
    #[inline]
    #[unstable(feature = "btree_retain", issue = "79025")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        self.drain_filter(|k, v| !f(k, v));
    }

    /// ຍ້າຍອົງປະກອບທັງ ໝົດ ຈາກ `other` ມາເປັນ `Self`, ເຮັດໃຫ້ `other` ຫວ່າງເປົ່າ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    ///
    /// let mut b = BTreeMap::new();
    /// b.insert(3, "d");
    /// b.insert(4, "e");
    /// b.insert(5, "f");
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.len(), 5);
    /// assert_eq!(b.len(), 0);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    /// assert_eq!(a[&3], "d");
    /// assert_eq!(a[&4], "e");
    /// assert_eq!(a[&5], "f");
    /// ```
    #[stable(feature = "btree_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self)
    where
        K: Ord,
    {
        // ພວກເຮົາຕ້ອງໄດ້ໃສ່ຫຍັງອີກບໍ່?
        if other.is_empty() {
            return;
        }

        // ພວກເຮົາພຽງແຕ່ສາມາດປ່ຽນ `self` ແລະ `other` ຖ້າ `self` ແມ່ນຫວ່າງເປົ່າ.
        if self.is_empty() {
            mem::swap(self, other);
            return;
        }

        let self_iter = mem::take(self).into_iter();
        let other_iter = mem::take(other).into_iter();
        let root = BTreeMap::ensure_is_owned(&mut self.root);
        root.append_from_sorted_iters(self_iter, other_iter, &mut self.length)
    }

    /// ການກໍ່ສ້າງຕົວຊີ້ທິດທາງແບບສອງຊັ້ນທີ່ຂື້ນກັບລະດັບຂອງອົງປະກອບຍ່ອຍໃນແຜນທີ່.
    /// ວິທີທີ່ງ່າຍທີ່ສຸດແມ່ນການ ນຳ ໃຊ້ syntax `min..max`, ດັ່ງນັ້ນ `range(min..max)` ຈະໃຫ້ຜົນຜະລິດຈາກ min (inclusive) ເຖິງສູງສຸດ (exclusive).
    /// ຊ່ວງນັ້ນຍັງອາດຈະຖືກໃສ່ເປັນ `(Bound<T>, Bound<T>)`, ສະນັ້ນຕົວຢ່າງ `range((Excluded(4), Included(10)))` ຈະໃຫ້ຜົນຜະລິດຢູ່ເບື້ອງຊ້າຍ, ສະເພາະດ້ານຂວາແຕ່ 4 ຫາ 10.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຊ່ວງ `start > end`.
    /// Panics ຖ້າຊ່ວງ `start == end` ແລະຂອບເຂດທັງສອງແມ່ນ `Excluded`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::ops::Bound::Included;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "a");
    /// map.insert(5, "b");
    /// map.insert(8, "c");
    /// for (&key, &value) in map.range((Included(&4), Included(&8))) {
    ///     println!("{}: {}", key, value);
    /// }
    /// assert_eq!(Some((&5, &"b")), map.range(4..).next());
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range<T: ?Sized, R>(&self, range: R) -> Range<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &self.root {
            Range { inner: root.reborrow().range_search(range) }
        } else {
            Range { inner: LeafRange::none() }
        }
    }

    /// ກໍ່ສ້າງຕົວປ່ຽນທິດທາງສອງດ້ານທີ່ປ່ຽນແປງໄດ້ໃນໄລຍະປະເພດຍ່ອຍຂອງແຜນທີ່.
    /// ວິທີທີ່ງ່າຍທີ່ສຸດແມ່ນການ ນຳ ໃຊ້ syntax `min..max`, ດັ່ງນັ້ນ `range(min..max)` ຈະໃຫ້ຜົນຜະລິດຈາກ min (inclusive) ເຖິງສູງສຸດ (exclusive).
    /// ຊ່ວງນັ້ນຍັງອາດຈະຖືກໃສ່ເປັນ `(Bound<T>, Bound<T>)`, ສະນັ້ນຕົວຢ່າງ `range((Excluded(4), Included(10)))` ຈະໃຫ້ຜົນຜະລິດຢູ່ເບື້ອງຊ້າຍ, ສະເພາະດ້ານຂວາແຕ່ 4 ຫາ 10.
    ///
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຊ່ວງ `start > end`.
    /// Panics ຖ້າຊ່ວງ `start == end` ແລະຂອບເຂດທັງສອງແມ່ນ `Excluded`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, i32> = ["Alice", "Bob", "Carol", "Cheryl"]
    ///     .iter()
    ///     .map(|&s| (s, 0))
    ///     .collect();
    /// for (_, balance) in map.range_mut("B".."Cheryl") {
    ///     *balance += 100;
    /// }
    /// for (name, balance) in &map {
    ///     println!("{} => {}", name, balance);
    /// }
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range_mut<T: ?Sized, R>(&mut self, range: R) -> RangeMut<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &mut self.root {
            RangeMut { inner: root.borrow_valmut().range_search(range), _marker: PhantomData }
        } else {
            RangeMut { inner: LeafRange::none(), _marker: PhantomData }
        }
    }

    /// ເອົາເຂົ້າທີ່ສອດຄ້ອງກັນຂອງຄີໃນແຜນທີ່ເພື່ອການ ໝູນ ໃຊ້ສະຖານທີ່.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut count: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// // ນັບ ຈຳ ນວນການປະກົດຕົວຂອງຕົວອັກສອນໃນ vec
    /// for x in vec!["a", "b", "a", "c", "a", "b"] {
    ///     *count.entry(x).or_insert(0) += 1;
    /// }
    ///
    /// assert_eq!(count["a"], 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn entry(&mut self, key: K) -> Entry<'_, K, V>
    where
        K: Ord,
    {
        // FIXME(@porglezomp) ຫລີກລ້ຽງການຈັດສັນຖ້າພວກເຮົາບໍ່ໃສ່
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree(&key) {
            Found(handle) => Occupied(OccupiedEntry { handle, dormant_map, _marker: PhantomData }),
            GoDown(handle) => {
                Vacant(VacantEntry { key, handle, dormant_map, _marker: PhantomData })
            }
        }
    }

    /// ແຍກການເກັບລວບລວມເປັນສອງທີ່ຄີທີ່ໃຫ້.
    /// ສົ່ງຄືນທຸກສິ່ງທຸກຢ່າງຫລັງຈາກຄີທີ່ໃຫ້, ລວມທັງກະແຈ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    /// a.insert(17, "d");
    /// a.insert(41, "e");
    ///
    /// let b = a.split_off(&3);
    ///
    /// assert_eq!(a.len(), 2);
    /// assert_eq!(b.len(), 3);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    ///
    /// assert_eq!(b[&3], "c");
    /// assert_eq!(b[&17], "d");
    /// assert_eq!(b[&41], "e");
    /// ```
    #[stable(feature = "btree_split_off", since = "1.11.0")]
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        K: Borrow<Q> + Ord,
    {
        if self.is_empty() {
            return Self::new();
        }

        let total_num = self.len();
        let left_root = self.root.as_mut().unwrap(); // unwrap ສົບຜົນສໍາເລັດເພາະວ່າບໍ່ແມ່ນຫວ່າງເປົ່າ

        let right_root = left_root.split_off(key);

        let (new_left_len, right_len) = Root::calc_split_length(total_num, &left_root, &right_root);
        self.length = new_left_len;

        BTreeMap { root: Some(right_root), length: right_len }
    }

    /// ສ້າງຕົວປ່ຽນແປງທີ່ໄປຢ້ຽມຢາມທຸກໆອົງປະກອບ (ຄູ່ ສຳ ຄັນທີ່ມີຄຸນຄ່າ) ໃນການຂຶ້ນລະດັບ ຄຳ ສັ່ງທີ່ ສຳ ຄັນແລະໃຊ້ການປິດເພື່ອ ກຳ ນົດວ່າຄວນເອົາອົງປະກອບໃດ ໜຶ່ງ ອອກໄປ.
    /// ຖ້າການປິດຈະກັບຄືນ `true`, ອົງປະກອບຈະຖືກຍ້າຍອອກຈາກແຜນທີ່ແລະໃຫ້ຜົນຜະລິດ.
    /// ຖ້າການປິດຈະກັບຄືນ `false`, ຫຼື panics, ອົງປະກອບຈະຍັງຄົງຢູ່ໃນແຜນທີ່ແລະຈະບໍ່ໃຫ້ຜົນຜະລິດ.
    ///
    /// ຕົວປ່ຽນແປງຍັງຊ່ວຍໃຫ້ທ່ານປ່ຽນມູນຄ່າຂອງແຕ່ລະອົງປະກອບໃນການປິດ, ບໍ່ວ່າທ່ານຈະເລືອກທີ່ຈະຮັກສາຫຼືເອົາມັນອອກ.
    ///
    /// ຖ້າຫາກວ່າຕົວປ່ຽນແມ່ນໃຊ້ພຽງບາງສ່ວນຫຼືບໍລິໂພກຢູ່ທັງ ໝົດ, ແຕ່ລະສ່ວນທີ່ຍັງເຫຼືອແມ່ນຍັງຕ້ອງຖືກປິດ, ເຊິ່ງອາດຈະປ່ຽນຄຸນຄ່າຂອງມັນແລະໂດຍການກັບຄືນ `true`, ມີສ່ວນປະກອບທີ່ຖືກຍ້າຍແລະຫຼຸດລົງ.
    ///
    ///
    /// ມັນຍັງບໍ່ໄດ້ລະບຸວ່າຈະມີອົງປະກອບໃດເພີ່ມເຕີມທີ່ຈະຖືກປິດຖ້າມີ panic ເກີດຂື້ນໃນການປິດ, ຫຼື panic ເກີດຂື້ນໃນຂະນະທີ່ ກຳ ລັງລຸດອົງປະກອບ, ຫຼືຖ້າມູນຄ່າ `DrainFilter` ຖືກຮົ່ວໄຫຼ.
    ///
    /// # Examples
    ///
    /// ການແບ່ງປັນແຜນທີ່ເຂົ້າໄປໃນປຸ່ມຕ່າງໆແລະແມ້ແຕ່ຄີກ, ນຳ ໃຊ້ແຜນທີ່ເດີມ:
    ///
    /// ```
    /// #![feature(btree_drain_filter)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x)).collect();
    /// let evens: BTreeMap<_, _> = map.drain_filter(|k, _v| k % 2 == 0).collect();
    /// let odds = map;
    /// assert_eq!(evens.keys().copied().collect::<Vec<_>>(), vec![0, 2, 4, 6]);
    /// assert_eq!(odds.keys().copied().collect::<Vec<_>>(), vec![1, 3, 5, 7]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "btree_drain_filter", issue = "70530")]
    pub fn drain_filter<F>(&mut self, pred: F) -> DrainFilter<'_, K, V, F>
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        DrainFilter { pred, inner: self.drain_filter_inner() }
    }

    pub(super) fn drain_filter_inner(&mut self) -> DrainFilterInner<'_, K, V>
    where
        K: Ord,
    {
        if let Some(root) = self.root.as_mut() {
            let (root, dormant_root) = DormantMutRef::new(root);
            let front = root.borrow_mut().first_leaf_edge();
            DrainFilterInner {
                length: &mut self.length,
                dormant_root: Some(dormant_root),
                cur_leaf_edge: Some(front),
            }
        } else {
            DrainFilterInner { length: &mut self.length, dormant_root: None, cur_leaf_edge: None }
        }
    }

    /// ສ້າງຕົວຊີ້ວັດທີ່ໃຊ້ບໍລິໂພກຢ້ຽມຢາມຂໍກະແຈທຸກຢ່າງ, ຈັດລຽງຕາມ ລຳ ດັບ.
    /// ແຜນທີ່ບໍ່ສາມາດໃຊ້ໄດ້ຫຼັງຈາກທີ່ທ່ານໂທຫານີ້.
    /// ປະເພດທາດອົງປະກອບແມ່ນ `K`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<i32> = a.into_keys().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_keys(self) -> IntoKeys<K, V> {
        IntoKeys { inner: self.into_iter() }
    }

    /// ສ້າງຕົວຊີ້ວັດການຊົມໃຊ້ທີ່ໄປຢ້ຽມຢາມທຸກໆຄຸນຄ່າຕາມ ລຳ ດັບ.
    /// ແຜນທີ່ບໍ່ສາມາດໃຊ້ໄດ້ຫຼັງຈາກທີ່ທ່ານໂທຫານີ້.
    /// ປະເພດທາດອົງປະກອບແມ່ນ `V`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.into_values().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_values(self) -> IntoValues<K, V> {
        IntoValues { inner: self.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a BTreeMap<K, V> {
    type Item = (&'a K, &'a V);
    type IntoIter = Iter<'a, K, V>;

    fn into_iter(self) -> Iter<'a, K, V> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for Iter<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Iter<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for Iter<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Iter<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Iter<'_, K, V> {
    fn clone(&self) -> Self {
        Iter { range: self.range.clone(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a mut BTreeMap<K, V> {
    type Item = (&'a K, &'a mut V);
    type IntoIter = IterMut<'a, K, V>;

    fn into_iter(self) -> IterMut<'a, K, V> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for IterMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for IterMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IterMut<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IterMut<'_, K, V> {}

impl<'a, K, V> IterMut<'a, K, V> {
    /// ສົ່ງຄືນຜູ້ອ້າງອີງໃສ່ລາຍການທີ່ຍັງເຫຼືອ.
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        Iter { range: self.range.iter(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> IntoIterator for BTreeMap<K, V> {
    type Item = (K, V);
    type IntoIter = IntoIter<K, V>;

    fn into_iter(self) -> IntoIter<K, V> {
        let mut me = ManuallyDrop::new(self);
        if let Some(root) = me.root.take() {
            let full_range = root.into_dying().full_range();

            IntoIter { range: full_range, length: me.length }
        } else {
            IntoIter { range: LeafRange::none(), length: 0 }
        }
    }
}

impl<K, V> Drop for Dropper<K, V> {
    fn drop(&mut self) {
        // ຄ້າຍຄືກັນກັບການກ້າວໄປສູ່ລະບົບປັບ ໄໝ.
        fn next_or_end<K, V>(this: &mut Dropper<K, V>) -> Option<(K, V)> {
            if this.remaining_length == 0 {
                unsafe { ptr::read(&this.front).deallocating_end() }
                None
            } else {
                this.remaining_length -= 1;
                Some(unsafe { this.front.deallocating_next_unchecked() })
            }
        }

        struct DropGuard<'a, K, V>(&'a mut Dropper<K, V>);

        impl<'a, K, V> Drop for DropGuard<'a, K, V> {
            fn drop(&mut self) {
                // ສືບຕໍ່ loop ດຽວກັນທີ່ພວກເຮົາປະຕິບັດຢູ່ຂ້າງລຸ່ມນີ້.
                // ນີ້ໃຊ້ໄດ້ພຽງແຕ່ໃນເວລາທີ່ເລີກລົ້ມ, ສະນັ້ນພວກເຮົາບໍ່ຕ້ອງສົນໃຈ panics ໃນເວລານີ້ (ພວກເຂົາຈະເອົາລູກອອກ).
                while let Some(_pair) = next_or_end(&mut self.0) {}
            }
        }

        while let Some(pair) = next_or_end(self) {
            let guard = DropGuard(self);
            drop(pair);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "btree_drop", since = "1.7.0")]
impl<K, V> Drop for IntoIter<K, V> {
    fn drop(&mut self) {
        if let Some(front) = self.range.front.take() {
            Dropper { front, remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Iterator for IntoIter<K, V> {
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.front.as_mut().unwrap().deallocating_next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> DoubleEndedIterator for IntoIter<K, V> {
    fn next_back(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.back.as_mut().unwrap().deallocating_next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IntoIter<K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IntoIter<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Keys<'a, K, V> {
    type Item = &'a K;

    fn next(&mut self) -> Option<&'a K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a K> {
        self.next_back()
    }

    fn min(mut self) -> Option<&'a K> {
        self.next()
    }

    fn max(mut self) -> Option<&'a K> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Keys<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Keys<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Keys<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Keys<'_, K, V> {
    fn clone(&self) -> Self {
        Keys { inner: self.inner.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Values<'a, K, V> {
    type Item = &'a V;

    fn next(&mut self) -> Option<&'a V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a V> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Values<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Values<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Values<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Values<'_, K, V> {
    fn clone(&self) -> Self {
        Values { inner: self.inner.clone() }
    }
}

/// ຕົວລະອໍທີ່ຜະລິດໂດຍການໂທຫາ `drain_filter` ໃນ BTreeMap.
#[unstable(feature = "btree_drain_filter", issue = "70530")]
pub struct DrainFilter<'a, K, V, F>
where
    K: 'a,
    V: 'a,
    F: 'a + FnMut(&K, &mut V) -> bool,
{
    pred: F,
    inner: DrainFilterInner<'a, K, V>,
}
/// ການປະຕິບັດສ່ວນໃຫຍ່ຂອງ DrainFilter ແມ່ນມີຫຼາຍກວ່າປະເພດຂອງການຄາດຄະເນ, ດັ່ງນັ້ນຍັງໃຫ້ບໍລິການ ສຳ ລັບ BTreeSet::DrainFilter.
///
pub(super) struct DrainFilterInner<'a, K: 'a, V: 'a> {
    /// ການອ້າງອີງໃສ່ຂໍ້ມູນຍາວໃນແຜນທີ່ທີ່ຢືມ, ປັບປຸງສົດ.
    length: &'a mut usize,
    /// ການອ້າງອີງຝັງໃສ່ພື້ນທີ່ຮາກໃນແຜນທີ່ຢືມ.
    /// ຫໍ່ຢູ່ໃນ `Option` ເພື່ອອະນຸຍາດໃຫ້ຜູ້ຈັດການລຸດລົງໄປທີ່ `take` ມັນ.
    dormant_root: Option<DormantMutRef<'a, Root<K, V>>>,
    /// ປະກອບດ້ວຍໃບ edge ທີ່ຢູ່ກ່ອນອົງປະກອບຕໍ່ໄປທີ່ຈະກັບຄືນມາ, ຫຼືໃບສຸດທ້າຍ edge.
    /// ຫວ່າງເປົ່າຖ້າຫາກວ່າແຜນທີ່ບໍ່ມີຮາກ, ຖ້າຫາກວ່າຄວາມເລິກໄດ້ກາຍໃບສຸດທ້າຍ edge, ຫຼືຖ້າ panic ເກີດຂື້ນໃນການຄາດຄະເນ.
    ///
    cur_leaf_edge: Option<Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>>,
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Drop for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    fn drop(&mut self) {
        self.for_each(drop);
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> fmt::Debug for DrainFilter<'_, K, V, F>
where
    K: fmt::Debug,
    V: fmt::Debug,
    F: FnMut(&K, &mut V) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.inner.peek()).finish()
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Iterator for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        self.inner.next(&mut self.pred)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

impl<'a, K: 'a, V: 'a> DrainFilterInner<'a, K, V> {
    /// ອະນຸຍາດໃຫ້ມີການປະຕິບັດ Debug ເພື່ອຄາດເດົາອົງປະກອບຕໍ່ໄປ.
    pub(super) fn peek(&self) -> Option<(&K, &V)> {
        let edge = self.cur_leaf_edge.as_ref()?;
        edge.reborrow().next_kv().ok().map(Handle::into_kv)
    }

    /// ການປະຕິບັດວິທີການ `DrainFilter::next` ແບບປົກກະຕິ, ຕາມການຄາດຄະເນ.
    pub(super) fn next<F>(&mut self, pred: &mut F) -> Option<(K, V)>
    where
        F: FnMut(&K, &mut V) -> bool,
    {
        while let Ok(mut kv) = self.cur_leaf_edge.take()?.next_kv() {
            let (k, v) = kv.kv_mut();
            if pred(k, v) {
                *self.length -= 1;
                let (kv, pos) = kv.remove_kv_tracking(|| {
                    // ປອດໄພ: ພວກເຮົາຈະແຕະຮາກໃນທາງທີ່ຈະບໍ່ເຮັດ
                    // invalidate ຕໍາແຫນ່ງໄດ້ກັບຄືນ.
                    let root = unsafe { self.dormant_root.take().unwrap().awaken() };
                    root.pop_internal_level();
                    self.dormant_root = Some(DormantMutRef::new(root).1);
                });
                self.cur_leaf_edge = Some(pos);
                return Some(kv);
            }
            self.cur_leaf_edge = Some(kv.next_leaf_edge());
        }
        None
    }

    /// ການປະຕິບັດວິທີການ `DrainFilter::size_hint` ແບບປົກກະຕິ.
    pub(super) fn size_hint(&self) -> (usize, Option<usize>) {
        // ໃນສ່ວນໃຫຍ່ຂອງລະບົບ ສຳ ຜັດ btree, `self.length` ແມ່ນ ຈຳ ນວນຂອງສ່ວນປະກອບທີ່ຍັງບໍ່ທັນໄດ້ໄປຢ້ຽມຢາມ.
        // ນີ້, ມັນປະກອບມີອົງປະກອບທີ່ໄດ້ໄປຢ້ຽມຢາມແລະຜູ້ຄາດຄະເນໄດ້ຕັດສິນໃຈບໍ່ໃຫ້ drain.
        // ການເຮັດໃຫ້ຂອບເຂດເທິງນີ້ມີຄວາມຖືກຕ້ອງສູງຂື້ນຮຽກຮ້ອງໃຫ້ມີການຮັກສາສະ ໜາມ ເສີມແລະບໍ່ມີຄ່າຫຍັງໃນຂະນະທີ່.
        //
        (0, Some(*self.length))
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> FusedIterator for DrainFilter<'_, K, V, F> where F: FnMut(&K, &mut V) -> bool {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for Range<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> Iterator for ValuesMut<'a, K, V> {
    type Item = &'a mut V;

    fn next(&mut self) -> Option<&'a mut V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a mut V> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> DoubleEndedIterator for ValuesMut<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a mut V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V> ExactSizeIterator for ValuesMut<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for ValuesMut<'_, K, V> {}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoKeys<K, V> {
    type Item = K;

    fn next(&mut self) -> Option<K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<K> {
        self.next_back()
    }

    fn min(mut self) -> Option<K> {
        self.next()
    }

    fn max(mut self) -> Option<K> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoKeys<K, V> {
    fn next_back(&mut self) -> Option<K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoKeys<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoKeys<K, V> {}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoValues<K, V> {
    type Item = V;

    fn next(&mut self) -> Option<V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<V> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoValues<K, V> {
    fn next_back(&mut self) -> Option<V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoValues<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoValues<K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for Range<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Range<'_, K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<K, V> Clone for Range<'_, K, V> {
    fn clone(&self) -> Self {
        Range { inner: LeafRange { front: self.inner.front, back: self.inner.back } }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for RangeMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }

    /// ສົ່ງຄືນຜູ້ອ້າງອີງໃສ່ລາຍການທີ່ຍັງເຫຼືອ.
    #[inline]
    pub(super) fn iter(&self) -> Range<'_, K, V> {
        Range { inner: self.inner.reborrow() }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for RangeMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for RangeMut<'_, K, V> {}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> FromIterator<(K, V)> for BTreeMap<K, V> {
    fn from_iter<T: IntoIterator<Item = (K, V)>>(iter: T) -> BTreeMap<K, V> {
        let mut map = BTreeMap::new();
        map.extend(iter);
        map
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Extend<(K, V)> for BTreeMap<K, V> {
    #[inline]
    fn extend<T: IntoIterator<Item = (K, V)>>(&mut self, iter: T) {
        iter.into_iter().for_each(move |(k, v)| {
            self.insert(k, v);
        });
    }

    #[inline]
    fn extend_one(&mut self, (k, v): (K, V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, K: Ord + Copy, V: Copy> Extend<(&'a K, &'a V)> for BTreeMap<K, V> {
    fn extend<I: IntoIterator<Item = (&'a K, &'a V)>>(&mut self, iter: I) {
        self.extend(iter.into_iter().map(|(&key, &value)| (key, value)));
    }

    #[inline]
    fn extend_one(&mut self, (&k, &v): (&'a K, &'a V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Hash, V: Hash> Hash for BTreeMap<K, V> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        for elt in self {
            elt.hash(state);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Default for BTreeMap<K, V> {
    /// ສ້າງ `BTreeMap` ເປົ່າ.
    fn default() -> BTreeMap<K, V> {
        BTreeMap::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialEq, V: PartialEq> PartialEq for BTreeMap<K, V> {
    fn eq(&self, other: &BTreeMap<K, V>) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a == b)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Eq, V: Eq> Eq for BTreeMap<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialOrd, V: PartialOrd> PartialOrd for BTreeMap<K, V> {
    #[inline]
    fn partial_cmp(&self, other: &BTreeMap<K, V>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V: Ord> Ord for BTreeMap<K, V> {
    #[inline]
    fn cmp(&self, other: &BTreeMap<K, V>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Debug, V: Debug> Debug for BTreeMap<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_map().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, Q: ?Sized, V> Index<&Q> for BTreeMap<K, V>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Output = V;

    /// ສົ່ງຂໍ້ມູນອ້າງອີງໃສ່ມູນຄ່າທີ່ສອດຄ້ອງກັບຄີທີ່ສະ ໜອງ ໃຫ້.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າກຸນແຈບໍ່ຢູ່ໃນ `BTreeMap`.
    #[inline]
    fn index(&self, key: &Q) -> &V {
        self.get(key).expect("no entry found for key")
    }
}

impl<K, V> BTreeMap<K, V> {
    /// ຈັບຕົວຜູ້ແກ້ໄຂຂໍ້ມູນຂອງແຜນທີ່, ຈັດຮຽງຕາມຄີ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "c");
    /// map.insert(2, "b");
    /// map.insert(1, "a");
    ///
    /// for (key, value) in map.iter() {
    ///     println!("{}: {}", key, value);
    /// }
    ///
    /// let (first_key, first_value) = map.iter().next().unwrap();
    /// assert_eq!((*first_key, *first_value), (1, "a"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, K, V> {
        if let Some(root) = &self.root {
            let full_range = root.reborrow().full_range();

            Iter { range: Range { inner: full_range }, length: self.length }
        } else {
            Iter { range: Range { inner: LeafRange::none() }, length: 0 }
        }
    }

    /// ເຮັດໃຫ້ຕົວປ່ຽນທິດທາງປ່ຽນແປງໄດ້ໃນການເຂົ້າຂອງແຜນທີ່, ຈັດຮຽງຕາມຄີ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert("a", 1);
    /// map.insert("b", 2);
    /// map.insert("c", 3);
    ///
    /// // ເພີ່ມ ຈຳ ນວນ 10 ໃຫ້ຄ່າຖ້າຄີບໍ່ແມ່ນ "a"
    /// for (key, value) in map.iter_mut() {
    ///     if key != &"a" {
    ///         *value += 10;
    ///     }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, K, V> {
        if let Some(root) = &mut self.root {
            let full_range = root.borrow_valmut().full_range();

            IterMut {
                range: RangeMut { inner: full_range, _marker: PhantomData },
                length: self.length,
            }
        } else {
            IterMut {
                range: RangeMut { inner: LeafRange::none(), _marker: PhantomData },
                length: 0,
            }
        }
    }

    /// ຈັບຕົວຜູ້ແກ້ໄຂຂື້ນເທິງກະແຈຂອງແຜນທີ່, ຕາມການຈັດຮຽງຕາມ ລຳ ດັບ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<_> = a.keys().cloned().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn keys(&self) -> Keys<'_, K, V> {
        Keys { inner: self.iter() }
    }

    /// ເອົາຜູ້ຕິດຕາມຜ່ານມູນຄ່າຂອງແຜນທີ່ຕາມ ລຳ ດັບ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.values().cloned().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn values(&self) -> Values<'_, K, V> {
        Values { inner: self.iter() }
    }

    /// ເຮັດໃຫ້ຕົວປ່ຽນແປງປ່ຽນແປງໄດ້ຫຼາຍກວ່າຄຸນຄ່າຂອງແຜນທີ່, ຕາມ ລຳ ດັບ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, String::from("hello"));
    /// a.insert(2, String::from("goodbye"));
    ///
    /// for value in a.values_mut() {
    ///     value.push_str("!");
    /// }
    ///
    /// let values: Vec<String> = a.values().cloned().collect();
    /// assert_eq!(values, [String::from("hello!"),
    ///                     String::from("goodbye!")]);
    /// ```
    #[stable(feature = "map_values_mut", since = "1.10.0")]
    pub fn values_mut(&mut self) -> ValuesMut<'_, K, V> {
        ValuesMut { inner: self.iter_mut() }
    }

    /// ກັບຄືນ ຈຳ ນວນຂອງສ່ວນປະກອບໃນແຜນທີ່.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert_eq!(a.len(), 0);
    /// a.insert(1, "a");
    /// assert_eq!(a.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn len(&self) -> usize {
        self.length
    }

    /// ກັບຄືນ `true` ຖ້າແຜນທີ່ບໍ່ມີສ່ວນປະກອບ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert!(a.is_empty());
    /// a.insert(1, "a");
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ຖ້າ node ຮາກແມ່ນຂໍ້ n (non-allocated) X root ເປົ່າ, ຈັດສັນຂໍ້ມູນຂອງພວກເຮົາເອງ.
    /// ແມ່ນ ໜ້າ ທີ່ທີ່ກ່ຽວຂ້ອງເພື່ອຫລີກລ້ຽງການກູ້ຢືມເງິນ BTreeMap ທັງ ໝົດ.
    fn ensure_is_owned(root: &mut Option<Root<K, V>>) -> &mut Root<K, V> {
        root.get_or_insert_with(Root::new)
    }
}

#[cfg(test)]
mod tests;