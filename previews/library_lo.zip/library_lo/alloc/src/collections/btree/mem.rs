use core::intrinsics;
use core::mem;
use core::ptr;

/// ສິ່ງນີ້ຈະປ່ຽນແທນມູນຄ່າທີ່ຢູ່ເບື້ອງຫຼັງເອກະສານອ້າງອີງ `v` ໂດຍການໂທຫາ ໜ້າ ທີ່ທີ່ກ່ຽວຂ້ອງ.
///
///
/// ຖ້າ panic ເກີດຂື້ນໃນການປິດ `change`, ຂະບວນການທັງຫມົດຈະຖືກຍົກເລີກ.
#[allow(dead_code)] // ຮັກສາເປັນຕົວຢ່າງແລະ ສຳ ລັບການ ນຳ ໃຊ້ future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// ສິ່ງນີ້ຈະປ່ຽນແທນມູນຄ່າທີ່ຢູ່ເບື້ອງຫຼັງເອກະສານອ້າງອີງ `v` ໂດຍການໂທຫາ ໜ້າ ທີ່ທີ່ກ່ຽວຂ້ອງ, ແລະສົ່ງຜົນໄດ້ຮັບທີ່ໄດ້ຮັບຕາມທາງ.
///
///
/// ຖ້າ panic ເກີດຂື້ນໃນການປິດ `change`, ຂະບວນການທັງຫມົດຈະຖືກຍົກເລີກ.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}