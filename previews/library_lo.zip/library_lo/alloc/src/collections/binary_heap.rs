//! ແຖວ ລຳ ດັບຄວາມ ສຳ ຄັນໄດ້ຈັດຕັ້ງປະຕິບັດກັບຖານສອງຂໍ້.
//!
//! ການແຊກແລະການປັ່ນປ່ວນອົງປະກອບທີ່ໃຫຍ່ທີ່ສຸດມີຄວາມສັບສົນເວລາ *O*(log(*n*)).
//! ການກວດສອບອົງປະກອບທີ່ໃຫຍ່ທີ່ສຸດແມ່ນ *O*(1).ການແປງ vector ໃຫ້ເປັນ heap ຄູ່ສາມາດເຮັດໄດ້ໃນສະຖານທີ່, ແລະມີຄວາມສັບສົນ *O*(*n*).
//! heap ຖານສອງຍັງສາມາດປ່ຽນເປັນ vector ທີ່ມີການຈັດລຽງ, ອະນຸຍາດໃຫ້ມັນຖືກ ນຳ ໃຊ້ ສຳ ລັບສະຖານທີ່ *O*(*n*\*log(* n*))) ໃນສະຖານທີ່.
//!
//! # Examples
//!
//! ນີ້ແມ່ນຕົວຢ່າງທີ່ໃຫຍ່ກວ່າທີ່ປະຕິບັດ [Dijkstra's algorithm][dijkstra] ເພື່ອແກ້ໄຂ [shortest path problem][sssp] ໃນ [directed graph][dir_graph].
//!
//! ມັນສະແດງໃຫ້ເຫັນວິທີການໃຊ້ [`BinaryHeap`] ກັບປະເພດລູກຄ້າ.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // ແຖວ ລຳ ດັບຄວາມ ສຳ ຄັນຂື້ນກັບ `Ord`.
//! // ປະຕິບັດຢ່າງຊັດເຈນ trait ເພື່ອໃຫ້ແຖວກາຍເປັນ min-heap ແທນທີ່ຈະເປັນ heap ສູງສຸດ.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // ສັງເກດເຫັນວ່າພວກເຮົາພິສູດການສັ່ງສິນຄ້າຕາມຕົ້ນທຶນ.
//!         // ໃນກໍລະນີທີ່ພວກເຮົາສົມທຽບ ຕຳ ແໜ່ງ, ຂັ້ນຕອນນີ້ແມ່ນ ຈຳ ເປັນເພື່ອເຮັດໃຫ້ການຈັດຕັ້ງປະຕິບັດ `PartialEq` ແລະ `Ord` ສອດຄ່ອງ.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` ຕ້ອງມີການຈັດຕັ້ງປະຕິບັດເຊັ່ນກັນ.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // ແຕ່ລະ node ແມ່ນຕົວແທນເປັນ `usize`, ເພື່ອປະຕິບັດສັ້ນກວ່າ.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // ສູດການຄິດໄລ່ເສັ້ນທາງທີ່ສັ້ນທີ່ສຸດຂອງ Dijkstra.
//!
//! // ເລີ່ມຕົ້ນທີ່ `start` ແລະໃຊ້ `dist` ເພື່ອຕິດຕາມໄລຍະທາງທີ່ສັ້ນທີ່ສຸດໃນປະຈຸບັນຕໍ່ແຕ່ລະ node.ການຈັດຕັ້ງປະຕິບັດນີ້ບໍ່ມີປະສິດຕິພາບສູງເພາະມັນອາດຈະເຮັດໃຫ້ຂໍ້ມູນຊ້ ຳ ຢູ່ໃນແຖວ.
//! //
//! // ມັນຍັງໃຊ້ `usize::MAX` ເປັນມູນຄ່າສົ່ງ, ເພື່ອການປະຕິບັດງ່າຍດາຍ.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=ໄລຍະຫ່າງສັ້ນທີ່ສຸດໃນປະຈຸບັນຈາກ `start` ເຖິງ `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // ພວກເຮົາຢູ່ທີ່ `start`, ມີຄ່າໃຊ້ຈ່າຍສູນ
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // ກວດເບິ່ງເຂດແດນທີ່ມີຂໍ້ມູນຕົ້ນທຶນຕ່ ຳ ກວ່າ (min-heap) ກ່ອນ
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // ອີກທາງເລືອກ ໜຶ່ງ ພວກເຮົາສາມາດສືບຕໍ່ຊອກຫາທຸກເສັ້ນທາງທີ່ສັ້ນທີ່ສຸດ
//!         if position == goal { return Some(cost); }
//!
//!         // ສິ່ງ ສຳ ຄັນດັ່ງທີ່ພວກເຮົາອາດໄດ້ພົບເຫັນວິທີການທີ່ດີກວ່າແລ້ວ
//!         if cost > dist[position] { continue; }
//!
//!         // ສຳ ລັບແຕ່ລະ node ທີ່ພວກເຮົາສາມາດໄປເຖິງ, ເບິ່ງວ່າພວກເຮົາສາມາດຊອກຫາທາງທີ່ມີຄ່າໃຊ້ຈ່າຍຕ່ ຳ ກວ່າທີ່ຈະຜ່ານທາງ node ນີ້
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // ຖ້າເປັນດັ່ງນັ້ນ, ຕື່ມໃສ່ແຖວ ໜ້າ ແລະສືບຕໍ່
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // ການພັກຜ່ອນຢ່ອນໃຈ, ດຽວນີ້ພວກເຮົາໄດ້ພົບເຫັນວິທີທີ່ດີກວ່າເກົ່າ
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // ເປົ້າ ໝາຍ ບໍ່ສາມາດເຂົ້າເຖິງໄດ້
//!     None
//! }
//!
//! fn main() {
//!     // ນີ້ແມ່ນເສັ້ນສະແດງທີ່ ກຳ ນົດທີ່ພວກເຮົາຈະ ນຳ ໃຊ້.
//!     // ຈຳ ນວນໂຫນດແມ່ນກົງກັບລັດທີ່ແຕກຕ່າງກັນ, ແລະນ້ ຳ ໜັກ edge ເປັນສັນຍາລັກຄ່າໃຊ້ຈ່າຍໃນການຍ້າຍຈາກ node ໄປຫາອີກບ່ອນ ໜຶ່ງ.
//!     //
//!     // ໃຫ້ສັງເກດວ່າແຄມແມ່ນທາງດຽວ.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |.
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           | | ||
//!     //                   +---------------+
//!     //
//!     // ເສັ້ນສະແດງໄດ້ຖືກສະແດງເປັນບັນຊີລາຍຊື່ທີ່ໃກ້ຄຽງເຊິ່ງແຕ່ລະດັດສະນີ, ກົງກັບຄ່າຂອງຂໍ້, ມີລາຍຊື່ຂອງຂອບທີ່ອອກ.
//!     // ເລືອກສໍາລັບປະສິດທິພາບຂອງມັນ.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Node 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // ຂໍ້ 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // ຂໍ້ 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Node 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Node 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// ແຖວ ລຳ ດັບຄວາມ ສຳ ຄັນໄດ້ຈັດຕັ້ງປະຕິບັດກັບຖານສອງຂໍ້.
///
/// ນີ້ຈະເປັນຄວາມໄວສູງສຸດ.
///
/// ມັນແມ່ນຂໍ້ຜິດພາດທີ່ມີເຫດຜົນ ສຳ ລັບລາຍການທີ່ຈະຖືກດັດແປງໃນລັກສະນະທີ່ສິນຄ້າມີການສັ່ງຊື້ທຽບກັບສິນຄ້າອື່ນໆ, ຕາມທີ່ໄດ້ ກຳ ນົດໂດຍ `Ord` trait, ມີການປ່ຽນແປງໃນຂະນະທີ່ມັນຢູ່ໃນກະຕ່າຂີ້ເຫຍື້ອ.
///
/// ໂດຍປົກກະຕິແລ້ວສິ່ງນີ້ສາມາດເຮັດໄດ້ໂດຍຜ່ານ `Cell`, `RefCell`, ສະພາບທົ່ວໂລກ, I/O, ຫຼືລະຫັດທີ່ບໍ່ປອດໄພ.
/// ພຶດຕິ ກຳ ທີ່ເກີດຈາກຄວາມຜິດພາດຕາມເຫດຜົນດັ່ງກ່າວບໍ່ໄດ້ຖືກລະບຸ, ແຕ່ຈະບໍ່ສົ່ງຜົນໃຫ້ມີພຶດຕິ ກຳ ທີ່ບໍ່ໄດ້ ກຳ ນົດ.
/// ນີ້ສາມາດປະກອບມີ panics, ຜົນໄດ້ຮັບທີ່ບໍ່ຖືກຕ້ອງ, ການເອົາລູກອອກ, ການຮົ່ວໄຫລຂອງຄວາມຊົງຈໍາແລະການບໍ່ຢຸດ.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // ປະເພດ inference ຊ່ວຍໃຫ້ພວກເຮົາຍົກເລີກລາຍເຊັນປະເພດທີ່ຈະແຈ້ງ (ເຊິ່ງຈະເປັນ `BinaryHeap<i32>` ໃນຕົວຢ່າງນີ້).
/////
/// let mut heap = BinaryHeap::new();
///
/// // ພວກເຮົາສາມາດໃຊ້ peek ເພື່ອເບິ່ງລາຍການຕໍ່ໄປໃນ heap.
/// // ໃນກໍລະນີນີ້, ຍັງບໍ່ມີສິນຄ້າຫຍັງຢູ່ໃນນັ້ນເທື່ອພວກເຮົາຈະບໍ່ມີ.
/// assert_eq!(heap.peek(), None);
///
/// // ຂໍໃຫ້ພວກເຮົາເພີ່ມບາງຄະແນນ ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // ດຽວນີ້ peek ສະແດງສິນຄ້າທີ່ ສຳ ຄັນທີ່ສຸດໃນ heap.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // ພວກເຮົາສາມາດກວດສອບຄວາມຍາວຂອງ heap ໄດ້.
/// assert_eq!(heap.len(), 3);
///
/// // ພວກເຮົາສາມາດແກ້ໄຂບັນດາລາຍການທີ່ຢູ່ໃນກະຕ່າໄດ້, ເຖິງວ່າມັນຈະຖືກສົ່ງຄືນຕາມ ລຳ ດັບ.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // ຖ້າພວກເຮົາແທນທີ່ຈະໃຫ້ຄະແນນເຫລົ່ານີ້, ພວກເຂົາຄວນກັບມາເປັນລະບຽບຮຽບຮ້ອຍ.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // ພວກເຮົາສາມາດລ້າງຂີ້ເຫຍື້ອຂອງສິ່ງຂອງທີ່ຍັງເຫຼືອ.
/// heap.clear();
///
/// // heap ໃນປັດຈຸບັນຄວນຈະເປົ່າ.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// ບໍ່ວ່າຈະເປັນ `std::cmp::Reverse` ຫຼືການປະຕິບັດ `Ord` ທີ່ກໍາຫນົດເອງສາມາດຖືກນໍາໃຊ້ເພື່ອເຮັດໃຫ້ `BinaryHeap` ເປັນເວລາຫນ້ອຍ.
/// ນີ້ເຮັດໃຫ້ `heap.pop()` ສົ່ງຄືນຄ່າທີ່ນ້ອຍທີ່ສຸດແທນທີ່ຈະເປັນສິ່ງທີ່ຍິ່ງໃຫຍ່ທີ່ສຸດ.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // ຄ່າຫໍ່ໃນ `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // ຖ້າພວກເຮົາໄດ້ຄະແນນເຫລົ່ານີ້ດຽວນີ້, ພວກເຂົາຄວນຈະກັບມາໃນຄໍາສັ່ງທີ່ສັບສົນ.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # ຄວາມສັບສົນເວລາ
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// ມູນຄ່າຂອງ `push` ແມ່ນຄ່າໃຊ້ຈ່າຍທີ່ຄາດໄວ້;ເອກະສານວິທີການໃຫ້ການວິເຄາະລະອຽດກວ່າ.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// ໂຄງສ້າງຫໍ່ເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບລາຍການໃຫຍ່ທີ່ສຸດໃນ `BinaryHeap`.
///
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍວິທີ [`peek_mut`] ໃນ [`BinaryHeap`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // ຄວາມປອດໄພ: PeekMut ແມ່ນໄດ້ຮັບການຕອບສະ ໜອງ ພຽງແຕ່ ສຳ ລັບສິ່ງທີ່ບໍ່ແມ່ນຫວ່າງ.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut ແມ່ນໄດ້ຮັບການຕອບສະ ໜອງ ພຽງແຕ່ ສຳ ລັບສິ່ງທີ່ບໍ່ແມ່ນຫວ່າງ
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut ແມ່ນໄດ້ຮັບການຕອບສະ ໜອງ ພຽງແຕ່ ສຳ ລັບສິ່ງທີ່ບໍ່ແມ່ນຫວ່າງ
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// ເອົາຄ່າທີ່ຖືກດຶງອອກຈາກ heap ແລະສົ່ງມັນຄືນ.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// ສ້າງ `BinaryHeap<T>` ເປົ່າ.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// ສ້າງ `BinaryHeap` ຫວ່າງເປົ່າເປັນຈຸດສູງສຸດ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// ສ້າງ `BinaryHeap` ເປົ່າທີ່ມີຄວາມສາມາດສະເພາະ.
    /// ນີ້ຈັດແຈງ ໜ່ວຍ ຄວາມ ຈຳ ພຽງພໍ ສຳ ລັບອົງປະກອບ `capacity`, ສະນັ້ນ, `BinaryHeap` ບໍ່ ຈຳ ເປັນຕ້ອງຈັດສັນຢ່າງແທ້ຈິງຈົນກວ່າມັນຈະປະກອບມີຢ່າງ ໜ້ອຍ ຫຼາຍຄ່າ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// ສົ່ງຄືນເອກະສານອ້າງອີງທີ່ປ່ຽນແປງໄດ້ກັບລາຍການທີ່ຍິ່ງໃຫຍ່ທີ່ສຸດໃນຖານຂໍ້ມູນສອງຊ່ອງ, ຫຼື `None` ຖ້າມັນຫວ່າງ.
    ///
    /// Note: ຖ້າຫາກວ່າມູນຄ່າ `PeekMut` ຖືກຮົ່ວໄຫຼ, heap ອາດຈະຢູ່ໃນສະພາບທີ່ບໍ່ສອດຄ່ອງ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # ຄວາມສັບສົນເວລາ
    ///
    /// ຖ້າລາຍການຖືກດັດແກ້ແລ້ວຄວາມສັບສົນທີ່ໃຊ້ເວລາທີ່ຮ້າຍແຮງທີ່ສຸດແມ່ນ *O*(log(*n*)), ຖ້າບໍ່ດັ່ງນັ້ນມັນແມ່ນ *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// ເອົາສິ່ງທີ່ຍິ່ງໃຫຍ່ທີ່ສຸດອອກມາຈາກຖານຂໍ້ມູນສອງເມັດແລະສົ່ງມັນຄືນ, ຫຼື `None` ຖ້າມັນຫວ່າງ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # ຄວາມສັບສົນເວລາ
    ///
    /// ຄ່າໃຊ້ຈ່າຍໃນກໍລະນີທີ່ຮ້າຍແຮງທີ່ສຸດຂອງ `pop` ໃນ heap ທີ່ມີອົງປະກອບ *n* ແມ່ນ *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // ຄວາມປອດໄພ: !self.is_empty() ໝາຍ ຄວາມວ່າ self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// ຍູ້ສິ່ງຂອງລົງໃສ່ທ່ອນໄມ້ໄບ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # ຄວາມສັບສົນເວລາ
    ///
    /// ຄ່າໃຊ້ຈ່າຍທີ່ຄາດວ່າຈະເປັນຂອງ `push`, ໂດຍສະເລ່ຍໃນທຸກໆການຈັດລຽງລໍາດັບທີ່ເປັນໄປໄດ້ຂອງອົງປະກອບທີ່ຖືກຍູ້, ແລະຫຼາຍກວ່າການຊຸກຍູ້ຢ່າງພຽງພໍ, ແມ່ນ *O*(1).
    ///
    /// ນີ້ແມ່ນຕົວເລກຄ່າໃຊ້ຈ່າຍທີ່ມີຄວາມ ໝາຍ ທີ່ສຸດໃນເວລາທີ່ຊຸກດັນອົງປະກອບທີ່ *ບໍ່ໄດ້* ຢູ່ໃນຮູບແບບຈັດລຽງໃດ ໜຶ່ງ.
    ///
    /// ຄວາມສັບສົນຂອງເວລາຈະເສື່ອມໂຊມຖ້າຫາກວ່າສ່ວນປະກອບຕ່າງໆຖືກກົດຂື້ນເປັນສ່ວນໃຫຍ່ຂື້ນ.
    /// ໃນກໍລະນີທີ່ຮ້າຍແຮງທີ່ສຸດ, ບັນດາອົງປະກອບຖືກຍູ້ໃນການຈັດລຽງຕາມ ລຳ ດັບທີ່ສູງຂຶ້ນແລະຄ່າໃຊ້ຈ່າຍທີ່ຖືກ ຊຳ ລະຕໍ່ການຊຸກຍູ້ແມ່ນ *O*(log(*n*)) ຕໍ່ກັບ heap ທີ່ມີສ່ວນປະກອບ *n*.
    ///
    /// ຄ່າໃຊ້ຈ່າຍໃນກໍລະນີທີ່ບໍ່ດີທີ່ສຸດຂອງການໂທດຽວ *ກັບ `push` ແມ່ນ* O *(* n *).ກໍລະນີທີ່ຮ້າຍແຮງທີ່ສຸດແມ່ນເກີດຂື້ນເມື່ອຄວາມສາມາດ ໝົດ ກຳ ລັງແລະຕ້ອງການຂະ ໜາດ.
    /// ຄ່າໃຊ້ຈ່າຍໃນການປັບຂະ ໜາດ ໄດ້ຖືກຄິດໄລ່ໃນຕົວເລກທີ່ຜ່ານມາ.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // ຄວາມປອດໄພ: ຍ້ອນວ່າພວກເຮົາຍູ້ລາຍການ ໃໝ່ ມັນ ໝາຍ ຄວາມວ່າ
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// ບໍລິໂພກ `BinaryHeap` ແລະສົ່ງຄືນ vector ໃນການຈັດຮຽງລໍາດັບ (ascending).
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // ຄວາມປອດໄພ: `end` ໄປຈາກ `self.len() - 1` ຫາ 1 (ທັງສອງລວມ),
            //  ສະນັ້ນມັນເປັນດັດສະນີທີ່ຖືກຕ້ອງໃນການເຂົ້າເຖິງ.
            //  ມັນປອດໄພທີ່ຈະເຂົ້າເຖິງດັດສະນີ 0 (ເຊັ່ນ `ptr`), ເພາະວ່າ
            //  1 <=ສິ້ນສຸດ <self.len(), ຊຶ່ງ ໝາຍ ຄວາມວ່າ self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // ຄວາມປອດໄພ: `end` ໄປຈາກ `self.len() - 1` ຫາ 1 (ທັງສອງລວມ) ດັ່ງນັ້ນ:
            //  0 <1 <=ສິ້ນສຸດ <= self.len(), 1 <self.len() ເຊິ່ງ ໝາຍ ເຖິງ 0 <ສິ້ນສຸດແລະສິ້ນສຸດ <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // ການຈັດຕັ້ງປະຕິບັດຂອງ sift_up ແລະ sift_down ໃຊ້ທ່ອນໄມ້ທີ່ບໍ່ປອດໄພເພື່ອຍ້າຍອົງປະກອບອອກຈາກ vector (ປະໄວ້ທາງຫລັງຂອງຂຸມ), ປ່ຽນທິດທາງອື່ນແລະຍ້າຍອົງປະກອບທີ່ຖືກຍ້າຍອອກໄປໃນ vector ທີ່ຈຸດສຸດທ້າຍຂອງຂຸມ.
    //
    // ປະເພດ `Hole` ຖືກ ນຳ ໃຊ້ເພື່ອເປັນຕົວແທນຂອງສິ່ງນີ້, ແລະໃຫ້ແນ່ໃຈວ່າຂຸມແມ່ນເຕັມໄປໃນຕອນທ້າຍຂອງຂອບເຂດຂອງມັນ, ແມ່ນແຕ່ຢູ່ໃນ panic.
    // ການໃຊ້ຂຸມແມ່ນຊ່ວຍຫຼຸດຜ່ອນປັດໃຈຄົງທີ່ເມື່ອທຽບກັບການໃຊ້ແລກປ່ຽນ, ເຊິ່ງກ່ຽວຂ້ອງກັບການຍ້າຍຫລາຍເທົ່າສອງເທົ່າ.
    //
    //
    //
    //

    /// # Safety
    ///
    /// ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // ເອົາມູນຄ່າທີ່ `pos` ອອກແລະສ້າງຂຸມ.
        // ຄວາມປອດໄພ: ຜູ້ຮັບປະກັນໂທໄດ້ຮັບປະກັນວ່າ pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // ຄວາມປອດໄພ: hole.pos()> ເລີ່ມຕົ້ນ>=0, ເຊິ່ງ ໝາຍ ຄວາມວ່າ hole.pos()> 0
            //  ແລະດັ່ງນັ້ນ hole.pos(), 1 ບໍ່ສາມາດແລ່ນໄດ້.
            //  ນີ້ຮັບປະກັນວ່າພໍ່ແມ່ <hole.pos() ສະນັ້ນມັນແມ່ນດັດສະນີທີ່ຖືກຕ້ອງແລະຍັງ!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // ຄວາມປອດໄພ: ຄືກັນກັບຂ້າງເທິງ
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// ເອົາອົງປະກອບທີ່ `pos` ແລະຍ້າຍມັນລົງຢູ່ໃນກະຕ່າ, ໃນຂະນະທີ່ລູກຂອງມັນໃຫຍ່ກວ່າ.
    ///
    ///
    /// # Safety
    ///
    /// ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // ຄວາມປອດໄພ: ຜູ້ໂທໄດ້ຮັບປະກັນວ່າ pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop invariant: ເດັກ==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // ປຽບທຽບກັບເດັກນ້ອຍທີ່ໃຫຍ່ກວ່າສອງຄົນທີ່ປອດໄພ: ເດັກ <ສິ້ນສຸດ, 1 <self.len() ແລະເດັກ + 1 <ທ້າຍ <= self.len(), ດັ່ງນັ້ນພວກມັນແມ່ນດັດສະນີທີ່ຖືກຕ້ອງ.
            //
            //  ເດັກ==2 *hole.pos() + 1!= hole.pos() ແລະເດັກ + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 ຫຼື 2* hole.pos() + 2 ສາມາດລົ້ນຖ້າ T ແມ່ນ ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ຖ້າພວກເຮົາມີຄວາມເປັນລະບຽບຮຽບຮ້ອຍແລ້ວ, ຢຸດ.
            // ຄວາມປອດໄພ: ເດັກປະຈຸບັນບໍ່ວ່າເດັກນ້ອຍຫຼືເດັກອາຍຸ +1
            //  ພວກເຮົາໄດ້ພິສູດແລ້ວວ່າທັງສອງແມ່ນ <self.len() ແລະ!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // ຄວາມປອດໄພ: ຄືກັນກັບຂ້າງເທິງ.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // ຄວາມປອດໄພ: &&ວົງຈອນສັ້ນ, ໝາຍ ຄວາມວ່າຢູ່ໃນ
        //  ເງື່ອນໄຂທີ່ສອງມັນເປັນຄວາມຈິງແລ້ວທີ່ເດັກນ້ອຍ==ສິ້ນສຸດ, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // ຄວາມປອດໄພ: ເດັກໄດ້ຖືກພິສູດແລ້ວວ່າເປັນດັດສະນີທີ່ຖືກຕ້ອງແລະ
            //  ເດັກ==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // ຄວາມປອດໄພ: pos <len ແມ່ນຮັບປະກັນໂດຍຜູ້ໂທແລະ
        //  len ແນ່ນອນ= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// ເອົາອົງປະກອບທີ່ `pos` ແລະຍ້າຍມັນລົງທຸກບ່ອນ, ຫຼັງຈາກນັ້ນຍົກມັນຂຶ້ນສູ່ ຕຳ ແໜ່ງ ຂອງມັນ.
    ///
    ///
    /// Note: ນີ້ຈະໄວກ່ວາເມື່ອອົງປະກອບທີ່ຮູ້ວ່າມີຂະ ໜາດ ໃຫຍ່/ຄວນຈະຢູ່ໃກ້ທາງລຸ່ມ.
    ///
    /// # Safety
    ///
    /// ຜູ້ໂທຕ້ອງຮັບປະກັນວ່າ `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // ຄວາມປອດໄພ: ຜູ້ຮັບປະກັນໂທໄດ້ຮັບປະກັນວ່າ pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Loop invariant: ເດັກ==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // ຄວາມປອດໄພ: ເດັກ <ສິ້ນສຸດ, 1 <self.len() ແລະ
            //  ເດັກ + 1 <ທ້າຍ <= self.len(), ດັ່ງນັ້ນພວກມັນແມ່ນດັດສະນີທີ່ຖືກຕ້ອງ.
            //  ເດັກ==2 *hole.pos() + 1!= hole.pos() ແລະເດັກ + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 ຫຼື 2* hole.pos() + 2 ສາມາດລົ້ນຖ້າ T ແມ່ນ ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ຄວາມປອດໄພ: ຄືກັນກັບຂ້າງເທິງ
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // ຄວາມປອດໄພ: ເດັກ==ສິ້ນສຸດ, 1 <self.len(), ສະນັ້ນມັນແມ່ນດັດສະນີທີ່ຖືກຕ້ອງ
            //  ແລະເດັກ==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // ຄວາມປອດໄພ: pos ແມ່ນ ຕຳ ແໜ່ງ ໃນຂຸມແລະໄດ້ພິສູດແລ້ວ
        //  ເປັນດັດສະນີທີ່ຖືກຕ້ອງ.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // ຄວາມປອດໄພ: n ເລີ່ມຕົ້ນຈາກ self.len()/2 ແລະຫຼຸດລົງເປັນ 0.
            //  ກໍລະນີດຽວເທົ່ານັ້ນເມື່ອ! (n <self.len()) ແມ່ນຖ້າ self.len() ==0, ແຕ່ມັນຖືກປະຕິເສດຕາມເງື່ອນໄຂຂອງ loop.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// ຍ້າຍອົງປະກອບທັງ ໝົດ ຂອງ `other` ລົງເປັນ `self`, ເຮັດໃຫ້ `other` ຫວ່າງເປົ່າ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` ດໍາເນີນການປະຕິບັດງານ O(len1 + len2) ແລະການປຽບທຽບປະມານ 2 *(len1 + len2) ໃນກໍລະນີທີ່ຮ້າຍແຮງທີ່ສຸດໃນຂະນະທີ່ `extend` ດໍາເນີນການປະຕິບັດງານ O(len2* log(len1)) ແລະປະມານ 1 *len2* log_2(len1) ປຽບທຽບໃນກໍລະນີຮ້າຍແຮງທີ່ສຸດ, ສົມມຸດວ່າ len1>= len2.
        // ສຳ ລັບຫິ້ວຂະ ໜາດ ໃຫຍ່, ຈຸດຂ້າມຜ່ານບໍ່ໄດ້ຕິດຕາມເຫດຜົນນີ້ແລະຖືກ ກຳ ນົດຢ່າງແທ້ຈິງ.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// ສົ່ງຄືນຕົວປັບທີ່ດຶງເອົາອົງປະກອບໃນ ລຳ ດັບ heap.
    /// ອົງປະກອບທີ່ດຶງມາໄດ້ຖືກເອົາອອກຈາກ heap ເດີມ.
    /// ສ່ວນປະກອບທີ່ຍັງເຫຼືອຈະຖືກຖອດອອກໄປຕາມ ລຳ ດັບ heap.
    ///
    /// Note:
    /// * `.drain_sorted()` ແມ່ນ *O*(*n*\*log(* n*)); ຊ້າກວ່າ `.drain()` ຫຼາຍ.
    ///   ທ່ານຄວນໃຊ້ແບບສຸດທ້າຍ ສຳ ລັບກໍລະນີຫຼາຍທີ່ສຸດ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // ກຳ ຈັດອົງປະກອບທັງ ໝົດ ອອກເປັນ ລຳ ດັບ
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// ຮັກສາພຽງແຕ່ອົງປະກອບທີ່ລະບຸໄວ້ໂດຍຜູ້ຄາດຄະເນ.
    ///
    /// ໃນຄໍາສັບຕ່າງໆອື່ນໆ, ເອົາທັງຫມົດອົງປະກອບ `e` ເຊັ່ນວ່າ `f(&e)` ກັບຄືນ `false`.
    /// ບັນດາອົງປະກອບດັ່ງກ່າວແມ່ນໄດ້ໄປຢ້ຽມຢາມໃນແບບບໍ່ມີການຈັດ (ແລະບໍ່ໄດ້ລະບຸ).
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // ພຽງແຕ່ຮັກສາຕົວເລກໄວ້
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// ສົ່ງຄືນເຄື່ອງ ໝາຍ ການຢ້ຽມຢາມມູນຄ່າທັງ ໝົດ ໃນ vector ທີ່ຢູ່ໃຕ້ພື້ນຖານ, ຕາມ ລຳ ດັບທີ່ຕົນເອງມັກ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // ພິມເລກທີ 1, 2, 3, 4 ເປັນລະບຽບຮຽບຮ້ອຍ
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// ສົ່ງຄືນຕົວປັບທີ່ດຶງເອົາອົງປະກອບໃນ ລຳ ດັບ heap.
    /// ວິທີການນີ້ໃຊ້ຕົ້ນກະໂພກ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// ສົ່ງຄືນສິນຄ້າທີ່ຍິ່ງໃຫຍ່ທີ່ສຸດໃນຖານຂໍ້ມູນສອງຊ່ອງ, ຫລື `None` ຖ້າມັນຫວ່າງຢູ່.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # ຄວາມສັບສົນເວລາ
    ///
    /// ຄ່າໃຊ້ຈ່າຍແມ່ນ *O*(1) ໃນກໍລະນີທີ່ບໍ່ດີທີ່ສຸດ.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// ສົ່ງຄືນ ຈຳ ນວນຂອງສ່ວນປະກອບທີ່ heap ຄູ່ສາມາດຖືໄດ້ໂດຍບໍ່ ຈຳ ເປັນຕ້ອງແບ່ງປັນ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// ສະຫງວນຄວາມອາດສາມາດຕ່ ຳ ສຸດ ສຳ ລັບອົງປະກອບເພີ່ມເຕີມ `additional` ທີ່ຈະຖືກໃສ່ເຂົ້າໃນ `BinaryHeap` ທີ່ໃຫ້.
    /// ບໍ່ມີຫຍັງເຮັດຖ້າຄວາມສາມາດພຽງພໍແລ້ວ.
    ///
    /// ຈົ່ງສັງເກດວ່າຜູ້ຈັດສັນອາດຈະໃຫ້ຫ້ອງເກັບຫຼາຍກວ່າທີ່ມັນຮ້ອງຂໍ.
    /// ສະນັ້ນຄວາມສາມາດບໍ່ສາມາດເພິ່ງພາໄດ້ຢ່າງ ໜ້ອຍ ທີ່ສຸດ.
    /// ມັກ [`reserve`] ຖ້າມີຄວາມຄາດຫວັງຂອງ future.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຄວາມສາມາດ ໃໝ່ ລົ້ນ `usize`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// ສະຫງວນຄວາມອາດສາມາດໃຫ້ຢ່າງ ໜ້ອຍ `additional` ອົງປະກອບເພີ່ມເຕີມທີ່ຈະເອົາເຂົ້າໃນ `BinaryHeap`.
    /// ການເກັບ ກຳ ຂໍ້ມູນດັ່ງກ່າວອາດຈະສະຫງວນເນື້ອທີ່ຫຼາຍຂື້ນເພື່ອຫລີກລ້ຽງການຈັດສັນທີ່ຢູ່ເລື້ອຍໆ.
    ///
    /// # Panics
    ///
    /// Panics ຖ້າຄວາມສາມາດ ໃໝ່ ລົ້ນ `usize`.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// ຍົກເລີກຄວາມສາມາດເພີ່ມເຕີມໃຫ້ຫຼາຍເທົ່າທີ່ເປັນໄປໄດ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// ຍົກເລີກຄວາມອາດສາມາດທີ່ມີຂອບນ້ອຍລົງ.
    ///
    /// ຄວາມອາດສາມາດຈະຍັງຄົງຢູ່ຢ່າງຫນ້ອຍທັງຄວາມຍາວແລະມູນຄ່າການສະ ໜອງ.
    ///
    ///
    /// ຖ້າຄວາມສາມາດໃນປະຈຸບັນຕ່ ຳ ກ່ວາຂີດ ຈຳ ກັດຕ່ ຳ, ນີ້ແມ່ນສິ່ງທີ່ບໍ່ມີ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// ບໍລິໂພກ `BinaryHeap` ແລະສົ່ງຄືນ vector ທີ່ຕິດພັນໃນການສັ່ງຊື້ທີ່ບໍ່ເປັນລະບຽບ.
    ///
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // ຈະພິມອອກເປັນບາງ ລຳ ດັບ
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// ສົ່ງຄືນຄວາມຍາວຂອງ heap ຄູ່.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// ກວດເບິ່ງວ່າ heap ໄບນາລີແມ່ນຫວ່າງເປົ່າຫລືບໍ່.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ກຳ ຈັດຂີ້ເຫຍື້ອຂອງຖານສອງ, ສົ່ງຄືນຕົວເກຍຂື້ນເທິງອົງປະກອບທີ່ຖືກຖອດອອກ.
    ///
    /// ອົງປະກອບຖືກໂຍກຍ້າຍອອກໃນລະບຽບທີ່ຕົນເອງມັກ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// ເອົາລົງທຸກລາຍການຈາກ heap ຖານສອງ.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// ຮູເປັນຕົວແທນຂອງຂຸມໃນຕົວຄືກັນ, ດັດຊະນີໂດຍບໍ່ມີມູນຄ່າທີ່ຖືກຕ້ອງ (ເພາະວ່າມັນຖືກຍ້າຍຈາກຫຼືເຮັດຊ້ ຳ).
///
/// ໃນການຫຼຸດລົງ, `Hole` ຈະຟື້ນຟູການຕັດໂດຍການຕື່ມຕໍາແຫນ່ງຂອງຂຸມທີ່ມີມູນຄ່າທີ່ຖືກໂຍກຍ້າຍໃນເບື້ອງຕົ້ນ.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// ສ້າງ `Hole` ໃໝ່ ທີ່ດັດສະນີ `pos`.
    ///
    /// ບໍ່ປອດໄພເພາະ pos ຕ້ອງຢູ່ໃນສ່ວນຂອງຂໍ້ມູນ.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pos ຄວນຢູ່ພາຍໃນຊອຍ
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// ກັບຄືນການອ້າງອີງໃສ່ອົງປະກອບທີ່ຖືກຍ້າຍອອກ.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// ສົ່ງຂໍ້ມູນອ້າງອີງໃສ່ອົງປະກອບທີ່ `index`.
    ///
    /// ບໍ່ປອດໄພເພາະວ່າດັດສະນີຕ້ອງຢູ່ໃນສ່ວນຂອງຂໍ້ມູນແລະບໍ່ເທົ່າກັບ pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// ຍ້າຍຂຸມໄປບ່ອນ ໃໝ່
    ///
    /// ບໍ່ປອດໄພເພາະວ່າດັດສະນີຕ້ອງຢູ່ໃນສ່ວນຂອງຂໍ້ມູນແລະບໍ່ເທົ່າກັບ pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // ຕື່ມຂໍ້ມູນໃສ່ຂຸມອີກເທື່ອຫນຶ່ງ
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// ຕົວລະບາຍຄວາມຖີ່ຫຼາຍກວ່າອົງປະກອບຂອງ `BinaryHeap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍ [`BinaryHeap::iter()`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) ເອົາອອກໃນເງື່ອນໄຂຂອງ `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// ເປັນເຈົ້າຂອງຕົວຕັ້ງໂຕະ ເໜືອ ອົງປະກອບຂອງ `BinaryHeap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍ [`BinaryHeap::into_iter()`] (ສະ ໜອງ ໂດຍ `IntoIterator` trait).
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// ຕົວລະບາຍນ້ ຳ ທີ່ໄຫຼຜ່ານອົງປະກອບຂອງ `BinaryHeap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍ [`BinaryHeap::drain()`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// ຕົວລະບາຍນ້ ຳ ທີ່ໄຫຼຜ່ານອົງປະກອບຂອງ `BinaryHeap`.
///
/// `struct` ນີ້ຖືກສ້າງຂື້ນໂດຍ [`BinaryHeap::drain_sorted()`].
/// ເບິ່ງເອກະສານຂອງມັນ ສຳ ລັບເພີ່ມເຕີມ.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// ກຳ ຈັດບັນດາ heap ອອກຕາມ ລຳ ດັບ heap.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// ແປງ `Vec<T>` ເປັນ `BinaryHeap<T>`.
    ///
    /// ການປ່ຽນໃຈເຫລື້ອມໃສນີ້ເກີດຂື້ນໃນສະຖານທີ່, ແລະມີຄວາມສັບສົນເວລາ *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// ແປງ `BinaryHeap<T>` ເປັນ `Vec<T>`.
    ///
    /// ການປ່ຽນໃຈເຫລື້ອມໃສນີ້ຮຽກຮ້ອງໃຫ້ບໍ່ມີການເຄື່ອນຍ້າຍຂໍ້ມູນຫລືການຈັດສັນ, ແລະມີຄວາມສັບສົນທີ່ໃຊ້ເວລາຄົງທີ່.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ສ້າງຕົວຊີ້ວັດທີ່ມີການຊົມໃຊ້, ນັ້ນແມ່ນສິ່ງ ໜຶ່ງ ທີ່ຍ້າຍມູນຄ່າແຕ່ລະອັນອອກຈາກຮ່ອງຖານສອງ.
    /// ບໍ່ສາມາດໃຊ້ຖານຂໍ້ມູນສອງເມັດໄດ້ຫຼັງຈາກທີ່ທ່ານໂທຫານີ້.
    ///
    /// # Examples
    ///
    /// ການ ນຳ ໃຊ້ຂັ້ນພື້ນຖານ:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // ພິມເລກທີ 1, 2, 3, 4 ເປັນລະບຽບຮຽບຮ້ອຍ
    /// for x in heap.into_iter() {
    ///     // x ມີປະເພດ i32, ບໍ່ແມ່ນ &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}