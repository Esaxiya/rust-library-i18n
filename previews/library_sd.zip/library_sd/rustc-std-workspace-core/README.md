# `rustc-std-workspace-core` crate

هي crate هڪ چمڪندڙ ۽ خالي crate آهي ، جيڪو صرف `libcore` تي ڀاڙيندو آهي ۽ ان جي سڀني مواد جي ٻيهر برآمد ڪندو آهي.
crate معياري معياري لائبريري کي بااختيار بڻائڻ جو مرڪز آهي.

Crates تي crates.io ته معياري لائبريري `rustc-std-workspace-core` تي انحصار ڪرڻ جي ضرورت آهي crate crates.io کان ، جيڪو خالي آهي.

اسان هن ذخيرو ۾ crate کي اوور ويڊ ڪرڻ لاءِ `[patch]` استعمال ڪريو ٿا.
نتيجي طور ، crates.io تي crates انحصار edge کي `libcore` تي آڻيندو ، ھن مخزن ۾ بيان ڪيل نسخو.
انهي کي يقيني بڻائڻ گهرجي تمام انحصار جا ڪنارا Cargo کي يقيني بڻائڻ لاءِ crates ٺاهي ٿو.

نوٽ ڪريو 0crates تي crates.io انهي انحصار ڪرڻ جي ضرورت آهي crate نالي `core` هر شي کي صحيح طريقي سان ڪم ڪرڻ لاءِ.اهي ڪرڻ لاء اهي استعمال ڪري سگھن ٿا:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

`package` ڪيٻي جي استعمال جي ذريعي ، crate کي `core` جو نالو ڏنو ويو آهي ، مطلب ته اهو نظر ايندو

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

جڏهن Cargo ترتيب ڏيڻ واري کي استعمال ڪري ٿو ، مرتب ڪندڙ انجيل ٿيل `extern crate core` هدايتڪار کي مطمئن ڪري ٿو.




