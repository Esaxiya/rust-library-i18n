#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) ڏسو.
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) ڏسو.
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) ڏسو.
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) ڏسو.
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) ڏسو.
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) ڏسو.
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// ڪيش لائن ڪو جيڪو ڏنل `rw` ۽ `locality` استعمال ڪري `p` پتي تي مشتمل آهي.
///
/// `rw` ھڪڙي هجڻ گھرجي:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): پريفيڪٽ پڙهڻ لاءِ تيار ڪري رهيو آهي.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): اڳڪٿي هڪ لکڻ جي تياري ڪري رهيو آهي.
///
/// `locality` ھڪڙي هجڻ گھرجي:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): وهڪرو يا غير عارضي اڳڪٿي ، ڊيٽا لاءِ جيڪا صرف هڪ ڀيرو استعمال ٿئي ٿي.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): سطح 3 ڪيش ۾ رسايو.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): سطح 2 ڪيش ۾ رسايو.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): سطح 1 ڪيش ۾ رسايو.
///
/// اڳڪٿي ياداشت جي هدايتن کي ياداشت واري نظام ڏانهن اشارو ڪن ٿا ته ياداشت هڪ مخصوص ايڊريس مان رسائي ممڪن آهي ويجهي future ۾ واقع ٿيندي.
/// ياداشت واري نظام انهن ڪارناما ذريعي ڪري سگھي ٿو جيڪي ياداشت جي رسائي کي تيز ڪرڻ جي توقع ڪن ٿا جڏهن اهي ٿئي ٿي ، جهڙوڪ مخصوص ايڊريس کي هڪ يا وڌيڪ ڪيچس ۾ لوڊ ڪرڻ.
///
/// ڇاڪاڻ ته اهي نشانيون صرف اشارا آهن ، اهو هڪ مخصوص سي پي يو لاءِ صحيح آهي ته ڪنهن يا سڀ اڳڀرائي هدايتون NOP وانگر سمجھي.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // اسان استعمال ڪريون ٿا `llvm.prefetch` instrinsic سان `cache type` =1 (ڊيٽا ڪيش)
    // `rw` ۽ ايڪس سيڪس فنڪشن جي پيٽرولن تي ٻڌل آهن.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}