use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // اسان جا `#[assert_instr]` تشريح ٻڌائڻ لاءِ استعمال ڪندا هئا ته سڀ سمڊ intrinsics انهن جي ڪوڊگن کي جانچڻ لاءِ موجود آهن ، ڇاڪاڻ ته ڪجهه وڌيڪ `-Ctarget-feature=+unimplemented-simd128` جي پويان جڙيل آهن جن کي هاڻي `#[target_feature]` ۾ ڪو به برابر ناهي.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}