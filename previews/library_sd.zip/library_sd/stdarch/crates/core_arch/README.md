`core::arch` - Rust جي بنيادي لائبريري آرڪيٽيڪچر خاص نوعيت جون
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` ماڊل آرڪيالاجيڪل-انحصار واري داخلي نظام کي لاڳو ڪندو آهي (مثال طور سمڊ).

# Usage 

`core::arch` `libcore` جي حصي جي طور تي دستياب آهي ۽ اهو `libstd` پاران ٻيهر برآمد ڪيو ويو آهي.هن crate ذريعي `core::arch` يا `std::arch` ذريعي استعمال ڪرڻ کي ترجيح ڏيو.
`feature(stdsimd)` ذريعي رات جو Rust ۾ غير مستحڪم خاصيتون گهڻو ڪري موجود آهن.

هن crate ذريعي `core::arch` استعمال ڪرڻ رات جي Rust جي ضرورت آهي ، ۽ اهو اڪثر ڪري سگھي ٿو (۽ ڪندو) ڀڃي ٿو.صرف ڪيسن جو توهان کي هن crate ذريعي استعمال ڪرڻ تي ڌيان ڏيڻ گهرجي:

* جيڪڏهن توهان کي `core::arch` پاڻ کي ٻيهر مرتب ڪرڻ جي ضرورت آهي ، مثال طور ، خاص هدف-خاصيتن سان جيڪي `libcore`/`libstd` لاءِ فعال نه آهن.
Note: جيڪڏهن توهان کي غير معياري حدف لاءِ ٻيهر مرتب ڪرڻ جي ضرورت آهي ، مھرباني ڪري `xargo` استعمال ڪرڻ کي ترجيح ڏيو ۽ crate استعمال ڪرڻ بدران ان کي مناسب طور تي `libcore`/`libstd` کي ٻيهر مرتب ڪريو.
  
* ڪجھ خاصيتون استعمال ڪندي جيڪي شايد غير موجود Rust خاصيتن جي پويان دستياب ناھن.اسان انهن کي گهٽ ۾ گهٽ رکڻ جي ڪوشش ڪيون.
جيڪڏهن توهان کي انهن مان ڪجهه خاصيتن کي استعمال ڪرڻ جي ضرورت آهي ، مهرباني ڪري هڪ مسئلو کوليو ته جيئن اسان انهن کي رات جي Rust ۾ لڳائي سگهون ۽ توهان انهن کي اتان کان استعمال ڪري سگهو.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` بنيادي طور تي MIT لائسنس ۽ Apache لائسنس (نسخو 2.0) ٻنهي شرطن جي تحت ورهايو ويو آهي ، مختلف حصا BSD وانگر لائسنسن جي حصي سان ڏنل آهن.

تفصيل لاءِ ڏسو LICENSE-APACHE ، ۽ LICENSE-MIT ڏسو.

# Contribution

جيستائين توهان ٻي صورت ۾ ظاهري طور تي بيان نٿا ڪريو ، توهان طرفان ايڪس آرڪس ۾ شموليت لاءِ ارادي طور تي ڪوبه حصو پيش ڪيو ويو ، جئين Apache-2.0 لائسنس ۾ وضاحت ڪئي وئي آهي ، مٿي ڏنل ڊبل لائسنس ڪيو ويندو ، اضافي شرطن ۽ شرطن کانسواءِ.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












