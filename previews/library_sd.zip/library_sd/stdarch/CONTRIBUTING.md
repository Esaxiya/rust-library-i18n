# حصو ڏيڻ ۾ حصو

`stdarch` crate مدد قبول ڪرڻ کان وڌيڪ آھي.پهرين توهان ممڪن طور تي مخزن جي چڪاس ڪرڻ چاهيندا ۽ پڪ ڪندا ته ٽيسٽ توهان لاءِ گذري آهي.

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

جتي `<your-target-arch>` ٽارگيٽ ٽيبل آهي جيڪو `rustup` پاران استعمال ڪيو ويو آهي ، مثال طور `x86_x64-unknown-linux-gnu` (اڳين `nightly-` يا ساڳي وانگر بغير).
اهو به ياد رکجو ته هي مخزن جي Rust واري رات وارو چينل جي ضرورت آهي!
مٿيان ٽيسٽ حقيقت ۾ رات جي rust کي توهان جي سسٽم تي ڊفالٽ ڪرڻ جي ضرورت آهي ، سيٽ ڪرڻ لاءِ `rustup default nightly` (۽ `rustup default stable` استعمال ڪرڻ لاءِ) سيٽ ڪرڻ لاءِ.

جيڪڏهن مٿئين قدم مان ڪو ڪم نٿو ڪري ، [please let us know][new]!

اڳيون توھان مدد ڪرڻ لاءِ [find an issue][issues] ڪري سگھوٿا ، اسان ڪجھ چونڊيو آھي [`help wanted`][help] ۽ [`impl-period`][impl] ٽيگ سان جيڪي خاص طور تي ڪجھ مدد استعمال ڪري سگھن ٿا. 
توهان شايد [#40][vendor] ۾ تمام گهڻو دلچسپي وٺندي ، x86 تي سڀني وينڊرز جي داخلا لاڳو ڪندي.انهي مسئلي کي ڪجهه بهتر اشارو مليو آهي ته ڪٿي شروع ڪجي!

جيڪڏهن توهان عام سوالن کي [join us on gitter][gitter] ڏانهن آزاد محسوس ڪيو ۽ چوڌاري پڇو!withاڻ ڏيو ته سوالن سانBurntSushi ياalexcrichton پنگ ڪريو.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# stdarch intrinsics لاءِ مثال ڪيئن لکندا

ڪجھ خاصيتون آھن جيڪي لازمي طور تي ڪم ڪرڻ لاءِ ڏنل اندروني کي فعال ڪرڻ ضروري آھن ۽ مثال صرف `cargo test --doc` کي ھلائڻ ضروري آھي جڏھن سي پي يو جي طرفان ان جي خاصيت ھجي.

نتيجي طور ، `rustdoc` پاران ٺاهيل ڊفالٽ X00 ڪم نه ڪندو (اڪثر ڪيسن ۾)
هيٺ ڏنل گائيڊ طور استعمال ڪرڻ تي غور ڪريو انهي کي يقيني بڻائڻ لاءِ توهان جو مثال توقع طور ڪم ڪري رهيو آهي.

```rust
/// # // اسان کي ضرورت آھي cfg_target_feature کي يقيني بڻائڻ لاءِ ته مثال صرف آھي
/// # // `cargo test --doc` هلائيندا جڏهن سي پي يو خاصيت کي سپورٽ ڪندو
/// # #![feature(cfg_target_feature)]
/// # // اسان کي ڪم ڪرڻ جي لاءِ اندرين ڀاڙي جي ضرورت گهرجي
/// # #![feature(target_feature)]
/// #
/// # // رسٽ ڊيڊ ڊفالٽ طور `extern crate stdarch` استعمال ڪندو آھي ، پر اسان کي ضرورت آھي
/// # // `#[macro_use]`
/// # # [ميڪرو_وائس] ٻاهرين crate وارڊ ؛
/// #
/// # // حقيقي بنيادي فنڪشن
/// # فني ايڪس ويڪس {
/// #     // صرف ايڪس هليا جيڪڏهن انهي جي حمايت ڪئي وئي
/// #     جيڪڏهن cfg_feature_enabled! ("<target feature>"){
/// #         // `worker` فنڪشن ٺاھيو جيڪو صرف هلندو آھي جيڪڏھن ٽارگيٽ جي خاصيت
/// #         // تعاون ڪئي وئي ۽ انهي کي يقيني بڻائي ٿو ته `target_feature` توهان جي ڪم ڪندڙ لاءِ چالو آهي
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         غير محفوظ fn worker() {
/// // پنهنجو مثال هتي لکو.خصوصي خاص دخل هتي ڪم ڪندو!چريو وڃ!
///
/// #         }
///
/// #         غير محفوظ { worker(); }
/// #     }
/// # }
```

جيڪڏهن مٿين ڪجهه نحو کان واقف نه ڏسجن ته ، [Rust Book] جو [Documentation as tests] سيڪشن انهن نموني سان `rustdoc` نحو کي واضح ڪري ٿو.
هميشه وانگر ، [join us on gitter][gitter] ڏانهن آزاد محسوس ٿيو ۽ اسان کان پڇو جيڪڏهن توهان کي ڪجهه نقصان پهچايو ، ۽ ايڪس ايڪس اين ايڪس جي دستاويزن کي بهتر ڪرڻ ۾ مدد لاءِ توهان جي مهرباني!

# متبادل جاچ واري هدايتون

اهو عام طور تي سفارش ڪئي وئي آهي ته توهان ٽيسٽ هلائڻ جي لاءِ `ci/run.sh` استعمال ڪريو ٿا.
تنهن هوندي اهو شايد توهان جي ڪم نه اچي ، مثال طور جيڪڏهن توهان Windows تي آهيو.

انهي صورت ۾ توهان ڪوڊ نسل کي جانچڻ لاءِ `cargo +nightly test` ۽ `cargo +nightly test --release -p core_arch` هلائڻ واپس پوئتي ٿي سگهو ٿا.
ياد رکو ته هي رات وارا ٽولين کي نصب ڪرڻ جي ضرورت آهي ۽ ايڪس 100 ايڪس جي لاءِ توهان جي ٽارگيٽ ٽرپل ۽ ان جي سي پي يو بابت toاڻڻ لاءِ.
خاص طور تي توهان کي `TARGET` ماحول متغير مقرر ڪرڻ جي ضرورت آهي جيئن توهان `ci/run.sh` ڪندا.
ان کان علاوه توهان کي نشانو بڻائڻ جي خصوصيتن جي نشاندهي ڪرڻ لاءِ `RUSTCFLAGS` (`C` جي ضرورت) جوڙڻ جي ضرورت آهي ، مثال طور `RUSTCFLAGS="-C -target-features=+avx2"`.
توهان سيٽ ڪري سگهو ٿا `-C -target-cpu=native` جيڪڏهن توهان "just" پنهنجي موجوده سي پي يو جي خلاف ترقي ڪري رهيا آهيو.

خبردار ڪيو وڃي ته جڏهن توهان اهي متبادل هدايتون استعمال ڪريو ، [things may go less smoothly than they would with `ci/run.sh`][ci-run-good] ، مثال طور
هدايت وارا نسل جا امتحان ناڪام ٿي سگھن ٿا ڇاڪاڻ ته انهن کي ختم ڪرڻ وارو هنن کي مختلف طرح سڏيو آهي ، مثال طور
اهو شايد `vaesenc` بدران `aesenc` هدايتون ٺاهي سگھي ٿو ان جي باوجود انهن جي ساڳئي رويي.
اهي هدايتون عام طور تي گهٽ ٽيسٽ واريون آپريشنون ڪنديون آهن ، تنهن ڪري تعجب نه ٿيو ته جڏهن توهان آخرڪار درخواست گهرڻ تي ڪجهه غلطيون هتي بيهي جاچ لاءِ نه ٿي ڏيکاري.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






