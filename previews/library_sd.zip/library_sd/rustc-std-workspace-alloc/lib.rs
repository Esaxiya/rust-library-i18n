#![feature(no_core)]
#![no_core]

// ڏسو rustc-std-workpace-core انهي جي لاءِ crate ڇو گهرجي.

// لبولاڪو ۾ مختص ماڊل سان تڪرار کان بچڻ لاءِ crate کي وري تبديل ڪريو.
extern crate alloc as foo;

pub use foo::*;