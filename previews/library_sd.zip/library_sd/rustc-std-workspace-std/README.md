# `rustc-std-workspace-std` crate

`rustc-std-workspace-core` crate لاءِ دستاويز ڏسو.