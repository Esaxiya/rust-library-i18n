use crate::iter::FromIterator;

/// ايٽرريٽر مان سڀ يونٽ جون شيون ختم ڪري ڇڏيون وينديون.
///
/// اهو وڌيڪ مفيد آهي جڏهن اعلي سطحي بدحالي سان گڏيل ، ايڪس آرڪس گڏ ڪرڻ وانگر جتي توهان صرف غلطين جي پرواهه ڪريو ٿا.
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}