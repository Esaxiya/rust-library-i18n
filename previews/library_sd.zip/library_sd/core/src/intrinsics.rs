//! مرتب ڪندڙ اندروني.
//!
//! ساڳئي تعريف `compiler/rustc_codegen_llvm/src/intrinsic.rs` ۾ آهن.
//! ساڳئي ڪنٽرول لاڳو ڪرڻ `compiler/rustc_mir/src/interpret/intrinsics.rs` ۾ آهن
//!
//! # مسلسل داخلا
//!
//! Note: داني جي استحڪام ۾ ڪنهن به تبديلي ٻولي ٽيم سان بحث ڪرڻ گهرجي.
//! ھن ۾ استحڪام جي استحڪام ۾ تبديليون شامل آھن.
//!
//! مرتب وقت تي اندروني استعمال لائق بڻائڻ لاءِ ، ايڪس کي `compiler/rustc_mir/src/interpret/intrinsics.rs` کان `compiler/rustc_mir/src/interpret/intrinsics.rs` تي نفاذ کي نقل ڪرڻ جي ضرورت آهي ۽ `#[rustc_const_unstable(feature = "foo", issue = "01234")]` کي اندروني ۾ شامل ڪرڻ جي ضرورت آهي.
//!
//!
//! جيڪڏهن هڪ داخلي کي استعمال ڪرڻ گهرجي ته هڪ `const fn` هڪ `rustc_const_stable` صفت سان ، اندروني حصي جي خاصيت `rustc_const_stable` پڻ هجڻ گهرجي.
//! اهڙي تبديلي ٽي لينگ جي مشوري کانسواءِ نه هئڻ گهرجي ڇاڪاڻ ته اهو هڪ خاصيت ٻولي ۾ ٺاهيندو آهي جنهن کي مرتب ڪندڙ مدد کانسواءِ صارف ڪوڊ ۾ نه ٿو نقل ڪري سگهجي.
//!
//! # Volatiles
//!
//! هلائيندڙ اندروني I/O ياداشت تي عمل ڪرڻ جو ارادو ڪيو آهي ، جيڪي ضايع ڪندڙ ٻئي intrinsics جي ترتيب سان ترتيب نه ڏيڻ جي ضمانت آهن.[[volatile]] تي ايل ايل وي ايم دستاويز ڏسو.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! ائٽمڪ انٽرومنس مشين جي لفظن تي عام ائٽمي آپريشن مهيا ڪن ٿا ، گهڻن ممڪن ميموري ترتيبن سان.اھي ساڳيا سيمينڪ فرمان ڪن ٿا C++ 11.[[atomics]] تي ايل ايل وي ايم دستاويز ڏسو.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! ميموري آرڊر تي هڪ تڪڙي ريفريشر:
//!
//! * لاڪ حاصل ڪرڻ ، تالا حاصل ڪرڻ لاءِ هڪ رڪاوٽ.بعد ۾ پڙهڻ ۽ لکڻ رڪاوٽ لڳڻ کانپوءِ.
//! * آزاد ڪريو ، تالو ڇڏڻ لاءِ هڪ رڪاوٽ.اڳڀرائي پڙهندي ۽ لکي ٿو رڪاوٽ جي اڳيان.
//! * تسلسل سان لاڳيتو ، ترتيب سان مسلسل عملن جي ترتيب جي ضمانت ڏني ويندي آهي.اهو ايٽمي قسمن سان ڪم ڪرڻ جو معياري طريقو آهي ۽ Java جي `volatile` جي برابر آهي.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// اهي واردات اندروني دستاويز لنڪس کي آسان بڻائڻ لاءِ استعمال ڪيا ويندا آهن
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // حفاظت: `ptr::drop_in_place` ڏسو
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // اين بي ، اهي اندروني خام پوائنٽ وٺن ٿا ڇاڪاڻ ته اهي الفا ٿيل ميموري کي رد ڪن ٿيون ، جيڪا ٻئي `&` يا `&mut` لاءِ صحيح ناهي.
    //

    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange` طريقي سان دستياب آھي [`Ordering::SeqCst`] کي ٻئي `success` ۽ `failure` پيرا ميٽرز جي ڪري.
    ///
    /// مثال طور، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange` طريقي سان دستياب آھي [`Ordering::Acquire`] کي ٻئي `success` ۽ `failure` پيرا ميٽرز جي ڪري.
    ///
    /// مثال طور، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange` طريقي سان دستياب آھي [`Ordering::Release`] کي `success` ۽ [`Ordering::Relaxed`] طور تي `failure` پيٽرولز طور.
    /// مثال طور، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange` طريقي سان دستياب آھي [`Ordering::AcqRel`] کي `success` ۽ [`Ordering::Acquire`] طور تي `failure` پيٽرولز طور.
    /// مثال طور، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange` طريقي سان دستياب آھي [`Ordering::Relaxed`] کي ٻئي `success` ۽ `failure` پيرا ميٽرز جي ڪري.
    ///
    /// مثال طور، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange` طريقي سان دستياب آھي [`Ordering::SeqCst`] کي `success` ۽ [`Ordering::Relaxed`] طور تي `failure` پيٽرولز طور.
    /// مثال طور، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange` طريقي سان دستياب آھي [`Ordering::SeqCst`] کي `success` ۽ [`Ordering::Acquire`] طور تي `failure` پيٽرولز طور.
    /// مثال طور، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange` طريقي سان دستياب آھي [`Ordering::Acquire`] کي `success` ۽ [`Ordering::Relaxed`] طور تي `failure` پيٽرولز طور.
    /// مثال طور، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange` طريقي سان دستياب آھي [`Ordering::AcqRel`] کي `success` ۽ [`Ordering::Relaxed`] طور تي `failure` پيٽرولز طور.
    /// مثال طور، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange_weak` طريقي سان دستياب آھي [`Ordering::SeqCst`] کي ٻئي `success` ۽ `failure` پيرا ميٽرز جي ڪري.
    ///
    /// مثال طور، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange_weak` طريقي سان دستياب آھي [`Ordering::Acquire`] کي ٻئي `success` ۽ `failure` پيرا ميٽرز جي ڪري.
    ///
    /// مثال طور، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange_weak` طريقي سان دستياب آھي [`Ordering::Release`] کي `success` ۽ [`Ordering::Relaxed`] طور تي `failure` پيٽرولز طور.
    /// مثال طور، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange_weak` طريقي سان دستياب آھي [`Ordering::AcqRel`] کي `success` ۽ [`Ordering::Acquire`] طور تي `failure` پيٽرولز طور.
    /// مثال طور، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange_weak` طريقي سان دستياب آھي [`Ordering::Relaxed`] کي ٻئي `success` ۽ `failure` پيرا ميٽرز جي ڪري.
    ///
    /// مثال طور، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange_weak` طريقي سان دستياب آھي [`Ordering::SeqCst`] کي `success` ۽ [`Ordering::Relaxed`] طور تي `failure` پيٽرولز طور.
    /// مثال طور، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange_weak` طريقي سان دستياب آھي [`Ordering::SeqCst`] کي `success` ۽ [`Ordering::Acquire`] طور تي `failure` پيٽرولز طور.
    /// مثال طور، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange_weak` طريقي سان دستياب آھي [`Ordering::Acquire`] کي `success` ۽ [`Ordering::Relaxed`] طور تي `failure` پيٽرولز طور.
    /// مثال طور، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// هڪ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو `old` جي قيمت جيتري آهي.
    ///
    /// ھن اندروني جو مستحڪم نسخو ايڪسڪسيمڪس قسمن تي `compare_exchange_weak` طريقي سان دستياب آھي [`Ordering::AcqRel`] کي `success` ۽ [`Ordering::Relaxed`] طور تي `failure` پيٽرولز طور.
    /// مثال طور، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// پوائنٽر جي موجوده قيمت کي لوڊ ڪري ٿو.
    ///
    /// هن intrinsic جو مستحڪم ورزن `load` طريقي سان [`Ordering::SeqCst`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// پوائنٽر جي موجوده قيمت کي لوڊ ڪري ٿو.
    ///
    /// هن intrinsic جو مستحڪم ورزن `load` طريقي سان [`Ordering::Acquire`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// پوائنٽر جي موجوده قيمت کي لوڊ ڪري ٿو.
    ///
    /// هن intrinsic جو مستحڪم ورزن `load` طريقي سان [`Ordering::Relaxed`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// مخصوص ياداشت جي جڳهه تي قيمت اسٽور ڪري ٿو.
    ///
    /// هن intrinsic جو مستحڪم ورزن `store` طريقي سان [`Ordering::SeqCst`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// مخصوص ياداشت جي جڳهه تي قيمت اسٽور ڪري ٿو.
    ///
    /// هن intrinsic جو مستحڪم ورزن `store` طريقي سان [`Ordering::Release`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// مخصوص ياداشت جي جڳهه تي قيمت اسٽور ڪري ٿو.
    ///
    /// هن intrinsic جو مستحڪم ورزن `store` طريقي سان [`Ordering::Relaxed`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// مخصوص ياداشت جي جڳھ تي قيمت اسٽور ڪري ٿو ، پراڻي ويليو موٽائي ٿو.
    ///
    /// هن intrinsic جو مستحڪم ورزن `swap` طريقي سان [`Ordering::SeqCst`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// مخصوص ياداشت جي جڳھ تي قيمت اسٽور ڪري ٿو ، پراڻي ويليو موٽائي ٿو.
    ///
    /// هن intrinsic جو مستحڪم ورزن `swap` طريقي سان [`Ordering::Acquire`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// مخصوص ياداشت جي جڳھ تي قيمت اسٽور ڪري ٿو ، پراڻي ويليو موٽائي ٿو.
    ///
    /// هن intrinsic جو مستحڪم ورزن `swap` طريقي سان [`Ordering::Release`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// مخصوص ياداشت جي جڳھ تي قيمت اسٽور ڪري ٿو ، پراڻي ويليو موٽائي ٿو.
    ///
    /// هن intrinsic جو مستحڪم ورزن `swap` طريقي سان [`Ordering::AcqRel`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// مخصوص ياداشت جي جڳھ تي قيمت اسٽور ڪري ٿو ، پراڻي ويليو موٽائي ٿو.
    ///
    /// هن intrinsic جو مستحڪم ورزن `swap` طريقي سان [`Ordering::Relaxed`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// موجوده ويليو ۾ شامل ڪريو ، اڳوڻي ويليو واپس ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_add` طريقي سان [`Ordering::SeqCst`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده ويليو ۾ شامل ڪريو ، اڳوڻي ويليو واپس ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_add` طريقي سان [`Ordering::Acquire`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده ويليو ۾ شامل ڪريو ، اڳوڻي ويليو واپس ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0 [`Ordering::Release`] طريقي سان `fetch_add` ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده ويليو ۾ شامل ڪريو ، اڳوڻي ويليو واپس ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_add` طريقي سان [`Ordering::AcqRel`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده ويليو ۾ شامل ڪريو ، اڳوڻي ويليو واپس ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_add` طريقي سان [`Ordering::Relaxed`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// موجوده ويليو کي ڪ ،و ، پوئين ويل قيمت واپس.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_sub` طريقي سان [`Ordering::SeqCst`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده ويليو کي ڪ ،و ، پوئين ويل قيمت واپس.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0 [`Ordering::Acquire`] طريقي سان `fetch_sub` ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده ويليو کي ڪ ،و ، پوئين ويل قيمت واپس.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_sub` طريقي سان [`Ordering::Release`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده ويليو کي ڪ ،و ، پوئين ويل قيمت واپس.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_sub` طريقي سان [`Ordering::AcqRel`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده ويليو کي ڪ ،و ، پوئين ويل قيمت واپس.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_sub` طريقي سان [`Ordering::Relaxed`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// bitwise ۽ موجوده قيمت سان ، پوئين ويل کي واپس ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_and` طريقي سان [`Ordering::SeqCst`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// bitwise ۽ موجوده قيمت سان ، پوئين ويل کي واپس ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_and` طريقي سان [`Ordering::Acquire`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// bitwise ۽ موجوده قيمت سان ، پوئين ويل کي واپس ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_and` طريقي سان [`Ordering::Release`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// bitwise ۽ موجوده قيمت سان ، پوئين ويل کي واپس ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_and` طريقي سان [`Ordering::AcqRel`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// bitwise ۽ موجوده قيمت سان ، پوئين ويل کي واپس ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0 [`Ordering::Relaxed`] طريقي سان `fetch_and` ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// هاڻوڪي قيمت سان ساwiseي طور تي نند ، پوئين قدر موٽڻ.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان [`Ordering::SeqCst`] کي `order` طور منتقل ڪندي دستياب آهي.
    /// مثال طور، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// هاڻوڪي قيمت سان ساwiseي طور تي نند ، پوئين قدر موٽڻ.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان [`Ordering::Acquire`] کي `order` طور منتقل ڪندي دستياب آهي.
    /// مثال طور، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// هاڻوڪي قيمت سان ساwiseي طور تي نند ، پوئين قدر موٽڻ.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0 `fetch_nand` طريقي سان [`Ordering::Release`] کي `order` طور منظور ڪندي [`AtomicBool`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// هاڻوڪي قيمت سان ساwiseي طور تي نند ، پوئين قدر موٽڻ.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان [`Ordering::AcqRel`] کي `order` طور منتقل ڪندي دستياب آهي.
    /// مثال طور، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// هاڻوڪي قيمت سان ساwiseي طور تي نند ، پوئين قدر موٽڻ.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان [`Ordering::Relaxed`] کي `order` طور منتقل ڪندي دستياب آهي.
    /// مثال طور، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ساٿي طور تي يا موجوده قيمت سان ، پوئين قيمت موٽڻ.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_or` طريقي سان [`Ordering::SeqCst`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// ساٿي طور تي يا موجوده قيمت سان ، پوئين قيمت موٽڻ.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_or` طريقي سان [`Ordering::Acquire`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ساٿي طور تي يا موجوده قيمت سان ، پوئين قيمت موٽڻ.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_or` طريقي سان [`Ordering::Release`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ساٿي طور تي يا موجوده قيمت سان ، پوئين قيمت موٽڻ.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_or` طريقي سان [`Ordering::AcqRel`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ساٿي طور تي يا موجوده قيمت سان ، پوئين قيمت موٽڻ.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_or` طريقي سان [`Ordering::Relaxed`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// موجوده ويليو سان گڏ Bitwise xor ، پوئين ويل قيمت موٽائي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_xor` طريقي سان [`Ordering::SeqCst`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده ويليو سان گڏ Bitwise xor ، پوئين ويل قيمت موٽائي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_xor` طريقي سان [`Ordering::Acquire`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده ويليو سان گڏ Bitwise xor ، پوئين ويل قيمت موٽائي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_xor` طريقي سان [`Ordering::Release`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده ويليو سان گڏ Bitwise xor ، پوئين ويل قيمت موٽائي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_xor` طريقي سان [`Ordering::AcqRel`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده ويليو سان گڏ Bitwise xor ، پوئين ويل قيمت موٽائي.
    ///
    /// هن intrinsic جو مستحڪم ورزن `fetch_xor` طريقي سان [`Ordering::Relaxed`] ذريعي `order` طور منظور ڪندي [`atomic`] قسم تي موجود آهي.
    /// مثال طور، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// وڌ ۾ وڌ موجوده قيمت سان دستخط ٿيل مقابلي ذريعي استعمال ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان `fetch_max` طريقي سان `order` طور منظور ڪندي `fetch_max` دستياب ٿيل انٽيگر قسمن تي موجود آهي.
    /// مثال طور، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// وڌ ۾ وڌ موجوده قيمت سان دستخط ٿيل مقابلي ذريعي استعمال ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان `fetch_max` طريقي سان `order` طور منظور ڪندي `fetch_max` دستياب ٿيل انٽيگر قسمن تي موجود آهي.
    /// مثال طور، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// وڌ ۾ وڌ موجوده قيمت سان دستخط ٿيل مقابلي ذريعي استعمال ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان `fetch_max` طريقي سان `order` طور منظور ڪندي `fetch_max` دستياب ٿيل انٽيگر قسمن تي موجود آهي.
    /// مثال طور، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// وڌ ۾ وڌ موجوده قيمت سان دستخط ٿيل مقابلي ذريعي استعمال ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان `fetch_max` طريقي سان `order` طور منظور ڪندي `fetch_max` دستياب ٿيل انٽيگر قسمن تي موجود آهي.
    /// مثال طور، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// وڌ کان وڌ موجوده ويليو سان.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان `fetch_max` طريقي سان `order` طور منظور ڪندي `fetch_max` دستياب ٿيل انٽيگر قسمن تي موجود آهي.
    /// مثال طور، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// موجوده قيمت سان گهٽ ۾ گهٽ هڪ دستخط ٿيل مقابلي ذريعي استعمال ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان `fetch_min` طريقي سان `order` طور منظور ڪندي `fetch_min` دستياب ٿيل انٽيگر قسمن تي موجود آهي.
    /// مثال طور، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده قيمت سان گهٽ ۾ گهٽ هڪ دستخط ٿيل مقابلي ذريعي استعمال ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان `fetch_min` طريقي سان `order` طور منظور ڪندي `fetch_min` دستياب ٿيل انٽيگر قسمن تي موجود آهي.
    /// مثال طور، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده قيمت سان گهٽ ۾ گهٽ هڪ دستخط ٿيل مقابلي ذريعي استعمال ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان `fetch_min` طريقي سان `order` طور منظور ڪندي `fetch_min` دستياب ٿيل انٽيگر قسمن تي موجود آهي.
    /// مثال طور، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده قيمت سان گهٽ ۾ گهٽ هڪ دستخط ٿيل مقابلي ذريعي استعمال ڪندي.
    ///
    /// ھن اندروني جو مستحڪم نسخو دستياب آھي [`atomic`] دستخط ٿيل عدد قسمن تي `fetch_min` طريقي سان [`Ordering::AcqRel`] کي `order` طور منتقل ڪرڻ سان.
    /// مثال طور، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده قيمت سان گهٽ ۾ گهٽ هڪ دستخط ٿيل مقابلي ذريعي استعمال ڪندي.
    ///
    /// هن intrinsic جو مستحڪم ورزن X0XX طريقي سان `fetch_min` ذريعي X0XX طور X003 ذريعي دستياب ٿيل عدد عددي قسمن تي موجود آهي.
    /// مثال طور، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// گھٽ ۾ گھٽ موجوده موازنہ جي استعمال سان گھٽ ۾ گھٽ.
    ///
    /// هن intrinsic جو مستحڪم ورزن [`Ordering::SeqCst`] طريقي سان [`Ordering::SeqCst`] کي `order` طور منظور ڪندي `fetch_min` طريقو ذريعي موجود آهي.
    /// مثال طور، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// گھٽ ۾ گھٽ موجوده موازنہ جي استعمال سان گھٽ ۾ گھٽ.
    ///
    /// هن intrinsic جو مستحڪم ورزن [`Ordering::Acquire`] طريقي سان [`Ordering::Acquire`] کي `order` طور منظور ڪندي `fetch_min` طريقو ذريعي موجود آهي.
    /// مثال طور، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// گھٽ ۾ گھٽ موجوده موازنہ جي استعمال سان گھٽ ۾ گھٽ.
    ///
    /// هن intrinsic جو مستحڪم ورزن [`Ordering::Release`] طريقي سان [`Ordering::Release`] کي `order` طور منظور ڪندي `fetch_min` طريقو ذريعي موجود آهي.
    /// مثال طور، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// گھٽ ۾ گھٽ موجوده موازنہ جي استعمال سان گھٽ ۾ گھٽ.
    ///
    /// هن intrinsic جو مستحڪم ورزن [`Ordering::AcqRel`] طريقي سان [`Ordering::AcqRel`] کي `order` طور منظور ڪندي `fetch_min` طريقو ذريعي موجود آهي.
    /// مثال طور، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// گھٽ ۾ گھٽ موجوده موازنہ جي استعمال سان گھٽ ۾ گھٽ.
    ///
    /// هن intrinsic جو مستحڪم ورزن [`Ordering::Relaxed`] طريقي سان [`Ordering::Relaxed`] کي `order` طور منظور ڪندي `fetch_min` طريقو ذريعي موجود آهي.
    /// مثال طور، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// موجوده قيمت سان وڌ ۾ وڌ اڻ edاتل مقابلو.
    ///
    /// هن intrinsic جو مستحڪم ورزن [`Ordering::SeqCst`] طريقي سان [`Ordering::SeqCst`] کي `order` طور منظور ڪندي `fetch_max` طريقو ذريعي موجود آهي.
    /// مثال طور، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده قيمت سان وڌ ۾ وڌ اڻ edاتل مقابلو.
    ///
    /// هن intrinsic جو مستحڪم ورزن [`Ordering::Acquire`] طريقي سان [`Ordering::Acquire`] کي `order` طور منظور ڪندي `fetch_max` طريقو ذريعي موجود آهي.
    /// مثال طور، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده قيمت سان وڌ ۾ وڌ اڻ edاتل مقابلو.
    ///
    /// هن intrinsic جو مستحڪم ورزن [`Ordering::Release`] طريقي سان [`Ordering::Release`] کي `order` طور منظور ڪندي `fetch_max` طريقو ذريعي موجود آهي.
    /// مثال طور، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده قيمت سان وڌ ۾ وڌ اڻ edاتل مقابلو.
    ///
    /// هن intrinsic جو مستحڪم ورزن [`Ordering::AcqRel`] طريقي سان [`Ordering::AcqRel`] کي `order` طور منظور ڪندي `fetch_max` طريقو ذريعي موجود آهي.
    /// مثال طور، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// موجوده قيمت سان وڌ ۾ وڌ اڻ edاتل مقابلو.
    ///
    /// هن intrinsic جو مستحڪم ورزن [`Ordering::Relaxed`] طريقي سان [`Ordering::Relaxed`] کي `order` طور منظور ڪندي `fetch_max` طريقو ذريعي موجود آهي.
    /// مثال طور، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` اندروني ڪو ڪوڊ جنريٽر ڏانهن اشارو آهي ، جيڪڏهن اڳڀرائي هدايت ڪئي وڃي ته داخل ٿئي ٿي.ٻي صورت ۾ ، اهو ڪو آپشن ناهي.
    /// اڳفريٽس پروگرام جي رويي تي ڪو اثر نه ٿو رکن پر ان جي ڪارڪردگي خاصيتن کي تبديل ڪري سگھن ٿا.
    ///
    /// `locality` دليل لازمي طور تي مستقل عدد هجڻ گهرجي ۽ هڪ عارضي طور تي مقامي جڳهه جو تعين ڪندڙ آهي (0) ، ڪوبه جڳهه ، (3) تائين ، تمام گهڻو مقامي ڪيش ۾ نه.
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` اندروني ڪو ڪوڊ جنريٽر ڏانهن اشارو آهي ، جيڪڏهن اڳڀرائي هدايت ڪئي وڃي ته داخل ٿئي ٿي.ٻي صورت ۾ ، اهو ڪو آپشن ناهي.
    /// اڳفريٽس پروگرام جي رويي تي ڪو اثر نه ٿو رکن پر ان جي ڪارڪردگي خاصيتن کي تبديل ڪري سگھن ٿا.
    ///
    /// `locality` دليل لازمي طور تي مستقل عدد هجڻ گهرجي ۽ هڪ عارضي طور تي مقامي جڳهه جو تعين ڪندڙ آهي (0) ، ڪوبه جڳهه ، (3) تائين ، تمام گهڻو مقامي ڪيش ۾ نه.
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` اندروني ڪو ڪوڊ جنريٽر ڏانهن اشارو آهي ، جيڪڏهن اڳڀرائي هدايت ڪئي وڃي ته داخل ٿئي ٿي.ٻي صورت ۾ ، اهو ڪو آپشن ناهي.
    /// اڳفريٽس پروگرام جي رويي تي ڪو اثر نه ٿو رکن پر ان جي ڪارڪردگي خاصيتن کي تبديل ڪري سگھن ٿا.
    ///
    /// `locality` دليل لازمي طور تي مستقل عدد هجڻ گهرجي ۽ هڪ عارضي طور تي مقامي جڳهه جو تعين ڪندڙ آهي (0) ، ڪوبه جڳهه ، (3) تائين ، تمام گهڻو مقامي ڪيش ۾ نه.
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` اندروني ڪو ڪوڊ جنريٽر ڏانهن اشارو آهي ، جيڪڏهن اڳڀرائي هدايت ڪئي وڃي ته داخل ٿئي ٿي.ٻي صورت ۾ ، اهو ڪو آپشن ناهي.
    /// اڳفريٽس پروگرام جي رويي تي ڪو اثر نه ٿو رکن پر ان جي ڪارڪردگي خاصيتن کي تبديل ڪري سگھن ٿا.
    ///
    /// `locality` دليل لازمي طور تي مستقل عدد هجڻ گهرجي ۽ هڪ عارضي طور تي مقامي جڳهه جو تعين ڪندڙ آهي (0) ، ڪوبه جڳهه ، (3) تائين ، تمام گهڻو مقامي ڪيش ۾ نه.
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// هڪ ايٽمي باهه.
    ///
    /// ھن اندروني جو مستحڪم نسخو [`atomic::fence`] ۾ موجود آھي [`Ordering::SeqCst`] کي `order` جي طور تي منتقل ڪري.
    ///
    ///
    pub fn atomic_fence();
    /// هڪ ايٽمي باهه.
    ///
    /// ھن اندروني جو مستحڪم نسخو [`atomic::fence`] ۾ موجود آھي [`Ordering::Acquire`] کي `order` جي طور تي منتقل ڪري.
    ///
    ///
    pub fn atomic_fence_acq();
    /// هڪ ايٽمي باهه.
    ///
    /// ھن اندروني جو مستحڪم نسخو [`atomic::fence`] ۾ موجود آھي [`Ordering::Release`] کي `order` جي طور تي منتقل ڪري.
    ///
    ///
    pub fn atomic_fence_rel();
    /// هڪ ايٽمي باهه.
    ///
    /// ھن اندروني جو مستحڪم نسخو [`atomic::fence`] ۾ موجود آھي [`Ordering::AcqRel`] کي `order` جي طور تي منتقل ڪري.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// هڪ تاليف وارا صرف ياداشت جي رڪاوٽ.
    ///
    /// مرتب ڪندڙ هن رڪاوٽ جي مٿان ياداشت جي رسائي کي ٻيهر ترتيب نه ڏني ويندي ، پر ان لاءِ ڪا به هدايت خارج نه ڪئي ويندي.
    /// اهو ساڳيو موضوع تي آپريشن لاءِ مناسب آهي جيڪا اڳڀرائي ٿي سگھي ٿي ، جيئن سگنل هٿ ڪرڻ وارن سان رابطو ڪرڻ دوران.
    ///
    /// ھن اندروني جو مستحڪم نسخو [`atomic::compiler_fence`] ۾ موجود آھي [`Ordering::SeqCst`] کي `order` جي طور تي منتقل ڪري.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// هڪ تاليف وارا صرف ياداشت جي رڪاوٽ.
    ///
    /// مرتب ڪندڙ هن رڪاوٽ جي مٿان ياداشت جي رسائي کي ٻيهر ترتيب نه ڏني ويندي ، پر ان لاءِ ڪا به هدايت خارج نه ڪئي ويندي.
    /// اهو ساڳيو موضوع تي آپريشن لاءِ مناسب آهي جيڪا اڳڀرائي ٿي سگھي ٿي ، جيئن سگنل هٿ ڪرڻ وارن سان رابطو ڪرڻ دوران.
    ///
    /// ھن اندروني جو مستحڪم نسخو [`atomic::compiler_fence`] ۾ موجود آھي [`Ordering::Acquire`] کي `order` جي طور تي منتقل ڪري.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// هڪ تاليف وارا صرف ياداشت جي رڪاوٽ.
    ///
    /// مرتب ڪندڙ هن رڪاوٽ جي مٿان ياداشت جي رسائي کي ٻيهر ترتيب نه ڏني ويندي ، پر ان لاءِ ڪا به هدايت خارج نه ڪئي ويندي.
    /// اهو ساڳيو موضوع تي آپريشن لاءِ مناسب آهي جيڪا اڳڀرائي ٿي سگھي ٿي ، جيئن سگنل هٿ ڪرڻ وارن سان رابطو ڪرڻ دوران.
    ///
    /// ھن اندروني جو مستحڪم نسخو [`atomic::compiler_fence`] ۾ موجود آھي [`Ordering::Release`] کي `order` جي طور تي منتقل ڪري.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// هڪ تاليف وارا صرف ياداشت جي رڪاوٽ.
    ///
    /// مرتب ڪندڙ هن رڪاوٽ جي مٿان ياداشت جي رسائي کي ٻيهر ترتيب نه ڏني ويندي ، پر ان لاءِ ڪا به هدايت خارج نه ڪئي ويندي.
    /// اهو ساڳيو موضوع تي آپريشن لاءِ مناسب آهي جيڪا اڳڀرائي ٿي سگھي ٿي ، جيئن سگنل هٿ ڪرڻ وارن سان رابطو ڪرڻ دوران.
    ///
    /// ھن اندروني جو مستحڪم نسخو [`atomic::compiler_fence`] ۾ موجود آھي [`Ordering::AcqRel`] کي `order` جي طور تي منتقل ڪري.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// جادو جا اندروني ڪم جيڪي پنهنجي فنڪشن سان منسلڪ خاصيتن مان حاصل ڪندا آهن.
    ///
    /// مثال طور ، ڊيٽا فلو مستحڪم جتن کي انجڻ ڪرڻ جي لاءِ استعمال ڪندو آهي ته جيئن `rustc_peek(potentially_uninitialized)` درحقيقت اهو چيڪ ڪري ها ته ڊيٽا فلو واقعي ڳڻيو آهي ته ان کي ڪنٽرول جي وهڪري ۾ انهي وقت شروع ڪيو ويو آهي.
    ///
    ///
    /// اهو intrinsic استعمال ڪندڙ کان ٻاهر نه استعمال ڪيو وڃي.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// عمل جي انجام کي رد ڪري ٿو.
    ///
    /// هن آپريشن جو وڌيڪ صارف دوست ۽ مستحڪم ورزن [`std::process::abort`](../../std/process/fn.abort.html) آهي.
    ///
    pub fn abort() -> !;

    /// بهتر ڪندڙ کي آگاهي ڪري ٿو ته ڪوڊ ۾ اهو نڪتو قابل نه آهي ، وڌيڪ بهتر بنائڻ جي قابل بنائي ٿو.
    ///
    /// اين بي ، هي `unreachable!()` ميڪرو کان بلڪل مختلف آهي: ميڪرو جي برعڪس ، جنهن کي هلائڻ وقت panics ، انهي ڪم سان لڳل ڪوڊ تائين پهچڻ لاءِ *غير تعين ٿيل رويو* آهي.
    ///
    ///
    /// ھن اندروني نسخ جو مستحڪم نسخو [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) آھي.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// اصلاح ڪندڙ کي آگاهه ڪري ٿو ته هڪ شرط هميشه صحيح هوندي آهي.
    /// جيڪڏهن شرط غلط آهي ، رويو غير متعين آهي.
    ///
    /// هن داخلي لاءِ ڪو ڪوڊ ٺهيل ناهي ، پر اصلاح ڪندڙ پاسن جي وچ ۾ انهي کي محفوظ ڪرڻ جي ڪوشش ڪندو (۽ ان جي حالت) ، جيڪو ڀرپاسي ڪوڊ کي بهتر ڪرڻ ۽ ڪارڪردگي گهٽائڻ ۾ مداخلت ڪري سگهي ٿو.
    /// اهو استعمال نه ڪيو وڃي جيڪڏهن گھڙي وٺندڙ پنهنجو پاڻ تي اصلاح ڪندڙ ڳولي لڌا وڃن ، يا جيڪڏهن اهو ڪنهن خاص اصلاح کي چالو نٿو ڪري.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// مرتب ڪندڙ کي اشارو ڏجي ٿو ته branch شرط سچي هجڻ جو امڪان آهي.
    /// ڏانھن ويندڙ قيمت کي واپس ڪري ٿو.
    ///
    /// ڪنهن به استعمال سان `if` بيانن کانسواءِ ممڪن ناهي.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// مرتب ڪندڙ کي اشارو ڏجي ٿو ته branch حالت غلط هجڻ جو امڪان آهي.
    /// ڏانھن ويندڙ قيمت کي واپس ڪري ٿو.
    ///
    /// ڪنهن به استعمال سان `if` بيانن کانسواءِ ممڪن ناهي.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// ڊيزوگ ڪندڙ طرفان چڪاس لاءِ وقف واري جھاز جو عمل ڏي ٿو.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn breakpoint();

    /// بائيٽ ۾ هڪ قسم جي سائيز.
    ///
    /// وڌيڪ خاص طور تي ، اهو ساڳئي قسم جي متواتر شين جي وچ ۾ بائيٽ ۾ آفسیٽ آهي ، بشمول ترتيب ڏيڻ واري پيڊنگ.
    ///
    ///
    /// ھن اندروني نسخ جو مستحڪم نسخو [`core::mem::size_of`](crate::mem::size_of) آھي.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// ھڪڙي قسم جي گھٽ ۾ گھٽ ترتيب.
    ///
    /// ھن اندروني نسخ جو مستحڪم نسخو [`core::mem::align_of`](crate::mem::align_of) آھي.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// ھڪڙي قسم جي پسنديده ترتيب.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// bytes حوالي ڪيل قيمت جو اندازو.
    ///
    /// ھن اندروني نسخ جو مستحڪم نسخو [`mem::size_of_val`] آھي.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// حوالو ويليوڊ جي گهربل ترتيب.
    ///
    /// ھن اندروني نسخ جو مستحڪم نسخو [`core::mem::align_of_val`](crate::mem::align_of_val) آھي.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// هڪ قسم جي نالي تي مشتمل جامد ڏاڪڻ سلائس حاصل ٿئي ٿي.
    ///
    /// ھن اندروني نسخ جو مستحڪم نسخو [`core::any::type_name`](crate::any::type_name) آھي.
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// هڪ سڃاڻيندڙ حاصل ڪري ٿو جيڪو عالمي سطح تي مخصوص قسم جي لحاظ کان منفرد آهي.
    /// اهو فنڪشن جيترو به crate ۾ هجي انهي جي قيمت لاءِ هڪ ئي قيمت موٽائيندو.
    ///
    ///
    /// ھن اندروني نسخ جو مستحڪم نسخو [`core::any::TypeId::of`](crate::any::TypeId::of) آھي.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// غير محفوظ افعال جي حفاظت ڪندڙ جيڪو `T` غير آباد آهي جيڪڏهن ڪڏهن به عمل نه ٿي ڪري سگهجي:
    /// اھو جامد طور تي panic ٿيندو ، يا ڪجھ به نه ڪندو.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// غير محفوظ افعال جي حفاظت ڪندڙ جيڪو ڪڏهن به عملدرآمد نه ٿي ڪري سگھجي جيڪڏهن `T` صفر شروعات جي اجازت نٿو ڏي: اهو جامد طور تي panic ٿيندو ، يا ڪجھ به نه ڪندو.
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn assert_zero_valid<T>();

    /// غير محفوظ افعال جي حفاظت ڪندڙ جيڪو ڪڏهن به عملدرآمد نه ٿي ڪري سگھجي جيڪڏهن `T` غلط بٽ نمونن وارو هوندو: اهو جامد طور panic ٿيندو ، يا ڪجھ به نه ڪندو.
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn assert_uninit_valid<T>();

    /// هڪ جامد `Location` جو هڪ حوالو اچي ٿو ظاهر ڪري ٿو جتي ان کي سڏيو ويو هو.
    ///
    /// [`core::panic::Location::caller`](crate::panic::Location::caller) جي بدران استعمال ڪرڻ تي غور ڪريو.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// هلڪو گريو کي هلائڻ کان بغير ڪنهن قدر پريشاني جي طرف منتقل ڪري ٿو.
    ///
    /// اهو صرف ۽ صرف [`mem::forget_unsized`] لاءِ موجود آهيعام `forget` بدران `ManuallyDrop` استعمال ڪندو آهي.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// هڪ قسم جي قيمت جي بٽس کي ٻئي قسم جي طور تي تعبير ڪندو آهي.
    ///
    /// ٻنهي قسمن جو ساڳيو انداز هجڻ گهرجي.
    /// نه ئي اصل ، ۽ نه ئي نتيجو ، ٿي سگهي ٿو [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` بنيادي طور تي هڪ قسم جو هڪ ٻئي کان ٻئي طرف منتقل ٿيڻ جي برابر آهي.اهو بٽس کي ماخذ ويليو کان منزل جي قيمت ۾ نقل ڪري ٿو ، پوءِ اصل کي وساري.
    /// اهو هائ وي تحت C جي `memcpy` جي برابر آهي ، بلڪل `transmute_copy` وانگر.
    ///
    /// ڇاڪاڻ ته `transmute` هڪ بائيٽ قدر آپريشن آهي ،*منتقل ٿيل قدرن جي ترتيب* انهن جي تشويش نه آهي.
    /// ڪنهن ٻئي فنڪشن سان ، مرتب ڪندڙ پهريان ئي يقيني بڻائي ٿو ٻئي `T` ۽ `U` صحيح نموني مطابق آهن.
    /// تنهن هوندي ، جڏهن قدرن کي منتقل ڪندي جيڪي * ٻئي هنڌ ڏانهن اشارو ڪن ٿا (جهڙوڪ اشارو ، حوالا ، باڪس ...) ، ڪالر کي پوائنٽ-ويل ويلز جي صحيح ترتيب کي يقيني بڻائڻو آهي.
    ///
    /// `transmute` **ناقابل اعتبار آھي** غير محفوظ آھي.ھن فنڪشن سان [undefined behavior][ub] جي ويجھڙائي جا ڪيترائي طريقا آھن.`transmute` مڪمل آخري رزق هجڻ گهرجي.
    ///
    /// [nomicon](../../nomicon/transmutes.html) وٽ اضافي دستاويز آهن.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ڪجهه شيون آهن جيڪي `transmute` واقعي لاءِ ڪارائتو آهن.
    ///
    /// پوائنٽر کي فنڪشن پوائنٽر ۾ تبديل ڪرڻ.هي *نه* مشينن ڏانهن پورٽبل آهي جتي فنڪشن پوائنٽر ۽ ڊيٽا پوائنٽر مختلف سائيز آهن.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// حياتيءَ کي ڊگهو ڪرڻ ، يا اڻ antميل حياتيءَ کي مختصر ڪرڻ.اھو ترقي يافته آھي ، بلڪل غير محفوظ Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// نااميد نه ٿيو: `transmute` جا ڪيترائي استعمال ٻين ذريعن ذريعي حاصل ڪري سگھن ٿا.
    /// هيٺيون `transmute` جي عام ايپليڪيشنون آهن ، جيڪي محفوظ ترڪيبون سان متبادل ٿي سگهن ٿيون.
    ///
    /// خام bytes(`&[u8]`) کي `u32` ، `f64` ، وغيره يرائڻ:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // `u32::from_ne_bytes` جي بدران استعمال ڪريو
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // يا استعمال ختم ڪرڻ لاءِ `u32::from_le_bytes` يا `u32::from_be_bytes` استعمال ڪريو
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// `usize` ۾ پوائنٽر يرائڻ:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // ھڪڙو `as` ڪاسٽ استعمال ڪريو
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// هڪ `*mut T` کي هڪ `&mut T` ۾ بدلائڻ:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // بدران بدعنواني استعمال ڪريو
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// هڪ `&mut T` هڪ `&mut U` ۾ تبديل ڪندي:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // ھاڻي ، ايڪس آرڪس ۽ ري ڪررنگنگ گڏ ڪريو ، نوٽ ڪريو `as` `as` منتقلي نه آھي
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// هڪ `&str` هڪ `&[u8]` ۾ تبديل ڪندي:
    ///
    /// ```
    /// // اھو ڪرڻ لاءِ ھڪڙو سٺو طريقو نه آھي.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // توھان استعمال ڪري سگھوٿا `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // يا ، صرف هڪ بائيٽ اسٽرنگ استعمال ڪريو ، جيڪڏهن توهان کي اسٽرنگ لفظي معنيٰ تي ڪنٽرول آهي
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// هڪ `Vec<&T>` کي `Vec<Option<&T>>` ۾ تبديل ڪندي.
    ///
    /// ڪنٽينر جي مواد جي اندروني قسم کي منتقل ڪرڻ لاءِ ، توهان کي پڪ ڪرڻ گهرجي ته ڪنهن به ڪنٽينر جي ڌانڌلي جي خلاف ورزي نه ڪئي وڃي.
    /// ايڪسڪسيمڪس لاءِ ، انهي جو مطلب آهي ته ٻئي قسم جي سائيز ۽ لائيننگ * کي مليل آهي.
    /// ٻيا ڪنٽينر شايد قسم جي ماپ ، ڀروسو رکندڙ ، يا اڃا تائين `TypeId` تي ڀاڙين ٿا ، ان صورت ۾ ڪنٽينر انواريٽس جي خلاف ورزي ڪرڻ کانسواءِ ٽرانسميٽنگ هرگز ممڪن نه آهي.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector کي کلون جيئن اسين انهن کي ٻيهر استعمال ڪنداسين
    /// let v_clone = v_orig.clone();
    ///
    /// // ٽرانسميٽ استعمال ڪندي: اهو `Vec` جي غير متعين ٿيل ڊيٽا جي ترتيب تي ڀاڙين ٿا ، جيڪو هڪ خراب خيال آهي ۽ اڻ inedاتل رويي جو سبب بڻجي سگهي ٿو.
    /////
    /// // تنهن هوندي ، اها ڪاپي ناهي.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // اها تجويز ڪيل ، محفوظ رستو آهي.
    /// // اهو نقل ڪري ٿو س Zو vector ، جيتوڻيڪ ، نئين صف ۾.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // اھو صحيح آھي ڪاپي ، غير محفوظ طريقو "transmuting" `Vec` جو ، ڊيٽا ترتيب ڏيڻ تي ڀروسو ڪرڻ کان سواء.
    /// // لفظي طور تي `transmute` کي سڏڻ بدران ، اسان پوائنٽر ڪاسٽ ڪريون ٿا ، پر اصل اندروني قسم (`&i32`) کي نئون (`Option<&i32>`) ۾ تبديل ڪرڻ جي لحاظ کان ، اهو سڀ ڪجهه ساڳيون خدشات آهن.
    /////
    /// // مٿي ڏنل اڻ کان علاوه ، [`from_raw_parts`] دستاويز سان پڻ صلاح ڪريو.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME هن کي تازه ڪاري ڪريو جڏهن vec_into_raw_parts مستحڪم ٿي آهي.
    ///     // يقيني بڻيو ته اصل vector نه ٿيو آهي.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` لاڳو ڪرڻ:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // ھن جا ڪيترائي طريقا آھن ، ۽ ھيٺ ڏنل (transmute) طريقي سان ڪيترائي مسئلا آھن.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // پهريون: ٽرانسمينٽ قسم جو محفوظ نه آهي ؛انهي تي چڪاس آهي ته ٽي ۽
    ///         // يو ساڳي سائيز جا آهن.
    ///         // ٻيو ، هتي ، توهان وٽ ٻه ياداشت وارا حوالا آهن جيڪي ساڳي يادگيري ڏانهن اشارو ڪن ٿا.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // هي قسم جي حفاظت واري مسئلن کان نجات حاصل ڪري ٿو.`&mut *` فقط* ڏيندو *توھان کي ھڪڙي `&mut T` ھڪڙي `&mut T` يا `* mut T` مان.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // تنهن هوندي ، توهان وٽ اڃا تائين ٻه ياداشت وارا حوالا آهن جيڪي ساڳي يادگيري ڏانهن اشارو ڪن ٿا.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // اهو معياري طريقي سان اهو ڪندو آهي.
    /// // اهو بهترين طريقو آهي ، جيڪڏهن توهان کي انهي وانگر ڪجهه ڪرڻ جي ضرورت آهي
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // ھن ھاڻي ٽي يادگار حوالا آھن ھڪڙي ئي يادگيري ڏانھن اشارو ڪندي.`slice` ، وڏو قدر ret.0 ، ۽ بي قدر ret.1.
    ///         // `slice` `let ptr = ...` کان پوءِ ڪڏهن به استعمال نه ڪيو ويو آهي ، ۽ تنهنڪري اهو "dead" وانگر ان جو علاج ڪري سگهي ٿو ، ۽ تنهن ڪري ، توهان وٽ صرف ٻه حقيقي مٽايل سلاز آهن.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: جڏهن ته ھي اندروني ضابطي کي مستحڪم بڻائيندو آھي ، اسان وٽ ڪن فني ۾ ڪسٽم ڪوڊ آھي
    // چيڪ جيڪي `const fn` جي اندر ان جي استعمال کي روڪائين ٿيون.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `true` جي واپسي ڏئي ٿو جيڪڏهن حقيقي قسم `T` طور ڏنل آهي ڊراپ گلو جي ضرورت آهي ؛جيڪڏهن `T` لاءِ فراهم ڪيل اصل قسم `Copy` لاڳو ڪندو آهي واپسي `false` ڏئي ٿو.
    ///
    ///
    /// جيڪڏهن اصل قسم کي نه گِپ گلو جي ضرورت آهي ۽ نه ئي `Copy` تي عمل ڪرائڻ جي ، ته پوءِ هن فنڪشن جي واپسي جو قدر ناگزير آهي.
    ///
    /// ھن اندروني نسخ جو مستحڪم نسخو [`mem::needs_drop`](crate::mem::needs_drop) آھي.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// پوائنٽر کان آفسيٽ ڳڻپ ڪندو آهي.
    ///
    /// اهو اندرئين طور تي تبديل ٿيڻ کان پاسو ڪرڻ ۽ انٽيگر کان مڪمل طور تي لاڳو ڪيو ويندو آهي ، ڇو ته اها تبديلي aliاڻ واري asingاڻ کي wouldهليندي.
    ///
    /// # Safety
    ///
    /// ٻئي شروعاتي ۽ نتيجو ڪندڙ پوائنٽر يا ته حدن ۾ يا هڪ بائيٽ تائين مختص ٿيل شيءَ جي آخر ۾ هجڻ لازمي آهي.
    /// جيڪڏهن يا ته پوائنٽر حد کان ٻاهر آهي يا رياضياتي حد کان وڌيڪ آهي ته موٽندڙ قدر جو وڌيڪ استعمال اڻ ڏٺي رويي جو نتيجو ٿيندو.
    ///
    ///
    /// ھن اندروني جو مستحڪم نسخو [`pointer::offset`] آھي.
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// پوائنٽر کان آفسيٽ حساب ڪندو آهي ، امڪاني طور تي لپڻ.
    ///
    /// اهو اندرئين طور تي لاڳو ٿيو آهي نن converن نن converن اچارن کان وٺي ۽ بدلائڻ کان بچڻ لاءِ ، جئين ته تبديلي ڪجهه اصلاح واري عمل کي روڪي ٿي.
    ///
    /// # Safety
    ///
    /// `offset` اندروني طور تي ، اهو اندروني نتيجن واري پوائنٽر کي محدود نٿو ڪري ۽ هڪ مختص ڪيل شي جي آخر تائين هڪ بائيٽ ڏانهن اشارو ڪري ٿو ، ۽ اهو ٻن جي مڪمل عددي سان ختم ڪري ٿو.
    /// نتيجو وارو قدر لازمي طور تي ياداشت تائين رسائي جي لاءِ استعمال ٿيڻ جي لحاظ سان صحيح ناهي.
    ///
    /// ھن اندروني نسخ جو مستحڪم نسخو [`pointer::wrapping_offset`] آھي.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// مناسب `llvm.memcpy.p0i8.0i8.*` اندروني جي برابر ، `count`*`size_of::<T>()` جي سائيز سان ۽
    ///
    /// `min_align_of::<T>()`
    ///
    /// وولٽٽر پيمراٽر `true` تي مقرر ٿيل آھي ، تنھنڪري اھو ڪ beي نٿو سگھبو جيستائين سائز صفر جي برابر نه ٿيندو.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// برابر `llvm.memmove.p0i8.0i8.*` اندروني ، برابر `count* size_of::<T>()` جي سائيز ۽ برابر جي برابر سان
    ///
    /// `min_align_of::<T>()`
    ///
    /// وولٽٽر پيمراٽر `true` تي مقرر ٿيل آھي ، تنھنڪري اھو ڪ beي نٿو سگھبو جيستائين سائز صفر جي برابر نه ٿيندو.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// برابر `llvm.memset.p0i8.*` اندروني جي برابر ، `count* size_of::<T>()` جي سائيز سان ۽ `min_align_of::<T>()` جي هڪ سڌي ترتيب سان.
    ///
    ///
    /// وولٽٽر پيمراٽر `true` تي مقرر ٿيل آھي ، تنھنڪري اھو ڪ beي نٿو سگھبو جيستائين سائز صفر جي برابر نه ٿيندو.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` پوائنٽر کان ويتر لوڊ ڪندو آهي.
    ///
    /// ھن اندروني نسخ جو مستحڪم نسخو [`core::ptr::read_volatile`](crate::ptr::read_volatile) آھي.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` پوائنٽر ڏانھن ھڪڙي ھلندڙ ذخيرو انجام ڏئي ٿو.
    ///
    /// ھن اندروني نسخ جو مستحڪم نسخو [`core::ptr::write_volatile`](crate::ptr::write_volatile) آھي.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` پوائنٽر کان ويتر لوڊ ادا ڪندو آهي پوائنٽر کي متوازن رکڻ جي ضرورت ناهي.
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` پوائنٽر ڏانھن ھڪڙي ھلندڙ ذخيرو انجام ڏئي ٿو.
    /// پوائنٽر ترتيب ڏيڻ جي ضرورت ناھي.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` جي چوٽي روٽ کي واپس آڻيندي
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` جي چوٽي روٽ کي واپس آڻيندي
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// هڪ `f32` کي شمسي طاقت ڏانهن وڌائي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// هڪ `f64` کي شمسي طاقت ڏانهن وڌائي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` جو سائو موٽائي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` جو سائو موٽائي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` جو قاعدو واپس ڏئي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` جو قاعدو واپس ڏئي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// هڪ `f32` کي `f32` پاور ڏانهن وڌائي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// هڪ `f64` کي `f64` پاور ڏانهن وڌائي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32` جي توسيع کي واپس ڏئي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64` جي توسيع کي واپس ڏئي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// 2 کي `f32` جي طاقت ڏانهن وڌي ويو واپسي.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// 2 کي `f64` جي طاقت ڏانهن وڌي ويو واپسي.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32` جي قدرتي علامتي ورجائي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64` جي قدرتي علامتي ورجائي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// `f32` جو بنيادي 10 لوگيتم موٽائيندو آهي.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// `f64` جو بنيادي 10 لوگيتم موٽائيندو آهي.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// ايڪس 2ڪس جو بنيادي نقشو واپسي ڏي ٿو `f32`.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// ايڪس 2ڪس جو بنيادي نقشو واپسي ڏي ٿو `f64`.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `a * b + c` کي `f32` قدرن لاءِ واپس ڏئي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `a * b + c` کي `f64` قدرن لاءِ واپس ڏئي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` جي مڪمل قيمت ڏي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` جي مڪمل قيمت ڏي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// گھٽ ۾ گھٽ ٻه `f32` قدرون واپس آڻيندي.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// گھٽ ۾ گھٽ ٻه `f64` قدرون واپس آڻيندي.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// وڌ ۾ وڌ ٻه `f32` قدرون واپس ڪري ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// وڌ ۾ وڌ ٻه `f64` قدرون واپس ڪري ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `y` کان `x` تائين نشاني نقل ڪري ٿو `f32` قدرن لاءِ.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `y` کان `x` تائين نشاني نقل ڪري ٿو `f64` قدرن لاءِ.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` کان گھٽ يا برابر برابر تمام وڏو انگيٽر موٽائيندو آهي.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` کان گھٽ يا برابر برابر تمام وڏو انگيٽر موٽائيندو آهي.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// نن00ن نن integن ننerن حصن کي `f32` کان وڌيڪ يا برابر برابر موٽائيندو آهي.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// نن00ن نن integن ننerن حصن کي `f64` کان وڌيڪ يا برابر برابر موٽائيندو آهي.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` جو جڙيل حصو ورجائي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` جو جڙيل حصو ورجائي ٿو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// `f32` کي ويجهي انٽيگرنٽ ڏي ٿو.
    /// جيڪڏهن دليل انٽيگر نه هجي غير معزز سچل نقطي جي رعايت کي وڌائي سگھي ٿو.
    pub fn rintf32(x: f32) -> f32;
    /// `f64` کي ويجهي انٽيگرنٽ ڏي ٿو.
    /// جيڪڏهن دليل انٽيگر نه هجي غير معزز سچل نقطي جي رعايت کي وڌائي سگھي ٿو.
    pub fn rintf64(x: f64) -> f64;

    /// `f32` کي ويجهي انٽيگرنٽ ڏي ٿو.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn nearbyintf32(x: f32) -> f32;
    /// `f64` کي ويجهي انٽيگرنٽ ڏي ٿو.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn nearbyintf64(x: f64) -> f64;

    /// `f32` کي ويجهي انٽيگرنٽ ڏي ٿو.صفر کان اڌ طرفو ڪيس رائونڊ ڪيو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// `f64` کي ويجهي انٽيگرنٽ ڏي ٿو.صفر کان اڌ طرفو ڪيس رائونڊ ڪيو.
    ///
    /// انهي اصل جو مستحڪم نسخو آهي
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// فلوٽ اضافو جيڪو الجبراڪ ضابطن جي بنياد تي اصلاح جي اجازت ڏي ٿو.
    /// فرض ڪيو داخلون فتني آهن.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// فليٽ ڪٽائڻ جيڪا الجبراڪ اصولن جي بنياد تي اصلاح جي اجازت ڏئي ٿي.
    /// فرض ڪيو داخلون فتني آهن.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// فلوٽ ضرب جيڪا الجبراڪ قاعدن جي بنياد تي اصلاح جي اجازت ڏئي ٿي.
    /// فرض ڪيو داخلون فتني آهن.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// فلوٽ ڊويزن جيڪا الجبراڪ ضابطن جي بنياد تي اصلاح جي اجازت ڏي ٿي.
    /// فرض ڪيو داخلون فتني آهن.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// فليٽ باقي رهي ٿو جيڪا الجبراڪ ضابطن جي بنياد تي ٺاهه جي اجازت ڏي.
    /// فرض ڪيو داخلون فتني آهن.
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// ايل ايل وي ايم جي ايڪسڪسيمڪس سان تبديل ڪريو ، جيڪا قيمت کان ٻاهرين قدرن جي بدلي ڪري سگهي ٿي
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] ۽ [`f64::to_int_unchecked`] طور تي استحڪام ڪيو ويو آهي.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// بيٽس جي تعداد کي عدد قسم جي `T` ۾ ڏيکاري ٿو
    ///
    /// هن intrinsic جو مستحڪم نسخو `count_ones` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// عدد قسم `T` ۾ انويسٽيبل بٽس (zeroes) جي تعداد کي واپسي ڏئي ٿو.
    ///
    /// هن intrinsic جو مستحڪم نسخو `leading_zeros` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// هڪ `x` قيمت `0` سان `T` جي ٿورڙي چوٽي موٽندي.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` وانگر ، پر اضافي غير محفوظ جئين اهو `undef` موٽائي ٿو جڏهن `x` سان `x` ڏنو وڃي ٿو.
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// انٽيگري قسم `T` ۾ ٽريلنگ بيس سيٽ جي نمبر (zeroes) کي واپسي ڏئي ٿو.
    ///
    /// هن intrinsic جو مستحڪم نسخو `trailing_zeros` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// هڪ `x` قيمت `0` سان `T` جي ٿورڙي چوٽي موٽندي:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` وانگر ، پر اضافي غير محفوظ جئين اهو `undef` موٽائي ٿو جڏهن `x` سان `x` ڏنو وڃي ٿو.
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// بائيٽ کي عدد قسم `T` ۾ رد ڪري ٿو.
    ///
    /// هن intrinsic جو مستحڪم نسخو `swap_bytes` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// بٽس کي انڌيري قسم `T` ۾ ريورس ڪري ٿو.
    ///
    /// هن intrinsic جو مستحڪم نسخو `reverse_bits` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// مڪمل ٿيل اضافي جاچ ڪئي.
    ///
    /// هن intrinsic جو مستحڪم نسخو `overflowing_add` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// انجام ڏنل عدد گھٽائڻ کي انجام ڏيو
    ///
    /// هن intrinsic جو مستحڪم نسخو `overflowing_sub` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// انجام ڏنل عدد ضربي انجام ڏيو
    ///
    /// هن intrinsic جو مستحڪم نسخو `overflowing_mul` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ھڪڙي پوري ڊويزن کي انجام ڏئي ٿو ، نتيجي ۾ اڻ behaviorاڻايل رويو جتي `x % y != 0` يا `y == 0` يا `x == T::MIN && y == -1` آھي
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// ھڪڙي غير جانچ ٿيل ڀا divisionي کي انجام ڏيو ، نتيجي ۾ اڻ behaviorاڻايل رويي جتي `y == 0` يا `x == T::MIN && y == -1`
    ///
    ///
    /// هن اندروني لاءِ محفوظ لفافا `checked_div` طريقو ذريعي انٽيگر پرائمري تي موجود آهن.
    /// مثال طور،
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// ھڪڙي غير چيڪ ٿيل ڀا divisionي جي باقي بچا ڏيکاري ٿو ، اڻ سڌريل رويي جي نتيجي ۾ جڏھن `y == 0` يا `x == T::MIN && y == -1`
    ///
    ///
    /// هن اندروني لاءِ محفوظ لفافا `checked_rem` طريقو ذريعي انٽيگر پرائمري تي موجود آهن.
    /// مثال طور،
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// اڻ چيڪ ٿيل کاٻي پاسي واري شفٽ جو انجام ڏي ٿو ، اڻ سڌريل رويو جي نتيجي ۾ جڏهن `y < 0` يا `y >= N` ، جتي ن ب جي ٽ جي چوٽي آهي.
    ///
    ///
    /// هن اندروني لاءِ محفوظ لفافا `checked_shl` طريقو ذريعي انٽيگر پرائمري تي موجود آهن.
    /// مثال طور،
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// اڻ چيڪ ٿيل سا shiftي شفٽ جو انجام ڏيو ، اڻ سڌريل رويو جي نتيجي ۾ جڏهن `y < 0` يا `y >= N` ، جتي ن ب جي ٽ جي چوٽي آهي.
    ///
    ///
    /// هن اندروني لاءِ محفوظ لفافا `checked_shr` طريقو ذريعي انٽيگر پرائمري تي موجود آهن.
    /// مثال طور،
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// غير چيڪ ٿيل اضافي جو نتيجو موٽائي ٿو ، اڻ سڌريل رويو جي نتيجي ۾ جڏهن `x + y > T::MAX` يا `x + y < T::MIN`.
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// هڪ غير معائنو ٿيل نن subڙي گهٽتائي جو نتيجو موٽائي ٿو ، نتيجي ۾ اڻ سڌريل رويو جڏهن `x - y > T::MAX` يا `x - y < T::MIN`.
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// غير چيڪ ٿيل ضرب جو نتيجو موٽائي ٿو ، اڻ سڌريل رويي جي نتيجي ۾ جڏهن `x *y > T::MAX` يا `x* y < T::MIN`.
    ///
    ///
    /// هن intrinsic جو هڪ مستحڪم ساٿي نه آهي.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// بائیں گردش انجام ڏيو.
    ///
    /// هن intrinsic جو مستحڪم نسخو `rotate_left` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// صحيح گھمندي انجام ڏيو.
    ///
    /// هن intrinsic جو مستحڪم نسخو `rotate_right` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// واپسي (a + b) موڊ 2 <sup>N</sup> ، جتي N bit ۾ T جي چوڻي آهي.
    ///
    /// هن intrinsic جو مستحڪم نسخو `wrapping_add` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// واپسي (a ، b) mod 2 <sup>N</sup> ، جتي N بٽس جي T جي چوٽي آهي.
    ///
    /// هن intrinsic جو مستحڪم نسخو `wrapping_sub` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// واپسي (a * b) موڊ 2 <sup>N</sup> ، جتي N bit ۾ T جي چوڻي آهي.
    ///
    /// هن intrinsic جو مستحڪم نسخو `wrapping_mul` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// `a + b` کي شمار ڪري ٿو ، انگن اکرن تي سيراب ڪرڻ.
    ///
    /// هن intrinsic جو مستحڪم نسخو `saturating_add` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// `a - b` کي شمار ڪري ٿو ، انگن اکرن تي سيراب ڪرڻ.
    ///
    /// هن intrinsic جو مستحڪم نسخو `saturating_sub` طريقي جي ذريعي انٽيگريٽيم پرائميوٽس تي موجود آهن.
    /// مثال طور،
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' ۾ فرق ڪرڻ واري فرق جي قيمت ڏي ٿو ؛
    /// جيڪڏهن `T` ڪو تعصب نه آهي ، `0` واپس ڪري ٿو.
    ///
    /// ھن اندروني نسخ جو مستحڪم نسخو [`core::mem::discriminant`](crate::mem::discriminant) آھي.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// قسم `T` ڪٽرن جي وارين نمبرن کي واپس آڻيندي `usize` ڏانھن؛
    /// جيڪڏهن `T` ڪي به حرفا ناهن ، `0` موٽائي ٿو.غير آبادگار وارين ڳڻپ ڪئي ويندي.
    ///
    /// هن اندروني جو مستحڪم نسخو [`mem::variant_count`] آهي.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust جي "try catch" تعمير جيڪو ڪم پوائنٽر `try_fn` کي دعوت ڏئي ٿو ڊيٽا پوائنٽر `data` سان.
    ///
    /// ٽيون دليل هڪ فنڪشن آهي جنهن کي سڏيو ويندو آهي جيڪڏهن panic ٿئي ٿي.
    /// اهو فنڪشن ڊيٽا پوائنٽر ۽ پوائنٽر کي هدف-مخصوص استثنا واري اعتراض ڏانهن وٺي ويو جيڪو پڪڙجي ويو.
    ///
    /// وڌيڪ معلومات لاءِ مرتب ڪندڙ ذريعو ڏسو ۽ std جا ڪيچ پلي.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// ايل ڊي وي ايم ايم جي مطابق هڪ `!nontemporal` اسٽور خارج ڪري ٿو (انهن جا دستاويز ڏسو).
    /// ممڪن ڪڏهن به مستحڪم نه ٿيندو.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// تفصيل لاءِ `<*const T>::offset_from` جي دستاويز ڏسو.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// تفصيل لاءِ `<*const T>::guaranteed_eq` جي دستاويز ڏسو.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// تفصيل لاءِ `<*const T>::guaranteed_ne` جي دستاويز ڏسو.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// برابر وقت تي مختص ڪريو.رن ٽائيم تي نه سڏيو وڃي.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// ڪجهه ڪم هتي بيان ڪيا ويا آهن ڇاڪاڻ ته اهي مستحڪم طور تي هن ماڊل ۾ دستياب ٿي دستياب ٿي ويا آهن.
// <https://github.com/rust-lang/rust/issues/15702> ڏسو.
// (`transmute` پڻ ھن درجي ۾ اچي ٿو ، پر ان جي چڪاس جي ڪري ان کي لپي نه سگھجي ٿو `T` ۽ `U` ھڪڙو ئي سائيز آھن.)
//

/// چيڪ ڪريو ته ڇا `ptr` `align_of::<T>()` جي حوالي سان صحيح طور سان گڏ ٺاھيو ويو آھي.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `src` کان `dst` تائين `count *size_of::<T>()` بائٽس نقل ڪري ٿو.ذريعو ۽ منزلون* نه * چٽيون.
///
/// ياداشت وارن علائقن لاءِ جيڪي شايد اوپلو ڪري سگھن ٿا ، بدران [`copy`] استعمال ڪريو.
///
/// `copy_nonoverlapping` اھم طور تي سي جي ايڪسڪسيمڪس جي برابر آھي ، پر دليل جي حڪم سان تبادلو ڪيو ويو آھي.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// جيڪڏهن هيٺين شرطن مان ڪنهن جي خلاف ورزي ڪئي وئي هجي ته رويي کي غير تعين ڪيو ويندو آهي:
///
/// * `src` `count * size_of::<T>()` بائٽس جي پڙهائي لاءِ [valid] هجڻ ضروري آهي.
///
/// * `dst` `count * size_of::<T>()` بائٽس جي لکڻين لاءِ [valid] هجڻ ضروري آهي.
///
/// * ٻئي `src` ۽ `dst` کي گڏ ڪرڻ لازمي آھي.
///
/// * يادگار جو علائقو `src` کان شروع ڪري ٿو ڳڻپ جي ماپ سان *
///   سائيز_ج: :<T>() "بائٽس * * نه هجڻ گهرجي ياداشت جي علائقي سان `dst` تي ساڳيو سائيز سان شروع ٿي.
///
/// جهڙوڪ [`read`] ، `copy_nonoverlapping` `T` جي ھڪڙي ننwiseڙي ڪاپي ٺاھي ٿو ، قطع نظر ته ڇا `T` آھي [`Copy`].
/// جيڪڏهن `T` [`Copy`] نه آهي ، `*src` کان شروع ٿيندڙ علائقي* ٻنهي *قدرن کي استعمال ڪندي ۽ `* dst` کان شروع ٿيندڙ علائقو [violate memory safety][read-ownership] ڪري سگھي ٿو.
///
///
/// ياد رکجو جيتوڻيڪ اثرائتي ڪاپي ڪيل سائيز ("شمار * سائيز_ف: :)<T>()") `0` آھي ، اشارو ڪندڙ غير اين ايل ايل هجڻ گھرجي ۽ صحيح طور تي ھلندڙ آھي.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// دستي طور تي [`Vec::append`] لاڳو ڪريو:
///
/// ```
/// use std::ptr;
///
/// /// `src` جي سڀني عنصرن کي `dst` ۾ منتقل ڪري ٿو ، `src` کي خالي ڪري ڇڏي ٿو.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // انهي کي يقيني بڻايو وڃي ته `dst` وٽ تمام گهڻي گنجائش آهي `src` جي سڀني کي رکڻ لاءِ.
///     dst.reserve(src_len);
///
///     unsafe {
///         // ڪال آف آفسيٽ هميشه محفوظ هوندي آهي ڇاڪاڻ ته `Vec` ڪڏهن به `isize::MAX` بائٽس کان وڌيڪ مختص نه ڪندو.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // ان جي مواد کي ڇڏي ڏيڻ جي بغير `src` ٽريڪ ڪيو.
///         // اسان Zopanics0Z ھيٺ اڳتي وڌڻ واري صورت ۾ ، مسئلن کان بچڻ لاءِ هي پهريون ڪريون ٿا.
///         src.set_len(0);
///
///         // ٻئي علائقا اوپلو نٿا ڪري سگهن ڇاڪاڻ ته چالو حوالا عرف نه آهن ۽ ٻه مختلف vectors هڪ ئي ميموري جا مالڪ نٿا ٿي سگھن.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst` کي خبر ڏيو ته اهو هاڻي `src` جو مواد رکي ٿو.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: صرف چڪاس وقت تي اهي چڪاس ڪريو
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // نه ڏسڻ لاءِ ڇڪڻ جي تڪليف نن impactي رکڻ لاءِ.
        abort();
    }*/

    // حفاظت: حفاظت جو معاهدو `copy_nonoverlapping` هجڻ گھرجي
    // سڏيندڙ طرفان منظور ٿيو.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `src` کان `dst` تائين `count * size_of::<T>()` بائٽس نقل ڪري ٿو.ذريعو ۽ منزل اوورلوپ ٿي سگهي ٿي.
///
/// جيڪڏهن ذريعو ۽ منزل *ڪڏهن به* اوورلوپ نه ڪندو ، [`copy_nonoverlapping`] بدران استعمال ٿي سگهي ٿو.
///
/// `copy` اھم طور تي سي جي ايڪسڪسيمڪس جي برابر آھي ، پر دليل جي حڪم سان تبادلو ڪيو ويو آھي.
/// ڪاپي ٿئي ٿي ifڻ ته بائٽس `src` کان عارضي طور تي پيش ڪيا ويا ۽ پوءِ صف کان `dst` تائين ڪاپي ڪيو ويو.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// جيڪڏهن هيٺين شرطن مان ڪنهن جي خلاف ورزي ڪئي وئي هجي ته رويي کي غير تعين ڪيو ويندو آهي:
///
/// * `src` `count * size_of::<T>()` بائٽس جي پڙهائي لاءِ [valid] هجڻ ضروري آهي.
///
/// * `dst` `count * size_of::<T>()` بائٽس جي لکڻين لاءِ [valid] هجڻ ضروري آهي.
///
/// * ٻئي `src` ۽ `dst` کي گڏ ڪرڻ لازمي آھي.
///
/// جهڙوڪ [`read`] ، `copy` `T` جي ھڪڙي ننwiseڙي ڪاپي ٺاھي ٿو ، قطع نظر ته ڇا `T` آھي [`Copy`].
/// جيڪڏهن `T` [`Copy`] نه آهي ، `*src` کان شروع ٿيندڙ علائقي ۾ ٻئي قدر استعمال ڪندي ۽ `* dst` جي شروعات واري علائقي کي [violate memory safety][read-ownership] ڪري سگھي ٿو.
///
///
/// ياد رکجو جيتوڻيڪ اثرائتي ڪاپي ڪيل سائيز ("شمار * سائيز_ف: :)<T>()") `0` آھي ، اشارو ڪندڙ غير اين ايل ايل هجڻ گھرجي ۽ صحيح طور تي ھلندڙ آھي.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// مؤثر طريقي سان ھڪڙي Rust vector ھڪڙي غير محفوظ بفر مان ٺاھيو.
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` لازمي طور تي صحيح ھجي ان جي قسم ۽ غير صفر لاءِ.
/// /// * `ptr` لازمي طور تي `T` قسم جي `elts` سان لاڳاپيل عنصر جي پڙهڻ لاءِ صحيح هجڻ گهرجي.
/// /// * اهي عنصر ڪم ڪرڻ کان پوءِ لازمي طور تي استعمال نه ڪيا وڃن جيستائين `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // حفاظت: اسان جي اوليت يقيني بڻائي ٿي ته ذريعو هڪجهڙائي ۽ صحيح آهي
///     // ۽ ايڪسڪسيمڪس انهي کي يقيني بڻائي ٿو ته اسان وٽ انهن جي لکڻ لاءِ قابل جڳهه جڳهه آهي.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // حفاظت: اسان انهي کي سڀ کان وڌيڪ قابليت سان بڻائي ڇڏيو ،
///     // ۽ اڳوڻي `copy` انھن عنصرن جي شروعات ڪئي آھي.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: صرف چڪاس وقت تي اهي چڪاس ڪريو
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // نه ڏسڻ لاءِ ڇڪڻ جي تڪليف نن impactي رکڻ لاءِ.
        abort();
    }*/

    // حفاظت: `copy` لاءِ حفاظتي معاهدو ڪالر کان برقرار رکيو وڃي.
    unsafe { copy(src, dst, count) }
}

/// X0 `dst` کان `val` تي شروع ٿيندڙ ميموري جي `count * size_of::<T>()` بائٽس سيٽ ڪري ٿو.
///
/// `write_bytes` سي جي ايڪسڪسيمڪس سان ساڳيو آهي ، پر ايڪسڪسيمڪس بيڪس کي `val` ڏانهن سيٽ ڪري ٿو.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// جيڪڏهن هيٺين شرطن مان ڪنهن جي خلاف ورزي ڪئي وئي هجي ته رويي کي غير تعين ڪيو ويندو آهي:
///
/// * `dst` `count * size_of::<T>()` بائٽس جي لکڻين لاءِ [valid] هجڻ ضروري آهي.
///
/// * `dst` لازمي طور تي ترتيب ڏيڻ گهرجي.
///
/// اضافي طور تي ، ڪالر انهي ڳالهه کي يقيني بڻائڻ گهرجي ته ياداشت جي ڏنل علائقي کي `count * size_of::<T>()` بائٽس لکڻ جي نتيجي ۾ `T` جي صحيح قدر ۾.
/// ايڪس اين ايڪس ايڪس وانگر ميموري جو علائقو استعمال ڪندي جنهن ۾ `T` جي غلط قيمت شامل آهي غير تعين ٿيل رويو آهي.
///
/// ياد رکجو جيتوڻيڪ اثرائتي ڪاپي ڪيل سائيز ("شمار * سائيز_ف: :)<T>()") `0` آھي ، پوائنٽر غير NULL ۽ صحيح طور تي ٺاھيو وڃي.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// هڪ غلط ويليو ٺاهڻ
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // نيل پوائنٽر سان `Box<T>` مٿان چڙهائي اڳوڻي رکيل قيمت کي ڇڪي ٿو.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // انهي موقعي تي ، `v` استعمال ڪندي يا گهٽائڻ جي نتيجي ۾ اڻ behaviorاتل رويي جا.
/// // drop(v); // ERROR
///
/// // اڃا به `v` "uses" ليڪ ڪري رهيو آهي ، ۽ تنهنڪري غير معياري رويي آهي.
/// // mem::forget(v); // ERROR
///
/// // حقيقت ۾ ، ايڪس قسم ايڪس بنيادي قسم جي ترتيب جي غير مطابقت رکندڙن مطابق غلط آهي ، تنهن ڪري *ڪنهن* آپريشن ان کي ڇهڻ غير متعين ٿيل رويو آهي.
/////
/// // اچو v2 =v ؛//غلطي
///
/// unsafe {
///     // اسان کي بدران صحيح قيمت ۾ آڻڻ ڏيو
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // هاڻي دٻي ٺيڪ آهي
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // حفاظت: `write_bytes` لاءِ حفاظتي معاهدو ڪالر کان برقرار رکيو وڃي.
    unsafe { write_bytes(dst, val, count) }
}