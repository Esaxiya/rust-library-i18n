//! ترتيب ڏيڻ ۽ نسبت جي.
//!
//! هن ماڊل قدر ترتيب ڏيڻ ۽ قدرن کي ترتيب ڏيڻ جي مختلف اوزارن تي مشتمل آهي.سمري ۾:
//!
//! * [`Eq`] ۽ [`PartialEq`] traits آهن جيڪي توهان کي ترتيب سان قدرن جي وچ ۾ مجموعي ۽ جزوي مساوات جي وضاحت ڪرڻ جي اجازت ڏين ٿا.
//! انهن کي لاڳو ڪرڻ `==` ۽ `!=` هلائيندڙن کي اوورلوڊ ڪري ٿو.
//! * [`Ord`] ۽ [`PartialOrd`] traits آهن جيڪي توهان کي ترتيب سان قدرن جي وچ ۾ مجموعي ۽ جزوي ترتيب بيان ڪرڻ جي اجازت ڏين ٿا.
//!
//! انهن کي لاڳو ڪرڻ `<` ، `<=` ، `>` ، ۽ `>=` آپريٽرز کي اوورلوڊ ڪري ٿو.
//! * [`Ordering`] هڪ اينيمڪس [`Ord`] ۽ [`PartialOrd`] جي بنيادي ڪمن طرفان واپس ڪئي وئي آهي ، ۽ هڪ ترتيب ڏيڻ جي وضاحت ڪندو آهي.
//! * [`Reverse`] اھو آھي جيڪو ھڪڙي ترتيب ڏيڻ جي اجازت ڏئي ٿو.
//! * [`max`] ۽ [`min`] اھڙا آھن جيڪي [`Ord`] ٺاھندا آھن ۽ توھان کي ٻن قدرن جي وڌ ۾ وڌ يا گھٽ کي ڳولڻ جي اجازت ڏين ٿا.
//!
//! وڌيڪ تفصيلن لاءِ ڏسو ، فهرست ۾ هر شيءَ جي متعلقہ دستاويز ڏسو.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// مساوات جي مقابلي لاءِ Trait جيڪي [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) آھن.
///
/// اهو trait جزوي مساوات جي اجازت ڏئي ٿو ، انهن قسمن لاءِ جيڪي مڪمل مساوات سان تعلق نه رکن.
/// مثال طور ، سچل پوائنٽ جي نمبرز `NaN != NaN` ۾ ، تنهنڪري فلوٽنگ پوائنٽ جا نمبر `PartialEq` لاڳو ڪن ٿا پر [`trait@Eq`] نه.
///
/// عام طور تي ، برابر هجڻ لازمي آهي (سڀني `a` ، `b` ، `c` قسم جي `A` ، `B` ، `C`):
///
/// - **سمائيٽري**: جيڪڏهن `A: PartialEq<B>` ۽ `B: PartialEq<A>` ، ته پوءِ **"a==b` جو مطلب آهي b==a`**؛۽
///
/// - **منتقلي**: جيڪڏهن `A: PartialEq<B>` ۽ `B: PartialEq<C>` ۽ "A:
///   ھڪڙي حصو<C>پوءِ ،** ** a==b`۽ `b == c` جو مطلب`a==c` **.
///
/// ياد رک ته `B: PartialEq<A>` (symmetric) ۽ `A: PartialEq<C>` (transitive) نقاب موجود هجڻ تي مجبور ڪونه آهن ، پر اهي ضرورتون جڏهن به موجود آهن انهن تي لاڳو ٿينديون آهن.
///
/// ## Derivable
///
/// ھي trait `#[derive]` سان استعمال ڪري سگھجي ٿو.جڏهن ڊائريڪٽ تي "حاصل ڪريو" ، ٻه صورتون برابر آهن جيڪڏهن سڀئي شعبا برابر آهن ، ۽ برابر نه آهن جيڪڏهن فيلڊ برابر نه آهن.جڏهن اينئيز تي `ڊي مايوس ڪريو` ، هر قسم پنهنجو پاڻ لاءِ برابر آهي ۽ ٻين قسمن جو برابر نه آهي.
///
/// ## آئون `PartialEq` کي ڪيئن لاڳو ڪري سگهان ٿو؟
///
/// `PartialEq` صرف [`eq`] طريقي سان عمل ڪرڻ جي ضرورت آهي.[`ne`] انهي جي لحاظ سان طئي ٿيل طور تي وضاحت ڪئي وئي آهي.[`ne`] جو ڪو به دستياب عمل درآمد *لازمي طور* انهي قانون جو احترام ڪرڻ گهرجي ته [`eq`] [`ne`] جي هڪ جڙيل آهي.اهو آهي ، `!(a == b)` جيڪڏهن ۽ صرف جيڪڏهن `a != b`.
///
/// `PartialEq` ، [`PartialOrd`] ، ۽ [`Ord`]*جي عمل سان لازمي* ھڪ ٻئي سان متفق ٿيڻ.اهو traits مان ڪجهه حاصل ڪندي پاڻ سان غلطي ڪرڻ آسان آهي ۽ ٻين کي دستي طور تي لاڳو ڪرڻ آسان آهي.
///
/// هڪ ڊومين جو مثال عمل درآمد ، جنهن ۾ ٻه ڪتاب هڪ ئي ڪتاب سمجهي وڃي ٿي ، جيڪڏهن ان جا ISBN ملن ٿا ، جيتوڻيڪ جيڪڏهن انهن شڪلن ۾ فرق آهي:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## آئون ٻن مختلف قسمن جو ڪيئن مقابلو ڪري سگهان ٿو؟
///
/// قسم جنهن سان توهان مقابلو ڪري سگهو ٿا سنڀاليو ويو آهي PartialEq جي قسم پيمائٽر.
/// مثال طور ، اچو ته اڳوڻو ڪوڊ ٿورڙو ڪريون
///
/// ```
/// // حاصل ڪرڻ جو ڪارڻ آهي<BookFormat>==<BookFormat>ڀيٽيو
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // لاڳو ڪريو<Book>==<BookFormat>ڀيٽيو
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // لاڳو ڪريو<BookFormat>==<Book>ڀيٽيو
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book` کان `impl PartialEq<BookFormat> for Book` تبديل ڪرڻ سان ، اسان اجازت ڏين ٿا "ڪتاب فروٽ" کي "ڪتاب" جي مقابلي سان.
///
/// مٿي ڏنل هڪ اهڙو مقابلو ، جيڪو بناوت جي ڪجهه شعبن کي نظرانداز ڪري ، خطرناڪ ٿي سگهي ٿو.اهو آساني سان جزوي مساوات جي رشتي جي گهرج جي اڻ violationاتل خلاف ورزي تي رھي سگھي ٿو.
/// مثال طور ، جيڪڏهن اسان `BookFormat` لاءِ `PartialEq<Book>` جي مٿين نفاذ کي برقرار رکيو ۽ `PartialEq<Book>` لاءِ `PartialEq<Book>` جو هڪ نفاذ شامل ڪيو (يا ته هڪ `#[derive]` ذريعي يا دستي عمل جي ذريعي پهرين مثال کان) پوءِ نتيجو ٽرانزيوٽي جي خلاف ورزي ڪندو.
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// اھو طريقو آزمائي ٿو `self` ۽ `other` قدرون برابر آھن ، ۽ استعمال ٿيل آھي `==`
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// ھي طريقو `!=` لاءِ آزمائي ٿو.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// ماخوذ ميڪرو trait `PartialEq` جو نقشو پيدا ڪري ٿو.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// مساوات جي مقابلي لاءِ Trait جيڪي [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) آھن.
///
/// ان جو مطلب ، `a == b` ۽ `a != b` جي سخت جھيڙن جي علاوه ، برابر هجڻ لازمي آھي (سڀ `a` ، `b` ۽ `c`):
///
/// - reflexive: `a == a`;
/// - سمميٽ: `a == b` مطلب `b == a` ؛۽
/// - منتقلي: `a == b` ۽ `b == c` مطلب `a == c` ڪري ٿو.
///
/// ھي ملڪيت گڏ ڪندڙ طرفان چڪاس نه ٿي ڪري سگھجي ، ۽ تنھنڪري `Eq` مطلب [`PartialEq`] کي ، ۽ ھن کان وڌيڪ ڪو طريقو ڪونھي.
///
/// ## Derivable
///
/// ھي trait `#[derive]` سان استعمال ڪري سگھجي ٿو.
/// جڏهن `ڊائريڪٽ` ، ڇاڪاڻ ته `Eq` وٽ اضافي طريقا نه آهي ، اهو صرف مرتب کي informاڻيندو آهي ته اهو جزوي مساوات جي نسبت جي بجاءِ هڪ مساوات وارو تعلق آهي.
///
/// ياد رکجو ته `derive` حڪمت عملي جي سڀني شعبن `Eq` جي ضرورت آهي ، جيڪي هميشه نه چاهيندا آهن.
///
/// ## آئون `Eq` کي ڪيئن لاڳو ڪري سگهان ٿو؟
///
/// جيڪڏهن توهان `derive` حڪمت عملي استعمال نٿا ڪري سگهو ، وضاحت ڪريو ته توهان جو قسم `Eq` لاڳو ڪري ٿو ، جنهن جو ڪوبه طريقو ناهي:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // اهو طريقو صرف#طرفان حاصل ڪرڻ لاءِ استعمال ڪيو ويندو آهي ته اهو مڃي ٿو ته هر قسم جو هڪ جزو پنهنجو پاڻ کي لاڳو ڪري ٿو ، موجوده حاصل ٿيندڙ بنيادي meansانچي جو مطلب آهي trait تي طريقو استعمال ڪرڻ کان سواءِ اهو زور لڳائڻ تمام گهڻو ناممڪن آهي.
    //
    //
    // اهو ڪڏهن به هٿ سان لاڳو نه ٿيڻ گهرجي.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// ماخوذ ميڪرو trait `Eq` جو نقشو پيدا ڪري ٿو.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: اها جوڙجڪ فقط#[derive] طرفان استعمال ٿئي ٿي
// يقين ڏياريو ته هر قسم جي هر حصي ۾ ايق لاڳو ٿئي ٿي.
//
// ھي جوڙجڪ استعمال ڪندڙ ڪوڊ ۾ ڪڏهن به ظاھر ٿيڻ گھرجي.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// هڪ `Ordering` ٻن قدرن جي وچ ۾ مقابلي جو نتيجو آهي.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// هڪ آرڊر جتي هڪ نسبت وارو قدر ٻئي کان گهٽ آهي.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// هڪ آرڊر جتي هڪ نسبت واري قدر ٻئي جي برابر آهي.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// هڪ آرڊر جتي هڪ نسبت وارو قدر ٻئي کان وڌيڪ آهي.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// ايڪس آرڪس کي واپسي ڏئي ٿو جيڪڏهن آرڊرنگ `Equal` ويئرٽ آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// ايڪس آرڪس کي واپسي ڏئي ٿو جيڪڏهن آرڊرنگ `Equal` قسم ناهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// ايڪس آرڪس کي واپسي ڏئي ٿو جيڪڏهن آرڊرنگ `Less` ويئرٽ آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// ايڪس آرڪس کي واپسي ڏئي ٿو جيڪڏهن آرڊرنگ `Greater` ويئرٽ آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// ايڪس آرڪس کي واپسي ڏئي ٿو جيڪڏهن آرڊرنگ `Less` يا `Equal` ورجن آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// ايڪس آرڪس کي واپسي ڏئي ٿو جيڪڏهن آرڊرنگ `Greater` يا `Equal` ورجن آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` تي ريورس ڪندو آهي.
    ///
    /// * `Less` `Greater` ٿي وڃي ٿو.
    /// * `Greater` `Less` ٿي وڃي ٿو.
    /// * `Equal` `Equal` ٿي وڃي ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي رويي
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// ھي طريقو مقابلي کي ريورس ڪرڻ لاءِ استعمال ڪري سگھجي ٿو.
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // نن largestي کان نن smallestڙي کان وٺي آرٽيڪل ترتيب ڏيو.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// ٻن نظمن جي قطار.
    ///
    /// `self` کي واپسي ڏئي ٿو جڏهن اهو `Equal` ناهي.ٻي صورت ۾ `other` موٽائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// ڏنل ڪارڪردگي سان ترتيب ڏيڻ ۾ تبديلي.
    ///
    /// `self` واپس اچي ٿو جڏهن اهو `Equal` ناهي.
    /// ٻي صورت ۾ `f` کي ڪال ڪري ٿو ۽ نتيجو موٽائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// ريورس ترتيب ڏيڻ لاءِ مددگار مددگار.
///
/// هن جوڙجڪ هڪ مددگار آهي ايڪس آرڪس وانگر ڪم سان ۽ استعمال ڪري سگهجي ٿو استعمال ڪري سگھجي ٿو ڪنجي حصن جي هڪ آرڊر کي ترتيب ڏيڻ لاءِ.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait قسمن جي لاء جيڪي [total order](https://en.wikipedia.org/wiki/Total_order) ٺاهيندا آهن.
///
/// هڪ آرڊر ڪل آرڊر آهي جيڪڏهن اهو آهي (سڀ `a` ، `b` ۽ `c` لاءِ):
///
/// - ڪل ۽ انجيميٽرڪ: بلڪل `a < b` ، `a == b` يا `a > b` سچ آهي ؛۽
/// - منتقلي ، `a < b` ۽ `b < c` مطلب `a < c`.ٻئي `==` ۽ `>` لاءِ ساڳيو ئي هئڻ لازمي آهي
///
/// ## Derivable
///
/// ھي trait `#[derive]` سان استعمال ڪري سگھجي ٿو.
/// جڏهن تحرڪ تي ڊي حاصل ڪريو ، اهو اسٽيڪ ميمبرن جي مٿين کان هيٺ ڏنل اعلى حڪم جي بنياد تي [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ترتيب ڏيندو.
///
/// جڏهن `ماصول تي ڊي حاصل ڪريو ، مختلف قسمون انهن جي مٿان کان هيٺين طرف امتياز جي ترتيب ڏنل آهن.
///
/// ## ليڪسيڪوگرافڪ مقابلو
///
/// ليڪسيڪوگرافڪ مقابلو هيٺين ملڪيت سان گڏ هڪ آپريشن آهي:
///  - ٻن تسلسل عنصري سان عنصر کان مقابلو ڪيو ويو.
///  - پهرين بي قاعدي وارو عنصر بيان ڪري ٿو ته ترتيب ٻئي درجي کان گهٽ يا وڌيڪ گهٽ آهي.
///  - جيڪڏھن ھڪڙي تسلسل ٻئي جي اڳياڙي آھي ، نن sequenceڙو تسلسل ٻين کان گھٽ لساني لحاظ کان گھٽ آھي.
///  - جيڪڏهن ٻن تسلسل جا برابر عنصر آهن ۽ هڪ ئي ڊيگهه جا آهن ، ته اهي ترتيب لسانياتي طور برابر آهن.
///  - هڪ خالي تسلسل ، ڪنهن به خالي تسلسل جي ڀيٽ ۾ ليسيسيگرافڪ لحاظ کان گهٽ آهي.
///  - ٻن خالي تشريحقي لحاظ کان برابر آهي.
///
/// ## آئون `Ord` کي ڪيئن لاڳو ڪري سگهان ٿو؟
///
/// `Ord` انهي جي ضرورت آهي ته قسم پڻ [`PartialOrd`] ۽ [`Eq`] هجي (جيڪو [`PartialEq`] جي ضرورت آهي).
///
/// پوءِ توھان کي لازمي آھي [`cmp`] لاءِ ھڪ تاڪيد عمل.توهان [`cmp`] پنهنجي قسم جي ميدانن تي استعمال ڪرڻ لاءِ ڪارآمد ڳوليندا.
///
/// [`PartialEq`] ، [`PartialOrd`] ، ۽ `Ord`*جي عمل سان لازمي* ھڪ ٻئي سان متفق ٿيڻ.
/// اھو آھي ، `a.cmp(b) == Ordering::Equal` جيڪڏھن ۽ جيڪڏھن جيڪڏھن `a == b` ۽ `Some(a.cmp(b)) == a.partial_cmp(b)` سڀ `a` ۽ `b` لاءِ.
/// اهو traits مان ڪجهه حاصل ڪندي پاڻ سان غلطي ڪرڻ آسان آهي ۽ ٻين کي دستي طور تي لاڳو ڪرڻ آسان آهي.
///
/// هتي هڪ مثال آهي جتي توهان صرف اونچائي ذريعي ماڻهن کي ترتيب ڏيڻ چاهيندا آهيو ، `id` ۽ `name` کي نظرانداز ڪرڻ:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// اهو طريقو `self` ۽ `other` جي وچ ۾ هڪ [`Ordering`] موٽائي ٿو.
    ///
    /// گڏيل طور تي ، `self.cmp(&other)` جيڪڏهن صحيح آهي ته اظهار `self <operator> other` سان ملندڙ آرڊر کي موٽائي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// وڌ کان وڌ ٻه قدر جي مقابلي ۽ واپسي ڪندو آهي.
    ///
    /// ٻئي دليل واپس آڻيندي جيڪڏهن مقابلي انهن جي برابر هجڻ جو عزم ڪري.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// ٻه قدر جي ڀيٽ ۾ گھٽ موازنہ ۽ واپس آڻيندي.
    ///
    /// پهريون دليل موٽائي ٿو جيڪڏھن موازنہ انھن جي برابر مقرر ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// ھڪڙي وقتي تائين ھڪڙي قدر محدود ڪريو.
    ///
    /// جيڪڏهن `self` `max` کان وڌيڪ آهي ، ۽ `min` جيڪڏهن `self` کي `min` کان گهٽ آهي ، واپس اچي ٿو.
    /// ٻي صورت ۾ هي `self` موٽائي ٿو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// ماخوذ ميڪرو trait `Ord` جو نقشو پيدا ڪري ٿو.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait قيمتون جي مقابلي ۾ مقابلو ڪري سگهجي ٿو.
///
/// مقابلو سڀني کي `a` ، `b` ۽ `c` جي لاءِ مطمئن ڪرڻ لازمي آهي:
///
/// - اسيمميٽري: جيڪڏهن `a < b` پوءِ `!(a > b)` ، گڏو گڏ `a > b` مطلب `!(a < b)` ؛۽
/// - منتقلي: `a < b` ۽ `b < c` مطلب `a < c`.ٻئي `==` ۽ `>` لاءِ ساڳيو ئي هئڻ لازمي آهي
///
/// نوٽ ڪيو ته انهن گهرجن جو مطلب اهو آهي ته trait پاڻ کي سم ۽ ٽرانزيڪل طريقي سان لاڳو ڪيو وڃي: جيڪڏهن `T: PartialOrd<U>` ۽ `U: PartialOrd<V>` ته پوءِ `U: PartialOrd<T>` ۽ "T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// ھي trait `#[derive]` سان استعمال ڪري سگھجي ٿو.جڏهن `آرٽيڪل تي اخذ ڪيو ويو ، اهو انهي جي ميمبرن جي مٿين کان هيٺ ڏنل اعلى حڪم جي بنياد تي هڪ لئڪسيڪوگرافڪ آرڊر پيدا ڪندو.
/// جڏهن `ماصول تي ڊي حاصل ڪريو ، مختلف قسمون انهن جي مٿان کان هيٺين طرف امتياز جي ترتيب ڏنل آهن.
///
/// ## آئون `PartialOrd` کي ڪيئن لاڳو ڪري سگهان ٿو؟
///
/// `PartialOrd` صرف [`partial_cmp`] طريقي جي عمل درآمد جي ضرورت آهي ، ٻين سان گڏ ڊفالٽ پليپشنن پاران ٺاهيل.
///
/// تنهن هوندي به اهو مختلف ممڪن آهي انهن قسمن لاءِ الڳ الڳ تي عمل درآمد ڪجي جن جي ڪا مڪمل ترتيب نه آهي.
/// مثال طور ، فلوٽنگ پوائنٽ نمبرز لاءِ ، `NaN < 0 == false` ۽ `NaN >= 0 == false` (cf.
/// آئي اي اي 754-2008 سيڪشن 5.11).
///
/// `PartialOrd` توهان جي قسم جي [`PartialEq`] هجڻ جي ضرورت آهي
///
/// [`PartialEq`] ، `PartialOrd` ، ۽ [`Ord`]*جي عمل سان لازمي* ھڪ ٻئي سان متفق ٿيڻ.
/// اهو traits مان ڪجهه حاصل ڪندي پاڻ سان غلطي ڪرڻ آسان آهي ۽ ٻين کي دستي طور تي لاڳو ڪرڻ آسان آهي.
///
/// جيڪڏهن توهان جو قسم [`Ord`] آهي ، توهان [`cmp`] استعمال ڪندي [`partial_cmp`] لاڳو ڪري سگهو ٿا:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// توهان شايد [`partial_cmp`] پنهنجي قسم جي شعبن تي استعمال ڪرڻ لاء ڪارائتو ڳولي سگهو ٿا.
/// هتي ايڪس هيڪسڪس وارن قسمن جو هڪ مثال آهي ، جيڪي فلوٽنگ پوائنٽ `height` فيلڊ آهن ، جن کي استعمال ڪرڻ لاءِ صرف هڪ ئي ميدان آهي:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// اهو طريقو `self` ۽ `other` قدرن جي وچ ۾ آرڊر ڏيندو آهي جيڪڏهن هڪ موجود هجي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// جڏهن مقابلو ناممڪن آهي:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// اھو طريقو `self` ۽ `other` کان گھٽ آھي ، ۽ `<` آپريٽر پاران استعمال ٿيل آھي.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// اھو طريقو `self` ۽ `other` کان گھٽ يا برابر جي جانچ ڪري ٿو ۽ `<=` آپريٽر استعمال ڪيو ويو آھي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// اھو طريقو `self` ۽ `other` کان وڌيڪ جاچ ڪري ٿو ۽ `>` آپريٽر پاران استعمال ٿيندو آھي.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// اھو طريقو `self` ۽ `other` کان وڌيڪ يا برابر جي جانچ ڪري ٿو ۽ `>=` آپريٽر استعمال ڪيو ويو آھي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// ماخوذ ميڪرو trait `PartialOrd` جو نقشو پيدا ڪري ٿو.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// ٻه قدر جي ڀيٽ ۾ گھٽ موازنہ ۽ واپس آڻيندي.
///
/// پهريون دليل موٽائي ٿو جيڪڏھن موازنہ انھن جي برابر مقرر ڪري ٿو.
///
/// اندروني طور تي [`Ord::min`] ڏانهن ھڪڙو عرف استعمال ڪري ٿو.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// مقرر ڪيل مقابلي واري فنڪشن جي حوالي سان گهٽ ۾ گهٽ ٻه قدر موٽائيندو آهي.
///
/// پهريون دليل موٽائي ٿو جيڪڏھن موازنہ انھن جي برابر مقرر ڪري ٿو.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// عنصر ڏيکاري ٿو جيڪو مخصوص فنڪشن مان گهٽ ۾ گهٽ قدر ڏئي ٿو.
///
/// پهريون دليل موٽائي ٿو جيڪڏھن موازنہ انھن جي برابر مقرر ڪري ٿو.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// وڌ کان وڌ ٻه قدر جي مقابلي ۽ واپسي ڪندو آهي.
///
/// ٻئي دليل واپس آڻيندي جيڪڏهن مقابلي انهن جي برابر هجڻ جو عزم ڪري.
///
/// اندروني طور تي [`Ord::max`] کي عرف استعمال ڪري ٿو.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// مخصوص مقابلي واري فنڪشن جي وڌ ۾ وڌ ٻن قدرن کي واپس ڏئي ٿو.
///
/// ٻئي دليل واپس آڻيندي جيڪڏهن مقابلي انهن جي برابر هجڻ جو عزم ڪري.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// عنصر ڏيکاري ٿو جيڪو مخصوص فنڪشن مان وڌ کان وڌ قدر ڏئي ٿو.
///
/// ٻئي دليل واپس آڻيندي جيڪڏهن مقابلي انهن جي برابر هجڻ جو عزم ڪري.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// ابتدائي قسمن لاءِ جزوي Eq ، Eq ، PartialOrd ۽ Ord کي لاڳو ڪرڻ
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // ھتان جو حڪم وڌيڪ اھم اسيمبلي ٺاھڻ ضروري آھي.
                    // وڌيڪ forاڻ لاءِ <https://github.com/rust-lang/rust/issues/63758> ڏسو.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // i8 ڏانهن ڪاسٽ ڪرڻ ۽ فرق کي آرڊرنگ ۾ بدلائڻ وڌيڪ بهتر اسيمبلي ٺاهيندو آهي.
            //
            // وڌيڪ forاڻ لاءِ <https://github.com/rust-lang/rust/issues/66780> ڏسو.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SAFETY: bool جئين i8 واپس 0 يا 1 ڏيکاري ٿو ، تنهن ڪري فرق ٻيو ڪجھ نٿو ٿي سگھي
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // ۽ اشارو

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}