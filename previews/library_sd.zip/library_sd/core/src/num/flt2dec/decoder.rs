//! فلوٽنگ پوائنٽ جي قدر کي انفرادي حصن ۽ غلطي جي حدن ۾ تبديل ڪري ٿو.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// اڻ سڌريل دستخط ٿيل قيمت ، جهڙوڪ:
///
/// - اصلي قدر `mant * 2^exp` جي برابر آهي.
///
/// - `(mant - minus)*2^exp` کان `(mant + plus)* 2^exp` جو ڪوبه نمبر اصل قدر ڏانھن گول ٿيندو.
/// رينج صرف ان وقت شامل آهي جڏهن `inclusive` `true` آهي.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// پيٽيل مينڊيسا.
    pub mant: u64,
    /// گھٽ غلطي جي حد.
    pub minus: u64,
    /// مٿين غلطي جي حد.
    pub plus: u64,
    /// حصيداري وڌائيندڙ بي بنياد 2 ۾.
    pub exp: i16,
    /// صحيح جڏهن غلطي جي حد شامل هوندي.
    ///
    /// IEEE 754 ۾ ، اهو سچ آهي جڏهن اصل منٿيسيا به هئي.
    pub inclusive: bool,
}

/// غير منع ٿيل قيمت.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// انفرافيشن ، يا ته مثبت يا منفي.
    Infinite,
    /// زيرو ، يا ته مثبت يا منفي.
    Zero,
    /// وڌيڪ ڊيڪڊيل فيلڊس سان فني نمبر.
    Finite(Decoded),
}

/// هڪ سچل نقطو جو قسم جنهن کي `decode`d ڪري سگهجي ٿو.
pub trait DecodableFloat: RawFloat + Copy {
    /// گھٽ ۾ گھٽ مثبت معمولي قيمت.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// واپسي واري واپسي کي واپسي (صحيح جڏهن منفي) ۽ `FullDecoded` قدر جئين سچل واري نقطي نمبر تان.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // پاڙيسري: (منٽ ، 2 ، ختم)-(منٽ ، ختم)-(منت + 2 ، ختم)
            // Float::integer_decode هميشه ظاهري کي بچائيندو آهي ، تنهنڪري منتر غير معمولي لاءِ طومار ڪيو ويندو آهي.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // پاڙيسري: (وڌ کان وڌ ، ختم ٿيڻ ، 1)-(گهٽ عام ، ختم)-(گهٽ عام + 1 ، ختم)
                // جتي وڌ کان وڌ=گهٽ معمولي * 2 ، 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // پاڙيسري: (منٽ ، 1 ، ختم)-(منٽ ، ختم)-(منت + 1 ، ختم)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}