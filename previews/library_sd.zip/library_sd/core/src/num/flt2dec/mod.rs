/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// جڏهن ته اها وڏي پئماني تي دستاويز ٿيل آهي ، اهو اصولي طور تي نجي آهي جنهن کي صرف جاچ جي لاءِ عوام بڻايو ويندو آهي.
// اسان کي نه روڪيو
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// ڊجيٽل نسل جي الگورتھم.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// سڀني کان نن minimumا نن ofا نن necessaryا نن necessaryا طريقا لازمي آھن مختصر ترين موڊ لاءِ.
///
/// اهو حاصل ڪرڻ غير معمولي طور تي گهٽجي ويو آهي ، پر اهو هڪ آهي سڀني کان نن numberن نتيجن جي حساب سان الگورٿم سان شڪل ڏيڻ جي وڌ ۾ وڌ اهم عددي انگن اکرن جو.
///
/// صحيح فارمولا `ceil(# bits in mantissa * log_10 2 + 1)` آهي.
pub const MAX_SIG_DIGITS: usize = 17;

/// جڏهن `d` ڊيمل نمبرز تي مشتمل هوندو ، آخري نمبر کي وڌايو ۽ پروپيگنڊا ڪيو.
/// ايندڙ ڊج ڪي ٿو جڏھن اھو causesيرائي ٿو لمبائي کي.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] سڀ نون آهن
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 وڌندڙ خرچ سان 1000..000 تائين گول
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // هڪ خالي بفر راؤنڊ اپ (ٿورڙو عجيب پر معقول)
            Some(b'1')
        }
    }
}

/// شڪل وارا حصا.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// صفر عددن جو تعداد ڏنو ويو.
    Zero(usize),
    /// لفظي نمبر 5 عددن تائين.
    Num(u16),
    /// بائٽس جي ڏنل لفظي ڪاپي.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// ڏنل حصي جي صحيح بائيٽ لمبائي واپس اچي ٿي.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// مهيا ڪيل بفر ۾ هڪ حصو لکي ٿو.
    /// جيڪڏهن بفر ڪافي نه آهي ته لکت واري بائٽس جو نمبر ، يا `None` ڏي ٿو.
    /// (اهو اڃا تائين بفر ۾ جزوي طور لکڻ وارا بائيٽ ڇڏي سگهي ٿو ؛ ان تي اعتبار نه ڪريو.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// فارميٽ جو نتيجو ھڪڙي يا وڌيڪ حصن تي مشتمل آھي.
/// اهو بائٽ بفر ڏانهن لکي يا مختص ڪيل اسٽرنگ ۾ تبديل ٿي سگهي ٿو.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// هڪ بائيٽ سلائس هڪ علامت جي نمائندگي ڪندي ، يا ته `""` ، `"-"` يا `"+"`.
    pub sign: &'static str,
    /// شڪل نشاني ۽ اختياري صفر پيڊنگ کان پوءِ ڏني ويندي.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// گڏيل فارميٽ وارو نتيجو بائيٽ بائيٽ جي ڊگري موٽندي آھي.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// مهيا ڪيل بفر ۾ سڀني شڪل وارا حصا لکي ٿو.
    /// جيڪڏهن بفر ڪافي نه آهي ته لکت واري بائٽس جو نمبر ، يا `None` ڏي ٿو.
    /// (اهو اڃا تائين بفر ۾ جزوي طور لکڻ وارا بائيٽ ڇڏي سگهي ٿو ؛ ان تي اعتبار نه ڪريو.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// فارميٽس ۾ ڏنل عددي عدد `0.<...buf...> * 10^exp` گهٽ ۾ گهٽ ڏنل تعداد ۾ ڪشميري انگن اکرن سان ڏنل آهن.
///
/// نتيجو مهيا ڪيل حصن جي ذخيري ڏانهن محفوظ ڪيو ويو آهي ۽ لکيل حصن جو هڪ حصو واپس ڪيو ويندو آهي.
///
/// `frac_digits` `buf` ۾ اصل حصن جي انگن اکرن کان گهٽ ٿي سگهي ٿو.
/// اهو نظرانداز ٿي ويندو ۽ مڪمل انگ اکر ڇپجي سگهندا.اهو صرف ڇپيل عددن کان پوءِ اضافي صفر کي ڇپائڻ لاءِ استعمال ڪيو ويندو آهي.
/// اھڙي طرح `frac_digits` of 0 جو مطلب آھي اھو صرف پرنٽ ٿيل انگ اکر پرنٽ ڪندو ۽ ٻيو ڪجھ به ناھي.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // جيڪڏهن آخري عدد واري پوزيشن تي پابندي آهي ، `buf` کي فرض ڪيو ويندو آهي ته مجازي زروسو سان ڇڏي ڇڏيو.
    // مجازي زيرو جو تعداد ، `nzeroes` ، `max(0, exp + frac_digits - buf.len())` جي برابر آهي ، انهي ڪري ته آخري عددي `exp - buf.len() - nzeroes` جي پوزيشن `-frac_digits` کان وڌيڪ ناهي:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |زيرو |پورو
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ X 10
    //    |                  |           |
    // 10 ^ ختم 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` انفرادي طور تي هر ڪيس جي حساب سان حساب ڪيو ويندو آهي ته جيئن گهڻي خرابي کان بچي سگهجي.
    //

    if exp <= 0 {
        // بيان ڪرڻ واري انگن اکرن کان پھريان آھي: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // حفاظت: اسان صرف عناصر `..4` کي شروعاتي بڻايو آهي.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // حفاظت: اسان صرف عناصر `..3` کي شروعاتي بڻايو آهي.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // ڊيمل پوائنٽ اندر ڏنل انگن اکرن ۾ آهي: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // حفاظت: اسان صرف عناصر `..4` کي شروعاتي بڻايو آهي.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // حفاظت: اسان صرف عناصر `..3` کي شروعاتي بڻايو آهي.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // ڊيزائن پوائنٽ بعد ۾ ڏنل انگن اکرن بعد آھي: [1234][____0000] يا [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // حفاظت: اسان صرف عناصر `..4` کي شروعاتي بڻايو آهي.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // حفاظت: اسان صرف عناصر `..2` کي شروعاتي بڻايو آهي.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// ڏنل ڊيزيڪل عددن `0.<...buf...> * 10^exp` کي ايڪسپوننيشنل فارم ۾ شڪل ڏئي ٿو گهٽ ۾ گهٽ ڏنل عددن کي گهٽ ۾ گهٽ اهم عددن سان.
///
/// جڏهن `upper` `true` هوندو ، ظاهر ڪندڙ `E` کان اڳوڻو هوندو ؛ٻي صورت ۾ اهو `e` آهي.
/// نتيجو مهيا ڪيل حصن جي ذخيري ڏانهن محفوظ ڪيو ويو آهي ۽ لکيل حصن جو هڪ حصو واپس ڪيو ويندو آهي.
///
/// `min_digits` `buf` ۾ حقيقي اھم انگن اکرن جي تعداد کان گھٽ ٿي سگھي ٿو.
/// اهو نظرانداز ٿي ويندو ۽ مڪمل انگ اکر ڇپجي سگهندا.اهو صرف ڇپيل عددن کان پوءِ اضافي صفر کي ڇپائڻ لاءِ استعمال ڪيو ويندو آهي.
/// اهڙيءَ طرح ، `min_digits == 0` جو مطلب اهو آهي ته اهو صرف ڏنل انگ اکر ڇاپيندو ۽ ٻيو ڪجهه به ناهي.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (ختم ٿيل-1)
    let exp = exp as i32 - 1; // ڪاوڙ جي خاتمي کان بچو جڏهن ايڪس پي ايڪس i16::MIN آهي
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // حفاظت: اسان صرف عناصر `..n + 2` کي شروعاتي بڻايو آهي.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// سائنسي فارميٽنگ جا اختيار.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// `-` رڳو منفي غير صفر جي قدر کي پرنٽ ڪري ٿو.
    Minus, // -inf -1 0 0 1 انفن نان
    /// `-` رڳو منفي قدرن جي لاءِ پرنٽ ڪندو آھي (منفي صفر سميت)
    MinusRaw, // -inf -1 -0 0 1 انفن نان
    /// `-` منفي غير صفر قدرن کي ، يا `+` ٻي صورت ۾ پرنٽ ڪري ٿو.
    MinusPlus, // -inf -1 +0 +0 +1 نان
    /// `-` ڇا منفي قدرن لاءِ پرنٽ ڪندو آھي (منفي صفر سميت) يا ٻي صورت ۾ `+`.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + انف نان
}

/// جامد بٽ واري اسٽرنگ کي واپس آڻي ٿو ته نشاني کي شڪل ۾ آڻڻ لاءِ.
/// اهو ٻئي `""` ، `"+"` يا `"-"` ٿي سگھي ٿو.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// ڏنل فلوٽنگ پوائنٽ جي نمبر کي ڊيمل فارم ۾ شڪل ڏئي ٿو گهٽ ۾ گهٽ ڏنل تعداد ۾ ڪثرت عددن سان.
/// نتيجو بائيٽ بفر کي خرچي وانگر استعمال ڪندي فراهم ڪيل حصن واري حصي کي ذخيرو ڪيو ويو آهي.
/// `upper` في الحال غير استعمال ٿيل آھي پر future کي ڇڏي ويو ته غير فطري قدرن جي ڪيس کي تبديل ڪرڻ جو فيصلو ، يعني ، `inf` ۽ `nan`.
///
/// پهريون حصو ڏيڻ جو عمل هميشه هميشه `Part::Sign` آهي (جيڪو خالي ڊاري ٿي سگهي ٿو جيڪڏهن نشاني نه ڏني وئي آهي).
///
/// `format_shortest` ھيٺ ڏنل عددي نسل جو فنڪشن ھجڻ گھرجي.
/// اهو بيففئر جو حصو واپس ڪرڻ گھرجي ته اھو شروعات.
/// توھان شايد چاھيو ٿا `strategy::grisu::format_shortest` ھن لاء.
///
/// `frac_digits` `v` ۾ اصل حصن جي انگن اکرن کان گهٽ ٿي سگهي ٿو.
/// اهو نظرانداز ٿي ويندو ۽ مڪمل انگ اکر ڇپجي سگهندا.اهو صرف ڇپيل عددن کان پوءِ اضافي صفر کي ڇپائڻ لاءِ استعمال ڪيو ويندو آهي.
/// اھڙي طرح `frac_digits` of 0 جو مطلب آھي اھو صرف پرنٽ ٿيل انگ اکر پرنٽ ڪندو ۽ ٻيو ڪجھ به ناھي.
///
/// بائيٽ بفر گهٽ کان گهٽ `MAX_SIG_DIGITS` بائٽس ڊگهو هجڻ گهرجي.
/// اي `frac_digits = 10` وانگر بدترين ڪيس جي ڪري ، گهٽ ۾ گهٽ 4 حصا دستياب هجڻ گهرجن.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // حفاظت: اسان صرف عناصر `..2` کي شروعاتي بڻايو آهي.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// ڏنل فلوٽنگ پوائنٽ جي ڊيزائين فارم ۾ يا دائمي شڪل ۾ آڻڻ وارو ، نتيجو ڪندڙ وڌندڙ تي منحصر هوندو آهي.
/// نتيجو بائيٽ بفر کي خرچي وانگر استعمال ڪندي فراهم ڪيل حصن واري حصي کي ذخيرو ڪيو ويو آهي.
/// `upper` استعمال ٿيل آھي غير فني قدرن جي ڪيس (`inf` ۽ `nan`) يا غير متوقع اڳئين جي صورت (`e` يا `E`) کي.
/// پهريون حصو ڏيڻ جو عمل هميشه هميشه `Part::Sign` آهي (جيڪو خالي ڊاري ٿي سگهي ٿو جيڪڏهن نشاني نه ڏني وئي آهي).
///
/// `format_shortest` ھيٺ ڏنل عددي نسل جو فنڪشن ھجڻ گھرجي.
/// اهو بيففئر جو حصو واپس ڪرڻ گھرجي ته اھو شروعات.
/// توھان شايد چاھيو ٿا `strategy::grisu::format_shortest` ھن لاء.
///
/// ايڪسڪسيمڪس هڪ ٽوپلس `(lo, hi)` هوندو آهي جيئن ته عدد صرف ڊيململ وانگر هوندو آهي جڏهن ته `10^lo <= V < 10^hi`.
/// نوٽ ڪريو ته ھي آھي *ظاھر*`V` اصل `v` جي بدران!اھڙيءَ طرح ڪا به پرنٽ ايڪسپوننيڊ نمودار واري شڪل ۾ ھن رينج ۾ نٿو ٿي سگھي ، ڪنھن به مونجهاري کان بچڻ.
///
///
/// بائيٽ بفر گهٽ کان گهٽ `MAX_SIG_DIGITS` بائٽس ڊگهو هجڻ گهرجي.
/// `[+][1][.][2345][e][-][6]` وانگر بدترين حالتن جي ڪري ، گهٽ ۾ گهٽ 6 حصن جو دستياب هجڻ گهرجي.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// وڌ ۾ وڌ بفر سائيز جي بدران وڌيڪ خراب انداز واري واپسي موٽندي آھي.
///
/// صحيح حد آهي:
///
/// - جڏهن `exp < 0` ، وڌ کان وڌ ڊيگهه `ceil(log_10 (5^-exp * (2^64 - 1)))` آهي.
/// - جڏهن `exp >= 0` ، وڌ کان وڌ ڊيگهه `ceil(log_10 (2^exp * (2^64 - 1)))` آهي.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)` کان گهٽ آهي ، جيڪا `20 + (1 + exp* log_10 x)` کان گهٽ ۾ آهي.
/// اسان حقيقتن کي استعمال ڪريون ٿا `log_10 2 < 5/16` ۽ `log_10 5 < 12/16` ، جيڪو اسان جي مقصدن لاءِ ڪافي آهي.
///
/// اسان کي ڇو گهرجي؟`format_exact` افعال س buffي بفر ڀريندو جيستائين آخري عدد جي پابندي تائين محدود نه هجي ، پر ممڪن آهي ته عرض ڪيو ويو عددن جو تعداد مضحکہ خیز وڏي هجي (چئي ، 30 هزار عدد).
///
/// وڏي تعداد ۾ بفر کي زيرو سان ڀريو ويندو ، تنھنڪري اسين سڀ اڳي بفر کي مختص ڪرڻ نٿا چاھيون.
/// نتيجتن ، ڪنھن ڏنل دلائل لاءِ ،
/// `f64` لاءِ 826 بئٽ بفر ڪافي هجڻ گهرجي.بدترين ڪيس جي اصل نمبر سان مقابلو ڪريو: 770 بائٽس (جڏهن `exp = -1074`).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// شڪلون اھم طور ڏنل اھم عدد سان لاڳاپيل شڪل واري نمبر ۾ فلوٽنگ پوائنٽ نمبر ڏنل آھن.
/// نتيجو بائيٽ بفر کي خرچي وانگر استعمال ڪندي فراهم ڪيل حصن واري حصي کي ذخيرو ڪيو ويو آهي.
/// `upper` استعمال ڪيو ويندو آھي استعمال ڪندڙ کي نمايان ڪرڻ واري اڳڪٿي جي صورت (`e` يا `E`)
/// پهريون حصو ڏيڻ جو عمل هميشه هميشه `Part::Sign` آهي (جيڪو خالي ڊاري ٿي سگهي ٿو جيڪڏهن نشاني نه ڏني وئي آهي).
///
/// `format_exact` ھيٺ ڏنل عددي نسل جو فنڪشن ھجڻ گھرجي.
/// اهو بيففئر جو حصو واپس ڪرڻ گھرجي ته اھو شروعات.
/// توھان شايد چاھيو ٿا `strategy::grisu::format_exact` ھن لاء.
///
/// بائيٽ بفر گهٽ ۾ گهٽ `ndigits` بائٽس هجڻ گهرجي جيستائين `ndigits` ايترو وڏو نه هجي ته صرف انگن جو مقرر تعداد ڪڏهن به لکجي.
/// (`f64` لاءِ ترڪيب وارو نقطو تقريباً 800 آهي ، تنهن ڪري 1000 بائٽس ڪافي هجڻ گهرجي.) `[+][1][.][2345][e][-][6]` وانگر بدترين صورتحال جي ڪري هتي گهٽ ۾ گهٽ 6 حصا دستياب هجڻ گهرجن.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // حفاظت: اسان صرف عناصر `..3` کي شروعاتي بڻايو آهي.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// فارميٽ جي پوائنٽ نمبر واري ڊيزائن ۾ ڏنل عدديت ۾ جيتري عددي تعداد جو ڏنل تعداد سان ڏنل هجي.
/// نتيجو بائيٽ بفر کي خرچي وانگر استعمال ڪندي فراهم ڪيل حصن واري حصي کي ذخيرو ڪيو ويو آهي.
/// `upper` في الحال غير استعمال ٿيل آھي پر future کي ڇڏي ويو ته غير فطري قدرن جي ڪيس کي تبديل ڪرڻ جو فيصلو ، يعني ، `inf` ۽ `nan`.
/// پهريون حصو ڏيڻ جو عمل هميشه هميشه `Part::Sign` آهي (جيڪو خالي ڊاري ٿي سگهي ٿو جيڪڏهن نشاني نه ڏني وئي آهي).
///
/// `format_exact` ھيٺ ڏنل عددي نسل جو فنڪشن ھجڻ گھرجي.
/// اهو بيففئر جو حصو واپس ڪرڻ گھرجي ته اھو شروعات.
/// توھان شايد چاھيو ٿا `strategy::grisu::format_exact` ھن لاء.
///
/// بائيٽ بفر ٻاھر نڪرڻ لاءِ ڪافي هجڻ گھرجي جيستائين `frac_digits` ايتري وڏي نہ ھجي جو صرف انگن جي ٺھيل تعداد ھميشه لکي ويندي.
/// (`f64` لاءِ ترڪيب وارو نقطو تقريباً 800 آهي ، ۽ 1000 بئٽس ڪافي هجڻ گهرجي.) گهٽ ۾ گهٽ 4 حصا دستياب هجڻ گهرجن ، ايڪس 0X سان `[+][0.][0000][2][0000]` جهڙي بدترين حالت جي ڪري.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // حفاظت: اسان صرف عناصر `..2` کي شروعاتي بڻايو آهي.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // اھو * ممڪن آھي ته `frac_digits` مضحکہ خیز وڏي حد تائين وڏي ھجي.
            // `format_exact` هن صورت ۾ تمام گهڻو اڳ واريون رينڊنگز ختم ڪنديون ، ڇاڪاڻ ته اسان `maxlen` طرفان سختي سان محدود آهيون.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // پابندي پوري نه ٿي سگهي ، تنهن ڪري هن کي صفر وانگر رنج ڪرڻ گهرجي ڪا به ڳالهه ناهي `exp` هو.
                // ان ۾ اهو شامل نه آهي ته پابندي صرف حتمي گول بندي اپ کان پوءِ ملي آهي.اهو `exp = limit + 1` سان هڪ باقاعده ڪيس آهي.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // حفاظت: اسان صرف عناصر `..2` کي شروعاتي بڻايو آهي.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // حفاظت: اسان صرف عناصر `..1` کي شروعاتي بڻايو آهي.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}