//! تقريبن سڌي (پر ٿورڙي اصلاح ڪئي وئي) Rust ترجمو 3 جي شڪل 3 `فلوٽنگ-پوائنٽ نمبرن جي پرنٽ جلدي ۽ صحيح نموني` [^ 1].
//!
//!
//! [^1]: Burger, آر جي ۽ ڊبي ووگ ، آر جي 1996. فلوٽنگ پوائنٽ جي نمبر ڇپائي
//!   تڪڙو ۽ صحيح طور تي.سائن ان نه.31 ، 5 (مئي 1996) ، 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 ^ (2 ^ n) لاءِ عددي عددن جو حساب ڪتاب
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// صرف قابل استعمال جڏهن `x < 16 * scale` ؛`scaleN` کي `scale.mul_small(N)` هجڻ گھرجي
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ڊريگن لاءِ نن modeو طريقو ـ نفاذ.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // فارميٽ ۾ `v` نمبر isاڻايل آھي:
    // - `mant * 2^exp` جي برابر
    // - اصل قسم ۾ `(mant - 2 *minus)* 2^exp` کان اڳ ؛۽
    // - `(mant + 2 *plus)* 2^exp` کان پوء اصلي قسم ۾.
    //
    // ظاهر آهي ، `minus` ۽ `plus` صفر نه ٿي سگھي.(ڪيفيت لاءِ ، اسين ٻاهرين درجي جي قدر استعمال ڪندا آهيون.) اسان اهو پڻ فرض ڪيو ته گهٽ ۾ گهٽ هڪ عدد ٺهيل آهي ، يعني `mant` پڻ صفر نٿو ٿي سگهي.
    //
    // اهو پڻ انهي جو مطلب آهي ته `low = (mant - minus)*2^exp` ۽ `high = (mant + plus)* 2^exp` جي وچ ۾ ڪوبه نمبر انهي صحيح سچل پوائنٽ جو نقشو ٺاهي سگهندي آهي ، حدن سان گڏ جڏهن اصل منتيسا به هئي (يعني ، `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` ايڪس X00 آهي
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // تخمينو `k_0` اصل ڪنٽينن کان `10^(k_0-1) < high <= 10^(k_0+1)` کي مطمئن ڪندڙ.
    // تنگ پابند `k` مطمئن ڪندڙ `10^(k-1) < high <= 10^k` بعد ۾ ڳڻتي آهي.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // ايڪسڪسيمڪس کي جزوي شڪل ۾ تبديل ڪيو ته جيئن:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `10^k` طرفان `mant` ورهايو.هاڻي `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // ٺيڪ ڪريو جڏهن `mant + plus > scale` (يا `>=`).
    // اسان اصل ۾ ايڪس سيڪس کي تبديل نٿا ڪري سگهون ، ڇاڪاڻ ته اسان بدران اصل ضرب ڇڏي سگهون ٿا.
    // ھاڻي ايڪس ايڪس ايڪس ۽ اسان عددن پيدا ڪرڻ لاءِ تيار آھيون.
    //
    // ياد رکجو ته `d[0]` * صفر ٿي سگھي ٿو ، جڏهن `scale - plus < mant < scale`.
    // ان صورت ۾ گولائي اپ واري حالت (هيٺ `up`) فوري طور تي متحرڪ ٿيندي.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // 10 کان `scale` کي ماپڻ جي برابر
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ڊجيٽل نسل لاءِ ڪيش ايڪس سيڪسڪس.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants ، جتي `d[0..n-1]` اب تائين عدد آهن.
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (اهڙيءَ طرح `mant / scale < 10`) جتي `d[i..j]` شارٽ ڊي آهي `ڊي [i] * 10 ^ (ji) +…
        // + ڊي [j-1] * 10 + d[j]`.

        // هڪ عدد ٺاهيو: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // اهو تبديل ٿيل ڊريگون الگورٿم جو آسان بيان آهي.
        // سھولت لاءِ ڪيترائي وچڙندڙ نڪتا ۽ مڪمل ڪرڻ واريون دليلون ختم ڪيون ويون آھن.
        //
        // تبديل ٿيل انوگرن سان شروع ڪريو ، جئين اسان ايڪس آرڪس کي اپڊيٽ ڪيو آهي:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // فرض ڪريو ته `d[0..n-1]` `low` ۽ `high` جي وچ ۾ مختصر ترين نمائندگي آهي ، يعني ، `d[0..n-1]` هيٺين ٻنهي کي مطمئن ڪري ٿو پر `d[0..n-2]` نٿو ڪري:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: `v` گول تائين عدد) ؛۽
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (آخري انگ صحيح آھي).
        //
        // ٻئين شرط `2 * mant <= scale` کي آسان بڻائي ٿي.
        // `mant` ، `low` ۽ `high` جي شرطن جي لحاظ کان invariaries حل ڪرڻ پهرين حالت جو هڪ آسان نسخو پيدا ڪري ٿو: `-plus < mant < minus`.
        // `-plus < 0 <= mant` کان وٺي ، اسان وٽ ھڪڙو مختصر نن shortڙو نمائندو آھي جڏھن `mant < minus` ۽ `2 * mant <= scale`.
        // (اڳوڻو `mant <= minus` ٿي ويندو آهي جڏهن اصل منتيسا پڻ آهي.)
        //
        // جڏهن سيڪنڊ رڪاوٽ نٿو رکي ("2 * منٽ> پيمانا") ، اسان کي آخري انگ وڌائڻ جي ضرورت آهي.
        // اھو ھن شرط کي بحال ڪرڻ لاءِ ڪافي آھي: اسان اڳي ئي knowاڻون ٿا ته ڊجيٽل نسل `0 <= v / 10^(k-n) - d[0..n-1] < 1` جي ضمانت آھي.
        // انهي حالت ۾ ، پهرين حالت `-plus < mant - scale < minus` ٿي ويندي آهي.
        // نسل کان پوءِ `mant < scale` ، اسان وٽ `scale < mant + plus` آھي.
        // (ٻيهر ، اهو `scale <= mant + plus` ٿي ويندو آهي جڏهن اصل منتيسا پڻ آهي.)
        //
        // مختصر ۾:
        // - `down` کي روڪيو ۽ گول ڪيو (جئين نمبر طور رکو) جڏهن `mant < minus` (يا `<=`).
        // - روڪيو ۽ گول ڪيو `up` (آخري ڊيٽ کي وڌايو) جڏهن `scale < mant + plus` (يا `<=`).
        // - ٻي صورت ۾ پيدا ڪندا رهو.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // اسان وٽ تمام گهڻي مختصر نمائندگي آهي ، گولنگ ڏانهن اڳتي وڌو

        // انووارين کي بحال ڪيو
        // اھو ٺاھيندو ٺاھيو الگورتھم کي ھميشه ختم ڪرڻ: `minus` ۽ `plus` ھميشه وڌي ٿو ، پر `mant` ڪلپيو ماڊلولو `scale` ۽ `scale` طئي ٿيل آھي.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // گولائي تڏهن ٿئي ٿي جڏهن i) صرف گولائي واري حالت کي حرڪت ڏني وئي ، يا ii) ٻنهي حالتن کي حرڪت ۾ آڻڻ ۽ ٽوڙڻ واري ترجيح گولائينگ کي ختم ڪيو ويو.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // جيڪڏهن گول theيرائڻ سان ڊگهو ٿيندو ، همراهه به تبديل ٿيڻ گهرجي.
        // اهو لڳي ٿو ته اها حالت پورو ڪرڻ ڏا hardي مشڪل آهي (ممڪن طور ناممڪن آهي) پر اسان هتي صرف محفوظ ۽ مستقل هجڻ وارا آهيون.
        //
        // حفاظت: اسان انهي ياداشت جي شروعات ڪئي.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // حفاظت: اسان انهي ياداشت جي شروعات ڪئي.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ڊريگن لاءِ صحيح ۽ طئي ٿيل موڊ نافذ.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // تخمينو `k_0` اصل ڪنٽينن کان `10^(k_0-1) < v <= 10^(k_0+1)` کي مطمئن ڪندڙ.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `10^k` طرفان `mant` ورهايو.هاڻي `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // فڪس اپ جڏهن `mant + plus >= scale` ، جتي `plus / scale = 10^-buf.len() / 2`.
    // صحيح ماپ وارو پنڊم رکڻ لاءِ ، اسان اصل ۾ `mant + floor(plus) >= scale` استعمال ڪريون ٿا.
    // اسان اصل ۾ ايڪس سيڪس کي تبديل نٿا ڪري سگهون ، ڇاڪاڻ ته اسان بدران اصل ضرب ڇڏي سگهون ٿا.
    // نن algorithي نن algorithي الگورتھم سان وري ، `d[0]` صفر ٿي سگھي ٿو پر آخرڪار گول ٿي ويندو.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // 10 کان `scale` کي ماپڻ جي برابر
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // جيڪڏهن اسان آخري عدد جي حد سان گڏ ڪم ڪري رهيا آهيون ، اسان کي اصل رڪارڊنگ کان اڳ بفر کي نن needو ڪرڻ جي ضرورت آهي ته جيئن ٻئين گولائي کان بچڻ.
    //
    // ياد ڪريو ته اسان کي ٻيهر بفر کي وڌائڻو آهي جڏهن رنڊنگ اپ اچي رهي آهي!
    let mut len = if k < limit {
        // اف ، اسان *ھڪڙو* عدد پيدا نٿا ڪري سگھون.
        // اھو ممڪن آھي جڏھن ، چئي ، اسان کي ڪجھ 9.5 وانگر مليو آھي ۽ ان کي 10 تائين گول ڪيو وڃي ٿو.
        // اسان هڪ خالي بفر واپس آڻيون ٿا ، سواءِ ان جي ته بعد جي گولائي وڌا واري ڪيس جي ، جنهن جي صورت `k == limit` ٿئي ٿي ۽ انهي ۾ هڪ عدد ئي پيدا ڪجي.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // ڊجيٽل نسل لاءِ ڪيش ايڪس سيڪسڪس.
        // (اهو قيمتي ٿي سگهي ٿو ، تنهن ڪري انهن جو حساب نه ڏيو جڏهن بفر خالي آهي.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // ھيٺيون عدد سڀئي صفر آھن ، اسان ھتي آھيون ٿا *نه* گول ڪرڻ جي ڪوشش ڪريو.بلڪه ، باقي انگن اکرن کي ڀريو.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // حفاظت: اسان انهي ياداشت جي شروعات ڪئي.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // جيڪڏهن اسان عددن جي وچ ۾ روڪيون جيڪڏهن هيٺ ڏنل انگن جو عڪس 5000 آهي ... ، اڳ واري عدد کي چيڪ ڪريو ۽ گول ڪرڻ جي ڪوشش ڪريو (يعني اڳيون عدد برابر آهي) گول ڪرڻ کان پاسو ڪريو.
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // حفاظت: `buf[len-1]` شروعاتي آھي.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // جيڪڏهن گول theيرائڻ سان ڊگهو ٿيندو ، همراهه به تبديل ٿيڻ گهرجي.
        // پر اسان هڪ گهربل تعداد جو انگ مقرر ڪيو آهي ، تنهن ڪري بفر کي تبديل نه ڪيو ...
        // حفاظت: اسان انهي ياداشت جي شروعات ڪئي.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... جيستائين اسان کان درخواست ڪئي وئي آهي ٺيڪ سڌرائي جي بدران.
            // اسان کي اهو پڻ جانچڻ جي ضرورت آهي ، جيڪڏهن اصل بفر خالي هو ، اضافي عدد صرف تڏهن شامل ڪري سگھجي ٿو جڏهن `k == limit` (edge ڪيس).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // حفاظت: اسان انهي ياداشت جي شروعات ڪئي.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}