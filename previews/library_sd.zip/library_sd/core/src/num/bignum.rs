//! ڪسٽم ثالثي صحت واري نمبر (bignum) عمل درآمد.
//!
//! اهو اسٽوري ياداشت جي قيمت تي هڻڻ واري رقم کان بچڻ لاءِ ٺهيل آهي.
//! عام طور تي استعمال ٿيل بينگينم قسم ، `Big32x40` ، 32 × 40=1،280 بٽس تائين محدود آهي ۽ اسٽيڪ ياداشت جي اڪثر 160 بائٽس وٺي ويندي.
//! اهو گول اسٽاپنگ جي سڀني ممڪن فيڪٽيڪس `f64` قدرن جي لاءِ ڪافي آهي.
//!
//! اصولي طور تي اهو ممڪن آهي ته مختلف داخلين لاءِ گهڻن بائنگم جا قسم هجن ، پر اسان ڪوڊ اي ميل کان بچڻ لاءِ ائين نٿا ڪريون.
//!
//! هر بينگ اڃا تائين اصل استعمالن لاءِ باخبر آهي ، تنهن ڪري اهو عام طور تي ڪو مسئلو ناهي.
//!

// اهو ماڊل صرف dec2flt ۽ flt2dec لاءِ آهي ، ۽ صرف ڪورٽس جي ڪري عوام لاءِ.
// اهو ڪڏهن به مستحڪم نه ٿيڻ جو ارادو آهي.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// بيگيگمس طرفان رياضياتي آپريشن گهربل آهن.
pub trait FullOps: Sized {
    /// `(carry', v')` کي واپسي ڏئي ٿو جهڙوڪ `carry' * 2^W + v' = self + other + carry` ، جتي `W` `Self` ۾ بٽس جو نمبر آهي.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `(carry', v')` کي واپسي ڏئي ٿو جهڙوڪ `carry'*2^W + v' = self* other + carry` ، جتي `W` `Self` ۾ بٽس جو نمبر آهي.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(carry', v')` کي واپسي ڏئي ٿو جهڙوڪ `carry'*2^W + v' = self* other + other2 + carry` ، جتي `W` `Self` ۾ بٽس جو نمبر آهي.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(quo, rem)` کي واپس ڏئي ٿو ته `borrow *2^W + self = quo* other + rem` ۽ `0 <= rem < other` ، جتي `W` `Self` ۾ بٽس جو نمبر آهي.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // اهو ختم نه ٿو ٿي سگهي.پيداوار `0` ۽ `2 * 2^nbits - 1` جي وچ ۾ آهي
                    // FIXME: ڇا LLVM هن کي ADC ۾ يا انهي وانگر پسند ڪندو؟
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // اهو ختم نه ٿو ٿي سگهي.
                    // پيداوار `0` ۽ `2^nbits * (2^nbits - 1)` جي وچ ۾ آهي
                    // FIXME: ڇا LLVM هن کي ADC ۾ يا انهي وانگر پسند ڪندو؟
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // اهو ختم نه ٿو ٿي سگهي.
                    // پيداوار `0` ۽ `2^nbits * (2^nbits - 1)` جي وچ ۾ آهي
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // اهو ختم نه ٿو ٿي سگهي.پيداوار `0` ۽ `other * (2^nbits - 1)` جي وچ ۾ آهي
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // ڏسو انهي کي فعال ڪرڻ لاءِ آر ايف سي ايڪسڪسيمڪس ڏسو.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// انگن اکرن ۾ 5 جو نمائندگي ڪندڙ طاقتن جي جدول.خاص طور تي ، سڀني کان وڏي {u8, u16, u32} قيمت جيڪا پنج جي طاقت آهي ، ۽ انهي سان تعلق رکندڙ وڌندڙ.
/// `mul_pow5` ۾ استعمال ڪيو ويو آهي.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// اسٽيڪ مختص ڪيل ثالث-سڌائي (ڪجهه حد تائين) انٽيگر.
        ///
        /// اهو ڏنل قسم جي ("digit") جي هڪ فيڪو سائيز وارو قطار طرفان پٺتي ڏنل آهي.
        /// جڏهن ته صف تمام وڏو نه آهي (عام طور تي ڪجهه سو بائيٽ) ، ان کي لاپرواهي سان نقل ڪرڻ ڪارڪردگي جي مار جو نتيجو ٿي سگهي ٿو.
        ///
        /// اھڙي طرح اھو ارادو طور تي `Copy` نھ آھي.
        ///
        /// اووربيشن جي صورت ۾ panic bignums سڀني آپريشنز دستياب آهن.
        /// ڪالر وڏي بيگينم قسمن جا استعمال ڪرڻ جو ذميوار آهي.
        pub struct $name {
            /// ھڪڙي ھڪڙي استعمال ڪرڻ جي وڌ ۾ وڌ "digit" ڏانھن آف سي.
            /// اهو گهٽ نه ٿو ڪري ، تنهنڪري حساب جي ترتيب کان آگاهه رهو.
            /// `base[size..]` صفر هجڻ گهرجي.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` ايڪسڪسيمڪس جي نمائندگي ڪندو آهي جتي `W` عددن جي قسم ۾ بٽس جو تعداد آهي.
            base: [$ty; $n],
        }

        impl $name {
            /// هڪ عددي کان هڪ بگيگم ٺاهي ٿو.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// `u64` قدر مان بگيگم ٺاهي ٿو.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// سليس `[a, b, c, ...]` وانگر اندروني انگن اکرن کي ورجائي ٿو ته عددي قيمت `a + b *2^W + c* 2^(2W) + ...` آهي جتي `W` عددن جي قسم ۾ بٽس جو نمبر آهي.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// واپسي آئي "i`-bit جتي بٽ 0 گهٽ ۾ گهٽ هڪ اهم آهي.
            /// ٻين لفظن ۾ ، وزن وزن `2^i` سان.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// ايڪس بي ايم ايڪس کي واپسي ڏئي ٿو جيڪڏهن بيگن صفر آهي.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// بيٽس جو تعداد واپس ڏئي ٿو انهي ويليو کي نمائندگي ڪرڻ لاءِ.
            /// ياد ڪريو ته صفر کي 0 بٽس جي ضرورت سمجهيو وڃي ٿو.
            pub fn bit_length(&self) -> usize {
                // اھم انگن اکرن تي ڇڏي ڏيو جيڪي صفر آھن.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // غير صفر عدد آهن ، يعني نمبر صفر آهي.
                    return 0;
                }
                // اهو ايڪسڪسڪس ۽ بيٽ شفٽ سان بهتر ٿي سگهي ٿو ، پر اهو شايد پريشاني جي لائق ناهي.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// `other` کي پاڻ ۾ شامل ڪري ٿو ۽ پنهنجو مٽجڻ وارو حوالو ڏئي ٿو.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// `other` کي پاڻ کان ڪٽيندو آهي ۽ ان جي پنهنجي بدلي واري حوالي سان واپس ايندو آهي.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// هڪ عددي ماپ واري `other` کان پاڻ کي ضرب ڏي ٿو ۽ پنهنجي قابل تبديل ريفرنس موٽائي ٿو.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// `2^bits` پاران پنهنجو پاڻ کي ضرب ڏئي ٿو ۽ پنهنجو مٽ پاڻ حوالي ڪندڙ حوالو ڏئي ٿو.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // `digits * digitbits` بٽس پاران شفٽ
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // `bits` بٽس پاران شفٽ
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. انگن اکرن] صفر آهي ، منتقل ڪرڻ جي ضرورت ناهي
                }

                self.size = sz;
                self
            }

            /// `5^e` پاران پنهنجو پاڻ کي ضرب ڏئي ٿو ۽ پنهنجو مٽ پاڻ حوالي ڪندڙ حوالو ڏئي ٿو.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // 2 ^ n تي اصل طور تي پيچرو صفرون آهن ، ۽ صرف لاڳاپيل عددن جي ماپ جا ٻه اختيار آهن ، تنهنڪري اهو جدول لاءِ مناسب ترتيب ڏنل آهي.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // سڀني کان وڏي اڪثريت واري طاقت سان ضرب ڏجي.
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... پوءِ رهيل ڪم ختم ڪريو.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` پاران بيان ڪيل هڪ نمبر کي پاڻ کي ضرب ڏي ٿو (جتي `W` عددن جي قسم جي بٽس جو تعداد آهي) ۽ پنهنجو مٽائيندڙ حوالو واپس ٿو ڏئي.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // اندروني رويو.سٺو ڪم ڪري ٿو جڏهن aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// ڊيزائينڊ `other` ذريعي پاڻ کي ورهائي ٿو ۽ واپسي جي پنھنجي قابل تبديلي ريفرنس *۽* کي باقي.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// هڪ ٻئي بائنگيم سان پنهنجو پاڻ کي ورهايو ، `q` مٿان دٻائيندڙ سان گڏ ۽ `r` کي باقي دٻائڻ سان.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // بيوقوف سست base-2 ڊگهو ڊويزن کان ورتي وئي
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME ڊگهي ڊويزن لاءِ وڌيڪ بنيادي ايڪس ايڪس ايڪس ايڪس استعمال ڪريو.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // q کان 1 تائين بٽ `i` کي سيٽ ڪريو.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// `Big32x40` لاءِ عددي جو قسم.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// اهو صرف هڪ آزمائش لاءِ استعمال ٿيندو آهي.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}