//! ڊي آئي ايم واري اسٽرنگ کي IEEE 754 ۾ تبديل ڪرڻ واريون بائنري فلوٽنگ پوائنٽ نمبرز ۾.
//!
//! # مسئلي جو بيان
//!
//! اسان کي ڏھڻ وارو اسٽرنگ ڏنو ويو آھي جھڙوڪ `12.34e56`.
//! ھن تار ۾ شامل آھي (`12`) جا جز ، ڀا frا (`34`) ، ۽ ھڪڙي وڌندڙ (`56`) حصن.سڀ حصا اختياري آهن ۽ صفر جي وضاحت ڪئي وئي آهي جڏهن غائب آهي.
//!
//! اسان چاهيون ٿا IEEE 754 فلوٽنگ پوائنٽ نمبر جيڪو عدليه تار جي اصل قدر جي ويجهو آهي.
//! اهو مشهور طور تي manyاڻايل آهي ته گهڻا ڊيمل اسٽرنگس بيس ۾ بيسٽي جي نمائندگي نه هوندي آهي ، تنهن ڪري اسان آخري جڳهه تي 0.5 يونٽ تائين گول ڪندا آهيون (ٻين لفظن ۾ به ممڪن آهي).
//! لاڳاپا ، ٻھراڙي وارا قدرَ لڳاتار ٻن مصلحتن جي وچ ۾ اڌ رستي جو ، اڌ حل ڪيل حڪمت عمليءَ سان حل ٿيل آھن ، پڻ بينڪر جي گولائي طور سڃاتو وڃي ٿو.
//!
//! چوڻ جي ضرورت ناهي ، اهو تمام سخت آهي ، ٻنهي تي عملدرآمد جي پيچيدگي جي لحاظ کان ۽ سي پي يو جي چڪر جي لحاظ کان.
//!
//! # Implementation
//!
//! پهرين ، اسان نشانين کي نظرانداز ڪريون ٿا.يا بدران ، اسان ان کي ٻيهر منتقلي جي عمل جي شروعات ۾ هٽائي ڇڏيو ۽ ان کي ٻي آخر ۾ ٻيهر لاڳو ڪيو.
//! اهو سڀ edge ڪيسن ۾ صحيح آهي ، ڇاڪاڻ ته IEEE فلوٽ صفر جي برابر آهن ، هڪٻئي کي رد ڪندي صرف پهرين بٽ کي flيرايو ويندو آهي.
//!
//! ان کان پوءِ اسان خارج ڪندڙ کي ترتيب ڏيندي ڊيسيمل پوائنٽ کي ڪ removeي ڇڏيو: تصوراتي طور تي ، `12.34e56` `1234e54` ۾ بدلجي ٿو ، جنهن کي اسين مثبت عدد `f = 1234` ۽ انٽيگر `e = 54` سان بيان ڪريون ٿا.
//! `(f, e)` نمائندگي تقريبن سڀني ڪوڊن جي پارسنگ جي اسٽيج کان اڳ ۾ استعمال ڪئي وئي آهي.
//!
//! اسان پوءِ مشين جي ماپ واري انٽيگرز ۽ نن fixedن ، مقرر ٿيل سائز وارا فلوٽنگ پوائنٽ نمبر (پهريون `f32`/`f64` ، پوءِ هڪ قسم 64 بِٽ اهم ، `Fp`) سان استعمال ڪري وڌيڪ ترقي واري وڌيڪ عام ۽ قيمتي خاص ڪيسن جي هڪ ڊگهي سلسلي جي ڪوشش ڪريون ٿا.
//!
//! جڏهن اهي سڀ ناڪام ٿي وڃن ، اسان بليٽ کي استعمال ڪيو ۽ هڪ آسان پر تمام سست رفتاري واري الگورتھم جو استعمال ڪيو جنهن ۾ `f * 10^e` کي مڪمل طرح سان ڪمپيوٽنگ ۽ بهتر اندازن جي ڳولا وارو ڌاتو شامل هجي.
//!
//! بنيادي طور تي ، هي ماڊل ۽ هن جا ٻار بيان ڪيل الگورٿم کي عمل ۾ آڻين ٿا:
//! "How to Read Floating Point Numbers Accurately" وليم ڊي پاران
//! ڪلنگر ، آن لائن دستياب: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! ان کان علاوه ، ڪيترائي مددگار افعال آهن جيڪي ڪاغذ ۾ استعمال ڪيا ويندا آهن پر Rust (يا گهٽ ۾ گهٽ ڪور ۾) دستياب ناهن.
//! اسان وارو نسخو اضافي طور تي پيچرو ۽ انڊر فلو کي سنڀالڻ جي ضرورت ۽ ذيلي غير معمولي نمبرن کي سنڀالڻ جي ضرورت کان پيچيده ٿي ويو.
//! بيلليروفون ۽ الورگيتم آر کي وڌيڪ وهڪرو ، غير معمولي ۽ گهٽ وهڪرو سان مسئلو آهي.
//! اسان خاص طور تي الورگيتم ايم (سوئچ ڪيو ويو سيڪشن 8 جي بيان ڪيل ترميمن سان) کي تبديل ڪيو ويو ته ان کان اڳ داخل ٿيڻ نازڪ علائقي ۾.
//!
//! هڪ ٻيو پاسو جنهن جي توجه جي ضرورت آهي "RawFloat" trait جنهن جي ڪري تقريباً سڀ ڪم طئه ڪيا ويا آهن.هڪڙي شايد اهو سمجهي سگھي ٿو ته اهو `f64` ڏانهن پارس ڪرڻ لاءِ ڪافي آهي ۽ ايڪس XOX تي نتيجو ڪ castيو وڃي.
//! بدقسمتي سان اها دنيا ناهي جنهن ۾ اسين رهون ٿا ، ۽ انهي جو ڪوبه بنياد يا ٻج اڌ گول ڪرڻ استعمال ناهي ڪيو.
//!
//! مثال طور غور ڪريو ٻن قسمن `d2` ۽ `d4` هڪ ڊيسيمل قسم جي نمائندگي ڪندڙ ٻه عددي انگن سان ۽ چار چار عدد ۽ هر هڪ طور تي "0.01499" داخل ڪريو.اچو ته اڌ اپ رائوننگ استعمال ڪريون.
//! ٻن ڊيسيمل عددن تي سڌو وڃي وڃڻ سان `0.01` ڏي ٿو ، پر جيڪڏهن اسان پهرين چار عددن تي گول ڪريون ٿا ، اسان کي `0.0150` ملي ٿو ، جيڪو پوءِ `0.02` تائين گول ڪري ٿو.
//! ساڳيو اصول ٻين آپريشنن تي پڻ لاڳو ٿئي ٿو ، جيڪڏهن توهان 0.5 يو ايل پي درستگي چاهيو ٿا ته توهان کي *سڀ ڪجهه* مڪمل درستگي ۽ گول * کي هڪ ئي وقت ، هڪ ئي وقت تي ، بلڪل ختم ٿيڻ تي ، هڪ ئي وقت ۾ سڀ ٽيونٽي بٽس تي غور ڪرڻ سان.
//!
//! FIXME: جيتوڻيڪ ڪجهه ڪوڊ نقل ساڳيو ضروري آهي ، شايد ڪوڊ جا حصا به چوڌاري uffيرائي سگهجن ته گهٽ ڪوڊ نقل ٿيل.
//! الورگرافس جا وڏا حصا فلوٽ جي قسم کان آزاد آهن ، يا صرف ڪجهه ڪنسٽن تائين رسائي جي ضرورت آهي ، جيڪي پيرا ميٽرز ۾ گذاري سگهن.
//!
//! # Other
//!
//! تبديلي *ڪڏهن به* panic نه هئڻ گهرجي.
//! يقينا آهن ۽ واضح طور تي panics ڪوڊ ۾ ، پر انهن کي ڪڏهن به ڌڪڻ نه گهرجي ۽ صرف اندروني صحت واري چڪاس جي طور تي خدمت ڪري.ڪوبه panics بگ سمجهڻ گهرجي.
//!
//! هتي يونٽ ٽيسٽ آهن پر انهن کي درستگي سان يقيني طور تي نا مناسب آهي ، اهي صرف نن percentageي سيڪڙو ممڪن غلطين کي coverڪيندا آهن.
//! زيور زيرو پي ايڇ ڊي ايڪس اسڪرپٽ جي طور تي ڊائريڪٽوريٽ `src/etc/test-float-parse` ۾ گهڻي کان وڌيڪ وسيع ٽيسٽ موجود آهن.
//!
//! انٽيگر اوور فلو تي هڪ نوٽ: هن فائل جا ڪيترائي حصا عددي ايڪسپرينر `e` سان رياضياتي انجام ڏين ٿا.
//! بنيادي طور تي ، اسان ٻٻرڻ واري پوائنٽ کي گھرايون ٿا: پهرين ڊيسيمل عدد کان اڳ ، آخري ڊيسيمل عدد کان پوءِ ، ۽ اڳتيجيڪڏهن لاپرواهي سان ٿي سگهي ته اهو وڌي سگهي ٿو.
//! اسان صرف نن smallا نن expا ننentsا مقصد استعمال ڪرڻ وارا ، پارسي جي ذيلي شيڊول تي ڀروسو رکون ٿا ، جتي "sufficient" جو مطلب "such that the exponent +/- the number of decimal digits fits into a 64 bit integer" آهي.
//! وڏا وڏا مڃيندڙ قبول ڪيا ويا آهن ، پر اسان انهن سان چڪاس نٿا ڪريون ، اهي فوري طور تي {positive,negative} {zero,infinity} ۾ تبديل ٿي ويا آهن.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// انهن ٻنهي وٽ پنهنجا پنهنجا امتحان آهن.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// 10 ۾ ٻڌل هڪ اسٽرنگ کي فلوٽ ۾ تبديل ڪيو آهي.
            /// هڪ اختياري ڊيزليمر مقرر ڪندڙ کي قبول ڪري ٿو.
            ///
            /// اهو فنڪشن اسٽرنگز کي قبول ڪندو آهي جهڙوڪ
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', يا برابر '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', يا ، برابر ، '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// خالي ۽ ڳرندڙ وائ اسپيس هڪ نقص جي نمائندگي ڪن ٿا.
            ///
            /// # Grammar
            ///
            /// سڀئي تار جيڪي هيٺ ڏنل [EBNF] گرامر تي عمل ڪن ٿيون ، نتيجو [`Ok`] موٽي ويندي:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # سڃاتل ڪيڙا
            ///
            /// ڪجهه حالتن ۾ ، ڪجهه اسٽرنگز جيڪي غلط فلوٽ ٺاهڻ بدران بدلي جي غلطي ڪن ٿيون.
            /// تفصيل لاءِ [issue #31407] ڏسو.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src ، هڪ تار
            ///
            /// # واپسي جي قيمت
            ///
            /// `Err(ParseFloatError)` جيڪڏهن تار هڪ صحيح نمبر جي نمائندگي نه ڪئي آهي.
            /// ٻي صورت ۾ ، `Ok(n)` جتي `n` سچل پوائنٽ نمبر آهي جيڪو `src` پاران نمائندگي ڪيو ويو آهي.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// هڪ غلطي جيڪا فلوٽ تي ڀاڙي وجهي واپس ڪري سگهجي ٿي.
///
/// اها غلطي [`f32`] ۽ [`f64`] لاءِ [`FromStr`] عمل درآمد جي لاءِ غلط قسم طور استعمال ڪئي وئي.
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// ڊيمل اسٽرنگ کي نشان ۽ باقي ۾ ورهائي ٿو ، بغير معائنو جي يا باقي جي تصديق ڪرڻ کان سواء.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // جيڪڏهن تار صحيح نه آهي ، اسان ڪڏهن به نشاني استعمال نٿا ڪريون ، تنهن ڪري اسان کي هتي صحيح ڪرڻ جي ضرورت ناهي.
        _ => (Sign::Positive, s),
    }
}

/// ديسيمل اسٽرنگ کي فلوٽنگ پوائنٽ نمبر ۾ بدلائي ٿو.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// ڊيسيمل-فلوٽ ڪنورورشن جو بنيادي محرڪ: تمام پري پروسسنگ کي ترتيب ڏيو ۽ figureاڻيو ته ڪهڙو الگورٿم اصل تبديلي آڻڻ گهرجي.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift ڊيسيمل پوائنٽ کان ٻاهر.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 1280 بٽس تائين محدود آهي ، جيڪو تقريبن 385 ڊيمل انگن ۾ ترجمو ڪري ٿو.
    // جيڪڏھن اسان ان کان ٻاھر ڪ ،و ٿا ، اسين ڪاوڙجي ويندا آھيون ، تنھنڪري اسين تمام پري رھڻ کان پھريائين غلطي (10 ^ 10 جي اندر)
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // هاڻي بيان ڪندڙ 16 بٽ ۾ پڪ سان ٺهيل آهي ، جيڪا پوري الگوريٿٿمز ۾ استعمال ٿئي ٿي.
    let e = e as i16;
    // درست ڪريو اهي حدون وڌيڪ محافظ آهن.
    // بيليروفون جي ناڪامي طريقن جو وڌيڪ محتاط تجزيو ان کي وڌيڪ ڪيسن ۾ وڏي رفتار جي رفتار سان استعمال ڪرڻ جي اجازت ڏئي سگهندو هو.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// جيئن لکيو ويو آهي ، اهو خراب طريقي سان انجام ڏيندو آهي (#27130 ڏسو ، جيتوڻيڪ اهو ڪوڊ جو پراڻو نسخو ظاهر ڪري ٿو).
// `inline(always)` هن لاءِ هڪ حل آهي.
// مجموعي طور تي فقط ٻه ڪال سائيٽون آهن ۽ اهو ڪوڊ سائيز وڌيڪ خراب نٿو ڪري.

/// ممڪن طور تي صفر کي پٽي ڇڏيو ، ان جي صورت ۾ جڏهن اهو تيزيء کي تبديل ڪرڻ جي ضرورت آهي
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // هنن زيروز کي تڙي ڪ anythingڻ ڪو ڪجهه به نٿو بدلائي پر جلدي جو رستو چالو ڪري سگھي ٿو (<15 عددن).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // فارم جي نمبرن کي آسان ڪريو 0.0 ... x ۽ x ... 0.0 ، ايڪسپلونٽ کي پاڻ مطابق ترتيب ڏيندي.
    // اهو شايد هميشه کٽي نه سگهندو آهي (ممڪن طور تي فاسٽ رستي کان ڪجھ انگ اکر ڪ pushي ٿو) ، پر اهو ٻين حصن کي وڏي پئماني تي سادي نموني ڪري ٿو (خاص طور تي ، قدر جي شدت ويجھو ڪري ٿو).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// واپسي جي هڪ تيز گند واري اوپري واپسي کي (log10) جي وڏي قدر جي ماپ ڏي ٿو ته الگوريٿم آر ۽ الورگيتم ايم حساب ڪتاب جي ڪم ۾ ڏين ٿا.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // اسان کي trivial_cases() ۽ پارڪر جي مهرباني وڌيڪ فلو بابت گهڻو پريشان ڪرڻ جي ضرورت ناهي ، جيڪا اسان جي انتهائي انتهائي انڪشافن کي فلٽر ڪري ٿي.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // صورت ۾ <>=0 ، ٻئي الگورتھم `f * 10^e` بابت سمجهندا آهن.
        // الگورٿم آر ھن سان ڪجھ پيچيده حساب ڪرڻ لڳن ٿا پر اسين ان کي نظرانداز ڪري سگھون ٿا ته اھو مٿيون پابند آھي ڇو ته اھو اڳي ئي ڪثرت گھٽائي ٿو ، تنھنڪري اسان وٽ ڪافي بفر آھي.
        //
        f_len + (e as u64)
    } else {
        // جيڪڏهن اي <0 ، الورگيتم ر ساڳيو ئي ڪم ڪري ٿو ، پر الگورٿم ايم مختلف آهي:
        // ھن کي ھڪڙو مثبت نمبر ڪي ڳولڻ جي ڪوشش ڪندو آھي جنھن جي ڪري `f << k / 10^e` ھڪڙي رينج جي اھم ھجي.
        // ان جو نتيجو `2^53 *f* 10^e` <`10^17 *f* 10^e` بابت.
        // ھڪڙو ان پٽ جيڪو حرڪت ڪري ٿو ھي 0.33 آھي ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// بيسمل عددن کي ڏسڻ کانسواءِ به واضح فلوز ۽ ان فلوز کي ڳولهي ٿو.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // هتي صفر هئا پر اهي simplify() کان لڪيل هئا
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // هي ceil(log10(the real value)) جي هڪ قسم جي ويجهو قيمت آهي.
    // ہمیں یہاں ضرورت سے زیادہ پریشان ہونے کی ضرورت نہیں ہے کیونکہ ان پٹ کی لمبائی چھوٹی ہے (کم از کم 2 ^ 64 کے مقابلے میں) اور پرسر پہلے ہی ان معززین کو سنبھالتا ہے جن کی مطلق قدر 10 ^ 18 سے زیادہ ہے (جو اب بھی 10 ^ 19 مختصر ہے جو 2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}