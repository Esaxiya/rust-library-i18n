//! فارم جي ڊيمل اسٽرنگ کي درست ۽ ختم ڪرڻ:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! ٻين لفظن ۾ ، معياري فلوٽنگ پوائنٽ نحو ، ٻن استثنان سان: نشاني ۽ "inf" ۽ "NaN" کي هٿ ڪرڻ.اهي ڊرائيور جي فنڪشن (super::dec2flt) پاران هٿ ڪيا ويا آهن.
//!
//! جيتوڻيڪ صحيح ان پٽن کي سڃاڻڻ نسبتا آسان آهي ، هن ماڊل کي پڻ لاتعداد غلط تبديلين کي رد ڪرڻو پوندو ، ڪڏهن به panic ، ۽ ڪيترن ئي چيڪ انجام ڏيو ته ٻئي ماڊل موڙ تي panic (يا اوور فلو) تي ڀاڙين ٿا.
//!
//! معاملا بدتر ڪرڻ لاءِ ، سڀ ڪجهه هڪ ئي پاس جي انٽ جي مٿان ٿيندي آهي.
//! تنهن ڪري ، خبردار ٿيو جڏهن ڪجهه به تبديل ڪرڻ ، ۽ ٻين ماڊلز سان ٻيهر جاچ ڪريو.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// ڊيسيمل اسٽرنگ جا دلچسپ حصا.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// ڊيسيمل ايڪسپوزينٽ ، گارنٽيڊ 18 عددن کان گهٽ هجڻ جي ضمانت.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// چيڪ ڪريو ته ان پٽنگ اسٽرنگ هڪ صحيح فلوٽنگ پوائنٽ نمبر آهي ۽ جيڪڏهن ائين آهي ته جغرافيائي حصو ، جزوي ڀا partو ۽ ان ۾ ظاهر ڪندڙ ماڻهو ڳوليو.
/// نشانين کي نه سنڀاليندو آهي.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' کان پهريان ڪي به عدد نه
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // اسان کي پوائنٽ کان اڳ يا پوءِ کان گهٽ ۾ گهٽ هڪ عدد گهربل آهي.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // جزيري واري حصي کان پوءِ پيچرو ڇڏڻ
            }
        }
        _ => Invalid, // پهرئين عدد واري تار کان پوءِ پيچرو ڇڏڻ
    }
}

/// پهرين غير عددي ڪردار تائين ڊيمل انگن کي ڪي ٿو.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// غير معمولي اضافي ۽ غلطي جي چڪاس.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // توڪل کان پوءِ پيچرو ڇڏڻ
    }
    if number.is_empty() {
        return Invalid; // خالي تڪڙو
    }
    // ھن پوائنٽ تي ، اسان وٽ يقيني طور تي انگن اکرن جو صحيح پٿر آھي.اهو `i64` ۾ لڳائڻ گهڻو ڊگهو ٿي سگهي ٿو ، پر جيڪڏهن اهو وڏو آهي ، انڪشاف يقينا صفر يا لا محدود آهي.
    // چونکہ صفر عددن ۾ هر صفر صرف نمودار کي +/-1 سان طئي ڪري ٿو ، exp=10 ^ 18 تي انپٽ لا محدود ٿيڻ جي ويجھو به ويجهڙائي حاصل ڪرڻ لاءِ صفر جي 17 ايڪسبي ايڪس ايڪس ايڪس هجڻ گهرجي ها.
    //
    // هي اصل ۾ ڪو استعمال ڪيس نه آهي اسان کي پورو ڪرڻ جي ضرورت آهي.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}