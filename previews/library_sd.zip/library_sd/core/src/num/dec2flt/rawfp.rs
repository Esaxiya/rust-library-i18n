//! مثبت IEEE 754 فلوٽس تي ساڙڻ.منفي نمبر نه آهن ۽ هٿ نه هئڻ گهرجن.
//! عام فلوٽنگ پوائنٽ نمبر ھڪ ڪنياتي نمائندگي ڪندا آھن جيئن (frac ، exp) اھڙو قدر 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>))) جتي N جي بٽس جو تعداد آھي.
//!
//! غير معمولي ڪجهه مختلف ۽ انوکو آهي ، پر اهو ساڳيو اصول لاڳو ٿئي ٿو.
//!
//! هتي ، جيتوڻيڪ ، اسان انهن کي نمائندگي ڪريون ٿا (سيگ ، ڪ) ف مثبت سان ، جهڙوڪ قدر f *
//! 2 <sup>اِي</sup> ."hidden bit" واضح طور تي ٺاهڻ کان علاوه ، هي نامياري منٿيسا شفٽ پاران ترقي ڪندڙ کي تبديل ڪري ٿو.
//!
//! ٻيو رستو رکون ، عام طور تي فلوٽس (1) وانگر لکجن ٿيون پر هتي اهي (2) وانگر لکجن ٿيون:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! اسان ڪال ڪريو (1)**fractional representation** ۽ (2)** ** مڪمل نمائندگي **.
//!
//! ھن ماڊل ۾ ڪيترائي افعال رڳو عام تعداد کي سنڀاليندا آھن.Dec2flt معمولي تمام نن smallن ۽ تمام وڏي تعداد لاءِ عالمي سطح تي صحيح سستي رستي (الورگيتم ايم) کي قدامت سان وٺن ٿا.
//! اهو الگورتھم صرف next_float() جي ضرورت آهي جيڪو غير معمولي ۽ صفر کي سنڀاليندو آهي.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// ھڪڙي مددگار trait نقل ڪرڻ کان بچڻ لاءِ بنيادي طور تي `f32` ۽ `f64` لاءِ سڀ تبديلي ڪوڊ.
///
/// ڏسو اهو ڇو ضروري آهي والدين ماڊل ماڊل جي دستاويزي راءِ.
///
/// ڇا ڪڏهن به ** ڪڏهن به ٻين قسمن لاءِ لاڳو نه ٿيڻ گهرجي يا dec2flt ماڊل کان ٻاهر استعمال ٿيڻ گهرجي.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// قسم `to_bits` ۽ `from_bits` پاران استعمال ڪيل.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// هڪ انوٽر تائين خام منتقلي ڪندو آهي.
    fn to_bits(self) -> Self::Bits;

    /// هڪ انوٽر کان خام ٽرانسڪشن انجام ڏيو.
    fn from_bits(v: Self::Bits) -> Self;

    /// درجه بندي واپس ڪري ٿو جيڪا هن نمبر ۾ اچي ٿي.
    fn classify(self) -> FpCategory;

    /// منسٽر ، مودي ۽ نشاني انگ کي واپس ڪري ٿو.
    fn integer_decode(self) -> (u64, i16, i8);

    /// فلوٽ کي رد ڪري ٿو.
    fn unpack(self) -> Unpacked;

    /// هڪ نن integي انڌيري تان ورتل جنهن کي پوري طرح نمائندگي ڪري سگهجي ٿو.
    /// Panic جيڪڏهن انٽيگر نمائندگي نه ٿي ڪري سگهجي ، هن ماڊل ۾ ٻيو ڪوڊ يقيني بڻائي ٿو ته ڪڏهن اهو ٿيڻ نه ڏيو.
    fn from_int(x: u64) -> Self;

    /// اڳ ڳڻپيل ٽيبل مان 10 <sup>اي</sup> ويليو حاصل ڪري ٿو.
    /// 0Panics لاء `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// نالو ڇا ٿو چوي.
    /// اهو اندروني ڪوڊ کي جڙڻ کان وڌيڪ سخت ڪوڊ آسان آهي ۽ اميد آهي ته ايل ايل ايم ايم مسلسل ان کي foldڪيندي.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // محافظن جي عددي انگن تي هڪ قدامت پسند پابند جيڪو اوور فلو يا صفر پيدا نه ڪري سگهي
    /// غير معمولي.ممڪن طور تي وڌ کان وڌ عام ويليوز جي ڊيزائن واري عيوض ، يعني نالو.
    const MAX_NORMAL_DIGITS: usize;

    /// جڏهن کان وڌيڪ اهم ڊيزيڪل عدد انهي جي جڳهه کان وڌيڪ هوندي آهي ، نمبر لازمي طور تي دائمي طور تي گول هوندو آهي.
    ///
    const INF_CUTOFF: i64;

    /// جڏهن سڀ کان اهم ڊيزيڪل عدد ھن کان گھٽ جڳھ قدر آھي ، نمبر يقيني طور صفر تائين گول آھي.
    ///
    const ZERO_CUTOFF: i64;

    /// ياداشت ۾ بٽس جو تعداد.
    const EXP_BITS: u8;

    /// بيت جي تعداد ۾ ، بشمول *بشمول* لڪيل بٽ.
    const SIG_BITS: u8;

    /// بيت جو تعداد وڏي پئماني تي ،*بغير* پوشیدہ بِٽ کي.
    const EXPLICIT_SIG_BITS: u8;

    /// وڌ ۾ وڌ قانوني توجهه رکندڙ فڪر ۾ نمائندگي.
    const MAX_EXP: i16;

    /// جزوي نمائندگي ۾ گھٽ قانوني توجهه ، سواءِ غير معمولي.
    const MIN_EXP: i16;

    /// `MAX_EXP` لازمي نمائندگي لاءِ ، يعني شفٽ لاڳو ٿيندي آهي.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` انڪوڊ ٿيل (يعني آفسيٽ تعصب سان)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` لازمي نمائندگي لاءِ ، يعني شفٽ لاڳو ٿيندي آهي.
    const MIN_EXP_INT: i16;

    /// وڌ کان وڌ معمولي شڪل ۾ انگ اکر جي نمائندگي.
    const MAX_SIG: u64;

    /// گهٽ ۾ گهٽ معمولي معنيٰ اجرڪ جي نمائندگي ۾.
    const MIN_SIG: u64;
}

// گهڻو ڪري هڪ ايڪس ريڪس لاءِ ايڪس ويڪس.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// منسٽر ، مودي ۽ نشاني انگ کي واپس ڪري ٿو.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // غير معمولي تعصب + منٽا شفٽ
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe غير يقيني آھي ته ڇا `as` صحيح طور تي س platformsو پليٽ فارمز تي آھي.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// منسٽر ، مودي ۽ نشاني انگ کي واپس ڪري ٿو.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // غير معمولي تعصب + منٽا شفٽ
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe غير يقيني آھي ته ڇا `as` صحيح طور تي س platformsو پليٽ فارمز تي آھي.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` ويجهي مشين فلوٽ جي قسم ۾ تبديل ڪري ٿي.
/// غير معمولي نتيجا نه سنڀاليندو آهي.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 بٽ آهي ، تنهن ڪري ايڪس ايڪس جي 63 جي منتر شفٽ آهي
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64-bit اهميت کي T::SIG_BITS بٽس اڌ گول ڪرڻ تائين.
/// exponent overflow کي نه سنڀاليندو آهي.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // منٿيس شفٽ کي ترتيب ڏيو
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// عام انگن اکرن لاءِ `RawFloat::unpack()` جي انڌ.
/// Panics جيڪڏهن اهميت يا عروج عام انگن اکرن لاءِ صحيح نه آهن.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // لڪيل بٽ ڪيو
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // غير جانبدار تعصب ۽ منٽيسي شفٽ لاءِ ايڪسپورٽ کي ترتيب ڏيو
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 0 ("+") تي سائن بٽ ڇڏي ڏيو ، اسان جا نمبر مثبت آهن
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// هڪ غير معمولي تعمير ڪريو.0 جو هڪ منتر اجازت ڏنل آهي ۽ صفر تعمير ڪري ٿو.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // انڪوڊ ٿيل Exponent 0 آهي ، نشاني بٽ 0 آهي ، تنهن ڪري اسان کي صرف بٽس جي ٻيهر وضاحت ڪرڻي آهي.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// تقريبن ھڪڙي بي ايف ايم ايف سان گڏ.اڌ کان به ويڪر تائين 0.5 ULP اندر رائونڊ.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // اسان ايڪس ايڪس ايڪس ايڪس انڊيڪس کان اڳ سڀني بٽس ڪٽيو ، يعني ، اسان نموني طور تي `start` جي هڪ مقدار سان صحيح شفٽ ڪئي سين ، تنهن ڪري اهو پڻ ضروري آهي جيڪو اسان کي گهرجي.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // گول (half-to-even) ٽريل بٽس تي منحصر آهي.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// دليل جي لحاظ کان تمام نن floڙو سچل پوائنٽ وارو نمبر ڳولي لهي ٿو.
/// ذيلي غير معمولي ، صفر ، يا غير معمولي هيٺيان وهڪرو نه سنڀاليندو آهي.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// نن smallestڙو سچل پوائنٽ وارو انگ اکر ڳوليو دليل کان سخت.
// ھي آپريشن سنياني آھي ، يعني ، next_float(inf) ==inf.
// ھن ماڊل ۾ اڪثر ڪوڊن جي برعڪس ، ھي ڪم صفر ، غير معمولي ۽ لامحدود کي سنڀاليندو آھي.
// تنهن هوندي ، هتي ٻين سڀني ڪوڊ وانگر ، اهو نمبر بي نمبر ۽ منفي نمبرن سان نه هلندو آهي.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // اهو لڳي ٿو ته اهو سٺو آهي ، پر اهو ڪم ڪري ٿو.
        // 0.0 صفر لفظ طور ڪوڊ ٿيل آهي.غير معمولي ايڪس ايمڪس ايم آهي ... ايم جتي مٽرتا آهي.
        // خاص طور تي ، سڀ کان نن subو غير معمولي 0x0 ... 01 آهي ۽ سڀ کان وڏو 0x000F آهي ... ايف.
        // نن normalڙو عام نمبر 0x0010 ... 0 آهي ، تنهنڪري اهو ڪنڊ ڪيس پڻ ڪم ڪري ٿو.
        // جيڪڏهن وڌندڙ منٿيسا کي وڌائي ٿو ، ڪيري بٽ وڌندڙ کي وڌائيندو آهي جئين اسان چاهيو ٿا ، ۽ منٽيسا بٽ صفر ٿي وڃن ٿا.
        // لڪيل بٽ ڪنوينشن جي ڪري ، اهو پڻ بلڪل صحيح آهي جيڪو اسان چاهيون ٿا!
        // آخرڪار ، f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}