//! بينگينم جي افاديت افعال جيڪي طريقن ۾ تبديل ٿيڻ جي گهڻي معنيٰ نه رکن ٿا.

// FIXME هن ماڊل جو نالو ٿورڙو بدقسمتي آهي ، ڇاڪاڻ ته ٻيا ماڊل `core::num` پڻ درآمد ڪن ٿيون.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// جانچ ڪريو ته ڇا نن00ن نن trن نن trن نن trن نن significantن نن trن نن trن نن trن نن introdن نن introdن نن introdن نن introdن برابر ، گهٽ برابر ، يا 0.5 يو ايل پي کان وڌيڪ متعارف ڪرايو.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 يو ايل پي
        return Less;
    }
    // جيڪڏهن سڀ باقي بٽ صفر آهن ، اهو آهي= 0.5 ULP ، ٻي صورت ۾> 0.5 جيڪڏهن وڌيڪ بٽس نه آهن (half_bit==0) ، هيٺيون به صحيح طور تي برابر موٽائي ٿو.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// هڪ ASCII اسٽرنگ کي تبديل ڪري ٿو جنهن ۾ صرف ڊيمل ايڪس عددن تي مشتمل آهي هڪ `u64` ڏانهن.
///
/// اوور فلو يا غلط اکرن جي چڪاس نه ٿو ڪري ، تنھنڪري جيڪڏھن سڏيندڙ محتاط ناھي ، نتيجو ڪوڙو ۽ panic ڪري سگھي ٿو (جيتوڻيڪ اھو `unsafe` نہ ٿيندو).
/// اضافي طور تي ، خالي تارون صفر جي طور تي علاج ٿيل آهن.
/// اهو فنڪشن موجود آهي ڇاڪاڻ
///
/// 1. استعمال ڪري `FromStr` `&[u8]` تي `from_utf8_unchecked` جي ضرورت آھي ، جيڪو خراب آھي ، ۽
/// 2. `integral.parse()` ۽ `fractional.parse()` جي نتيجن کي گڏ ڪرڻ انهي پوري فنڪشن کان وڌيڪ پيچيده آهي.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII عددن جي هڪ تار کي بگنم ۾ تبديل ڪري ٿو.
///
/// `from_str_unchecked` وانگر ، هي فنڪشن پارسر تي ڀروسو ڪري ٿو غير عددن کي ختم ڪرڻ.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// بينگم کي 64 بٽ انٽيگر ۾ خراب ڪري ٿو.Panics جيڪڏهن نمبر وڏو آهي.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// بٽس جي حد کي ڪي ٿو.

/// انڊيڪس 0 گهٽ ۾ گهٽ اھم بِٽ آھي ۽ حد معمولي طور تي اڌ کليل آھي.
/// Panics جيڪڏهن واپسي واري قسم ۾ مناسب کان وڌيڪ بٽس ڪ toڻ لاءِ چيو وڃي.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}