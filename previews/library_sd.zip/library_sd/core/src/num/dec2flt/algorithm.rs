//! ڪاغذن کان مختلف الگورڊس.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp ۾ اھم بٽس جو تعداد
const P: u32 = 64;

// اسان بس مڪمل طور تي چڪاس ڪيون ٿا *سڀ* توجهه ڏيندڙن جي لاءِ ، تنهنڪري متغير "h" ۽ لاڳاپيل حالتون ختم ٿي سگهن ٿيون.
// اهو ٻلهن ڪلو بائيٽ جي جڳهه لاءِ ڪارڪردگي ڏيکاري ٿو.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// اڪثر عمارتن ۾ ، فلوٽنگ پوائنٽ آپريشنن جو پڌرو سا انگ آهي ، تنهن ڪري ڳڻپيوڪر جي درستگي هر آپريشن جي بنياد تي طئي ڪئي وئي آهي.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// x86 تي ، x87 FPU فلوٽ جي آپريشن لاءِ استعمال ٿئي ٿي جيڪڏهن SSE/SSE2 ايڪسٽينشن موجود نه آهي.
// x87 FPU ڊفالٽ جي درستگي جي 80 بٽس سان هلندي آهي ، جنهن جو مطلب آهي ته آپريشنز 80 بٽ تي ٿيندي.
//
// 32/64 سا flا فلوٽ ويلس.ان تي قابو پائڻ لاءِ FPU ڪنٽرول لفظ مقرر ڪري سگهبو ته جيئن ڳڻپيوڪريون مطلوبا درستگيءَ سان ڪن.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// ايف پي پي ڪنٽرول لفظ جي اصلي قدر کي محفوظ ڪرڻ لاءِ هڪ جوڙجڪ استعمال ڪئي وئي ، انهي جي ڪري اهو بحالي اچي سگهيو آهي جڏهن ته جوڙجڪ گهٽجي وڃي.
    ///
    ///
    /// x87 FPU هڪ 16 بٽ رجسٽرڊ آهي جنهن جا شعبا هن ريت آهن:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// سڀني شعبن لاءِ دستاويز IA-32 آرڪيٽيڪچر سوفٽويئر ڊيولپر دستياب (حجم 1) ۾ موجود آهي.
    ///
    /// صرف فيلڊ جيڪو هيٺيان ڪوڊ سان لاڳاپيل آهي پي سي ، پريسسيسي ڪنٽرول.
    /// هي ميدان FPU پاران ڪيل آپريشن جي درستگي جو تعين ڪري ٿو.
    /// اهو سيٽ تي ڪري سگهجي ٿو:
    ///  - 0b00 ، سنگل درستگي ، يعني 32 بٽ
    ///  - 0b10 ، ٻٻر سڌا ، يعني 64 بٽ
    ///  - 0b11 ، ٻلو وڌايل صحت واري يعني 80 بٽ (ڊفالٽ اسٽيٽ) 0b01 ويليو محفوظ ٿيل آھي ۽ استعمال نه ٿيڻ گھرجي.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // حفاظت: `fldcw` هدايت سان صحيح ڪم ڪيو ويو آهي صحيح طريقي سان ڪم ڪرڻ جي قابل
        // ڪوبه `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: اسان ايل ٽي وي ايم 8 ۽ ايل ايل وي ايم 9 کي سهائتا لاءِ اي ٽي ٽي نحو استعمال ڪري رهيا آهيون.
                options(att_syntax, nostack),
            )
        }
    }

    /// FPU جي سڌريل فيلڊ کي `T` ڏانھن مقرر ڪريو ۽ ايڪس X X X موٽائي ٿو.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // پريسٽي ڪنٽرول فيلڊ جي ويليو کي ڏسو جيڪو `T` لاءِ مناسب آھي.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 بٽ
            8 => 0x0200, // 64 بٽ
            _ => 0x0300, // ڊفالٽ ، 80 بٽس
        };

        // انهي کي بحال ڪرڻ جي لاءِ ڪنٽرول ورڊ جي اصل قيمت حاصل ڪريو بعد ۾ ، جڏهن `FPUControlWord` جو اڏاوت ڇڏيو وڃي محفوظ ڪريو: `fnstcw` هدايت ڪنهن به `u16` سان صحيح ڪم ڪرڻ جي قابل هجڻ لاءِ جاچ ڪئي وئي آهي.
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: اسان ايل ٽي وي ايم 8 ۽ ايل ايل وي ايم 9 کي سهائتا لاءِ اي ٽي ٽي نحو استعمال ڪري رهيا آهيون.
                options(att_syntax, nostack),
            )
        }

        // ڪنٽرول لفظ ترتيب واري حد تائين درست ڪريو.
        // اهو پراڻي تندرستي کي لڪائڻ سان حاصل ڪيو ويو آهي (بٽس 8 ۽ 9 ، 0x300) ۽ ان کي متبادل طريقي سان ڏنل درستگي پرچم کي تبديل ڪندي.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// مشين جي ماپ جا انٽيگر ۽ فلوٽنگ استعمال ڪندي بيلروفين جو تيز رستو.
///
/// هن کي هڪ الڳ فنڪشن ۾ ڪ isيو وڃي ٿو ته جيئن ان کي بنجي ٺاهڻ کان اڳ ڪوشش ڪري سگهجي.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // MAX_SIG جي آخري قيمت کي ويجهي ٿيندي آھي ، اھو صرف ھڪ تڪڙو ، سستا رد آھي (۽ باقي ڪوڊ کي انڊر فلو بابت پريشان ڪرڻ کان آزاد ڪري ٿو).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // تيز رفتار بنيادي طور تي عدديه تي بائيٽ جي صحيح نمبر تي گول ڪرڻ جي وچ تي ڀاڙيندڙ آهي.
    // x86 تي (ايس ايس اي يا SSE2 کانسواءِ) ھن کي x87 FPU اسٽيڪ جي درستگيءَ کي مٽائڻ جي ضرورت آھي ، ان ڪري اھو سڌو سنئون 64/32 بٽ کي گول ڪري ٿو.
    // `set_precision` فنڪشن کي درستگي جو خيال رکي ٿو جيڪا ان کي عالمي رياست ۾ تبديل ڪرڻ جي ضرورت آهي (جيئن x87 FPU جو ڪنٽرول لفظ).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // ڪيس اي <0 ٻئي branch ۾ فوڊ ڪري نه ٿو سگھجي.
    // ناڪاري طاقتن جو نتيجو بائنري ۾ جزوي ورها partي وارو حصو آهي ، جيڪي گول هوندا آهن ، جيڪي حتمي نتيجي ۾ غلط (۽ ڪڏهن ڪڏهن اهم)!
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// الورگيتم بيليوفرون هڪ مايوس ڪوڊ آهي غير ننrivڙي انگن اکرن واري چڪاس واري طريقي سان.
///
/// اهو "f" فلوٽ ڏانهن 64 بٽ جي اهميت سان ٺهڪي ٿو ۽ ان کي `10^e` جي بهترين انداز سان ملائي (جيڪا ساڳي فليٽ پوائنٽ واري شڪل ۾).اهو اڪثر ڪري صحيح نتيجو حاصل ڪرڻ لاءِ ڪافي هوندو آهي.
/// تنهن هوندي ، جڏهن نتيجو ٻن ويجهن (ordinary) فلوٽس جي وچ ۾ اڌ ويجهو هوندو ، مرڪب گولنگ جي غلطي ٻن تقريبن کي ضرب ڪرڻ جو مطلب اهو ٿيندو ته نتيجو ڪجهه بٽس کان پري ٿي سگهي ٿو.
/// جڏهن اهو ٿئي ٿو ، اهو ورثو الورگيتم آر شين کي درست ڪري ٿو.
///
/// هٿ-ويڪرو "close to halfway" ڪاغذ ۾ انگن اکرن جي تجزئي طرفان صحيح ڪئي وئي آهي.
/// ڪلينگر جي لفظن ۾:
///
/// > opلو ، گهٽ ۾ گهٽ اھم بڪ وارن يونٽن ۾ اظهار ٿيل ، غلطي لاءِ شامل آھي
/// > f * 10 ^ e کي ويجھو ڪرڻ واري فلوٽنگ پوائنٽ جي حساب سان جمع ڪيو ويو.(سلوڪ آھي
/// > صحيح غلطي جي لاءِ پابند ناهي ، پر ان جي فرق کي حد جي برابر آهي Z ۽
/// > بھترين ممڪن طريقو آھي جيڪو اھميت واري بائيٽس استعمال ڪري.
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // ڪيسن abs(e) <log5(2^N) fast_path() ۾ آهن
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // ڇا نپلس کي گول ڪرڻ جڏهن فرق ڪرڻ ڪافي آهي؟
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// اهو هڪ ورثي وارو الگورتھم جيڪو `f * 10^e` جي هڪ سچل نقطي کي بهتر ڪري ٿو.
///
/// هر ايراضيء کي آخري جڳهه ويجهي هڪ يونٽ حاصل ٿئي ٿو ، جو يقينا انتشار ڏا longو ڊگهو آهي جيڪڏهن `z0` ايستائين ٿورو ئي بند آهي.
/// خوش قسمتي سان ، جڏهن بيليروفون لاءِ فال بیک طور استعمال ٿئي ٿو ، شروعات وارو تعارف اڪثر هڪ يو ايل پي کان بند ٿيو آهي.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // مثبت انٽيگريجيون ڳوليو `x`، `y` جيئن `x / y` بلڪل `(f *10^e) / (m* 2^k)` آهي.
        // هي نه رڳو `e` ۽ `k` جي نشانين سان معاملو ڪرڻ کان بچي ٿو ، اسان به نمبرن کي نن toڙو بڻائڻ لاءِ ٻه عام ماڻهن کي `10^e` ۽ `2^k` جي طاقت کي ختم ڪيو.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // ھي ٿورو عجب طريقي سان لکيو ويو آھي ڇاڪاڻ تھ اسان جا بينيگمنٽ منفي نمبرن جي مدد نٿا ڪن ، تنھنڪري اسين پوري قدر استعمال ڪريو + نشاني informationاڻ.
        // ڪھاڻي_ m_digits سان واڌارو نٿو آڻي سگھي.
        // جيڪڏهن `x` يا `y` ڪافي وڏا آهن ته اسان کي اوور فلو بابت پريشان ٿيڻ گهرجي ، پوءِ اهي پڻ ڪافي وڏا آهن ته `make_ratio` ڪنهن عنصر کي 2 ^ 64 يا وڌيڪ کان وڌيڪ حصو گھٽائي ڇڏيو آهي.
        //
        //
        let (d2, d_negative) = if x >= y {
            // وڌيڪ ايڪس جي ضرورت نه آهي ، هڪ clone() بچايو.
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // اڃان يو جي ضرورت آهي ، ڪاپي ٺاهي وٺو.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// ڏنو ويو `x = f` ۽ `y = m` جتي `f` عام طور تي انپٽ ڊيزيڪل عددن جي نمائندگي ڪندو آهي ۽ `m` سچل نقطي جي تقريبن جي اھميت آھي ، تناسب `x / y` کي `(f *10^e) / (m* 2^k)` جي برابر ڪريو ، ممڪن طور تي ٻنھي جي طاقت گھٽائي عام ٿي چڪي آھي.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e ، y=م* 2 ^ k ، سواءِ ان جي ته اسين ٻن جي ڪجهه طاقت ذريعي حصو گھٽائي سگھون.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k) ، y=m اهو ختم نٿو ٿي سگهي ڇاڪاڻ ته اهو مثبت `e` ۽ منفي `k` جي ضرورت آهي ، جيڪو صرف 1 جي ويجهو قدرن لاءِ ٿي سگهي ٿو ، جنهن جو مطلب اهو آهي ته `e` ۽ `k` نسبتا نن tinyا هوندا.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f ، y=m *10^abs(e)* 2 ^ k اهو يا ته اوور فاعل نٿو ٿي سگهي ، مٿي ڏسو.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k) ، y=م* 10^abs(e) ، ٻيهر ھڪٻئي جي ٻني طاقت ذريعي گھٽائڻ.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// تصوراتي طور تي ، الورگيتم ايم هڪ عدليه کي فلوٽ ۾ تبديل ڪرڻ جو هڪ آسان طريقو آهي.
///
/// اسان هڪ تناسب ٺاهيون ٿا جيڪو `f * 10^e` جي برابر آهي ، پوءِ ٻن جي طاقتن ۾ اڇلائڻ تائين جيستائين اهو صحيح فلوٽ جي صحيحيت نه ڏئي.
/// بائنري غير ترقي ڪندڙ `k` ڪيترا ئي ڀيرا آھن جنھن کي ضرب ڪندڙ انگن اکرن يا تڪرار کي ٻن سان ضرب ڪريون ٿا ، يعني ھر وقت `f *10^e` `(u / v)* 2^k` برابر آھن.
/// جڏهن اسان نشانيون ڳولي چڪا آهيون ، اسان کي صرف ڊويزن جي باقي حصي جو معائنو ڪرڻ جي ضرورت آهي ، جيڪا هيٺ ڏنل مددگار افعال ۾ ڪئي وئي آهي.
///
///
/// هي الگورتھم سپر سست آهي ، اي سي ايڪس ايڪس ۾ بيان ڪيل اصلاح سان گڏ.
/// جڏهن ته ، اهو الگورتمگس جو آسان ترين آهي ترتيب ڏيڻ لاءِ وڌيڪ وهڪرو ، گهٽ وهڪرو ۽ ذيلي نتيجا ڏيڻ لاءِ.
/// اهو عملدرآمد تڏهن ختم ٿيندو آهي جڏهن بيلفرون ۽ الگورٿم آر وڏا هوندا آهن.
/// انڊر فلو ۽ اوور فلو کي ڳولڻ آسان آهي: تناسب اڃا تائين ڪي رينج واري اهميت وارو ناهي ، اڃا تائين minimum/maximum ايڪسپونٽ پهچي ويو آهي.
/// اوور فلو جي صورت ۾ ، اسان بس لامحدود موٽائيندا آهيون.
///
/// انڊر فلو ۽ غير معمولي ڪم کي هلائڻ ڏکيو آهي.
/// هڪ وڏو مسئلو اهو آهي ته ، گهٽ ۾ گهٽ خرچ ڪندڙ سان ، تناسب اڃا تائين وڏي اهميت لاءِ وڏو ٿي سگهي ٿو.
/// تفصيل لاءِ underflow() ڏسو.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME ممڪن ڪھڙي اصلاح: big_to_fp کي عام ڪريو ته جيئن اسان fp_to_float(big_to_fp(u)) جي برابر ھئن ڪري سگھون ، صرف بغير گول جي.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // اسان کي گهٽ ۾ گهٽ توجهه ڏيڻو آهي ، جيڪڏهن اسان `k < T::MIN_EXP_INT` تائين انتظار ڪندا ، ته پوءِ اسان ٻن جي هڪ عنصر کان پري ٿي وڃون ٿا.
            // بدقسمتي سان هن جو مطلب آهي اسان کي ڪيسن جي عام نمبرن کي گهٽ ۾ گهٽ وڌايندڙ سان.
            // فڪس ايم اي وڌيڪ خوبصورت فارموليشن ڳولي لڌو ، پر انهي کي پڪ ڪرڻ لاءِ `tiny-pow10` ٽيسٽ هلائڻ جي ڪوشش ڪريو!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// گھڻي ڊيگهه چڪاس ڪندي سڀ کان وڌيڪ الورگيتم مي ورشن تي ڇڏي ڏيو.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // بٽ لمبائي بي بنياد ٻن لاگرٿم جو هڪ تخمينو آهي ، ۽ log(u / v) = log(u) ، log(v).
    // گهڻو ڪري 1 کان ختم ٿي چڪو آهي ، پر هميشه هڪ نن anي تخميني ، تنهنڪري log(u) ۽ log(v) تي غلطي هڪ ئي نشاني جي آهن ۽ ان کي منسوخ ڪريو (جيڪڏهن ٻئي وڏا آهن).
    // تنهنڪري log(u / v) جي غلطي تمام گهڻيون ئي آهي.
    // ھدف جو تناسب ھڪڙو آھي جتي u/v ھڪڙي رينج جي اھميت ۾ آھي.اھڙي طرح اسان جي ختم ٿيڻ واري حالت log2(u / v) اھم آھي بٽس ، plus/minus ھڪڙي.
    // درست ڪريو سيڪنڊ بِٽ کي ڏسڻ سان اندازو بهتر ٿي سگهيو ۽ ڪجھ وڌيڪ ڊويزن کان پاسو ڪيو.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // انڊرروپ يا غير معمولي.ان کي ڇڏي ڏيو اصل ڪم ڏانهن.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // اوجاڳو.ان کي ڇڏي ڏيو اصل ڪم ڏانهن.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // تناسب گھٽ ۾ گھٽ توجهه ڏيندڙ سان گڏ رينج جي تعريف نه آهي ، تنهن ڪري اسان کي اضافي بٽيون گول ڪرڻ جي ضرورت آهي ۽ همعصر کي حساب سان ترتيب ڏيڻ.
    // اصلي قدر هاڻي هن وانگر لڳي ٿو:
    //
    //        x ايل ايس بي
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    ٽ ٽڪنڪ.(يادگيري سان ترتيب ڏيڻ)
    //
    // تنهن ڪري ، جڏهن گول بند ٿيل بٽ هوندا آهن!= 0.5 ULP ، اهي پنهنجي طور تي گولائي ڪرڻ جو فيصلو ڪن ٿا.
    // جڏهن اهي برابر آهن ۽ باقي نان-صفر آهي ، قيمت اڃا تائين گول ڪرڻ جي ضرورت آهي.
    // صرف جڏهن گول بند بٽ 1/2 آهن ۽ باقي صفر آهي ، اسان وٽ اڌ کان به وڌيڪ صورتحال آهي.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// عام گول کان ، اڃا تائين هڪ ڊويزن جي باقي رهڻ جي بنياد تي گول ٿي ويو.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}