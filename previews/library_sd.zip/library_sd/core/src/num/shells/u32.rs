//! 32-bit انگيز ٿيل انٽيگر قسم لاءِ ڪانسٽنٽ.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! نون ڪوڊ استعمال ڪندڙ قسطن کي سڌو آدمشماري جي قسم تي استعمال ڪرڻ گهرجي.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }