//! `f32` سنگل درستگي واري سچائي پوائنٽ جي قسم جي مخصوص.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! `consts` ذيلي ماڊل ۾ رياضياتي طور تي اهم انگ مهيا ڪيا ويندا آهن.
//!
//! هن ماڊل ۾ سڌي طرح بيان ڪيل قسطن وارن جي لاءِ (جيئن اهي `consts` ذيلي ماڊل ۾ بيان ٿيل آهن) ، نئون ڪوڊ بدران `f32` قسم تي سڌو سنئون constاڻايل مستحڪم استعمال ڪرڻ گهرجي.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f32` جي اندروني نمائندگي جو ريڊيڪس يا بنياد.
/// [`f32::RADIX`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // گهربل طريقو
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// بي بنياد 2 ۾ اھم انگن اکرن جو تعداد.
/// [`f32::MANTISSA_DIGITS`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // گهربل طريقو
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// بنياد 10 ۾ اھم انگن اکرن جو تعداد.
/// [`f32::DIGITS`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // گهربل طريقو
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] `f32` لاءِ قيمت.
/// [`f32::EPSILON`] جي بدران استعمال ڪريو.
///
/// اهو ئي فرق آهي `1.0` ۽ ايندڙ کان وڏي نمائندگي واري نمبر جي.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // گهربل طريقو
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// ننestو نن finو نن Xو `f32` قدر.
/// [`f32::MIN`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // گهربل طريقو
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// ننestي نن positiveڙي عام `f32` قدر.
/// [`f32::MIN_POSITIVE`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // گهربل طريقو
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// وڏي حد تائين محدود `f32` قدر.
/// [`f32::MAX`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // گهربل طريقو
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// ھڪڙو وڌندڙ عام طاقت 2 کان وڌيڪ وڌ کان وڌ ھڪڙو وڏو.
/// [`f32::MIN_EXP`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // گهربل طريقو
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// 2 وڌندڙ جي وڌ کان وڌ طاقت.
/// [`f32::MAX_EXP`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // گهربل طريقو
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// 10 وڌندڙ جي گهٽ ۾ گهٽ معمولي طاقت.
/// [`f32::MIN_10_EXP`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // گهربل طريقو
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// 10 وڌندڙن جي وڌ کان وڌ ممڪن بجلي.
/// [`f32::MAX_10_EXP`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // گهربل طريقو
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// نمبر (NaN) ناهي.
/// [`f32::NAN`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // گهربل طريقو
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// انفینٹی (∞).
/// [`f32::INFINITY`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // گهربل طريقو
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// منفي انفرافيشن (−∞).
/// [`f32::NEG_INFINITY`] جي بدران استعمال ڪريو.
///
/// # Examples
///
/// ```rust
/// // فرسوده رستو
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // گهربل طريقو
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// بنيادي رياضياتي ضابطو.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: ايم سيٿٿ کان رياضياتي محافظن سان مٽايو.

    /// آرڪييمينس جو مستقل (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// مڪمل دائرو مسلسل (τ)
    ///
    /// 2π جي برابر.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// ايولر جو نمبر (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// `f32` جي اندروني نمائندگي جو ريڊيڪس يا بنياد.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// بي بنياد 2 ۾ اھم انگن اکرن جو تعداد.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// بنياد 10 ۾ اھم انگن اکرن جو تعداد.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] `f32` لاءِ قيمت.
    ///
    /// اهو ئي فرق آهي `1.0` ۽ ايندڙ کان وڏي نمائندگي واري نمبر جي.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// ننestو نن finو نن Xو `f32` قدر.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// ننestي نن positiveڙي عام `f32` قدر.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// وڏي حد تائين محدود `f32` قدر.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// ھڪڙو وڌندڙ عام طاقت 2 کان وڌيڪ وڌ کان وڌ ھڪڙو وڏو.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// 2 وڌندڙ جي وڌ کان وڌ طاقت.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// 10 وڌندڙ جي گهٽ ۾ گهٽ معمولي طاقت.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// 10 وڌندڙن جي وڌ کان وڌ ممڪن بجلي.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// نمبر (NaN) ناهي.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// انفینٹی (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// منفي انفرافيشن (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// ايڪس ويڪس کي واپسي ڏي ٿو جيڪڏهن هي قيمت `NaN` آهي.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): بندرگاھ جي باري ۾ خدشات جي ڪري `abs` عوامي سطح تي دستياب ناھي ، تنھنڪري ھي نفاذ اندروني طور تي نجي استعمال لاءِ آھي.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// `true` کي واپسي ڏئي ٿو جيڪڏھن اھو قدر مثبت انفینٹی يا منفي لاتعداد ، ۽ `false` ٻي صورت ۾.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// `true` ورجائي ٿو جيڪڏھن اھو نمبر نه ئي لاتعداد آھي ۽ نه `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // اين اين کي الڳ الڳ سنڀالڻ جي ڪا ضرورت ناهي: جيڪڏهن خود اين اين آهي ته مقابلو درست نه آهي ، بلڪل جيترو گهربل آهي.
        //
        self.abs_private() < Self::INFINITY
    }

    /// جيڪڏهن نمبر [subnormal] هجي ته `true` واپس ڪري ٿو.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // `0` ۽ `min` جي وچ ۾ قدر غير معمولي آهن.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// `true` ورجائي ٿو جيڪڏھن نمبر نه صفر ، لاتعداد ، [subnormal] ، يا `NaN` آھي.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // `0` ۽ `min` جي وچ ۾ قدر غير معمولي آهن.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// نمبر واري فلوٽنگ پوائنٽ واري ڪيٽيگري کي واپس ڪري ٿو۔
    /// جيڪڏهن صرف هڪ ملڪيت جانچ ڪرڻ وڃي رهي آهي ، عام طور تي اها تيز predicate استعمال ڪرڻ بدران تيز آهي.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// `true` ورجائي ٿو جيڪڏھن `self` ھڪڙي ھڪڙي مثبت نشاني آھي ، بشمول `+0.0` ، "اين اين" کي مثبت نشاني بٽ ۽ مثبت لامحدود سان.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// `true` ورجائي ٿو جيڪڏھن `self` ھڪڙي منفي نشاني آھي ، `-0.0` سميت ، اين اين `منفي نشاني بٽ ۽ منفي لامحدود سان.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 چوي ٿو: isSignMinus(x) صحيح آهي جيڪڏهن ۽ صرف جيڪڏهن ايڪس منفي نشاني هوندي.
        // isSignMinus پڻ زيرو ۽ اين اين ايس تي لاڳو ٿئي ٿو.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// هڪ عدد جي انفرادي (inverse) وٺي ٿو، `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// شعاع کي ريگريز ۾ تبديل ڪندو آهي.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // بهتر صحت واري لاءِ مسلسل استعمال ڪيو.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// درجي کي ريڊين ۾ بدلائي ٿو.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// وڌ ۾ وڌ ٻن نمبرن کي واپس ڪري ٿو.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// جيڪڏهن هڪ دليل اين اين جي آهي ، ته ٻي دليل واپس ٿي ويندي آهي.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// گھٽ ۾ گھٽ ٻن نمبرن کي واپس ڪري ٿو.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// جيڪڏهن هڪ دليل اين اين جي آهي ، ته ٻي دليل واپس ٿي ويندي آهي.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// صفر جي طرف چڪر ڪري ٿو ۽ ڪنهن به بنيادي انٽيگر واري قسم ڏانهن بدلائي ٿو ، ڀورن کي ڀانئجي ٿو ته ويل ليول آهي ۽ انهي قسم ۾ مناسب آهي.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// قيمت ضرور
    ///
    /// * ايڪس ايڪس ايڪس نه بنو
    /// * لاتعداد نه
    /// * واپسي جي قسم `Int` ۾ نمائندگي ٿيڻ ، ان جي جزوي حصن کي ڪٽائڻ کان پوءِ
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // حفاظت: ڪال ڪندڙ کي `FloatToInt::to_int_unchecked` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u32` ڏانهن خام منتقلي.
    ///
    /// اهو في الحال `transmute::<f32, u32>(self)` جي سڀني پليٽ فارمن تي هڪجهڙائي آهي.
    ///
    /// `from_bits` ڏسو ھن آپريشن جي پورائيگيءَ بابت ڪجھ بحث لاءِ (تقريباً ڪو مسئلو ناھي)
    ///
    /// ياد رکجو ته اهو فنڪشن `as` ڪاسٽنگ کان ڌار آهي ، جيڪو *عددي* قيمت کي محفوظ ڪرڻ جي ڪوشش ڪري ٿو ، ۽ ساٿي واري قيمت تي نه.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() لوسٽ نه پيو وڃي!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // حفاظت: `u32` هڪ سادي پراڻي ڊيٽائپ آهي ، انهي ڪري اسان هميشه انهي ڏانهن منتقل ڪري سگهون ٿا
        unsafe { mem::transmute(self) }
    }

    /// `u32` کان خام منتقلي.
    ///
    /// اهو في الحال `transmute::<u32, f32>(v)` جي سڀني پليٽ فارمن تي هڪجهڙائي آهي.
    /// اهو ظاهر ٿيو ته اهو ناقابل اعتماد حد تائين پورٽبل آهي ، ٻن سببن جي ڪري:
    ///
    /// * فلوٽ ۽ انٽ سڀني سپورٽ ٿيل پليٽ فارمن تي هڪ جيتري حيثيت رکي ٿي.
    /// * IEEE-754 تمام صحيح طور تي فلوٽس جي بي ترتيب ترتيب ڏئي ٿو.
    ///
    /// تنهن هوندي به هڪ خبرداري آهي: IEEE-754 جي 2008 ورزن کان اڳ ، اين اين سگنلنگ بٽ جي وضاحت ڪئين ڪجي اصل طور تي بيان ٿيل ناهي.
    /// گهڻن پليٽ فارم (خاص طور تي x86 ۽ ARM) تفسير چونڊيو جيڪو آخرڪار 2008 ۾ معياري هو ، پر ڪجھ نه ڪيو (خاص طور تي MIPS).
    /// نتيجي طور ، MIPS تي سڀني سگنلنگ اين اينز x86 تي خاموش اين اينسز ، ۽ ان جي برعڪس.
    ///
    /// بلڪه سگنلنگ-نيس ڪراس پليٽ فارم کي محفوظ ڪرڻ جي ڪوشش ڪرڻ بدران ، هي عمل درآمد صحيح بٽس کي محفوظ ڪرڻ جي مدد ڪري ٿو.
    /// هن جو مطلب آهي ته اين اين ايس ۾ انڪوڊ ٿيل ڪنهن به پيون لوڊ کي محفوظ ڪيو ويندو جيتوڻيڪ جيڪڏهن هن طريقي جو نتيجو ايڪس نيٽ ايڪس مشين کان MIPS هڪ نيٽورڪ تي موڪليو وڃي.
    ///
    ///
    /// جيڪڏهن هن طريقي جا نتيجا فقط ساڳيو تعميراتي طريقي سان هٿ ڪيا وڃن جيڪي انهن کي پيدا ڪن ، ته اتي پورائيتيت جو خدشو ناهي.
    ///
    /// جيڪڏهن انٽيشن اين اين ناهي ، انهي جي پورائييت بابت ڪا به ڳڻتي ناهي.
    ///
    /// جيڪڏهن توهان سگنلنگ جي پرواه نه ڪندا (تمام گهڻو ممڪن) ، پوءِ پورٽيبليت جا انديشو ناهن.
    ///
    /// ياد رکجو ته اهو فنڪشن `as` ڪاسٽنگ کان ڌار آهي ، جيڪو *عددي* قيمت کي محفوظ ڪرڻ جي ڪوشش ڪري ٿو ، ۽ ساٿي واري قيمت تي نه.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // حفاظت: `u32` هڪ سادي پراڻي ڊيٽائپ آهي ، انهي ڪري اسان هميشه انهي مان منتقل ڪري سگهون ٿا
        // اهو sNaN سان حفاظت جا مسئلا ختم ٿي ويا!اڙي!
        unsafe { mem::transmute(v) }
    }

    /// انهي سچل واري پوائنٽ جي يادگيري نمائندگي کي بائيٽ آرڊر جي بائيٽ ائنڊين (network) بائيٽ آرڊر ۾ واپس ڪريو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// نن-ي-ائنٽي بائيٽ آرڊر ۾ بائيٽ صف جي طور تي فلوٽنگ پوائنٽ نمبر جي يادگيري نمائندگيءَ کي واپس آڻيو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// اصلي byte آرڊر ۾ بائيٽ صف جي طور تي فلوٽنگ پوائنٽ نمبر جي يادگيري نمائندگي واپس آڻيو.
    ///
    /// جئين ٽارگيٽ پليٽ فارم جي اصلي برداشت استعمال ڪئي وئي آهي ، پورٽبل ڪوڊ کي [`to_be_bytes`] يا [`to_le_bytes`] استعمال ڪرڻ گهرجي ، مناسب طور تي ، بدران.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// اصلي byte آرڊر ۾ بائيٽ صف جي طور تي فلوٽنگ پوائنٽ نمبر جي يادگيري نمائندگي واپس آڻيو.
    ///
    ///
    /// [`to_ne_bytes`] جڏهن ممڪن ٿي سگھي ، هن کي ترجيح ڏيڻ گهرجي.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // حفاظت: `f32` هڪ سادي پراڻي ڊيٽائپ آهي ، انهي ڪري اسان هميشه انهي ڏانهن منتقل ڪري سگهون ٿا
        unsafe { &*(self as *const Self as *const _) }
    }

    /// انهي جي نمائندگي ڪرڻ کان فلوٽنگ پوائنٽ ويليو ٺاهيو بائيٽ آرٽ جي طور تي وڏي اينڊان ۾.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// نن endي اينڊين ۾ بائيٽ صف جي طور تي ان جي نمائندگي مان فلوٽنگ پوائنٽ ويليو ٺاهيو.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// آبائی endian ۾ بائيٽ صف جي طور تي ان جي نمائندگي مان سچل پوائنٽ قدر ٺاھيو.
    ///
    /// جئين ٽارگيٽ پليٽ فارم جي اصلي برداشت وارو استعمال ٿيندو آهي ، پورٽبل ڪوڊ ممڪن طور تي [`from_be_bytes`] يا [`from_le_bytes`] استعمال ڪرڻ چاهيندو آهي ، ان جي بدران مناسب طور تي.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// نفس ۽ ٻين قدرن جي وچ ۾ هڪ حڪم گهري ٿو.
    /// سچل پوائنٽ جي انگن اکرن جي وچ ۾ معياري جزوي مقابلو جي مقابلي ۾ ، اهو مقابلو هميشه ڪل آرڊر جي اڳڪٿي مطابق IEEE 754 (2008 revisi) floating point standard ۾ بيان ڪيل ترتيب ڏيندو آهي.
    /// قدرن کي هيٺين ترتيب ۾ ترتيب ڏنو ويو آهي.
    /// - ناڪاري چپ اين اين
    /// - ناڪاري سگنل اين اين
    /// - ناڪاري لامحدود
    /// - ناڪاري نمبر
    /// - منفي غير معمولي نمبر
    /// - ناڪاري زيرو
    /// - مثبت صفر
    /// - مثبت غير معمولي نمبر
    /// - هاڪاري انگ
    /// - مثبت لامحدود
    /// - مثبت سگنل اين اين
    /// - مثبت خاموش اين اين
    ///
    /// ياد رکجو ته اهو فنڪشن `f32` ۽ [`PartialEq`] جي `f32` عملن سان هميشه متفق ناهي.خاص طور تي ، انهن منفي ۽ مثبت صفر جي برابر سمجهيو ٿا ، جڏهن ته `total_cmp` نه آهي.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // منفيات جي صورت ۾ ، ٻئي بٽ کي فلپ ڪريو نشاني کانسواءِ هڪ ٻئي لي آئوٽ حاصل ڪرڻ لاءِ جيترو ٻٽو پوري ڪرڻ گهرجي
        //
        // هي ڪم ڇو ٿو ڪري؟آئي اي اي 754 فلوٽس ٽن شعبن تي مشتمل آهن:
        // نشاني بٽ ، عاليشان ۽ منشا.مجموعي طور تي فطرتي ۽ منٿيسا شعبن جي سيٽ اها ملڪيت آهي ته انهن جو ننwiseڙو حڪم عددي شدت جي برابر آهي جتي شدت بيان ڪئي وئي آهي.
        // عام طور تي اين اين قدرن تي عام طور تي بيان ٿيل نه هوندو آهي ، پر IEEE 754 totalOrder به ننwiseي حڪم جي پيروي ڪرڻ لاءِ NaN قدرن جي تعريف ڪندو آهي.ھن دائيري ۾ تبصرو بيان ڪيو آھي.
        // تنهن هوندي ، قد جي نمائندگي منفي ۽ مثبت انگن جي لاءِ ساڳيو آهي-صرف نشاني بٽ به مختلف آهي.
        // صحيح طور تي صحيح انگ کي گڏ ڪرڻ لاءِ ، منفي نمبرن جي صورت ۾ اسان کي خيالي ۽ منٽيسي بٽ toلڻ گهرجن.
        // اسان مؤثر نموني نمبرن کي "two's complement" فارم ۾ تبديل ڪيو.
        //
        // فلپنگ ڪرڻ لاءِ ، اسان ان جي خلاف نقاب ۽ ايڪس او آر تعمير ڪريون ٿا.
        // اسان برانچ لائن کان منفي-سائن ٿيل قدرن مان "all-ones except for the sign bit" ماسڪ شمار ڪريو ٿا: صحيح شفٽنگ سائين انٽيگر کي وڌائيندو آهي ، تنهن ڪري اسان "fill" ماسڪ سائن بٽس سان ، ۽ پوءِ هڪ وڌيڪ صفر بِٽ کي ڌڪڻ لاءِ دستخط ۾ تبديل ڪيو.
        //
        // مثبت قدرن تي ، ماسڪ سڀ صفر آهي ، تنهن ڪري اهو ڪو اوپي آهي.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// ھڪڙي قيمت کي ھڪڙي وقتي تائين محدود ڪريو جيستائين جيستائين اين اين ناھي.
    ///
    /// جيڪڏهن `self` `max` کان وڌيڪ آهي ، ۽ `min` جيڪڏهن `self` کي `min` کان گهٽ آهي ، واپس اچي ٿو.
    /// ٻي صورت ۾ هي `self` موٽائي ٿو.
    ///
    /// اهو نوٽ ڪريو ته هي فنڪشنل اين اين کي موٽائيندو آهي جيڪڏهن شروعاتي قيمت پڻ اين اين هوندي هئي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `min > max` ، `min` اين اين آهي ، يا `max` اين اين آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}