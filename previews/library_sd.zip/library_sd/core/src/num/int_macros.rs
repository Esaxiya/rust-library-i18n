macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// نن valueي قيمت جيڪا هن انٽيگر قسم مان ظاھر ڪري سگھي ٿي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// سڀ کان وڏو قدر جيڪو هن انٽيگر قسم مان ظاھر ڪري سگھي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// هن انگ ۾ موجود انٽيگر قسم جو قد.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// ھڪڙي ترتيب واري اسٽرنگ کي ھڪڙي بنيادي بنياد ۾ انٽيگر ڏانھن بدلائي ٿو.
        ///
        /// انگن اکرن کي ھڪڙو اختياري `+` يا `-` نشان لڳڻ جي توقع ڪئي وڃي ٿي ہندس جي پٺيان.
        /// خالي ۽ ڳرندڙ وائ اسپيس هڪ نقص جي نمائندگي ڪن ٿا.
        /// انگن اکرن کي اهڙن ڪردارن جو هڪ سبٽيوٽ آهي ، انحصار `radix` تي:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// اهو ڪم panics جيڪڏهن `radix` 2 کان 36 تائين جي حد ۾ ناهي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` جي بائنري نمائندگي ۾ نمبرن کي واپسي ڏيکاري ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// `self` جي بائنري نمائندگي ۾ صفر جو تعداد ورجائي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` جي بائنري نمائندگي ۾ معروف زيرو جو تعداد واپس ڏئي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// `self` جي بائنري نمائندگي ۾ پيچرو زيرو جو تعداد واپس ڏئي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// `self` جي بائنري نمائندگي ۾ معروف وارن جو تعداد موٽائي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// `self` جي بائنري نمائندگي ۾ پيچرو ڇڪندڙن جو تعداد واپس ڏئي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// بٽ کي کاٻي طرف منتقل ڪيو ويو آھي ھڪڙي مخصوص مقدار جي ذريعي ، ايڪس X ايڪس ايمڪس ، نتيجن واري عدد جي آخر تائين ڪٽي ٿيل بٽ کي appingيريندي.
        ///
        ///
        /// مهرباني ڪري نوٽ ڪريو ته اهو ساڳيو آپريشن `<<` شفٽنگ هلائيندڙ وانگر ناهي!
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// نتيجي واري انگن اکرن جي شروعات تائين بٽ کي متعين ٿيل رقم ، ايڪس ايڪس ايمڪس ، سا toي طرف منتقل ڪري ٿو.
        ///
        ///
        /// مهرباني ڪري نوٽ ڪريو ته اهو ساڳيو آپريشن `>>` شفٽنگ هلائيندڙ وانگر ناهي!
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// انڌيري جي بائيٽ آرڊر کي مٽائي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// اچو م=ايڪسڪسيمڪس ؛
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// انٽيگر ۾ بٽس جي ترتيب کي رد ڪري ٿو.
        /// گهٽ ۾ گهٽ اھم بِٽ تمام اھم بِٽ ٿي ويندو آھي ، ٻيو گھٽ اھم بِٽ ٻيو تمام اھم بِٽ ، وغيره
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// اچو م=ايڪسڪسيمڪس ؛
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// وڏي اينٽيرين کان هدف کي اخريق جي حد تائين بدلائي ٿو.
        ///
        /// وڏي پيماني تي اهو هڪ او پي ڪونهي.نن endي آخرڪار طرف بائٽس مٽايو پيو وڃي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// جيڪڏهن cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } ٻيا {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// نن endي ائيرين کان انگ کي بدلائي ٿو ٽارگيٽ جي پڇاڙي تائين.
        ///
        /// ٿورين انٽرنيٽ تي اهو ڪونهي.وڏي پيماني تي بائٽس مٽايو پيو وڃي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// جيڪڏهن cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } ٻيا {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// `self` کي وڏين بيڪيٽ کي ھدف جي پڇاڙي کان بدلائي ٿو.
        ///
        /// وڏي پيماني تي اهو هڪ او پي ڪونهي.نن endي آخرڪار طرف بائٽس مٽايو پيو وڃي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// جيڪڏهن cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } ٻيا { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // يا نه هئڻ؟
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// `self` کي ھدف واري ننianڙي واري نن endڙي واري ايشيان ۾ بدلائي ٿو.
        ///
        /// ٿورين انٽرنيٽ تي اهو ڪونهي.وڏي پيماني تي بائٽس مٽايو پيو وڃي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// جيڪڏهن cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } ٻيا { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// انٽيگر اضافو شامل ڪيو ويو.
        /// ڳڻپيوڪر `self + rhs` ، واپسي `None` جيڪڏهن اوور فلو ٿي وئي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// غير جانچيل انجير اضافي.`self + rhs` کي ڳڻيندو آهي ، فرض ڪريو اوور فلو نه ٿي سگھي.
        /// اھو نتيجو اڻ سڌريل رويو ۾ جڏھن
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // حفاظت: ڪال ڪندڙ کي `unchecked_add` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// چڪاس ٿيل انٽيگرنٽ ڪٽ.
        /// ڳڻپيوڪر `self - rhs` ، واپسي `None` جيڪڏهن اوور فلو ٿي وئي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// غير محفوظ انضمام غير محفوظ.`self - rhs` کي ڳڻيندو آهي ، فرض ڪريو اوور فلو نه ٿي سگھي.
        /// اھو نتيجو اڻ سڌريل رويو ۾ جڏھن
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // حفاظت: ڪال ڪندڙ کي `unchecked_sub` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// چڪاس ڪندڙ عدد ضرب.
        /// ڳڻپيوڪر `self * rhs` ، واپسي `None` جيڪڏهن اوور فلو ٿي وئي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// اڻ جانچيل عدد ضرب.`self * rhs` کي ڳڻيندو آهي ، فرض ڪريو اوور فلو نه ٿي سگھي.
        /// اھو نتيجو اڻ سڌريل رويو ۾ جڏھن
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // حفاظت: ڪال ڪندڙ کي `unchecked_mul` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// چيڪ ڪيل انٽيگر ڊويزن.
        /// `self / rhs` جو حساب ڏئي ٿو ، `None` موٽائي رهيو آھي جيڪڏھن `rhs == 0` يا ڊويزن جو نتيجو اوور فلو ۾ آھي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // حفاظت: صفر سان ورهايو ويو آهي ۽ INT_MIN طرفان مٿي ڏنل چڪاس ڪئي وئي آهي
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// چيڪ ڪيو ويو يوڪلائيڊان ڊيوٽي.
        /// `self.div_euclid(rhs)` جو حساب ڏئي ٿو ، `None` موٽائي رهيو آھي جيڪڏھن `rhs == 0` يا ڊويزن جو نتيجو اوور فلو ۾ آھي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// چڪاس ڪندڙ انجير باقي رهيل آهي.
        /// `self % rhs` جو حساب ڏئي ٿو ، `None` موٽائي رهيو آھي جيڪڏھن `rhs == 0` يا ڊويزن جو نتيجو اوور فلو ۾ آھي.
        ///
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // حفاظت: صفر سان ورهايو ويو آهي ۽ INT_MIN طرفان مٿي ڏنل چڪاس ڪئي وئي آهي
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// چيڪ ڪيو ويو ايوليڊين باقي.
        /// `self.rem_euclid(rhs)` جو حساب ڏئي ٿو ، `None` موٽائي رهيو آھي جيڪڏھن `rhs == 0` يا ڊويزن جو نتيجو اوور فلو ۾ آھي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// چڪاس ڪيو ويو.
        /// ڳڻپيو ويو `-self` ، واپس `None` جيڪڏهن `self == MIN`.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// چوڪيدار شفٽ ڇڏي وئي.
        /// ڳڻپيو ويو `self << rhs` ، `None` موٽڻ وارو جيڪڏهن `rhs` `self` ۾ بٽس جي نمبرن کان وڌيڪ يا برابر آهي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// چيڪ شفٽ سا rightي.
        /// ڳڻپيو ويو `self >> rhs` ، `None` موٽڻ وارو جيڪڏهن `rhs` `self` ۾ بٽس جي نمبرن کان وڌيڪ يا برابر آهي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// پوري قدر جانچيو.
        /// ڳڻپيو ويو `self.abs()` ، واپس `None` جيڪڏهن `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// چڪاس ڪئي وئي.
        /// ڳڻپيوڪر `self.pow(exp)` ، واپسي `None` جيڪڏهن اوور فلو ٿي وئي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // exp==0 ، آخرڪار ايڪسپريس ضرور هجڻ گهرجي 1.
            // معزز جي آخري بٽ کي الڳ الڳ سان ڊيل ڪريو ، ڇاڪاڻ ته بعد ۾ بنياد چوڪ ڪرڻ ضروري نه آهي ۽ غير ضروري فراواني جو سبب بڻجي سگھي ٿو.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// مرڪب انٽيگر اضافو.
        /// `self + rhs` کي ڳڻپ ڪري ٿو ، انگن اکرن جي مٿان وڌيڪ وهڻ جي بجاء.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// مرڪب عدل ڪٽ.
        /// `self - rhs` کي ڳڻپ ڪري ٿو ، انگن اکرن جي مٿان وڌيڪ وهڻ جي بجاء.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// مرڪب عدل رد.
        /// `-self` جو حساب ڏئي ٿو ، `MAX` موٽڻ وارو جيڪڏهن `self == MIN` وڌيڪ وهڻ جي بدران.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// پيٽ ڀرڻ جي گھڻي قدر.
        /// `self.abs()` جو حساب ڏئي ٿو ، `MAX` موٽڻ وارو جيڪڏهن `self == MIN` وڌيڪ وهڻ جي بدران.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// مرڪب عدد ضرب.
        /// `self * rhs` کي ڳڻپ ڪري ٿو ، انگن اکرن جي مٿان وڌيڪ وهڻ جي بجاء.
        ///
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// مرڪب عدد وڌائڻ.
        /// `self.pow(exp)` کي ڳڻپ ڪري ٿو ، انگن اکرن جي مٿان وڌيڪ وهڻ جي بجاء.
        ///
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// (modular) اضافي کي لٺڻ.
        /// `self + rhs` جو حساب ڏئي ٿو ، قسم جي حدن جي چوڌاري wrرڻ.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) تقسيم کي ختم ڪندي.
        /// `self - rhs` جو حساب ڏئي ٿو ، قسم جي حدن جي چوڌاري wrرڻ.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) ضرب کي ختم ڪرڻ.
        /// `self * rhs` جو حساب ڏئي ٿو ، قسم جي حدن جي چوڌاري aroundري ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) ڊويزن کي ورهائي رهيو.`self / rhs` جو حساب ڏئي ٿو ، قسم جي حدن جي چوڌاري wrرڻ.
        ///
        /// صرف هڪ صورت جتي اهڙي لپيٽ ٿي سگهي ٿي جڏهن هڪ دستخط ٿيل قسم تي `MIN / -1` ورهايو (جتي `MIN` قسم لاءِ منفي گهٽ ۾ گهٽ قيمت هوندي)؛اهو برابر آهي `-MIN` ، هڪ مثبت قدر جيڪا قسم ۾ نمائندگي ڪرڻ لاءِ تمام وڏو آهي.
        /// اهڙي حالت ۾ ، اهو فنڪشن `MIN` پاڻ کي واپس ڏئي ٿو.
        ///
        /// # Panics
        ///
        /// انهي فنڪشن panic هوندي جيڪڏهن `rhs` 0 آهي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// اقليدين ڊويزن ۾ ويڙهي رهيو آهي.
        /// `self.div_euclid(rhs)` جو حساب ڏئي ٿو ، قسم جي حدن جي چوڌاري wrرڻ.
        ///
        /// صرف `MIN / -1` ۾ دستخط ٿيل قسم تي ريپنگ واقع ٿيندي (جتي `MIN` قسم لاء منفي گهٽ قيمت آهي).
        /// اها برابر آهي `-MIN` ، هڪ مثبت قدر جيڪا قسم ۾ نمائندگي ڪرڻ لاءِ تمام وڏي آهي.
        /// انهي صورت ۾ ، هي طريقو خود `MIN` کي واپس ڪري ٿو.
        ///
        /// # Panics
        ///
        /// انهي فنڪشن panic هوندي جيڪڏهن `rhs` 0 آهي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// (modular) باقي رهي ٿو لپي.`self % rhs` جو حساب ڏئي ٿو ، قسم جي حدن جي چوڌاري wrرڻ.
        ///
        /// اهڙيون لپي واريون شيون ڪڏهن به رياضياتي طور تي ناهن ٿينديون.دستخط ٿيل قسم تي `MIN / -1` لاء `x % y` ناجائز ٺاھڻ وارا نمونو ٺاھيو (جتي `MIN` منفي گھٽ قيمت آھي).
        ///
        /// اهڙي صورت ۾ ، اهو فنڪشن `0` موٽائي ٿو.
        ///
        /// # Panics
        ///
        /// انهي فنڪشن panic هوندي جيڪڏهن `rhs` 0 آهي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// ايڪيليڊين باقي رهي رهيا آهن.`self.rem_euclid(rhs)` جو حساب ڏئي ٿو ، قسم جي حدن جي چوڌاري wrرڻ.
        ///
        /// صرف `MIN % -1` ۾ دستخط ٿيل قسم تي ريپنگ واقع ٿيندي (جتي `MIN` قسم لاء منفي گهٽ قيمت آهي).
        /// انهي صورت ۾ ، هي طريقو 0 واپس آڻيندو آهي.
        ///
        /// # Panics
        ///
        /// انهي فنڪشن panic هوندي جيڪڏهن `rhs` 0 آهي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// (modular) نفي کي يرڻ.`-self` جو حساب ڏئي ٿو ، قسم جي حدن جي چوڌاري wrرڻ.
        ///
        /// صرف هڪ صورت جتي اهڙي لپائي ٿي سگهي ٿي جڏهن هڪ دستخط ٿيل قسم تي `MIN` کي رد ڪري ٿو (جتي `MIN` قسم لاءِ منفي گهٽ ۾ گهٽ قيمت آهي)؛اھو ھڪڙو مثبت قدر آھي جنھن قسم ۾ نمائندگي ڪرڻ تمام وڏو آھي.
        /// اهڙي حالت ۾ ، اهو فنڪشن `MIN` پاڻ کي واپس ڏئي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic مفت بٽ وار شفٽ-کاٻي ؛`self << mask(rhs)` حاصل ڪري ٿو ، جتي `mask` `rhs` جي ڪنهن به آرڊر بٽ ڪ remي ٿو ، جنهن شفٽ جي قسم جي بٽ ويڊٿ کان وڌي وڃڻ جي ڪري ٿي.
        ///
        /// ياد رکجو ته هي *نه* ساڳيو آهي جيڪو هڪ گھرو-کاٻي وانگر آهي ؛هڪ ويڙهڻ واري کاٻي پاسي واري آر ايڇ ايس ، قسم جي حد تائين محدود آهي ، بجاءِ جي بي ايس ايس جو ختم ٿيل بَٽ ٻئي ختم ڏانهن موٽيا پيا وڃن.
        ///
        /// ابتدائي انٽيگر قسم سڀني [`rotate_left`](Self::rotate_left) فنڪشن کي لاڳو ڪيو آھي ، جيڪو توھان جي بدران چاھي سگھي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // حفاظت: هن قسم جي بائٽسيز سان ماڪو ڪرڻ يقيني بڻائي ٿي ته اسان شفٽ نٿا ڪريون
            // حدن کان ٻاهر
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic مفت بائيٽ وار شفٽ-سا ؛ي ؛حاصل ڪري ٿو `self >> mask(rhs)` ، جتي `mask` `rhs` جو ڪو به آرڊر بٽ ڪ remي ٿو جنهن جي شفٽ جي قسم جي بٽ ويڊٿ کان وڌي وڃڻ جي ڪري ٿي.
        ///
        /// ياد رکجو ته اهو *ناھي* ساڳيا روٽ-سا وانگر آھي.هڪ لفافي شفٽ واري آر ايس ايس جو قسم جي حد تائين محدود آهي ، بجاءِ جي بي ايس ايس جو ختم ٿيل بئٽ ٻئي ختم ڏانهن واپس ٿي رهيا آهن.
        ///
        /// ابتدائي انٽيگر قسم سڀني [`rotate_right`](Self::rotate_right) فنڪشن کي لاڳو ڪيو آھي ، جيڪو توھان جي بدران چاھي سگھي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // حفاظت: هن قسم جي بائٽسيز سان ماڪو ڪرڻ يقيني بڻائي ٿي ته اسان شفٽ نٿا ڪريون
            // حدن کان ٻاهر
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) مطلق قدر لپي رهيو.`self.abs()` جو حساب ڏئي ٿو ، قسم جي حدن جي چوڌاري wrرڻ.
        ///
        /// صرف هڪ صورت جتي اهڙي لپيٽي ٿي سگهي ٿي جڏهن هڪ اهڙي قسم جي ناڪاري گهٽ قيمت جي مڪمل قدر وٺي ٿي.اھو ھڪڙو مثبت قدر آھي جنھن قسم ۾ نمائندگي ڪرڻ تمام وڏو آھي.
        /// اهڙي حالت ۾ ، اهو فنڪشن `MIN` پاڻ کي واپس ڏئي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// ڪنهن به لپڻ يا ڇڪڻ کان بغير `self` جي مطلق قيمت جو اندازو لڳائي ٿو.
        ///
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// (modular) توجه ڏيڻ وارو ريپنگ.
        /// `self.pow(exp)` جو حساب ڏئي ٿو ، قسم جي حدن جي چوڌاري aroundري ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp==0 ، آخرڪار ايڪسپريس ضرور هجڻ گهرجي 1.
            // معزز جي آخري بٽ کي الڳ الڳ سان ڊيل ڪريو ، ڇاڪاڻ ته بعد ۾ بنياد چوڪ ڪرڻ ضروري نه آهي ۽ غير ضروري فراواني جو سبب بڻجي سگھي ٿو.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` کي ڳڻيندو آهي
        ///
        /// هڪ بولين سان گڏ اضافي جو ٽپي ڏي ٿو ته ظاهر ٿئي ٿو ته ڇا هڪ رياضياتي اوور فلو ٿيندو.
        /// جيڪڏهن اوور فلو ٿئي ها ته لپي ويل قيمت واپس ٿي وڃي ها.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` ، `rhs` کي حساب ڪري ٿو
        ///
        /// ڪوليء سان گڏ ڪٽيل جي ٽپي ڏي ٿو ظاهر ڪري ٿو ته ڇا هڪ رياضياتي فلو واقع ٿيندو.
        /// جيڪڏهن اوور فلو ٿئي ها ته لپي ويل قيمت واپس ٿي وڃي ها.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` ۽ `rhs` جي ضرب کي حساب ڪري ٿو.
        ///
        /// ڪوليءَ جي واڌاري جو هڪ ٽولو eanرائيندو آهي انهي سان گڏ انهي جي نشاندهي ته ڇا هڪ عددي چترالي هجي ٿي.
        /// جيڪڏهن اوور فلو ٿئي ها ته لپي ويل قيمت واپس ٿي وڃي ها.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408 ، سچو)) ؛
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// ڊائيور کي حساب ڏي ٿو جڏهن `self` `rhs` پاران ورهايل آهي.
        ///
        /// ڊائيولر جي ٽپي کي هڪ بولين سان گڏ ريٽر ڪري ٿو ظاهر ڪري ٿو ته ڇا هڪ رياضياتي فلو واقع ٿيندو.
        /// جيڪڏهن اوور فلو ٿئي ٿو ته پوءِ پنهنجو پاڻ موٽايو وڃي ٿو.
        ///
        /// # Panics
        ///
        /// انهي فنڪشن panic هوندي جيڪڏهن `rhs` 0 آهي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Euclidean ڊويزن `self.div_euclid(rhs)` جي چوٽي کي شمار ڪري ٿو.
        ///
        /// ڊائيولر جي ٽپي کي هڪ بولين سان گڏ ريٽر ڪري ٿو ظاهر ڪري ٿو ته ڇا هڪ رياضياتي فلو واقع ٿيندو.
        /// جيڪڏهن هڪ اوور فلو ٿئي ها ته `self` واپس اچي ويندو آهي.
        ///
        /// # Panics
        ///
        /// انهي فنڪشن panic هوندي جيڪڏهن `rhs` 0 آهي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// باقي کي حساب ڏي ٿو جڏهن `self` `rhs` پاران ورهايل آهي.
        ///
        /// بولين سان گڏ ورهائڻ کان پوءِ باقي رهڻ جو هڪ ٽولو موٽائيندو آهي ظاهر ڪري ٿو ته ڇا ڪو رياضياتي فلو واقع ٿيندو.
        /// جيڪڏهن اوور فلو ٿئي ٿو تڏهن 0 موٽي ويندي آهي.
        ///
        /// # Panics
        ///
        /// انهي فنڪشن panic هوندي جيڪڏهن `rhs` 0 آهي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// ايلوڊائيڊن جي مٿان غالب رهندي.`self.rem_euclid(rhs)` کي حساب ڪري ٿو
        ///
        /// بولين سان گڏ ورهائڻ کان پوءِ باقي رهڻ جو هڪ ٽولو موٽائيندو آهي ظاهر ڪري ٿو ته ڇا ڪو رياضياتي فلو واقع ٿيندو.
        /// جيڪڏهن اوور فلو ٿئي ٿو تڏهن 0 موٽي ويندي آهي.
        ///
        /// # Panics
        ///
        /// انهي فنڪشن panic هوندي جيڪڏهن `rhs` 0 آهي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// پنهنجو پاڻ کي رد ڪري ٿو ، گھٻرائجي جيڪڏهن اهو گهٽ ۾ گهٽ قدر جي برابر آهي.
        ///
        /// پنهنجي پاڻ سان ناڪاري ٿيل نسخو وارو ٽولو واپس ڪندو آهي جنهن سان گڏ انهي تعريف ڪئي وئي آهي ته ڇا هڪ اوور فلو ٿيو.
        /// جيڪڏهن `self` گهٽ ۾ گهٽ قيمت آهي (مثال طور ، X003 قسم جي `i32` جي قدرن لاءِ) ، پوءِ گهٽ ۾ گهٽ قيمت ٻيهر موٽي ويندي ۽ `true` واپس اچڻ جي لاءِ گهڻي موٽ ٿي ويندي.
        ///
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// `rhs` بٽس طرفان تبديليون خود ڇڏيون ويون آهن.
        ///
        /// نفسانن سان گڏ شفٽ ٿيل نسخو جو هڪ ٽولو ڏي ٿو انهي کي ظاهر ڪري ٿو ته ڇا شفٽ جي قيمت بٽس جي تعداد کان وڏي يا برابر هئي.
        /// جيڪڏھن شفٽ ويليو تمام وڏي آھي ، ته ويل ماسڪ ٿيل (N-1) آھي جتي اين بٽس جو نمبر آھي ، ۽ اھو ويليو پھر شفٽ ڪرڻ لاءِ استعمال ٿئي ٿي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10 ، سچو)) ؛
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// `rhs` بٽس پاران صحيح طريقي سان تبديلي آڻيندي.
        ///
        /// نفسانن سان گڏ شفٽ ٿيل نسخو جو هڪ ٽولو ڏي ٿو انهي کي ظاهر ڪري ٿو ته ڇا شفٽ جي قيمت بٽس جي تعداد کان وڏي يا برابر هئي.
        /// جيڪڏھن شفٽ ويليو تمام وڏي آھي ، ته ويل ماسڪ ٿيل (N-1) آھي جتي اين بٽس جو نمبر آھي ، ۽ اھو ويليو پھر شفٽ ڪرڻ لاءِ استعمال ٿئي ٿي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1 ، سچو)) ؛
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// `self` جي مڪمل قيمت جو اندازو لڳائي ٿو.
        ///
        /// واپسيء جو پاڻ سان گڏ مطلق نسخه جو هڪ ٽوپل ڏي ٿو جيڪو بولين سان ظاهر ٿئي ٿو ته ڇا هڪ وڌيڪ اضافو ٿيو.
        /// جيڪڏهن نفس گهٽ کان گھٽ قدر آهي
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// پوءِ گهٽ ۾ گهٽ قيمت ٻيهر موٽي ويندي ۽ سچائي گهڻي موٽ ڪئي ويندي.
        ///
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// پنهنجو پاڻ کي `exp` جي طاقت کي وڌائي ٿو ، چوڪنڊو ذريعي توسيع جو استعمال ڪندي.
        ///
        /// bool سان گڏ ايڪسونٽيشن جو هڪ ٽولو ڏي ٿو ظاهر ڪيو ته ڇا اوور فلو ٿي ويو آهي.
        ///
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13 ، سچو)) ؛
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Overflowing_mul جي نتيجن کي محفوظ ڪرڻ لاءِ جاءِ خرچي ڏي.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp==0 ، آخرڪار ايڪسپريس ضرور هجڻ گهرجي 1.
            // معزز جي آخري بٽ کي الڳ الڳ سان ڊيل ڪريو ، ڇاڪاڻ ته بعد ۾ بنياد چوڪ ڪرڻ ضروري نه آهي ۽ غير ضروري فراواني جو سبب بڻجي سگھي ٿو.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// پنهنجو پاڻ کي `exp` جي طاقت کي وڌائي ٿو ، چوڪنڊو ذريعي توسيع جو استعمال ڪندي.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp==0 ، آخرڪار ايڪسپريس ضرور هجڻ گهرجي 1.
            // معزز جي آخري بٽ کي الڳ الڳ سان ڊيل ڪريو ، ڇاڪاڻ ته بعد ۾ بنياد چوڪ ڪرڻ ضروري نه آهي ۽ غير ضروري فراواني جو سبب بڻجي سگھي ٿو.
            //
            //
            acc * base
        }

        /// `rhs` کان Euclidean ڊويزن جي قارئين کي `rhs` پاران حساب ڏي ٿو.
        ///
        /// اهو انگن اکرن `n` ٺاهي ٿو ته `self = n * rhs + self.rem_euclid(rhs)` ، `0 <= self.rem_euclid(rhs) < rhs` سان.
        ///
        ///
        /// ٻين لفظن ۾ ، نتيجو `self / rhs` انٽيگر `n` ڏانهن گول ڪيو ويو آهي ته `self >= n * rhs`.
        /// جيڪڏهن `self > 0` ، اهو صفر جي طرف گول تائين برابر آهي (Rust ۾ ڊفالٽ) ؛
        /// جيڪڏهن `self < 0` ، اهو گول ڪرڻ جي برابر آهي +/-لا محدود.
        ///
        /// # Panics
        ///
        /// انهي فنڪشن panic ٿيندو جيڪڏهن `rhs` 0 آهي يا ڊويزن جو نتيجو اوور فلو ٿئي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// اچو b=4 ؛
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b) ، -1) ؛//7>= -4*-1 assert_eq!((-a).div_euclid(b) ، -2) ؛//-7>=4 *-2 assert_eq!((-a).div_euclid(-b) ، 2) ؛//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// `self (mod rhs)` جي گھٽ ۾ گھٽ غير منقسمي باقي حساب جو حساب ڏي ٿو.
        ///
        /// اهو ائين ڪيو ويو آهي theڻ ته اقليڊين ڊويزن الگورتھم پاران-ڏنل `r = self.rem_euclid(rhs)` ، `self = rhs * self.div_euclid(rhs) + r` ، ۽ `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// انهي فنڪشن panic ٿيندو جيڪڏهن `rhs` 0 آهي يا ڊويزن جو نتيجو اوور فلو ٿئي ٿو.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// اچو b=4 ؛
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// `self` جي مڪمل قيمت جو اندازو لڳائي ٿو.
        ///
        /// # اوجاڳو رويو
        ///
        /// جي مطلق قيمت
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// نمائندگي نٿي ڪري سگھجي
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// ۽ انهي کي حساب ڏيڻ جي ڪوشش هڪ وهڪري جو سبب بڻجندي.
        /// ان جو مطلب آهي ته ڪوڊ ۾ ڊيبگ موڊ کي انهي ڪيس تي panic متحرڪ ڪندو ۽ اصلاح ٿيل ڪوڊ واپس آڻيندو
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// panic کان سواء.
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // ياد رکون ته مٿي##ان لائن جو مطلب اهو آهي ته ڪثرت جي اوور فلو سيمينٽس crate تي ڀاڙين ٿا جنهن ۾ اسان داخل ڪيو پيو وڃي.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// ھڪڙي نمبر ڏيکاري ٿو جيڪو ھڪڙي `self` نشاني جي نشاني ڏيکاري ٿو.
        ///
        ///  - `0` جيڪڏهن نمبر صفر آهي
        ///  - `1` جيڪڏهن نمبر هاڪاري آهي
        ///  - `-1` جيڪڏهن نمبر منفي آهي
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// جيڪڏهن `self` مثبت آهي ۽ `false` جيڪڏهن نمبر صفر يا منفي آهي ، واپسي ڏئي ٿو `true`.
        ///
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// جيڪڏهن `self` منفي آهي ۽ `false` جيڪڏهن نمبر صفر يا مثبت آهي ، واپسي کي `true` ڏئي ٿو.
        ///
        ///
        /// # Examples
        ///
        /// بنيادي استعمال
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// انهي انٽيگر جي يادگيري نمائندگي کي واپس الٽني بڪس آرڊر ۾ بائيٽ جي آرٽ جي طور تي واپس ڪيو وڃي.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// نن integي اينڊنٽ بائيٽ آرڊر ۾ بائيٽ جي ترتيب جي طور تي ان انٽيگر جي يادگيري نمائندگي واپس آڻيو.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// اصل انٽيگر جي يادگيري نمائندگي کي بائيٽ جي ذريعي اصلي بائيٽ ترتيب ۾ واپس آڻيو.
        ///
        /// جئين ٽارگيٽ پليٽ فارم جي اصلي برداشت استعمال ڪئي وئي آهي ، پورٽبل ڪوڊ کي [`to_be_bytes`] يا [`to_le_bytes`] استعمال ڪرڻ گهرجي ، مناسب طور تي ، بدران.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     بائٽس ، جيڪڏهن سيفگ! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } ٻيا {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // حفاظت: مسلسل آواز ڇاڪاڻ ته انٽيگرز سادي پراڻي ڊيٽائپ آهن ، انهي ڪري اسان هميشه ڪري سگهون ٿا
        // انهن بائيٽ جي صفن ۾ منتقل ڪيو
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // حفاظت: انٽيگرز سادي پراڻي ڊيٽائپ آهن ، انهي ڪري اسان هنن کي هميشه منتقل ڪري سگهون ٿا
            // بائٽس جون قطارون
            unsafe { mem::transmute(self) }
        }

        /// اصل انٽيگر جي يادگيري نمائندگي کي بائيٽ جي ذريعي اصلي بائيٽ ترتيب ۾ واپس آڻيو.
        ///
        ///
        /// [`to_ne_bytes`] جڏهن ممڪن ٿي سگھي ، هن کي ترجيح ڏيڻ گهرجي.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// بائيٽ طرفان ڏيو num.as_ne_bytes() ؛
        /// assert_eq!(
        ///     بائٽس ، جيڪڏهن سيفگ! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } ٻيا {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // حفاظت: انٽيگرز سادي پراڻي ڊيٽائپ آهن ، انهي ڪري اسان هنن کي هميشه منتقل ڪري سگهون ٿا
            // بائٽس جون قطارون
            unsafe { &*(self as *const Self as *const _) }
        }

        /// انهي جي نمائندگي ڪرڻ سان گڏ انگ اکر ٺاهيو هڪ بائيٽ جي ترتيب جي طور تي وڏي اينڊين ۾.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto استعمال ڪريو؛
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * انڌ=آرام ؛
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// نن endي اينڊين ۾ بائيٽ صف جي طور تي ان جي نمائندگي مان هڪ جيتري قدر ٺاهيو.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto استعمال ڪريو؛
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * انڌ=آرام ؛
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// ان جي ياداشت جي نمائندگي کان انگ جي هڪ عدد کي بائيٽ لائيري جي ذريعي ڏيهي Endianness ۾.
        ///
        /// جئين ٽارگيٽ پليٽ فارم جي اصلي برداشت وارو استعمال ٿيندو آهي ، پورٽبل ڪوڊ ممڪن طور تي [`from_be_bytes`] يا [`from_le_bytes`] استعمال ڪرڻ چاهيندو آهي ، ان جي بدران مناسب طور تي.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } ٻيا {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto استعمال ڪريو؛
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * انڌ=آرام ؛
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // حفاظت: مسلسل آواز ڇاڪاڻ ته انٽيگرز سادي پراڻي ڊيٽائپ آهن ، انهي ڪري اسان هميشه ڪري سگهون ٿا
        // انهن ڏانهن منتقل ڪيو
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // حفاظت: انٽيگرز سادي پراڻي ڊيٽائپ جا آهن ، انهي ڪري اسان هميشه انهن ڏانهن منتقل ڪري سگهون ٿا
            unsafe { mem::transmute(bytes) }
        }

        /// نئون ڪوڊ استعمال ڪرڻ کي ترجيح ڏيڻ گهرجي
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// نن smallestي قيمت ڏيان ٿو جيڪا ان انٽيگر قسم مان ظاھر ڪري سگھي ٿي.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// نئون ڪوڊ استعمال ڪرڻ کي ترجيح ڏيڻ گهرجي
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// تمام وڏي قيمت ڏيان ٿو جيڪا انهي انٽيگر قسمن سان ظاھر ڪري سگھي ٿي.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}