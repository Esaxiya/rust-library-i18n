//! مجموعي قسمن ۾ غلطي جا قسم conversionيرائڻ لاءِ.

use crate::convert::Infallible;
use crate::fmt;

/// غلطي جي قسم موٽندي هئي جڏهن هڪ چيڪ ڪيل انٽيگريٽل قسم جي تبديلي ناڪام ٿيندي آهي.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // مجبور ڪرڻ بجاءِ ميچ ڪريو ته انهي کي يقيني بڻايو وڃي ته ايڪس ڪوڪس وانگر ڪوڊ مٿي ڪم ڪندو رهندو جڏهن `Infallible` `!` کي عرف بنائي ٿو.
        //
        //
        match never {}
    }
}

/// هڪ نقص جيڪو واپس اچي سگهي ٿو جڏهن انضمام کي ترتيب ڏيڻ.
///
/// ھن غلطي کي استعمال ڪيو ويو آھي غلط قسم جي `from_str_radix()` فھرستن لاء ابتدائي انٽيگري وارن قسمن تي ، اھڙي طرح [`i8::from_str_radix`].
///
/// # امڪاني سبب
///
/// ٻين سببن جي ڪري ، `ParseIntError` اڇلائي اسپيس جي معروف يا ختم ٿيڻ واري سبب اڇلائي سگهجي ٿو ، مثال طور ، جڏهن اهو معياري ان پٽ مان حاصل ٿئي.
///
/// [`str::trim()`] طريقو استعمال ڪرڻ سان يقيني بڻائي ٿو ته جڙڻ کان اڳ ڪابه اسپيس رهي ڪونه ٿي.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// اينم جي مختلف قسمن کي اسٽور ڪرڻ جي لاءِ گڏجاڻي جيڪا انوگر کي ناڪام بڻائڻ جو سبب بڻجي سگهي ٿي.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// قيمت وجھڻ لاءِ خالي آھي.
    ///
    /// ٻين سببن جي وچ ۾ ، اهو متان تعمير ٿيندو جڏهن خالي ڪنڊ کي ترتيب ڏيڻ.
    Empty,
    /// ان جي تناظر ۾ غلط انگن اکرن تي مشتمل آھي.
    ///
    /// ٻين سببن جي وچ ۾ ، اهو متغير تعمير ٿيندو جڏهن هڪ تار تي ڌيان ڏيڻ جنهن ۾ غير ASCII چار شامل آهي.
    ///
    /// اهو ويڪرو پڻ تعمير ٿيل آهي جڏهن هڪ `+` يا `-` هڪ تار ۾ يا ٻئي جي وچ ۾ يا نمبر جي وچ ۾ غلط استعمال ٿيل آهي.
    ///
    ///
    InvalidDigit,
    /// انٽيگر انٽيگر انٽيگر قسم ۾ اسٽور ڪرڻ لاءِ تمام وڏو آهي.
    PosOverflow,
    /// انٽيگر انٽيگر انٽيگر قسم ۾ اسٽور ڪرڻ لاءِ تمام نن smallڙو آهي.
    NegOverflow,
    /// قدر صفر هئي
    ///
    /// اهو حشر اس وقت ايما ٿيل ٿيندو جڏهن پيرسنگ ڪرڻ واري اسٽرنگ صفر جي قيمت هوندي جيڪا غير صفر جي قسمن لاءِ غيرقانوني هوندي.
    ///
    Zero,
}

impl ParseIntError {
    /// انٽيگر ناڪاره کي ختم ڪرڻ جي تفصيلي سبب ٻاھر ڪputي ٿو.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}