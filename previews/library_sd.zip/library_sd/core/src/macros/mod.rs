#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // وڌايو ويو يا ته `$crate::panic::panic_2015` يا `$crate::panic::panic_2021` ڪالر جي ايڊيشن تي منحصر آهي.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// انهي کي ظاهر ڪري ٿو ته ٻه اظهار هڪ ٻئي جي برابر آهن (ايڪس [`PartialEq`] استعمال ڪندي).
///
/// panic تي ، اهو ميڪرو انهن جي ڊيبگ جي نمائندگيز سان خيالن جي قدرن کي پرنٽ ڪندو.
///
///
/// [`assert!`] وانگر ، ھي ميڪرو ٻيون روپ آھي ، جتي ڪسٽم panic پيغام مهيا ڪري سگھجي ٿو.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // هيٺيون بغاوتون ارادي آهن.
                    // انهن کان بغير ، قرض لاءِ اسٽيڪ سلاٽ شروعات ڪئي وئي آهي اڳ ئي قدرن جي مقابلي ۾ ، مقابلي جي شروعات کان اڳ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // هيٺيون بغاوتون ارادي آهن.
                    // انهن کان بغير ، قرض لاءِ اسٽيڪ سلاٽ شروعات ڪئي وئي آهي اڳ ئي قدرن جي مقابلي ۾ ، مقابلي جي شروعات کان اڳ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// انهي کي ظاهر ڪري ٿو ته ٻه اظهار هڪ ٻئي لاءِ برابر نه آهن ([`PartialEq`] استعمال ڪندي).
///
/// panic تي ، اهو ميڪرو انهن جي ڊيبگ جي نمائندگيز سان خيالن جي قدرن کي پرنٽ ڪندو.
///
///
/// [`assert!`] وانگر ، ھي ميڪرو ٻيون روپ آھي ، جتي ڪسٽم panic پيغام مهيا ڪري سگھجي ٿو.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // هيٺيون بغاوتون ارادي آهن.
                    // انهن کان بغير ، قرض لاءِ اسٽيڪ سلاٽ شروعات ڪئي وئي آهي اڳ ئي قدرن جي مقابلي ۾ ، مقابلي جي شروعات کان اڳ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // هيٺيون بغاوتون ارادي آهن.
                    // انهن کان بغير ، قرض لاءِ اسٽيڪ سلاٽ شروعات ڪئي وئي آهي اڳ ئي قدرن جي مقابلي ۾ ، مقابلي جي شروعات کان اڳ.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// انهي ڳالهه جو اظهار ڪيو ته بولين جو اظهار رن ٽائيم تي `true` آهي.
///
/// اهو [`panic!`] ميڪرو سڏيندو جيڪڏهن مهيا ڪيل اظهار `true` کي رن ٽائيم تي تشخيص نه ٿي ڪري سگهجي.
///
/// [`assert!`] وانگر ، هن ميڪرو پڻ هڪ ٻيو نسخو آهي ، جتي هڪ رواج panic پيغام فراهم ڪري سگهجي ٿو.
///
/// # Uses
///
/// [`assert!`] جي برعڪس ، `debug_assert!` بيانن کي صرف غير بهتر ٿيل ڊفالٽ ۾ ڊفالٽ طور فعال ڪيو ويو آھي.
/// هڪ بهتر ڪيل ايڪس ايڪس ايڪس بيانن تي عمل نه ڪندو جيستائين ايڪس ڪمپليڪس کي `-C debug-assertions` منظور نه ڪيو وڃي.
/// اهو ايڪسچيڪس چيڪ لاءِ مفيد بڻائي ٿو جيڪو رليز بلڊ ۾ موجود هجڻ لاءِ تمام گهڻو مهانگو آهي پر ترقي دوران مددگار ٿي سگهي ٿو.
/// `debug_assert!` کي وڌائڻ جو نتيجو هميشه قسم جي چڪاس ڪيو ويو آھي.
///
/// هڪ غير جانچيل زور ڀرڻ هڪ متضاد حالت ۾ هڪ پروگرام کي جاري رکڻ جي اجازت ڏي ٿو ، جنهن جا غير متوقع نتيجا به ٿي سگهن ٿا پر هن غير محفوظيت کي متعارف نه ڪرايو جيستائين ڪو صرف اهو محفوظ ڪوڊ ۾ ٿئي.
///
/// ، بيانن جي ڪارڪردگي قيمت عام طور تي ماپن ناهي.
/// ايڪسڪسيمڪس کي `debug_assert!` سان تبديل ڪرڻ ان ڪري مڪمل طور تي پروفائيلنگ بعد ئي زور ڏنو وڃي ٿو ، ۽ وڌيڪ اهم طور تي ، صرف محفوظ ڪوڊ ۾.
///
/// # Examples
///
/// ```
/// // ھن اشارن لاءِ panic پيغام ڏنو ويو آھي ظاھر ٿيل قيمت آھي.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // هڪ تمام سادو فنڪشن
/// debug_assert!(some_expensive_computation());
///
/// // مرضي مطابق پيغام سان
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// انهي ڳالهه جو اظهار ڪري ٿو ته ٻه اظهار هڪ ٻئي لاءِ برابر آهن.
///
/// panic تي ، اهو ميڪرو انهن جي ڊيبگ جي نمائندگيز سان خيالن جي قدرن کي پرنٽ ڪندو.
///
/// [`assert_eq!`] جي برعڪس ، `debug_assert_eq!` بيانن کي صرف غير بهتر ٿيل ڊفالٽ ۾ ڊفالٽ طور فعال ڪيو ويو آھي.
/// هڪ بهتر ڪيل ايڪس ايڪس ايڪس بيانن تي عمل نه ڪندو جيستائين ايڪس ڪمپليڪس کي `-C debug-assertions` منظور نه ڪيو وڃي.
/// اهو ايڪسچيڪس چيڪ لاءِ مفيد بڻائي ٿو جيڪو رليز بلڊ ۾ موجود هجڻ لاءِ تمام گهڻو مهانگو آهي پر ترقي دوران مددگار ٿي سگهي ٿو.
///
/// `debug_assert_eq!` کي وڌائڻ جو نتيجو هميشه قسم جي چڪاس ڪيو ويو آھي.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// فرض ڪري ٿو ته ٻه اظهار هڪ ٻئي لاءِ برابر نه آهن.
///
/// panic تي ، اهو ميڪرو انهن جي ڊيبگ جي نمائندگيز سان خيالن جي قدرن کي پرنٽ ڪندو.
///
/// [`assert_ne!`] جي برعڪس ، `debug_assert_ne!` بيانن کي صرف غير بهتر ٿيل ڊفالٽ ۾ ڊفالٽ طور فعال ڪيو ويو آھي.
/// هڪ بهتر ڪيل ايڪس ايڪس ايڪس بيانن تي عمل نه ڪندي جيستائين ايڪس ڪمپليڪس کي `-C debug-assertions` منظور نه ڪيو وڃي.
/// اهو ايڪسچيڪس چيڪ لاءِ مفيد بڻائي ٿو جيڪو رليز بلڊ ۾ موجود هجڻ لاءِ تمام گهڻو مهانگو آهي پر ترقي دوران مددگار ٿي سگهي ٿو.
///
/// `debug_assert_ne!` کي وڌائڻ جو نتيجو هميشه قسم جي چڪاس ڪيو ويو آھي.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// واپسي ڏئي ٿو ته ڏنل بيان ڪنهن به ڏني وئي نموني سان ملي ٿو.
///
/// هڪ `match` اظهار وانگر ، نموني اختياري طور `if` ۽ بعد ۾ هڪ گارڊ اظهار جو پيروي ٿي سگهي ٿو جنهن جي نموني تائين پابند نالا نالا آهن.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// نتيجو لاهي ٿو يا ان جي غلطي کي تبليغ ڪري ٿو.
///
/// `?` آپريٽر شامل ڪيو ويو `try!` کي تبديل ڪرڻ ۽ ان جي بدران استعمال ڪيو وڃي.
/// وڌيڪ ، `try` Rust 2018 ۾ محفوظ ڪيل لفظ آهي ، تنهن ڪري جيڪڏهن توهان کي ان کي استعمال ڪرڻ گهرجي ، توهان کي [raw-identifier syntax][ris] استعمال ڪرڻ جي ضرورت پوندي. `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ڏنل [`Result`] سان ملي ٿو `Ok` وارينٽي جي صورت ۾ ، اظهار جي ورهايل ويليو جي قيمت آهي.
///
/// `Err` ويئرٽ جي صورت ۾ ، اهو اندروني غلطي کي واپس وٺي ٿو.`try!` پوءِ `From` استعمال ڪندي ڪنورينشن ڪندو آهي.
/// اهو خاص غلطيون ۽ وڌيڪ عام ماڻهن جي وچ ۾ پاڻمرادو conversionير conversionار ڏيندو آهي.
/// نتيجو ڪندڙ غلطي پوءِ فوري طور تي واپس اچي وئي آهي.
///
/// ابتدائي واپسي جي ڪري ، `try!` صرف انهن افعال ۾ استعمال ٿي سگھي ٿو جيڪي [`Result`] واپس ڪن ٿيون.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // جلدي موٽڻ واري نقصن جو پسنديده طريقو
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // جلدي واپسي واري غلطي جو پويون طريقو
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // هي برابر آهي:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// فارميٽ ٿيل ڊيٽا بفر ۾ لکي ٿي.
///
/// اهو ميڪرو 'writer' ، هڪ فارميٽ اسٽرنگ ۽ دلائل جي هڪ لسٽ کي قبول ڪري ٿو.
/// دلائل مقرر ڪيل شڪل جي ترتيب جي مطابق ڏنل هوندي ۽ نتيجو ليکڪ کي منتقل ڪيو ويندو.
/// ليکڪ `write_fmt` طريقي سان ڪي به قدر ٿي سگهي ٿو ؛عام طور تي اهو يا ته [`fmt::Write`] يا [`io::Write`] trait جي عمل درآمد کان اچي ٿو.
/// ميڪرو واپس اچي ٿو جيڪو `write_fmt` طريقو واپس اچي ٿو ؛عام طور تي هڪ [`fmt::Result`] ، يا هڪ [`io::Result`].
///
/// فارميٽ اسٽرنگ نحو تي وڌيڪ معلومات لاءِ [`std::fmt`] ڏسو.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// ھڪڙو ماڊل ٻئي `std::fmt::Write` ۽ `std::io::Write` درآمد ڪري سگھي ٿو ۽ ھڪڙي ٻئي تي عمل ڪرڻ واري شين تي `write!` کي ڪال ڪري سگھي ٿو ، جئين شيون عام طور تي ٻن کي لاڳو نٿا ڪن.
///
/// تنهن هوندي ، ماڊل traits کي مستحڪم ڪرڻ لازمي هوندو ته انهن جا نالا تڪرار نه ڪن.
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt استعمال ڪندو آهي
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt استعمال ڪندو آهي
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: ھي ميڪرو `no_std` سيٽ اپ ۾ پڻ استعمال ڪري سگھجي ٿو.
/// هڪ `no_std` سيٽ اپ ۾ توهان حصن جي نفاذ جي تفصيل جا ذميوار آهيو.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// فارميٽ ٿيل ڊيٽا بفر ۾ لکو ، هڪ نئين لائن سان شامل ٿيل آهي.
///
/// سڀني پليٽ فارمن تي ، نئين لائن فقط لائن فيڊ جي ڪردار آهي (`\n`/`U+000A`) (وڌيڪ اضافي ڪارٽري رٽرنن (`\r`/`U+000D`)).
///
/// وڌيڪ معلومات لاءِ ، ڏسو [`write!`].فارميٽ اسٽرنگ نحو تي معلومات لاءِ ، ايڪس ايڪس ڏسو X.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// ھڪڙو ماڊل ٻئي `std::fmt::Write` ۽ `std::io::Write` درآمد ڪري سگھي ٿو ۽ ھڪڙي ٻئي تي عمل ڪرڻ واري شين تي `write!` کي ڪال ڪري سگھي ٿو ، جئين شيون عام طور تي ٻن کي لاڳو نٿا ڪن.
/// تنهن هوندي ، ماڊل traits کي مستحڪم ڪرڻ لازمي هوندو ته انهن جا نالا تڪرار نه ڪن.
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt استعمال ڪندو آهي
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt استعمال ڪندو آهي
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// رسائي جي سگهه جو اشارو آهي.
///
/// اهو هر وقت ڪارائتو آهي ته مرتب ڪندڙ اهو طئي نٿو ڪري سگهي ته ڪجهه ڪوڊ پهچائي نه سگهيو آهي.مثال طور:
///
/// * هٿيار حالتن سان حفاظت ڪريو.
/// * لوپ جيڪي متحرڪ طور ختم ٿين ٿا.
/// * ايٽرٽر جيڪي متحرڪ طور تي ختم ڪن ٿا.
///
/// جيڪڏهن اهو عزم ته ڪوڊ اڻ پهچيل غلط ثابت ٿيو آهي ، پروگرام فوري طور تي [`panic!`] سان ختم ٿي وڃي ٿو.
///
/// هن ميڪرو جي غير محفوظ هم منصب [`unreachable_unchecked`] فنڪشن آهي ، جيڪا ڪوڊ تائين پهچي وئي ته غير معياري رويي جو سبب بڻجندي.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// اهو هميشه [`panic!`] هوندو.
///
/// # Examples
///
/// هٿن سان ملو:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // جيڪڏهن تبصرو ڪيو ويو ته غلطيون مرتب ڪريو
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // ايڪس اين ايڪس ايڪس جي سڀني غريب عملن مان هڪ آهي
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" جي پيغام سان ickingرندڙ بغير عمل ٿيل ڪوڊ جي نشاندهي ڪري ٿو.
///
/// اهو توهان جي ڪوڊ کي چڪاس ڪرڻ جي اجازت ڏي ٿو ، جيڪو توهان مفيد آهي يا توهان trait پروٽوٽائپ ڪري رهيا آهيو يا ڪيترن ئي طريقن جي ضرورت آهي جيڪي توهان سڀني کي استعمال ڪرڻ جو منصوبو ناهي.
///
/// `unimplemented!` ۽ [`todo!`] جي وچ ۾ فرق اهو آهي ته جڏهن `todo!` بعد ۾ ڪارڪردگي تي عمل ڪرڻ جو ارادو رکي ٿو ۽ پيغام "not yet implemented" آهي ، `unimplemented!` اهڙو ڪو به دعويٰ ناهي.
/// ان جو پيغام "not implemented" آهي.
/// ڪجهه IDE پڻ نشان لڳندا
///
/// # Panics
///
/// اهو هميشه [`panic!`] ٿيندو ڇو ته `unimplemented!` هڪ مقرر ڪيل ، مخصوص پيغام سان صرف `panic!` لاءِ هڪ نن aو آهي.
///
/// `panic!` وانگر ، ھن ميڪرو ۾ ٻئين شڪل آھي ڪسٽم قدرون ڏيکارڻ لاءِ.
///
/// # Examples
///
/// چئو ته اسان وٽ آھي trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// اسان 'MyStruct' لاءِ `Foo` لاڳو ڪرڻ چاهيون ٿا ، پر ڪجهه سببن جي ڪري اهو صرف `bar()` فنڪشن لاڳو ڪرڻ جو احساس رکي ٿو.
/// `baz()` ۽ `qux()` اسان کي `Foo` جي عملدرآمد ۾ اڃا به وضاحت ڪرڻ جي ضرورت پوندي ، پر اسان اسان کي انهن جي تعريفن ۾ `unimplemented!` استعمال ڪري سگھون ٿا اسان جي ڪوڊ کي ترتيب ڏيڻ جي اجازت ڏين.
///
/// اسان چاهيون ٿا اڃان به اسانجو پروگرام هلندي هلن جيڪڏهن بي پهچ ٿيل طريقا رسي وڃن.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // اهو `baz` هڪ `MyStruct` جو ڪو به مطلب ناهي ، تنهن ڪري هتي اسان وٽ هتي ڪا به منطق ناهي.
/////
///         // اهو ڊسپلي "thread 'main' panicked at 'not implemented'" ڪري ٿو.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // اسان وٽ هتي ڪجھ منطق آهي ، اسان اڻ پورو ٿيل پيغام شامل ڪري سگهون ٿا!اسان جي چڪاس ظاهر ڪرڻ لاءِ.
///         // اهو ظاهر ڪندو: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// نامڪمل ڪوڊ کي ظاهر ڪري ٿو.
///
/// جيڪڏهن توهان پروٽوڪائپ ڪري رهيا آهيو ۽ اهو ڏسي سگهجن ٿا ته توهان جو ڪوڊ ٽائپ چيڪ ڪري رهيو آهي.
///
/// [`unimplemented!`] ۽ `todo!` جي وچ ۾ فرق اهو آهي ته جڏهن `todo!` بعد ۾ ڪارڪردگي تي عمل ڪرڻ جو ارادو رکي ٿو ۽ پيغام "not yet implemented" آهي ، `unimplemented!` اهڙو ڪو به دعويٰ ناهي.
/// ان جو پيغام "not implemented" آهي.
/// ڪجهه IDE پڻ نشان لڳندا
///
/// # Panics
///
/// اهو هميشه [`panic!`] هوندو.
///
/// # Examples
///
/// هتي ڪجهه پيش رفت ڪوڊ جي هڪ مثال آهي.اسان وٽ هڪ trait `Foo` آهي:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// اسان پنھنجي ھڪڙي ھڪڙي قسم تي `Foo` لاڳو ڪرڻ چاھيو ٿا ، پر اسين پڻ صرف `bar()` تي پھريائين ڪم ڪرڻ چاھيون ٿا.اسان جي ڪوڊ کي ترتيب ڏيڻ لاءِ ، اسان کي `baz()` لاڳو ڪرڻ جي ضرورت آهي ، انهي ڪري اسان `todo!` استعمال ڪري سگهون ٿا:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // لاڳو ٿيڻ هتي آهي
///     }
///
///     fn baz(&self) {
///         // اچو ته هاڻي لاءِ baz() جي نفاذ جي باري ۾ پريشان نه ڪريون
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // اسان baz() پڻ استعمال نٿا ڪري رهيا ، تنهنڪري اهو ٺيڪ آهي.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// تعمير ٿيل ميڪروز جون وضاحتون.
///
/// اڪثر ڪريرو مال (استحڪام ، ڏيک ، وغيره) هتي ماخذ ڪوڊ مان ورتو وڃي ٿو ، توسيع جي افعال کان سواءِ ماکي ان پٽن کي شين ۾ تبديل ڪندي ، اهي ڪمر مرتب ڪندڙ طرفان فراهم ڪيا ويندا آهن.
///
///
pub(crate) mod builtin {

    /// سامنا ڪرڻ جي غلطي پيغام سان ناڪام ٿيڻ جو سبب بڻيو.
    ///
    /// اهو ميڪرو استعمال ٿيڻ گهرجي جڏهن هڪ crate مشروط تاليف واري حڪمت عملي ڪتب آڻيندو ته هو غلط حالتن لاءِ بهتر غلطي جا پيغام فراهم ڪندو.
    ///
    /// اهو [`panic!`] جو مرتب ڪندڙ سطح وارو فارم آهي ، پر *رائلٽ* تي بجاءِ *ترتيب* دوران هڪ غلطي خارج ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ٻه اھڙا مثال ميڪس ۽ `#[cfg]` ماحول آھن.
    ///
    /// بهتر ميڪولر غلطي کي اجايو جيڪڏهن هڪ ميڪرو غلط قيمتون منظور ڪري وڃي ٿو.
    /// حتمي branch کانسواءِ ، مرتب ڪندڙ اڃا تائين غلطي خارج ڪري ٿو ، پر غلطي جو پيغام ٻن صحيح قدرن جو ذڪر نه ڪندو.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// مرتب ڪرڻ واري غلطي کي اجايو جيڪڏهن ڪيترين ئي فيچرن مان هڪ موجود نه آهي.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ٻئي اسٽرنگ-فارميٽنگ ميڪروز لاءِ پيراگراف ٺهيل آهن.
    ///
    /// ھي ميڪرو فنڪشن فارميٽ اسٽرنگ لفظ کڻڻ کان وٺي `{}` تي مشتمل ھر اضافي دليل پاس جي لاءِ.
    /// `format_args!` اضافي پيٽرولز تيار ڪندو آهي انهي کي يقيني بڻائڻ لاءِ پيداوار هڪ اسٽرنگ وانگر سمجهي سگهجي ٿي ۽ دليلن کي هڪ قسم ۾ تبديل ڪري سگهجي ٿو.
    /// ڪي به قدر جيڪو لاڳو ڪري ٿو [`Display`] trait کي `format_args!` ڏانهن منتقل ڪري سگھجي ٿو ، جئين ڪو به [`Debug`] لاڳو ڪرڻ `{:?}` کي فارميٽنگ واري اسٽرنگ ۾ منتقل ڪري سگھجي ٿو.
    ///
    ///
    /// ھي ميڪرو ايڪس جي قسم جو قدر پيدا ڪري ٿو.اهو ويليو مفيد ريڊريشن جي لاءِ [`std::fmt`] جي اندر ميڪرو پاس ڪري سگهجي ٿو.
    /// ٻين سڀني فارميٽنگ وارا ميڪروز (["فارميٽ!"] ، [`write!`] ، [`println!`] ، وغيره) پر انهي جي ذريعي پيش ڪيل آهن.
    /// `format_args!`, پنهنجي نڪتل ميڪروز جي برعڪس ، ڊسپلي واري پئڪيجز کان بچي ٿو.
    ///
    /// توهان استعمال ڪري سگھوٿا [`fmt::Arguments`] قدر جيڪو `format_args!` واپس اچي ٿو `Debug` ۽ `Display` حوالي سان جيئن هيٺ ڏٺو ويو آهي.
    /// مثال پڻ ڏيکاري ٿو ته `Debug` ۽ `Display` ساڳئي شڪل ڏانهن: ايڪس پي ايڪس ۾ بين الاقوامي فارميٽ اسٽرنگ.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// وڌيڪ معلومات لاءِ ، ڏسو [`std::fmt`] ۾ دستاويز.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// ساڳيو `format_args` ، پر آخر ۾ نئين لائن شامل ڪري ٿو.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// ترتيب واري وقت تي ماحول واري ڪيفيت جي معائنو ڪندو آهي.
    ///
    /// اهو ميڪرو مجموعي وقت جي نالي واري ماحول جي متغير جي قيمت ڏانهن وڌندي ، ايڪس ايڪس ايڪس قسم جو اظهار پيدا ڪندي.
    ///
    ///
    /// جيڪڏهن ماحول جي متحرڪ وضاحت نه ڪئي وئي ، ته هڪ مجموعي غلطي ختم ٿي ويندي.
    /// تاليف واري غلطي کي نه وجھڻ لاءِ ، استعمال ڪريو [`option_env!`] ميڪرو بدران.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// توھان ھڪڙي اسٽرنگ کي ٻئي پيراگراف جي پاس ڪرڻ سان غلط پيغام کي ترتيب ڏئي سگھو ٿا.
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// جيڪڏهن `documentation` ماحول واري ڪيفيت بيان نه ڪئي وئي آهي ، توهان هيٺين غلطي حاصل ڪندا:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// اختياري طور تي ماحول واري ڪيفيت کي ترتيب ڏيڻ واري وقت تي چڪاس ڪندو آهي.
    ///
    /// جيڪڏهن نالي واري ماحول جو تغيرات وقت جي ترتيب تي موجود آهي ، اهو ايڪسڪسيمڪس قسم جي ايڪسپريس ۾ وڌي ويندو جنهن جي قيمت ماحول جي متغير جي قيمت `Some` آهي.
    /// جيڪڏهن ماحول جو تغير موجود نه آهي ، ته اهو ايڪس ايڪس ايڪس تائين وڌي ويندو.
    /// انهي قسم بابت وڌيڪ معلومات لاءِ [`Option<T>`][Option] ڏسو.
    ///
    /// انهي ميڪرو کي استعمال ڪندي جڏهن ماحول ماحول متغير موجود آهي يا نه ، ڪڏهن به مرتب ٿيل وقت جي غلطي ڪڏهن به خارج نه ٿيندي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// سڃاڻپ ڪندڙ کي ھڪ سڃاڻيندڙ ۾ تبديل ڪري ٿو.
    ///
    /// اهو ميڪو ڪاما کان جدا ٿيل سڃاڻپ ڪندڙن جو ڪو نمبر وٺي ٿو ، ۽ انهن سڀني کي هڪ ۾ ملائي ٿو ، هڪ اظهار پيدا ڪري ٿو جيڪو هڪ نئون سڃاڻڻ وارو آهي.
    /// ياد رکجي ته حفظان صحت ان کي انهي طرح ڪري ٿو ته هي ميڪرو مقامي متغير تي قبضو نه ٿو ڪري سگهي.
    /// گڏوگڏ ، عام قاعدي جي طور تي ، ميڪروز کي صرف شين ، بيان يا اظهار واري پوزيشن ۾ اجازت ڏنل آهي.
    /// ان جو مطلب جڏهن توهان موجوده متغيرات ، افعال يا ماڊل وغيره جي حوالي سان هن ميڪرو استعمال ڪري سگهو ٿا ، توهان ان سان نئين وضاحت نه ٿا ڪري سگهو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (نئون ، مزو ، نالو) { }//ھن طريقي سان قابل استعمال نہ آھي!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// اصطلاحن کي جامد اسٽرنگ سليس ۾ ملائيندو آهي.
    ///
    /// اهو ميڪو ڪاما کان ڌار ليٽرز جو ڪو به نمبر وٺي ٿو ، ايڪس ايڪس ايڪس قسم جو اظهار ڏيکاري ٿو جيڪا سڀني کاٻي کان سا rightي طرف سان ڳن allيل لکندڙن جي نمائندگي ڪري ٿو.
    ///
    ///
    /// انٽيگريٽر ۽ فلوٽنگ پوائنٽ لفظي انگ اکر ترتيب ڏيڻ لاءِ ترتيب ڏنل آهن.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// انهي نمبر جي نمبر تي وڌندي جنهن تي هن کي ڪال ڪيو ويو هو.
    ///
    /// [`column!`] ۽ [`file!`] سان ، اهي ميڪرو ڊولپرز کي ماخذ اندر مقام بابت معلومات مهيا ڪندا آهن.
    ///
    /// وڌايل اظهار جو قسم `u32` آهي ۽ 1 تي ٻڌل آهي ، تنهن ڪري هر فائل ۾ پهرين لائن 1 ، ٻي کان 2 ، وغيره تائين تشخيص ڪري ٿي.
    /// اهو عام مرتب ڪندڙن يا مشهور ايڊيٽرن جي طرفان غلط پيغامن سان برابر آهي.
    /// واپسي واري لائن *لازمي طور تي*`line!` انوڪوشن واري لائن ناهي ، بلڪه `line!` ميڪرو کي سڏڻ سان گڏ پهرين ميڪرو انوائيشن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// وڌايو ويو ڪالمن نمبر تي جنهن تي ان کي سڏيو ويو هو.
    ///
    /// [`line!`] ۽ [`file!`] سان ، اهي ميڪرو ڊولپرز کي ماخذ اندر مقام بابت معلومات مهيا ڪندا آهن.
    ///
    /// وڌايل اظهار جو قسم `u32` آھي ۽ 1 تي ٻڌل آھي ، تنھنڪري ھر قطار ۾ پھريون ڪالم 1 ، ٻئي کان 2 ، وغيره کي تشخيص ڪري ٿو.
    /// اهو عام مرتب ڪندڙن يا مشهور ايڊيٽرن جي طرفان غلط پيغامن سان برابر آهي.
    /// واپس ڪيل ڪالم *لازمي طور تي*`column!` انوڪوشن واري لائن پاڻ ناهي ، بلڪه `column!` ميڪرو کي سڏڻ سان گڏ پهرين ميڪرو انوائيشن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// وڌندي آھي فائل نالي ڏانھن جنھن ۾ ان کي سڏيو ويو آھي.
    ///
    /// [`line!`] ۽ [`column!`] سان ، اهي ميڪرو ڊولپرز کي ماخذ اندر مقام بابت معلومات مهيا ڪندا آهن.
    ///
    /// وڌايل اظهار جو قسم `&'static str` آھي ، ۽ واپس ٿيل فائل پاڻ کي `file!` ميڪرو جو سڏيندڙ ڪونھي ، بلڪه `file!` ميڪرو کي دعوت ڏيڻ واري اڳواٽ ميڪرو انوکو آھي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// ان جي دليلن کي سخت ڪري ٿو.
    ///
    /// اهو ميڪرو ايڪس ايڪس ايڪس قسم جو اظهار پيدا ڪري ٿو جيڪو سڀني tokens جي ترتيب ڏئي ٿو ميڪرو ڏانهن.
    /// خود مڪو انڪوٽو ڪرڻ جي نحو تي پابنديون نه رکيون آهن.
    ///
    /// نوٽ ڪريو ته ان پتي جي وڌايل نتيجا tokens future ۾ تبديل ٿي سگھن ٿا.توهان کي محتاط هئڻ گهرجي جيڪڏهن توهان محصول تي اعتبار ڪيو ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ھڪڙي اسٽرنگ وانگر UTF-8 انڪوڊ ٿيل فائل شامل آھي.
    ///
    /// فائل موجوده فائل جي نسبت سان واقع آهي (ساڳي طرح ڪئين ماڊل ڪيئن مليل آهن).
    /// مهيا ڪيل رستو مرتب ٿيل وقت تي پليٽ فارم جي مخصوص طريقي سان تعبير ڪيو ويندو آهي.
    /// تنهن ڪري ، مثال طور ، پٺتي ڌڪي `\` تي مشتمل هڪ Windows رستي سان گڏ دعوت ، Unix تي صحيح گڏ نه ٿي سگھندي.
    ///
    ///
    /// اهو ميڪرو ايڪس ايڪس ايڪس قسم جو اظهار پيدا ڪري ٿو جيڪا فائل جي مواد واري آهي.
    ///
    /// # Examples
    ///
    /// فرض ڪريو ھڪڙي ڊائريڪٽري ۾ ھيٺيون مواد آھن ھڪڙي ھيٺ ڏنل مواد سان.
    ///
    /// فائيل 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// فائيل 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' گڏ ڪرڻ ۽ نتيجو ڪندڙ بائنري "adiós" پرنٽ ڪندا.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// بائيٽ صف جي حوالي سان فائل شامل آهي.
    ///
    /// فائل موجوده فائل جي نسبت سان واقع آهي (ساڳي طرح ڪئين ماڊل ڪيئن مليل آهن).
    /// مهيا ڪيل رستو مرتب ٿيل وقت تي پليٽ فارم جي مخصوص طريقي سان تعبير ڪيو ويندو آهي.
    /// تنهن ڪري ، مثال طور ، پٺتي ڌڪي `\` تي مشتمل هڪ Windows رستي سان گڏ دعوت ، Unix تي صحيح گڏ نه ٿي سگھندي.
    ///
    ///
    /// اهو ميڪرو ايڪس ايڪس ايڪس قسم جو اظهار پيدا ڪري ٿو جيڪا فائل جي مواد واري آهي.
    ///
    /// # Examples
    ///
    /// فرض ڪريو ھڪڙي ڊائريڪٽري ۾ ھيٺيون مواد آھن ھڪڙي ھيٺ ڏنل مواد سان.
    ///
    /// فائيل 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// فائيل 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' گڏ ڪرڻ ۽ نتيجو ڪندڙ بائنري "adiós" پرنٽ ڪندا.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ھڪڙي تار ڏانھن وڌندي آھي جيڪو موجوده ماڊل وارو رستو پيش ڪري ٿو.
    ///
    /// موجوده ماڊل جو رستو crate root کي واپس وٺي موجود ماڊلز جي هينٽري جي طور تي سوچي سگهجي ٿو.
    /// رستي جو پهريون حصو موٽي ويو crate جو نالو آھي جيڪو في الحال مرتب ڪيو پيو وڃي.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// ترتيب واري وقت تي ترتيب واري جھنڊين جا بولن جي مجموعن جو جائزو وٺندي آهي.
    ///
    /// `#[cfg]` وصف جي علاوه ، هن ميڪرو مهيا ڪئي وئي آهي ترتيب جي جھنڊي جي بولين جي اظهار جي تشخيص جي.
    /// اهو بار بار گهٽ نقل ٿيل ڪوڊ ڏانهن ويندا آهن.
    ///
    /// هن ميڪرو کي ڏنل ڏني وئي نحو [`cfg`] واري خاصيت جي برابر ئي آهي.
    ///
    /// `cfg!`, `#[cfg]` جي برعڪس ، ڪو به ڪوڊ خارج نٿو ڪري ۽ صرف صحيح يا غلط جي تشخيص ڪري ٿو.
    /// مثال طور ، if/else جي بيان ۾ سڀ بلاڪ درست ٿيڻ گهرجن جڏهن `cfg!` شرط لاءِ استعمال ٿئي ، قطع نظر انهي جي ته ڇا `cfg!` جائزو وٺي رهيو آهي.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// فائل هڪ قاعدي موجب بيان ڪيل هجي يا شيءَ جي لحاظ کان هڪ شيءَ کي.
    ///
    /// فائل موجوده فائل جي نسبت سان واقع آهي (ساڳي طرح ڪئين ماڊل ڪيئن مليل آهن).مهيا ڪيل رستو مرتب ٿيل وقت تي پليٽ فارم جي مخصوص طريقي سان تعبير ڪيو ويندو آهي.
    /// تنهن ڪري ، مثال طور ، پٺتي ڌڪي `\` تي مشتمل هڪ Windows رستي سان گڏ دعوت ، Unix تي صحيح گڏ نه ٿي سگھندي.
    ///
    /// هن ميڪرو کي استعمال ڪرڻ گهڻو ڪري خراب خيال آهي ، ڇاڪاڻ ته جيڪڏهن فائل هڪ ظاهري طور تي تجزيو ڪيو وڃي ، اهو ڀرپاسي جي ڪوڊ ۾ غيرجانبدار طور تي رکيو وڃي رهيو آهي.
    /// اهو نتيجو ٿي سگهي ٿو متغير يا افعال ان کان مختلف هجن جئين فائل جي توقع هجي جيڪڏهن متغير يا افعال آهن جن جو موجوده نالو ۾ ساڳيو نالو آهي.
    ///
    ///
    /// # Examples
    ///
    /// فرض ڪريو ھڪڙي ڊائريڪٽري ۾ ھيٺيون مواد آھن ھڪڙي ھيٺ ڏنل مواد سان.
    ///
    /// فائيل 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// فائيل 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' گڏ ڪرڻ ۽ نتيجو ڪندڙ بائنري "🙈🙊🙉🙈🙊🙉" پرنٽ ڪندا.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// انهي ڳالهه جو اظهار ڪيو ته بولين جو اظهار رن ٽائيم تي `true` آهي.
    ///
    /// اهو [`panic!`] ميڪرو سڏيندو جيڪڏهن مهيا ڪيل اظهار `true` کي رن ٽائيم تي تشخيص نه ٿي ڪري سگهجي.
    ///
    /// # Uses
    ///
    /// ڊيبيوز ۽ رليز بلڊس ۾ اشاعتون هميشه چڪاس ڪيون وينديون آهن ، ۽ غير فعال نٿا ڪري سگهجن.
    /// ڏسو [`debug_assert!`] جتن لاءِ جيڪي ڊفالٽ ۾ رليز بلڊس ۾ فعال ٿيل ناهن.
    ///
    /// غير محفوظ ڪوڊ `assert!` تي ڀروسو ڪري سگھي ٿو رٽ ٽائم ٽرومنٽ لاڳو ڪرڻ لاءِ ، جيڪڏهن خلاف ورزي ٿيندي ڪي غير محفوظ ٿي سگھي ٿي.
    ///
    /// `assert!` جي ٻين استعمال ڪيسن ۾ سيف ڪوڊ ۾ ٽيسٽ وقت هلندڙ انوڪارين کي شامل ۽ لاڳو ڪرڻ شامل آهن (جن جي خلاف ورزي نااميدگي جو نتيجو نه ٿي سگھي).
    ///
    ///
    /// # ڪسٽم پيغام
    ///
    /// ھن ميڪو ۾ ھڪڙو ٻيو فارم آھي ، جتي ڪسٽمائيز panic پيغام فارميٽ جي دليلن سان يا فراهم ڪري سگھجن ٿيون.
    /// هن فارم لاءِ نحو لاءِ [`std::fmt`] ڏسو.
    /// فارميٽ دليلن جي طور تي استعمال ٿيندڙ طريقا صرف ان وقت جاچيا ويندا جڏهن اهو قائل ناڪام ٿيندو.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ھن اشارن لاءِ panic پيغام ڏنو ويو آھي ظاھر ٿيل قيمت آھي.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // هڪ تمام سادو فنڪشن
    ///
    /// assert!(some_computation());
    ///
    /// // مرضي مطابق پيغام سان
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// ان لائن اسيمبلي.
    ///
    /// پڙهڻ لاءِ [unstable book] پڙهو.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// ايل ايل وي ايم طرز جي ان لائن اسيمبلي.
    ///
    /// پڙهڻ لاءِ [unstable book] پڙهو.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// ماڊل-سطح ان لائن اسيمبلي.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// پرنٽ tokens معياري ٻا passed ۾ گذري ويا.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ٻئي ميڪروز کي ڊيبگ ڪرڻ لاءِ استعمال ٿيل نشان لڳائڻ واري فعاليت کي فعال يا غير فعال ڪري ٿو.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// منسوب ٿيندڙ کي لاڳو ڪندي ميڪرو خاصيت ڪندا هئا.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// انتساب ميڪرو هڪ فنڪشن تي لاڳو ڪيو ويو ان کي يونٽ ٽيسٽ ۾ بدلائڻ لاءِ.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// منڊي کي منسوب ڪيو ويو هڪ ڪارڪردگي تي ڪم ڪرڻ لاءِ ان کي معياري مارڪ ٽيسٽ ۾ تبديل ڪرڻ.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` ۽ `#[bench]` ميڪروز جي هڪ عملدرآمد تفصيل.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// منسوب ڪندڙ منسوب جامد تي لاڳو ڪيو ويو ته ان کي عالمي مختص ڪندڙ طور رجسٽر ڪيو وڃي.
    ///
    /// پڻ ڏسو [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// شي کي جاري رکيو ٿو وڃي جيڪڏهن منظور ٿيل رستو رسائي لائق هجي ، ۽ ٻي صورت ۾ ان کي ڪ remي ٿو.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// سڀني `#[cfg]` ۽ `#[cfg_attr]` خاصيتن کي وڌايو آھي ڪوڊ ٽڪرا ۾ اھو تي لاڳو ٿيل آھي.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` مرتب ڪندڙ غير مستحڪم عمل واري تفصيل ، استعمال نه ڪريو.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` مرتب ڪندڙ غير مستحڪم عمل واري تفصيل ، استعمال نه ڪريو.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}