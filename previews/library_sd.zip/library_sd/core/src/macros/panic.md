Panics موجوده سلسلو.

اهو هڪ پروگرام کي فوري طور تي ختم ڪرڻ ۽ پروگرام جي سڏيندڙ کي موٽ فراهم ڪرڻ جي اجازت ڏي ٿو.
`panic!` استعمال ڪيو وڃي جڏهن هڪ پروگرام ناقابل واپسي رياست تائين پهچي وڃي.

هي ميڪرو بهترين طريقي سان مثالن جا ڪوڊ ۽ ٽيسٽ ۾ حالتن جي تصديق ڪرڻ جو آهي.
`panic!` ويجهڙائي سان [`Option`][ounwrap] ۽ [`Result`][runwrap] ٻنهي مان `unwrap` طريقي سان ڳن tiedيل آهي.
ٻئي عمل درآمد `panic!` کي سڏيندا آهن جڏهن اهي [`None`] يا [`Err`] وارينٽس تي سيٽ ڪيا ويندا آهن.

جڏهن `panic!()` استعمال ڪري توهان هڪ اسٽرنگ پيڊ لوڊ بيان ڪري سگھو ٿا ، جيڪو [`format!`] نحو استعمال ڪندي ٺهيل آهي.
انهي پيڊ لوڊ کي استعمال ڪيو ويندو آهي جڏهن panic کي ڪال ڪرڻ واري Rust سلسلي ۾ داخل ڪندي ، مڪمل طور تي panic واري سلسلي کي.

ڊفالٽ `std` hook جو رويو ، يعني
ڪوڊ جيڪو سڌو panic کي سڏيو ويندو ھجي ٿو ، X02 کي `panic!()` جي معلومات جي file/line/column سان گڏ پيغام پے لوڊ کي پرنٽ ڪرڻو آھي.

توهان [`std::panic::set_hook()`] استعمال ڪندي panic hook تي چڙهائي سگهو ٿا.
hook جي اندر ، panic کي `&dyn Any + Send` تائين پهچائي سگھجي ٿو ، جنهن ۾ باقاعده `panic!()` انوائسز لاء `&str` يا `String` شامل آهن.
ٻئي قسم جي قيمت سان panic ڏانهن ، [`panic_any`] استعمال ڪري سگھجي ٿو.

[`Result`] اينم عام طور تي `panic!` ميڪرو استعمال ڪرڻ کان غلطين کان وصولي جو هڪ بهتر حل آهي.
ھن ميڪرو کي غلط قدرن جي استعمال سان اڳتي وڌڻ کان پاسو ڪرڻ گھرجي جيئن خارجي ذريعن کان.
[book] ۾ غلطي جي سنڀال بابت تفصيلي 00اڻ ملي ٿي.

تاليف دوران غلطيون وڌائيندي ، پڻ ميڪرو [`compile_error!`] کي ڏسو.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# موجوده عمل درآمد

جيڪڏهن مکيه سلسلي panics اهو توهان جي س threadي سلسلي کي ختم ڪري ڇڏيندو ۽ پروگرام `101` سان توهان جي پروگرام کي ختم ڪندو.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





