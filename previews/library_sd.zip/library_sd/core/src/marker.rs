//! بنيادي traits ۽ قسم جا قسم جي بنيادي ملڪيت جي نمائندگي ڪن ٿا.
//!
//! Rust قسمون پنھنجي اندروني ملڪيت جي مطابق مختلف مفيد طريقن سان درجه بندي ڪري سگھجن ٿيون.
//! اهي درجابندي traits طور پيش ڪيون وينديون آهن.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// قسمون جيڪي موضوعن جي حدن ۾ منتقل ڪري سگهجن ٿيون.
///
/// اهو trait پاڻمرادو لاڳو ٿئي ٿو جڏهن مرتب ڪندڙ پاڻ کي طئي ڪري ٿو ته مناسب آهي.
///
/// هڪ 'موڪلي' قسم جو هڪ مثال حوالن جي ڳڻپيندڙ پوائنٽر [`rc::Rc`][`Rc`] آهي.
/// جيڪڏهن ٻه سلسلا ڪلون ڪرڻ جي ڪوشش ڪن ٿيون [`آر سي] جيڪو ساڳئي حوالن جي ڳڻپ واري قدر ڏانهن اشارو ڪن ٿا ، اهي شايد ساڳئي وقت ريفرنس جي ڳڻپ کي تازه ڪاري ڪرڻ جي ڪوشش ڪري ، جيڪا [undefined behavior][ub] آهي ڇاڪاڻ ته [`Rc`] ايٽمي آپريشنز استعمال نٿو ڪري.
///
/// هن جي کزن [`sync::Arc`][arc] ايٽمي آپريشن استعمال ڪندو آهي (ڪجهه اوور ويڊ ٿيڻ) ۽ اهڙي طرح `Send` آهي.
///
/// وڌيڪ تفصيل لاءِ [the Nomicon](../../nomicon/send-and-sync.html) ڏسو.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// جامد وقت تي knownاتل مستقل سائيز سان ٽائپ.
///
/// سڀني قسمن جي پيٽرولن کي `Sized` جي هڪ ظاهري پابند آهي.جيڪڏهن اها مناسب نه هجي ته ان کي هٽائڻ لاءِ خاص نحو `?Sized` استعمال ڪري سگهجي ٿي.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // جوڙ FooUse(Foo<[i32]>) ؛//غلطي: [i32] لاءِ سئيز تي عمل ناهي ڪيو ويو
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// ھڪڙي استثنا ھڪڙي ظاھر ٿيل `Self` قسم آھي trait.
/// trait کي بي نقاب `Sized` پابند ناهي ، جئين اهو [trait اعتراض] سان مطابقت ناهي رکي ، جتي ، تعريف جي لحاظ کان ، trait کي هر ممڪن عمل ڪندڙ سان ڪم ڪرڻ جي ضرورت آهي ، ۽ اهڙي طرح ڪنهن به سائيز ٿي سگهي ٿي.
///
///
/// جيتوڻيڪ Rust توهان کي `Sized` کي trait تي پابند ڪندو ، توهان بعد ۾ trait اعتراض ٺاهڻ لاءِ استعمال نه ڪري سگهندا.
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // اچو y: &dyn بار= &Impl ؛//غلطي: trait `Bar` شئي ۾ نٿي ٺاهي سگھجي
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // پهريان کان ڊيفالٽ لاءِ ، مثال طور ، جيڪو گهربل x00X جائزو وٺڻ جي ضرورت آهي
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// قسمن جو متحرڪ سائيز واري قسم جي "unsized" ٿي سگھي ٿي.
///
/// مثال طور ، ترتيب واري ترتيب جو قسم `[i8; 2]` لاڳو ڪري ٿو `Unsize<[i8]>` ۽ `Unsize<dyn fmt::Debug>`.
///
/// `Unsize` جو س implementو عمل درآمد ڪندڙ پاڻمرادو ترتيب ڏنل آهن.
///
/// `Unsize` جي لاءِ لاڳو ڪيو ويو آهي:
///
/// - `[T; N]` ايڪس X00 آهي
/// - `T` آهي `Unsize<dyn Trait>` جڏهن `T: Trait` آهي
/// - `Foo<..., T, ...>` آهي `Unsize<Foo<..., U, ...>>` جيڪڏهن:
///   - `T: Unsize<U>`
///   - فو هڪ تعمير آهي
///   - صرف `Foo` جي آخري فيلڊ ۾ ھڪڙي قسم شامل آھي `T`
///   - `T` ڪنهن ٻئي شعبن جي قسم جو حصو نه آهي
///   - `Bar<T>: Unsize<Bar<U>>`, جيڪڏهن `Foo` جي آخري فيلڊ ۾ `Bar<T>` جو قسم آهي
///
/// `Unsize` استعمال ڪيو ويو آهي [`ops::CoerceUnsized`] سان گڏ "user-defined" ڪنٽينرز جهڙوڪ [`Rc`] متحرڪ طئي ڪرڻ وارن قسمن تي مشتمل ڪرڻ جي اجازت ڏيڻ لاءِ.
/// وڌيڪ تفصيل لاءِ ڏسو [DST coercion RFC][RFC982] ۽ [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// پيٽرن جي ميچن ۾ استعمال ٿيندڙ مستقليون لاءِ گهربل trait.
///
/// `PartialEq` حاصل ڪيل ڪو به قسم trait پاڻمرادو لاڳو ڪري ٿو ،*قطع نظر* ته ڇا هن جي قسم جا پيرا ميٽر `Eq` لاڳو ڪندا آهن.
///
/// جيڪڏهن هڪ `const` شئي ڪجهه اهڙي قسم تي مشتمل آهي جيڪو trait کي نافذ نٿو ڪري ، ته پوءِ اهڙي قسم يا (1.) `PartialEq` لاڳو نٿو ڪري (جنهن جو مطلب آهي ته مسلسل اهو موازنہ پيش نه ڪندو ، جيڪو ڪوڊ جنريشن موجود آهي) ، يا (2.) اهو *لاڳو ڪندو* پنهنجو پاڻ * `PartialEq` جو نسخو (جيڪو اسان فرض ڪريون ٿا ته اهو هڪ-انچي جي برابر مساوات جي مطابق نه آهي).
///
///
/// مٿي ڏنل ٻن منظرنامن مان ، اسان هڪ نمونو ميچ ۾ اهڙي مسلسل جي استعمال کي رد ڪيون ٿا.
///
/// پڻ ڏسو [structural match RFC][RFC1445] ، ۽ [issue 63438] جنهن کي منسوب ڪيو ويو آهي منسوب بي بنياد ڊيزائن کان trait ڏانهن.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// پيٽرن جي ميچن ۾ استعمال ٿيندڙ مستقليون لاءِ گهربل trait.
///
/// `Eq` حاصل ڪيل ڪو به قسم trait پاڻمرادو لاڳو ڪري ٿو *بغير پروا* انهي جو ته ايڪسپيٽر ايڪس پيڪس لاڳو ٿئي ٿي.
///
/// هي اسان جي قسم جي نظام ۾ حد جي چوڌاري ڪم ڪرڻ لاءِ هاڪ آهي.
///
/// # Background
///
/// اسان انهي کان مطالبو ڪرڻ چاهيون ٿا ته نمونن جي ميچ ۾ استعمال ٿيندڙ قائداعظم جي خاصيت `#[derive(PartialEq, Eq)]` هجي.
///
/// وڌيڪ مثالي دنيا ۾ ، اسان انهي ضرورت کي چڪاس ڪري سگھوٿا ته جئين قسم `StructuralPartialEq` trait *۽*`Eq` trait ٻنهي کي لاڳو ڪري ٿو.
/// تنهن هوندي ، توهان ڪري سگهو ٿا ADTs جيڪي *ڪر*`derive(PartialEq, Eq)` ، ۽ هڪ ڪيس هجڻ گهرجي جنهن کي اسان ٺاهيندڙ کي قبول ڪرڻ چاهيو ، ۽ اڃا تائين مسلسل قسم جو `Eq` کي عمل ڪرڻ ۾ ناڪام آهي.
///
/// ڇهن ، اهڙي صورت وانگر:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (مٿي ڏنل ڪوڊ ۾ مسئلو اهو آهي ته `Wrap<fn(&())>` `PartialEq` ۽ `Eq` تي عمل نٿو ڪري ، ڇاڪاڻ ته `لاءِ <
///
/// تنهن ڪري ، اسان `StructuralPartialEq` ۽ صرف `Eq` جي غير معمولي چيڪ تي اعتبار نٿا ڪري سگهون.
///
/// هن جي چوڌاري ڪم ڪرڻ لاءِ هيڪ طور ، اسان ٻن ڌار ڌار traits کي استعمال ڪريون ٿا هر هڪ پاران نڪتل آهي (`#[derive(PartialEq)]` ۽ `#[derive(Eq)]`) ۽ چڪاس ڪريو ته انهن ٻنهي اهو موجود آهي ساختاتي ميچ جي چڪاس جي حصي طور.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// ٽائپ جن جي قدرن کي صرف نقل ڪندي نقل ڪري سگهجي ٿي.
///
/// ڊفالٽ طرفان ، متغير پابندين کي 'حرڪت واري سيمينٽ' آهي.ٻين لفظن ۾:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y` ۾ منتقل ڪيو ويو آهي ، ۽ تنهن ڪري استعمال نٿا ڪري سگهجي
///
/// // ڇاپيو! ("{: ؟}" ، x) ؛//غلطي: منتقل ٿيل قدر جو استعمال
/// ```
///
/// تنهن هوندي ، جيڪڏهن هڪ قسم `Copy` تي عمل ڪندو آهي ، ان جي بدران 'ڪاپي سيمينٽڪ' آهي:
///
/// ```
/// // اسان هڪ `Copy` عملدرآمد حاصل ڪري سگھون ٿا.
/// // `Clone` پڻ گهربل آهي ، جئين اهو `Copy` جو هڪ سپرٽيٽريٽ آهي.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x` جي ڪاپي آهي
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// اهو نوٽ ڪرڻ ضروري آهي ته انهن ٻن مثالن ۾ ، صرف فرق اهو آهي ته ڇا توهان کي تفويض کانپوءِ `x` تائين رسائي جي اجازت آهي.
/// ھيڊ جي ھيٺان ، ھڪڙي ڪاپي ۽ ھلڻ واري نتيجي ۾ ، بٽس ۾ ياداشت ۾ نقل ٿي سگھي ٿي ، جيتوڻيڪ ھي ڪڏھن ڪ optimڻو آھي.
///
/// ## آئون `Copy` کي ڪيئن لاڳو ڪري سگهان ٿو؟
///
/// توهان جي قسم تي `Copy` لاڳو ڪرڻ جا ٻه طريقا آهن.س00و آسان `derive` استعمال ڪرڻ آهي:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// توهان پڻ `Copy` ۽ `Clone` دستي طور تي لاڳو ڪري سگهو ٿا.
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// ٻنهي جي وچ ۾ هڪ نن differenceڙو فرق آهي: `derive` حڪمت عملي پڻ `Copy` هڪ قسم جي پيرا ميٽرز جي پابند هوندي ، جيڪا هميشه نه چاهيو.
///
/// ## `Copy` ۽ `Clone` جي وچ ۾ ڇا فرق آهي؟
///
/// نقلون ظاهري طور تي ٿينديون آهن ، مثال طور ايڪسينڪس ايڪسائنڪس جي تفويض جي حصي طور.`Copy` جو رويو اوور لوڈ ٿيل نه آهي ؛اهو هميشه سادي بائيٽ وار ڪاپي آهي.
///
/// ڪلوننگ هڪ ظاهري عمل آهي ، ايڪس 100.[`Clone`] جو نفاذ محفوظ رکي سگھي ٿو ٻئي قسم جي مخصوص رويي کي محفوظ طور نقل ڪرڻ واريون قدرون.
/// مثال طور ، [`String`] جي لاءِ [`Clone`] جي نفاذ جي ضرورت آهي ته اشارو ۾ واري تار واري بفر کي ڪوپ ۾ ڪاپي ڪجي.
/// [`String`] قدرن جي هڪ سادي ساٿي ڪاپي صرف پوائنٽر کي ڪاپي ڪري ڇڏيندي ، لڪير کي ٻيڻو ڪرڻ جو سبب بڻجندي.
/// انهي سبب ، [`String`] [`Clone`] آهي پر `Copy` ناهي.
///
/// [`Clone`] `Copy` جو سپرٽرٽ آھي ، تنھنڪري سڀ ڪجھ جيڪو `Copy` آھي ، [`Clone`] کي به لاڳو ڪرڻ گھرجي.
/// جيڪڏهن هڪ قسم `Copy` آهي ته پوءِ ان جو [`Clone`] عمل درآمد صرف `*self` واپس ڪرڻ جي ضرورت آهي (مٿين مثال ڏسو).
///
/// ## منهنجو قسم `Copy` ڪڏهن ٿي سگهي ٿو؟
///
/// ھڪڙو قسم `Copy` لاڳو ڪري سگھي ٿو جيڪڏھن ان جا سڀئي حصا `Copy` لاڳو ڪن.مثال طور ، هي جوڙجڪ `Copy` ٿي سگهي ٿو:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// ھڪڙي جوڙجڪ `Copy` ٿي سگھي ٿو ، ۽ [`i32`] `Copy` آھي ، تنھنڪري `Point` `Copy` ٿيڻ جي قابل آھي.
/// تڪرار سان ، غور ڪريو
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// ساخت `PointList` `Copy` لاڳو نٿو ڪري سگھي ، ڇاڪاڻ ته [`Vec<T>`] `Copy` ڪونھي.جيڪڏهن اسان `Copy` لاڳو ڪرڻ جي ڪوشش ڪئي ، اسان هڪ غلطي حاصل ڪنداسين.
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// حصيداري ڪيل حوالا (`&T`) پڻ `Copy` آهن ، تنهن ڪري هڪ قسم `Copy` ٿي سگهي ٿو ، جيتوڻيڪ جڏهن اهو `T` قسم جا گڏيل حوالا رکي ٿو جيڪي *نه*`Copy` آهن.
/// هيٺ ڏنل جوڙجڪ تي غور ڪريو ، جيڪو `Copy` لاڳو ڪري سگهي ٿو ، ڇاڪاڻ ته اهو صرف مٿي ڏنل *غير حصيداري* اسان جي غير-ڪاپي قسم `PointList` ڏانهن رکي ٿو:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## *ڇا* منهنجو قسم `Copy` نٿو ٿي سگهي؟
///
/// ڪجهه قسمن کي محفوظ سان نقل نٿو ڪري سگهجي.مثال طور ، `&mut T` کي نقل ڪندي هڪ نالي واري مٽا سٿي حوالي سان ٺاهي ويندي.
/// [`String`] ڪاپي ڪرڻ [String]] جي بفر کي منظم ڪرڻ جي ذميداري جي نقل ها ، ٻيڻو مفت ڏانهن وڃي ٿي.
///
/// بعد ۾ ڪيس کي عام ڪرڻ ، ڪنهن به قسم کي [`Drop`] لاڳو ڪرڻ `Copy` نه ٿو ٿي سگهي ، ڇاڪاڻ ته اهو پنهنجي [`size_of::<T>`] بائٽس کان علاوه ڪجهه وسيلن جو انتظام ڪري رهيو آهي.
///
/// جيڪڏھن توھان ھڪڙي ڪري رھيا آھيو `Copy` ھڪڙو اسٽيڪ يا اينيم تي جيڪي غير "ڪاپي" ڊيٽا تي مشتمل آھن ، توھان حاصل ڪندؤ [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## ڇا *ڇا هجڻ گهرجي* منهنجو قسم `Copy` هجڻ گهرجي؟
///
/// عام طور تي ڳالهائڻ ، جيڪڏهن توهان جو قسم _can_ ايڪسڪسيمڪس لاڳو ڪري ٿو ، اهو هئڻ گهرجي.
/// جيتوڻيڪ ذهن ۾ رکون ، ايڪس آرڪس لاڳو ڪرڻ توهان جي قسم جي عوامي API جو حصو آهي.
/// جيڪڏهن قسم future ۾ غير-ڪاپي ٿي سگهي ٿي ، `Copy` جي عملدرآمد کي هاڻي ختم ڪرڻ عقلمندي ٿي سگهي ٿي ، ڀڃڪڙي API جي تبديلي کان بچڻ لاءِ.
///
/// ## اضافي پليجو
///
/// [implementors listed below][impls] جي اضافي ۾ ، هيٺيان قسم `Copy` پڻ لاڳو ڪن ٿيون.
///
/// * فنڪشن شئي جا قسم (يعني هر فنڪشن لاءِ مقرر ڪيل جدا جدا قسم)
/// * فنڪشن پوائنٽر جا قسم (مثال طور ، `fn() -> i32`)
/// * صفن جا قسم ، سڀني سائيز لاءِ ، جيڪڏهن شيءَ جو قسم به `Copy` تي لاڳو ٿئي ٿو (مثال طور ، `[i32; 123456]`)
/// * ٽوپل جا قسم ، جيڪڏهن هر جزو `Copy` پڻ لاڳو ڪندو آهي (مثال طور ، `()` ، `(i32, bool)`)
/// * بندش جا قسم ، جيڪڏهن اهي ماحول کان ڪابه قدر قبضي ۾ نه وٺندا يا جيڪڏهن اهي سڀئي قبضو ڪيل قدر پاڻ ۾ `Copy` لاڳو ڪندا.
///   ياد رکجو متغير حصيداري ڪيل حوالن طرفان هميشه `Copy` لاڳو ڪندا آهن (جيتوڻيڪ جيڪڏهن حوالو نه هجي) ، جڏهن ته متغير حوالا پاران قبضو ڪيل variables ڪڏهن به `Copy` لاڳو نٿا ڪن
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) اهو هڪ قسم کي نقل ڪرڻ جي اجازت ڏئي ٿو جيڪا `Copy` لاڳو نه ڪندو آهي ڇاڪاڻ ته غير اطمينان واري زندگي جي حدن جي ڪري (`A<'_>` ڪاپي ڪري رهيو آهي جڏهن صرف `A<'static>: Copy` ۽ `A<'_>: Clone`).
// اسان وٽ هتي صرف هن لاءِ خاصيتون هتي آهن ، ڇاڪاڻ ته `Copy` وٽ ڪجهه موجوده خاصيتون موجود آهن جيڪي اڳ ۾ ئي معياري لائبريري ۾ موجود آهن ، ۽ هن وقت محفوظ طور تي انهي رويي جو ڪو طريقو ناهي.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// ماخوذ ميڪرو trait `Copy` جو نقشو پيدا ڪري ٿو.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// قسمن لاءِ جن جي سلسلي ۾ حوالن جي حصيداري ڪرڻ محفوظ آهي.
///
/// اهو trait پاڻمرادو لاڳو ٿئي ٿو جڏهن مرتب ڪندڙ پاڻ کي طئي ڪري ٿو ته مناسب آهي.
///
/// صحيح نموني: هڪ قسم `T` آهي [`Sync`] جيڪڏهن ۽ صرف جيڪڏهن `&T` [`Send`] آهي.
/// ٻين لفظن ۾ ، جيڪڏهن موضوعن جي وچ ۾ `&T` ريفرنس پاس ڪرڻ وقت [undefined behavior][ub] (ڊيٽا ريس سميت) جو ڪو به امڪان ناهي.
///
/// جيئن ته توقع ڪئي وئي ، آدمشماري قسم جهڙوڪ [`u8`] ۽ [`f64`] سڀ [`Sync`] آهن ، ۽ ائين سادي مجموعي قسم آهن ، انهن ۾ شامل آهن ، جهڙوڪ ٽپلس ، ساخت ۽ اينيمس.
/// بنيادي [`Sync`] قسم جا وڌيڪ مثال شامل آهن "immutable" قسم `&T` ، ۽ اهي جيڪي سادي ورثي ميثاق سان گڏ آهن ، جهڙوڪ [`Box<T>`][box] ، [`Vec<T>`][vec] ۽ ٻيا ڪيترائي قسم جا.
///
/// (انهن جي ڪنٽينر لاءِ عام پيٽرولس کي [`Sync`] هجڻ گهرجن [`Sync`].
///
/// ڪجهه تعجب ڪندڙ تعريف جو نتيجو اهو آهي ته `&mut T` `Sync` آهي (جيڪڏهن `T` `Sync` آهي) جيتوڻيڪ اهو لڳي ٿو ته شايد غير مطابقت پذير ميوٽيشن مهيا ڪري سگهي ٿي.
/// چال اهو آهي ته هڪ گڏيل ريفرنس جي پويان هڪ قابل تبديلي وارو حوالو (اهو آهي ، `& &mut T`) صرف پڙهڻ وارو ٿئي ٿو ، itڻ ته اهو `& &T` هجي.
/// ان ڪري ڊيٽا نسل جي ڪا خطري ناهي.
///
/// قسمون جيڪي `Sync` نه آھن اھي آھن جن ۾ غير سلسلي واري محفوظ شڪل ۾ "interior mutability" آھن ، اھڙي طرح [`Cell`][cell] ۽ [`RefCell`][refcell].
/// اهي قسمون پنهنجن مواد جي ميوٽيشن کي غير بدليل ، گڏيل حوالي ذريعي پڻ اجازت ڏين ٿيون.
/// مثال طور ، `set` [`Cell<T>`][cell] جو طريقو `&self` وٺي ٿو ، تنهن ڪري ان کي صرف هڪ گڏيل حوالو [`&Cell<T>`][cell] جي ضرورت آهي.
/// طريقو ڪوبه هم وقت سازي نه ڪندو آهي ، اهڙي طرح [`Cell`][cell] `Sync` نه ٿو ٿي سگهي.
///
/// غير "سنڪ" قسم جو ٻيو مثال حوالو-ڳڻپيندڙ پوائنٽر [`Rc`][rc] آهي.
/// ڪنهن به حوالي سان [`&Rc<T>`][rc] ڏنو ، توهان هڪ نئون [`Rc<T>`][rc] کلون ڪري سگهو ٿا ، غير ايٽمي طريقي سان حوالن جي شمارن کي تبديل ڪري سگهو ٿا.
///
/// ڪيسن جي لاءِ جڏهن هڪ گهري واري محفوظ گهريلو تڪرار جي ضرورت هوندي آهي ، Rust مهيا ڪندو آهي [atomic data types] ، ۽ گڏوگڏ [`sync::Mutex`][mutex] ۽ [`sync::RwLock`][rwlock] ذريعي واضح تالا لڳائڻ.
/// انهن قسمن کي يقيني بڻائي ٿو ته ڪو به dataير dataار ڊيٽا ريسز جو سبب نٿي بڻجي سگهي ، انهي ڪري اهي قسمون `Sync` آهن.
/// اهڙي طرح ، [`sync::Arc`][arc] [`Rc`][rc] جو هڪ محفوظ محفوظ اينالاگ مهيا ڪندو آهي.
///
/// ڪنهن به قسم سان داخلي mutيرائيت سان value(s) ويڙهاڪ پڻ استعمال ڪرڻ لازمي آهي value(s) جنهن کي هڪ گڏيل حوالي سان ملائي سگهجي ٿو.
/// اهو ڪرڻ ۾ ناڪام [undefined behavior][ub] آهي.
/// مثال طور ، [Transute`][transmute]-ing کان `&T` کان `&mut T` غلط آهي.
///
/// `Sync` بابت وڌيڪ تفصيل لاءِ ڏسو [the Nomicon][nomicon-send-and-sync].
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): هڪ دفعو بيٽا ۾ `rustc_on_unimplemented` زمينن ۾ نوٽس شامل ڪرڻ جي حمايت ڪئي وئي آهي ، ۽ انهي کي چڪاس ڪيو ويو آهي ته ڇا بندش گهربل زنجير ۾ ڪٿي به آهي ، ايڪس ايڪس ايڪس وانگر وڌايو آهي:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// زيرو سائيز جو قسم انهن شين تي نشان لڳائيندو هو ته "act like" انهن وٽ هڪ `T` هوندي آهي.
///
/// توهان جي قسم ۾ `PhantomData<T>` فيلڊ شامل ڪرڻ سان کمپائلر کي ٻڌائي ٿو ته توهان جو قسم ڪم ڪري ٿو جئين ته اهو ايڪسڪسيمڪس قسم جي قيمت کي اسٽور ڪري ٿو ، جيتوڻيڪ اها واقعي واقعي ناهي.
/// اها معلومات استعمال ڪئي وئي آهي جڏهن خاص حفاظتي خاصيتن کي ڳڻپيو ويندو آهي.
///
/// وڌيڪ تفصيل جي وضاحت لاءِ ته `PhantomData<T>` ڪئين استعمال ڪجي ، مهرباني ڪري [the Nomicon](../../nomicon/phantom-data.html) کي ڏسو.
///
/// # هڪ غمناڪ نوٽ 👻👻👻
///
/// جيتوڻيڪ انهن ٻنهي ۾ خوفناڪ نالا هوندا آهن ، `PhantomData` ۽ `پريتم قسمون` جڙيل آهن ، پر هڪجهڙا نه آهن.هڪ پرنٽ قسم جي پيمراٽر صرف هڪ قسم جي پيمائٽر آهي جيڪو ڪڏهن به استعمال نه ٿيندو آهي.
/// Rust ۾ ، اهو اڪثر ڪري ٺاهيندڙ کي شڪايت ڪرڻ جو سبب بڻائيندو آهي ، ۽ حل ايڪس `PhantomData` X ذريعي "dummy" استعمال کي شامل ڪرڻ جو حل آهي.
///
/// # Examples
///
/// ## بي حياتي حياتي واريون پيراگراف
///
/// شايد `PhantomData` جو سڀ کان عام استعمال ڪيس هڪ ساخت آهي جنهن جي استعمال ٿيل اڻ پوري حياتي پيراگراف آهي ، خاص طور تي ڪجهه غير محفوظ ڪوڊ جي حصي طور.
/// مثال طور ، هتي هڪ اڏاوت `Slice` آهي جنهن جا قسم `*const T` جا ٻه اشارو آهن ، شايد ڪنهن جاءِ تي ڳجهارت ۾ اشارو ڪن ٿا.
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// ارادو اھو آھي ته ھيٺين ڊيٽا صرف `'a` جي پوري عمر لاءِ صحيح آھي ، تنھنڪري `Slice` کي `'a` کي ٻاھر نه ڇڏڻ گھرجي.
/// تنهن هوندي ، هن ارادا کي ڪوڊ ۾ ظاهر ناهي ڪيو ويو ، ڇو ته حياتي `'a` X جي ڪا به استعمال ناهي ۽ انهي جي ڪري اهو واضح ناهي ته اهو ڪهڙي ڊيٽا تي لاڳو ٿئي ٿو.
/// اسان ان کي درست ڪري سگهو ٿا ڪمپائلر کي اهو عمل ڪندي *ڻ ته*`Slice` جوڙ هڪ حوالو `&'a T` شامل آهي:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// انهي ۾ پڻ وضاحت جي ضرورت آهي `T: 'a` ، ظاهر ڪري ٿو ته `T` ۾ ڪنهن به حوالو `'a` سXي عرصي تائين صحيح آهن.
///
/// جڏھن توھان `Slice` جي شروعات ڪري سگھوٿا توھان فيلڊ `phantom` لاءِ صرف `PhantomData` قدر فراهم ڪريو:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## استعمال ٿيل قسم جا پيراگراف
///
/// اهو ڪڏهن ڪڏهن ٿئي ٿو ته توهان استعمال ڪيو آهي قسم جا پيرا ميٽر جيڪي ظاهر ڪن ٿا ته ڪهڙي قسم جو ڊيٽا ايڪس آرڪس ڏانهن آهي ، جيتوڻيڪ اها ڊيٽا پاڻ وٽ ساخت ۾ نه آهي.
/// هتي هڪ مثال آهي جتي هي [FFI] سان گڏ پيدا ٿئي ٿو.
/// غير ملڪي انٽرفيس استعمال ڪن ٿا `*mut ()` قسم جا Rust قدرن کي مختلف قسمن جو.
/// اسان ڊائريڪٽ `ExternalResource` تي هڪ فينٽم قسم پيمائٽر استعمال ڪندي Rust قسم ٽريڪ ڪريون ٿا جيڪو هل سنڀال ڪري ٿو.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## ملڪيت ۽ ڊراپ چيڪ
///
/// قسم `PhantomData<T>` جو فيلڊ شامل ڪرڻ اهو اشارو ڏئي ٿو ته توهان جو قسم `T` قسم جو ڊيٽا مالڪ آهي.اھو ان جي نتيجي ۾ اھو ظاھر ڪندو آھي ته جڏھن توھان جو قسم گريو ويو آھي ، اھو قسم `T` جي ھڪڙي يا وڌيڪ مثالن کي ڇڏي سگھي ٿو.
/// ھي اثر Rust ٺاھيندڙ جي [drop check] تجزيي تي.
///
/// جيڪڏهن توهان جي اڏاوت حقيقت ۾ *پنهنجي* قسم *جو ڊيٽا `T` ناهي ، اهو بهتر آهي ته حوالو قسم جو استعمال ڪجي ، جهڙوڪ `PhantomData<&'a T>` (ideally) يا `PhantomData<* const T>` (جيڪڏهن ڪو لائفائم لاڳو نه ٿئي) ، ته جيئن ملڪيت ظاهر ڪرڻ نه گهرجي.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// کمپائلر-اندروني trait اينيم تعصب جي قسم ڏانهن اشارو ڪندو هو.
///
/// اهو trait پاڻمرادو هر قسم جي لاءِ لاڳو ٿئي ٿو ۽ ايڪس او ايس ايڪس کي ڪابه ضمانت شامل نٿو ڪري.
/// اهو `DiscriminantKind::Discriminant` ۽ `mem::Discriminant` جي وچ ۾ منتقل ڪرڻ ** غير متعين رويو آهي.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// تعصب وارو قسم ، جيڪو لازمي طور تي `mem::Discriminant` کان trait bounds کي مطمئن ڪندڙ هجي.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// کمپائلر-اندروني trait اهو طئي ڪيو هو ته ڇا هڪ قسم اندروني طور تي ڪنهن `UnsafeCell` تي مشتمل آهي ، پر ڪنهن هدايت جي ذريعي نه.
///
/// اهو اثر پوي ٿو ، مثال طور ، ڇا انهي قسم جي `static` صرف پڙهڻ واري جامد ميموري يا ريليبل اسٽيڪ ميموري ۾ رکيل آهي.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// ٽائپ جيڪي محفوظ طور تي پن ٿيڻ بعد منتقل ٿي سگھن ٿا.
///
/// Rust پاڻ کي غير typesرندڙ قسمن جو ڪو به تصور ناهي ، ۽ هلڻ تي غور ڪندو آهي (مثال طور ، تفويض ذريعي يا [`mem::replace`]) هميشه سان محفوظ رهڻ لاءِ.
///
/// [`Pin`][Pin] قسم استعمال ڪيو ويندو آهي بدران ٽائپ سسٽم ذريعي هلڻ کان روڪڻ.اشارو `P<T>` [`Pin<P<T>>`][Pin] لفاف ۾ لپيل ٻاهر نڪري نه ٿا سگھن.
/// پنڻ بابت وڌيڪ معلومات لاءِ [`pin` module] دستاويز ڏسو.
///
/// `T` لاء `Unpin` trait کي لاڳو ڪرڻ ، قسم کي پن ڪرڻ جي پابنديون ختم ڪري ٿو ، جيڪي پوءِ `T` کي [`Pin<P<T>>`][Pin] کان ڪم ڪرڻ جي اجازت ڏئي ٿو جهڙوڪ [`mem::replace`].
///
///
/// `Unpin` ڪو به پن consequاڻايل ڊيٽا لاءِ ڪو نتيجو نه آهي.
/// خاص طور تي ، [`mem::replace`] خوشيءَ سان `!Unpin` ڊيٽا منتقل ڪري ٿو (اهو ڪنهن `&mut T` لاءِ ڪم ڪري ٿو ، نه فقط جڏهن `T: Unpin`).
/// تنهن هوندي ، توهان [`Pin<P<T>>`][Pin] اندر لپي ڊيٽا تي استعمال نٿا ڪري سگهو ڇاڪاڻ ته توهان `&mut T` حاصل نٿا ڪري سگهو توهان جي ضرورت آهي ، ۽ *اهو* جيڪو هن سسٽم کي ڪم ڪندو آهي.
///
/// تنهنڪري هي ، مثال طور ، صرف `Unpin` تي لاڳو ٿيندڙ قسمن تي ڪري سگهجي ٿو.
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // اسان کي `mem::replace` سڏڻ لاءِ هڪ متغير حوالو جي ضرورت آهي.
/// // اسان (implicitly) کي `Pin::deref_mut` سڏيندي اهڙو حوالو حاصل ڪري سگهون ٿا ، پر اهو صرف ممڪن آهي ڇاڪاڻ ته `String` `Unpin` کي لاڳو ڪندو آهي.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// هي trait تقريبن هر قسم جي لاءِ لاڳو ٿئي ٿي.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// مارڪر جو قسم جيڪو `Unpin` تي عمل نٿو ڪري.
///
/// جيڪڏهن هڪ قسم ۾ `PhantomPinned` شامل آهي ، اهو ڊفالٽ طور `Unpin` تي عمل نه ڪندو.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// `Copy` جي ابتدائي قسمن بابت پليپشن.
///
/// عمل درآمد جيڪي Rust ۾ بيان نه ٿي ڪري سگھجن ٿيون `traits::SelectionContext::copy_clone_conditions()` ۾ `rustc_trait_selection` ۾.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// گڏيل حوالا نقل ٿي سگھن ٿا ، پر متغير حوالا * نٿا آڻي سگهجن!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}