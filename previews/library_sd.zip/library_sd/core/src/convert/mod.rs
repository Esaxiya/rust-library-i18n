//! Traits تبديلي لاء قسمن جي وچ ۾.
//!
//! هن ماڊل ۾ traits هڪ قسم کان ٻئي قسم ۾ تبديل ڪرڻ جو طريقو مهيا ڪندو آهي.
//! هر trait هڪ مختلف مقصد حاصل ڪري ٿو:
//!
//! - لاڳو ڪريو [`AsRef`] trait سستا حوالن جي حوالي سان تبادلي جي لاءِ
//! - لاڳو ڪريو [`AsMut`] trait سستا بدلڻ-مٽ-مائٽ تبادلن لاءِ
//! - پئسن جي قيمت ڏي وٺ ڪرڻ لاءِ [`From`] trait لاڳو ڪريو
//! - موجوده crate کان ٻاهر جي قسمن جي قيمت تي قدرن جي قيمت جي استعمال لاء [`Into`] trait لاڳو ڪريو
//! - [`TryFrom`] ۽ [`TryInto`] traits جو سلوڪ [`From`] ۽ [`Into`] وانگر آھي ، پر ان کي لاڳو ڪيو وڃي جڏھن تبديلي ناڪام ٿي سگھي.
//!
//! هن ماڊل ۾ traits اڪثر ڪري عام استعمالن لاءِ trait bounds طور استعمال ڪيا ويندا آهن جيئن ڪيترن ئي قسمن جي دليلن جي مدد ڪئي وڃي.هر trait جي دستاويز مثال طور ڏسو.
//!
//! لائبريري ليکڪ جي طور تي ، توهان کي هميشه هميشه [`From<T>`][`From`] يا [`TryFrom<T>`][`TryFrom`] بجاءِ [`Into<U>`][`Into`] يا [`TryInto<U>`][`TryInto`] لاڳو ڪرڻ جي ترجيح ڏيڻي آهي ، جئين [`From`] ۽ [`TryFrom`] وڌيڪ لچڪ فراهم ڪن ۽ مفت [`Into`] يا [`TryInto`] عمل درآمد پيش ڪن مفت لائبريري جي شبانه معيار لائبريري ۾
//! جڏھن Rust 1.41 کان پھريائين ھڪڙي نسخہ کي ھدف ڪريو ، اھو موجوده crate کان ٻاھر ھڪڙي قسم کي بدلائڻ دوران [`Into`] يا [`TryInto`] سڌو سنئون لاڳو ڪرڻ ضروري آھي.
//!
//! # عام عمل درآمد
//!
//! - [`AsRef`] ۽ [`AsMut`] خود ڊيوٽي جيڪڏهن اندروني قسم جو هڪ حوالو آهي
//! - ["کان"] <U>لاءِ T جي معنيٰ ["Into"] آهي</u><T><U>يو لاءِ</u>
//! - ["TryFrom"] "T" <U>جو مطلب آهي ["TryInto"] "</u><T><U>يو لاءِ</u>
//! - [`From`] ۽ [`Into`] reflexive آهن ، جنهن جو مطلب آهي ته هر قسم پنهنجو پاڻ `into` ۽ `from` پاڻ ڪري سگهي ٿو
//!
//! استعمال ڪريو مثالن لاءِ ھر trait ڏسو.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// سڃاڻپ جو فنڪشن.
///
/// انهي ڪم بابت ياد رکڻ لاءِ ٻه شيون اهم آهن:
///
/// - اھو هميشه ايڪس 100 وانگر ھڪڙي بند ڪرڻ جي برابر ناھي ، جئين ته بند ٿي سگھي ٿو `x` ھڪڙو مختلف قسم ۾.
///
/// - اهو انڪشن `x` کي منتقل ڪيو ويو فنڪشن ڏانهن ويو.
///
/// جيتوڻيڪ اهو فنڪشن لڳي سگهي ٿو اهو عجیب هوندو آهي جيڪو صرف واپسي کي واپس ڏئي ٿو ، ڪجهه دلچسپ استعمال آهن.
///
///
/// # Examples
///
/// ٻين شين جي دلچسپ ، فني شين جي تسلسل ۾ ڪجهه به ڪرڻ لاءِ `identity` استعمال نه ڪرڻ:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // اچو ته اهو پيش ڪريون ته هڪ شامل ڪرڻ هڪ دلچسپ فنڪشن آهي.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// هڪ مشروط طور "do nothing" بنيادي ڪيس کي "do nothing" استعمال ڪندي:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // وڌيڪ دلچسپ شيون ٺاهيو
///
/// let _results = do_stuff(42);
/// ```
///
/// ايڪسڪسيمڪس استعمال ڪندي X002 جي هڪ ورجاءُ جي مختلف قسمن کي `identity` استعمال ڪرڻ:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// سستا حوالا-حوالا conversionيرائڻ لاءِ استعمال ڪندا هئا.
///
/// ھي trait اھڙي آھي [`AsMut`] جيڪو استعمال ٿيندڙ قابل referencesاڻايل حوالن جي وچ ۾ آھي.
/// جيڪڏهن توهان کي مهانگي بدلاءُ ڪرڻ جي ضرورت آهي ته اهو بهتر آهي ايڪس آرڪس کي `&T` سان لکو يا وري ڪسٽم فنڪشن لکو.
///
/// `AsRef` ھڪڙي ھڪڙي دستخط آھي ھڪڙي [`Borrow`] وانگر ، پر [`Borrow`] ڪجھ حصن ۾ مختلف آھي:
///
/// - `AsRef` جي نسبت ، [`Borrow`] وٽ ھڪڙو `T` ھڪڙي ڪمبل آھي ، ۽ استعمال ڪري سگھجي ٿو يا ته ريفرنس يا قدر قبول ڪرڻ لاءِ.
/// - [`Borrow`] انهي جي لاءِ به ضرورت آهي ته قرض وٺڻ واري قيمت لاءِ [`Hash`] ، [`Eq`] ۽ [`Ord`] اهي ملڪيت جي برابر جي برابر آهن.
/// انهي سبب لاءِ ، جيڪڏهن توهان ساخت جي صرف هڪ فيلڊ تان قرض وٺڻ چاهيو ٿا ته توهان `AsRef` لاڳو ڪري سگهو ٿا ، پر [`Borrow`] نه.
///
/// **Note: ھي trait ناڪام ٿيڻ نٿي گھرجي **.جيڪڏهن تبديلي ناڪام ٿي سگهي ٿي ، هڪ وقف طريقو استعمال ڪريو جيڪو [`Option<T>`] يا [`Result<T, E>`] واپس ڪري ٿو.
///
/// # عام عمل درآمد
///
/// - `AsRef` پاڻمرادو حوالاجيون جيڪڏهن اندروني قسم هڪ حوالو هجي يا هڪ قابل تغير حوالو (مثال طور: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// trait bounds استعمال ڪندي اسان مختلف قسمن جي دليلن کي قبول ڪري سگهون ٿا جيسين تائين اهي مخصوص قسم `T` ۾ تبديل ٿي سگھن.
///
/// مثال طور: هڪ عام فنڪشن ٺاهڻ سان جيڪو هڪ `AsRef<str>` وٺي ٿو اسان اظهار ڪريون ٿا ته اسان سڀني حوالن کي قبول ڪرڻ چاهيون ٿا جيڪي دليل طور [`&str`] ۾ بدلجي سگهجن ٿيون.
/// ٻئي [`String`] ۽ [`&str`] کان وٺي `AsRef<str>` لاڳو ڪندا آھن اسين ٻئي قبول ڪري سگھوٿا انپٽ دليل جي طور تي.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// انجام ڏي ٿو.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// سستا ableر mutار----reference reference reference reference reference reference reference reference reference reference reference to to to to to do to to to to to
///
/// ھي trait ھڪڙي [`AsRef`] وانگر آھي پر استعمال ٿيندڙ حوالن جي وچ ۾ تبديل ڪرڻ لاءِ استعمال ٿيل آھي.
/// جيڪڏهن توهان کي مهانگي بدلاءُ ڪرڻ جي ضرورت آهي ته اهو بهتر آهي ايڪس آرڪس کي `&mut T` سان لکو يا وري ڪسٽم فنڪشن لکو.
///
/// **Note: ھي trait ناڪام ٿيڻ نٿي گھرجي **.جيڪڏهن تبديلي ناڪام ٿي سگهي ٿي ، هڪ وقف طريقو استعمال ڪريو جيڪو [`Option<T>`] يا [`Result<T, E>`] واپس ڪري ٿو.
///
/// # عام عمل درآمد
///
/// - `AsMut` اندروني دخل جيڪڏهن اندروني قسم هڪ مترجم حوالو آهي (مثال طور: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// هڪ عام فنڪشن لاءِ `AsMut` کي trait bound استعمال ڪندي اسان سڀني بدل ٿيندڙ حوالن کي قبول ڪري سگھون ٿا جيڪي ايڪس ايڪس ايڪس ٽائيپ ۾ بدلجن ٿيون.
/// ڇاڪاڻ ته [`Box<T>`] `AsMut<T>` لاڳو ڪندو آهي اسان هڪ فنڪشن `add_one` لکي سگھو ٿا جيڪو سڀني دليلن کي وٺي ٿو جيڪو `&mut u64` ۾ بدلجي سگھي ٿو.
/// ڇاڪاڻ ته [`Box<T>`] `AsMut<T>` لاڳو ڪري ٿو ، `add_one` پڻ `&mut Box<u64>` قسم جي دليلن کي قبول ڪري ٿو.
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// انجام ڏي ٿو.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// ويليو-ويليو ڪنورنس جيڪا انپٽ ويليو کي استعمال ڪندي آهي.[`From`] جي سامهون.
///
/// هڪ کي [`Into`] لاڳو ڪرڻ کان پاسو ڪرڻ گهرجي ۽ [`From`] جي بدران نافذ ڪرڻ گهرجي.
/// [`From`] تي عمل درآمد خود هڪ کي فراهم ڪندو آهي ايڪسڪسيمڪس جي هڪ عملدرآمد جي مهرباني معياري لائبريري ۾ ڪمبل تي لاڳو ٿيڻ.
///
/// جڏهن عام واري فنڪشن تي trait bounds بيان ڪيو وڃي ته [`Into`] تي [`Into`] استعمال ڪرڻ کي ترجيح ڏيو ، اهو يقيني بڻائڻ لاءِ صرف [`Into`] استعمال ڪيا وڃن.
///
/// **Note: ھي trait ناڪام ٿيڻ نٿي گھرجي **.جيڪڏهن ڪنيڪشن ناڪام ٿي سگهي ٿي ، ايڪس ايڪس ايڪس استعمال ڪريو.
///
/// # عام عمل درآمد
///
/// - ["کان"]<T>توهان جي لاءِ `Into<U> for T` جو مطلب آهي
/// - [`Into`] اهو reflexive آهي ، جنهن جو مطلب آهي `Into<T> for T` لاڳو ڪيو ويو آهي
///
/// # Rust جي پراڻي نسخن ۾ ٻاهرين قسمن ڏانهن تبديلين لاءِ [`Into`] لاڳو ڪرڻ
///
/// Rust 1.41 کان پهريان ، جيڪڏهن منزل جو قسم موجوده crate جو حصو نه هو ته پوءِ توهان سڌي طرح [`From`] نافذ نٿا ڪري سگھو.
/// مثال طور ، هي ڪوڊ وٺو.
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// اهو ٻولي جي پراڻي نسخن ۾ مرتب ڪرڻ ۾ ناڪام ٿيندو ڇاڪاڻ ته Rust جا يتيم اصول ڪجهه وڌيڪ سخت هوندا هئا.
/// انهي کي نظرانداز ڪرڻ لاءِ ، توهان سڌو سنئون [`Into`] نافذ ڪري سگھو ٿا:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// اهو سمجهڻ ضروري آهي ته [`Into`] [`From`] عمل مهيا نٿو ڪري (جئين [`From`] [`Into`] سان ڪندو آهي).
/// تنهن ڪري ، توهان کي هميشه [`From`] کي لاڳو ڪرڻ جي ڪوشش ڪرڻ گهرجي ۽ پوءِ [`Into`] ڏانهن واپس اچو جيڪڏهن [`From`] نافذ نه ٿي سگهي.
///
/// # Examples
///
/// [`String`] لاڳو ٿئي ٿو ["۾"] <"[" وييڪ "]" "[u8"] >> ":
///
/// اهو اظهار ڪرڻ لاءِ ته اسان عام دليل ڏيڻ چاهيون ٿا سڀني دليلن تي جيڪي مخصوص قسم جي `T` ۾ بدلجي سگھجن ٿيون ، اسين [ZoTrait0Z bound of ["Into"] استعمال ڪري سگھو ٿا<T>".
///
/// مثال طور: فنڪشن `is_hello` سڀني دلائل کي کڻي ٿو جيڪي ["Vec"] "<" ["u8"] "> ۾ تبديل ٿي سگھن ٿيون.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// انجام ڏي ٿو.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// ان پٽ ويل کي استعمال ڪرڻ وقت ويليو-ويليو ڪنورينز ڪندا هئا.اهو [`Into`] جو مشاهدو آهي.
///
/// هڪڙي هميشه هميشه `From` تي `From` لاڳو ڪرڻ کي ترجيح ڏي ٿو ڇاڪاڻ ته `From` لاڳو ڪرڻ هڪ پاڻ کي [`Into`] جي عمل سان مهيا ڪري ٿو معياري لائبريري ۾ خالي عملن جي مهرباني.
///
///
/// صرف Rust 1.41 کان اڳ واري نسخي کي ھدف ڪندي ۽ موجوده crate کان ٻاھر ھڪڙي قسم کي تبديل ڪرڻ دوران [`Into`] لاڳو ڪريو.
/// `From` Rust جي يتيم ضابطن جي ڪري اڳئين ورزن ۾ هن قسم جي چڪاس ڪرڻ جي قابل نه هئس.
/// وڌيڪ تفصيل لاءِ [`Into`] ڏسو.
///
/// هڪ عام فنڪشن تي trait bounds کي وضاحت ڪندي `From` استعمال ڪرڻ دوران [`Into`] کي ترجيح ڏيو.
/// هن طريقي سان ، ايڪس آرڪس تي سڌو سنئون پليور جا قسم دليلن طور پڻ استعمال ٿي سگهن ٿا.
///
/// غلطي کي سنڀالڻ دوران `From` پڻ تمام ڪارائتو آهي.جڏهن هڪ فنڪشن ٺاهي رهيو جيڪو ناڪام بڻائڻ جي قابل هوندو ، واپسي جو قسم عام طور تي `Result<T, E>` جو هوندو.
/// `From` trait غلطي سنڀالڻ کي آسان بڻائي ٿو ھڪڙي فنڪشن کي ھڪڙي قسم جي غلطي کي واپس ڪرڻ جي اجازت ڏي ٿو جيڪي ڪيترن ئي غلط قسم کي سٽ ڪري رھيا آھن.وڌيڪ تفصيل لاءِ "Examples" سيڪشن ۽ [the book][book] ڏسو.
///
/// **Note: ھي trait ناڪام ٿيڻ نٿي گھرجي **.جيڪڏهن ڪنيڪشن ناڪام ٿي سگهي ٿي ، ايڪس ايڪس ايڪس استعمال ڪريو.
///
/// # عام عمل درآمد
///
/// - `From<T> for U` مطلب آهي "[۾"] <U>T لاءِ</u>
/// - `From` اهو reflexive آهي ، جنهن جو مطلب آهي `From<T> for T` لاڳو ڪيو ويو آهي
///
/// # Examples
///
/// [`String`] `From<&str>` تي لاڳو ٿئي ٿو:
///
/// ھڪڙي `&str` کان ھڪڙو اسٽرنگ ڏانھن ظاھر ٿيل تبديلي ھيٺ ڏنل آھي:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// غلطي کي ھلائڻ دوران عمل ڪندي توھان پنھنجي غلطي جي قسم لاءِ ايڪس00ڪس کي لاڳو ڪرڻ لاءِ گھڻو ڪارآمد آھي.
/// بنيادي غلطي جي قسمن کي پنهنجي ذاتي غلطي جي قسم ۾ تبديل ڪرڻ سان جيڪي هيٺيان غلط قسم کي طئي ڪري ڇڏيندا آهن ، اسان هڪ ئي غلطي جي قسم کي واپس آڻي سگهون ٿا ـ بنيادي سبب تي معلومات وڃائڻ کانسواءِ.
/// '?' آپريٽر پاڻمرادو غلطي واري قسم کي `Into<CliError>::into` سڏ ڪري اسان جي گراهڪ غلطي جي قسم کي خود بخود تبديل ڪري ٿو.
/// مرتب ڪندڙ وري داخل ڪري ٿو جيڪو `Into` جو نفاذ استعمال ڪيو وڃي.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// انجام ڏي ٿو.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// هڪ ڪوشش واري تبديلي جيڪا ايڪس ايڪس ايڪس کي استعمال ڪري ٿي ، جيڪا شايد قيمتي يا قيمتي نه هجي.
///
/// لائبريري جي ليکڪ عام طور تي هن trait کي سڌو سنئون عمل درآمد نه ڪرڻ گهرجن ، پر ايڪس اين ايڪس trait تي عمل درآمد کي ترجيح ڏي ، جيڪو وڌيڪ لچڪ فراهم ڪري ٿو ۽ برابر برابر `TryInto` عمل درآمد مهيا ڪري ٿو ، مهرباني ڪري معياري لائبريري ۾ هڪ خالي پيٽ تي عملدرآمد جي مهرباني.
/// انهي بابت وڌيڪ معلومات لاءِ ، ايڪس ايڪس ايڪس لاءِ دستاويز ڏسو.
///
/// # `TryInto` تي عمل ڪرائڻ
///
/// هي [`Into`] لاڳو ڪرڻ وانگر ساڳيون پابنديون ۽ استدلال سان ڀريل آهي ، هتي تفصيل لاءِ ڏسو.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// قسم بدلائي جي غلطي جي صورت ۾ واپس آيو.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// انجام ڏي ٿو.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// سادي ۽ محفوظ قسم جي thatير someار جيڪا شايد ڪجهه حالتن ۾ قابو واري طريقي سان ناڪام ٿي سگھي.اهو [`TryInto`] جو مشاهدو آهي.
///
/// اهو مفيد آهي جڏهن توهان هڪ قسم جي doingير doingار ڪري رهيا آهيو ته عارضي طور تي ڪامياب ٿي سگهي ٿو پر شايد ان کي خاص سنڀالڻ جي ضرورت پڻ آهي.
/// مثال طور ، [`From`] trait استعمال ڪندي [`i64`] کي [`i32`] ۾ تبديل ڪرڻ جو ڪو طريقو ناهي ، ڇاڪاڻ ته هڪ [`i64`] هڪ قيمت رکي سگهي ٿو جيڪو [`i32`] نمائندگي نٿو ڪري سگهي ۽ پوءِ ڪنورٽ جي ڊيٽا وڃائي ها.
///
/// اهو شايد [`i64`] کي [`i32`] ڏانهن ختم ڪرڻ سان (لازمي طور تي ["i64"] وارو قدر ماڊلولو [`i32::MAX`] ڏي ٿو) يا صرف [`i32::MAX`] موٽڻ ، يا ڪنهن ٻئي طريقي سان.
/// [`From`] trait مڪمل ڪنوريوشنز لاءِ تيار آهي ، تنهن ڪري `TryFrom` trait پروگرامر کي آگاهي ڏئي ٿو جڏهن هڪ قسم جي تبديلي خراب ٿي سگهي ٿي ۽ انهن کي اِهو فيصلو ڪرڻ جي اجازت ڏي.
///
/// # عام عمل درآمد
///
/// - `TryFrom<T> for U` اس جو مطلب آهي ["TryInto"] " <U>T لاءِ</u>
/// - [`try_from`] اهو reflexive آهي ، جنهن جو مطلب اهو آهي ته `TryFrom<T> for T` لاڳو ٿيل آهي ۽ ناڪام نٿو ٿي سگھي-`T::try_from()` کي ڪال ڪرڻ لاءِ لاڳاپيل `Error` قسم `T` قسم جي قيمت تي [`Infallible`] آهي.
/// جڏهن [`!`] قسم کي مستحڪم ڪيو ويو آهي [`Infallible`] ۽ [`!`] برابر ٿي ويندو.
///
/// `TryFrom<T>` هيٺ ڏنل طور تي لاڳو ٿي سگهي ٿو.
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// جي طور تي بيان ڪيو ويو آهي ، ايڪسڪسيمڪس "ڪوشش ڪريو <" ["i64"]>>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // خاموشيء سان ايڪس آرڪس کي ختم ڪري ٿو ، واقعي کان بعد ٽريڪشن کي ڳولڻ ۽ هٿ ڪرڻ جي ضرورت آهي.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // غلطي ڏانھن واپسي ڏئي ٿي ڇاڪاڻ ته `big_number` اي `i32` ۾ فٽ ڪرڻ لاءِ تمام وڏو آهي.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` واپس ڪري ٿو.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// قسم بدلائي جي غلطي جي صورت ۾ واپس آيو.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// انجام ڏي ٿو.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// عام طور تي اثر
////////////////////////////////////////////////////////////////////////////////

// جيئن لفٽ ختم ٿيڻ ۽
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// جئين ايڪس اين ايڪس ايڪس کان مٿي لفٽ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): مٿي ڏنل نقشن کي مٽائڻ واري&سان گڏ وڌيڪ عام طور تي.
// // جئين Deref مٿان لفٽون
// نقشو <D: ?Sized + Deref<Target: AsRef<U>> ، يو:؟ سائز> اي ايس ريف <U>ڊي لاءِ {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut ايڪسڪسيمڪس مٿان ختم ڪري ٿو
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ھيٺ ڏنل impl کي &mut ھيٺ ڏنل وڌيڪ عام سان تبديل ڪريو.
// // AsMut ڊيرفٽ مٿان ويٺو
// نقشو <D: ?Sized + Deref<Target: AsMut<U>> ، يو:؟ سائز> اي ايم ايمٽ <U>لاءِ ڊي {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// شموليت کان
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// کان (۽ اهڙي طرح Into) عڪسي آهي
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **استحڪام نوٽ:** اهو نقشو اڃا موجود ناهي ، پر اسان 0future ۾ ان کي شامل ڪرڻ لاءِ ايڪس آرڪس آهيون.
/// تفصيل لاءِ [rust-lang/rust#64715][#64715] ڏسو.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ڪيو ويندو اصولي طور تي ٺيڪ.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom کان مطلب آهي TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// ناقابل برداشت conversير semارڪ اھم طور تي ھڪڙي رھيل غلطي جي ھڪڙي قسم جي تبادلي جي برابر آھن.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// صحيح نقطن
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// بغير غلطي جي غلطي جو قسم
////////////////////////////////////////////////////////////////////////////////

/// نقصن جو قسم غلط جيڪو ڪڏهن به ٿي نٿو سگهي.
///
/// کان وٺي ان جي ڪابه مختلف قسم ناهي ، هن قسم جي قيمت ڪڏهن به وجود نٿي رکي سگھي.
/// اهو عام ڪندڙ APIs لاءِ ڪارائتو ٿي سگهي ٿو جيڪي [`Result`] استعمال ڪن ٿيون ۽ غلطي جي قسم کي پيمريٽري ڪري ڏين ٿيون ، انهي جي نشاندهي ڪرڻ لاءِ ته نتيجو هميشه [`Ok`] هوندو.
///
/// مثال طور ، [`TryFrom`] trait (تبديلي جيڪو هڪ [`Result`] موٽائيندو آهي) هر قسم جي هڪ خالي ڪاري عمل آهي جتي ريورس [`Into`] عملدرآمد موجود آهي.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future مطابقت
///
/// هن اينيم جو اهو ساڳيو ڪردار آهي [the `!`“never”type][never] ، جيڪو Rust جي هن ورزن ۾ غير مستحڪم آهي.
/// جڏهن `!` تي مستحڪم ٿيو ، اسان منصوب ڪرڻ لاءِ `Infallible` هڪ قسم جي نالي ڪرڻ جي رٿابندي ڪئي آهي:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …۽ آخرڪار `Infallible` کي ختم ڪريو.
///
/// تنهن هوندي به هڪ ڪيس آهي جتي `!` نحو استعمال ٿي سگهي ٿو `!` کان اڳ مڪمل طور تي هڪ قسم جي طور تي مستحڪم ٿي ويندي آهي: فنڪشن جي واپسي جي قسم جي پوزيشن ۾.
/// خاص طور تي ، ٻن مختلف فنڪشن پوائنٽر جي قسمن لاءِ ممڪن عمل درآمد آهي.
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// `Infallible` وٽ هڪ ٿيڻ وارو آهي ، اهو ڪوڊ صحيح آهي.
/// تنهن هوندي جڏهن `Infallible` never type لاءِ عرف بڻجي ويندو آهي ، ٻئي `impl` اوورلوپ ٿيڻ شروع ٿي ويندا آهن ۽ تنهن ڪري زبان جي trait مربوط ضابطن کان روڪيو ويندو.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}