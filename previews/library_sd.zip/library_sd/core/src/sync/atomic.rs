//! ايٽمي قسمَ
//!
//! ايٽمي قسمون ڪنارن جي وچ ۾ ابتدائي حصيداري ۽ يادگيري مواصلات فراهم ڪن ٿيون ، ۽ ٻين گڏيل قسمن جا عمارت ساز بلاڪ آهن.
//!
//! هي ماڊل آدمشماري نسخن جي چونڊ قسم جي ابتدائي قسمن جي وضاحت ڪري ٿو ، جن ۾ [`AtomicBool`] ، [`AtomicIsize`] ، [`AtomicUsize`] ، [`AtomicI8`] ، [`AtomicU16`] ، وغيره.
//! ايٽمي قسمَ آپريشن ڪن ٿا جيڪي ، جڏهن صحيح نموني استعمال ڪيا وڃن ، اُنهن جي وچ ۾ تازه ڪاري هم وقت ڪن.
//!
//! هر طريقو [`Ordering`] وٺي ٿو جيڪو انهي آپريشن لاءِ ياداشت جي رڪاوٽ جي طاقت کي ظاهر ڪري ٿو.اهي ترتيب ساڳيا [C++20 atomic orderings][1] آهن.وڌيڪ معلومات لاءِ [nomicon][2] کي ڏسو.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! ايٽمي تغيرات ڌاڙن جي وچ ۾ حصيداري لاءِ محفوظ آهن (اهي [`Sync`] لاڳو ڪن ٿا) پر اهي پاڻ حصيداري لاءِ ميڪانيزم فراهم نٿا ڪن ۽ Rust جي [threading model](../../../std/thread/index.html#the-threading-model) جي پيروي ڪن.
//!
//! ايٽمي متغير حصيداري ڪرڻ جو سڀ کان عام طريقو اهو آهي ته ان کي [`Arc`][arc] (هڪ ايٽمي طور تي ريفرنس شمار ٿيل شيئر پوائنٽر) ۾ وجهو.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! ايٽمي قسم جامد متغير ۾ محفوظ ٿي سگهن ٿا ، ايڪسائزڪس وانگر مستقل ابتدائي استعمال ڪندڙ کي استعمال ڪندي ابتدائي طور تي.ايٽمي جامد گهڻو ڪري سست عالمي مرتبي جي لاءِ استعمال ڪيا ويندا آهن.
//!
//! # Portability
//!
//! ھن ماڊل ۾ سڀ ائٽمي قسم [lock-free] ٿيڻ جي ضمانت آھن جيڪڏھن دستياب ھجن.هن جو مطلب آهي ته اهي اندروني طور تي هڪ عالمي ميوٽيڪس حاصل نٿا ڪن.ائٽمي قسم ۽ آپريشن جي انتظار ۾ رهڻ جي ضمانت نه آهي.
//! هن جو مطلب اهو آهي ته ايڪس پيڪسڪس وانگر آپريشن هڪ موازنہ ۽ مٽ اپ لوپ سان لاڳو ٿي سگهي ٿو.
//!
//! ايٽمي آپريشن وڏي پيماني تي ايٽمي ميٽرن جي هدايت جي پرت تي لاڳو ٿي سگهي ٿو.مثال طور ڪجهه پليٽ فارم `AtomicI8` کي عمل ڪرڻ لاءِ 4 بائيٽ ائٽمڪ هدايتون استعمال ڪن ٿا.
//! ياد رکجو ته اهو حيوانيت ڪوڊ جي درستگي تي اثرانداز نه ٿيڻ گهرجي ، بس اهو ئي ڪجهه واقف ٿيڻو آهي.
//!
//! ھن ماڊل ۾ ائٽمي قسم تمام پليٽفارم تي دستياب ناھن ھوندا.هتي ايٽمي قسم تمام وڏي تعداد ۾ موجود آھن ، پر عام طور تي موجود موجود تي ڀروسو ڪري سگھجي ٿو.ڪجهه قابل استثنا آهن:
//!
//! * PowerPC ۽ MIPS پليٽ فارمز 32 بٽ پوائنٽرز وٽ `AtomicU64` يا `AtomicI64` قسم نه آهن.
//! * ARM پليٽ فارمز جهڙوڪ `armv5te` جيڪي Linux جي لاءِ نه آهن صرف `load` ۽ `store` آپريشن فراهم ڪن ٿيون ، ۽ (CAS) آپريشن جي موازنہ ۽ تبادلي جي معاونت نه ڪن ، جيئن `swap` ، `fetch_add` ، وغيره.
//! Linux تي اضافي طور تي ، اهي CAS آپريشن [operating system support] ذريعي لاڳو ڪيا ويا آهن ، جيڪو ڪارڪردگي جي سزا سان اچي سگهي ٿو.
//! * ARM صرف `thumbv6m` ۽ `store` آپريشنز کي مقصد سان پيش ڪن ٿيون ، ۽ موازنہ ڪن ۽ (CAS) آپريشنز کي مٽائڻ ، جهڙوڪ `swap` ، `fetch_add` ، وغيره.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! نوٽ ڪيو ته future پليٽ فارم شامل ڪيا ويندا جيڪي پڻ ڪجھ ائٽمي آپريشن جي مدد نٿا ڪن.وڌ کان وڌ پورٽبل ڪوڊ محتاط ٿي رکڻ چاهيندا ته ڪهڙا ائٽمي قسم استعمال ڪيا ويا.
//! `AtomicUsize` ۽ `AtomicIsize` عام طور تي سڀ کان وڌيڪ پورٽبل آهن ، پر ان جي باوجود اهي هر هنڌ دستياب ناهن.
//! حوالا جي لاءِ ، `std` لائبريري کي پوائنٽر-سائز ايٽمس جي ضرورت آهي ، جيتوڻيڪ `core` نٿو ٿئي.
//!
//! في الحال توهان کي ايٽومڪس سان ڪوڊ ۾ شروط سان مرتب ڪرڻ لاءِ `#[cfg(target_arch)]` بنيادي طور تي استعمال ڪرڻ جي ضرورت پوندي.هتي هڪ غير مستحڪم `#[cfg(target_has_atomic)]` پڻ آهي جيڪا future ۾ مستحڪم ٿي سگهي ٿي.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! هڪ سادي اسپن لاڪ:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // لاڪ کي ڇڏڻ لاءِ ٻيون سلسلي جو انتظار ڪريو
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! زنده موضوعن جو عالمي شمار رکو:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// هڪ بولين جو قسم ، جيڪو محفوظ طور تي ڏهن وارن جي وچ ۾ ورهائي سگهجي ٿو.
///
/// اهڙي قسم جي يادگيري نمائندگي هڪ ئي [`bool`] وانگر آهي.
///
/// **نوٽ**: هي قسم صرف پليٽ فارم تي دستياب آهي جيڪي ايڪس ايڪس ايڪس جو ائٽمي لوڊ ۽ اسٽورن کي سپورٽ ڪن ٿا.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` کي ايڪسچيڪس ايچرلڪس ٺاهي ٿو.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// AtomicBool لاءِ موڪل ناجائز طريقي سان لاڳو ڪئي وئي.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// هڪ خام پوائنٽر جو قسم جيڪو محفوظ طور تي موضوعن ۾ ورهائي سگهجي ٿو.
///
/// اهڙي قسم جي يادگيري نمائندگي هڪ ئي `*mut T` وانگر آهي.
///
/// **نوٽ**: هي قسم صرف پليٽفارم تي موجود آهي جيڪي ائٽمي لوڊ ۽ پوائنٽرز جي اسٽورن کي سپورٽ ڪندا آهن.
/// ان جي سائيز تي ٽارگيٽ پوائنٽر جي سائيز تي منحصر هوندو.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// هڪ نول `AtomicPtr<T>` ٺاهي ٿو.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// ايٽمي ياداشت جا حڪم
///
/// ميموري ترتيب آرٽيڪل ايٽمي آپريشن کي ميموري سان هم وقت سازي ڪري ٿو.
/// ان جي ڪمزور ترين [`Ordering::Relaxed`] ۾ ، صرف آپريشن جي سڌي ياد سان سڌو سنئون آهي.
/// ٻئي طرف ، [`Ordering::SeqCst`] آپريشنز جو اسٽور لوڊ ٻيون ٻين ياداشتن کي هم وقت سازي ڪندي جڏهن ته انهن سڀني عملن ۾ اهڙن عملن جي مجموعي ترتيب کي محفوظ ڪرڻ سان گڏوگڏ.
///
///
/// Rust جي ميموري آرڊرينڪس [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) آهن.
///
/// وڌيڪ معلومات لاءِ [nomicon] کي ڏسو.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// آرڊر ڏيڻ ۾ رڪاوٽون نه ، صرف ائٽومي آپريشن.
    ///
    /// C ++ 20 ۾ [`memory_order_relaxed`] سان ملندڙ آهي.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// جڏهن هڪ اسٽور سان گڏ ٺهيل ، سڀني پوئين عملن هن قيمت جي ايڪس آرڪس (يا وڌيڪ مضبوط) ترتيب ڏيڻ کان پهريان آرڊر ٿي ويون.
    ///
    /// خاص طور تي ، پويون لکڻيون سڀني موضوعن لاءِ ظاهر ٿينديون آهن جيڪي هن قيمت جي [`Acquire`] (يا مضبوط) لوڊ ڪن ٿيون.
    ///
    /// نوٽ ڪريو ته هي آرڊر استعمال ڪندي هڪ آپريشن لاءِ جيڪو لوڊ ۽ اسٽورن کي گڏ ڪري ٿو ايڪس ايڪس اين ايڪس لوڊ آپريشن جي ڪري ٿو.
    ///
    /// اهو آرڊر صرف انهن عملن لاءِ لاڳو آهي جيڪي اسٽور انجام ڏئي سگھن ٿا.
    ///
    /// C ++ 20 ۾ [`memory_order_release`] سان ملندڙ آهي.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// جڏهن لوڊ سان گڏ هجي ، جيڪڏهن لوڊ ٿيل قيمت ايڪس آرڪس (يا مضبوط) آرڊر سان اسٽور آپريشن سان لکجي وڃي ها ، ته پوءِ سڀ اسٽور بعد ۾ انهي دڪان بعد آرڊر ٿي ويا.
    /// خاص طور تي ، سڀ ايندڙ لوڊ اسٽور کان اڳ لکيا ڊيٽا ڏسندا.
    ///
    /// نوٽ ڪريو ته هي آرڊر استعمال ڪندي هڪ آپريشن لاءِ جيڪو وزن ۽ دڪانن کي گڏ ڪري ٿو ، ايڪس ايڪس اين ايڪس اسٽور آپريشن جي ڪري ٿو.
    ///
    /// اهو آرڊر صرف عملن لاءِ لاڳو آهي جيڪو لوڊ سر انجام ڏئي سگهي ٿو.
    ///
    /// C ++ 20 ۾ [`memory_order_acquire`] سان ملندڙ آهي.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// ڇا [`Acquire`] ۽ [`Release`] ٻنهي جا اثر گڏ آهن:
    /// لوڊين لاء اهو استعمال ڪري ٿو [`Acquire`] ترتيب ڏيڻ.اسٽورز لاءِ اهو [`Release`] ترتيب ڏيندو آهي.
    ///
    /// نوٽ ڪريو ته `compare_and_swap` جي صورت ۾ ، ممڪن آهي ته آپريشن ڪنهن به اسٽور کي انجام ڏيڻ ختم نه ٿي ڪري ۽ انهي ڪري اهو صرف [`Acquire`] ترتيب ڏيڻ وارو آهي.
    ///
    /// جيتوڻيڪ ، `AcqRel` ڪڏهن به [`Relaxed`] رسائي انجام نه ڏيندو.
    ///
    /// اهو حڪم صرف آپريشن لاءِ لاڳو آهي جيڪي ٻنهي لوڊ ۽ دڪان کي گڏ ڪن ٿا.
    ///
    /// C ++ 20 ۾ [`memory_order_acq_rel`] سان ملندڙ آهي.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// جهڙوڪ [`Acquire`]/[`Release ']/[`AcqRel`](ترتيب لاءِ ، اسٽور ، ۽ لوڊ وار اسٽور آپريشن لاءِ ، ترتيب سان) اضافي ضمانت سان ته سڀ سلسلا هڪ ئي ترتيب سان تمام تسلسل سان لاڳاپيل عملن کي ڏسن ٿا. .
    ///
    ///
    /// C ++ 20 ۾ [`memory_order_seq_cst`] سان ملندڙ آهي.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// هڪ [`AtomicBool`] `false` لاءِ شروعات ڪئي.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// هڪ نئون `AtomicBool` ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// قابل واپسي [`bool`] ڏانهن قابل تبديل حوالو ڏئي ٿو.
    ///
    /// اهو محفوظ آهي ڇاڪاڻ ته قابل تغير حوالو انهي جي ضمانت ڏي ٿو ته ٻيا به موضوع گڏيل ائٽمي ڊيٽا تائين رسائي نٿا رکن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // حفاظت: theير mutار جو حوالو منفرد ملڪيت جي ضمانت آهي.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// ايڪس `&mut bool` کي ايٽمي رسائي حاصل ڪريو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // حفاظت: قابل تغير حوالو منفرد ملڪيت جي ضمانت آهي ، ۽
        // `bool` ۽ `Self` ٻنهي جي ترتيب هڪ آهي.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// ايٽم کي کارائيندو آهي ۽ شامل ڪيل قيمت کي موٽائيندو آهي.
    ///
    /// اهو محفوظ آهي ڇاڪاڻ ته قيمت جي ذريعي `self` پاس ڪرڻ جي ضمانت آهي ته ٻيون به موضوعون ايٽمي ڊيٽا تائين رسائي نٿا ڪن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool کان قيمت لوڊ ڪري ٿي.
    ///
    /// `load` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.
    /// ممڪن قيمتون [`SeqCst`] ، [`Acquire`] ۽ [`Relaxed`] آهن.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `order` آهي [`Release`] يا [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // حفاظت: ڊيٽا جي ريسن کي ايٽمي رڪاوٽن ۽ خام جي ڪري روڪيو وڃي ٿو
        // پوائنٽر داخل ٿيو صحيح آھي ڇاڪاڻ ته اسان کي ھڪڙي حوالي سان ملي ويو آھي.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool ۾ قيمت اسٽور ڪري ٿو.
    ///
    /// `store` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.
    /// ممڪن قيمتون [`SeqCst`] ، [`Release`] ۽ [`Relaxed`] آهن.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `order` آهي [`Acquire`] يا [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // حفاظت: ڊيٽا جي ريسن کي ايٽمي رڪاوٽن ۽ خام جي ڪري روڪيو وڃي ٿو
        // پوائنٽر داخل ٿيو صحيح آھي ڇاڪاڻ ته اسان کي ھڪڙي حوالي سان ملي ويو آھي.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// bool ۾ قيمت محفوظ ڪري ٿو ، پوئين ويل قيمت موٽائي.
    ///
    /// `swap` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
    /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
    ///
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي `u8` تي ايٽمي آپريشن کي سپورٽ ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// قيمت کي [`bool`] ۾ ذخيرو ڪري ٿو جيڪڏهن موجوده ويليو `current` ويليو وانگر ساڳيو آهي.
    ///
    /// واپسي جي قيمت هميشه اڳوڻي قيمت آهي.جيڪڏهن اهو `current` جي برابر آهي ، ته قيمت نئين ٿي وئي.
    ///
    /// `compare_and_swap` پڻ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.
    /// نوٽ ڪريو ته [`AcqRel`] استعمال ڪرڻ دوران ، آپريشن به ناڪام ٿي سگھي ٿو ۽ تنهن ڪري صرف ايڪس01ڪس لوڊ ڪري سگھي ٿو ، پر ان ۾ `Release` اهم ناهن.
    /// جيڪڏهن استعمال ٿئي ٿي ته [`Acquire`] اسٽور کي هن حصي جو حصو بڻائي ٿو [`Relaxed`] جيڪڏهن اهو ٿئي ٿو ، ۽ استعمال ڪري [`Release`] لوڊ حصو [`Relaxed`] ٺاهي ٿو.
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي `u8` تي ايٽمي آپريشن کي سپورٽ ڪن ٿا.
    ///
    /// # `compare_exchange` ۽ `compare_exchange_weak` ڏانهن لڏپلاڻ
    ///
    /// `compare_and_swap` ميموري آرڊرينس لاءِ هيٺين نقشي سان `compare_exchange` جي برابر آهي.
    ///
    /// اصلي |ڪاميابي |ناڪامي
    /// -------- | ------- | -------
    /// آرام وارو. |آرام وارو. |آرام سان حاصل ڪندڙ |حاصل ڪيو |حاصل ڪيل رسيد |ڇڏڻ |آرام سان ايڪريلر |ايڪو آريل |حاصل ڪيو SeqCst |SeqCst |ايس اي سي سي ايس
    ///
    /// `compare_exchange_weak` جڏهن مقابلو ڪامياب ٿي ويندو آهي ، ته هو خرابي سان ناڪام ٿيڻ جي اجازت ڏني ويندي آهي ، جيڪا کمپائلر کي بهتر اسيمبلي جو ڪوڊ ٺاهڻ جي اجازت ڏي ٿي جڏهن ته مقابلو ۽ تبادلو هڪ لوپ ۾ استعمال ٿئي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// قيمت کي [`bool`] ۾ ذخيرو ڪري ٿو جيڪڏهن موجوده ويليو `current` ويليو وانگر ساڳيو آهي.
    ///
    /// واپسي جي قيمت هڪ نتيجو آهي ظاهر ڪري ٿو ته نئين قيمت لکي وئي هئي ۽ اڳوڻي ويليو شامل آهي.
    /// ڪاميابي تي اهو قدر `current` جي برابر جي ضمانت آهي.
    ///
    /// `compare_exchange` هن آپريشن جي ميموري ترتيب کي بيان ڪرڻ لاءِ ٻه [`Ordering`] دليل وٺن ٿا.
    /// `success` انهي پڙهڻ جي ترميم-لکڻ لاءِ آپريشن جي گهربل ترتيب بيان ڪري ٿي جيڪا `current` سان مقابلو ڪامياب ٿي وڃي.
    /// `failure` لوڊ آپريشن جي گھربل آرڊر بندي جي وضاحت ڪري ٿو جڏھن مقابلو ناڪامياب ٿيندو آھي.
    /// ڪامياب آرڊر جي طور تي [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] ڪامياب لوڊ [`Relaxed`] ٺاهي ٿو.
    ///
    /// ناڪامي وارو حڪم رڳو [`SeqCst`] ، [`Acquire`] يا [`Relaxed`] ٿي سگهي ٿو ۽ ڪاميٽي آرڊرنگ جي برابر يا ضعيف هجڻ لازمي آهي.
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي `u8` تي ايٽمي آپريشن کي سپورٽ ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// قيمت کي [`bool`] ۾ ذخيرو ڪري ٿو جيڪڏهن موجوده ويليو `current` ويليو وانگر ساڳيو آهي.
    ///
    /// [`AtomicBool::compare_exchange`] جي برعڪس ، انهي فنڪشن کي ناجائز طور تي ناڪام ٿيڻ جي اجازت آهي جڏهن ته مقابلو ڪامياب ٿي وڃي ، جنهن جي نتيجي ۾ ڪجهه پليٽفارم تي وڌيڪ ڪارائتو ڪوڊ ٿي سگھي ٿو.
    ///
    /// واپسي جي قيمت هڪ نتيجو آهي ظاهر ڪري ٿو ته نئين قيمت لکي وئي هئي ۽ اڳوڻي ويليو شامل آهي.
    ///
    /// `compare_exchange_weak` هن آپريشن جي ميموري ترتيب کي بيان ڪرڻ لاءِ ٻه [`Ordering`] دليل وٺن ٿا.
    /// `success` انهي پڙهڻ جي ترميم-لکڻ لاءِ آپريشن جي گهربل ترتيب بيان ڪري ٿي جيڪا `current` سان مقابلو ڪامياب ٿي وڃي.
    /// `failure` لوڊ آپريشن جي گھربل آرڊر بندي جي وضاحت ڪري ٿو جڏھن مقابلو ناڪامياب ٿيندو آھي.
    /// ڪامياب آرڊر جي طور تي [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] ڪامياب لوڊ [`Relaxed`] ٺاهي ٿو.
    /// ناڪامي وارو حڪم رڳو [`SeqCst`] ، [`Acquire`] يا [`Relaxed`] ٿي سگهي ٿو ۽ ڪاميٽي آرڊرنگ جي برابر يا ضعيف هجڻ لازمي آهي.
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي `u8` تي ايٽمي آپريشن کي سپورٽ ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// بولين قيمت سان منطقي "and".
    ///
    /// موجوده ويليو ۽ دليل `val` تي منطقي "and" آپريشن انجام ڏئي ٿو ، ۽ نتيجو کي نئين قيمت مقرر ڪري ٿو.
    ///
    /// پوئين ويليو ڏيکاري ٿو.
    ///
    /// `fetch_and` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
    /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
    ///
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي `u8` تي ايٽمي آپريشن کي سپورٽ ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// بولين قيمت سان منطقي "nand".
    ///
    /// موجوده ويليو ۽ دليل `val` تي منطقي "nand" آپريشن انجام ڏئي ٿو ، ۽ نتيجو کي نئين قيمت مقرر ڪري ٿو.
    ///
    /// پوئين ويليو ڏيکاري ٿو.
    ///
    /// `fetch_nand` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
    /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
    ///
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي `u8` تي ايٽمي آپريشن کي سپورٽ ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // atomic_nand اسان هتي استعمال نٿا ڪري سگھو ڇاڪاڻ ته اهو هڪ غلط قدر سان bool جو نتيجو آڻي سگهي ٿو.
        // اهو ٿئي ٿو ڇاڪاڻ ته ائٽمڪ ڪم هڪ اندر 8 بٽ انٽيگر سان ڪيو وڃي ٿو ، جيڪو مٿئين 7 بٽ کي سيٽ ڪندو.
        //
        // تنهنڪري اسان صرف فچڪس_ xor استعمال ڪريون ٿا يا بدران.
        if val {
            // ! (x ۽ سچو)== !x اسان کي bool کي تبديل ڪرڻ گھرجي.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==سچو اسان کي bool کي سچو لڳائڻ گھرجي.
            //
            self.swap(true, order)
        }
    }

    /// بولين قيمت سان منطقي "or".
    ///
    /// موجوده ويليو ۽ دليل `val` تي منطقي "or" آپريشن انجام ڏئي ٿو ، ۽ نتيجو کي نئين قيمت مقرر ڪري ٿو.
    ///
    /// پوئين ويليو ڏيکاري ٿو.
    ///
    /// `fetch_or` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
    /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
    ///
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي `u8` تي ايٽمي آپريشن کي سپورٽ ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// بولين قيمت سان منطقي "xor".
    ///
    /// موجوده ويليو ۽ دليل `val` تي منطقي "xor" آپريشن انجام ڏئي ٿو ، ۽ نتيجو کي نئين قيمت مقرر ڪري ٿو.
    ///
    /// پوئين ويليو ڏيکاري ٿو.
    ///
    /// `fetch_xor` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
    /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
    ///
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي `u8` تي ايٽمي آپريشن کي سپورٽ ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// ھڪڙي قابل تبديل ٿيل پوائنٽر کي ھيٺ ڏنل [`bool`] ڏانھن موٽائي ٿو.
    ///
    /// غير ائٽمي ڪرڻ پڙهڻ ۽ نتيجو ڪندڙ انٽيگر تي لکڻ هڪ ڊيٽا جي نسل ٿي سگهي ٿي.
    /// اهو طريقو اڪثر ڪري ايف ايف آءِ لاءِ فائديمند آهي ، جتي فنڪشن وارو دستخط `*mut bool` جي بدران `* mut bool` استعمال ڪري سگهي ٿو.
    ///
    /// هن ائٽومي کي شيئرڊ ريفرنس مان `*mut` پوائنٽر واپس ڪرڻ محفوظ آهي ڇاڪاڻ ته ائٽمي قسمَ اندرين مطابقت سان ڪم ڪن ٿا.
    /// ائٽمي جا سڀ ترميمي ويلڊٽ ريفرنس ذريعي قدر تبديل ڪن ٿا ، ۽ ايستائين محفوظ طور تي ڪري سگھن ٿا جيستائين اهي ايٽمي آپريشن ڪن.
    /// واپس ٿيل خام پوائنٽر جو ڪو به استعمال ايڪس سي ايم ايڪس بلاڪ جي ضرورت آهي ۽ اڃا به ساڳئي رڪاوٽ کي برقرار رکڻ آهي: انهي تي آپريشن لازمي طور تي ائٽمي هجڻ گهرجي.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// قيمت کي ڇڪي ٿو ، ۽ انهي تي هڪ فنڪشن لاڳو ڪري ٿو جيڪو هڪ اختياري نئين قيمت موٽائي ٿو.ھڪڙي فنڪشن `Ok(previous_value)` جو `Ok(previous_value)` واپس ڪري ٿو جيڪڏھن فنڪشن `Some(_)` موٽيو ، ٻي صورت ۾ `Err(previous_value)`.
    ///
    /// Note: اهو شايد ڪال ڪيترائي ڀيرا سڏ ڪندو جيڪڏهن ٻي صورت ۾ قدر تبديل ٿي وئي آهي ، جيستائين اهو فنڪشن `Some(_)` موٽائي ٿو ، پر اها فنڪشن صرف هڪ ڀيرو محفوظ ٿيل قدر تي لاڳو ٿئي ٿي.
    ///
    ///
    /// `fetch_update` هن آپريشن جي ميموري ترتيب کي بيان ڪرڻ لاءِ ٻه [`Ordering`] دليل وٺن ٿا.
    /// پهريون گهربل آرڊر لاءِ بيان ڪندو آهي جڏهن آپريشن آخر ڪامياب ٿي ويندو جڏهن ته ٻيو لوڊ جي گهربل ترتيب بيان ڪندو.
    /// ھي ترتيب ڏنل [`AtomicBool::compare_exchange`] جي ڪاميابي ۽ ناڪاميءَ جو ترتيب ڏين ٿيون.
    ///
    /// ڪامياب آرڊر جي طور تي [`Acquire`] استعمال ڪندي دڪان کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] آخري ڪامياب لوڊ [`Relaxed`] ٺاهي ٿو.
    /// (failed) لوڊ آرڊرنگ صرف [`SeqCst`] ، [`Acquire`] يا [`Relaxed`] ٿي سگھي ٿو ۽ ڪاميٽي آرڊرنگ جي برابر يا گھٽ ھجڻ گھرجي.
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي `u8` تي ايٽمي آپريشن کي سپورٽ ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// هڪ نئون `AtomicPtr` ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// ھيٺئين پوائنٽر جي حوالي سان ھڪ قابل تبديلي واپسي واپس ڪندو آھي.
    ///
    /// اهو محفوظ آهي ڇاڪاڻ ته قابل تغير حوالو انهي جي ضمانت ڏي ٿو ته ٻيا به موضوع گڏيل ائٽمي ڊيٽا تائين رسائي نٿا رکن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// ھڪڙي پوائنٽر تائين ايٽمي رسائي حاصل ڪريو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - مٽائڻ وارو حوالو منفرد ملڪيت جي ضمانت آهي.
        //  - `*mut T` ۽ `Self` جي ترتيب سڀني پليٽ فارمن تي ھڪڙي آھي rust پاران ، جيئن مٿي ڏنل تصديق ٿيل آھي.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// ايٽم کي کارائيندو آهي ۽ شامل ڪيل قيمت کي موٽائيندو آهي.
    ///
    /// اهو محفوظ آهي ڇاڪاڻ ته قيمت جي ذريعي `self` پاس ڪرڻ جي ضمانت آهي ته ٻيون به موضوعون ايٽمي ڊيٽا تائين رسائي نٿا ڪن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// پوائنٽر مان ويليو لوڊ ڪري ٿو.
    ///
    /// `load` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.
    /// ممڪن قيمتون [`SeqCst`] ، [`Acquire`] ۽ [`Relaxed`] آهن.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `order` آهي [`Release`] يا [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// پوائنٽر ۾ قيمت ڳاناپو.
    ///
    /// `store` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.
    /// ممڪن قيمتون [`SeqCst`] ، [`Release`] ۽ [`Relaxed`] آهن.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `order` آهي [`Acquire`] يا [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// پوائنٽر کي ھڪ قدر اسٽور ڪري ٿو ، پوئين ويل قيمت واپس.
    ///
    /// `swap` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
    /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
    ///
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي پوائنٽرن تي ايٽمي آپريشن جي حمايت ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// پوائنٽر کي ھڪ قدر اسٽور ڪندو آھي جيڪڏھن موجوده ويليو `current` جي قيمت جيتري آھي.
    ///
    /// واپسي جي قيمت هميشه اڳوڻي قيمت آهي.جيڪڏهن اهو `current` جي برابر آهي ، ته قيمت نئين ٿي وئي.
    ///
    /// `compare_and_swap` پڻ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.
    /// نوٽ ڪريو ته [`AcqRel`] استعمال ڪرڻ دوران ، آپريشن به ناڪام ٿي سگھي ٿو ۽ تنهن ڪري صرف ايڪس01ڪس لوڊ ڪري سگھي ٿو ، پر ان ۾ `Release` اهم ناهن.
    /// جيڪڏهن استعمال ٿئي ٿي ته [`Acquire`] اسٽور کي هن حصي جو حصو بڻائي ٿو [`Relaxed`] جيڪڏهن اهو ٿئي ٿو ، ۽ استعمال ڪري [`Release`] لوڊ حصو [`Relaxed`] ٺاهي ٿو.
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي پوائنٽرن تي ايٽمي آپريشن جي حمايت ڪن ٿا.
    ///
    /// # `compare_exchange` ۽ `compare_exchange_weak` ڏانهن لڏپلاڻ
    ///
    /// `compare_and_swap` ميموري آرڊرينس لاءِ هيٺين نقشي سان `compare_exchange` جي برابر آهي.
    ///
    /// اصلي |ڪاميابي |ناڪامي
    /// -------- | ------- | -------
    /// آرام وارو. |آرام وارو. |آرام سان حاصل ڪندڙ |حاصل ڪيو |حاصل ڪيل رسيد |ڇڏڻ |آرام سان ايڪريلر |ايڪو آريل |حاصل ڪيو SeqCst |SeqCst |ايس اي سي سي ايس
    ///
    /// `compare_exchange_weak` جڏهن مقابلو ڪامياب ٿي ويندو آهي ، ته هو خرابي سان ناڪام ٿيڻ جي اجازت ڏني ويندي آهي ، جيڪا کمپائلر کي بهتر اسيمبلي جو ڪوڊ ٺاهڻ جي اجازت ڏي ٿي جڏهن ته مقابلو ۽ تبادلو هڪ لوپ ۾ استعمال ٿئي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// پوائنٽر کي ھڪ قدر اسٽور ڪندو آھي جيڪڏھن موجوده ويليو `current` جي قيمت جيتري آھي.
    ///
    /// واپسي جي قيمت هڪ نتيجو آهي ظاهر ڪري ٿو ته نئين قيمت لکي وئي هئي ۽ اڳوڻي ويليو شامل آهي.
    /// ڪاميابي تي اهو قدر `current` جي برابر جي ضمانت آهي.
    ///
    /// `compare_exchange` هن آپريشن جي ميموري ترتيب کي بيان ڪرڻ لاءِ ٻه [`Ordering`] دليل وٺن ٿا.
    /// `success` انهي پڙهڻ جي ترميم-لکڻ لاءِ آپريشن جي گهربل ترتيب بيان ڪري ٿي جيڪا `current` سان مقابلو ڪامياب ٿي وڃي.
    /// `failure` لوڊ آپريشن جي گھربل آرڊر بندي جي وضاحت ڪري ٿو جڏھن مقابلو ناڪامياب ٿيندو آھي.
    /// ڪامياب آرڊر جي طور تي [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] ڪامياب لوڊ [`Relaxed`] ٺاهي ٿو.
    ///
    /// ناڪامي وارو حڪم رڳو [`SeqCst`] ، [`Acquire`] يا [`Relaxed`] ٿي سگهي ٿو ۽ ڪاميٽي آرڊرنگ جي برابر يا ضعيف هجڻ لازمي آهي.
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي پوائنٽرن تي ايٽمي آپريشن جي حمايت ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// پوائنٽر کي ھڪ قدر اسٽور ڪندو آھي جيڪڏھن موجوده ويليو `current` جي قيمت جيتري آھي.
    ///
    /// [`AtomicPtr::compare_exchange`] جي برعڪس ، انهي فنڪشن کي ناجائز طور تي ناڪام ٿيڻ جي اجازت آهي جڏهن ته مقابلو ڪامياب ٿي وڃي ، جنهن جي نتيجي ۾ ڪجهه پليٽفارم تي وڌيڪ ڪارائتو ڪوڊ ٿي سگھي ٿو.
    ///
    /// واپسي جي قيمت هڪ نتيجو آهي ظاهر ڪري ٿو ته نئين قيمت لکي وئي هئي ۽ اڳوڻي ويليو شامل آهي.
    ///
    /// `compare_exchange_weak` هن آپريشن جي ميموري ترتيب کي بيان ڪرڻ لاءِ ٻه [`Ordering`] دليل وٺن ٿا.
    /// `success` انهي پڙهڻ جي ترميم-لکڻ لاءِ آپريشن جي گهربل ترتيب بيان ڪري ٿي جيڪا `current` سان مقابلو ڪامياب ٿي وڃي.
    /// `failure` لوڊ آپريشن جي گھربل آرڊر بندي جي وضاحت ڪري ٿو جڏھن مقابلو ناڪامياب ٿيندو آھي.
    /// ڪامياب آرڊر جي طور تي [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] ڪامياب لوڊ [`Relaxed`] ٺاهي ٿو.
    /// ناڪامي وارو حڪم رڳو [`SeqCst`] ، [`Acquire`] يا [`Relaxed`] ٿي سگهي ٿو ۽ ڪاميٽي آرڊرنگ جي برابر يا ضعيف هجڻ لازمي آهي.
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي پوائنٽرن تي ايٽمي آپريشن جي حمايت ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // حفاظت: اهو اندروني غير محفوظ آهي ڇاڪاڻ ته اهو خام پوائنٽر تي هلندو آهي
        // پر اسان کي پڪ سان knowاڻون ٿا ته پوائنٽر صحيح آهي (اسان اهو صرف `UnsafeCell` وٽان حاصل ڪيو آهي جيڪو اسان وٽ حوالو آهي) ۽ ائٽمي آپريشن خود اسان کي `UnsafeCell` مواد کي محفوظ طور تي خاموش ڪرڻ جي اجازت ڏئي ٿو.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// قيمت کي ڇڪي ٿو ، ۽ انهي تي هڪ فنڪشن لاڳو ڪري ٿو جيڪو هڪ اختياري نئين قيمت موٽائي ٿو.ھڪڙي فنڪشن `Ok(previous_value)` جو `Ok(previous_value)` واپس ڪري ٿو جيڪڏھن فنڪشن `Some(_)` موٽيو ، ٻي صورت ۾ `Err(previous_value)`.
    ///
    /// Note: اهو شايد ڪال ڪيترائي ڀيرا سڏ ڪندو جيڪڏهن ٻي صورت ۾ قدر تبديل ٿي وئي آهي ، جيستائين اهو فنڪشن `Some(_)` موٽائي ٿو ، پر اها فنڪشن صرف هڪ ڀيرو محفوظ ٿيل قدر تي لاڳو ٿئي ٿي.
    ///
    ///
    /// `fetch_update` هن آپريشن جي ميموري ترتيب کي بيان ڪرڻ لاءِ ٻه [`Ordering`] دليل وٺن ٿا.
    /// پهريون گهربل آرڊر لاءِ بيان ڪندو آهي جڏهن آپريشن آخر ڪامياب ٿي ويندو جڏهن ته ٻيو لوڊ جي گهربل ترتيب بيان ڪندو.
    /// ھي ترتيب ڏنل [`AtomicPtr::compare_exchange`] جي ڪاميابي ۽ ناڪاميءَ جو ترتيب ڏين ٿيون.
    ///
    /// ڪامياب آرڊر جي طور تي [`Acquire`] استعمال ڪندي دڪان کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] آخري ڪامياب لوڊ [`Relaxed`] ٺاهي ٿو.
    /// (failed) لوڊ آرڊرنگ صرف [`SeqCst`] ، [`Acquire`] يا [`Relaxed`] ٿي سگھي ٿو ۽ ڪاميٽي آرڊرنگ جي برابر يا گھٽ ھجڻ گھرجي.
    ///
    /// **Note:** اهو طريقو صرف پليٽ فارم تي موجود آهي جيڪي پوائنٽرن تي ايٽمي آپريشن جي حمايت ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// هڪ `bool` هڪ `AtomicBool` ۾ بدلائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // اهو ميڪرو ڪجهه اڏاوتن تي غير استعمال ٿيڻ سان ختم ٿي ويو.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// انٽيگر قسم جنهن کي محفوظ طور تي موضوعن جي وچ ۾ ورهائي سگهجي ٿو.
        ///
        /// هن قسم ۾ ياداشت جي نمائندگي ساڳي ئي هوندي آهي جيتري هيٺئين انٽيگر جي قسم
        ///
        #[doc = $s_int_type]
        /// `].
        /// ايٽمي قسمن ۽ غير ائٽمي قسمن جي فرق بابت وڌيڪ asاڻ لاءِ پڻ هن قسم جي پورٽيبلگي بابت ،اڻ لاءِ مهرباني ڪري ايڪس اين ايڪس ڏسو.
        ///
        ///
        /// **Note:** اهو قسم صرف پليٽ فارم تي دستياب آهي جيڪي ائٽمي لوڊ ۽ اسٽورن کي اسٽور ڪنديون آهن [
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// ھڪڙي ايڪسٽورڪ انٽيگريٽر `0` ڏانھن شروع ڪيو.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // موڪل اڻ سڌي طرح لاڳو ٿي چڪي آهي.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// هڪ نئون ائٽومڪ انٽيگر ٺاهيا.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// واپسي واري انڌيري جي حوالي سان aيرableار وارو حوالو ڏئي ٿو.
            ///
            /// اهو محفوظ آهي ڇاڪاڻ ته قابل تغير حوالو انهي جي ضمانت ڏي ٿو ته ٻيا به موضوع گڏيل ائٽمي ڊيٽا تائين رسائي نٿا رکن.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5 ؛
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// ڪجهه_int=123 ڏيو
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (ڪجهه_int ، 100) ؛
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - مٽائڻ وارو حوالو منفرد ملڪيت جي ضمانت آهي.
                //  - `$int_type` ۽ `Self` جي ترتيب ساڳيو آھي ، جئين $cfg_align پاران واعدو ڪيو ويو آھي ۽ مٿي ifiedاڻايل آھي.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// ايٽم کي کارائيندو آهي ۽ شامل ڪيل قيمت کي موٽائيندو آهي.
            ///
            /// اهو محفوظ آهي ڇاڪاڻ ته قيمت جي ذريعي `self` پاس ڪرڻ جي ضمانت آهي ته ٻيون به موضوعون ايٽمي ڊيٽا تائين رسائي نٿا ڪن.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// ائٽمڪ انوگر مان هڪ قدر لوڊ ڪري ٿو.
            ///
            /// `load` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.
            /// ممڪن قيمتون [`SeqCst`] ، [`Acquire`] ۽ [`Relaxed`] آهن.
            ///
            /// # Panics
            ///
            /// Panics جيڪڏهن `order` آهي [`Release`] يا [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// ائٽمڪ انڌيري ۾ هڪ قدر جمع ڪري ٿو.
            ///
            /// `store` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.
            ///  ممڪن قيمتون [`SeqCst`] ، [`Release`] ۽ [`Relaxed`] آهن.
            ///
            /// # Panics
            ///
            /// Panics جيڪڏهن `order` آهي [`Acquire`] يا [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// ائٽمڪ انٽيگر ۾ قيمت جمع ڪري ٿو ، اڳوڻي ويليو موٽائي ٿو.
            ///
            /// `swap` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
            /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
            ///
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// ائٽمڪ انٽيگر ۾ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو ايڪس اين ايڪس ايڪس واري قيمت جي ساڳي آهي.
            ///
            /// واپسي جي قيمت هميشه اڳوڻي قيمت آهي.جيڪڏهن اهو `current` جي برابر آهي ، ته قيمت نئين ٿي وئي.
            ///
            /// `compare_and_swap` پڻ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.
            /// نوٽ ڪريو ته [`AcqRel`] استعمال ڪرڻ دوران ، آپريشن به ناڪام ٿي سگھي ٿو ۽ تنهن ڪري صرف ايڪس01ڪس لوڊ ڪري سگھي ٿو ، پر ان ۾ `Release` اهم ناهن.
            ///
            /// جيڪڏهن استعمال ٿئي ٿي ته [`Acquire`] اسٽور کي هن حصي جو حصو بڻائي ٿو [`Relaxed`] جيڪڏهن اهو ٿئي ٿو ، ۽ استعمال ڪري [`Release`] لوڊ حصو [`Relaxed`] ٺاهي ٿو.
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` ۽ `compare_exchange_weak` ڏانهن لڏپلاڻ
            ///
            /// `compare_and_swap` ميموري آرڊرينس لاءِ هيٺين نقشي سان `compare_exchange` جي برابر آهي.
            ///
            /// اصلي |ڪاميابي |ناڪامي
            /// -------- | ------- | -------
            /// آرام وارو. |آرام وارو. |آرام سان حاصل ڪندڙ |حاصل ڪيو |حاصل ڪيل رسيد |ڇڏڻ |آرام سان ايڪريلر |ايڪو آريل |حاصل ڪيو SeqCst |SeqCst |ايس اي سي سي ايس
            ///
            /// `compare_exchange_weak` جڏهن مقابلو ڪامياب ٿي ويندو آهي ، ته هو خرابي سان ناڪام ٿيڻ جي اجازت ڏني ويندي آهي ، جيڪا کمپائلر کي بهتر اسيمبلي جو ڪوڊ ٺاهڻ جي اجازت ڏي ٿي جڏهن ته مقابلو ۽ تبادلو هڪ لوپ ۾ استعمال ٿئي ٿو.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// ائٽمڪ انٽيگر ۾ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو ايڪس اين ايڪس ايڪس واري قيمت جي ساڳي آهي.
            ///
            /// واپسي جي قيمت هڪ نتيجو آهي ظاهر ڪري ٿو ته نئين قيمت لکي وئي هئي ۽ اڳوڻي ويليو شامل آهي.
            /// ڪاميابي تي اهو قدر `current` جي برابر جي ضمانت آهي.
            ///
            /// `compare_exchange` هن آپريشن جي ميموري ترتيب کي بيان ڪرڻ لاءِ ٻه [`Ordering`] دليل وٺن ٿا.
            /// `success` انهي پڙهڻ جي ترميم-لکڻ لاءِ آپريشن جي گهربل ترتيب بيان ڪري ٿي جيڪا `current` سان مقابلو ڪامياب ٿي وڃي.
            /// `failure` لوڊ آپريشن جي گھربل آرڊر بندي جي وضاحت ڪري ٿو جڏھن مقابلو ناڪامياب ٿيندو آھي.
            /// ڪامياب آرڊر جي طور تي [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] ڪامياب لوڊ [`Relaxed`] ٺاهي ٿو.
            ///
            /// ناڪامي وارو حڪم رڳو [`SeqCst`] ، [`Acquire`] يا [`Relaxed`] ٿي سگهي ٿو ۽ ڪاميٽي آرڊرنگ جي برابر يا ضعيف هجڻ لازمي آهي.
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// ائٽمڪ انٽيگر ۾ قيمت کي اسٽور ڪري ٿو جيڪڏهن موجوده ويليو ايڪس اين ايڪس ايڪس واري قيمت جي ساڳي آهي.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// انهي فنڪشن کي ناجائز طريقي سان ناڪام ٿيڻ جي اجازت آهي جڏهن ته مقابلو ڪامياب ٿي وڃي ٿو ، جنهن جي نتيجي ۾ ڪجهه پليٽ فارمن تي وڌيڪ موثر ڪوڊ ملي سگهن ٿا.
            /// واپسي جي قيمت هڪ نتيجو آهي ظاهر ڪري ٿو ته نئين قيمت لکي وئي هئي ۽ اڳوڻي ويليو شامل آهي.
            ///
            /// `compare_exchange_weak` هن آپريشن جي ميموري ترتيب کي بيان ڪرڻ لاءِ ٻه [`Ordering`] دليل وٺن ٿا.
            /// `success` انهي پڙهڻ جي ترميم-لکڻ لاءِ آپريشن جي گهربل ترتيب بيان ڪري ٿي جيڪا `current` سان مقابلو ڪامياب ٿي وڃي.
            /// `failure` لوڊ آپريشن جي گھربل آرڊر بندي جي وضاحت ڪري ٿو جڏھن مقابلو ناڪامياب ٿيندو آھي.
            /// ڪامياب آرڊر جي طور تي [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] ڪامياب لوڊ [`Relaxed`] ٺاهي ٿو.
            ///
            /// ناڪامي وارو حڪم رڳو [`SeqCst`] ، [`Acquire`] يا [`Relaxed`] ٿي سگهي ٿو ۽ ڪاميٽي آرڊرنگ جي برابر يا ضعيف هجڻ لازمي آهي.
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// مٽ پراڻي= val.load(Ordering::Relaxed) ؛
            /// لوپ {نئين اچڻ=پراڻي * 2 ؛
            ///     ڀيٽيو val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// موجوده ويليو ۾ شامل ڪريو ، اڳوڻي ويليو واپس ڪندي.
            ///
            /// هي آپريشن ڀرپاسي جي ڀرپاسي ڪري ٿو.
            ///
            /// `fetch_add` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
            /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
            ///
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// ڪٽيل ويلس کي ڪٽجي ٿو ، پوئين ويل قيمت موٽائي.
            ///
            /// هي آپريشن ڀرپاسي جي ڀرپاسي ڪري ٿو.
            ///
            /// `fetch_sub` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
            /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
            ///
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// موجوده ويليو سان بيٽ ويڪس "and".
            ///
            /// موجوده ويليو ۽ دليل `val` تي ٻٽي وار "and" آپريشن سرانجام ڏئي ٿو ، ۽ نتيجو کي نئين ويليو کي ترتيب ڏئي ٿو.
            ///
            /// پوئين ويليو ڏيکاري ٿو.
            ///
            /// `fetch_and` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
            /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
            ///
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// موجوده ويليو سان بيٽ ويڪس "nand".
            ///
            /// موجوده ويليو ۽ دليل `val` تي ٻٽي وار "nand" آپريشن سرانجام ڏئي ٿو ، ۽ نتيجو کي نئين ويليو کي ترتيب ڏئي ٿو.
            ///
            /// پوئين ويليو ڏيکاري ٿو.
            ///
            /// `fetch_nand` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
            /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
            ///
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13 ۽ 0x31)) ؛
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// موجوده ويليو سان بيٽ ويڪس "or".
            ///
            /// موجوده ويليو ۽ دليل `val` تي ٻٽي وار "or" آپريشن سرانجام ڏئي ٿو ، ۽ نتيجو کي نئين ويليو کي ترتيب ڏئي ٿو.
            ///
            /// پوئين ويليو ڏيکاري ٿو.
            ///
            /// `fetch_or` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
            /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
            ///
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// موجوده ويليو سان بيٽ ويڪس "xor".
            ///
            /// موجوده ويليو ۽ دليل `val` تي ٻٽي وار "xor" آپريشن سرانجام ڏئي ٿو ، ۽ نتيجو کي نئين ويليو کي ترتيب ڏئي ٿو.
            ///
            /// پوئين ويليو ڏيکاري ٿو.
            ///
            /// `fetch_xor` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
            /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
            ///
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// قيمت کي ڇڪي ٿو ، ۽ انهي تي هڪ فنڪشن لاڳو ڪري ٿو جيڪو هڪ اختياري نئين قيمت موٽائي ٿو.ھڪڙي فنڪشن `Ok(previous_value)` جو `Ok(previous_value)` واپس ڪري ٿو جيڪڏھن فنڪشن `Some(_)` موٽيو ، ٻي صورت ۾ `Err(previous_value)`.
            ///
            /// Note: اهو شايد ڪال ڪيترائي ڀيرا سڏ ڪندو جيڪڏهن ٻي صورت ۾ قدر تبديل ٿي وئي آهي ، جيستائين اهو فنڪشن `Some(_)` موٽائي ٿو ، پر اها فنڪشن صرف هڪ ڀيرو محفوظ ٿيل قدر تي لاڳو ٿئي ٿي.
            ///
            ///
            /// `fetch_update` هن آپريشن جي ميموري ترتيب کي بيان ڪرڻ لاءِ ٻه [`Ordering`] دليل وٺن ٿا.
            /// پهريون گهربل گهربل بيان ڪري ٿو جڏهن آپريشن آخرڪار ڪامياب ٿي وڃي ٿو جڏهن ته ٻيو لوڊ جي گهربل ترتيب بيان ڪري ٿو.اھي ڪاميابيءَ ۽ ناڪاميءَ جي ترتيب سان ترتيب ڏين ٿيون
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// ڪامياب آرڊر جي طور تي [`Acquire`] استعمال ڪندي دڪان کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] آخري ڪامياب لوڊ [`Relaxed`] ٺاهي ٿو.
            /// (failed) لوڊ آرڊرنگ صرف [`SeqCst`] ، [`Acquire`] يا [`Relaxed`] ٿي سگھي ٿو ۽ ڪاميٽي آرڊرنگ جي برابر يا گھٽ ھجڻ گھرجي.
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (ترتيب ڏيڻ: : SeqCst ، Ordering::SeqCst ، | x | Some(x + 1)) ، Ok(7));
            /// assert_eq! (x.fetch_update (ترتيب ڏيڻ: : SeqCst ، Ordering::SeqCst ، | x | Some(x + 1)) ، Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// وڌ کان وڌ موجوده ويليو سان.
            ///
            /// وڌ کان وڌ موجوده قيمت ۽ دليل `val` ڳولي ٿو ، ۽ نتيجو کي نئين قيمت مقرر ڪري ٿو.
            ///
            /// پوئين ويليو ڏيکاري ٿو.
            ///
            /// `fetch_max` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
            /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
            ///
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// بار=42 ؛
            /// max_foo=foo.fetch_max ڏيو (بار ، Ordering::SeqCst).max(bar);
            /// زور ڀريو! (max_foo==42) ؛
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// گھٽ ۾ گھٽ موجوده قيمت سان.
            ///
            /// موجوده ويليو جي گھٽ ۾ گھٽ گولي ۽ دليل `val` ، ۽ نتيجو کي نئين قيمت ڏي ٿو.
            ///
            /// پوئين ويليو ڏيکاري ٿو.
            ///
            /// `fetch_min` هڪ [`Ordering`] دليل وٺندو آهي جيڪو هن آپريشن جي يادگيري ترتيب کي بيان ڪري ٿو.ترتيب ڏيڻ جا سمورا طريقا ممڪن آهن.
            /// نوٽ ڪريو ته [`Acquire`] استعمال ڪندي اسٽور کي هن آپريشن جو حصو بڻائي ٿو [`Relaxed`] ، ۽ استعمال ڪندي [`Release`] لوڊ حصو کي [`Relaxed`] بڻائي ٿو.
            ///
            ///
            /// **نوٽ**: هي طريقو صرف پليٽ فارم تي موجود آهي جيڪي ايٽمي آپريشنن کي سپورٽ ڪن ٿا
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// بار=12 ؛
            /// اجازت ڏيو min_foo=foo.fetch_min (بار ، Ordering::SeqCst).min(bar);
            /// assert_eq! (منٽ_ فو ، 12) ؛
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // حفاظت: ڊيٽا جي رتن کي ائٽمي ڊرامي کان روڪيو ويو آهي.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// قابل تبديلي پوائنٽر کي انڌيري انوگر ۾ موٽائيندو آهي.
            ///
            /// غير ائٽمي ڪرڻ پڙهڻ ۽ نتيجو ڪندڙ انٽيگر تي لکڻ هڪ ڊيٽا جي نسل ٿي سگهي ٿي.
            /// اهو طريقو اڪثر ڪري ايف ايف آءِ لاءِ فائديمند آهي ، جتي فنڪشن وارو دستخط استعمال ڪري سگهندو آهي
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// هن ائٽومي کي شيئرڊ ريفرنس مان `*mut` پوائنٽر واپس ڪرڻ محفوظ آهي ڇاڪاڻ ته ائٽمي قسمَ اندرين مطابقت سان ڪم ڪن ٿا.
            /// ائٽمي جا سڀ ترميمي ويلڊٽ ريفرنس ذريعي قدر تبديل ڪن ٿا ، ۽ ايستائين محفوظ طور تي ڪري سگھن ٿا جيستائين اهي ايٽمي آپريشن ڪن.
            /// واپس ٿيل خام پوائنٽر جو ڪو به استعمال ايڪس سي ايم ايڪس بلاڪ جي ضرورت آهي ۽ اڃا به ساڳئي رڪاوٽ کي برقرار رکڻ آهي: انهي تي آپريشن لازمي طور تي ائٽمي هجڻ گهرجي.
            ///
            ///
            /// # Examples
            ///
            /// (extern-declaration) کي نظرانداز ڪريو
            ///
            /// # فني ايڪس ويڪس {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ٻاهرين "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // محفوظ: محفوظ جيستائين جيستائين `my_atomic_op` ايٽمي آهي.
            /// غير محفوظ {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // حفاظت: ڪال ڪندڙ کي `atomic_store` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // حفاظت: ڪال ڪندڙ کي `atomic_load` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // حفاظت: ڪال ڪندڙ کي `atomic_swap` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// پوئين ويل قيمت موٽائي ٿو (جهڙوڪ __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // حفاظت: ڪال ڪندڙ کي `atomic_add` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// پوئين قيمت موٽائي ٿو (جهڙوڪ __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // حفاظت: ڪال ڪندڙ کي `atomic_sub` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // حفاظت: ڪال ڪندڙ کي `atomic_compare_exchange` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // حفاظت: ڪال ڪندڙ کي `atomic_compare_exchange_weak` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // حفاظت: ڪال ڪندڙ کي `atomic_and` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // حفاظت: ڪال ڪندڙ کي `atomic_nand` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // حفاظت: ڪال ڪندڙ کي `atomic_or` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // حفاظت: ڪال ڪندڙ کي `atomic_xor` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// وڌ کان وڌ قيمت موٽائي ٿو (دستخط ٿيل مقابلو)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // حفاظت: ڪال ڪندڙ کي `atomic_max` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// گھٽ قيمت موٽائي ٿو (دستخط ٿيل مقابلو)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // حفاظت: ڪال ڪندڙ کي `atomic_min` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// وڌ کان وڌ قيمت موٽائي ٿو (اڻignاتل نسبت)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // حفاظت: ڪال ڪندڙ کي `atomic_umax` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// گھٽ قيمت موٽائي ٿو (اڻedاتل نسبت)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // حفاظت: ڪال ڪندڙ کي `atomic_umin` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// هڪ ايٽمي باهه.
///
/// مخصوص حڪم تي ڀاڙڻ وارا ، هڪ باھ گڏ ڪرڻ وارا ڪمپائلر ۽ سي پي يو کي ان جي گردن جي خاص قسم جي ميموري جي عملن کي ترتيب ڏيڻ کان روڪيندي آهي
/// اهو ٺاهه ٺاهيندو آهي ـ انهي سان لاڳاپن جو ۽ ان جي وچ ۾ ائٽمڪ آپريشن يا باهه.
///
/// هڪ باڑ 'A' جنهن وٽ (گهٽ ۾ گهٽ) [`Release`] آرڪٽيڪ سيمينٽڪ ، هڪ باڪس 'B' سان (هم آهن گھٽ) [`Acquire`] semantics سان هم وقت سازي ڪن ٿيون ، جيڪڏهن ۽ صرف جيڪڏهن هتي آپريشن ايڪس ۽ وائي موجود آهن ، ٻئي ڪجهه ايٽمي شيٽ 'M' تي ڪم ڪري رهيا آهن ته اي هن کان اڳ ترتيب ڏني وئي آهي ايڪس ، وائي ب کان پهريان هم وقت سازي ڪئي وڃي ٿي ۽ وائي ايم کي تبديل ڪري ٿو.
/// اهو هڪ اي ۽ بي جي وچ ۾ ٿيڻ کان اڳ انحصار مهيا ڪري ٿو.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] يا [`Acquire`] سيمينٽ سان گڏ ائٽمي آپريشن به باهه سان هم وقت سازي ڪري سگهن ٿا.
///
/// هڪ باڙ جيڪا [`SeqCst`] ترتيب ، ٻئي [`Acquire`] ۽ [`Release`] سيمينٽڪ هجڻ کان علاوه ، ٻئي [`SeqCst`] آپريشن ۽/يا باهه جي عالمي پروگرام آرڊر ۾ حصو وٺي ٿي.
///
/// [`Acquire`] ، [`Release`] ، [`AcqRel`] ۽ [`SeqCst`] آرڊرز کي قبول ڪري ٿو.
///
/// # Panics
///
/// Panics جيڪڏهن `order` آهي [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // اسپين لاڪ جي بنياد تي هڪ باهمي خارج ٿيڻ وارو ابتدائي.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // انتظار ڪريو جيستائين پراڻي قيمت `false` آهي.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // هي باڑ ايڪسڪسيمڪس ۾ اسٽور سان هم وقت سازي ڪري ٿي.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // حفاظت: ايٽمي باهه استعمال ڪندي محفوظ آهي.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// هڪ مرتب ڪندڙ يادگار باڙ.
///
/// `compiler_fence` ڪنهن مشين جي ڪوڊ کي ايمي نه ٿو ڪري ، پر ان قسم جي ميموري کي محدود ڪري ٿو ، ترتيب ڏيندڙ کي ٻيهر ترتيب ڏيڻ جي اجازت آهي.خاص طور تي ، ڏنل [`Ordering`] سيمينٽ جي بنياد تي ، مرتب ڪندڙ اڳيان پڙهڻ يا لکڻ کان منع ٿيل هوندا يا ڪال ڪرڻ کان اڳ يا بعد ۾ `compiler_fence` ڏانهن ڪال ڪال جي ٻئي طرف.ياد رکجو ته اهو **نه* ڪري ٿو *هارڊويئر* کي اهڙي ترتيب ڏيڻ کان روڪي ٿو.
///
/// اهو هڪ ڌڪيل ، عمل واري ترتيب ۾ مسئلو ناهي ، پر جڏهن ٻيا سلسلا ياداشت کي هڪ ئي وقت تبديل ڪري سگھن ٿا ، مضبوط هم وقت سازي وارو خاصيتون جهڙوڪ [`fence`] گهربل آهن.
///
/// مختلف ترتيب واري سيمينٽ کي ٻيهر ترتيب ڏيڻ سان ٻيهر روڪيو ويو آهي:
///
///  - [`SeqCst`] سان ، انهي مقام تي پڙهڻ ۽ لکڻ جي ٻيهر ترتيب جي اجازت ناهي.
///  - [`Release`] سان ، اڳئين لکڻين ۽ لکڻين کي پوئين تحريرن ۾ منتقل نٿو ڪري سگهجي.
///  - [`Acquire`] سان ، بعد ۾ ٿيندڙ پڙهڻ ۽ لکڻ کي اڳين پڙهڻ کان اڳ ۾ منتقل نٿو ڪري سگھجي.
///  - [`AcqRel`] سان ، مٿي ڏنل ٻنهي قاعدن کي لاڳو ڪيو وڃي ٿو.
///
/// `compiler_fence` عام طور تي صرف هڪ ڪنڊ کي ريسنگ کان بچائڻ لاءِ ڪارائتو آهي *پنهنجو پاڻ سان*.اهو آهي ، جيڪڏهن هڪ ڏنل سلسلو ڪوڊ جي هڪ ٽڪڙي کي عمل ڪري رهيو آهي ، ۽ پوءِ رڪاوٽ ٿي پيو آهي ، ۽ ڪوڊ کي ٻئي هنڌ تي عمل ڪرڻ شروع ڪري ٿو (اڃا تائين ساڳي سلسلي ۾ ، ۽ اڃا تائين ساڳئي ڪور تي تصوراتي طور تي).روايتي پروگرامن ۾ ، اهو تڏهن ئي ٿي سگھي ٿو جڏهن سگنل هٿ ڪرڻ وارو رجسٽر ٿيل هجي.
/// گهٽ هيٺين ليول ڪوڊ ۾ ، اهڙيون حالتون به پيدا ٿي سگهن ٿيون جڏهن رڪاوٽن کي هٿ ڪرڻ سان ، جڏهن اڳڀرو ٿيڻ سان سبز سلسلو هلائين ، وغيره.
/// مزيدار پڙهندڙن کي ايڪس [memory barriers] X ڪيريل جي بحث Linux پڙهڻ جي حوصلا افزائي آهي.
///
/// # Panics
///
/// Panics جيڪڏهن `order` آهي [`Relaxed`].
///
/// # Examples
///
/// `compiler_fence` کان سواءِ ، ھيٺ ڏنل ڪوڊ ۾ `assert_eq!` آھي *ڪاميابي* جي ضمانت ناھي ، ھڪڙي ھڪڙي سلسلي ۾ سڀ ڪجھ جي باوجود.
/// ڇو ڏسڻ لاءِ ، ياد رکو ته مرتب ڪندڙ دڪانن کي `IMPORTANT_VARIABLE` ۽ `IS_READ` مٽائڻ لاءِ مفت آهي ڇاڪاڻ ته اهي ٻئي `Ordering::Relaxed` آهن.جيڪڏهن اهو ڪري ٿو ، ۽ سگنل هينڊر `IS_READY` کي اپڊيٽ ٿيڻ جي صحيح بعد انڪوول ڪيو ويو آهي ، ته پوءِ سگنل هينڊلر `IS_READY=1` ڏسندا ، پر `IMPORTANT_VARIABLE=0`.
/// `compiler_fence` استعمال ڪندي هن صورتحال کي علاج ڪري ٿي.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // اڳين لکڻين کي ھن نقطي کان اڳتي وڌڻ کان روڪيو
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // حفاظت: ايٽمي باهه استعمال ڪندي محفوظ آهي.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// پروسيسر کي اشارو ڏئي ٿو ته اهو هڪ مصروف انتظار جي اسپن لوپ اندر آهي ("اسپن لاڪ").
///
/// اهو فنڪشن [`hint::spin_loop`] جي حق ۾ جڙي ويو آهي.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}