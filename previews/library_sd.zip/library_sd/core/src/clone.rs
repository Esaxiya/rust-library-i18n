//! `Clone` trait قسمن لاءِ جيڪي نقل طور تي نقل نٿا ڪري سگھجن.
//!
//! Rust ۾ ، ڪجهه سادي قسمون "implicitly copyable" آهن ۽ جڏهن توهان انهن کي تفويض ڪيو ٿا يا دلائل جي طور تي پاس ڪيو ٿا ، وصول ڪندڙ کي هڪ ڪاپي ملي ويندي ، اصل جڳهه کي جڳهه تي ڇڏڻ سان.
//! انهن قسمن کي ڪاپي ڪرڻ لاءِ مختص جي ضرورت نه هوندي آهي ۽ نه فائنل ڪرڻ وارا هوندا آهن (يعني انهن جا مالڪ خانه نه هوندا آهن يا ايڪس ايڪس ايڪس نافذ ڪندا هئا) ، تنهنڪري ڪمپائلر انهن کي نقل ڪرڻ لاءِ سستو ۽ محفوظ سمجهندو آهي.
//!
//! ٻين قسمن جي ڪاپيون واضح طور تي بڻائڻ گهرجن ، [`Clone`] trait کي لاڳو ڪرڻ ۽ [`clone`] طريقي سان سڏڻ.
//!
//! [`clone`]: Clone::clone
//!
//! بنيادي استعمال جو مثال:
//!
//! ```
//! let s = String::new(); // اسٽرنگ جو قسم ڪلون کي لاڳو ڪندو آهي
//! let copy = s.clone(); // تنهنڪري اسان ان کي کلون
//! ```
//!
//! کلون trait کي آساني سان لاڳو ڪرڻ لاءِ ، توهان پڻ `#[derive(Clone)]` استعمال ڪري سگھو ٿا.مثال ؛
//!
//! ```
//! #[derive(Clone)] // اسان Clone trait کي مارفورس جي جوڙجڪ ۾ شامل ڪريون ٿا
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ۽ ھاڻي اسان ان کي کلون ڪري سگھون ٿا!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// هڪ عام trait ڪنهن شي کي واضح طور تي نقل ڪرڻ جي قابليت لاءِ.
///
/// [`Copy`] ۾ فرق اهو آهي ته [`Copy`] ڇڪيل ۽ انتهائي قيمتي آهي ، جڏهن ته `Clone` هميشه واضح طور تي آهي ۽ شايد قيمتي ناهي.
/// انهن خاصيتن کي لاڳو ڪرڻ لاءِ ، Rust توهان کي [`Copy`] ٻيهر لاڳو ڪرڻ جي اجازت نٿو ڏي ، پر توهان شايد `Clone` ٻيهر لاڳو ڪري ۽ صوابدیدي ڪوڊ هلائي سگهو ٿا.
///
/// جيئن ته `Clone` [`Copy`] کان وڌيڪ عام آهي ، توهان پاڻبخود ڪا به شيءِ ٺاهي سگهو ٿا [`Copy`] `Clone` پڻ ائين آهي.
///
/// ## Derivable
///
/// اهو trait استعمال ڪري سگهجي ٿو `#[derive]` جيڪڏهن سڀ شعبا `Clone` آهن.[`Clone`] جو "حاصل" ڊي فيلڊ هر فيلڊ تي [`clone`] سڏيندو آهي.
///
/// [`clone`]: Clone::clone
///
/// هڪ عام ساخت جي لاءِ ، `#[derive]` عام چڪاس لاءِ پابند `Clone` شامل ڪندي `Clone` مشروط طور تي لاڳو ڪري ٿو.
///
/// ```
/// // `derive` پڙھڻ لاءِ ڪلون کي لاڳو ڪندو آھي<T>جڏهن T ڪلون آهي.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## آئون `Clone` کي ڪيئن لاڳو ڪري سگهان ٿو؟
///
/// قسم جيڪي [`Copy`] آهن انهن کي `Clone` جو هڪ عارضي نفاذ گهرجي.وڌيڪ رسمي طور تي:
/// جيڪڏهن `T: Copy` ، `x: T` ، ۽ `y: &T` ، ته پوءِ `let x = y.clone();` `let x = *y;` جي برابر آهي.
/// هن سموري جزيري کي برقرار رکڻ لاءِ دستي نفاذ کي محتاط رهڻ گهرجي.تنهن هوندي ، ياداشت جي حفاظت کي يقيني بڻائڻ لاءِ غير محفوظ ڪوڊ ان تي ڀروسو نه ڪرڻ گهرجي.
///
/// ھڪڙو مثال ھڪڙو عام آھي جيڪو ھڪڙو ڪم پوائنٽر کي منعقد ڪري سگھي ٿو.انهي صورت ۾ ، ايڪس 100 جي عمل درآمد کي "حاصل نه ڪري سگهجي" ڊي ، پر لاڳو ٿي سگهي ٿو.
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## اضافي پليجو
///
/// [implementors listed below][impls] جي اضافي ۾ ، هيٺيان قسم `Clone` پڻ لاڳو ڪن ٿيون.
///
/// * فنڪشن شئي جا قسم (يعني هر فنڪشن لاءِ مقرر ڪيل جدا جدا قسم)
/// * فنڪشن پوائنٽر جا قسم (مثال طور ، `fn() -> i32`)
/// * صفن جا قسم ، سڀني سائيز لاءِ ، جيڪڏهن شيءَ جو قسم به `Clone` تي لاڳو ٿئي ٿو (مثال طور ، `[i32; 123456]`)
/// * ٽوپل جا قسم ، جيڪڏهن هر جزو `Clone` پڻ لاڳو ڪندو آهي (مثال طور ، `()` ، `(i32, bool)`)
/// * بندش جا قسم ، جيڪڏهن اهي ماحول کان ڪابه قدر قبضي ۾ نه وٺندا يا جيڪڏهن اهي سڀئي قبضو ڪيل قدر پاڻ ۾ `Clone` لاڳو ڪندا.
///   ياد رکجو متغير حصيداري ڪيل حوالن طرفان هميشه `Clone` لاڳو ڪندا آهن (جيتوڻيڪ جيڪڏهن حوالو نه هجي) ، جڏهن ته متغير حوالا پاران قبضو ڪيل variables ڪڏهن به `Clone` لاڳو نٿا ڪن
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// قدر جي ڪاپي موٽائيندو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ڪلون کي لاڳو ڪندو آهي
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` کان ڪاپي اسسٽنٽ انجام ڏئي ٿو.
    ///
    /// `a.clone_from(&b)` ڪارڪردگي جي لحاظ کان `a = b.clone()` جي برابر آهي ، پر `a` جي وسيلن کي ٻيهر استعمال ۾ رنڊڪ ڪري سگهجي ٿو غير ضروري مختص کان بچڻ لاءِ.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// ماخوذ ميڪرو trait `Clone` جو نقشو پيدا ڪري ٿو.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): اهڙيون اڏاوتون صرف ۽ صرف#طرفان حاصل ڪيون ويون آهن ته بيان ڪري ٿو ته هر قسم جي جزو ڪلون يا ڪاپي لاڳو ڪندو آهي.
//
//
// ھي userانچو ڪتب آڻڻ وارن صارف جي ڪوڊ ۾ ھرگز ظاھر نٿا ٿين
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Clone` جي ابتدائي قسمن بابت پليپشن.
///
/// عمل درآمد جيڪي Rust ۾ بيان نه ٿي ڪري سگھجن ٿيون `traits::SelectionContext::copy_clone_conditions()` ۾ `rustc_trait_selection` ۾.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// گڏيل حوالي سان کلون ڪري سگھجن ٿيون ، پر متغير حوالا * نٿا وڃي سگھجن.
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// گڏيل حوالي سان کلون ڪري سگھجن ٿيون ، پر متغير حوالا * نٿا وڃي سگھجن.
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}