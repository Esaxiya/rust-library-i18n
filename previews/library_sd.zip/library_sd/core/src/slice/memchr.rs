// rust-memchr کان اصلي عمل درآمد.
// ڪاپي رائيٽ 2015 اينڊريو گيلينٽ ، بلس ۽ نڪولس ڪوچ

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// تعريف استعمال ڪريو.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// جيڪڏهن `x` صفر بائيٽ تي مشتمل ھجي ته `true` موٽائي ٿو.
///
/// *جا معاملا ڳڻپيوڪر*، ج آرند:
///
/// "خيال اهو آهي ته هر هڪ بائٽ کي ختم ڪيو وڃي ۽ پوءِ بائٽس کي ڳوليو ، جتي قرض سڀني کان وڌيڪ اهم طريقي سان پروپيگنڊا ڪئي هجي
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text` ۾ بائيٽ سان ملندڙ پهريون انڊيڪس واپس ڏئي ٿو.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // نن slي سلسلن لاءِ تيز رستو
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // هڪ وقت ۾ ٻه `usize` لفظ پڙهڻ سان هڪ بائيٽ جي قدر لاءِ اسڪين ڪريو.
    //
    // ٽن حصن ۾ `text` ورهايو
    // - اڻ سڌي ٿيل ابتدائي حصو ، پهرين لفظ سان جڙيل پتو کان اڳ متن ۾
    // - جسم ، هڪ وقت تي 2 لفظن ذريعي اسڪين ڪريو
    // - آخري رهيل حصو ، <2 لفظ جي سائيز

    // سڌي ٿيل حد تائين ڳوليو
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // لکت جي جسم کي ڳوليو
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // حفاظت: هن وقت جي وقار گهٽ ۾ گهٽ 2 * us__bytes جي فاصلي جي ضمانت ڏئي ٿي
        // آفسيس ۽ سلائس جي پڇاڙي جي وچ ۾.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // ٽوڙيو جيڪڏهن هتي مليل بائيٽ آهي
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // جسم لوپ بند ٿيڻ جي پوائنٽ کانپوءِ بائيٽ ڳوليو.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text` ۾ بائيٽ سان لاڳاپيل آخري انڊيڪس واپس ڏئي ٿو.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // هڪ وقت ۾ ٻه `usize` لفظ پڙهڻ سان هڪ بائيٽ جي قدر لاءِ اسڪين ڪريو.
    //
    // ٽن حصن ۾ `text` ورهايو:
    // - اڻ edميل دم ، متن ۾ آخري لفظ جي ترتيب واري ايڊريس کان پوءِ ،
    // - جسم ، هڪ وقت تي 2 لفظن طرفان اسڪين ٿيل ،
    // - پهرين باقي بائيٽ ، <2 لفظي سائيز.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // اسان اهو صرف ڪالهه ۽ پريڪس جي ڊيگهه حاصل ڪرڻ لاءِ سڏيون ٿا.
        // وچ ۾ اسان هميشه هڪ ئي وقت تي ٻن چئن کي پروسيس ڪندا آهيون.
        // حفاظت: `[u8]` کي `[usize]` منتقل ڪرڻ محفوظ آهي سائيز جي فرق کان سواء ، جيڪي `align_to` سان هٿ ڪيا ويا آهن.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // متن جي لاش کي ڳوليو ، پڪ ڪريو ته اسان min_aligned_offset پار نه ڪريون.
    // آفسيٽ هميشه مطابق آهي ، تنهنڪري صرف `>` جاچڻ ڪافي آهي ۽ ممڪن وهڪري کان بچڻ.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // سافٽي: آفسيٽ لينن ، suffix.len() تي شروع ٿئي ٿي ، جيستائين ان کان وڌيڪ وڏي آهي
        // min_aligned_offset (prefix.len()) باقي مفاصلو گھٽ ۾ گھٽ 2 * chunk_bytes آهي.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // ٽوڙيو جيڪڏهن هتي مليل بائيٽ آهي.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // جسم لوپ بند ٿيڻ جي پوائنٽ کان پهريان بائيٽ ڳوليو.
    text[..offset].iter().rposition(|elt| *elt == x)
}