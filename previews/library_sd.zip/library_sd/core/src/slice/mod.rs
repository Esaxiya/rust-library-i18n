// ignore-tidy-filelength

//! سليس انتظام ۽ چرپر.
//!
//! وڌيڪ تفصيل لاءِ ڏسو [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// خالص rust يادگار عمل درآمد ، rust-memchr کان ورتو ويو
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// اهو فنڪشن صرف عوام لاءِ آهي ڇاڪاڻ ته يونٽ جي ٽيسٽ هارپس جي ٻيو ڪو رستو ناهي.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// سلائس ۾ عناصر جو تعداد موٽائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // حفاظت: آواز اٿو ڇاڪاڻ ته اسان ڊگھي ميدان کي يوزائيزي جي طور تي منتقل ڪيو (جنهن کي ضرور هئڻ گهرجي)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // حفاظت: اهو محفوظ آهي ڇاڪاڻ ته `&[T]` ۽ `FatPtr<T>` وٽ ساڳئي ترتيب آهي.
            // صرف `std` اها ضمانت ڪري سگھي ٿو.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: `crate::ptr::metadata(self)` سان بدلايو جڏهن اهو مستحڪم آهي.
            // هن لکڻ جي جيئن ته هي "Const-stable functions can only call other const-stable functions" غلطي جو سبب بڻجي ٿو.
            //

            // حفاظت: ايڪس ايڪس اين ايڪس يونين تان قدر رسائي حاصل ڪرڻ کان محفوظ آهي * const T
            // ۽ پيٽر ڪمپونز<T>ساڳيا ياداشت جون جوڙيون آھن.
            // صرف std اها گارنٽي ڏئي سگهي ٿي.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// ايڪس سلڪسڪس کي واپسي ڏئي ٿو جيڪڏھن سلائس جي ڊيگهه 0 ٿئي ٿي.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// واپسي جي پهرين عنصر کي واپس ڏئي ٿي ، يا ايڪس اين ايڪس ايڪس جيڪڏهن اها خالي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// واپسيءَ جي پهرين عنصر کي هڪ قابل poيريندڙ نشانو موٽائيندو آهي ، يا ايڪس اين ايڪس ايڪس جيڪڏهن اها خالي هوندي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// واپسي جي پهرين ۽ باقي سڀ عنصر واپس ڪن ٿا ، يا ايڪس اين ايڪس ايڪس جيڪڏهن اها خالي هوندي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// واپسي جي پهرين ۽ باقي سڀ عنصر واپس ڪن ٿا ، يا ايڪس اين ايڪس ايڪس جيڪڏهن اها خالي هوندي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// واپسي جي آخري ۽ باقي سمورن عنصرن کي واپس ڪندو آهي ، يا ايڪس اين ايڪس ايڪس جيڪڏهن اها خالي هوندي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// واپسي جي آخري ۽ باقي سمورن عنصرن کي واپس ڪندو آهي ، يا ايڪس اين ايڪس ايڪس جيڪڏهن اها خالي هوندي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// واپسي جي آخري عنصر کي واپسي ڏئي ٿو ، يا ايڪس اين ايمڪس جيڪڏهن اهو خالي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// ٻٻر ۾ آخري شيءَ لاءِ هڪ قابل بدل اشارو ڏي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// انڊيڪس جي قسم تي ڀاڙيندي عنصر يا سبسڊي کي هڪ حوالو موٽائيندو آهي.
    ///
    /// - جيڪڏهن هڪ پوزيشن ڏني ، موٽندي عنصر کي انهي پوزيشن يا `None` تي هڪ حوالو جيڪڏهن حدن کان ٻاهر آهي.
    ///
    /// - جيڪڏهن حد ڏني وڃي ، انهي حد جي مطابق سبسڪرس ڏي ٿو ، يا ايڪس آرڪس جيڪڏهن حد کان ٻاهر.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// اشاري جي قسم تي ڀاڙيل عنصر کي ذيلي تقليد واپس ڏئي ٿو ([`get`] ڏسو) يا `None` جيڪڏهن انڊيڪس حد کان ٻاهر آهي.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// حدون چيڪ ڪرڻ کانسواءِ ، ڪنهن عنصر يا سبسڊي جي حوالي کي اڻ ڏي ٿو.
    ///
    /// هڪ محفوظ متبادل لاءِ [`get`] ڏسو.
    ///
    /// # Safety
    ///
    /// انهي طريقي کي ٻاهرين حد تائين انڊيڪس سڏڻ *[اڻ بيان ٿيل رويو]* آهي جيتوڻيڪ نتيجو وارو حوالو استعمال نه ڪيو ويو آهي.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // حفاظت: سڏيندڙ کي `get_unchecked` لاءِ اڪثر حفاظت جي ضرورتن کي برقرار رکڻ گهرجي.
        // سلائس غير قابل بيان آهي ڇاڪاڻ ته `self` هڪ محفوظ حوالو آهي.
        // واپسي پوائنٽر محفوظ آهي ڇاڪاڻ ته `SliceIndex` جي نقل لازمي آهي ته ان جي ضمانت ڏي.
        unsafe { &*index.get_unchecked(self) }
    }

    /// حدون چيڪ ڪرڻ کانسواءِ ، ڪنھن عنصر يا سبسليس جو قابل referenceير referenceار حوالو ڏئي ٿو.
    ///
    /// هڪ محفوظ متبادل لاءِ ڏسو [`get_mut`].
    ///
    /// # Safety
    ///
    /// انهي طريقي کي ٻاهرين حد تائين انڊيڪس سڏڻ *[اڻ بيان ٿيل رويو]* آهي جيتوڻيڪ نتيجو وارو حوالو استعمال نه ڪيو ويو آهي.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // حفاظت: سڏيندڙ کي `get_unchecked_mut` لاءِ حفاظت جي ضرورتن کي برقرار رکڻ گهرجي.
        // سلائس غير قابل بيان آهي ڇاڪاڻ ته `self` هڪ محفوظ حوالو آهي.
        // واپسي پوائنٽر محفوظ آهي ڇاڪاڻ ته `SliceIndex` جي نقل لازمي آهي ته ان جي ضمانت ڏي.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// خام پوائنٽر کي سلائس جي بفر ڏانھن موٽائيندو آھي.
    ///
    /// ڪالر کي ضرور پڪ ڪرڻ گهرجي ته سلائس پوائنٽر کان بچيل آهي اها فنڪشن موٽائي ٿي ورنہ ختم ٿي ويندي انهي ڏانهن اشارو ڪرڻ واري لاءِ.
    ///
    /// ڪالر پڻ انهي ڳالهه کي يقيني بنائڻ گهرجي ته يادگيري پوائنٽر (non-transitively) ڏانهن اشارو ڪڏهن به ناهي لکيو ويو (سواءِ `UnsafeCell` جي) انهي پوائنٽر يا ان مان نڪتل ڪنهن به پوائنٽر کي استعمال ڪندي.
    /// جيڪڏهن توهان کي سلائس جي مواد کي متحرڪ ڪرڻ جي ضرورت آهي ، استعمال ڪريو [`as_mut_ptr`].
    ///
    /// هن سلائس جو حوالو ڏنل ڪنٽينر کي تبديل ڪرڻ ان جي بفر کي فراءِ ڪرڻ جو سبب بڻجي ، جنهن ان کي به ڪو اشارو ڪندي ته غلط ٿيندي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// سلائس جي بفر ڏانھن ھڪڙو غير محفوظ مٽيل پوائنٽر واپس ڏئي ٿو.
    ///
    /// ڪالر کي ضرور پڪ ڪرڻ گهرجي ته سلائس پوائنٽر کان بچيل آهي اها فنڪشن موٽائي ٿي ورنہ ختم ٿي ويندي انهي ڏانهن اشارو ڪرڻ واري لاءِ.
    ///
    /// هن سلائس جو حوالو ڏنل ڪنٽينر کي تبديل ڪرڻ ان جي بفر کي فراءِ ڪرڻ جو سبب بڻجي ، جنهن ان کي به ڪو اشارو ڪندي ته غلط ٿيندي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// ٻه خام پوائنٽر ڏي ٿو سلائس کي وڌائي.
    ///
    /// واپسي واري حد اڌ کليل آهي ، جنهن جو مطلب آهي ته آخري پوائنٽر پوائنٽس *هڪ ماضي* سلائس جو آخري عنصر.
    /// هن طريقي سان ، خالي سلائيس ٻن برابر پوائنٽرن جي نمائندگي ڪئي ويندي آهي ۽ ٻن اشارن جو فرق سليس جي ماپ جي نمائندگي ڪري ٿو.
    ///
    /// هنن پوائنٽرن کي استعمال ڪرڻ جي خبرداري لاءِ [`as_ptr`] ڏسو.آخري پوائنٽر اضافي احتياط جي ضرورت هوندي آهي ، ڇاڪاڻ ته اهو سلائس ۾ هڪ صحيح عنصر ڏانهن اشارو نه هوندو آهي.
    ///
    /// اهو فنڪشنل فارن انٽرفيسس سان ڳالهه ٻولهه ڪرڻ جي لاءِ مفيد آهي جيڪي ٻه اشارو استعمال ڪندا آهن يادگيري ۾ گهڻو ڪري عناصر ، جيئن عام طور تي سي ++ ۾ عام آهن.
    ///
    ///
    /// اهو چيڪ ڪرڻ لاءِ پڻ ڪارائتو ٿي سگهي ٿو ته پوائنٽر ڏانهن هڪ عنصر ڏانهن هن سلائس جي هڪ عنصر جو حوالو ڏنو ويو آهي.
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // حفاظت: `add` هتي محفوظ آھي ، ڇاڪاڻ ته:
        //
        //   - ٻئي اشارو هڪ ئي شيءَ جو حصو هوندا آهن ، جيئن سڌي طرح اشارو ڪرڻ سان به شيءَ سمجهيو وڃي ٿو.
        //
        //   - سليز جو اندازو isize::MAX بائٽس کان ڪڏهن به وڏو ناهي ، جيئن هتي نوٽ ڪيو ويو آهي:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - چوڌاري ويڙھيل ناھي ، جئين سلائسس پتي جي پڇاڙي جي آخر تائين لفاف نه ڪنديون آھن.
        //
        // pointer::add جو دستاويز ڏسو.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// ٻلي کي ختم ڪندي ٻه غير محفوظ مٽائيندڙ اشارو ڏي ٿو.
    ///
    /// واپسي واري حد اڌ کليل آهي ، جنهن جو مطلب آهي ته آخري پوائنٽر پوائنٽس *هڪ ماضي* سلائس جو آخري عنصر.
    /// هن طريقي سان ، خالي سلائيس ٻن برابر پوائنٽرن جي نمائندگي ڪئي ويندي آهي ۽ ٻن اشارن جو فرق سليس جي ماپ جي نمائندگي ڪري ٿو.
    ///
    /// هنن پوائنٽرن کي استعمال ڪرڻ جي خبرداري لاءِ [`as_mut_ptr`] ڏسو.
    /// آخري پوائنٽر اضافي احتياط جي ضرورت هوندي آهي ، ڇاڪاڻ ته اهو سلائس ۾ هڪ صحيح عنصر ڏانهن اشارو نه هوندو آهي.
    ///
    /// اهو فنڪشنل فارن انٽرفيسس سان ڳالهه ٻولهه ڪرڻ جي لاءِ مفيد آهي جيڪي ٻه اشارو استعمال ڪندا آهن يادگيري ۾ گهڻو ڪري عناصر ، جيئن عام طور تي سي ++ ۾ عام آهن.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // حفاظت: مٿي ڏسو as_ptr_range() ڇو ته `add` هتي محفوظ آھي.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// سليس ۾ ٻن عنصرن کي مٽايو.
    ///
    /// # Arguments
    ///
    /// * هڪ ، پهرين عنصر جو انڊيڪس
    /// * ب ، ٻئي عنصر جو انڊيڪس
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `a` يا `b` حد کان ٻاهر آهن.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // هڪ vector کان ٻه بدلندڙ قرض نه وٺي سگهيا ، انهي جي بدران خام اشارا استعمال ڪريو.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SAFETY: `pa` ۽ `pb` ٺاھيل آھن محفوظ مٽيل حوالن ۽ حوالن مان
        // سليس ۾ عنصرن ۽ ان جي ڪري صحيح ۽ ترتيب ڏيڻ جي ضمانت آهي.
        // ياد رکو ته `a` ۽ `b` جي پويان عناصر تائين رسائي جي جانچ ڪئي وئي آهي ۽ حد کان ٻاهر جڏهن panic ٿيندو.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// سليس ۾ عناصر جي حڪم کي مٽائي ٿو ، جڳهه تي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // تمام نن typesن قسمن لاءِ ، سڀئي فرد عام رستي ۾ پڙهي خراب آهي.
        // اسان بهتر ڪري سگھون ٿا ، ڏنو ويو آھي غير محفوظ ٿيل load/store ، ھڪڙي وڏي چڪر کي لوڊ ڪندي ۽ ھڪڙي رجسٽر کي ريورس ڪريو.
        //

        // مثالي طور تي ايل ايل وي ايم اسان لاءِ اهو ڪندو ، ڇاڪاڻ ته اهو اسان کان بهتر knowsاڻي ٿو ته ڇا غير ترتيب واري پڙهڻ موثر آهن (ڇاڪاڻ ته مختلف آر ايم نسخن جي وچ ۾ جيڪي تبديليون اچن ٿيون ، مثال طور) ۽ ڇا بهترين چونڪ وارو سائز ٿيندو.
        // بدقسمتي سان ، جيئن LLVM 4.0 (2017-05) اهو صرف لوپ کي ختم ڪري ٿو ، تنهنڪري اسان کي اهو پاڻ ڪرڻ جي ضرورت آهي.
        // (هائپسيس: ريورس ڏکوئيندڙ آهي ڇاڪاڻ ته ڪنارن کي مختلف سان ڳن alignيل ٿي سگهي ٿو. ٿيندو ، جڏهن ڊيگهه طويل هوندي. تنهنڪري وچ ۾ مڪمل طور تي SIMميل سمڊ کي استعمال ڪرڻ لاءِ اڳڀرائي ۽ اڳين پوسٽن کي خارج ڪرڻ جو ڪو طريقو ناهي.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // استعمال ڪريو يوڪسز کي ريورس ڪرڻ لاءِ llvm.bswap داخل ڪرڻ جي لاءِ
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // حفاظت: هتي چيڪ ڪرڻ لاءِ ڪيتريون شيون آهن:
                //
                // - نوٽ ڪيو ته `chunk` مٿي يا ٻئي طرف cfg چيڪ ڪرڻ جي سبب 4 يا 8 آهي.تنهن ڪري `chunk - 1` مثبت آهي.
                // - انڊيڪس ايڪس 100 سان انڊسٽنگ ٺيڪ آهي جيئن ته لوپ چيڪ ضمانت ڏي
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - انڊيڪس ايڪس 600 سان انڊسٽنگ ٺيڪ آهي:
                //   - `i + chunk > 0` ٿورڙي صحيح آهي.
                //   - لوپ چيڪ جي ضمانت آهي.
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln` ، اھڙي طرح ڪفر ڪڏھن ن گھٽجي.
                // - `read_unaligned` ۽ `write_unaligned` ڪال صحيح آهن:
                //   - `pa` انڊيڪس `i` ڏانهن اشارو ڪري ٿو جتي `i < ln / 2 - (chunk - 1)` (مٿي ڏسو) ۽ `pb` انڊيڪس `ln - i - chunk` ڏانهن اشارو ڪن ٿا ، تنهن ڪري ٻئي `self` جي آخر کان وٺي ڪيترائي بٽس گهٽ ۾ گهٽ `chunk` آهن.
                //
                //   - ڪوبه شروعاتي ياداشت صحيح آھي `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // u32 ۾ u16s کي ريورس ڪرڻ لاءِ گردش-ذريعي-16 استعمال ڪريو
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // حفاظت: هڪ غير ترتيب ٿيل u32 ايڪسڪسيمڪس کان پڙهي سگهجي ٿو جيڪڏهن `i + 1 < ln`
                // (۽ ظاهر طور تي `i < ln`) ، ڇاڪاڻ ته هر عنصر 2 بائٽس آهي ۽ اسان 4 پڙهي رهيا آهيون.
                //
                // `i + chunk - 1 < ln / 2` # جڏهن ته حالت
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // جئين اهو 2 جي ڀيٽ ۾ ورهايل ڊيگهه کان گهٽ آهي ، تنهن ڪري ان کي حدن ۾ ضرور هئڻ گهرجي
                //
                // اهو پڻ مطلب آهي ته حالت `0 < i + chunk <= ln` هميشه معزز رهي ٿي ، انهي کي يقيني بڻائي ته `pb` پوائنٽر محفوظ طور تي استعمال ڪري سگهجي ٿو.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // حفاظت: `i` ٻلي جي ڊيگهه جي ڀيٽ ۾ گهٽ آهي
            // `i` ۽ `ln - i - 1` تائين رسائي محفوظ آهي (`i` 0 کان شروع ٿئي ٿو ۽ `ln / 2 - 1` کان وڌيڪ نه ويندي).
            // نتيجو وارو اشارو `pa` ۽ `pb` صحيح ۽ ترتيب ڏنل آهن ، ۽ انهي کان پڙهي ۽ لکي سگهجي ٿو.
            //
            //
            unsafe {
                // محفوظ تبادلي ۾ حدن کان بچڻ لاءِ غير محفوظ ادل
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// واپسي واري مٿان هڪ ويڙهاڪ واپس ڏي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// هڪ ورثو واپس ڏئي ٿو جيڪو هر ويل کي تبديل ڪرڻ جي اجازت ڏئي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// ڊيگهه `size` جي تمام سٺائي windows مٿان ايريرٽر واپس ڏئي ٿو.
    /// windows اوورلوپ.
    /// جيڪڏهن سلائس `size` کان نن isو آهي ، ايٽررٽر ڪو به قدر واپس نه ٿو ڪري.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `size` 0 آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// جيڪڏهن سلائس `size` کان نن isو آهي:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// ٻلي جي `chunk_size` عنصرن مٿان هڪ ورائيٽر کي واپس ڏئي ٿو ، سليس جي شروعات کان شروع.
    ///
    /// ڀا areيون سلائسون آهن ۽ مٿان چڙهندڙ نه آهن.جيڪڏهن `chunk_size` سليس جي ڊيگهه کي ورهائي نه ٿو ورهائي ، ته پوءِ آخري چوڪ `chunk_size` جي ڊيگهه نه هوندي.
    ///
    /// XI [`chunks_exact`] هن ايٽرر جي هڪ قسم جي لاءِ ڏسو جيڪي هميشه هميشه `chunk_size` عناصر جا حصا موٽائيندو آهي ، ۽ ساڳئي ايٽرر لاءِ [`rchunks`] پر ساڳيو سلائير جي آخر ۾ شروع ٿيندي.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `chunk_size` 0 آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// ٻلي جي `chunk_size` عنصرن مٿان هڪ ورائيٽر کي واپس ڏئي ٿو ، سليس جي شروعات کان شروع.
    ///
    /// چڪن متحرڪ سلائسون آهن ، ۽ مٿان چڙهندڙ نه آهن.جيڪڏهن `chunk_size` سليس جي ڊيگهه کي ورهائي نه ٿو ورهائي ، ته پوءِ آخري چوڪ `chunk_size` جي ڊيگهه نه هوندي.
    ///
    /// XI [`chunks_exact_mut`] هن ايٽرر جي هڪ قسم جي لاءِ ڏسو جيڪي هميشه هميشه `chunk_size` عناصر جا حصا موٽائيندو آهي ، ۽ ساڳئي ايٽرر لاءِ [`rchunks_mut`] پر ساڳيو سلائير جي آخر ۾ شروع ٿيندي.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `chunk_size` 0 آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// ٻلي جي `chunk_size` عنصرن مٿان هڪ ورائيٽر کي واپس ڏئي ٿو ، سليس جي شروعات کان شروع.
    ///
    /// ڀا areيون سلائسون آهن ۽ مٿان چڙهندڙ نه آهن.
    /// جيڪڏهن `chunk_size` سليس جي ڊيگهه کي تقسيم نه ڪري ، پوءِ آخري `chunk_size-1` عنصرن کي ختم ڪري ڇڏيو وڃي ٿو ۽ ايڪسٽر جي `remainder` فنڪشن کان واپس وٺي سگهجي ٿو.
    ///
    ///
    /// هر ڪنڪ جي ڪري بلڪل `chunk_size` عناصر هجڻ ڪري ، مرتب ڪندڙ گهڻو ڪري نتيجي ۾ ڪوڊ کي بهتر بڻائي سگھي ٿو ايڪسڪسيمڪس جي صورت ۾.
    ///
    /// [`chunks`] هن ايريرٽر جي هڪ قسم جي لاءِ ڏسو جيڪي بچيل پڻ نن chي ڀاڙي وانگر واپس ڪري ٿو ۽ ساڳيو ئي ايئرايٽر لاءِ [`rchunks_exact`] پر سليس جي آخر ۾ شروع ٿئي ٿو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `chunk_size` 0 آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// ٻلي جي `chunk_size` عنصرن مٿان هڪ ورائيٽر کي واپس ڏئي ٿو ، سليس جي شروعات کان شروع.
    ///
    /// چڪن متحرڪ سلائسون آهن ، ۽ مٿان چڙهندڙ نه آهن.
    /// جيڪڏهن `chunk_size` سليس جي ڊيگهه کي تقسيم نه ڪري ، پوءِ آخري `chunk_size-1` عنصرن کي ختم ڪري ڇڏيو وڃي ٿو ۽ ايڪسٽر جي `into_remainder` فنڪشن کان واپس وٺي سگهجي ٿو.
    ///
    ///
    /// هر ڪنڪ جي ڪري بلڪل `chunk_size` عناصر هجڻ ڪري ، مرتب ڪندڙ گهڻو ڪري نتيجي ۾ ڪوڊ کي بهتر بڻائي سگھي ٿو ايڪسڪسيمڪس جي صورت ۾.
    ///
    /// [`chunks_mut`] هن ايريرٽر جي هڪ قسم جي لاءِ ڏسو جيڪي بچيل پڻ نن chي ڀاڙي وانگر واپس ڪري ٿو ۽ ساڳيو ئي ايئرايٽر لاءِ [`rchunks_exact_mut`] پر سليس جي آخر ۾ شروع ٿئي ٿو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `chunk_size` 0 آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// سلائس کي اين اين ايل عنصر ايريم جي سلائس ۾ ورهايو ، فرض ڪيو ته باقي ڪجهه ناهي.
    ///
    ///
    /// # Safety
    ///
    /// اهو شايد تڏهن سڏجي ٿو جڏهن
    /// - سلائس صحيح طور تي "اين" عنصر چوڪن ۾ ورهايو ويو آهي
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // حفاظت: 1 عنصر عنصرن کي ڪڏھن بھي رھيو ناھي
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // حفاظت: سلائس جي ڊيگهه (6) 3 جي گهڻن آهي
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // اهي بي بنياد هوندا:
    /// // چئن جو حصو ڏيو: &[[_؛5]]=ايڪسڪسيمڪس//سلائس جي ڊيگهه 5 جي گهڻن کان وڌيڪ ناهي:&[[_ ؛0]]= slice.as_chunks_unchecked()//صفر جي ڊگھائي چڪنن جي ڪڏھن اجازت ناھي
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // حفاظت: اسان جي اڳڀرائي ساڳي ريت آهي جنهن کي سڏ ڪرڻ جي ضرورت آهي
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // حفاظت: اسان `new_len * N` عنصرن جو هڪ ٽڪرا اڇلائي ڇڏيو
        // `new_len` جي ڪيترن ئي `N` عنصرن جو هڪ ٽڪرو.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// سلائس کي اين جي عنصر ايليز جي سلائس ۾ ورهايو ، سلائس جي شروعات کان شروع ٿئي ، ۽ باقي رهيل سلائس ايڪس آرڪس کان گهٽ سختي سان.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `N` 0. اهو چڪاس ممڪن طور تي مرتب ٿيل وقت جي غلطي تي ٿيندو ته هن طريقي سان مستحڪم ٿيڻ کان اڳ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // حفاظت: اسان اڳ ۾ صفر کان ڊickي ڇڏيو ، ۽ تعمير جي ذريعي يقيني بڻائي ڇڏيو
        // انهي سبسڪرز جي ڊيگهه اين.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// سلائس کي اين جي عنصر ايليز جي سلائس ۾ ورهايو ، سلائس جي آخر ۾ شروع ٿيندڙ ، ۽ باقي رهيل سلائس ايڪس آرڪس کان گهٽ سختي سان.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `N` 0. اهو چڪاس ممڪن طور تي مرتب ٿيل وقت جي غلطي تي ٿيندو ته هن طريقي سان مستحڪم ٿيڻ کان اڳ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // حفاظت: اسان اڳ ۾ صفر کان ڊickي ڇڏيو ، ۽ تعمير جي ذريعي يقيني بڻائي ڇڏيو
        // انهي سبسڪرز جي ڊيگهه اين.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// ٻلي جي `N` عنصرن مٿان هڪ ورائيٽر کي واپس ڏئي ٿو ، سليس جي شروعات کان شروع.
    ///
    /// چڪن آرڪي ريفرنس آهن ۽ وڌيڪ چڙهندا نه آهن.
    /// جيڪڏهن `N` سليس جي ڊيگهه کي تقسيم نه ڪري ، پوءِ آخري `N-1` عنصرن کي ختم ڪري ڇڏيو ويندو ۽ ويرر واري `remainder` فنڪشن تان واپس وٺي سگهجي ٿو.
    ///
    ///
    /// اهو طريقو [`chunks_exact`] جي برابر عام عام آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `N` 0. اهو چڪاس ممڪن طور تي مرتب ٿيل وقت جي غلطي تي ٿيندو ته هن طريقي سان مستحڪم ٿيڻ کان اڳ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// سلائس کي اين اين ايل عنصر ايريم جي سلائس ۾ ورهايو ، فرض ڪيو ته باقي ڪجهه ناهي.
    ///
    ///
    /// # Safety
    ///
    /// اهو شايد تڏهن سڏجي ٿو جڏهن
    /// - سلائس صحيح طور تي "اين" عنصر چوڪن ۾ ورهايو ويو آهي
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // حفاظت: 1 عنصر عنصرن کي ڪڏھن بھي رھيو ناھي
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // حفاظت: سلائس جي ڊيگهه (6) 3 جي گهڻن آهي
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // اهي بي بنياد هوندا:
    /// // چئن جو حصو ڏيو: &[[_؛5]]=ايڪسڪسيمڪس//سلائس جي ڊيگهه 5 جي گهڻن کان وڌيڪ ناهي:&[[_ ؛0]]= slice.as_chunks_unchecked_mut()//صفر جي ڊگھائي چڪنن جي ڪڏھن اجازت ناھي
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // حفاظت: اسان جي اڳڀرائي ساڳي ريت آهي جنهن کي سڏ ڪرڻ جي ضرورت آهي
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // حفاظت: اسان `new_len * N` عنصرن جو هڪ ٽڪرا اڇلائي ڇڏيو
        // `new_len` جي ڪيترن ئي `N` عنصرن جو هڪ ٽڪرو.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// سلائس کي اين جي عنصر ايليز جي سلائس ۾ ورهايو ، سلائس جي شروعات کان شروع ٿئي ، ۽ باقي رهيل سلائس ايڪس آرڪس کان گهٽ سختي سان.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `N` 0. اهو چڪاس ممڪن طور تي مرتب ٿيل وقت جي غلطي تي ٿيندو ته هن طريقي سان مستحڪم ٿيڻ کان اڳ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // حفاظت: اسان اڳ ۾ صفر کان ڊickي ڇڏيو ، ۽ تعمير جي ذريعي يقيني بڻائي ڇڏيو
        // انهي سبسڪرز جي ڊيگهه اين.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// سلائس کي اين جي عنصر ايليز جي سلائس ۾ ورهايو ، سلائس جي آخر ۾ شروع ٿيندڙ ، ۽ باقي رهيل سلائس ايڪس آرڪس کان گهٽ سختي سان.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `N` 0. اهو چڪاس ممڪن طور تي مرتب ٿيل وقت جي غلطي تي ٿيندو ته هن طريقي سان مستحڪم ٿيڻ کان اڳ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // حفاظت: اسان اڳ ۾ صفر کان ڊickي ڇڏيو ، ۽ تعمير جي ذريعي يقيني بڻائي ڇڏيو
        // انهي سبسڪرز جي ڊيگهه اين.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// ٻلي جي `N` عنصرن مٿان هڪ ورائيٽر کي واپس ڏئي ٿو ، سليس جي شروعات کان شروع.
    ///
    /// چڪن متغير صفن جا حوالا آهن ۽ مٿي نه چڙهندا آهن.
    /// جيڪڏهن `N` سليس جي ڊيگهه کي تقسيم نه ڪري ، پوءِ آخري `N-1` عنصرن کي ختم ڪري ڇڏيو وڃي ٿو ۽ ايڪسٽر جي `into_remainder` فنڪشن کان واپس وٺي سگهجي ٿو.
    ///
    ///
    /// اهو طريقو [`chunks_exact_mut`] جي برابر عام عام آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `N` 0. اهو چڪاس ممڪن طور تي مرتب ٿيل وقت جي غلطي تي ٿيندو ته هن طريقي سان مستحڪم ٿيڻ کان اڳ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// هڪ ٻلي جي `N` عناصر windows مٿان وڌيڪ چڙ ڏيڻ دوران هڪ بار بار واپس آندي آهي ، سلائس جي شروعات کان شروع.
    ///
    ///
    /// اهو [`windows`] جي برابر عام عام آهي.
    ///
    /// جيڪڏهن `N` سليس جي ماپ کان وڏي آهي ، ته اهو windows واپس نه ٿيندو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `N` 0 آهي.
    /// هن چيڪ مستحڪم ٿيڻ کان اڳ ممڪن طور تي مرتب ٿيل وقت جي غلطي ۾ تبديل ٿي ويندي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// سلائس جي آخر ۾ شروع ٿيندڙ `chunk_size` عنصرن مٿان هڪ منتظر واپس ڏي ٿو.
    ///
    /// ڀا areيون سلائسون آهن ۽ مٿان چڙهندڙ نه آهن.جيڪڏهن `chunk_size` سليس جي ڊيگهه کي ورهائي نه ٿو ورهائي ، ته پوءِ آخري چوڪ `chunk_size` جي ڊيگهه نه هوندي.
    ///
    /// XI [`rchunks_exact`] هن ايٽررٽر جي هڪ قسم جي لاءِ ڏسو جيڪي هميشه `chunk_size` عناصر جا حصا موٽائيندو آهي ، ۽ ساڳئي ايٽرر لاءِ [`chunks`] پر انهي سلائس جي شروعات تي شروع.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `chunk_size` 0 آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// سلائس جي آخر ۾ شروع ٿيندڙ `chunk_size` عنصرن مٿان هڪ منتظر واپس ڏي ٿو.
    ///
    /// چڪن متحرڪ سلائسون آهن ، ۽ مٿان چڙهندڙ نه آهن.جيڪڏهن `chunk_size` سليس جي ڊيگهه کي ورهائي نه ٿو ورهائي ، ته پوءِ آخري چوڪ `chunk_size` جي ڊيگهه نه هوندي.
    ///
    /// XI [`rchunks_exact_mut`] انهي ايٽرر جي هڪ قسم جي لاءِ ڏسو جيڪي هميشه هميشه `chunk_size` عناصر جا حصا موٽائيندو آهي ، ۽ ساڳئي ايٽرر لاءِ [`chunks_mut`] پر انهي سلائس جي شروعات تي شروع.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `chunk_size` 0 آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// سلائس جي آخر ۾ شروع ٿيندڙ `chunk_size` عنصرن مٿان هڪ منتظر واپس ڏي ٿو.
    ///
    /// ڀا areيون سلائسون آهن ۽ مٿان چڙهندڙ نه آهن.
    /// جيڪڏهن `chunk_size` سليس جي ڊيگهه کي تقسيم نه ڪري ، پوءِ آخري `chunk_size-1` عنصرن کي ختم ڪري ڇڏيو وڃي ٿو ۽ ايڪسٽر جي `remainder` فنڪشن کان واپس وٺي سگهجي ٿو.
    ///
    /// هر ڪنڪ جي ڪري بلڪل `chunk_size` عناصر هجڻ ڪري ، مرتب ڪندڙ گهڻو ڪري نتيجي ۾ ڪوڊ کي بهتر بڻائي سگھي ٿو ايڪسڪسيمڪس جي صورت ۾.
    ///
    /// انهي ايريٽر جي هڪ قسم جي لاءِ [`rchunks`] ڏسو جيڪو پڻ بچجي ٿو نن aي ٿنڀي وانگر ، ۽ [`chunks_exact`] ساڳي ايٽرر لاءِ پر سليس جي شروعات ۾ شروع.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `chunk_size` 0 آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// سلائس جي آخر ۾ شروع ٿيندڙ `chunk_size` عنصرن مٿان هڪ منتظر واپس ڏي ٿو.
    ///
    /// چڪن متحرڪ سلائسون آهن ، ۽ مٿان چڙهندڙ نه آهن.
    /// جيڪڏهن `chunk_size` سليس جي ڊيگهه کي تقسيم نه ڪري ، پوءِ آخري `chunk_size-1` عنصرن کي ختم ڪري ڇڏيو وڃي ٿو ۽ ايڪسٽر جي `into_remainder` فنڪشن کان واپس وٺي سگهجي ٿو.
    ///
    /// هر ڪنڪ جي ڪري بلڪل `chunk_size` عناصر هجڻ ڪري ، مرتب ڪندڙ گهڻو ڪري نتيجي ۾ ڪوڊ کي بهتر بڻائي سگھي ٿو ايڪسڪسيمڪس جي صورت ۾.
    ///
    /// انهي ايريٽر جي هڪ قسم جي لاءِ [`rchunks_mut`] ڏسو جيڪو پڻ بچجي ٿو ننderو نن asڙو نن asڙو حصو ، ۽ [`chunks_exact_mut`] ساڳي ايٽرر لاءِ پر سلائس جي شروعات تي شروع.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `chunk_size` 0 آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// عناصر کي ڌار ڌار استعمال ڪرڻ واري پيشن گوئي کي استعمال ڪندي سلائي مٿان هڪ بار بار ورجائي ٿو.
    ///
    /// predikat کي پنھنجي پٺيان ٻن عنصرن تي سڏيو ويو آھي ، ان جو مطلب آھي predikat کي `slice[0]` ۽ `slice[1]` سڏيو وڃي ٿو پوءِ `slice[1]` ۽ `slice[2]` ۽ اھڙي طرح.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// هي طريقو ترتيب وار سبسڪرٽس ڪ toڻ لاءِ استعمال ڪري سگهجي ٿو.
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// سلائس مٿان هڪ ورجاءُ کي واپسي ڏي ٿو جتان عنصرن کي استعمال ڪرڻ واري عنصر کي استعمال نه ڪرڻ واري ٺاهن کي ختم ڪرڻ.
    ///
    /// predikat کي پنھنجي پٺيان ٻن عنصرن تي سڏيو ويو آھي ، ان جو مطلب آھي predikat کي `slice[0]` ۽ `slice[1]` سڏيو وڃي ٿو پوءِ `slice[1]` ۽ `slice[2]` ۽ اھڙي طرح.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// هي طريقو ترتيب وار سبسڪرٽس ڪ toڻ لاءِ استعمال ڪري سگهجي ٿو.
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// ھڪڙي انڊيڪس ۾ ھڪ ورڇ کي ٻن ۾ ورهايو ويو آھي.
    ///
    /// پهرين ۾ `[0, mid)` کان سڀ انڊيڪس شامل ٿي وينديون (انڊيڪس `mid` پاڻ انڊيڪس کان سواءِ) ۽ ٻئي ۾ `[mid, len)` (سڀ انڊيڪس `len` پاڻ انڊيڪس کان سواءِ) سڀ انڊيڪس شامل آهن.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // حفاظت: `[ptr; mid]` ۽ `[mid; len]` `self` اندر آهن ، جنهن
        // `from_raw_parts_mut` جي ضرورتن کي پورو ڪري ٿو.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// ھڪڙي انڊيڪس ۾ ھڪڙي ھڪڙي سليلي سلائس کي ٻن حصن ۾ ورهائي ٿو.
    ///
    /// پهرين ۾ `[0, mid)` کان سڀ انڊيڪس شامل ٿي وينديون (انڊيڪس `mid` پاڻ انڊيڪس کان سواءِ) ۽ ٻئي ۾ `[mid, len)` (سڀ انڊيڪس `len` پاڻ انڊيڪس کان سواءِ) سڀ انڊيڪس شامل آهن.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // حفاظت: `[ptr; mid]` ۽ `[mid; len]` `self` اندر آهن ، جنهن
        // `from_raw_parts_mut` جي ضرورتن کي پورو ڪري ٿو.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// حدن جي چڪاس ڪرڻ کانسواءِ ، هڪ سٽ هڪ انڊيڪس ۾ ٻن ۾ ورهائي ٿي.
    ///
    /// پهرين ۾ `[0, mid)` کان سڀ انڊيڪس شامل ٿي وينديون (انڊيڪس `mid` پاڻ انڊيڪس کان سواءِ) ۽ ٻئي ۾ `[mid, len)` (سڀ انڊيڪس `len` پاڻ انڊيڪس کان سواءِ) سڀ انڊيڪس شامل آهن.
    ///
    ///
    /// هڪ محفوظ متبادل لاءِ [`split_at`] ڏسو.
    ///
    /// # Safety
    ///
    /// انهي طريقي کي ٻاهرين حد تائين انڊيڪس سڏڻ *[اڻ بيان ٿيل رويو]* آهي جيتوڻيڪ نتيجو وارو حوالو استعمال نه ڪيو ويو آهي.ڪالر کي انهي ڳالهه کي يقيني بڻائڻو آهي ته `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // سافٽويئر: ڪالر کي چيڪ ڪرڻو پوندو ايڪسڪسيمڪس
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// هڪ چڪاس واري چڪاس کي ٻن ۾ انڊيڪس ۾ ورهائي ٿو ، بغير حدون چڪاس ڪرڻ جي.
    ///
    /// پهرين ۾ `[0, mid)` کان سڀ انڊيڪس شامل ٿي وينديون (انڊيڪس `mid` پاڻ انڊيڪس کان سواءِ) ۽ ٻئي ۾ `[mid, len)` (سڀ انڊيڪس `len` پاڻ انڊيڪس کان سواءِ) سڀ انڊيڪس شامل آهن.
    ///
    ///
    /// هڪ محفوظ متبادل لاءِ ڏسو [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// انهي طريقي کي ٻاهرين حد تائين انڊيڪس سڏڻ *[اڻ بيان ٿيل رويو]* آهي جيتوڻيڪ نتيجو وارو حوالو استعمال نه ڪيو ويو آهي.ڪالر کي انهي ڳالهه کي يقيني بڻائڻو آهي ته `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // سافٽويئر: ڪالر کي چيڪ ڪرڻو پوندو ايڪسڪسيمڪس.
        //
        // `[ptr; mid]` ۽ `[mid; len]` مٿي چڙهائي نه ٿيون آهن ، تنهنڪري هڪ بدل لائق ريفرنس واپس اچڻ ٺيڪ آهي.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// سبسڪرز مٿان ايريٽر کي واپس ڪري ٿو جيڪي جدا جدا عنصر آهن جيڪي `pred` سان ملن ٿيون.
    /// ملايو عنصر شامل آھي سبسڪرٽس ۾ نه.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// جيڪڏهن پهرين عنصر کي ملائي ويو آهي ، هڪ خالي سلائس انهي پهرين شيئرر طرفان واپس ٿي ويندي.
    /// اهڙي طرح ، جيڪڏهن ٻلي ۾ آخري عنصر ملائي رهي آهي ، هڪ خالي قميص اهو آخري سامان آهي جيڪو ٻيهر طرف ويندو آهي:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// جيڪڏهن ٻن ٺڳيل عناصر سڌي طرح سان جڙيل آهن ، انهن جي وچ ۾ خالي قليص موجود هوندي.
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// موٽندڙ مبلغ ذيلي ذخيري مٿان هڪ ورجاءُ کي واپس ڏئي ٿو جيڪي عناصر ڌار ڌار آهن جيڪي `pred` سان ملن ٿيون.
    /// ملايو عنصر شامل آھي سبسڪرٽس ۾ نه.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// سبسڪرز مٿان ايريٽر کي واپس ڪري ٿو جيڪي جدا جدا عنصر آهن جيڪي `pred` سان ملن ٿيون.
    /// ملائي عنصر گذريل سبسڪرپشن جي خاتمي ۾ هڪ ٽرمينٽر طور شامل ڪيو ويندو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// جيڪڏهن سليز جو آخري عنصر ملائي هجي ته اهو عنصر اڳئين ٻلي جو خاتمو تصور ڪيو ويندو.
    ///
    /// اهو سلائير آئيرر طرفان واپس ايندڙ آخري شيءَ هوندي.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// موٽندڙ مبلغ ذيلي ذخيري مٿان هڪ ورجاءُ کي واپس ڏئي ٿو جيڪي عناصر ڌار ڌار آهن جيڪي `pred` سان ملن ٿيون.
    /// ميلاپ ٿيل عنصر گذريل سبسڊي ۾ ٽرمينٽر طور شامل ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// سبسڪرس مٿان هڪ ورثيٽ موٽائيندو آهي ، جيڪي ايڪس ايڪس ايڪس سان ملن ٿا ، سلائس جي آخر ۾ شروع ۽ پوئتي ڪم ڪن ٿا.
    /// ملايو عنصر شامل آھي سبسڪرٽس ۾ نه.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// جيئن `split()` سان ، جيڪڏهن پهريون يا آخري عنصر مليل آهي ، هڪ خالي سلائس انهي ڪاررائيندڙ طرفان واپس ايندڙ پهرين (يا آخري) شيٽ هوندي.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// موٽندڙ ماتحت سبسڪرز مٿان هڪ ورثيٽ موٽائيندو آهي ، جيڪي ايڪس ايڪس ايڪس سان ملن ٿا ، سلائس جي آخر ۾ شروع ۽ پوئتي ڪم ڪن ٿا.
    /// ملايو عنصر شامل آھي سبسڪرٽس ۾ نه.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// سبسڪرس مٿان هڪ ورثيٽر موٽائيندو آهي ، جيڪي ايڪس ايڪس ايڪس سان ملن ٿا ، اڪثر `n` شيون تي موٽڻ تائين محدود آهن.
    /// ملايو عنصر شامل آھي سبسڪرٽس ۾ نه.
    ///
    /// آخري عنصر موٽي آيو ، جيڪڏھن ڪو آھي ، ته باقي سلائس تي مشتمل ھوندو.
    ///
    /// # Examples
    ///
    /// 3 نمبرن جي ترتيب سان نمبرن کي ورهائڻ واري سلائس کي پرنٽ ڪريو (يعني ، `[10, 40]` ، `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// سبسڪرس مٿان هڪ ورثيٽر موٽائيندو آهي ، جيڪي ايڪس ايڪس ايڪس سان ملن ٿا ، اڪثر `n` شيون تي موٽڻ تائين محدود آهن.
    /// ملايو عنصر شامل آھي سبسڪرٽس ۾ نه.
    ///
    /// آخري عنصر موٽي آيو ، جيڪڏھن ڪو آھي ، ته باقي سلائس تي مشتمل ھوندو.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// سبسڪس مٿان هڪ ورثيٽر موٽائيندو آهي جيڪي جدا جدا عناصر طرفان `pred` سان مماثل آهن جيڪي گهڻو ڪري `n` شيون موٽڻ تي محدود ٿين ٿيون.
    /// اهو ٻلي جي آخر ۾ شروع ٿيندو آهي ۽ پوئتي هلندو آهي.
    /// ملايو عنصر شامل آھي سبسڪرٽس ۾ نه.
    ///
    /// آخري عنصر موٽي آيو ، جيڪڏھن ڪو آھي ، ته باقي سلائس تي مشتمل ھوندو.
    ///
    /// # Examples
    ///
    /// هڪ ڀيرو سلائس کي ورهايو پرنٽ شروع ڪيو ، آخر کان ، نمبرن ذريعي ورهائيندڙ نمبرن سان 3 (يعني ، `[50]` ، `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// سبسڪس مٿان هڪ ورثيٽر موٽائيندو آهي جيڪي جدا جدا عناصر طرفان `pred` سان مماثل آهن جيڪي گهڻو ڪري `n` شيون موٽڻ تي محدود ٿين ٿيون.
    /// اهو ٻلي جي آخر ۾ شروع ٿيندو آهي ۽ پوئتي هلندو آهي.
    /// ملايو عنصر شامل آھي سبسڪرٽس ۾ نه.
    ///
    /// آخري عنصر موٽي آيو ، جيڪڏھن ڪو آھي ، ته باقي سلائس تي مشتمل ھوندو.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// ايڪس سلڪس واپسي کي ڏئي ٿو جيڪڏھن ٻلي ڏنل آھي ھڪڙي عنصر سان ڏنل قيمت سان.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// جيڪڏهن توهان وٽ هڪ `&T` ناهي ، پر صرف هڪ `&U` آهي ته `T: Borrow<U>` (مثال طور
    /// اسٽرنگ: قرض<str>) ، توهان `iter().any` استعمال ڪري سگهو ٿا:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // ايڪسڪسيمڪس جو ٽڪرو
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` سان ڳوليو
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// `true` ڏي ٿو جيڪڏھن `needle` ٻليءَ جو ھڪڙو پريڪس آھي.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// هميشه `true` موٽائي ٿو جيڪڏهن `needle` هڪ خالي سلائس آهي:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// `true` کي واپسي ڏئي ٿو جيڪڏهن `needle` سليڪس جو هڪ پريڪس آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// هميشه `true` موٽائي ٿو جيڪڏهن `needle` هڪ خالي سلائس آهي:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// پريفڪس کي ختم ٿيل ھڪڙي سبسڪرس کي واپس ڏئي ٿو.
    ///
    /// جيڪڏهن سلائس `prefix` سان شروع ٿئي ٿي ، اڳڪس کان پوءِ سبسڪرس کي واپس آڻي ٿي ، ايڪس آرڪس ۾ لپي وئي.
    /// جيڪڏهن `prefix` خالي آهي ، بس اصل سلائس کي واپس آڻيندا.
    ///
    /// جيڪڏهن سلائس `prefix` سان شروع نه ٿئي ، ايڪس سيڪس کي واپسي ڏئي ٿي.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // انهي فنڪشن کي ٻيهر لکڻ جي ضرورت پوندي جيڪڏهن ۽ جڏهن سليس پيٽرين وڌيڪ نفيس ٿي پون.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// ختم ٿيل لاحق سان گڏ سبسڪرس ڏي ٿو.
    ///
    /// جيڪڏهن سلائس `suffix` سان ختم ٿي وڃي ، سبڪسس کي واپس اچڻ کان اڳ موٽائي ٿو ، `Some` ۾ ويڙهيل.
    /// جيڪڏهن `suffix` خالي آهي ، بس اصل سلائس کي واپس آڻيندا.
    ///
    /// جيڪڏهن سلائس `suffix` سان ختم نه ٿئي ، ايڪس ايڪس ايڪس کي واپس ڪري ٿي.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // انهي فنڪشن کي ٻيهر لکڻ جي ضرورت پوندي جيڪڏهن ۽ جڏهن سليس پيٽرين وڌيڪ نفيس ٿي پون.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// بائنري ھڪڙي ڏنل عنصر لاء ھڪڙي ترتيب ڏنل سلائس ڳولي ٿو.
    ///
    /// جيڪڏهن ويليو ملي وڃي ته [`Result::Ok`] موٽيل آهي ، ملندڙ عنصر جي انڊيڪس تي مشتمل آهي.
    /// جيڪڏهن ڪيتريون ئي ميچون هجن ، ته ميچن مان ڪو به واپس ٿي سگهي ٿو.
    /// جيڪڏهن قدر نه ملي ته پوءِ [`Result::Err`] واپس اچي ويو ، انڊيڪس تي مشتمل آهي جتي هڪ مماثل عنصر داخل ٿي سگهيو آهي جڏهن ته ترتيب وار ترتيب برقرار رکيو وڃي.
    ///
    ///
    /// پڻ ڏسو [`binary_search_by`] ، [`binary_search_by_key`] ، ۽ [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ڏسڻ ۾ اچي ٿو چئن عنصرن جي هڪ سيريز.
    /// پهريون مليو آهي ، هڪ منفرد طور تي طئي ٿيل مقام سان.ٻيو ۽ ٽيون نه مليو آهيچوٿون `[1, 4]` ۾ ڪنهن به پوزيشن سان مائل ٿي سگهي ٿو.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// جيڪڏهن توهان ترتيب وار ترتيب برقرار رکڻ دوران ، ترتيب وار vector ۾ هڪ شيءِ داخل ڪرڻ چاهيو ٿا.
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// بائنري هڪ ترتيب ڏيندڙ فنڪشن سان هن ترتيب ڏنل سلائس کي ڳوليندو آهي.
    ///
    /// تقابلي فنڪشن ترتيب ڏنل سلائس جي ترتيب جي ترتيب سان مطابقت رکندڙ هڪ آرڊر کي لاڳو ڪرڻ گهرجي ، آرڊر ڪوڊ واپس ڏي ٿو جيڪو ظاهر ڪري ٿو ته انهي جو دليل `Less` ، `Equal` يا `Greater` گھربل حدف آهي.
    ///
    ///
    /// جيڪڏهن ويليو ملي وڃي ته [`Result::Ok`] موٽيل آهي ، ملندڙ عنصر جي انڊيڪس تي مشتمل آهي.جيڪڏهن ڪيتريون ئي ميچون هجن ، ته ميچن مان ڪو به واپس ٿي سگهي ٿو.
    /// جيڪڏهن قدر نه ملي ته پوءِ [`Result::Err`] واپس اچي ويو ، انڊيڪس تي مشتمل آهي جتي هڪ مماثل عنصر داخل ٿي سگهيو آهي جڏهن ته ترتيب وار ترتيب برقرار رکيو وڃي.
    ///
    /// پڻ ڏسو [`binary_search`] ، [`binary_search_by_key`] ، ۽ [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// ڏسڻ ۾ اچي ٿو چئن عنصرن جي هڪ سيريز.پهريون مليو آهي ، هڪ منفرد طور تي طئي ٿيل مقام سان.ٻيو ۽ ٽيون نه مليو آهيچوٿون `[1, 4]` ۾ ڪنهن به پوزيشن سان مائل ٿي سگهي ٿو.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // حفاظت: ڪالھ ھيٺ ڏنل جوابدارن کان محفوظ ٿي وئي آھي
            // - `mid >= 0`
            // - `mid < size`: `mid` وٽ محدود آھي `[left; right)` پابند
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // اسان ايڪس آرڪس ڪنٽرول فلو کي ميچ جي ڀيٽ ۾ استعمال ڪرڻ جو سبب ڇو ٿا ، ڇاڪاڻ ته ميچ ريئرنگ موازنہ آپريشنز ، جيڪو هڪ حساس آهي.
            //
            // هي x86 ايس ايم ايڪس ايڪس لاء آهي: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// بائنري اهم نموني ڪ functionڻ واري فنڪشن سان هن ترتيب ڏنل سلائس کي ڳوليندو آهي.
    ///
    /// فرض ڪري ٿو ته سليس ڪيئي ترتيب سان ترتيب ڏني وئي آهي ، مثال طور [`sort_by_key`] سان گڏ هڪ ئي اهم اضافي ڪم ذريعي.
    ///
    /// جيڪڏهن ويليو ملي وڃي ته [`Result::Ok`] موٽيل آهي ، ملندڙ عنصر جي انڊيڪس تي مشتمل آهي.
    /// جيڪڏهن ڪيتريون ئي ميچون هجن ، ته ميچن مان ڪو به واپس ٿي سگهي ٿو.
    /// جيڪڏهن قدر نه ملي ته پوءِ [`Result::Err`] واپس اچي ويو ، انڊيڪس تي مشتمل آهي جتي هڪ مماثل عنصر داخل ٿي سگهيو آهي جڏهن ته ترتيب وار ترتيب برقرار رکيو وڃي.
    ///
    ///
    /// پڻ ڏسو [`binary_search`] ، [`binary_search_by`] ، ۽ [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// انهن جي ٻئي عنصرن طرفان ترتيب ڏنل جوڑوں جي هڪ سلي ۾ چئن عنصرن جي هڪ سيريز کي ڏسجي ٿي.
    /// پهريون مليو آهي ، هڪ منفرد طور تي طئي ٿيل مقام سان.ٻيو ۽ ٽيون نه مليو آهيچوٿون `[1, 4]` ۾ ڪنهن به پوزيشن سان مائل ٿي سگهي ٿو.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links جي اجازت ڏني وئي آهي `slice::sort_by_key` crate `alloc` ۾ آهي ، ۽ ايڪسڪسيمڪس جي تعمير ڪرڻ دوران ايئن موجود ناهي.
    //
    // هيٺيون وهڪرو crate ڏانهن لنڪس: #74481.primitif صرف libstd (#73423) ۾ دستاويز ٿيل آهن ، انهي کي ڪڏهن به مشق ۾ ٽوڙي لنڪس طرف نه ٿو آڻي.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// سلائس کي ترتيب ڏيو ، پر شايد برابر عناصر جو نظم محفوظ نه ڪري سگھن.
    ///
    /// اهو قسم غير مستحڪم آهي (يعني ، برابر عناصر کي ٻيهر ترتيب ڏئي) ، جڳهه ۾ (يعني ، مختص نه ٿو ڪيو وڃي) ، ۽ *O*(*n*\*log(* n*)) بدترين حالت.
    ///
    /// # موجوده عمل درآمد
    ///
    /// موجوده الورورٿم [pattern-defeating quicksort][pdqsort] تي آرسن پيٽرس تي ٻڌل آهي ، جيڪا هاپسورٽ جي تيز ترين بدترين ڪيس سان بي ترتيب واري تيز رفتار واري اوسط ڪيس کي گڏ ڪري ٿي ، جڏهن خاص نمونن سان سلائسس تي لڪير وارو وقت حاصل ڪندي.
    /// اهو انحصار ڪندڙ ڪيسن کان بچڻ لاءِ ڪجهه بي ترتيب استعمال ڪندو آهي ، پر هڪ مقرر ٿيل seed سان هميشه طئي ٿيل رويي کي مهيا ڪرڻ لاءِ.
    ///
    /// اهو عام طور تي مستحڪم ترتيب ڏيڻ کان وڌيڪ تيز آهي ، ڪجهه خاص ڪيسن ۾ ، مثال طور ، جڏهن سلائس ڪيترن ئي ٺهيل ترتيب تي مشتمل آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// تقسيم واري فنڪشن سان سلائس کي ترتيب ڏيو ، پر برابر عنصرن جي نظم کي محفوظ نه ٿي ڪري سگهجي.
    ///
    /// اهو قسم غير مستحڪم آهي (يعني ، برابر عناصر کي ٻيهر ترتيب ڏئي) ، جڳهه ۾ (يعني ، مختص نه ٿو ڪيو وڃي) ، ۽ *O*(*n*\*log(* n*)) بدترين حالت.
    ///
    /// تقابلي فنڪشن سليس ۾ موجود عنصرن جي ڪل ترتيب ڏيڻ لازمي آهي.جيڪڏهن ترتيب مڪمل نه آهي ، عنصرن جي ترتيب اڻ ecاڻايل آهي.هڪ آرڊر ڪل آرڊر آهي جيڪڏهن اهو آهي (سڀ `a` ، `b` ۽ `c` لاءِ):
    ///
    /// * ڪل ۽ antimymmetric: ھڪڙو بلڪل `a < b` ، `a == b` يا `a > b` سچ آھي ، ۽
    /// * منتقلي ، `a < b` ۽ `b < c` مطلب `a < c`.ٻئي `==` ۽ `>` لاءِ ساڳيو ئي هئڻ لازمي آهي
    ///
    /// مثال طور ، جڏهن [`f64`] [`Ord`] تي عمل نٿو ڪري ، ڇاڪاڻ ته `NaN != NaN` ، اسان `partial_cmp` استعمال ڪري سگھوٿا اسان جي ترتيب ڏيڻ واري فنڪشن جي طور تي جڏهن اسان knowاڻون ٿا ته سلائس `NaN` تي مشتمل ناهي.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # موجوده عمل درآمد
    ///
    /// موجوده الورورٿم [pattern-defeating quicksort][pdqsort] تي آرسن پيٽرس تي ٻڌل آهي ، جيڪا هاپسورٽ جي تيز ترين بدترين ڪيس سان بي ترتيب واري تيز رفتار واري اوسط ڪيس کي گڏ ڪري ٿي ، جڏهن خاص نمونن سان سلائسس تي لڪير وارو وقت حاصل ڪندي.
    /// اهو انحصار ڪندڙ ڪيسن کان بچڻ لاءِ ڪجهه بي ترتيب استعمال ڪندو آهي ، پر هڪ مقرر ٿيل seed سان هميشه طئي ٿيل رويي کي مهيا ڪرڻ لاءِ.
    ///
    /// اهو عام طور تي مستحڪم ترتيب ڏيڻ کان وڌيڪ تيز آهي ، ڪجهه خاص ڪيسن ۾ ، مثال طور ، جڏهن سلائس ڪيترن ئي ٺهيل ترتيب تي مشتمل آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ريورس ترتيب ڏيڻ
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// سلائس کي اضافي نڪتي فنڪشن سان ترتيب ڏئي ٿو ، پر شايد برابر عنصرن جي نظم کي محفوظ نه ڪري سگهجي.
    ///
    /// هي قسم غير مستحڪم آهي (يعني ، برابر عناصر کي ٻيهر ترتيب ڏئي) ، جڳهه (يعني ، مختص نه ڪيو ويو) ، ۽ *O*(m\* * n *\* log(*n*)) بدترين حالت ، جتي ڪيلي فنڪشن آهي *O*(*ايم*).
    ///
    /// # موجوده عمل درآمد
    ///
    /// موجوده الورورٿم [pattern-defeating quicksort][pdqsort] تي آرسن پيٽرس تي ٻڌل آهي ، جيڪا هاپسورٽ جي تيز ترين بدترين ڪيس سان بي ترتيب واري تيز رفتار واري اوسط ڪيس کي گڏ ڪري ٿي ، جڏهن خاص نمونن سان سلائسس تي لڪير وارو وقت حاصل ڪندي.
    /// اهو انحصار ڪندڙ ڪيسن کان بچڻ لاءِ ڪجهه بي ترتيب استعمال ڪندو آهي ، پر هڪ مقرر ٿيل seed سان هميشه طئي ٿيل رويي کي مهيا ڪرڻ لاءِ.
    ///
    /// ان جي ڪالنگ حڪمت عملي جي ڪري ، ايڪس پيڪسڪس ڪيسن ۾ [`sort_by_cached_key`](#method.sort_by_cached_key) کان وڌيڪ سست ٿيڻ جو امڪان آهي جڏهن ته اهم فنڪشن مهانگو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// سليس کي ٻيهر ترتيب ڏيو ته عنصر `index` تي پنهنجي آخري ترتيب واري جڳهه تي آهي.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// تقسيم واري ڪارڪردگي سان سلائس کي ٻيهر ترتيب ڏيو ته عنصر `index` تي پنهنجي آخري ترتيب واري جڳهه تي آهي.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// سلائس کي ٻيهر ريلي ڪactionڻ واري فنڪشن سان ترتيب ڏيو ته ايڪس ايڪس اين ايڪس تي عنصر پنهنجي آخري ترتيب واري جڳهه تي آهي.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// سليس کي ٻيهر ترتيب ڏيو ته عنصر `index` تي پنهنجي آخري ترتيب واري جڳهه تي آهي.
    ///
    /// هن ترتيب ڏيڻ ۾ اها خاص ملڪيت آهي ته پوزيشن `i < index` تي ڪنهن به قيمت ايڪس ايڪس ايڪس ايڪس پوزيشن تي ڪنهن به قدر کان گهٽ يا برابر جي برابر هوندي.
    /// اضافي طور تي ، هي ترتيب ڏيڻ بي ترتيب آهي (يعني
    /// ڪي به برابر عنصر ختم ٿي سگھن ٿا پوزيشن `index`) ، جڳهه ۾ (يعني
    /// مختص نه ڪندو آهي) ، ۽ *اي*(*اين*) بدترين ڪيس.
    /// انهي فنڪشن کي "kth element" ٻين لائبريرين ۾ به سڃاتو وڃي ٿو.
    /// اهو هيٺين قدرن جو ٽڪر ٽڪر ڏي ٿو: ڏنل عنصر ڏنل انڊيڪس ۾ هڪ کان گهٽ ، ڏنل انڊيڪس تي ويليو ، ۽ ڏنل انڊيڪس تي هڪ کان وڌيڪ سڀ عنصر.
    ///
    ///
    /// # موجوده عمل درآمد
    ///
    /// موجوده الورگرافم [`sort_unstable`] لاءِ استعمال ڪيل ساڳيا تيز سڪرنڊ الگورٿم جي جلد چونڊيل حصي تي مشتمل آهي.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics جڏهن `index >= len()` ، مطلب اهو هميشه panics خالي سلائسس تي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // وچين ڳوليو
    /// v.select_nth_unstable(2);
    ///
    /// // اسان جي صرف ضمانت آهي ته سليس هڪ هيٺيان هوندي ، جنهن جي بنياد تي اسان مخصوص انڊيڪس بابت ترتيب ڏينداسين.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// تقسيم واري ڪارڪردگي سان سلائس کي ٻيهر ترتيب ڏيو ته عنصر `index` تي پنهنجي آخري ترتيب واري جڳهه تي آهي.
    ///
    /// اهو ترتيب ڏيڻ ۾ اضافي ملڪيت آهي ته ، ايڪس ريڪس ايڪس ايمڪس تي ڪنهن به قيمت ، موازنہ ڪارڪردگي استعمال ڪندي پوزيشن `j > index` تي ڪنهن به قيمت کان گهٽ يا برابر هوندو.
    /// اضافي طور تي ، هي ترتيب ڏيڻ غير مستحڪم آهي (يعني ڪو به جيترو برابر عنصر پوزيشن `index` تي ختم ٿي سگهي ٿو) ، جڳهه ۾ (يعني مختص نه ٿو ڪيو) ، ۽ *O*(*n*) بدترين حالت.
    /// انهي فنڪشن کي "kth element" ٻين لائبريرين ۾ پڻ سڃاتو وڃي ٿو.
    /// اها هيٺ ڏنل قدرن جي ٽن ٽولن کي واپس ڏئي ٿي: ڏنل عنصر ڏنل انڊيڪس ۾ هڪ کان گهٽ ، ڏنل انڊيڪس تي ويليو ، ۽ ڏنل انڊيڪس تي هڪ کان وڌيڪ تمام عنصر ، مهيا ڪيل تقابلي فنڪشن کي استعمال ڪندي.
    ///
    ///
    /// # موجوده عمل درآمد
    ///
    /// موجوده الورگرافم [`sort_unstable`] لاءِ استعمال ڪيل ساڳيا تيز سڪرنڊ الگورٿم جي جلد چونڊيل حصي تي مشتمل آهي.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics جڏهن `index >= len()` ، مطلب اهو هميشه panics خالي سلائسس تي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ميڊين ڳوليو theڻ سليس کي ترتيب سان ترتيب ۾ ترتيب ڏنو وڃي.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // اسان جي صرف ضمانت آهي ته سليس هڪ هيٺيان هوندي ، جنهن جي بنياد تي اسان مخصوص انڊيڪس بابت ترتيب ڏينداسين.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// سلائس کي ٻيهر ريلي ڪactionڻ واري فنڪشن سان ترتيب ڏيو ته ايڪس ايڪس اين ايڪس تي عنصر پنهنجي آخري ترتيب واري جڳهه تي آهي.
    ///
    /// هن ترتيب ڏيڻ ۾ اضافي ملڪيت آهي ته ، ايڪس ريڪس ايڪس ايمڪس تي ڪنهن به قيمت ، ايڪسينڪس پوزيشن تي ڪنهن به قدر کان گهٽ يا برابر جي اهم نڪتل فنڪشن کي استعمال ڪندي.
    /// اضافي طور تي ، هي ترتيب ڏيڻ غير مستحڪم آهي (يعني ڪو به جيترو برابر عنصر پوزيشن `index` تي ختم ٿي سگهي ٿو) ، جڳهه ۾ (يعني مختص نه ٿو ڪيو) ، ۽ *O*(*n*) بدترين حالت.
    /// انهي فنڪشن کي "kth element" ٻين لائبريرين ۾ پڻ سڃاتو وڃي ٿو.
    /// اها هيٺ ڏنل قدرن جي ٽن ٽولي ڏي ٿو: ڏنل عنصر ڏنل انڊيڪس ۾ هڪ کان گهٽ ، ڏنل انڊيڪس تي ويليو ، ۽ ڏنل انڊيڪس تي هڪ کان وڌيڪ تمام عنصر ، مهيا ڪيل اهم ڪ keyڻ وارو فنڪشن.
    ///
    ///
    /// # موجوده عمل درآمد
    ///
    /// موجوده الورگرافم [`sort_unstable`] لاءِ استعمال ڪيل ساڳيا تيز سڪرنڊ الگورٿم جي جلد چونڊيل حصي تي مشتمل آهي.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics جڏهن `index >= len()` ، مطلب اهو هميشه panics خالي سلائسس تي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ميڊين موٽايو theڻ ته صف پوري قدر جي حساب سان ترتيب ڏنل آهي.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // اسان جي صرف ضمانت آهي ته سليس هڪ هيٺيان هوندي ، جنهن جي بنياد تي اسان مخصوص انڊيڪس بابت ترتيب ڏينداسين.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// سڀني لڳاتار بار بار عناصر کي سلائيز جي آخر ۾ منتقل ڪري ٿو [`PartialEq`] trait عمل مطابق.
    ///
    ///
    /// ٻه سلائسون ڏياري ٿو.پهرين ۾ مسلسل بار بار شامل نه آھن عنصر.
    /// ٻيو ڪنهن مخصوص حڪم ۾ تمام نقل نه هوندو آهي.
    ///
    /// جيڪڏهن سلائس کي ترتيب ڏني وڃي ، پهرين موٽڻ واري ٻلي ۾ ڪو به نقل نه آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// سڀني کي منتقل ڪري ٿو پر لاڳيتو پهرين ساڳيو سلائيس جي آخر تائين هڪ ڏنل مساوات جي رشتي کي مطمئن ڪندڙ.
    ///
    /// ٻه سلائسون ڏياري ٿو.پهرين ۾ مسلسل بار بار شامل نه آھن عنصر.
    /// ٻيو ڪنهن مخصوص حڪم ۾ تمام نقل نه هوندو آهي.
    ///
    /// `same_bucket` فنڪشن سلائس مان ٻن عنصرن جي حوالي ڪئي وئي آهي ۽ طئي ڪرڻ گهرجي ته جيڪڏهن عنصر برابر هجن.
    /// عناصر سليس ۾ انهن جي ترتيب جي مخالف ترتيب سان پاس ڪيا ويا ، تنهن ڪري جيڪڏهن `same_bucket(a, b)` ڏي00 `true` موٽائي ، `a` سلائيس جي آخر ۾ منتقل ڪئي وڃي.
    ///
    ///
    /// جيڪڏهن سلائس کي ترتيب ڏني وڃي ، پهرين موٽڻ واري ٻلي ۾ ڪو به نقل نه آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // جيتوڻيڪ اسان وٽ `self` جي لاءِ هڪ قابل بدل حوالو آهي ، پر اسان *ثالث* تبديليون نٿا ڪري سگهون.ايڪسڪسيمڪس ڪالز panic ٿي سگھن ٿيون ، تنھنڪري اسان کي يقيني بڻائڻ گھرجي ته سلائيز ھر وقت صحيح حالت ۾ آھي.
        //
        // اهو طريقو جيڪو اسان سنڀالينداسين اهو استعمال ڪندي آهياسان سڀني عنصرن جي مٿان انحصار ڪريون ٿا ، جئين وڃڻ ٿيو وڃان ٿا ته آخرڪار اهي عنصر جيڪي اسان رکڻ چاهيندا آهن سامهون آهن ، ۽ جن کي اسان رد ڪرڻ چاهيون ٿا اهي پويان آهن.
        // اسان وري سليس کي ورهائي سگهون ٿا.
        // اهو آپريشن اڃا تائين `O(n)` آهي.
        //
        // مثال: اسان هن رياست ۾ شروع ڪريون ٿا ، جتي `r` اڳيون `جي نمائندگي ڪري ٿو
        // پڙهايو "۽ ايڪسڪسيمڪس" اڳيان_ لکڻ "جي نمائندگي ڪري ٿو.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // self[r] خود [w-1] جي خلاف مقابلو ڪرڻ ، اهو نقل ناهي ، تنهن ڪري اسان self[r] ۽ self[w] کي تبادلو ڪريو (اثر انداز ناهي r==w) ۽ پوءِ ٻئي r ۽ w کي وڌايو ، اسان کي هن سان ڇڏڻ:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] خود [w-1] جي خلاف مقابلو ڪرڻ ، اهو قيمت نقل آهي ، تنهن ڪري اسان `r` وڌايو ٿا پر هر شي کي تبديل نه ڪيو:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] جو مقابلو خود [w-1] جي مقابلي ۾ ، اهو نقل ناهي ، تنهن ڪري مٽايو self[r] ۽ self[w] ۽ اڳوڻو r ۽ w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // ٻيڻو نه ، ورجايو:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // نقل ، ٻلي جي advance r. End.w تي اٿل.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // حفاظت: `while` شرط `next_read` ۽ `next_write` جي ضمانت ڏئي ٿي
        // `len` کان گھٽ آھن ، اھڙي طرح `self` اندر آھن.
        // `prev_ptr_write` `ptr_write` کان پهريان هڪ عنصر ڏانهن اشارو ڪيو ، پر `next_write` 1 کان شروع ٿئي ٿو ، تنهن ڪري `prev_ptr_write` ڪڏهن به 0 کان گهٽ ناهي ۽ سلائس اندر آهي.
        // اهو `ptr_read` ، `prev_ptr_write` ۽ `ptr_write` کي ختم ڪرڻ جي ضرورتن کي پورو ڪري ٿو ، ۽ `ptr.add(next_read)` ، `ptr.add(next_write - 1)` ۽ `prev_ptr_write.offset(1)` کي استعمال ڪرڻ لاءِ.
        //
        //
        // `next_write` اهو پڻ وڌ ۾ وڌ هڪ ڀيرو وڌايل آهي وڌ ۾ وڌ گهڻن معنى ۾ ڪو عنصر ناهي ڇڏي ويو جڏهن ان کي مٽائڻ جي ضرورت آهي.
        //
        // `ptr_read` ۽ `prev_ptr_write` ڪڏهن به ساڳيو عنصر ڏانهن اشارو نٿو ڪري.انهي لاءِ `&mut *ptr_read` ، `&mut* prev_ptr_write` محفوظ ٿيڻ گهربل آهي.
        // وضاحت صرف اهو آهي ته `next_read >= next_write` هميشه صحيح آهي ، اهڙي طرح `next_read > next_write - 1` به آهي.
        //
        //
        //
        //
        //
        unsafe {
            // خام پوائنٽرن کي استعمال ڪندي حد جي چڪاس کان پاسو ڪريو.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// سڀني کي منتقل ڪري ٿو پر لاڳيتو پهرين عناصر کي سلائس جي آخر ۾ جيڪا ساڳي ڪيٻي کي حل ڪيو وڃي.
    ///
    ///
    /// ٻه سلائسون ڏياري ٿو.پهرين ۾ مسلسل بار بار شامل نه آھن عنصر.
    /// ٻيو ڪنهن مخصوص حڪم ۾ تمام نقل نه هوندو آهي.
    ///
    /// جيڪڏهن سلائس کي ترتيب ڏني وڃي ، پهرين موٽڻ واري ٻلي ۾ ڪو به نقل نه آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// سلائس کي جڳھ تي گھمائيندو آھي ته سليس جي پھرين `mid` عناصر آخري طرف منتقل ڪن ٿا جڏھن ته آخري `self.len() - mid` عناصر مئٽرڪ ڏانھن منتقل ڪن ٿا.
    /// `rotate_left` کي ڪال ڪرڻ کان پوءِ ، آرٽيڪل `mid` کان پھريائين جو عنصر سليس ۾ پهريون عنصر بڻجي ويندو.
    ///
    /// # Panics
    ///
    /// اهو ڪم panic ٿيندو جيڪڏهن `mid` سلائس جي ڊيگهه کان وڌيڪ آهي.ياد رکو ته `mid == self.len()` _not_ panic ڪندو آهي ۽ ڪو او پي گردش آهي.
    ///
    /// # Complexity
    ///
    /// لڪير وٺندو آهي (`self.len()`) وقت ۾.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// هڪ ذيلي ذخيرو گھمڻ:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // سافٽويئر: رينج `[p.add(mid) - mid, p.add(mid) + k)` عارضي طور تي آهي
        // پڙهڻ ۽ لکڻ لاءِ صحيح ، جيترو `ptr_rotate` جي گھربل آهي.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// سلائس کي جڳھ تي گھمائيندو آھي ته سليس جي پھرين `self.len() - k` عناصر آخري طرف منتقل ڪن ٿا جڏھن ته آخري `k` عناصر مئٽرڪ ڏانھن منتقل ڪن ٿا.
    /// `rotate_right` کي ڪال ڪرڻ کان پوءِ ، آرٽيڪل `self.len() - k` کان پھريائين جو عنصر سليس ۾ پهريون عنصر بڻجي ويندو.
    ///
    /// # Panics
    ///
    /// اهو ڪم panic ٿيندو جيڪڏهن `k` سلائس جي ڊيگهه کان وڌيڪ آهي.ياد رکو ته `k == self.len()` _not_ panic ڪندو آهي ۽ ڪو او پي گردش آهي.
    ///
    /// # Complexity
    ///
    /// لڪير وٺندو آهي (`self.len()`) وقت ۾.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// ذيلي ذخيرو گھرايو:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // سافٽويئر: رينج `[p.add(mid) - mid, p.add(mid) + k)` عارضي طور تي آهي
        // پڙهڻ ۽ لکڻ لاءِ صحيح ، جيترو `ptr_rotate` جي گھربل آهي.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// ايڪس پيڪس کي کلون ڪري `self` عنصرن سان ڀريل آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// بار بار ھڪڙي بندش کي ڪال ڪندي واپس موٽندڙ عناصر سان `self` ڀريل آھي.
    ///
    /// اهو طريقو بندش استعمال ڪري ٿو نئين قدرن کي ٺاهڻ لاءِ.جيڪڏهن توهان پسند ڪيو ٿا [`Clone`] ڏنل قيمت ، استعمال ڪريو [`fill`]
    /// جيڪڏهن توهان قدر پيدا ڪرڻ لاءِ [`Default`] trait استعمال ڪرڻ چاهيو ٿا ، توهان دليل طور [`Default::default`] پاس ڪري سگهو ٿا.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src` کان عناصر `self` ۾ نقل ڪري ٿو.
    ///
    /// `src` جي ڊيگهه `self` وانگر ساڳيو هجڻ گهرجي.
    ///
    /// جيڪڏهن `T` `Copy` لاڳو ڪري ، ان کي [`copy_from_slice`] استعمال ڪرڻ وڌيڪ ڪارائتو ٿي سگهي ٿو.
    ///
    /// # Panics
    ///
    /// اهو ڪم panic ٿيندو جيڪڏهن ٻن سلائسون مختلف لمبائي آهن.
    ///
    /// # Examples
    ///
    /// ٻٻر کي سولي کان ٻن عنصرن ۾ آڻڻ.
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // ڇو ته سلائسن جي ساڳي ڊيگهه هجڻ گهرجي ، اسان ماخذ سلائس کي چئن عنصرن ٻن کان ڪٽي ڇڏيو.
    /// // جيڪڏهن اسان اهو نه ڪندا ته اهو panic هوندو.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust انهي کي لاڳو ڪري ٿو ته هتي صرف هڪ مٽاسٽا حوالو ٿي سگهي ٿو جنهن ۾ ڪنهن خاص دائري ۾ ڊيٽا جي مخصوص ٽڪڙي جي اڻ مٽ ريفرنس سان.
    /// انهي جي ڪري ، ايڪس سلڪس کي هڪ سلائس تي استعمال ڪرڻ جي ڪوشش ڪرڻ جو نتيجو ناڪامي جي نتيجي ۾ ٿيندو.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// هن جي چوڌاري ڪم ڪرڻ لاءِ ، اسين [`split_at_mut`] استعمال ڪري سگھون ٿا ته هڪ سلائس مان ٻه الڳ ذيلي سلائسون ٺاهي سگھون:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// سڀني عنصرن `src` کان `self` ۾ نقل ڪري ٿو ، هڪ ماتم استعمال ڪندي.
    ///
    /// `src` جي ڊيگهه `self` وانگر ساڳيو هجڻ گهرجي.
    ///
    /// جيڪڏهن `T` `Copy` لاڳو نٿو ڪري ، [`clone_from_slice`] استعمال ڪريو.
    ///
    /// # Panics
    ///
    /// اهو ڪم panic ٿيندو جيڪڏهن ٻن سلائسون مختلف لمبائي آهن.
    ///
    /// # Examples
    ///
    /// ٻه عناصر کي سلائس کان ٻئي ۾ نقل ڪندي:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // ڇو ته سلائسن جي ساڳي ڊيگهه هجڻ گهرجي ، اسان ماخذ سلائس کي چئن عنصرن ٻن کان ڪٽي ڇڏيو.
    /// // جيڪڏهن اسان اهو نه ڪندا ته اهو panic هوندو.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust انهي کي لاڳو ڪري ٿو ته هتي صرف هڪ مٽاسٽا حوالو ٿي سگهي ٿو جنهن ۾ ڪنهن خاص دائري ۾ ڊيٽا جي مخصوص ٽڪڙي جي اڻ مٽ ريفرنس سان.
    /// انهي جي ڪري ، ايڪس سلڪس کي هڪ سلائس تي استعمال ڪرڻ جي ڪوشش ڪرڻ جو نتيجو ناڪامي جي نتيجي ۾ ٿيندو.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// هن جي چوڌاري ڪم ڪرڻ لاءِ ، اسين [`split_at_mut`] استعمال ڪري سگھون ٿا ته هڪ سلائس مان ٻه الڳ ذيلي سلائسون ٺاهي سگھون:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // ڪال سائيٽ کي فليٽ نه ڪرڻ لاءِ panic ڪوڊ جو رستو ٿڌو ٿي ويو.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // حفاظت: `self` تعريف جي لحاظ کان `self.len()` عناصر لاءِ صحيح آھي ، ۽ `src` ھئي
        // ساڳي ڊيگهه هجڻ جي جانچ ڪئي وئي آهي.
        // سلائسون مٿي چڙهائي نٿي سگھن ٿيون ڇاڪاڻ ته تبديل ٿيندڙ حوالا خاص آهن.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// سلائس جي هڪ حصي کان عناصر پاڻ کي ٻئي حصي ڏانهن نقل ڪري ٿو ، ميمووم استعمال ڪندي.
    ///
    /// `src` ڪاپي ڪرڻ لاءِ `self` جي اندر حد آهي.
    /// `dest` ڪاپي ڪرڻ لاءِ `self` جي اندر رينج جي شروعاتي انڊيڪس آهي ، جنهن جي `src` جيتري ڊيگهه هوندي.
    /// ٻن حدن جي مٿان چڙھي سگھي ٿي.
    /// ٻن حدن جي پڇاڙيء کي `self.len()` کان گهٽ يا برابر هجڻ گهرجي.
    ///
    /// # Panics
    ///
    /// اهو فنڪشن panic ٿيندو جيڪڏهن يا ته سليس جي آخر جي حد کان وڌي وڃي ٿو ، يا جيڪڏهن `src` جي پڇاڙي شروعات کان اڳ آهي.
    ///
    ///
    /// # Examples
    ///
    /// چار بائٽس کي سلائس اندر نقل ڪندي:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // حفاظت: `ptr::copy` لاءِ حالتون مٿي چڪاس ڪيون ويون آهن ،
        // جيئن `ptr::add` لاء اهي آهن.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `other` ۾ سڀني عناصر کي `other` ۾ تبديل ڪري ٿو.
    ///
    /// `other` جي ڊيگهه `self` وانگر ساڳيو هجڻ گهرجي.
    ///
    /// # Panics
    ///
    /// اهو ڪم panic ٿيندو جيڪڏهن ٻن سلائسون مختلف لمبائي آهن.
    ///
    /// # Example
    ///
    /// ٻن عناصر کي سليس ۾ تبديل ڪرڻ:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust انهي کي لاڳو ڪري ٿو ته صرف هڪ خاص موڙ ۾ ڊيٽا جي مخصوص ٽڪڙي جو هڪ قابل بدل حوالو ٿي سگهي ٿو.
    ///
    /// انهي جي ڪري ، ايڪس سلڪس کي هڪ سلائس تي استعمال ڪرڻ جي ڪوشش ڪرڻ جو نتيجو ناڪامي جي نتيجي ۾ ٿيندو.
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// هن جي چوڌاري ڪم ڪرڻ لاءِ ، اسان [`split_at_mut`] استعمال ڪري سگھون ٿا ته ٻه سلائيز کان ٻه الڳ قابل بدل بدل ذيلي سلائسون.
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // حفاظت: `self` تعريف جي لحاظ کان `self.len()` عناصر لاءِ صحيح آھي ، ۽ `src` ھئي
        // ساڳي ڊيگهه هجڻ جي جانچ ڪئي وئي آهي.
        // سلائسون مٿي چڙهائي نٿي سگھن ٿيون ڇاڪاڻ ته تبديل ٿيندڙ حوالا خاص آهن.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}` لاء وچين ڊگهن ۽ پيچرن واري سلسلن جي حساب کي ڪم ڪرڻ جي فنڪشن.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // `rest` بابت اسان ڇا ڪرڻ جي ڪوشش ڪنداسين اهو outاڻون ٿا ته ڪيترا يوس اسان تمام گهٽ ڪري سگهون ٿا.
        //
        // ۽ اسان جي هر اهڙي "multiple" لاءِ ڪيترو `T` گهربل آهي.
        //
        // مثال طور غور ڪريو T=u8 U=u16.پوء اسان 1 U 2 Ts ۾ وجهي سگهون ٿا.سادو.
        // ھاڻي ، مثال جي طور تي ھڪڙي ڪيس تي غور ڪريو جتي size_of: :<T>=16 ، سائيز_of::<U>=24.</u>
        // اسان `rest` سلائس ۾ هر 3 ٽ جي جاء تي 2 اسان کي رکي سگهو ٿا.
        // ھڪڙو وڌيڪ پيچيده.
        //
        // انهي کي حساب ڏيڻ لاءِ فارمولا هي آهي:
        //
        // اسان= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // وڌايل ۽ سادگي:
        //
        // اسان=سائيز_ف: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=سائيز_ف::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // خوش قسمت ، ڇاڪاڻ ته اهو سڀ ڪجهه مسلسل جائزو ورتو ويندو آهي ... ڪارڪردگي هتي اهم ناهي.
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // هلندڙ اسٽائن جي الگورتھم اسان کي اڃا هي `const fn` ٺاهڻ گهرجي (۽ ٻيهر ڪرڻ واري الورجيٿم کي جيڪڏهن اسان ڪيو وڃي) ڇاڪاڻ ته lvvm تي ڀروسو ڪرڻ اهو سڀ ڪجهه قائم رکڻ لاءِ آهي…چ wellو ، هي مونکي نااهل بڻائي ٿو.
            //
            //

            // حفاظت: `a` ۽ `b` غير صفر قدر هجڻ جي چڪاس ڪئي وئي آھي.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // 2 مان سڀ عنصر ڪ bي ڇڏيو ب
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // حفاظت: `b` غير صفر ٿيڻ جي چڪاس ڪئي وئي آھي.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // هن علم سان هٿياربند ، اسان ڳولي سگهون ته اسان ڪيترو "اسان صحيح هوندا!
        let us_len = self.len() / ts * us;
        // ۽ ڪيترو "T`s پويان واري سلائي ۾ هوندو!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// سليس کي ڪنهن ٻئي قسم جي سلائيس ۾ منتقل ڪريو ، يقيني بڻائڻ ته قسمن جي ترتيب برقرار آهي.
    ///
    /// اھو طريقو سليس کي ٽن الڳ سلائسن ۾ ورهائي ٿو: پريفڪس ، نئين قسم جي وچ ۾ صحيح سلائي ۽ صحيح لاھور.
    /// طريقو وچولي سلائس کي ممڪن طور تي ڏنل قسم ۽ ان پٽ سليس جي وڏي ممڪن بڻائي سگھي ٿو ، پر صرف توهان جي الگورٿم جي ڪارڪردگي ان تي ڀاڙڻ گهرجي ، نه ان جي درستگي.
    ///
    /// ان پتي جي سڀني ڊيٽا کي اجازت ڏني وڃي ته اڳئين يا لاحقه سلائس جي طور تي واپس اچجن.
    ///
    /// هن طريقي جو ڪوبه مقصد ناهي جڏهن يا ته انپٽ عنصر `T` يا آئوٽ عنصر `U` صفر سائيز وارا آهن ۽ ڪجهه ورهائڻ کانسواءِ اصل سلائس واپس آڻيندا.
    ///
    /// # Safety
    ///
    /// هي طريقو لازمي طور تي واپسي وچولي سلائس ۾ موجود عنصرن جي حوالي سان `transmute` آهي ، تنهنڪري `transmute::<T, U>` سان لاڳاپيل سڀئي معمولي احاطا هتي پڻ لاڳو ٿين ٿا.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // ياد رکجو ته ھن فنڪشن جو اڪثر جائزو ورتو ويندو ،
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // خاص طور تي ZSTs سنڀاليو ، جيڪو آهي-انهن کي بلڪل هٿ ۾ نه رکو.
            return (self, &[], &[]);
        }

        // پهرين ، ڳوليو ته اسين پهرين ۽ ٻئي سلائس جي وچ ۾ ڇا ورهايو ٿا.
        // ايڪسڪسيمڪس سان آسان.
        let ptr = self.as_ptr();
        // حفاظت: تفصيلي حفاظت واري تبصري جي لاءِ `align_to_mut` طريقو ڏسو.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // حفاظت: هاڻ `rest` يقيني طور تي گڏ ڪيو ويو آهي ، تنهن ڪري هيٺ ڏنل `from_raw_parts` ٺيڪ آهي ،
            // کان وٺي سڏيندڙ ضمانت ڏي ٿو ته اسان محفوظ طور تي `T` کان `U` منتقل ڪري سگهون ٿا.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// سليس کي ڪنهن ٻئي قسم جي سلائيس ۾ منتقل ڪريو ، يقيني بڻائڻ ته قسمن جي ترتيب برقرار آهي.
    ///
    /// اھو طريقو سليس کي ٽن الڳ سلائسن ۾ ورهائي ٿو: پريفڪس ، نئين قسم جي وچ ۾ صحيح سلائي ۽ صحيح لاھور.
    /// طريقو وچولي سلائس کي ممڪن طور تي ڏنل قسم ۽ ان پٽ سليس جي وڏي ممڪن بڻائي سگھي ٿو ، پر صرف توهان جي الگورٿم جي ڪارڪردگي ان تي ڀاڙڻ گهرجي ، نه ان جي درستگي.
    ///
    /// ان پتي جي سڀني ڊيٽا کي اجازت ڏني وڃي ته اڳئين يا لاحقه سلائس جي طور تي واپس اچجن.
    ///
    /// هن طريقي جو ڪوبه مقصد ناهي جڏهن يا ته انپٽ عنصر `T` يا آئوٽ عنصر `U` صفر سائيز وارا آهن ۽ ڪجهه ورهائڻ کانسواءِ اصل سلائس واپس آڻيندا.
    ///
    /// # Safety
    ///
    /// هي طريقو لازمي طور تي واپسي وچولي سلائس ۾ موجود عنصرن جي حوالي سان `transmute` آهي ، تنهنڪري `transmute::<T, U>` سان لاڳاپيل سڀئي معمولي احاطا هتي پڻ لاڳو ٿين ٿا.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // ياد رکجو ته ھن فنڪشن جو اڪثر جائزو ورتو ويندو ،
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // خاص طور تي ZSTs سنڀاليو ، جيڪو آهي-انهن کي بلڪل هٿ ۾ نه رکو.
            return (self, &mut [], &mut []);
        }

        // پهرين ، ڳوليو ته اسين پهرين ۽ ٻئي سلائس جي وچ ۾ ڇا ورهايو ٿا.
        // ايڪسڪسيمڪس سان آسان.
        let ptr = self.as_ptr();
        // حفاظت: هتي اسان کي يقيني بڻايون ته اسان يو لاءِ ايلڪنڊ پوائنٽر استعمال ڪنداسين
        // باقي طريقو.اهو پوائنٽر طرف ڪرڻ سان ۽ [T] ذريعي ترتيب ڏيڻ سان ڪيو ويندو آهي يو.
        // `crate::ptr::align_offset` هڪ صحيح ترتيب سان ۽ صحيح پوائنٽر سان سڏيو وڃي ٿو `ptr` (اهو `self` جي حوالي سان اچي ٿو) ۽ هڪ سائيز سان جيڪو ٻن جي طاقت آهي (ڇاڪاڻ ته اهو يو جي ترتيب مان اچي ٿو) ، هن جي حفاظت جي رڪاوٽن کي پورو ڪري.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // اسان انهي کان پوءِ ٻيهر `rest` استعمال نٿا ڪري سگهون ، اهو ان جي عرف `mut_ptr` کي باطل ڪري ڇڏيندو!حفاظت: `align_to` لاءِ تبصرا ڏسو.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// چيڪ ڪريو ته ڇا هن سلائس جي عنصرن کي ترتيب ڏنو وڃي ٿو.
    ///
    /// اھو آھي ، ھر عنصر `a` ۽ ان جي ھيٺان عنصر `b` لاءِ ، `a <= b` ضرور رکي ٿو.جيڪڏهن سلائس بلڪل صفر يا هڪ عنصر پيدا ڪري ، `true` واپس ٿي وڃي.
    ///
    /// ياد رکو ته جيڪڏهن `Self::Item` صرف `PartialOrd` آهي ، پر `Ord` نه ، مٿي ڏنل تعريف مان پتو پوي ٿو ته اهو فنڪشن `false` موٽائي ٿو جيڪڏهن ٻه مسلسل لڳل شيون برابر نه هجن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// چيڪ ڪريو ته جيڪڏهن هن ٻلي جا عنصر ڏنل موازنہ واري فنڪشن کي ترتيب ڏني وڃي.
    ///
    /// `PartialOrd::partial_cmp` استعمال ڪرڻ بدران ، اهو فنڪشن ڏنو ويو `compare` فنڪشن کي ٻن عنصرن جي ترتيب جو تعين ڪرڻ لاءِ.
    /// ان کان سواء ، اهو برابر آهي [`is_sorted`]؛وڌيڪ forاڻ لاءِ ان جو دستاويز ڏسو.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// چيڪ ڪريو ته جيڪڏهن هن سلائس جي عناصر ڏنل ڏنل ڪ extrڻ واري فنڪشن کي استعمال ڪندي ترتيب ڏني وڃي.
    ///
    /// سليس جي عناصرن کي سڌي طرح سان مقابلو ڪرڻ بدران ، هي ڪم عناصر جي چاٻي کي برابر ڪري ٿو ، جئين `f` طئي ٿيل آهي.
    /// ان کان سواء ، اهو برابر آهي [`is_sorted`]؛وڌيڪ forاڻ لاءِ ان جو دستاويز ڏسو.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// ورها partي واري نقطي جي انڊيڪس ڏنل ڏنل اڳڪٿي مطابق موٽائي ٿو (پهرين ورها elementي جي پهرين عنصر جي فهرست)
    ///
    /// سليس ۾ ڏنل ملڪيت جي مطابق ورهايل فرض ڪيو ويندو آهي.
    /// هن جو مطلب آهي ته اهي سمورا عنصر جنهن لاءِ پراٽيڪٽس موٽڻ صحيح آهي سليس جي شروعات تي آهن ۽ سڀ عنصر جنهن لاءِ غلط اڳرائي موٽندي آهي آخر ۾ آهن.
    ///
    /// مثال طور ، [7, 15, 3, 5, 4, 12, 6] اڳڪٿي تحت ورهايل آهي x٪ 2!=0 (تمام بي جوڙ نمبر شروعات ۾ آهن ، تمام آخر ۾ به).
    ///
    /// جيڪڏهن هن سلائس کي ورها notي ۾ نه ڏجي ته واپسي وارو نتيجو اڻ تصديق ٿيل ۽ بي معنيٰ آهي ، جئين اهو طريقو هڪ قسم جي بائنري ڳولا کي انجام ڏئي.
    ///
    /// پڻ ڏسو [`binary_search`] ، [`binary_search_by`] ، ۽ [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // حفاظت: جڏهن `left < right` ، `left <= mid < right`.
            // ان ڪري `left` هميشه وڌي ٿو ۽ `right` هميشه گهٽجي ٿو ، ۽ انهن مان ٻن کي به چونڊيو ويندو آهي.ٻنهي صورتن ۾ `left <= right` مطمئن آهي.ان ڪري جيڪڏهن `left < right` هڪ قدم ۾ ، `left <= right` ايندڙ قدم ۾ مطمئن آهي.
            //
            // ان ڪري جيستائين جيستائين `left != right` ، `0 <= left < right <= len` مطمئن آهي ۽ جيڪڏهن اهو ڪيس `0 <= mid < len` به مطمئن آهي.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: اسان کي انهن کي ساڳئي لمبائي تي واضح طور تي سلائي ڪرڻ جي ضرورت آهي
        // حدون چڪاس ڪرڻ لاءِ ڀائيچاري کي آسان ڪرڻ لاءِ
        // پر جيئن اھو ڀروسو نٿي ڪري سگھجي اسان وٽ ٽي لاءِ ڪا خاص اسپيشلائيزيشن آھي: ڪاپي.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// خالي سلائسون ٺاهي ٿو.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// هڪ بدلي واري slاٽي سليس ٺاهي ٿي.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// سلائسون ۾ نمونو ، في الحال ، صرف `strip_prefix` ۽ `strip_suffix` طرفان استعمال ٿيل.
/// future پوائنٽ تي ، اسان اميد رکون ٿا ته عام طور تي `core::str::Pattern` (جيڪو لکڻ جي وقت تي `str` تائين محدود آهي) سلائسس ڏانهن ، ۽ پوء اهو trait تبديل ڪيو ويندو يا ختم ڪيو ويندو.
///
pub trait SlicePattern {
    /// سلائس جو عنصر قسم ملائي رهيو آهي.
    type Item;

    /// ان وقت ايڪس ايڪس ايڪس جي استعمال ڪندڙن کي سليس جي ضرورت آهي.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}