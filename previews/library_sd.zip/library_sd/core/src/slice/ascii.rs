//! ASCII `[u8]` تي آپريشن.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// انهي چڪاس ۾ جيڪڏهن بائٽس تمام ASCII حد ۾ آهن.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// چيڪ ڪري ٿو ته ٻه سلائسون هڪ اي ايس سي آئي آئي ڪيس جي غير جانبدار ميچ آهن.
    ///
    /// ساڳي طرح `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ، پر عارضي طور تي مختص ڪرڻ ۽ ڪاپي ڪرڻ کان سواء.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// ان سلائس کي ان جي ASCII مٿئين صورت ۾ برابر واري هنڌ ۾ تبديل ڪري ڇڏيو.
    ///
    /// ASCII خط 'a' کان 'z' 'A' کان 'Z' ڏانهن نقشه ڏنل آهن ، پر غير ASCII خط بدلايو نٿا وڃن.
    ///
    /// موجوده ۾ ھڪڙي کي بغير تبديل ڪرڻ جي لاءِ ھڪڙي جديد نقدي قيمت ڏانھن واپس ڪرڻ لاءِ ، [`to_ascii_uppercase`] استعمال ڪريو.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// ان سلائس کي ان جي ASCII نن caseي صورت ۾ برابر واري هنڌ ۾ بدلائي ٿو.
    ///
    /// ASCII خط 'A' کان 'Z' 'a' کان 'z' ڏانهن نقشه ڏنل آهن ، پر غير ASCII خط بدلايو نٿا وڃن.
    ///
    /// موجوده ۾ ھڪڙي کي تبديل ڪرڻ کانسواءِ ھڪڙي نئون گھٽ قيمت کي واپس ڪرڻ لاءِ ، [`to_ascii_lowercase`] استعمال ڪريو.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `true` لفظ ۾ ڪو بائيٽ اگر نسيسي (>=128) آهي.
/// `../str/mod.rs` کان لڪيل ، جيڪو utf8 جي تصديق لاءِ ڪجهه ساڳيو ڪندو آهي.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimized ASCII ٽيسٽ جيڪا بائٽ اي وقت اپ آپريشن جي بدران (جڏهن ممڪن هجي) بدران هڪ وقت تي آپريشنز کي استعمال ڪندي.
///
/// هتي جيڪو الگورتھم استعمال ڪيو آھي اھو ڪافي سادو آھي.جيڪڏهن `s` تمام نن shortڙو آهي ، اسان صرف هر بائيٽ کي چڪاس ڪريو ۽ ان سان ڪيو وڃي.ٻي صورت ۾:
///
/// - پهرين لفظ کي بي ترتيب ٿيل لوڊ سان گڏ پڙهو.
/// - پوائنٽر کي ignيرايو ، بعد ۾ آيل لفظن کي پڙهو جيستائين قطار ٿيل وزن سان ختم ٿئي.
/// - پڙھيو آخري `usize` کان `s` ھڪڙي بي ترتيب ٿيل لوڊ سان.
///
/// جيڪڏهن انهن لوڊن مان ڪا به اهڙي شي پيدا ڪري ٿي جنهن لاءِ `contains_nonascii` (above) سچو موٽائي ٿو ، ته اسان knowاڻون ٿا ته جواب غلط آهي.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // جيڪڏهن اسان لفظ وقت واري عمل مان ڪجھ حاصل نه ڪري سگهنداسين ، هڪ arرندڙ لوپ ڏانهن واپس اچو.
    //
    // اسان اهو پڻ تعميراتي ڪم جي لاءِ ڪريون ٿا جتي `size_of::<usize>()` ايڪسڪسيمڪس لاءِ مناسب ترتيب نه آهي ، ڇاڪاڻ ته اهو هڪ انوکو edge ڪيس آهي.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // اسان هميشه پهريون لفظ بي ترتيب پڙهيو ، جنهن جو مطلب آهي `align_offset` آهي
    // 0 ، اسان بي ترتيب پڙهيل لاءِ وري ساڳي قيمت پڙهي هئي.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // حفاظت: اسان مٿي `len < USIZE_SIZE` جي تصديق ڪيون ٿا.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // اسان هن کي مٿي چڪاس ڪيو ، ڪنهن حد تائين اڻ سڌي نموني.
    // نوٽ ڪريو ته `offset_to_aligned` يا `align_offset` آھي يا `USIZE_SIZE` ، ٻئي مٿي ڏنل طور تي مٿي ڏنل آھن.
    //
    debug_assert!(offset_to_aligned <= len);

    // SAFETY: word_ptr اسان جي پڙهڻ لاءِ استعمال ڪيو ويندو آهي
    // سلائس جو وچيون حصو.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` `word_ptr` جو بائيٽ انڊيڪس آھي ، لوپ آخر جي چڪاس لاءِ استعمال ٿيندو آھي.
    let mut byte_pos = offset_to_aligned;

    // پروانويا قطار بند جي باري ۾ چيڪ ڪريو ، جئين اسان ويٺا آهيون بي ترتيب سامان کڻڻ جو.
    // عملي طور تي اهو `align_offset` ۾ بگ کي روڪڻ ممڪن نه هجڻ گهرجي.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // آخري قطار ٿيل لفظ تائين پڙهو ، جيستائين آخري صفائي ٿيل لفظ کانسواءِ پاڻ تي ڪري بعد ۾ دم جي چڪاس ۾ ڪئي وڃي ، انهي ڳالهه کي يقيني بڻائڻ لاءِ ته چوٿون هميشه هڪ وڌيڪ `usize` وڌيڪ branch `byte_pos == len` تي آهي.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // سنيت چيڪ ڪريو ته پڙهيل حدن ۾ آهي
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // ۽ اهو اسان `byte_pos` بابت اسان جي ويچار رکو ٿا.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // حفاظت: اسان knowاڻون ٿا ته `word_ptr` صحيح ترتيب ڏنل آھي (جي ڪري
        // "align_offset") ، ۽ اسان knowاڻون ٿا ته اسان وٽ `word_ptr` ۽ پڇاڙي جي وچ ۾ ڪافي بائٽس آهن
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // سافٽويئر: اسان knowاڻون ٿا `byte_pos <= len - USIZE_SIZE` ، انهي جو مطلب آهي
        // ھي `add` کان پوءِ ، `word_ptr` ھڪڙي ھڪڙي آخري آخري ۾ رھندو.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // اتي جانچ ڪرڻ لاءِ سنجيدگي وارو چيڪ واقعي هتي فقط هڪ `usize` بچيل آهي.
    // اهو اسان جي لوپ ڏاهپ جي گارنٽي هئڻ گهرجي.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // حفاظت: انهي جو انحصار `len >= USIZE_SIZE` تي آهي ، جيڪو اسان شروعات ۾ چيڪ ڪيو آهي.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}