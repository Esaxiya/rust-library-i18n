//! `&[T]` ۽ `&mut [T]` ٺاھڻ لاءِ مفت ڪم.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// پوائنٽر ۽ ڊگھائي مان سليس ٺھي ٿو.
///
/// `len` دليل **عناصر** جو تعداد آهي ، نه بائيٽ جو تعداد.
///
/// # Safety
///
/// جيڪڏهن هيٺين شرطن مان ڪنهن جي خلاف ورزي ڪئي وئي هجي ته رويي کي غير تعين ڪيو ويندو آهي:
///
/// * `data` `len * mem::size_of::<T>()` کي XT [valid] ڪيترن ئي بائٽس جي پڙهڻ لاءِ لازمي طور تي ، ۽ ان کي لازمي طور تي متوازن ٿيڻ ضروري آهي.هن جو مطلب خاص طور تي:
///
///     * هن سلائس جي مڪمل يادگيري هڪ ئي مختص ڪيل شيءَ جي اندر شامل ٿيڻ گهرجي!
///       سلائسون ڪيترن ئي مختص ڪيل شين ۾ شامل نه ٿيون ٿي سگهن.مثال طور [below](#incorrect-usage) ڏسو انهي حساب ۾ نه وٺڻ.
///     * `data` صفر-ڊگھائي سلائسس لاءِ پڻ غير جانبدار ۽ متوازن هجڻ لازمي آهي.
///     انهي جو هڪ سبب اهو آهي ته اينم ترتيب ترتيب ڏيڻ ، ڀاڙيندڙن تي انحصار ڪري سگهن ٿا (بشمول ڪنهن به ڊيگهه جي سلائس) ٻئي طرف ڊيٽا ڌار ڪرڻ جي لاءِ صف بندي ڪرڻ ۽ غير خالي هجڻ.
///     توهان هڪ پوائنٽر حاصل ڪري سگهو ٿا جيڪو [`NonNull::dangling()`] استعمال ڪندي صفر ڊگهي سلائسز لاء `data` طور قابل استعمال آهي.
///
/// * `data` لازمي طور تي `T` قسم جي `T` جي شروعاتي ابتدائي قدرن ڏانهن اشارو ڪرڻ لازمي آهي.
///
/// * واپس ٿيل سلائس جي حوالي سان يادداشت جي يادگيري لازمي هوندي جيستائين زندگي جي `'a` جي عرصي تائين ، سواء `UnsafeCell` اندر.
///
/// * سليس جي ڪل سائيز `len * mem::size_of::<T>()` کان وڌيڪ نه هجڻ گهرجي `isize::MAX`.
///   [`pointer::offset`] جي حفاظت واري دستاويز کي ڏسو.
///
/// # Caveat
///
/// واپسي واري ٻلي لاءِ سetimeي حياتي هن جي استعمال کان مشابه آهي.
/// حادثاتي غلط استعمال کي روڪڻ لاءِ ، تجويز ڪيو ويو لائفائمٽ کي ٽائيج ڪريو جيڪو به ذري گهٽ لائف ٽائيم لائفمنٽ ۾ محفوظ هوندو آهي ، جيئن مددگار فنڪشن جي طرفان سستي جي ميزبان جي قيمت جو لائفائم کڻڻ ، يا واضح نموني ذريعي.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // ھڪ عنصر لاءِ سلائس ظاهر ڪريو
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### غلط استعمال
///
/// هيٺيون `join_slices` فنڪشن **غير محفوظ** ⚠️ آهي
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // مٿي assاڻايل چڪاس کي يقيني بڻائي ٿو `fst` ۽ `snd` ويجھي آھن ، پر اھي اڃا تائين _different allocated objects_ اندر موجود ھجن ، انھيءَ حالت ۾ ، ھي سلائس ٺاھڻ غير متعين رويو آھي.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ۽ ايڪس 400 الڳ مختص ڪيل شيون آهن ...
///     let a = 42;
///     let b = 27;
///     // ... جنهن جي باوجود يادگيري سان مڪمل طور تي ترتيب ۾ رکيو ويو آهي: |هڪ |ب |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // حفاظت: ڪال ڪندڙ کي `from_raw_parts` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// [`from_raw_parts`] وانگر ئي ساڳيو ڪارڪردگي انجام ڏئي ٿو ، سواءِ ان جي ته هڪ مٽائيندڙ ٻلي واپس اچي وئي.
///
/// # Safety
///
/// جيڪڏهن هيٺين شرطن مان ڪنهن جي خلاف ورزي ڪئي وئي هجي ته رويي کي غير تعين ڪيو ويندو آهي:
///
/// * `data` لازمي طور تي [valid] ٻنهي بائيٽ لاءِ پڙهائي ۽ لکڻ لاءِ [valid] هجڻ گهرجي ، ۽ اهو لازمي طور تي گڏ ٿيڻ لازمي آهي.هن جو مطلب خاص طور تي:
///
///     * هن سلائس جي مڪمل يادگيري هڪ ئي مختص ڪيل شيءَ جي اندر شامل ٿيڻ گهرجي!
///       سلائسون ڪيترن ئي مختص ڪيل شين ۾ شامل نه ٿيون ٿي سگهن.
///     * `data` صفر-ڊگھائي سلائسس لاءِ پڻ غير جانبدار ۽ متوازن هجڻ لازمي آهي.
///     انهي جو هڪ سبب اهو آهي ته اينم ترتيب ترتيب ڏيڻ ، ڀاڙيندڙن تي انحصار ڪري سگهن ٿا (بشمول ڪنهن به ڊيگهه جي سلائس) ٻئي طرف ڊيٽا ڌار ڪرڻ جي لاءِ صف بندي ڪرڻ ۽ غير خالي هجڻ.
///
///     توهان هڪ پوائنٽر حاصل ڪري سگهو ٿا جيڪو [`NonNull::dangling()`] استعمال ڪندي صفر ڊگهي سلائسز لاء `data` طور قابل استعمال آهي.
///
/// * `data` لازمي طور تي `T` قسم جي `T` جي شروعاتي ابتدائي قدرن ڏانهن اشارو ڪرڻ لازمي آهي.
///
/// * واپسي واري سلائس جو حوالو ڏنل يادگيري لازمي طور تي ڪنهن ٻئي پوائنٽر تائين رسائي نه هجڻ گهرجي (واپسي واري قيمت مان نڪتل ناهي) س00ي حياتي `'a` تائين.
///   پڙهڻ ۽ لکڻ جي رسائي منع ڪئي وئي آهي.
///
/// * سليس جي ڪل سائيز `len * mem::size_of::<T>()` کان وڌيڪ نه هجڻ گهرجي `isize::MAX`.
///   [`pointer::offset`] جي حفاظت واري دستاويز کي ڏسو.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // حفاظت: ڪال ڪندڙ کي `from_raw_parts_mut` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// بدلجي ٿو ٽو جي حوالي سان ھڪ ڊگھي 1 جي سلائس ۾ (ڪاپي ڪرڻ کان سواءِ)
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// بدلجي ٿو ٽو جي حوالي سان ھڪ ڊگھي 1 جي سلائس ۾ (ڪاپي ڪرڻ کان سواءِ)
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}