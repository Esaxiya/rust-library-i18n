//! ميڪروس سلائس جي ويتر استعمال ڪندڙن طرفان استعمال ڪيو ويو آهي.

// لائننگ is_empty ۽ لين ھڪڙي وڏي ڪارڪردگي جو فرق وٺندي آھي
macro_rules! is_empty {
    // جنهن طريقي سان اسان ZST ايٽرر جي ڊگھائي جوڙيو ٿا ، اهو ZST ۽ Non-ZST لاءِ ٻئي ڪم ڪري ٿو.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// ڪجهه حدن جي چيڪن کان نجات حاصل ڪرڻ جي لاءِ (`position` ڏسو) ، اسان طويل ڪجهه غير متوقع طريقي سان ڳڻپ ڪيون ٿا.
// (آزمائشي طور تي "ڪوڊگين/سلائس پوزيشن بائونڊ چيڪ" طرفان.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // اسان ڪڏهن ڪڏهن غير محفوظ بلاڪ ۾ استعمال ڪيا ويندا آهن

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // هي _cannot_ `unchecked_sub` استعمال ڪندو آهي ڇاڪاڻ ته اسين ڊگهي ZST سلائس ايريرٽرز جي ڊيگهه جي نمائندگي ڪرڻ لاءِ لپڻ تي منحصر آهيون.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // اسان thatاڻون ٿا ته `start <= end` ، تنھنڪري `offset_from` کان بھتر ڪري سگھي ٿو ، جيڪو دستخط ٿيل ۾ ڊيل ڪرڻ جي ضرورت آھي.
            // هتي مناسب فليگنگ ترتيب ڏيندي اسان انهي کي ايل ـ ايل ايم ايم ٻڌائي سگهون ٿا ، جيڪا انهي جي مدد ڪري ٿي حدون چيڪ.
            // حفاظتي قسم قسم وارين ترتيب سان ، `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // ايل ايل وي ايم کي اهو ٻڌائڻ سان پڻ ته اشارو هڪ کان وڌيڪ مختلف قسمن جي ڌار ڌار ڌار ڌار ڌار ڌار ڌار اندازن سان ڪري رهيا آهن ، اهي ايڪسڪسيمڪس جي بدران `start == end` ڏانهن `len() == 0` ڏانهن بهتر ڪري سگهن ٿا.
            //
            // حفاظت: قسم انوائيٽري طرفان ، اشارو ڏيندڙ ائين ئي ٺهيل آهن
            //         انهن جي وچ ۾ فاصلي جي گھڻائي جي هجڻ گهرجي
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter` ۽ `IterMut` iterators جي گڏيل وصف
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // پهريون عنصر واپس آڻيندي ۽ 1 ذريعي ايندڙ ورر جي شروعات کي منتقل ڪري ٿو.
        // هڪ هلائڻ واري فنڪشن جي مقابلي ۾ بهتر نموني ڪارڪردگي بهتر ڪندو آهي.
        // ويتر کي خالي نه هجڻ گهرجي.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // آخري عنصر موٽائي ٿو ۽ 1 کي ختم ڪرڻ واري طرف کي ختم ڪري ٿو.
        // هڪ هلائڻ واري فنڪشن جي مقابلي ۾ بهتر نموني ڪارڪردگي بهتر ڪندو آهي.
        // ويتر کي خالي نه هجڻ گهرجي.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // ڇنڊڻيندڙ کي ڇڪائي ٿو جڏهن T هڪ ZST آهي ، `n` ذريعي ايٽرر جي پڇاڙي طرف منتقل ڪرڻ سان.
        // `n` `self.len()` کان وڌيڪ نه هجڻ گهرجي.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // ايٽرر کان هڪ سلائس ٺاهڻ لاءِ مددگار فنڪشن.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // حفاظت: ايجريٽر پوائنٽ سان سلائس مان ٺهيل هئي
                // `self.ptr` ۽ `len!(self)` جي ڊيگهه.
                // اهو ضمانت ڏئي ٿو ته `from_raw_parts` جون سڀ شرائط پوريون ٿي چڪيون آهن.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // ايٽرٽر جي شروعات کي منتقل ڪرڻ جي لاءِ مدد وارو ڪم `offset` عناصر اڳتي وڌائيندي ، پراڻي شروعات کي واپس ڪندي.
            //
            // غير محفوظ ڇاڪاڻ ته آفسيٽ `self.len()` کان وڌيڪ نه هجڻ گهرجي.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // حفاظت: ڪال ڪرڻ واري کي ضمانت ڏي ٿي ته `offset` `self.len()` کان وڌيڪ نه آهي ،
                    // تنهن ڪري هي نئون پوائنٽر `self` اندر آهي ۽ اهڙي طرح غير خالي ٿيڻ جي ضمانت آهي.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // ايليٽر `offset` عناصر طرفان ايٽرٽر جي پڇاڙي طرف منتقل ڪرڻ لاءِ مددگار فعل ، نئين پڇاڙي واپس موٽڻ.
            //
            // غير محفوظ ڇاڪاڻ ته آفسيٽ `self.len()` کان وڌيڪ نه هجڻ گهرجي.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // حفاظت: ڪال ڪرڻ واري کي ضمانت ڏي ٿي ته `offset` `self.len()` کان وڌيڪ نه آهي ،
                    // جيڪو هڪ `isize` مٿان چڙھڻ جي ضمانت نه آھي.
                    // ان کان علاوه ، نتيجو ڪندڙ پوائنٽر `slice` جي حد ۾ آهي ، جيڪا `offset` جي ٻين ضرورتن کي پورو ڪري ٿي.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // پليسز سان لاڳو ٿي سگھيو ، پر اھو حد جي چڪاس کان بچي ٿو

                // حفاظت: ھڪڙي سلائس جي شروعاتي پوائنٽر کان `assume` ڪالون محفوظ آھن
                // غير جانبدار هجڻ گهرجي ، ۽ ZSTs مٿان سلائسون پڻ هڪ نان آخري آخري پوائنٽر هجڻ ضروري آهن.
                // `next_unchecked!` کي ڪال محفوظ آهي جئين اسان چڪاسيون ٿا ته هي ٽيريٽر پهرين خالي آهي.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // اهو آئيرٽر هاڻي خالي آهي.
                    if mem::size_of::<T>() == 0 {
                        // اسان کي ان طريقي سان ان لاءِ ڪرڻ کپي جيئن `ptr` ڪڏهن به 0 نه ٿي سگهي ، پر `end` ٿي سگهي ٿو (لپيٽڻ جي ڪري).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // حفاظت: آخري ٿي سگهي ٿو 0 نه آهي جيڪڏهن T ZST ناهي ڇاڪاڻ ته ptr 0 ناهي ۽ آخر>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // حفاظت: اسان حدن ۾ آهيون.`post_inc_start` صحيح ڪم ڪري ٿو ZSTs لاء پڻ.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // اسان ڊفالٽ پليجيسٽيوشن کي ختم ڪري ڏيون ٿا ، جيڪو `try_fold` استعمال ڪندو آهي ، ڇاڪاڻ ته هي سادو عمل گهٽ LLVM IR ٺاهي ٿو ۽ مرتب ڪرڻ تي تيز آهي.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // اسان ڊفالٽ پليجيسٽيوشن کي ختم ڪري ڏيون ٿا ، جيڪو `try_fold` استعمال ڪندو آهي ، ڇاڪاڻ ته هي سادو عمل گهٽ LLVM IR ٺاهي ٿو ۽ مرتب ڪرڻ تي تيز آهي.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // اسان ڊفالٽ پليجيسٽيوشن کي ختم ڪري ڏيون ٿا ، جيڪو `try_fold` استعمال ڪندو آهي ، ڇاڪاڻ ته هي سادو عمل گهٽ LLVM IR ٺاهي ٿو ۽ مرتب ڪرڻ تي تيز آهي.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // اسان ڊفالٽ پليجيسٽيوشن کي ختم ڪري ڏيون ٿا ، جيڪو `try_fold` استعمال ڪندو آهي ، ڇاڪاڻ ته هي سادو عمل گهٽ LLVM IR ٺاهي ٿو ۽ مرتب ڪرڻ تي تيز آهي.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // اسان ڊفالٽ پليجيسٽيوشن کي ختم ڪري ڏيون ٿا ، جيڪو `try_fold` استعمال ڪندو آهي ، ڇاڪاڻ ته هي سادو عمل گهٽ LLVM IR ٺاهي ٿو ۽ مرتب ڪرڻ تي تيز آهي.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // اسان ڊفالٽ پليجيسٽيوشن کي ختم ڪري ڏيون ٿا ، جيڪو `try_fold` استعمال ڪندو آهي ، ڇاڪاڻ ته هي سادو عمل گهٽ LLVM IR ٺاهي ٿو ۽ مرتب ڪرڻ تي تيز آهي.
            // انهي سان گڏ ، `assume` حدون چيڪ ڪرڻ کان پاسو ڪري ٿو.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // حفاظت: اسان کي لوپ انٽريٽري طرفان حدن ۾ هجڻ جي ضمانت آهي.
                        // جڏهن `i >= n` ، `self.next()` واپسي `None` ۽ لوپ ڀڃي ٿو.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // اسان ڊفالٽ پليجيسٽيوشن کي ختم ڪري ڏيون ٿا ، جيڪو `try_fold` استعمال ڪندو آهي ، ڇاڪاڻ ته هي سادو عمل گهٽ LLVM IR ٺاهي ٿو ۽ مرتب ڪرڻ تي تيز آهي.
            // انهي سان گڏ ، `assume` حدون چيڪ ڪرڻ کان پاسو ڪري ٿو.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // حفاظت: `i` کان `n` کان گھٽ هجڻ لازمي آھي جڏھن اھو `n` تي شروع ٿئي ٿو
                        // ۽ رڳو گهٽجي رهيو آهي.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // حفاظت: سڏيندڙ کي گارنٽي ڏيڻ گهرجي ته `i` حدن ۾ آهي
                // بنيادي سلائس ، تنهن ڪري `i` ايڪسڪسيمڪس کي اوور فلو نٿو ڪري سگهي ، ۽ واپسي واري حوالن گليس جي هڪ عنصر ڏانهن اشارو ڪرڻ جي ضمانت آهي ۽ اهڙي طرح صحيح هجڻ جي ضمانت آهي.
                //
                // اهو به ياد ڪريو ته سڏيندڙ پڻ گارنٽي ٿو ڏئي ته اسان ڪڏهن به ساڳئي انڊيڪس سان ٻيهر سڏجي نٿا سگهون ، ۽ ٻيا ته طريقا نه آهن جيڪي هن سبسڊي کي رسائي ڏين ٿا ، جي ڪري انهي جي واپسي جي صورت ۾ اهو مٽجڻ لاءِ صحيح آهي
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // پليسز سان لاڳو ٿي سگھيو ، پر اھو حد جي چڪاس کان بچي ٿو

                // حفاظتي: `assume` ڪالون محفوظ آهن انهي کان پوء هڪ سلائس جي شروعاتي پوائنٽر غير-لازمي هجڻ گهرجي ،
                // ۽ غير ZSTs مٿان سلائسون پڻ ھڪڙي ناھيل آخري پوائنٽر هجڻ لازمي آھي.
                // `next_back_unchecked!` کي ڪال محفوظ آهي جئين اسان چڪاسيون ٿا ته هي ٽيريٽر پهرين خالي آهي.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // اهو آئيرٽر هاڻي خالي آهي.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // حفاظت: اسان حدن ۾ آهيون.`pre_dec_end` صحيح ڪم ڪري ٿو ZSTs لاء پڻ.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}