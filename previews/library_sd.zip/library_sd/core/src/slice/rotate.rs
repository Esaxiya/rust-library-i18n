// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` جي حد کي گھمائيندو آهي ته `mid` تي پهريون عنصر جيترو عنصر بڻجي ويندو آهي.ويجهڙائي سان ، سا Xي طرف `left` عنصرن کي کاٻي يا `right` عنصرن کي سا toي طرف گھمائيندو.
///
/// # Safety
///
/// مخصوص رينج پڙهڻ ۽ لکڻ لاءِ صحيح هجڻ گهرجي.
///
/// # Algorithm
///
/// الورگيتم 1 `left + right` جي نن valuesن قدرن لاءِ يا وڏي `T` لاءِ استعمال ڪيو وڃي ٿو.
/// عناصر `mid - left` ۽ هڪ ڀيرو `right` قدم ماڊلو `left + right` پاران هڪ وقت تي پنهنجي حتمي پوزيشن ۾ منتقل ڪيا ويا آهن ، صرف هڪ عارضي جي ضرورت آهي.
/// آخرڪار ، اسان `mid - left` تي واپس پھچون ٿا.
/// بهرحال ، جيڪڏهن `gcd(left + right, right)` 1 نه آهي ، مٿي ڏنل قدمن تي عناصر ختم ٿي ويا آهن.
/// مثال طور:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// خوش قسمتي سان ، حتمي عنصرن جي وچ ۾ ofرڻ وارن عنصرن جو تعداد هميشه برابر آهي ، تنهن ڪري اسان صرف پنهنجي شروعاتي پوزيشن کي بهتر انداز سان ۽ وڌيڪ گول ڪري سگهون ٿا (رائونڊ جو ڪل تعداد `gcd(left + right, right)` value) آهي.
///
/// آخري نتيجو اهو آهي ته سڀني عنصرن کي حتمي ۽ صرف هڪ ڀيرو حتمي شڪل ڏني وڃي ٿي.
///
/// الگورٿم 2 استعمال ٿئي ٿو جيڪڏهن `left + right` وڏو آهي پر `min(left, right)` ڪافي نن isڙو آهي جيڪو اسٽيڪ بفر تي ويهڻ لاءِ هوندو آهي.
/// `min(left, right)` عناصر بفر تي نقل ٿيل آھن ، `memmove` ٻين تي لاڳو ٿيل آھي ، ۽ بفر تي اھي جيڪي واپس ھليا ويا آھن ، جتي اھي پيدا ٿيا آھن.
///
/// الگورڊٿم جيڪي ويڪر ٿي سگھي ٿو مٿي کان مٿي چالو ڪري سگھن ٿا ايڪسڪسيمڪس ڪافي وڏو ٿي وڃي ٿو.
/// الورگيتم 1 کي چڪنائي سان وينٽيريز ڪري سگهجي ٿو ۽ هڪ ئي وقت ڪيترائي رائونڊ ڪري سگھي ٿو ، پر اوسط تي تمام گهٽ رائونڊ آهن جيستائين `left + right` وڏو آهي ، ۽ هڪ ئي دور جي بدترين صورت هميشه اتي آهي.
/// ان جي بدران ، الگورتھم 3 `min(left, right)` عناصر جي بار بار مٽائڻ کي استعمال ڪندو آهي جيستائين هڪ نن rotڙو گردش وارو مسئلو رهجي نه وڃي.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// جڏهن `left < right` ادل بدران کاٻي پاسي کان اچي ٿو۔
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. جيڪڏهن انهن ڪيسن جي چڪاس نه ڪئي وڃي ته هيٺ ڏنل الگورتھم ناڪام ٿي سگهن ٿا
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // الورگيتم 1 مائڪرو بينچ مارڪ ظاهر ڪن ٿا ته بي ترتيب واري شفٽ جي سراسري ڪارڪردگي س00ي طريقي سان بهتر آهي `left + right == 32` تائين هرڪو ، پر بدترين حالت جي ڪارڪردگي به 16 جي چوڌاري ڇڪي ٿو.
            // 24 وچين زمين طور چونڊيو ويو.
            // جيڪڏهن `T` جو سائز 4 "ڪتب آڻيندڙ" کان وڏو آهي ، اهو الگورتھم ٻين الگورتھم کي به گهٽائي ٿو.
            //
            //
            let x = unsafe { mid.sub(left) };
            // پهرين دور جي شروعات
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` `gcd(left + right, right)` جي حساب سان هٿ کان اڳ ڳولي سگھجي ٿو ، پر اهو هڪ لوپ ڪرڻ لاءِ تيز آهي ، جيڪا پڻ جي ڊي ڊي کي ضمني اثر جي حساب سان معلوم ڪري ٿي ، باقي ڪن کي
            //
            //
            let mut gcd = right;
            // معيارن کي ظاهر ڪيو ويو آهي ته اها عارضي طور تي عارضي طور تي سموري رستي سان مٽائڻ بدران هڪ عارضي طور تي هڪ ڀيرو پڙهڻ بدران ، پوئتي ڪاپي ڪرڻ ، ۽ پوءِ اهو عارضي طور تي آخر ۾ لکڻ.
            // شايد اهو ئي سبب آهي ته عارضي شين کي مٽائڻ يا بدلائڻ ٻن کي منظم ڪرڻ جي ضرورت جي بدران لوپ ۾ صرف هڪ ميموري پتي استعمال ڪندو آهي.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` کي وڌائڻ کان پوء ۽ انهي جي چڪاس ڪريو ته اها حدن کان ٻاهر آهي ، اسان چيڪ ڪريو ته ڇا `i` ايندڙ اگري تي حدن کان ٻاهر ويندي.
                // اهو پوائنٽرن يا `usize` جي ڪنهن به لپڻ کي روڪي ٿو.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // پهرين دور جي پاڻي
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // اها شرطي هتي هجڻ لازمي آهي جيڪڏهن `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // وڌيڪ گولن سان چڪر کي ختم ڪيو
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` صفر-سائيز وارو قسم نه آهي ، تنهنڪري اهو صحيح آهي ته ان جي ماپ سان ورهايو وڃي.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // الگورٿم 2 `[T; 0]` هتي اهو يقيني بڻائڻ لاءِ آهي ته اها ٽي لاءِ مناسب انداز سان ترتيب ڏنل آهي
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // الگورٿم 3 مٽائڻ جو هڪ متبادل طريقو آهي جنهن ۾ اهو ڳولڻ شامل آهي ته هن الگورتھم جو آخري بدل ڪٿي ڪٿي هوندو ، ۽ هن الگورٿم وانگر ڀرپاسي چوڪن کي مٽائڻ بدران ان آخري چوڪ جو استعمال ڪندي ، پر اهو طريقو اڃا وڌيڪ تيز آهي.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // الگورٿيم 3 ، `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}