//! سليس جي ترتيب ڏيڻ
//!
//! ھن ماڊل ۾ ترتيب ڏنل الگورتھم شامل آھي ، ورنز پيٽرس جي طرز تي شڪست ڏيڻ جا نمونا ، شايع ٿيل: <https://github.com/orlp/pdqsort>
//!
//!
//! غير مستحڪم ترتيب ڏيڻ لبرڪ سان مطابقت رکي ٿي ڇاڪاڻ ته اهو اسان جي مستحڪم ترتيب وار عمل جي برعڪس ياداشت کي مختص نه ڪندو آهي.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// جڏهن ڇڏيو ويو ، `src` کان `dest` تان ڪاپي.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // حفاظت: ھي مددگار ڪلاس آھي.
        //          مهرباني ڪري درستگي لاءِ ان جي استعمال جو حوالو ڏيو.
        //          ڇهن ، هڪ کي ضرور پڪ ڪرڻ گهرجي ته `src` ۽ `dst` اوپلوپ نٿا ڪن جئين `ptr::copy_nonoverlapping` پاران گھربل آهي.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// پهرين عنصر کي سا toي طرف منتقل ڪري ٿو جيستائين ان جو مقابلو وڌيڪ يا برابر عنصر سان نه ٿئي.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // حفاظت: هيٺ ڏنل غير محفوظ عملن ۾ بنا چيڪ جي چڪاس ڪرڻ جي فهرست شامل آهي (`get_unchecked` ۽ `get_unchecked_mut`)
    // ۽ ياداشت (`ptr::copy_nonoverlapping`) نقل ڪندي.
    //
    // هڪ.انڊسٽرنگ:
    //  1. اسان>=2 تائين صف جو قد چڪاسيو.
    //  2. سموري انڊيڪسنگ جيڪا اسين ڪنداسين اهو هميشه گهڻو ڪري {0 <= index < len} جي وچ ۾ آهي.
    //
    // ب.ياداشت ڪاپي ڪندي
    //  1. اسان کي ريفرنسن ڏانهن اشارو ملي رهيا آهن جيڪي صحيح هجڻ جي ضمانت آهن.
    //  2. اهي مٿان چڙهائي نه ٿا سگهن ڇاڪاڻ ته اسان سلسلن جي مختلف اشارن ڏانهن اشارا حاصل ڪندا آهيون.
    //     ڇهن ، `i` ۽ `i-1`.
    //  3. جيڪڏهن سلائس صحيح طرح سان هلي وڃي ، عناصر صحيح نموني سان ٺهيل آهن.
    //     اهو ڪالڪر جي ذميواري آهي انهي کي يقيني بڻائڻ ته سلائس صحيح طريقي سان گڏ ڪيو وڃي.
    //
    // وڌيڪ تفصيل لاءِ هيٺ ڏنل رايا ڏسو.
    unsafe {
        // جيڪڏهن پهرين ٻه عنصر حد کان ٻاهر آهن ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // پهريون عنصر پڙهو اسٽيڪ کان مختص ٿيل متغير ۾.
            // جيڪڏهن هيٺ ڏنل مقابلي واري آپريشن panics ، `hole` ڊرايو ويندو ۽ خودڪار طور عنصر کي واپس سلائس ۾ لکندو.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // اي `عنصر کي هڪ جڳهه کي کاٻي پاسي منتقل ڪيو ، تنهنڪري سوراخ کي سا toي طرف منتقل ڪيو.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` گريو وڃي ٿو ۽ انهي ڪري `tmp` `v` ۾ باقي سوراخ ۾ نقل ڪري ٿو.
        }
    }
}

/// آخري عنصر کي کاٻي پاسي يريندو آهي جيستائين ان جو نن aڙو يا برابر عنصر نه اچي.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // حفاظت: هيٺ ڏنل غير محفوظ عملن ۾ بنا چيڪ جي چڪاس ڪرڻ جي فهرست شامل آهي (`get_unchecked` ۽ `get_unchecked_mut`)
    // ۽ ياداشت (`ptr::copy_nonoverlapping`) نقل ڪندي.
    //
    // هڪ.انڊسٽرنگ:
    //  1. اسان>=2 تائين صف جو قد چڪاسيو.
    //  2. سموري انڊيڪسنگ جيڪو اسان ڪنداسين اهو هميشه گهڻو ڪري `0 <= index < len-1` جي وچ ۾ آهي.
    //
    // ب.ياداشت ڪاپي ڪندي
    //  1. اسان کي ريفرنسن ڏانهن اشارو ملي رهيا آهن جيڪي صحيح هجڻ جي ضمانت آهن.
    //  2. اهي مٿان چڙهائي نه ٿا سگهن ڇاڪاڻ ته اسان سلسلن جي مختلف اشارن ڏانهن اشارا حاصل ڪندا آهيون.
    //     ڇهن ، `i` ۽ `i+1`.
    //  3. جيڪڏهن سلائس صحيح طرح سان هلي وڃي ، عناصر صحيح نموني سان ٺهيل آهن.
    //     اهو ڪالڪر جي ذميواري آهي انهي کي يقيني بڻائڻ ته سلائس صحيح طريقي سان گڏ ڪيو وڃي.
    //
    // وڌيڪ تفصيل لاءِ هيٺ ڏنل رايا ڏسو.
    unsafe {
        // جيڪڏهن آخري ٻه عنصر ٻاهران آيل آهن ۔۔۔
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // پڙھيو آخري عنصر اسٽيڪ مختص ٿيل متغير ۾.
            // جيڪڏهن هيٺ ڏنل مقابلي واري آپريشن panics ، `hole` ڊرايو ويندو ۽ خودڪار طور عنصر کي واپس سلائس ۾ لکندو.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // اي `عنصر کي هڪ جڳهه کي سا toي طرف منتقل ڪريو ، تنهنڪري سوراخ کي کاٻي پاسي shيرائي ڇڏيو.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` گريو وڃي ٿو ۽ انهي ڪري `tmp` `v` ۾ باقي سوراخ ۾ نقل ڪري ٿو.
        }
    }
}

/// جزوي طور ڪيترن ئي گهرن ۾ موجود عناصر کي byيرائڻ سان هڪ سلائس ترتيب ڏنل آهي.
///
/// ايڪس سلڪسڪس ڏي ٿو جيڪڏهن سليس آخر ۾ ترتيب ڏني وڃي.هي فنڪشن *او*(*اين*) بدترين ڪيس آهي.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // وڌ کان وڌ تعداد ۾ ڀرپاسي واري ٻاهرين جوڙي جيڪا منتقل ٿي ويندي آهي.
    const MAX_STEPS: usize = 5;
    // جيڪڏهن سلائس ان کان نن isو آهي ، ڪنهن به عنصر کي shiftيرائي نه ڇڏيو.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // حفاظت: اسان اڳ ۾ ئي واضح طور تي پابند ڪيو چڪاس ڪئي `i < len` سان.
        // اسان جي سڀيئي ايندڙ انڊسٽنگ صرف حد `0 <= index < len` ۾ آهي
        unsafe {
            // ڀرپاسي کان ٻاھر ٿيندڙ عناصر جو ايندڙ جوڙو ڳولھيو.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // ڇا اسان ڪيا آهيون؟
        if i == len {
            return true;
        }

        // مختصر arrays تي عنصرن کي shiftيرائڻ نه ، انهي جي ڪارڪردگي قيمت آهي.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // عناصر جي مليو جوڙي کي تبديل ڪريو.اهو انهي کي صحيح ترتيب سان ترتيب ڏئي ٿو.
        v.swap(i - 1, i);

        // نن elementو عنصر کي کاٻي پاسي منتقل ڪريو.
        shift_tail(&mut v[..i], is_less);
        // حق کي وڏو عنصر منتقل ڪريو
        shift_head(&mut v[i..], is_less);
    }

    // محدود تعداد ۾ سلائس کي ترتيب ڏيڻ جو انتظام نه ڪيو.
    false
}

/// داخل ٿيل قسم کي استعمال ڪندي هڪ سلائس ترتيب ڏي ٿو ، جيڪو *او*(*اين*^ 2) بدترين صورت آهي.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// `v` حرص استعمال ڪندي ترتيب ڏي ٿو ، جيڪو *او*(*n*\*log(* n*)) بدترين ڪيس جي ضمانت ڏئي ٿو).
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // هي بائنري هوپر اندار سان `parent >= child` جو احترام ڪندو آهي.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // `node` جا ٻار:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // وڏي ٻار جو انتخاب ڪيو.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // روڪيو جيڪڏهن محافظ `node` تي رکي ٿو.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // وڏي ٻار سان ايڪس ڪيوڪس سويپ ڪيو ، هڪ قدم ھيٺ لھي وڃو ، ۽ صفائي جاري رکو.
            v.swap(node, greater);
            node = greater;
        }
    };

    // لڪير جي وقت ۾ هائيڪ ٺاهيو.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // theَر مان وڌ کان وڌ عنصر.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// حصو `v` عناصر `pivot` کان نن smallerا آهن ، ان جي پٺيان `pivot` کان وڌيڪ يا برابر عناصر.
///
///
/// `pivot` کان نن elementsا عناصر جو تعداد موٽائي ٿو.
///
/// برانچنگ آپريشن جي قيمت کي گھٽ ڪرڻ لاءِ ورها blockي کان بلاڪ ڪرائي وئي آهي.
/// اهو خيال [BlockQuicksort][pdf] پيپر ۾ پيش ڪيو ويو آهي.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // عام بلاڪ ۾ عناصر جو تعداد.
    const BLOCK: usize = 128;

    // ورهاي وارو الگورتھم هيٺين مرحلن کي مڪمل ڪرڻ تائين ورجائي ٿو.
    //
    // 1. کاٻي پاسي کان هڪ بلاڪ کي پاسو کان وڌيڪ يا برابر برابر سڃاڻڻ لاءِ نشانو بڻايو.
    // 2. سا sideي طرف کان هڪ بلاڪ کي پايو کان نن elementsن عنصرن جي سڃاڻپ ڪرڻ لاءِ نشانو بڻايو.
    // 3. کاٻي ۽ سا sideي طرف جي وچ ۾ elementsاڻايل عنصرن کي مٽايو.
    //
    // اسان عناصر جي بلاڪ لاءِ هيٺيان متغير رکون ٿا.
    //
    // 1. `block` - بلاڪ ۾ عناصر جو تعداد.
    // 2. `start` - پوائنٽر `offsets` صف ۾ شروع ڪريو.
    // 3. `end` - `offsets` صف ۾ پوائنٽر ختم ڪريو.
    // 4. بلاڪ ۾ اندر گهڻي ترتيب وارن عنصرن جي اشاري.

    // کاٻي پاسي کان موجوده بلاڪ (`l` کان `l.add(block_l)`) تائين.
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // سا blockي طرف هاڻوڪي بلاڪ (`r.sub(block_r)` to `r`) کان.
    // حفاظت: .add() لاءِ دستاويز خاص طور تي ذڪر ڪيو آهي ته `vec.as_ptr().add(vec.len())` هميشه محفوظ هوندو
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: جڏهن اسان VLA حاصل ڪريون ٿا ، ڊيگهه `min(v.len() ، 2 * BLOCK) جي هڪ صف ٺاهڻ جي ڪوشش ڪريو
    // `BLOCK` ڊيگهه جي ٻن فيڪٽ-سائز جزن کان.شايد VLA ڪيش وڌيڪ موثر هوندا.

    // پوائنٽر `l` (inclusive) ۽ `r` (exclusive) جي وچ ۾ عنصر جو تعداد موٽائي ٿو.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // اسان ورهاitionي سان روڪٿ-بلاڪ کي روڪيو ويو آهي جڏهن `l` ۽ `r` تمام ويجهو ٿيو.
        // پوءِ اسان وچ ۾ باقي رهيل عنصرن کي ورهائي ڏيڻ لاءِ ڪجهه پيچ اپ ڪم ڪندا آهيون.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // باقي عنصرن جو تعداد (اڃا تائين تارن جي مقابلي ۾ ناهي).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // بلاڪ جي سائيز کي ترتيب ڏيو ته جيئن کاٻي ۽ سا blockي بلاڪ مٿي نه لکجي ، پر س ،ي بچيل خلا کي toڪڻ لاءِ مڪمل طور تي موافق بڻجي.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // کاٻي پاسي کان `block_l` عنصرن کي ڇڪيو.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // حفاظت: هيٺيون غير محفوظ ٿيندڙ آپريشن `offset` جو استعمال شامل ڪري ٿو.
                //         ڪارڪردگي مطابق گھربل حالتن جي مطابق ، اسان انهن کي مطمئن ڪريون ٿا:
                //         1. `offsets_l` اسٽيڪ مختص ٿيل آهي ، ۽ اهڙي طرح الڳ الڳ مختص ڪيل شي کي سمجهيو ويندو.
                //         2. فنڪشن `is_less` هڪ `bool` موٽائي ٿو.
                //            `bool` ڪاسٽ ڪندي ڪڏهن به `isize` مٿان چڙهائي نه سگهندي.
                //         3. اسان ضمانت ڏني آهي ته `block_l` به `<= BLOCK` هوندو.
                //            وڌيڪ ، `end_l` شروعاتي طور تي `offsets_` جي شروعاتي پوائنٽر تي سيٽ ڪئي وئي جيڪا اسٽيڪ تي اعلان ڪيو ويو.
                //            ان ڪري ، اسان thatاڻون ٿا ته بدترين حالت ۾ (`is_less` جي سڀني دعوائن جي واپسي به غلط آهي) اسان رڳو آخر ۾ فقط 1 بائيٽ پاس ڪنداسين.
                //        هتي هڪ ٻيو غير محفوظ آپريشن `elem` کي ختم ڪرڻ آهي.
                //        جيتوڻيڪ ، `elem` شروعاتي طور تي سليس ڏانهن شروعاتي اشارو هو جيڪو هميشه صحيح آهي.
                unsafe {
                    // برانچ لفافي وارو مقابلو.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // سا00ي طرف کان `block_r` عنصرن کي ٽريڪ ڪريو.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // حفاظت: هيٺيون غير محفوظ ٿيندڙ آپريشن `offset` جو استعمال شامل ڪري ٿو.
                //         ڪارڪردگي مطابق گھربل حالتن جي مطابق ، اسان انهن کي مطمئن ڪريون ٿا:
                //         1. `offsets_r` اسٽيڪ مختص ٿيل آهي ، ۽ اهڙي طرح الڳ الڳ مختص ڪيل شي کي سمجهيو ويندو.
                //         2. فنڪشن `is_less` هڪ `bool` موٽائي ٿو.
                //            `bool` ڪاسٽ ڪندي ڪڏهن به `isize` مٿان چڙهائي نه سگهندي.
                //         3. اسان ضمانت ڏني آهي ته `block_r` به `<= BLOCK` هوندو.
                //            وڌيڪ ، `end_r` شروعاتي طور تي `offsets_` جي شروعاتي پوائنٽر تي سيٽ ڪئي وئي جيڪا اسٽيڪ تي اعلان ڪيو ويو.
                //            ان ڪري ، اسان thatاڻون ٿا ته بدترين حالتن ۾ (`is_less` جي سڀني دعوائن تي سچيون موٽيون) اسان صرف آخر ۾ صرف 1 بائيٽ پاس ٿي وينداسين.
                //        هتي هڪ ٻيو غير محفوظ آپريشن `elem` کي ختم ڪرڻ آهي.
                //        جيتوڻيڪ ، `elem` شروعاتي طور تي `1 *sizeof(T)` ختم ٿي چڪو هو ۽ اسان ان کي پهچائڻ کان پهريان `1* sizeof(T)` ذريعي گهٽايو.
                //        وڌيڪ ، `block_r` کي `BLOCK` کان گهٽ زور ڏنو ويو هو ۽ `elem` تنهنڪري اڪثر اڪثر سلائسس جي شروعات ڏانهن اشارو ڪيو ويندو.
                unsafe {
                    // برانچ لفافي وارو مقابلو.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // کاٻي ۽ سا sideي پاسي جي وچ ۾ ڇڪڻ لاءِ سجاڳي ختم ڪرڻ وارن عنصرن جو تعداد.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // ھڪڙي وقت تي ھڪڙو جوڙو مٽائڻ بدران ، سائي سائيڪلڪ اجازت ڏيڻ وڌيڪ ڪارائتو آھي.
            // هي نموني تبديل ڪرڻ جي برابر ناهي ، پر گهٽ ياداشت جي عملن جو استعمال ڪندي هڪ ئي نتيجو پيدا ڪري ٿو.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // کاٻي پاسي ۾ تمام گهڻي ترتيب وارا عنصر منتقل ڪيا ويا.ايندڙ بلاڪ ڏانهن وڌو.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // صحيح بلاڪ ۾ سمورن آرڊر وارا عنصر حرڪت ۾ اچي ويا.پوئين بلاڪ ڏانھن منتقل ڪريو.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // هاڻ اهو سڀ ڪجهه اڃا وڌيڪ هڪ بلاڪ تي آهي (يا ته بائيڪاٽ يا سا theي) ٻاهر-بند-عناصر سان گڏ جنهن کي منتقل ڪرڻ جي ضرورت آهي.
    // اهڙا باقي عنصر صرف انهن جي بلاڪ اندر آخري طرف منتقل ٿي سگهن ٿا.
    //

    if start_l < end_l {
        // کاٻي پاسي واريون رهجي ويون.
        // هن جي باقي پري آرٽيڪل عنصرن کي گهڻي سا toي طرف منتقل ڪريو.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // صحيح رڪاوٽ رهي ٿي.
        // هن جي باقي پري آرٽيڪل عنصرن کي گهڻي کان کاٻي طرف منتقل ڪريو.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // ٻيو ڪجهه نه ٿيو ، اسان ٿي وياسين.
        width(v.as_mut_ptr(), l)
    }
}

/// حصو `v` عناصر `v[pivot]` کان نن smallerا آهن ، ان جي پٺيان `v[pivot]` کان وڌيڪ يا برابر عناصر.
///
///
/// واپس اچڻ جو ھڪڙو ٽائٽل آھي:
///
/// 1. `v[pivot]` کان نن elementsا عنصر جو تعداد.
/// 2. صحيح آهي جيڪڏهن `v` اڳ ۾ ئي ورهايل هو.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // پوائٽ کي سلائس جي شروعات تي رکجن.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // ڪارڪردگي لاءِ ڀروسو هڪ اسٽيڪ مختص ٿيل متغير ۾ پڙهو.
        // جيڪڏهن هيٺين مقابلي وارو آپريشن panics ، پوٽو خودڪار طور تي واپس سلائس ۾ لکجي ويندو.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // پهرين کان ٻاهر ٿيندڙ عناصر جو پهريون جوڙو ڳوليو.
        let mut l = 0;
        let mut r = v.len();

        // حفاظت: هيٺ ڏنل غير محفوظيت صف کي انڊيڪس ڪرڻ ۾ شامل آهي.
        // پهرين لاء: اسان اڳ ۾ ئي حدون چيڪ ڪري رهيا آهيون `l < r` سان.
        // ٻئين لاءِ: اسان وٽ شروعاتي طور تي `l == 0` ۽ `r == v.len()` آهي ۽ اسان چڪاس ڪيو ته هر انڊيڪسنگ آپريشن تي `l < r` آهي.
        //                     هتان کان اسان knowاڻون ٿا ته `r` گهٽ ۾ گهٽ `r == l` هجڻ گهرجي ها جيڪو پهرين ڪنهن طرفان صحيح ڏيکاريل هو.
        unsafe {
            // ابتدائي عنصر ڳوليو پوئين کان وڏو يا برابر آهي.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // آخري عنصر نن smallerو ڳوليو جيڪو پيوٽ ٿئي.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` گنجائش کان ٻاهر نڪري ويو آهي ۽ پوٽو (جيڪو اسٽيڪ مختص ٿيل متغير آهي) واپس سلائس ۾ آهي جتي اصل هو.
        // اهو قدم حفاظت کي يقيني بڻائڻ ۾ اهم آهي!
        //
    };

    // ٻن حصن جي وچ ۾ محراب رکي.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// حصو `v` عناصر `v[pivot]` جي برابر ۾ داخل ٿيون ۽ بعد ۾ `v[pivot]` کان وڌيڪ عناصر.
///
/// عناصر جي تعداد کي پينٽ جي برابر ڏيکاري ٿو.
/// اهو فرض ڪيو ويو آهي ته `v` عنصر کان نن smallerن نن containن عنصرن تي مشتمل نه هوندو آهي.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // پوائٽ کي سلائس جي شروعات تي رکجن.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // ڪارڪردگي لاءِ ڀروسو هڪ اسٽيڪ مختص ٿيل متغير ۾ پڙهو.
    // جيڪڏهن هيٺين مقابلي وارو آپريشن panics ، پوٽو خودڪار طور تي واپس سلائس ۾ لکجي ويندو.
    // حفاظت: پوائنٽر هتي صحيح آهي ڇاڪاڻ ته اهو هڪ سلائس جي حوالي سان حاصل ڪيو ويو آهي.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // هاڻي سلائس کي ورهايو.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // حفاظت: هيٺ ڏنل غير محفوظيت صف کي انڊيڪس ڪرڻ ۾ شامل آهي.
        // پهرين لاء: اسان اڳ ۾ ئي حدون چيڪ ڪري رهيا آهيون `l < r` سان.
        // ٻئين لاءِ: اسان وٽ شروعاتي طور تي `l == 0` ۽ `r == v.len()` آهي ۽ اسان چڪاس ڪيو ته هر انڊيڪسنگ آپريشن تي `l < r` آهي.
        //                     هتان کان اسان knowاڻون ٿا ته `r` گهٽ ۾ گهٽ `r == l` هجڻ گهرجي ها جيڪو پهرين ڪنهن طرفان صحيح ڏيکاريل هو.
        unsafe {
            // ڳرڻ کان وڏو عنصر ڳوليو.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // پوٽو جي برابر آخري عنصر ڳوليو.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // ڇا اسان ڪيا آهيون؟
            if l >= r {
                break;
            }

            // ٺاھيل ٻاھر موجود عناصر مان ملندڙ جوڙو ٺاھيو.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // اسان `l` عناصر کي ڳاڙهي جي برابر ڏٺو.ڳاٽ جي حساب سان حساب لاءِ 1 شامل ڪريو.
    l + 1

    // `_pivot_guard` گنجائش کان ٻاهر نڪري ويو آهي ۽ پوٽو (جيڪو اسٽيڪ مختص ٿيل متغير آهي) واپس سلائس ۾ آهي جتي اصل هو.
    // اهو قدم حفاظت کي يقيني بڻائڻ ۾ اهم آهي!
}

/// نمونن کي ٽوڙڻ جي ڪوشش ۾ ڪجهه عنصرن کي ورهائي ٿو جيڪا جلدي ۾ غير متوازن ورها partي جو سبب بڻجي سگھي ٿي.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // جارج مارسجيليا طرفان "Xorshift RNGs" پيپر تان تخلصورمو نمبر جنريٽر.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // وٺو بي ترتيب نمبر وارو نمبر اھو نمبر.
        // نمبر `usize` ۾ ٺهي ٿو ڇو ته `len` `isize::MAX` کان وڏو ناهي.
        let modulus = len.next_power_of_two();

        // ڪجهه پائٽ اميدوار هن انڊيڪس جي ويجهي ۾ هوندا.اچو ته انهن کي ترتيب ڏي.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // بي ترتيب واري نموني ماڊل نمبر `len` ٺاھيو.
            // تنهن هوندي ، قيمتي آپريشن کان بچڻ جي لاءِ اسان پهرين ان کي ماڊل جي ٻٽي طاقت وٺون ٿا ، ۽ پوءِ `len` کان گهٽ ڪري ڇڏيو جيستائين اهو `[0, len - 1]` جي حد تائين پهچي وڃي.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` `2 * len` کان گھٽ جي ضمانت آھي.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// `v` ۾ محور چونڊيندو آھي ۽ انڊيڪس ۽ `true` موٽائي ٿو جيڪڏھن سلائسس اڳ ۾ ئي ترتيب ڏنل آھي.
///
/// `v` ۾ عناصر ٻيهر پروسيس ۾ هوندا.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // وچولي انداز جي وچين طريقي کي چونڊڻ جي گھٽ ۾ گهٽ ڊيگهه.
    // ننicesا سلائسون سادي وچين-ٽن طريقي جو استعمال ڪن ٿا.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // وڌ ۾ وڌ سويپَپَس نمبرَ جيڪي انهي فنڪشن ۾ انجام ڏئي سگھن ٿا.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // ٽي انڊيڪس جن جي ويجهو اسان هڪ پلٽ چونڊڻ وارا آهيون.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // مجموعي طور تي سوٽا جو تعداد ڳڻپ ٿو جيڪو اسان ترتيب ڏيڻ وارا آهيون.
    let mut swaps = 0;

    if len >= 8 {
        // انڊيڪس کي سويپ ڪيو ته ايڪس ايڪس ايڪس.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // انڊيڪس کي سويپ ڪيو ته ايڪس ايڪس ايڪس.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // `v[a - 1], v[a], v[a + 1]` جو ميڊين ڳولي ٿو ۽ ايڪس ڊيڪس کي `a` ۾ ذخيرو ڪري ٿو.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // `a` ، `b` ، ۽ `c` جي ڀرپاسي ۾ ميڊين ڳوليو.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // `a` ، `b` ، ۽ `c` جي وچ ۾ اوسط ڳوليو.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // وڌ ۾ وڌ تبديلي جو نظارو انجام ڏنو ويو.
        // موقعا سلائس کي گهٽائي رهيا آهن يا اڪثر هيٺ ڏجن ٿا ، تنهنڪري الٽائڻ شايد ان کي تيزيء سان ترتيب ڏيڻ ۾ مدد ڪندو.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` وارين طور تي.
///
/// جيڪڏهن سلائس اصل صف ۾ اڳوڻي هئي ، انهي کي `pred` طور بيان ڪيو ويو آهي.
///
/// `limit` ڇا `heapsort` تي وڃڻ کان اڳ اجازت ڏنل عدم توازن ورهايلن جو تعداد آهي.
/// جيڪڏهن صفر ، اهو فنڪشن فوري طور تي هاسپرٽ ڏانهن تبديل ٿيندو.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // هن ڊيگهه تائين سلائسون ترتيب ڏيندي ترتيب ڏيندي ترتيب ڏي.
    const MAX_INSERTION: usize = 20;

    // صحيح آهي جيڪڏهن آخري ورهاingي کي معقول طور تي متوازن بڻايو ويو.
    let mut was_balanced = true;
    // اهو صحيح آهي ته آخري ورهاingي جا عنصر ڌاڙيل نه ڪندا هئا (سلائس اڳ ئي ورهايل هئا).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // تمام نن slا سلائس داخل ڪرڻ جي ترتيب سان ترتيب ڏيو.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // جيڪڏهن تمام گھڻي خراب چونڊون ڪيون ويون ، صرف `O(n * log(n))` بدترين ڪيس جي گارنٽي ڏيڻ لاءِ هجرت ڏانهن واپس وڃو.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // جيڪڏهن آخري ورهاingي غير متوازن هئي ، ڪجهه عناصر جي چوڌاري byهلائڻ سان گڏ ٽڪراڻ واري نموني کي ٽوڙڻ جي ڪوشش ڪريو.
        // اميد آهي ته اسان هن ڀيري وڌيڪ بهتر pار چونڊينداسين.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // هڪ محور چونڊيو ۽ اندازو لڳائڻ جي ڪوشش ڪريو ته ڇا سلائس اڳ ۾ ئي ترتيب ڏنل آهي.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // جيڪڏھن آخري ورهاingي کي متوازن طريقي سان متوازن بڻايو ويو ۽ عناصر کي ڇڪيو نه ويو ، ۽ جيڪڏھن پوٽو انتخاب پيش گوئي ڪري ٿو ته سلائسس اڳ ۾ ئي چھانٽي پئي وڃي ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // ڪوشش ڪريو ڪيترن ئي ٻاھرين حصن کي elementsاڻڻ ۽ انھن کي صحيح جڳھ ڏانھن منتقل ڪرڻ.
            // جيڪڏھن سليس مڪمل طور تي ختم ٿي وڃي ختم ٿئي ، اسان ٿي چڪو آھي.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // جيڪڏهن چونڊيل محور اڳڪٿي جي برابر آهي ، ته اهو سلائس ۾ سڀني کان نن elementڙو عنصر آهي.
        // سلائي کي عنصرن برابر ۽ عنصرن کي پلٽ کان وڌيڪ ورهايو.
        // اهو ڪيس عام طور تي تڏهن ڌڪجي ٿو جڏهن سلائس ڪيترن ئي نقل ڪندڙ عنصرن تي مشتمل هجي.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // محور کان وڏي عناصر ترتيب ڏيڻ جاري رکو.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // سلائس کي ورهايو.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // سلائس کي `left` ، `pivot` ، ۽ `right` ۾ ورهايو.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // ٻيهر چڪر واري ڪل جي تعداد کي گھٽ ڪرڻ لاءِ ۽ نن stackي اسٽيڪ جي جاءِ کي گھٽ ڪرڻ لاءِ رڳو نن sideي پاسي ۾ ٻيهر جمع ڪريو.
        // پوءِ صرف ڊگھي طرف سان جاري رکو (اهو دم جهولڻ جهڙو آهي)
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// نموني خارج ڪرڻ واري طريقي سان `v` استعمال ڪري ٿو ، جيڪو *O*(*n*\*log(* n*)) بدترين صورت آهي.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // صفر وارين قسمن تي ترتيب ڏيڻ سان ڪو به معنوي رويو نه آهي.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // `floor(log2(len)) + 1` تائين متوازن حصن جي تعداد کي محدود ڪريو.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // انهي جي ڊيگهه تائين نن slن ٽڪرن لاءِ شايد ممڪن آهي ته انهن جي ترتيب ڏيڻ ۾ تيز.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // هڪ محور چونڊيو
        let (pivot, _) = choose_pivot(v, is_less);

        // جيڪڏهن چونڊيل محور اڳڪٿي جي برابر آهي ، ته اهو سلائس ۾ سڀني کان نن elementڙو عنصر آهي.
        // سلائي کي عنصرن برابر ۽ عنصرن کي پلٽ کان وڌيڪ ورهايو.
        // اهو ڪيس عام طور تي تڏهن ڌڪجي ٿو جڏهن سلائس ڪيترن ئي نقل ڪندڙ عنصرن تي مشتمل هجي.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // جيڪڏھن اسان پنھنجو انڊيڪس پاس ڪيو ، پوءِ اسين سٺو آھيون.
                if mid > index {
                    return;
                }

                // ٻي صورت ۾ ، عناصر کي ترتيب ڏيڻ کان وڌيڪ جاري رکو.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // سلائس کي `left` ، `pivot` ، ۽ `right` ۾ ورهايو.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // جيڪڏهن وچ==انڊيڪس ، پوء اسان مڪمل ڪيو آهي ، ڇو ته partition() گارنٽيڊ آهي ته وچ کان پوءِ سڀ عنصر وچ کان وڌيڪ يا برابر آهن.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // صفر وارين قسمن تي ترتيب ڏيڻ سان ڪو به معنوي رويو نه آهي.ڪجھ نه ڪر.
    } else if index == v.len() - 1 {
        // وڌ کان وڌ عنصر ڳوليو ۽ ان کي ترتيب جي آخري پوزيشن ۾ رکجي.
        // اسان هتي `unwrap()` استعمال ڪرڻ لاءِ آزاد آهيون ڇاڪاڻ ته اسان knowاڻون ٿا ته وي کي خالي نه ٿيڻ گهرجي.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // منٽ جو عنصر ڳوليو ۽ ان کي پهرين قطار جي جڳھ تي رکو.
        // اسان هتي `unwrap()` استعمال ڪرڻ لاءِ آزاد آهيون ڇاڪاڻ ته اسان knowاڻون ٿا ته وي کي خالي نه ٿيڻ گهرجي.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}