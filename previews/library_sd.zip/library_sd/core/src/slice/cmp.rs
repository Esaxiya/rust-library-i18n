//! `[T]` لاء مقابلو traits.

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// ڪال امپريشن مهيا ڪئي.
    ///
    /// ڊيٽا کي u8 وانگر تعبير ڪري ٿو.
    ///
    /// 0 لاءِ برابر ڏيکاري ٿو ، <0 کان گھٽ لاءِ ۽> 0 کان وڌيڪ لاءِ وڏي.
    ///
    // FIXME(#32610): واپسي جو قسم c_int هجڻ گهرجي
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// vectors [lexicographically](Ord#lexicographical-comparison) جو مقابلو بهتر
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// vectors [lexicographically](Ord#lexicographical-comparison) جو مقابلو بهتر
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// وچولي trait سلائس جي PartialEq جي خاصيت لاءِ
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// عام سلائي مساوات
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// استعمال ڪندا آھن ميممو پي برابر توازن لاءِ جڏھن قسمون اجازت ڏين
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // حفاظت: `self` ۽ `other` حوالا آھن ۽ اھڙي طرح صحيح آھي ضمانت.
        // ٻن سلائسن جي چڪاس ڪئي وئي آھي جيتري ساڳي آھي مٿي.
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// وچولي trait slice جي PartialOrd کي خاص ڪرڻ لاءِ
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // loopرندڙ چيڪ ختم ڪرڻ کي فعال ڪرڻ لاءِ لوپ انٽيشن جي حد تائين سليس
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// هي هڪ نپ آهي جيڪو اسان چاهيون ٿا.بدقسمتي سان اهو آواز ناهي.
// `partial_ord_slice.rs` ڏسو.
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// وچولي trait سلائسس جي Ord خاص ڪرڻ لاءِ
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // loopرندڙ چيڪ ختم ڪرڻ کي فعال ڪرڻ لاءِ لوپ انٽيشن جي حد تائين سليس
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// ميم سي ايم پي لينگيولوجيڪل انگن اکرن جي بائنس جي هڪ ترتيب ترتيب ڏئي ٿي.
// اھو ٺاھيو آرڊر جيڪو اسان [u8] لاءِ چاھيو ٿا ، پر ٻيا ڪونہ ([i8] توڙي کڻي) ناھي.
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // حفاظت: `left` ۽ `right` حوالا آھن ۽ اھڙي طرح صحيح آھي ضمانت.
            // اسان ٻنهي حدن جو گهٽ ۾ گهٽ استعمال ڪيو آهي جيڪا ضمانت ڏئي ٿي ته ٻئي علائقا انهي وقفي ۾ پڙهڻ لاءِ صحيح آهن.
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// ايڪس `Eq` کي خاص ڪرڻ جي اجازت ڏيڻ هيڪ ڪريو جيتوڻيڪ `Eq` وٽ هڪ طريقو آهي.
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait انهن قسمن لاءِ لاڳو ڪيا ويا جيڪي برابري لاءِ برابر ٿي سگهن ٿا
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // SAFETY: `i8` ۽ `u8` وٽ ساڳيون ياداشت واري ترتيب آھي ، اھڙي ريت `x.as_ptr()` کي ڪٽڻ
        // جيئن ته `*const u8` محفوظ آهي.
        // `x.as_ptr()` هڪ حواله مان آيو آهي ۽ انهي طرح گارنٽي `x.len()` جي ڊگهو پڙهڻ جي صحيح جي ضمانت آهي ، جيڪا `isize::MAX` کان وڏي نه ٿي سگهي.
        // واپس ٿيل سلائس ڪڏھن به خاموش نٿي ٿئي.
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}