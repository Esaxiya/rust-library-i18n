// نظر انداز ڪريو ڳجهارت جي فائل تقريباً خاص طور تي `Iterator` جي تعريف تي مشتمل آهي.
// اسان ان کي ڪيترن ئي فائلن ۾ ورهائي نٿا سگهون.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// آئي ٽيٽرز سان معاملو ڪرڻ جو هڪ انٽرنيٽ.
///
/// اهو بنيادي ايريٽرر trait آهي.
/// عام طور تي ورجاءُ جي تصور بابت وڌيڪ لاءِ ، مهرباني ڪري [module-level documentation] کي ڏسو.
/// خاص طور تي ، توهان کي toاڻڻ چاهيندا ته [implement `Iterator`][impl] کان ڪئين.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// عناصر جي قسم کي ختم ٿي رهيو آهي.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ايسٽر کي اڳتي وڌائيندو آهي ۽ ايندڙ ويليو موٽائيندو آهي.
    ///
    /// واپسي جي ختم ٿيڻ واري وقت [`None`] کي واپس ڏئي ٿو.
    /// انفرادي ايٽررٽر عمل درآمد شايد ٻيهر ورجائڻ جي چونڊ ڪن ، ۽ انهي ڪري `next()` ٻيهر ڪال ڪري سگھي ٿو يا ٿي سگهي ٿو آخرڪار [`Some(Item)`] ڪنهن موڙ تي ٻيهر موٽڻ شروع نه ڪري.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next() ڏانهن هڪ ڪال اچي ٿو ايندڙ اگني ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ۽ پوءِ هڪ ڀيرو ختم ناهي ٿيو.
    /// assert_eq!(None, iter.next());
    ///
    /// // وڌيڪ ڪال `None` موٽي سگھن ٿيون يا نه ٿيون.هتي ، اهي هميشه چاهيندا.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// ايٽرر جي باقي لمبائي تي حدون موٽائيندو آهي.
    ///
    /// خاص طور تي ، `size_hint()` هڪ ٽپل ڏي ٿو جتي پهريون عنصر هيٺين حد تائين آهي ، ۽ ٻيو عنصر مٿين حد وارو آهي.
    ///
    /// ٻي جيڪا ٽاپيل موٽندي آهي اها [Option]] <<["استعمال ڪريو"]> آهي.
    /// هڪ [`None`] هتي مطلب آهي ته ، يا ته ڪوبه سڃاتو مٿاهين حد ناهي ، يا مٿيون پابند [`usize`] کان وڏي آهي.
    ///
    /// # پليجي نوٽ
    ///
    /// اهو لاڳو نه ڪيو ويو آهي ته اهو هڪ ايراضي عمل درآمد عنصرن جو اعلان ڪيل نمبر پيدا ڪري ٿو.هڪ بگ آئيرٽر ٿي سگهي ٿو هيٺين حد کان گهٽ يا عناصر جي اوپري حد کان وڌيڪ.
    ///
    /// `size_hint()` بنيادي طور تي ڊيزائينز جي لاءِ استعمال ڪيو ويندو آهي جيئن ايٽرر جي عنصرن لاءِ جڳهه کي محفوظ ڪيو وڃي ، پر اعتبار نه ڪيو وڃي مثال طور ، غير محفوظ ڪوڊ ۾ حدن جي چيڪن کي ختم ڪرڻ.
    /// `size_hint()` جي غلط عمل کي ياد رکڻ گهرجي حفاظت جي خلاف ورزي جي نتيجي ۾.
    ///
    /// اھو چيو آھي ، عملدرآمد کي صحيح اندازو لڳائڻ گھرجي ، ڇاڪاڻ تھ ٻي صورت ۾ اھو trait جي پروٽوڪول جي خلاف ورزي ھوندي.
    ///
    /// ڊفالٽ پلي لاڳو موٽندو آھي "(0،" [None "]") اھو جيڪو ڪنھن بهاریٽر لاءِ صحيح آھي.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// وڌيڪ پيچيده مثال:
    ///
    /// ```
    /// // ايستائين جو نمبر صفر کان ڏھ تائين.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // اسان اهو صفر کان ڏھ ڀيرا مٽائي سگھون ٿا.
    /// // اهو thatاڻڻ ته اهو پنجن ئي filter() کي انجام ڏيڻ جي بغير ممڪن ناهي.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // اچو ته chain() سان گڏ پنج عدد وڌيڪ تعداد ۾ شامل ڪريون
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // هاڻ ٻئي حدون پنج کان وڌي ويون آهن
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// ھڪڙي چوٽيءَ لاءِ `None` واپس ڪندي:
    ///
    /// ```
    /// // لامحدود ورثي کي ڪا مٿي واري حد نه آهي ۽ وڌ کان وڌ ممڪن حد تائين هيٺيون
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// iterator کي کارائيندو ، اعلى تعداد کي ڳڻيندو ۽ ان کي واپس ڪندي.
    ///
    /// اهو طريقو X0 [`next`] کي بار بار سڏيندو جيستائين [`None`] سان مقابلو ٿيو ، ڪيترا ئي ڀيرا موٽيو جڏهن هن [`Some`] ڏٺو.
    /// ياد رهي ته [`next`] کي گهٽ ۾ گهٽ هڪ ڀيرو سڏڻو آهي ان جي باوجود جيڪڏهن ايٽريٽر ۾ ڪو عنصر نه آهي.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # اوور رويو رويي
    ///
    /// طريقو اوورفولز جي خلاف ڪوبه حفاظت نٿو ڪري ، انهي ڪري [`usize::MAX`] کان وڌيڪ عناصر هڪ بار بار عناصر جي ڳڻپ ڪري ٿو يا ته غلط نتيجو پيدا ڪري ٿو يا panics.
    ///
    /// جيڪڏهن ڊيبگ جا جزا فعال آهن ، هڪ panic گارنٽي آهي.
    ///
    /// # Panics
    ///
    /// اهو فنڪشن panic ٿي سگهي ٿو جيڪڏهن ايٽررٽر [`usize::MAX`] کان وڌيڪ عنصر آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// iterator کي کارائي ٿو ، آخري عنصر واپس ڪري ٿو.
    ///
    /// اهو طريقو ايٽرٽر جي تشخيص ڪندو جيستائين ان کي [`None`] واپس نه ڏيندو.
    /// ائين ڪرڻ دوران ، اهو موجوده عنصر جو نقشو رکي ٿو.
    /// [`None`] واپس ٿيڻ کان پوءِ ، `last()` وري جيڪو آخري عنصر ڏٺو سو واپس ڪندو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// اي ٽيٽر کي `n` عناصر ذريعي پيش ڪري ٿو.
    ///
    /// اهو طريقو X0XX کي `n` تائين ڪال ڪندي ايڪس آرڪس عناصر کي شوق سان ڇڏي ڏيندو جيستائين [`None`] جو سامنا ٿيڻ تائين.
    ///
    /// `advance_by(n)` جيڪڏهن X0XX وارن سان ڪاميابي سان اڳتي وڌندي وڃي ، [`Err(k)`][Err] واپس آڻيندو ، يا [`Err(k)`][Err] جيڪڏهن [`None`] سان ڪو سامنا ٿي پوي ، جتي `k` انهن عنصرن جو تعداد آهي جئين عناصر کي ختم ڪرڻ کان پهريان اڳيٽر کي اڳتي وڌايو وڃي ٿو (يعني.
    /// اندازي جي ڊيگهه)
    /// نوٽ ڪريو ته `k` هميشه `n` کان گهٽ آهي.
    ///
    /// ڪال ڪرڻ `advance_by(0)` ڪوبه عنصر نه کائيندو ۽ هميشه [`Ok(())`][Ok] موٽائي ٿو.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // صرف ايڪس 00 ايڪس کي ڇڏي ڏنو ويو
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// واپسي واري `n 'عنصر کي واپس ڏئي ٿو.
    ///
    /// اڪثر انڊيڪنگ آپريشن وانگر ، ڳڻپ صفر کان شروع ٿئي ٿو ، تنهن ڪري `nth(0)` پهرين ويليو موٽائي ٿو ، `nth(1)` سيڪنڊ ، ۽ ايئن.
    ///
    /// ياد رهي ته اڳئين عنصرن ، جئين واپس موٽندڙ عنصر ، ٻيهر ورتل کان کنيو ويندو.
    /// ان جو مطلب اهو آهي ته اڳين عنصرن کي رد ڪيو ويندو ، ۽ اهو پڻ چئي ٿو ته `nth(0)` کي ساڳئي ايٽرر تي ڪيترائي ڀيرا ڪال ڪرڻ.
    ///
    ///
    /// `nth()` جيڪڏهن `n` ايٽررٽر جي ڊيگهه کان وڌيڪ يا برابر برابر هجي ته واپس آڻيندو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` کي ڪيترائي ڀيرا ڪال ڪرڻ پاڻ ٻيهر ورجائيندڙ نه ٿو ڇڏي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// جيڪڏهن `n + 1` کان گهٽ عنصر آهن ته `None` واپس ڪري رهيا آهن:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// ساڳئي نقطي تي شروع ڪندي ايريرٽر ٺاهي ٿو ، پر هر ايٽيرشن تي ڏنل رقم سان قدم کڻڻ.
    ///
    /// نوٽ 1: آئيٽرر جو پهريون عنصر هميشه واپس ڏنو ويندو ، قطع نظر جي ڏنل قدم جي.
    ///
    /// نوٽ 2: جنهن وقت نظرانداز ٿيندڙ عنصر ڪ areيا ويندا اهو طئي ناهي.
    /// `StepBy` برتاؤ `next(), nth(step-1), nth(step-1),…` وانگر ڏسندو آهي ، پر اهو پڻ تسلسل وانگر عمل ڪرڻ ۾ آزاد آهي
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// ڪهڙو طريقو استعمال ڪيو وڃي ٿو ڪارڪردگي سببن جي ڪري ڪجهه وراثت ۾ تبديل ٿي سگھي ٿو.
    /// ٻيو رستو اهو هوندو هو ته اڳڀرو اڳڀرائي ڪندو ۽ وڌيڪ شيون هٿ ڪري سگهندو.
    ///
    /// `advance_n_and_return_first` جي برابر آهي
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// جيڪڏهن طريقو ڏنل `0` هوندو ته panic طريقو ٿيندو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// ٻه ورثو وٺندو آهي ۽ ٻنهي ترتيب ۾ هڪ نئون ايريرٽر ٺاهي ٿو.
    ///
    /// `chain()` هڪ نئين ايرايٽر کي واپس ڪندو جيڪو پھريائين پھريائين آئي ايٽر کان قيمتن مٿان ٿيندو ۽ پوءِ ٻئي ايئريٽر کان ويليوز مٿان.
    ///
    /// ٻين لفظن ۾ ، اهو هڪ ٻه تسلسل سان گڏ ، هڪ زنجير سان ڳن linksيندو آهي.🔗
    ///
    /// [`once`] عام طور تي هڪ قسم جي ٻين تهذيبن جي زنجير ۾ جڙيل هڪ قيمت کي عام ڪرڻ لاءِ استعمال ٿيندو آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` استعمال ڪرڻ واري دليل کان وٺي [`IntoIterator`] استعمال ڪري ٿو ، اسان ڪجھ به پاس ڪري سگهون ٿا جيڪو [`Iterator`] ۾ تبديل ٿي سگهي ٿو ، نه صرف هڪ [`Iterator`] پاڻ.
    /// مثال طور ، سليڪس (`&[T]`) لاڳو ڪن [`IntoIterator`] ، ۽ انهي ڪري سڌو سنئون `chain()` ڏانهن منتقل ڪري سگھجي ٿو.
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// جيڪڏهن توهان Windows API سان ڪم ڪيو ، توهان شايد [`OsStr`] کي `Vec<u16>` ۾ تبديل ڪرڻ چاهيندا:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// ٻٻر کي جاري ڪرڻ واري ھڪڙي ايٽرر ۾ 'ٻه رڪاوٽون'.
    ///
    /// `zip()` هڪ نئون ورثو واپس ڏي ٿو جيڪو ٻه ٻين ايريرائٽرز تي ٻيهر ورجائي ٿو ، هڪ ٽپل ڏيڻو پوي ٿو جتي پهريون عنصر پهريون ايٽرر مان ايندو آهي ، ۽ ٻيو عنصر ٻئي ايٽرر مان ايندو آهي.
    ///
    ///
    /// ٻين لفظن ۾ ، اهو ٻه وراثت هڪٻئي سان جڙي ٿو ، هڪٻئي ۾.
    ///
    /// جيڪڏهن يا ته ايٽررٽر [`None`] ، [`next`] زپ ٿيل ايٽريٽر کان واپس ڪري ٿو [`None`].
    /// جيڪڏهن پهريون ايٽرر [`None`] موٽائي ٿو ، `zip` شارٽ سرڪٽ ٿيندي ۽ `next` ٻئي ايٽرر تي نه سڏ ڪئي ويندي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` استعمال ڪرڻ واري دليل کان وٺي [`IntoIterator`] استعمال ڪري ٿو ، اسان ڪجھ به پاس ڪري سگهون ٿا جيڪو [`Iterator`] ۾ تبديل ٿي سگهي ٿو ، نه صرف هڪ [`Iterator`] پاڻ.
    /// مثال طور ، سليڪس (`&[T]`) لاڳو ڪن [`IntoIterator`] ، ۽ انهي ڪري سڌو سنئون `zip()` ڏانهن منتقل ڪري سگھجي ٿو.
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` اڪثر ڪري هڪ لامحدود ترتيب ڏيڻ واري هڪ کي ختم ڪرڻ لاءِ استعمال ڪيو ويندو آهي.
    /// اهو ڪم ڪري ٿو ڇاڪاڻ ته فني ايٽررٽر آخرڪار [`None`] واپس ڪري ، زپ ختم ڪندي.ايڪسڪسيمڪس سان زپ ڪرڻ [`enumerate`] وانگر تمام گھڻو ڏسجي سگھن ٿا.
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// هڪ نئين ايريرٽر ٺاهي ٿو جيڪا اصل ايٽررٽر جي ويجهي شيون جي وچ ۾ `separator` جي ڪاپي رکي ٿي.
    ///
    /// ان صورت ۾ `separator` [`Clone`] لاڳو نٿو ٿئي يا ھر وقت حساب ڪرڻ جي ضرورت آھي ، [`intersperse_with`] استعمال ڪريو.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a` کان پهريون عنصر.
    /// assert_eq!(a.next(), Some(&100)); // ڌار ڪندڙ.
    /// assert_eq!(a.next(), Some(&1));   // `a` کان ايندڙ عنصر.
    /// assert_eq!(a.next(), Some(&100)); // ڌار ڪندڙ.
    /// assert_eq!(a.next(), Some(&2));   // `a` کان آخري عنصر.
    /// assert_eq!(a.next(), None);       // الٽر ختم ٿي ويو آهي.
    /// ```
    ///
    /// `intersperse` هڪ عام عنصر کي استعمال ڪندي بار بار شيون جوڙڻ ۾ تمام گهڻو مفيد ٿي سگهي ٿو.
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// هڪ نئين ايريرٽر ٺاهي ٿو جيڪا `separator` پاران ٺاهيل هڪ شيون اصل ايٽررٽر جي ويجهي وارن وارن جي وچ ۾ رکي ٿو.
    ///
    /// بند ھڪڙي بار لاءِ سڏي ويندي ھڪڙي دفعي ھڪڙي شيءَ ھيٺئين آئيريٽر مان ٻن ويجھي شيون جي وچ ۾ رکيل آھي.
    /// خاص طور تي ، بندش ان کي نه سڏيو ويندو آهي جيڪڏهن بنيادي ايريريٽر ٻن شين کان گهٽ ۽ آخري شيون پيدا ٿيڻ بعد گهٽ ٿئي ٿي.
    ///
    ///
    /// جيڪڏهن ايريرٽر جي شيءِ [`Clone`] لاڳو ڪري ٿي ، اهو [`intersperse`] استعمال ڪرڻ آسان ٿي سگهي ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v` کان پهريون عنصر.
    /// assert_eq!(it.next(), Some(NotClone(99))); // ڌار ڪندڙ.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v` کان ايندڙ عنصر.
    /// assert_eq!(it.next(), Some(NotClone(99))); // ڌار ڪندڙ.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v` کان آخري عنصر.
    /// assert_eq!(it.next(), None);               // الٽر ختم ٿي ويو آهي.
    /// ```
    ///
    /// `intersperse_with` حالتن ۾ استعمال ڪري سگھجي ٿو جتي ڌار ڌار کي حساب ڏيڻ جي ضرورت آهي:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // بندش پنهنجي ترتيب سان ڪنهن شئي کي پيدا ڪرڻ جي لاءِ قرض وٺي ڇڏيندي آهي.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// بندش وٺندي آهي ۽ ايريريٽر ٺاهي ٿي جنهن ۾ هر عنصر تي بندش ختم ٿي وڃي ٿي.
    ///
    /// `map()` هڪ دهرائي کي ٻئي ۾ تبديل ڪري ٿو ، پنهنجي دليل جي ذريعي:
    /// ڪجھ ايڪس آرڪس کي لاڳو ڪري ٿو.اهو هڪ نئون ايريرٽر پيدا ڪري ٿو جيڪو هن بند کي اصلي ايٽررٽر جي هر عنصر تي سڏيندو آهي.
    ///
    /// جيڪڏهن توهان قسمن ۾ سوچڻ ۾ سٺو آهيو ، توهان انهي وانگر `map()` بابت سوچيو ٿا:
    /// جيڪڏهن توهان وٽ هڪ ايراضي ڪندڙ آهي جيڪو توهان کي ڪجهه قسم جي `A` جا عنصر فراهم ڪري ٿو ، ۽ توهان ڪنهن ٻئي قسم جي `B` کي هڪ ورثي واري شيءَ چاهيو ٿا ، ته توهان `map()` استعمال ڪري سگهو ٿا ، هڪ بندش پاس ڪندي جيڪا هڪ `A` وٺي ٿي ۽ هڪ `B` موٽائي ٿي.
    ///
    ///
    /// `map()` تصوراتي طور تي [`for`] لوپ وانگر آهي.تنهن هوندي ، جئين `map()` سست آهي ، اهو بهترين استعمال ٿيندو آهي جڏهن توهان اڳ ۾ ئي ٻين ايٽرر سان ڪم ڪري رهيا آهيو.
    /// جيڪڏهن توهان هڪ قسم جي لوپنگ جي لاءِ س effectي اثر جي ڀڃڪڙي ڪري رهيا هجو ، `map()` کان [`for`] استعمال ڪرڻ وڌيڪ بيوقوف سمجهيو وڃي ٿو.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// جيڪڏهن توهان ڪجهه قسم جي ضمني اثر ڪري رهيا آهيو ، پسند ڪريو [`for`] کان `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // هي نه ڪر:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // اهو به ڪم نه ڪندو آهي ، ڇاڪاڻ ته اهو سست آهي.Rust توهان کي ان بابت خبردار ڪندو.
    ///
    /// // بدران ، استعمال لاءِ:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// هڪ تسلسل واري هر عنصر تي بندش ختم ڪري ٿو.
    ///
    /// اهو ايئيرٽر تي [`for`] لوپ استعمال ڪرڻ جي برابر آهي ، جيتوڻيڪ `break` ۽ `continue` بند ٿيڻ کان ممڪن ناهي.
    /// عام طور تي `for` لوپ استعمال ڪرڻ لاءِ اهو وڌيڪ مجازي آهي ، پر XI `for_each` وڌيڪ اطالوي ٿي سگھي ٿو جڏهن شين کي پروسيسنگ ڪرڻ ڊگهن ايٽرر زنجير جي آخر ۾.
    ///
    /// ڪجهه حالتن ۾ `for_each` پڻ لوپ کان تيز ٿي سگهي ٿو ، ڇاڪاڻ ته اهو ايڪسڪسيمڪس وانگر ايڊپرٽرز تي اندروني تڪرار استعمال ڪندو.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// اهڙي نن exampleڙي مثال لاءِ ، ايڪس X00 لوپ صاف ٿي سگهي ٿو ، پر `for_each` ترجيح ٿي سگهي ٿي ته افعال ڊگهو ايٽرر سان گڏ ڪم ڪار جي طرز تي رکو.
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// اهو هڪ ايٽرر بڻائي ٿو جيڪو هڪ بندش استعمال ڪري ٿو اهو طئي ڪرڻ جي ته ڪنهن عنصر پيدا ٿيڻ گهرجي.
    ///
    /// عنصر کي ڏنو ويو بندش `true` يا `false` کي واپس ڪرڻ گھرجي.واپس ٿيل ورجاءُ صرف انهن عنصرن جي پيداوار ڪندو جن جي لاءِ بندش صحيح موٽندي آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ڇاڪاڻ ته بندش `filter()` ڏانهن ويو آهي هڪ حوالو ، ۽ ڪيترائي ورتاءُ حوالن مٿان ڏين ٿا ، اهو ممڪن طور تي مونجهاري واري صورتحال ڏانهن ڏسجي ٿو ، جتي بندش جو قسم ٻيڻو حوالو آهي:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // ٻن * جي ضرورت آهي!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// اهو عام طور تي هڪ کي هٽائڻ جي دليل تي تباهي وارو استعمال ڪرڻ بدران عام آهي:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ٻئي ۽ *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// يا ٻئي:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // ٻه &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// انهن تہه جا
    ///
    /// نوٽ ڪريو ته `iter.filter(f).next()` `iter.find(f)` جي برابر آهي.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// ايريٽر ٺاهي ٿو جيڪو ٻئي فلٽر ۽ نقشا.
    ///
    /// واپس ٿيل ايرايٽر صرف "قدر" حاصل ڪندو آهي جنهن جي لاءِ فراهم ڪيل بندش `Some(value)` موٽائي ٿي.
    ///
    /// `filter_map` [`filter`] ۽ [`map`] جي زنجيرن کي وڌيڪ جامع بڻائيندي استعمال ڪري سگهجي ٿو.
    /// هيٺ ڏنل مثال ڏيکاري ٿو ته ڪئين `map().filter().map()` هڪ ڪال کي نن00و ڪري سگهجي ٿو `filter_map` ڏانهن.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// هتي ساڳيو ئي مثال آهي ، پر [`filter`] ۽ [`map`] سان:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// اهو ايريٽر ٺاهي ٿو جيڪو موجوده ايٽرٽيشن ڳڻپ سان گڏوگڏ اگلي ويليو ڏئي ٿو.
    ///
    /// ايجريٽر واپس روانگي جوڙو `(i, val)` حاصل ڪري ٿو ، جتي `i` ورجائي جو موجوده انڊيڪس آهي ۽ `val` ويٽر پاران واپس ڪيل قدر آهي.
    ///
    ///
    /// `enumerate()` انهي جو شمار ھڪڙي [`usize`] طور تي رکي ٿو.
    /// جيڪڏهن توهان مختلف سڻڀو انٽيگر سان ڳڻپ ڪرڻ چاهيو ٿا ته [`zip`] فنڪشن ساڳئي ڪارڪردگي مهيا ڪري ٿو.
    ///
    /// # اوور رويو رويي
    ///
    /// طريقو اوورفلز جي خلاف ڪوبه تحفظ ناهي ، تنهنڪري [`usize::MAX`] کان وڌيڪ عناصر ڳڻڻ سان يا ته غلط نتيجو پيدا ڪري ٿي يا panics.
    /// جيڪڏهن ڊيبگ جا جزا فعال آهن ، هڪ panic گارنٽي آهي.
    ///
    /// # Panics
    ///
    /// جيڪڏهن واپس ٿيڻ وارو انڊيڪس ايڪس اين ايڪس ايڪس کي وڌيڪ ڌڪيندو ته جيڪڏهن واپس موٽڻ وارو انڊيڪس panic ٿي سگهي ٿو.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// اهو ايريٽر ٺاهي ٿو جيڪو استعمال ڪرڻ کان بغير ايٽرٽر جي ايندڙ عنصر کي ڏسڻ لاءِ [`peek`] استعمال ڪري سگهي ٿو.
    ///
    /// ايٽرريٽر ۾ [`peek`] طريقو شامل ٿئي ٿو.وڌيڪ forاڻ لاءِ ان جو دستاويز ڏسو.
    ///
    /// ياد رکو ته ٻلي آئي ٽيريٽر اڃا تائين ترقي يافته آهي جڏهن پهريون ڀيرو [`peek`] کي سڏيو وڃي ٿو: ايندڙ عنصر کي واپس وٺڻ لاءِ ، [`next`] کي هيٺئين ايريرٽر تي سڏيو وڃي ٿو ، تنهن ڪري ڪي به ضمني اثرات (يعني
    ///
    /// [`next`] طريقي جي ايندڙ قيمت آڻڻ کانسواءِ ڪجھ به ٿيندو.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() اسان کي future ۾ ڏسڻ ڏيو
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // اسان peek() ڀيرا ڪيترائي ڀيرا ڪري سگهون ٿا ، اهو ورجائيندڙ اڳتي نه وڌندو
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ايٽررٽر ختم ٿيڻ کان پوءِ ، اي peek() آهي
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// هڪ اعداوڪار ٺاهي ٿو ته [`ڇڏي ڏيو '] عنصرن جو بنياد بي بنياد.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` دليل طور بندش وٺندي آهي.اهو ايريٽرٽر جي هر عنصر تي بندش کي سڏيندو ، ۽ عناصر کي نظرانداز ڪرڻ جيستائين اهو `false` واپس اچي وڃي.
    ///
    /// `false` واپس ٿيڻ بعد ، `skip_while()`'s نوڪري ختم ٿي وئي آهي ، ۽ باقي عنصر پيدا ڪيا ويندا آهن.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ڇاڪاڻ ته بندش `skip_while()` ڏانهن ويو هڪ حوالو ، ۽ ڪيترائي ورتاءُ حوالن تي ڏين ٿا ، اهو ممڪن طور تي مونجهاري واري صورتحال ڏانهن ڏسجي ٿو ، جتي بندش جي دليل جو قسم ٻيڻو حوالو آهي:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // ٻن * جي ضرورت آهي!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// شروعاتي `false` کان پوءِ روڪي رهيو:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // جڏهن ته اهو غلط هوندو هئس ، جتان اسان اڳي ئي هڪ غلط هئاسين ، skip_while() وڌيڪ ڪو به استعمال نه ڪيو ويو آهي
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// اييريٽر ٺاهي ٿو جيڪا عناصر کي پريڊيڪيٽ تي ٻڌل آهي.
    ///
    /// `take_while()` دليل طور بندش وٺندي آهي.اهو بند ڪندڙ کي عنصر جي هر عنصر تي بند ڪندي ، ۽ پيداوار وارو عنصر جڏهن ته اهو `true` واپس ڪري ٿو.
    ///
    /// `false` واپس ٿيڻ کان پوءِ `take_while()`'s نوڪري ختم ٿي وئي آهي ، باقي ٻين عنصرن کي نظرانداز ڪيو وڃي ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ڇاڪاڻ ته بندش `take_while()` ڏانهن ويو آهي هڪ حوالو ، ۽ ڪيترائي ورتاءُ حوالن مٿان ڏين ٿا ، اهو ممڪن طور تي مونجهاري واري صورتحال ڏانهن ڏسجي ٿو ، جتي بندش جو قسم ٻيڻو حوالو آهي:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // ٻن * جي ضرورت آهي!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// شروعاتي `false` کان پوءِ روڪي رهيو:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // اسان وٽ وڌيڪ عنصر آهن جيڪي صفر کان گهٽ آهن ، پر جيئن ته اسان اڳ ۾ ئي هڪ غلط بڻجي چڪا آهيون ، take_while() وڌيڪ ڪونه استعمال ڪيو ويو آهي
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ڇو ته `take_while()` کي ڏسڻ لاءِ قيمت ڏسڻ جي ضرورت آهي ته ان ۾ شامل ٿيڻ گهرجي يا نه ، Iterators استعمال ڪندي اهو ڏسندا ته اهو ختم ٿي ويو:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` هاڻي ناهي رهي ، ڇاڪاڻ ته اهو ڏسڻ لاءِ خرچ ڪيو ويو ته ڇا ويڙهاڪ بند ٿيڻ گهرجي ، پر اهو ٻيهر ايئريٽر ۾ نه رکيو ويو آهي.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// هڪ ايريرٽر ٺاهي ٿو جنهن ٻنهي عنصرن کي بنياد ۽ نقشن تي ٻڌل بڻائي ٿو.
    ///
    /// `map_while()` دليل طور بندش وٺندي آهي.
    /// اهو بند ڪندڙ کي عنصر جي هر عنصر تي بند ڪندي ، ۽ پيداوار وارو عنصر جڏهن ته اهو [`Some(_)`][`Some`] واپس ڪري ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// هتي ساڳيو ئي مثال آهي ، پر [`take_while`] ۽ [`map`] سان:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// شروعاتي [`None`] کان پوءِ روڪي رهيو:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // اسان وٽ وڌيڪ عنصر هوندا آهن جيڪي u32 (4 ، 5) ۾ مناسب هوندا ، پر `map_while` `-3` کي واپس موٽائين ٿو `-3` (جئين ته `predicate` واپس `None`) ۽ `collect` پهريون `None` سان منسوب ٿي ويو.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// ڇو ته `map_while()` کي ڏسڻ لاءِ قيمت ڏسڻ جي ضرورت آهي ته ان ۾ شامل ٿيڻ گهرجي يا نه ، Iterators استعمال ڪندي اهو ڏسندا ته اهو ختم ٿي ويو:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` هاڻي ناهي رهي ، ڇاڪاڻ ته اهو ڏسڻ لاءِ خرچ ڪيو ويو ته ڇا ويڙهاڪ بند ٿيڻ گهرجي ، پر اهو ٻيهر ايئريٽر ۾ نه رکيو ويو آهي.
    ///
    /// ياد رکجو ته [`take_while`] جي برعڪس هي آئيرٽر ** نه ٿيل آهي فيوزن آهي.
    /// اهو پڻ مخصوص ناهي ته هي ايڪسٽر پهرين [`None`] واپس ٿيڻ کانپوءِ واپس ٿئي ٿو.
    /// جيڪڏهن توهان کي فيوزڊ ايٽيرٽر جي ضرورت آهي ، استعمال ڪريو [`fuse`]
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// اهو ايريٽر ٺاهي ٿو جيڪو پهرين `n` عناصر کي ڇڏي ٿو.
    ///
    /// انهن کي کائڻ کان پوء ، باقي عنصر پيدا ڪيا ويا آهن.
    /// ان طريقي سان سڌو سنئون پريشان ڪرڻ بدران ، بدران `nth` طريقي کي رد ڪريو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// ايريٽر ٺاهي ٿو جيڪا هن جي پهرين `n` عنصر پيدا ڪري ٿي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` اڪثر ڪري لامحدود ترتيب ڏيڻ واري سان استعمال ڪيو ويندو آهي ، انهي کي ختم ڪرڻ لاءِ.
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// جيڪڏهن `n` کان گهٽ عنصر موجود آهن ، `take` پاڻ کي هيٺيون ايٽرر جي سائيز تائين محدود ڪندو.
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// ايرٽر ائڊاپٽر جيڪو [`fold`] سان ملندڙ آهي جيڪو اندروني رياست رکي ٿو ۽ هڪ نئون ايٽرر پيدا ڪري ٿو.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` ٻه دليل وٺندو آهي: هڪ ابتدائي قيمت جيڪا اندروني رياست کي ٻجيندي آهي ، ۽ هڪ ٻن دليلن سان هڪ بندش ، پهرين اندرين رياست جو هڪ ٻيو قابل referenceيرندڙ حوالو ۽ ٻيو هڪ تسلسل وارو عنصر.
    ///
    /// بندش اندروني رياست ڏانهن مفاهمت جي رياست کي حصيداري ڪرڻ جو تفويض ڪري سگهي ٿو.
    ///
    /// ويتر تي ، بندش اطالوي جي هر عنصر تي لاڳو ٿيندي ۽ بند کان واپسي واري قيمت ، ايڪس X X هڪ ، ايٽرر پاران پيدا ڪيل آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // هر هڪ تسلسل ، اسين رياست کي عنصر سان وڌايون
    ///     *state = *state * x;
    ///
    ///     // پوءِ ، اسين رياست جي ناڪاريگي پيدا ڪنداسين
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// ايريٽر ٺاهي ٿو جيڪو نقشي وانگر ڪم ڪري ٿو ، پر گهريل جوڙ کي برابر بڻائي ٿو.
    ///
    /// [`map`] ايڊاپٽر تمام مفيد آهي ، پر صرف جڏهن بندش جي دليل قدرن کي پيدا ڪندي.
    /// جيڪڏهن ان جي بدران اهو ورجاءُ پيدا ٿئي ٿو ، اتي اڻ سڌيگي جي اضافي پرت آهي.
    /// `flat_map()` هي اضافي پرت پنهنجو پاڻ ختم ڪندو.
    ///
    /// توهان سوچي سگهو ٿا `flat_map(f)` جي برابر بنيادي طور تي ["نقشي"] پنگ ، ۽ پوء ["برابر"] `map(f).flatten()` ۾.
    ///
    /// `flat_map()` بابت سوچڻ جو ٻيو طريقو: [نقشي `] جي بندش هر عنصر لاءِ هڪ هڪ شيون موٽندي آهي ، ۽ `flat_map()`'s جي بندش هر عنصر لاءِ هڪ ورجاءُ موٽائي ٿي.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() هڪ واپسي واري موٽروي
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// ايريٽر ٺاهي ٿو جيڪو گھريل ٿيل ساخت کي structureهلائي ٿو.
    ///
    /// اهو مفيد آهي جڏهن توهان وٽ مهمانن جو هڪ مهمان يا شيون جو هڪ اعرار هجي جيڪو بار بار ٿي سگهي ٿو ۽ هڪ طرفي بندي کي ختم ڪرڻ چاهيو ٿا.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// نقشه سازي ڪرڻ ۽ پوءِ فليٽ ڪرڻ:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() هڪ واپسي واري موٽروي
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// توهان انهي کي [`flat_map()`] جي لحاظ سان ٻيهر لکي سگهو ٿا ، جيڪو هن صورت ۾ ترجيح آهي ڇاڪاڻ ته اهو وڌيڪ واضح اراده ٻڌائي ٿو.
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() هڪ واپسي واري موٽروي
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// فليٽ ڪرڻ صرف هڪ وقت بياني ڏيڻ واري سطح کي ختم ڪري ٿو:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// هتي اسان ڏسون ٿا ته `flatten()` فليٽن وارو "deep" انجام نٿو ڏي.
    /// پر ان جي بدران ، صرف نچڻ جي ھڪڙي سطح کي ڪ isيو ويندو آھي.اهو آهي ، جيڪڏهن توهان `flatten()` هڪ 3 طول و عرض کي ، نتيجو ٻه طول و عرض جو نه پر هڪ طول و عرض جو هوندو.
    /// هڪ متحرڪ structureانچي کي حاصل ڪرڻ لاءِ ، توهان کي ٻيهر `flatten()` ڪرڻو پوندو.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// ايريٽر ٺاهي ٿو جيڪو پهريون [`None`] کان پوءِ ختم ٿي وڃي ٿو.
    ///
    /// ايريٽر کان پوءِ [`None`] موٽي ٿو ، future ڪالون شايد [`Some(T)`] يا وري ٻيهر پيدا نه ڪن.
    /// `fuse()` هڪ ايريٽر کي ترتيب ڏئي ٿو ، انهي کي يقيني بڻائي ته هڪ [`None`] ڏنو ويو آهي ، اهو هميشه لاءِ [`None`] سدائين واپس ڪندو.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// // اهو هلندڙ جيڪو ڪجهه ۽ ڪوبه نه وچ ۾ متبادل آهي
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // جيڪڏهن اهو به ، Some(i32) ، ٻيو ڪو نه آهي
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // اسان ڏسي سگهو ٿا ته پنهنجو ايٽرر پوئتي ۽ پوئتي وڃي رهيو آهي
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // جڏهن ته ، هڪ ڀيرو اسان ان کي باڪس ڪيون ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // اهو هميشه پهرين وقت بعد `None` واپس ڪندو.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// ڇا اهو هڪ ايٽرٽر جي هر عنصر سان ڪجهه ڪري ٿو ، قدر کي پاس ڪرڻ.
    ///
    /// جڏهن اهو ورثو استعمال ڪندي ، توهان اڪثر ڪري ڪيترن ئي کي پاڻ سان گڏ سينگاريندا.
    /// اهڙي ڪوڊ تي ڪم ڪرڻ دوران ، توهان اهو معلوم ڪرڻ چاهيندا ته پائپ لائن ۾ مختلف حصن تي ڇا ٿي رهيو آهي.ائين ڪرڻ لاءِ ايڪس ڪال کي ايڪس داخل ڪريو.
    ///
    /// اهو عام طور تي توهان جي آخري ڪوڊ ۾ موجود ڊيبگنگ وارو اوزار طور استعمال ٿيڻ کان وڌيڪ عام آهي ، پر ايپليڪيشنون اهو خاص حالتن ۾ ڪارائتو ٿي سگهن ٿيون جڏهن غلطين کي رد ڪرڻ کان پهريان لاگ ان ٿيڻ جي ضرورت هجي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // اهو ايريٽر تسلسل پيچيده آهي.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // اچو ته ڪجهه ڪيو پيو وڃي inspect() ڪالز جاچڻ لاءِ ته ڇا ٿي رهيو آهي
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// اهو پرنٽ ڪندو:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// رد ڪرڻ کان پهريان لاگ ان ڪريو غلطيون:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// اهو پرنٽ ڪندو:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// اهو واپرائڻ بجاءِ هڪ ورجاءُ کي قرض وٺي ٿو.
    ///
    /// اهو ڪارائتو ائڊاپٽرز کي لاڳو ڪرڻ جي اجازت ڏيڻ لاءِ ڪارائتو آهي جڏهن ته اصلي ايٽرر جي ملڪيت برقرار رکي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // جيڪڏھن اسان ان کي ٻيهر استعمال ڪرڻ جي ڪوشش ڪريون ، اھو ڪم نه ڪندو.
    /// // هيٺئين لائن ڏنل آهي "غلطي: منتقل ٿيل قدر جو استعمال: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // اچو ته ان کي ٻيهر ڪوشش ڪريون
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ان جي بدران ، اسان ايڪس آرڪس ۾ شامل ڪريون ٿا
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // هاڻي اهو صرف ٺيڪ آهي:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// هڪ آئيرٽر هڪ مجموعي ۾ بدلائي ٿو.
    ///
    /// `collect()` ڪنهن به شيءِ کي دهرائڻ ، ۽ ان کي لاڳاپيل مجموعي ۾ بدلائڻ کپي.
    /// اهو معياري لائبريري ۾ وڌيڪ طاقتور طريقن جو آهي ، مختلف حوالن ۾ استعمال ڪيو ويو.
    ///
    /// سڀ کان بنيادي نموني جنهن ۾ `collect()` استعمال ڪيو ويندو آهي اهو هڪ مجموعي کي ٻئي ۾ intoيرائڻ آهي.
    /// توھان ھڪڙو مجموعو وٺو ، ان کي [`iter`] کي ڪال ڪريو ، ھڪڙي تبديلي جي ھڪڙي گچھه ڪريو ، ۽ پوء `collect()` آخر ۾.
    ///
    /// `collect()` انهن قسمن جا مثال پڻ ٺاهي سگھي ٿو جيڪي معمولي مجموعن نه هجن.
    /// مثال طور ، هڪ [`String`] [`char`] s کان تعمير ڪري سگھجي ٿو ، ۽ [`Result<T, E>`][`Result`] شيون جو ايٽرر `Result<Collection<T>, E>` گڏ ڪري سگهجي ٿو.
    ///
    /// وڌيڪ لاءِ هيٺ ڏنل مثال ڏسو.
    ///
    /// ڇاڪاڻ ته `collect()` ايترو عام آهي ، اهو قسم جي تعينات سان مسئلو پيدا ڪري سگهي ٿو.
    /// جيئن ته ، `collect()` ڪجھه ڀيرا آهي جيڪو توهان ان سان گڏ نحو کي ڏسي سگھوٿا 'turbofish' طور سڃاتو وڃي ٿو. `::<>`.
    /// اهو مددگار نتيجو الگورتھم کي سمجھڻ ۾ مدد ڪري ٿو جيڪو توهان گڏ ڪرڻ جي ڪوشش ڪري رهيا آهيو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// نوٽ ڪيو ته اسان کي کاٻي هٿ تي `: Vec<i32>` جي ضرورت هئي.اهو ڇو ته اسان گڏ ڪري سگهون ٿا ، مثال طور ، هڪ [`VecDeque<T>`] بدران:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// ايڪسڪسيمڪس استعمال ڪرڻ جي بدران 'turbofish' استعمال ڪندي:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ڇاڪاڻ ته `collect()` رڳو انهي جي پرواهه ڪندو آهي جنهن ۾ توهان جمع ڪري رهيا آهيو ، توهان اڃا تائين جزوي قسم جو اشارو ، `_` ، ٽربوفش سان استعمال ڪري سگهو ٿا:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ايڪسڪسيمڪس XXX ٺاھڻ لاءِ استعمال ڪيو:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// جيڪڏهن توهان وٽ هڪ فهرست آهي [نتيجو<T, E>ڏسو ته توهان `collect()` استعمال ڪري سگھوٿا ته انهن مان ڪو ناڪام ٿيو:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // اسان کي پهرين غلطي ڏئي ٿي
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // اسان کي جوابن جي لسٽ ڏي ٿو
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// هڪ آئيرٽر کي استعمال ڪري ٿو ، ان مان ٻه مجموعو ٺاهيندي آهي.
    ///
    /// نڪتو `partition()` ڏانهن ويو آهي `true` ، يا `false` واپس ڪري سگھي ٿو.
    /// `partition()` ھڪڙي جوڙي واپس ڏئي ٿو ، اھو سڀ عناصر جنھن لاءِ ھن کي `true` واپس ڪيو ، ۽ اھو سڀ عناصر جن جي لاءِ اھو `false` واپس ڪيو.
    ///
    ///
    /// پڻ ڏسو [`is_partitioned()`] ۽ [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// ڏنل ايراضي جي عناصر کي ترتيب ڏئي ٿو *جڳهه* ڏنل پيش ڪيل مطابق ، جيئن ته اهي سڀئي جيڪي `true` واپس ڪن ٿيون انهن سڀني کان اڳ آهن جيڪي `false` واپس ڪن ٿيون.
    ///
    /// `true` ملندڙ عنصرن جو تعداد ڏيکاري ٿو.
    ///
    /// ورهاitionي واري شين جي واسطيدار ترتيب برقرار ناھي.
    ///
    /// پڻ ڏسو [`is_partitioned()`] ۽ [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // ورها evي جي جڳهن ۽ خرابين جي وچ ۾ جاءِ
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ڇا اسان کي ڳڻپ ختم ٿيڻ جي باري ۾ پريشان ٿيڻ گهرجي؟وٽانھ کان فقط رستو آھي
        // `usize::MAX` مٽاسٽا وارا حوالا ZSTs سان آهن ، جيڪي ورها toي لاءِ ڪارآمد نه آهن.

        // اهي بندش "factory" ڪم ڪار موجود آهن `Self` ۾ سخاوت کان بچڻ.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // ٻيهر پهرين `false` کي ورجائي ڇڏيو ۽ ان کي آخري `true` سان ان کي مٽايو.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// چيڪ ڪريو ته ڇا هي ايٽرر جا عنصر predاڻايل پيش ڪيل مطابق ورهايل آهن ، جهڙوڪ جيڪي `true` موٽندا آهن انهن سڀني کان اڳ ڪن ٿيون جيڪي `false` واپس ڪن ٿا.
    ///
    ///
    /// پڻ ڏسو [`partition()`] ۽ [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // يا ته سڀئي شيون `true` ٽيسٽ ڪن ٿيون ، يا پهرين شق `false` وٽ رُڪي ٿي ۽ اسان چڪاس ڪيون ٿا ته هن کان پوءِ `true` وڌيڪ شيون نه آهن.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// اهو هڪ ايٽريرٽر طريقو جيڪو هڪ فنڪشن کي لاڳو ڪندو آهي جيستائين اهو ڪاميابي سان موٽي اچي ، هڪ ، آخري قدر پيدا ڪندي.
    ///
    /// `try_fold()` ٻه دليل وٺندو آهي: هڪ ابتدائي قدر ، ۽ هڪ بندش ٻن دليلن سان: هڪ 'accumulator' ، ۽ هڪ عنصر.
    /// بندش يا تو ڪاميابي سان موٽي ٿي ، انهي قيمت سان جيڪو جمع ڪندڙ کي ايندڙ ايراضي لاءِ ٿيڻ گهرجي ، يا اهو ناڪاميه موٽائي ٿو ، هڪ غلط قدر سان جنهن کي ڪالر تي واپس ايڪسپيڪس ڪيو وڃي ٿو.
    ///
    ///
    /// شروعاتي قيمت ويليو آھي جمع ڪندڙ کي پھريون ڪال تي.جيڪڏهن بندش لاڳو ڪندي ايريٽرر جي هر عنصر خلاف ڪامياب ٿي ، `try_fold()` ڪاميابي جي طور تي حتمي جمع ڪندڙ کي واپس ڪري ٿو.
    ///
    /// جڏهن به توهان کي ڪنهن شيءَ جو مجموعو هجي ، فولڊنگ مفيد آهي ، ۽ انهي مان هڪڙي قيمت پيدا ڪرڻ چاهيو ٿا.
    ///
    /// # عمل درآمد ڪندڙن جو نوٽ
    ///
    /// ڪيترن ئي ٻين (forward) طريقن جي ھڪڙي ھڪڙي شرط آھي ھڪڙي شرطن جي لحاظ سان ، تنھنڪري ھي نمايان طريقي سان عمل ڪرڻ جي ڪوشش ڪريو جيڪڏھن اھو ڪجھ ڊفالٽ `for` لوپ پليپشن کان ڪجھ بهتر ڪري سگھي.
    ///
    /// خاص طور تي ، ھن ڪال `try_fold()` کي اندروني حصن مان ھئڻ جي ڪوشش ڪريو جتان ھي ھيٽرٽر ٺھي وڃي.
    /// جيڪڏهن گھڻن ڪالن جي ضرورت آھي ، `?` هلائيندڙ جمع ڪرڻ واري قيمت سان جڙڻ لاءِ آسان ٿي سگھي ٿو ، پر ھميشه رھندڙن کان بچو جيڪي شروعاتي واپسي کان پھريائين برقرار رکيا وڃن.
    /// اهو `&mut self` طريقو آهي ، تنهنڪري غلطي کي هتان ڪرڻ بعد ٻيهر شروع ٿيڻ جي ضرورت آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // صف جي سڀني عنصرن جي چڪاس ڪيل رقم
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // هي رقم 100 عنصر کي شامل ڪرڻ دوران وڌي وئي
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // ڇاڪاڻ ته اهو مختصر گردش ۾ آهي ، باقي عنصر اڃا تائين ايٽرٽر ذريعي موجود آهن.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// اهو هڪ ورثو وارو طريقو جيڪو ايٽريٽر ۾ هر شي کي غلط ڪم ڪرڻ وارو هوندو آهي ، پهرين غلطي تي بيهڻ ۽ اها غلطي واپس ڪري رهيو آهي.
    ///
    ///
    /// اهو شايد [`for_each()`] جي قابل برداشت شڪل يا [`try_fold()`] جي غير مستحڪم نسخ جي طور تي سوچي سگھي ٿو.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // اهو مختصر گردش ۾ آهي ، تنهن ڪري باقي شيون اڃا تائين ايراضي ۾ آهن:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// هر عنصر کي آپريشن جي ذريعي جمع ڪندڙ کي ڳري ٿو ، آخري نتيجو موٽڻ.
    ///
    /// `fold()` ٻه دليل وٺندو آهي: هڪ ابتدائي قدر ، ۽ هڪ بندش ٻن دليلن سان: هڪ 'accumulator' ، ۽ هڪ عنصر.
    /// بندش قيمت واپس ڪري ٿو ته اچار کي ايندڙ ايراضي لاءِ ٿيڻ گھرجي.
    ///
    /// شروعاتي قيمت ويليو آھي جمع ڪندڙ کي پھريون ڪال تي.
    ///
    /// بند جي هر عنصر کي بند ڪرڻ جي درخواست ڪرڻ کان پوءِ ، ايڪس ايڪس ايڪس جمع ڪندڙ کي واپس ڪري ٿو.
    ///
    /// هي آپريشن ڪڏهن ڪڏهن 'reduce' يا 'inject' سڏيو ويندو آهي.
    ///
    /// جڏهن به توهان کي ڪنهن شيءَ جو مجموعو هجي ، فولڊنگ مفيد آهي ، ۽ انهي مان هڪڙي قيمت پيدا ڪرڻ چاهيو ٿا.
    ///
    /// Note: `fold()` ، ۽ ساڳيا طريقا جيڪي پوري ايجاد کي پار ڪري ، لامحدود ايٽرائيٽرز کي ختم نٿا ڪن ، ايستائين جو traits تي جنهن لاءِ نتيجو مقرر وقت ۾ طئي ٿي سگهندو آهي.
    ///
    /// Note: [`reduce()`] پهرين عنصر کي شروعاتي ويليو طور استعمال ڪرڻ لاءِ استعمال ڪري سگهجي ٿو ، جيڪڏهن ايڪريلٽر جو قسم ۽ شيءَ جو قسم ساڳيو آهي.
    ///
    /// # عمل درآمد ڪندڙن جو نوٽ
    ///
    /// ڪيترن ئي ٻين (forward) طريقن جي ھڪڙي ھڪڙي شرط آھي ھڪڙي شرطن جي لحاظ سان ، تنھنڪري ھي نمايان طريقي سان عمل ڪرڻ جي ڪوشش ڪريو جيڪڏھن اھو ڪجھ ڊفالٽ `for` لوپ پليپشن کان ڪجھ بهتر ڪري سگھي.
    ///
    ///
    /// خاص طور تي ، ھن ڪال `fold()` کي اندروني حصن مان ھئڻ جي ڪوشش ڪريو جتان ھي ھيٽرٽر ٺھي وڃي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // صف جي سڀني عنصرن جو مجموعو
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// اچو ته هتي ورها theي جي هر قدم ذريعي هلون.
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// ۽ ائين ، اسان جو آخري نتيجو ، `6`.
    ///
    /// اهو ماڻهن جي لاءِ عام آهي جن گهڻو ڪري استعمال ڪرڻ وارن کي فهرست جي شين جي فهرست سان `for` لوپ استعمال ڪرڻ جي لاءِ گهڻو ڪري استعمال نه ڪيو آهي ، هڪ نتيجو پيدا ڪرڻ.جن کي `fold()`s ۾ تبديل ڪري سگھجي ٿو:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // لوپ لاءِ
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // اهي هڪجهڙا آهن
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// عناصر کي گھٽائي ھڪڙي کي گھٽائي ٿو ، بار بار ھڪڙي گھٽائڻ واري آپريشن کي لاڳو ڪندي.
    ///
    /// جيڪڏهن اهو ايٽرر خالي آهي ، واپسي [`None`] ؛ٻي صورت ۾ ، واپسي جو نتيجو موٽائيندو.
    ///
    /// گهٽ ۾ گهٽ هڪ عنصر سان مذاڪر ڪرڻ وارن لاءِ ، اهو ئي ساڳيو عنصر [`fold()`] سان آهي ، ايريٽر جي پهرين عنصر وانگر ابتدائي قيمت ، پوئين هر عنصر کي ان ۾ fيرايو وڃي.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// وڌ کان وڌ ويليو ڳوليو
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// ٽيسٽ ڪري ٿو ته جيڪڏهن هر ايٽرٽر جو عنصر پرديئر سان ملي ٿو.
    ///
    /// `all()` هڪ بندش کڻي ٿو جيڪو `true` يا `false` موٽائي ٿو.اهو بندش انهي ايٽرٽر جي هر عنصر تي لاڳو ڪندو آهي ، ۽ جيڪڏهن اهي سڀئي واپس `true` ، ته ائين ئي `all()` ڪندو آهي.
    /// جيڪڏهن انهن مان ڪو به `false` موٽائيندو آهي ، اهو `false` واپس ڪندو آهي.
    ///
    /// `all()` نن-ڙو گردش ڪندڙ آهي ؛ٻين لفظن ۾ ، اهو `false` جي تلاش سان ئي اهو عمل ڪرڻ بند ڪري ڇڏيندو ، انهي چيو ته ٻيو ڇا ٿيندو ، انهي جو نتيجو به `false` ٿيندو.
    ///
    ///
    /// هڪ خالي ايريرٽر `true` موٽائي ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// پهرين ايڪسڪسيمڪس تي روڪڻ
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // اسان اڃا به `iter` استعمال ڪري سگهون ٿا ، ڇاڪاڻ ته هتي وڌيڪ عنصر آهن.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// ٽيسٽ جيڪڏهن ڪنهن ايٽرر جو عنصر ڪنهن predicate سان ملندو آهي.
    ///
    /// `any()` هڪ بندش کڻي ٿو جيڪو `true` يا `false` موٽائي ٿو.اهو بندش انهي ايٽرٽر جي هر عنصر ڏانهن لاڳو ڪندو آهي ، ۽ جيڪڏهن انهن مان ڪو `true` موٽائي ٿو ، ته ائين ئي `any()` ڪندو آهي.
    /// جيڪڏهن اهي سڀئي واپسي `false` ، اهو واپسي `false` تي.
    ///
    /// `any()` نن-ڙو گردش ڪندڙ آهي ؛ٻين لفظن ۾ ، اهو `true` جي تلاش سان ئي اهو عمل ڪرڻ بند ڪري ڇڏيندو ، انهي چيو ته ٻيو ڇا ٿيندو ، انهي جو نتيجو به `true` ٿيندو.
    ///
    ///
    /// هڪ خالي ايريرٽر `false` موٽائي ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// پهرين ايڪسڪسيمڪس تي روڪڻ
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // اسان اڃا به `iter` استعمال ڪري سگهون ٿا ، ڇاڪاڻ ته هتي وڌيڪ عنصر آهن.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// ايٽرريٽر جو عنصر تلاش ڪري ٿو جيڪو هڪ گدا کي مطمئن ڪري ٿو.
    ///
    /// `find()` هڪ بندش کڻي ٿو جيڪو `true` يا `false` موٽائي ٿو.
    /// اهو بندش انهي اطالوي جي هر عنصر ڏانهن لاڳو ڪندو آهي ، ۽ جيڪڏهن انهن مان ڪو `true` موٽندو آهي ، تڏهن `find()` واپس [`Some(element)`] ڪري ٿو.
    /// جيڪڏهن اهي سڀئي واپسي `false` ، اهو واپسي [`None`] تي.
    ///
    /// `find()` نن-ڙو گردش ڪندڙ آهي ؛ٻين لفظن ۾ ، اهو بند ٿيڻ سان ئي پروسيسنگ بند ٿي ويندو جئين ئي بندش `true` واپس اچي ٿي.
    ///
    /// ڇاڪاڻ ته `find()` ھڪڙي حوالو وٺندو آھي ، ۽ ڪيترائي ورڪرز حوالاجات کي ختم ڪن ٿا ، اھو ھڪڙي ممڪن صورت حال کي موڙيندو آھي ، جتي دليل ٻيڻو حوالو آھي.
    ///
    /// توهان `&&x` سان هيٺ ڏنل مثالن ۾ اهو اثر ڏسي سگهو ٿا.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// پهرين ايڪسڪسيمڪس تي روڪڻ
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // اسان اڃا به `iter` استعمال ڪري سگهون ٿا ، ڇاڪاڻ ته هتي وڌيڪ عنصر آهن.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// نوٽ ڪريو ته `iter.find(f)` `iter.filter(f).next()` جي برابر آهي.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// بار بار فعل کي لاڳو ڪندڙ عنصر کي لاڳو ڪري ٿو ۽ پهرين بي غير نتيجو ڏي ٿو.
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` جي برابر آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// ايٽرٽر جي عناصر کي فنڪشن لاڳو ڪري ٿو ۽ پهريون سچو نتيجو يا پھريون غلطي واپس ڪري ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// ايٽررٽر ۾ عنصر ڳولھيندي ، ان جي انڊيڪس واپس ڪندي.
    ///
    /// `position()` هڪ بندش کڻي ٿو جيڪو `true` يا `false` موٽائي ٿو.
    /// اهو بندش انهي اطالوي جي هر عنصر ڏانهن لاڳو ڪندو آهي ، ۽ جيڪڏهن انهن مان هڪ کي `true` موٽائي ٿو ، ته پوءِ `position()` [`Some(index)`] واپس ڪري ٿو.
    /// جيڪڏهن اهي سڀئي `false` واپس ڪن ٿا ، اهو [`None`] واپس ڪري ٿو.
    ///
    /// `position()` نن-ڙو گردش ڪندڙ آهي ؛ٻين لفظن ۾ ، اهو `true` جي ڳولا سان ئي پروسيسنگ بند ڪري ڇڏيندو.
    ///
    /// # اوور رويو رويي
    ///
    /// طريقو اوور فلوز کان بچاءُ ناهي رکي ، تنهنڪري جيڪڏهن [`usize::MAX`] سان وڌيڪ غير ملايل عنصر موجود آهن ، اهو يا ته غلط نتيجو پيدا ڪري ٿو يا panics.
    ///
    /// جيڪڏهن ڊيبگ جا جزا فعال آهن ، هڪ panic گارنٽي آهي.
    ///
    /// # Panics
    ///
    /// اهو فنڪشن panic ٿي سگهي ٿو جيڪڏهن ايٽررٽر `usize::MAX` کان وڌيڪ غير مماثل عنصر آهي.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// پهرين ايڪسڪسيمڪس تي روڪڻ
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // اسان اڃا به `iter` استعمال ڪري سگهون ٿا ، ڇاڪاڻ ته هتي وڌيڪ عنصر آهن.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // واپسي انڊيڪس انيٽرر رياست تي منحصر آهي
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// عنصر کي ڳوليندو آھي دائیں کان ٻرندڙ ، ان جي انڊيڪس کي واپس ڪرڻ.
    ///
    /// `rposition()` هڪ بندش کڻي ٿو جيڪو `true` يا `false` موٽائي ٿو.
    /// اهو بندش انهي اطالوي جي هر عنصر ڏانهن لاڳو ٿئي ٿو ، شروعات کان شروع ڪري ٿو ، ۽ جيڪڏهن انهن مان هڪ کي `true` موٽائي ٿو ، ته پوءِ `rposition()` واپس وڃي ٿو [`Some(index)`].
    ///
    /// جيڪڏهن اهي سڀئي `false` واپس ڪن ٿا ، اهو [`None`] واپس ڪري ٿو.
    ///
    /// `rposition()` نن-ڙو گردش ڪندڙ آهي ؛ٻين لفظن ۾ ، اهو `true` جي ڳولا سان ئي پروسيسنگ بند ڪري ڇڏيندو.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// پهرين ايڪسڪسيمڪس تي روڪڻ
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // اسان اڃا به `iter` استعمال ڪري سگهون ٿا ، ڇاڪاڻ ته هتي وڌيڪ عنصر آهن.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // ھتي وڌيڪ اوورفول چيڪ جي ضرورت ناھي ، ڇو ته `ExactSizeIterator` مطلب آھي ته عناصر جو تعداد `usize` ۾ پھچندو آھي.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// بار بار وڌندڙ عنصر کي ورجائي ٿو.
    ///
    /// جيڪڏھن ڪيترائي عنصر برابر آھن وڌ ۾ وڌ ، آخري عنصر واپس آھي.
    /// جيڪڏهن اهو ايٽرر خالي آهي ، [`None`] واپس ٿيو آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// گهٽ ۾ گهٽ عنصر کي بار بار ظاهر ڪري ٿو.
    ///
    /// جيڪڏهن ڪيترائي عنصر برابر گهٽ ۾ گهٽ هوندا آهن ، پهرين عنصر واپس ڪيو ويندو آهي.
    /// جيڪڏهن اهو ايٽرر خالي آهي ، [`None`] واپس ٿيو آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// عنصر ڏيکاري ٿو جيڪو مخصوص فنڪشن مان وڌ کان وڌ قدر ڏئي ٿو.
    ///
    ///
    /// جيڪڏھن ڪيترائي عنصر برابر آھن وڌ ۾ وڌ ، آخري عنصر واپس آھي.
    /// جيڪڏهن اهو ايٽرر خالي آهي ، [`None`] واپس ٿيو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// عنصر ڏيکاري ٿو جيڪو مخصوص مقابلي واري فنڪشن جي حوالي سان وڌ کان وڌ قيمت ڏي ٿو.
    ///
    ///
    /// جيڪڏھن ڪيترائي عنصر برابر آھن وڌ ۾ وڌ ، آخري عنصر واپس آھي.
    /// جيڪڏهن اهو ايٽرر خالي آهي ، [`None`] واپس ٿيو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// عنصر ڏيکاري ٿو جيڪو مخصوص فنڪشن مان گهٽ ۾ گهٽ قدر ڏئي ٿو.
    ///
    ///
    /// جيڪڏهن ڪيترائي عنصر برابر گهٽ ۾ گهٽ هوندا آهن ، پهرين عنصر واپس ڪيو ويندو آهي.
    /// جيڪڏهن اهو ايٽرر خالي آهي ، [`None`] واپس ٿيو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// عنصر ڏيکاريندو آھي جيڪو مخصوص مقابلي واري فنڪشن جي لحاظ کان گھٽ قيمت ڏيندو آھي.
    ///
    ///
    /// جيڪڏهن ڪيترائي عنصر برابر گهٽ ۾ گهٽ هوندا آهن ، پهرين عنصر واپس ڪيو ويندو آهي.
    /// جيڪڏهن اهو ايٽرر خالي آهي ، [`None`] واپس ٿيو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// هڪ ورائيٽر جي هدايت کي رد ڪري ٿو.
    ///
    /// عام طور تي ، اهو کاٻي کان سا rightي کان وهي ٿو.
    /// `rev()` استعمال ڪرڻ کان پوءِ ، اهو هڪ ايررٽر بدران سا rightي کان کاٻي کان وٺي ويندو.
    ///
    /// اهو صرف ممڪن آهي جيڪڏهن انٽراٽر جو هڪ انجام آهي ، تنهن ڪري `rev()` صرف [`DoubleEndedIterator`] تي ڪم ڪندو آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// ڪنٽرول جي هڪ جوڙي کي ڪنٽينر جي جوڙي ۾ تبديل ڪري ٿو.
    ///
    /// `unzip()` جوڙن جو هڪ مڪمل ايٽرر استعمال ڪندو آهي ، ٻه مجموعا پيدا ڪري ٿو: هڪ جوڙن جي کاٻي عناصر کان ، ۽ هڪ سا elementsي عنصرن کان.
    ///
    ///
    /// اهو فنڪشن ، ڪجهه معنى ۾ ، [`zip`] جي سامهون.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// ايريٽر ٺاهي ٿو جيڪو هن جي سڀني عنصرن کي نقل ڪري ٿو.
    ///
    /// اھو مفيد آھي جڏھن توھان کي `&T` کان وڌيڪ ايرايٽر هجي ، پر توھان کي `T` کان وڌيڪ ايرايٽر جي ضرورت آھي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // ڪاپي ڪيل .map(|&x| x) وانگر ساڳيو آهي
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// اهو ايريٽر ٺاهي ٿو جيڪو ["ڪلون"] ان جا سڀئي عنصر.
    ///
    /// اھو مفيد آھي جڏھن توھان کي `&T` کان وڌيڪ ايرايٽر هجي ، پر توھان کي `T` کان وڌيڪ ايرايٽر جي ضرورت آھي.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // ڪلونڊ .map(|&x| x) وانگر ساڳيو آهي ، اڪثريت وارن لاءِ
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// بار بار هڪ بار بار ورجائي ٿو.
    ///
    /// [`None`] کي بند ڪرڻ جي بدران ، ايٽررٽر ٻيهر شروع ٿي ويندو ، شروعات کان.اهو ٻيهر ورجائڻ کان پوءِ ، اهو ٻيهر شروع کان شروع ڪندو.۽ ٻيهر.
    /// ۽ ٻيهر.
    /// Forever.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// هڪ ويڙهاڪ جي عنصر کي شامل ڪري ٿو.
    ///
    /// هر عنصر ورتو ، انهن کي گڏ ڪيو ، ۽ نتيجو موٽائي ٿو.
    ///
    /// خالي ايريرٽر ان قسم جي صفر قدر واپس ڪري ٿو.
    ///
    /// # Panics
    ///
    /// جڏهن `sum()` کي سڏيندي ۽ هڪ پرائمري انٽيگر قسم واپس ڪئي پئي وڃي ، اهو طريقو panic هوندو جيڪڏهن ڪمپيوٽنگ اوور فلو ۽ ڊيبگ جزنز چالو ٿئي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// اهو مڪمل ايٽررٽر تي ٻيهر مچائي ٿو ، سڀني عنصرن کي ضرب ڏئي ٿو
    ///
    /// خالي iterator ، ھڪڙي قسم جي ھڪڙي قيمت موٽائي ٿو.
    ///
    /// # Panics
    ///
    /// جڏهن `product()` کي سڏيندي ۽ هڪ پرائمري انٽيگر قسم واپس ڪئي وڃي ، طريقو panic جيڪڏهن حساب بندي جي فلوشن ۽ ڊيبگ جزن کي چالو ڪيو وڃي ها.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) هن [`Iterator`] جي عناصر سان ڪنهن ٻئي سان ڀيٽيندو آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) هن [`Iterator`] جي عناصر کي ٻئي کان ٻئي سان طئي ڪيو ويو مخصوص نسخي جي فنڪشن جي لحاظ سان.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) هن [`Iterator`] جي عناصر سان ڪنهن ٻئي سان ڀيٽيندو آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) هن [`Iterator`] جي عناصر کي ٻئي کان ٻئي سان طئي ڪيو ويو مخصوص نسخي جي فنڪشن جي لحاظ سان.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// اهو طئي ڪري ٿو ته جيڪڏهن هي [`Iterator`] جا عنصر ٻئي جا برابر آهن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// اهو طئي ڪري ٿو ته جيڪڏهن ايڪس [`Iterator`] جا عنصر مخصوص مساوات واري فنڪشن جي حوالي سان ٻئي سان برابر آهن.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// اهو طئي ڪري ٿو ته جيڪڏهن [`Iterator`] جا عنصر هڪ ٻئي جا نه برابر آهن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// اهو طئي ڪري ٿو ته جيڪڏهن [`Iterator`] جا عنصر [lexicographically](Ord#lexicographical-comparison) ڪنهن ٻئي کان گهٽ آهن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// اهو معلوم ڪري ٿو ته جيڪڏهن [`Iterator`] جا عنصر [lexicographically](Ord#lexicographical-comparison) گهٽ يا ٻئي ڪنهن جا برابر آهن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// اهو معلوم ڪري ٿو ته جيڪڏهن [`Iterator`] جا عنصر [lexicographically](Ord#lexicographical-comparison) ٻئي کان ٻئي کان وڌيڪ آهن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// اهو معلوم ڪري ٿو ته جيڪڏهن [`Iterator`] جا عنصر [lexicographically](Ord#lexicographical-comparison) ٻئي کان وڌيڪ يا برابر آهن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// چيڪ ڪريو ته ڇا هن آئيٽر جي عناصر کي ترتيب ڏنل آهي.
    ///
    /// اھو آھي ، ھر عنصر `a` ۽ ان جي ھيٺان عنصر `b` لاءِ ، `a <= b` ضرور رکي ٿو.جيڪڏهن ايريٽر صحيح صفر يا هڪ عنصر پيدا ڪري ٿو ، `true` واپس ڪيو وڃي.
    ///
    /// ياد رکو ته جيڪڏهن `Self::Item` صرف `PartialOrd` آهي ، پر `Ord` نه ، مٿي ڏنل تعريف مان پتو پوي ٿو ته اهو فنڪشن `false` موٽائي ٿو جيڪڏهن ٻه مسلسل لڳل شيون برابر نه هجن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// چيڪ ڪريو ته جيڪڏهن هن اٽلر جا عنصر ڏنل موازنہ واري فنڪشن کي ترتيب ڏني وڃي.
    ///
    /// `PartialOrd::partial_cmp` استعمال ڪرڻ بدران ، اهو فنڪشن ڏنو ويو `compare` فنڪشن کي ٻن عنصرن جي ترتيب جو تعين ڪرڻ لاءِ.
    /// ان کان سواء ، اهو برابر آهي [`is_sorted`]؛وڌيڪ forاڻ لاءِ ان جو دستاويز ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// چيڪ ڪريو ته انهي ايٽرر جي عناصر ڏنل ڏنل ڪ extrڻ واري فنڪشن کي استعمال ڪندي ترتيب ڏنل آهن.
    ///
    /// اهو آئيٽرر جي عنصرن جو سڌو سنئون مقابلو ڪرڻ بدران ، هي فنڪشن عنصرن جي چيڪن جو مقابلو ڪري ٿو ، جئين `f` ذريعي طئي ٿيل آهي.
    /// ان کان سواء ، اهو برابر آهي [`is_sorted`]؛وڌيڪ forاڻ لاءِ ان جو دستاويز ڏسو.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] ڏسو
    // غير معمولي نالو طريقن جي قرارداد ۾ نالو ٽوڙڻ کان بچڻ آهي #76479 ڏسو.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}