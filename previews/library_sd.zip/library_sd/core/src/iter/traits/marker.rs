/// اهو هلندڙ مرڪز جيڪو هميشه ختم ٿيڻ وقت `None` جو پيداوار جاري رکي ٿو.
///
/// هڪ فون ٿيل آئيٽرر تي ايندڙ کي فون ڪري ٿو جيڪو هڪ ڀيرو `None` واپس ڪري چڪو آهي [`None`] ٻيهر واپس ڪرڻ جي ضمانت آهي.
/// اهو trait سڀني ايئيرٽرز جي طرفان لاڳو ٿيڻ گهرجي جيڪو هن طريقي سان عمل ڪن ٿا ڇاڪاڻ ته اهو [`Iterator::fuse()`] کي بهتر ڪرڻ جي اجازت ڏئي ٿو.
///
///
/// Note: عام طور تي ، توهان کي عام حدن ۾ `FusedIterator` استعمال نه ڪرڻ گهرجي جيڪڏهن توهان فيوزڊ ايٽررٽر جي ضرورت آهي.
/// ان جي بدران ، توهان کي صرف ايئريٽر تي [`Iterator::fuse()`] کي ڪال ڪرڻ گهرجي.
/// جيڪڏهن اهو ويڙهاڪ اڳ ۾ ئي ڀusedي ويو آهي ، اضافي [`Fuse`] وارپر نه هوندو آهي ڪارڪردگي سان گڏ ڏنڊ.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// اهو هلندڙ جيڪو هڪ لمبائي سائيز جي رپورٽ ڪري ٿو
///
/// ايريٽر هڪ سائيز جي اشارو ڏئي ٿو جتي اهو صحيح آهي (هيٺين حد برابر حد تائين برابر آهي) ، يا اوپري حد [`None`] آهي.
///
/// مٿين حد کي صرف [`None`] هجڻ گهرجي جيڪڏهن حقيقي ايريرٽر جي ڊيگهه [`usize::MAX`] کان وڏي هجي.
/// انهي صورت ۾ ، هيٺين حد [`usize::MAX`] هجڻ گهرجي ، نتيجي ۾ `(usize::MAX, None)` جي [`Iterator::size_hint()`].
///
/// هلندڙ کي لازمي طور تي عنصر ظاهر ڪرڻ لازمي آهي
///
/// # Safety
///
/// هن trait صرف ان وقت لاڳو ڪئي وڃي جڏهن معاهدو برقرار آهي.
/// هن trait جي استعمال ڪندڙن کي [`Iterator::size_hint()`]’s اپر بائونڊ جو معائنو ڪرڻ لازمي آهي.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// هڪ هلندڙ اهو ته جڏهن هڪ شيءَ جي پيداوار گهٽ ۾ گهٽ هڪ عنصر پنهنجي بنيادي [`SourceIter`] کان ورتو هوندو.
///
/// ڪو به طريقو سڏڻ جيڪو ورائيٽر کي اڳتي وڌائي ، مثال طور
/// [`next()`] يا [`try_fold()`] ، ضمانت ڏي ٿو ته هر قدم لاءِ ايٽررٽر جي بنيادي ذريعه جي گهٽ ۾ گهٽ هڪ قدر منتقل ڪئي وئي آهي ۽ ايريٽر چينل جو نتيجو ان جي جاءِ تي داخل ٿي سگهيو آهي ، فرض ڪيو ته ذريعن جي اڏاوتي رڪاوٽن کي اهڙي داخلي جي اجازت ڏين.
///
/// ٻين لفظن ۾ هن trait ظاهر ٿئي ٿو ته هڪ آئيرٽر جي پائپ لائن هڪ هنڌ گڏ ڪري سگهجي ٿي.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}