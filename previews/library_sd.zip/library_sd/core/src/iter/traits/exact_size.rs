/// هڪ ويڙهاڪ جيڪو ان جي صحيح ڊيگهه knowsاڻي ٿو.
///
/// ڪيترائي [Iterator] کي نٿا howاڻن ته ڪيترا دفعا اھو انرار ڪندو ، پر ڪجھ ڪن ٿا.
/// جيڪڏهن اهو ورثو knowsاڻي ٿو ته ڪيترا ڀيرا اهو ٻيهر ٿي سگھي ٿو ، انهي معلومات جي رسائي مددگار ثابت ٿي سگهي ٿي.
/// مثال طور ، جيڪڏهن توهان پوئتي موٽ ڪرڻ چاهيو ٿا ، هڪ سٺي شروعات اها toاڻڻ آهي ته آخر ڪٿي آهي.
///
/// جڏهن `ExactSizeIterator` لاڳو ڪرڻ ، توهان کي [`Iterator`] پڻ لاڳو ڪرڻ گهرجي.
/// جڏهن ائين ڪرڻ تي ، [`Iterator::size_hint`]*جي نفاذ لازمي* موٽائي جي صحيح سائيز کي واپس اچڻ گهرجي.
///
/// [`len`] طريقو ھڪڙو ٺھيل عمل درآمد آھي ، تنھنڪري توھان عام طور تي ان کي لاڳو نھ ڪرڻ گھرجي.
/// تنهن هوندي ، توهان ڊفالٽ کان وڌيڪ پرفارمنس وارو نفاذ مهيا ڪري سگهندا آهيو ، تنهن ڪري ان صورت ۾ ان کي ختم ڪرڻ سان عقل پيدا ٿي.
///
///
/// ياد رکجو ته هي trait محفوظ trait آهي ۽ جئين طور تي *نه* ۽ *نٿو چئي سگھجي ٿو* واپسي واري صحيح صحيح آهي.
/// ان جو مطلب آهي ته `unsafe` ڪوڊ **کي** X00 جي درستگي تي اعتبار نه ڪرڻ گهرجي.
/// غير مستحڪم ۽ غير محفوظ [`TrustedLen`](super::marker::TrustedLen) trait ھن اضافي گارنٽي ڏئي ٿو.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// // هڪ محدود حد knowsاڻي ٿي ته ڪيترا ئي ڀيرا ان تي عمل ڪندو
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs] ۾ ، اسان هڪ [`Iterator`] لاڳو ڪيو ، `Counter`.
/// اچو ته انهي جي لاء `ExactSizeIterator` کي لاڳو ڪريون.
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // اسان آرام سان ورجاءُ جي باقي تعداد کي ڳڻپ ڪري سگھون ٿا.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // ۽ ھاڻي اسان استعمال ڪري سگھوٿا!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// ايرير جي صحيح لمبائي ڏي ٿو.
    ///
    /// عمل درآمد يقيني بنائي ٿو ته ايٽرر [`None`] موٽڻ کان پهريان [`Some(T)`] ويل جي ڀيٽ ۾ وڌيڪ `len()` وڌيڪ بارَ واپس ڪندو.
    ///
    /// هن طريقي جو هڪ ڊفالٽ نفاذ آهي ، تنهن ڪري توهان عام طور تي ان کي سڌو سنئون لاڳو نه ڪرڻ گهرجي.
    /// تنهن هوندي ، جيڪڏهن توهان هڪ وڌيڪ موثر عمل درآمد مهيا ڪري سگهو ٿا ، توهان ائين ڪري سگهو ٿا.
    /// مثال طور [trait-level] ڊاڪيوڪس ڏسو.
    ///
    /// انهي ڪم ۾ ساڳي حفاظت گارنٽي آهي جيترو [`Iterator::size_hint`] فنڪشن.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// // هڪ محدود حد knowsاڻي ٿي ته ڪيترا ئي ڀيرا ان تي عمل ڪندو
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: اهو زور گهڻو دفاعي آهي ، پر اهو انوڙيار کي چيڪ ڪري ٿو
        // trait طرفان ضمانت ڏنل.
        // جيڪڏهن اهو trait rust اندروني هو ، اسان استعمال ڪري سگھون ٿا debug_assert!assert_eq!سڀ Rust استعمال ڪندڙ ادارن کي پڻ چيڪ ڪندو.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// ايڪس ايٽرڪس کي واپسي ڏئي ٿو جيڪڏهن آئي ٽيرير خالي هجي.
    ///
    /// هن طريقي ۾ [`ExactSizeIterator::len()`] استعمال ڪندي هڪ ڊفالٽ نفاذ آهي ، تنهن ڪري توهان ان کي پاڻ تي لاڳو ڪرڻ جي ضرورت ناهي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}