/// هڪ [`Iterator`] کان تبديلي.
///
/// ھڪڙي قسم جي `FromIterator` لاڳو ڪرڻ سان ، توھان بيان ڪيو ته اھو ھڪڙي آئيٽرٽر مان ڪيئن ٺاھيو ويندو.
/// اهو انهن قسمن لاءِ عام آهي جيڪي ڪجهه قسم جو مجموعو بيان ڪن ٿا.
///
/// [`FromIterator::from_iter()`] عام طور تي صاف طور تي سڏيو ويندو آهي ، ۽ انهي جي بدران [`Iterator::collect()`] طريقي سان استعمال ڪيو ويو آهي
///
/// وڌيڪ مثالن لاءِ [`Iterator::collect()`]'s دستاويز ڏسو.
///
/// به ڏسو [`IntoIterator`].
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// بي بي XXX استعمال ڪرڻ جي واضح طور تي استعمال ڪرڻ:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// توهان جي قسم لاءِ ايڪسڪسيمڪس لاڳو ڪندي:
///
/// ```
/// use std::iter::FromIterator;
///
/// // هڪ نمونو گڏ ڪرڻ ، اها صرف Vec تي ويڙهيل آهي<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // اچو ته ان کي ڪجهه طريقا ڏيو ته اسين هڪ ٺاهي سگهون ٿا ۽ ان ۾ شيون شامل ڪري سگهون ٿا.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ۽ اسين FromIterator تي عمل ڪنداسين
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // هاڻي اسان نئون ايٽرر ڪري سگهون ٿا ۔۔۔
/// let iter = (0..5).into_iter();
///
/// // ... ۽ ان مان پنهنجو MyCollection ٺاهيو
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // گڏ ڪيو ڪم پڻ!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// آئيرٽر کان ويليو ٺاهي ٿو.
    ///
    /// وڌيڪ لاءِ [module-level documentation] ڏسو.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// [`Iterator`] ۾ تبديلي.
///
/// هڪ قسم جي لاءِ `IntoIterator` لاڳو ڪرڻ سان ، توهان وضاحت ڪيو ٿا ته اهو هڪ آئيرٽر ۾ ڪيئن بدلجي ويندو.
/// اهو انهن قسمن لاءِ عام آهي جيڪي ڪجهه قسم جو مجموعو بيان ڪن ٿا.
///
/// `IntoIterator` لاڳو ڪرڻ جو هڪ فائدو اهو آهي ته توهان جو قسم ايڪس ڪيوڪس ڪندو.
///
///
/// به ڏسو [`FromIterator`].
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// توهان جي قسم لاءِ ايڪسڪسيمڪس لاڳو ڪندي:
///
/// ```
/// // هڪ نمونو گڏ ڪرڻ ، اها صرف Vec تي ويڙهيل آهي<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // اچو ته ان کي ڪجهه طريقا ڏيو ته اسين هڪ ٺاهي سگهون ٿا ۽ ان ۾ شيون شامل ڪري سگهون ٿا.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ۽ اسين انڊيٽرٽر نافذ ڪنداسين
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // هاڻي اسان نئون مجموعو ٺاهي سگھون ٿا ۔۔۔
/// let mut c = MyCollection::new();
///
/// // ... انهي ۾ ڪجهه شامل ڪيو ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... ۽ پوءِ ان کي يڪٽر ۾ turnيرائي:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// اهو `IntoIterator` کي trait bound طور استعمال ڪرڻ عام آهي.اهو انپٽ ڪليڪشن جي قسم کي تبديل ڪرڻ جي اجازت ڏئي ٿو ، جيستائين اهو اڃا تائين هڪ ورجائي وارو آهي.
/// اضافي پابنديون محدود ڪندي بيان ڪري سگهجن ٿيون
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// عناصر جي قسم کي ختم ٿي رهيو آهي.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// اسين ڪهڙي قسم جو بار بار ان کي تبديل ڪري رهيا آهيون؟
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// ويليو کان ايٽرريٽر ٺاهي ٿو.
    ///
    /// وڌيڪ لاءِ [module-level documentation] ڏسو.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// هڪ زياده جي مواد سان گڏ مجموعو وڌايو.
///
/// آئيٽرٽر قدرن جو هڪ سلسلو پيدا ڪن ٿا ، ۽ مجموعن کي قدرن جو هڪ سلسلو به سوچي سگهجي ٿو.
/// `Extend` trait هن خسيج کي پُلائي ٿي ، توهان کي اجازت ڏي ٿو ته مجموعو وڌائڻ جي ڪري انهي ايٽرر جي مواد کي شامل ڪندي.
/// جڏهن اڳئين موجود شيڊ سان گڏ ڪليڪشن وڌائيندي ، ته داخلا تازه ڪاري ٿي ويندي آهي ، يا مجموعن جي صورت ۾ ، جيڪي برابر چيڪن سان گهڻن داخلا جي اجازت ڏيندا آهن ، داخلا داخل ڪئي ويندي آهي.
///
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// // توهان ڪجهه ڪردارن سان هڪ اسٽرنگ وڌائي سگهو ٿا:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` لاڳو ڪرڻ:
///
/// ```
/// // هڪ نمونو گڏ ڪرڻ ، اها صرف Vec تي ويڙهيل آهي<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // اچو ته ان کي ڪجهه طريقا ڏيو ته اسين هڪ ٺاهي سگهون ٿا ۽ ان ۾ شيون شامل ڪري سگهون ٿا.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // جڏهن کان MyCollection ۾ i32s جي فهرست آهي ، اسان ايڪسٽي ايڪس لاءِ ايڪسينڊ کي لاڳو ڪيو آهي
/// impl Extend<i32> for MyCollection {
///
///     // اهو ذرا سادو آهي ڪنڪريڪ قسم جي دستخط سان: اسان هر شي تي وڌائي سگهون ٿا جيڪو ايٽرٽر ۾ بدلجي وڃي ٿو جيڪو اسان کي I32s ڏئي ٿو.
///     // ڇو ته اسان کي MyCollection ۾ رکڻ لاءِ i32s جي ضرورت آهي.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // جي عملدرآمد تمام سڌو آهي: ايٽررٽر ذريعي لوپ ، ۽ add() هر عنصر پنهنجو پاڻ ڏانهن.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // اچو ته وڌيڪ تعداد سان گڏ پنهنجو مجموعو وڌايون
/// c.extend(vec![1, 2, 3]);
///
/// // اسان اهي عنصر آخر ۾ شامل ڪيا
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// هڪ دڪان کي هڪ ورجائيندڙ جي مواد سان گڏ وڌائيندو آهي.
    ///
    /// جئين ته اھو trait لاءِ واحد گهربل طريقو آھي ، [trait-level] ڊاڪٽس وڌيڪ تفصيل سان گڏ آھن.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// // توهان ڪجهه ڪردارن سان هڪ اسٽرنگ وڌائي سگهو ٿا:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// ھڪڙي عنصر سان گڏ ھڪڙي مجموعي کي وڌايو.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// اضافي عناصر جي ڏنل تعداد لاءِ مجموعي ۾ ذخيرو ڪري ٿو.
    ///
    /// ڊفالٽ پلي ڪجهه نه ڪندو آهي.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}