use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// اهو هلندڙ هڪ مرڪز جيڪو ٻه ٻين ايجاد کي هڪ ئي وقت ڪري ٿو.
///
/// هي `struct` ايڪس اين ايم ايڪس طرفان ٺهيل آهي.
/// وڌيڪ لاءِ ان جي دستاويز ڏسو.
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // index ، len ۽ a_len صرف زپ جو مخصوص نسخو استعمال ڪندي آهي
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // حفاظت: `ZipImpl::__iterator_get_unchecked` وٽ ھڪڙو ئي حفاظت آھي
        // گهرجن ايڪس آرڪس وانگر.
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// جپ اسپيشلائيزيشن trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // انهي `Iterator::__iterator_get_unchecked` وانگر ساڳيون حفاظت گهربل آهن
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// جنرل زپ امپي
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // ترتيب ڏيو a ، b برابر برابر
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // حفاظت: `i` `self.len` کان نن isو آھي ، اھڙي طرح `self.a.len()` ۽ `self.b.len()` کان نن smallerو آھي
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // بنيادي عمل درآمد جي امڪاني ضمني اثرات سان حفاظت ڪريو حفاظت: اسان صرف چڪاس ڪيو ته `i` <`self.a.len()`
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // حفاظت: `cmp::min` کي `delta` حساب ڪرڻ جو استعمال
                // انهي کي يقيني بڻائي ٿي ته `end` `self.len` کان نن orو يا برابر آهي ، تنهن ڪري `i` `self.len` کان به نن isو آهي.
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // حفاظت: ساڳي طرح مٿي.
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // اي ، ب برابر برابر طئه ڪريو ، پڪ ڪيو ته صرف `next_back` جي پهرين ڪال هي ڪرڻ کپي ، ٻي صورت ۾ اسان `get_unchecked()` کي ڪال ڪرڻ کان پوءِ `self.next_back()` جي ڪالن تي پابندي و willائي ڇڏينداسين.
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // حفاظت: `i` `self.len` جي پوئين قدر کان نن isو آھي ،
            // جيڪو پڻ `self.a.len()` ۽ `self.b.len()` جي برابر يا برابر آهي
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // حفاظت: ڪال ڪندڙ کي `Iterator::__iterator_get_unchecked` ٺيڪي کي برقرار رکڻ گهرجي.
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// ثالث طور Zip iteration جي کاٻي پاسي کي منتخب ڪيو ايڪس X X XUMX طور طور چونڊيو ويندو ، ان کي ٻنهي جي ڪوشش ڪرڻ جي لاءِ منفي trait bounds جي ضرورت هوندي.
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // حفاظت: غير محفوظ فنڪشن کي غير ضروري ڪم ڪرڻ لاءِ ساڳين گهرجن سان گڏ
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// آئٽم تائين محدود: نقل جي ذريعي زوري جي TrustedRandomAccess جي استعمال جي وچ ۾ باهمي تعلق ۽ ذريعه لاڳو ٿيڻ ڊراپ واضح ناهي.
//
// اضافي طريقي سان ماخذن کي واپس ڪرڻ جو ڪو طريقو منطقي طور تي ترقي ڪئي وئي آهي (next()) کي ڪال ڪرڻ کان سواءِ ذري گهٽ ذري گهٽ ڇڏڻ جي ضرورت پوندي).
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // اهو *محفوظ نه آهي* تي مشتمل آئيٽرز تي fmt سڏ ڪرڻ ، جڏهن کان اسين هڪ ڀيرو ٻيهر شروع ڪندا آهيون اهي عجيب ، امڪاني طور تي غير محفوظ رياستن ۾ آهن.
        //
        f.debug_struct("Zip").finish()
    }
}

/// اهو هڪ تسلسل آهي جنهن جون شيون بي ترتيب نموني سان رسائي لائق آهن
///
/// # Safety
///
/// الٽرر جو `size_hint` ڪال ڪرڻ لاءِ صحيح ۽ سستا هجڻ لازمي آهي.
///
/// `size` ختم نه ٿي ڪري سگهجي.
///
/// `<Self as Iterator>::__iterator_get_unchecked` لازمي طور تي هيٺين شرطن تي پورا ٿيڻ لاءِ ڪال محفوظ هجڻ لازمي آهي.
///
/// 1. `0 <= idx` ۽ ايڪس 600.
/// 2. جيڪڏهن `self: !Clone` ، پوء `get_unchecked` هڪ ڀيرو وڌيڪ هڪ ڀيرو کان وڌيڪ `self` تي ساڳيو انڊيڪس سان نه سڏيو ويو آهي.
/// 3. `self.get_unchecked(idx)` کي سڏڻ کان پوءِ `next_back` صرف `self.size() - idx - 1` بار کي سڏ ڪيو ويندو.
/// 4. `get_unchecked` کي سڏڻ کان پوءِ ، `self` تي صرف هيٺيان طريقا سڏيا ويندا.
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// وڌيڪ ، ڏنو ويو ته اهي شرطون پوريون ٿين ، ان کي لازمي طور تي گارنٽي ڏيڻ گهرجي:
///
/// * اهو `size_hint` کان واپس موٽڻ واري قيمت کي تبديل نٿو ڪري
/// * ايڪسڪسيمڪس تي مٿي ڏنل طريقي سان ڪالون ڪرڻ لازمي آهي `get_unchecked` ڪال ڪرڻ کان پوءِ ، فرض ڪيو وڃي ته گهربل traits نافذ ڪيو وڃي.
///
/// * `get_unchecked` کي ڪال ڪرڻ کانپوءِ `self` کي گهٽائڻ لاءِ پڻ محفوظ هجڻ گهرجي.
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // آسان طريقو.
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` جيڪڏهن هڪ اٽرريٽر عنصر حاصل ٿي سگهي ٿو ضمني اثرات.
    /// اندروني ايريررز کي حساب ۾ رکڻ جي ياد رکو.
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// `Iterator::__iterator_get_unchecked` وانگر ، پر ان کي ilerاڻڻ جي ضرورت ناهي ته `U: TrustedRandomAccess` theاڻ ڏيو.
///
///
/// ## Safety
///
/// ساڳي ضرورتن کي `get_unchecked` کي سڏي ٿو.
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // حفاظت: ڪال ڪندڙ کي `Iterator::__iterator_get_unchecked` ٺيڪي کي برقرار رکڻ گهرجي.
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// جيڪڏهن `Self: TrustedRandomAccess` ، اهو `Iterator::__iterator_get_unchecked(self, index)` کي ڪال ڪرڻ لاءِ محفوظ هجڻ لازمي آهي.
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // حفاظت: ڪال ڪندڙ کي `Iterator::__iterator_get_unchecked` ٺيڪي کي برقرار رکڻ گهرجي.
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}