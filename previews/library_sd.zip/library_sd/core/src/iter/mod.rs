//! ٺهيل ٻاهرين تڪرار.
//!
//! جيڪڏهن توهان پنهنجو پاڻ کي ڪنهن قسم جي مجموعن سان مليو آهي ، ۽ توهان کي انهي مجموعي جي عناصر تي آپريشن ڪرڻ جي ضرورت آهي ، توهان جلدي ۾ آڻينداسين 'iterators'.
//! محاوراتي Rust ڪوڊ ۾ آئيٽرٽر گهڻو ڪري استعمال ڪيا ويندا آهن ، ان ڪري اهو انهن سان واقف ٿيڻ جي لائق آهي.
//!
//! وڌيڪ وضاحت ڪرڻ کان پهريان ، اچو ته ڳالهايون ته هي ماڊل ڪيئن ٺهيل آهي:
//!
//! # Organization
//!
//! هي ماڊل وڏي قسم جي ترتيب سان ترتيب ڏنل آهي.
//!
//! * [Traits] بنيادي حصو آهن: اهي traits وضاحت ڪن ٿا ته ڪهڙي قسم جا بار بار موجود آهن ۽ توهان انهن سان ڇا ڪري سگهو ٿا.هنن traits جا طريقا ڪجهه وڌيڪ پڙهائي جي وقت ۾ رکڻ جي قابل آهن.
//! * [Functions] ڪجهه بنيادي اعداو ٺاهڻ لاءِ ڪجهه مددگار طريقا مهيا ڪريو.
//! * [Structs] اڪثر ڪري هن ماڊل جي traits تي مختلف طريقن جي واپسي جا قسم آهن.توهان عام طور تي `struct` ٺاهيندڙ طريقي سان ڏسڻ جو طريقو ڏسڻ چاهيندا.
//! ڇو لاءِ وڌيڪ تفصيل لاءِ ، ڏسو '[لاڳو ڪرڻ وارو آئيٽرٽر](#پليٽنگ-ايريٽر)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! بس اهو آهي!اچو ته ويڙهاڪن ۾ کٽيو.
//!
//! # Iterator
//!
//! هن ماڊل جي دل ۽ روح [`Iterator`] trait آهي.[`Iterator`] جو بنيادي هيٺيان ڏسڻ جهڙو آهي:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! انيريٽر جو هڪ طريقو آهي ، [`next`] ، جنهن کي جڏهن سڏيو وڃي ٿو ، هڪ [اختيار] کي واپس ڏئي ٿو<Item>".
//! [`next`] [`Some(Item)`] جي واپسي آڻيندو جيستائين جيستائين عنصر آهن ، ۽ هڪ ڀيرو اهي سڀ ختم ٿي ويا آهن ، `None` واپس آڻيندا ته اهو اشارو ڏيڻ ته عمل ختم ٿي ويو آهي.
//! انفرادي ايٽرر ٻيهر چونڊ ٻيهر ڪرڻ جو انتخاب ڪري سگھن ٿا ، ۽ تنهن ڪري [`next`] ٻيهر ڪال ڪري سگھي ٿو يا ٿي سگھي ٿو ته آخرڪار ڪنهن به وقت [`Some(Item)`] ٻيهر موٽڻ شروع نه ڪري (مثال طور ، [`TryIter`] ڏسو).
//!
//!
//! [`آئيٽرٽر`] جي مڪمل تعريف ۾ ٻين ڪيترن ئي طريقن سان گڏ شامل آهن ، پر اهي پهريان کان طئي ٿيل طريقا آهن ، ايڪس اين ايڪس ايڪس کان مٿي تعمير ڪيل آهن ، ۽ انهي ڪري توهان انهن کي مفت حاصل ڪندا آهيو.
//!
//! آئيٽرٽر پڻ ٺهيل آهن ، ۽ اهو عام آهي ته انهن کي پروسيسنگ جي وڌيڪ پيچيده شڪلون ڪرڻ لاءِ گڏ ڪرڻ.وڌيڪ تفصيل لاءِ هيٺ ڏنل [Adapters](#adapters) سيڪشن ڏسو.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # انڪاريءَ جا ٽي روپ
//!
//! هتي ٽي عام طريقا آهن جيڪي هڪ مجموعي مان ورڪر ٺاهي سگهن ٿا:
//!
//! * `iter()`, جيڪو `&T` کان وڌيڪ وٺي ٿو.
//! * `iter_mut()`, جيڪو `&mut T` کان وڌيڪ وٺي ٿو.
//! * `into_iter()`, جيڪو `T` کان وڌيڪ وٺي ٿو.
//!
//! معياري لائبريري ۾ مختلف شيون هڪ يا وڌيڪ ٽن کان لاڳو ٿي سگهن ٿيون ، جتي مناسب هجي.
//!
//! # آئيٽرٽر کي لاڳو ڪرڻ
//!
//! توهان جي پنهنجي آئيريٽر ٺاهڻ ۾ ٻه قدم شامل آهن: ايٽيرٽر جي حالت کي منعقد ڪرڻ لاءِ `struct` ٺاهڻ ۽ پوءِ ان لاءِ [`Iterator`] لاڳو ڪرڻ.
//! اهو ئي سبب آهي ته هن ماڊل ۾ ڪيتريون ئي `اڏاوتون` آهن: هر هڪ ايريٽر ۽ ايريٽر ايڊاپٽر لاءِ هڪ آهي.
//!
//! اچو ته `Counter` نالي هڪ ورجاءُ بڻايون جيڪو `1` کان `5` تائين شمار ڪري ٿو.
//!
//! ```
//! // پهرين ، جوڙجڪ:
//!
//! /// اهو هلندڙ هڪ مرڪز جيڪو هڪ کان پنجن تائين ڳڻپ ڪري ٿو
//! struct Counter {
//!     count: usize,
//! }
//!
//! // اسان چاهيون ٿا ته اسان جي ڳڻپ هڪٻئي کان شروع ٿئي ، تنهن ڪري مدد لاءِ ايڪس ڪنڪس جو طريقو شامل ڪريون ٿا.
//! // اهو سختي سان ضروري ناهي ، پر آسان آهي.
//! // نوٽ ڪريو ته اسان `count` کي صفر تي شروع ڪريون ٿا ، اسين ڏسنداسين ته `next()`'s جي ھيٺان عمل ھيٺ اچي ٿو.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // پوءِ ، اسان پنهنجي `Counter` لاءِ `Iterator` لاڳو ڪيو ٿا:
//!
//! impl Iterator for Counter {
//!     // اسان کي ڳڻپ سان ڳڻينداسين
//!     type Item = usize;
//!
//!     // next() فقط گهربل طريقو آهي
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // اسان جي ڳڻپ کي وڌايو.اهو ڇو آھي اسان صفر تي شروع ڪيو.
//!         self.count += 1;
//!
//!         // چيڪ ڪريو ته اسان ڳڻپ ختم ڪري چڪا آھيون يا نه.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // ۽ ھاڻي اسان استعمال ڪري سگھوٿا!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! انهي طريقي سان [`next`] ڪال ڪرڻ بار بار ڪيو ويندو آهي.Rust وٽ ھڪڙو ٺاھيو آھي جيڪو [`next`] کي توھان جي ٽيرير تي ڪال ڪري سگھي ٿو ، جيستائين اھو `None` تي پھچي.اچو ته اڳتي هلون.
//!
//! اهو به نوٽ ڪريو ته `Iterator` طريقن جا ڊفالٽ نفاذ مهيا ڪندو آهي جهڙوڪ `nth` ۽ `fold` جيڪي `next` اندروني سڏ ڪن ٿا.
//! تنهن هوندي ، ايڪس01ڪس ۽ `fold` جهڙوڪ طريقن جي هڪ ڪسٽمائيز نفاذ لکڻ پڻ ممڪن آهي جيڪڏهن ايٽررٽر `next` کي فون ڪرڻ کانسواءِ انهن کي وڌيڪ ڪارائتو بڻائي سگهي ٿو.
//!
//! # `for` لوپس ۽ ايڪسڪسيمڪس
//!
//! Rust جي `for` لوپ نحوي اصل ۾ اٽرر لاءِ شگر آهي.هتي `for` جو بنيادي مثال آهي:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! اهو نمبر هڪ کان پنج تائين پرنٽ ڪندو ، هر هڪ پنهنجي پنهنجي ليڪ تي.پر توهان هتي ڪجهه محسوس ڪنداسين: اسان کي ايٽرر تيار ڪرڻ لاءِ اسان ڪڏهن به vector تي ڪجهه به ناهي سڏيو.ڇا ڪري ٿو؟
//!
//! هتي معياري لائبريري ۾ trait موجود آهي ته ڪا شي کي ايٽرر ۾ تبديل ڪرڻ لاءِ: [`IntoIterator`].
//! ھي trait ھڪڙو طريقو آھي ، [`into_iter`] ، جيڪو ايڪس01 ايڪس کي لاڳو ڪرڻ واري شيءِ کي ايٽريٽر ۾ بدلائي ٿو.
//! اچو ته `for` لوپ ٻيهر هڪ نظر وجهون ، ۽ ڇا مرتب ڪندڙ ان کي تبديل ڪري
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust هن کي ختم ڪري ٿو:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! پهرين ، اسان قيمت تي `into_iter()` چوندا آهيون.ان کان پوء ، اسان واپسي واري ايٽرٽر تي ملون ٿا ، جيڪو [`next`] کي ڪال ڪري رهيو آهي مٿي ۽ وڌيڪ تائين جيستائين اسان `None` ڏسندا آهيون.
//! انهي موقعي تي ، اسان `break` لوپ مان ٻاهر نڪتاسين ، ۽ اسان اهو ڪري رهيا آهيون.
//!
//! هتي هڪ وڌيڪ ذيلي بيٽ آهي: معياري لائبريري [`IntoIterator`] جو هڪ دلچسپ نفاذ تي مشتمل آهي:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! ٻين لفظن ۾ ، سڀني [`آئيٽرٽر] جو ايڪسينڪس لاڳو ڪيو وڃي ، صرف پنهنجو پاڻ واپس موٽڻ سان.هن جو مطلب آهي ٻه شيون:
//!
//! 1. جيڪڏهن توهان هڪ [`Iterator`] لکي رهيا آهيو ، توهان ان کي `for` لوپ سان استعمال ڪري سگهو ٿا.
//! 2. جيڪڏهن توهان مجموعو ٺاهي رهيا آهيو ، انهي لاءِ [`IntoIterator`] لاڳو ڪرڻ توهان جي جمع کي `for` لوپ سان استعمال ڪرڻ جي اجازت ڏيندا.
//!
//! # حوالي سان ترتيب ڏيڻ
//!
//! کان وٺي [`into_iter()`] قيمت ذريعي `self` وٺي ٿو ، هڪ جمع ڪرڻ تي ايڪس آرڪسڪس لوپ استعمال ڪندي اهو مجموعو استعمال ڪندو آهي.گهڻو ڪري ، توهان ان کي استعمال ڪرڻ کان بغير ڪنهن ٻئي مجموعي تي ٻيهر جاري رکڻ چاهيندا.
//! ڪيترائي مجموعا طريقا پيش ڪن ٿا جيڪي حوالن مٿان بار بار مهيا ڪن ٿا ، روايتي طور تي `iter()` ۽ `iter_mut()` سڏيو وڃي ٿو:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` اڃا تائين انهي فنڪشن جي ملڪيت آهي.
//! ```
//!
//! جيڪڏهن هڪ جمع ڪندڙ قسم `C` `iter()` مهيا ڪندو آهي ، اهو عام طور تي `IntoIterator` کي `&C` به لاڳو ڪري ٿو ، هڪ عمل درآمد سان جيڪو صرف `iter()` کي سڏيندو آهي.
//! اهڙي طرح ، هڪ مجموعو `C` جيڪو `iter_mut()` مهيا ڪندو آهي عام طور تي `IntoIterator` کي `iter_mut()` ڏانهن ڏيهي وڃڻ سان لاڳو ڪندو آهي.هي هڪ آسان شارٿانٽ بڻائيندو آهي:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // ساڳيو `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // ساڳيو `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! جڏهن ته ڪيترائي مجموعا `iter()` پيش ڪن ٿا ، سڀئي پيشڪش `iter_mut()` نه.
//! مثال طور ، هڪ [`HashSet<T>`] يا [`HashMap<K, V>`] جي چابين کي موٽائي ڏيڻ سان گڏ ڪليڪشن کي متضاد حالت ۾ آڻي سگهي ٿو جيڪڏهن ڪيش هشس تبديل ٿي وڃي ، تنهن ڪري اهي مجموعا صرف `iter()` پيش ڪن ٿا.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! ڪارناما جيڪي [`Iterator`] وٺي وٺن ٿا ۽ ٻيو [`Iterator`] واپس ڪن ٿا ، اڪثر ڪري ان کي "ايجريٽر ايڊاپٽرز" سڏين ٿا ، ڇاڪاڻ ته اهي ايڊاپٽر جو هڪ روپ آهن
//! pattern'.
//!
//! عام ايريرٽر ايڊاپٽرز ۾ [`map`] ، [`take`] ، ۽ [`filter`] شامل آهن.
//! وڌيڪ لاءِ ، انهن جو دستاويز ڏسو.
//!
//! جيڪڏهن آئي ٽيريٽر اڊاپٽر panics ، اهو ايٽرر هڪ غير متعين (پر ياداشت محفوظ) حالت ۾ هوندو.
//! هن رياست ۾ Rust جي ساڳئي ورزن تي رهڻ جي گارنٽي پڻ ناهي ، تنهن ڪري توهان کي هڪ آرير طرفان موٽيل ڪيل صحيح قدرن تي ڀروسو ڪرڻ کان پاسو ڪرڻ گهرجي جنهن کان ڊ panي ٿي ويا.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! ايٽرٽر (۽ ايٽررٽر [adapters](#adapters))*سست* آھن. ان جو مطلب آھي ته صرف ايٽرريٽر ٺاھڻ ۾ س0ي _do_ ڪونھي. اصل تائين ڪجھ به واقعو نٿو ٿئي جيستائين توھان [`next`] فون نٿا ڪريو.
//! اهو ڪڏهن ڪڏهن انتشار جو ذريعو هوندو آهي جڏهن ته صرف ان جي ضمني اثرات لاءِ ويڙهاڪ بڻجندا.
//! مثال طور ، [`map`] طريقو هر عنصر تي هڪ بند کي سڏيندو آهي اهو ورجائي ٿو:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! اهو ڪوبه قدر نه پرنٽ ڪندو ، جئين اسان صرف ان کي استعمال ڪرڻ بدران ، ٻيهر ورجائي بڻايون.مرتب ڪندڙ اسان کي ان قسم جي روين بابت خبردار ڪندو.
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! [`map`] ان جي ضمني اثرات جي لاءِ لکڻ جو محاوري طريقو اهو آهي ته `for` لوپ استعمال ڪريو يا [`for_each`] طريقو کي ڪال ڪريو:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! ايٽرر جو جائزو وٺڻ جو ٻيو عام طريقو [`collect`] طريقو استعمال ڪرڻ آهي هڪ نئون گڏ ڪرڻ لاءِ.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! آئيٽرس کي فنا ٿيڻو نه آهي.مثال طور ، هڪ کليل ختم ٿيندڙ حد هڪ لامحدود ايجادر آهي:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! هڪ عام طور تي [`take`] ايٽيرٽر اڊاپٽر کي استعمال ڪرڻ واري لامحدود ورزن کي محدود ڪرڻ ۾ استعمال ڪرڻ آهي:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! اهو نمبر `0` کان `4` تائين ، هر هڪ پنهنجي پنهنجي لائن تي پرنٽ ڪندو.
//!
//! ذهن ۾ رکون ٿا ته لامحدود ايجادرز تي طريقا ، اهي به جن جا نتيجا جتن کي رياضياتي طور تي فني وقت ۾ طئي ڪري سگهجن ٿا ، ختم نٿا ٿي سگهن.
//! خاص طور تي ، [`min`] وانگر طريقا ، جيڪي عام صورت ۾ ورثي ۾ هر عنصر کي ڇڪڻ جي ضرورت هوندي آهي ، ممڪن آهي ته ڪنهن به لامحدود اڪارٽرز کي ڪاميابي سان واپس نه موجن.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // اڙي نه!هڪ لامحدود لوپ!
//! // `ones.min()` هڪ لامحدود لوپ جو سبب بڻجندو ، تنهنڪري اسان هن مقام تي نه پهچي سگهنداسين!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;