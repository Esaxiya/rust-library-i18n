use crate::iter::{FusedIterator, TrustedLen};

/// ايٽرريٽر ٺاهي ٿو جيڪا سست رفتار مهيا ڪيل بند کي دعوت ڏيڻ سان هڪ ڀيرو قيمت پيدا ڪري ٿي.
///
/// اهو عام طور تي استعمال ڪيو ويندو آهي هڪ واحد جنريٽر کي ٻين قسمن جي ورها Xي جي [`chain()`] ۾ ترتيب ڏيڻ.
/// ٿي سگهي ٿو توهان وٽ هڪ بار بار آهي جيڪو تقريبن هر شي کي coversڪي ٿو ، پر توهان کي اضافي خاص ڪيس جي ضرورت آهي.
/// ٿي سگهي ٿو توهان وٽ هڪ فنڪشن هجي جيڪو ايريٽرز تي ڪم ڪندو آهي ، پر توهان کي صرف هڪ ويليو کي پروسيس ڪرڻ جي ضرورت آهي.
///
/// [`once()`] جي برعڪس ، ھي فنڪشن سستگي سان درخواست تي قدر پيدا ڪندو.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// use std::iter;
///
/// // اڪيلو اڪيلو نمبر آهي
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // بس هڪ ، اهو سڀ ڪجهه اسان حاصل ڪري ورتو آهي
/// assert_eq!(None, one.next());
/// ```
///
/// هڪ ٻئي آئيٽرر سان گڏ سلسلو جاري رهيو.
/// اچو ته چوندا آهيون ته اسان `.foo` ڊاريڪٽري جي هر فائل تي ٻيهر ورزي ڪرڻ چاهيون ٿا ، پر هڪ ترتيب واري فائيل پڻ ،
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // اسان کي DirEntry-s جي هڪ ورجاءُ کي PathBufs جي ايررٽر ۾ تبديل ڪرڻ جي ضرورت آهي ، انهي ڪري اسان نقشو استعمال ڪريون ٿا
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // هاڻي ، صرف اسان جي فائل ترتيب ڏيندڙ ترتيب ڏيندڙ
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // ٻن ايٽررائٽس کي هڪ وڏو ايرررٽر ۾ گڏ ڪيو
/// let files = dirs.chain(config);
///
/// // ھي .foo ۽ .foorc ۾ اسان سڀني فائلن کي ڏيندو
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// هڪ هلندڙ مرڪز جيڪو مهيا ڪيل بندش `F: FnOnce() -> A` لاڳو ڪندي `A` قسم جو هڪڙو عنصر پيدا ڪري ٿو.
///
///
/// هي `struct` [`once_with()`] فنڪشن پاران ٺهيل آهي.
/// وڌيڪ لاءِ ان جي دستاويز ڏسو.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}