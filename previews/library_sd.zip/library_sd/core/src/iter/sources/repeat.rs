use crate::iter::{FusedIterator, TrustedLen};

/// هڪ نئون ايريرٽر ٺاهي ٿو جيڪو هڪ عنصر کي آهستي آهستي ختم ڪري ٿو.
///
/// `repeat()` فعل ھڪڙي ھڪڙي قدر بار بار کي ورجائي ٿو.
///
/// `repeat()` وانگر لامحدود ورثاء اڪثر ڪري [`Iterator::take()`] وانگر ائڊاپٽرس سان استعمال ٿيندا آهن ، انهن کي فني بڻائڻ لاءِ.
///
/// جيڪڏهن آئيٽرر جو عنصر قسم توهان کي `Clone` لاڳو نٿو ٿئي ، يا جيڪڏهن توهان بار بار عنصر کي ياد ۾ رکڻ نٿا چاهيو ، توهان بدران [`repeat_with()`] فنڪشن استعمال ڪري سگهو ٿا.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// use std::iter;
///
/// // نمبر چار 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // ها ، اڃا چار
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] سان فني وڃڻ وارو:
///
/// ```
/// use std::iter;
///
/// // آخري آخري مثال تمام گھڻيون چار آھي.اچو ته صرف چار چار.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ۽ هاڻي اسان ٿي چڪا آهيون
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// اهو هڪ ورثو جيڪو هڪ عنصر کي لاتعداد طور ختم ڪري ٿو.
///
/// هي `struct` [`repeat()`] فنڪشن پاران ٺهيل آهي.وڌيڪ لاءِ ان جي دستاويز ڏسو.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}