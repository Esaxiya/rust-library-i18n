use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// شيون جنهن وٽ *جانشين* ۽ *اڳڪٿيون* آپريشنز جو تصور هجي.
///
/// *جانشين* آپريشن انهن قدرن ڏانهن وڌي ٿو جيڪي عظيم ٿين ٿا.
/// * * اڳڪٿي * آپريشن قدرن ڏانهن وڌي ٿو جيڪي گهٽ موازنہ ڪن ٿا.
///
/// # Safety
///
/// اهو trait ايڪسڪسيمڪس آهي ڇاڪاڻ ته انهي جو نفاذ `unsafe trait TrustedLen` عمل درآمد جي حفاظت لاءِ صحيح هجڻ گهرجي ، ۽ هن trait استعمال ڪرڻ جا نتيجا ٻي صورت ۾ `unsafe` ڪوڊ تي ڀروسو ٿي سگهي ٿو صحيح ۽ درج ٿيل الزامن کي پورو ڪرڻ.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// *01 کي `end` کان حاصل ڪرڻ جي لاءِ* جانشين * قدمن جا نمبر ورجائي ٿو.
    ///
    /// `None` کي واپسي ڏئي ٿو جيڪڏهن قدمن جو تعداد `usize` اوور فلو ڪندو (يا لامحدود آهي ، يا جيڪڏهن `end` ڪڏهن به نه پهچي ها).
    ///
    ///
    /// # Invariants
    ///
    /// ڪنھن به `a` ، `b` ۽ `n` لاءِ:
    ///
    /// * `steps_between(&a, &b) == Some(n)` جيڪڏهن ۽ صرف جيڪڏهن `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` جيڪڏهن ۽ صرف جيڪڏهن `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` صرف جيڪڏهن `a <= b`
    ///   * صداقت: `steps_between(&a, &b) == Some(0)` جيڪڏهن ۽ صرف جيڪڏهن `a == b`
    ///   * ياد رکجو ته `a <= b` ڇا _not_ ڪندو آھي `steps_between(&a, &b) != None` ؛
    ///     اهو معاملو آهي جڏهن `b` ڏانهن `usize::MAX` قدم کان وڌيڪ قدمن جي ضرورت هوندي
    /// * `steps_between(&a, &b) == None` جيڪڏهن `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// قدر موٽائي ٿو جيڪا `self` `count` جي *جانشين* کي وٺڻ سان حاصل ڪئي ويندي.
    ///
    /// جيڪڏهن اهو `Self` سان سهڪار وارن قدرن جي حد تائين وڌي ويندو ، ايڪس ايڪس ايڪس کي واپسي ڏئي ٿو.
    ///
    /// # Invariants
    ///
    /// ڪنھن به `a` ، `n` ۽ `m` لاءِ:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// ڪنهن به `a` ، `n` ۽ `m` جي لاءِ جتي `n + m` اوور فال نه ٿو ڪري:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// ڪنهن به `a` ۽ `n` لاءِ:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// قدر موٽائي ٿو جيڪا `self` `count` جي *جانشين* کي وٺڻ سان حاصل ڪئي ويندي.
    ///
    /// جيڪڏهن اهو `Self` طرفان سپورٽ ڪيل اقدار جي حد کي وڌائي سگهندي ، هن فنڪشن کي panic ، لفاف ڪرڻ ، يا ستو ڪرڻ جي اجازت آهي.
    ///
    /// تجويز ڪيل رويو panic ڏانهن آهي جڏهن ڊيبگ جزا فعال ڪيا ويا آهن ، ۽ ٻي صورت ۾ لفاف ڪرڻ يا لفافي ڪرڻ.
    ///
    /// غير محفوظ ڪوڊ اوور فلو ٿيڻ کانپوءِ رويي جي درستگي تي ڀروسو نه رکڻ گهرجي.
    ///
    /// # Invariants
    ///
    /// ڪنهن به `a` ، `n` ۽ `m` لاءِ ، جتي ڪوبه اوور فلو ٿئي ٿو:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// ڪنھن به `a` ۽ `n` لاءِ ، جتي ڪو اوور فلو ٿئي ٿو:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// قدر موٽائي ٿو جيڪا `self` `count` جي *جانشين* کي وٺڻ سان حاصل ڪئي ويندي.
    ///
    /// # Safety
    ///
    /// هن ايڪس اين ايم ايڪس سان سهڪار ڪيل قدرن جي حد تائين وڌي وڃڻ لاءِ هن آپريشن لاءِ غير معياري رويو آهي.
    /// جيڪڏهن توهان گارنٽي نٿا ڪري سگھو ته اهو وڌيڪ نه وڌائيندو ، استعمال ڪريو `forward` يا `forward_checked` بدران.
    ///
    /// # Invariants
    ///
    /// ڪنهن به `a` لاءِ
    ///
    /// * جيڪڏهن `b` موجود آهي جهڙوڪ `b > a` ، اهو محفوظ ڪرڻ لاءِ `Step::forward_unchecked(a, 1)` آهي
    /// * جيڪڏهن اتي موجود آهي `b` ، `n` اهڙو `steps_between(&a, &b) == Some(n)` ، اهو محفوظ آهي `Step::forward_unchecked(a, m)` ڪنهن به `m <= n` لاءِ.
    ///
    ///
    /// ڪنھن به `a` ۽ `n` لاءِ ، جتي ڪو اوور فلو ٿئي ٿو:
    ///
    /// * `Step::forward_unchecked(a, n)` `Step::forward(a, n)` جي برابر آهي
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// قدر ڏي ٿو جيڪا `self` `count` ڀيرا * * اڳوڻي * حاصل ڪندي حاصل ڪئي ويندي.
    ///
    /// جيڪڏهن اهو `Self` سان سهڪار وارن قدرن جي حد تائين وڌي ويندو ، ايڪس ايڪس ايڪس کي واپسي ڏئي ٿو.
    ///
    /// # Invariants
    ///
    /// ڪنھن به `a` ، `n` ۽ `m` لاءِ:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// ڪنهن به `a` ۽ `n` لاءِ:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// قدر ڏي ٿو جيڪا `self` `count` ڀيرا * * اڳوڻي * حاصل ڪندي حاصل ڪئي ويندي.
    ///
    /// جيڪڏهن اهو `Self` طرفان سپورٽ ڪيل اقدار جي حد کي وڌائي سگهندي ، هن فنڪشن کي panic ، لفاف ڪرڻ ، يا ستو ڪرڻ جي اجازت آهي.
    ///
    /// تجويز ڪيل رويو panic ڏانهن آهي جڏهن ڊيبگ جزا فعال ڪيا ويا آهن ، ۽ ٻي صورت ۾ لفاف ڪرڻ يا لفافي ڪرڻ.
    ///
    /// غير محفوظ ڪوڊ اوور فلو ٿيڻ کانپوءِ رويي جي درستگي تي ڀروسو نه رکڻ گهرجي.
    ///
    /// # Invariants
    ///
    /// ڪنهن به `a` ، `n` ۽ `m` لاءِ ، جتي ڪوبه اوور فلو ٿئي ٿو:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// ڪنھن به `a` ۽ `n` لاءِ ، جتي ڪو اوور فلو ٿئي ٿو:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// قدر ڏي ٿو جيڪا `self` `count` ڀيرا * * اڳوڻي * حاصل ڪندي حاصل ڪئي ويندي.
    ///
    /// # Safety
    ///
    /// هن ايڪس اين ايم ايڪس سان سهڪار ڪيل قدرن جي حد تائين وڌي وڃڻ لاءِ هن آپريشن لاءِ غير معياري رويو آهي.
    /// جيڪڏهن توهان گارنٽي نٿا ڪري سگھو ته اهو وڌيڪ نه وڌائيندو ، استعمال ڪريو `backward` يا `backward_checked` بدران.
    ///
    /// # Invariants
    ///
    /// ڪنهن به `a` لاءِ
    ///
    /// * جيڪڏهن `b` موجود آهي جهڙوڪ `b < a` ، اهو محفوظ ڪرڻ لاءِ `Step::backward_unchecked(a, 1)` آهي
    /// * جيڪڏهن اتي موجود آهي `b` ، `n` اهڙو `steps_between(&b, &a) == Some(n)` ، اهو محفوظ آهي `Step::backward_unchecked(a, m)` ڪنهن به `m <= n` لاءِ.
    ///
    ///
    /// ڪنھن به `a` ۽ `n` لاءِ ، جتي ڪو اوور فلو ٿئي ٿو:
    ///
    /// * `Step::backward_unchecked(a, n)` `Step::backward(a, n)` جي برابر آهي
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// اهي اڃا تائين ميڪو پيدا ٿيل آهن ڇاڪاڻ ته انٽيگر لفظي مختلف قسمن ڏانهن حل ٿين ٿا.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // حفاظت: ڪالر کي ضمانت ڏيڻو آھي ته `start + n` اوور فلو نه ڪندو آھي.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // حفاظت: ڪالر کي ضمانت ڏيڻو آھي ته `start - n` اوور فلو نه ڪندو آھي.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // ڊيبگ اڏن ۾ ، اوور چلو تي panic ڇڪيو.
            // اهو مڪمل طور تي آزاد ٿيڻ واري عمارتن ۾ ٻاهر نڪرڻ گهرجي.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // مثال طور اجازت ڏيڻ لاءِ ريپنگ ميٿ ڪندا `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // ڊيبگ اڏن ۾ ، اوور چلو تي panic ڇڪيو.
            // اهو مڪمل طور تي آزاد ٿيڻ واري عمارتن ۾ ٻاهر نڪرڻ گهرجي.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // مثال طور اجازت ڏيڻ لاءِ ريپنگ ميٿ ڪندا `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // اهو انحصار $u_narrower <=استعمال تي آهي
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // جيڪڏهن ن حد کان ٻاهر آهي ، ايڪس ريڪس به آهي
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // جيڪڏهن ن حد کان ٻاهر آهي ، ايڪس ريڪس به آهي
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // اهو انحصار $i_narrower <=استعمال تي آهي
                        //
                        // ڪاسٽ ڪرڻ ڪاسائي وڌندي آهي پر نشان کي محفوظ رکي ٿي.
                        // استعمال ڪريو اسپائيٽنگ ۾ wrapping_sub ۽ ڪاز کي استعمال ڪرڻ لاءِ استعمال ڪيو ويو ته جيئن ان فرق کي شمار ڪجي جيڪا شايد آئيزيل جي رينج ۾ اندر نه هجي.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // `Step::forward(-120_i8, 200) == Some(80_i8)` وانگر ڪيسن کي ختم ڪندي ، جيتوڻيڪ 200 i8 جي حد کان ٻاهر آهي.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // اضافو وڌي ويو
                            }
                        }
                        // جيڪڏهن ن مثال کان ٻاهر آهي
                        // u8, پوء اهو i8 پوري رينج کان وڏي آهي ، مڪمل طور تي `any_i8 + n` ايڪسڪسيمڪس کي اوورلوز ڪري ٿو.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // `Step::forward(-120_i8, 200) == Some(80_i8)` وانگر ڪيسن کي ختم ڪندي ، جيتوڻيڪ 200 i8 جي حد کان ٻاهر آهي.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // ڪثرت ختم ٿي وئي
                            }
                        }
                        // جيڪڏهن ن مثال کان ٻاهر آهي
                        // u8, پوء اهو i8 پوري رينج کان وڏي آهي ، مڪمل طور تي `any_i8 - n` ايڪسڪسيمڪس کي اوورلوز ڪري ٿو.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // جيڪڏهن فرق وڏو آهي مثال طور
                            // I128 ، اهو پڻ گهٽ ننitsن بٽن سان استعمال ڪرڻ تمام وڏو آهي.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // حفاظت: ري صحيح يونيڪوڊ اسڪالر آهي
            // (0x110000 کان هيٺ ۽ 0xD800..0xE000 ۾ نه)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // حفاظت: ري صحيح يونيڪوڊ اسڪالر آهي
        // (0x110000 کان هيٺ ۽ 0xD800..0xE000 ۾ نه)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // حفاظت: سڏيندڙ کي گارنٽي ڏيڻ گهرجي ته اهو ختم نه ٿي ڪري
        // قدر جي قيمت جي حد
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // حفاظت: سڏيندڙ کي گارنٽي ڏيڻ گهرجي ته اهو ختم نه ٿي ڪري
            // قدر جي قيمت جي حد
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // حفاظت: اڳوڻي معاهدي جي ڪري ، اها ضمانت ٿئي ٿي
        // ڪال ڪرڻ واري طرفان هڪ صحيح چار هجڻ گهرجي.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // حفاظت: سڏيندڙ کي گارنٽي ڏيڻ گهرجي ته اهو ختم نه ٿي ڪري
        // قدر جي قيمت جي حد
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // حفاظت: سڏيندڙ کي گارنٽي ڏيڻ گهرجي ته اهو ختم نه ٿي ڪري
            // قدر جي قيمت جي حد
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // حفاظت: اڳوڻي معاهدي جي ڪري ، اها ضمانت ٿئي ٿي
        // ڪال ڪرڻ واري طرفان هڪ صحيح چار هجڻ گهرجي.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // حفاظت: صرف شرط کي چڪاس ڪيو
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // حفاظت: صرف شرط کي چڪاس ڪيو
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// اهي ميڪو ايڪس ڊي ايڪس مختلف قسم جي مختلف قسمن جي پيدا ڪن ٿا.
//
// * `ExactSizeIterator::len` گھربل آھي ھڪڙي ھڪڙي حقيقي `usize` موٽڻ جي ، تنهنڪري ڪا حد `usize::MAX` کان ڊگھي نٿي سگھي.
//
// * `Range<_>` ۾ انوگر قسمن جي لاءِ اهو ڪيس `usize` کان تمام نن thanو يا وسيع جزن لاءِ هوندو آهي.
//   `RangeInclusive<_>` ۾ انٽيگر ٽائپز لاءِ ھي ڪيسن جي صورت آھي *سخت طور تي تنگ*`usize` کان وٺي مثال طور
//   `(0..=u64::MAX).len()` `u64::MAX + 1` هوندو.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // اهي مٿي ڏنل استدلال مطابق شامل آهن ، پر انهن کي ڪ removingڻ هڪ برائي جي تبديلي هوندي ڇاڪاڻ ته اهي Rust 1.0.0 ۾ مستحڪم ٿي چڪيون هيون.
    // تنهنڪري ، مثال طور
    // `(0..66_000_u32).len()` مثال طور 16-bit پليٽ فارم تي غلطي يا ڊي warnاريندڙن کانسواءِ مرتب ڪنديون ، پر غلط نتيجو جاري رکندا.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // اهي مٿي ڏنل استدلال مطابق شامل آهن ، پر انهن کي ڪ removingڻ هڪ برائي جي تبديلي هوندي ڇاڪاڻ ته اهي Rust 1.26.0 ۾ مستحڪم ٿي چڪيون هيون.
    // تنهنڪري ، مثال طور
    // `(0..=u16::MAX).len()` مثال طور 16-bit پليٽ فارم تي غلطي يا ڊي warnاريندڙن کانسواءِ مرتب ڪنديون ، پر غلط نتيجو جاري رکندا.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // حفاظت: صرف شرط کي چڪاس ڪيو
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // حفاظت: صرف شرط کي چڪاس ڪيو
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // حفاظت: صرف شرط کي چڪاس ڪيو
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // حفاظت: صرف شرط کي چڪاس ڪيو
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // حفاظت: صرف شرط کي چڪاس ڪيو
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // حفاظت: صرف شرط کي چڪاس ڪيو
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}