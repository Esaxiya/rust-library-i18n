//! اوورلوڊ لوڊ آپريٽر.
//!
//! هنن traits کي لاڳو ڪرڻ توهان کي ڪجهه آپريٽرز کي اوور لوڊ ڪرڻ جي اجازت ڏئي ٿو.
//!
//! هنن traits مان ڪجھ prelude طرفان درآمد ٿيل آهن ، تنهن ڪري اهي هر Rust پروگرام ۾ موجود آهن.صرف آپريٽرز traits جي پٺڀرائي اوور لوڊ ٿي سگهي ٿي.
//! مثال طور ، اضافي هلائيندڙ (`+`) ، [`Add`] trait ذريعي اوور لوڊ ٿي سگهي ٿو ، پر جڏهن کان تفويض هلائيندڙ (`=`) وٽ trait جي ڪا به پٺڀرائي نه آهي ، ان جي ڪري هن کي اهميت نه آهي.
//! انهي سان گڏ ، هي ماڊل نون آپريٽرز ٺاهڻ جي ڪا به طريقا فراهم نٿو ڪري.
//! جيڪڏهن ٽرائلٽ اوور لوڊنگ يا ڪسٽم آپريٽر گهربل هجن ، توهان کي Rust جي نحو وڌائڻ لاءِ ميڪرو يا ڪمپائلر پلگ ان کي ڏسڻ گهرجي.
//!
//! آپريٽر traits جو لاڳو ٿيڻ انهن جي دائمي مقصدن ۾ ڪوئي تعجب نه هجڻ گهرجي ، انهن جي معمولي معنى ۽ [operator precedence] کي نظر ۾ رکندي.
//! مثال طور ، [`Mul`] کي عمل ڪرڻ دوران ، آپريشن ضرب لاءِ ڪجهه مشابهت هجڻ گهرجي (۽ متوقع خاصيتون جهڙوڪ اشتراڪيت کي حصيداري ڪنديون).
//!
//! ياد رکو ته `&&` ۽ `||` آپريٽر شارٽ سرڪٽ ، يعني ، اهي صرف پنهنجي ٻئي هلائيندڙ جو اندازو ڪن ٿيون جيڪڏهن اهو نتيجو ۾ حصو وٺندو آهي.جئين traits پاران هن رويي تي عملدرآمد نه ٿو ڪري سگھجي ، `&&` ۽ `||` وڌيڪ لوڊ ٿيل آپريٽرز جي طور تي مدد نٿا ڪري سگھجن.
//!
//! ڪيترائي آپريٽر پنھنجي بلندي سان آپريشن ڪري وٺندا آھن.عام طور تي ٺاهيل قسم ۾ شامل ٿيندڙ عام contextاڻ ۾ ، اهو اڪثر مسئلو ناهي.
//! تنهن هوندي ، انهن آپريٽرن کي عام ڪوڊ ۾ استعمال ڪرڻ ، ڪجهه ڌيان جي ضرورت هوندي آهي جيڪڏهن قدرن کي ٻيهر استعمال ڪرڻ گهرجي ته هليا هلندڙن کي انهن جي استعمال ڪرڻ جي مخالفت ڪرڻ جي.هڪ آپشن ڪڏهن ڪڏهن [`clone`] استعمال ڪرڻ هوندو آهي.
//! هڪ ٻيو آپشن حوالن جي لاءِ اضافي هلائيندڙ عمل درآمد مهيا ڪرڻ واري قسم تي ڀاڙڻ آهي.
//! مثال طور ، صارف لاءِ بيان ٿيل قسم `T` جنهن لاءِ اضافي مدد ڪرڻ گهرجي ، اهو شايد بهتر هجي ته اهو `T` ۽ `&T` ٻئي traits [`Add<T>`][`Add`] ۽ [`Add<&T>`][`Add`] کي عمل ۾ آڻين ته غير ضروري ڪلوننگ کانسواءِ عام ڪوڊ لکي سگهجي ٿو.
//!
//!
//! # Examples
//!
//! اهو مثال هڪ `Point` جوڙ ٺاهي ٿو جيڪو [`Add`] ۽ [`Sub`] کي لاڳو ڪري ٿو ، ۽ پوء ٻن پوائنٽ کي شامل ۽ گهٽائڻ جو مظاهرو ڪري ٿو.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! مثال طور عمل درآمد لاءِ هر trait لاءِ دستاويز ڏسو.
//!
//! [`Fn`] ، [`FnMut`] ، ۽ [`FnOnce`] traits لاڳو ڪيا ويا آهن جيڪي افعال کي سڏي سگهجن ٿيون.ياد رکو ته [`Fn`] `&self` وٺي ٿو ، [`FnMut`] `&mut self` وٺي ٿو ۽ [`FnOnce`] `self` وٺي ٿو.
//! اهي ٽي قسم جي طريقن سان واسطو رکن ٿيون جيڪي مثال طور سڏيا وڃن: ڪال-حوالا ، ڪال-ماٽبل-ريفرنس-ڪال ، ۽ ڪال-ويل-قدر.
//! هنن traits جو سڀ کان عام استعمال حد کان وڌيڪ ڪم ڪرڻ آهي ڪم ڪرڻ واري سطح جي افعال جو ته ڪم ڪري ٿو يا بند ڪري دليلن وانگر.
//!
//! هڪ [`Fn`] پيرا ميٽر طور ورتو وڃي:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! هڪ [`FnMut`] پيرا ميٽر طور ورتو وڃي:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! هڪ [`FnOnce`] پيرا ميٽر طور ورتو وڃي:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ان جي قبضي وارن متغيرن کي ڪي ٿو ، تنهنڪري اهو هڪ ڀيرو کان وڌيڪ هلائي نه سگھجي
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // ٻيهر `func()` کي دعوت ڏيڻ جي ڪوشش ڪندي `func` لاءِ `use of moved value` غلطي اڇلايو ويندو
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` هن موقعي تي وڌيڪ جواب اختيار نه ٿو ڪري سگھجي
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;