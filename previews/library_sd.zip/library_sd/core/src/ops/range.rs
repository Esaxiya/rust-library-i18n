use crate::fmt;
use crate::hash::Hash;

/// ھڪڙي حد تائين ھڪڙي حد تائين (`..`).
///
/// `RangeFull` بنيادي طور تي [slicing index] طور استعمال ڪيو ويندو آهي ، ان جي ننorthڙي ايڪس `..` آهي.
/// اهو [`Iterator`] وانگر ڪم نٿو ڪري سگهي ڇاڪاڻ ته اهو شروعاتي نقطو ناهي.
///
/// # Examples
///
/// `..` نحو هڪ `RangeFull` آهي:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// انهي ۾ [`IntoIterator`] لاڳو ناهي ، ان ڪري توهان ان کي سڌو سنئون `for` لوپ ۾ استعمال نٿا ڪري سگھو.
/// اهو مرتب نه ڪندو:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// ايڪسڪسيمڪس طور استعمال ٿيل ، `RangeFull` هڪ سليس وانگر مڪمل صف ٺاهي ٿو.
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // هي `RangeFull` آهي
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// هڪ (half-open) حد محدود طور تي محدود طور تي هيٺ ڏنل آهي ۽ خاص طور تي (`start..end`) کان مٿي.
///
///
/// رينج `start..end` `start <= x < end` سان گڏ سڀ قدر شامل آهن.
/// جيڪڏهن `start >= end` آهي خالي آهي.
///
/// # Examples
///
/// `start..end` نحو هڪ `Range` آهي:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // اھو ھڪڙو `Range` آھي
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // نقل نه ڪريو-ايڪس 400 کي ڏسو
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// (inclusive) جي حد کان هيٺيان حد.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// ايڪس (exclusive) X جي حد تائين مٿين حد.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// جيڪڏهن `item` رينج ۾ شامل هجي `true` جي واپسي ڏي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// `true` واپس ڪندو آھي جيڪڏھن رينج ۾ ڪوبہ اھم ناھي.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// جيڪڏهن ٻن طرفن جي مقابلي ۾ خالي نه هجي ته حد خالي آهي:
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// صرف ھڪڙي حد تائين (`start..`) تائين محدود حد تائين.
///
/// `RangeFrom` `start..` سڀني قدرن تي مشتمل آھي `x >= start`.
///
/// *نوٽ*: [`Iterator`] عملدرآمد ۾ اوور فلو (جڏهن ان ۾ موجود ڊيٽا قسم پنهنجي عددي حد تائين پهچي وڃي) panic ، لفاف ڪرڻ ، يا ستو ڪرڻ جي اجازت آهي.
/// اهو رويو [`Step`] trait جي نفاذ سان بيان ڪيو ويو آهي.
/// پرائمري انٽيگرز لاءِ ، هي عام قاعدن جي پيروي ڪري ٿو ، ۽ اوور فلو چيڪ پروفائل جو احترام ڪري ٿو (ڊيبگ ۾ panic ، رليز ۾ لٽڻ).
/// اهو پڻ نوٽ ڪريو ته مٿان کان ڀ happensڻ وارو فرض ٿئي ٿو توهان جي فرض ٿيڻ کان اڳ: اوور فلو ڪال ڪال `next` ۾ ٿئي ٿي جيڪا وڌ کان وڌ قدر پيدا ڪندي ، جيئن ته ايندڙ قيمت پيدا ڪرڻ لاءِ حد کي هڪ رياست ڏانهن مقرر ڪيو وڃي.
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` نحو هڪ `RangeFrom` آهي:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // اھو ھڪڙو `RangeFrom` آھي
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // نقل نه ڪريو-ايڪس 400 کي ڏسو
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// (inclusive) جي حد کان هيٺيان حد.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// جيڪڏهن `item` رينج ۾ شامل هجي `true` جي واپسي ڏي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// صرف (`..end`) کان مٿاهون حد تائين محدود آهي.
///
/// `RangeTo` `..end` سڀني قدرن تي مشتمل آھي `x < end`.
/// اهو [`Iterator`] وانگر ڪم نٿو ڪري سگهي ڇاڪاڻ ته اهو شروعاتي نقطو ناهي.
///
/// # Examples
///
/// `..end` نحو هڪ `RangeTo` آهي:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// انهي ۾ [`IntoIterator`] لاڳو ناهي ، ان ڪري توهان ان کي سڌو سنئون `for` لوپ ۾ استعمال نٿا ڪري سگھو.
/// اهو مرتب نه ڪندو:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// جڏهن [slicing index] طور استعمال ڪيو ويو آهي ، `RangeTo` پاران x00X پاران ظاهر ڪيل انڊيڪس کان اڳ سڀني آرٽ عناصر جي هڪ سليس پيدا ڪري ٿي.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // اھو ھڪڙو `RangeTo` آھي
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// ايڪس (exclusive) X جي حد تائين مٿين حد.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// جيڪڏهن `item` رينج ۾ شامل هجي `true` جي واپسي ڏي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// هڪ حد (`start..=end`) کان مٿي ۽ مٿي جي حد تائين محدود آهي.
///
/// `RangeInclusive` `start..=end` سڀني قدرن تي مشتمل آهي `x >= start` ۽ `x <= end`.اهو خالي آهي جيستائين `start <= end`.
///
/// اهو ورثو [fused] آهي ، پر مڪمل ختم ٿيڻ کانپوءِ `start` ۽ `end` جون مخصوص قدرون **غير بيان ٿيل آهن** ان کان علاوه [`.is_empty()`] هڪ ڀيرو وڌيڪ قدر پيدا نه ڪندي هڪ ڀيرو وڌيڪ `true` واپس ڪندو.
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` نحو هڪ `RangeInclusive` آهي:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // اھو ھڪڙو `RangeInclusive` آھي
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // نقل نه ڪريو-ايڪس 400 کي ڏسو
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // نوٽ ڪريو ته ھتان فيلڊون عوامي آھن future ۾ نمائندگي تبديل ڪرڻ جي اجازت نه ؛خاص طور تي ، جڏهن اسان معقول طور تي start/end کي پڌرو ڪري سگهون ، انهن کي تبديل ڪرڻ جي بغير (future/current) پرائيويٽ شعبا غلط رويو سبب ٿي سگھن ٿا ، تنهن ڪري اسان انهي موڊ کي سپورٽ نٿا ڪرڻ چاهيون.
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // هي ميدان آهي
    //  - `false` تعمير تي
    //  - `false` جڏهن اهو مرڪز هڪ عنصر پيدا ڪري چڪو آهي ۽ ايٽرير ختم نه ٿيو آهي
    //  - `true` جڏهن اهو آئيٽريٽر کي ختم ڪرڻ جي لاءِ استعمال ڪيو ويو آهي
    //
    // هي جزوي آرڊ پابند يا ماهر بنا ڪنهن جزوي ايق ۽ هش جي مدد ڪرڻ جي ضرورت آهي.
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// ھڪڙو نئون شامل ڪندڙ رينج ٺاھي ٿو.`start..=end` لکڻ جي برابر
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// حد جي هيٺئين حد کي ڏيکاري ٿي (inclusive).
    ///
    /// جڏهن انيجشن لاءِ انيڪلوجيل رينج استعمال ڪندي ، `start()` ۽ [`end()`] جا قدر iteration ختم ٿيڻ بعد اڻ وضاحت ٿيل آهن.
    /// اهو طئي ڪرڻ لاءِ ته ڇا شامل حد خالي آهي ، ايڪس پي ايم جي مقابلي ڪرڻ جي بجاءِ [`is_empty()`] طريقو استعمال ڪريو.
    ///
    /// Note: هن طريقي سان واپس موٽڻ واري قيمت اڻ لڀ ٿي وڃي حد کان پوءِ ختم ٿيڻ تائين حد ٿي وئي آهي.
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// حد (inclusive) جي مٿين حد کي ڏيکاري ٿو.
    ///
    /// جڏهن انيجشن لاءِ انيڪلوجيل رينج استعمال ڪندي ، [`start()`] ۽ `end()` جا قدر iteration ختم ٿيڻ بعد اڻ وضاحت ٿيل آهن.
    /// اهو طئي ڪرڻ لاءِ ته ڇا شامل حد خالي آهي ، ايڪس پي ايم جي مقابلي ڪرڻ جي بجاءِ [`is_empty()`] طريقو استعمال ڪريو.
    ///
    /// Note: هن طريقي سان واپس موٽڻ واري قيمت اڻ لڀ ٿي وڃي حد کان پوءِ ختم ٿيڻ تائين حد ٿي وئي آهي.
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// `RangeInclusive` کي تباهه ڪري ٿو (هيٺين حد ، اوپري (inclusive) پابند).
    ///
    /// Note: هن طريقي سان واپس موٽڻ واري قيمت اڻ لڀ ٿي وڃي حد کان پوءِ ختم ٿيڻ تائين حد ٿي وئي آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// بدلجي ٿو ڌڪ ايڪسڪسيمڪس ايڪسچينٽس لاء ايڪسڪسيمڪس جي ايڪسڪسيمڪس لاءِ.
    /// ڪالر `end == usize::MAX` سان معاملو ڪرڻ جي ذميوار آهي.
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // جيڪڏهن اسان ختم نه ڪيا ويا آهيون ، اسان صرف `start..end + 1` کي نن wantڙو ڪرڻ چاهيون ٿا.
        // جيڪڏهن اسان ختم ٿي ويا آهيون ، پوءِ `end + 1..end + 1` سان سلائينڻ اسان کي هڪ خالي رينج ڏي ٿو جيڪا اڃا تائين انهي آخري پوائنٽ جي حدن جي چڪاس جي تابع آهي.
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// جيڪڏهن `item` رينج ۾ شامل هجي `true` جي واپسي ڏي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// اهو طريقو هميشه ختم ٿي ويو ايڪس آرڪس کي ختم ڪرڻ کان پوء.
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // اصلي فيلڊ جا قدر هتي بيان ٿيل نه آهن
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// `true` واپس ڪندو آھي جيڪڏھن رينج ۾ ڪوبہ اھم ناھي.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// جيڪڏهن ٻن طرفن جي مقابلي ۾ خالي نه هجي ته حد خالي آهي:
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// اهو طريقو مڪمل ٿيڻ کان پوء `true` موٽائي ٿو:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // اصلي فيلڊ جا قدر هتي بيان ٿيل نه آهن
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// صرف (`..=end`) کان مٿاهون حد تائين محدود آهي.
///
/// `RangeToInclusive` `..=end` سڀني قدرن تي مشتمل آھي `x <= end`.
/// اهو [`Iterator`] وانگر ڪم نٿو ڪري سگهي ڇاڪاڻ ته اهو شروعاتي نقطو ناهي.
///
/// # Examples
///
/// `..=end` نحو هڪ `RangeToInclusive` آهي:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// انهي ۾ [`IntoIterator`] لاڳو ناهي ، ان ڪري توهان ان کي سڌو سنئون `for` لوپ ۾ استعمال نٿا ڪري سگھو.اهو مرتب نه ڪندو:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// جڏهن [slicing index] طور استعمال ڪيو ويو ته ، `RangeToInclusive` سڀني صفن جي عناصر جو هڪ نمونو پيدا ڪري ٿو ۽ ان ۾ شامل آهي ايڪس ايڪس ايڪس پاران نشاندهي ڪيل اشارا شامل آهن.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // اھو ھڪڙو `RangeToInclusive` آھي
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// ايڪس (inclusive) X جي حد تائين مٿين حد
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// جيڪڏهن `item` رينج ۾ شامل هجي `true` جي واپسي ڏي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// رينج ٽو او انيلڪيو<Idx>کان نقل نٿو ڪري سگھي <RangeTo<Idx>> ڇو ته (..0).into() سان انڊر فلو ممڪن هوندو
//

/// ڪيز جي حد جو هڪ آخري نقطو.
///
/// # Examples
///
/// حد بنديون آهن آخري حدون:
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// [`BTreeMap::range`] ڏانهن دليل جي طور تي "بائونڊ" جو هڪ ٽپال استعمال ڪندي.
/// نوٽ ڪريو ته اڪثر ڪيسن ۾ ، بهتر آهي ته رينج نحو (`1..5`) بدران.
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// هڪ شامل جڙيل.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// هڪ خاص پابند.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// هڪ لامحدود نقطو.ظاهر ڪري ٿو ته هن هدايت ۾ ڪابه پابند ناهي.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// `&Bound<T>` کان `Bound<&T>` تائين تبديل ڪندو آهي.
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// `&mut Bound<T>` کان `Bound<&T>` تائين تبديل ڪندو آهي.
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// پابند ٿيل مواد کي ڪلون ڪرڻ سان `Bound<&T>` کي `Bound<T>` ڏانهن نقشو ٺاھيو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` Rust جي بلڊنگ ۾ رينج جي قسمن جي طرفان ، رينج نائيٽيڪس وانگر تيار ڪيل آهي جهڙوڪ `..` ، `a..` ، `..b` ، `..=c` ، `d..e` ، يا `f..=g`.
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// شروعاتي انڊيڪس پابند.
    ///
    /// `Bound` جي طور تي شروعاتي قيمت واپس آڻيندي.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// آخر انڊيڪس پابند.
    ///
    /// `Bound` جي طور تي آخري قيمت ڏي ٿو
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// جيڪڏهن `item` رينج ۾ شامل هجي `true` جي واپسي ڏي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// زور ڀريو! ((3..5).contains(&4)) ؛
    /// assert!(!(3..5).contains(&2));
    ///
    /// زور ڀريو! ((0.0..1.0).contains(&0.5)) ؛
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // جڏهن اهو ويڙهاڪ ختم ٿي چڪو آهي ، اسان عام طور تي شروعات==ختم ٿئي ٿي ، پر اسان چاهيون ٿا ته حد خالي ظاهر ٿئي ، جنهن ۾ ڪجهه به ناهي.
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}