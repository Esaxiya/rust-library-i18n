use crate::marker::Unsize;

/// Trait جيڪو ظاهر ڪري ٿو ته اهو پوائنٽر يا ڪنهن لاءِ ويڙهاڪ آهي ، جتي پوائنسي تي بي ترتيب ڪري سگهجي ٿو.
///
/// وڌيڪ تفصيل لاءِ ڏسو [DST coercion RFC][dst-coerce] ۽ [the nomicon entry on coercion][nomicon-coerce].
///
/// بلٽ پوائنٽر قسمن لاءِ ، پوائنٽس ايڪسڪٽرز کي `U` ڏانهن اشارو ڪندو جيڪڏھن `T: Unsize<U>` ھڪ پتلي پوائنٽر کان ٿڌي پوائنٽ کي تبديل ڪندي.
///
/// ڪسٽم قسمن لاءِ ، جبر هتي `Foo<T>` کي `Foo<U>` ڪرڻ لاءِ ڪم ڪري ٿو ، اتي موجود `CoerceUnsized<Foo<U>> for Foo<T>` جو هڪ مثال موجود آهي.
/// جيڪڏهن هڪ مضمون صرف `T` ۾ صرف هڪ غير فانٽوميتا ميدان آهي ، صرف ان صورت ۾ لکيا وڃن ٿا.
/// جيڪڏهن هن فيلڊ جو قسم `Bar<T>` آهي ، `CoerceUnsized<Bar<U>> for Bar<T>` جو هڪ عمل لازمي طور تي موجود هجڻ گهرجي.
/// ڪورس `Bar<T>` فيلڊ کي `Bar<U>` ۾ دٻائڻ ۽ `Foo<T>` کان باقي باقي خانن کي ڀرڻ سان `Foo<U>` ٺاهڻ جي لاءِ ڪم ڪندو.
/// اهو موثر طريقي سان پوائنٽر فيلڊ ڏانهن ويندو ۽ زور ڀريندو.
///
/// عام طور تي ، سمارٽ پوائنٽرن لاءِ توهان `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` تي عملدرآمد ڪندو ، `T` پاڻ تي هڪ اختياري `?Sized` پابند هوندو.
/// ريپر جي قسمن لاءِ جيڪي سڌي طرح `T` جھڙا ڪن ٿا `Cell<T>` ۽ `RefCell<T>` ، توھان سڌو سنئون لاڳو ڪري سگھو ٿا `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// هي ايڪسينڪس وانگر ڪم ڪرڻ وارن قسمن جي جبر کي اجازت ڏيندو.
///
/// [`Unsize`][unsize] انهن نشانين جي نشان لڳائڻ لاءِ استعمال ڪيو ويو آهي جيڪي DSTs سان لهي سگهجن ٿا جيڪڏهن اشارو ڪندڙن جي پٺيان هجي.اهو ٺاهيل پاڻمرادو مرتب ڪندڙ جي طرفان آهي.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut ٽي-> &mut يو
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut ٽي-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut ٽي-> * مت U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut ٽي-> * کانس يو
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * کانس يو
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* مت U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const يو
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *Const T->* const يو
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// اهو استعمال ڪيو ويو آھي اعتراض حفاظت لاءِ ، چيڪ ڪرڻ لاءِ ته ھڪ طريقو وصول ڪندڙ جي قسم موڪلي سگھجي ٿو.
///
/// trait جو هڪ مثال عمل درآمد:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut ٽي-> &mut يو
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *Const T->* const يو
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* مت U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}