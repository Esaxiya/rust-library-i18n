/// بي ترتيب ڏنل مقصدن ۾ انڊيڪس ايڪسنگ ايڪس آپريشنز لاءِ استعمال ڪيو ويندو.
///
/// `container[index]` اصل ۾ `*container.index(index)` لاءِ مصنوعي شگر آهي ، پر صرف جڏهن هڪ ناقابل برداشت قدر طور استعمال ٿئي ٿي.
/// جيڪڏهن قابل منتقلي قدر درخواست ڪئي وڃي ٿي ، بدران [`IndexMut`] استعمال ڪيو وڃي ٿو.
/// اهڙي نموني شين جي اجازت ڏئي ٿي جهڙوڪ `let value = v[index]` جيڪڏهن `value` جو قسم [`Copy`] لاڳو ڪري ٿو.
///
/// # Examples
///
/// هيٺيون مثال `Index` کي صرف پڙهڻ واري `NucleotideCount` ڪنٽينر تي لاڳو ڪندو آهي ، انفرادي ڳڻپيوٽس کي انڊيڪس نحو سان واپس آڻڻ جي قابل بڻائيندو آهي.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// انڊيڪسنگ بعد واپس ٿيل قسم.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// انڊيڪس ايڪس (`container[index]`) آپريشن کي انجام ڏئي ٿو.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// متحرڪ مقصدن ۾ ايڪسچيڪس آپريشن جي لاءِ استعمال ڪيو ويو.
///
/// `container[index]` اصل ۾ `*container.index_mut(index)` لاءِ مصنوعي شگر آهي ، پر صرف جڏهن هڪ هڪ قابل قدر قيمت طور استعمال ٿئي ٿي.
/// جيڪڏهن هڪ قابل منتقلي قيمت درخواست ڪئي وڃي ٿي ، بدران [`Index`] trait استعمال ڪيو وڃي ٿو.
/// هي سٺي شيون جهڙوڪ `v[index] = value` جي اجازت ڏئي ٿو.
///
/// # Examples
///
/// ايڪس اين ايڪس اسٽرڪ جو هڪ تمام سادو عمل جيڪو ٻن طرفن وارو آهي ، جتي هر هڪ کي خاموش ۽ بي ترتيبيءَ سان ڏيکاري سگهجي ٿو.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // انهي حالت ۾ ، `balance[Side::Right]` ايڪس X00 لاء شوگر آهي ، جتان اسان فقط *پڙهي*`balance[Side::Right]` ، آهيون نه.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // جيتوڻيڪ ، انهي صورت ۾ `balance[Side::Left]` شوگر آهي `*balance.index_mut(Side::Left)` ، جيسين اسان `balance[Side::Left]` لکي رهيا آهيون.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// مٽا سٽا وارو ايڪسٽنگ (`container[index]`) آپريشن انجام ڏئي ٿي.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}