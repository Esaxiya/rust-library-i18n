/// ڪال آپريٽر جو نسخو جيڪو هڪ ناقابلِ قبول رسيور کڻي ٿو.
///
/// `Fn` جي مثال کي ڌار ڌار حالت کي بار بار چئي سگهجي ٿو.
///
/// *اھو trait (`Fn`) ڪنھن بہ غلط ٿيڻ سان [function pointers] (`fn`) آھي.*
///
/// `Fn` بندش جي ذريعي خودڪار طريقي سان عملدرآمد ڪيو ويو آهي جيڪو صرف قبضو ڪيل متغيرن لاءِ غير معقول حوالو وٺندو آهي يا ڪنهن به شيءَ تي قبضو نه ڪندا آهن ، گڏو گڏ (safe) [function pointers] (ڪجهه خبرداري سان ، وڌيڪ تفصيل لاءِ انهن جي دستاويز ڏسو).
///
/// اضافي طور تي ، `F` جي ڪنهن به قسم جي لاءِ `Fn` ، `&F` لاڳو ڪري ٿو `Fn` پڻ.
///
/// ڇاڪاڻ ته ٻئي [`FnMut`] ۽ [`FnOnce`] `Fn` جا سپرٽرٽ آهن ، تنهن ڪري `Fn` جو ڪنهن به مثال پيرا ميٽر طور استعمال ڪري سگهجي ٿو جتي [`FnMut`] يا [`FnOnce`] جي توقع ڪئي وئي آهي.
///
/// `Fn` کي پابند بڻايو استعمال ڪريو جڏهن توهان فنڪشن جهڙو قسم جي پيراڊيٽر کي قبول ڪرڻ چاهيندا هجو ۽ بار بار سڏڻ جي ضرورت هجي ۽ بغير ڪيٽ ڪرڻ جي حالت (مثال طور ،
/// جيڪڏهن توهان کي اهڙي سخت ضرورتن جي ضرورت ناهي ، ايڪس باڪس طور [`FnMut`] يا X01 استعمال ڪريو.
///
/// انهي موضوع تي ڪجهه وڌيڪ معلومات جي لاءِ [chapter on closures in *The Rust Programming Language*][book] ڏسو.
///
/// پڻ نوٽ `Fn` traits لاء خاص نحو آهي (مثال طور
/// `Fn(usize, bool) -> استعمال ڪر).جيڪي [the relevant section in the *Rustonomicon*][nomicon] کان فني تفصيلي تفصيل ۾ دلچسپي رکن ٿا.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## بند ڪرڻ جو سڏ
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## `Fn` پيٽرولر استعمال ڪندي
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // انهي ڪري regex ان انحصار ڪري سگھن ٿا `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// ڪال آپريشن ڪندو آهي.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// ڪال آپريٽر جو نسخو جيڪو هڪ مٽايل رسيور وٺي ٿو.
///
/// `FnMut` جي مثالن کي بار بار سڏيو وڃي ٿو ۽ شايد حالت بدلائي سگھي ٿو.
///
/// `FnMut` بندش جي ذريعي خودڪار طريقي سان لاڳو ڪئي وئي آهي جيڪي قبضو ڪيل متغيرن جي قابل منتقلي حوالا وٺن ٿا ، انهي سان گڏ سڀني قسمن تي جيڪي [`Fn`] کي لاڳو ڪن ٿيون ، مثال طور ، (safe) [function pointers] (ڇاڪاڻ ته `FnMut` [`Fn`] جو سپرٽرنٽ آهي).
/// اضافي طور تي ، `F` جي ڪنهن به قسم جي لاءِ `FnMut` ، `&mut F` لاڳو ڪري ٿو `FnMut` پڻ.
///
/// جئين [`FnOnce`] `FnMut` جي ھڪڙي سپرٽرٽٽ آھي ، `FnMut` جو ھڪڙو مثال استعمال ڪري سگھجي ٿو جتي [`FnOnce`] جي اُميد ڪئي وئي آھي ، ۽ جيئن کان [`Fn`] آھي `FnMut` جي ذيلي ذخيرو ، [`Fn`] جو ھڪڙو مثال استعمال ٿي سگھي ٿو جتي `FnMut` جي اُميد ڪئي وڃي.
///
/// `FnMut` کي پابند بڻايو استعمال ڪريو جڏهن توهان فنڪشن جهڙو قسم جي پيرا ميٽر کي قبول ڪرڻ چاهيندا آهيو ۽ بار بار ڪال ڪرڻ جي ضرورت هوندي آهي ، جڏهن ته اها حالت کي متحرڪ ڪرڻ جي اجازت ڏيو.
/// جيڪڏهن توهان پيراٽرٽ کي حالت کي لٽائڻ نٿا چاهيون ، هڪ بند طور [`Fn`] استعمال ڪريو ؛جيڪڏهن توهان کي بار بار فون ڪرڻ جي ضرورت نه آهي ، ايڪس ايڪس استعمال ڪريو.
///
/// انهي موضوع تي ڪجهه وڌيڪ معلومات جي لاءِ [chapter on closures in *The Rust Programming Language*][book] ڏسو.
///
/// پڻ نوٽ `Fn` traits لاء خاص نحو آهي (مثال طور
/// `Fn(usize, bool) -> استعمال ڪر).جيڪي [the relevant section in the *Rustonomicon*][nomicon] کان فني تفصيلي تفصيل ۾ دلچسپي رکن ٿا.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## بند ٿيڻ جي ٻرندڙ گرفتاري کي سڏڻ
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## `FnMut` پيٽرولر استعمال ڪندي
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // انهي ڪري regex ان انحصار ڪري سگھن ٿا `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// ڪال آپريشن ڪندو آهي.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// ڪال آپريٽر جو نسخو جيڪو قدر جي حساب سان وصول ڪندڙ وٺندو آهي.
///
/// `FnOnce` جي مثال سڏائي سگھجن ٿا ، پر ڪيترن ئي ڀيرا ڪال نه ٿي سگھي.انهي جي ڪري ، جيڪڏهن هڪ قسم بابت صرف نالي بابت thatاڻڻ آهي ته اهو `FnOnce` تي عمل ڪري ٿو ، اهو صرف هڪ ڀيرو سڏ ڪري سگهجي ٿو.
///
/// `FnOnce` بندش جي ذريعي خودڪار طريقي سان لاڳو ڪئي وئي جيڪا ضبط ٿيل متغيرن کي استعمال ڪري سگهي ٿي ، انهي سان گڏ [`FnMut`] لاڳو ڪندڙ سڀني قسمن ، مثال طور ، (safe) [function pointers] (کان وٺي `FnOnce` [`FnMut`] جو سپرٽيٽ آهي)
///
///
/// ڇاڪاڻ ته ٻئي [`Fn`] ۽ [`FnMut`] `FnOnce` جا ماتحت آهن ، [`Fn`] يا [`FnMut`] جو ڪنهن به مثال استعمال ڪري سگهجي ٿو جتي `FnOnce` جي توقع ڪئي وئي آهي.
///
/// `FnOnce` هڪ پابند جي طور تي استعمال ڪريو جڏهن توهان فنڪشن جهڙو قسم جي پيٽرولر کي قبول ڪرڻ چاهيو ٿا ۽ صرف انهي کي هڪ ڀيرو فون ڪرڻ جي ضرورت آهي.
/// جيڪڏهن توهان کي پيرا ميٽر کي بار بار ڪال ڪرڻ جي ضرورت آهي ، هڪ پابند طور [`FnMut`] استعمال ڪريو ؛جيڪڏهن توهان کي رياست کي لاتعداد ڪرڻ جي ضرورت ناهي ، ايڪس ايڪس ايڪس استعمال ڪريو.
///
/// انهي موضوع تي ڪجهه وڌيڪ معلومات جي لاءِ [chapter on closures in *The Rust Programming Language*][book] ڏسو.
///
/// پڻ نوٽ `Fn` traits لاء خاص نحو آهي (مثال طور
/// `Fn(usize, bool) -> استعمال ڪر).جيڪي [the relevant section in the *Rustonomicon*][nomicon] کان فني تفصيلي تفصيل ۾ دلچسپي رکن ٿا.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## `FnOnce` پيٽرولر استعمال ڪندي
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ان جي قبضي وارن متغيرن کي ڪesي ٿي ، تنهنڪري اهو هڪ ڀيرو کان وڌيڪ هلائي نه سگھجي.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // ٻيهر `func()` کي دعوت ڏيڻ جي ڪوشش ڪندي `func` لاءِ `use of moved value` غلطي اڇلايو ويندو.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` هن موقعي تي وڌيڪ جواب اختيار نه ٿو ڪري سگھجي
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // انهي ڪري regex ان انحصار ڪري سگھن ٿا `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// ڪال آپريٽر استعمال ٿيڻ بعد واپس ٿيل قسم.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// ڪال آپريشن ڪندو آهي.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}