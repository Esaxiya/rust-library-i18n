/// `?` آپريٽر جي رويي کي ترتيب ڏيڻ لاءِ trait.
///
/// هڪ قسم `Try` لاڳو ڪرڻ وارو هڪ آهي جيڪو انهي کي success/failure ڊائي ڪوٽوامي جي لحاظ کان ڏسڻ لاءِ هڪ طنزيه طريقي وارو آهي.
/// هي trait انهن ڪاميابين يا ناڪاميءَ جا قدر ڪنهن موجود صورت مان ڪ extractڻ جي اجازت ڏئي ٿو ۽ ڪاميابي يا ناڪاميءَ واري قيمت کان هڪ نئون مثال ٺاهڻ.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// هن قيمت جو قسم جڏهن ڪامياب ڏٺو وڃي.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// هن قيمت جو قسم جڏهن ناڪام ڏٺو ويو.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" هلائيندڙ تي لاڳو ٿئي ٿو.`Ok(t)` جي واپسي جو مطلب آهي عملدرآمد عام طور تي جاري رهڻ گهرجي ، ۽ `?` جو نتيجو قدر `t` آهي.
    /// `Err(e)` جي واپسي جو مطلب آهي ايڪسوڪسڪس branch کي ايڪسچينج سان اندروني اندروني جڙيل ڏانهن عمل ڪرڻ گهرجي ، يا فنڪشن کان واپس اچڻ گهرجي.
    ///
    /// جيڪڏهن `Err(e)` نتيجو واپس ڪيو ويو آهي ، قيمت `e` انڪوٽنگ جي دائري جي واپسي واري قسم ۾ "wrapped" ٿي ويندو (جيڪو پاڻ کي `Try` لاڳو ڪرڻ گهرجي).
    ///
    /// خاص طور تي ، قيمت `X::from_error(From::from(e))` موٽي وئي آهي ، جتي `X` بند ڪرڻ واري فنڪشن جي واپسي واري قسم آهي.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// جامع نتيجو تعمير ڪرڻ لاءِ غلطي جي قيمت لپیٽيو.
    /// مثال طور ، `Result::Err(x)` ۽ `Result::from_error(x)` برابر آهن.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// جامع نتيجو ٺاھڻ لاءِ ٺيڪ ويليو وايو.
    /// مثال طور ، `Result::Ok(x)` ۽ `Result::from_ok(x)` برابر آهن.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}