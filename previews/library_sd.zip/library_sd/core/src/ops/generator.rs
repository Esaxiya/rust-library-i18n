use crate::marker::Unpin;
use crate::pin::Pin;

/// هڪ جنريٽر وري شروع ٿيڻ جو نتيجو.
///
/// هي اينيم `Generator::resume` طريقي سان واپس ڪئي وئي ۽ جنريٽر جي ممڪن واپسي واريون قيمتون ظاهر ڪندي.
/// في الحال اهو يا ته معطلي پوائنٽ (`Yielded`) يا ختم ٿيڻ واري نقطي (`Complete`) سان تعلق رکي ٿو.
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// هڪ جنريٽر بيخبر سان معطل ٿي ويو.
    ///
    /// اهو رياست ظاهر ڪري ٿو ته هڪ جنريٽر معطل ٿي چڪو آهي ، ۽ خاص طور تي هڪ `yield` بيان سان ملي ٿو.
    /// هن قسم ۾ مهيا ڪيل قدر ايڪس اين ايڪس ايڪس ڏانهن منتقل ڪيل اظهار سان مطابقت رکي ٿي ۽ جنريٽر کي هر وقت انهن جي قيمت ڏيارڻ جي اجازت ڏئي ٿي.
    ///
    ///
    Yielded(Y),

    /// جنريٽر واپسي جي قيمت سان مڪمل ڪيو.
    ///
    /// اها حالت ظاهر ڪري ٿي ته هڪ جنريٽر مهيا ڪيل قدر سان عمل درآمد ختم ڪري چڪو آهي.
    /// هڪ ڀيرو جنريٽر `Complete` واپس ڪري آيو آهي ته انهي کي `resume` ٻيهر فون ڪرڻ لاءِ پروگرامر غلطي سمجهيو وڃي ٿو.
    ///
    Complete(R),
}

/// trait بلٽ جنريٽر جي قسمن سان لاڳو ڪئي وئي آهي.
///
/// جنريٽر ، عام طور تي ڪوروتين پڻ چيو ويندو آهي ، في الحال Rust ۾ تجرباتي ٻولي جي خاصيت آهن.
/// [RFC 2033] جنريٽرز ۾ شامل ڪيا ويا آهن في الحال بنيادي طور تي async/await نحو ٺاهڻ لاءِ عمارت سازي جو ڪم مهيا ڪرڻ لازمي آهي پر ممڪن آهي ته اهي ويڙهاڪ ۽ ٻين ابتدائي عملن لاءِ ergonomic تعريف پڻ پيش ڪن.
///
///
/// نحو ۽ پيدا ڪرڻ وارا جنريٽرز غير مستحڪم آهن ۽ انهن کي اڳتي وڌائڻ لاءِ وڌيڪ آر ايف سي جي ضرورت پوندي.هن وقت ، جيتوڻيڪ ، نحو بند هجڻ جهڙو آهي:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// اڻ سڌريل ڪتاب ۾ جنريٽرن جون وڌيڪ دستاويزون ڳولي سگھجن ٿيون.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// هن جنريٽر مان پيدا ٿيندڙ قيمت جو قسم.
    ///
    /// ھي منسلڪ قسم `yield` ظاھر ۽ قدرن سان ملندڙ آھي جيڪي ھر وقت جنريٽر پيدا ٿيڻ بعد واپس ٿيڻ جي اجازت ڏني وڃي ٿو.
    ///
    /// مثال طور ايٽرٽر-هڪ-جنريٽر شايد هن قسم کي `T` وانگر هوندو ، قسم ان جي مٿان هلي رهيو هو.
    ///
    type Yield;

    /// هن جنريٽر قيمت جو قسم موٽائي ٿو.
    ///
    /// اھو ٺاھيو ويو قسم جو ھڪڙي جنريٽر کان واپس ويو يا ته `return` بيان سان يا ظاھر طور تي ھڪڙي جنريٽر لفظي جي آخري اظهار طور.
    /// مثال طور futures ان کي `Result<T, E>` طور استعمال ڪندو جئين اهو مڪمل future جي نمائندگي ڪندو آهي.
    ///
    ///
    type Return;

    /// هن جنريٽر جي ڪارروائي ٻيهر شروع ڪري ٿو.
    ///
    /// اهو فنڪشن جنريٽر کي انجام ڏيڻ جي شروعات ڪندو يا عملدرآمد شروع ڪندو جيڪڏهن اهو اڳ ئي نه ٿيو آهي.
    /// اهو ڪال هڪ ڀيرو ٻيهر جنريٽر جي آخري معطلي واري نقطي ۾ واپس آيو ، تازو `yield` کان عملدرآمد کي ٻيهر شروع ڪندي.
    /// جنريٽر انڪشاف جاري رکندو جيستائين اهو يا ته پيداوار ڪونه ڏيندو يا موٽندو ، انهي مقام تي اهو فنڪشن واپس ٿيندو.
    ///
    /// # واپسي جي قيمت
    ///
    /// انهي فنڪشن مان واپسي `GeneratorState` اينم ٻڌائي ٿو ته رياست واپس اچڻ تي جنريٽر ڪهڙي حالت ۾ آهي.
    /// جيڪڏهن `Yielded` وارٽ موٽندي آهي ته پوءِ جنريٽر معطل ڪرڻ واري جاءِ تي پهچي ويو آهي ۽ هڪ قدر پيدا ڪئي وئي آهي.
    /// ھن رياست ۾ جنريٽر بعد ۾ شروع ڪرڻ لاءِ دستياب آھن.
    ///
    /// جيڪڏهن `Complete` واپس موٽيا وڃن ته پوءِ جنريٽر مڪمل طور تي فراهم ٿيل قدر سان مڪمل ٿي چڪو آهي.جنريٽر لاءِ وري ٻيھر ٿيڻ شروع ڪرڻ غلط آھي.
    ///
    /// # Panics
    ///
    /// اهو فنڪشن panic ٿي سگهي ٿو جيڪڏهن ان کي سڏيو وڃي ته `Complete` ويئر اڳ ۾ واپس اچي ويو آهي.
    /// جڏهن زبان ۾ جنريٽر لٽريٽس `Complete` کان پوءِ ٻيهر شروع ٿيڻ تي panic کي ضمانت ڏيڻي آهي ، اهو `Generator` trait جي سڀني عمل درآمد جي ضمانت ناهي.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}