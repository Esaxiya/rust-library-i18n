#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// هڪ `RawWaker` هڪ ڪم ڪندڙ عهديدار جي [`Waker`] ٺاهڻ جي اجازت ڏئي ٿو جيڪا ڪسٽمائيز جاڳڻ واري رويي مهيا ڪري ٿي.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// اهو هڪ ڊيٽا پوائنٽر ۽ هڪ [virtual function pointer table (vtable)][vtable] تي مشتمل آهي جيڪو `RawWaker` جي رويي کي ترتيب ڏئي ٿو.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// هڪ ڊيٽا پوائنٽر ، جيڪو عملدار طرفان گهربل گهربل صوابدیدي ڊيٽا کي محفوظ ڪرڻ لاءِ استعمال ٿي سگهي ٿو.
    /// اهو مثال ٿي سگهي ٿو
    /// `Arc` ڏانهن هڪ قسم جي حذف ڪيل پوائنٽر جيڪو ڪم سان ڳن isيل آهي.
    /// ھن فيلڊ جو ويليو سڀني فنڪشنن ڏانھن منتقل ٿي وڃي ٿو جيڪي ويٽبل جو حصو آھن پهرين پيرا ميٽر جي طور تي.
    ///
    data: *const (),
    /// مجازي فنڪشن پوائنٽر ٽيبل جيڪو هن وارر جي رويي کي حساس بڻائي ٿو.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// مهيا ڪيل `data` پوائنٽر ۽ `vtable` کان ھڪڙو نئون `RawWaker` ٺاھي ٿو.
    ///
    /// `data` پوائنٽر ثالثي ڊيٽا کي ذخيرو ڪرڻ جي ضرورت مطابق محفوظ ڪرڻ لاءِ استعمال ٿي سگهي ٿو.اهو مثال ٿي سگهي ٿو
    /// `Arc` ڏانهن هڪ قسم جي حذف ڪيل پوائنٽر جيڪو ڪم سان ڳن isيل آهي.
    /// هن پوائنٽر جي قيمت سڀني فنڪشن کي منظور ڪئي ويندي جيڪي `vtable` جو حصو آهن ، پهرين پيرا ميٽر جي طور تي.
    ///
    /// `vtable` `Waker` جي رويي کي حسب ضرورت بڻائي ٿو جيڪو `RawWaker` کان پيدا ٿئي ٿو.
    /// `Waker` تي هر آپريشن جي لاءِ ، هيٺئين `RawWaker` جي `vtable` سان لاڳاپيل ڪم سڏيو ويندو.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// هڪ مجازي فنڪشن پوائنٽر ٽيبل (vtable) جيڪو [`RawWaker`] جي رويي کي بيان ڪري ٿو.
///
/// پوائنٽر ويبلبل ۾ سڀني افعال ڏانهن ويو پوٽو [`RawWaker`] اعتراض کان `data` پوائنٽر آھي.
///
/// هن جوڙجڪ جي اندر ڪم صرف [`RawWaker`] عملدرآمد کان [`RawWaker`] اعتراض جي صحيح تعمير ٿيل [`RawWaker`] پوائنٽر تي سڏڻ جا مقصد آهن.
/// ھڪڙي سڀني ڪارنامن کي ھڪڙي فون ڪندي ، ڪنھن ٻئي `data` پوائنٽر کي استعمال ڪندي اڻ سڌريل رويو سبب.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// اهو فنڪشنل اس وقت سڏيو ويندو جڏهن [`RawWaker`] ڪلون ٿي وڃي ، مثال طور جڏهن [`Waker`] جنهن ۾ [`RawWaker`] ذخيرو ٿيل آهي کلون ٿي وڃي.
    ///
    /// هن فنڪشن جي نفاذ ۾ سڀني وسيلن کي برقرار رکڻ گهرجي جيڪي [`RawWaker`] ۽ اضافي ڪم جي هن اضافي مثال جي ضرورت آهي.
    /// نتيجي تي `wake` کي ڪال ڪريو [`RawWaker`] ساڳيو ڪم جي جاڳڻ جي نتيجي ۾ هجي ها ته اهي اصل [`RawWaker`] ذريعي جاڳندا هجن ها.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// ايڪس [`Waker`] X تي جڏهن `wake` سڏيو ويندو ته اهو فنڪشن سڏيو ويندو.
    /// اهو لازمي طور تي هن [`RawWaker`] سان جڙيل ڪم کي جاڳڻ گهرجي.
    ///
    /// انهي فنڪشن جي عملدرآمد کي يقيني بڻائڻو آهي ته ڪنهن به ذريعن کي آزاد ڪيو وڃي جيڪا [`RawWaker`] جي هن مثال سان ۽ لاڳاپيل ڪم سان جڙيل آهي.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// ايڪس [`Waker`] X تي جڏهن `wake_by_ref` سڏيو ويندو ته اهو فنڪشن سڏيو ويندو.
    /// اهو لازمي طور تي هن [`RawWaker`] سان جڙيل ڪم کي جاڳڻ گهرجي.
    ///
    /// اهو فنڪشن `wake` وانگر آهي ، پر مهيا ڪيل ڊيٽا پوائنٽر کي استعمال نه ڪرڻ گهرجي.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// جڏهن [`RawWaker`] ٽٽي ويندو آهي ته اهو فنڪشن هلايو ويندو آهي.
    ///
    /// انهي فنڪشن جي عملدرآمد کي يقيني بڻائڻو آهي ته ڪنهن به ذريعن کي آزاد ڪيو وڃي جيڪا [`RawWaker`] جي هن مثال سان ۽ لاڳاپيل ڪم سان جڙيل آهي.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// مهيا ڪيل `clone` ، `wake` ، `wake_by_ref` ، ۽ `drop` فنڪشن کان ھڪ نئون `RawWakerVTable` ٺاھي.
    ///
    /// # `clone`
    ///
    /// اهو فنڪشنل اس وقت سڏيو ويندو جڏهن [`RawWaker`] ڪلون ٿي وڃي ، مثال طور جڏهن [`Waker`] جنهن ۾ [`RawWaker`] ذخيرو ٿيل آهي کلون ٿي وڃي.
    ///
    /// هن فنڪشن جي نفاذ ۾ سڀني وسيلن کي برقرار رکڻ گهرجي جيڪي [`RawWaker`] ۽ اضافي ڪم جي هن اضافي مثال جي ضرورت آهي.
    /// نتيجي تي `wake` کي ڪال ڪريو [`RawWaker`] ساڳيو ڪم جي جاڳڻ جي نتيجي ۾ هجي ها ته اهي اصل [`RawWaker`] ذريعي جاڳندا هجن ها.
    ///
    /// # `wake`
    ///
    /// ايڪس [`Waker`] X تي جڏهن `wake` سڏيو ويندو ته اهو فنڪشن سڏيو ويندو.
    /// اهو لازمي طور تي هن [`RawWaker`] سان جڙيل ڪم کي جاڳڻ گهرجي.
    ///
    /// انهي فنڪشن جي عملدرآمد کي يقيني بڻائڻو آهي ته ڪنهن به ذريعن کي آزاد ڪيو وڃي جيڪا [`RawWaker`] جي هن مثال سان ۽ لاڳاپيل ڪم سان جڙيل آهي.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// ايڪس [`Waker`] X تي جڏهن `wake_by_ref` سڏيو ويندو ته اهو فنڪشن سڏيو ويندو.
    /// اهو لازمي طور تي هن [`RawWaker`] سان جڙيل ڪم کي جاڳڻ گهرجي.
    ///
    /// اهو فنڪشن `wake` وانگر آهي ، پر مهيا ڪيل ڊيٽا پوائنٽر کي استعمال نه ڪرڻ گهرجي.
    ///
    /// # `drop`
    ///
    /// جڏهن [`RawWaker`] ٽٽي ويندو آهي ته اهو فنڪشن هلايو ويندو آهي.
    ///
    /// انهي فنڪشن جي عملدرآمد کي يقيني بڻائڻو آهي ته ڪنهن به ذريعن کي آزاد ڪيو وڃي جيڪا [`RawWaker`] جي هن مثال سان ۽ لاڳاپيل ڪم سان جڙيل آهي.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// هڪ غير جانبدار ڪم جي `Context`.
///
/// في الحال ، `Context` صرف `&Waker` تائين رسائي فراهم ڪرڻ جو ڪم ڪري ٿو جيڪو موجوده ڪم کي جاڳڻ لاءِ استعمال ڪري سگهجي ٿو.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // يقيني بڻايون ته اسان future-پروف ويئرينس تبديلين خلاف ثبوت لائفائمٽ کي موتمار ٿيڻ تي مجبور ڪيو آهي (دليل-پوزيشن جون لائيوا متضاد آهن جڏهن ته واپسي واري پوزيشن وارا حياتي ڪيوريٽري آهن).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// ايڪس `&Waker` X کان نئون `Context` ٺاهيو.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// موجوده ڪم لاءِ ايڪسڪسيمڪس جو حوالو ڏئي ٿو.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// اي `Waker` پنهنجي عمل کي اطلاع ڏيڻ سان ڪم جاڳڻ لاءِ هڪ هينڊل آهي انهي کي هلائڻ لاءِ تيار آهي.
///
/// اهو هاربل [`RawWaker`] مثال کي ختم ڪري ٿو ، جيڪي عملدار کي مخصوص جاگنگ واري رويي جي وضاحت ڪري ٿو.
///
///
/// اندازن [`Clone`]، [`Send`]، ۽ [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// هن `Waker` سان جڙيل ڪم کي جاڳايو.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // حقيقي جاگ ڪال هڪ مجازي فنڪشن ڪال جي ذريعي عملدرآمد ڏانهن منتقل ڪيو ويو آهي جيڪو عملدار طرفان بيان ڪيو ويو آهي.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // `drop` کي ڪال نه ڪريو-ويکر `wake` پاران ڀاڙي ويندي.
        crate::mem::forget(self);

        // حفاظت: اهو محفوظ آهي ڇاڪاڻ ته `Waker::from_raw` هڪڙو ئي رستو آهي
        // `wake` ۽ `data` جي شروعات لاءِ صارف کي ان کي تسليم ڪرڻ جي ضرورت آهي `RawWaker` جو معاهدو برقرار آهي.
        //
        unsafe { (wake)(data) };
    }

    /// هن `Waker` سان منسوب ڪيل ڪم کي جاڳايو ايڪس اين ايم ايڪس ايڪس کي استعمال ڪرڻ کان سواء.
    ///
    /// اهو `wake` سان ملندڙ آهي ، پر انهي صورت ۾ شايد ڪجهه گهٽ موثر هجي جتي ملڪيت واري `Waker` موجود هجي.
    /// هن طريقي کي `waker.clone().wake()` کي سڏڻ کي ترجيح ڏني وڃي.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // حقيقي جاگ ڪال هڪ مجازي فنڪشن ڪال جي ذريعي عملدرآمد ڏانهن منتقل ڪيو ويو آهي جيڪو عملدار طرفان بيان ڪيو ويو آهي.
        //

        // حفاظت: `wake` ڏسو
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// جيڪڏهن `Waker` ۽ ٻيو `Waker` ساڳيو ڪم ڪري چڪو هجي `true` موٽائي ٿو.
    ///
    /// اهو فنڪشن تمام بهترين ڪوشش جي بنياد تي ڪم ڪري ٿو ، ۽ غلط به تڏهن موٽي سگهي ٿو جئين ويڪر هڪ ئي ڪم کي جاڳائيندو.
    /// بهرحال ، جيڪڏهن اهو ڪم ايڪسڪسيمڪس موٽائي ٿو ، اهو ضمانت آهي ته "واڪر" ساڳيو ڪم کي جاڳائيندو.
    ///
    /// ھي فنڪشن بنيادي طور تي اصلاح جي مقصدن لاءِ استعمال ڪيو ويندو آھي.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// [`RawWaker`] کان نئون `Waker` ٺاهي ٿو.
    ///
    /// واپسي `Waker` جو رويو غير مقرر ٿيل آهي جيڪڏهن معاهدو [`RawWaker`] جي ۽ [`RawWakerVTable`] جي دستاويز ۾ ڏنل نه آهي.
    ///
    /// ان ڪري اهو طريقو غير محفوظ آهي.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // حفاظت: اهو محفوظ آهي ڇاڪاڻ ته `Waker::from_raw` هڪڙو ئي رستو آهي
            // `clone` ۽ `data` جي شروعات لاءِ صارف کي ان کي تسليم ڪرڻ جي ضرورت آهي [`RawWaker`] جو معاهدو برقرار آهي.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // حفاظت: اهو محفوظ آهي ڇاڪاڻ ته `Waker::from_raw` هڪڙو ئي رستو آهي
        // `drop` ۽ `data` جي شروعات لاءِ صارف کي ان کي تسليم ڪرڻ جي ضرورت آهي `RawWaker` جو معاهدو برقرار آهي.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}