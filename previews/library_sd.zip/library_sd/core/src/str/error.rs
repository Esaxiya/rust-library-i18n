//! utf8 غلطي جي قسم جي وضاحت ڪندو آهي.

use crate::fmt;

/// نقص جيڪي واقعا ٿي سگھن ٿا جڏهن [`u8`] جي ھڪڙي تسلسل کي ھڪڙي تار وانگر سمجھڻ جي ڪوشش ڪندا.
///
/// انهي وانگر ، `from_utf8` فيمليز جا طريقا ۽ طريقا ٻنهي [اسٽرنگس] ۽ ["&str" جي غلطين جو استعمال ڪندا آهن ، مثال طور.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// هن غلطي جي قسم جا طريقا `String::from_utf8_lossy` وانگر ڪارڪردگي ٺاهڻ لاءِ استعمال ڪري سگهجن ٿا.
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// ڏنل اسٽرنگ ۾ انڊيڪس کي واپس آڻيندي جنھن کي صحيح UTF-8 جي تصديق ڪئي وئي.
    ///
    /// اھو وڌ کان وڌ انڊيڪس آھي اھڙي طرح `from_utf8(&input[..index])` `Ok(_)` واپس ڪندو.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// use std::str;
    ///
    /// // ڪجهه غلط بائيٽ ، vector ۾
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 يوٽ 8 غلطي کي واپس ڪري ٿو
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // ٻيون بائيٽ هتي غلط آهي
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// ناڪاميءَ بابت وڌيڪ معلومات مهيا ڪري ٿو:
    ///
    /// * `None`: ان پتي جي پڇاڙيءَ ۾ اوچتو پهچي وئي.
    ///   `self.valid_up_to()` ان پٹ جي پڇاڙي کان 1 کان 3 بائٽس آهي.
    ///   جيڪڏهن هڪ بائيٽ وهڪرو (جهڙوڪ هڪ فائل يا نيٽ ورڪ ساکٽ) وڌي رهيو آهي ، اهو صحيح `char` ٿي سگهي ٿو جنهن جي UTF-8 بائيٽ تسلسل ڪيترن ئي حصن ۾ پکڙيل آهي.
    ///
    ///
    /// * `Some(len)`: اڻ unexpectedاتل بائيٽ سان ملاقات ٿي چڪي هئي.
    ///   مهيا ڪيل ڊيگهه غلط بائيٽ تسلسل جي آهي جيڪا `valid_up_to()` پاران ڏنل انڊيڪس تي شروع ٿئي ٿي.
    ///   خسوده جوڙڻ جي صورت ۾ هن ترتيب (ٻيهر [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] داخل ڪرڻ کان پوءِ) ٻيهر ڪوڊنگ شروع ٿيڻ گهرجي.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// هڪ غلطي موٽي وئي جڏهن [`from_str`] استعمال ڪندي `bool` تي پارس ڪرڻ ۾ ناڪام ٿيو
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}