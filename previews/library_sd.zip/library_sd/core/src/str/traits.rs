//! Trait عمل درآمد `str` لاءِ.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// تارن جو حڪم لاڳو ڪريو.
///
/// ان جي بائيٽ قدرن طرفان سٽرنگ کي [lexicographically](Ord#lexicographical-comparison) جو حڪم ڏنو ويو آهي.
/// هي ڪوڊ ڪوڊ ۾ انهن جي پوزيشن جي بنياد تي يونيڪوڊ ڪوڊ پوائنٽس جو حڪم ڏئي ٿو.
/// اهو لازمي طور تي ايڪس ايڪس آر آرڊر وانگر ساڳيو ناهي ، جيڪو ٻولي ۽ جڳهه جي لحاظ کان مختلف آهي.
/// ثقافتي طور تي مڃيل معيارن مطابق اسٽرنگ کي ترتيب ڏيڻ مقامي جڳهن جي ڊيٽا جي ضرورت هوندي آهي جيڪي `str` قسم جي دائري کان ٻاهر هوندا آهن.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// تار تي موازنہ آپريشن آپريشن.
///
/// اسٽرنگز [lexicographically](Ord#lexicographical-comparison) سان سندن وائيٽ قدرن جي مقابلي ۾ آهن.
/// اهو ڪوڊ چارٽس ۾ انهن جي پوزيشن جي بنياد تي يونيڪوڊ ڪوڊ پوائنٽس جو تقابلي ڪندو.
/// اهو لازمي طور تي ايڪس ايڪس آر آرڊر وانگر ساڳيو ناهي ، جيڪو ٻولي ۽ جڳهه جي لحاظ کان مختلف آهي.
/// ثقافتي طور تي مڃيل معيارن مطابق اسٽرنگ جو مقابلو ڪرڻ مقامي جڳهن جي ڊيٽا جي ضرورت آهي جيڪا `str` قسم جي دائري کان ٻاهر آهي.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// سبسٽنگ سلائنگ سان نحو `&self[..]` يا `&mut self[..]` سان لاڳو ڪرڻ.
///
/// پوري سليس جو هڪ سليڪس موٽائي ٿو ، يعني `&self` يا `&mut self` موٽائي ٿو.۽ خود جي برابر آهي [0 ..
/// لين] "يا" خود پاڻ [0 ..
/// len]`.
/// ٻين انڊيڪنگ آپريشنز وانگر ، اھو ڪڏهن به panic نٿو ڪري سگھي.
///
/// هي آپريشن آهي *اي*(1).
///
/// 1.20.0 کان پهريان ، اهي indexing آپريشن `Index` ۽ `IndexMut` جي سڌي عمل درآمد طرفان اڃا تائين سهڪار ڪيا ويا هئا.
///
/// `&self[0 .. len]` يا `&mut self[0 .. len]` جي برابر
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// سبسٽنگ سلائنگ سان نحو `&self[begin .. end]` يا `&mut self[begin .. end]` سان لاڳو ڪرڻ.
///
/// بائيٽ جي حد مان ڏنل ڏنل سلائس جو هڪ ٽڪرو ڏي ٿو [شروع ٿئي ٿو ، `end`]۔
///
/// هي آپريشن آهي *اي*(1).
///
/// 1.20.0 کان پهريان ، اهي indexing آپريشن `Index` ۽ `IndexMut` جي سڌي عمل درآمد طرفان اڃا تائين سهڪار ڪيا ويا هئا.
///
/// # Panics
///
/// Panics جيڪڏهن `begin` يا `end` هڪ ڪردار جي شروعاتي بائيٽ آفسيٽ ڏانهن اشارو نٿو ڪري (جيئن `is_char_boundary` پاران بيان ڪيل آهي) ، جيڪڏهن `begin > end` ، يا جيڪڏهن `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // اهي panic ٿيندا:
/// // بائيٽ 2 `ö` اندر ڪوڙ آهي:
/// // &s [2 ..3] ؛
///
/// // بائيٽ 8 `老` جي اندر ڪوڙ آهي [1 ..
/// // 8];
///
/// // بائيٽ 100 سٽرنگ&s کان ٻاهر آهي ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // محفوظ: صرف چڪاس ڪيو ويو آهي ته `start` ۽ `end` هڪ چاربري حد تي آهن ،
            // ۽ اسان محفوظ حوالن ۾ گذري رهيا آهيون ، تنهنڪري واپسي جي قيمت به هڪ هوندي.
            // اسان پڻ چيڪ ڪيل حدن کي چڪاس ڪيو ، تنهن ڪري اهو صحيح UTF-8 آهي.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // محفوظ: صرف چڪاس ڪيو ويو آهي ته `start` ۽ `end` هڪ چارر حد تي آهن.
            // اسان اڻون ٿا ته پوائنٽر منفرد آهي ڇاڪاڻ ته اسان اهو `slice` کان حاصل ڪيو.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // حفاظت: ڪال ڪرڻ واري کي ضمانت ڏي ٿي ته `self` `slice` جي حد ۾ آهي
        // جيڪو `add` جي سڀني شرطن کي پورو ڪري ٿو.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // حفاظت: `get_unchecked` لاءِ تبصرا ڏسو.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary چيڪون آھي ته انڊيڪس [0 ۾ آھي ، .len()] `get` کي مٿي وانگر استعمال نٿو ڪري سگھي ، اين ايل ايل جي مصيبت جي ڪري
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // محفوظ: صرف چڪاس ڪيو ويو آهي ته `start` ۽ `end` هڪ چاربري حد تي آهن ،
            // ۽ اسان محفوظ حوالن ۾ گذري رهيا آهيون ، تنهنڪري واپسي جي قيمت به هڪ هوندي.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// سبسٽنگ سلائنگ سان نحو `&self[.. end]` يا `&mut self[.. end]` سان لاڳو ڪرڻ.
///
/// بائيٽ جي حد کان ڏنل ڏنل سلائس جو هڪ ٽڪرو واپس ڏئي ٿو ["0"، `end`].
/// `&self[0 .. end]` يا `&mut self[0 .. end]` جي برابر
///
/// هي آپريشن آهي *اي*(1).
///
/// 1.20.0 کان پهريان ، اهي indexing آپريشن `Index` ۽ `IndexMut` جي سڌي عمل درآمد طرفان اڃا تائين سهڪار ڪيا ويا هئا.
///
/// # Panics
///
/// Panics جيڪڏهن `end` ڪنهن ڪردار جي شروعاتي بائيٽ آفسيٽ ڏانهن اشارو نٿو ڪري (جيئن `is_char_boundary` پاران بيان ڪيل آهي) ، يا جيڪڏهن `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // حفاظت: صرف چڪاس ڪيو ويو آهي ته `end` هڪ چارر حد تي آهي ،
            // ۽ اسان محفوظ حوالن ۾ گذري رهيا آهيون ، تنهنڪري واپسي جي قيمت به هڪ هوندي.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // حفاظت: صرف چڪاس ڪيو ويو آهي ته `end` هڪ چارر حد تي آهي ،
            // ۽ اسان محفوظ حوالن ۾ گذري رهيا آهيون ، تنهنڪري واپسي جي قيمت به هڪ هوندي.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // حفاظت: صرف چڪاس ڪيو ويو آهي ته `end` هڪ چارر حد تي آهي ،
            // ۽ اسان محفوظ حوالن ۾ گذري رهيا آهيون ، تنهنڪري واپسي جي قيمت به هڪ هوندي.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// سبسٽنگ سلائنگ سان نحو `&self[begin ..]` يا `&mut self[begin ..]` سان لاڳو ڪرڻ.
///
/// بائيٽ جي حد کان ڏنل ڏنل سلين جو هڪ ٽڪرو موٽائي ٿو `[شروع ٿئي ٿو ، `len`].۽ خود جي برابر آهي [شروعات ..
/// لين] يا "۽ پاڻ [شروع ..
/// len]`.
///
/// هي آپريشن آهي *اي*(1).
///
/// 1.20.0 کان پهريان ، اهي indexing آپريشن `Index` ۽ `IndexMut` جي سڌي عمل درآمد طرفان اڃا تائين سهڪار ڪيا ويا هئا.
///
/// # Panics
///
/// Panics جيڪڏهن `begin` ڪنهن ڪردار جي شروعاتي بائيٽ آفسيٽ ڏانهن اشارو نٿو ڪري (جيئن `is_char_boundary` پاران بيان ڪيل آهي) ، يا جيڪڏهن `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // حفاظت: صرف چڪاس ڪيو ويو آهي ته `start` هڪ چارر حد تي آهي ،
            // ۽ اسان محفوظ حوالن ۾ گذري رهيا آهيون ، تنهنڪري واپسي جي قيمت به هڪ هوندي.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // حفاظت: صرف چڪاس ڪيو ويو آهي ته `start` هڪ چارر حد تي آهي ،
            // ۽ اسان محفوظ حوالن ۾ گذري رهيا آهيون ، تنهنڪري واپسي جي قيمت به هڪ هوندي.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // حفاظت: ڪال ڪرڻ واري کي ضمانت ڏي ٿي ته `self` `slice` جي حد ۾ آهي
        // جيڪو `add` جي سڀني شرطن کي پورو ڪري ٿو.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // حفاظت: `get_unchecked` تي هڪجهڙائي.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // حفاظت: صرف چڪاس ڪيو ويو آهي ته `start` هڪ چارر حد تي آهي ،
            // ۽ اسان محفوظ حوالن ۾ گذري رهيا آهيون ، تنهنڪري واپسي جي قيمت به هڪ هوندي.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// سبسٽنگ سلائنگ سان نحو `&self[begin ..= end]` يا `&mut self[begin ..= end]` سان لاڳو ڪرڻ.
///
/// بائيٽ جي حد [`begin`, `end`] مان ڏنل اسٽرنگ جو هڪ ٽڪرو واپس ڏئي ٿو.`&self [begin .. end + 1]` يا `&mut self[begin .. end + 1]` جي برابر ، سواء جيڪڏهن `end` وٽ `usize` جي وڌ ۾ وڌ قدر آھي.
///
/// هي آپريشن آهي *اي*(1).
///
/// # Panics
///
/// Panics جيڪڏهن `begin` هڪ ڪردار جي شروعاتي بائيٽ آفسيٽ ڏانهن اشارو نٿو ڪري (جيئن `is_char_boundary` پاران بيان ڪيل آهي) ، جيڪڏهن `end` ڪنهن ڪردار جي ختم ٿيڻ واري بائيٽ آفسيٽ ڏانهن اشارو نه ٿو ڪري (`end + 1` يا ته شروعات جي بائيٽ آفسيٽ يا `len` جي برابر آهي) ، جيڪڏهن `begin > end` ، يا جيڪڏهن `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // حفاظت: ڪال ڪندڙ کي `get_unchecked` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // حفاظت: ڪال ڪندڙ کي `get_unchecked_mut` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// سبسٽنگ سلائنگ سان نحو `&self[..= end]` يا `&mut self[..= end]` سان لاڳو ڪرڻ.
///
/// بائيٽ جي حد [0, `end`] مان ڏنل اسٽرنگ جو هڪ ٽڪرو واپس ڏئي ٿو.
/// ايڪس 01 ايڪس جي برابر ، سواء جيڪڏهن `end` وٽ `usize` جي وڌ ۾ وڌ قدر آهي.
///
/// هي آپريشن آهي *اي*(1).
///
/// # Panics
///
/// Panics جيڪڏهن `end` هڪ ڪردار جي ختم ٿيڻ واري بائيٽ آف سيٽ ڏانهن اشارو نه ٿو ڪري (`end + 1` هڪ شروعاتي بائيٽ آف سيٽ آهي جيئن `is_char_boundary` پاران بيان ڪيل آهي ، يا `len` جي برابر) ، يا جيڪڏهن `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // حفاظت: ڪال ڪندڙ کي `get_unchecked` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // حفاظت: ڪال ڪندڙ کي `get_unchecked_mut` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// ھڪڙي تار مان ھڪڙي قدر ڪريو
///
/// "StrS" جي [`from_str`] طريقو اڪثر طريقي سان ، اسٽوريٽ [`parse`] طريقي سان استعمال ڪيو ويندو آهي.
/// مثال طور ، [پارسي] جي دستاويز ڏسو.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` حياتي حياتي پيراگراف ڪونهي ، ۽ تنهن ڪري توهان صرف قسم جون وضاحتون ڪري سگهو ٿا جيڪي انهن پاڻ ۾ حياتي حياتي پيراگراف شامل نه آهن.
///
/// ٻين لفظن ۾ ، توهان `FromStr` سان `i32` پارسي ڪري سگهو ٿا ، پر ايڪس `&i32` نه.
/// توهان هڪ ترتيب کي پارسي ڪري سگهو ٿا جنهن ۾ هڪ `i32` شامل آهي ، پر هڪ نه جنهن ۾ `&i32` شامل آهي.
///
/// # Examples
///
/// `FromStr` جو بنيادي مثال ھڪڙو مثال آھي `Point` قسم:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// ملندڙ غلطي جنهن کي پار ڪرڻ کان واپس ڪري سگهجي ٿو.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// ھن قسم جي ھڪڙي قيمت ڏانھن واپسي لاءِ ھڪڙي اسٽرنگ `s` کي ترتيب ڏيندو آھي.
    ///
    /// جيڪڏهن ترتيب ڏيڻ ڪامياب ٿيو ، [`Ok`] جي اندر قيمت واپس ڪن ، ٻي صورت ۾ جڏهن اسٽرنگ غلط شڪل ۾ آهي اندر [`Err`] لاءِ مخصوص غلطي ڏي.
    /// غلطي جو قسم trait تي عمل درآمد لاءِ مخصوص آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال [`i32`] سان ، هڪ قسم آهي جيڪو `FromStr` تي عمل ڪندو آهي:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// هڪ تار مان هڪ `bool` پار ڪريو.
    ///
    /// `Result<bool, ParseBoolError>` حاصل ڪري ٿو ، ڇاڪاڻ ته `s` شايد اصل ۾ قابل حل نه هوندا آهن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// نوٽ ، ڪيترن ئي ڪيسن ۾ ، `str` تي X00 طريقو وڌيڪ مناسب آهي.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}