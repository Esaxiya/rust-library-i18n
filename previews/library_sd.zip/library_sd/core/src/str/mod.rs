//! تاريون سنڀالڻ.
//!
//! وڌيڪ تفصيلن لاءِ ڏسو [`std::str`] ماڊل.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. حدن کان ٻاهر
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. شروعات <=ختم
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. ڪردار جي حد
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // ڪردار ڳوليو
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` لين ۽ چار جي حد کان گهٽ هجڻ لازمي آهي
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// `self` جي ڊيگهه کي ڏيکاري ٿو.
    ///
    /// ڊيگهه اها بائٽس ۾ آهي ، نه ڪي [چارس] يا گرافڪس.
    /// ٻين لفظن ۾ ، اهو شايد نه ٿي سگهي ٿو ته هڪ انسان تار جي ڊيگهه کي سمجهي ٿو.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // سهڻو!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// `true` کي واپسي ڏئي ٿو جيڪڏھن `self` صفر بائٽس جي ڊيگهه آھي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// چيڪ ڪريو ته `انڊيڪس` ٽي بائيٽ XteX ڪوڊ پوائنٽ جي تسلسل ۾ پهرين بائيٽ آهي يا اسٽرنگ جي پڇاڙي.
    ///
    ///
    /// تار جو آغاز ۽ آخر (جڏهن `index== self.len()`) حدون سمجهيو وڃي ٿو).
    ///
    /// جيڪڏهن `index` `self.len()` کان وڏو آهي ته واپس اچي ٿو `false`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // `老` جي شروعات
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // `ö` جو ٻيو بائيٽ
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // `老` جو ٽيون بائيٽ
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 ۽ لين هميشه ٺيڪ آھن.
        // 0 واضح طور تي جانچيو ته جيئن اھو آساني سان چيڪ کي بهتر ڪري سگھن ۽ ان صورت لاءِ پڙھڻ واري اسٽرنگ ڊيٽا کي ڇڏي ڏيو.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // ھي bit جادو برابر آھي: b <128 ||ب>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// بٽرٽ سلائس کي اسٽرنگ سلائس کي بدلائي ٿي.
    /// بائيٽ سلائس کي واپس واري اسٽرنگ ۾ تبديل ڪرڻ لاءِ ، [`from_utf8`] فنڪشن استعمال ڪريو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // حفاظت: آواز آواز ڇاڪاڻ ته اسان هڪ ئي ترتيب سان ٻن قسمن کي منتقل ڪريون ٿا
        unsafe { mem::transmute(self) }
    }

    /// بدلڻ واري تار واري سليس کي هڪ تبديل ٿيندڙ بائيٽ سلائس ۾ تبديل ڪري ٿي.
    ///
    /// # Safety
    ///
    /// ڪالر کي ان ڳالهه کي يقيني بڻائڻو آهي ته قرض ختم ٿيڻ کان پهريان ۽ هيٺيان `str` استعمال ٿيل سلائسز جو مواد درست UTF-8 آهي.
    ///
    ///
    /// `str` جو استعمال درست نه آهي جن جا مواد UTF-8 صحيح نه آهن اڻ سڌريل رويي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // حفاظت: `&str` کان `&[u8]` کان ڪاسٽ `str` کان محفوظ آهي
        // `&[u8]` وانگر ھڪڙي ئي ترتيب آھي (صرف اھو لائسٽ ڊي ، هي گارنٽي ڪري سگھي ٿو).
        // پوائنٽر جي عزت محفوظ آهي جئين اهو هڪ قابل تبديلي حوالي سان اچي ٿو جيڪا لکڻ جي صحيح هجڻ جي ضمانت آهي.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// ھڪڙي پوائنٽر واري ھڪڙي پوائنٽ کي ھڪڙي پوائنٽر ڏانھن تبديل ڪري ٿو.
    ///
    /// جيئن ته اسٽرنگ سلائسس بائيٽ جو هڪ ٽڪرو آهي ، خام پوائنٽر [`u8`] ڏانهن اشارو ڪن ٿا.
    /// هن پوائنٽر ڏانهن اشارو واري سلائيٽ جي پهرين بائيٽ ڏانهن اشارو ڪيو ويندو.
    ///
    /// سڏيندڙ کي اهو يقين ڏيارڻ گهرجي ته موٽندڙ پوائنٽر ڪڏهن به نه لکيو ويندو آهي.
    /// جيڪڏهن توهان کي اسٽرنگ سلائس جي مواد کي تبديل ڪرڻ جي ضرورت آهي ، [`as_mut_ptr`] استعمال ڪريو.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// تبديل ٿيندڙ ھڪڙي تبديلي واري اسٽرنگ سل کي خام پوائنٽر ڏانھن.
    ///
    /// جيئن ته اسٽرنگ سلائسس بائيٽ جو هڪ ٽڪرو آهي ، خام پوائنٽر [`u8`] ڏانهن اشارو ڪن ٿا.
    /// هن پوائنٽر ڏانهن اشارو واري سلائيٽ جي پهرين بائيٽ ڏانهن اشارو ڪيو ويندو.
    ///
    /// اها توهان جي ذميواري آهي ته توهان انهي ڳالهه کي يقيني بڻايون ته اسٽرنگ سليس صرف انهي طريقي سان تبديل ٿي وڃي ته اهو صحيح UTF-8 رهندو.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// `str` جو ذيلي ذخيرو واپس اچي ٿو.
    ///
    /// اھو `str` کي انڊيڪس ڏيڻ لاءِ غير رڪاوٽ وارو متبادل آھي.
    /// [`None`] موٽائي ٿو جڏهن برابر انڊيڪيٽنگ آپريشن panic ٿي ها.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // ايڪسچيڪس ايڪس آرڪس جي حدن تي نه
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // حدن کان ٻاهر
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// `str` جي قابل تبديلي سبسڪرانس ڏيکاري ٿو.
    ///
    /// اھو `str` کي انڊيڪس ڏيڻ لاءِ غير رڪاوٽ وارو متبادل آھي.
    /// [`None`] موٽائي ٿو جڏهن برابر انڊيڪيٽنگ آپريشن panic ٿي ها.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // صحيح ڊيگهه
    /// assert!(v.get_mut(0..5).is_some());
    /// // حدن کان ٻاهر
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// `str` جو ھڪڙي غير چيڪ ٿيل سبسڪرس ڏي ٿو.
    ///
    /// ايڪس ايڪس ايڪس کي انڊيڪس ڏيڻ لاءِ اهو غير محفوظ متبادل آهي.
    ///
    /// # Safety
    ///
    /// انهي فنڪشن جا ڪالر ذميوار آهن ته اهي شرطون مطمئن آهن:
    ///
    /// * شروعاتي انڊيڪس ختم ٿيڻ واري انڊيڪس کان وڌيڪ نه هجڻ گھرجي ؛
    /// * انڊيڪس اصل سليس جي حدن ۾ هجڻ گهرجن ؛
    /// * انڊيڪس ايڪس 0 ايڪس سيڪس جي حدن تي لازمي طور تي ڪوڙ هجن.
    ///
    /// انهي ۾ ناڪام ٿي ، موٽڻ واري اسٽرنگ سلائس غلط ياداشت جي حوالي ڪري سگهي ٿي يا `str` قسم سان ٺاهيل مخلصن جي ڀڃڪڙي ڪري سگهي ٿي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // حفاظت: ڪال ڪندڙ کي `get_unchecked` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        // سلائس غير قابل بيان آهي ڇاڪاڻ ته `self` هڪ محفوظ حوالو آهي.
        // واپسي پوائنٽر محفوظ آهي ڇاڪاڻ ته `SliceIndex` جي نقل لازمي آهي ته ان جي ضمانت ڏي.
        unsafe { &*i.get_unchecked(self) }
    }

    /// `str` جي قابل تبديلي ، اڻ چڪاس سبسڪرس ڏيکاري ٿو.
    ///
    /// ايڪس ايڪس ايڪس کي انڊيڪس ڏيڻ لاءِ اهو غير محفوظ متبادل آهي.
    ///
    /// # Safety
    ///
    /// انهي فنڪشن جا ڪالر ذميوار آهن ته اهي شرطون مطمئن آهن:
    ///
    /// * شروعاتي انڊيڪس ختم ٿيڻ واري انڊيڪس کان وڌيڪ نه هجڻ گھرجي ؛
    /// * انڊيڪس اصل سليس جي حدن ۾ هجڻ گهرجن ؛
    /// * انڊيڪس ايڪس 0 ايڪس سيڪس جي حدن تي لازمي طور تي ڪوڙ هجن.
    ///
    /// انهي ۾ ناڪام ٿي ، موٽڻ واري اسٽرنگ سلائس غلط ياداشت جي حوالي ڪري سگهي ٿي يا `str` قسم سان ٺاهيل مخلصن جي ڀڃڪڙي ڪري سگهي ٿي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // حفاظت: ڪال ڪندڙ کي `get_unchecked_mut` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        // سلائس غير قابل بيان آهي ڇاڪاڻ ته `self` هڪ محفوظ حوالو آهي.
        // واپسي پوائنٽر محفوظ آهي ڇاڪاڻ ته `SliceIndex` جي نقل لازمي آهي ته ان جي ضمانت ڏي.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// حفاظت جي چڪاس کي نظرانداز ڪندي ، هڪ ٻئي تارنگ سلائس مان هڪ اسٽرنگ سلس ٺاهي ٿو.
    ///
    /// اهو عام طور تي سفارش نه ڪئي وئي آهي ، احتياط سان استعمال ڪريو!هڪ محفوظ متبادل لاءِ ڏسو [`str`] ۽ [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// هي نئون سلائس ايڪسڪسيمڪس کان `end` ڏانهن وڃي ٿو ، جنهن ۾ `begin` به شامل آهي پر `end` کي به شامل نه آهي.
    ///
    /// بدلي واري سليٽر سلائس حاصل ڪرڻ بدران ، [`slice_mut_unchecked`] طريقو ڏسو.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// هن فنڪشن جا ڪالر ذميوار آهن ته ٽي شرطون مطمئن آهن:
    ///
    /// * `begin` `end` کان وڌيڪ نه هجڻ گهرجي.
    /// * `begin` ۽ ايڪسڪسيمڪس کي سٽرنگ سلائس جي اندر بائيٽ پوزيشن هجڻ گهرجي.
    /// * `begin` ۽ `end` کي UTF-8 ترتيب جي حدن تي ويھڻ گھرجي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // حفاظت: ڪال ڪندڙ کي `get_unchecked` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        // سلائس غير قابل بيان آهي ڇاڪاڻ ته `self` هڪ محفوظ حوالو آهي.
        // واپسي پوائنٽر محفوظ آهي ڇاڪاڻ ته `SliceIndex` جي نقل لازمي آهي ته ان جي ضمانت ڏي.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// حفاظت جي چڪاس کي نظرانداز ڪندي ، هڪ ٻئي تارنگ سلائس مان هڪ اسٽرنگ سلس ٺاهي ٿو.
    /// اهو عام طور تي سفارش نه ڪئي وئي آهي ، احتياط سان استعمال ڪريو!هڪ محفوظ متبادل لاءِ ڏسو [`str`] ۽ [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// هي نئون سلائس ايڪسڪسيمڪس کان `end` ڏانهن وڃي ٿو ، جنهن ۾ `begin` به شامل آهي پر `end` کي به شامل نه آهي.
    ///
    /// ھڪڙي مٽائڻ واري تار واري سليس کي حاصل ڪرڻ بدران ، [`slice_unchecked`] طريقي کي ڏسو.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// هن فنڪشن جا ڪالر ذميوار آهن ته ٽي شرطون مطمئن آهن:
    ///
    /// * `begin` `end` کان وڌيڪ نه هجڻ گهرجي.
    /// * `begin` ۽ ايڪسڪسيمڪس کي سٽرنگ سلائس جي اندر بائيٽ پوزيشن هجڻ گهرجي.
    /// * `begin` ۽ `end` کي UTF-8 ترتيب جي حدن تي ويھڻ گھرجي.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // حفاظت: ڪال ڪندڙ کي `get_unchecked_mut` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        // سلائس غير قابل بيان آهي ڇاڪاڻ ته `self` هڪ محفوظ حوالو آهي.
        // واپسي پوائنٽر محفوظ آهي ڇاڪاڻ ته `SliceIndex` جي نقل لازمي آهي ته ان جي ضمانت ڏي.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// ھڪڙي انڊسٽري ۾ ھڪڙي ھڪڙي سليڪٽ کي 2 ۾ ورهايو.
    ///
    /// دليل ، `mid` ، اسٽرنگ جي شروعات کان هڪ بائيٽ آفسیٽ هجڻ گهرجي.
    /// اهو UTF-8 ڪوڊ پوائنٽ جي حد تي پڻ هئڻ لازمي آهي.
    ///
    /// ٻن سلائسس واپس اچي ويو آهن اسٽرنگ سلائس جي شروعات کان `mid` تائين ، ۽ `mid` کان وٺي اسٽرنگ سلائس جي آخر تائين.
    ///
    /// بدلي سٽرنگ سلائسس حاصل ڪرڻ بدران ، [`split_at_mut`] طريقو ڏسو.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `mid` UTF-8 ڪوڊ پوائنٽ جي حد تي نه هجي ، يا جيڪڏهن اهو اسٽرنگ سلائس جي آخري ڪوڊ پوائنٽ جي آخر جي ماضي ۾ هجي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary چيڪون آھي ته انڊيڪس [0 ۾ آھي ، .len()]
        if self.is_char_boundary(mid) {
            // محفوظ: صرف چڪاس ڪيو ويو آهي ته `mid` هڪ چارر حد تي آهي.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ھڪڙي انڊيڪس ۾ ھڪڙي مٽاسٽنگ واري سلائي کي 2 ۾ ورهايو.
    ///
    /// دليل ، `mid` ، اسٽرنگ جي شروعات کان هڪ بائيٽ آفسیٽ هجڻ گهرجي.
    /// اهو UTF-8 ڪوڊ پوائنٽ جي حد تي پڻ هئڻ لازمي آهي.
    ///
    /// ٻن سلائسس واپس اچي ويو آهن اسٽرنگ سلائس جي شروعات کان `mid` تائين ، ۽ `mid` کان وٺي اسٽرنگ سلائس جي آخر تائين.
    ///
    /// بدران سادگي واري تار سلائس حاصل ڪرڻ لاءِ ، [`split_at`] طريقو ڏسو.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `mid` UTF-8 ڪوڊ پوائنٽ جي حد تي نه هجي ، يا جيڪڏهن اهو اسٽرنگ سلائس جي آخري ڪوڊ پوائنٽ جي آخر جي ماضي ۾ هجي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary چيڪون آھي ته انڊيڪس [0 ۾ آھي ، .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // محفوظ: صرف چڪاس ڪيو ويو آهي ته `mid` هڪ چارر حد تي آهي.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ھڪڙي تار کي سلائي سلائس جي [`char`] مٿان وھرائيندو آھي.
    ///
    /// جئين ھڪڙي اسٽرنگ سلائس صحيح UTF-8 تي مشتمل آھي ، اسان [`char`] پاران ھڪڙي اسٽرنگ سلائس ذريعي مھرباني ڪري سگھون ٿا.
    /// اھو طريقو اھڙي ايرايٽر کي واپس ڪري ٿو.
    ///
    /// اهو ياد رکڻ ضروري آهي ته [`char`] يونيڪوڊ اسڪالر ويليو جي نمائندگي ڪري ٿو ، ۽ شايد توهان جي خيال سان مطابقت نه رکي سگهي ته 'character' ڇا آهي.
    ///
    /// گرافيم ڪلستر تي ورڇ اهو ٿي سگهي ٿو جيڪو توهان اصل ۾ چاهيو ٿا.
    /// اهو ڪارڪردگي Rust جي معياري لائبريري طرفان فراهم نه ڪئي وئي آهي ، چڪاس ڪريو بدران crates.io.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// ياد رکو ، ["چار"] شايد ڪردارن بابت توهان جي سوچ کي مطابقت نه رکي سگهي.
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ايڪس ايڪس نيڪس نه
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// هڪ [بار بار] تار واري سلائس ، ۽ انهن جي پوزيشن کان وڌيڪ ورجائي ٿو.
    ///
    /// جئين ھڪڙي اسٽرنگ سلائس صحيح UTF-8 تي مشتمل آھي ، اسان [`char`] پاران ھڪڙي اسٽرنگ سلائس ذريعي مھرباني ڪري سگھون ٿا.
    /// اهو طريقو هنن ٻنهي [char]] جي ٻيهر ورجائي ٿو ، ۽ انهي سان گڏ انهن جي بائيٽ واري پوزيشن کي.
    ///
    /// آئيرٽر تپليس پيدا ڪندو آهي.پهرين نمبر تي آهي ، [`char`] ٻي آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// ياد رکو ، ["چار"] شايد ڪردارن بابت توهان جي سوچ کي مطابقت نه رکي سگهي.
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // نه (0 ، 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // هتي 3 نوٽ ڪريو ، آخري ڪردار ٻٽي بٽس ورتي
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// هڪ ويڙهاڪ هڪ سلور سلائس جي بائٽس مٿان.
    ///
    /// جيئن ته هڪ تار ۾ سلائيٽ بائيٽ جي تسلسل تي مشتمل آهي ، اسان بائيٽ جي هڪ اسٽرنگ سلائس ذريعي وڪري ڪري سگهون ٿا.
    /// اھو طريقو اھڙي ايرايٽر کي واپس ڪري ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// اسپائيٽ سليٽس کي وائيٽ اسپيس سان ورهائي ٿو.
    ///
    /// وراثت وارو موٽي اچي ٿو ڏنگو سلائسس جيڪي اصلي اسٽرنگ سلائس جا ذيلي سلائسون آهن ، ڪنهن به جڳهه کي ڪٽي جي ڌار ڌار ڌار ڪري.
    ///
    ///
    /// 'Whitespace' بيان ڪيو ويو آھي يونيڪوڊ ڪivedيل ڪور پراپرٽي `White_Space` جي شرطن جي مطابق.
    /// جيڪڏهن توهان صرف ASCII وائيٽ اسپيس تي ورهائڻ چاهيو ٿا ، [`split_ascii_whitespace`] استعمال ڪريو.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// هر قسم جي اڇلائي واري جڳهه سمجهيو ويندو آهي:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// اي ايس سي آئي آئي اسپيس اسپيس طرفان هڪ سلور سلائس کي ورهائي ٿو.
    ///
    /// وراثت وارو موٽي اچي ٿو ڏنگو سلائسس جيڪي اصلي اسٽرنگ سلائس جا ذيلي سلائسون آهن ، ڪنهن به رقم اي ايس سي آئي اي آئي اسپيس اسپيس کي ڌار ڪندي.
    ///
    ///
    /// يونيڪوڊ `Whitespace` پاران ورهائڻ لاءِ ، ايڪس ڪيوڪس کي استعمال ڪريو.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// ASCII هر جڳهه کي مڪمل طور سمجهڻ وارا آهن:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// ھڪڙي تارري جي تار مٿان ، ھڪڙي تار کي سلائسن وانگر.
    ///
    /// لائنون يا ته هڪ نئين لائن (`\n`) يا هڪ گاڏي واپسي لائن سان فيڊ (`\r\n`) سان ختم ٿي وڃن ٿيون.
    ///
    /// آخري لائين ختم ٿيڻ اختياري آهي.
    /// ھڪڙي تار جيڪا آخري ليڪ جي ختم ٿيڻ سان ختم ٿئي ٿي ، ساڳين ليڪن کي ٻي صورت ۾ ختم ڪندي بغير ٻي لڪير ختم ڪندي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// آخري لائين ختم ٿيڻ جي ضرورت ناھي:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// هڪ تار جي تار مٿان هڪ بار بار.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// UTF-16 جي طور تي انڪوڊ ٿيل اسٽرنگ مٿان `u16` جو هڪ ورجاءُ موٽائي ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// ايڪس ڏنو ايڪس کي واپسي ڏئي ٿو جيڪڏهن ڏنل نموني هن ڏاڪڻ واري سلائس جي ذيلي سلائس سان ملي ٿو.
    ///
    /// `false` واپس ڪري ٿو جيڪڏھن اھو نٿو اچي.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// ايڪس ڏنو ايڪس کي واپسي ڏئي ٿو جيڪڏهن ڏنل نموني هي اسٽرنگ سلائس جي اڳياڙي سان ملي.
    ///
    /// `false` واپس ڪري ٿو جيڪڏھن اھو نٿو اچي.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// `true` جي واپسي ڏي ٿو جيڪڏهن ڏنل نموني انهي تار واري ٻلي جي هڪ لاحق سان ملي ٿي.
    ///
    /// `false` واپس ڪري ٿو جيڪڏھن اھو نٿو اچي.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// ھن اسٽرنگ سلائس جو پھريون ڪردار جي بائيٽ انڊيڪس موٽائي ٿو جيڪو نمونن سان ملي ٿو.
    ///
    /// [`None`] واپس ڪري ٿو جيڪڏھن نموني نٿو ملي.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// سادو نمونو:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// وڌيڪ پيچيده نمونا استعمال ڪندي پوائنٽ کان آزاد انداز ۽ بندش:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// نمونو نه ڳولي رهيو آهي:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// ھن اسٽرنگ سلائس ۾ نمونن جي سب سے صحيح ملاھٽ لاءِ بائيٽ انڊيڪس کي واپس ڏئي ٿو.
    ///
    /// [`None`] واپس ڪري ٿو جيڪڏھن نموني نٿو ملي.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// سادو نمونو:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// وڌيڪ پيچيده نمونن سان بندش:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// نمونو نه ڳولي رهيو آهي:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// اهو اسٽرنگ سلائس جي ذيلي تقسيم تي هڪ ويڙهاڪ ، جدا جدا ڪردارن طرفان هڪ نمونو.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ارتقائي رويو
    ///
    /// واپس ٿيل ورجائي هڪ [`DoubleEndedIterator`] ٿيندو جيڪڏهن نمونو ريورس سرچ جي اجازت ڏئي ٿو ۽ forward/reverse ڳولا ساڳيو عناصر پيدا ڪري ٿي.
    /// اها سچ آهي ، مثال طور ، [`char`] لاءِ ، پر `&str` لاءِ نه.
    ///
    /// جيڪڏھن نمونہ ريورس سرچ جي اجازت ڏئي پر ان جا نتيجا اڳتي وڌڻ واري ڳولا کان مختلف ٿي سگھن ، [`rsplit`] طريقو استعمال ڪري سگھجي ٿو.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// سادو نمونو:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// جيڪڏهن نمونہ ڪارن جو هڪ ٽڪرو آهي ، ڪنهن جي به ڪردارن جي جدا ٿيڻ تي ورهايو.
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// وڌيڪ پيچيده نموني ، هڪ بند کي استعمال ڪندي:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// جيڪڏھن ھڪڙي جملن ۾ گھڻن سان اھل جدا جدا شامل آھن ، توھان ٻاھر وارا ختم ٿيندڙ ختم ٿي ويندا.
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// لاڳيتو ڌار ڌار ٿورا ڌار ڌار تار طرفان جدا ڪيا ويا آهن.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// هڪ تار جي شروعات يا آخر ۾ خالي تار جي ذريعي لڳل آهن.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// جڏهن خالي اسٽرنگ کي هڪ جدا ڪندڙ طور استعمال ڪيو ويندو آهي ، اهو تار ۾ هر ڪردار کي جدا ڪرڻ سان گڏ ، تار جي شروعات ۽ آخر سان گڏ ٿيندو آهي.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// ويجهڙائي واري ڌار ڌار ڌڪ لڳائيندڙ حيران ڪندڙ رويي جو سبب بڻجي سگهي ٿي جڏهن ته ڌار ڌار کي ڌار ڌار طور استعمال ڪيو ويندو آهي.هي ڪوڊ صحيح آهي:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// اھو _not_ توھان کي ڏئي ٿو:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// استعمال ڪريو [`split_whitespace`] هن رويي لاء.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// اهو اسٽرنگ سلائس جي ذيلي تقسيم تي هڪ ويڙهاڪ ، جدا جدا ڪردارن طرفان هڪ نمونو.
    /// `split` پاران ٺاهيل انبارير کان ڌار تنهن ۾ `split_inclusive` انهي جوڙي وارو حصو ڇڏي ٿو سبسٽرنگ جو ختم ٿيڻ وارو.
    ///
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// جيڪڏھن ڏور جو آخري عنصر ملائي آھي ، اھو عنصر اڳين سبسٽنگ کي ختم ڪرڻ وارو سمجهيو ويندو.
    /// انهي سبسٽنگ کي آخرڪار واپس ويندڙ شيئر ٿيندي.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// هڪ تسلسل ڏنل ڏنل اسٽرنگ سلائسز جي مٿان ، ڌار ڌار حرفن سان جدا جدا نمونن ۽ جدا طريقي سان ترتيب ڏنل.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ارتقائي رويو
    ///
    /// واپس ٿيل ايراضيٽر جي ضرورت آهي ته اهو نمونو هڪ ريورس ڳولڻ جي حمايت ڪري ٿو ، ۽ اهو هڪ [`DoubleEndedIterator`] ٿيندو جيڪڏهن هڪ forward/reverse ڳولا ساڳيو عناصر پيدا ڪري.
    ///
    ///
    /// مئٽرڪ کان ايندڙ دهرائڻ لاءِ ، [`split`] طريقو استعمال ڪري سگھجي ٿو.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// سادو نمونو:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// وڌيڪ پيچيده نموني ، هڪ بند کي استعمال ڪندي:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// هڪ ورها stringي ڏنل ڏنل اسٽرنگ جي نقشن تي ، جدا جدا ڪردارن سان جدا جدا نمونا.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] جي برابر ، انهي کان سواء ته پيچرو سبسٽنگ کي خالي ڪيو ويو آهي جيڪڏهن خالي آهي.
    ///
    /// [`split`]: str::split
    ///
    /// اهو طريقو ، اسٽرنگ ڊيٽا لاءِ استعمال ڪري سگهجي ٿو جيڪا _terminated_ آهي ، بدران _separated_ هڪ نموني ذريعي.
    ///
    /// # ارتقائي رويو
    ///
    /// واپس ٿيل ورجائي هڪ [`DoubleEndedIterator`] ٿيندو جيڪڏهن نمونو ريورس سرچ جي اجازت ڏئي ٿو ۽ forward/reverse ڳولا ساڳيو عناصر پيدا ڪري ٿي.
    /// اها سچ آهي ، مثال طور ، [`char`] لاءِ ، پر `&str` لاءِ نه.
    ///
    /// جيڪڏھن نمونہ ريورس سرچ جي اجازت ڏئي پر ان جا نتيجا اڳتي وڌڻ واري ڳولا کان مختلف ٿي سگھن ، [`rsplit_terminator`] طريقو استعمال ڪري سگھجي ٿو.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// ايٽرريٽر `self` سبسٽنگس تي ، ڌار ڌار حرفن سان جدا جدا نمونا ۽ ريورس ترتيب ۾ پيدا ٿيل.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// [`split`] جي برابر ، انهي کان سواء ته پيچرو سبسٽنگ کي خالي ڪيو ويو آهي جيڪڏهن خالي آهي.
    ///
    /// [`split`]: str::split
    ///
    /// اهو طريقو ، اسٽرنگ ڊيٽا لاءِ استعمال ڪري سگهجي ٿو جيڪا _terminated_ آهي ، بدران _separated_ هڪ نموني ذريعي.
    ///
    /// # ارتقائي رويو
    ///
    /// واپس ٿيل ايراضيٽر جي ضرورت آهي ته اهو نمونو هڪ ريورس ڳولڻ جي حمايت ڪري ٿو ، ۽ جيڪڏهن ٻه ڀيرا ختم ٿي ويندي ته forward/reverse ساڳيو عناصر پيدا ڪندي.
    ///
    ///
    /// مئٽرڪ کان ايندڙ دهرائڻ لاءِ ، [`split_terminator`] طريقو استعمال ڪري سگھجي ٿو.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// هڪ ترتيب وارو ڏنل اسٽرنگ سلائسس جي ماتحت حصن مٿان ، هڪ نمونو ڌار ڌار ، اڪثر `n` شيون تي موٽڻ تائين محدود.
    ///
    /// جيڪڏهن `n` ذرا واپس موٽيا ويا آهن ، آخري سبسٽنگ (`اين` سب سبسٽنگ) ۾ باقي واري تار هوندي.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ارتقائي رويو
    ///
    /// واپس ٿيل ورجاءُ ٻيڻو ختم نه ڪيو ويندو ، ڇو ته سهائتا ڪرڻ قابل نه آهي.
    ///
    /// جيڪڏهن نموني هڪ ريورس ڳولڻ جي اجازت ڏئي ٿو ، ايڪس X00 طريقو استعمال ڪري سگهجي ٿو.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// سادو نمونو:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// وڌيڪ پيچيده نموني ، هڪ بند کي استعمال ڪندي:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// انهي تارنگ سلائس جي ماتحت حصن تي هڪ ويڙهاڪ ، هڪ نمونو جدا جدا ، اسٽرنگ جي آخر کان شروع ، اڪثر `n` شيون تي واپس اچڻ تائين محدود.
    ///
    ///
    /// جيڪڏهن `n` ذرا واپس موٽيا ويا آهن ، آخري سبسٽنگ (`اين` سب سبسٽنگ) ۾ باقي واري تار هوندي.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ارتقائي رويو
    ///
    /// واپس ٿيل ورجاءُ ٻيڻو ختم نه ڪيو ويندو ، ڇو ته سهائتا ڪرڻ قابل نه آهي.
    ///
    /// پري کان ڌار ٿيڻ لاءِ ، [`splitn`] طريقو استعمال ڪري سگھجي ٿو.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// سادو نمونو:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// وڌيڪ پيچيده نموني ، هڪ بند کي استعمال ڪندي:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// تار کي مختص ڪيل حد بندي جي پهرين واقعن تي ورهائي ٿو ۽ حد کان اڳ واري واپسي کي ختم ڪري ٿو ۽ حد کانپوءِ ختم ڪرڻ کان اڳ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// تار کي مختص ڪيل حد بندي جي آخري واقعن تي ورهائي ٿو ۽ حد کان اڳ واري واپسي کي ختم ڪري ٿو ۽ حد کانپوءِ ختم ڪرڻ کان اڳ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// ھڪڙي نموني جي ھڪڙي ترتيب جي منزلن تي ھڪڙي ھڪڙي ترتيب واري سلائس اندر اندر.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ارتقائي رويو
    ///
    /// واپس ٿيل ورجائي هڪ [`DoubleEndedIterator`] ٿيندو جيڪڏهن نمونو ريورس سرچ جي اجازت ڏئي ٿو ۽ forward/reverse ڳولا ساڳيو عناصر پيدا ڪري ٿي.
    /// اها سچ آهي ، مثال طور ، [`char`] لاءِ ، پر `&str` لاءِ نه.
    ///
    /// جيڪڏھن نمونہ ريورس سرچ جي اجازت ڏئي پر ان جا نتيجا اڳتي وڌڻ واري ڳولا کان مختلف ٿي سگھن ، [`rmatches`] طريقو استعمال ڪري سگھجي ٿو.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// هن تارنگ سلائس اندر هڪ نمونن جي ڌار ڌار ميچن تي هڪ ورجائي ، ريورس ترتيب ۾ پيدا ٿي.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ارتقائي رويو
    ///
    /// واپس ٿيل ايراضيٽر جي ضرورت آهي ته اهو نمونو هڪ ريورس ڳولڻ جي حمايت ڪري ٿو ، ۽ اهو هڪ [`DoubleEndedIterator`] ٿيندو جيڪڏهن هڪ forward/reverse ڳولا ساڳيو عناصر پيدا ڪري.
    ///
    ///
    /// مئٽرڪ کان ايندڙ دهرائڻ لاءِ ، [`matches`] طريقو استعمال ڪري سگھجي ٿو.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// هن تارنگ سلائس اندر هڪ نمونو ڌار ڌار ميچن تي ٻيهر ورجائي ٿو ۽ گڏوگڏ اهو انڊيڪس جيڪو ميچ شروع ٿئي ٿو.
    ///
    /// `self` اندر `pat` جي ميچن لاءِ جيڪي اوورلوپ ٿي چڪيون آهن ، صرف پهرين ميچ سان واسطو رکندڙ انڊس واپس ڪيون ويون آهن.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ارتقائي رويو
    ///
    /// واپس ٿيل ورجائي هڪ [`DoubleEndedIterator`] ٿيندو جيڪڏهن نمونو ريورس سرچ جي اجازت ڏئي ٿو ۽ forward/reverse ڳولا ساڳيو عناصر پيدا ڪري ٿي.
    /// اها سچ آهي ، مثال طور ، [`char`] لاءِ ، پر `&str` لاءِ نه.
    ///
    /// جيڪڏھن نمونہ ريورس سرچ جي اجازت ڏئي پر ان جا نتيجا اڳتي وڌڻ واري ڳولا کان مختلف ٿي سگھن ، [`rmatch_indices`] طريقو استعمال ڪري سگھجي ٿو.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // صرف پهرين `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// `self` اندر ھڪڙي نموني جي منزلن واري ميچز تي ھڪڙي مھرباني ، ميچ جي انڊيڪس سان گڏ ريورس ترتيب ۾ پيداوار.
    ///
    /// `self` اندر `pat` جي ميچن لاءِ جيڪي اوورلوپ ٿي وڃن ٿيون ، صرف آخري ميچ سان واسطو رکندڙ اشارا واپس ڪيون ويون آهن.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ارتقائي رويو
    ///
    /// واپس ٿيل ايراضيٽر جي ضرورت آهي ته اهو نمونو هڪ ريورس ڳولڻ جي حمايت ڪري ٿو ، ۽ اهو هڪ [`DoubleEndedIterator`] ٿيندو جيڪڏهن هڪ forward/reverse ڳولا ساڳيو عناصر پيدا ڪري.
    ///
    ///
    /// مئٽرڪ کان ايندڙ دهرائڻ لاءِ ، [`match_indices`] طريقو استعمال ڪري سگھجي ٿو.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // صرف آخري `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// هٽايو ويو ھڪڙي سليگ سلائس کي ھڪڙي طرف ھليو ويو آھي معروف ۽ ھڪڙي جڳھ واري خالي جڳھ کي.
    ///
    /// 'Whitespace' بيان ڪيو ويو آھي يونيڪوڊ ڪivedيل ڪور پراپرٽي `White_Space` جي شرطن جي مطابق.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// ھڪڙي وڏي جڳھ کي ختم ٿيل ھڪڙي جڳھ کي واپس ڏئي ٿو.
    ///
    /// 'Whitespace' بيان ڪيو ويو آھي يونيڪوڊ ڪivedيل ڪور پراپرٽي `White_Space` جي شرطن جي مطابق.
    ///
    /// # متن جي هدايت
    ///
    /// ھڪڙينگ بائٽس جي ھڪڙي تسلسل آھي.
    /// `start` انهي تناظر ۾ معنيٰ بائيٽ اسٽرنگ جي پهرين پوزيشن ؛انگريزي يا روسي وانگر کاٻي کان سا rightي ٻولي لاءِ ، اهو کاٻي طرف هوندو ۽ عربي يا عبراني وانگر دائي-کان-کاٻي ٻولين لاءِ ، اهو سا theي طرف هوندو.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// هٽيل واري اسپائيٽ کي ڪ trailڻ سان هڪ سلائيٽ سلائسون ڏياريندو آهي.
    ///
    /// 'Whitespace' بيان ڪيو ويو آھي يونيڪوڊ ڪivedيل ڪور پراپرٽي `White_Space` جي شرطن جي مطابق.
    ///
    /// # متن جي هدايت
    ///
    /// ھڪڙينگ بائٽس جي ھڪڙي تسلسل آھي.
    /// `end` انهي تناظر ۾ معنيٰ بائيٽ اسٽرنگ جي آخري پوزيشن ؛انگريزي يا روسي وانگر کاٻي کان سا rightي طرف ٻولي لاءِ ، هي سا rightي طرف هوندو ۽ عربي يا عبراني وانگر دائي کان کاٻي طرف وارن ٻولين لاءِ ، اهو کاٻي طرف هوندو.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// ھڪڙي وڏي جڳھ کي ختم ٿيل ھڪڙي جڳھ کي واپس ڏئي ٿو.
    ///
    /// 'Whitespace' بيان ڪيو ويو آھي يونيڪوڊ ڪivedيل ڪور پراپرٽي `White_Space` جي شرطن جي مطابق.
    ///
    /// # متن جي هدايت
    ///
    /// ھڪڙينگ بائٽس جي ھڪڙي تسلسل آھي.
    /// 'Left' انهي تناظر ۾ معنيٰ بائيٽ اسٽرنگ جي پهرين پوزيشن ؛عربي يا عبرانيءَ لاءِ اهڙي ٻولي لاءِ ، جيڪي `کاٻي کان سا'ي طرف` بدران `کاٻي کان سا rightي طرف` بدران `هي کاٻي کان سا notي طرف واري پاسي ڏانهن وڃي ٿي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// هٽيل واري اسپائيٽ کي ڪ trailڻ سان هڪ سلائيٽ سلائسون ڏياريندو آهي.
    ///
    /// 'Whitespace' بيان ڪيو ويو آھي يونيڪوڊ ڪivedيل ڪور پراپرٽي `White_Space` جي شرطن جي مطابق.
    ///
    /// # متن جي هدايت
    ///
    /// ھڪڙينگ بائٽس جي ھڪڙي تسلسل آھي.
    /// 'Right' انهي تناظر ۾ معنيٰ بائيٽ اسٽرنگ جي آخري پوزيشن ؛عربي يا عبرانيءَ لاءِ اهڙي ٻولي لاءِ ، جيڪا `کاٻي کان سا'ي طرف` بدران `کاٻي کان سا thanي طرف` بدران `هي سا leftي طرف واري طرف آهي ، نه صحيح آهي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// تمام پريڪس ۽ اسفڪس سان گڏ هڪ اسٽرنگ سلائس کي واپس ڏئي ٿو جيڪا بار بار هٽائڻ واري نموني سان ملي ٿي.
    ///
    /// [pattern] ھڪڙو [`char`] ٿي سگھي ٿو ، ["چار"] جو ھڪڙو حصو ، يا ھڪڙي فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته جيڪڏھن ھڪڙو ڪردار ملائي ٿو.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// سادو نمونو:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// وڌيڪ پيچيده نموني ، هڪ بند کي استعمال ڪندي:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // سڀ کان پهرين matchاتل سڃاتل ميچ ، ياد ڪريو انهي کي هيٺ درست ڪريو
            // آخري ميچ مختلف آهي
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // حفاظت: `Searcher` صحيح انڊيڪس واپس ڪرڻ لاءِ سڃاتو وڃي ٿو.
        unsafe { self.get_unchecked(i..j) }
    }

    /// تمام پريڪس سان هڪ اسٽرنگ سلائي ڪ Returnي ٿو جيڪا بار بار هٽائڻ واري نموني سان ملي ويندي آهي.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # متن جي هدايت
    ///
    /// ھڪڙينگ بائٽس جي ھڪڙي تسلسل آھي.
    /// `start` انهي تناظر ۾ معنيٰ بائيٽ اسٽرنگ جي پهرين پوزيشن ؛انگريزي يا روسي وانگر کاٻي کان سا rightي ٻولي لاءِ ، اهو کاٻي طرف هوندو ۽ عربي يا عبراني وانگر دائي-کان-کاٻي ٻولين لاءِ ، اهو سا theي طرف هوندو.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // حفاظت: `Searcher` صحيح انڊيڪس واپس ڪرڻ لاءِ سڃاتو وڃي ٿو.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// پريڪس کي ختم ٿيل ھڪڙي اسٽرنگ سلائس کي واپس آڻيندي.
    ///
    /// جيڪڏهن تار `prefix` واري نموني سان شروع ٿئي ٿي ، اڳڪس کي سبٽرنگ موٽائي ٿو ، `Some` ۾ لپي ويو.
    /// `trim_start_matches` جي برعڪس ، ھي طريقو ھڪڙو ئي اڳين کي ختم ڪري ٿو.
    ///
    /// جيڪڏهن تار `prefix` سان شروع نه ٿئي ، `None` موٽائي ٿو.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// ھڪڙي اسٽار ڪليس کي ختم ڪري ٿو واپس ڪ withي ٿو.
    ///
    /// جيڪڏهن تار `suffix` واري نموني سان ختم ٿي وڃي ، ختم ٿيڻ کان پهريان سبسٽنگ کي واپس ڪري ٿو ، `Some` ۾ ويڙهيل.
    /// `trim_end_matches` جي برعڪس ، اهو طريقو هڪ ڀيرو ئي لاڪس کي ختم ڪري ٿو.
    ///
    /// جيڪڏهن تار `suffix` سان ختم نٿي ٿئي ، `None` موٽائي ٿو.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// تمام گھِڻلين سان سٽرنگ سلائس کي واپس آڻيندي آھي جيڪا بار بار ختم ٿيل نموني سان ملي.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # متن جي هدايت
    ///
    /// ھڪڙينگ بائٽس جي ھڪڙي تسلسل آھي.
    /// `end` انهي تناظر ۾ معنيٰ بائيٽ اسٽرنگ جي آخري پوزيشن ؛انگريزي يا روسي وانگر کاٻي کان سا rightي طرف ٻولي لاءِ ، هي سا rightي طرف هوندو ۽ عربي يا عبراني وانگر دائي کان کاٻي طرف وارن ٻولين لاءِ ، اهو کاٻي طرف هوندو.
    ///
    ///
    /// # Examples
    ///
    /// سادو نمونو:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// وڌيڪ پيچيده نموني ، هڪ بند کي استعمال ڪندي:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // حفاظت: `Searcher` صحيح انڊيڪس واپس ڪرڻ لاءِ سڃاتو وڃي ٿو.
        unsafe { self.get_unchecked(0..j) }
    }

    /// تمام پريڪس سان هڪ اسٽرنگ سلائي ڪ Returnي ٿو جيڪا بار بار هٽائڻ واري نموني سان ملي ويندي آهي.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # متن جي هدايت
    ///
    /// ھڪڙينگ بائٽس جي ھڪڙي تسلسل آھي.
    /// 'Left' انهي تناظر ۾ معنيٰ بائيٽ اسٽرنگ جي پهرين پوزيشن ؛عربي يا عبرانيءَ لاءِ اهڙي ٻولي لاءِ ، جيڪي `کاٻي کان سا'ي طرف` بدران `کاٻي کان سا rightي طرف` بدران `هي کاٻي کان سا notي طرف واري پاسي ڏانهن وڃي ٿي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// تمام گھِڻلين سان سٽرنگ سلائس کي واپس آڻيندي آھي جيڪا بار بار ختم ٿيل نموني سان ملي.
    ///
    /// [pattern] ھڪڙو `&str` ، [`char`] ، ھڪڙو ڪري سگھي ٿو ["چار"] ، يا ھڪڙو فنڪشن يا بندش اھو اھو طئي ڪري ٿو ته ھڪڙو ڪردار جڏھن ملي ٿو.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # متن جي هدايت
    ///
    /// ھڪڙينگ بائٽس جي ھڪڙي تسلسل آھي.
    /// 'Right' انهي تناظر ۾ معنيٰ بائيٽ اسٽرنگ جي آخري پوزيشن ؛عربي يا عبرانيءَ لاءِ اهڙي ٻولي لاءِ ، جيڪا `کاٻي کان سا'ي طرف` بدران `کاٻي کان سا thanي طرف` بدران `هي سا leftي طرف واري طرف آهي ، نه صحيح آهي.
    ///
    ///
    /// # Examples
    ///
    /// سادو نمونو:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// وڌيڪ پيچيده نموني ، هڪ بند کي استعمال ڪندي:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// ھن تار کي سلائي کي ٻي قسم ۾ تبديل ڪري ڇڏيو آھي.
    ///
    /// ڇاڪاڻ ته `parse` ايترو عام آهي ، اهو قسم جي تعينات سان مسئلو پيدا ڪري سگهي ٿو.
    /// جيئن ته ، `parse` ڪجھه ڀيرا آهي جيڪو توهان ان سان گڏ نحو کي ڏسي سگھوٿا 'turbofish' طور سڃاتو وڃي ٿو. `::<>`.
    ///
    /// اهو مدد وٺندڙ الورگيتم کي سمجھڻ ۾ مدد ڪندو خاص طور تي توهان ڪهڙي قسم کي ترتيب ڏيڻ جي ڪوشش ڪري رهيا آهيو.
    ///
    /// `parse` ڪنهن به قسم ۾ تفصيل ڏئي سگهجي ٿو جيڪا [`FromStr`] trait کي لاڳو ڪري ٿي.
    ///

    /// # Errors
    ///
    /// ايڪس آرڪس کي واپس آڻيندو جيڪڏھن اھو ممڪن نہ ھجي ته ھن تارنگ سلائس کي مطلوبہ قسم ۾ پار ڪيو وڃي.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// ايڪسڪسيمڪس استعمال ڪرڻ جي بدران 'turbofish' استعمال ڪندي:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// تفصيل ڏيڻ ۾ ناڪام
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// چيڪ ڪريو جيڪڏهن هن قطب جا سڀ ڪردار ASCII جي حد ۾ آهن.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // اسان هر بائيٽ کي ڪردار جي حيثيت سان هتي علاج ڪري سگهون ٿا: سڀئي گھڻائي واريون اکر هڪ بائيٽ سان شروع ٿيون جيڪي اسيسي حد ۾ نه آهن ، تنهن ڪري اسان اتي ئي روڪي ڇڏينداسين.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// چيڪ ڪري ٿو ته ٻه تارا هڪ ASCII ڪيس جي بيزاري واري مقابلي ۾ آهن.
    ///
    /// ساڳي طرح `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ، پر عارضي طور تي مختص ڪرڻ ۽ ڪاپي ڪرڻ کان سواء.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// انهي واري اسٽرنگ کي ان جي ASCII اپر ڪيس جي برابر جڳهه ۾ تبديل ڪري ٿو.
    ///
    /// ASCII خط 'a' کان 'z' 'A' کان 'Z' ڏانهن نقشه ڏنل آهن ، پر غير ASCII خط بدلايو نٿا وڃن.
    ///
    /// موجوده ۾ ھڪڙي کي بغير تبديل ڪرڻ جي لاءِ ھڪڙي جديد نقدي قيمت ڏانھن واپس ڪرڻ لاءِ ، [`to_ascii_uppercase()`] استعمال ڪريو.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // حفاظت: محفوظ آهي ڇاڪاڻ ته اسان ٻن قسمن کي ساڳئي ترتيب سان منتقل ڪريون ٿا.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// ان جي اسٽرنگ کي ان جي اي ايس سي آئي آئي نن lowerي صورت ۾ برابر واري هنڌ ۾ تبديل ڪري ٿو.
    ///
    /// ASCII خط 'A' کان 'Z' 'a' کان 'z' ڏانهن نقشه ڏنل آهن ، پر غير ASCII خط بدلايو نٿا وڃن.
    ///
    /// موجوده ۾ ھڪڙي کي تبديل ڪرڻ کانسواءِ ھڪڙي نئون گھٽ قيمت کي واپس ڪرڻ لاءِ ، [`to_ascii_lowercase()`] استعمال ڪريو.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // حفاظت: محفوظ آهي ڇاڪاڻ ته اسان ٻن قسمن کي ساڳئي ترتيب سان منتقل ڪريون ٿا.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// هڪ ايريرٽر واپس ڪ thatو جيڪو X50X سان X50X ۾ هر چار ڪري فرار ٿئي ٿو.
    ///
    ///
    /// Note: صرف وڌايل گرافم ڪوڊ لائنون جيڪي تارن کي شروع ڪن ٿا اهي ڀ willي وينديون.
    ///
    /// # Examples
    ///
    /// هڪ ويڙهاڪ جي طور تي:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// سڌو `println!` استعمال ڪندي:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// ٻئي برابر آهن:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// `to_string` استعمال ڪندي:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// هڪ ايريرٽر واپس ڪ thatو جيڪو X50X سان X50X ۾ هر چار ڪري فرار ٿئي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// هڪ ويڙهاڪ جي طور تي:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// سڌو `println!` استعمال ڪندي:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// ٻئي برابر آهن:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// `to_string` استعمال ڪندي:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// هڪ ايريرٽر واپس ڪ thatو جيڪو X50X سان X50X ۾ هر چار ڪري فرار ٿئي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// هڪ ويڙهاڪ جي طور تي:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// سڌو `println!` استعمال ڪندي:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// ٻئي برابر آهن:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// `to_string` استعمال ڪندي:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// خالي اسٽيٽ ٺاهي ٿو
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// هڪ خالي ableيرائيلي اسٽر ٺاهي ٿو
    #[inline]
    fn default() -> Self {
        // حفاظت: خالي اسٽرنگ UTF-8 صحيح آهي.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// هڪ نالي وارو ، ڪلونائي فائي قسم
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // محفوظ: محفوظ نه آهي
        unsafe { from_utf8_unchecked(bytes) }
    };
}