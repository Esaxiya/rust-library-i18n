//! اسٽرنگ پيٽرن API.
//!
//! پيٽرن API هڪ تار ذريعي ڳولا دوران مختلف نمونن جي قسمن کي استعمال ڪرڻ جي لاءِ عمومي ميڪانيزم مهيا ڪندو آهي.
//!
//! وڌيڪ تفصيل لاءِ ڏسو ڏسو traits [`Pattern`] ، [`Searcher`] ، [`ReverseSearcher`] ، ۽ [`DoubleEndedSearcher`].
//!
//! جيتوڻيڪ هي اي پي آئي غير مستحڪم آهي ، اها ايڪس ويڪس قسم تي مستحڪم APIن ذريعي سامهون اچي ٿي.
//!
//! # Examples
//!
//! [`Pattern`] آھي [implemented][pattern-impls] مستحڪم API ۾ [`&str`][`str`] ، [`char`] ، [`char`] جي سليس ، ۽ `FnMut(char) -> bool` تي عمل درآمد ۽ بندش.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // چار جو نمونو
//! assert_eq!(s.find('n'), Some(2));
//! // ڪردارن جي ٽڪڙي
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // بند ڪرڻ جو نمونو
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// ھڪڙي تار جو نمونو.
///
/// هڪ `Pattern<'a>` ظاهر ڪري ٿو ته ايڪسنگ ايڪس جي ڳولا ۾ عملدرآمد واري قسم کي تار تار نموني طور استعمال ڪري سگهجي ٿو.
///
/// مثال طور ، ٻئي `'a'` ۽ `"aa"` نمونا آهن جيڪي انڊيڪس `1` کي اسٽرنگ `"baaaab"` ۾ ملندا.
///
/// trait پاڻ لاڳاپيل [`Searcher`] قسم جي بلڊر طور ڪم ڪري ٿو ، جيڪي ھڪڙي تارنگ ۾ نموني جي واقعن کي ڳولڻ جو اصل ڪم ڪن ٿا.
///
///
/// نموني جي قسم تي منحصر ڪري ٿو ، [`str::find`] ۽ [`str::contains`] وانگر طريقن جي رويي تبديل ڪري سگھن ٿا.
/// هيٺ ڏنل جدول انهن مان ڪجھ رويي کي بيان ڪيو.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// ھن نموني لاءِ انجمن ڳوليندڙ
    type Searcher: Searcher<'a>;

    /// `self` ۽ `haystack` کان جڙيل ڳولا ڪندڙ کي تعمير ڪري ٿو ڳولا ۾.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// چيڪ ڪريو ته ڇا نمونن هاکي ۾ ڪٿي به ملائي ٿو
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// چيڪ ڪريو ته ڇا نمونن کي هاکي جي اڳئين پاسي سان ملي ٿو
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// چيڪ ڪريو ته ڇا نموني کي هاکي جي پوئين پاسي ملائي ٿو
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// هٽ ڀرڻ جي پوئين حصي کان نموني ڪي ٿو ، جيڪڏهن اها لهي ٿي.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // حفاظت: `Searcher` صحيح انڊيڪس واپس ڪرڻ لاءِ سڃاتو وڃي ٿو.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// هٽ backير جي پوئين طرف کان نمونو ڪي ٿو ، جيڪڏهن انهي کي ملائي.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // حفاظت: `Searcher` صحيح انڊيڪس واپس ڪرڻ لاءِ سڃاتو وڃي ٿو.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] يا [`ReverseSearcher::next_back()`] کي سڏڻ جو نتيجو.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// ايڪسپريس ۾ ايڪسپورٽ ملايو ويو آهي ميچ جو نمونو.
    ///
    Match(usize, usize),
    /// ايڪسپريس جو ممڪن نموني رد ڪيو ويو ظاهر ڪري ٿو ظاهر ڪري ٿو.
    ///
    /// ياد رکو ته ٻن ميچين جي وچ ۾ هڪ کان وڌيڪ `Reject` ٿي سگهن ٿا ، انهن لاءِ هڪ ۾ گڏجاڻي جي ڪا ضرورت ناهي.
    ///
    ///
    Reject(usize, usize),
    /// ظاهر ڪري ٿو ته هائي ٽيڪ جو هر بائٽ دورو ڪيو ويو آهي ، اهو ورجاءُ ختم ٿي ويو.
    ///
    Done,
}

/// تار جي نموني لاءِ ڳولا ڪندڙ.
///
/// هي trait هڪ تار جي اڳئين (left) کان شروع ٿيندڙ نموني جي غير اوورلوپنگ مماثل جي ڳولا لاءِ طريقا مهيا ڪندو آهي.
///
/// انهي کي [`Pattern`] trait سان لاڳاپيل `Searcher` قسمن پاران لاڳو ڪيو ويندو.
///
/// trait غير محفوظ ٿيل نشان لڳايو ويو آهي ڇاڪاڻ ته [`next()`][Searcher::next] طريقن سان واپس ڪيل انڊيڪس هيڪ اسٽيڪ ۾ صحيح utf8 حدن تي ڪوڙ ڳالهائڻ گهرجن.
/// انهي trait کي استعمال ڪرڻ وارن ماڻهن کي بنا بغير هلنگ جي اضافي چيڪ هاسس کي سلائي ڪرڻ جي قابل بنايو.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter ھيٺ ڏنل تار لاءِ ڳولھيو وڃي
    ///
    /// هميشه ساڳيو [`&str`][str] موٽي وٺندو.
    fn haystack(&self) -> &'a str;

    /// اڳيون شروع کان ايندڙ تلاش وارو قدم انجام ڏئي ٿو.
    ///
    /// - جيڪڏهن `haystack[a..b]` موٽ ڀريو وڃي ته [`Match(a, b)`][SearchStep::Match] واپس اچي ٿو.
    /// - ايڪس ايڪس کي واپسي ڏي ٿو جيڪڏهن `haystack[a..b]` نموني سان مطابقت نه ٿو رکي سگھي ، جزوي طور تي به.
    /// - [`Done`][SearchStep::Done] جي واپسي ڏئي ٿو جيڪڏهن هائيڪ جي هر بائيٽ جو دورو ڪيو ويو هجي.
    ///
    /// [`Match`][SearchStep::Match] ۽ [`Reject`][SearchStep::Reject] قدرن جو وهڪرو هڪ [`Done`][SearchStep::Done] تائين انڊيڪس سلسلن تي مشتمل هوندو جيڪي ڀرپاسي وارا آهن ، غير نقاب پذير آهن ، س hي خشڪي کي coveringڪيندا آهن ، ۽ utf8 جي حدن تي رکندا آهن.
    ///
    ///
    /// هڪ [`Match`][SearchStep::Match] نتيجو سڀني ميلاپ واري نموني تي مشتمل هجڻ جي ضرورت آهي ، جڏهن ته [`Reject`][SearchStep::Reject] نتيجو ڪيترن ئي ويجهي حصن ۾ ثالثن ۾ ورهائي سگهجي ٿي.ٻنهي حدن ۾ صفر ڊگھائي ٿي سگھي ٿي.
    ///
    /// هڪ مثال طور ، نموني `"aaa"` ۽ هاڪسڪ `"cbaaaaab"` وهڪرو پيدا ڪري سگھن ٿيون
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// ايندڙ [`Match`][SearchStep::Match] نتيجو ڳوليو.[`next()`][Searcher::next] ڏسو.
    ///
    /// [`next()`][Searcher::next] جي نسبت ، ڪا گارنٽي ناھي ته ھن جي واپسي جون حدون ۽ [`next_reject`][Searcher::next_reject] اوپليپ ٿي وينديون.
    /// هي ايڪس سي ايم ايڪس کي واپسي ڪندو ، جتي شروعاتي_ ميچ ميچ جي شروعات واري انڊيڪس آهي جتي ميچ شروع ٿئي ٿي ، ۽ آخر_ ميچ ميچ جي ختم ٿيڻ بعد انڊيڪس آهي.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// ايندڙ [`Reject`][SearchStep::Reject] نتيجو ڳوليو.ڏسو [`next()`][Searcher::next] ۽ [`next_match()`][Searcher::next_match].
    ///
    /// [`next()`][Searcher::next] جي نسبت ، ڪا گارنٽي ناھي ته ھن جي واپسي جون حدون ۽ [`next_match`][Searcher::next_match] اوپليپ ٿي وينديون.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// ھڪڙي اسٽرنگ جي نموني لاءِ ھڪڙي ريورس ڳوليندڙ.
///
/// هي trait هڪ تار جي پوئين (right) کان شروع ٿيندڙ نموني جي غير اوپلوپنگ ميچ ڳولڻ جي طريقن مهيا ڪندو آهي.
///
/// اهو [`Pattern`] trait سان لاڳاپيل [`Searcher`] قسمن پاران لاڳو ڪيو ويندو جيڪڏهن نمونو انهي کان پٺي ڳولي ٿو.
///
///
/// ھي trait پاران واپس ڪيل انڊيڪس جون حدون ريورس ۾ اڳيان واري تلاش جي وارن کي بلڪل ملائڻ جي ضرورت ناھي.
///
/// اهو سبب ڇو ته هن trait کي غير محفوظ نشان لڳل آهي ، انهن کي ڏسو والدين trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// پوئتي کان شروع ٿيندڙ ايندڙ ڳولا وارو عمل انجام ڏئي ٿو.
    ///
    /// - جيڪڏهن `haystack[a..b]` موٽ ڀريو وڃي ته [`Match(a, b)`][SearchStep::Match] واپس اچي ٿو.
    /// - [`Reject(a, b)`][SearchStep::Reject] واپس ڏئي ٿو جيڪڏھن `haystack[a..b]` نموني سان مطابقت نه رکي سگھي ، جزوي طور تي پڻ.
    /// - [`Done`][SearchStep::Done] جي واپسي ڏئي ٿو جيڪڏهن هائيڪ جي هر بائيٽ جو دورو ڪيو ويو هجي
    ///
    /// [`Match`][SearchStep::Match] ۽ [`Reject`][SearchStep::Reject] قدرن جو وهڪرو هڪ [`Done`][SearchStep::Done] تائين انڊيڪس سلسلن تي مشتمل هوندو جيڪي ڀرپاسي وارا آهن ، غير نقاب پذير آهن ، س hي خشڪي کي coveringڪيندا آهن ، ۽ utf8 جي حدن تي رکندا آهن.
    ///
    ///
    /// هڪ [`Match`][SearchStep::Match] نتيجو سڀني ميلاپ واري نموني تي مشتمل هجڻ جي ضرورت آهي ، جڏهن ته [`Reject`][SearchStep::Reject] نتيجو ڪيترن ئي ويجهي حصن ۾ ثالثن ۾ ورهائي سگهجي ٿي.ٻنهي حدن ۾ صفر ڊگھائي ٿي سگھي ٿي.
    ///
    /// مثال طور ، نموني `"aaa"` ۽ هاکي اسٽيڪس `"cbaaaaab"` شايد وهڪرو `[Reject(7, 8) ، Match(4, 7) ، Reject(1, 4) ٺاهي سگھن ٿيون. Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// ايندڙ [`Match`][SearchStep::Match] نتيجو ڳوليو.
    /// [`next_back()`][ReverseSearcher::next_back] ڏسو.
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// ايندڙ [`Reject`][SearchStep::Reject] نتيجو ڳوليو.
    /// [`next_back()`][ReverseSearcher::next_back] ڏسو.
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// هڪ نشانڪار trait ظاهر ڪرڻ جي لاءِ ايڪسڪسيمڪس [`DoubleEndedIterator`] جي عمل لاءِ استعمال ڪري سگهجي ٿو.
///
/// انهي لاء ، [`Searcher`] ۽ [`ReverseSearcher`] جو نقشو انهن شرطن تي عمل ڪرڻ جي ضرورت آهي.
///
/// - `next()` جي سڀني نتيجن کي ريورس ترتيب ۾ `next_back()` جي نتيجن جي برابر هجڻ جي ضرورت آهي.
/// - `next()` ۽ `next_back()` ھڪڙي حد تائين قدر جي ٻن پڇاڙيون وانگر ھجڻ جي ضرورت آھي ، اھو آھي اھي "walk past each other" نٿا ڪري سگھن.
///
/// # Examples
///
/// `char::Searcher` هڪ `DoubleEndedSearcher` آهي ڇاڪاڻ ته هڪ [`char`] جي ڳولا هڪ وقت ۾ هڪ ئي وقت ڏسڻ جي ضرورت آهي ، جيڪو ٻنهي سرن کان هڪ جهڙو سلوڪ ڪري ٿو.
///
/// `(&str)::Searcher` هڪ `DoubleEndedSearcher` نه آهي ڇاڪاڻ ته هاٽ اسٽيڪ `"aaa"` ۾ `"aa"` وارو نمونو ٻئي نمبر تي `"[aa]a"` يا `"a[aa]"` سان ملندو آهي ، ان جي لحاظ کان انهي طرف کان ڳولا ڪئي وئي آهي.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// چارپ لاءِ امپيل
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher` لاءِ لاڳاپيل قسم
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // حفاظت انوائيوانٽ: `finger`/`finger_back` `haystack` جو صحيح utf8 بائيٽ انڊيڪس هجڻ لازمي آهي ٻي ٺاهيل * Next_match ۽ next_match_back اندر ٽوڙي سگھجي ٿو ، جڏهن ته انهن کي صحيح ڪوڊ پوائنٽ جي حدن تي آ fingersريون کڻي ٻاهر نڪرڻ گهرجن.
    //
    //
    /// `finger` اڳيان ڳولا جي موجوده بائيٽ انڊيڪس آهي.
    /// تصور ڪيو ته اهو موجود آهي بائيٽ کان پهريان ان جي انڊيڪس تي ، يعني
    /// `haystack[finger]` سليس جو پهريون بائيٽ آهي اسان کي اڳيان ڳولا دوران جاچڻ گهرجي
    ///
    finger: usize,
    /// `finger_back` ريورس سرچ جو موجوده بائيٽ انڊيڪس آهي.
    /// تصور ڪيو ته اهو موجود آهي بائيٽ کان پوءِ ان جي انڊيڪس ۾
    /// هسٽ اسٽيڪ [آ_ر_يٺ ، 1] ٻلي جو آخري بائيٽ آهي جيڪو اسان کي اڳيان ڳولا جي دوران معائنو ڪرڻ گهرجي (۽ اهڙي طرح next_back()) کي سڏڻ وقت پهريون بائيٽ جو معائنو ڪيو وڃي.
    ///
    finger_back: usize,
    /// ڪردار ڳولهيو پيو وڃي
    needle: char,

    // حفاظت وارو ڪمرائيندڙ: `utf8_size` کي 5 کان گهٽ هجڻ گهرجي
    /// بائيٽس `needle` جو تعداد مٿي وٺي ٿو جڏهن utf8 ۾ انڪوڊ ڪيو ويو آهي.
    utf8_size: usize,
    /// `needle` جي هڪ utf8 انڪوڊ ٿيل ڪاپي
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // حفاظت: 1-4 `get_unchecked` جي حفاظت جي ضمانت
        // 1. `self.finger` ۽ `self.finger_back` يونيڪوڊ حدن تي رکيل آهن (اهو هلندڙ آهي)
        // 2. `self.finger >= 0` جتان اهو شروع ٿئي ٿو 0 تي ۽ صرف وڌندو آهي
        // 3. `self.finger < self.finger_back` ڇاڪاڻ ته ٻي صورت ۾ چارا `iter` `SearchStep::Done` واپس ڪندو
        // 4.
        // `self.finger` هاکي جي ختم ٿيڻ کان اڳ اچي ٿو ڇو ته `self.finger_back` آخر ۾ شروع ٿئي ٿو ۽ فقط گهٽجي وڃي ٿو
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // utf-8 کي ٻيهر انڪوڊنگ ڪرڻ کانسواءِ موجوده ڪردار جي بائيٽ آف سيٽ شامل ڪريو
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // آخري ڪردار مليو کان پوءِ هن stاٽڻ حاصل ڪيو
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 انڪوڊ ٿيل انجڻ واري حفاظت جي آخري بائيٽ: اسان وٽ هڪ انوڪار آهي ته `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // نئين آ fingerريون بائيٽ جو انڊيڪس آهي جيڪو اسان مليو آهي ، انهي سان گڏ هڪ ، ڇاڪاڻ ته اسين ڪردار جي آخري بائيٽ کي ياد ڪندا آهيون.
                //
                // ياد رکو ته هي اسان کي هميشه UTF8 جي حد تي آ aر نٿو ڏئي.
                // جيڪڏهن اسان *نه* پنهنجو ڪردار ڳوليو اسان شايد 3 بائيٽ يا 4 بائيٽ جي نان-آخري بائيٽ ڏانهن اشارو ڪيو.
                // اسان صرف ايندڙ صحيح بائيٽ ڏانهن وڃڻ جي توفيق نه ٿا ڪري سگهون ڇاڪاڻ ته هڪ ڪردار ꁁ (U + A041 YI SYLLABLE PA) ، utf-8 `EA 81 81` هميشه اسان کي ٻي بائيٽ ڳولي جڏهن اسان ٽئين کي ڳولي سگهنداسين.
                //
                //
                // بهرحال ، اهو مڪمل طور تي ٺيڪ آهي.
                // جڏهن ته اسان وٽ تغير آهي ته self.finger هڪ UTF8 حد تي آهي ، ان سموري جغرافيه هن طريقي تي انحصار نه ڪيو ويو آهي (اهو CharSearcher::next()) تي ڀروسو ڪيو ويو آهي).
                //
                // اسان صرف اهو طريقو ختم ڪريون ٿا جڏهن اسين تار جي پڇاڙي تي پهچي ، يا جيڪڏهن اسان ڪجهه ڳوليندا.جڏهن اسان ڪجهه ڳوليندا آهيون ايڪس ايڪس ايڪس هڪ حد UTF8 تي مقرر ڪيو ويندو.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ڪجھ نه مليو ، ٻاھر نڪتو
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // اڳيون_reject ڳوليندڙ trait مان ڊفالٽ پليپشن استعمال ڪريو
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // حفاظت: مٿي Xاڻايل آهي next() لاءِ تبصرو
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // utf-8 کي ٻيهر انڪوڊنگ ڪرڻ کانسواءِ موجوده ڪردار جي بائيٽ آف سيٽ کي ڪٽ ڪريو
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // stاڻ کي ڇڪڻ حاصل ڪريو پر آخري ڪردار شامل نه آهي ڳولا ڪئي
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 انڪوڊ ٿيل انجڻ واري حفاظت جي آخري بائيٽ: اسان وٽ هڪ انوڪار آهي ته `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // اسان هڪ سليس ڳولهيو جنهن کي self.finger پاران آفسيٽ ڪيو ويو هو ، ايڪس انڊيڪس شامل ڪيو ته اصلي انڊيڪس بحال لاءِ
                //
                let index = self.finger + index;
                // ميمر اسان بائيٽ جو انڊيڪس واپس آڻيندا جيڪا اسان ڳولڻ چاهيندا.
                // اي ايس سي آئي آئي ڪردار جي صورت ۾ ، هي واقعي اسان جي خواهش هئي اسان جي نئين آ fingerر ٿيڻ جي (ايڪس ري ايڪس ري کي ريٽيلشن جي تمثيل ۾ مليل چار).
                //
                // multibyte chars لاءِ اسان کي ASSII کان وڌيڪ بائٽس جي تعداد کي ڇڏي ڏيڻ جي ضرورت آهي
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // ملندڙ ڪردار کان پهريان آ fingerر ڏانهن منتقل ڪريو (يعني ، ان جي شروعاتي انڊيڪس تي)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // اسان هتي آ fingerر_ بيڪ=انڊيڪس ، سائيز + 1 استعمال نٿا ڪري سگھون.
                // جيڪڏھن اسان مختلف سائز واري ڪردار جي آخري چار کي ملي چڪا آھيون (يا ھڪ مختلف ڪردار جي وچ واري بائيٽ) اسان کي `index` ڏانھن فنگر_ بيڪ کي ٽوڙڻ جي ضرورت آھي.
                // اهو ساڳي طرح `finger_back` ٺاهه ڪرڻ جي صلاحيت رکي ٿو وڌيڪ حد تي نه ، پر اهو ٺيڪ آهي ڇاڪاڻ ته اسان صرف هن فنڪشن کي چائونڊري تي نڪرو ٿا يا جڏهن گيٽ کي مڪمل طور تي ڳولي ورتو ويو آهي.
                //
                //
                // next_match جي برعڪس ھن کي utf-8 ۾ بار بار بٽس جو مسئلو ناھي ڇاڪاڻ ته اسان آخري بائيٽ کي ڳولي رھيا آھيون ، ۽ اسين صرف آخري بائيٽ ڳولي سگھياسين جڏھن ريورس ۾ تلاش ڪندا.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ڪجھ نه مليو ، ٻاھر نڪتو
                return None;
            }
        }
    }

    // اگلا_reject_back ڳوليندڙ trait مان ڊفالٽ پليپشن استعمال ڪريو
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// ڪردارن جي ڳولا آهي جيڪا هڪ ڏنل [`char`] جي برابر آهن.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// MultiCharEq لفافي لاءِ امپيل
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // موجوده بٽ جي ڊيگهه ڳولڻ لاءِ اندروني بائيٽ سلائس ايريٽر جي ڊيگهه جو موازنہ ڪيو
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // موجوده بٽ جي ڊيگهه ڳولڻ لاءِ اندروني بائيٽ سلائس ايريٽر جي ڊيگهه جو موازنہ ڪيو
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl&[char] لاءِ
/////////////////////////////////////////////////////////////////////////////

// Todo: معنى ۾ مونجهاري جو سبب تبديل/هٽايو.

/// `<&[char] as Pattern<'a>>::Searcher` لاءِ لاڳاپيل قسم
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// چارس جي ڳولا آھي جيڪي سليس ۾ ڪنھن [`چار`] جي برابر آھن.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl for F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher` لاءِ لاڳاپيل قسم
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// ["چار"] جي ڳولا ڪندو آهي جيڪا ڏنل predicate سان ملي.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &amp. str
/////////////////////////////////////////////////////////////////////////////

/// `&str` امپ تي وفد.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// &str لاء اثر ڏيو
/////////////////////////////////////////////////////////////////////////////

/// غير مختص ڪيل سبسٽرنگ ڳولا.
///
/// سنڀاليندو ايڪس آر ايڪس کي هر ڪردار جي حد تي خالي ميچون موٽڻ وانگر.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// چيڪ ڪريو ته ڇا نمونن کي هاکي جي اڳئين پاسي سان ملي ٿو.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// هٽ ڀرڻ جي پوئين حصي کان نموني ڪي ٿو ، جيڪڏهن اها لهي ٿي.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // حفاظت: اڳرائي جي موجود هجڻ جي تصديق ڪئي وئي هئي.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// چيڪ ڪريو ته ڇا نموني کي هاکي جي پوئين پاسي ملائي ٿو.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// هٽ backير جي پوئين طرف کان نمونو ڪي ٿو ، جيڪڏهن انهي کي ملائي.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // حفاظت: لفافي صرف موجود هجڻ جي تصديق ڪئي وئي هئي.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// ٻه رستو ڳولڻ وارو ڳوليندڙ
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher` لاءِ لاڳاپيل قسم
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // خالي انجڻ هر چار کي رد ڪري ٿي ۽ انهن جي وچ واري هر خالي تار کي ملائي ٿي
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher صحيح پيدا ڪندو آهي *ميچ* انڊيڪس جيڪي چار جي حدن ۾ ورهايل آهن انهي وقت تائين جڏهن اهي درست ملائڻ ۽ هي هاڪ ۽ سائل صحيح آهن UTF-8 *رد* الگورتم مان ڪنهن انڊيڪس تي گر ٿي سگهن ٿا ، پر اسان انهن کي دستياب طور تي ايندڙ ڪردار جي حد تائين هلائينداسين ، انهي ڪري اهي اهي utf-8 محفوظ آهن.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // ايندڙ چار چوديواري تي وڃو
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `true` ۽ `false` ڪيس لکو compiler کي حوصلہ افزائي ڪرڻ لاءِ ٻنهي ڪيسن کي الڳ الڳ ماهر ڪرڻ جو.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // ايندڙ چار چوديواري تي وڃو
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `true` ۽ `false` وانگر ، `next_match` وانگر لکو
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// ٻن طرفن جي تلاش جي الگورتھم جي اندروني حالت.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// تنقيدي فڪر واري اشاري
    crit_pos: usize,
    /// الٽندڙ سوئي لاءِ نازڪ فيڪٽريزيشن انڊيڪس
    crit_pos_back: usize,
    period: usize,
    /// `byteset` هڪ واڌ آهي (ٻن طرفن جي الگورتھم جو حصو نه آهي)
    /// اهو هڪ 64-bit "fingerprint" آهي جتي هر سيٽ بيٽ `j` هڪ (بائيٽ ۽ 63)==ج ان سوئي ۾ موجود آهي.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// سوئي انڊيڪس ۾ جنهن کي اڳي اسين ملائي چڪا آهيون
    memory: usize,
    /// انڊيڪس کي سوئي ۾ وڌو جنهن کان پوءِ اسان ملائي چڪا آهيون
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // ھتي ڇا وڃڻ واري ھڪڙي خاص طور تي پڙھندڙ وضاحت ڪري سگھي ٿو Crochemore and Rytter's book "Text Algorithms"، ch 13.
        // خاص طور تي "Algorithm CP" لاءِ ڪوڊ ڏسو p.
        // 323.
        //
        // ڇا وڃي رهيو آهي اسان وٽ ڪجهه نازڪ عنصرن وارو عنصر (يو ، وي) ۽ اسان اهو طئي ڪرڻ گهرون ٿا ته ڇا توهان وي سي جي مدت جو نالو آهي [..].
        // جيڪڏهن اهو آهي ، اسان استعمال ڪريون ٿا "Algorithm CP1".
        // ٻي صورت ۾ اسان "Algorithm CP2" استعمال ڪريون ٿا ، جيڪو آهستي لاءِ بهتر ٿيل آهي جڏهن سوئي جي مدت وڏي هوندي آهي.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // نن periodو عرصو ڪيس-عرصو صحيح theيرندڙ سوئي لاءِ هڪ جدا تنقيدي فڪر جو حساب آهي x=u 'v' جتي | v '|<ايڪس ايمڪس.
            //
            // اهو اڳي ئي beingاتل سڃاتل آهي.
            // ياد رکو ته ھڪڙو ڪيس وانگر x= "acba" فيڪٽر ڪري سگھجي ٿو بلڪل اڳتي وڌڻ (تنقيدي_پوز=1 ، دور=3) ھڪڙي ريورس ۾ ويجھي عرصي سان فيڪٽريٽ ٿيڻ دوران (تنقيدي پوسٽ=2 ، دور=2).
            // اسان ڏنل رد عمل جي فڪر استعمال ڪريون ٿا پر صحيح مدت رکون.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // ڊگهي عرصي وارو ڪيس-اسان وٽ اصل دورن جي ويجهڙائي آهي ، ۽ يادگيري جو استعمال نه ڪيو وڃي.
            //
            //
            // هيٺيون پابند max(|u|, |v|) + 1 پاران تقريبن تقريبن.
            // اڳتي وڌڻ ۽ پٺڀرائي ٻنهي جي استعمال لاءِ نازڪ فيڪٽريزيشن موثر آهي.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // ڊيمن ويليو انهي کي اشارو ڏيڻ ته مدت ڊگهي آهي
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // ٻه طرفي رستي جو هڪ بنيادي خيال اهو آهي ته اسان انجڻ کي ٻن حصن ۾ وڌو ، (يو ، وي) ۽ کاٻي طرف کان کاٻي طرف اسڪين ڪري هيم اسٽيڪ ۾ وي ڳولڻ جي ڪوشش ڪئي.
    // جيڪڏهن v مماثلت ڪن ٿا ، اسان توهان سان ملائڻ جي ڪوشش ڪريون ٿا سا rightي کان کاٻي طرف.
    // ڪيتري حد تائين اسين جمپ ڪري سگھون ٿا جڏهن اسان ڪنهن غلطيءَ سان منهن ملنداسين اهو سڀ حقيقت تي بيٺل آهي ته (يو ، وي) انجڻ لاءِ هڪ نازڪ فڪر آهي.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` `self.position` کي ڪرسر طور استعمال ڪندو آهي
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // چيڪ ڪريو ته اسان وٽ پوزيشن ۾ ڳولا لاءِ ڪمرو آهي + انجلي_ لسٽ اوور فلو نه ٿي ڪري سگهي جيڪڏهن اسان سمجهون ته سلائسز آئزز جي حد تائين پابند آهن.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // اسان جي سبسٽرنگ سان واسطو رکندڙ وڏن حصن ذريعي جلدي ڇڏڻ جي ذريعي
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // ڏسو ته س needو حصو انجڻ سان ملن ٿا
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // ڏسو ته سئي کاٻي حصو ميچز جي برابر
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // اسانکي هڪ ميچ مليو آهي!
            let match_pos = self.position;

            // Note: needle.len() بدران needle.len() وڌيڪ ڪوپ ڪرڻ واريون ميچون شامل ڪريو
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // اوورلوپ ٿيل ميچز کي needle.len() ، self.period تي سيٽ ڪريو
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `next()` ۾ خيالن جي پيروي ڪري ٿو.
    //
    // وضاحتون متوازن آهن ، period(x) = period(reverse(x)) ۽ local_period(u, v) = local_period(reverse(v) ، reverse(u)) سان ، تنهنڪري جيڪڏهن (u ، v) هڪ نازڪ عنصر آهي ، تنهنڪري (reverse(v) آهي ، reverse(u)).
    //
    //
    // ريورس ڪيس جي لاءِ اسان هڪ نازڪ عنصر جوڙيو آهي x=u 'v' (فيلڊ `crit_pos_back`).اسان کي ضرورت آهي | توهان |<فارورڊ ڪيس لاءِ period(x) ۽ اھڙي طرح | v '|<period(x) ريورس لاء.
    //
    // هاڪي جي ذريعي ريورس ۾ ڳولڻ لاءِ ، اسين هڪ ريورس ڪيل ڀاstي جي ذريعي ڳوليندا آهيون ريورسيل سوئي سان ، پهرين توهان جي مل کي پوءِ پوءِ v.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` کي ڪرسر طور استعمال ڪندو آھي-ڇوته `next()` ۽ `next_back()` آزاد آھن.
        //
        let old_end = self.end;
        'search: loop {
            // چيڪ ڪريو ته اسان وٽ آخر ۾ تلاش ڪرڻ جو ڪم آهي ، needle.len() ڪيڏانهن نه رسندو جڏهن وڌيڪ ڪو گنجائش ناهي ، پر سلائس جي ڊيگهه حدن جي ڪري اهو گهوڙي واري لمبائي ۾ واپس س neverي طريقي سان واپس لهي نه سگهندو آهي.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // اسان جي سبسٽرنگ سان واسطو رکندڙ وڏن حصن ذريعي جلدي ڇڏڻ جي ذريعي
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // ڏسو ته سئي کاٻي حصو ميچز جي برابر
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // ڏسو ته س needو حصو انجڻ سان ملن ٿا
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // اسانکي هڪ ميچ مليو آهي!
            let match_pos = self.end - needle.len();
            // Note: ذيلي self.period بدران needle.len() وڌيڪ نقاب ڪرڻ
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr` جي وڌ کان وڌ واري لافاني جو حساب ڪريو
    //
    // وڌ کان وڌڻ وارو ايڪس اين ايڪس ايڪس جي هڪ ممڪن نازڪ عنصر (يو ، وي) آهي.
    //
    // واپسي (`i` ، `p`) جتي `i` وي جي شروعاتي انڊيڪس آھي ۽ `p` وي جي مدت آھي.
    //
    // `order_greater` اهو طئي ڪندو آهي ته لسانياتي ترتيب `<` يا `>` آهي.
    // ٻنهي حڪمن کي حساب ڏيڻو پوندو-سڀني کان وڏي `i` سان ترتيب ڏيڻ هڪ نازڪ عنصر جوڙڻ آهي.
    //
    //
    // ڊگهي عرصي جي ڪيسن لاءِ ، نتيجو وارو دور پورو ناهي (اهو تمام مختصر آهي).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // اخبار ۾ مون سان مطابقت آهي
        let mut right = 1; // ج ڪاغذ ۾ جي برابر آهي
        let mut offset = 0; // ڪاغذن ۾ ڪي سان ملندڙ ، پر 0 کان شروع ٿيو
        // 0 بنياد تي انڊسٽري کي ملائڻ لاءِ.
        let mut period = 1; // ڪاغذ ۾ پي سان برابر آهي

        while let Some(&a) = arr.get(right + offset) {
            // `left` انباؤنڊس ٿي ويندي جڏهن `right` آهي.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // سيفرڪس نن isڙو آهي ، دور تائين س prefو اڳڪس آهي.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // هاڻوڪي عرصي کي ورجائڻ ذريعي اڳتي وڌڻ.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // سوفڪس وڏو آهي ، موجوده جڳهه کان شروعات.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // `arr` جي ريورس جي وڌ کان وڌ لاحقه حساب ڪريو.
    //
    // وڌ کان وڌ لاڪس `arr` جي ھڪڙي ممڪن نازڪ عنصر (u '، v') آھي.
    //
    // `i` کي واپسي ڏئي ٿو جتي `i` وي کان شروعاتي انڊيڪس آهي ، پوئتي کان ؛
    // فوري طور تي واپسي جڏهن `known_period` جي هڪ مدي تائين پهچي وڃي.
    //
    // `order_greater` اهو طئي ڪندو آهي ته لسانياتي ترتيب `<` يا `>` آهي.
    // ٻنهي حڪمن کي حساب ڏيڻو پوندو-سڀني کان وڏي `i` سان ترتيب ڏيڻ هڪ نازڪ عنصر جوڙڻ آهي.
    //
    //
    // ڊگهي عرصي جي ڪيسن لاءِ ، نتيجو وارو دور پورو ناهي (اهو تمام مختصر آهي).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // اخبار ۾ مون سان مطابقت آهي
        let mut right = 1; // ج ڪاغذ ۾ جي برابر آهي
        let mut offset = 0; // ڪاغذن ۾ ڪي سان ملندڙ ، پر 0 کان شروع ٿيو
        // 0 بنياد تي انڊسٽري کي ملائڻ لاءِ.
        let mut period = 1; // ڪاغذ ۾ پي سان برابر آهي
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // سيفرڪس نن isڙو آهي ، دور تائين س prefو اڳڪس آهي.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // هاڻوڪي عرصي کي ورجائڻ ذريعي اڳتي وڌڻ.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // سوفڪس وڏو آهي ، موجوده جڳهه کان شروعات.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy الگورتھم کي اجازت ڏي ٿو ته جيترو جلد ممڪن هجي غير ميچز کي ڇڏي ڏي ، يا موڊ ۾ ڪم ڪجي جتي اهو رموز رد ٿئي ٿو نسبتاً جلدي.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// جيترو ممڪن ٿي سگهي ميچ سان ميچ ڪرڻ لاءِ ڇڏي ڏيو
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// ايمٽ رد ڪري ٿو باقائدگي سان
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}