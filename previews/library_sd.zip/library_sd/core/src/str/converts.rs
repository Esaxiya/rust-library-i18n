//! بٽس سلائس کان `str` ٺاھڻ جا طريقا.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// بائيٽ جي هڪ سلائيٽ کي هڪ سلائيٽ سلائس ۾ تبديل ڪري ٿو.
///
/// اسٽرنگ سلائس ([`&str`]) بائيٽ ([`u8`]) مان ٺهيل آهي ، ۽ هڪ بائيٽ سلائس ([`&[u8]`][byteslice]) بائيٽ مان ٺهيل آهي ، تنهنڪري اهو فنڪشن ٻنهي جي وچ ۾ تبديل ٿي ٿو.
/// بائيٽ جي تمام سليٽس صحيح اسٽرنگ سلائسون نه آهن ، جڏهن ته: [`&str`] جي ضرورت آهي ته اهو درست UTF-8 آهي.
/// `from_utf8()` انهي ڳالهه کي يقيني بڻائڻ جي لاءِ ته بائٽس درست UTF-8 آهن ، ۽ انهي کان پوءِ ڪنورپشن ٿئي ٿي.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// جيڪڏھن توھان کي پڪ آھي ته بائيٽ سلائس صحيح UTF-8 آھي ، ۽ توھان صحيح چڪاس جي مٿي کي برداشت ڪرڻ نٿا چاھيو ، ھن فنڪشن جو غير محفوظ ورزن ، [`from_utf8_unchecked`] آھي ، جيڪو ساڳيو رويو آھي پر چيڪ کي ڇڏي ڏئي ٿو.
///
///
/// جيڪڏهن توهان کي `&str` جي بدران `String` جي ضرورت آهي ، [`String::from_utf8`][string] تي غور ڪريو.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// ڇاڪاڻ ته توهان هڪ `[u8; N]` اسٽيڪ مختص ڪري سگهو ٿا ، ۽ توهان ان جو [`&[u8]`][byteslice] وٺي سگهو ٿا ، اهو فنڪشن اسٽوري کان مختص ڪيل اسٽرنگ هجڻ جو هڪ طريقو آهي.هتي ان جي هڪ مثال آهي مثال هيٺ ڏنل سيڪشن ۾.
///
/// [byteslice]: slice
///
/// # Errors
///
/// ايڪس سلڪس ايڪس کي واپس ڪري ٿو جيڪڏهن ٻلي UTF-8 نه آهي هڪ وضاحت سان ، ڇو ته مهيا ڪيل سلائس UTF-8 ناهي.
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// use std::str;
///
/// // ڪجهه بائٽس ، vector ۾
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // اسان اڻون ٿا ته بائٽس صحيح آهن ، تنهنڪري صرف `unwrap()` استعمال ڪريو.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// غلط بائٽس:
///
/// ```
/// use std::str;
///
/// // ڪجهه غلط بائيٽ ، vector ۾
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// ڏسو وڌيڪ تفصيل لاءِ دستاويز [`Utf8Error`] لاءِ انهن قسمن جي غلطين تي جيڪي واپس ڪري سگهجن ٿيون.
///
/// هڪ "stack allocated string":
///
/// ```
/// use std::str;
///
/// // ڪجهه بائٽس ، اسٽيڪ کان مختص ڪيل صف ۾
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // اسان اڻون ٿا ته بائٽس صحيح آهن ، تنهنڪري صرف `unwrap()` استعمال ڪريو.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // حفاظتي: صرف تصديق ٿيل ڊوڙايو.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// بائيٽ جي هڪ مٽائي سليس کي هڪ مٽندڙ سٽ سليس ۾ بدلائي ٿو.
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" هڪ بدل لائق vector طور
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // جئين اسان knowاڻون ٿا ته بائٽس صحيح آهن ، اسان `unwrap()` استعمال ڪري سگهون ٿا
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// غلط بائٽس:
///
/// ```
/// use std::str;
///
/// // هڪ قابل بدل vector ۾ ڪجهه غلط بائيٽ
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// ڏسو وڌيڪ تفصيل لاءِ دستاويز [`Utf8Error`] لاءِ انهن قسمن جي غلطين تي جيڪي واپس ڪري سگهجن ٿيون.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // حفاظتي: صرف تصديق ٿيل ڊوڙايو.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// بائٽس جي هڪ سلائيٽ کي سٽرنگ سلائس ۾ تبديل ڪري ٿو ، اهو چيڪ ڪرڻ جي بغير ته اسٽرنگ ۾ صحيح UTF-8 شامل آهي.
///
/// وڌيڪ forاڻ لاءِ محفوظ نسخو ، [`from_utf8`] کي ڏسو.
///
/// # Safety
///
/// اهو فنڪشن غير محفوظ آهي ڇاڪاڻ ته اهو چڪاس نٿو ڪري ته بائٽس ان ڏانهن منتقل ٿيل آهن صحيح UTF-8.
/// جيڪڏهن هن رڪاوٽ جي ڀڃڪڙي ڪئي وئي آهي ، اڻ سڌريل رويي جا نتيجا ، جئين باقي Rust فرض ڪري ٿو ته ["&str"] صحيح UTF-8 آهن.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// use std::str;
///
/// // ڪجهه بائٽس ، vector ۾
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // سافٽويئر: ڪالر کي گارنٽي ڏيڻ لازمي آھي ته بائٽس `v` صحيح UTF-8 آھن.
    // اهو ساڳيو ترتيب ڏنل `&str` ۽ `&[u8]` تي به ڀاڙيندو آهي.
    unsafe { mem::transmute(v) }
}

/// بائٽس جي هڪ سلائيٽ کي سٽرنگ سلائس ۾ تبديل ڪري ٿو ، بغير چيڪ ڪرڻ جي ته اسٽرنگ ۾ صحيح UTF-8 شامل آهي ؛مٽاسٽا ورزن.
///
///
/// ڏسو وڌيڪ تبديل ٿيندڙ ورجن ، [`from_utf8_unchecked()`] وڌيڪ معلومات لاءِ.
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // حفاظت: ڪال ڪرڻ واري کي گارنٽي ڏيڻ لازمي آهي بائٽ `v`
    // UTF-8 صحيح آهن ، اهڙي طرح `*mut str` ڏانهن ڪاسٽ محفوظ آهي.
    // انهي سان گڏ ، پوائنٽر جي تعريف محفوظ آهي ڇاڪاڻ ته پوائنٽر هڪ حوالي سان اچي ٿو جيڪو لکڻ جي صحيح هجڻ جي ضمانت آهي.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}