//! اهو ماڊل `Any` trait لاڳو ڪندو آهي ، جيڪو رن ٽائيم موٽائن ذريعي ڪنهن به `'static` قسم جي متحرڪ ٽائيپنگ کي قابل بنائي ٿو.
//!
//! `Any` پنهنجو پاڻ کي `TypeId` حاصل ڪرڻ لاءِ استعمال ڪري سگھجي ٿو ، ۽ وڌيڪ خاصيتون آهن جڏهن trait اعتراض طور استعمال ڪيو وڃي ٿو.
//! جئين `&dyn Any` (هڪ قرض وارو trait اعتراض) ، ان ۾ `is` ۽ `downcast_ref` طريقا آهن ، انهي جي جاچ ڪرڻ لاءِ ته ڇا قيمت ڏنل قيمت جي آهي ، ۽ هڪ قسم جي اندرئين قدر جو حوالو حاصل ڪرڻ جي لاءِ.
//! جئين `&mut dyn Any` پڻ ، `downcast_mut` طريقو پڻ آهي ، اندروني قدر جي قابل متغير حوالو حاصل ڪرڻ لاءِ.
//! `Box<dyn Any>` `downcast` طريقو شامل ڪري ٿو ، جيڪو `Box<T>` ۾ بدلائڻ جي ڪوشش ڪري ٿو.
//! مڪمل تفصيل لاءِ [`Box`] دستاويز ڏسو.
//!
//! ياد رکجو ته `&dyn Any` انهي جي چڪاس تائين محدود آهي ته ڇا هڪ قدر مخصوص ڪنڪريٽ جي آهي ، ۽ ٽيسٽ ڪرڻ لاءِ استعمال نه ٿي ڪري سگهجي ته ڇا هڪ قسم trait کي لاڳو ڪندي آهي.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # اسمارٽ اشارو ۽ `dyn Any`
//!
//! خاص طور تي `Box<dyn Any>` يا `Arc<dyn Any>` وانگر قسم سان ، خاص طور تي `Box<dyn Any>` يا `Arc<dyn Any>` قسم وانگر ، ذهن ۾ رکڻ لاءِ رويو جو هڪ ٽڪڙو اهو رکڻو آهي ته x03X ويليو تي صرف *ڪنٽينر* جي `TypeId` پيدا ڪندو * نه ڪي بنيادي trait اعتراض.
//!
//! اهو سمارٽ پوائنٽر کي `&dyn Any` ۾ تبديل ڪرڻ سان بچائي سگهجي ٿو ، جيڪو اهو شئي `TypeId` موٽائي سگهندو.
//! مثال طور:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // توهان هن کان وڌيڪ چاهيو ٿا:
//! let actual_id = (&*boxed).type_id();
//! // ... هن کان:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! ھڪڙي حالت تي غور ڪريو جتي اسان ھڪڙي فنڪشن ۾ گذري ويل قدر ختم ڪرڻ چاھيو ٿا.
//! اسان اڻون ٿا جيڪا اسان ڪم ڪري رهيا آهيون ڊيبگ تي ڪم ڪري رهيا آهيون ، پر اسان هن کي concreteاڻ نٿا سمجهون.اسان خاص قسمن کي خاص علاج ڏيڻ چاهيندا آهيون: انهي صورت ۾ انهن جي قيمت کان پهريان اسٽرنگ قدرن جي ڊيگهه کي پرنٽ ڪرڻ.
//! اسان timeاڻون ٿا ته اسان قطعي قسم جو اسان جي قيمت ترتيب ڏيڻ وقت نه آهي ، تنهن ڪري اسان کي بدران هلائڻ جي ضرورت
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // ڪنهن به قسم جي لاگر جو ڪم جيڪو ڊيبگ تي لاڳو ٿئي ٿو.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // اسان جي قيمت کي `String` ۾ بدلائڻ جي ڪوشش ڪريو.
//!     // جيڪڏهن ڪامياب ٿي وڃي ، اسان انهي کي اسٽرنگ جي ڊيگهه ۽ انهي جي قيمت کي وڌائڻ چاهيندا آهيون.
//!     // جيڪڏهن نه ، اهو هڪ مختلف قسم آهي: صرف ان کي پرنٽ ڪيو.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // انهي فنڪشن سان ڪم ڪرڻ کان پهريان ان جي پيمراٽر ٻاهر نڪرڻ چاهي ٿي.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... ڪو ٻيو ڪم ڪيو؟
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// ڪوبه trait
///////////////////////////////////////////////////////////////////////////////

/// متحرڪ ٽائپنگ کي ظاھر ڪرڻ لاءِ trait.
///
/// اڪثر قسمون `Any` تي عمل ڪن ٿيون.بهرحال ، ڪنهن به قسم ۾ جيڪو غير "جامد" حوالا شامل نه آهي.
/// وڌيڪ تفصيل لاءِ [module-level documentation][mod] ڏسو.
///
/// [mod]: crate::any
// ھي trait غير محفوظ نه آھي ، جيتوڻيڪ اسين غير محفوظ ڪيل ڪوڊ ۾ ان جي واحد چپ جي `type_id` جي خاصيتن تي ڀروسو ڪندا آھيون (مثال طور ، `downcast`).عام طور تي ، اهو هڪ مسئلو ٿي ويندو ، پر ڇاڪاڻ ته صرف `Any` جو هڪ خالي ڪم آهي ، ڪو ٻيو ڪوڊ `Any` لاڳو نٿو ڪري سگهي.
//
// اسان هلڪي نموني سان اهو trait غير محفوظ ڪري سگهون ٿا-اهو خرابي جو سبب نه بڻجندو ، ڇو ته اسان سڀني عمل درآمد تي ضابطو رکون ٿا-پر اسان نه چونڊون ٿا ڇو ته اهو واقعي ضروري نه آهي ۽ صارف کي غير محفوظ traits ۽ غير محفوظ طريقن جي فرق بابت پريشان ڪري سگهون ٿا (يعني `type_id` اڃا به ڪال ڪرڻ لاءِ محفوظ هوندو ، پر اسان ممڪن طور تي ظاهر ڪرڻ چاهيون ٿا جهڙوڪ دستاويزن ۾).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self` `TypeId` حاصل ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// ڪنهن به trait شين لاءِ توسيع جا طريقا.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// يقيني بڻايو وڃي ته مثال جو نتيجو ، ڪنڊي ۾ شامل ٿيڻ سان پرنٽ ٿي سگھي ٿو ۽ اھڙي طرح `unwrap` سان استعمال ٿيندو.
// شايد بالآخر ڪا ضرورت نه آهي جيڪڏهن ڊسڪشن اپ ڊيٽنگ سان ڪم ڪري ٿي.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// `true` ورجائي ٿو جيڪڏھن باڪس ٿيل ٽائيم ساڳيو آھي `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // انهي قسم جي `TypeId` حاصل ڪريو اهو فنڪشن شروع ڪيو ويو آهي.
        let t = TypeId::of::<T>();

        // حاصل ڪريو `TypeId` قسم جي trait اعتراض (`self`) ۾.
        let concrete = self.type_id();

        // برابر ڪريو "TypeId" s.
        t == concrete
    }

    /// باڪس ٿيل قيمت کي ڪجهه حوالو ڏئي ٿو جيڪڏھن اھو قسم `T` ، يا `None` جيڪڏھن نه آھي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // حفاظت: صرف چڪاس ڪيو ته ڇا اسان صحيح قسم ڏانهن اشارو ڪري رهيا آهيون ، ۽ اسان انحصار ڪري سگهون ٿا
            // انهي ياداشت جي حفاظت جي چڪاس ڪريو ڇاڪاڻ ته اسان هر قسم جي لاءِ لاڳو ڪيو آهي.ڪوبه ٻيو اثر موجود نه آهي جئين اهي اسان جي نقلي سان تڪرار ڪندا هجن.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// باڪس ويليو جي حوالي سان ڪجهه قابل تبديل حوالو واپس ڏئي ٿو جيڪڏهن اها قسم `T` ، يا `None` آهي ته ناهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // حفاظت: صرف چڪاس ڪيو ته ڇا اسان صحيح قسم ڏانهن اشارو ڪري رهيا آهيون ، ۽ اسان انحصار ڪري سگهون ٿا
            // انهي ياداشت جي حفاظت جي چڪاس ڪريو ڇاڪاڻ ته اسان هر قسم جي لاءِ لاڳو ڪيو آهي.ڪوبه ٻيو اثر موجود نه آهي جئين اهي اسان جي نقلي سان تڪرار ڪندا هجن.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` قسم تي بيان ڪيل طريقي سان اڳتي وڌو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` قسم تي بيان ڪيل طريقي سان اڳتي وڌو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` قسم تي بيان ڪيل طريقي سان اڳتي وڌو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` قسم تي بيان ڪيل طريقي سان اڳتي وڌو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` قسم تي بيان ڪيل طريقي سان اڳتي وڌو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` قسم تي بيان ڪيل طريقي سان اڳتي وڌو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// ٽائپ آئي ڊي ۽ ان جا طريقا
///////////////////////////////////////////////////////////////////////////////

/// هڪ `TypeId` هڪ قسم جي عالمي سطح تي منفرد سڃاڻڻ واري جي لاءِ نمائندگي ڪندو آهي.
///
/// هر هڪ `TypeId` هڪ ڇڪائيندڙ شيءَ آهي جيڪا اندر جي جانچ جي اجازت نه ڏئي ٿي پر بنيادي آپريشن جي اجازت ڏي ٿي جيئن ڪلوننگ ، مقابلو ، ڇپائي ۽ ڏيکارڻ.
///
///
/// هڪ `TypeId` في الحال صرف انهن قسمن لاءِ موجود آهي جيڪي `'static` کي بيان ڪن ٿا ، پر اهو حد future ۾ ختم ڪري سگهجي ٿو.
///
/// جڏهن `TypeId` ايڪسڪسيمڪس ، `PartialOrd` ۽ `Ord` کي لاڳو ڪري ٿو ، اهو سمجهڻ جي لائق آهي ته هش ۽ ترتيب Rust رليز جي وچ ۾ فرق ٿيندو.
/// پنهنجي ڪوڊ جي اندر انهن تي ڀروسو ڪرڻ کان بچو!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// قسم جي `TypeId` کي واپسي ڏئي ٿو ھي عام ڪم سان شروع ڪيو ويو آھي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// ھڪڙي قسم جو نالو واپس آڻيندو آھي ھڪڙو اسٽرنگ سلائس وانگر.
///
/// # Note
///
/// اهو مقصد تشخيصي استعمال لاءِ آهي.
/// واپس ڏنل اسٽرنگ جو صحيح مواد ۽ شڪل بيان ٿيل ناهي ، ٻيو قسم جي بهترين ڪوشش وارو بيان کانسواءِ.
/// مثال طور ، وچ مان جيڪي `type_name::<Option<String>>()` موٽي سگھن ٿيون `"Option<String>"` ۽ `"std::option::Option<std::string::String>"`.
///
///
/// واپسي واري اسٽرنگ کي ڪنهن قسم جي منفرد سڃاڻيندڙ سمجهيو ئي نه هجڻ گهرجي ڇاڪاڻ ته ڪيترن ئي قسمن لاءِ ساڳئي قسم جي نالي تي نقشو ٿي سگهي ٿو.
/// ساڳئي طرح ، ڪا به ضمانت نه آهي ته هڪ قسم جا سڀئي حصا واپس واري وارنگ ۾ ظاهر ٿيندا: مثال طور ، لائفائم وضاحت ڪندڙ في الحال شامل نه آهن.
/// ان کان علاوه ، محصول گڏ ڪندڙ جي نسخن جي وچ ۾ تبديلي ٿي سگھي ٿي.
///
/// موجوده عملن ساڳئي انفراسٽرڪچر کي استعمال ڪيو آهي جيئن ته کمپائلر ڊاڪٽرن ۽ ڊيبگينفو ، پر اها گارنٽي ناهي.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// تار جي قدر وانگر ھڪڙي طرف واري پوائنٽ جي نالي جو نالو واپسي ڏيندو آھي.
/// اهو ساڳيو `type_name::<T>()` وانگر آهي ، پر استعمال ٿي سگهي ٿو جتي هڪ قسم جي متحرڪ آساني سان دستياب ناهي.
///
/// # Note
///
/// اهو مقصد تشخيصي استعمال لاءِ آهي.قطعي جو صحيح مواد ۽ قسم جي وضاحت نه ٿيل آهي ، ٻئي قسم جي بهترين ڪوشش ڪرڻ کان علاوه.
/// مثال طور ، `type_name_of_val::<Option<String>>(None)` `"Option<String>"` يا `"std::option::Option<std::string::String>"` واپس ڪري سگھي ٿو ، پر `"foobar"` نه.
///
/// ان کان علاوه ، محصول گڏ ڪندڙ جي نسخن جي وچ ۾ تبديلي ٿي سگھي ٿي.
///
/// اهو فنڪشن trait شيون حل نٿو ڪري ، مطلب ته `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` واپس ٿي سگهي ٿو ، پر `"u32"` نه.
///
/// قسم جو نالو ھڪڙي قسم جي منفرد سڃاڻپ نه سمجهيو وڃي ؛
/// ڪيترن ئي قسمن ۾ ساڳيو قسم جو نالو شيئر ٿي سگھي ٿو.
///
/// موجوده عملن ساڳئي انفراسٽرڪچر کي استعمال ڪيو آهي جيئن ته کمپائلر ڊاڪٽرن ۽ ڊيبگينفو ، پر اها گارنٽي ناهي.
///
/// # Examples
///
/// طئي ٿيل انڌيري ۽ فلوٽ جا قسم پرنٽ ڪندو آهي.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}