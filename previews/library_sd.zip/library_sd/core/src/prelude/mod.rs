//! لائبريري prelude
//!
//! اهو ماڊل ليبيڪور جي استعمال ڪندڙن لاءِ استعمال ڪيو ويو آهي جيڪي لئسٽسٽ سان پڻ ڳن linkيل ناهن.
//! اهو ماڊل ڊفالٽ طرفان درآمد ڪيو ويو آهي جڏهن `#![no_std]` ساڳئي طريقي سان معياري لائبريري جي prelude طور استعمال ڪيو وڃي ٿو.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// ڪور prelude جو 2015 نسخو.
///
/// وڌيڪ لاءِ [module-level documentation](self) ڏسو.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// ڪور prelude جو 2018 نسخو.
///
/// وڌيڪ لاءِ [module-level documentation](self) ڏسو.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// ڪور 200 جو نسخو prelude جو نسخو.
///
/// وڌيڪ لاءِ [module-level documentation](self) ڏسو.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: وڌيڪ شيون شامل ڪريو.
}