//! ايم پي ايڪس {} X

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char` جو سڀ کان وڌيڪ صحيح ڪوڊ پوائنٽ ٿي سگھي ٿو.
    ///
    /// هڪ `char` هڪ [Unicode Scalar Value] آهي ، جنهن جو مطلب اهو آهي ته اهو هڪ [Code Point] آهي ، پر صرف هڪ خاص حد تائين.
    /// `MAX` سڀ کان وڌيڪ صحيح ڪوڊ پوائنٽ آهي جيڪو صحيح [Unicode Scalar Value] آهي.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () ڊيڪوڊنگ واري غلطي جي نمائندگي ڪرڻ لاءِ يونيڪوڊ ۾ استعمال ٿيندو آهي.
    ///
    /// اهو ٿي سگهي ٿو ، مثال طور ، جڏهن [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) کي خراب ٺهيل UTF-8 بائٽس ڏيڻ.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// [Unicode](http://www.unicode.org/) جو نسخو ته يونيڪوڊ جا حصا `char` ۽ `str` جا بنياد آهن.
    ///
    /// يونيڪوڊ جا نوان نسخا باقاعده جاري ڪيا ويندا آهن ۽ بعد ۾ يونيڪوڊ جي بنياد تي معياري لائبريري ۾ سڀ طريقي سان اپڊيٽ ٿي ويندا آهن.
    /// تنهن ڪري ڪجهه `char` ۽ `str` طريقن جي رويي ۽ وقت جي انهي مسلسل قيمت جو قدر.
    /// اھو * سمجھڻ واري تبديلي نہ سمجھڻ آھي.
    ///
    /// [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) ۾ ورشن نمبرنگ اسڪيم وضاحت ڪئي وئي آهي.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter` ۾ UTF-16 انڪوڊ ٿيل ڪوڊ پوائنٽس مٿان هڪ ورجائي ٺاهيندو آهي ، غلط طور تي اڻedاڻين ريگروٽس کي "ايرز" وانگر.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// متبادل ڪردار سان `Err` نتيجا تبديل ڪندي ڪو نقصان ڏيندڙ ڊيڪوڊر حاصل ڪري سگھجي ٿو.
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// هڪ `u32` هڪ `char` ۾ بدلائي ٿو.
    ///
    /// نوٽ ڪريو ته سڀ "چار" صحيح آھن [u32 "] ، ۽ ھڪڙي کي اڇلائي سگھجي ٿو
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// بهرحال ، ريورس درست ناهي: سڀئي صحيح [u32\"صحيح نه آهي] چارز.
    /// `from_u32()` جيڪڏهن انڊرڪس `char` لاءِ صحيح قيمت نه هجي ته واپسي ـ `None` واپس ڪندو.
    ///
    /// انهي فنڪشن جي غير محفوظ ورزن لاءِ جيڪو انهن چيڪن کي نظرانداز ڪري ٿو ، [`from_u32_unchecked`] کي ڏسو.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// `None` واپس ڪرڻ جڏهن انٽيپ صحيح صحيح `char` ناهي:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// هڪ `u32` هڪ `char` ۾ بدلائي ٿو ، درستگي کي نظر انداز ڪرڻ.
    ///
    /// نوٽ ڪريو ته سڀ "چار" صحيح آھن [u32 "] ، ۽ ھڪڙي کي اڇلائي سگھجي ٿو
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// بهرحال ، ريورس درست ناهي: سڀئي صحيح [u32\"صحيح نه آهي] چارز.
    /// `from_u32_unchecked()` هن کي نظرانداز ڪري ڇڏيندي ، ۽ انڌي طور تي `char` ڏانهن اڇلائي ، ممڪن طور هڪ غلط بڻجندڙ کي.
    ///
    ///
    /// # Safety
    ///
    /// اهو فنڪشن غير محفوظ آهي جئين اهو غلط `char` قدر ٺاهي سگھي ٿو.
    ///
    /// هن فنڪشن جي محفوظ ورزن لاءِ ، ڏسو [`from_u32`] فنڪشن.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // حفاظت: حفاظت جو معاهدو سڏيندڙ طرفان برقرار رکڻ لازمي آهي.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// ھڪڙي عددي طور ايڪس ري ايڪسينڪس ۾ ھڪڙي عددي کي `char` ۾ تبديل ڪري ٿو.
    ///
    /// هتي هڪ 'radix' ڪڏهن ڪڏهن 'base' پڻ سڏيو ويندو آهي.
    /// ٻن جو ريڊڪس هڪ بائنري نمبر ، ڏهه ريڊيڪس ، ۽ ڇهه ، ريڪسڪس ، ريڪسڪس هيڪسڊيڪل جي اشارو ڏئي ٿو ، ڪجهه عام قدر ڏيڻ لاءِ.
    ///
    /// ثالث راڪس سپورٽ ڪيا آهن.
    ///
    /// `from_digit()` ايڪس ايڪس ايڪس واپس آڻيندي جيڪڏهن ڏنل ريڊڪس ۾ انجيڪشن نه آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن ڏنو ويو ريڊڪسڪس 36 کان وڏو آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // ڊيمل 11 بيس 16 ۾ ھڪڙو عددي آھي
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// `None` واپس ڪرڻ جڏھن انجيٽ عددي نه آھي:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// وڏي ريڊڪس گزرڻ ، هڪ panic سبب ڪري رهيو آهي:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// چيڪ ڪريو ته ڇا `char` ڏنل ريڊڪس ۾ هڪ عدد آهي.
    ///
    /// هتي هڪ 'radix' ڪڏهن ڪڏهن 'base' پڻ سڏيو ويندو آهي.
    /// ٻن جو ريڊڪس هڪ بائنري نمبر ، ڏهه ريڊيڪس ، ۽ ڇهه ، ريڪسڪس ، ريڪسڪس هيڪسڊيڪل جي اشارو ڏئي ٿو ، ڪجهه عام قدر ڏيڻ لاءِ.
    ///
    /// ثالث راڪس سپورٽ ڪيا آهن.
    ///
    /// [`is_numeric()`] جي مقابلي ۾ ، اهو فنڪشن صرف `0-9` ، `a-z` ۽ `A-Z` جي ڪردار کي سڃاڻي ٿو.
    ///
    /// 'Digit' صرف هيٺين اکرن تي تعريف ٿيل آهي:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit' جي وڌيڪ جامع سمجھڻ لاءِ ، [`is_numeric()`] کي ڏسو.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن ڏنو ويو ريڊڪسڪس 36 کان وڏو آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// وڏي ريڊڪس گزرڻ ، هڪ panic سبب ڪري رهيو آهي:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// ڏنل ريڊڪس ۾ ايڪس ايڪس کي ڊڪس تائين تبديل ڪري ٿو.
    ///
    /// هتي هڪ 'radix' ڪڏهن ڪڏهن 'base' پڻ سڏيو ويندو آهي.
    /// ٻن جو ريڊڪس هڪ بائنري نمبر ، ڏهه ريڊيڪس ، ۽ ڇهه ، ريڪسڪس ، ريڪسڪس هيڪسڊيڪل جي اشارو ڏئي ٿو ، ڪجهه عام قدر ڏيڻ لاءِ.
    ///
    /// ثالث راڪس سپورٽ ڪيا آهن.
    ///
    /// 'Digit' صرف هيٺين اکرن تي تعريف ٿيل آهي:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// `None` واپس ڏئي ٿو جيڪڏھن `char` ڏنل ريڊڪس ۾ ھڪڙي عددي جو حوالو نٿي ڏئي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن ڏنو ويو ريڊڪسڪس 36 کان وڏو آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// ناڪاميءَ جا نتيجا پاس ڪرڻ ۾ ناڪامي:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// وڏي ريڊڪس گزرڻ ، هڪ panic سبب ڪري رهيو آهي:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // ڪوڊ هتي ڀڃڪڙي ڪيو ويو آهي عمل ڪرڻ جي رفتار کي بهتر ڪرڻ جي لاءِ جتي `radix` مستقل ۽ 10 يا نن smallerا آهن
        //
        let val = if likely(radix <= 10) {
            // جيڪڏهن هڪ عددي نه ، ريڊڪس کان به وڏو انگ پيدا ٿيندو.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// هڪ ايريرٽر واپس ڏئي ٿو جيڪو هڪ ڪردار جي هيڪاڊيڪمل يونيڪوڊ فرار کي ڏئي ٿو جيئن چار کي.
    ///
    /// اهو ڪردار `\u{NNNNNN}` سان گڏ Rust نحو سان فرار ٿي ويندا جتي `NNNNNN` هڪ هيڪسڊيڪل ايڏي نمائندگي آهي.
    ///
    ///
    /// # Examples
    ///
    /// هڪ ويڙهاڪ جي طور تي:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// سڌو `println!` استعمال ڪندي:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// ٻئي برابر آهن:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` استعمال ڪندي:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // يا-1 1 انهي کي يقيني بڻائي ٿو ته c==0 ڪوڊ سمجھي ٿو ته هڪ عدد پرنٽ ٿيڻ گهرجي ۽ (جيڪو ساڳيو آهي)(31، 32) انڊر فال کان پاسو ڪري.
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // سڀ کان وڌيڪ اھم ھيڪ انڊيڪس جو انڊيڪس
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// `escape_debug` جو وڌايل نسخو جيڪو اختيارن سان وڌايل گرافيم ڪوڊ ڪوڊ سان فرار ٿيڻ جي اجازت ڏيندو آهي.
    /// اهو اسان کي ڪردارن کي شڪل ڏيڻ جي اجازت ڏيندو آهي جيئن ته نشانين جي نشاندهي بهتر هجي جڏهن اهي تار جي شروعات تي هجن.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// اهو بار بار ورجائي ٿو جيڪو هڪ ڪردار جي لفظي فرار وارو ڪوڊ حاصل ڪري ٿو "چار" طور.
    ///
    /// اهو `str` يا `char` جي `Debug` لاڳو ڪندڙ جهڙي ڪردارن کان فرار ٿي ويندي.
    ///
    ///
    /// # Examples
    ///
    /// هڪ ويڙهاڪ جي طور تي:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// سڌو `println!` استعمال ڪندي:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// ٻئي برابر آهن:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` استعمال ڪندي:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// اهو بار بار ورجائي ٿو جيڪو هڪ ڪردار جي لفظي فرار وارو ڪوڊ حاصل ڪري ٿو "چار" طور.
    ///
    /// ڊفالٽ لفظي پيدا ڪرڻ جي تعصب سان چونڊيو ويو آهي جيڪي مختلف ٻولين ۾ قانوني آهن ، بشمول C++ 11 ۽ ساڳي سي خاندان واريون ٻوليون.
    /// صحيح ضابطا آهن:
    ///
    /// * ٽيب `\t` وانگر فرار ٿي ويو آهي.
    /// * گاڏي واپسي واپسي `\r` وانگر فرار ٿي وئي آهي.
    /// * لائين فيڊ `\n` وانگر فرار ٿي ويو آهي.
    /// * اڪيلو اقتباس ايڪس آرڪس وانگر فرار ٿي ويو آهي.
    /// * ڊبل اقتباس `\"` وانگر فرار ٿي ويو آهي.
    /// * Backslash `\\` وانگر فرار ٿي ويو آهي.
    /// * ڪنهن به ڪردار `پرنٽ لائق اي ايس سي آءِ اي` رينج `0x20` ۾ .. `0x7e` ان ۾ شامل ڪونه آهي.
    /// * ٻين سڀني ڪردارن کي هيڪسڊيڪل يونيڪوڊ فرار ڏنو ويو آهي؛[`escape_unicode`] ڏسو.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// هڪ ويڙهاڪ جي طور تي:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// سڌو `println!` استعمال ڪندي:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// ٻئي برابر آهن:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` استعمال ڪندي:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// بائٽس جو نمبر واپس ڏئي ٿو ايڪس `char` جيڪڏهن انڪوڊ ڪيو ويو جيڪڏهن UTF-8 ۾.
    ///
    /// بائٽس جو تعداد هميشه 1 ۽ 4 جي وچ ۾ هوندو آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` قسم انهي جي ضمانت ڏي ٿو ته ان جا مواد UTF-8 آهن ، ۽ تنهن ڪري اسان ان جي ڊيگهه جو مقابلو ڪري سگهون ٿا ، جيڪڏهن هر ڪوڊ پوائنٽ `&str` پاڻ ۾ `char` بمقابلي جي نمائندگي ڪئي وئي هئي.
    ///
    ///
    /// ```
    /// // ڪردارن جي طور تي
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ٻئي ٽي ٽي بائٽس جي نمائندگي ڪري سگهجي ٿي
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // هڪ &str طور ، اهي ٻئي UTF-8 ۾ انڪوڊ ٿيل آهن
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // اسان ڏسي سگهون ٿا ته اهي ڇهه بائٽس کل وٺي وڃن ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... &str وانگر ئي
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// 16-bit ڪوڊ يونٽن جو نمبر ڏي ٿو هي `char` جي ضرورت هوندي جيڪڏهن UTF-16 ۾ انڪوڊ ڪيو وڃي.
    ///
    ///
    /// ھن تصور جي وڌيڪ وضاحت لاءِ [`len_utf8()`] لاءِ دستاويز ڏسو.
    /// اها فنڪشن هڪ آئيني آهي ، پر ايڪس UTF-8 جي بدران UTF-16.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// ان ڪردار کي UTF-8 طور ڏنل بائيٽ بفر ۾ شامل ڪيو ويو آھي ، ۽ پوءِ بفر جو سبسڪرس واپس ڪري ٿو جيڪو انڪوڊ ٿيل ڪردار تي مشتمل آھي.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن بفر ڪافي وڏي نه آهي.
    /// ڪنهن `char` کي انڪوڊ ڪرڻ لاءِ چار طول ڏيڻ وارو ڪافي وڏو آهي.
    ///
    /// # Examples
    ///
    /// انهن ٻنهي مثالن ۾ ، 'ß' ٻن بائٽس کي انڪوڊنگ ڪرڻ لاءِ وٺي ٿو.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// هڪ بيفر جيڪو تمام نن: ڙو آهي:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // سافٽوي: `char` ھڪ ريگيوليشن ناھي ، تنھنڪري ھي صحيح آھي UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// ان ڪردار کي UTF-16 طور فراهم ڪيو ويو `u16` بفر ۾ ، ۽ پوء بفر جو ذيلي ذخيرو واپس ڏئي ٿو جيڪو انڪوڊ ٿيل ڪردار کي شامل ڪري ٿو.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن بفر ڪافي وڏي نه آهي.
    /// `char` کي ڳڻڻ لاءِ 2 جي هڪ بفر ڪافي وڏي آهي.
    ///
    /// # Examples
    ///
    /// انهن ٻنهي مثالن ۾ ، '𝕊' ٻه "u16" انڪوڊ ڪرڻ گهري ٿو.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// هڪ بيفر جيڪو تمام نن: ڙو آهي:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// جيڪڏهن `char` وٽ `Alphabetic` ملڪيت هجي تو `true` واپس ڪري ٿي.
    ///
    /// `Alphabetic` [Unicode Standard] جي باب 4 (ڪردار جي خاصيت) کي بيان ڪيو ويو آهي ۽ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ۾ بيان ڪيو ويو آهي.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // پيار ڪيتريون ئي شيون آهن ، پر اهو الفابيٽ ناهي
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// جيڪڏهن `char` وٽ `Lowercase` ملڪيت هجي تو `true` واپس ڪري ٿي.
    ///
    /// `Lowercase` [Unicode Standard] جي باب 4 (ڪردار جي خاصيت) کي بيان ڪيو ويو آهي ۽ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ۾ بيان ڪيو ويو آهي.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // مختلف چيني رسم الخط ۽ ڇڪاءُ ڪيس ۾ نه آهن ، ۽ ائين:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// جيڪڏهن `char` وٽ `Uppercase` ملڪيت هجي تو `true` واپس ڪري ٿي.
    ///
    /// `Uppercase` [Unicode Standard] جي باب 4 (ڪردار جي خاصيت) کي بيان ڪيو ويو آهي ۽ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ۾ بيان ڪيو ويو آهي.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // مختلف چيني رسم الخط ۽ ڇڪاءُ ڪيس ۾ نه آهن ، ۽ ائين:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// جيڪڏهن `char` وٽ `White_Space` ملڪيت هجي تو `true` واپس ڪري ٿي.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`] ۾ بيان ڪيو ويو آهي.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // نه ٽوڙڻ واري جاءِ
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// `true` موٽائي ٿو جيڪڏھن ھي `char` ٻئي [`is_alphabetic()`] يا [`is_numeric()`] کي مطمئن ڪري ٿو.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// `true` جي واپسي ڏئي ٿو جيڪڏهن هن `char` ۾ عام ڪوڊس ڪوڊ جي درجه بندي آهن.
    ///
    /// ڪنٽرول ڪوڊ (ڪوڊ پوائنٽ `Cc` جي عام درجي سان) بيان ڪيا ويا آهن باب 4 (ڪردار جي خصوصيت) [Unicode Standard] جي ۽ [Unicode Character Database][ucd] [`UnicodeData.txt`] ۾ بيان ڪيل.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// // يو + 009 سي ، اسٽرنگ ٽرمينٽر
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// جيڪڏهن `char` وٽ `Grapheme_Extend` ملڪيت هجي تو `true` واپس ڪري ٿي.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] ۾ بيان ڪيو ويو آهي ۽ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ۾ بيان ڪيو ويو آهي.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// `true` جي واپسي ڏي ٿو جيڪڏھن ھي `char` نمبرن لاءِ ھڪڙي عام قسم جي آھي.
    ///
    /// انگن اکرن لاءِ عام قسمون (عددي انگن اکرن لاءِ `Nd` ، خط جهڙو عددي اکرن لاءِ `Nl` ، ۽ ٻين انگن اکرن لاءِ `No`) [Unicode Character Database][ucd] [`UnicodeData.txt`] ۾ بيان ڪيون ويون آهن.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// هڪ ايريرٽر واپس ڏئي ٿو جيڪا هن `char` جي ننcaseڙي نن mڙي نقشي کي هڪ يا وڌيڪ طور حاصل ڪري ٿي
    /// `char`s.
    ///
    /// جيڪڏهن هن `char` وٽ ننcaseا نن mا نقشا ٺاھڻ وارا نه آهن ، ايٽرر ساڳيو `char` پيدا ڪري ٿو.
    ///
    /// جيڪڏهن هن `char` وٽ [Unicode Character Database][ucd] [`UnicodeData.txt`] پاران ڏنل هڪ کان نن lowerا نن mا نقشا ٺاهيا ويا آهن ، ايٽرٽر انڊرٽ ڏئي ٿو ته `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// جيڪڏهن هن `char` کي خاص خيالات جي ضرورت آهي (مثال طور گهڻن ``چارز '') ، ايٽرر [`SpecialCasing.txt`] پاران ڏنل`چار` (ٽي) پيدا ڪري ٿو.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// هي آپريشن بغير ڪنهن مشاهدي جي نقشه ڪ performندي آهي.اها آهي ، تبديلي تابع ۽ ٻولي کان آزاد آهي.
    ///
    /// [Unicode Standard] ۾ ، باب 4 (ڪردار جي خاصيتن) ڪيس جي نقشي کي عام طور تي بحث ڪندو آهي ۽ باب 3 (Conformance) ڪيس جي تبديلي لاءِ ڊفالٽ الگورٿم تي بحث ڪندو آهي.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// هڪ ويڙهاڪ جي طور تي:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// سڌو `println!` استعمال ڪندي:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// ٻئي برابر آهن:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` استعمال ڪندي:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // ڪڏهن ڪڏهن نتيجو هڪ کان وڌيڪ ڪردار هوندو آهي.
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // ڪردار جنهن ۾ ٻنهي جا ننcaseا اکر ۽ ننcaseا اکر نه هجن پنهنجو پاڻ ۾ بدلائيندا آهن.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// هڪ ورزن کي واپس ڏئي ٿو جيڪا هن `char` جي مٿين نقشي جي نقشي کي هڪ يا وڌيڪ طور حاصل ڪري ٿي
    /// `char`s.
    ///
    /// جيڪڏهن هن `char` ۾ ننcaseا نن mا نقشا ٺاھڻ وارا نه آهن ، ايٽرر ساڳيو `char` پيدا ڪري ٿو.
    ///
    /// جيڪڏهن هن `char` وٽ [Unicode Character Database][ucd] [`UnicodeData.txt`] طرفان ڏنل هڪ هڪ کان مٿانهين نقشي جي ڀڃڪڙي آهي ، ايٽررٽر انڊر ڏيکاري ٿو ته `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// جيڪڏهن هن `char` کي خاص خيالات جي ضرورت آهي (مثال طور گهڻن ``چارز '') ، ايٽرر [`SpecialCasing.txt`] پاران ڏنل`چار` (ٽي) پيدا ڪري ٿو.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// هي آپريشن بغير ڪنهن مشاهدي جي نقشه ڪ performندي آهي.اها آهي ، تبديلي تابع ۽ ٻولي کان آزاد آهي.
    ///
    /// [Unicode Standard] ۾ ، باب 4 (ڪردار جي خاصيتن) ڪيس جي نقشي کي عام طور تي بحث ڪندو آهي ۽ باب 3 (Conformance) ڪيس جي تبديلي لاءِ ڊفالٽ الگورٿم تي بحث ڪندو آهي.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// هڪ ويڙهاڪ جي طور تي:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// سڌو `println!` استعمال ڪندي:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// ٻئي برابر آهن:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` استعمال ڪندي:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // ڪڏهن ڪڏهن نتيجو هڪ کان وڌيڪ ڪردار هوندو آهي.
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // ڪردار جنهن ۾ ٻنهي جا ننcaseا اکر ۽ ننcaseا اکر نه هجن پنهنجو پاڻ ۾ بدلائيندا آهن.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # مقامي تي نوٽ
    ///
    /// ترڪ ۾ ، لاطيني ۾ 'i' جي برابر ٻن جي بدران پنج فارم آهن:
    ///
    /// * 'Dotless': آ/I ، ڪڏهن ڪڏهن لکندو ï
    /// * 'Dotted': İ/مان
    ///
    /// نوٽ ڪريو ته نن theو ڊاٽ 'i' ساڳيو ئي لاطيني وانگر آهي.تنهن ڪري:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// `upper_i` هتي قدر متن جي ٻولي تي ڀاڙين ٿا: جيڪڏهن اسان `en-US` ۾ آهيون ، اهو `"I"` هجڻ گهرجي ، پر جيڪڏهن اسان `tr_TR` ۾ آهيون ، اهو `"İ"` هجڻ گهرجي.
    /// `to_uppercase()` هن کي حساب ۾ نه ورتو ويو ، ۽ ائين:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// سڀني ٻولين ۾ رکندي آهي
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// چيڪ ڪريو ته ڇا قيمت ASCII حد جي اندر آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// انهي جي اي ايس سي آئي مٿئين صورت ۾ قيمت جي ڪاپي ٺاهي ٿو برابر.
    ///
    /// ASCII خط 'a' کان 'z' 'A' کان 'Z' ڏانهن نقشه ڏنل آهن ، پر غير ASCII خط بدلايو نٿا وڃن.
    ///
    /// قيمت کي جڳائي ۾ وڏو ڪرڻ لاءِ ، ايڪس ايڪس ايڪس استعمال ڪريو.
    ///
    /// ASCII حروف کي غير ASCII حروف کان علاوه ، [`to_uppercase()`] استعمال ڪريو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// انهي جي اي ايس سي آئي نن lowerي ڪيس ۾ برابر جي ڪاپي ٺاهي ٿو.
    ///
    /// ASCII خط 'A' کان 'Z' 'a' کان 'z' ڏانهن نقشه ڏنل آهن ، پر غير ASCII خط بدلايو نٿا وڃن.
    ///
    /// قيمت کي گھٽائڻ واري جڳهه ۾ ، [`make_ascii_lowercase()`] استعمال ڪريو.
    ///
    /// ASCII اکرن کي گھٽ ڪرڻ لاءِ ، غير ASCII اکرن جي گھٽتائي لاءِ ، [`to_lowercase()`] استعمال ڪريو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// چيڪ ڪري ٿو ته ٻه قدر هڪ اي ايس سي آئي ڪيس جا غير حساس ميچ آهن.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` جي برابر.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// انهي قسم کي ان جي ASCII اوپري ڪيس برابر واري هنڌ ۾ تبديل ڪري ٿو.
    ///
    /// ASCII خط 'a' کان 'z' 'A' کان 'Z' ڏانهن نقشه ڏنل آهن ، پر غير ASCII خط بدلايو نٿا وڃن.
    ///
    /// موجوده ۾ ھڪڙي کي بغير تبديل ڪرڻ جي لاءِ ھڪڙي جديد نقدي قيمت ڏانھن واپس ڪرڻ لاءِ ، [`to_ascii_uppercase()`] استعمال ڪريو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// انهي قسم کي ان جي ASCII هيٺين صورت ۾ برابر واري هنڌ ۾ تبديل ڪري ٿو.
    ///
    /// ASCII خط 'A' کان 'Z' 'a' کان 'z' ڏانهن نقشه ڏنل آهن ، پر غير ASCII خط بدلايو نٿا وڃن.
    ///
    /// موجوده ۾ ھڪڙي کي تبديل ڪرڻ کانسواءِ ھڪڙي نئون گھٽ قيمت کي واپس ڪرڻ لاءِ ، [`to_ascii_lowercase()`] استعمال ڪريو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// چيڪ ڪريو ته ويليو هڪ ASCII الفابيٽ وارو ڪردار آهي.
    ///
    /// - يو + 0041 'A' ..=يو + 005 اي 'Z' ، يا
    /// - يو + 0061 'a' ..=يو + 007 اي 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// چيڪ ڪريو جيڪڏهن ويليو يو ايس سي آئي اي پي جا وڏا اکر آهي:
    /// يو + 0041 'A' ..=يو + 005 اي 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// چيڪ ڪريو ته ويليو اي ايس سي آئي اي ننcaseو ڪردار آهي:
    /// يو + 0061 'a' ..=يو + 007 اي 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// چيڪ ڪريو ته ويليو ASCII الفابيٽڪڪ ڪردار آهي.
    ///
    /// - يو + 0041 'A' ..=يو + 005 اي 'Z' ، يا
    /// - يو + 0061 'a' ..=يو + 007 اي 'z' ، يا
    /// - يو + 0030 '0' ..=يو + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// چيڪ ڪريو ته ويليو اي ايس سي آئي آئي ڊيمل عددي آهي:
    /// يو + 0030 '0' ..=يو + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// چيڪ ڪريو جيڪڏهن ويليو اي ايس سي آئي آئي هيڪسڊيڪل ايجاد آهي.
    ///
    /// - يو + 0030 '0' ..=يو + 0039 '9' ، يا
    /// - يو + 0041 'A' ..=يو + 0046 'F' ، يا
    /// - يو + 0061 'a' ..=يو + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// چيڪ ڪريو ته ويليو اي ايس سي آئي اي ڪي چوڪسي وارو ڪردار آهي:
    ///
    /// - يو + 0021 ..=يو + 002F `! " # $ % & ' ( ) * + , - . /` ، يا
    /// - يو + 003A ..=U + 0040 `: ; < = > ? @` ، يا
    /// - يو + 005 بي ..=يو + 0060 "[\] ^ _" `` ، يا
    /// - يو + 007B ..=يو + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// چيڪ ڪريو جيڪڏهن ويليو يو ايس سي آئي گرافڪ ڪردار آهي.
    /// يو + 0021 '!' ..=يو + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// چيڪ ڪريو ته ويليو اي ايس سي آئي اي جي وائيٽ اسپيس ڪردار آهي:
    /// U + 0020 SPACE ، U + 0009 HORIZONTAL TAB ، U + 000A LINE FEED ، U + 000C FORM FEED ، يا U + 000D ڪيريٽري ريٽرن.
    ///
    /// Rust ڇا ڊبليو ڊبليو ڊبليو پيرا انفرا اسٽينڊ جو [definition of ASCII whitespace][infra-aw] استعمال ڪندو آهي.وسيع استعمال ۾ ڪيترائي ٻيون وضاحتون آهن.
    /// مثال طور ، [the POSIX locale][pct] ۾ U + 000B عمودي ٽيب ۽ سڀئي مٿي ڏنل حرف شامل آهن ، پر ساڳئي ساڳئي وضاحت مان ، [بورن shell ۾ "field splitting" لاءِ اصلي قاعدو][bfs] صرف * اسپيس ، هورزونل ٽيب ، ۽ لائن فائينڊ وائيٽ اسپيس وانگر.
    ///
    ///
    /// جيڪڏهن توهان هڪ پروگرام لکي رهيا آهيو جيڪو موجوده فائل فارميٽ کي پروسيس ڪندو ، چيڪ ڪريو ته فارميٽ جي ڪهڙي فارميشن جي تعريف هن فنڪشن کي استعمال ڪرڻ کان اڳ آهي.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// چيڪ ڪريو ته ويليو اي ايس سي آئي آئي ڪنٽرول ڪنٽرول ڪردار آهي:
    /// U + 0000 NUL ..=U + 001F يونٽ جدا ڪندڙ ، يا يو + 007 ايف خارج ڪريو.
    /// ياد رکو ته اڪثر اي ايس سي آئي وائيٽ اسپيس جا ڪردار ڪنٽرول ڪردار آهن ، پر SPACE ناهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// هڪ خام u32 قدر UTF-8 طور ڏنل بائيٽ بفر ۾ انڪوڊ ڪيو ، ۽ پوءِ بفر جو سبسائيس واپس اچي ٿو جيڪو انڪوڊ ٿيل ڪردار کي شامل ڪري ٿو.
///
///
/// `char::encode_utf8` جي برعڪس ، اهو طريقو پڻ واپسي واري حد ۾ ڪوڊ پوائنٽس کي هٿ ڪري ٿو.
/// (متبادل واري حد ۾ `char` ٺاھڻ يو بي آھي.) نتيجو صحيح آھي [generalized UTF-8] پر درست نه آھي UTF-8
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics جيڪڏهن بفر ڪافي وڏي نه آهي.
/// ڪنهن `char` کي انڪوڊ ڪرڻ لاءِ چار طول ڏيڻ وارو ڪافي وڏو آهي.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// هڪ خام u32 قدر UTF-16 طور فراهم ڪيو ويو آهي `u16` بفر ۾ ، ۽ پوء بفر جو ذيلي ذخيرو واپس ڏئي ٿو جيڪو انڪوڊ ٿيل ڪردار تي مشتمل آهي.
///
///
/// `char::encode_utf16` جي برعڪس ، اهو طريقو پڻ واپسي واري حد ۾ ڪوڊ پوائنٽس کي هٿ ڪري ٿو.
/// (ھڪڙو متبادل `char` ٺاھڻ جي حد ۾ يو بي آھي.)
///
/// # Panics
///
/// Panics جيڪڏهن بفر ڪافي وڏي نه آهي.
/// `char` کي ڳڻڻ لاءِ 2 جي هڪ بفر ڪافي وڏي آهي.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // حفاظت: هر هٿ چيڪ ڪري ٿو ته ڇا لکڻ لاءِ ڪافي ٽڪڙا آهن
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // بي ايم پي ذريعي ٿئي ٿي
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // ضمني جهاز سروگيچ ۾ داخل ٿيندا آهن.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}