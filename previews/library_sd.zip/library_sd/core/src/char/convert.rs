//! اکر جي conversير conversار.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// هڪ `u32` هڪ `char` ۾ بدلائي ٿو.
///
/// ياد رکو ته سڀ [چار`] صحيح آهن [u32`s ، ۽ هڪ کي ڪاسٽ ڪري سگھجي ٿو
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// بهرحال ، ريورس درست ناهي: سڀ صحيح [`u32`s] صحيح ناهي [`char`] s.
/// `from_u32()` جيڪڏهن انڊرڪس [`char`] لاءِ صحيح قيمت نه هجي ته واپسي آڻيندي `None`.
///
/// انهي فنڪشن جي غير محفوظ ورزن لاءِ جيڪو انهن چيڪن کي نظرانداز ڪري ٿو ، [`from_u32_unchecked`] کي ڏسو.
///
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// `None` واپس ڪرڻ جڏهن انٽيپ صحيح صحيح [`char`] ناهي:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// هڪ `u32` هڪ `char` ۾ بدلائي ٿو ، درستگي کي نظر انداز ڪرڻ.
///
/// ياد رکو ته سڀ [چار`] صحيح آهن [u32`s ، ۽ هڪ کي ڪاسٽ ڪري سگھجي ٿو
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// بهرحال ، ريورس درست ناهي: سڀ صحيح [`u32`s] صحيح ناهي [`char`] s.
/// `from_u32_unchecked()` هن کي نظرانداز ڪري ڇڏيندي ، ۽ انڌي طور تي [`char`] ڏانهن اڇلائي ، ممڪن طور هڪ غلط بڻجندڙ کي.
///
///
/// # Safety
///
/// اهو فنڪشن غير محفوظ آهي جئين اهو غلط `char` قدر ٺاهي سگھي ٿو.
///
/// هن فنڪشن جي محفوظ ورزن لاءِ ، ڏسو [`from_u32`] فنڪشن.
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // سافٽويئر: ڪالر کي گارنٽي ڏيڻ لازمي آھي `i` ھڪ صحيح چار ويلڊ آھي.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// هڪ [`char`] هڪ [`u32`] ۾ بدلائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// هڪ [`char`] هڪ [`u64`] ۾ بدلائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // چار کي ڪوڊ پوائنٽ جي قدر ڏانهن اڇليو ويندو آهي ، پوءِ صفر کي وڌايو ويو 64 بٽ تائين.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] ڏسو
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// هڪ [`char`] هڪ [`u128`] ۾ بدلائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // چار کي ڪوڊ پوائنٽ جي قدر ڏانهن ڪٽايو ويندو آهي ، پوءِ صفر وڌايو ويو 128 بيٽ تائين.
        // [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] ڏسو
        c as u128
    }
}

/// نقشو ٺاھيو ھڪڙي بائيٽ 0x00 ..=0xFF کي `char` ڏانھن جنھن جي ڪوڊ پوائنٽ جي ساڳي قيمت آھي ، U + 0000 ۾ ..=U + 00FF.
///
/// يونيڪوڊ اهڙو ڊزائن ڪيو ويو آهي جيڪو هن مؤثر انداز سان بائيٽ کي ڪوڊ انڪوڊنگ ڪري ٿو جيڪا آئي اين اي ISO-8859-1 سڏيندو آهي.
/// اهو انڪوڊنگ ASCII سان مطابقت رکي ٿي.
///
/// نوٽ ڪريو ته اهو ISO/IEC 8859-1 اڪيا کان مختلف آهي
/// ISO 8859-1 (هڪ گهٽ هائفن سان) ، جيڪو ڪجهه "blanks" ڇڏي ٿو ، بائيٽ جي قدر جيڪي ڪنهن به ڪردار سان منسوب نه ڪيا ويا آهن.
/// ISO-8859-1 (IANA one) انهن کي C0 ۽ C1 ڪنٽرول ڪوڊ لڳائيندو آهي.
///
/// ياد رهي ته هي پڻ * ونڊوز-1252 اڪا کان مختلف آهي
/// ڪوڊ صفحو 1252 ، جيڪو هڪ سپر سيٽ آهي ISO/IEC 8859-1 جيڪو ڪجهه (نه سڀ!) صفائي ۽ مختلف لاطيني اکرن کي خالي ڪري ٿو.
///
/// شين کي وڌيڪ الجھن ڏيڻ لاءِ ، [on the Web](https://encoding.spec.whatwg.org/) `ascii` ، `iso-8859-1` ، ۽ `windows-1252` سڀ هڪ ونڊوز 1252 جي هڪ سپر سيٽ جي لاءِ آهن جيڪي بچيل خالي نشانيون ڀرين ٿيون C0 ۽ C1 ڪنٽرول ڪوڊز سان.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// هڪ [`u8`] هڪ [`char`] ۾ بدلائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// هڪ غلطي جيڪا چار کي ختم ڪندي جڏهن واپس ڪري سگهجي ٿي.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // حفاظت: چيڪ ڪيو ته اهو قانوني يونيڪوڊ قدر آهي
            Ok(unsafe { transmute(i) })
        }
    }
}

/// غلطي جو قسم واپس اچي ويو جڏهن ايڪسينڪس کان چار ۾ تبديلي ناڪام ٿيندي.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// ھڪڙي عددي طور ايڪس ري ايڪسينڪس ۾ ھڪڙي عددي کي `char` ۾ تبديل ڪري ٿو.
///
/// هتي هڪ 'radix' ڪڏهن ڪڏهن 'base' پڻ سڏيو ويندو آهي.
/// ٻن جو ريڊڪس هڪ بائنري نمبر ، ڏهه ريڊيڪس ، ۽ ڇهه ، ريڪسڪس ، ريڪسڪس هيڪسڊيڪل جي اشارو ڏئي ٿو ، ڪجهه عام قدر ڏيڻ لاءِ.
///
/// ثالث راڪس سپورٽ ڪيا آهن.
///
/// `from_digit()` ايڪس ايڪس ايڪس واپس آڻيندي جيڪڏهن ڏنل ريڊڪس ۾ انجيڪشن نه آهي.
///
/// # Panics
///
/// Panics جيڪڏهن ڏنو ويو ريڊڪسڪس 36 کان وڏو آهي.
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // ڊيمل 11 بيس 16 ۾ ھڪڙو عددي آھي
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// `None` واپس ڪرڻ جڏھن انجيٽ عددي نه آھي:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// وڏي ريڊڪس گزرڻ ، هڪ panic سبب ڪري رهيو آهي:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}