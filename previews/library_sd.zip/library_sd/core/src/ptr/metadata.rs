#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// پوائنٽر-قسم جو پوائنٽر ميٽ ڊيٽاتا مهيا ڪري ٿو.
///
/// # پوائنٽر ميٽااتا
///
/// Rust ۾ خام پوائنٽر جا قسم ۽ حوالا ڏيڻ جا قسم ٻن حصن مان ٺهيل سمجھي سگھجن ٿا.
/// هڪ ڊيٽا پوائنٽر جنهن ۾ قدر جي يادگيري ايڊريس ۽ ڪجهه ميٽا ڊيٽا شامل آهن.
///
/// جامد قسم جي قسمن لاءِ (جيڪي `Sized` traits لاڳو ڪندا آهن) ۽ `extern` جي قسمن لاءِ ، اشارو ڏيندڙن کي `پتلا` چيو ويندو آهي: ميٽادا صفر طول وارا آهن ۽ هن جو قسم `()` آهي.
///
///
/// [dynamically-sized types][dst] ڏانهن اشارو ڏيندڙن کي `وسيع` يا `چربو` چيو وڃي ٿو ، انهن وٽ غير صفر وارا ميٽااتا آهن:
///
/// * انهي جوڙجڪ لاءِ جن جي آخري فيلڊ ڊي ٽي ايس آهي ، آخري ميدان لاءِ ميٽا ڊيٽا آهي
/// * `str` قسم لاءِ ، ميٽادا بائٽس ۾ `usize` جي طور تي ڊيگهه آهي
/// * ٻليءَ وارن قسمن وانگر `[T]` ، ميٽادا وارن شين جيتري آهي `usize`
/// * trait شين وانگر `dyn SomeTrait` لاءِ ، ميٽاداتا [`DynMetadata<Self>`][DynMetadata] آھي (مثال طور `DynMetadata<dyn SomeTrait>`)
///
/// future ۾ ، Rust ٻولي نئين قسم جا حصا حاصل ڪري سگھي ٿي جيڪي مختلف پوائنٽر ميٽاادا آھن.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// هن trait جو نقشو ان جي `Metadata` جڙيل قسم آهي ، جيڪو مٿي بيان ڪيل آهي `()` يا `usize` يا `DynMetadata<_>`.
/// اهو پاڻمرادو هر قسم لاءِ لاڳو ڪيو ويندو آهي.
/// اهو عام طور تي ترتيب ڏيڻ وارو فرض ٿي سگھي ٿو ، ساڳئي حد تائين بغير.
///
/// # Usage
///
/// خام پوائنٽرن کي انهن جي [`to_raw_parts`] طريقي سان ڊيٽا جي ايڊريس ۽ ميٽادا حصن ۾ مايوس ڪري سگهجي ٿو.
///
/// متبادل طور تي ، صرف ميٽاادا کي [`metadata`] فنڪشن سان ڪ canي سگهجي ٿو.
/// هڪ حوالو [`metadata`] ڏانهن منتقل ڪري سگھجي ٿو ۽ اڻ سڌي طرح زبردستي ڪيو ويو.
///
/// هڪ (possibly-wide) پوائنٽر ان جي ايڊريس ۽ ميٽاادا کان [`from_raw_parts`] يا [`from_raw_parts_mut`] سان گڏ واپس رکي سگھجن ٿا.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// پوائنٽ ۾ حوالن ۽ `Self` جي حوالي سان ميٽاادا جو قسم
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata` ۾ trait حدون رکو
    //
    // `library/core/src/ptr/metadata.rs` ۾ انهن سان هتي هم وقت سازي ۾:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// هن trait عرف کي لاڳو ڪرڻ وارن طرف اشارو ڏيندڙ `پتلا` آهن.
///
/// ھن ۾ جامد-`سائيز` جا قسم ۽ `extern` قسم شامل آھن.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait عرف ۾ ٻولي کي مستحڪم ٿيڻ کان پهريان انهي کي مستحڪم نٿا ڪريو؟
pub trait Thin = Pointee<Metadata = ()>;

/// پوائنٽر جي ميٽا ڊيٽا جو حصو ڪو.
///
/// `*mut T` ، `&T` ، يا `&mut T` قسم جا قدر سڌي طرح هن فنڪشن ڏانهن وڃي سگھجن ٿا جئين اهي لازمي طور تي `* const T` تي مجبور ٿين ٿيون.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // حفاظت: ايڪس ايڪس اين ايڪس يونين تان قدر رسائي حاصل ڪرڻ کان محفوظ آهي * const T
    // ۽ پيٽر ڪمپونز<T>ساڳيا ياداشت جون جوڙيون آھن.
    // صرف std اها گارنٽي ڏئي سگهي ٿي.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// ھڪڙي ڊيٽا ايڊريس ۽ ميٽا ڊيٽا مان (possibly-wide) خام پوائنٽر ٺاھي ٿو.
///
/// ھي فنڪشن محفوظ آھي پر واپس موٽندڙ پوائنٽ ھجڻ گھرجي لازمي طور تي گھٽ ڪرڻ نه آھي.
/// سلائسس لاءِ ، حفاظت جي ضرورتن لاءِ [`slice::from_raw_parts`] جي دستاويز ڏسو.
/// trait وارين شين لاءِ ، ميٽاادا هڪ هيٺيان اڏيل قسم ڏانهن پوائنٽر کان اچڻ لازمي آهي.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // حفاظت: ايڪس ايڪس اين ايڪس يونين تان قدر رسائي حاصل ڪرڻ کان محفوظ آهي * const T
    // ۽ پيٽر ڪمپونز<T>ساڳيا ياداشت جون جوڙيون آھن.
    // صرف std اها گارنٽي ڏئي سگهي ٿي.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// [`from_raw_parts`] وانگر ساڳئي ڪارڪردگي انجام ڏيندو آهي ، انهي کان سواء هڪ خام `*mut` پوائنٽر موٽي وئي آهي ، انهي جي مقابلي ۾ خام `* const` پوائنٽر جي مخالفت
///
///
/// وڌيڪ تفصيل لاءِ [`from_raw_parts`] جي دستاويز ڏسو.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // حفاظت: ايڪس ايڪس اين ايڪس يونين تان قدر رسائي حاصل ڪرڻ کان محفوظ آهي * const T
    // ۽ پيٽر ڪمپونز<T>ساڳيا ياداشت جون جوڙيون آھن.
    // صرف std اها گارنٽي ڏئي سگهي ٿي.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// دستي امپ ايڪس ايڪس باڪس کان بچڻ لاءِ گهربل.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// دستي امپ ايڪس ايڪس باڪس کان بچڻ لاءِ گهربل.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait اعتراض جي قسم لاءِ ميٽادا.
///
/// اهو هڪ ويڪبل (پوائنٽ ڪال ٽيبل) ڏانهن اشارو ڪندڙ آهي جيڪو trait اعتراض جي اندر محفوظ ٿيل ڪنڪريٽ جو قسم هٿ ڪرڻ لاءِ سڀني ضروري معلومات جي نمائندگي ڪندو آهي.
/// ويتبل ۾ ان تي مشتمل آهي:
///
/// * قسم جو ماپ
/// * قسم جي ترتيب
/// * قسم جي `drop_in_place` impl ڏانهن ھڪڙي پوائنٽر (شايد پراڻي پراڻي ڊيٽا لاءِ ڪا به اوپي)
/// * اشارو trait جي قسم جي عمل لاءِ سڀني طريقن ڏانهن اشارو ڪيو
///
/// نوٽ ڪريو ته پهرين ٽي خاص آھن ڇو ته اھي ڪنھن trait اعتراض کي مختص ڪرڻ ، dropوٽو ۽ گھٽائڻ ضروري آھن.
///
/// ھن اڏاوت کي ھڪڙي قسم جي پيراگراف سان نالو ڏيڻ ممڪن آھي جيڪو `dyn` trait اعتراض نه ھجي (مثال طور `DynMetadata<u64>`) پر انھيءَ ٺاھ جوڙ واري معنى قدر حاصل ڪرڻ لاءِ ناھي.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// سڀني vtables جو عام اڳڪٿي.اهو trait طريقن جي فنڪشن پوائنٽرن جي پٺيان آهي.
///
/// `DynMetadata::size_of` وغيره جي نجي عمل درآمد جو تفصيل.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// ھن ٽيبل سان لاڳاپيل قسم جي سائيز کي واپس ڪري ٿو.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// ھن ويتبل سان جڙيل قسم جي سازشن کي واپس آڻيندي.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// `Layout` سان گڏ سائيز ۽ ترتيب کي واپس آڻيندي
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SAFETY: ترتيب ڏيڻ وارو اهو ڪمبل Rust قسم لاءِ استعمال ڪري ٿو
        // layoutاتل سڃاتل آھي صحيح ترتيب.`Layout::for_value` ۾ ساڳيو منطق.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// ايڪسڪسيمڪس حدن کان بچڻ لاءِ دستي معني ۾ گهربل آهي.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}