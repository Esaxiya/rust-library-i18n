use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// هڪ ريپر هڪ خام غير نيل ايڪس `*mut T` جي ڀرسان انهي ڳالهه جي اشارو ڪندي ته انهي ريپر جو مالڪ حوالو جو مالڪ آهي.
/// `Box<T>` ، `Vec<T>` ، `String` ، ۽ `HashMap<K, V>` جھڙن عمارتن جي تعمير لاءِ ڪارائتو.
///
/// `*mut T` جي برعڪس ، `Unique<T>` ڪم ڪري ٿو "as if" اھو ھڪڙو `T` جو ھڪڙو مثال ھو.
/// اهو لاڳو ڪري ٿو `Send`/`Sync` جيڪڏهن `T` `Send`/`Sync` آهي.
/// اهو به ظاهر ڪري ٿو ته قسم جي مضبوط Aliasing جي ضمانت ڏئي ٿو `T` جو مثال توقع ڪري سگهي ٿو:
/// پوائنٽر جي حوالي کي پنھنجي مالڪ جي انفراديت کانسواءِ ھڪڙي خاص رستي کانسواءِ تبديل نه ڪرڻ گھرجي.
///
/// جيڪڏھن توھان پڪ سان ناھي ته ڇا `Unique` توھان جي مقصدن لاءِ استعمال ڪرڻ صحيح آھي ، `NonNull` استعمال ڪرڻ تي غور ڪريو ، ان وٽ وزن ڪمزور آھي.
///
///
/// `*mut T` جي نسبت ، پوائنٽر هميشه ھلائڻ گھرجي ، جيتوڻيڪ پوائنٽر ڪڏهن به تعريف نه ڪندو آھي.
/// اهو ائين آهي ته جيئن اينيمس حرام ممنوع قيمت استعمال ڪري سگهندي ـ X `Option<Unique<T>>` X وٽان ساڳي سائيز آهي `Unique<T>`.
/// تنهن هوندي به پوائنٽر شايد بي دخل ڪري سگهي ٿو جيڪڏهن اهو تعريف نه ڪيو وڃي.
///
/// `*mut T` جي نسبت ، `Unique<T>` `T` کان وڌيڪ وڳوڙ آھي.
/// اهو هميشه ڪنهن به قسم جي لاءِ صحيح هئڻ گهرجي جيڪو يونيڪ جي عليحدگيءَ جي گهرج کي برقرار رکي ٿو.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: هن مارڪر وٽ وهنجڻ لاءِ ڪو نتيجو ناهي ، پر ضروري آهي
    // انهي سمجهه لاءِ ته ڇا اسان منطقي طور تي `T` جو مالڪ آهيون.
    //
    // تفصيل لاءِ ، ڏسو:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` اشارو `Send` آهن جيڪڏهن `T` `Send` آهي ڇاڪاڻ ته اهي ڊيٽا جيڪي انهن جو حوالو ڏيو غير معياري آهي.
/// نوٽ ڪيو ته هي ختم ٿيڻ وارو ٻروچ قسم جي سسٽم طرفان ناقابل آهي.تجديد `Unique` استعمال ڪندي ان کي لاڳو ڪرڻ گهرجي.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` اشارو `Sync` آهن جيڪڏهن `T` `Sync` آهي ڇاڪاڻ ته اهي ڊيٽا جيڪي انهن جو حوالو ڏيو غير معياري آهي.
/// نوٽ ڪيو ته هي ختم ٿيڻ وارو ٻروچ قسم جي سسٽم طرفان ناقابل آهي.تجديد `Unique` استعمال ڪندي ان کي لاڳو ڪرڻ گهرجي.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// هڪ نئون `Unique` ٺاهي ٿو جيڪو خلل آهي ، پر سٺي ترتيب.
    ///
    /// اهو قسم شروع ڪرڻ لاءِ ڪارائتو آهي جيڪو سست طريقي سان ورهائي ٿو ، جهڙوڪ `Vec::new` ڪندو آهي.
    ///
    /// ياد رکو ته پوائنٽر ويليو ممڪن طور تي `T` ڏانهن صحيح پوائنٽر جي نمائندگي ڪري سگھي ٿو ، جنهن جو مطلب اهو لازمي طور تي "not yet initialized" سينسليل قدر طور استعمال نه ڪيو وڃي.
    /// اقسام جيڪي سست طريقي سان مختص ڪندا آهن ڪنهن نه ڪنهن ٻئي طريقي سان شروعاتي طرف جڙڻ لازمي آهن
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // حفاظت: mem::align_of() هڪ صحيح ، بغير نڪ جي پوائنٽر جي واپسي ڪري ٿو.جي
        // new_unchecked() کي ڪال ڪرڻ واري شرطن جو اهو احترام ڪيو وڃي ٿو.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// هڪ نئون `Unique` ٺاهي ٿو.
    ///
    /// # Safety
    ///
    /// `ptr` غير جانبدار هجڻ ضروري آهي.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // حفاظت: ڪال ڪرڻ واري کي گارنٽي ڏيڻ گهرجي ته `ptr` غير ٺهيل آهي.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// ھڪڙو نئون `Unique` ٺاھي ٿو جيڪڏھن `ptr` غيرلول آھي.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // حفاظت: پوائنٽر اڳ ۾ ئي جانچ ڪئي وئي آھي ۽ خالي ناھي.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// بنيادي `*mut` پوائنٽر حاصل ڪري ٿو.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// مواد کي رد ڪري ٿو.
    ///
    /// نتيجو ڪ lifڻ وارو زندگي پاڻ تي پابند آهي ان ڪري اهو "as if" کي روبرو ڪري ٿو اهو اصل ۾ هڪ ٽي جو مثال هو جيڪو قرض وٺندي رهي آهي.
    /// جيڪڏهن وڌيڪ (unbound) جي زندگي جي ضرورت آهي ، `&*my_ptr.as_ptr()` استعمال ڪريو.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // سافٽويئر: ڪالر کي گارنٽي ڏيڻ گھرجي ته `self` سڀني سان ملڻ
        // حوالي لاءِ گهربل
        unsafe { &*self.as_ptr() }
    }

    /// گڏيل مواد کي ختم ڪري ٿو.
    ///
    /// نتيجو ڪ lifڻ وارو زندگي پاڻ تي پابند آهي ان ڪري اهو "as if" کي روبرو ڪري ٿو اهو اصل ۾ هڪ ٽي جو مثال هو جيڪو قرض وٺندي رهي آهي.
    /// جيڪڏهن وڌيڪ (unbound) جي زندگي جي ضرورت آهي ، `&mut *my_ptr.as_ptr()` استعمال ڪريو.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // سافٽويئر: ڪالر کي گارنٽي ڏيڻ گھرجي ته `self` سڀني سان ملڻ
        // قابل تبديلي حوالا جي ضرورت
        unsafe { &mut *self.as_ptr() }
    }

    /// ٻئي قسم جي پوائنٽر ڏانهن اڇلائي ٿو.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // حفاظت: Unique::new_unchecked() ھڪڙو نئون منفرد ٺاھيندو آھي ۽ ضرورت پوندي
        // ڏنل پوائنٽر خالي نه هئڻ لاءِ.
        // جئين اسان پنهنجو پاڻ کي پوائنٽر طور تبديل ڪري رهيا آهيون ، اهو صحيح نٿو ٿي سگهي.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // حفاظت: هڪ متغير حوالو خالي نه ٿو ڪري سگهجي
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}