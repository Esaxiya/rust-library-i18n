use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` پر غير صفر ۽ لاڳاپي وارو.
///
/// اهو اڪثر استعمال ٿيندڙ صحيح شيءَ آهي جڏهن ڊيٽا جي اڏاوتن کي خام پوائنٽرن جو استعمال ڪندي ٺاهيو وڃي ، پر آخرڪار ان جي اضافي خاصيتن جي ڪري استعمال ڪرڻ وڌيڪ خطرناڪ آهي.جيڪڏهن توهان پڪ ناهي ته جيڪڏهن توهان `NonNull<T>` استعمال ڪرڻ گهرجي ، صرف `*mut T` استعمال ڪريو!
///
/// `*mut T` جي نسبت ، پوائنٽر هميشه ھلائڻ گھرجي ، جيتوڻيڪ پوائنٽر ڪڏهن به تعريف نه ڪندو آھي.اهو ائين آهي ته جيئن اينيمس حرام ممنوع قدر استعمال ڪري سگهندي ايڏي ڌارئين طور تي-`Option<NonNull<T>>` وٽ `* mut T` جي ساڳي سائيز آهي.
/// تنهن هوندي به پوائنٽر شايد بي دخل ڪري سگهي ٿو جيڪڏهن اهو تعريف نه ڪيو وڃي.
///
/// `*mut T` جي نسبت ، `NonNull<T>` کي `T` کان وڌيڪ محتاط ٿي چونڊيو ويو.اهو ممڪن بڻائي ٿو ايڪس `NonNull<T>` 3 استعمال ڪرڻ وقت جڏهن covariant قسمون ٺاهيون وڃن ، پر بي بنياد جي خطري کي متعارف ڪرايو جيڪڏهن هڪ قسم ۾ استعمال ڪيو وڃي جيڪا اصل ۾ covariant نه هجڻ گهرجي.
/// (`*mut T` لاء سامهون واري چونڊ ڪئي وئي هئي جيتوڻيڪ ٽيڪنالاجي طور غير محفوظ ڪم جي ڪري بي قاعدي صرف ٿي سگهي ٿي.)
///
/// گهڻيون محفوظ ڪيل تصورن لاءِ ڪوورنس صحيح آهي ، جهڙوڪ `Box` ، `Rc` ، `Arc` ، `Vec` ، ۽ `LinkedList`.اهو معاملو آهي ڇاڪاڻ ته اهي عوامي API فراهم ڪن ٿيون جيڪي Rust جي عام شيئر واري مباحثي واري ضابطي جي پيروي ڪن ٿيون.
///
/// جيڪڏهن توهان جو قسم محفوظ طور تي جهانگائي نه ٿو سگهجي ، توهان کي لازمي طور تي طئي ڪرڻ لاءِ ڪجهه اضافي ميدان کي يقيني بڻائڻ گهرجي.گهڻو ڪري ھي ميدان ھڪڙو [`PhantomData`] قسم جھڙو ٿيندو `PhantomData<Cell<T>>` يا `PhantomData<&'a mut T>`.
///
/// نوٽ ڪريو ته `NonNull<T>` وٽ `From` مثال آھي `&T`.تنهن هوندي ، اها حقيقت تبديل نه ڪندو آهي ته هڪ (شيئر ڪيل حوالو) ذريعي ميوٽيشن هڪ حوالي ڪيو ويو غير متعين رويو آهي جيستائين ايڪسٽيشن هڪ [`UnsafeCell<T>`] اندر نه ٿئي.اهو ساڳيو ئي گڏيل حوالن مان مٽيل ٺاهڻ واري حوالي سان ٿيندو آهي.
///
/// جڏهن `UnsafeCell<T>` کان بغير `UnsafeCell<T>` مثال استعمال ڪريو ، اهو توهان جي ذميواري آهي ته `as_mut` ڪڏهن به نه سڏيو ويندو ، ۽ `as_ptr` ڪڏهن به ميوٽيشن لاءِ استعمال ناهي ٿيندو.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` اشارو `Send` نه آھن ڇاڪاڻ ته جيڪو ڊيٽا آھي اھي حوالو ڏين ٿا.
// اين بي ، هي لاڳو غير ضروري آهي ، پر بهتر غلط پيغام فراهم ڪرڻ گهرجي.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` اشارو `Sync` نه آھن ڇاڪاڻ ته جيڪو ڊيٽا آھي اھي حوالو ڏين ٿا.
// اين بي ، هي لاڳو غير ضروري آهي ، پر بهتر غلط پيغام فراهم ڪرڻ گهرجي.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// هڪ نئون `NonNull` ٺاهي ٿو جيڪو خلل آهي ، پر سٺي ترتيب.
    ///
    /// اهو قسم شروع ڪرڻ لاءِ ڪارائتو آهي جيڪو سست طريقي سان ورهائي ٿو ، جهڙوڪ `Vec::new` ڪندو آهي.
    ///
    /// ياد رکو ته پوائنٽر ويليو ممڪن طور تي `T` ڏانهن صحيح پوائنٽر جي نمائندگي ڪري سگھي ٿو ، جنهن جو مطلب اهو لازمي طور تي "not yet initialized" سينسليل قدر طور استعمال نه ڪيو وڃي.
    /// اقسام جيڪي سست طريقي سان مختص ڪندا آهن ڪنهن نه ڪنهن ٻئي طريقي سان شروعاتي طرف جڙڻ لازمي آهن
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // سافٽويئر: mem::align_of() نا-زيرو ڪي يوز موٽائي ٿو جيڪو پوءِ اڇلايو وڃي ٿو
        // هڪ * mut T. ڏانهن
        // تنهن ڪري ، ايڪس سيڪس خالي ناهي ۽ new_unchecked() کي سڏڻ جي شرطن جو احترام ڪيو وڃي ٿو.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// ويليو کي ھڪ مشترڪ حوالو ڏئي ٿو.[`as_ref`] جي برعڪس ، انهي جي ضرورت ناهي ته قدر شروع ٿيڻ گهرجي.
    ///
    /// مٽائڻ واري هم منصب لاءِ [`as_uninit_mut`] ڏسو.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// هن طريقي کي سڏڻ وقت ، توهان کي تسليم ڪرڻو پوندو ته هيٺ ڏنل سڀ صحيح آهن:
    ///
    /// * پوائنٽر کي صحيح طور تي قطار سان لڳائڻ لازمي آھي.
    ///
    /// * [the module documentation] ۾ بيان ڪيل معنى ۾ "dereferencable" هجڻ گھرجي.
    ///
    /// * توهان لازمي طور تي Rust جي علیحدگي واري ضابطن کي لاڳو ڪيو وڃي ، ڇاڪاڻ ته واپسي واري حياتي `'a` صوابدید سان چونڊيو ويو آهي ۽ ضروري طور تي ڊيٽا جي حقيقي زندگي کي ظاهر نٿو ڪري.
    ///
    ///   خاص طور تي ، هن حياتي جي عرصي تائين ، ياداشت ڏانهن اشارو ڪندڙ نقاط لازمي طور تي موٽي نه هئڻ گهرجي (سواء ايڪس ايڪس ايڪس جي اندر)
    ///
    /// انهي تي به لاڳو ٿئي ٿي جيتوڻيڪ هن طريقي جو نتيجو اڻ استعمال ٿيل آهي!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // سافٽويئر: ڪالر کي گارنٽي ڏيڻ گھرجي ته `self` سڀني سان ملڻ
        // حوالي لاءِ گهربل
        unsafe { &*self.cast().as_ptr() }
    }

    /// قدر لاءِ منفرد حوالو ڏئي ٿو.[`as_mut`] جي برعڪس ، انهي جي ضرورت ناهي ته قدر شروع ٿيڻ گهرجي.
    ///
    /// حصيداري هم منصب لاءِ ايڪس ايڪس ايڪس ڏسو.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// هن طريقي کي سڏڻ وقت ، توهان کي تسليم ڪرڻو پوندو ته هيٺ ڏنل سڀ صحيح آهن:
    ///
    /// * پوائنٽر کي صحيح طور تي قطار سان لڳائڻ لازمي آھي.
    ///
    /// * [the module documentation] ۾ بيان ڪيل معنى ۾ "dereferencable" هجڻ گھرجي.
    ///
    /// * توهان لازمي طور تي Rust جي علیحدگي واري ضابطن کي لاڳو ڪيو وڃي ، ڇاڪاڻ ته واپسي واري حياتي `'a` صوابدید سان چونڊيو ويو آهي ۽ ضروري طور تي ڊيٽا جي حقيقي زندگي کي ظاهر نٿو ڪري.
    ///
    ///   خاص طور تي ، ھن حياتيءَ جي عرصي تائين ، ياد رکڻ لاءِ پوائنٽر پوائنٽس لازمي طور تي پھچ (ٻئي يا پوائنٽر) ذريعي پھچڻ نه گھرجي.
    ///
    /// انهي تي به لاڳو ٿئي ٿي جيتوڻيڪ هن طريقي جو نتيجو اڻ استعمال ٿيل آهي!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // سافٽويئر: ڪالر کي گارنٽي ڏيڻ گھرجي ته `self` سڀني سان ملڻ
        // حوالي لاءِ گهربل
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// هڪ نئون `NonNull` ٺاهي ٿو.
    ///
    /// # Safety
    ///
    /// `ptr` غير جانبدار هجڻ ضروري آهي.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // حفاظت: ڪال ڪرڻ واري کي گارنٽي ڏيڻ گهرجي ته `ptr` غير ٺهيل آهي.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// ھڪڙو نئون `NonNull` ٺاھي ٿو جيڪڏھن `ptr` غيرلول آھي.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // حفاظت: پوائنٽر اڳ ۾ ئي جانچيل آھي ۽ خالي ناھي
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// [`std::ptr::from_raw_parts`] وانگر ساڳئي ڪارڪردگي انجام ڏئي ٿو ، انهي کان سواء هڪ `NonNull` پوائنٽر واپس آهي ، خام `*const` پوائنٽر جي مخالفت.
    ///
    ///
    /// وڌيڪ تفصيل لاءِ [`std::ptr::from_raw_parts`] جي دستاويز ڏسو.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // حفاظت: `ptr::from::raw_parts_mut` جو نتيجو غير مهل آهي ڇاڪاڻ ته `data_address` آهي.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// بيان ڪريو (ممڪن طور تي وسيع) ھڪڙي پوائنٽر پتي ۽ ميٽادا حصن ۾ شامل آھي.
    ///
    /// پوائنٽر بعد ۾ تعمير ڪري سگھجي ٿو [`NonNull::from_raw_parts`] سان.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// بنيادي `*mut` پوائنٽر حاصل ڪري ٿو.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// ويليو کي ھڪ مشترڪ حوالو ڏئي ٿو.جيڪڏهن قدر ناقابل ابتدائي ٿي سگھي ٿي ، [`as_uninit_ref`] بدران استعمال ڪيو وڃي.
    ///
    /// مٽائڻ واري هم منصب لاءِ [`as_mut`] ڏسو.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// هن طريقي کي سڏڻ وقت ، توهان کي تسليم ڪرڻو پوندو ته هيٺ ڏنل سڀ صحيح آهن:
    ///
    /// * پوائنٽر کي صحيح طور تي قطار سان لڳائڻ لازمي آھي.
    ///
    /// * [the module documentation] ۾ بيان ڪيل معنى ۾ "dereferencable" هجڻ گھرجي.
    ///
    /// * پوائنٽر کي `T` جي ھڪڙي شروعاتي مثال ڏانهن اشارو ڪرڻ گھرجي.
    ///
    /// * توهان لازمي طور تي Rust جي علیحدگي واري ضابطن کي لاڳو ڪيو وڃي ، ڇاڪاڻ ته واپسي واري حياتي `'a` صوابدید سان چونڊيو ويو آهي ۽ ضروري طور تي ڊيٽا جي حقيقي زندگي کي ظاهر نٿو ڪري.
    ///
    ///   خاص طور تي ، هن حياتي جي عرصي تائين ، ياداشت ڏانهن اشارو ڪندڙ نقاط لازمي طور تي موٽي نه هئڻ گهرجي (سواء ايڪس ايڪس ايڪس جي اندر)
    ///
    /// انهي تي به لاڳو ٿئي ٿي جيتوڻيڪ هن طريقي جو نتيجو اڻ استعمال ٿيل آهي!
    /// (شروعاتي بڻجڻ بابت حصو اڃا تائين مڪمل طور تي طئي ڪونه ٿيو آهي ، پر جيستائين اهو نه آهي ، صرف محفوظ رستو اهو آهي ته هو يقينن ابتدائي طور تي شروع ڪن.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // سافٽويئر: ڪالر کي گارنٽي ڏيڻ گھرجي ته `self` سڀني سان ملڻ
        // حوالي لاءِ گهربل
        unsafe { &*self.as_ptr() }
    }

    /// قدر لاءِ منفرد حوالو ڏئي ٿو.جيڪڏهن قدر ناقابل ابتدائي ٿي سگھي ٿي ، [`as_uninit_mut`] بدران استعمال ڪيو وڃي.
    ///
    /// حصيداري هم منصب لاءِ ايڪس ايڪس ايڪس ڏسو.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// هن طريقي کي سڏڻ وقت ، توهان کي تسليم ڪرڻو پوندو ته هيٺ ڏنل سڀ صحيح آهن:
    ///
    /// * پوائنٽر کي صحيح طور تي قطار سان لڳائڻ لازمي آھي.
    ///
    /// * [the module documentation] ۾ بيان ڪيل معنى ۾ "dereferencable" هجڻ گھرجي.
    ///
    /// * پوائنٽر کي `T` جي ھڪڙي شروعاتي مثال ڏانهن اشارو ڪرڻ گھرجي.
    ///
    /// * توهان لازمي طور تي Rust جي علیحدگي واري ضابطن کي لاڳو ڪيو وڃي ، ڇاڪاڻ ته واپسي واري حياتي `'a` صوابدید سان چونڊيو ويو آهي ۽ ضروري طور تي ڊيٽا جي حقيقي زندگي کي ظاهر نٿو ڪري.
    ///
    ///   خاص طور تي ، ھن حياتيءَ جي عرصي تائين ، ياد رکڻ لاءِ پوائنٽر پوائنٽس لازمي طور تي پھچ (ٻئي يا پوائنٽر) ذريعي پھچڻ نه گھرجي.
    ///
    /// انهي تي به لاڳو ٿئي ٿي جيتوڻيڪ هن طريقي جو نتيجو اڻ استعمال ٿيل آهي!
    /// (شروعاتي بڻجڻ بابت حصو اڃا تائين مڪمل طور تي طئي ڪونه ٿيو آهي ، پر جيستائين اهو نه آهي ، صرف محفوظ رستو اهو آهي ته هو يقينن ابتدائي طور تي شروع ڪن.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // سافٽويئر: ڪالر کي گارنٽي ڏيڻ گھرجي ته `self` سڀني سان ملڻ
        // قابل تبديلي حوالا جي ضرورت
        unsafe { &mut *self.as_ptr() }
    }

    /// ٻئي قسم جي پوائنٽر ڏانهن اڇلائي ٿو.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // حفاظت: `self` هڪ `NonNull` پوائنٽر آهي جيڪو ضروري طور تي غير خالي آهي
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// ٿلهي پوائنٽر ۽ ڊيگهه کان هڪڙو نه خالي خام سلائس ٺاهي ٿو.
    ///
    /// `len` دليل **عناصر** جو تعداد آهي ، نه بائيٽ جو تعداد.
    ///
    /// اهو فنڪشن محفوظ آهي ، پر واپسي جي قيمت کي گهٽائڻ غير محفوظ آهي.
    /// ٻلي حفاظت جي گهرجين لاءِ [`slice::from_raw_parts`] جي دستاويز ڏسو.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // پهرين عنصر ڏانهن پوائنٽر سان شروع ڪرڻ دوران هڪ سلائس پوائنٽر ٺاهيو
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (نوٽ ڪريو ته هي مثال مصنوعي طريقي سان هن طريقي جي استعمال جو مظاهرو ڪري ٿو ، پر `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // حفاظت: `data` هڪ `NonNull` پوائنٽر آهي جيڪو ضروري طور تي غير خالي آهي
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// نه ختم ٿيندڙ خام سلائس جي ڊيگهه ڏي ٿو.
    ///
    /// واپسي واري قيمت **عناصر** جو تعداد آهي ، نه بائيٽ جو تعداد.
    ///
    /// اهو فنڪشن محفوظ آهي ، جڏهن ته اڻ صحيح خام سلائس کي سلائس جي سزا نه ڏني ويندي آهي ڇاڪاڻ ته پوائنٽر کي صحيح پتو نه هوندو آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// ھڪڙي غير نيل پوائنٽر کي سلائس جي بفر ڏانھن موٽائيندو آھي.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // حفاظت: اسان knowاڻون ٿا ته `self` غير ٺهيل آهي.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// خام پوائنٽر کي سلائس جي بفر ڏانھن موٽائيندو آھي.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// ھڪڙي حصيداري حوالو ڏئي ٿو ممڪن طور تي شروعاتي طور قدر ناھي.[`as_ref`] جي برعڪس ، انهي جي ضرورت ناهي ته قدر شروع ٿيڻ گهرجي.
    ///
    /// مٽائڻ واري هم منصب لاءِ [`as_uninit_slice_mut`] ڏسو.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// هن طريقي کي سڏڻ وقت ، توهان کي تسليم ڪرڻو پوندو ته هيٺ ڏنل سڀ صحيح آهن:
    ///
    /// * پوائنٽر `ptr.len()*mem::size_of::<T>()` کي `ptr.len()* mem::size_of::<T>()` گھڻن بائٽس جي لاءِ پڙھڻ گھرجي ، ۽ ان کي لازمي طور تي گڏ ڪرڻ لازمي آھي.هن جو مطلب خاص طور تي:
    ///
    ///     * هن سلائس جي مڪمل يادگيري هڪ ئي مختص ڪيل شيءَ جي اندر شامل ٿيڻ گهرجي!
    ///       سلائسون ڪيترن ئي مختص ڪيل شين ۾ شامل نه ٿيون ٿي سگهن.
    ///
    ///     * پوائنٽر صفر-ڊگھائي سلائسس لاءِ به برابر هجڻ گھرجي.
    ///     انهي جو هڪ سبب اهو آهي ته اينم ترتيب ترتيب ڏيڻ ، ڀاڙيندڙن تي انحصار ڪري سگهن ٿا (بشمول ڪنهن به ڊيگهه جي سلائس) ٻئي طرف ڊيٽا ڌار ڪرڻ جي لاءِ صف بندي ڪرڻ ۽ غير خالي هجڻ.
    ///
    ///     توهان هڪ پوائنٽر حاصل ڪري سگهو ٿا جيڪو [`NonNull::dangling()`] استعمال ڪندي صفر ڊگهي سلائسز لاء `data` طور قابل استعمال آهي.
    ///
    /// * سليس جي ڪل سائيز `ptr.len() * mem::size_of::<T>()` کان وڌيڪ نه هجڻ گهرجي `isize::MAX`.
    ///   [`pointer::offset`] جي حفاظت واري دستاويز کي ڏسو.
    ///
    /// * توهان لازمي طور تي Rust جي علیحدگي واري ضابطن کي لاڳو ڪيو وڃي ، ڇاڪاڻ ته واپسي واري حياتي `'a` صوابدید سان چونڊيو ويو آهي ۽ ضروري طور تي ڊيٽا جي حقيقي زندگي کي ظاهر نٿو ڪري.
    ///   خاص طور تي ، هن حياتي جي عرصي تائين ، ياداشت ڏانهن اشارو ڪندڙ نقاط لازمي طور تي موٽي نه هئڻ گهرجي (سواء ايڪس ايڪس ايڪس جي اندر)
    ///
    /// انهي تي به لاڳو ٿئي ٿي جيتوڻيڪ هن طريقي جو نتيجو اڻ استعمال ٿيل آهي!
    ///
    /// پڻ ڏسو [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // حفاظت: ڪال ڪندڙ کي `as_uninit_slice` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// ممڪن طور تي غير شروعاتي قدرن جي سليس ۾ ھڪ منفرد حوالو ڏئي ٿو.[`as_mut`] جي برعڪس ، انهي جي ضرورت ناهي ته قدر شروع ٿيڻ گهرجي.
    ///
    /// حصيداري هم منصب لاءِ ايڪس ايڪس ايڪس ڏسو.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// هن طريقي کي سڏڻ وقت ، توهان کي تسليم ڪرڻو پوندو ته هيٺ ڏنل سڀ صحيح آهن:
    ///
    /// * پوائنٽر `ptr.len()*mem::size_of::<T>()` پڙهڻ لاءِ ۽ `ptr.len()* mem::size_of::<T>()` گھڻن بائٽس لاءِ لازمي هجڻ گھرجي ، ۽ اھو لازمي طور تي گڏ ڪرڻ لازمي آھي.هن جو مطلب خاص طور تي:
    ///
    ///     * هن سلائس جي مڪمل يادگيري هڪ ئي مختص ڪيل شيءَ جي اندر شامل ٿيڻ گهرجي!
    ///       سلائسون ڪيترن ئي مختص ڪيل شين ۾ شامل نه ٿيون ٿي سگهن.
    ///
    ///     * پوائنٽر صفر-ڊگھائي سلائسس لاءِ به برابر هجڻ گھرجي.
    ///     انهي جو هڪ سبب اهو آهي ته اينم ترتيب ترتيب ڏيڻ ، ڀاڙيندڙن تي انحصار ڪري سگهن ٿا (بشمول ڪنهن به ڊيگهه جي سلائس) ٻئي طرف ڊيٽا ڌار ڪرڻ جي لاءِ صف بندي ڪرڻ ۽ غير خالي هجڻ.
    ///
    ///     توهان هڪ پوائنٽر حاصل ڪري سگهو ٿا جيڪو [`NonNull::dangling()`] استعمال ڪندي صفر ڊگهي سلائسز لاء `data` طور قابل استعمال آهي.
    ///
    /// * سليس جي ڪل سائيز `ptr.len() * mem::size_of::<T>()` کان وڌيڪ نه هجڻ گهرجي `isize::MAX`.
    ///   [`pointer::offset`] جي حفاظت واري دستاويز کي ڏسو.
    ///
    /// * توهان لازمي طور تي Rust جي علیحدگي واري ضابطن کي لاڳو ڪيو وڃي ، ڇاڪاڻ ته واپسي واري حياتي `'a` صوابدید سان چونڊيو ويو آهي ۽ ضروري طور تي ڊيٽا جي حقيقي زندگي کي ظاهر نٿو ڪري.
    ///   خاص طور تي ، ھن حياتيءَ جي عرصي تائين ، ياد رکڻ لاءِ پوائنٽر پوائنٽس لازمي طور تي پھچ (ٻئي يا پوائنٽر) ذريعي پھچڻ نه گھرجي.
    ///
    /// انهي تي به لاڳو ٿئي ٿي جيتوڻيڪ هن طريقي جو نتيجو اڻ استعمال ٿيل آهي!
    ///
    /// پڻ ڏسو [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // اهو محفوظ آهي جئين `memory` پڙهڻ لاءِ صحيح آهي `memory.len()` ڪيترن ئي بائٽس لاءِ.
    /// // ياد رکو ته `memory.as_mut()` کي ڪال ڪرڻ جي اجازت ناهي هتي اهو مواد غير ابتدائي ٿي سگھي ٿو.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // حفاظت: ڪال ڪندڙ کي `as_uninit_slice_mut` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// بغير پوائنٽ جي چڪاس ڪرڻ کان ، خام پوائنٽر کي هڪ عنصر يا سبسڪرس ڏانهن موٽائيندو آهي.
    ///
    /// هن طريقي کي ٻاهر-بند-انڊيڪس سان ڪال ڪرڻ يا جڏهن `self` قابل مذمت نه آهي * *[اڻ سڌريل رويو] * توڙي جو نتيجو ڪندڙ پوائنٽر استعمال نه ڪيو وڃي.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // حفاظت: سڏيندڙ کي يقيني بڻائي ٿو ته `self` قابل مذمت آهي ۽ `index` حدن ۾.
        // نتيجي طور ، نتيجو ڪندڙ اشارو NULL نٿو ٿي سگھي.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // حفاظت: هڪ انوکو پوائنٽر رد نه ٿو ڪري سگھجي ، انهي لاءِ حالتون
        // new_unchecked() قابل احترام آھن.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // حفاظت: هڪ متغير حوالو خالي نه ٿو ڪري سگهجي.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // حفاظت: هڪ حوالو خالي نه ٿو ٿي سگهي ، تنهن ڪري حالتون
        // new_unchecked() قابل احترام آھن.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}