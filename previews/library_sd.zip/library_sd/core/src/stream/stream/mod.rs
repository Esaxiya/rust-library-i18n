use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// عينڪ ايجادرز سان معاملو ڪرڻ لاءِ هڪ انٽرنيٽ.
///
/// ھي اھم وهڪرو trait آهي.
/// عام طور تي وهڪري جي تصور بابت وڌيڪ pleaseاڻ لاءِ مهرباني ڪري [module-level documentation] کي ڏسو.
/// خاص طور تي ، توهان کي toاڻڻ چاهيندا ته [implement `Stream`][impl] کان ڪئين.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// وهڪرو طرفان پيدا ڪيل شيون جي قسم.
    type Item;

    /// انهي وهڪري جي ايندڙ قيمت کي ڪ toڻ جي ڪوشش ڪريو ، ويهڻ لاءِ موجوده ڪم کي رجسٽر ڪرڻ جيڪڏهن قيمت اڃا موجود ناهي ، ۽ وهڪرو ختم ٿي ويو `None` جي واپسي.
    ///
    /// # واپسي جي قيمت
    ///
    /// هتي ڪيترائي ممڪن واپسي جا قدر آھن ، ھر ھڪڙي ھڪڙي الڳ وهڪرو جي حالت کي ظاھر ڪري ٿو.
    ///
    /// - `Poll::Pending` مطلب ته هن وهڪري جي ايندڙ قيمت اڃا تيار ناهي.عمل درآمد ان ڳالهه کي يقيني بڻائيندو ته موجوده ڪم کي اطلاع تڏهن ڏنو ويندو جڏهن ايندڙ قيمت تيار ٿي سگھي ٿي.
    ///
    /// - `Poll::Ready(Some(val))` ان جو مطلب آهي ته وهڪرو ڪاميابي سان قيمت پيدا ڪري چڪو آهي ، ايڪس ويڪس ، ۽ ايندڙ `poll_next` ڪالرن تي وڌيڪ قدر پيدا ڪري سگهي ٿو.
    ///
    /// - `Poll::Ready(None)` مطلب ته وهڪرو ختم ٿي ويو آهي ، ۽ ايڪس سيڪس کي ٻيهر ٻيهر مدعو نه ڪيو وڃي.
    ///
    /// # Panics
    ///
    /// هڪ ڀيرو وهڪرو ختم ٿي چڪو آهي (`Ready(None)` from `poll_next`) موٽي آيو آهي ، ان کي `poll_next` طريقو ٻيهر سڏجي ٿو panic ، سدائين بلاڪ ، يا ٻين قسمن جا مسئلا پيدا ڪري ٿو ؛ `Stream` trait ڪال جي اثرن تي ڪا به ضرورت ناهي
    ///
    /// تنهن هوندي ، جئين `poll_next` طريقو `unsafe` تي نشان لڳل نه آهي ، Rust جا معمولي قاعدو لاگو آهن: ڪالون ڪڏهن به اڻ سڌريل رويو (يادگيري ڪرپشن ، `unsafe` فنڪشن جو غلط استعمال ، يا انهي وانگر) سبب نه هجڻ ، ندي ندي جي اسٽيٽس جي.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// حد کي ڇڏي نديءَ جي باقي لمبائي تي.
    ///
    /// خاص طور تي ، `size_hint()` هڪ ٽپل ڏي ٿو جتي پهريون عنصر هيٺين حد تائين آهي ، ۽ ٻيو عنصر مٿين حد وارو آهي.
    ///
    /// ٻي جيڪا ٽاپيل موٽندي آهي اها [Option]] <<["استعمال ڪريو"]> آهي.
    /// هڪ [`None`] هتي مطلب آهي ته ، يا ته ڪوبه سڃاتو مٿاهين حد ناهي ، يا مٿيون پابند [`usize`] کان وڏي آهي.
    ///
    /// # پليجي نوٽ
    ///
    /// اهو لاڳو نه ڪيو ويو آهي ته هڪ وهڪرو لاڳو ٿيڻ عنصرن جو اعلان ڪيل تعداد پيدا ڪري ٿو.هڪ بگٽي وهڪرو شايد هيٺين حد کان گهٽ يا عناصر جي اوپري حد کان وڌيڪ جي پيداوار ٿي سگهي ٿي.
    ///
    /// `size_hint()` بنيادي طور تي ڪتب آڻڻ جي لاءِ استعمال ڪيو ويندو آهي جيئن ته نديءَ جي عناصر لاءِ جڳهه محفوظ ڪرڻ ، پر ڀروسو نه هجڻ لازمي آهي مثال طور ، غير محفوظ ڪوڊ ۾ بائونڊ چيڪ کي ختم ڪرڻ.
    /// `size_hint()` جي غلط عمل کي ياد رکڻ گهرجي حفاظت جي خلاف ورزي جي نتيجي ۾.
    ///
    /// اھو چيو آھي ، عملدرآمد کي صحيح اندازو لڳائڻ گھرجي ، ڇاڪاڻ تھ ٻي صورت ۾ اھو trait جي پروٽوڪول جي خلاف ورزي ھوندي.
    ///
    /// ڊفالٽ پلي واپسي موٽائي `(0،` [None `]`) جيڪا ڪنهن به وهڪرو لاءِ صحيح آهي.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}