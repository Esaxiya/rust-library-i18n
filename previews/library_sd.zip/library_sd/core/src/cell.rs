//! شيئر ڪرڻ جي قابل تبديلي ڪنٽينر.
//!
//! Rust ميموري حفاظت ھن قاعدي تي مبني آھي: ھڪڙي شي کي `T` ڏنو ، اھو ممڪن آھي صرف ھيٺ ڏنل ھجي.
//!
//! - اعتراض کي (`&T`) ڪيترن ئي بدقسمتي حوالن سان گڏ هجڻ (پڻ ** ** وڃڻ)).
//! - اعتراض کي هڪ قابل بدل حوالو ("&mut T")(پڻ ** ** ميٽيبلٽيشن) طور سڃاتو وڃي ٿو).
//!
//! اهو Rust ترتيب ڏيندڙ طرفان لاڳو ڪيل آهي.بهرحال ، اهڙيون حالتون آهن جتي هي ضابطو ڪافي لچڪدار نه آهي.ڪڏهن ڪڏهن اهو گهربل هوندو آهي ته ڪنهن شيءَ جا ڪيترائي حوالا هجن ۽ اڃا به ان کي ميوٽ ڪيو وڃي.
//!
//! شيئر ٿيندڙ قابل تبديل ڪنٽينرز موجود آهن طريقن سان ويچاري کي ڪنٽرول واري طريقي سان ، حتي عليٰ جي موجودگي ۾.ٻئي [`Cell<T>`] ۽ [`RefCell<T>`] هن ڪم کي هڪ ڪنو ويڊ ٿيل طريقي سان ڪرڻ جي اجازت ڏين ٿيون.
//! تنهن هوندي ، نه `Cell<T>` ۽ نه `RefCell<T>` سلسلي محفوظ آهن (اهي [`Sync`] لاڳو نٿا ڪن).
//! جيڪڏهن توهان ڪيترن ئي سلسلي جي وچ ۾ عليحدگي ۽ ميوٽيشن کي ڪرڻ جي ضرورت آهي ، اهو ممڪن آهي ته [`Mutex<T>`] ، [`RwLock<T>`] يا [`atomic`] قسم استعمال ڪريو.
//!
//! `Cell<T>` ۽ `RefCell<T>` قسم جا قدر حصيداري ڪيل حوالن ذريعي بدلجن ٿا (يعني
//! عام `&T` قسم) ، جڏهن ته اڪثر Rust قسمون صرف منفرد (&&mut T) ذريعي حوالن سان ملي سگھن ٿيون.
//! اسان اهو چوندا آهيون ته `Cell<T>` ۽ `RefCell<T>` عام Rust قسم جي مقابلي ۾ ، `داخلي تغيرات` فراهم ڪن ٿا ، جيڪي `وراثت واري متغيرات` کي ظاهر ڪن ٿا.
//!
//! سيل جا قسم ٻن ذائقن ۾ اچن ٿا: `Cell<T>` ۽ `RefCell<T>`.`Cell<T>` `Cell<T>` اندر ۽ ٻاهر منتقل ٿيندڙ قدر منتقل ڪندي داخلي تغيرات کي لاڳو ڪري ٿو.
//! قيمتن جي بدران حوالا استعمال ڪرڻ لاءِ ، هڪ کي `RefCell<T>` قسم استعمال ڪرڻ گهرجي ، ميوٽيشن کي لکڻ کان پهريان ليٽ لاڪ حاصل ڪرڻ.`Cell<T>` موجوده داخلي قدر کي واپس وٺڻ ۽ تبديل ڪرڻ جا طريقا مهيا ڪري ٿو:
//!
//!  - انهن قسمن لاءِ جيڪي [`Copy`] لاڳو ڪن ٿا ، [`get`](Cell::get) طريقو موجوده داخلي قدر کي واپس وٺي ٿو.
//!  - انهن قسمن جي لاءِ جيڪي [`Default`] لاڳو ڪن ٿا ، [`take`](Cell::take) طريقو موجوده گهرو قدر کي [`Default::default()`] سان تبديل ڪري ٿو ۽ بدلي واري قيمت ڏي ٿو.
//!  - سڀني قسمن جي لاءِ ، [`replace`](Cell::replace) طريقو موجوده داخلي قدر کي بدلائي ٿو ۽ بدلي واري قيمت کي واپس ٿو ڏي ۽ [`into_inner`](Cell::into_inner) جو طريقو `Cell<T>` کي استعمال ڪري ٿو ۽ داخلي جي قيمت کي واپس آڻي ٿو.
//!  وڌيڪ ، [`set`](Cell::set) طريقي سان داخلي قيمت کي متبادل بڻائي ٿو ، بدلي واري قيمت کي گھٽائي ٿو.
//!
//! `RefCell<T>` متحرڪ قرض ڏيڻ جي عمل لاءِ Rust's lifetime استعمال ڪندو آهي ، هڪ اهڙو عمل جنهن سان ڪو اندرين قدر جي عارضي ، خاص ، مٽيريل رسائي جي دعويٰ ڪري سگھي ٿو.
//! ريفيل لاءِ قرض وٺندا آهن<T>"s runtime" تي هليا ويا آهن ، Rust جي اصلي حوالن جي برعڪس جيڪي مڪمل طور تي جامد طريقي سان ٽريڪ ٿيل وقت تي.
//! ڇو ته `RefCell<T>` قرض وٺي متحرڪ آهن اهو ممڪن آهي ته قيمت وڃائڻ جي ڪوشش ڪئي وڃي جيڪا اڳ ۾ ئي قابل قبول قرضن تي هجي ؛جڏهن اهو ٿئي ٿو اهو نتيجو panic ۾ ڪري ٿو.
//!
//! # جڏهن چونڊڻ جي مرضي ڏي
//!
//! عام طور تي وراثت واري متڀيد ، جتي هڪ قيمت کي مٽائڻ لاءِ انفرادي رسائي هجڻ لازمي آهي ، اهم ٻولي عنصرن مان هڪ آهي ، جيڪو Rust کي پوائنٽر ايليسنگ بابت سخت دليل ڏيڻ جي قابل بنائي ٿو ، حادثاتي طور تي خرابين کي روڪڻ.
//! انهي جي ڪري ، وراثت واري حب الوطني کي ترجيح ڏني وڃي ٿي ، ۽ داخلي طور تي mutير aارگي آخري ترتيب جي شيءَ آهي
//! جئين سيل جا قسم ميوٽيشن کي چالو ڪن ٿا جتي ٻي صورت ۾ ان کي رد نه ڪيو وڃي ها ، اتي اهڙا موقعا هوندا آهن جڏهن داخلي مطابقت مناسب هجي يا اڃا به * لازمي استعمال ٿيڻ گهرجي.
//!
//! * تعريف ناممڪن شي جي ايڪس ايڪس ايڪس متعارف ڪرائڻ
//! * منطقي طور تي ناقابل منتقلي طريقن جي عمل درآمد جي تفصيل.
//! * [`Clone`] جي ميٽنگن کي لاڳو ڪرڻ.
//!
//! ## تعريف ناممڪن شي جي ايڪس ايڪس ايڪس متعارف ڪرائڻ
//!
//! ڪيترائي حصيداري سمارٽ پوائنٽر قسم ، بشمول [`Rc<T>`] ۽ [`Arc<T>`] ، ڪنٽينر مهيا ڪن ٿا جيڪي ڪيترن ئي پارٽين جي وچ ۾ ڪلون ۽ شئرنگ ٿين.
//! ڇاڪاڻ ته شامل ڪيل قيمتون ضرب الائيز ٿي سگھن ٿيون ، انهن کي صرف `&` سان قرض وٺي سگهجي ٿو ، نه `&mut`.
//! سيلن کانسواءِ اهو سمارٽ اشارن جي اندر ڊيٽا کي تبديل ڪرڻ ناممڪن هوندو.
//!
//! اهو گهڻو عام آهي پوءِ هڪ ڀروسي کي ٻيهر متعارف ڪرائڻ لاءِ ونڊيل پوائنٽر وارن قسمن ۾ `RefCell<T>` رکڻو پوندو.
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // متحرڪ قرضن جو دائرو محدود ڪرڻ جي لاءِ نئون بلاڪ ٺاهيو
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // اهو نوٽ ڪريو ته جيڪڏهن اسان اڳئين قرض کي ڪيش جي دائري کان ٻاهر نه وڃڻ ڏيو ها ته پوءِ ايندڙ قرض هڪ متحرڪ سلسلي panic جو سبب بڻجندو.
//!     //
//!     // ايڪس `RefCell` استعمال ڪرڻ جو اهو وڏو خطرو آهي.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! ياد رکجو ته اهو مثال `Rc<T>` استعمال ڪري ٿو ۽ نه `Arc<T>` کي.ريفيل<T>واحد ڏنڊي واري منظرنامي لاءِ آهن.غور ڪريو [`RwLock<T>`] يا [`Mutex<T>`] استعمال ڪريو جيڪڏھن توھان گھٽي موضوع ٿيل صورتحال ۾ حصيداري ڀروسي جي ضرورت آھي.
//!
//! ## منطقي طور تي ناقابل منتقلي طريقن جي عمل درآمد جي تفصيل
//!
//! ڪڏهن ڪڏهن اهو مناسب ٿي سگهي ٿو ته هڪ اي پي ۾ اجاگر نه ٿئي ها ته اتي موجود آهي ميوٽيڪس "under the hood".
//! اهو ٿي سگهي ٿو ڇاڪاڻ ته منطقي طور تي آپريشن ناقابل برداشت آهي ، پر مثال طور ، ڪيچنگ عمل درآمد کي ميوٽيشن ڏيڻ تي مجبور ڪري ٿو.يا ڇاڪاڻ ته توهان trait طريقي کي لاڳو ڪرڻ لاءِ ميوٽيشن کي لازمي طور استعمال ڪرڻو پوندو.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // قيمتي حساب هتي وڃي ٿو
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone` جي ميٽنگن کي لاڳو ڪرڻ
//!
//! اهو صرف اڳوڻي جو هڪ خاص ، پر عام ، ڪيس آهي: آپريشن لاءِ صلح پوشيده لڪائڻ جيڪي بظاهر حرڪت ۾ اچن ٿا.
//! [`clone`](Clone::clone) طريقو توقع ڪئي وئي آهي ته ذريعو جي قدر تبديل نه ڪئي وڃي ، ۽ `&self` وٺڻ جو اعلان ڪيو ويو آهي ، نه `&mut self`.
//! تنهن ڪري ، `clone` طريقي سان ڪنهن به ميوٽيشن کي سيل جي قسمن کي استعمال ڪرڻ گهرجي.
//! مثال طور ، [`Rc<T>`] هڪ `Cell<T>` اندر ان جي حوالن جي ڳڻپ کي برقرار رکي ٿو.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// هڪ مٽائيندڙ يادگار جڳھ.
///
/// # Examples
///
/// هن مثال ۾ ، توهان ڏسي سگهو ٿا ته `Cell<T>` ميوٽيشن کي هڪ مٽجڻ واري اڏاوت جي اندر فعال ڪري ٿو.
/// ٻين لفظن ۾ ، اهو "interior mutability" کي قابل بنائي ٿو.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ERROR: `my_struct` تبديل ٿيندڙ آھي
/// // my_struct.regular_field =نئين_ قيمت ؛
///
/// // ڪاروباريت: جيتوڻيڪ `my_struct` مٽائڻ وارو آهي ، `special_field` هڪ `Cell` آهي ،
/// // جيڪو هميشه متحرڪ به ٿي سگهي ٿو
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// وڌيڪ لاءِ [module-level documentation](self) ڏسو.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// `Cell<T>` ٺاهي ٿو ، `Default` قدر سان ٽي لاءِ.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// ڏنل قيمت تي مشتمل نئون `Cell` ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// شامل ٿيل قدر کي ترتيب ڏيو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// ٻن خاني جي قدر کي مٽايو.
    /// `std::mem::swap` سان فرق اهو آهي ته اهو فنڪشن `&mut` ريفرنس جي ضرورت ناهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // حفاظت: اهو خطرناڪ ٿي سگهي ٿو جيڪڏهن جدا جدا موضوعن مان سڏيا وڃن ، پر ايڪس ڪيوڪس
        // ايڪس X ايڪس آهي انهي ڪري اهو ناهي ٿيندو.
        // اهو پڻ ڪنهن به پوائنٽرن کي غلط نه ڪندو ڇاڪاڻ ته ايڪسڪسيمڪس انهي کي يقيني بڻائي ٿو ته ٻيو ڪجهه به انهي "سيل" ۾ اشارو نه ڪندي.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// `val` سان گڏ موجود ويليو کي بدلائي ٿو ، ۽ پراڻي موجود ويليو قيمت کي واپس ڏئي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // حفاظت: اهو ڊيٽا ريسز جو سبب بڻجي سگهي ٿو جيڪڏهن هڪ الڳ موضوع کان سڏيا وڃن ،
        // پر `Cell` آھي `!Sync` ، ائين ناھي ٿيندو.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// قدر نه لڙهي ٿو
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// قابل قدر قيمت جي ڪاپي موٽائيندو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // حفاظت: اهو ڊيٽا ريسز جو سبب بڻجي سگهي ٿو جيڪڏهن هڪ الڳ موضوع کان سڏيا وڃن ،
        // پر `Cell` آھي `!Sync` ، ائين ناھي ٿيندو.
        unsafe { *self.value.get() }
    }

    /// هڪ فنڪشن استعمال ڪندي شامل ٿيل قيمت کي تازه ڪاري ڪري ٿو ۽ نئين قيمت کي واپس آڻي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// هن سيل ۾ بنيادي ڊيٽا ڏانهن خام پوائنٽر کي واپس ڏئي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// واپسي واري ڊيٽا جي قابل aير referenceار واري واپسي ڏي.
    ///
    /// هي ڪال `Cell` کي ٻرندڙ طور تي قرض وٺي ٿو (ٽائيم وقت تي) جيڪو انهي جي ضمانت ڏي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&Cell<T>` کان `&Cell<T>` موٽائي ٿو
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // حفاظت: `&mut` ڌار ڌار رسائي کي يقيني بڻائي ٿي.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// سيل جي قيمت وٺندي آهي ، ايڪس ريڪس پنهنجي جڳهه تي ڇڏي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&[Cell<T>]` کان `&[Cell<T>]` موٽائي ٿو
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // حفاظتي: `Cell<T>` وٽ ھڪڙو ئي يادگيري واري ھڪڙي آھي `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// متحرڪ چيڪ ڪيل قرضن جي قاعدن سان هڪ تبديل ٿيندڙ يادگار مقام
///
/// وڌيڪ لاءِ [module-level documentation](self) ڏسو.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] پاران هڪ غلطي موٽائي وئي.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] پاران هڪ غلطي موٽائي وئي.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// مثبت قدر `Ref` فعال جي تعداد جي نمائندگي ڪن ٿا.منفي قدر `RefMut` فعال تعداد جي نمائندگي ڪن ٿا.
// گهڻن `ريفمٽ` صرف هڪ وقت ۾ فعال ٿي سگهي ٿي ، جيڪڏهن اهي هڪ `RefCell` جي مختلف ، غير اوورلوپنگ حصن جو حوالو ڏين (مثال طور ، هڪ سلائس جي مختلف حدن).
//
// `Ref` ۽ `RefMut` سائيز جا ٻه لفظ آهن ، ۽ انهي جي ڪري X1X جي اڌ جي اڌ کي اوورلو ڪرڻ لاءِ وجود ۾ ڪڏهن ڪڏهن ريفري يا ريفمٽ موجود نه هوندو.
// اهڙيء طرح ، `BorrowFlag` شايد ڪڏهن به فلو يا هيٺيان نه هوندو.
// تنهن هوندي ، هي ضمانت نه آهي جئين هڪ پيالوجيولوجي پروگرام بار بار ٺاهي سگهي ٿو ۽ پوءِ mem::forget Ref`s يا `RefMut`s.
// ان ڪري ، غير محفوظيت کان بچڻ لاءِ س codeو ڪوڊ واضح طور تي اوور فلو ۽ ان فلو کي جانچڻ لازمي آهي ، يا گهٽ ۾ گهٽ صحيح طريقي سان عمل ٿيڻ کپي جنهن کي اوور فلو يا ان فلو ڪيو وڃي (مثال طور ، ڏسو BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` تي مشتمل هڪ نئون `RefCell` ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell` کي وساري ٿو ، واپسي واري قيمت ڏي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // ڇاڪاڻ ته هي فنڪشن قدر جي ذريعي `self` (`RefCell`) وٺي ٿو ، مرتب ڪندڙ ان جي تصديق ڪري ٿو ته في الحال اهو قرض نه ورتو ويو آهي.
        //
        self.value.into_inner()
    }

    /// ريپيل ويليو کي نئين سان تبديل ڪري ٿو ، پراڻي ويل کي موٽائي ٿو ، بنا ڪنهن هڪ جي ترتيب ڏيڻ کان.
    ///
    ///
    /// اهو فنڪشن [`std::mem::replace`](../mem/fn.replace.html) سان ملي ٿو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت في الحال قرض ورتو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// `f` کان مرتب ڪيل نئين قيمت سان ريپيل قيمت واري جڳهه بدلائي ٿو ، پراڻي قدر موٽائي ، هڪڙي ٻئي کي ڊي سيز ڪرڻ کانسواءِ.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت في الحال قرض ورتو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `other` جي وڪري واري قيمت کي `other` جي ريپلي ويل قيمت سان مٽايو وڃي ، بغير ڪنهن کي ڊي ويو ڪرڻ کان سواءِ.
    ///
    ///
    /// اهو فنڪشن [`std::mem::swap`](../mem/fn.swap.html) سان ملي ٿو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت `RefCell` في الحال قبول ڪئي وئي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// لپي ويل قيمت کي ناجائز طور تي قرض وٺي ٿو.
    ///
    /// قرض ايستائين جاري آهي جيستائين واپسي `Ref` دائري کان ٻاهر نه وڃي.
    /// هڪ ئي وقت ۾ گهڻن ableيرorrار قرض ڪ canي سگهجي ٿو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت موجوده طور تي اسان جي قرض ورتي وئي آهي.
    /// بنا رڪاوٽ جي حرڪت ڪرڻ لاءِ ، ايڪس ايڪس ايڪس استعمال ڪريو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic جو مثال:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// ناجائز طور تي لپي ويل قيمت کي واپس ڪندي ، غلطي کي واپس آڻيندي جيڪڏهن قيمت في الحال قابل قبول طور تي قرض ورتو وڃي.
    ///
    ///
    /// قرض ايستائين جاري آهي جيستائين واپسي `Ref` دائري کان ٻاهر نه وڃي.
    /// هڪ ئي وقت ۾ گهڻن ableيرorrار قرض ڪ canي سگهجي ٿو.
    ///
    /// اھو [`borrow`](#method.borrow) جو غير panicking قسم آھي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // حفاظت: `BorrowRef` يقيني بڻائي ٿو ته رڳو هتي ناقابل تبديلي رسائي آهي
            // قرض وٺڻ دوران ويليو ڏانهن
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// گڏيل طور تي لپي ويل قيمت کي قرض وٺي ٿو.
    ///
    /// قرض ايستائين هلي ٿو جيستائين موٽي `RefMut` يا ان کان نڪتل سڀ ريفٽ ختم نه ٿي وڃي.
    ///
    /// قيمت قرض نه ٿو ڏئي سگهجي جڏهن ته اهو قرض فعال آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت في الحال قرض ورتو ويو آهي.
    /// بنا رڪاوٽ جي حرڪت ڪرڻ لاءِ ، ايڪس ايڪس ايڪس استعمال ڪريو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic جو مثال:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// گڏيل طور تي لپي ويل قيمت کي قرض طور قبول ڪري ٿو ، هڪ غلطي کي واپس ڏئي ٿو جيڪڏهن قيمت في الحال قرض ورتو وڃي.
    ///
    ///
    /// قرض ايستائين هلي ٿو جيستائين موٽي `RefMut` يا ان کان نڪتل سڀ ريفٽ ختم نه ٿي وڃي.
    /// قيمت قرض نه ٿو ڏئي سگهجي جڏهن ته اهو قرض فعال آهي.
    ///
    /// ھي [`borrow_mut`](#method.borrow_mut) جو غير panicking قسم آھي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // حفاظت: `BorrowRef` منفرد رسائي جي ضمانت ڏئي ٿو.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// هن سيل ۾ بنيادي ڊيٽا ڏانهن خام پوائنٽر کي واپس ڏئي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// واپسي واري ڊيٽا جي قابل aير referenceار واري واپسي ڏي.
    ///
    /// اهو ڪال `RefCell` کي متحرڪ طور تي قرض وٺي ٿو (ڪمپائل وقت تي) انهي ڪري متحرڪ چيڪن جي ضرورت نه آهي.
    ///
    /// تنهن هوندي به محتاط رهو: اهو طريقو توقع رکي ٿو `self` ته مٽائڻ وارو ، جيڪو عام طور تي ايڏو نه هوندو جڏهن `RefCell` استعمال ڪيو ويندو.
    ///
    /// جيڪڏهن `self` قابل تبديلي نه هجي ته بدران [`borrow_mut`] طريقو تي نظر وجهو.
    ///
    /// پڻ ، مهرباني ڪري beاڻو ته اهو طريقو صرف خاص حالتن جي لاءِ آهي ۽ عام طور تي اهو ناهي جيڪو توهان چاهيو ٿا.
    /// شڪ جي حالت ۾ ، بدران [`borrow_mut`] استعمال ڪريو.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `RefCell` جي قرض واري رياست تي ليکڪ محافظن جو اثر رد ڪريو.
    ///
    /// اهو ڪال [`get_mut`] وانگر ساڳيو آهي پر وڌيڪ خاص آهي.
    /// اهو `RefCell` قرض جي ادائيگي سان گڏ انهي کي يقيني بڻائڻ لاءِ قرض کڻندو آهي ۽ پوءِ اسٽيٽ ٽريڪ ڪيل حصيداري قرضن کي ٻيهر ترتيب ڏيندو آهي.
    /// اهو لاڳاپيل آهي جيڪڏهن ڪجهه `Ref` يا `RefMut` قرض وٺي چڪا آهن.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// ناجائز طور تي لپي ويل قيمت کي واپس ڪندي ، غلطي کي واپس آڻيندي جيڪڏهن قيمت في الحال قابل قبول طور تي قرض ورتو وڃي.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow` جي برعڪس ، هي طريقو غير محفوظ آهي ڇاڪاڻ ته اهو `Ref` واپس نٿو ڪري ، انهي ڪري قرضن جي پرچم کي ڇڪايو وڃي ٿو.
    /// مڪمل طور تي `RefCell` قرض وٺي رهيا آهن جڏهن ته هن طريقي سان واپسي حوالو زنده آهي اڻ سڌريل رويو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // حفاظت: اسان پڙتال ڪريون ٿا ڪو فعال طور تي ھاڻي ڪونه لکي رھيو آھي ، پر اھو آھي
            // ڪال ڪرڻ واري جي ذميواري يقيني بڻائڻ آهي ته ڪو به ان وقت تائين نه لکندو جيستائين واپسي وارو حوالو هاڻي استعمال ۾ نه هجي.
            // انهي سان گڏ ، `self.value.get()` `self` جي ملڪيت جي قيمت ڏانهن اشارو ڪندو آهي ۽ انهي جي ضمانت آهي ته `self` جي س forي عرصي لاءِ صحيح.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// لپي ويل قيمت وٺي ٿو ، `Default::default()` کي ان جي جڳھ تي ڇڏي ٿو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت في الحال قرض ورتو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت موجوده طور تي اسان جي قرض ورتي وئي آهي.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// `RefCell<T>` ٺاهي ٿو ، `Default` قدر سان ٽي لاءِ.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت `RefCell` في الحال قبول ڪئي وئي آهي.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت `RefCell` في الحال قبول ڪئي وئي آهي.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت `RefCell` في الحال قبول ڪئي وئي آهي.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت `RefCell` في الحال قبول ڪئي وئي آهي.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت `RefCell` في الحال قبول ڪئي وئي آهي.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت `RefCell` في الحال قبول ڪئي وئي آهي.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت `RefCell` في الحال قبول ڪئي وئي آهي.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // وڌندڙ قرض نتيجو ٿي سگهي ٿو غير پڙهڻ واري قيمت (<=0) انهن صورتن ۾:
            // 1. اهو <0 هو ، يعني اتي لکڻ وارا قرض آهن ، تنهنڪري اسان پڙهڻ جي اجازت نٿا ڏئي سگهون ڇاڪاڻ ته Rust جي حوالي سان جدا جدا قاعدن جي ڪري
            // 2.
            // اهو isize::MAX هو (پڙهڻ لاءِ قرض کڻڻ جي وڌ کان وڌ رقم) ۽ اها isize::MIN ۾ گهڙي وئي (لکڻ جي وڌ ۾ وڌ رقم) تنهنڪري اسان هڪ اضافي پڙهڻ وارو قرض وٺڻ جي اجازت نٿا ڏئي سگهون ڇاڪاڻ ته Isize ڪيتري ئي پڙهيل قرض جي نمائندگي نه ٿو ڪري سگهي (اهو صرف انهي ڪري ٿي سگهي ٿو جيڪڏهن توهان mem::forget ريفٽ جي هڪ نن thanڙي مسلسل رقم کان وڌيڪ ، جيڪو سٺو طريقو ناهي)
            //
            //
            //
            //
            None
        } else {
            // وڌندڙ قرض نتيجو ٿي سگهي ٿو پڙهڻ جي قيمت (> 0) انهن صورتن ۾:
            // 1. اهو=0 هو ، يعني اهو قرض نه ورتو ويو هو ، ۽ اسان پهريون پڙهيل قرض کڻي رهيا آهيون
            // 2. اهو> 0 ۽ <isize::MAX هو ، يعني
            // هتي پڙهيل قرض هئا ، ۽ هڪ وڏو پڙهيل قرض هجڻ جي نمائندگي ڪرڻ لاءِ تمام وڏو آهي
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // جئين هي ريفريج موجود آهي ، اسان knowاڻون ٿا ته قرض جو پرچم پڙهڻ جو قرض آهي.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // قرضن جي منڊي کي لکت واري قرض ۾ اوور فلو ٿيڻ کان روڪيو.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// هڪ قرضدار حوالو `RefCell` باڪس ۾ قيمت تي لڙهي ٿو.
/// `RefCell<T>` کان هڪ غير معقول قرض لاءِ ويلپيپر قسم.
///
/// وڌيڪ لاءِ [module-level documentation](self) ڏسو.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// هڪ `Ref` کي نقل ڪري ٿو.
    ///
    /// `RefCell` اڳ ۾ ئي غير معقول طور تي قرض ورتو ويو آهي ، تنهن ڪري اهو ناڪام ٿي نٿو سگهي.
    ///
    /// هي هڪ ڳن functionيل فنڪشن آهي جنهن کي `Ref::clone(...)` طور استعمال ڪرڻ جي ضرورت آهي.
    /// هڪ `Clone` عمل درآمد يا هڪ طريقو `r.borrow().clone()` جي وسيع استعمال ۾ مداخلت ڪري سگهندو هو `RefCell` جي مواد کي ڪلون ڪرڻ لاءِ.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// قرض ڏيندڙ ڊيٽا جي جز لاءِ نئين `Ref` ٺاهي ٿو.
    ///
    /// `RefCell` اڳ ۾ ئي غير معقول طور تي قرض ورتو ويو آهي ، تنهن ڪري اهو ناڪام ٿي نٿو سگهي.
    ///
    /// هي هڪ ڳن functionيل فنڪشن آهي جنهن کي `Ref::map(...)` طور استعمال ڪرڻ جي ضرورت آهي.
    /// هڪ طريقو `Deref` ذريعي استعمال ڪيل `RefCell` جي مواد تي ساڳئي نالي جي طريقن سان مداخلت ڪندو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// قرض ڏيندڙ ڊيٽا جي اختياري جز لاءِ نئون `Ref` ٺاهي ٿو.
    /// اصلي محافظ `Err(..)` جي طور تي واپس ڪيو ويندو آهي جيڪڏهن بندش `None` موٽائي ٿي.
    ///
    /// `RefCell` اڳ ۾ ئي غير معقول طور تي قرض ورتو ويو آهي ، تنهن ڪري اهو ناڪام ٿي نٿو سگهي.
    ///
    /// هي هڪ ڳن functionيل فنڪشن آهي جنهن کي `Ref::filter_map(...)` طور استعمال ڪرڻ جي ضرورت آهي.
    /// هڪ طريقو `Deref` ذريعي استعمال ڪيل `RefCell` جي مواد تي ساڳئي نالي جي طريقن سان مداخلت ڪندو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// قرض ڏيندڙ ڊيٽا جي مختلف حصن لاءِ `Ref` کي ڪيترن ئي `Ref` ۾ ورهايو آهي.
    ///
    /// `RefCell` اڳ ۾ ئي غير معقول طور تي قرض ورتو ويو آهي ، تنهن ڪري اهو ناڪام ٿي نٿو سگهي.
    ///
    /// هي هڪ ڳن functionيل فنڪشن آهي جنهن کي `Ref::map_split(...)` طور استعمال ڪرڻ جي ضرورت آهي.
    /// هڪ طريقو `Deref` ذريعي استعمال ڪيل `RefCell` جي مواد تي ساڳئي نالي جي طريقن سان مداخلت ڪندو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// ھيٺئين ڊيٽا جي حوالي سان تبديل ڪريو.
    ///
    /// بنيادي `RefCell` ڪڏهن به ٻيهر کان قرض حاصل نٿو ڪري سگھي ۽ اڳي ئي غير معقول قرض ورتو ويندو.
    ///
    /// مستقل حوالن کان وڌيڪ ٽوڪ ڏيڻ سٺو ڪم ناهي.
    /// صرف `RefCell` غير معقول طور تي قرض وٺي سگھجي ٿو جيڪڏهن صرف ٿورڙي تعداد ۾ ٻليون واقعا ٿي چڪيون آهن.
    ///
    /// هي هڪ ڳن functionيل فنڪشن آهي جنهن کي `Ref::leak(...)` طور استعمال ڪرڻ جي ضرورت آهي.
    /// هڪ طريقو `Deref` ذريعي استعمال ڪيل `RefCell` جي مواد تي ساڳئي نالي جي طريقن سان مداخلت ڪندو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // انهي ريف کي وسارڻ سان اسان يقين ڏيارينداسين ته RefCell ۾ قرض ڏيڻ وارو ڊائلز `'b` جي اندر اندر UNUSED ڏانهن واپس نٿو وڃي سگهي.
        // ريفرنس ٽريڪنگ اسٽيٽ کي ري سيٽ ڪرڻ جي لاءِ قرض ڏيندڙ ريفيل کي هڪ منفرد حوالو گهربل هوندو.
        // اصل خاني کان وڌيڪ ڪي به قابل تبديلي حوالا نه ٺاهي سگهجن ٿا.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// قرض ڏيندڙ ڊيٽا جي جز لاءِ نئين ايڪس سيڪس ايڪس کي ٺاهيندي آهي ، مثال طور ، اينيم ويئر.
    ///
    /// `RefCell` اڳ ۾ ئي قابل استعمال قرض کڻي چڪو آهي ، تنهن ڪري اهو ناڪام ٿي نٿو سگهي.
    ///
    /// هي هڪ ڳن functionيل فنڪشن آهي جنهن کي `RefMut::map(...)` طور استعمال ڪرڻ جي ضرورت آهي.
    /// هڪ طريقو `Deref` ذريعي استعمال ڪيل `RefCell` جي مواد تي ساڳئي نالي جي طريقن سان مداخلت ڪندو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): قرض جي چڪاس درست ڪريو
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// قرض ڏيندڙ ڊيٽا جي اختياري جز لاءِ نئون `RefMut` ٺاهي ٿو.
    /// اصلي محافظ `Err(..)` جي طور تي واپس ڪيو ويندو آهي جيڪڏهن بندش `None` موٽائي ٿي.
    ///
    /// `RefCell` اڳ ۾ ئي قابل استعمال قرض کڻي چڪو آهي ، تنهن ڪري اهو ناڪام ٿي نٿو سگهي.
    ///
    /// هي هڪ ڳن functionيل فنڪشن آهي جنهن کي `RefMut::filter_map(...)` طور استعمال ڪرڻ جي ضرورت آهي.
    /// هڪ طريقو `Deref` ذريعي استعمال ڪيل `RefCell` جي مواد تي ساڳئي نالي جي طريقن سان مداخلت ڪندو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): قرض جي چڪاس درست ڪريو
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // حفاظت: فنڪشن گھڙي عرصي تائين ھڪ خاص حوالي سان رھندي آھي
        // `orig` ذريعي ان جو ڪال ، ۽ پوائنٽر صرف ڪم جي ڪال جي اندر حوالي ٿيل هوندو آهي ڪڏهن به خاص حوالي کي ڀ allowingڻ جي اجازت نه ڏيندو آهي.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // حفاظت: ساڳي طرح مٿي.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// قرض ڏيندڙ ڊيٽا جي مختلف حصن لاءِ `RefMut` ڪيترن ئي `RefMut` ۾ ورهايو.
    ///
    /// بنيادي `RefCell` خاموش طور تي قرض تي رھندي رھندي جيستائين جيستائين واپس موٽڻ وارا `ريفٽ` دائري کان نڪري نہ وڃن.
    ///
    /// `RefCell` اڳ ۾ ئي قابل استعمال قرض کڻي چڪو آهي ، تنهن ڪري اهو ناڪام ٿي نٿو سگهي.
    ///
    /// هي هڪ ڳن functionيل فنڪشن آهي جنهن کي `RefMut::map_split(...)` طور استعمال ڪرڻ جي ضرورت آهي.
    /// هڪ طريقو `Deref` ذريعي استعمال ڪيل `RefCell` جي مواد تي ساڳئي نالي جي طريقن سان مداخلت ڪندو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// تبديل ٿيل referenceاڻ واري ڊيٽا جي حوالي سان تبديل ڪريو.
    ///
    /// ھيٺ ڏنل `RefCell` وري کان قرض نه ٿو ورتو وڃي ۽ اھو اڳي ئي الڳ ٿيل قرض طور تي ظاھر ٿيندو ، واپس ٿيل حوالو صرف داخلي ڏانھن.
    ///
    ///
    /// هي هڪ ڳن functionيل فنڪشن آهي جنهن کي `RefMut::leak(...)` طور استعمال ڪرڻ جي ضرورت آهي.
    /// هڪ طريقو `Deref` ذريعي استعمال ڪيل `RefCell` جي مواد تي ساڳئي نالي جي طريقن سان مداخلت ڪندو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // هن BorrowRefMut کي وسارڻ سان اسان انهي ڳالهه کي يقيني بڻايون ٿا ته RefCell ۾ قرض وٺڻ وارو UXED `'b` جي اندر اندر UNUSED ڏانهن واپس نٿو وڃي سگهي.
        // ريفرنس ٽريڪنگ اسٽيٽ کي ري سيٽ ڪرڻ جي لاءِ قرض ڏيندڙ ريفيل کي هڪ منفرد حوالو گهربل هوندو.
        // انهي س withinي حياتي اندر اصل سيل مان وڌيڪ حوالا پيدا نٿا ڪري سگهجن ، موجوده قرضن کي باقي حياتيءَ جو واحد حوالو بنائڻو آهي.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone جي برعڪس ، نئين کي شروعاتي ٺاهڻ لاء سڏيو ويندو آهي
        // مٽيريل حوالا ، ۽ تنهنڪري في الحال ڪوبه موجود حوالو نه هجڻ گهرجي.
        // اهڙيءَ طرح ، جڏهن ڪلون ناقابل تبديل ٿيندڙ ڪيفنس کي وڌائيندي آهي ، هتي اسين واضع طور تي صرف UNUSED کان UNUSED ، 1 ڏانهن وڃڻ جي اجازت ڏيندا آهيون.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // ڪلون ايڪس ايڪس ايڪس.
    //
    // اهو صرف صحيح آهي جڏهن هر هڪ `BorrowRefMut` اصل اعتراض جي الڳ ، غير اوورلوپنگ رينج جي مٽاسٽا ريفرنس کي ٽريڪ ڪرڻ لاءِ استعمال ڪيو وڃي.
    //
    // اهو ڪلون جي پاڙي ۾ ناهي تنهن ڪري ڪوڊ اهو نقاب نٿو سڏين.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // قرض ڏيندڙ ڊيل کي گهمائڻ کان روڪيو.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// `RefCell<T>` کان خاموش طور تي قرض لاءِ ڏنل قيمت لاءِ ويپر قسم.
///
/// وڌيڪ لاءِ [module-level documentation](self) ڏسو.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust ۾ اندروني مطابقت حاصل ڪرڻ جو بنيادي ابتدائي.
///
/// جيڪڏهن توهان وٽ هڪ حوالو `&T` آهي ، ته پوءِ عام طور تي Rust ۾ مرتب ڪندڙ هن basedاڻ جي بنياد تي واڌايون سرانجام ڏئي ٿو ته `&T` اڻ کٽ ڊيٽا ڏانهن اشارو ڪن ٿا.ان ڊيٽا کي ميٽ ڪرڻ ، مثال طور عرف جي ذريعي يا `&T` کي `&mut T` ۾ منتقل ڪري ، اڻ سڌريل رويي سمجهيو وڃي ٿو.
/// `UnsafeCell<T>` `&T` لاءِ موٽائتي ضمانت جي آپٽ آئوٽ ڪ: و: هڪ حصيداري حوالو `&UnsafeCell<T>` شايد ڊيٽا ڏانهن اشارو ڪري جنهن کي ميوٽيشن ڪيو پيو وڃي.انهي کي "interior mutability" سڏيو ويندو آهي.
///
/// ٻيا سڀ قسم جيڪي اندروني تغيرات جي اجازت ڏين ٿا ، جهڙوڪ `Cell<T>` ۽ `RefCell<T>` ، اندروني طور تي `UnsafeCell` استعمال ڪن ٿيون انهن جي ڊيٽا لپڻ لاءِ.
///
/// نوٽ ڪريو ته صرف حصيداري حوالن جي غير وابستگي جي ضمانت `UnsafeCell` کان متاثر آهي.تبديل ٿيندڙ حوالن جي انفراديت جي ضمانت متاثر ناهي.ھڪڙو `&mut` حاصل ڪرڻ جو ڪو به قانوني طريقو ناهي ، ايستائين `UnsafeCell<T>` سان.
///
/// `UnsafeCell` API پاڻ ٽيڪنيڪل طور تي بلڪل سادو آهي: [`.get()`] توهان کي انهي ڏانهن انهي ڏانهن گهٽ پوائنٽر `*mut T` ڏئي ٿو.اهو خام پوائنٽر کي صحيح طور تي استعمال ڪرڻ لاءِ تجريدي ڊيزائنر طور _you_ تائين آهي.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// صحيح Rust الگ ڪرڻ وارو قاعدو ڪجهه فلوڪس ۾ آهن ، پر بنيادي نقطا تڪرار نه آهن.
///
/// - جيڪڏهن توهان لائفائمٽ `'a` سان هڪ محفوظ حوالو ٺاهيو ٿا (يا ته `&T` يا `&mut T` حوالو) جيڪو محفوظ ڪوڊ ذريعي رسائي لائق آهي (مثال طور ، ڇاڪاڻ ته توهان هن کي واپس ڪيو) ، پوءِ توهان کي لازمي طور تي ڊيٽا تائين رسائي نه هجڻ گهرجي جيڪا بقا جي حوالي سان ان جي تضاد ٿئي. ايڪس ايڪس اين ايڪس جو.
/// مثال طور ، هن جو مطلب اهو آهي ته جيڪڏهن توهان `*mut T` کان `UnsafeCell<T>` وٺي ۽ `&T` ڏانهن اڇلائي ڇڏيو ، ته `T` ۾ ڊيٽا لازمي طور تي مٽجڻ گهرجي (ماڊل `UnsafeCell` ڪنهن به `&T` اندر مليو ڊيٽا ، يقينا) جيستائين ان حوالي سان س lifي زندگي جو حوالو ختم ٿئي.
/// ساڳي ريت ، جيڪڏهن توهان ايڪس `&mut T` ريفرنس ٺاهيو جيڪو محفوظ ڪوڊ ڏانهن جاري ڪيو ويو آهي ، ته توهان کي `UnsafeCell` اندر ڊيٽا تائين رسائي نه هجڻ گهرجي جيستائين اهو حوالو ختم نه ٿئي.
///
/// - هر وقت ، توهان کي ڊيٽا ريسز کان پاسو ڪرڻ گهرجي.جيڪڏهن گهڻن موضوعن جي ساڳي `UnsafeCell` تائين رسائي آهي ، ته پوءِ ڪنهن به لکڻين کي لازمي طور تي صحيح ٿيڻ گهرجي-ٻين سڀني رسالن جي نسبت کان اڳ (يا ايٽمي ايٽم استعمال ڪريو).
///
/// مناسب ڊزائن سان مدد ڪرڻ لاءِ ، هيٺيان منظر واضح طور تي واحد وارڊ ٿيل ڪوڊ لاءِ قانوني طور بيان ڪيا ويا آهن.
///
/// 1. اي `&T` حوالو محفوظ ڪوڊ ڏانهن جاري ڪري سگھجي ٿو ۽ اُتي اهو ٻين `&T` حوالن سان هموار ٿي سگھي ٿو ، پر ايڪس ايڪس ايڪس سان نه
///
/// 2. هڪ `&mut T` ريفورڊ ٿي سگھي ٿو محفوظ ڪوڊ ڏانهن نه مهيا ڪيو ويو نه ٻئي `&mut T` ۽ نه ئي `&T` انهي سان گڏ.هڪ `&mut T` هميشه منفرد هوندو.
///
/// ياد رکو ته هڪ `&UnsafeCell<T>` جي مواد کي مٽائڻ دوران (جيتوڻيڪ ٻيا `&UnsafeCell<T>` حوالي ڪري ٿو سيل) ٺيڪ آهي (جيڪڏهن توهان مٿي ڏنل ڀريندڙن کي ڪجهه ٻيو طريقي سان لاڳو ڪيو) ، اهو اڃا تائين غير متعين ٿيل رويو آهي ڪيترن ئي `&mut UnsafeCell<T>` عرفن کي.
/// اھو آھي ، `UnsafeCell` ھڪڙي وپپر ٺاھيو ويو آھي _shared_ accesses (_i.e._ سان ھڪڙي خاص رابطي جو ، `&UnsafeCell<_>` ريفرنس جي ذريعي) ؛جڏهن _exclusive_ accesses (_e.g._ سان `&mut UnsafeCell<_>` ذريعي معاملو ڪرڻ ۾ ڪو به جادو ناهي: نه ئي `&mut` قرض جي مدت تائين نه ئي سيل ۽ نه ئي و beيل ويليو خالي ٿي سگھي ٿي.
///
/// اهو نمائش [`.get_mut()`] پهچائيندڙ طرفان ڏيکاريو ويو آهي ، جيڪو هڪ _safe_ getter آهي جيڪو هڪ `&mut T` پيدا ڪري ٿو.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// هتي هڪ مثال ڏيکاريندي آهي ته ايڪس ايڪس ايڪس جي مواد کي آواز سان ڪيئن بدلجي سگهجي ٿو باوجود ڪيترن ئي حوالن جي ڪيترن ئي حوالا ڏيڻ جي باوجود:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // ساڳيو `x` جي گهڻن/گڏيل/گڏيل حوالن کي حاصل ڪيو.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // حفاظت: هن دائري اندر x جي مواد جا ٻيا حوالا نه آهن ،
///     // تنهنڪري اسان جو مؤثر انداز سان منفرد آهي.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- قرض وٺڻ +
///     *p1_exclusive += 27; // |
/// } // <---------- هن نقطي کان اڳتي نٿو وڃي سگھجي -------------------+
///
/// unsafe {
///     // حفاظت: هن دائري اندر ڪنهن جي به توقع ناهي ته هو x جي مواد تائين خاص رسائي حاصل ڪري ٿو ،
///     // تنهنڪري اسان ٻنهي سان گڏيل حصيداري حاصل ڪري سگهون ٿا.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// هيٺ ڏنل مثال اها حقيقت ظاهر ڪري ٿي ته ايڪس01ڪس تائين رسائي خاص طور تي ان جي `T` تائين خاص رسائي جو مطلب آهي.
///
/// ```rust
/// #![forbid(unsafe_code)] // خاص رسائي سان ،
///                         // `UnsafeCell` ھڪڙو شفاف اوپي وپر آھي ، تنھنڪري ھتي `unsafe` جي ضرورت ڪونھي.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x` لاء هڪ مرتب ڪيل وقت جي چڪاس وارو منفرد حوالو حاصل ڪريو.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // هڪ خاص حوالي سان ، اسان مواد کي مفت ۾ تبديل ڪري سگهون ٿا.
/// *p_unique.get_mut() = 0;
/// // يا ، برابر:
/// x = UnsafeCell::new(0);
///
/// // جڏهن اسان قيمت کي اسان وٽ آهي ، اسان مواد مفت ۾ ڪ canي سگھون ٿا.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// `UnsafeCell` جو نئون مثال تعمير ڪري ٿو جيڪا مخصوص ويل لڙهي ويندي.
    ///
    ///
    /// طريقن سان اندرين قيمت تائين سڀ رسائي `unsafe` آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// قدر نه لڙهي ٿو
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// لپي ويل ويل لاءِ قابل بدلڻ واري نشاني حاصل ڪئي.
    ///
    /// اهو ڪنهن به قسم جي پوائنٽر ڏانهن اڇلائي سگهجي ٿو.
    /// انهي کي يقيني بڻايو وڃي ته رسائي منفرد آهي (ڪي فعال حوالا ، غير متحرڪ يا نه) جڏهن `&mut T` ڏانهن ڪاسٽ ڪري رهيا آهن ، ۽ انهي کي يقيني بڻايو وڃي ته `&T` ڏانهن ڪتب آڻڻ دوران ڪي به ميوٽيشنز يا ڪي تبديل ٿيندڙ القابات نه آهن
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // اسان صرف `UnsafeCell<T>` کان `T` ڏانهن پوائنٽر اڇلائي سگهو ٿا #[repr(transparent)] جي ڪري.
        // هي استحصال ليبسٽڊ جي خاص اسٽيٽس جي استحصال ڪري ٿو ، صارف جي ڪوڊ جي گارنٽي ناهي ته هي ڪمپوزر جي future ورزن ۾ ڪم ڪندو!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// واپسي واري ڊيٽا جي قابل aير referenceار واري واپسي ڏي.
    ///
    /// هي ڪال `UnsafeCell` کي ٻرندڙ طور تي قرض وٺي ٿو (مرتب واري وقت) جيڪو انهي جي ضمانت ڏي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// لپي ويل ويل لاءِ قابل بدلڻ واري نشاني حاصل ڪئي.
    /// [`get`] ڏانهن فرق اهو آهي ته هي فنڪشن خام پوائنٽر کي قبول ڪري ٿو ، جيڪو عارضي حوالن جي تخليق کان بچڻ لاءِ مفيد آهي.
    ///
    /// نتيجو ڪنهن به قسم جي پوائنٽر ڏانهن اڇلائي سگهجي ٿو.
    /// انهي کي يقيني بڻايو وڃي ته رسائي منفرد آهي (ڪي فعال حوالا ، غير متحرڪ يا نه) جڏهن `&mut T` ڏانهن ڪاسٽ ڪري رهيا آهن ، ۽ انهي کي يقيني بڻايو وڃي ته `&T` ڏانهن ڪتب آڻڻ دوران ڪي به ميوٽيشنز يا ڪي بدلڻ وارا عرفان نه آهن.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// ھڪڙي `UnsafeCell` جي شروعاتي شروعات `raw_get` جي ضرورت آھي ، جئين `get` ڪال ڪرڻ جي ضرورت آھي اڻ ابتدائي ڊيٽا جو حوالو ٺاھڻ جي.
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // اسان صرف `UnsafeCell<T>` کان `T` ڏانهن پوائنٽر اڇلائي سگهو ٿا #[repr(transparent)] جي ڪري.
        // هي استحصال ليبسٽڊ جي خاص اسٽيٽس جي استحصال ڪري ٿو ، صارف جي ڪوڊ جي گارنٽي ناهي ته هي ڪمپوزر جي future ورزن ۾ ڪم ڪندو!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// `UnsafeCell` ٺاهي ٿو ، `Default` قدر سان ٽي لاءِ.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}