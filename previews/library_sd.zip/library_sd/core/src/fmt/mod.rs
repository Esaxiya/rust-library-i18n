//! اسٽرنگ کي ترتيب ڏيڻ ۽ ڇپائي لاءِ استعمال ڪرڻ.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` پاران ممڪن موٽ واريون موٽي ويون
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// اشارو ڏنو ويو آهي ته مواد کي ڇڏي رکڻ گهرجي.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// اشارو ڏنو ويو آهي ته مواد صحيح صحيح هجڻ گهرجي.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// اشارو ڏنو وڃي ٿو ته مواد وچ ۾ ترتيب ڏنل هجڻ گهرجي.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// فارموليٽر طريقن سان واپس موٽندڙ قسم.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// غلطي جي قسم جيڪا پيغام کي اسٽريم ۾ آڻڻ کان واپس ڪئي وئي آهي.
///
/// اھو قسم ٻي غلطي جي ٽرانسميشن جي مدد نه ڪندو آھيان کان سواءِ ان ۾ غلطي پيدا ٿي.
/// ڪنهن به اضافي معلومات کي ڪجهه ٻين طريقي سان منتقل ڪرڻ جو بندوبست ڪيو وڃي.
///
/// ياد رکڻ جي اهم ڳالهه اها آهي ته `fmt::Error` قسم کي [`std::io::Error`] يا [`std::error::Error`] سان جهرڻ نه گهرجي ، جنهن جي شايد توهان کي به گنجائش آهي.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// يونيڪوڊ قبول ڪرڻ واري بفرن يا اسٽريمز ۾ لکڻ يا فارميٽ لاءِ trait.
///
/// trait صرف UTF-8 انڪوڊ ٿيل ڊيٽا قبول ڪندو آهي ۽ ايڪس ايڪس ايڪس نه آهي.
/// جيڪڏهن توهان صرف يونيڪوڊ قبول ڪرڻ چاهيو ٿا ۽ توهان کي هلاڻ جي ضرورت نه آهي ، توهان کي هن trait کي عمل ڪرڻ گهرجي ؛
/// ٻي صورت ۾ توهان کي [`std::io::Write`] لاڳو ڪرڻ گهرجي.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// هن ليکڪ ۾ هڪ تار سلائي لکي ٿو ، واپس اچي رهيو آهي ته ڇا لکڻ ڪامياب ٿي ويو.
    ///
    /// اهو طريقو صرف انهي صورت ۾ ڪامياب ٿي سگهي ٿو ، جڏهن سموري اسٽرنگ سلائس ڪاميابي سان لکجي ويندي هئي ، ۽ اهو طريقو واپس نه ايندو جيستائين سموري ڊيٽا لکجي يا غلطي نه ٿئي.
    ///
    ///
    /// # Errors
    ///
    /// انهي فنڪشن ايڪس اين ايڪس ايڪس جو هڪ مثال غلطي ڏي ويندي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// هن ليکڪ ۾ هڪ [`char`] لکي ٿو ، واپس اچي رهيو آهي ته ڇا لکڻ ڪامياب ٿي ويو.
    ///
    /// ھڪڙو [`char`] ھڪڙي بائيٽ کان وڌيڪ انڪوڊ ٿي سگھي ٿو.
    /// اهو طريقو صرف انهي صورت ۾ ڪامياب ٿي سگھي ٿو جڏهن مڪمل بائيٽ تسلسل ڪاميابي سان لکجي وڃي ، ۽ اهو طريقو واپس نه ايندو جيستائين پوري ڊيٽا نه لکي وئي هجي يا هڪ نقص پيدا ٿئي.
    ///
    ///
    /// # Errors
    ///
    /// انهي فنڪشن ايڪس اين ايڪس ايڪس جو هڪ مثال غلطي ڏي ويندي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// ھن trait کي لاڳو ڪرڻ وارن سان [`write!`] ميڪرو جي استعمال لاءِ گلو.
    ///
    /// اهو طريقو عام طور تي انفرادي طور تي انڪوائڊ نه ڪيو وڃي ، بلڪه پاڻ [`write!`] ميڪرو ذريعي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// فارميٽنگ لاءِ ترتيب ڏيڻ.
///
/// اي `Formatter` فارمٽنگ سان لاڳاپيل مختلف اختيارن جي نمائندگي ڪندو آهي.
/// صارفين سڌو سنئون ٺاھيو نه ٿا ٺاھيندڙھڪڙي ھڪڙي قابل تبديل ريفرنس [`Debug`] ۽ [`Display`] وانگر ، سڀني فارميٽنگ traits جي ھڪڙي طريقي سان `fmt` ڏانھن منتقل ڪيو ويو آھي.
///
///
/// `Formatter` سان رابطو ڪرڻ لاءِ ، توهان فارميٽنگ سان لاڳاپيل مختلف اختيارن کي تبديل ڪرڻ لاءِ مختلف طريقا سڏيندا.
/// مثال طور ، مهرباني ڪري هيٺ ڏنل `Formatter` تي بيان ڪيل طريقن جي دستاويز ڏسو.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// دليل بنيادي طور تي هڪ بهتر طور تي لاڳو ڪيل جزوي شڪل ڏيڻ وارو فنڪشن آهي ايڪس ايڪس ايڪسز جي برابر.

extern "C" {
    type Opaque;
}

/// اهو جوڙ عام "argument" جي نمائندگي ڪري ٿو جيڪو Xprintf خاندان جي افڪارن پاران ورتو وڃي ٿو.انهي ۾ ڏنل قيمت کي شڪل ڏيڻ جي لاءِ ڪم ڪيو ويو آهي.
/// مجموعي وقت تي اها پڪ ڪئي وئي آهي ته فنڪشن ۽ ويليو جا صحيح قسم آهن ، ۽ انهي کان پوءِ هن اڏاوت کي هڪ قسم تي دليلن جي درست ترتيب ڏيڻ لاءِ استعمال ڪيو ويندو آهي.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// اهو هڪ واحد مستحڪم قدر جي ضمانت ڏئي ٿو فارميٽ انفراسٽرڪچر ۾ indices/counts سان لاڳاپيل فٽر پوائنٽر.
//
// ياد رکجو هڪ اهڙو فنڪشن بيان ڪيو ويو صحيح نه هوندو جيئن فنڪشن هميشه ايل ايل ايم آر آئي آر کي گهٽائي سان نام نهاد_اددر کي ٽيگ ڪيو وڃي ، تنهن ڪري هنن جو پتو ايل ايل وي ايم لاءِ اهم نه سمجهيو ويو آهي ۽ جيئن ته ايس_ يوز ڪاسٽ کي غلط قرار ڏنو ويو هو.
//
// عملي طور تي ، اسان ڊيٽا کي غير استعمال ڪندڙن تي as_usize ڪڏهن به نه ٿا سڏيو (جيئن ته فارميٽنگ دليلن جي جامد نسل جي طور تي) ، تنهنڪري اهو صرف هڪ اضافي چڪاس آهي.
//
// اسان بنيادي طور تي انهي ڳالهه کي يقيني بڻائڻ گهرون ٿا ته `USIZE_MARKER` تي ڪم ڪندڙ پوائنٽر وٽ هڪ پتو *صرف* شين جي ڪمائي آهي جيڪو `&usize` پڻ انهن جي پهرين دليل طور وٺن ٿا.
// ھتي پڙھڻ وارو عمل يقيني بڻائي ٿو ته اسان محفوظ طور تي منظور ٿيل ريفرنس مان ھڪڙو تيار تيار ڪري سگھون ٿا ۽ ھي پتو غير استعمال واري ڪم جي طرف اشارو نٿي ڪري.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // حفاظت: ptr هڪ حوالو آهي
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // حفاظت: `mem::transmute(x)` محفوظ آھي ڇاڪاڻ ته
        //     1. `&'b T` حياتي کي برقرار رکي ٿو اهو `'b` سان شروع ڪيل (جيئن ته بي حد زندگي گذار نه هجي)
        //     2.
        //     `&'b T` ۽ `&'b Opaque` وٽ ھڪڙو ئي ياداشت واري ترتيب آھي (جڏھن `T` آھي `Sized` ، جئين ھتي آھي) `mem::transmute(f)` کان محفوظ آھي `fn(&T, &mut Formatter<'_>) -> Result` ۽ `fn(&Opaque, &mut Formatter<'_>) -> Result` وٽ ھڪڙو اي بي آئي آھي (جيستائين `T` آھي `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // حفاظت: `formatter` فيلڊ صرف USIZE_MARKER تي سيٽ ٿيل آھي جيڪڏھن
            // قدر هڪ استعمال ٿيل آهي ، تنهن ڪري اهو محفوظ آهي
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// فارميٽ_ارگس جي ايڪسڪسيمڪس فارميٽ ۾ موجود پرچم موجود آهن
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// جڏهن فارميٽ_ارگس! () ميڪرو استعمال ڪندي ، اهو فنڪشن دليل ٺاهڻ واري ساخت ٺاهڻ لاءِ استعمال ٿيندو آهي.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// ھي فنڪشن غير معياري فارميٽنگ جي ڀرمار کي بيان ڪرڻ لاءِ استعمال ڪيو ويندو آھي.
    /// `pieces` قطعيت گھٽ ۾ گھٽ ايتري تائين هجڻ گهرجي جيستائين `fmt` هڪ صحيح دليل وارو اڏاوتيتو ٺاهي وڃي.
    /// پڻ ، `fmt` اندر ڪنھن `Count` جيڪو `CountIsParam` آھي يا `CountIsNextParam` آھي `argumentusize` سان ٺاھيل ھڪ دليل ڏانھن اشارو ڪرڻ.
    ///
    /// تنهن هوندي ، ائين ڪرڻ ۾ ناڪام ٿيڻ نااميدگي جو سبب نه آهي ، پر غلط کي نظرانداز ڪندو.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// بنا شڪل واري متن جي ڊيگهه جو اندازو لڳائي ٿو.
    ///
    /// اهو ارادو ڪيو ويو آهي ايڪسڪسيمڪس جي ابتدائي سيٽنگ کي سيٽ ڪرڻ جي لاءِ جڏهن `format!` استعمال ڪيو ويندو.
    /// Note: هي نن theو ۽ نه مٿيون پابند آهي.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // جيڪڏهن فارميٽ اسٽرنگ دليل سان شروع ٿئي ، ڪنهن به شيءِ کي اوليت نه ڏيو ، جيستائين ٽڪرن جي ڊيگهه اهم نه هوندي.
            //
            //
            0
        } else {
            // هتي ڪجهه دلائل آهن ، تنهن ڪري ڪنهن به اضافي ڌڪ کي سوراخ ڪندو.
            //
            // انهي کان بچڻ کان ، اسان هتي گنجائش "pre-doubling" آهيون.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// اها جوڙجڪ فارميٽ جي اسٽرنگ ۽ ان جي دليلن جو محفوظ حفاظت سان گڏ ڪيل نسخو ظاهر ڪري ٿي.
/// اهو هلڻ واري وقت تي پيدا نٿو ڪري سگهجي ڇاڪاڻ ته اهو محفوظ طور تي نه ٿي ڪري سگهجي ، تنهن ڪري ڪنهن به تعمير ڪندڙن کي ناهي ڏنو ويو ۽ فيلڊز ذاتي هجڻ کان بچڻ کان پاسو ڪري رهيون آهن.
///
///
/// [`format_args!`] ميڪرو حفاظت سان هن ساخت جو هڪ مثال ٺاهي سگهندو.
/// ميڪرو کمپائل وقت تي فارميٽ اسٽرنگ کي درست ڪندو آهي تنهن ڪري ايڪس [`write()`] ۽ X01 افعال جو استعمال محفوظ طور تي ٿي سگهي ٿو.
///
/// توهان استعمال ڪري سگهو ٿا `Arguments<'a>` جيڪو [`format_args!`] واپسي `Debug` ۽ `Display` حوالي سان هيٺ ڏنل ڏٺو ويو آهي.
/// مثال پڻ ڏيکاري ٿو ته `Debug` ۽ `Display` ساڳئي شڪل ڏانهن: ايڪس پي ايڪس ۾ بين الاقوامي فارميٽ اسٽرنگ.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // طباعت ڪرڻ لاءِ تار جا حصا طئي ڪريو.
    pieces: &'a [&'static str],

    // جڳهه جي جڳهه چشمون ، يا `None` جيڪڏهن سڀ چيڪس ڊفالٽ آهن (جيئن "{}{}" ۾).
    fmt: Option<&'a [rt::v1::Argument]>,

    // تعلقي لاءِ متحرڪ دليل ، تار جي ٽڪرن سان مداخلت ڪرڻ.
    // (هر دليل هڪ تار جي ٽڪڙي سان ٿيندي آهي.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// حاصل ٿيل شڪل حاصل ڪريو ، جيڪڏھن ان وٽ فارميٽ ڪرڻ جو ڪو دليل ناھي.
    ///
    /// اهو سڀ گهٽ نن caseو ڪيس ۾ مختص ڪرڻ کان بچڻ جي لاءِ استعمال ڪري سگهجي ٿو.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` پروگرامر-سامهون ، ڊيبگنگ واري ريفرنس ۾ محصول کي شڪل ڏيڻ گھرجي.
///
/// عام طور تي ڳالهائڻ ، توهان کي صرف `derive` `Debug` لاڳو ٿيڻ گهرجي.
///
/// جڏهن متبادل فارميٽ اسپيسيفائيزر `#?` سان استعمال ڪيو ويندو آهي ، اها پيداوار خوبصورت ڇپيل هوندي آهي.
///
/// فارميٽرز بابت وڌيڪ معلومات لاءِ ، ڏسو [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// اهو trait استعمال ڪري سگهجي ٿو `#[derive]` جيڪڏهن سڀني شعبن تي `Debug` لاڳو ٿئي ٿو.
/// جڏهن ڊي سي کي حاصل ڪيو وڃي ، اهو `struct` جو نالو استعمال ڪندو ، پوءِ `{` ، پوءِ ڪاما کان جدا ٿيل فهرست هر فيلڊ جو نالو ۽ `Debug` قدر ، پوءِ `}`.
/// Enum جي لاءِ ، اهو ويرين جو نالو استعمال ڪندو ۽ ، جيڪڏهن ٿي سگهي ٿو ، `(` ، پوءِ `Debug` قدرن جي پاسن ، پوءِ `)`.
///
/// # Stability
///
/// نڪتل `Debug` فارمٽس مستحڪم نه آهن ، ۽ ائين future Rust ورزن سان تبديل ٿي سگهي ٿو.
/// ان کان علاوه ، معياري لائبريري طرفان فراهم ڪيل قسمن جي `Debug` لاڳو ("libstd" ، `libcore` ، `liballoc` ، وغيره) مستحڪم نه آهن ، ۽ پڻ future Rust ورزن سان تبديل ٿي سگهن ٿيون.
///
///
/// # Examples
///
/// عمل درآمد ڪرڻ
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// دستي طور تي عمل ڪرڻ:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// توھان کي دستي عمل درآمد سان مدد ڏيڻ ۾ مدد لاءِ ڪيترائي مددگار طريقا [`Formatter`] آھن ڪيترائي [`debug_struct`].
///
/// `Debug` [`Formatter`] يا ڊيبگ بلڊر اي پي يو استعمال ڪندي عملدرآمد متبادل پرچم استعمال ڪندي خوبصورت پرنٽنگ جي حمايت ڪريو. `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` سان خوبصورت ڇپائي:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// ڏنل فارميٽ استعمال ڪندي ويليو کي فارميٽ ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// prelude کان trait `Debug` کان بغير ميڪرو ايڪسڪسيمڪس کي ٻيهر رپورٽ ڪرڻ لاءِ ڌار ماڊل.
pub(crate) mod macros {
    /// ماخوذ ميڪرو trait `Debug` جو نقشو پيدا ڪري ٿو.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// خالي فارميٽ لاءِ trait فارميٽ ڪريو ، `{}`.
///
/// `Display` [`Debug`] سان ساڳيو آهي ، پر `Display` صارف سان منهن ڏيڻ واري پيداوار لاءِ آهي ، ۽ ان جي نڪتل نه ٿي سگھي.
///
///
/// فارميٽرز بابت وڌيڪ معلومات لاءِ ، ڏسو [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ھڪڙي قسم تي `Display` لاڳو ڪندي:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// ڏنل فارميٽ استعمال ڪندي ويليو کي فارميٽ ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait کي ٻاھر ڪ formatڻ گھرجي ان جي ھڪڙي نمبر کي base-8 ۾.
///
/// ابتدائي دستخط ٿيل انٽيگرز لاءِ (`i8` کان `i128` ، ۽ `isize`) ، منفي قدرن کي ٻن جي مڪمل نمائندگي جي طور تي ترتيب ڏنو ويو آهي.
///
///
/// متبادل پرچم ، `#` ، ٻاھر جي اڳيان `0o` شامل ڪري ٿو.
///
/// فارميٽرز بابت وڌيڪ معلومات لاءِ ، ڏسو [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` سان بنيادي استعمال:
///
/// ```
/// let x = 42; // 42 آکيريل ۾ '52' آهي
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// ھڪڙي قسم تي `Octal` لاڳو ڪندي:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 جي نفاذ تي اختيار
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// ڏنل فارميٽ استعمال ڪندي ويليو کي فارميٽ ڪري ٿو.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait کي ٻاھر ڪ formatڻ گھرجي ھڪڙي نمبر کي بائنري ۾.
///
/// ابتدائي دستخط ٿيل انٽيگرز لاءِ ([`i8`] کان [`i128`] ، ۽ [`isize`]) ، منفي قدرن کي ٻن جي مڪمل نمائندگي جي طور تي ترتيب ڏنو ويو آهي.
///
///
/// متبادل پرچم ، `#` ، ٻاھر جي اڳيان `0b` شامل ڪري ٿو.
///
/// فارميٽرز بابت وڌيڪ معلومات لاءِ ، ڏسو [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] سان بنيادي استعمال:
///
/// ```
/// let x = 42; // 42 بائنري ۾ '101010' آهي
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// ھڪڙي قسم تي `Binary` لاڳو ڪندي:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 جي نفاذ تي اختيار
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// ڏنل فارميٽ استعمال ڪندي ويليو کي فارميٽ ڪري ٿو.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait کي ٻاھر ڪ heڻ گھرجي ھڪڙي عددي ۾ ايڪس ايڪس ايڪس سان ، ننXي صورت ۾ `a` کان `f` تائين.
///
/// ابتدائي دستخط ٿيل انٽيگرز لاءِ (`i8` کان `i128` ، ۽ `isize`) ، منفي قدرن کي ٻن جي مڪمل نمائندگي جي طور تي ترتيب ڏنو ويو آهي.
///
///
/// متبادل پرچم ، `#` ، ٻاھر جي اڳيان `0x` شامل ڪري ٿو.
///
/// فارميٽرز بابت وڌيڪ معلومات لاءِ ، ڏسو [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` سان بنيادي استعمال:
///
/// ```
/// let x = 42; // 42 هيڪس ۾ '2a' آهي
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// ھڪڙي قسم تي `LowerHex` لاڳو ڪندي:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 جي نفاذ تي اختيار
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// ڏنل فارميٽ استعمال ڪندي ويليو کي فارميٽ ڪري ٿو.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait کي ٻاھر ڪ heڻ گهرجي ھڪڙي نمبر ايڪساڊڪمل ۾ ، ايڪس چوڪس کان `F` سان `F` وڏي صورت ۾.
///
/// ابتدائي دستخط ٿيل انٽيگرز لاءِ (`i8` کان `i128` ، ۽ `isize`) ، منفي قدرن کي ٻن جي مڪمل نمائندگي جي طور تي ترتيب ڏنو ويو آهي.
///
///
/// متبادل پرچم ، `#` ، ٻاھر جي اڳيان `0x` شامل ڪري ٿو.
///
/// فارميٽرز بابت وڌيڪ معلومات لاءِ ، ڏسو [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` سان بنيادي استعمال:
///
/// ```
/// let x = 42; // 42 هيڪس ۾ '2A' آهي
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// ھڪڙي قسم تي `UpperHex` لاڳو ڪندي:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 جي نفاذ تي اختيار
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// ڏنل فارميٽ استعمال ڪندي ويليو کي فارميٽ ڪري ٿو.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait ان جي ٻاھرئين کي ياداشت جي جڳھ جي طور تي ترتيب ڏيڻ گھرجي.
/// اهو عام طور تي هيڪسڊيڪل طور پيش ڪيو ويو آهي.
///
/// فارميٽرز بابت وڌيڪ معلومات لاءِ ، ڏسو [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` سان بنيادي استعمال:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // اھو ڪجھ ٺاھيندو آھي ايڪسڪسيمڪس وانگر
/// ```
///
/// ھڪڙي قسم تي `Pointer` لاڳو ڪندي:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // ايڪسڪسيمڪس کي ايڪسڪسيمڪس ۾ بدلائڻ لاءِ استعمال ڪريو ، جيڪو پوائنٽر لاڳو ڪري ٿو ، جيڪو اسان استعمال ڪري سگهون ٿا
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// ڏنل فارميٽ استعمال ڪندي ويليو کي فارميٽ ڪري ٿو.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait سائنسي نوٽڪشن ۾ ان جي پيداوار کي نن aو ڪيس `e` سان فارميٽ ڏيڻ گھرجي.
///
/// فارميٽرز بابت وڌيڪ معلومات لاءِ ، ڏسو [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` سان بنيادي استعمال:
///
/// ```
/// let x = 42.0; // 42.0 ايڪس سائنسي نوٽيس ۾ '4.2e1' آهي
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// ھڪڙي قسم تي `LowerExp` لاڳو ڪندي:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // F64 جو نفاذ ڪرڻ تي وفد
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// ڏنل فارميٽ استعمال ڪندي ويليو کي فارميٽ ڪري ٿو.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait ان جي ٻاٽي کي سائنسي نوٽيس ۾ فارميٽ `E` سان فارميٽ ڏيڻ گھرجي.
///
/// فارميٽرز بابت وڌيڪ معلومات لاءِ ، ڏسو [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` سان بنيادي استعمال:
///
/// ```
/// let x = 42.0; // 42.0 ايڪس سائنسي نوٽيس ۾ '4.2E1' آهي
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// ھڪڙي قسم تي `UpperExp` لاڳو ڪندي:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // F64 جو نفاذ ڪرڻ تي وفد
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// ڏنل فارميٽ استعمال ڪندي ويليو کي فارميٽ ڪري ٿو.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` فنڪشن ھڪڙي ٻا stream واري وهڪرو وٺندو آھي ، ۽ ھڪڙي `Arguments` اڏاوت جيڪو `format_args!` ميڪرو سان گڏ ٿي سگھي ٿو.
///
///
/// دليلن کي دستياب ٿيل فارميٽ جي اسٽرنگ موجب ترتيب ڏني ويندي ٻاھرين ٻاھر واري وهڪري ۾.
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// مهرباني ڪري نوٽ ڪريو ته [`write!`] استعمال ڪندي ترجيح هجڻ لڳي.مثال ؛
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // اسان سڀني دليلن لاءِ ڊفالٽ فارمٽنگ وارو پيٽرول استعمال ڪري سگهون ٿا.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // هر نموني جي ساڳئي دليل هوندي آهي ، جيڪا تار جي ٽڪڙي کان اڳ هوندي آهي.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // حفاظت: دليل ۽ args.args ساڳي دليلن کان ايندا آھن ،
                // جيڪو ضمانت ڏيندو آهي انڊيڪس هميشه حدن اندر هوندو آهي.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // اتي ئي رھجي سگھجي ٿو ھڪڙي ھڪڙي رھندڙ ڏاڪڻ وارو ٽڪرو.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // حفاظت: دليل ۽ دليل ساڳيا دليل کان ايندا آھن ،
    // جيڪو ضمانت ڏيندو آهي انڊيڪس هميشه حدن اندر هوندو آهي.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // صحيح دليل ڪو
    debug_assert!(arg.position < args.len());
    // حفاظت: دليل ۽ دليل ساڳيا دليل کان ايندا آھن ،
    // جيڪو ضمانت ڏي ٿو ان جي انڊيڪس هميشه حدن اندر آهي.
    let value = unsafe { args.get_unchecked(arg.position) };

    // پوءِ اصل ۾ ڪجهه ڇپائي ڪيو
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // حفاظت: cnt ۽ دليل ساڳيا دليلن کان اچن ٿا ،
            // جيڪو ضمانت ڏي ٿو اهو انڊيڪس هميشه حدن ۾ هوندو آهي.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// ڪنهن شيءَ جي ختم ٿيڻ بعد پيڊنگ.`Formatter::padding` طرفان واپس ڪيل.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// هن پوسٽ پيڊنگ کي لکو.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // اسان انهي کي تبديل ڪرڻ چاهيون ٿا
            buf: wrap(self.buf),

            // ۽ انهن کي محفوظ ڪريو
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // مددگار طريقا پيڊنگ ۽ پروسيسنگ فارميٽ دليلن لاءِ استعمال ٿيل ته سڀ فارميٽ traits استعمال ڪري سگھن ٿيون.
    //

    /// انٽيگر لاءِ صحيح پيڊنگ انجام ڏي ٿو جيڪو اڳ ۾ ئي هڪ دٻي ۾ خارج ٿي چڪو آهي.
    /// عدد لاءِ نه هجڻ گهرجي * انضمام لاءِ نشاني ، جنهن کي هن طريقي سان شامل ڪيو ويندو.
    ///
    /// # Arguments
    ///
    /// * is_negegative ، ڇا اصل عدد مثبت يا صفر هو.
    /// * اڳياڙي ، جيڪڏھن '#' حرف (Alternate) مهيا ڪيو وڃي ، ھي اڳياڙي نمبر کي اڳيان رکڻ لاءِ آھي.
    ///
    /// * بائيف ، بائيٽ صف جنهن جو نمبر ٺاھيو ويو آھي
    ///
    /// انهي فنڪشن جي مهيا ڪيل پرچم جي درست حساب سان ۽ گهٽ ۾ گهٽ چوٽي پڻ شامل هوندي.
    /// اهو درست حساب ۾ نه وٺندو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // اسان کي نمبر ٻاھران کان "-" ڪ toڻ جي ضرورت آھي.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // جيڪڏهن موجود هجي ته نشان لکان ٿو ، ۽ جيڪڏهن اڳين هن جي درخواست ڪئي وڃي ها
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // ھن جڳھ تي `width` ھڪڙي `min-width` پيرا ميٽر مان آھي.
        match self.width {
            // جيڪڏهن ايڏي ڊگھائي گھربل ناهي ته پوءِ بس اسان بائيٽ لکي سگهون ٿا.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // چڪاس ڪريو ته اسان گھٽ ۾ گھٽ چوٽي تي آھيون ، جيڪڏھن ائين آھي ته پوءِ اسان پڻ بائيٽس لکي سگھوٿا.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // جيڪڏهن نشان وارو ڪردار صفر صفر آهي ته پيڊنگ کان اڳ نشان ۽ اڳيئي وڃي ٿو
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // ٻي صورت ۾ ، علامت ۽ اڳياڙي پيڊنگ کان پوءِ وڃي ٿي
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// اهو فنڪشن هڪ اسٽرنگس سلائس وٺندو آهي ۽ اهو مخصوص فارميٽنگ فليگ جو مخصوص ٿيل فارميٽ لاڳو ڪرڻ کانپوءِ اندروني بفر ۾ داخل ڪندو آهي.
    /// عام تارن لاءِ recognizedاڻايل جھنڊيون آھن:
    ///
    /// * چوٿون ، گهٽ ۾ گهٽ چوٿون ڇا اخراجات
    /// * fill/align - ڇا ترتيب ڏيڻ گهرجي ۽ ڪٿي خارج ڪرڻ کپي جيڪڏهن فراهم ڪيل تار کي پيڊنگ ڪرڻ گهرجي
    /// * صحت واري ، وڌ کان وڌ شيئر ڪرڻ لاءِ ، تار گهٽجي ويو ته جيڪڏهن هن لمبائي کان وڌيڪ ڊگهو آهي
    ///
    /// خاص طور تي اهو ڪم `flag` پيٽرولز کي نظرانداز ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // پڪ ڏي ته اتي اڳيان تيز رستو آهي
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // `precision` فيلڊ کي فارغ ڪيو پيو وڃي اسٽرنگ کي `max-width` جي طور تي بيان ڪري سگھجي ٿو.
        //
        let s = if let Some(max) = self.precision {
            // جيڪڏهن اسان جو اهو اسٽرنگ ڊگهو آهي ته درستگي ، پوءِ اسان کي گهرجي ته اسان کي تراشي وڃڻ گهرجي.
            // جيتوڻيڪ ٻيون جھنڊيون `fill` ، `width` ۽ `align` وانگر ھميشه ڪم ڪرڻ گھرجن.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM هتي اهو ثابت نٿو ڪري سگھي ته `..i` panic `&s[..i]` نٿو وٺي ، پر اسين knowاڻون ٿا ته اهو panic نٿو ڪري سگھي.
                // X0 `unsafe` کان بچڻ لاءِ `get` + `unwrap_or` استعمال ڪريو ۽ ٻي صورت ۾ هتي panic سان لاڳاپيل ڪوڊ خارج نه ڪريو.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // ھن جڳھ تي `width` ھڪڙي `min-width` پيرا ميٽر مان آھي.
        match self.width {
            // جيڪڏهن اسان وڌ ۾ وڌ ڊيگهه جي هيٺان آهيون ، ۽ گهٽ ۾ گهٽ ڊگهو گهرج ناهي ، پوءِ اسان صرف تار خارج ڪري سگهون ٿا
            //
            None => self.buf.write_str(s),
            // جيڪڏهن اسان وڌ کان وڌ چوٽي تي آهيو ، چيڪ ڪريو ته ڇا اسان گهٽ ۾ گهٽ چوٽي کان مٿي آهيون ، جيڪڏهن اهو آسان آهي ته جيئن تار کي بسائي ڇڏڻ.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // جيڪڏهن اسان ٻنهي کان گهٽ ۽ گهٽ ۾ گهٽ چوٽي هيٺ آهيو ، پوءِ مقرر ڪيل اسٽرنگ + ڪجهه ترتيب سان گهٽ ۾ گهٽ چوٿون ڀريو.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// پري پيڊنگ لکي ۽ اڻ لکندڙ پوسٽ پُڇڻ.
    /// ڪالرز کي يقيني بڻائڻ جي ذميواري آهي پوسٽ پيڊنگ انهي شيءَ جي پيڊنگ کان پوءِ لکي پئي.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// ڇڪيل ڀا partsو ڪندو ۽ پيڊنگ کي لاڳو ڪندو.
    /// فرض ڪري ٿو ته ڪالر اڳ ئي حصن کي گهربل سنجيدگي سان ڏئي چڪو آهي ، انهي ڪري جو ايڪس ڪيوڪس کي نظرانداز ڪري سگهجي ٿو.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // نشاني جي zeroاڻيندڙ صفر پيڊنگ لاءِ ، اسان نشان کي سڀ کان پهريان رهون ٿا ۽ رويي ڪيو ifڻ ته اسان کي شروع کان ڪا نشاني نه هئي.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // هڪ نشاني هميشه پهرين هوندي آهي
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // فارغ ٿيل حصن مان دستخط ختم ڪريو
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // باقي حصا عام پيڊنگ جي عمل مان گذري ٿو.
            let len = formatted.len();
            let ret = if width <= len {
                // ڪوڊنگ ناهي
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // اهو عام ڪيس آهي ۽ اسان هڪ شارٽ ڪٽ وٺون ٿا
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // حفاظت: اهو `flt2dec::Part::Num` ۽ `flt2dec::Part::Copy` لاءِ استعمال ٿئي ٿو.
            // اهو `flt2dec::Part::Num` استعمال ڪرڻ کان محفوظ آهي ڇاڪاڻ ته هر چارار `c` `b'0'` ۽ `b'9'` جي وچ ۾ آهي ، جنهن جو مطلب آهي `s` UTF-8 صحيح آهي.
            // اهو عملي طور تي شايد `flt2dec::Part::Copy(buf)` لاءِ محفوظ طور تي محفوظ آهي ، ڇاڪاڻ ته `buf` سادو ASCII هجڻ گهرجي ، پر اهو ممڪن آهي ته ڪنهن کي خراب قدر لاءِ `buf` لاءِ `flt2dec::to_shortest_str` ۾ وٺي وڃي ڇاڪاڻ ته اهو هڪ عوامي فنڪشن آهي.
            //
            // FIXME: چڪاس ڪريو ته ڇا اهو يو بي جو نتيجو ٿي سگھي ٿو.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 زيرو
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// ھن فارميٽر ۾ موجود بنيادي بفر ڏانھن ڪجھ ڊيٽا لکندو آھي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // هي برابر آهي:
    ///         // لکو! (فارميٽر ، "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// انهي مثال ۾ ڪجهه فارميٽ ٿيل اڻ لکان ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// فارميٽنگ لاءِ ڙا
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// حرف 'fill' طور استعمال ڪيو ويو جڏهن به هڪجهڙائي واري هجي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // اسان ">" سان سا toي طرف سڌي ترتيب ڏي.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// پرچم ظاهر ڪندي ظاهر ڪيو ته ڪهڙي صفائي جي درخواست ڪئي وئي.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// اختياري طور تي متعين عدد چوٽي جيڪا پيداوار هجڻ گهرجي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // جيڪڏهن اسان هڪ چوٽي حاصل ڪئي ، اسان ان کي استعمال ڪريون ٿا
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // ٻي صورت ۾ اسان ڪجهه خاص نٿا ڪريون
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// اختياري طور تي عددي قسمن لاءِ مقرر ڪيو ويو.
    /// متبادل طور تي ، اسٽرنگ جي قسمن لاءِ وڌ کان وڌ چوڻي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // جيڪڏهن اسان هڪ صحت واري حاصل ڪئي ، اسان ان کي استعمال ڪريون ٿا.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // ٻي صورت ۾ اسان 2 تائين ڊفالٽ ڪيو.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// اهو معلوم ڪري ٿو ته `+` پرچم مخصوص ٿيل هو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// اهو معلوم ڪري ٿو ته `-` پرچم مخصوص ٿيل هو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // توهان مائنس سائن چاهيو ٿا؟هڪ آهي!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// اهو معلوم ڪري ٿو ته `#` پرچم مخصوص ٿيل هو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// اهو معلوم ڪري ٿو ته `0` پرچم مخصوص ٿيل هو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // اسان فارمٽرر جي اختيارن کي نظرانداز ڪريون ٿا.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: اهو فيصلو ڪريو ته اسان هنن ٻن جھنڊن لاءِ ڪهڙي عوامي API چاهيون ٿا.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// [`fmt::Debug`] ٺاھيندڙن سان تعاون لاءِ مدد لاءِ تيار ڪيل [`DebugStruct`] بلڊر ٺاھي ٿو.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// ھڪڙي `DebugTuple` ٺاھيندڙ ٺاھيندو آھي جنھن جي مدد سان ٺهيل آھي `fmt::Debug` عملن جي ٺاھڻ لاءِ.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// فهرست جهڙو جوڙيندڙن لاءِ `fmt::Debug` پليٽس جي ٺاھڻ لاءِ مدد لاءِ ٺهيل `DebugList` بلڊر ٺاھي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// سيٽ وانگر اڏاوتن لاءِ `fmt::Debug` پليٽس جي ٺاھڻ لاءِ مدد لاءِ تيار ڪيل `DebugSet` بلڊر ٺاھي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// انهي وڌيڪ پيچيده نموني ۾ ، اسان ميچ بازو جي لسٽ ٺاهڻ لاءِ [`format_args!`] ۽ `.debug_set()` استعمال ڪريون ٿا:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// نقشو جهڙين اڏاوتن لاءِ `fmt::Debug` پليٽس جي ٺاھڻ لاءِ مدد لاءِ ٺهيل `DebugMap` بلڊر ٺاھي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// traits تي بنيادي فارميٽنگ جو لاڳو

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // جيڪڏهن چار کي فرار ٿيڻ جي ضرورت آهي ، اڃا تائين لاڪ فلش ڪيو ۽ لکو ، ٻي صورت ڇڏيو
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // متبادل پرچم پهريان ئي لوئر هيڪس طرفان خاص طور تي علاج ڪيو ويو آهي-اهو ظاهر ڪري ٿو ته ڇا 0x سان پريڪس ڪرڻ گهرجي.
        // اسان انهي کي ڪم ڪرڻ لاءِ استعمال ڪيو صفر کي وڌائڻ يا نه ڪرڻ ، ۽ پوءِ انهيءَ کي اڳڀرائي لاءِ مشروط طور قائم ڪيو.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Display/Debug جي مختلف مختلف قسمن لاء عمل درآمد

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell ادھار طور پر مستعار لیا جاتا ہے اس لیے ہم یہاں اس کی قیمت نہیں دیکھ سکتے۔
                // بدران جاءِ سنڀاليندڙ ڏيکاريو.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// جيڪڏهن توهان توقع ڪئي ته هتي اچڻ جا ٽيسٽ آهن ، core/tests/fmt.rs فائل جي بدران ڏسو ، اهو هتي rt::Piece اڏاوتون ٺاهڻ کان تمام آسان آهي.
//
// crate ۾ پڻ اهڙا تجربا آهن ، انهن لاءِ جيڪي مختص جي ضرورت آهي.