//! اهو آئي ايم ٽي پاران استعمال ڪيل اندروني ماڊل آهي!رن ٽائيم.اهي اڏاوتون وقت کان اڳ فارميٽ جي اسٽرنگن کي ترتيب ڏيڻ لاءِ جامد گرفتارن ڏانهن اماڻيل آهن.
//!
//! اهي وضاحتون پنهنجي `ct` برابر آهن ، پر انهي ۾ فرق آهي ته اهي مستحڪم طور تي مختص ڪري سگهجن ٿيون ۽ هلندڙ وقت لاءِ ٿورو بهتر آهن.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// ممڪن صف بندی جيڪا فارمٽنگ جي هدايت جي حصي جي طور تي درخواست ڪري سگھجي ٿي.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// اشارو ڏنو ويو آهي ته مواد کي ڇڏي رکڻ گهرجي.
    Left,
    /// اشارو ڏنو ويو آهي ته مواد صحيح صحيح هجڻ گهرجي.
    Right,
    /// اشارو ڏنو وڃي ٿو ته مواد وچ ۾ ترتيب ڏنل هجڻ گهرجي.
    Center,
    /// ڪنهن به ترتيب جي درخواست نه ڪئي وئي هئي
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width) ۽ [precision](https://doc.rust-lang.org/std/fmt/#precision) وضاحت ڪندڙ طرفان استعمال ڪيو ويو آهي.
#[derive(Copy, Clone)]
pub enum Count {
    /// لفظي انگ سان متعين ٿيل ، قدر کي محفوظ ڪري ٿو
    Is(usize),
    /// `$` ۽ `*` نحو استعمال ڪندي وضاحت ڪئي وئي ، ايڪسچيڪس ۾ ايڪس آرڪس کي اسٽور ڪري ٿو
    Param(usize),
    /// مخصوص ناهي
    Implied,
}