#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! ترتيب ڏنل ٺاهيل قسمن جي ترتيب لاءِ جوڙجڪ جي وصفن تي مشتمل آهي.
//!
//! اهي سڌو سنئون خام نمائندگي کي صاف ڪرڻ لاءِ اڻ محفوظ ڪوڊ ۾ ٽرانسورس جو هدف طور استعمال ڪري سگهندا آهن.
//!
//!
//! انهن جي تعريف هميشه `rustc_middle::ty::layout` ۾ بيان ڪيل ABI سان ملائڻ گهرجي.
//!

/// `&dyn SomeTrait` وانگر trait اعتراض جي نمائندگي.
///
/// ھن جوڙجڪ وٽ `&dyn SomeTrait` ۽ `Box<dyn AnotherTrait>` وانگر ھڪڙي ئي ترتيب آھي.
///
/// `TraitObject` ٺاھڻ جي ضمانت آھي ، پر اھو trait آبجيوز جو قسم ناھي (مثال طور ، فيلڊز سڌو `&dyn SomeTrait` تي پھچ ناھي) ۽ نه ئي اھو ٺاھ جوڙ کي ڪنٽرول ڪن ٿا (تعریف تبديل ڪرڻ سان `&dyn SomeTrait` واري ليٽ کي تبديل نه ڪيو ويندو).
///
/// اهو صرف ڊزائين ڪيو ويو آهي جيڪو غير محفوظ ڪوڊ جي استعمال سان.
///
/// هتي trait شيون عام طور تي حوالي ڪرڻ جو ڪو طريقو ناهي ، تنهن ڪري هن قسم جي قدرن کي تخليق ڪرڻ جو واحد طريقو ايڪس سيڪس وانگر افعال سان آهي.
/// ساڳي طرح ، `TraitObject` ويليو کان صحيح trait اعتراض ٺاهڻ جو واحد رستو `transmute` سان آهي.
///
/// [transmute]: crate::intrinsics::transmute
///
/// هڪ trait اعتراض کي بي ترتيبي قسم سان ترتيب ڏيڻ ـ هڪ جتي vtable valueاڻيو وڃي ٿو ان ويليو جي قسم سان جنهن جي ڊيٽا پوائنٽر پوائنٽ نه هجڻ جو امڪان آهي شايد اڻ inedاتل طريقي سان.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // هڪ مثال trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // theاڻائيندڙ ٺاھيو trait اعتراض ڪر
/// let object: &dyn Foo = &value;
///
/// // خام نمائندگي کي ڏسو
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ڊيٽا پوائنٽر `value` جو پتو آهي
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // نئين اعتراض جي تعمير ، هڪ مختلف `i32` ڏانهن اشارو ڪندي ، `object` کان `i32` ويبل استعمال ڪرڻ لاءِ محتاط هجڻ جي
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // اهو انهي وانگر ڪم ڪرڻ گهرجي جئين اسان ايڪسڪسيمڪس کان سڌو trait اعتراض تعمير ڪيو هو
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}