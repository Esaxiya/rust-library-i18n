#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! غير ملڪي فنڪشنل انٽرفيس (FFI) پابندين سان لاڳاپيل.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// سي جي `void` جي برابر آهي جڏهن ته [pointer] وانگر استعمال ٿيندو.
///
/// جوهر ۾ ، `*const c_void` سي جي `const void*` جي برابر آهي ۽ `*mut c_void` سي جي `void*` جي برابر آهي.
/// اھو چيو آھي ، اھو *ناھن* سيءَ جي `void` جي قسم جھڙو آھي ، جيڪو Rust جي `()` قسم آھي.
///
/// اشارو ڏيندڙن کي ماڊل ڪرڻ جي لاءِ FFI ۾ موجود آهن ، جيستائين `extern type` تي مستحڪم ٿئي ، اهو خالي بائيٽ صف جي چوڌاري newtype ريپرپر استعمال ڪرڻ جي سفارش ڪئي وئي آهي.
///
/// تفصيل لاءِ [Nomicon] ڏسو.
///
/// جيڪڏهن اهي 1.1.0 کان هيٺ پراڻا Rust ترتيب ڏيڻ واري مدد ڪرڻ چاهين ها استعمال ڪري سگهن ها.
/// Rust 1.30.0 کان پوءِ ، هن تعريف طرفان ٻيهر ايڪسپورٽ ڪيو ويو.
/// وڌيڪ معلومات لاءِ مهرباني ڪري ايڪس اين ايڪس ايڪس پڙهو.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// اين بي ، ايل ايل وي ايم لاءِ باطل پوائنٽر جي قسم کي تسليم ڪرڻ لاءِ ۽ ايڪس ايڪس ايڪس وانگر ايڪسٽينشن افيڪٽس ذريعي ، اسان کي انهي کي L8VM bitcode ۾ i8 * جي نمائندگي ڪرڻ گهرجي.
// هتي استعمال ڪيل اينم انهي کي يقيني بڻائي ٿي ۽ صرف خانگي وارين قسمن جي ڪري "raw" قسم جي غلط استعمال کي روڪيندي آهي.
// اسان کي ٻن قسمن جي ضرورت آهي ، ڇو ته مرتب ڪندڙ ٻي صورت ۾ ريپروٽٽ وصف بابت شڪايت ڪري ٿو ۽ اسان کي گهٽ ۾ گهٽ هڪ ڏيتي ليتي جي ضرورت آهي ڇاڪاڻ ته ٻي صورت ۾ اينم آباد نه هوندو ۽ گهٽ ۾ گهٽ اهڙن اشارن کي ختم ڪرڻ UB هوندو.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// هڪ `va_list` جو بنيادي عمل.
// نالو WIP آهي ، ايڪس اين ايڪس ايڪس کان هاڻي استعمال ڪندي.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f` کان وڌيڪ انڌيريار آهي ، تنهنڪري هر `VaListImpl<'f>` اعتراض هن فنڪشن جي علائقي سان ڳن isيل آهي جنهن ۾ اهو بيان ڪيو ويو آهي
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 اي `va_list` جي اي بي آئي لاڳو.
/// وڌيڪ تفصيل لاءِ [AArch64 Procedure Call Standard] ڏسو.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC اي `va_list` جي اي بي آئي لاڳو.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 اي `va_list` جي اي بي آئي لاڳو.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// هڪ `va_list` لاءِ ريپر
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// هڪ `VaListImpl` هڪ `VaList` ۾ تبديل ڪريو جيڪو بائنري سان مطابقت رکي ٿو C جي `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// هڪ `VaListImpl` هڪ `VaList` ۾ تبديل ڪريو جيڪو بائنري سان مطابقت رکي ٿو C جي `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait کي عوامي انٽرنيٽ ۾ استعمال ڪرڻ جي ضرورت آهي ، جڏهن ته ، trait پاڻ کي هن ماڊل کان ٻاهر استعمال ٿيڻ جي اجازت ناهي.
// صارفين کي trait کي نئين قسم لاءِ لاگو ڪرڻ جي اجازت ڏيڻ (انهي ڪري وائي آرگينز کي نئين قسم تي استعمال ٿيڻ جي اجازت ملي ٿي) ممڪن آهي ته اڻ رڪاوٽ رويي جو سبب بڻجي.
//
// FIXME(dlrobertson): VArgSafe trait کي عوامي انٽرفيس ۾ استعمال ڪرڻ لاءِ استعمال ڪريو پر اهو پڻ يقيني بڻايون ته اهو ڪنهن ٻئي هنڌ استعمال نٿو ڪري سگهي ، trait کي ڪنهن خانگي ماڊل ۾ عوام جي ضرورت آهي.
// هڪ ڀيرو آر ايف سي 2145 لاڳو ڪيو ويو آهي انهي کي بهتر بنائڻ ۾ ڏسجي.
//
//
//
//
mod sealed_trait {
    /// Trait جيڪو اجازت ڏي ٿو قسمن کي [super::VaListImpl::arg] سان استعمال ڪرڻ جي اجازت ڏئي ٿو.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// ايندڙ دليل کي اڳتي وڌايو.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // حفاظت: ڪال ڪندڙ کي `va_arg` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        unsafe { va_arg(self) }
    }

    /// `va_list` کي موجوده جڳھ تي نقل ڪري ٿو.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // حفاظت: ڪال ڪندڙ کي `va_end` لاءِ حفاظتي معاهدو برقرار رکڻ گهرجي.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // حفاظتي: اسان `MaybeUninit` ڏانهن لکون ٿا ، اهڙي طرح اهو شروع ڪيو ويو آهي ۽ `assume_init` قانوني آهي
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: اهو ڪال `va_end` کي سڏڻ گھرجي ، پر ڪو صاف رستو ناهي
        // ضمانت ڏي ته `drop` هميشه ان جي ڪالرڊر ۾ داخل ٿيندي آهي ، تنهن ڪري `va_end` انهي ساڳي فنڪشن کان سڌو `va_copy` وانگر ڊائريڪٽ حاصل ڪندو.
        // `man va_end` اهو ٻڌائي ٿو ته سي هن جي ضرورت آهي ، ۽ ايل ايل وي ايم بنيادي طور تي سي سيمينٽ جي پيروي ڪندو آهي ، تنهن ڪري اسان کي اهو يقيني بڻائڻ جي ضرورت آهي ته `va_end` هميشه هڪ ئي فنڪشن کان `va_copy` طور سڏيو ويندو آهي.
        //
        // وڌيڪ تفصيل لاءِ ، see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // اهو ڪم هينئر تائين آهي ، ڇاڪاڻ ته `va_end` سڀني موجوده ايل ايل وي ايم مقصدن تي جاري آهي.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` يا `va_copy` سان گڏ شروعات ڪرڻ کان بحث ڪندڙ آر ايلسٽڪس X01 کي تباهه ڪيو.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// آرگسٽسٽ `src` جي موجوده جڳھ کي نقل ڪندڙ آر ايل ايلسٽ `dst` ڏانھن نقل ڪندو.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap` کان `T` قسم جو هڪ دليل لوڊ ڪريو ۽ دليل کي وڌايو `ap` ڏانهن.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}