//! ياداشت کي مختص ڪرڻ وارا API

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` غلطي مختص ڪرڻ جي ناڪامي جي نشاندهي ڪري ٿي جيڪا وسيلن جي ختم ٿيڻ يا ڪنهن غلط ڪم جي سبب ٿي سگهي ٿي جڏهن مختص ڪيل انپٽ جي تقسيم کي هن مختص ڪندڙ سان گڏ هجن.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (اسان کي trait غلطي جي هيٺين اسٽوريج لاءِ ضرورت آهي)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` جو هڪ نفاذ [`Layout`][] ذريعي بيان ڪيل ڊيٽا جي صوابدیدي بلاڪن کي مختص ، وڌائي ، سکڻ ۽ ختم ڪرڻ ڪري ٿو.
///
/// `Allocator` ZSTs ، حوالي ، يا سمارٽ پوائنٽرن تي لاڳو ٿيڻ جي لاءِ تيار ڪيو ويو آهي ڇاڪاڻ ته `MyAlloc([u8; N])` وانگر هڪ مختص ڪرڻ وارو حرڪت نٿو ڪري سگهجي ، مختص ڪيل ميموري ڏانهن اشارو ڪندڙن کي تازه ڪاري ڪرڻ کان بغير.
///
/// [`GlobalAlloc`][] جي نسبت ، `Allocator` ۾ صفر سائز وارا مختص ڪيا وڃن.
/// جيڪڏهن هڪ هيٺيان مختص ڪندڙ هن کي سپورٽ نٿو ڪري (جهملڪو وانگر) يا خالي پوائنٽر واپس آڻيندو آهي (جهڙوڪ `libc::malloc`) ، اهو عملدرآمد طرفان پڪڙجڻ گهرجي.
///
/// ### هن وقت يادگيري لاءِ وئي
///
/// ڪجھ طريقن مان ھڪ گھربل آھي ته ميموري بلاڪ * في الحال مختص ڪيو وڃي.هن جو مطلب آهي:
///
/// * انهي ميموري بلاڪ جو شروعاتي پتو اڳ ۾ ئي [`allocate`] ، [`grow`] ، يا [`shrink`] طرفان واپس ڪيو ويو هو ، ۽
///
/// * بعد ۾ ياداشت بلاڪ ختم نه ڪيو ويو آهي ، جتي بلاڪ يا ته سڌو سنئون ocيريو ويو آهي [`deallocate`] ڏانهن يا ته [`grow`] يا [`shrink`] ڏانهن منتقل ڪيو ويو جيڪي `Ok` موٽائي اچن ٿا.
///
/// جيڪڏهن `grow` يا `shrink` واپس اچي چڪا آهن `Err` ، منظور ٿيل پوائنٽر صحيح رهي ٿو.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### ميموري فٽنگ
///
/// ڪجھ طريقن جي ضرورت آھي ته ترتيب *فٽ* ميموري بلاڪ.
/// ان جو مطلب ڇا آهي "fit" ترتيب ڏيڻ لاءِ ، ميموري بلاڪ جو مطلب آهي (يا برابر طور تي ، ميموري بلاڪ لاءِ "fit" ترتيب ڏيڻ) اهو آهي ته هيٺيون شرطون لازمي طور تي هجن:
///
/// * [`layout.align()`] وانگر ساڳيو بلاڪ سان لازمي طور تي مختص ڪيا وڃن ، ۽
///
/// * مهيا ڪيل [`layout.size()`] ھيٺ `min ..= max` ۾ گرڻ گھرجي ، جتي:
///   - `min` تازي طور تي ترتيب ڏنل سائيز جي شڪل آهي بلاڪ کي مختص ڪرڻ ، ۽
///   - `max` [`allocate`] ، [`grow`] ، يا [`shrink`] کان واپسي واري تازي حقيقي ماپ آهي.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * هڪ مختص ڪندڙ کان واپس ڪيل ياداشت بلاڪ لازمي ياداشت کي درست ڪرڻ ۽ انهن جي صحيح برقرار رکڻ جي وقت تائين ۽ ان جون سڀئي کلون ختم ٿي وينديون آهن ،
///
/// * مختص ڪرڻ واري ڪلوننگ يا حرڪت ۾ انهي يادگيري مان واپس ڪيل ياداشتن جا بلاڪ غلط نه هجڻ گهرجن.هڪ کلونڊ مختص ڪندڙ هڪ ئي مختص ڪندڙ وانگر عمل ٿيڻ گهرجي ، ۽
///
/// * ڪنهن به پوائنٽر ميموري بلاڪ ڏانهن جيڪو [*currently allocated*] هوندو آهي مختص ڪيل ڪنهن ٻئي طريقي ڏانهن منتقل ڪري سگهجي ٿو.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// ميموري جو بلاڪ مختص ڪرڻ جي ڪوشش ڪئي وڃي ٿي.
    ///
    /// ڪاميابي تي ، هڪ [`NonNull<[u8]>`][NonNull] موٽندو آهي `layout` جي سائيز ۽ ترتيب جي ضمانت.
    ///
    /// واپسي واري بلاڪ کي `layout.size()` طرفان بيان ڪيل ماپ کان وڌيڪ وڏو سائيز ٿي سگهي ٿو ، ۽ شايد انهي جي مواد کي ابتدائي به نه هجي.
    ///
    /// # Errors
    ///
    /// `Err` واپس ڪرڻ ظاهر ڪري ٿو ته يا ته ياداشت ختم ٿي وئي آهي يا `layout` مختص ڪندڙ سائيز يا صفائي واري رڪاوٽن کي پورو نٿو ڪري.
    ///
    /// عمل درآمد ڪرڻ جي حوصلہ افزائي ڪئي وئي آهي ايڪس آرڪس کي ياد رکڻ جي بجاء يادگيري جي خارج ٿيڻ تي panهلائڻ يا ختم ٿيڻ بدران ، پر اهو سخت ضرورت ناهي.
    /// (خاص طور تي: اهو trait انهي بنيادي آڳاٽي مختص ڪيل لائبريري تي لاڳو ڪرڻ لاءِ *قانوني* آهي جيڪو ياداشت جي گھٽتائي تي ختم ٿئي ٿو.)
    ///
    /// مبلغين جي غلطي جي جواب ۾ حساب کي ختم ڪرڻ جي خواهشمند گراهڪن کي [`handle_alloc_error`] فنڪشن سڏڻ جي همٿ ڏياري وڃي ٿي ، بجاءِ ان جي ته سڌو سنئون `panic!` يا انهي وانگر گهرايو وڃي.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` وانگر ظاهر ٿيو ، پر انهي کي پڻ يقيني بڻائي ٿو ته واپسي ياداشت صفر ابتدائي آهي.
    ///
    /// # Errors
    ///
    /// `Err` واپس ڪرڻ ظاهر ڪري ٿو ته يا ته ياداشت ختم ٿي وئي آهي يا `layout` مختص ڪندڙ سائيز يا صفائي واري رڪاوٽن کي پورو نٿو ڪري.
    ///
    /// عمل درآمد ڪرڻ جي حوصلہ افزائي ڪئي وئي آهي ايڪس آرڪس کي ياد رکڻ جي بجاء يادگيري جي خارج ٿيڻ تي panهلائڻ يا ختم ٿيڻ بدران ، پر اهو سخت ضرورت ناهي.
    /// (خاص طور تي: اهو trait انهي بنيادي آڳاٽي مختص ڪيل لائبريري تي لاڳو ڪرڻ لاءِ *قانوني* آهي جيڪو ياداشت جي گھٽتائي تي ختم ٿئي ٿو.)
    ///
    /// مبلغين جي غلطي جي جواب ۾ حساب کي ختم ڪرڻ جي خواهشمند گراهڪن کي [`handle_alloc_error`] فنڪشن سڏڻ جي همٿ ڏياري وڃي ٿي ، بجاءِ ان جي ته سڌو سنئون `panic!` يا انهي وانگر گهرايو وڃي.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // حفاظت: `alloc` صحيح ميموري بلاڪ موٽندي آهي
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` پاران ڏنل ياداشت کي ختم ڪري ٿو.
    ///
    /// # Safety
    ///
    /// * `ptr` هن مختص ڪندڙ ذريعي ياداشت جي [*currently allocated*] جي بلاڪ کي رد ڪرڻ گهرجي ، ۽
    /// * `layout` ياد رکڻ گهرجي [*fit*] انهي ميموري جو بلاڪ.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// ميموري بلاڪ کي وڌائڻ جي ڪوشش ڪئي وڃي ٿي.
    ///
    /// پوائنٽر ۽ مختص ڪيل ميموري جي اصل ماپ تي مشتمل [`NonNull<[u8]>`][NonNull] هڪ نئون ريٽ ڏئي ٿو.پوائنٽر `new_layout` پاران بيان ڪيل ڊيٽا کي رکڻ لاءِ مناسب آهي.
    /// انهي کي پورو ڪرڻ لاءِ ، مختصرو `ptr` جو حوالو ڏئي مختص ڪري سگھي ٿو ته نئين ترتيب کي پورو ڪري.
    ///
    /// جيڪڏهن اهو `Ok` موٽائي ٿو ، ته `ptr` جي حوالي ڪيل ميموري بلاڪ جي ملڪيت هن مختصه ڏانهن منتقل ڪيو ويو آهي.
    /// شايد ياداشت کي آزاد ڪيو ويو هجي يا نه هجي ، ۽ اهو ناقابل استعمال سمجهي وڃي جيستائين اهو واپس وٺي واپس ڪالر تي هن طريقي جي قيمت جي ذريعي منتقل ڪيو وڃي.
    ///
    /// جيڪڏهن اهو طريقو `Err` ڏانهن موٽائي ٿو ، ته ميموري بلاڪ جي ملڪيت هن مختصرن ڏانهن منتقل نه ڪئي وئي آهي ، ۽ ميموري بلاڪ جو مواد تبديل ٿيل آهي.
    ///
    /// # Safety
    ///
    /// * `ptr` هن مختص ڪندڙ ذريعي ياداشت جي [*currently allocated*] جي بلاڪ کي رد ڪرڻ گهرجي.
    /// * `old_layout` لازمي [*fit*] اھو ميموري جو بلاڪ (`new_layout` دليل ھن کي قابل نھ ڪرڻ جي ضرورت آھي.)
    /// * `new_layout.size()` `old_layout.size()` کان وڌيڪ يا برابر ھئڻ گھرجي.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` کي واپس ڏئي ٿو جيڪڏھن نئين ترتيب مختص ڪندڙ کي سائيز ۽ قطار جي تقسيم واري ضابطن کي پورو نٿو ڪري ، يا ٻي صورت ۾ وڌندي آھي ناڪامي ٿي.
    ///
    /// عمل درآمد ڪرڻ جي حوصلہ افزائي ڪئي وئي آهي ايڪس آرڪس کي ياد رکڻ جي بجاء يادگيري جي خارج ٿيڻ تي panهلائڻ يا ختم ٿيڻ بدران ، پر اهو سخت ضرورت ناهي.
    /// (خاص طور تي: اهو trait انهي بنيادي آڳاٽي مختص ڪيل لائبريري تي لاڳو ڪرڻ لاءِ *قانوني* آهي جيڪو ياداشت جي گھٽتائي تي ختم ٿئي ٿو.)
    ///
    /// مبلغين جي غلطي جي جواب ۾ حساب کي ختم ڪرڻ جي خواهشمند گراهڪن کي [`handle_alloc_error`] فنڪشن سڏڻ جي همٿ ڏياري وڃي ٿي ، بجاءِ ان جي ته سڌو سنئون `panic!` يا انهي وانگر گهرايو وڃي.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // سافٽويئر: ڇاڪاڻ ته `new_layout.size()` برابر يا برابر هجڻ گھرجي
        // `old_layout.size()`, ٻئي پراڻي ۽ نئين يادگيري واري ترتيب `old_layout.size()` بائٽس پڙهڻ ۽ لکڻ لاءِ صحيح آهي.
        // انهي کان علاوه ، ڇاڪاڻ ته اڳئين ورهاست کي اڃا تائين نيڪال نه ڪيو ويو آهي ، اهو `new_ptr` مٿان چڙهائي نٿو سگهي.
        // ان ڪري ، ايڪس 00X تي ڪال محفوظ آهي.
        // `dealloc` لاءِ حفاظتي معاهدو ڪال ڪندڙ کي برقرار رکڻ گهرجي.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// جهڙوڪر `grow` ، پر اهو پڻ انهي ڳالهه کي يقيني بڻائي ٿو ته نوان مواد موٽڻ کان پهريان صفر تي سيٽ ڪيا ويا آهن.
    ///
    /// ميموري بلاڪ ڪامياب ڪال ڪرڻ کانپوءِ هيٺين مواد تي مشتمل هوندي
    /// `grow_zeroed`:
    ///   * بائٽس `0..old_layout.size()` اصل مختص کان محفوظ آھن.
    ///   * بائيٽ `old_layout.size()..old_size` يا ته محفوظ ٿي ويندي يا صفر ٿيل آهي ، مختص ڪندڙ عمل درآمد تي منحصر هوندو.
    ///   `old_size` `grow_zeroed` ڪال کان پهريان ميموري بلاڪ جي ماپ جو حوالو ڏئي ٿو ، جيڪو شايد انهي کان وڌيڪ وڏو هجي جيڪو اصل ۾ درخواست ڪئي وئي هجي جڏهن اهو مختص ڪيو ويو هو.
    ///   * بائٽس `old_size..new_size` صفر آهن.ايڪسڪسيمڪس `grow_zeroed` ڪال پاران واپس موٽندڙ ميموري بلاڪ جي ماپ کي رد ڪري ٿو.
    ///
    /// # Safety
    ///
    /// * `ptr` هن مختص ڪندڙ ذريعي ياداشت جي [*currently allocated*] جي بلاڪ کي رد ڪرڻ گهرجي.
    /// * `old_layout` لازمي [*fit*] اھو ميموري جو بلاڪ (`new_layout` دليل ھن کي قابل نھ ڪرڻ جي ضرورت آھي.)
    /// * `new_layout.size()` `old_layout.size()` کان وڌيڪ يا برابر ھئڻ گھرجي.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` کي واپس ڏئي ٿو جيڪڏھن نئين ترتيب مختص ڪندڙ کي سائيز ۽ قطار جي تقسيم واري ضابطن کي پورو نٿو ڪري ، يا ٻي صورت ۾ وڌندي آھي ناڪامي ٿي.
    ///
    /// عمل درآمد ڪرڻ جي حوصلہ افزائي ڪئي وئي آهي ايڪس آرڪس کي ياد رکڻ جي بجاء يادگيري جي خارج ٿيڻ تي panهلائڻ يا ختم ٿيڻ بدران ، پر اهو سخت ضرورت ناهي.
    /// (خاص طور تي: اهو trait انهي بنيادي آڳاٽي مختص ڪيل لائبريري تي لاڳو ڪرڻ لاءِ *قانوني* آهي جيڪو ياداشت جي گھٽتائي تي ختم ٿئي ٿو.)
    ///
    /// مبلغين جي غلطي جي جواب ۾ حساب کي ختم ڪرڻ جي خواهشمند گراهڪن کي [`handle_alloc_error`] فنڪشن سڏڻ جي همٿ ڏياري وڃي ٿي ، بجاءِ ان جي ته سڌو سنئون `panic!` يا انهي وانگر گهرايو وڃي.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // سافٽويئر: ڇاڪاڻ ته `new_layout.size()` برابر يا برابر هجڻ گھرجي
        // `old_layout.size()`, ٻئي پراڻي ۽ نئين يادگيري واري ترتيب `old_layout.size()` بائٽس پڙهڻ ۽ لکڻ لاءِ صحيح آهي.
        // انهي کان علاوه ، ڇاڪاڻ ته اڳئين ورهاست کي اڃا تائين نيڪال نه ڪيو ويو آهي ، اهو `new_ptr` مٿان چڙهائي نٿو سگهي.
        // ان ڪري ، ايڪس 00X تي ڪال محفوظ آهي.
        // `dealloc` لاءِ حفاظتي معاهدو ڪال ڪندڙ کي برقرار رکڻ گهرجي.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// ميموري بلاڪ کي سٿڻ جي ڪوشش ڪئي وڃي ٿي.
    ///
    /// پوائنٽر ۽ مختص ڪيل ميموري جي اصل ماپ تي مشتمل [`NonNull<[u8]>`][NonNull] هڪ نئون ريٽ ڏئي ٿو.پوائنٽر `new_layout` پاران بيان ڪيل ڊيٽا کي رکڻ لاءِ مناسب آهي.
    /// انهي کي پورو ڪرڻ لاءِ ، مختصار `ptr` پاران نئين ترتيب کي ترتيب ڏيڻ لاءِ مختص ڪيل رقم کي ختم ڪري سگهي ٿو.
    ///
    /// جيڪڏهن اهو `Ok` موٽائي ٿو ، ته `ptr` جي حوالي ڪيل ميموري بلاڪ جي ملڪيت هن مختصه ڏانهن منتقل ڪيو ويو آهي.
    /// شايد ياداشت کي آزاد ڪيو ويو هجي يا نه هجي ، ۽ اهو ناقابل استعمال سمجهي وڃي جيستائين اهو واپس وٺي واپس ڪالر تي هن طريقي جي قيمت جي ذريعي منتقل ڪيو وڃي.
    ///
    /// جيڪڏهن اهو طريقو `Err` ڏانهن موٽائي ٿو ، ته ميموري بلاڪ جي ملڪيت هن مختصرن ڏانهن منتقل نه ڪئي وئي آهي ، ۽ ميموري بلاڪ جو مواد تبديل ٿيل آهي.
    ///
    /// # Safety
    ///
    /// * `ptr` هن مختص ڪندڙ ذريعي ياداشت جي [*currently allocated*] جي بلاڪ کي رد ڪرڻ گهرجي.
    /// * `old_layout` لازمي [*fit*] اھو ميموري جو بلاڪ (`new_layout` دليل ھن کي قابل نھ ڪرڻ جي ضرورت آھي.)
    /// * `new_layout.size()` `old_layout.size()` کان نن orو يا انهي جي برابر هجڻ گھرجي.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` کي واپسي ڏئي ٿو جيڪڏھن نئين ترتيب مختص ڪندڙ کي سائيز ۽ رٿا جي تقسيم واري تقسيم وارن کي نٿي ملي ، يا جيڪڏھن نن otherwiseي رھڻ ۾ ناڪام ٿئي ٿو.
    ///
    /// عمل درآمد ڪرڻ جي حوصلہ افزائي ڪئي وئي آهي ايڪس آرڪس کي ياد رکڻ جي بجاء يادگيري جي خارج ٿيڻ تي panهلائڻ يا ختم ٿيڻ بدران ، پر اهو سخت ضرورت ناهي.
    /// (خاص طور تي: اهو trait انهي بنيادي آڳاٽي مختص ڪيل لائبريري تي لاڳو ڪرڻ لاءِ *قانوني* آهي جيڪو ياداشت جي گھٽتائي تي ختم ٿئي ٿو.)
    ///
    /// مبلغين جي غلطي جي جواب ۾ حساب کي ختم ڪرڻ جي خواهشمند گراهڪن کي [`handle_alloc_error`] فنڪشن سڏڻ جي همٿ ڏياري وڃي ٿي ، بجاءِ ان جي ته سڌو سنئون `panic!` يا انهي وانگر گهرايو وڃي.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // حفاظت: ڇاڪاڻ ته `new_layout.size()` کان گھٽ يا برابر ھجن
        // `old_layout.size()`, ٻئي پراڻي ۽ نئين يادگيري واري ترتيب `new_layout.size()` بائٽس پڙهڻ ۽ لکڻ لاءِ صحيح آهي.
        // انهي کان علاوه ، ڇاڪاڻ ته اڳئين ورهاست کي اڃا تائين نيڪال نه ڪيو ويو آهي ، اهو `new_ptr` مٿان چڙهائي نٿو سگهي.
        // ان ڪري ، ايڪس 00X تي ڪال محفوظ آهي.
        // `dealloc` لاءِ حفاظتي معاهدو ڪال ڪندڙ کي برقرار رکڻ گهرجي.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `Allocator` هن مثال جي لاءِ "by reference" ايڊاپٽر ٺاهيو.
    ///
    /// واپسي وارو اڊاپٽر `Allocator` کي به لاڳو ڪندو آهي ۽ بس انهي کي قرض وٺي سگهندو آهي.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // حفاظت: حفاظت جو معاهدو سڏيندڙ طرفان برقرار رکڻ لازمي آهي
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // حفاظت: حفاظت جو معاهدو سڏيندڙ طرفان برقرار رکڻ لازمي آهي
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // حفاظت: حفاظت جو معاهدو سڏيندڙ طرفان برقرار رکڻ لازمي آهي
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // حفاظت: حفاظت جو معاهدو سڏيندڙ طرفان برقرار رکڻ لازمي آهي
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}