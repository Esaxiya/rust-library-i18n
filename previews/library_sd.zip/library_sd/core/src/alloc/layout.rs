use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// جڏهن ته اها فنڪشن هڪ جڳهه تي استعمال ڪئي وئي ۽ ان جي عملدرآمد لا ان لائن ٿي سگهي ٿي ، rustc ائين ڪرڻ لاءِ اڳيون ڪوششون ڪيون ويون:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// ميموري جي بلاڪ جي ترتيب.
///
/// ايڪسڪسيمڪس جو هڪ مثال ياداشت جي هڪ خاص ترتيب بابت بيان ڪري ٿو.
/// توهان `Layout` مٿي هڪ مختص ڪندڙ کي ڏيڻ لاءِ انپٽ جي طور تي ٺاهي رهيا آهيو.
///
/// سڀني ترتيبن ۾ منسلڪ سائيز ۽ طاقت جي ھڪڙي ٻنھي آھي.
///
/// (نوٽ ڪريو ته ترتيبون *نه* گهربل آهن غير صفر سائيز هجڻ جي ، جيتوڻيڪ `GlobalAlloc` ضرورت آهي ته سڀ ياداشت جي درخواستون سائيز ۾ غير صفر هجڻ گهرجي.
/// ڪاليندڙ کي لازمي طور تي يقيني بڻائڻ گهرجي ته اهڙيون حالتون ملنديون آهن ، مخصوص تقاضا استعمال ڪندڙن کي لوسر جي ضرورتن سان گڏ استعمال ڪن ، يا وڌيڪ لينڪس `Allocator` انٽررفيٽ استعمال ڪن.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // ياداشت جي درخواست ڪيل بلاڪ جي ماپ ، بائيٽ ۾ ماپي وئي.
    size_: usize,

    // ميموري جي درخواست واري بلاڪ جي ترتيب ، بائيٽ ۾ ماپي.
    // اسان انهي کي يقيني بڻايون ته اهو هميشه هڪ پاور آف ٻن جو آهي ، ڇاڪاڻ ته API وانگر ايڪسڪسيمڪس انهي جي ضرورت آهي ۽ لي آئوٽ ٺاهيندڙن تي مسلط ٿيڻ هڪ معقول جبر آهي.
    //
    //
    // (تنهن هوندي ، اسان مطابق طور تي `ترتيب ڏيڻ جي ضرورت ناهي== sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// ٺهيل `size` ۽ `align` مان `Layout` ٺاهي ٿو ، يا `LayoutError` موٽائي ٿو ، جيڪڏھن ڪنھن به پوئين شرطن مان پورا نٿا ٿين.
    ///
    /// * `align` صفر نه هجڻ گهرجي ،
    ///
    /// * `align` لازمي طور ٻن جي طاقت هجي
    ///
    /// * `size`, جڏهن `align` جي ويجهي گهڻن طرف گول ٿي وڃي ، ختم نه ٿيڻ گهرجي (يعني ، گول ٿيل قيمت `usize::MAX` کان گهٽ يا برابر هجڻ گهرجي).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (طاقت-ٻن جو مطلب آهي سڌو!=0.)

        // گول ٿيل سائيز آهي:
        //   size_rounded_up=(سائيز + سڌو ، 1)&! (سڌو ، 1) ؛
        //
        // اسان مٿي knowاڻون ٿا ته مٿيان ترتيب!=0.
        // جيڪڏهن شامل ڪرڻ (سڌو ، 1) اوور فلو نه ٿو ٿئي ، ته پوءِ گول ڪرڻ ٺيڪ ٿي ويندو.
        //
        // بالآخر ، ۽-ماسڪنگ سان! (سڌو ، 1) صرف گهٽ آرڊر جي بٽ کي ڪٽيندو.
        // اهڙيءَ طرح جيڪڏهن رقم سان گهڻي فراواني ٿئي ٿي ، ۽-ماسڪ ان اوور فلو کي رد ڪرڻ لاءِ ڪافي مقدار ۾ رد نٿو ڪري سگهي.
        //
        //
        // مٿين جو مطلب آهي ته چڪاس جي اوور فلو جي جاچ ٻئي ضروري ۽ ڪافي آهي.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // حفاظت: `from_size_align_unchecked` لاءِ شرطون ٿي ويون آهن
        // مٿي چيڪ ڪيو.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// ترتيب ڏئي ٿو ، سڀني چيڪن کي نظرانداز ڪري ڇڏيو.
    ///
    /// # Safety
    ///
    /// اهو فنڪشن غير محفوظ آهي جئين ته انهي جي [`Layout::from_size_align`] شرطن جي تصديق نه ٿي ٿئي.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // حفاظت: ڪال ڪرڻ واري کي يقيني بڻائڻ گهرجي ته `align` صفر کان وڏو آهي.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// ھن ترتيب جي ميموري بلاڪ لاءِ بائيٽ ۾ گھٽ گھٽ.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// ھن ترتيب جي ميموري بلاڪ لاءِ گھٽ ۾ گھٽ بائيٽ ترتيب ڏيڻ
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// ھڪڙي `Layout` ٺاھيو ٿا ھڪڙي قسم جي `T` کي رکڻ لاء مناسب.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // حفاظت: صف بندي Rust پاران ضمانت ڪئي وئي آهي ته ٻن ۽
        // اسان جي ايڊريس جي جڳھ تي فٽ ڪرڻ جي ضمانت آهي.
        // نتيجي طور هتي اڻ جانچيل تعمير ڪندڙ استعمال ڪريو ته ڪوڊ کي داخل ڪرڻ کان بچڻ لاءِ panics جيڪڏهن اهو بهتر نموني بهتر ناهي ڪيو ويو.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// خاڪو بيان ڪري ٿو ترتيب جو هڪ ريڪارڊ جيڪو `T` جي پٺڀرائي جي structureانچي کي مختص ڪرڻ ۾ استعمال ٿي سگهي ٿو (جيڪو هڪ trait يا هڪ ٻي سلائيٽ وانگر ٻلائز ٿيل قسم ٿي سگهي ٿو).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // حفاظت: `new` ۾ منطقي ڏسو ڇو ته اهو غير محفوظ ٿيل استعمال ڪيو پيو وڃي
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// خاڪو بيان ڪري ٿو ترتيب جو هڪ ريڪارڊ جيڪو `T` جي پٺڀرائي جي structureانچي کي مختص ڪرڻ ۾ استعمال ٿي سگهي ٿو (جيڪو هڪ trait يا هڪ ٻي سلائيٽ وانگر ٻلائز ٿيل قسم ٿي سگهي ٿو).
    ///
    /// # Safety
    ///
    /// جيڪڏهن اها هيٺين حالتون جهليندي ، اهو ڪم صرف محفوظ هوندو.
    ///
    /// - جيڪڏهن `T` `Sized` آهي ، اهو فنڪشن هميشه محفوظ آهي.
    /// - جيڪڏهن `T` جو غير ترتيب ڏنل دم آهي:
    ///     - هڪ [slice] ، پوءِ سلائس جي ڊيگهه جي ڊيگهه لازمي جڙيل هجڻ گهرجي ، ۽ *س valueو ويل سائيز*(متحرڪ دم جي ڊيگهه + جامد ماپ واري اڳياڙي) جي ماپ `isize` ۾ لازمي طور تي لازمي هجڻ گهرجي.
    ///     - هڪ [trait object] ، پوءِ پوائنٽر جو Vtable حصو x02X واري قسم جي درست vtable ڏانهن اشارو ڪرڻ گهرجي هڪ اڻ سڌريل اتحاد سان حاصل ڪيل ، ۽ *پوري ويل سائيز*(متحرڪ دم جي ڊيگهه + جامد ماپ واري اڳياڙي) جي ماپ `isize` ۾ لازمي هجڻ گهرجي.
    ///
    ///     - هڪ (unstable) [extern type] ، پوءِ اهو فنڪشن هميشه لاءِ محفوظ آهي ، پر شايد panic يا ٻي صورت ۾ غلط ويليو موٽائي سگهي ، جيئن ته ٻاهرين قسم جي ترتيب جي layoutاڻ نه هجي.
    ///     اهو ساڳيو ئي رويو [`Layout::for_value`] تي خارجي قسم جي دم جي حوالي آهي.
    ///     - ٻي صورت ۾ ، محافظ طور تي هن فنڪشن کي سڏڻ جي اجازت ناهي.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // حفاظت: اسان سڏيندڙ کي انهن افعال جي شرائط سان گڏ گذاريندا آهيون
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // حفاظت: `new` ۾ منطقي ڏسو ڇو ته اهو غير محفوظ ٿيل استعمال ڪيو پيو وڃي
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `NonNull` ٺاهي ٿو جيڪا خلقي آهي ، پر هن لي آئوٽ لاءِ بهتر نموني.
    ///
    /// ياد رکجو ته پوائنٽر ويليو ممڪن طور تي هڪ صحيح پوائنٽر جي نمائندگي ڪندو ، انهي جو مطلب اهو لازمي طور تي "not yet initialized" موڪليوinel قيمت طور استعمال نه ڪيو وڃي.
    /// اقسام جيڪي سست طريقي سان مختص ڪندا آهن ڪنهن نه ڪنهن ٻئي طريقي سان شروعاتي طرف جڙڻ لازمي آهن
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // حفاظت: صفائي جي ضمانت آهي غير صفر
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// ترتيب بيان ڪري ٿو ليٽنگ کي بيان ڪري ٿو جيڪا `self` وانگر ساڳئي ترتيب واري قدر کي رکي سگهي ٿي ، پر اهو پڻ ايڪس01ڪس جي ترتيب سان ترتيب ڏنل آهي (بائيٽ ۾ ماپيل).
    ///
    ///
    /// جيڪڏهن `self` اڳ ۾ ئي مقرر ڪيل صفن کي پورا ڪري ، پوءِ `self` موٽائي ٿو.
    ///
    /// ياد رهي ته هي طريقو مجموعي سائيز ۾ ڪوبه پيڊنگ شامل نه ٿو ڪري ، قطع نظر ته موٽڻ واري ترتيب جي هڪ الڳ صفائي آهي.
    /// ٻين لفظن ۾ ، جيڪڏهن `K` سائيز 16 آهي ، `K.align_to(32)` به *اڃا به* سائيز 16 هوندو.
    ///
    /// جيڪڏهن `self.size()` ۽ ڏنل `align` جو ميلاپ [`Layout::from_size_align`] ۾ درج ٿيل حالتن جي ڀڃڪڙي ٿئي ٿي ته غلطي واپس ڏي ٿي.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// پيڊنگ جي مقدار کي واپس ڏئي ٿو اسان کي `self` بعد داخل ڪرڻ لازمي آهي انهي کي يقيني بڻائڻ ته هيٺ ڏنل پتو `align` کي مطمئن ڪندو (بائيٽ ۾ ماپيل).
    ///
    /// مثال طور ، جيڪڏهن `self.size()` 9 آهي ، ته `self.padding_needed_for(4)` 3 موٽائي ٿو ، ڇاڪاڻ ته انهي 4_ ايڊريس حاصل ڪرڻ جي لاءِ پيڊنگ جي گهٽ ۾ گهٽ بائيٽ جي نمبر آهي (فرض ڪيو وڃي ته ياداشت جي يادگيري بلاڪ 4 ترتيب واري ايڊريس تي شروع ٿيندي).
    ///
    ///
    /// جيڪڏهن `align` هڪ ٻن جي طاقت نه آهي ، ته هن فنڪشن جي واپسي قيمت جو ڪو مطلب ناهي.
    ///
    /// ياد رکو ته واپسي جي قيمت جي افاديت `align` جي ضرورت آھي ياداشت جي سموري مختص بلاڪ لاءِ شروعاتي ايڊريس جي صفائي کان گھٽ يا برابر.انهي تڪڙ کي مطمئن ڪرڻ جو هڪڙو طريقو `align <= self.align()` کي يقيني بڻائڻ آهي.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // گهريل قيمت آهي:
        //   len_rounded_up=(لين + سڌو ، 1) ۽! (سڌي ٿيل ، 1) ؛
        // ۽ پوءِ اسان پيڊنگ جو فرق موٽايو: `len_rounded_up - len`.
        //
        // اسان س modي نموني ماڊريٽري رياضياتي استعمال ڪريون ٿا.
        //
        // 1. ترتيب ڏيڻ گارنٽي آھي> 0 ، تنھنڪري سڌو ، 1 هميشه صحيح آھي.
        //
        // 2.
        // `len + align - 1` وڌيڪ `align - 1` کان وڌيڪ وڇائي سگھي ٿو ، انهي ڪري `!(align - 1)` سان&-mask انهي کي يقيني بڻائي سگهندي ته اوور فلو جي صورت ۾ ، `len_rounded_up` پنهنجو پاڻ 0 ٿي ويندو.
        //
        //    اهڙيء طرح موٽڻ واري پيڊنگ ، جڏهن `len` سان شامل ڪئي وئي ، پيداوار 0 ، جنهن کي عارضي طور تي هلي ويل ايڪسينڪس کي مطمئن رکي ٿو.
        //
        // (يقينا ، ياداشت جي بلاڪ کي مختص ڪرڻ جي ڪوشش ڪئي وئي آهي جن جي ماپ ۽ مٿي ڪرڻ وارو انداز مٿي inاڻايل طريقي سان مختص ڪندڙ کي به غلطي پيدا ڪرڻ گهرجي.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// ھن ترتيب جي سائيز کي گول ڪري ترتيب واري شيءَ جي گھڻائي ٺاھي ٿو.
    ///
    ///
    /// اهو جوڙ جي موجوده سائيز ڏانهن `padding_needed_for` جو نتيجو شامل ڪرڻ جي برابر آهي.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // اهو وڌي نه سگهي ٿو.لي آئوٽ جي invariant مان اقتباس:
        // > `size`, جڏهن `align` جي ويجهي گهڻن تائين گول ڪيو ويو ،
        // > لازمي طور تي ختم نه ٿيڻ گهرجي (يعني ، گول ڪيل قدر گهٽ کان گهٽ هجڻ گهرجي
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` مثالن کي `self` مثالن جو رڪارڊ بيان ڪندي ترتيب ٺاهي ٿو ، هر هڪ جي وچ ۾ پيڊنگ جي مناسب مقدار کي يقيني بڻائڻ لاءِ ته هر مثال پنهنجي گهربل سائيز ۽ مطابق ترتيب ڏني وڃي.
    /// ڪامياب تي ، واپسي `(k, offs)` آهي جتي `k` ترتيب واري ترتيب آهي ۽ `offs` صف ۾ هر عنصر جي شروعات جي وچ ۾ فاصلو آهي.
    ///
    /// رياضياتي اوورفول تي ، واپسي `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // اهو وڌي نه سگهي ٿو.لي آئوٽ جي invariant مان اقتباس:
        // > `size`, جڏهن `align` جي ويجهي گهڻن تائين گول ڪيو ويو ،
        // > لازمي طور تي ختم نه ٿيڻ گهرجي (يعني ، گول ڪيل قدر گهٽ کان گهٽ هجڻ گهرجي
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SAFETY: self.align اڳ ۾ ئي صحيح هجڻ جي isاتل آھي ۽ All_size ٿي آھي
        // اڳ ۾ ئي بيٺل آهي
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `next` جي پٺيان ريڪارڊ بيان ڪندي ٺاهي ٿو `next` ، `next` سميت ، ڪنهن به ضروري پيڊنگنگ کي يقيني بڻائڻ لاءِ ته `next` صحيح طريقي سان هلي ويندي ، پر *ڪو پيچرو نه پيڊنگ*.
    ///
    /// سي جي نمائندگي لي آئوٽ `repr(C)` کي ملائڻ لاءِ ، توهان کي سڀني شعبن سان ترتيب وڌائڻ کان پوءِ `pad_to_align` سڏڻ گهرجي.
    /// (طريقي سان Rust نمائندگي ترتيب ترتيب `repr(Rust)`, as it is unspecified.) کي ملائڻ جو ڪو طريقو ناهي
    ///
    /// نوٽ ڪريو ته نتيجو ڪ layoutڻ جي ترتيب `self` ۽ `next` جي وڌ کان وڌ هوندي ، ٻنهي حصن جي ترتيب کي يقيني بڻائڻ لاءِ.
    ///
    /// `Ok((k, offset))` کي واپسي ڏي ٿو ، جتي `k` گڏ ٿيل رڪارڊ جي ترتيب آھي ۽ `offset` ھڪڙي جڳھ آھي ، بائٽس ۾ ، `next` جي شروعات جو ملندڙ ريڪارڊ جي اندر شامل ٿيل (فرض ڪيو ويو آھي ته ريڪارڊ پاڻ کي شروع ٿئي ٿو 0).
    ///
    ///
    /// رياضياتي اوورفول تي ، واپسي `LayoutError`.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` structureانچي جي ترتيب ۽ هن جي فيلڊ جي لي آئوٽ کان وائيس آف لائنن جو حساب رکڻ لاءِ:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // ياد رکو ته `pad_to_align` سان گڏ ختم ٿيڻ!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // آزمائش ڪيو ته اهو ڪم ڪري ٿو
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` مثالن جي `n` جي رڪارڊ جي وضاحت ڪندي لي آئوٽ ٺاهي ٿو ، هر مثال جي وچ ۾ پيڊنگ ناهي.
    ///
    /// ياد رکجو ، `repeat` جي برعڪس ، `repeat_packed` گارنٽي نٿو ڏئي ته `self` جي بار بار مثالن کي صحيح طريقي سان هلي ويندي ، جيتوڻيڪ `self` جو ڏنل مثال صحيح طرح سان هلي وڃي ٿو.
    /// ٻين لفظن ۾ ، جيڪڏهن ترتيب ڏنل ايڪس آر ايڪس کي ترتيب ڏيڻ لاءِ استعمال ڪيو ويو آهي ، انهي کي ضمانت نه آهي ته صف ۾ سڀئي عنصر صحيح نموني سان ترتيب ڏنل هوندا.
    ///
    /// رياضياتي اوورفول تي ، واپسي `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// هڪ ترتيب ٺاهي ٿو `self` جو رڪارڊ بيان ڪندي `next` جي پٺيان ۽ ٻنهي جي وچ ۾ ڪا اضافي پيڊنگ ناهي.
    /// جيستائين ڪوبه پيڊنگ داخل نه ڪيو ويو آهي ، `next` جي ترتيب بي ترتيب آهي ، ۽ شامل نه ڪيو وڃي *مڪمل طور تي* نتيجي واري ترتيب ۾.
    ///
    ///
    /// رياضياتي اوورفول تي ، واپسي `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// هڪ `[T; n]` لاءِ رڪارڊ بيان ڪندي لي آئوٽ ٺاهي ٿو.
    ///
    /// رياضياتي اوورفول تي ، واپسي `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// پيٽرولر `Layout::from_size_align` يا ڪجهه ٻين `Layout` تعمير ڪندڙ کي ڏنل آهن ان جي دستاويزي پابندين کي پورو نٿا ڪن.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (اسان کي trait غلطي جي هيٺين اسٽوريج لاءِ ضرورت آهي)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}