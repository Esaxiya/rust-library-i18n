//! سيپ هاش جو هڪ نفاذ.

#![allow(deprecated)] // هن ماڊل ۾ قسمن کي ختم ڪيو ويو آهي

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// سيپ هش 1-3 جو هڪ نفاذ.
///
/// اهو في الحال معياري ڊڪشنري هشنگ وارو ڪم آهي جيڪو معياري لائبريري طرفان استعمال ڪري رهيو آهي (مثال طور ، `collections::HashMap` ڊفالٽ طور استعمال ڪندو آهي).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// سيپ هش 2-4 جو عمل.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// سيپ هش 2-4 جو عمل.
///
/// See: <https://131002.net/siphash/>
///
/// سيپ هاش هڪ عام مقصد جي هشنگ فنڪشن آهي: اها سٺي رفتار سان هلندي آهي (اسپوڪي ۽ سٽي سان مقابلو) ۽ مضبوط _keyed_ هاشنگ جي اجازت ڏئي ٿي.
///
/// انهي کي توهان کي توهان جي هش ٽيبل کي مضبوط آر اين جي کان اجازت ڏي ، جهڙوڪ [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// جيتوڻيڪ سيپ هش الگورٿم عام طور تي مضبوط تصور ڪيو ويندو آهي ، اهو مقصد cryptographic مقصدن لاءِ نه آهي.
/// جيئن ، هن عمل جي سڀني ڪرپٽگرافڪ استعمال _strongly discouraged_ آهن.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // اسان ڪيتري بائيٽ کي پروسيس ڪيو
    state: State,  // هش رياست
    tail: u64,     // اڻ سڌريل بائيٽ لي
    ntail: usize,  // دم ۾ ڪيترا بائيٽ صحيح آهن
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 ۽ v1 ، v3 الگورتھم ۾ جوڑوں ۾ ظاهر ٿيندا آهن ، ۽ سيپ هش جي سم ڊي پليٽس استعمال ڪندو vectors جو v02 ۽ v13.
    //
    // انهي ترتيب ۾ ان کي ترتيب سان ترتيب ڏيڻ سان ، مرتبڪار پنهنجو پاڻ کي ڪجهه سمڊ اصلاحن تي وٺي سگھي ٿو.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// بي اي وهڪرو کان مطلوب قسم جو انٽيگرجر لوڊ ڪريو ، لي آرڊر ۾.
/// ممڪن طور تي اڻ ignاڻايل ايڊريس مان ان کي لوڊ ڪرڻ لاءِ ڪارائتو تمام موثر طريقو پيدا ڪرڻ لاءِ `copy_nonoverlapping` استعمال ڪندو آهي.
///
///
/// غير محفوظ ڇاڪاڻ ته: i..i+size_of(int_ty) تي غير چيڪ ڪيل انڊيڪسنگ
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// هڪ u64 بائيٽ سليس جي 7 بائٽس استعمال ڪندي لوڊ ڪري ٿي.
/// اهو غير خوشگوار ڏسڻ ۾ اچي ٿو پر `copy_nonoverlapping` ڪال جيڪي واقعا آهن (`load_int_le!` ذريعي) سڀ مقرريون سائيز آهن ۽ `memcpy` کي ڪال ڪرڻ کان پاسو ڪن ٿيون ، جيڪو اسپيڊ لاء سٺو آهي.
///
///
/// غير محفوظ ڇاڪاڻ ته: شروعات ۾ غير نشان ٿيل انڊيڪس .. شروعات + لين
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // موجوده بائيٽ انڊيڪس (ايل ايس بي کان) ٻاڪسٽ u64 ۾
    let mut out = 0;
    if i + 3 < len {
        // حفاظت: `i` `len` کان وڏو نٿو ٿي سگھي ، ۽ ڪال ڪندڙ کي گارنٽي ڏيڻ لازمي آھي
        // اھو انڊيڪس شروع ٿيو آھي .. شروع + لين حدن ۾ آھي.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // حفاظت: ساڳي طرح مٿي.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // حفاظت: ساڳي طرح مٿي.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// 0 کي سيٽ ڪرڻ واري شروعاتي ٻن ڪنجين سان نئون `SipHasher` ٺاهي ٿو.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// هڪ `SipHasher` ٺاهي ٿو جيڪا ڏنل مهيا ڪيل چئنن کي بند ڪيو وڃي ٿو.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// 0 کي سيٽ ڪرڻ واري شروعاتي ٻن ڪنجين سان نئون `SipHasher13` ٺاهي ٿو.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// `SipHasher13` ٺاهي ٿو جيڪا مهيا ڪيل ڪيز کي بند ڪري ڇڏيو آهي.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: ڪوبه عدد هشنگنگ طريقا ("write_u *" ، `write_i*`) بيان ٿيل ناهن
    // هن قسم لاءِ.
    // اسان انهن کي شامل ڪري ، `short_write` ، `SipHasher` ، `SipHasher13` ۽ `DefaultHasher` ۾ `write_u *`/`write_i*` طريقن کي شامل ڪيو.
    //
    // اهو انهن هاشرز پاران انڌيش هاش کي تيز ڪيو ويندو هو ، ڪجهه معيار تي گهٽ رفتار جي مرتڪب رفتار جي قيمت تي.
    // تفصيل لاءِ #69152 ڏسو.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // حفاظت: `cmp::min(length, needed)` `length` کان وڌيڪ نه هجڻ جي ضمانت آهي
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // بفر ٿيل دم هاڻي flري چڪو آهي ، نئين ان پٽ کي پروسيس ڪريو.
        let len = length - needed;
        let left = len & 0x7; // لين٪ 8

        let mut i = needed;
        while i < len - left {
            // حفاظت: ڇاڪاڻ ته `len - left` 8 جي هيٺان کان وڏو آھي
            // `len`, ۽ ڇاڪاڻ ته `i` `needed` کان شروع ٿئي ٿو جتي `len` `length - needed` آھي ، `i + 8` `length` کان گھٽ يا برابر جي ضمانت آھي.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // حفاظت: `i` ھاڻي `needed + len.div_euclid(8) * 8` آھي ،
        // پوءِ `i + left` = `needed + len` = `length` ، جيڪو تعين مطابق آهي `msg.len()` جي برابر.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// 0 کي سيٽ ڪرڻ واري شروعاتي ٻن ڪنجين سان `Hasher<S>` ٺاهي ٿو.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}