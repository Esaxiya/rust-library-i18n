#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future هڪ عينڪ انٽيليشن ڳڻپ جي نمائندگي ڪندو آهي.
///
/// future هڪ قيمت آهي جيڪا شايد ڪمپيوٽرنگ اڃا تائين مڪمل نه ڪيو آهي.
/// اهڙي قسم جي ايڪسڪسيمڪس انهي سلسلي کي ممڪن بڻائي ٿو ته ڪم ڪار جاري رکڻ جاري رکو جڏهن ته اهو موجود ٿيڻ جي قيمت جو انتظار ڪري.
///
///
/// # ايڪس آرڪس جو طريقو
///
/// future جو بنيادي طريقو ، `poll` ،*ڪوششون* future کي آخري قيمت ۾ حل ڪرڻ جي.
/// جيڪڏهن اهو قدر تيار نه آهي ته اهو طريقو بلاڪ نه ٿيندو.
/// ان جي بدران ، موجوده ڪم کي جاڳڻ جو شيڊول آهي جڏهن ٻيهر پولنگ ڪندي وڌيڪ اڳڀرائي ڪرڻ ممڪن آهي.
/// جيڪو `context` پاس ڪيو ويو `poll` طريقو [`Waker`] مهيا ڪري سگھي ٿو ، جيڪو موجوده ڪم کي جاڳڻ جي لاءِ سنڀاليندڙ آهي.
///
/// جڏهن future استعمال ڪندي ، توهان عام طور تي سڌو سنئون `poll` کي ڪال نه ڪندا ، پر بدران `.await` ويليو.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// تڪميل تي پيدا ٿيل قدر جو قسم.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// future کي آخري قيمت تي حل ڪرڻ جي ڪوشش ڪئي ، ويک لاءِ موجوده ڪم جي رجسٽرڊ ڪرڻ جي صورت ۾ جيڪڏهن قدر اڃان موجود نه هجي.
    ///
    /// # واپسي جي قيمت
    ///
    /// هي فنڪشن موٽائي ٿو:
    ///
    /// - [`Poll::Pending`] جيڪڏهن future اڃا تائين تيار ناهي
    /// - [`Poll::Ready(val)`] انهي future جي `val` جي نتيجي سان جيڪڏهن اهو ڪاميابي سان ختم ٿي وڃي.
    ///
    /// هڪ ڀيرو future ختم ٿيو آهي ، گراهڪن کي ٻيهر `poll` نه هجڻ گهرجي.
    ///
    /// جڏهن future اڃا تيار نه آهي ، `poll` `Poll::Pending` واپس ڪري ٿو ۽ موجوده [`Context`] مان ڪاپي ڪيل [`Waker`] واري ڪلون محفوظ ڪري ٿو.
    /// ايڪس [`Waker`] هڪ ڀيرو جاڳندي آهي جڏهن future ترقي ڪري سگهي ٿي.
    /// مثال طور ، هڪ future ساکٽ جو انتظار ڪرڻ جي قابل ٿيڻ جو انتظار ڪري رهيو هو ته [`Waker`] کي [`Waker`] تي ڪال ڪندو ۽ ان کي ذخيرو ڪندو.
    /// جڏهن هڪ سگنل ٻئي جاءِ تي اچي ويندو آهي جنهن مان ظاهر ٿئي ٿو ته ساکٽ پڙهڻ لائق آهي ، [`Waker::wake`] کي سڏيو وڃي ٿو ۽ ساکٽ future جو ڪم جاڳيل آهي.
    /// هڪ ڪم جاڳندي هڪ دفعو ، اهو ٻيهر `poll` future کي ڪوشش ڪرڻ گهرجي ، جيڪو حتمي قدر پيدا ڪري سگهي ٿو يا نه.
    ///
    /// نوٽ ڪريو ته ڪيترن ئي ڪالن تي `poll` ، صرف [`Waker`] کان [`Context`] سڀ کان وڌيڪ ڪال ۾ گذري ويا ، جائيڪ حاصل ڪرڻ جو وقت طئي ٿيڻ گهرجي.
    ///
    /// # رنٽمينٽ خاصيتون
    ///
    /// Futures اڪيلو آھن *انڊرٽ*؛انهن کي *اڳڀرائي ڪرڻ لاءِ* فعال طور تي ـ پول ڪيو وڃي ، مطلب ته هر وقت جڏهن موجوده ڪم جاڳيو هجي ، انهي کي futures جي انتظار ۾ ٻيهر پولنگ ڪرائڻ گهرجي ، انهي ۾ اڃا به دلچسپي آهي.
    ///
    /// `poll` واري ڪم کي تنگ لوپ ۾ بار بار نه سڏيو ويندو آهي-بجاءِ ، اهو صرف ان کي سڏڻ گهرجي جڏهن future ظاهر ڪري ته اهو ترقي ڪرڻ لاءِ تيار آهي (`wake()`) کي ڪال ڪندي.
    /// جيڪڏهن توهان `poll(2)` تي `poll(2)` يا `select(2)` اسڪوچ سان واقف آهيو ته اهو ڌيان ڏيڻ گهرجي ته futures عام طور تي *نه*"all wakeups must poll all events" جي ساڳي مسئلن جو شڪار ڪن ٿا.اهي وڌيڪ `epoll(4)` وانگر آهن.
    ///
    /// `poll` جي هڪ منصوبي کي جلدي موٽڻ جي ڪوشش ڪرڻ گهرجي ، ۽ بلاڪ نه ڪرڻ گهرجي.جلدي واپس اچڻ واري سلسلي کي ڪٽيل ڌڪ يا واقعا loرندڙن کان غير ضروري طور روڪي ٿو.
    /// جيڪڏهن وقت کان اڳ اهو isاڻجي وڃي ته هڪ ڪال `poll` وٽ ختم ٿي سگهي ٿي ، ڪم کي ڪنڊيڊ پول (يا ساڳي ئي ڪجهه) ختم ڪرڻ گهرجي ته انهي کي يقيني بڻائي ته `poll` جلدي واپس اچي سگهي ٿو.
    ///
    /// # Panics
    ///
    /// هڪ دفعو future مڪمل ڪيو ويو (`poll` کان `Ready` واپس) ، ڪال کي پنهنجو `poll` طريقو ٻيهر panic ٿو ، هميشه لاءِ بلاڪ ، يا ٻين قسمن جا مسئلا پيدا ڪرڻ ؛`Future` trait اهڙي ڪال جي اثرن جي ڪا ضرورت ناهي رکي.
    /// تنهن هوندي ، جئين `poll` جو طريقو `unsafe` تي نشان لڳل نه آهي ، Rust جا معمولي قاعده لاڳو ٿين ٿا: ڪالز کي ڪڏهن به تعريف جو رويو (يادگيري ڪرپشن ، `unsafe` افعال جو غلط استعمال يا اهڙي طرح) سبب نه هجڻ گهرجي ، future جي حالت جي پرواهه
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}