#![stable(feature = "futures_api", since = "1.36.0")]

//! غير منقول قيمتون.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// اهو قسم ضروري آهي ڇاڪاڻ ته:
///
/// a) جنريٽر `for<'a, 'b> Generator<&'a mut Context<'b>>` لاڳو نٿا ڪري سگھن ، تنھنڪري اسان کي ھڪ خام پوائنٽر پاس ڪرڻ جي ضرورت آھي (<https://github.com/rust-lang/rust/issues/68923> ڏسو).
///
/// b) را پوائنٽر ۽ `NonNull` ڪونھي `Send` يا `Sync` ، ان ڪري ھر ھڪڙي future non-Send/Sync ٺاھيندا ، ۽ اسان اھو نٿا چاھيون.
///
/// اهو پڻ `.await` جي HIR گھٽائڻ کي آسان بڻائي ٿو.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// future ۾ جنريٽر لپيو.
///
/// اهو فنڪشن هڪ هيٺ ڏنل `GenFuture` موٽائي ٿو ، پر هن کي `impl Trait` ۾ لڪايو وڃي ٿو ته بهتر پيغام موڪلڻ لاءِ (`impl Future` بجاءِ `GenFuture<[closure.....]>`).
///
// هي ايڪسڪسيمڪس کان وصولي بعد وڌيڪ غلطين کان بچڻ جي لاءِ هي `const` آهي
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // اسان حقيقت تي ڀروسو رکون ٿا ته async/await futures ھيٺئين جنريٽر ۾ خود ريفرنس قرض ٺاھڻ لاءِ متحرڪ آھن.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // حفاظت: محفوظ آهي ڇاڪاڻ ته اسان !Unpin + !Drop آهيون ، ۽ اهو صرف هڪ فيلڊ پروجئشن آهي.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // جنريٽر کي هلايو ، `&mut Context` کي `NonNull` خام پوائنٽر ۾ تبديل ڪري.
            // `.await` هيٺين طور تي واپس `&mut Context` ڏانهن اڇلائي ڇڏيندو.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // SAFETY: ڪالر کي ضمانت ڏيڻو پوندو ته `cx.0` هڪ صحيح پوائنٽر آهي
    // جيڪا هڪ قابل تبديلي حوالي سان سڀني ضرورتن کي پورو ڪري ٿي.
    unsafe { &mut *cx.0.as_ptr().cast() }
}