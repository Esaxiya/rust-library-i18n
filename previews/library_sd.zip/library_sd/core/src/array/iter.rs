//! `IntoIter` ارائيٽرز لاء اراديٽر جي تعريف ڪندو آهي.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A طرفان ويليو [array] iterator
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// هي اهو سلسلو آهي جنهن کي اسان لڳائي رهيا آهيون.
    ///
    /// انڊيڪس `i` سان گڏ عناصر جتي `alive.start <= i < alive.end` اڃا تائين حاصل نه ڪيا ويا آهن ۽ صحيح صف واريون داخلائون آهن.
    /// اشارن `i < alive.start` يا `i >= alive.end` سان گڏ عنصر پيدا ٿي چڪا آهن ۽ هاڻي رسائي نه هجڻ گهرجي!اهي مئل عنصر شايد مڪمل طور تي غير ابتدائي حالت ۾ هوندا!
    ///
    ///
    /// تنهن ڪري چالان ڪندڙ آهن:
    /// - `data[alive]` زنده آهي (يعني جائز عنصرن تي مشتمل آهي)
    /// - `data[..alive.start]` ۽ `data[alive.end..]` مري ويا آهن (يعني عناصر اڳ ئي پڙهي چڪا هئا ۽ هاڻي ڇهڻ نه گهرجي!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` ۾ عناصر جيڪي اڃا تائين پيدا نه ڪيا ويا آهن.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// ڏنل `array` مٿان نئون ايريرٽر ٺاهي ٿو.
    ///
    /// *نوٽ*: [`IntoIterator` is implemented for arrays][array-into-iter] کان پوء ، هي طريقو future ۾ ختم ڪيو ويندو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // ايڪس01ڪس جو قسم `i32` هتي آهي ، بدران `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // حفاظت: هتي منتقلي اصل ۾ محفوظ آهي.`MaybeUninit` جا دستاويز
        // promise:
        //
        // > `MaybeUninit<T>` ضمانت هڪ ئي سائيز ۽ برابر هجڻ جي ضمانت آهي
        // > جيئن `T`.
        //
        // دستاويز جيتوڻيڪ `MaybeUninit<T>` کان `T` جي صف تائين هڪ منتقلي ڏيکارين ٿا.
        //
        //
        // انهي سان ، اهو شروعات انويندڙن کي مطمئن ڪري ٿو.

        // FIXME(LukasKalbertodt): اصل ۾ `mem::transmute` هتي استعمال ڪريو ، هڪ ڀيرو اهو ڪم ڪندڙ جنرلن سان گڏ ڪم ڪندو آهي:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // هن وقت تائين ، اسان استعمال ڪري سگھون ٿا `mem::transmute_copy` ھڪڙي مختلف قسم جي طور تي ھڪڙي ٻيٽ واري ڪاپي ٺاھڻ لاءِ ، پوء `array` کي وساري ڇڏيو ته ھي ٻڏي نه سگھيو.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// سڀني عنصرن جو ايمرجنسي سلائس واپس ڏئي ٿو جيڪا اڃا تائين پيدا نه ٿي هئي.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // حفاظت: اسان knowاڻون ٿا ته `alive` اندر سڀ عناصر مناسب طور تي شروعاتي آھن.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// سڀني عنصرن جو هڪ قابل تبديلي سلائي ري ٿو جيڪا اڃا تائين پيدا نه ٿي آهي.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // حفاظت: اسان knowاڻون ٿا ته `alive` اندر سڀ عناصر مناسب طور تي شروعاتي آھن.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // اڳيان کان ايندڙ انڊيڪس حاصل ڪيو.
        //
        // 1 پاران `alive.start` واڌ ڪرڻ `alive` جي حوالي سان گھرواري برقرار رکي ٿو.
        // جيتوڻيڪ ، انهي تبديلي جي ڪري ، ٿوري وقت لاءِ ، زنده علائقو `data[alive]` هاڻي ناهي ، پر `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // صف کان عنصر پڙهو.
            // حفاظت: `idx` اڳوڻي "alive" علائقي ۾ ھڪڙو انڊيڪس آھي
            // صف.انهي عنصر کي پڙهڻ جو مطلب اهو آهي ته `data[idx]` هاڻي مرده سمجهيو ويندو آهي (يعني نه رابطو ڪريو).
            // جئين `idx` زنده زون جي شروعات هئي ، زنده علائقو هاڻي `data[alive]` هڪ ڀيرو ٻيهر سڀني invariants کي بحال ڪري رهيو آهي.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // پوئتي کان ايندڙ انڊيڪس حاصل ڪريو.
        //
        // 1 پاران `alive.end` گهٽائڻ `alive` جي حوالي سان گھٻريل برقرار رکي ٿو.
        // جيتوڻيڪ ، انهي تبديلي جي ڪري ، ٿوري وقت لاءِ ، زنده علائقو `data[alive]` هاڻي ناهي ، پر `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // صف کان عنصر پڙهو.
            // حفاظت: `idx` اڳوڻي "alive" علائقي ۾ ھڪڙو انڊيڪس آھي
            // صف.انهي عنصر کي پڙهڻ جو مطلب اهو آهي ته `data[idx]` هاڻي مرده سمجهيو ويندو آهي (يعني نه رابطو ڪريو).
            // جئين `idx` زنده زون جو خاتمو هو ، هاڻ زنده زون هاڻي `data[alive]` آهي سڀني بحال ڪندڙن کي بحال ڪندي.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // حفاظت: اهو محفوظ آهي: `as_mut_slice` ذيلي ذليس واپس اچي ٿو
        // انهن عنصرن جو جيڪي اڃا تائين منتقل نه ڪيا ويا آهن ۽ اهي ختم ٿيڻا آهن.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // دائمي طور تي ڪڏهن به هيٺ نه هلندو
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// اهو ورثو ڪندڙ واقعي صحيح لمبائي جي رپورٽ ڪري ٿو.
// "alive" عناصر جو تعداد (جيڪو اڃا تائين پيدا ٿيندو) رينج `alive` جي ڊيگهه آهي.
// ھن حد کي `next` يا `next_back` ۾ ڊگھي گھٽائي وئي آھي.
// انهن طريقن مان هميشه اهو 1 کان گهٽ ڪيو ويو آهي ، پر صرف جيڪڏهن `Some(_)` واپس اچي وڃي.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // نوٽ ، اسان کي واقعي ساڳئي زنده رينج سان ميچ ڪرڻ جي ضرورت ناهي ، تنهن ڪري اسان صرف 0 آف سيٽ ۾ کلون ڪري سگهون ٿا قطع نظر ان جي ته `self` ڪٿي آهي.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // سڀني زنده عنصرن کي کلون.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // کلون لکو نئين صف ۾ ، پوءِ تازه ڪاري ان جي زنده رينج.
            // جيڪڏهن panics کي ڪلڊنگ ڪيو وڃي ، اسان پوئين شين کي صحيح نموني سان اڇلائي ڇڏينداسون
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // صرف انهن عنصرن کي پرنٽ ڪيو جيڪي پيدا نه ڪيا ويا هئا: اسان پيدا ٿيندڙ عنصرن تائين رسائي نٿا ڪري سگهون.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}