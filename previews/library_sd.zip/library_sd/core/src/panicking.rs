//! Panic ليبيڪيٽ جي حمايت
//!
//! بنيادي لائبريري ڇڪتاڻ جي تعريف نه ٿي ڪري سگهجي ، پر اهو * * اڻڻ * اعلان ڪرڻ.
//! هن جو مطلب آهي ته ليبورڊ جي اندر ڪم ڪن panic کي اجازت ڏني وڃي ٿي ، پر هڪ upstream crate استعمال ڪرڻ لاءِ استعمال ٿيڻ ضروري آهي.
//! ڇڪڻ لاءِ موجوده انٽرويو انٽرنيٽ آهي:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! اها تعريف ڪنهن عام پيغام سان ickingاڙڻ جي اجازت ڏئي ٿي ، پر اهو `Box<Any>` ويل سان ناڪام ٿيڻ جي اجازت نٿو ڏئي.
//! (`PanicInfo` صرف `&(dyn Any + Send)` تي مشتمل آهي ، جنهن جي لاءِ اسين "PanicInfo: : internal_constructor" ۾ هڪ ڊيم واري قيمت ڀريندا آهيون.) ان جو سبب اهو آهي ته ليبڪور کي مختص ڪرڻ جي اجازت ناهي.
//!
//!
//! ھن ماڊل ۾ ڪجھ ٻين ڀاڙيندڙن جا ڪم شامل آھن ، پر ھيءَ مرتب ڪندڙ ضروري شيون آھن.سڀ panics فنڪشنل آھن ھن ھڪڙي فنڪشن ذريعي.
//! `#[panic_handler]` جي وصف ذريعي اصلي علامت قرار ڏني وئي آهي.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// ليبرڪ جي `panic!` ميڪرو جي هيٺيان لاڳو ٿيل جڏهن ڪا فارميٽنگ استعمال نه ڪئي وئي آهي.
#[cold]
// ڪالعدم نه ڪريو جيستائين panic_immediate_abort جيترو ممڪن ٿي سگهي ڪال سائٽس تي ڪوڊ فليٽنگ کان بچڻ
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // panic کي اوور فلو ۽ ٻين `Assert` MIR ٽرمينٽرز لاءِ ڪوڊن پاران گهربل
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ممڪن ٿي ويو سائيز تي وڌيڪ گھٽائڻ لاءِ فارميٽ_ارگس جي بدران Arguments::new_v1 استعمال ڪريو! ("{}"، expr)
    // فارميٽ_ گرگس!ميڪرو ex کي لکڻ لاءِ str's Display trait استعمال ڪندو آهي ، جنهن کي Formatter::pad چون ٿا ، جنهن کي لازمي طور تي تار ٽوڙڻ ۽ پيڊنگ ڪرڻ گهرجي (جيتوڻيڪ هتي ڪوبه استعمال نه ٿيندو).
    //
    // Arguments::new_v1 استعمال ڪرڻ سان ڪمپائلر کي Formatter::pad ٻاھران بائنري مان ختم ڪرڻ جي اجازت ڏئي سگھي ٿي ، ڪجھ ڪلو بائيٽ تائين بچت.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // جي ضرورت آهي panics لاء
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice رسائي تي panic لاءِ ڪوڊيڪن طرفان گهربل
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// جڏهن فارميٽنگ کي استعمال ڪيو ويندو ليبورڊ جي `panic!` ميڪرو جي هيٺيان لاڳو ٿيو.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ياداشت اهو فعل ڪڏهن به ايف ايف آءِ جي حد کي ڪراس نٿو ڪري.اهو Rust-to-Rust ڪال آهي جيڪا `#[panic_handler]` جي فنڪشن کي حل ڪيو وڃي.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SAFETY: `panic_impl` محفوظ Rust ڪوڊ ۾ بيان ڪيل آھي ۽ اھڙي طرح ڪال ڪرڻ لاءِ محفوظ آھي.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!` ۽ `assert_ne!` ميڪروز لاءِ اندروني ڪارڪردگي
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}