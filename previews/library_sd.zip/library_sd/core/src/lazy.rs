//! سست ويلز ۽ هڪ وقت جي جامد ڊيٽا جي شروعات.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// هڪ سيل جيڪو صرف هڪ ڀيرو لکي سگهجي ٿو.
///
/// `RefCell` جي نسبت ، `OnceCell` صرف حصيداري `&T` ان جي قيمت جي حوالي ڪري ٿو.
/// `Cell` جي نسبت ، `OnceCell` ان تائين رسائي جي قيمت کي نقل يا بدلائڻ جي ضرورت ڪونھي.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // تباهڪار: هڪ ئي وقت لکڻ.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// نئون خالي خانو ٺاهي ٿو.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// ھيٺ ڏنل قدر جو حوالو حاصل ڪري ٿو.
    ///
    /// ايڪس وليڪس ڏي ٿو جيڪڏھن سيل خالي آھي.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // حفاظت: اندروني طور تي غير متوازن هجڻ جي ڪري محفوظ
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// قابل قدر حوالو بنيادي قدر جي حوالي ڪري ٿو.
    ///
    /// ايڪس وليڪس ڏي ٿو جيڪڏھن سيل خالي آھي.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // حفاظت: محفوظ آهي ڇاڪاڻ ته اسان وٽ ڌار رسائي آهي
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// خاني جي مواد کي `value` ڏانهن مقرر ڪري ٿو.
    ///
    /// # Errors
    ///
    /// اهو طريقو واپس اچي ٿو `Ok(())` جيڪڏهن سيل خالي هئي ۽ `Err(value)` جيڪڏهن اهو مڪمل هو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // حفاظت: محفوظ آهي ڇاڪاڻ ته اسان وڌيڪ چٽيون قابل قبول قرض کڻي نٿا سگهون
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // حفاظت: هي واحد جڳهه آهي جتي اسان سلاٽ کي مقرر ڪيو ، ريسون نه
        // reentrancy/concurrency جي ڪري ممڪن آهي ، ۽ اسان چڪاس ڪيو آهي ته سلاٽ في الحال `None` آهي ، تنهن ڪري هي لکت "اندروني" جي غير متحرڪ برقرار رکي.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// خاني جي مواد حاصل ڪري ٿو ، انهي کي شروعاتي طور تي `f` سان جيڪڏهن سيل خالي هجي.
    ///
    /// # Panics
    ///
    /// جيڪڏهن `f` panics ، panic ڪالر تائين تبليغ ڪئي وئي آهي ، ۽ سيل غير ابتدائي رهي ٿو.
    ///
    ///
    /// اهو `f` کان عارضي طور تي سيل کي شروع ڪرڻ ۾ هڪ غلطي آهي.ائين ڪرڻ panic ۾ نتيجا آڻي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// خاني جي مواد حاصل ڪري ٿو ، انهي کي شروعاتي طور تي `f` سان جيڪڏهن سيل خالي هجي.
    /// جيڪڏهن سيل خالي هو ۽ `f` ناڪام ٿيو ، هڪ غلطي واپس ڪئي وئي.
    ///
    /// # Panics
    ///
    /// جيڪڏهن `f` panics ، panic ڪالر تائين تبليغ ڪئي وئي آهي ، ۽ سيل غير ابتدائي رهي ٿو.
    ///
    ///
    /// اهو `f` کان عارضي طور تي سيل کي شروع ڪرڻ ۾ هڪ غلطي آهي.ائين ڪرڻ panic ۾ نتيجا آڻي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // ياد رکجو ته *ڪجهه* ٻيهر داخلا جي شروعات جا طريقا يو بي جي سبب ٿي سگھن ٿا (ڏسو `reentrant_init` ٽيسٽ).
        // مان سمجهان ٿو ته صرف `assert` هٽائڻ ، `set/get` رکڻ سان آواز هوندو ، پر اهو panic کي بهتر ڏسڻ بدران ، هڪ پراڻي قيمت خاموشي سان استعمال ڪرڻ بجاءِ بهتر لڳي ٿو.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// سيل کي کائي ٿو ، واپسي واري قيمت ڏي.
    ///
    /// ايڪس خانو واپس آڻيندي جيڪڏهن سيل خالي هئي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // ڇاڪاڻ ته `into_inner` `self` قدر جي لحاظ کان وٺي ٿو ، ڪمپائلر جامد تصديق ڪري ٿو ته اهو في الحال قرض نه ورتو ويو آهي.
        // تنهن ڪري ايڪس `Option<T>` ٻاهر وڃڻ محفوظ آهي.
        self.inner.into_inner()
    }

    /// هن `OnceCell` کان قيمت ڪي ٿو ، ان کي غير ابتدائي حالت ڏانهن واپس کڻي وڃڻ.
    ///
    /// ڪو اثر ناهي ۽ `None` موٽائي ٿو جيڪڏهن `OnceCell` شروعاتي ڪونه ڪئي وئي آهي.
    ///
    /// حفاظت قابل ضمانت حوالا گهربل آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// ھڪڙو قدر جيڪو ابتدائي پھچن تي پيل ٿيل آھي.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   تيار ڪرڻ جي شروعات
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// ڏنل ابتدائي فعل سان ھڪ نئون سٺيل قدر ٺاھي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// هن سست قيمت جو جائزو وٺڻ تي مجبور ڪري ٿو ۽ نتيجو جو حوالو ڏئي ٿو.
    ///
    ///
    /// اهو `Deref` impl جي برابر آهي ، پر ظاهر آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// `Default` کي شروعاتي ڪم ڪرڻ جي طور تي استعمال ڪندي هڪ نئين سستي قدر ٺاهي ٿو.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}