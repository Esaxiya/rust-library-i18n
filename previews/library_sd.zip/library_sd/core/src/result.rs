//! `Result` قسم سان هٿ ڪرڻ ۾ غلطي.
//!
//! [`Result<T, E>`][`Result`] قسم آهي واپسي ۽ تبليغ ڪرڻ وارن لاءِ استعمال ٿيل قسم.
//! اهو مختلف قسمن سان گڏ هڪ اينمم آهي ، ايڪس 100 ، ڪاميابي جي نمائندگي ڪرڻ ۽ قيمت تي مشتمل آهي ، ۽ [`Err(E)`] ، غلطي جي نمائندگي ڪرڻ ۽ غلطي جي قيمت تي مشتمل آهي.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! افعال [`Result`] واپس ڪن ٿا جڏهن غلطي جي توقع ڪئي وئي ۽ وصولي ٿڪجي.`std` crate ۾ ، [`Result`] خاص طور تي [I/O](../../std/io/index.html) لاءِ استعمال ڪيو ويندو آھي.
//!
//! ھڪڙو سادو ڪم جيڪو [`Result`] موٽائي سگھي ٿو اھو بيان ڪري سگھجي ٿو ۽ اھڙي طرح استعمال ٿيندو:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! [نتيجو] جي نمونن تي ملندڙ واضح ڪيسن لاءِ صاف ۽ سڌو آهي ، پر ايڪس ايڪس اين ايڪس ڪجهه سهولت طريقن سان اچي ٿو جيڪي هن سان ڪم ڪرڻ کي وڌيڪ سولو بڻائيندا آهن.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok` ۽ `is_err` طريقا اهي ڪن ٿا جيڪي چون ٿا.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` `Result` کي ڀاڙي ٿو ۽ ٻيو پيدا ڪري ٿو.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // `and_then` استعمال ڪريو ڳڻڻ جاري رکو.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // غلط کي سنڀالڻ لاءِ `or_else` استعمال ڪريو.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // نتيجو ڪيو ۽ مواد کي `unwrap` سان واپس ڪريو.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # نتيجا لازمي طور ڪتب آڻڻ
//!
//! غلطين کي ظاهر ڪرڻ لاءِ واپسي جي قدر استعمال ڪرڻ سان هڪ عام مسئلو اهو آهي ته واپسي جي قدر کي نظرانداز ڪرڻ آسان آهي ، اهڙيءَ ريت غلطي کي سنڀالڻ ۾ ناڪام ٿي.
//! [`Result`] `#[must_use]` منسوب سان تشريح ڪئي وئي آهي ، جيڪو کمپائلر کي هڪ خبرداري جاري ڪندو جڏهن نتيجو جي قيمت کي نظرانداز ڪيو ويو.
//! اهو ايڪس 100ڪس خاص طور تي ڪارناما سان گڏ ڪم ڪري ٿو جيڪي خرابي سان ٿي سگهن ٿيون پر ٻي صورت ۾ مفيد قيمت واپس نه ڏيندا آهن.
//!
//! غور ڪريو [`write_all`] طريقو I/O لاء بيان ڪيو ويو آھي [`Write`] trait پاران:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`] جي اصل تعريف [`io::Result`] استعمال ڪري ٿي ، جيڪو صرف [نتيجو]] جي مترادف آهي<T, `[`io: :Error`]`>".*
//!
//! اهو طريقو قدر نه پيدا ڪندو آهي ، پر لکڻ ناڪام ٿي سگھي ٿو.اهو ضروري آهي ته غلطي جي ڪيس کي سنڀالڻ ، ۽ *نه* ڪجهه لکڻ وانگر:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // جيڪڏهن `write_all` غلطي ، پوء اسان ڪڏهن به نه ،اڻينداسين ، ڇاڪاڻ ته واپسي جي قيمت نظرانداز ٿيل آهي.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! جيڪڏهن توهان *ڊان ڪيو* لکيو آهي ته Rust ۾ ، مرتب ڪندڙ توهان کي هڪ ڊي warningاريندڙ (ڊفالٽ طور ، ڪنٽرول `unused_must_use` lint) ڏئي ٿو.
//!
//! توهان شايد بدران ، جيڪڏهن توهان غلطي کي سنڀالڻ نٿا چاهيو ، صرف [`expect`] سان ڪاميابي ڀريو.
//! اهو panic ٿيندو جيڪڏهن لکڻ ناڪام ٿيندو ، هڪ مرضي سان مفيد پيغام مهيا ڪندي جنهن جي ظاهر ڪندي ڇو:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! توهان شايد ڪاميابي سان اعتماد ڪري سگھو ٿا:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! يا [`?`] سان ڪال اسٽيڪ کي غلطي جي تبليغ ڪريو:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # سواليا نشان هلائيندڙ ، `?`
//!
//! ڪوڊ لکڻ دوران جيڪي ڪيترائي افعال سڏي ٿو جيڪي [`Result`] قسم کي واپس ڪن ٿيون ، غلطي کي ختم ڪرڻ مشڪل ٿي سگهي ٿو.
//! سوالي نشان هلائيندڙ ، [`?`] ، ڪال اسٽيڪ کي پروپيگنڊا ڪندڙ غلطين جي ڪجهه بوائلرپليٽ کي لڪائي ٿو.
//!
//! اهو انهي کي بدلائي ٿو:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // غلطي تي شروعاتي واپسي
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! هن سان:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // غلطي تي شروعاتي واپسي
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *اهو گهڻو بهتر آهي!*
//!
//! [`?`] سان اظهار ختم ڪرڻ ڪامياب بيچين ([`Ok`]) ويليوٽ جو نتيجو ٿيندو ، جيستائين اهو نتيجو [`Err`] نه هجي ، ان صورت ۾ [`Err`] انجيڪشن واري فنڪشن کان جلد موٽي ويندي آهي.
//!
//!
//! [`?`] صرف انهي ڪارن ۾ استعمال ڪري سگهجي ٿو جيڪي [`Err`] واپس ڪن ٿا ڇاڪاڻ ته اها [`Err`] جي شروعاتي واپسي جي ڪري آهي جيڪا ان کي فراهم ڪري ٿي.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` اهو قسم آهي جيڪو ڪامياب ڪاميابي ([`Ok`]) يا ناڪامي ([`Err`]) جي نمائندگي ڪري ٿو.
///
/// تفصيل لاءِ [module documentation](self) ڏسو.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// ڪاميابي جي قيمت تي مشتمل آهي
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// غلطي جي قيمت تي مشتمل آهي
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// قسم جو عمل درآمد
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // موجود قيمتن بابت سوال ڪندي
    /////////////////////////////////////////////////////////////////////////

    /// جيڪڏهن [`Ok`] وارو نتيجو هجي `true` واپس ڪري ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// جيڪڏهن [`Err`] وارو نتيجو هجي `true` واپس ڪري ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// `true` کي واپسي ڏئي ٿو جيڪڏھن نتيجو ھڪڙي [`Ok`] قدر آھي جنھن ۾ ڏنل قدر آھي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// `true` کي واپسي ڏئي ٿو جيڪڏھن نتيجو ھڪڙي [`Err`] قدر آھي جنھن ۾ ڏنل قدر آھي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // هر ورڪ لاءِ اڊاپٽر
    /////////////////////////////////////////////////////////////////////////

    /// `Result<T, E>` کان [`Option<T>`] تائين تبديل ڪندو آهي.
    ///
    /// `self` کي [`Option<T>`] ۾ تبديل ڪري ٿو ، `self` استعمال ڪندي ، ۽ غلطي کي رد ڪري ، جيڪڏهن ڪو به.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// `Result<T, E>` کان [`Option<E>`] تائين تبديل ڪندو آهي.
    ///
    /// `self` کي [`Option<E>`] ۾ تبديل ڪري ٿو ، `self` استعمال ڪندي ، ۽ ڪاميابي جي قيمت کي رد ڪري ٿو ، جيڪڏهن ڪو به.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // حوالين سان ڪم ڪرڻ لاءِ اڊاپٽر
    /////////////////////////////////////////////////////////////////////////

    /// `&Result<T, E>` کان `Result<&T, &E>` تائين تبديل ڪندو آهي.
    ///
    /// نئون `Result` پيدا ڪري ٿو ، اصل ۾ ھڪڙي حوالو شامل آھي ، اصل کي پنھنجي جڳھ تي ڇڏيندي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// `&mut Result<T, E>` کان `Result<&mut T, &mut E>` تائين تبديل ڪندو آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // بدلائڻ واريون قدرون
    /////////////////////////////////////////////////////////////////////////

    /// ھڪڙي `Result<T, E>` کان `Result<U, E>` کي نقشو ٺاھيو ھڪڙي ڪم ۾ شامل ڪريو [`Ok`] قدر ، ھڪڙي [`Err`] ويليو کي ڇڏيندي.
    ///
    ///
    /// ھي فنڪشن ٻن عملن جي نتيجن کي ترتيب ڏيڻ لاءِ استعمال ڪري سگھجي ٿو.
    ///
    /// # Examples
    ///
    /// ھڪڙي سٽرنگ جي ھر لائن تي انگ کي وڌايو ويو ٻن کان.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// قابل قدر قيمت تي ھڪڙي فنڪشن لاڳو ڪندو آھي (جيڪڏھن [`Ok`]) ، يا مهيا ڪيل ڊفالٽ کي واپس آڻيندي (جيڪڏھن [`Err`]).
    ///
    /// `map_or` وٽ بحث ڪيل دليلون بي احتياطي سان جائزي ٿيون ؛جيڪڏهن توهان هڪ فنڪشن ڪال جو نتيجو گذري رهيا آهيو ، اهو [`map_or_else`] استعمال ڪرڻ جي سفارش ڪئي وئي آهي ، جيڪو سست انداز سان جائزو ورتو وڃي ٿو.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// ھڪڙي `Result<T, E>` کان `U` ڏانھن نقشو ٺاھيو ھڪڙي ڪم ڪندي ھڪڙي [`Ok`] قدر ، يا ھڪڙي فڪ بيڪ فنڪشن تي مشتمل آھي [`Err`] ويليو.
    ///
    ///
    /// ھن فنڪشن کي استعمال ڪندي ھڪڙي ڪامياب نتيجن کي ٻاھر ڪ canڻ لاءِ استعمال ڪري سگھجي ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// ھڪڙي `Result<T, E>` کان `Result<T, F>` کي نقشو ٺاھيو ھڪڙي ڪم ۾ شامل ڪريو [`Err`] قدر ، ھڪڙي [`Ok`] ويليو کي ڇڏيندي.
    ///
    ///
    /// انهي ڪارڪردگي کي ڪامياب طريقي سان پاس ڪرڻ دوران استعمال ڪري سگهجي ٿو جڏهن مسئلو handlingهلائڻ.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // آئٽرٽر تعمير ڪندڙ
    /////////////////////////////////////////////////////////////////////////

    /// ممڪن طور تي موجود قدر مٿان بار بار موٽي اچي ٿو.
    ///
    /// ايريٽر هڪ قدر پيدا ڪري ٿو جيڪڏهن نتيجو [`Result::Ok`] آهي ، ٻي صورت ۾ ڪوبه ناهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// ممڪن تبديل ٿيل قيمت جي مٿان هڪ ableير itار واري آئيٽراءِ کي ورجائي ٿو.
    ///
    /// ايريٽر هڪ قدر پيدا ڪري ٿو جيڪڏهن نتيجو [`Result::Ok`] آهي ، ٻي صورت ۾ ڪوبه ناهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // قدرن تي بولين آپريشن ، شوقين ۽ سست
    /////////////////////////////////////////////////////////////////////////

    /// `res` ڏي ٿو جيڪڏھن نتيجو [`Ok`] آھي ، ٻي صورت ۾ X003 جي [`Err`] قدر موٽائي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// فون ڪري ٿو `op` جيڪڏهن نتيجو [`Ok`] آھي ، ٻي صورت ۾ X003 جي [`Err`] قيمت موٽائي ٿو.
    ///
    ///
    /// انهي فنڪشن کي `Result` قدرن تي ٻڌل ڪنٽرول وهڪري لاءِ استعمال ڪري سگهجي ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// `res` ڏي ٿو جيڪڏھن نتيجو [`Err`] آھي ، ٻي صورت ۾ X003 جي [`Ok`] قدر موٽائي ٿو.
    ///
    /// `or` وٽ بحث ڪيل دليلون بي احتياطي سان جائزي ٿيون ؛جيڪڏهن توهان هڪ فنڪشن ڪال جو نتيجو گذري رهيا آهيو ، اهو [`or_else`] استعمال ڪرڻ جي سفارش ڪئي وئي آهي ، جيڪو سست انداز سان جائزو ورتو وڃي ٿو.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// فون ڪري ٿو `op` جيڪڏهن نتيجو [`Err`] آھي ، ٻي صورت ۾ X003 جي [`Ok`] قيمت موٽائي ٿو.
    ///
    ///
    /// ھي فنڪشن استعمال ڪري سگھندي ڪنٽرول جي وهڪري لاءِ نتيجو قدر جي بنياد تي
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// شامل ڪيل [`Ok`] قدر يا مهيا ڪيل ڊفالٽ واپس آڻيندي.
    ///
    /// `unwrap_or` وٽ بحث ڪيل دليلون بي احتياطي سان جائزي ٿيون ؛جيڪڏهن توهان هڪ فنڪشن ڪال جو نتيجو گذري رهيا آهيو ، اهو [`unwrap_or_else`] استعمال ڪرڻ جي سفارش ڪئي وئي آهي ، جيڪو سست انداز سان جائزو ورتو وڃي ٿو.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// مشتمل [`Ok`] قيمت کي واپس ڏئي ٿو يا بند ڪرڻ کي ان کي برابر ڪرڻ.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// شامل ڪيل [`Ok`] ويليو واپس ڏئي ٿو ، `self` قدر کي گھٽائيندي ، بغير چيڪ ڪرڻ جي ته قيمت [`Err`] ناھي.
    ///
    ///
    /// # Safety
    ///
    /// ايڪس آرڪس تي هن طريقي کي سڏڻ *[اڻ بيان ٿيل رويو]* آهي.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // اڻ سڌريل رويو!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // حفاظت: حفاظت جو معاهدو سڏيندڙ طرفان برقرار رکڻ لازمي آهي.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// شامل ڪيل [`Err`] ويليو واپس ڏئي ٿو ، `self` قدر کي گھٽائيندي ، بغير چيڪ ڪرڻ جي ته قيمت [`Ok`] ناھي.
    ///
    ///
    /// # Safety
    ///
    /// ايڪس آرڪس تي هن طريقي کي سڏڻ *[اڻ سڌريل رويو]* آهي.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // اڻ سڌريل رويو!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // حفاظت: حفاظت جو معاهدو سڏيندڙ طرفان برقرار رکڻ لازمي آهي.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// نقشو `Result<&T, E>` ڏانهن `Result<T, E>` ڏانهن `Ok` حصو جي مواد جو نقل ڪندي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// نقشو `Result<&mut T, E>` ڏانهن `Result<T, E>` ڏانهن `Ok` حصو جي مواد جو نقل ڪندي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// `Ok` حصو جي مواد کي ڪلون ڪندي `Result<&T, E>` ڏانهن `Result<&T, E>` ڏانھن نقشو ٺاھيو ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// `Ok` حصو جي مواد کي ڪلون ڪندي هڪ `Result<&mut T, E>` کي `Result<T, E>` ڏانهن نقشو ٺاھيو ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// ھجي ويو [`Ok`] قيمت کي ، واپس ڪري ٿو `self` قدر.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت [`Err`] آهي ، panic پيغام سان گڏ گذري ويو پيغام ، ۽ [`Err`] جو مواد.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// ھجي ويو [`Ok`] قيمت کي ، واپس ڪري ٿو `self` قدر.
    ///
    /// ڇاڪاڻ ته هي فنڪشن panic ٿي سگهي ٿو ، ان جي استعمال جي عام طور تي حوصلہ افزائي ڪئي وڃي ٿي.
    /// ان جي بدران ، نمونو ملائڻ ۽ [`Err`] ڪيس واضح طور تي سنڀالڻ کي ترجيح ڏيو ، يا [`unwrap_or`] ، [`unwrap_or_else`] ، يا [`unwrap_or_default`] کي ڪال ڪريو.
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت [`Err`] آهي ، panic پيغام سان ["Err"] جي قدر طرفان مهيا ڪيل آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// ھجي ٿو [`Err`] قدر ، `self` قيمت کي گھٽائڻ.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت [`Ok`] آهي ، panic پيغام سان گڏ گذري ويو پيغام ، ۽ [`Ok`] جو مواد.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// ھجي ٿو [`Err`] قدر ، `self` قيمت کي گھٽائڻ.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن قيمت [`Ok`] آهي ، ڪاٿي panic پيغام سان ["Ok"] جي قدر طرفان مهيا ڪيل آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// شامل ڪيل [`Ok`] قدر يا ڊفالٽ واپس آڻيندي
    ///
    /// `self` دليل کي استعمال ڪري ٿو ، جيڪڏهن [`Ok`] ، موجود ويل قيمت موٽائي ٿو ، ٻي صورت ۾ جيڪڏهن [`Err`] ، ان قسم جي اصل قيمت واپس آڻيندي.
    ///
    ///
    /// # Examples
    ///
    /// هڪ اسٽرنگ کي انٽيگر ۾ بدلائي ٿو ، خراب طور تي ٺهيل اسٽرنگ کي 0 ۾ بدلائي ٿو (انٽيگرن لاءِ اصلي قيمت)
    /// [`parse`] ھڪڙي اسٽرنگ کي ڪنھن ٻئي قسم ۾ تبديل ڪري ٿو جنھن کي [`FromStr`] لاڳو ڪندو ، غلطي تي [`Err`] موٽائي ٿو.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// واپسي وارو [`Ok`] قيمت ڏي ٿو ، پر ڪڏهن به panics.
    ///
    /// [`unwrap`] جي برعڪس ، هي طريقو panic ڪڏهن به نه knownاتو ويندو آهي جنهن جي نتيجي ۾ اهو لاڳو ڪيو ويندو آهي.
    /// تنهن ڪري ، اهو استعمال ڪري سگھي ٿو `unwrap` جي بدران حفاظت جي حفاظت جي طور تي جيڪو مرتب ڪرڻ ۾ ناڪام ٿيندو جيڪڏهن `Result` جي غلطي قسم بعد ۾ ڪنهن غلطي ڏانهن بدلجي وڃي جيڪا اصل ۾ ٿي سگھي ٿي.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// `Result<T, E>` (يا `&Result<T, E>`) کان `Result<&<T as Deref>::Target, &E>` کان تبديل ڪري ٿو.
    ///
    /// ھڪڙي [`Deref`](crate::ops::Deref) اصل [`Result`] جي [`Deref`](crate::ops::Deref) جي قسم جي چڪاس ڪري ٿو ۽ نئون [`Result`] موٽائي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// `Result<T, E>` (يا `&mut Result<T, E>`) کان `Result<&mut <T as DerefMut>::Target, &mut E>` کان تبديل ڪري ٿو.
    ///
    /// ھڪڙي [`DerefMut`](crate::ops::DerefMut) اصل [`Result`] جي [`DerefMut`](crate::ops::DerefMut) جي قسم جي چڪاس ڪري ٿو ۽ نئون [`Result`] موٽائي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// ھڪڙي `Option` جي ھڪڙي `Result` کي ھڪڙي `Option` جي ھڪڙي `Result` ۾ منتقل ڪري ٿو.
    ///
    /// `Ok(None)` `None` ڏانهن نقشو ڏنو ويندو.
    /// `Ok(Some(_))` ۽ `Err(_)` کي `Some(Ok(_))` ۽ `Some(Err(_))` ڏانهن نقشو ڏنو ويندو.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// `Result<Result<T, E>, E>` کان `Result<T, E>` تائين تبديل ڪندو آهي
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// فليٽ ڪرڻ صرف هڪ وقت بياني ڏيڻ واري سطح کي ختم ڪري ٿو:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// جيڪڏهن `self` `Ok` آهي ، يا [`Err`] ويليو جيڪڏهن `self` آھي `Err` آھي ، [`Ok`] موٽائي ٿو.
    ///
    /// ٻين لفظن ۾ ، هي فنڪشن `Result<T, T>` جي قيمت (`T`) واپس ڪري ٿو ، قطع نظر ته اهو نتيجو `Ok` يا `Err` آهي يا نه.
    ///
    /// اهو APIs سان [`Atomic*::compare_exchange`] ، يا [`slice::binary_search`] سان گڏ مفيد ٿي سگهي ٿو ، پر صرف انهن حالتن ۾ جتي توهان کي پرواه ناهي ته نتيجو `Ok` يا نه هو.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// اهو جدا جدا فنڪشن آهي طريقن جو ڪوڊ ماپ
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait لاڳو ڪرڻ
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ممڪن طور تي موجود قدر مٿان ھڪڙي استعمال ڪندڙ بار بار موٽي ٿو.
    ///
    /// ايريٽر هڪ قدر پيدا ڪري ٿو جيڪڏهن نتيجو [`Result::Ok`] آهي ، ٻي صورت ۾ ڪوبه ناهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// نتيجو Iterators
/////////////////////////////////////////////////////////////////////////////

/// هڪ [`Result`] جي [`Ok`] وارينٽري جي حوالي سان هڪ ورثي واري رٿ.
///
/// ايريٽر هڪ قدر پيدا ڪري ٿو جيڪڏهن نتيجو [`Ok`] آهي ، ٻي صورت ۾ ڪوبه ناهي.
///
/// [`Result::iter`] پاران ٺاهيل.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// هڪ [`Result`] جي [`Ok`] وارينٽري تي هڪ مٽايل حوالو مٿان هڪ ورجاءُ.
///
/// [`Result::iter_mut`] پاران ٺاهيل.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// ھڪڙي [`Result`] ھڪڙي قسم جي ھڪڙي [`Result`] قسم ۾ ھڪڙي تسلسل.
///
/// ايريٽر هڪ قدر پيدا ڪري ٿو جيڪڏهن نتيجو [`Ok`] آهي ، ٻي صورت ۾ ڪوبه ناهي.
///
/// اها جوڙجڪ [`Result`] تي [`into_iter`] طريقو پاران ٺهيل آهي (ايڪس سيڪڪس ايڪس ٽرٽ پاران فراهم ڪئي وئي آهي).
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// `Iterator` ۾ هر عنصر وٺي ٿو: جيڪڏهن اهو `Err` آهي ، وڌيڪ عنصر نه ورتو وڃي ٿو ، ۽ `Err` واپس ڪيو وڃي ٿو.
    /// ڇا `Err` واقع نه ٿئي ، ھر `Result` جي قدر سان گڏ ھڪ ڪنٽينر واپس ڪيو وڃي.
    ///
    /// هتي هڪ مثال آهي جيڪو vector ۾ هر انٽيگرم کي وڌائيندو آهي ، اوور فلو جي چڪاس ٿو ڪري.
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// هتي هڪ ٻيو مثال آهي جيڪو انٽيگر جي هڪ ٻي فهرست مان ٻئي کي رد ڪرڻ جي ڪوشش ڪندو آهي ، هن وقت هيٺ وهڪري جي چڪاس:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// هتي پوئين مثال تي هڪ تغير آهي ، ظاهر ڪري ٿو ته پهرين `Err` کان پوءِ `iter` کان وڌيڪ عنصر ڪونه ورتو وڃي.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// جئين ٽئين عنصر هڪ وهڪرو سبب بڻيو ، وڌيڪ عنصر نه ورتو ويو ، تنهنڪري `shared` جي آخري قيمت 6 (= `3 + 2 + 1`) آهي ، 16 نه.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): اهو Iterator::scan سان مٽائي سگھجي ها جڏهن ته هي ڪارڪردگي بگ بند ٿي وئي آهي.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}