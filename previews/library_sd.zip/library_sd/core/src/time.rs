#![stable(feature = "duration_core", since = "1.25.0")]

//! عارضي مقدار جي مقدار.
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // ٻئي اعلان برابر آهن
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// هڪ `Duration` قسم هڪ مدي واري وقت جي نمائندگي ڪرڻ لاءِ ، عام طور تي نظام وقت جي التواء لاءِ استعمال ٿيندو آهي.
///
/// هر `Duration` سيڪنڊ جي سيڪنڊن جي تعداد تي مشتمل آهي ۽ هڪ جزوي حصو نانو سيڪنڊ ۾ نمائندگي ڪئي وئي آهي.
/// جيڪڏهن ناڻي وارو نظام نانو سيڪنڊ جي سطح جي درستگيءَ کي سپورٽ نٿو ڪري ، APIس هڪ سسٽم ٽائيم آئوٽ کي باضابطه طور تي نانو سيڪنڊ جي تعداد کي وڌائي ڇڏينديون.
///
/// ["دوري"] ڪيترن ئي عام traits تي عملدرآمد ، بشمول [`Add`] ، [`Sub`] ، ۽ ٻيا [`ops`] traits.اهو [`Default`] کي صفر جي ڊيگهه `Duration` موٽائي ڏيڻ تي لاڳو ڪندو آهي.
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # `Duration` قدرن کي ترتيب ڏيڻ
///
/// `Duration` ارادتي طور تي `Display` لاڳو نٿو ٿئي ، ڇاڪاڻ ته انساني پڙھڻ لاءِ وقت جي فاصلي کي شڪل ڏيڻ جا ڪيترائي طريقا آھن.
/// `Duration` `Debug` مهيا ڪندو آهي جيڪو قدر جي درستگي ڏيکاري ٿو.
///
/// `Debug` ٻاھر مائڪرو سيڪنڊ لاءِ غير ASCII "µs" لاحق استعمال ڪندو آھي.
/// جيڪڏهن توهان جو پروگرام ٻاڪس ترتيب ڏنل ٿي سگھي ٿو جيڪي مڪمل يونيڪوڊ مطابقت تي ڀروسو نه ٿا ڪري سگهن ، توهان شايد `Duration` شيون پاڻ فارمٽ ڪرڻ چاهيو يا crate استعمال ڪريو.
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // هميشه 0 <=نانو <NANOS_PER_SEC
}

impl Duration {
    /// هڪ سيڪنڊ جو عرصو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// هڪ ملي سيڪنڊ جو عرصو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// هڪ مائيڪرو سيڪنڊ جو عرصو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// هڪ nanosecond جي مدي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// صفر وقت جو عرصو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// وڌ ۾ وڌ عرصو.
    ///
    /// اهو تقريبن 584،942،417،355 سالن جي عرصي جي برابر آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// مخصوص سيڪنڊن ۽ اضافي نانو سيڪنڊ جي مخصوص نمبر مان هڪ نئون `Duration` ٺاهي ٿو.
    ///
    /// جيڪڏهن نانو سيڪنڊ جو تعداد 1 ارب کان وڌيڪ آهي (هڪ سيڪنڊ ۾ نانو سيڪنڊ جو تعداد) ، ته اهو فراهم ڪيل سيڪنڊن ۾ ئي هلي ويندو.
    ///
    ///
    /// # Panics
    ///
    /// اهو ٺاهيندڙ panic ٿيندو جيڪڏهن نونو سيڪنڊ کان کڻندڙ سيڪنڊ جي ڪورس کي وڌيڪ ڪري ڇڏي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// پوري سيڪنڊن جي مخصوص تعداد مان نئون `Duration` ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// مليس سيڪنڊن جي مخصوص تعداد مان هڪ نئون `Duration` ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// microseconds جي مخصوص عدد مان نئون `Duration` ٺاهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// نينو سيڪنڊ جي مخصوص تعداد مان هڪ نئون `Duration` ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// سچائي موٽائي ٿو جيڪڏهن هي `Duration` وقت نه ٿو وڃي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// ھن `Duration` تي مشتمل _whole_ سيڪنڊن جو تعداد واپس آڻيندي.
    ///
    /// واپسي جي قيمت ۾ ورهاionalي واري (nanosecond) حصو شامل ناهي ، جيڪو [`subsec_nanos`] استعمال ڪندي حاصل ڪري سگهجي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// `Duration` پاران نمائندگي ڪندڙ سيڪنڊن جي ڪل تعداد کي طئي ڪرڻ لاءِ ، [`subsec_nanos`] سان گڏ `as_secs` استعمال ڪريو:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// هن `Duration` جو جزوي ڀاو واپس ڏئي ٿو ، پوري ميلي سيڪنڊ ۾.
    ///
    /// اهو طريقو **نه** واپسي جي ڊيگهه کي موٽائيندو آهي جڏهن مليس سيڪنڊ طرفان نمائندگي ٿيندي.
    /// واپسي ٿيل نمبر هميشه هڪ سيڪنڊ جي جزوي حصي جي نمائندگي ڪندو آهي (يعني اهو هڪ هزار کان گهٽ هوندو آهي).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// ھن `Duration` جي جزوي حصي کي واپسي ڏئي ٿو ، پوري مائڪرو سيڪنڊ ۾.
    ///
    /// اهو طريقو **نه** لمبائي جي مدت کي موٽائيندو آهي جڏهن مائڪرو سيڪنڊ جي نمائندگي ڪئي ويندي آهي.
    /// واپسي ٿيل نمبر هميشه هڪ سيڪنڊ جي جزوي حصي جي نمائندگي ڪندو آهي (يعني اها هڪ ملين کان گهٽ هوندي آهي).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// هن `Duration` جي جزوي حصي کي واپسي آهي ، نانو سيڪنڊ ۾.
    ///
    /// اهو طريقو **نه** واپسي جي مدت جي واپسي جڏهن نانو سيڪنڊ جي نمائندگي ڪري ٿو.
    /// واپسي ٿيل نمبر هميشه هڪ سيڪنڊ جي جزوي حصي جي نمائندگي ڪندو آهي (يعني اهو هڪ ارب کان گهٽ هوندو آهي).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// ھن `Duration` تي مشتمل پوري مليس سيڪنڊن جو مجموعي تعداد واپس ڏئي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// ھن `Duration` تي مشتمل پوري مائڪروڪوڪونڊز جي مجموعي تعداد کي واپسي ڏئي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// هن `Duration` تي مشتمل نينو سيڪنڊ جي مجموعي تعداد کي واپسي ڏئي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// ايڪسڪسيمڪس اضافي جي چڪاس ڪئي.
    /// ڳڻپيوڪر `self + other` ، واپسي [`None`] جيڪڏهن اوور فلو ٿي وئي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// مرڪب `Duration` اضافي.
    /// ڳڻپيوڪر `self + other` ، واپسي [`Duration::MAX`] جيڪڏهن اوور فلو ٿي وئي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` گھٽتائي جي چڪاس ڪئي وئي.
    /// `self - other` کي ڳڻيندو آهي ، [`None`] موٽڻ وارو جيڪڏهن نتيجو منفي هوندو يا جيڪڏهن اوور فلو ٿئي ٿي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ترتيب ڏيڻ `Duration` ماتحت.
    /// `self - other` کي ڳڻيندو آهي ، [`Duration::ZERO`] موٽڻ وارو جيڪڏهن نتيجو منفي هوندو يا جيڪڏهن اوور فلو ٿئي ٿي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// `Duration` ضرب جي چڪاس ڪئي.
    /// ڳڻپيوڪر `self * other` ، واپسي [`None`] جيڪڏهن اوور فلو ٿي وئي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // ضرب نونوو سيڪنڊ u64 طور ڪريو ، ڇاڪاڻ ته اهو انهي طريقي سان وڌي نه سگهي ٿو.
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// سيرٽڪس `Duration` ضرب.
    /// ڳڻپيوڪر `self * other` ، واپسي [`Duration::MAX`] جيڪڏهن اوور فلو ٿي وئي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// چيڪ ڪيو ويو `Duration` ڊويزن.
    /// ڳڻپيو ويو `self / other` ، واپس [`None`] جيڪڏهن `other == 0`.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// `f64` پاران ھي `Duration` شامل ڪيل سيڪنڊن جي تعداد کي واپس آڻيندو آھي.
    /// واپسي جي قيمت شامل آهي مدت جي جزوي (nanosecond) حصو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// `f32` پاران ھي `Duration` شامل ڪيل سيڪنڊن جي تعداد کي واپس آڻيندو آھي.
    /// واپسي جي قيمت شامل آهي مدت جي جزوي (nanosecond) حصو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// `f64` طور ڏيکاريل سيڪنڊن جي مخصوص تعداد مان نئون `Duration` ٺاهي ٿو.
    ///
    /// # Panics
    /// اهو ٺاهيندڙ panic ٿيندو جيڪڏهن `secs` مڪمل نه هجي ، منفي يا `Duration` کي ختم ڪري.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f32` طور ڏيکاريل سيڪنڊن جي مخصوص تعداد مان نئون `Duration` ٺاهي ٿو.
    ///
    /// # Panics
    /// اهو ٺاهيندڙ panic ٿيندو جيڪڏهن `secs` مڪمل نه هجي ، منفي يا `Duration` کي ختم ڪري.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f64` پاران `Duration` ضرب ڪري ٿو.
    /// # Panics
    /// اهو طريقو panic ٿيندو جيڪڏهن نتيجو حتمي نه هجي ، منفي يا ايڪسڪسيمڪس کي اوورلوف ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// `f32` پاران `Duration` ضرب ڪري ٿو.
    /// # Panics
    /// اهو طريقو panic ٿيندو جيڪڏهن نتيجو حتمي نه هجي ، منفي يا ايڪسڪسيمڪس کي اوورلوف ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // ياد رهي ته گولنگ جي غلطين جي نتيجي جي نتيجي ۾ 8.478 ۽ 847800.0 کان ٿورو مختلف آهي
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// `f64` کان `Duration` ورهايو.
    /// # Panics
    /// اهو طريقو panic ٿيندو جيڪڏهن نتيجو حتمي نه هجي ، منفي يا ايڪسڪسيمڪس کي اوورلوف ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // نوٽ ڪيو ته ڪتب آڻيو ويو آهي ، گول نه
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// `f32` کان `Duration` ورهايو.
    /// # Panics
    /// اهو طريقو panic ٿيندو جيڪڏهن نتيجو حتمي نه هجي ، منفي يا ايڪسڪسيمڪس کي اوورلوف ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // ياد رکجي ته گولنگ جي غلطين جي ڪري نتيجو 0.859_872_611 کان ٿورو مختلف آهي
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // نوٽ ڪيو ته ڪتب آڻيو ويو آهي ، گول نه
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// `Duration` `Duration` کي ورهايو ۽ `f64` واپس ڪيو.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// `Duration` `Duration` کي ورهايو ۽ `f32` واپس ڪيو.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// فارميٽ پوائنٽ نمبر کي ڊيمل نوٽ ۾ ترتيب ڏئي ٿو.
        ///
        /// انگ ايڪس اين ايڪس ايڪس ۽ هڪ جزوي حصي طور ڏنل آهي.
        /// ڀوري واري حصي جي قيمت `fractional_part / divisor` آهي.
        /// تنهن ڪري `integer_part` =3 ، `fractional_part` =12 ۽ `divisor` =100 اهو انگ `3.012` جي نمائندگي ڪري ٿو.
        /// پيچرو صفر ختم ٿي ويا.
        ///
        /// `divisor` 100_000_000 کان مٿي نه هجڻ گھرجي.
        /// اهو پڻ 10 جي طاقت هجڻ گهرجي ، باقي سڀ ڪجهه سمجهه ۾ نه ايندو.
        /// `fractional_part` `10 * divisor` کان گھٽ آھي
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // جزوي ڪفر کي عارضي طور تي بفر ۾ جوڙيو وڃي.
            // بفر کي صرف 9 عنصر رکڻ جي ضرورت آهي ، ڇو ته `fractional_part` کي 10 ^ 9 کان نن hasو رکڻو آهي.
            //
            // هيٺ ڏنل ڪوڊ کي آسان ڪرڻ لاءِ بفر '0' عددن سان اڳڀرائي ڪئي وئي آهي.
            let mut buf = [b'0'; 9];

            // ايندڙ انگ هن پوزيشن تي لکيو ويو آهي
            let mut pos = 0;

            // اسان بفر ۾ انگ لکندا رهون ٿا جڏهن ته صفر وارا عدد ناهن باقي ۽ اسان اڃا تائين ڪافي انگ اکر نه لکيو آهي.
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // بفر ۾ نئون انگ لکرايو
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // جيڪڏهن هڪ قدم <9 بيان ڪيو ويو هجي ، ٿي سگهي ٿو ڪجهه بي لا۽ صفر عدد جيڪي بفر ۾ نه لکيل هئا.
            // ان صورت ۾ اسان کي عام فلوٽنگ پوائنٽ جي نمبرن جي پرنٽنگ جي سمجهاڻي سان ملائڻ لاءِ گول ڪرڻ جي ضرورت آهي.
            // جڏهن ته ، اسان کي صرف ڪم ڪرڻو پوندو آهي جڏهن گولائي ڪرڻ.
            // اهو ٿئي ٿو جيڪڏهن بچيل وارن جو پهريون عدد>=5.
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // بفر ۾ شامل نمبر کي گول ڪريو.
                // اسان بفر کان پوئتي موٽيا وڃون ٿا ۽ ڪياري جو رستو رکو ٿا.
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // جيڪڏهن بفر ۾ عدد '9' نه آهي ، اسان کي صرف انهي ۾ اضافو ڪرڻ جي ضرورت آهي ۽ انهي کي روڪي سگھي ٿو (ڇاڪاڻ ته اسان وٽ هاڻي کڻڻ نه آهي).
                    // ٻي صورت ۾ ، اسان ان کي سيٽ ڪريو '0' (overflow) ۽ جاري رکو.
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // جيڪڏهن اسان اڃا تائين ڪيري بيٽ سيٽ رکيا آهيون ، انهي جو مطلب اهو آهي ته اسان مڪمل 0 تي واري بفر کي '0's ڪيو ۽ انٽيگر حصو کي وڌائڻ جي ضرورت آهي.
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // بفر جي پڇاڙي کي طئي ڪيو: جيڪڏهن درستگي طئي ڪئي وئي ، اسان بفر مان ڪيترا ئي عدد ئي استعمال ڪريو (9 ڏانهن محدود ٿيل).
            // جيڪڏهن اهو سيٽ ناهي ، اسان صرف آخري انگ اکر تائين سڀني عددن جو استعمال ڪندا آهيون.
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // جيڪڏهن اسان هڪ جزئي عددي خارج نه ڪئي ۽ درستگي غير صفر جي قيمت تي مقرر نه ڪئي وئي ، اسان ديسيمل پوائنٽ کي پرنٽ نٿا ڪريون.
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // حفاظت: اسان صرف ASCII عدد بفر ۾ لکي رهيا آهيون ۽ اهو هو
                // 0 جي شروعات سان ، انهي ۾ صحيح UTF8 شامل آهي
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // جيڪڏھن استعمال ڪندڙ ڪا رڪنيت جي درخواست ڪري ٿو> 9 ، اسين آخر ۾ '0' پيڊ ڪريون ٿا.
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // جيڪڏهن درخواست ڪئي وئي ته '+' نشان پرنٽ ڪريو
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}