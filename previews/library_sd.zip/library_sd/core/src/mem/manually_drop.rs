use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// يو ٽي کي تباهي ڪندڙ پاڻمرادو ڪال ڪرڻ کان روڪيندڙ هڪ ريپر.
/// هي ريپر 0 قيمت آهي.
///
/// `ManuallyDrop<T>` `T` وانگر ساڳئي ترتيب جي اصلاحن جي تابع آهي.
/// نتيجي طور ، اهو مفروضن تي * ڪو اثر نه پيو پوي جو مرتب ڪندڙ ان جي مواد بابت ٺاهي ٿو.
/// مثال طور ، [`mem::zeroed`] سان `ManuallyDrop<&mut T>` جي شروعات غفلت واري رويو آهي.
/// جيڪڏهن توهان کي غير شروع ٿيل ڊيٽا سنڀالڻ جي ضرورت آهي ، بدران [`MaybeUninit<T>`] استعمال ڪريو.
///
/// نوٽ ڪيو ته ايڪس `ManuallyDrop<T>` X ۾ قيمت تائين رسائي محفوظ آهي.
/// هن جو مطلب اهو آهي ته هڪ `ManuallyDrop<T>` جنهن جو مواد بيهاريو ويو آهي ان کي عوامي محفوظ API ذريعي ظاهر نه ڪيو وڃي.
/// صحيح طرح ، `ManuallyDrop::drop` غير محفوظ آھي.
///
/// # `ManuallyDrop` ۽ ڊراپ آرڊر.
///
/// Rust قدر جي صحيح Xاڻيل [drop order] آهي.
/// انهي ڳالهه کي يقيني بڻائڻ لاءِ ته زمينون ۽ علائقا هڪ خاص ترتيب ۾ گهٽجي ويا آهن ، اعلانن کي ٻيهر ترتيب ڏين ته جئين قطب نما قطرو حڪم درست آهي.
///
/// اهو ممڪن آهي ته `ManuallyDrop` ڊراپ آرڊر کي ڪنٽرول ڪرڻ لاءِ استعمال ڪجي ، پر انهي لاءِ غير محفوظ ڪوڊ جي ضرورت آهي ۽ اڻ کٽ جي موجودگي ۾ صحيح طريقي سان انجام ڏيڻ مشڪل آهي.
///
///
/// مثال طور ، جيڪڏهن توهان اهو پڪ ڪرڻ چاهيو ٿا ته هڪ مخصوص فيلڊ ٻين جي پٺيان ڇڏڻ جو آهي ، ان کي ٺاهيندڙ جو آخري ميدان ٺاهيو:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` کان پوءِ ڇڏيو ويندو.
///     // Rust ضمانت ڏي ٿو ته ميدان اعلان جي حڪم ۾ کٽي ويا.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// دستي طور ٻڏي وڃڻ لاءِ قيمت ورايو.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // توھان اڃا تائين محفوظ طور تي قيمت تي هلائي سگھو ٿا
    /// assert_eq!(*x, "Hello");
    /// // پر ايڪس ايڪس ايڪس هتي نه هليو ويندو
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` ڪنٽينر مان قدر ڪي ٿو.
    ///
    /// هي قدر ٻيهر ڇڏڻ جي اجازت ڏئي ٿو.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // هي `Box` ٽي ٿو.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` ڪنٽينر کان قيمت ڪ outي ٿو.
    ///
    /// ھي طريقو بنيادي طور تي ڪٽڻ ۾ قدرن کي منتقل ڪرڻ جو مقصد آھي.
    /// [`ManuallyDrop::drop`] استعمال ڪرڻ جي بدران دستي طور تي قيمت ڪ dropڻ لاءِ ، توهان هن طريقي کي استعمال ڪري ان قيمت کي استعمال ڪيو ۽ مطلوب طور تي ٿي استعمال ڪري سگهو ٿا.
    ///
    /// جڏهن به ممڪن ٿئي ، [`into_inner`][`ManuallyDrop::into_inner`] جي بدران استعمال ڪرڻ ترجيح آهي ، جيڪا `ManuallyDrop<T>` جي مواد کي نقل ڏيڻ کان روڪي ٿي.
    ///
    ///
    /// # Safety
    ///
    /// اهو فنڪشن بنيادي طور تي وڌيڪ استعمال کي روڪڻ کان بغير قيمت تي ٻاهر نڪري ٿو ، هن ڪنٽينر جي حالت کي leavingيرائي ڇڏي ٿو.
    /// اهو توهان جي ذميواري آهي ته توهان انهي `ManuallyDrop` کي ٻيهر استعمال نه ڪرڻ جي پڪ ڪريو.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // حفاظت: اسان هڪ حوالي سان پڙهي رهيا آهيون ، جنهن جي گارنٽي آهي
        // پڙهائي لاءِ صحيح هجڻ.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// دستياب ٿيل قيمت کي دستي طور تي dropsٽو ڪري ٿو.اهو بلڪل صحيح طور تي [`ptr::drop_in_place`] کي پوائنٽر سان موجود قيمت سان سڏڻ جي برابر آهي.
    /// جيئن ته ، جيستائين موجود قيمت ڀريل پيڪيج نه آهي ، خراب ڪندڙ قيمت کي حرڪت ڪرڻ جي بغير جاءِ تي سڏيو ويندو ، ۽ اهڙي طرح ايڪس ايڪس ايڪس ڊيٽا کي محفوظ طور تي ڇڏڻ لاءِ استعمال ڪري سگهجي ٿو.
    ///
    /// جيڪڏهن توهان وٽ قدر جي ملڪيت آهي ، توهان بدران [`ManuallyDrop::into_inner`] استعمال ڪري سگهو ٿا.
    ///
    /// # Safety
    ///
    /// اهو فنڪشن موجود قيمت جي تباهي ڪندڙ هلندو آهي.
    /// تباهي واري پاڻ سان ڪيل تبديلين کان سواءِ ، ياداشت يڪدم تبديل ٿي چڪو آھي ، ۽ ايتري تائين جو ٺاھيندڙ ٺاھيندڙ آھي اڃا تائين ھڪڙي بيٽ نمونو رھي ٿو جيڪو `T` قسم لاءِ صحيح آھي.
    ///
    ///
    /// تنهن هوندي ، هن "zombie" قيمت کي محفوظ ڪوڊ کي ظاهر نه ڪيو وڃي ، ۽ هن فنڪشن کي هڪ کان وڌيڪ نه سڏيو وڃي.
    /// گرڻ کان پوءِ قيمت استعمال ڪرڻ ، يا قدر وڃائڻ جي ڀيٽ ۾ ، اڻ اعلانيل رويو پيدا ڪرڻ جو سبب بڻجڻ (ان تي منحصر آهي جيڪو `drop` ڪندو آهي).
    /// اهو عام طور تي ٽائپ سسٽم کان روڪيو ويندو آهي ، پر ايڪس آرڪس جي استعمال ڪندڙن کي اهي تاليفون تاليف ڪندڙ کان مدد وٺن ٿيون.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // حفاظت: اسان هڪ قابل تبديلي حوالي سان ظاهر ڪيل قدر وڃائي رهيا آهيون
        // جيڪا لکڻ وارن جي جائز هجڻ جي ضمانت هجي.
        // اهو ڪالر تي منحصر آهي ته پڪ ڪري ته `slot` ٻيهر نه گريو ويو.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}