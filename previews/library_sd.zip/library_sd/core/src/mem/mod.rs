//! ياداشت سان واسطو رکندڙ بنيادي ڪم.
//!
//! ھن ماڊل ۾ ميموري جي شروعات ، منڊي کي منظم ڪرڻ ۽ قسمن جي قسمن ۽ ترتيب لاءِ سوال ڪرڻ شامل آھن.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// تخريبڪار کي هلائڻ کان بغير **ملڪيت ۽ "forgets" وٺي ٿو**.
///
/// ڪي به وسيلا قدر کي منظم ڪن ٿا ، جهڙوڪ هيپ ياداشت يا هڪ فائل جو هينڊل ، هميشه تائين نه پهچڻ واري حالت ۾ سدائين رهندو.بهرحال ، اهو ضمانت نه ٿو ڏئي ته انهي يادگيري ڏانهن اشارو صحيح رهندو.
///
/// * جيڪڏهن توهان ميموري ليڪ ڪرڻ چاهيو ٿا ، [`Box::leak`] ڏسو.
/// * جيڪڏهن توهان ياداشت ڏانهن هڪ خام پوائنٽر حاصل ڪرڻ چاهيو ٿا ، [`Box::into_raw`] ڏسو.
/// * جيڪڏهن توهان صحيح طور تي هڪ قيمت ختم ڪرڻ چاهيندا ، هن جي تباهي ڪندڙ ، هلائيندڙ [`mem::drop`] ڏسو.
///
/// # Safety
///
/// `forget` `unsafe` طور نشان لڳل نه آهي ، ڇاڪاڻ ته Rust جي حفاظت جي ضمانت هڪ گارنٽيشن شامل ناهي ته تباهي هميشه هلندا.
/// مثال طور ، هڪ پروگرام [`Rc`][rc] استعمال ڪندي هڪ حوالو وارو چڪر ٺاهي سگھي ٿو ، يا [`process::exit`][exit] کي سڏيندو ته تباهي ڪرڻ وارن کان بغير نڪرڻ لاءِ.
/// اهڙيء طرح ، `mem::forget` کي محفوظ ڪوڊ کان اجازت ڏيڻ بنيادي طور تي Rust جي حفاظتي ضمانتن کي تبديل نٿو ڪري.
///
/// اهو چيو ته ، لابنگ وارو وسيلا جهڙوڪ ياداشت يا I/O شيون عام طور تي ناپسنديده آهن.
/// ضرورت ايف ايف آئي يا غير محفوظ ٿيل ڪوڊ جي ڪجهه خاص استعمال جي ڪيسن ۾ اچي ٿي ، پر ان جي باوجود ، [`ManuallyDrop`] عام طور تي ترجيح ڏني ويندي آهي.
///
/// ڇو ته هڪ قدر وساري ڇڏڻ جي اجازت آهي ، ڪو به `unsafe` ڪوڊ جيڪو توهان لکي ٿو لازمي طور تي هن امڪان لاءِ اجازت ڏيڻ گهرجي.توهان هڪ قيمت واپس نه ٿا ڪري سگهو ۽ توقع ڪريو ته ڪالر لازمي طور تي قيمت هلائيندڙ کي هلائي سگهندو.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` جو سڌي محفوظ استعمال قدر جي تباهي کي ختم ڪرڻ آهي `Drop` trait پاران.مثال طور ، اهو ايڪسڪسيمڪس لڪايو ويندو ، يعني
/// ٻيهر کڻي خلاء کي کٽيو وڃي ، پر ڪڏهن به هيٺيان سسٽم جي وسيلن کي بند نه ڪريو.
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// اهو مفيد آهي جڏهن پوئين وسيلن جي ملڪيت اڳوڻي Rust کان ڪوڊ تي منتقل ٿي وئي آهي ، مثال طور خام فائل جي وضاحت ڪندڙ کي C ڪوڊ ڏانهن منتقل ڪندي.
///
/// # `ManuallyDrop` سان تعلق
///
/// جڏهن ته `mem::forget` پڻ *يادگيري* ملڪيت جي منتقلي لاءِ استعمال ڪري سگهجي ٿو ، ائين ڪرڻ غلطي کان پري آهي.
/// [`ManuallyDrop`] بدران استعمال ڪيو وڃي.مثال طور غور ڪريو ، هي ڪوڊ:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // ايڪس `v` جو مواد استعمال ڪندي `String` ٺاهيو
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` ليڪ ڪريو ڇو ته ان جي ميموري هاڻ `s` پاران منظم ڪئي وئي آهي
/// mem::forget(v);  // ERROR ، وي غلط آھي ۽ ھڪڙي فنڪشن ۾ پاس نه ٿيڻ گھرجي
/// assert_eq!(s, "Az");
/// // `s` ناجائز طور تي droppedٽي وئي آهي ۽ ان جي يادگيري ختم ڪئي وئي آهي.
/// ```
///
/// مٿي exampleاڻايل مثال سان ٻه مسئلا آهن:
///
/// * جيڪڏهن `String` جي تعمير ۽ `mem::forget()` جي ايجاد جي وچ ۾ وڌيڪ ڪوڊ شامل ڪيو ويو ، ان ۾ panic ٻيڻو فري ٿيندو ڇو ته `v` ۽ `s` ٻنهي جي ساڳئي يادداشت هٿ ڪئي وئي آهي.
/// * `v.as_mut_ptr()` کي ڪال ڪرڻ ۽ ڊيٽا جي ملڪيت جي منتقلي `s` کان پوءِ ، `v` ويليو غلط آهي.
/// جيتوڻيڪ جڏهن هڪ قيمت صرف `mem::forget` ڏانهن منتقل ڪيو وڃي (جيڪو اهو ان جي معائنو نه ڪندو) ، ڪجهه قسمن کي انهن جي قدرن تي سخت گهرج هوندي آهي جيڪي انهن کي ناجائز بڻائي ڇڏيندا آهن جڏهن رکو يا هاڻي وڌيڪ ملڪيت نه هوندي.
/// ڪنهن به طريقي سان غلط قدرن کي استعمال ڪرڻ ، انهن کي پاس ڪرڻ يا انهن کي افعال مان واپس ڪرائڻ سميت ، غير تعين ڪيل رويو قائم ڪرڻ ۽ مرتب ڪندڙن پاران ڏنل گمانن کي ٽوڙڻ.
///
/// `ManuallyDrop` ڏانهن مٽائڻ ٻنهي مسئلن کان بچي ٿو:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // ان کان اڳ جو اسين ايڪس آر ايڪس کي ان جي خام حصن ۾ ڌار ڪريو ، پڪ ڪريو ته اهو گر نه ٿيو!
/////
/// let mut v = ManuallyDrop::new(v);
/// // ھاڻي ايڪس سيڪس کي ختم ڪريو.اهي آپريشن panic نٿا ڪري سگھن ، ان ڪري ليکڪ ناهي ٿي سگھي.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // آخرڪار ، ايڪس X00 تعمير ڪريو.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ناجائز طور تي droppedٽي وئي آهي ۽ ان جي يادگيري ختم ڪئي وئي آهي.
/// ```
///
/// `ManuallyDrop` مضبوط طور تي ٻٽي فري کان بچي ٿو ڇاڪاڻ ته اسان ڪجهه ڪرڻ کان پهرين "وي" جي تباهه ڪندڙ کي ناڪاره ڪريون ٿا.
/// `mem::forget()` انهي جي اجازت نه ٿو ڏئي ڇاڪاڻ ته اهو پنهنجي دليل استعمال ڪري ٿو ، اسان کي مجبور ڪرڻ بعد ان کي ايڪس 0 ايڪس تان اسان کي گهربل ڪجهه به ڪ afterڻ کان پوءِ.
/// جيتوڻيڪ panic متعارف ڪرايو ويو `ManuallyDrop` جي تعمير ۽ اسٽرنگ جي تعمير جي وچ ۾ (جيڪو ڪوڊ ۾ ڏيکاريل نه هوندو آهي) ، انهي جي نتيجي ۾ ليول ۽ ٻه ڀيرا آزاد نه ٿيندو.
/// ٻين لفظن ۾ ، `ManuallyDrop` (رڻ جي پاسي غلط ٿيڻ جي بدران (ٻٽي) گرائڻ واري پاسي.
///
/// پڻ ، `ManuallyDrop` اسان کي `s` کان بچائڻ کان روڪي ٿو `s` کي ملڪيت جي منتقلي کان پوء-`v` سان رابطو ڪرڻ جو حتمي قدم ان جي تباهي تي هلائڻ کانسواءِ هن کي ضائع ڪرڻ کان مڪمل طور تي پاسو ڪرڻ.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] وانگر ، پر پڻ ناقابل قبول قدر قبول ڪري ٿو.
///
/// اها فنڪشنل صرف هڪ شي کي هٽائڻ جو ارادو ڪيو ويو جڏهن `unsized_locals` خصوصيت مستحڪم ٿي وڃي.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// بائيٽ ۾ ھڪڙي قسم جي سائيز موٽائي ٿو.
///
/// وڌيڪ خاص طور تي ، اهو بائيٽ ۾ بائنس ۾ قطار جي عناصر سان گڏ شين جي قسم سان گڏ ترتيب شامل آهي.
///
/// ان ڪري ، `T` ۽ ڊيگهه `n` جي ڪنھن به قسم جي لاءِ ، `[T; n]` وٽ ھڪڙو `n * size_of::<T>()` آھي.
///
/// عام طور تي ، ھڪڙي قسم جي سائيز مجموعي طور تي مستحڪم نه آھي ، پر خاص قسم جھڙو آھي پرائميوٽس.
///
/// هيٺ ڏنل ٽيبل آدمشماري لاءِ سائيز ڏي ٿي.
///
/// قسم |سائيز_ه: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 خير |4
///
/// ان کان علاوه ، `usize` ۽ `isize` جي ساڳي سائيز آهي.
///
/// `*const T` ، `&T` ، `Box<T>` ، `Option<&T>` ، ۽ `Option<Box<T>>` سڀني قسمن ۾ ساڳئي سائيز آهي.
/// جيڪڏهن `T` سئيز ٿيل آهي ، انهن سڀني قسمن ۾ `usize` جي ساڳي ماپ آهي.
///
/// پوائنٽر جي متغيرت ان جي سائيز تبديل نه ڪندو آهي.جيئن ، `&T` ۽ `&mut T` جي ساڳي سائيز آهي.
/// ساڳي طرح `*const T` ۽ `* mut T` لاءِ.
///
/// # ايڪس ايڪس ايڪس شيون جي ماپ
///
/// شين لاءِ `C` جي نمائندگي ھڪڙي ترتيب ڏنل آھي.
/// هن ترتيب سان ، شين جو قد پڻ مستحڪم آهي جيستائين سڀني شعبن کي مستحڪم سائيز آهي.
///
/// ## ڳاڙهن جو سائيز
///
/// `structs` لاءِ ، سائيز هيٺ ڏنل الگورتھم طرفان طئي ڪيو ويو آهي.
///
/// اعلان واري آرڊر پاران ترتيب ڏنل ترتيب ۾ هر فيلڊ لاءِ:
///
/// 1. فيلڊ جي سائيز کي شامل ڪريو.
/// 2. موجوده سائيز کي [alignment] ايندڙ فيلڊ جي ويجهي کان گهڻن طرف گول ڪيو.
///
/// آخرڪار ، ساخت جي سائيز کي پنھنجي [alignment] جي ويجھو گهڻن تائين گول ڪري.
/// ساخت جي ترتيب عام طور تي ان جي سڀني شعبن جو وڏو مرڪب آهي.ھي ايڪس ايڪس ايڪس جي استعمال سان مٽائي سگھجي ٿو.
///
/// `C` جي مقابلي ۾ ، زيرو سائيز واريون شڪلون ھڪڙي بائيٽ تائين گول نه آھن.
///
/// ## اينيمڪس جو سائز
///
/// ايونج جيڪي ٻئي ڊيٽا کان بغير ڪنهن فرق جي ٻئي carryاڻيو ئي نه هونديون آهن جيترو C اينيمس پليٽ فارم تي جيڪي اهي گڏ ڪيون وينديون آهن.
///
/// ## اتحادين جو قد
///
/// يونين جو اندازو هن جي سڀ کان وڏي ميدان جو شڪل آهي.
///
/// `C` جي نسبت ، زيرو سائيز وارا اتحادون بائٽ جي سائيز تائين گول نه آهن.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // ڪجهه آدمشماري
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // ڪجهه arrays
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // پوائنٽر سائيز برابر
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` استعمال ڪندي.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // پهرين فيلڊ جي ڊيگهه 1 آهي ، تنهن ڪري سائيز ۾ 1 شامل ڪريو.سائيز 1 آهي.
/// // ٻي فيلڊ جي ترتيب 2 آهي ، تنهن ڪري 1 کي پيڊ ڪرڻ لاءِ سائيز ۾ شامل ڪريو.سائيز 2 آهي.
/// // ٻي فيلڊ جو سائز 2 آهي ، تنهنڪري 2 کي سائز ۾ شامل ڪريو.سائيز 4 آهي.
/// // ٽئين فيلڊ جي ترتيب 1 آهي ، تنهن ڪري پيٽنگ کي سائيز واري 0 ۾ شامل ڪريو.سائيز 4 آهي.
/// // ٽئين فيلڊ جو سائز 1 آهي ، ڊيگهه 1 ۾ شامل ڪريو.سائيز 5 آهي.
/// // آخرڪار ، theانچي جي ترتيب 2 آهي (ڇاڪاڻ ته هن جي ميدانن جي وچ ۾ وڏي ترتيب 2 آهي) ، تنهن ڪري پيڊنگ جي سائيز تي 1 کي شامل ڪريو.
/// // سائيز 6 آهي.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // مٿين قاعدن ساڳين ضابطن تي عمل ڪيو.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // ياد رکجو ته ميدانن کي ٻيهر ترتيب ڏيڻ وارا طريقا گهٽائي سگهن ٿا.
/// // اسان `second` کان اڳ `third` لڳائڻ سان ٻنهي پيڊنگ بائيٽ کي ڪ removeي سگهو ٿا.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // يونين سائيز سڀني کان وڏي ميدان جو سائز آهي.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// بائيٽ ۾ پوائنٽ ويليو جي قيمت کي واپس ڪري ٿو.
///
/// هي عام طور تي `size_of::<T>()` وانگر ساڳيو آهي.
/// تنهن هوندي ، جڏهن `T` * معياري طور تي sizeاڻايل سائيز نه آهي ، مثال طور ، هڪ نن Xڙو [`[T]`][slice] يا هڪ [trait object] ، تڏهن `size_of_val` متحرڪ طور سڃاتل سائيز حاصل ڪري سگهجي ٿو.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // حفاظت: `val` هڪ حوالو آهي ، تنهن ڪري اهو هڪ صحيح خام پوائنٽر آهي
    unsafe { intrinsics::size_of_val(val) }
}

/// بائيٽ ۾ پوائنٽ ويليو جي قيمت کي واپس ڪري ٿو.
///
/// هي عام طور تي `size_of::<T>()` وانگر ساڳيو آهي.تنهن هوندي ، جڏهن `T` * معياري طور تي sizeاڻايل سائيز نه آهي ، مثال طور ، هڪ نن Xڙو [`[T]`][slice] يا هڪ [trait object] ، تڏهن `size_of_val_raw` متحرڪ طور سڃاتل سائيز حاصل ڪري سگهجي ٿو.
///
/// # Safety
///
/// جيڪڏهن اها هيٺين حالتون جهليندي ، اهو ڪم صرف محفوظ هوندو.
///
/// - جيڪڏهن `T` `Sized` آهي ، اهو فنڪشن هميشه محفوظ آهي.
/// - جيڪڏهن `T` جو غير ترتيب ڏنل دم آهي:
///     - هڪ [slice] ، پوءِ سلائس جي ڊيگهه جي ڊيگهه ابتدائي عدد هجڻ گهرجي ، ۽ *س valueو قدر جي سائيز*(متحرڪ دم جي ڊيگهه + جامد ماپ واري اڳياڙي) ضرور `isize` ۾ مناسب هجڻ گهرجي.
///     - هڪ [trait object] ، پوءِ پوائنٽر جو vtable حصو لازمي طور تي هڪ vizing جي زور تي حاصل ڪيل هڪ درست vtable طرف اشارو ڪيو وڃي ٿو ، ۽ *پوري ويل جو قد*(متحرڪ دم جي ڊيگهه + جامد ماپ وارو اڳياڙي) x00X ۾ لازمي طور تي لازمي هئڻ گهرجي.
///
///     - هڪ (unstable) [extern type] ، پوءِ اهو فنڪشن هميشه لاءِ محفوظ آهي ، پر شايد panic يا ٻي صورت ۾ غلط ويليو موٽائي سگهي ، جيئن ته ٻاهرين قسم جي ترتيب جي layoutاڻ نه هجي.
///     اهو هڪ ئي قسم آهي خارجي قسم جي دم سان هڪ قسم جي حوالي سان [`size_of_val`].
///     - ٻي صورت ۾ ، محافظ طور تي هن فنڪشن کي سڏڻ جي اجازت ناهي.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // حفاظت: ڪال ڪندڙ کي لازمي خام پوائنٽر فراهم ڪرڻ گھرجي
    unsafe { intrinsics::size_of_val(val) }
}

/// [ABI] گهربل قسم جي گھٽ ۾ گھٽ ترتيب ڏيکاريو
///
/// `T` قسم جي قيمت جي هر حوالي سان هن نمبر جي گھڻائي هجڻ لازمي آهي.
///
/// هي متوازن ترتيب ڏنل شعبن لاءِ استعمال ڪئي وئي.ٿي سگهي ٿو نن theن ترجيحن کان نن smallerو هجي.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// واپسي جي [اي بي آئي] گهربل ضروري قيمت جي قيمت کي واپس ڏئي ٿي جنهن جي طرف `val` اشارو ڪيو ويو آهي.
///
/// `T` قسم جي قيمت جي هر حوالي سان هن نمبر جي گھڻائي هجڻ لازمي آهي.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // حفاظت: وال هڪ حوالو آهي ، تنهن ڪري اهو هڪ صحيح خام اشارو آهي
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI] گهربل قسم جي گھٽ ۾ گھٽ ترتيب ڏيکاريو
///
/// `T` قسم جي قيمت جي هر حوالي سان هن نمبر جي گھڻائي هجڻ لازمي آهي.
///
/// هي متوازن ترتيب ڏنل شعبن لاءِ استعمال ڪئي وئي.ٿي سگهي ٿو نن theن ترجيحن کان نن smallerو هجي.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// واپسي جي [اي بي آئي] گهربل ضروري قيمت جي قيمت کي واپس ڏئي ٿي جنهن جي طرف `val` اشارو ڪيو ويو آهي.
///
/// `T` قسم جي قيمت جي هر حوالي سان هن نمبر جي گھڻائي هجڻ لازمي آهي.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // حفاظت: وال هڪ حوالو آهي ، تنهن ڪري اهو هڪ صحيح خام اشارو آهي
    unsafe { intrinsics::min_align_of_val(val) }
}

/// واپسي جي [اي بي آئي] گهربل ضروري قيمت جي قيمت کي واپس ڏئي ٿي جنهن جي طرف `val` اشارو ڪيو ويو آهي.
///
/// `T` قسم جي قيمت جي هر حوالي سان هن نمبر جي گھڻائي هجڻ لازمي آهي.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// جيڪڏهن اها هيٺين حالتون جهليندي ، اهو ڪم صرف محفوظ هوندو.
///
/// - جيڪڏهن `T` `Sized` آهي ، اهو فنڪشن هميشه محفوظ آهي.
/// - جيڪڏهن `T` جو غير ترتيب ڏنل دم آهي:
///     - هڪ [slice] ، پوءِ سلائس جي ڊيگهه جي ڊيگهه ابتدائي عدد هجڻ گهرجي ، ۽ *س valueو قدر جي سائيز*(متحرڪ دم جي ڊيگهه + جامد ماپ واري اڳياڙي) ضرور `isize` ۾ مناسب هجڻ گهرجي.
///     - هڪ [trait object] ، پوءِ پوائنٽر جو vtable حصو لازمي طور تي هڪ vizing جي زور تي حاصل ڪيل هڪ درست vtable طرف اشارو ڪيو وڃي ٿو ، ۽ *پوري ويل جو قد*(متحرڪ دم جي ڊيگهه + جامد ماپ وارو اڳياڙي) x00X ۾ لازمي طور تي لازمي هئڻ گهرجي.
///
///     - هڪ (unstable) [extern type] ، پوءِ اهو فنڪشن هميشه لاءِ محفوظ آهي ، پر شايد panic يا ٻي صورت ۾ غلط ويليو موٽائي سگهي ، جيئن ته ٻاهرين قسم جي ترتيب جي layoutاڻ نه هجي.
///     اهو هڪ ئي قسم آهي خارجي قسم جي دم سان هڪ قسم جي حوالي سان [`align_of_val`].
///     - ٻي صورت ۾ ، محافظ طور تي هن فنڪشن کي سڏڻ جي اجازت ناهي.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // حفاظت: ڪال ڪندڙ کي لازمي خام پوائنٽر فراهم ڪرڻ گھرجي
    unsafe { intrinsics::min_align_of_val(val) }
}

/// ايڪس 0 ايڪس کي واپسي جيڪڏهن اقدار کي گھٽائيندي آهي `T` معاملو.
///
/// اهو خالص طور تي اصلاح جي نشاندهي آهي ، ۽ محافظ طور تي لاڳو ٿي سگهي ٿو.
/// اهو شايد `true` قسم جي واپسي ڏي سگھي ٿو جيڪا اصل ۾ نن toڙي ڇڏڻ جي ضرورت ناهي.
/// جئين سدائين `true` موٽڻ هن فنڪشن جو صحيح نفاذ هوندو.تنهن هوندي جيڪڏهن اهو فنڪشن اصل ۾ `false` موٽائي ٿو ، ته توهان پڪ ڪري سگهو ٿا ته `T` ڇڏڻ جو ڪو به اثر ناهي.
///
/// مجموعي طور تي شين وانگر گهٽ سطح تي عمل درآمد ، جيڪي دستي طور تي انهن جي ڊيٽا کي ڇڏڻ جي ضرورت هوندي آهي ، اهي هن فنڪشن کي استعمال ڪن ته غير ضروري طور تي پنهنجون سڀ شيون گرائڻ جي ڪوشش ڪرڻ کان پاسو ڪجي جڏهن اهي تباهه ٿي وڃن.
///
/// اهو شايد رليز بلڊس ۾ فرق نه ڪري (جتي هڪ لوپ جنهن جا ضمني اثرات آسانيءَ سان نه معلوم ڪيا وڃن ۽ ختم ڪيا ويا) ، پر اڪثر ڪري ڊيبگ بلڊس لاءِ هڪ وڏي ڪاميابي آهي.
///
/// ياد رکو ته [`drop_in_place`] اڳ ۾ ئي اهو چيڪ انجام ڏئي ٿو ، تنهن ڪري جيڪڏهن توهان جي ڪم ڪار کي [`drop_in_place`] ڪالن جي ڪجهه نن numberي تعداد ۾ گهٽائي سگهجي ، اهو استعمال ڪرڻ غير ضروري آهي.
/// خاص طور تي نوٽ ڪريو ته توھان ڪري سگھوٿا [`drop_in_place`] ھڪڙو سلائس ، ۽ اھو ھڪڙو ڪم ڪندو_ ڊراپ چيڪ ڪندو سڀ قيمتون.
///
/// قسمن وانگر ويڪ وانگر صرف `drop_in_place(&mut self[..])` بغير `needs_drop` واضح طور تي استعمال ڪندي.
/// [`HashMap`] وانگر ٽائيپ ، ٻئي طرف ، قدرن کي هڪ ئي وقت گهٽائڻو پوندو ۽ هن اي پي کي استعمال ڪرڻ گهرجي.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// هتي هڪڙو مثال آهي ته ڪيئن گڏجاڻي ڪيئن `needs_drop` جو استعمال ڪري سگھي ٿي:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ڊيٽا ڇڏ
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// قسم `T` جي قيمت کي واپسي ڏيکاري ٿي سڀ صفر جي بائيٽ نموني طرفان نمائندگي ڪئي وئي آهي.
///
/// هن جو مطلب ، مثال طور ، `(u8, u16)` ۾ پيڊنگ بائيٽ لازمي طور تي صفر ناهي.
///
/// ڪابه گارنٽي نه آهي ته سڀ صفر بائيٽ نمونو `T` جي ڪجهه قسم جي صحيح قدر جي نمائندگي ڪري ٿو.
/// مثال طور ، سڀني صفر بائيٽ جو نمونو حوالن جي قسمن (۽&T` ، `&mut T`) ۽ ڪم پوائنٽرن جي لاءِ صحيح قيمت ناهي.
/// `zeroed` اهڙي قسم تي استعمال ڪرڻ سبب فوري طور تي [undefined behavior][ub] سبب ٿئي ٿو ڇاڪاڻ ته [the Rust compiler assumes][inv] ته اتي هميشه هڪ صحيح قدر آهي تغير ۾ جيڪو اهو ابتدائي سمجهي ٿو.
///
///
/// اهو ساڳيو اثر [`MaybeUninit::zeroed().assume_init()`][zeroed] وانگر آهي.
/// هي ڪڏهن ڪڏهن ايف ايف آءِ لاءِ فائديمند آهي ، پر عام طور تي انهي کي پاسو ڪرڻ گهرجي
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// هن فنڪشن جو صحيح استعمال: صفر سان عدد ابتدا ڪرڻ.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *غلط* هن فنڪشن جو استعمال: ريفرنس کي شروعات ۾ صفر سان.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // اڻ سڌريل رويو!
/// let _y: fn() = unsafe { mem::zeroed() }; // ۽ ٻيهر!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // حفاظت: ڪال ڪرڻ واري کي گارنٽي ڏيڻ گهرجي ته سڀ صفر جي قيمت `T` لاءِ صحيح آهي.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// 0Rust جي عام ياداشت جي شروعاتي چڪاس کي چڪاس ڪندي قسم جي `T` پيدا ڪرڻ جي پيشڪش ذريعي ، جڏهن ته ڪجھ به ناهي.
///
/// **اهو ڪم ختم ٿي ويو آهي.** بدران [`MaybeUninit<T>`] استعمال ڪريو.
///
/// فرسودگي جو سبب اهو آهي ته فنڪشن بنيادي طور تي صحيح طريقي سان استعمال نه ٿي ڪري سگهجي: انهي جو [`MaybeUninit::uninit().assume_init()`][uninit] وانگر ساڳيو اثر آهي.
///
/// جئين [`assume_init` documentation][assume_init] وضاحت ڪري ٿو ، [the Rust compiler assumes][inv] جيڪي قدر مناسب طور تي شروع ڪيا ويا آهن.
/// نتيجي طور ، ڪال مثال طور
/// `mem::uninitialized::<bool>()` هڪ `bool` واپس ڪرڻ جي لاءِ فوري طور تي اڻ behaviorاتل رويي جو سبب بڻجندي آهي جيڪي نه ته يقيني طور تي `true` يا `false` هوندو.
/// بدتر ، حقيقي طور تي غير شروعاتي ياداشت جيئن هتي موٽندي آهي انهي ۾ خاص آهي ته مرتب ڪندڙ knowsاڻي ٿو ته هن وٽ ڪا مقرر ڪيل قيمت نه آهي.
/// انهي مان اڻ سڌريل رويو ٺاهيل هڪ غير متحرڪ ڊيٽا هجڻ جي باوجود ته انهي متحرڪ ۾ هڪ عدد قسم هجي.
/// (ياد ڪريو ته غير ابتدائي انگ جي چوڌاري ضابطن کي اڃا حتمي نه ڪيو ويو آهي ، پر جيستائين اهي آهن ، انهن کان پاسو ڪرڻ جي صلاح ڏني وئي.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // حفاظت: ڪال ڪرڻ واري کي لازمي طور تي گارنٽي ڏيڻ گھرجي هڪ يونٽيوالڊ ويلڊ ايڪس `T` لاءِ صحيح آهي.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// ٻن بدلجندڙ جڳهن تي قدرن کي مٽايو ، بغير ڪنهن جي ترتيب ڏيڻ کانسواءِ.
///
/// * جيڪڏهن توهان ڊفالٽ يا ڊيمڪي قيمت سان تبادلو ڪرڻ چاهيو ٿا ، ايڪس X00 ڏسو.
/// * جيڪڏهن توهان منظور ٿيل قيمت سان تبادلي ڪرڻ چاهيندا ، پراڻي قيمت واپس ڪندي ، [`replace`] ڏسو.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // حفاظت: خام پوائنٽ محفوظ ٺاهيل محفوظ حوالن کان ٺاهيا ويا آهن جيڪي سڀني کي مطمئن ڪن ٿا
    // `ptr::swap_nonoverlapping_one` تي رڪاوٽون
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` کي `T` جي ڊفالٽ قيمت سان تبديل ڪري ٿو ، پوئين `dest` قدر واپس ڪري ٿو.
///
/// * جيڪڏهن توهان ٻن متغيرن جي قدرن کي مٽائڻ چاهيو ٿا ، [`swap`] ڏسو.
/// * جيڪڏهن توهان اصل قيمت جي بدران گذري ويل قيمت سان مٽائڻ چاهيو ٿا ، [`replace`] ڏسو.
///
/// # Examples
///
/// هڪ سادي مثال
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` ھڪڙي فيڪٽ فيلڊ جي ملڪيت وٺڻ جي اجازت ڏئي ٿو ان کي "empty" قدر سان تبديل ڪندي.
/// `take` کان بغير توهان هن مسئلن ۾ هلائي سگهو ٿا:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// ياد رکو ته `T` لازمي طور تي [`Clone`] لاڳو نٿو ڪري ، تنهن ڪري ان کي `self.buf` به ڪلون ۽ ٻيهر ريٽ نه ٿو ڪري سگهجي.
/// پر ايڪسڪسيمڪس X002 جي اصلي قيمت `self` کان ڌار ڪرڻ لاءِ استعمال ڪري سگھجي ٿي ، ان کي واپس ڪرڻ جي اجازت ڏي.
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` حوالي ڪيل `dest` ۾ منتقل ڪري ٿو ، پوئين `dest` قدر واپس ڪري ٿو.
///
/// نه به قيمت وڃائي وئي آهي.
///
/// * جيڪڏهن توهان ٻن متغيرن جي قدرن کي مٽائڻ چاهيو ٿا ، [`swap`] ڏسو.
/// * جيڪڏهن توهان ڊفالٽ قدر سان مٽائڻ چاهيو ٿا ، [`take`] ڏسو.
///
/// # Examples
///
/// هڪ سادي مثال
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` ھڪڙي fieldانچي جي فيلڊ کي گھٽائڻ سان ان کي مٽائڻ جي اجازت ڏئي ٿو.
/// `replace` کان بغير توهان هن مسئلن ۾ هلائي سگهو ٿا:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// نوٽ ڪيو ته `T` لازمي طور تي [`Clone`] لاڳو نٿا ڪن ، تنھنڪري اسين حرڪت کان بچڻ لاءِ `self.buf[i]` به کلون نٿا ڪري سگھون.
/// پر ايڪسڪسيمڪس `self` کان وٺي ان انڊيڪس جي اصلي قيمت کي ڌار ڪرڻ لاءِ استعمال ڪري سگھجي ٿو ، ان کي واپس ڪرڻ جي اجازت ڏي.
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // حفاظت: اسان `dest` کان پڙهون ٿا پر سڌو سنئون `src` ان کان پوءِ ،
    // اهڙي طرح پراڻي قيمت نقل ٿيل ناهي.
    // ڪجھ به ختم نه ٿيو ۽ هتي ڪجھ به panic نٿو ڪري سگھي.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// ويليو کي ختم ڪري ٿو
///
/// اهو دليل کي [`Drop`][drop] جي عمل درآمد سڏيندي.
///
/// اهو مؤثر طريقي سان ايڪس آرڪس کي لاڳو ڪرڻ وارن قسمن لاءِ نٿو ڪري
/// integers.
/// اهڙي قدر نقل ڪئي وئي آهي ۽ _then_ فنڪشن ۾ منتقل ٿي ويو ، تنهنڪري هن فنڪشن ڪال کانپوءِ قدر جاري رهي.
///
///
/// اها فنڪشن جادو ناهي ؛ان جي لفظي طور تي وضاحت ڪئي وئي آهي
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// ڇاڪاڻ ته `_x` هن فنڪشن ۾ منتقل ڪيو ويو آهي ، اهو فنڪشن موٽڻ کان اڳ پاڻهي ڇڏيو ويو آهي.
///
/// [drop]: Drop
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // واضح طور تي vector ڇڏيندا
/// ```
///
/// جيئن کان [`RefCell`] رن ٽائيم تي قرضن جو قاعدو لاڳو ڪري ٿو ، `drop` ھڪڙي [`RefCell`] قرض جاري ڪري سگھي ٿو:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // هن سلاٽ تي قابل تبديلي قرض کڻي وڃ
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`] تي انٽيگرز ۽ ٻيا قسم لاڳو ڪندڙ `drop` کان متاثر نه آهن.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` جي ڪاپي منتقل ڪئي وئي ۽ ڇڏي وئي آهي
/// drop(y); // `y` جي ڪاپي منتقل ڪئي وئي ۽ ڇڏي وئي آهي
///
/// println!("x: {}, y: {}", x, y.0); // اڃا تائين دستياب آهي
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// ايڪسڪسيمڪس کي قسم `&U` وانگر بيان ڪري ٿو ، ۽ انهي کان پوء پڙهڻ واري قيمت کي منتقل ڪرڻ جي بغير `src` پڙهي ٿو.
///
/// اهو فنڪشن غير محفوظ طور تي فرض ڪندو ته پوائنٽر `src` [`size_of::<U>`][size_of] بائٽس لاء `&T` کان `&U` منتقل ڪندي ۽ پوءِ `&U` پڙهي رهيو آهي (سواءِ ان جي ته اهو ڪم اهڙي طريقي سان ڪيو وڃي.
/// اهو پڻ `src` مان ٻاهر نڪرڻ جي بدران موجود قدر جي ڪاپي پيدا ڪندو.
///
/// اهو کمپائل وقت جي غلطي نه آهي جيڪڏهن `T` ۽ `U` مختلف سائزون آهن ، پر اهو انهي کي وڌيڪ ترجيح ڏني وئي آهي صرف هن فنڪشن کي سڏيندي جتي `T` ۽ `U` جو ساڳيو سائز آهي.اهو ڪم [undefined behavior][ub] کي ڇڪيندو آهي جيڪڏهن `U` `T` کان وڏو آهي.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' کان ڊيٽا نقل ڪريو ۽ ان کي 'Foo' وانگر علاج ڪريو
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // نقل ڪيل ڊيٽا ۾ تبديلي آڻيو
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' جي مواد کي تبديل نه ڪرڻ گهرجي ها
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // جيڪڏهن يو کي وڌيڪ هڪ ترتيب ڏيڻ جي ضرورت آهي ، src مناسب طريقي سان نٿي ٺاهي سگهجي.
    if align_of::<U>() > align_of::<T>() {
        // حفاظت: `src` هڪ حوالو آهي ، جيڪا پڙهڻ جي صحيح هجڻ جي ضمانت آهي.
        // سڏيندڙ کي ضمانت ڏيڻ گهرجي ته واقعي منتقلي محفوظ آهي.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // حفاظت: `src` هڪ حوالو آهي ، جيڪا پڙهڻ جي صحيح هجڻ جي ضمانت آهي.
        // اسان صرف اهو جانچيو ته `src as *const U` صحيح طرح سان ترتيب ڏنل هو.
        // سڏيندڙ کي ضمانت ڏيڻ گهرجي ته واقعي منتقلي محفوظ آهي.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// بدمعاشي قسم هڪ اينيم جي تعصب جي نمائندگي ڪري ٿو.
///
/// وڌيڪ informationاڻ لاءِ هن ماڊل ۾ [`discriminant`] فنڪشن ڏسو.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. اهي trait لاڳو نه ٿي سگھجن ڇاڪاڻ ته اسان نٿا چاهيون ته ٽي.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` ۾ منفرد طور تي اينيم ويريٽ جي نشاندهي ڪرڻ واري قيمت کي واپس آڻيندي.
///
/// جيڪڏهن `T` هڪ اينيمم ناهي ، هن فنڪشن کي سڏڻ ۾ اڻ سڌريل رويو پيدا نه ٿيندو ، پر واپسي جي قيمت اڻ ecاڻيل آهي.
///
///
/// # Stability
///
/// جيڪڏهن اينم جي تعريف تبديل ٿي وڃي ته اينم ويئر جو تعصب تبديل ٿي سگهي ٿو.
/// ساڳي ئي مرتب ڪرڻ واري گڏجاڻين جي وچ ۾ ڪجهه ويدن جو فرق نه بدليو.
///
/// # Examples
///
/// اهو ڊيٽا جو مقابلو ڪرڻ لاءِ استعمال ڪري سگهجي ٿو جيڪو ڊيٽا کڻي وڃي ، اصل ڊيٽا کي نظرانداز ڪرڻ دوران:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// اينيم قسم `T` ۾ مختلف قسمن جو تعداد موٽائي ٿو.
///
/// جيڪڏهن `T` هڪ اينيمم ناهي ، هن فنڪشن کي سڏڻ ۾ اڻ سڌريل رويو پيدا نه ٿيندو ، پر واپسي جي قيمت اڻ ecاڻيل آهي.
/// ساڳئي طور ، جيڪڏهن `T` هڪ وڌيڪ مختلف قسمن سان هڪ اينيمڪس آهي `usize::MAX` کان واپسي جي قيمت غير واضع آهي.
/// غير آبادگار وارين ڳڻپ ڪئي ويندي.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}