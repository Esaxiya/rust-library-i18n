use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` جي غير شروعاتي صورتن کي اڏائڻ لاءِ ريپر قسم.
///
/// # شروعات وارو مدعي
///
/// ترتيب ڏيڻ وارو ، عام طور تي ، فرض ڪري ٿو ته هڪ متغير صحيح طرح سان ڪيبل ٿيل قسم جي گهرجن جي مطابق ترتيب ڏنل آهي.مثال طور ، ريفرنس قسم جو هڪ متغير لازمي هجڻ گهرجي ۽ غير NULL.
/// اها هڪ طمع هوندي آهي جنهن کي *هميشه* برقرار رکڻ گهرجي ، اڃا به غير محفوظ ڪوڊ ۾.
/// نتيجي طور ، ريفرنس جي قسم جي هڪ متغير جي شروعات صفر [undefined behavior][ub] سبب ڪري ٿي ، ڪوبه مسئلو ناهي ته اهو حوالو ڪڏهن به ياداشت تائين رسائي حاصل ڪري ٿو.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // اڻ سڌريل رويو!⚠️
/// // `MaybeUninit<&i32>` سان گڏ ساڳيو ڪوڊ:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // اڻ سڌريل رويو!⚠️
/// ```
///
/// اهو استحصال ڪندڙ مختلف استحصال ڪندڙن طرفان استحصال ڪيو ويو آهي ، جيئن هلندڙ وقت جي چڪاس ۽ `enum` ترتيب ڏيڻ کي بهتر ڪرڻ.
///
/// ساڳئي طرح ، مڪمل طور تي غير شروع ٿيل ياداشت ۾ شايد ڪو مواد هجي ، جڏهن ته هڪ `bool` هميشه هميشه `true` يا `false` هجڻ گهرجي.ان ڪري ، ھڪڙي غير تيار ٿيل `bool` ٺاھڻ واري غير معياري طريقي سان آھي:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // اڻ سڌريل رويو!⚠️
/// // `MaybeUninit<bool>` سان گڏ ساڳيو ڪوڊ:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // اڻ سڌريل رويو!⚠️
/// ```
///
/// ان کان سواء ، غير شروعاتي ياداشت خاص هوندي آهي انهي ۾ طئي ٿيل قيمت ناهي ("fixed" مطلب "it won't change without being written to").هڪ ئي اڻ پڙهيل بائيٽ کي ڪيترن ئي دفعا پڙهڻ مختلف نتيجا ڏئي سگهي ٿو.
/// اهو انهي اڻ behaviorاڻيل رويي کي بنا ڪنهن اڻ سڌريل ڊيٽا جي ڪنٽرڪ ۾ رکڻ جي باوجود جيڪڏهن هن ويريٽ ۾ هڪ انٽيگر قسم هجي ، جيڪا ٻي صورت ۾ ڪنهن به *مقرر* بٽ نموني کي جهڪي سگهي ٿي:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // اڻ سڌريل رويو!⚠️
/// // `MaybeUninit<i32>` سان گڏ ساڳيو ڪوڊ:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // اڻ سڌريل رويو!⚠️
/// ```
/// (ياد ڪريو ته غير ابتدائي انگ جي چوڌاري ضابطن کي اڃا حتمي نه ڪيو ويو آهي ، پر جيستائين اهي آهن ، انهن کان پاسو ڪرڻ جي صلاح ڏني وئي.)
///
/// انهي جي چوٽي تي ، ياد رکجو اڪثر قسم تي اضافي ويڙهاڪ آهن صرف قسم جي سطح تي ابتدائي سمجهي رهيا آهن.
/// مثال طور ، هڪ `1` ٻڌل ايڪس ايڪس ايڪس کي شروعاتي تصور ڪيو وڃي ٿو (موجوده عملدرآمد جي هيٺان ؛ اهو هڪ مستحڪم گارنٽي نه ٺهي ٿو) ڇاڪاڻ ته اها ئي ضرورت آهي ته مرتبڪار ان بابت knowsاڻي ٿو ته ڊيٽا پوائنٽر کي `هَول` نه هجڻ گهرجي.
/// اهڙي `Vec<T>` ٺاهڻ *فوري* اڻ behaviorاڻ وارو رويو نه ٿو ٺاهي ، پر اڪثر محفوظ آپريشن سان (اڻ includingاڻ سميت ان سميت) جي لاتعداد رويي جو سبب بڻجندي.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` غير ابتدائي ڊيٽا سان معاملو ڪرڻ لاءِ غير محفوظ ڪوڊ کي فعال ڪرڻ جو ڪم ڏئي ٿو.
/// اھو ٺاھيندڙ کي اشارو ڪيو ويو آھي ، اھو ظاھر ڪري ٿو ته ھتي ڊيٽا *شروع* نه ٿي سگھي:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // ظاهري طور تي اڻ تيار ٿيل حوالو ٺاهيو.
/// // مرتب ڪندڙ knowsاڻي ٿو ته `MaybeUninit<T>` اندر ڊيٽا غلط ٿي سگهي ٿو ، ۽ تنهن ڪري هي يو بي نه آهي:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // ان کي صحيح قدر مقرر ڪيو.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // شروعاتي ڊيٽا ڪو-اھو صرف اجازت ڏنل آھي *بعد ۾*`x` کي صحيح طرح شروع ڪرڻ کان!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// مرتب ڪندڙ وري knowsاڻي ٿو ته هن ڪوڊ تي ڪو به غلط مفروضا يا اصلاح نه ڪئي وڃي.
///
/// توهان سوچي سگهو ٿا ايڪسڪسيمڪس وانگر هڪجهڙائي آهي `Option<T>` وانگر پر بغير ڪنهن وقت جي ٽريڪنگ ۽ بغير ڪنهن حفاظت جي چڪاس کان.
///
/// ## out-pointers
///
/// توهان `MaybeUninit<T>` لاڳو ڪرڻ لاءِ استعمال ڪري سگھو ٿا "out-pointers": هڪ فنڪشن مان ڊيٽا موٽڻ بدران ، ان کي نتيجي ۾ وجهڻ لاءِ ان کي پوائنٽ x02X ميمري ڏانهن موڪليو.
/// اهو ڪارائتو ٿي سگھي ٿو جڏهن ڪال ڪرڻ لاءِ اهو اهم آهي ته ڪئين ريموٽ ڪيو ويو ڪئين ياداشت جو نتيجو محفوظ ٿيل آهي ، ۽ توهان غير ضروري حرڪت کان پاسو ڪرڻ چاهيو ٿا.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` پراڻي مواد کي نه ڇڏيندو آهي ، جيڪو اهم آهي.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // هاڻي اسان knowاڻون ٿا `v` شروعاتي آهي!اهو پڻ انهي ڳالهه کي يقيني بڻائي ٿو ته vector صحيح طريقي سان ختم ٿي وڃي ٿو.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## ابتدائي-ذريعي-عنصر ذريعي صف ترتيب ڏيڻ
///
/// `MaybeUninit<T>` استعمال ڪري سگھجي ٿو ھڪڙي وڏي صف کي عنصر ڏيڻ واري عنصر کان عنصر طور:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` جو غير شروعاتي صف ٺاهيو.
///     // `assume_init` محفوظ آھي ڇاڪاڻ ته اسان جنھن قسم جو اسان دعوي ڪرڻ شروع ڪري رھيا آھيون ، اھو آھي `ٿي يونٽينائيٽس` جو ، جيڪو شروعات ڪرڻ جي ضرورت نه آھي.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // ايڪس 000 کي ڇڏڻ جو ڪجهه ناهي.
///     // اھڙي طرح `ptr::write` بدران خام پوائنٽر جي تفويض استعمال ڪرڻ سان پراڻي غير قيمتي قدر ختم ٿيڻ جو سبب نٿي پوي.
/////
///     // انهي کان علاوه جيڪڏهن هن لوپ دوران panic آهي ، اسان وٽ هڪ ياداشت ليک آهي ، پر يادگيري جي حفاظت جو مسئلو ناهي.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // هر شيءِ شروعاتي آهي.
///     // ابتدائي قسم ڏانهن صف کي منتقل ڪريو.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// جزوي طور تي ابتدائي ڀٽائي سان به ڪم ڪري سگھون ٿا ، جيڪي گهٽ درجه بندي جي درميان حاصل ڪري سگهجن ٿيون.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` جو غير شروعاتي صف ٺاهيو.
/// // `assume_init` محفوظ آھي ڇاڪاڻ ته اسان جنھن قسم جو اسان دعوي ڪرڻ شروع ڪري رھيا آھيون ، اھو آھي `ٿي يونٽينائيٽس` جو ، جيڪو شروعات ڪرڻ جي ضرورت نه آھي.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // عناصر جو تعداد اسان مقرر ڪيو آھي ڳڻپ ڪريو.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // صف ۾ هر شئي لاءِ ، گرايو جيڪڏهن اسان ان کي مختص ڪيو.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## ھڪڙي فيلڊ فيلڊ في فيلڊ شروعات ڪندي
///
/// توھان فيلڊ پاران فريم ورڪ کي شروع ڪرڻ لاءِ ، `MaybeUninit<T>` ۽ [`std::ptr::addr_of_mut`] ميڪرو استعمال ڪري سگھوٿا.
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` فيلڊ کي شروعات ڪندي
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` فيلڊ کي شروعاتي بڻائڻ جيڪڏھن ھتي panic آھي ، ته پوءِ `String` `name` فيلڊ لڪايو ٿو.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // سڀني شعبن جي شروعاتي بڻيل آهي ، انهي ڪري اسان شروعاتي فو کي حاصل ڪرڻ لاءِ ايڪس آرڪس کي سڏ ڪريون ٿا.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ضمانت ڪئي وئي آهي ته ساڳئي سائيز ، ترتيب ، ۽ اي بي آئي کي `T` وانگر آهي.
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// پر ياد رک ته هڪ قسم *جنهن ۾*`MaybeUninit<T>` ضروري ناهي ساڳئي ترتيب ؛Rust عام طور تي گارنٽي نٿو ڏئي ته `Foo<T>` جي فيلڊس وٽ `Foo<U>` وانگر ساڳيو حڪم آهي جيتوڻيڪ `T` ۽ `U` جي ساڳي سائيز ۽ هڪجهڙائي آهي.
///
/// وڌيڪ ڇاڪاڻ ته `MaybeUninit<T>` لاء ڪا به صحيح قيمت صحيح آهي ، مرتب ڪندڙ non-zero/niche-filling اصلاحات لاڳو نٿا ڪري سگهن ، ممڪن طور تي وڏي سائيز جو نتيجو آهي.
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// جيڪڏهن `T` ايف ايف آئي محفوظ آهي ، ته ائين ئي `MaybeUninit<T>` آهي.
///
/// جڏهن ته `MaybeUninit` `#[repr(transparent)]` آهي (اهو ظاهر ڪري ٿو ته اهو ساڳي سائيز ، ترتيب ، ۽ اي بي آئي کي `T` جي طور تي گارنٽي ڪري ٿو) ، هي *پوئين وارتا مان ڪا به تبديلي نٿو* ڪري.
/// `Option<T>` ۽ شايد `Option<MaybeUninit<T>>` اڃا مختلف سائز رکي ٿو ، ۽ قسم جي `T` قسم جي فيلڊ تي مشتمل هوندا شايد مختلف هوندا هئا (۽ سائيز) الڳ الڳ جيڪڏهن اهو ميدان `MaybeUninit<T>` هو.
/// `MaybeUninit` هڪ يونين قسم آهي ، ۽ يونينڪس تي `#[repr(transparent)]` غير مستحڪم آهي ([the tracking issue](https://github.com/rust-lang/rust/issues/60405)) ڏسو.
/// وقت سان ، يونينز تي `#[repr(transparent)]` جي صحيح ضمانتون اڀياس ٿي سگهن ٿيون ، ۽ `MaybeUninit` شايد `#[repr(transparent)]` نه رهن.
/// اھو چيو ، `MaybeUninit<T>` آھي *هميشه* گارنٽي ڪندو ، اھو ھڪڙي سائيز ، مطابق ، ۽ اي بي آئي `T` وانگر ؛اهو صرف اهو آهي ته رستو `MaybeUninit` لاڳو ڪري ٿو جيڪا ضمانت ختم ٿي سگهي ٿي.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// لانگ شيٽ ان ڪري اسان ان ۾ ٻين قسمن جو وڳوڙ ڪري سگھون ٿا.اھو جنريٽر لاءِ مفيد آھي.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` کي نه سڏي ، اسان cannotاڻ نه ٿا سگھون ته اسان انهي جي لاءِ شروعاتي طور تي ڪافي آھيون.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// ڏنل قدر سان شروع ٿيل هڪ نئون `MaybeUninit<T>` ٺاهي ٿو.
    /// انهي فنڪشن جي واپسي جي قيمت تي [`assume_init`] ڪال ڪرڻ محفوظ آهي.
    ///
    /// ياد رکجو ته `MaybeUninit<T>` ڇڏڻ ڪو به ناهي `T` جو ڊراپ ڪوڊ.
    /// اها توهان جي ذميواري آهي ته توهان شروع ڪيو جيڪڏهن `T` droppedوٽو ڇڏي وڃي.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// هڪ نئون `MaybeUninit<T>` هڪ غير شروعاتي حالت ۾ ٺاهي ٿو.
    ///
    /// ياد رکجو ته `MaybeUninit<T>` ڇڏڻ ڪو به ناهي `T` جو ڊراپ ڪوڊ.
    /// اها توهان جي ذميواري آهي ته توهان شروع ڪيو جيڪڏهن `T` droppedوٽو ڇڏي وڃي.
    ///
    /// ڪجھ مثالن لاءِ [type-level documentation][MaybeUninit] ڏسو.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// `MaybeUninit<T>` شيون جي نئين صف ٺاهيو ، هڪ ابتدائي حالت ۾.
    ///
    /// Note: future Rust ورزن ۾ اهو طريقو غير ضروري ٿي سگھي ٿو جڏهن صف آر لفظي نحو جي اجازت [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// هيٺ ڏنل مثال `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` استعمال ڪري سگھي ٿو.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// ڊيٽا جو هڪ (شايد نن possiblyا نن)ا) واپسي ڏئي ٿو جيڪو اصل ۾ پڙهيو هو
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // حفاظت: هڪ غير شروعاتي `[MaybeUninit<_>; LEN]` صحيح آهي.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// هڪ نئون `MaybeUninit<T>` هڪ ناقابل شروعاتي حالت ۾ پيدا ڪري ٿو ، ياداشت سان گڏ `0` بائٽس سان ڀريل.اهو `T` تي منحصر هوندو آهي ڇا اهو اڳ ۾ ئي صحيح شروعات جي لاءِ انجام ڏئي ٿو.
    ///
    /// مثال طور ، `MaybeUninit<usize>::zeroed()` شروعات ڪئي وئي آهي ، پر `MaybeUninit<&'static i32>::zeroed()` نه آهي ڇاڪاڻ ته حوالو خالي هجڻ لازمي ناهي.
    ///
    /// ياد رکجو ته `MaybeUninit<T>` ڇڏڻ ڪو به ناهي `T` جو ڊراپ ڪوڊ.
    /// اها توهان جي ذميواري آهي ته توهان شروع ڪيو جيڪڏهن `T` droppedوٽو ڇڏي وڃي.
    ///
    /// # Example
    ///
    /// ھن فنڪشن جو صحيح استعمال: ھڪڙي ساخت کي شروعات صفر سان گڏ ، جتي ساخت جا سڀئي شعبا بائيٽ نمونہ 0 کي صحيح قدر طور برقرار رکي سگھن ٿا.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *غلط* هن فنڪشن جو استعمال: `x.zeroed().assume_init()` کي ڪال ڪندي جڏهن `0` هن قسم لاءِ صحيح بٽ نمونو ناهي.
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // ھڪڙي جوڙي جي اندر ، اسان ھڪڙو `NotZero` ٺاھيو ٿا جيڪو ھڪڙو صحيح فرق ڪندڙ ناھي.
    /// // اهو اڻ سڌريل رويو آهي.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // حفاظت: ايڪس ڪيو ايم کي مختص ڪيل ياداشت ڏانهن اشارو ڪيو ويو آهي.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` جي قيمت کي ترتيب ڏيو.
    /// اهو ختم ڪرڻ جي ڪنهن به اڳوڻي قيمت کي ختم ڪري ڇڏي ٿو ، تنهن ڪري محتاط رهو جڏهن ته هن تباهي کي هلائڻ نه ڇڏي ڏيو.
    ///
    /// توهان جي سهولت لاءِ ، انهي ۾ `self` جي (هاڻ محفوظ طور تي شروعات ٿيل) مواد جو هڪ قابل تبديلي حوالو پڻ اچي ٿو.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // حفاظت: اسان صرف هن قيمت جي شروعات ڪئي.
        unsafe { self.assume_init_mut() }
    }

    /// شامل ٿيل قيمت کي پوائنٽر حاصل ڪندو آهي
    /// هن پوائنٽر تان پڙهي يا ان کي ريفرنس ۾ تبديل ڪرڻ ڪو تعين ٿيل رويو آهي جيستائين `MaybeUninit<T>` شروعات ناهي.
    /// ميموري ڏانهن لکجي ٿو ته هي پوائنٽر (non-transitively) ڏانهن اشارو ڪيو ويو آهي اڻ سڌريل رويو (سواء `UnsafeCell<T>` اندر).
    ///
    /// # Examples
    ///
    /// ھن طريقي جو صحيح استعمال:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` ۾ هڪ حوالو ٺاهيو.اهو ٺيڪ آهي ڇاڪاڻ ته اسان هن کي شروعات ڪيو.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *غلط* هن طريقي جو استعمال:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // اسان هڪ اڻ مڪمل طور تي vector جو هڪ حوالو ٺاهيو آهي.اهو اڻ سڌريل رويو آهي.⚠️
    /// ```
    ///
    /// (ياد ڪريو ته غير ابتدائي ڊيٽا جي حوالي سان ايندڙ قاعدن کي اڃا تائين حتمي شڪل ڪونه ڏني وئي آهي ، پر جيستائين اهي نه آهن ، انهن کان بچڻ جي صلاح ڏني وئي.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ۽ `ManuallyDrop` ٻئي `repr(transparent)` آھن تنھنڪري اسان پوائنٽر اڇلائي سگھون ٿا.
        self as *const _ as *const T
    }

    /// قابل قدر پوائنٽر شامل ٿيل قيمت کي حاصل ڪري ٿو.
    /// هن پوائنٽر تان پڙهي يا ان کي ريفرنس ۾ تبديل ڪرڻ ڪو تعين ٿيل رويو آهي جيستائين `MaybeUninit<T>` شروعات ناهي.
    ///
    /// # Examples
    ///
    /// ھن طريقي جو صحيح استعمال:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` ۾ هڪ حوالو ٺاهيو.
    /// // اهو ٺيڪ آهي ڇاڪاڻ ته اسان هن کي شروعات ڪيو.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *غلط* هن طريقي جو استعمال:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // اسان هڪ اڻ مڪمل طور تي vector جو هڪ حوالو ٺاهيو آهي.اهو اڻ سڌريل رويو آهي.⚠️
    /// ```
    ///
    /// (ياد ڪريو ته غير ابتدائي ڊيٽا جي حوالي سان ايندڙ قاعدن کي اڃا تائين حتمي شڪل ڪونه ڏني وئي آهي ، پر جيستائين اهي نه آهن ، انهن کان بچڻ جي صلاح ڏني وئي.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ۽ `ManuallyDrop` ٻئي `repr(transparent)` آھن تنھنڪري اسان پوائنٽر اڇلائي سگھون ٿا.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` ڪنٽينر مان قدر ڪي ٿو.اهو هڪ بهترين طريقو آهي انهي کي يقيني بڻائڻ ته ڊيٽا ڀ droppedي ويندي ، ڇاڪاڻ ته نتيجو ڪندڙ `T` معمولي ڊراپ هٿ ڪرڻ سان مشروط آهي.
    ///
    /// # Safety
    ///
    /// اهو ڪال ڪرڻ واري تي منحصر آهي انهي جي ضمانت ڏي ته `MaybeUninit<T>` واقعي هڪ ابتدائي حالت ۾ آهي.انهي کي ڪال ڪندي جڏهن مواد اڃا مڪمل طور تي ابتدائي نه ڪيو وڃي فوري طور تي اڻ سڌريل رويو ٺاهيندي.
    /// [type-level documentation][inv] ھن ابتدائي متحرڪ جي باري ۾ وڌيڪ معلومات تي مشتمل آھي.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// انهي جي چوٽي تي ، ياد رکجو اڪثر قسم تي اضافي ويڙهاڪ آهن صرف قسم جي سطح تي ابتدائي سمجهي رهيا آهن.
    /// مثال طور ، هڪ `1` ٻڌل ايڪس ايڪس ايڪس کي شروعاتي تصور ڪيو وڃي ٿو (موجوده عملدرآمد جي هيٺان ؛ اهو هڪ مستحڪم گارنٽي نه ٺهي ٿو) ڇاڪاڻ ته اها ئي ضرورت آهي ته مرتبڪار ان بابت knowsاڻي ٿو ته ڊيٽا پوائنٽر کي `هَول` نه هجڻ گهرجي.
    ///
    /// اهڙي `Vec<T>` ٺاهڻ *فوري* اڻ behaviorاڻ وارو رويو نه ٿو ٺاهي ، پر اڪثر محفوظ آپريشن سان (اڻ includingاڻ سميت ان سميت) جي لاتعداد رويي جو سبب بڻجندي.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// ھن طريقي جو صحيح استعمال:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *غلط* هن طريقي جو استعمال:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` اڃا شروعات نه ڪئي وئي ھئي ، تنھنڪري ھن آخري لڪير ۾ غير متعين سلوڪ جو سبب بڻيا.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // حفاظت: سڏيندڙ کي گارنٽي ڏيڻ گھرجي `self` شروعاتي آھي.
        // ان جو مطلب اهو پڻ آهي ته `self` هڪ `value` ويئرٽ هجڻ گهرجي.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` ڪنٽينر کان قدر پڙهي ٿو.نتيجو `T` معمولي ڊراپ ھٿنگ سان مشروط آھي.
    ///
    /// جڏهن به ممڪن ٿئي ، [`assume_init`] جي بدران استعمال ڪرڻ ترجيح آهي ، جيڪا `MaybeUninit<T>` جي مواد کي نقل ڏيڻ کان روڪي ٿي.
    ///
    /// # Safety
    ///
    /// اهو ڪال ڪرڻ واري تي منحصر آهي انهي جي ضمانت ڏي ته `MaybeUninit<T>` واقعي هڪ ابتدائي حالت ۾ آهي.اهو مواد ڪال ڪرڻ ڪندي جڏهن مواد اڃا مڪمل طور تي طئي ناهي ڪيو ويو اڻ سڌريل رويو سبب.
    /// [type-level documentation][inv] ھن ابتدائي متحرڪ جي باري ۾ وڌيڪ معلومات تي مشتمل آھي.
    ///
    /// ان کان علاوه ، هي `MaybeUninit<T>` ۾ ساڳئي ڊيٽا جي ڪاپي پويان ڇڏيندو آهي.
    /// جڏهن ڊيٽا جون گهڻيون ڪاپيون استعمال ڪندي (`assume_init_read` کي ڪيترائي ڀيرا ڪال ڪندي ، يا پهرين ڪال ڪندي `assume_init_read` ۽ پوءِ [`assume_init`]) ، اهو توهان جي ذميواري آهي ته يقيني بڻايون ته ڊيٽا درحقيقت نقل ٿيل هوندا.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ھن طريقي جو صحيح استعمال:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` ايڪس `Copy` آهي ، تنهنڪري اسان ڪيترائي ڀيرا پڙهي سگهون ٿا.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` ويليو کي نقل ڪرڻ ٺيڪ آهي ، تنهن ڪري اسين ڪيترائي ڀيرا پڙهي سگهون ٿا.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *غلط* هن طريقي جو استعمال:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // اسان هاڻي هڪ ئي vector جون ٻه ڪاپيون ٺاهي ، ٻل فري ⚠️ ڏانهن روانو ٿيو جڏهن اهي ٻئي لهي ويا!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // حفاظت: سڏيندڙ کي گارنٽي ڏيڻ گھرجي `self` شروعاتي آھي.
        // `self.as_ptr()` کان پڙهائي محفوظ آهي جئين `self` جي شروعات ڪئي وڃي.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// هنڌ تي مشتمل ويليو ڇڪي ٿو.
    ///
    /// جيڪڏهن توهان وٽ `MaybeUninit` جي ملڪيت آهي ، توهان بدران [`assume_init`] استعمال ڪري سگهو ٿا.
    ///
    /// # Safety
    ///
    /// اهو ڪال ڪرڻ واري تي منحصر آهي انهي جي ضمانت ڏي ته `MaybeUninit<T>` واقعي هڪ ابتدائي حالت ۾ آهي.اهو مواد ڪال ڪرڻ ڪندي جڏهن مواد اڃا مڪمل طور تي طئي ناهي ڪيو ويو اڻ سڌريل رويو سبب.
    ///
    /// انهي جي چوٽي تي ، `T` قسم جي سڀني اضافي ويڙهاڪن کي مطمئن ڪرڻو پوندو ، جئين `T` (يا ان جا ميمبر) جي `Drop` عمل درآمد شايد هن تي ڀروسو ڪن.
    /// مثال طور ، هڪ `1` ٻڌل ايڪس ايڪس ايڪس کي شروعاتي تصور ڪيو وڃي ٿو (موجوده عملدرآمد جي هيٺان ؛ اهو هڪ مستحڪم گارنٽي نه ٺهي ٿو) ڇاڪاڻ ته اها ئي ضرورت آهي ته مرتبڪار ان بابت knowsاڻي ٿو ته ڊيٽا پوائنٽر کي `هَول` نه هجڻ گهرجي.
    ///
    /// اهڙي `Vec<T>` کي ڇڏڻ جيتوڻيڪ اڻ undاتل رويي جو سبب بڻجندي.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // حفاظت: سڏيندڙ کي گارنٽي ڏيڻ لازمي آهي `self` شروعاتي آھي ۽
        // سڀني کي `T` جي تسلي بخش آهي.
        // قيمت ۾ جاءِ ڇڏائڻ ته محفوظ آهي جيڪڏهن اها ڳالهه آهي.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// شامل ٿيل قدر جي حصيداري ٿي وڃي ٿي.
    ///
    /// اهو ڪارائتو ٿي سگهي ٿو جڏهن اسان هڪ `MaybeUninit` تائين رسائي حاصل ڪرڻ چاهيندا آهيون جيڪا شروعات ڪئي وئي آهي پر `MaybeUninit` جي ملڪيت نه آهي (`.assume_init()`) جي استعمال کي روڪڻ).
    ///
    /// # Safety
    ///
    /// انهي کي ڪال ڪندي جڏهن مواد اڃا مڪمل طور تي طئي ناهي ڪيو ويو اڻ سڌريل رويو سبب: اها ڪال ڪرڻ واري تي منحصر آهي انهي جي ضمانت ڏي ته `MaybeUninit<T>` واقعي هڪ ابتدائي حالت ۾ آهي.
    ///
    ///
    /// # Examples
    ///
    /// ### ھن طريقي جو صحيح استعمال:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` شروع ڪريو:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // ھاڻي ھاڻي اسان جو `MaybeUninit<_>` شروعاتي طور سڃاتو وڃي ٿو ، اھو ٺيڪ آھي ان لاءِ گڏيل حصيداري ڪرڻ جو:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // حفاظت: `x` تہ شروعات ڪئي وئي آھي.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *غلط* هن طريقن جا استعمال:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // اسان هڪ اڻ مڪمل طور تي vector جو هڪ حوالو ٺاهيو آهي.اهو اڻ سڌريل رويو آهي.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` استعمال ڪندي `MaybeUninit` شروع ڪريو:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // هڪ شروع ٿيل `Cell<bool>` جو حوالو: يو بي!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // حفاظت: سڏيندڙ کي گارنٽي ڏيڻ گھرجي `self` شروعاتي آھي.
        // ان جو مطلب اهو پڻ آهي ته `self` هڪ `value` ويئرٽ هجڻ گهرجي.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// قابل قدر (unique) حوالو ڏنل قيمت جي حوالي ڪري ٿو.
    ///
    /// اهو ڪارائتو ٿي سگهي ٿو جڏهن اسان هڪ `MaybeUninit` تائين رسائي حاصل ڪرڻ چاهيندا آهيون جيڪا شروعات ڪئي وئي آهي پر `MaybeUninit` جي ملڪيت نه آهي (`.assume_init()`) جي استعمال کي روڪڻ).
    ///
    /// # Safety
    ///
    /// انهي کي ڪال ڪندي جڏهن مواد اڃا مڪمل طور تي طئي ناهي ڪيو ويو اڻ سڌريل رويو سبب: اها ڪال ڪرڻ واري تي منحصر آهي انهي جي ضمانت ڏي ته `MaybeUninit<T>` واقعي هڪ ابتدائي حالت ۾ آهي.
    /// مثال طور ، `MaybeUninit` کي `MaybeUninit` شروع ڪرڻ لاءِ استعمال نٿو ڪري سگهجي.
    ///
    /// # Examples
    ///
    /// ### ھن طريقي جو صحيح استعمال:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// ان پٹ بفر جي تمام * بائٽس کي شروع ڪري ٿو
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` شروع ڪريو:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // ھاڻي اسان knowاڻون ٿا ته `buf` جي شروعات ڪئي وئي آھي ، تنھنڪري اسان ان کي `.assume_init()` ڪري سگھياسين.
    /// // جيتوڻيڪ ، `.assume_init()` استعمال ڪندي 2048 بائيٽ جي `memcpy` متحرڪ ڪري سگهي ٿي.
    /// // انهي کي پڪ ڪرڻ لاءِ اسان جي بفر کي بغير نقل ڪرڻ جي شروعات ڪئي وئي آهي ، اسان `&mut MaybeUninit<[u8; 2048]>` کي `&mut [u8; 2048]` ۾ اپڊيٽ ڪيو ٿا:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // حفاظت: `buf` تہ شروعات ڪئي وئي آھي.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // هاڻي اسان ايڪس آرڪس کي عام سلائس وانگر استعمال ڪري سگھون ٿا.
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *غلط* هن طريقن جا استعمال:
    ///
    /// توھان ھڪڙو قدر شروع ڪرڻ لاءِ `.assume_init_mut()` استعمال نٿا ڪري سگھو:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // اسان ھڪڙي ٺاھيو آھي (mutable) ھڪڙي XML ھڪڙي حوالن ٺاھيو!
    ///     // اهو اڻ سڌريل رويو آهي.⚠️
    /// }
    /// ```
    ///
    /// مثال طور ، توهان [`Read`] هڪ غير شروعاتي بفر ۾ نٿا ڪري سگهو:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) غير تيار ٿيل يادگيري جو حوالو!
    ///                             // اهو اڻ سڌريل رويو آهي.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// ۽ نه توهان فيلڊ ذريعي فيلڊ ڊگري شروعات ڪرڻ لاءِ سڌي فيلڊ رسائي استعمال ڪري سگهو ٿا.
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) غير تيار ٿيل يادگيري جو حوالو!
    ///                  // اهو اڻ سڌريل رويو آهي.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) غير تيار ٿيل يادگيري جو حوالو!
    ///                  // اهو اڻ سڌريل رويو آهي.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): في الحال اسان مٿي beingاڻايل غلط هجڻ تي ڀروسو ڪيو آهي ، يعني اسان وٽ غير شروع ٿيل ڊيٽا جا حوالا آهن (مثال طور ، `libcore/fmt/float.rs` ۾).
    // اسان کي استحڪام کان اڳ قاعدن بابت حتمي فيصلو ڪرڻ گهرجي.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // حفاظت: سڏيندڙ کي گارنٽي ڏيڻ گھرجي `self` شروعاتي آھي.
        // ان جو مطلب اهو پڻ آهي ته `self` هڪ `value` ويئرٽ هجڻ گهرجي.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` ڪنٽينرز جي صف کان قدر ڪي ٿو.
    ///
    /// # Safety
    ///
    /// اهو ڪال ڪرڻ تي منحصر آهي انهي جي ضمانت ڏي ته صف جا سڀئي عنصر ابتدائي حالت ۾ آهن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // حفاظت: هاڻ محفوظ آهي جئين اسان شروعات ۾ سڀني عنصرن کي
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * ڪالر انهي جي ضمانت ڏي ٿو ته صف جا سڀئي عنصر ابتدائي آهن
        // * `MaybeUninit<T>` ۽ ٽي ضمانت ڏني وئي آهي ته هڪ ئي ترتيب سان
        // * ٿي سگهي ٿو يونٽ نه ڇڏيندو آهي ، تنهنڪري ٻه گهراڻا نه هوندا آهن ۽ اهڙي طرح اها تبديلي محفوظ هوندي آهي
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// فرض ڪريو سڀني عنصرن کي شروعات ڪئي وئي ، انھن کي ھڪ سلائس حاصل ڪريو.
    ///
    /// # Safety
    ///
    /// اهو ڪال ڪرڻ واري تي منحصر آهي انهي جي ضمانت ڏي ته `MaybeUninit<T>` عناصر واقعي ابتدائي حالت ۾ آهن.
    ///
    /// اهو مواد ڪال ڪرڻ ڪندي جڏهن مواد اڃا مڪمل طور تي طئي ناهي ڪيو ويو اڻ سڌريل رويو سبب.
    ///
    /// وڌيڪ تفصيل ۽ مثالن لاءِ [`assume_init_ref`] ڏسو.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // حفاظت: هڪ `*const [T]` ڏانهن سلائس کي محفوظ ڪرڻ کان محفوظ آهي ڇاڪاڻ ته سڏيندڙ ان جي ضمانت ڏئي ٿو
        // `slice` شروعات ڪئي وئي آهي ، ۽`MaybeUninit` هڪ ئي ترتيب ڏنل آهي `T` وانگر ساڳئي ترتيب.
        // حاصل ڪيل پوائنٽر صحيح آھي ڇاڪاڻ ته اھو `slice` جي ملڪيت واري يادگيري کي ظاھر ڪري ٿو جيڪو ھڪڙو حوالو آھي ۽ اھڙي طرح پڙھڻ جي صحيح جي ضمانت آھي.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// فرض ڪيو سڀني عنصرن کي شروعات ڪئي وئي ، انهن کي هڪ قابل متبادل getانچو حاصل ڪريو.
    ///
    /// # Safety
    ///
    /// اهو ڪال ڪرڻ واري تي منحصر آهي انهي جي ضمانت ڏي ته `MaybeUninit<T>` عناصر واقعي ابتدائي حالت ۾ آهن.
    ///
    /// اهو مواد ڪال ڪرڻ ڪندي جڏهن مواد اڃا مڪمل طور تي طئي ناهي ڪيو ويو اڻ سڌريل رويو سبب.
    ///
    /// وڌيڪ تفصيل ۽ مثالن لاءِ [`assume_init_mut`] ڏسو.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // حفاظتي: حفاظتي نوٽس وانگر `slice_get_ref` وانگر ، پر اسان وٽ آهي
        // قابل تغير حوالو جيڪو پڻ صحيح آھي وارن لکڻين جي.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// صف جي پهرين عنصر کي پوائنٽر حاصل ڪندو آهي.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// صف جي پهرين عنصر کي بدلائي پوائنٽر حاصل ڪري ٿو
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` کان `this` جا عنصر نقل ڪري ٿو ، ايڪس اين ايڪس ايڪس جي هاڻي انضمام واري مواد ڏانهن هڪ قابل تبديلي حوالو ڏئي ٿو.
    ///
    /// جيڪڏهن `T` `Copy` لاڳو نٿو ڪري ، [`write_slice_cloned`] استعمال ڪريو
    ///
    /// اهو [`slice::copy_from_slice`] سان ملندڙ آهي.
    ///
    /// # Panics
    ///
    /// اهو ڪم panic ٿيندو جيڪڏهن ٻن سلائسون مختلف لمبائي آهن.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // حفاظت: اسان لين جي سڀني عنصرن کي اضافي صلاحيت ۾ نقل ڪيو آهي
    /// // وي سي جو پهريون src.len() عنصر هاڻي صحيح آهن.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // سيفٽي: &[T] ۽ ۽ [ٿي سگهي ٿو يونٽينٽ<T>] ساڳئي ترتيب آهي
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // حفاظت: صحيح عنصرن کي صرف `this` ۾ نقل ڪيو ويو آهي تنهن ڪري ان جي ابتڙ آهي
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` کان `this` جي عنصر کي کلون ، ايڪس ايڪس ايڪس جي هاڻي غير انساني مواد ۾ هڪ قابل تبديلي حوالو.
    /// ڪوبه اڳ ۾ ئي داخل ٿيل عنصر نه ڇڏيو ويندو.
    ///
    /// جيڪڏهن `T` `Copy` لاڳو ڪندو ، [`write_slice`] استعمال ڪريو
    ///
    /// اهو ساڳي طرح [`slice::clone_from_slice`] سان آهي پر موجوده عنصرن کي نه ڇڏيندو آهي.
    ///
    /// # Panics
    ///
    /// اهو ڪم panic ٿيندو جيڪڏهن ٻه سلائسون مختلف لمبائي آهن ، يا جيڪڏهن ايڪسڪسيمڪس panics جو عمل درآمد ٿيندو.
    ///
    /// جيڪڏھن ھڪڙو panic آھي ، اڳ ۾ ئي ڪلون ٿيل عنصر ڇڏيا ويندا.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // حفاظت: اسان صرف لين جي سڀني عنصرن کي اسپيس جي گنجائش ۾ کليو آهي
    /// // وي سي جو پهريون src.len() عنصر هاڻي صحيح آهن.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // copy_from_slice جي برعڪس اھو سليون تي clone_from_slice کي ڪال نه ٿو ڪري ، اھو آھي ڇو ته `MaybeUninit<T: Clone>` ڪلون کي لاڳو نٿو ڪري.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // حفاظت: انهي خام سلائس ۾ صرف شروعاتي شيون شامل هونديون
                // ان ڪري ، اهو ڇڏڻ جي اجازت آهي.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: اسان کي انهن کي ساڳئي لمبائي تي واضح طور تي سلائي ڪرڻ جي ضرورت آهي
        // حدف جي چڪاس لاءِ مدد حاصل ڪرڻ لاءِ ، ۽ اصلاح ڪندڙ سادي ڪيسن لاءِ يادگيريون پيدا ڪنديون (مثال طور T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // محافظ جي ضرورت آهي b/c panic شايد کلون جي دوران
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // حفاظت: صحيح عناصر صرف `this` ۾ لکيو ويو آهي انهي جي ڪري هي جائزي مطابق آهي
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}