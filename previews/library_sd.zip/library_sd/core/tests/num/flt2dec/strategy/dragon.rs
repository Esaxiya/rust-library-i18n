use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // ميئر تمام سستي آهي
fn exact_sanity_test() {
    // هي آزمائشي ختم ٿيڻ ختم ٿي وئي ، مان صرف فرض ڪري سگهان ٿو `exp2` لائبريري جي فنڪشن جو ڪجهه ڪنو ايش ڪيس آهي ، جيڪو سي رن ٽائم ۾ بيان ڪيو ويو آهي اسان استعمال ڪري رهيا آهيون.
    // وي ايس 2013 ۾ هن فنڪشن کي ظاهري طور تي هڪ بگ ٿي هئي جئين اهو ڳن linkedيل هجي ته ناڪام ٿيندو آهي ، پر وي ايس 2015 سان اها بگ فڪس ٿي رهي آهي جيئن ٽيسٽ بلڪل ٺيڪ ٿي وڃي.
    //
    // بگ `exp2(-1057)` جي واپسي جي قيمت ۾ فرق لڳي ٿو ، جتي VS 2013 ۾ اهو ٻٽي نموني 0x2 سان ٻيڻو ڏي ٿو ۽ VS 2015 ۾ اهو 0x20000 موٽائي ٿو.
    //
    //
    // هاڻي ئي صرف ايم ايس وي سي تي مڪمل طور تي اهو ٽيسٽ نظرانداز ڪيو وڃي ، جيئن اهو ڪنهن ٻئي طرف آزمايو وڃي ۽ اسان هر پليٽ فارم جي exp2 عمل درآمد جي جاچ ۾ سپر دلچسپي نٿا رکون.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}