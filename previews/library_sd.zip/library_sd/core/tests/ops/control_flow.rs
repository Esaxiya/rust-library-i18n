use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // اهو مستحڪم مٿاڇري وارو علائقو ناهي ، پر هنن جي وچ ۾ `?` سستو رکڻ ۾ مدد ڪندو آهي ، جيتوڻيڪ جيڪڏهن LLVM هميشه هاڻي ان جو فائدو نٿو وٺي سگهي.
    //
    // (افسوس جو نتيجو ۽ اختيار متضاد آهن ، تنهن ڪري ڪنٽرول فلو ٻنهي سان نٿو ملي سگهي.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}