// rsbegin.o ۽ rsend.o ائين ئي سڏيو ويندو آهي "compiler runtime startup objects".
// انهن ۾ ڪوڊليٽر رن ٽائيم کي صحيح طور تي شروع ڪرڻ لاءِ گهربل مواد شامل آهن.
//
// جڏهن عملدرآمد يا ڊليب تصوير جوڙي ڳن isيل هجي ، سڀ صارف ڪوڊ ۽ لائبريريون انهن ٻن اعتراضن فائلن جي وچ ۾ "sandwiched" هونديون آهن ، تنهن ڪري rsbegin.o کان ڪوڊ يا ڊيٽا تصوير جي لاڳاپيل حصن ۾ پهرين ۾ شامل ٿي وينديون ، جڏهن ته rsend.o کان ڪوڊ ۽ ڊيٽا آخري ٿي وينديون آهن.
// اهو اثر هڪ حصي جي شروعات يا آخر ۾ نشانين کي رکڻ لاءِ ، انهي سان گڏ ڪنهن به گهربل هيڊر يا فوٽر کي داخل ڪرڻ لاءِ استعمال ڪري سگهجي ٿو.
//
// ياد رکجو اصل ماڊل داخلا جو نقشو سي رن ٽائيم شروع ٿيندڙ شئي ۾ واقع آهي (عام طور تي `crtX.o` سڏبو) ، جيڪو پوءِ ٻين رن ٽائيم حصن جي شروعاتي ڪال بڪ (اڃا تائين هڪ ٻي خاص تصوير واري سيڪشن ذريعي رجسٽرڊ ٿيل) سڏيو وڃي ٿو.
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // اسٽيڪ فريم جي شروعات کي نشان لڳل اڻindاڻ infoاڻ واري حصي کي
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // جاچيندڙ جي اندروني ڪتاب رکڻ جي لاءِ خشڪ جاءِ.
    // اهو `struct object` $ GCC/undind-dw2-fde.h ۾ بيان ڪيو ويو آهي.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // معلومات کي ختم ڪريو registration/deregistration معمولات.
    // libpanic_unwind جا دستاويز ڏسو.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // ماڊل شروع ڪرڻ تي ويهڻ جي معلومات داخل ڪريو
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // بند ڪرڻ تي رجسٽرڊ ٿيو
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW مخصوص init/uninit معمولي رجسٽريشن
    pub mod mingw_init {
        // MinGW جي شروعاتي شيون (crt0.o/dllcrt0.o) شروع ڪرڻ ۽ نڪرڻ تي .ctors ۽ .dtors سيڪشن ۾ عالمي تعمير ڪندڙن کي بلائيندو.
        // ڊي ايلز جي صورت ۾ ، هي اهو ڪيو ويندو آهي جڏهن ڊي ايل ايل لوڊ ۽ لوڊ ٿئي ٿي.
        //
        // ڳنيل حصن کي ترتيب ڏيندو ، جنهن کي يقيني بڻائي ٿو ته اسان جي ڪال بيڪ لسٽ جي آخر ۾ واقع آهن.
        // جيئن ٺاهيندڙن ريورس ترتيب ۾ هليا ويا آهن ، انهي کي يقيني بڻائي ٿو ته اسان جا ڪالڪا پهرين ۽ آخري آهن جيڪي عمل ڪيا ويا.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: سي شروع ٿيندڙ ڪال بيڪ
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: سي ختم ڪال ڪال
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}