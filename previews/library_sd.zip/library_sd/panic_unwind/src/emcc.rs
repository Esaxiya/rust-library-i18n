//! *emscripten* ھدف لاءِ ٻاهر ڪindingڻ.
//!
//! جتي Unix پليٽ فارمز لاءِ Rust جو عام طور تي اڻ کٽ عمل درآمد سڌو لبون ويند APIs ۾ داخل ٿئي ٿو ، ايم ايس اسڪرپٽ تي اسان بدران سي ++ اڻ کٽ APIs تي ڪال ڪريو ٿا.
//! اهو صرف هڪ نن anڙو عمل آهي ڇو ته ايمپسسن جي هلت واري وقت هميشه انهن APIs کي لاڳو ڪندي آهي ۽ لبنانڊ نه لاڳو ڪندي آهي.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// ھي C++ ۾ std::type_info جي ترتيب سان ٺھي ٿو
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // معروف `\x01` بائيٽ هتي اصل ۾ LLVM ڏانهن هڪ جادوئي سگنل آهي *نه* ڪنهن ٻئي سانگنگ لاڳو ڪرڻ جهڙوڪ `_` ڪردار سان.
    //
    //
    // هي نشاني وبلبل آهي C++ جي `std::type_info` پاران.
    // قسم `std::type_info` جا اعتراض ، قسم جي وضاحت ڪندڙ ، ھن ميز کي ھڪڙي پوائنٽر آھن.
    // قسم جي تشريح ڪندڙ مٿي بيان ڪيل سي ++ اي ايڇ ڊزائينز جي حوالي ڪيا ويا آهن ۽ جيڪي اسان هيٺ تعمير ڪريون ٿا.
    //
    // نوٽ ڪريو ته حقيقي سائيز 3 استعمال کان وڏو آهي ، پر اسان کي رڳو ٽئين عنصر ڏانهن اشارو ڪرڻ لاءِ اسان جو Vtable گهربل آهي.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info rust_panic ڪلاس لاءِ
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // عام طور تي اسان .as_ptr().add(2) استعمال ڪندا هئاسين پر اهو ڪم مستقل حوالي سان ڪم نٿو ڪري.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // اهو ارادي طور تي عام نالي جي ترتيب واري اسڪيم استعمال نه ڪندو آهي ڇاڪاڻ ته اسان نٿا چاهيون ته C++ Rust panics پيدا ڪرڻ يا پڪ ڪرڻ جي قابل ٿي.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // اهو ضروري آهي ڇاڪاڻ ته C++ ڪوڊ اسان جي ايڪسچينج کي std::exception_ptr سان پڪڙي سگهي ٿو ۽ ان کي ٻيهر گھرايائين ، ممڪن طور تي ڪنهن ٻئي سلسلي ۾.
    //
    //
    caught: AtomicBool,

    // اهو هڪ اختيار ٿيڻ جي ضرورت آهي ڇو ته اعتراض جي حياتي C++ سيمينٽڪ جي پيروي ڪري ٿي: جڏهن catch_unwind باڪس کي رعايت مان ڪ movesي ٿو اها استثناء واري شي کي صحيح حالت ۾ ڇڏڻ گهرجي ڇو ته هن کي تباهه ڪندڙ کي __cxa_end_catch سڏڻ وارو آهي
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try دراصل اسان کي هن اڏاوت ڏانهن اشارو ڏي ٿو.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // cleanup() کان panic کان اجازت ناهي ، اسان صرف ان جي بدران ختم ڪيو.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}