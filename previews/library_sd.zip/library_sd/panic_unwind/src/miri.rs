//! ميري لاء panics کولڻ.
use alloc::boxed::Box;
use core::any::Any;

// پيئي لوڊ جو قسم جيڪو مري انجڻ اسان جي لاءِ اجاگر ڪرڻ ذريعي پروپئگنڊا ڪري ٿو.
// پوائنٽر جي سائز جو هجڻ لازمي آھي.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// ميري مهيا ڪيل خارجي فنڪشن ڪ unwڻ شروع ڪرڻ لاءِ.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // پيڪس لوڊ اسان `miri_start_panic` ڏانهن وڃو درست هي دليل هوندو اسان هيٺ `cleanup` ۾.
    // تنهن ڪري اسان انهي کي صرف هڪ دفعو باڪس ڪيو ، ڪجهه پوائنٽر سائز وٺڻ لاءِ.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // ھيٺ ڏنل `Box` کي بحال ڪريو.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}