//! Windows SEH
//!
//! Windows تي (في الحال صرف MSVC تي) ، ڊفالٽ استثنا سنڀالڻ وارو ميڪانيزم Structured Exception Handling (SEH) آهي.
//! اهو ٻوڙن جي بنياد تي استثنا سان هٿ ڪرڻ کان گهڻو مختلف آهي (مثال طور ، ڇا ٻئي unix پليٽ فارم استعمال ڪندڙ) ٺاهيندڙن جي انٽيلنسل جي لحاظ کان ، انهي ڪري ايل ايل وي ايم لاءِ گهربل آهي ته ايس ايڇ لاءِ اضافي سهڪار جا بهتر واڌايون.
//!
//! مختصر ۾ ، هتي ڇا ٿيندو آهي:
//!
//! 1. `panic` فنڪشنل Windows فنڪشن `_CxxThrowException` سڏيندو آهي C++ اڇلائڻ وانگر ، استثنا وانگر ، پوشاڪ واري عمل کي ڇڪڻ.
//! 2.
//! کمپائلر پاران ٺاهيل سڀئي لينڊنگ پيڊس شخصيت واري فنڪشن `__CxxFrameHandler3` استعمال ڪن ٿا ، CRT ۾ هڪ فنڪشن ، ۽ Windows ۾ ويهڻ وارو ڪوڊ هن شخصيت واري فنڪشن کي اسٽيڪ تي سڀني صفائي ڪوڊ کي عمل ۾ آڻڻ لاءِ استعمال ڪندو.
//!
//! 3. `invoke` تي سڀني مرتب ڪيل ٺاھيندڙ ڪالن کي `cleanuppad` LLVM هدايتون طور لينڊنگ پيڊ سيٽ آھي ، جيڪو صفائي جي روزاني جي شروعات کي ظاھر ڪري ٿو.
//! شخصيت (قدم 2 ۾ ، سي آر ٽي ۾ بيان ٿيل) صفائي جي معمول کي هلائڻ لاءِ ذميوار آهي.
//! 4. آخرڪار "catch" ڪوڊ `try` اندروني (ٺاهيل ترتيب ڏيندڙ) ٺاهيا ويا آهن ۽ اشارو ڪري ٿو ته ڪنٽرول Rust ڏانهن واپس اچڻ گهرجي.
//! اهو ايل ايل ايم ايم آر جي شرطن ۾ `catchswitch` ۽ `catchpad` هدايتون ذريعي ڪيو ويو آهي ، آخرڪار ايڪس 0X جي هدايت سان پروگرام تي عام ڪنٽرول واپس اچي رهيو آهي.
//!
//! gcc تي ٻڌل استثنا سان لاڳاپيل ڪجهه خاص فرق آهن:
//!
//! * Rust کي ڪا به ذاتي شخصيت واري فنڪشن ناهي ، ان جي بدران *هميشه*`__CxxFrameHandler3`.اضافي طور تي ، اضافي فلٽرنگ انجام نه ڏني وئي آهي ، تنهن ڪري اسان ڪنهن C++ استثنا کي پڪڙي ورتو آهي جيڪو انهي وانگر ڏسڻ ۾ اچي ٿو جيڪو اسان اڇلائي رهيا آهيون.
//! ياد رکجو Rust ۾ هڪ استثنا اڇلاڻ وارو عمل بدليل آهي ، تنهن ڪري اهو صحيح هجڻ گهرجي.
//! * اسان کي بيهڻ واري حد پار ڪرڻ لاءِ ڪجهه ڊيٽا ملي چڪا آهن ، خاص طور تي هڪ `Box<dyn Any + Send>`.ڊوارف جي استثنا سان ، اهي ٻئي اشارو استثنا جي پاڻ ۾ پيڊ لوڊ جي طور تي محفوظ ٿيل آهن.
//! جڏهن ته ، ايم ايس وي سي تي ، اضافي اضافي ڊڪشن جي ضرورت نه آهي ڇو ته ڪال اسٽيڪ محفوظ ٿيل آهي جڏهن ته فلٽر افعال کي انجام ڏنو ويندو آهي.
//! هن جو مطلب آهي ته اشارو سڌو `_CxxThrowException` ڏانهن منتقل ڪيا ويا آهن جيڪي پوءِ فلٽر فنڪشن ۾ وصولي آهن `try` اندروني واري اسٽيڪ جي فريم ڏانهن لکڻ لاءِ.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // اهو هڪ اختيار ٿيڻ جي ضرورت آهي ڇو ته اسان حوالن کان استثنا کي پڪيون ٿا ۽ انهي جو تباهي ڪندڙ C++ رن ٽائم کان انجام ڏنو ويو آهي.
    // جڏهن اسين باڪس کي رعايت مان ڪ takeي وٺون ٿا ، اسان کي ان کي تباهه ڪرڻ واري کي صحيح حالت ۾ ڇڏڻ جي ضرورت آهي انهي جي تباهي ڪندڙ کي باڪس کي ٻوڙڻ کان سواءِ هلائڻ لاءِ.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// پهرين مٿي ، قسم جي تعريفات جو هڪ مڪمل مجموعو.هتي ڪجهه پليٽ فارمنس بي مثال موجود آهن ، ۽ گهڻو ڪجهه ، اها صرف LLVM تان واضح طور تي نقل ٿيل آهي.ان سڀ جو مقصد `_CxxThrowException` کي ڪال ڪال ذريعي `panic` فنڪشن کي لاڳو ڪرڻو آهي.
//
// ھي فنڪشن ٻن دليلن تي وٺندو آھي.پهريون ڊيٽا ڏانهن اشارو ڪندڙ آهي جنهن ۾ اسان گذري رهيا آهيون ، انهي صورت ۾ اسان جو trait اعتراض آهي.ڳولڻ ۾ ڪافي آسان آھي!ايندڙ ، بهرحال ، وڌيڪ پيچيده آهي.
// هي `_ThrowInfo` structureانچي ڏانهن اشارو آهي ، ۽ اهو عام طور تي صرف استثنا اڇلائڻ جي وضاحت ڪرڻ جو مقصد آهي.
//
// هن وقت هن قسم جي [1] نن definitionڙي بالائي آهي ، ۽ بنيادي بيچيني (۽ آن لائن آرٽيڪل کان فرق) اهو آهي ته 32-bit تي پوائنٽر پوائنٽر آهن پر 64-bit تي پوائنٽرس کي 32 بٽ آفسيٽس طور ظاهر ڪيو وڃي ٿو. `__ImageBase` علامت.
//
// ماڊلولز ۾ `ptr_t` ۽ `ptr!` ميڪرو ھي اظهار لاءِ استعمال ڪيا ويندا آھن.
//
// قسم جي وصفن جي بھولبندي پڻ هن ريت آهي ته ايل ايل وي ايم هن قسم جي آپريشن لاءِ ڇا نڪتو آهي.مثال طور ، جيڪڏهن توهان هن C++ ڪوڊ کي ايم ايس وي سي تي مرتب ڪيو ۽ ايل ايل وي ايم آر کي خارج ڪيو.
//
//      #include <stdint.h>
//
//      اڏام رسٽ_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2] ؛ هائوٽي} ؛
//
//      باطل ٿيل foo() { rust_panic a = {0, 1} ؛
//          اڇلايو ؛}
//
// اھو بنيادي طور تي جيڪو اسان جذب ڪرڻ جي ڪوشش ڪري رھيا آھيون.ھيٺ ڏنل مستقل قدر صرف ايل ايل وي ايم مان نقل ڪيا ويا.
//
// ڪنهن به صورت ۾ ، اهي اڏاوتون ساڳيءَ طرح تعمير ڪيون ويون آهن ، ۽ اهو اسان لاءِ فقط ڪجهه زباني هوندو آهي.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// ياد رکو ته اسان ارادي طور تي نالو جي نالي واري قانون کي نظرانداز ڪندا آهيون.
//
//
// جڏهن ترميمي ڪرڻ ، پڪ ڪري وٺو ته ٽائيپ جو نالو وارو اسٽرنگ بلڪل انهي سان ملندو آهي جيڪو `compiler/rustc_codegen_llvm/src/intrinsic.rs` ۾ استعمال ٿيل آهي.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // معروف `\x01` بائيٽ هتي اصل ۾ LLVM ڏانهن هڪ جادوئي سگنل آهي *نه* ڪنهن ٻئي سانگنگ لاڳو ڪرڻ جهڙوڪ `_` ڪردار سان.
    //
    //
    // هي نشاني وبلبل آهي C++ جي `std::type_info` پاران.
    // قسم `std::type_info` جا اعتراض ، قسم جي وضاحت ڪندڙ ، ھن ميز کي ھڪڙي پوائنٽر آھن.
    // قسم جي تشريح ڪندڙ مٿي بيان ڪيل سي ++ اي ايڇ ڊزائينز جي حوالي ڪيا ويا آهن ۽ جيڪي اسان هيٺ تعمير ڪريون ٿا.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// هي قسم جي وضاحت ڪندڙ صرف تڏهن ڪتب آڻيندي آهي جڏهن هڪ استثنا اڇلايو وڃي.
// ڪيچ جو حصو ڪوشش اندروني طور تي هٿ ڪيو ويو آهي ، جيڪو پنهنجي ٽائپي بيان ڪندڙ پيدا ڪري ٿو.
//
// اهو ٺيڪ آهي ڇو ته ايم ايس وي سي رن ٽائيم ٽائپ نالي تي سٽرنگ موازنہ استعمال ڪندو آهي ٽائپ ڊيڪيٽرس کي پوائنٽر مساوات کان ملائڻ لاءِ.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// تباهي وارو استعمال ڪيو ويندو آهي جيڪڏهن C++ ڪوڊ استثنا کي پڪڙڻ ۽ ان کي تبليغ ڪرڻ کان سواءِ ڇڏڻ جو فيصلو ڪري ٿو.
// آزمائشي داخلي جو حصو حصو استثناء واري شيءَ جو پهريون لفظ طئي ڪندو 0 ڏانهن انهي ڪري ته اها تباهي ڪندڙ طرفان ڀ isي وڃي.
//
// ياد رکجو ته x86 Windows سي ++ ميمبر جي افعال لاءِ "thiscall" ڪالنگ ڪنوينشن جي بدران ڊفالٽ "C" ڪالنگ ڪنوينشن جي بدران استعمال ڪندو آهي.
//
// استثنا_ کاپي فنڪشن هتي ڪجھ خاص آهي: اهو ايڪس وي ايس بلاڪ جي تحت ايم ايس وي سي رن ٽائم ۽ panic پاران انڪو ڪيو ويو آهي ، جيڪو اسان هتي ٺاهيندا آهيون استثنا جي ڪاپي جي نتيجي ۾.
//
// اهو استعمال ڪيو ويو C++ رن ٽائيم سان ايڪس آرڪس سان استثناء کي قبضو ڪرڻ ۾ مدد ڏيڻ لاءِ ، جنهن جي اسان مدد نٿا ڪري سگھون ڇاڪاڻ ته باڪس<dyn Any>ڪلائونڊ ناهي.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _ اسٽيڪس فريم مڪمل طور تي اسٽيڪ فريم تي عمل ڪيو ويندو آھي ، تنھنڪري ٻيھر ھڪڙو `data` ٻيھر منتقل ڪرڻ جي ضرورت ناھي.
    // اسان صرف انهي ڪم ڏانهن اسٽيڪ پوائنٽر کي پاس ڪندا آهيون.
    //
    // دستي طور تي ڊراپ جي ضرورت آهي جئين ته اسان نٿا چاهيون جڏهن ته ڪاهي وڃڻ جي استثنا ختم نه ٿئي.
    // انهي جي بدران اهو ڪ exceptionيو ويندو استثناء واري ڪلپ سان جيڪو C++ رن ٽائم پاران سڏيو ويندو آهي.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // اهو ... حيرت ٿي سگھي ٿو ، ۽ جائز طور تي ايترو.32-bit MSVC تي انهن اڏامن جي وچ ۾ اشارو صرف اهو آهي ، اشارو.
    // 64-bit MSVC تي ، بهرحال ، اڏاوتن جي وچ ۾ اشارو بجاء `__ImageBase` 32-bit آفسیٽ طور ظاهر ڪيا ويا آهن.
    //
    // نتيجتن ، 32-bit MSVC تي اسان انهن سڀني اشارن کي مٿي ڏنل `جامد` ۾ قرار ڏئي سگھون ٿا.
    // 64-bit MSVC تي ، اسان کي شماريات ۾ پوائنٽرن جي گھٽتائي جو اظهار ڪرڻو پوندو ، جيڪو Rust في الحال اجازت نٿو ڏئي ، انهي ڪري اسان اهو بلڪل نٿا ڪري سگهون.
    //
    // ايندڙ سٺي شيءِ ، پوءِ هلڪي وقت تي انهن اڏاوتن کي پُر ڪرڻ (ڇڪڻ واري ڳالهه پهريان ئي "slow path" آهي).
    // تنهن ڪري اسان هتي انهن پوينٽر فيلڊ کي 32-bit انٽيگرز طور ٻيهر تعبير ڪريون ٿا ۽ پوءِ ان سان لاڳاپيل ويليو کي ذخيرو ڪريون ٿا (ايٽمي طور تي ، هڪجهڙائي سان panics ٿي سگھي ٿو).
    //
    // تخنيقي طور تي رن ٽائيم شايد انهن شعبن جي اڻ اڻ پڙهيل حرڪت ڪندو ، پر نظرياتي طور انهن ڪڏهن *غلط* قدر ڪڏهن نه پڙهي ته پوءِ اهو تمام خراب نه هئڻ گهرجي ...
    //
    // ڪنهن به صورت ۾ ، اسان کي بنيادي طور تي ڪجهه ڪرڻ جي ضرورت آهي ، جيستائين اسان جامد ۾ وڌيڪ عملن جو اظهار ڪري سگھون (۽ اسان ڪڏهن به ٿي نٿا سگھون).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // هتي هڪ نيل پيلي لوڊ جو مطلب آهي ته اسان __rust_try جي ڪيچ (...) مان هتي پهچي ويا آهيون.
    // اهو ٿئي ٿو جڏهن هڪ غير Rust پرڏيهي استثنا پڪڙجي ٿو.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// اهو موجود هجڻ لاءِ ضروري آهي ترتيب ڏيڻ وارو (مثال طور ، اهو هڪ لانگ شيٽ آهي) ، پر اهو اصل ۾ ڪڏهن به ٺلائيندڙ طرفان نه سڏيو ويو آهي ڇاڪاڻ ته __C_specific_handler يا _except_handler3 اهو شخصيت وارو فنڪشن آهي ، جيڪو هميشه استعمال ڪيو ويندو آهي.
//
// ان ڪري اهو صرف هڪ ضرب وارو حرڪت آهي.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}