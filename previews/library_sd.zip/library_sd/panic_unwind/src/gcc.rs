//! 0panics جي عمل درآمد ۾ libgcc/libunwind (ڪجهه شڪل ۾) کان پٺتي آهي.
//!
//! استثناء ڏيڻ جي پس منظر ۽ پس منظر جي ترتيب لاءِ مهرباني ڪري ڏسو "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) ۽ انهي سان ڳن documentsيل دستاويز.
//! اهي پڻ سٺا پڙهيا آهن:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## مختصر خلاصو
//!
//! استثنا سنڀالڻ ٻن مرحلن ۾ هوندو آهي: هڪ ڳولا وارو مرحلو ۽ صفائي وارو مرحلو.
//!
//! ٻنهي مرحلن ۾ ، ناشر ڪندڙ اسٽيڪ فريم کي مٿين کان مٿي تائين گھمائيندو آهي اسٽيڪ فريم جي اڻ sectionsاڻ حصن کي عمل جي موجوده عمل جي ماولولز ("module" هتي او ايس ماڊل ، يعني ، هڪ قابل عمل يا متحرڪ لائبريري) جي حوالي ڪري ٿو.
//!
//!
//! هر اسٽيڪ فريم لاءِ ، اها لاڳاپيل "personality routine" کي سڏيندو آهي ، جنهن جو پتو پهن جي infoاڻ واري سيڪشن ۾ پڻ اسٽور ٿيل آهي.
//!
//! ڳولا جي مرحلي ۾ ، شخصيت جي روين جو ڪم استثنا واري شيءِ کي اڇلائڻ جو معائنو ڪرڻ آهي ، ۽ اهو فيصلو ڪرڻ ته ڇا اهو ان اسٽوري فريم تي پڪڙي وڃڻ گهرجي.هڪ ڀيرو هينڊلر فريم جي سڃاڻپ ٿي وئي آهي ، صفائي وارو مرحلو شروع ٿي ويندو آهي.
//!
//! صفائي واري مرحلي ۾ ، غنڊر ڪندڙ هر شخصيت معمول کي ٻيهر سڏيندو آهي.
//! هن وقت اهو فيصلو ڪري ٿو ته (جيڪڏهن ڪو) صفائي ڪوڊ کي هاڻوڪي اسٽيڪ فريم لاءِ هلائڻ جي ضرورت آهي.جيڪڏهن ائين آهي ، ڪنٽرول ڪم جسم ۾ هڪ خاص branch ڏانهن منتقل ڪيو ويو آهي ، "landing pad" ، جيڪو تباهه ڪندڙ کي سڏيندو آهي ، ياداشت کي آزاد ڪري ٿو ، وغيره.
//! لينڊنگ پيڊ جي آخر ۾ ، ڪنٽرول واپس ويهڻ وارن ۽ واپس اچڻ واري هنڌ تي منتقل ڪيو ويندو آهي.
//!
//! هڪ ڀيرو اسٽيڪ سنڀاليندڙ فريم جي سطح تي لاٿو ويو آهي ، نه ختم ٿيڻ واري اسٽاپ ۽ آخري شخصيت معمولي ڪنٽرول ڪيچ بلاڪ ڏانهن منتقل ڪري ٿي.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust جي استثناء واري ڪلاس سڃاڻيندڙ.
// اهو شخصيت واري معمولي طرفان استعمال ڪيو ويندو آهي اهو طئي ڪرڻ جي لاءِ ته انهن جي پنهنجي رن ٽائيم کان استثنا اڇلايا ويا هئا.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-وڪڻندڙ ، ٻولي
    0x4d4f5a_00_52555354
}

// رجسٽريشن آئي ڊيز LLVM جي TargetLowering::getExceptionPointerRegister() ۽ TargetLowering::getExceptionSelectorRegister() کان هر آرڪيٽيڪچر لاءِ ڪ wereيا ويا ، پوءِ رجسٽر ڊيفينيشن ٽيبلز ذريعي DWARF رجسٽرڊ نمبر تي نقشو ٺاهيا ويا (خاص طور تي<arch>RegisterInfo.td ، "DwarfRegNum" لاءِ ڳوليو).
//
// پڻ ڏسو http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX ، اي ڊي ايڪس

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX ، آر ڊي ايڪس

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0 ، X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3 ، X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// هيٺيون ڪوڊ GCC جي C ۽ C++ شخصيتن جي معمول تي ٻڌل آهي.حوالي لاءِ ، ڏسو:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM ايڇ اي بي آئي شخصيت جي معمولي آهي.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS استعمال ٿيل سڌي طرح استعمال ڪندو آهي ڇاڪاڻ ته اهو استعمال ڪندي SjLj آرام ڪرڻ وارو آهي.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM تي پٺيون ھلندڙ شخصيت کي معمولي رياست سان سڏيندو==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // انهن حالتن ۾ اسين اسٽيڪ کي جاري رکڻ جاري رکون ٿا ، ٻي صورت ۾ اسان جون سڀ پٺاڻيون __rust_try تي ختم ٿي وينديون
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // ڊي ڊبليو ايف بي بي اهو فرض ڪري ٿو ته _Uwwind_Context شين ۽ ايل ايس ڊي اي پوائنٽرن وانگر شين کي روڪي ٿو ، جڏهن ته ARM EHABI انهن کي استثنا جي ايجاد ۾ رکي ٿو.
            // _Unwind_GetLanguageSpecificData() وانگر افعال جي دستخط محفوظ ڪرڻ لاءِ ، جيڪي صرف ديهانڪ پوائينٽر وٺي وڃن ٿا ، GCC شخصيات معمول کي اشارو ۾ استثنا لاءِ استعمال ڪن ٿيون_ ARM جي "scratch register" (r12) لاءِ محفوظ ڪيل مقام استعمال ڪندي.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... هڪ وڌيڪ اصولي انداز اسان جي لبنانڊ پابندين ۾ ARM جي _ان ون_ڊ_ڪونٽ جي مڪمل تعريف مهيا ڪرڻ هوندو ۽ اتي کان گهربل ڊيٽا سڌو سنئون حاصل ڪندي ، ڊي ڊبليو ايف ايف مطابقت واري ڪارنامن کي نظرانداز ڪندي.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI کي شخصيتن جي معمولي کي ايس پي قدر کي تازه ڪاري ڪرڻ جي ضرورت آهي استثنا واري شي جي ڪيريئر ڪيش ۾.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // اي آر ايم اي ايڇ آئي تي شخصيت جي معمولي اصل ۾ ذميوار آهي اصل ۾ واپسي کان پهريان هڪ اسٽيڪ فريم ڪ unwڻ (آر ايم اي ايڇ آئي سيڪ.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc ۾ تعريف ڪئي وئي
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // اصلي شخصيت وارو رواج ، جيڪو سڌي طرح اڪثر مقصدن تي استعمال ڪيو ويندو آهي ۽ اڻ سڌي طرح Windows x86_64 تي ايس ايڇ او.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 من جي ڊبليو ايڇ ٽارگيٽ تي ، اڻ کٽ وارو ميڪانيزم ايس ايڇ هوندو آهي جڏهن ته اڻ ڏٺي سنڀاليندڙ ڊيٽا (اڪا ايل ايس ڊي اي) GCC-مطابقت رکندڙ انڪوڊنگ استعمال ڪندو آهي.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // اسان جي اڪثر مقصدن لاءِ شخصيت جو معمول.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // واپسي جي ايڊريس پوائنٽ 1 بائيٽ ڪال جي هدايت ، جيڪا ايندڙ آئي ايس جي حد ۾ ايل ايس ڊي اي رينج ٽيبل ۾ ٿي سگهي ٿي.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// معلومات جي اندراج جي فريم هڻ
//
// هر ماڊل جي تصوير تي مشتمل آهي فريم نڪڻ جي sectionاڻ وارو سيڪشن (عام طور تي ".eh_frame").جڏهن هڪ ماڊل loaded/unloaded پروسيس ۾ هجي ، ياد ڪرڻ وارو يادداشت ۾ هن حصي جي مقام بابت آگاهي ٿيڻ گهرجي.حاصل ڪرڻ جا طريقا جيڪي پليٽ فارم تان مختلف ٿين ٿا.
// ڪجهه تي (مثال طور ، Linux) ، وينڊر پنهنجو پاڻ واندو معلومات جي حصا ڳولي سگهي ٿو (dl_iterate_phdr() API and finding their ".eh_frame" sections) ذريعي في الحال لوڊ ٿيل ماڊلز کي متحرڪ طور تي ڳڻڻ سان ؛ ٻيا ، جهڙوڪ Windows ، ماڊلر جي ضرورت آهي انهن جي infoاڻندڙ معلومات حصي وارن کي اي پي اين آر جي ذريعي.
//
//
// اهو ماڊل ٻن علامن کي بيان ڪري ٿو جن کي حوالو ڏنو ويو ۽ rsbegin.rs کان سڏيو وڃي ٿو اسان جي معلومات GCC رن ٽائم سان رجسٽر ڪرڻ لاءِ.
// اسٽيڪ اڻindingاڻ جو نفاذ (هينئر لاءِ) libgcc_eh لاءِ ملتوي ڪيو ويو آهي ، جڏهن ته Rust crates هنن Rust خاص داخلا پوائنٽس استعمال ڪيو ته ممڪن آهي ڪنهن به GCC رن ٽائيم سان ڌڪ لڳڻ کان.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}