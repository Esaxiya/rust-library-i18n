//! مختص Prelude
//!
//! هن ماڊل جو مقصد `alloc` crate جي عام طور تي استعمال ٿيندڙ شين جي وارداتن جي گهٽتائي ڪرڻ آهي.
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;