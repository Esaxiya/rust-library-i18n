/// دليلن تي مشتمل [`Vec`] ٺاهي ٿو.
///
/// `vec!` اجازت ڏئي ٿو "ويڪ" کي ساڳئي نحو سان بيان ڪيو ويو آهي جئين صف بيانن وانگر.
/// ھن ميڪرو جا ٻه روپ آھن:
///
/// - عناصر جي ھڪڙي ڏنل فهرست تي مشتمل [`Vec`] ٺاھيو:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - ڏنل عنصر ۽ سائيز مان [`Vec`] ٺاهيو.
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// ياد رکو ته صف بيانن جي برعڪس هي نحو انهن سڀني عنصرن کي سپورٽ ڪري ٿو جيڪي [`Clone`] تي عمل ڪن ٿا ۽ عناصر جو تعداد مسلسل هجڻ جي ضرورت ناهي.
///
/// اهو ايڪس ڊيڪس هڪ اظهار کي نقل ڪرڻ لاءِ استعمال ڪندو ، تنهن ڪري هن کي غير معياري `Clone` عمل درآمد ٿيڻ وارن قسمن سان استعمال ڪرڻ گهرجي.
/// مثال طور ، `vec![Rc::new(1) ؛5] "ساڳيو باڪسڊ انٽيگر ويليو جي پنجن حوالن مان 5 Z0 ويڪٽر0 ز ٺاهي ٿو ، نه پنج حوالا آزاد طور باڪس ٿيل انٽيگرز ڏانهن اشارو ڪن ٿا.
///
///
/// اهو پڻ ، ياد رکجو ته `vec![expr; 0]` جي اجازت آهي ، ۽ هڪ خالي vector پيدا ڪري ٿي.
/// اهو اڃا تائين `expr` جو جائزو وٺندو ، ۽ ، فوري طور تي نتيجو ويليو ڇڏيندي ، تنهنڪري ضمني اثرات جي طرف ڌيان ڏيو.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): cfg(test) سان گڏ موروثي `[T]::into_vec` طريقو ، جيڪو ھن ميڪرو ڊيفينيشن جي ضرورت آھي ، دستياب ناھي.
// بدران `slice::into_vec` فنڪشن استعمال ڪريو جيڪو صرف cfg(test) NB سان دستياب آھي وڌيڪ slice.rs ۾ slice::hack ماڊل ڏسو وڌيڪ معلومات لاءِ
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// رن ٽائيم بيانن جي وچولي استعمال ڪندي `String` ٺاهي ٿو.
///
/// پهريون دليل `format!` وصول ڪندو آهي هڪ فارميٽ اسٽرنگ.ھي لازمي طور تي ھڪڙي تار آھي.فارميٽنگ واري اسٽرنگ جي طاقت `` {} ۾ شامل آهي.
///
/// ايڪس پي ايم وٽ اضافي پيراگراف پاس ڪيا ويا شڪل ۾ {{} جي فارميٽنگ واري اسٽرنگ ۾ ڏنل جيستائين حڪم ڏنل يا پوزيشن جا پيراگراف استعمال نه ڪيا وڃن ؛وڌيڪ معلومات لاءِ [`std::fmt`] ڏسو.
///
///
/// ھڪڙو عام استعمال `format!` جي گڏ ڪرڻ ۽ گڏي جي وچ ۾ مداخلت آھي.
/// [`print!`] ۽ [`write!`] ميڪروز سان ساڳيو ڪنوينشن استعمال ٿيندو آهي ، انهي تي ٻڌل آهي تارنگ جي منزل واري منزل تي.
///
/// ھڪڙي قيمت کي ھڪڙي ۾ تبديل ڪرڻ لاءِ ، [`to_string`] طريقو استعمال ڪريو.اهو استعمال ڪندو ايڪسڪسيمڪس فارميٽنگ trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics جيڪڏهن فارميٽنگ trait عمل درآمد هڪ غلطي موٽايو.
/// اهو غلط عمل درآمد ڏانهن اشارو ڪري ٿو ڇاڪاڻ ته `fmt::Write for String` ڪڏهن به پاڻ کي غلطي واپس نه آڻيندو آهي.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// اي ايس ٽي نوڊ کي ايڪسپريس تي زور ڀريو ويو ته جيئن پيٽرڪ پوزيشن ۾ تشخيص بهتر ڪرڻ.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}