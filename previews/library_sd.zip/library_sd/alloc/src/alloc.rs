//! ياداشت کي مختص ڪرڻ وارا API

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // اھي عالمي جادوءَ کي سڏڻ جا جادو نشان آھن.rustc انهن کي ٺاهي ٿو ايڪس آرڪس وغيره کي سڏ ڪرڻ لاءِ.
    // جيڪڏهن `#[global_allocator]` وصف آهي (ڪوڊ وڌائي ٿو ته منسوب ڪرڻ واري ميڪرو انهن افعال کي پيدا ڪري ٿي) ، يا لبيسٽڊ ۾ ڊفالٽ پليٽس کي ڪال ڪرڻ لاءِ (`__rdl_alloc` وغيره.
    //
    // ٻي صورت ۾ `library/std/src/alloc.rs`) ٻي صورت ۾.
    // rustc fork ايل ايل وي ايم پڻ خاص ڪيسن ۾ اهي فنڪشن نالا رکجن ٿا ، انهن کي ترتيب ڏيڻ سان ، ترتيب ڏنل `malloc` ، `realloc` ۽ `free` وانگر.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// عالمي يادگيري مختص ڪندڙ.
///
/// اهڙي قسم کي [`Allocator`] trait اڳتي وڌڻ جي ذريعي مختص ڪرڻ واري ڪال کي اڳتي وڌڻ سان `#[global_allocator]` خاصيت سان رجسٽر ٿيل آهي جيڪڏهن ڪو آهي ، يا `std` crate جي ڊفالٽ آهي.
///
///
/// Note: جڏهن ته اهو قسم غير مستحڪم آهي ، انهي جو ڪم مهيا ڪري سگھي ٿو ايڪس ايڪس ايڪس وسيلي پهچائي سگھجي ٿو.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// عالمي مختص ڪندڙن سان يادگيري مختص ڪريو.
///
/// اهو فنڪشن ايڪس ويڪس جي صفت سان رجسٽر ٿيل مختصار جي [`GlobalAlloc::alloc`] جي طريقيڪار کي اڳتي وڌائيندو آهي جيڪڏهن ان ۾ ڪو ، يا `std` crate جي ڊيفالٽ آهي.
///
///
/// اهو فنڪشن [`Global`] جي قسم جي `alloc` طريقي جي حق ۾ تحليل ٿيڻ جي توقع ڪئي وڃي ٿي جڏهن اهو ۽ [`Allocator`] trait مستحڪم ٿيو.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] ڏسو.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// يادداشت کي عالمي مختص ڪندڙ سان ختم ڪريو.
///
/// اهو فنڪشن ايڪس ويڪس جي صفت سان رجسٽر ٿيل مختصار جي [`GlobalAlloc::dealloc`] جي طريقيڪار کي اڳتي وڌائيندو آهي جيڪڏهن ان ۾ ڪو ، يا `std` crate جي ڊيفالٽ آهي.
///
///
/// اهو فنڪشن [`Global`] جي قسم جي `dealloc` طريقي جي حق ۾ تحليل ٿيڻ جي توقع ڪئي وڃي ٿي جڏهن اهو ۽ [`Allocator`] trait مستحڪم ٿيو.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] ڏسو.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// يادگيري بحال ڪريو عالمي مختص ڪندڙ سان.
///
/// اهو فنڪشن ايڪس ويڪس جي صفت سان رجسٽر ٿيل مختصار جي [`GlobalAlloc::realloc`] جي طريقيڪار کي اڳتي وڌائيندو آهي جيڪڏهن ان ۾ ڪو ، يا `std` crate جي ڊيفالٽ آهي.
///
///
/// اهو فنڪشن [`Global`] جي قسم جي `realloc` طريقي جي حق ۾ تحليل ٿيڻ جي توقع ڪئي وڃي ٿي جڏهن اهو ۽ [`Allocator`] trait مستحڪم ٿيو.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] ڏسو.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// صفر-شروعاتي يادگار کي عالمي مختص ڪندڙ سان مختص ڪريو.
///
/// اهو فنڪشن ايڪس ويڪس جي صفت سان رجسٽر ٿيل مختصار جي [`GlobalAlloc::alloc_zeroed`] جي طريقيڪار کي اڳتي وڌائيندو آهي جيڪڏهن ان ۾ ڪو ، يا `std` crate جي ڊيفالٽ آهي.
///
///
/// اهو فنڪشن [`Global`] جي قسم جي `alloc_zeroed` طريقي جي حق ۾ تحليل ٿيڻ جي توقع ڪئي وڃي ٿي جڏهن اهو ۽ [`Allocator`] trait مستحڪم ٿيو.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] ڏسو.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // حفاظت: `layout` سائيز ۾ غير صفر آهي ،
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // حفاظت: ساڳي طرح `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // حفاظتي: `new_size` غير صفر آهي ڇاڪاڻ ته `old_size` `new_size` کان وڌيڪ يا برابر آهي
            // جيئن حفاظت جي حالتن مطابق گھربل آهي.ٻين شرطن کي سڏيندڙ طرفان برقرار رکڻ لازمي آهي
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` شايد ايڪس ايڪس اين ايڪس يا انهي وانگر ڪجهه چيڪ ڪندا آهن.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // حفاظت: ڇاڪاڻ ته `new_layout.size()` `old_size` کان وڌيڪ يا برابر هجڻ گھرجي ،
            // ٻئي پراڻي ۽ نئين يادگيري واريون واريون `old_size` بائٽس پڙهڻ ۽ لکڻ لاءِ صحيح آهن.
            // انهي کان علاوه ، ڇاڪاڻ ته اڳئين ورهاست کي اڃا تائين نيڪال نه ڪيو ويو آهي ، اهو `new_ptr` مٿان چڙهائي نٿو سگهي.
            // ان ڪري ، ايڪس 00X تي ڪال محفوظ آهي.
            // `dealloc` لاءِ حفاظتي معاهدو ڪال ڪندڙ کي برقرار رکڻ گهرجي.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // حفاظت: `layout` سائيز ۾ غير صفر آهي ،
            // ٻيون حالتون ٻڌائيندڙ کي برقرار رکڻ گهرجي
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // محفوظ: ڪاليندڙ طرفان سڀني شرطن کي برقرار رکيو وڃي
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // محفوظ: ڪاليندڙ طرفان سڀني شرطن کي برقرار رکيو وڃي
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // حفاظت: ڪالرن کي برقرار رکڻ لازمي آهي شرط
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // حفاظت: `new_size` صفر آهي.ٻيون شرطون کي سڏيندڙ کي برقرار رکڻ گهرجي
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` شايد ايڪس ايڪس اين ايڪس يا انهي وانگر ڪجهه چيڪ ڪندا آهن.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // حفاظت: ڇاڪاڻ ته `new_size` `old_layout.size()` کان نن orو يا برابر هجڻ گھرجي ،
            // ٻئي پراڻي ۽ نئين يادگيري واري ترتيب `new_size` بائٽس پڙهڻ ۽ لکڻ لاءِ صحيح آهي.
            // انهي کان علاوه ، ڇاڪاڻ ته اڳئين ورهاست کي اڃا تائين نيڪال نه ڪيو ويو آهي ، اهو `new_ptr` مٿان چڙهائي نٿو سگهي.
            // ان ڪري ، ايڪس 00X تي ڪال محفوظ آهي.
            // `dealloc` لاءِ حفاظتي معاهدو ڪال ڪندڙ کي برقرار رکڻ گهرجي.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// مختص پوائنٽرن لاءِ مختص ڪندڙ.
// ھن فنڪشن کي ٻاھرڻ نه کپي.جيڪڏهن اهو ڪري ٿو ، ايم آءِ آر ڪوڊٽين ناڪام ٿيندي.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// هن دستخط `Box` وانگر ساڳيو هجڻ گهرجي ، ٻي صورت ۾ هڪ ICE ٿي ويندو.
// جڏهن `Box` تي هڪ اضافي پيٽرولر شامل ڪيو ويو آهي (جهڙوڪ `A: Allocator`) ، انهي کي هتي هتي پڻ شامل ڪرڻ گهرجي.
// مثال طور ، جيڪڏهن `Box` کي `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` ۾ تبديل ڪيو وڃي ٿو ، انهي فنڪشن کي پڻ `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` ۾ تبديل ڪرڻو پوندو.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # مختص ڪرڻ غلطي سنڀاليندڙ

extern "Rust" {
    // هي عالمي علامتي غلطي کي سنڀالڻ وارو جادو نشان آهي.
    // rustc ٺاهي ٿو `__rg_oom` انهي کي ڪال ڪرڻ لاءِ جيڪڏهن `#[alloc_error_handler]` آهي ، يا (`__rdl_oom`) هيٺ ڏنل ڊفالٽ پليٽس کي ٻي صورت ۾ سڏڻ لاءِ.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// يادگيري مختص ڪرڻ واري غلطي يا ناڪامي تي ختم ڪريو.
///
/// ياداشت جي مختص ڪيل APIs جي ڪال ڪندڙن کي ڳڻپيوڪر ختم ڪرڻ جي خواهش جي الائننگ جي غلطي جي جواب ۾ هن فنڪشن کي سڏڻ جي همت افزائي ڪئي وئي آهي ، بجاءِ ان جي ته سڌو سنئون `panic!` يا ساڳي طريقي سان.
///
///
/// هن فنڪشن جو طئي ٿيل رويو هڪ پيغام کي معياري غلطي ڏانهن پرنٽ ڪرڻ ۽ عمل کي ختم ڪرڻ آهي.
/// ان کي [`set_alloc_error_hook`] ۽ [`take_alloc_error_hook`] سان مٽائي سگھجي ٿو.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// مختص ٽيسٽ لاءِ `std::alloc::handle_alloc_error` سڌو استعمال ڪري سگھجي ٿو.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // ٺاهيل `__rust_alloc_error_handler` ذريعي سڏ ڪيو ويو

    // جيڪڏهن ڪو `#[alloc_error_handler]` نه آهي
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // جيڪڏهن هڪ ايڪس سيڪس آهي
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// اڳوڻي مختص ٿيل ، غير شروعاتي ياداشت ۾ ڪلون خاص ڪريو.
/// `Box::clone` ۽ `Rc`/`Arc::make_mut` پاران استعمال ٿيل آهي.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // مختص ڪرڻ *پهرين* اجازت ڏئي سگھي ٿو ته اصلاح ڪندڙ کي جڳائي ڪلونڊ ويل ٺاهڻ جي اجازت ڏئي ، مقامي کي ڇڏي وڃڻ ۽ حرڪت ڪري.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // اسان هميشه جڳائي کي ڪاپي ڪري سگهون ٿا ، ڪڏهن به مقامي قدر جي شامل ٿيڻ جي بغير.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}