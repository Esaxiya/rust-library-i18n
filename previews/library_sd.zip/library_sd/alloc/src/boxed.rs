//! هيڪٽر مختص لاءِ پوائنٽر جو قسم.
//!
//! [`Box<T>`], غير معمولي طور تي 'box' جي طور تي حوالو ڏنو ويو آهي ، Rust ۾ ئي هولي جي ورڇ جو آسان فارم مهيا ڪري ٿو.دٻاءُ هن تقسيم جي ملڪيت بڻائيندو آهي ، ۽ جڏهن انهن جي دائري مان نڪري ويندا آهن ته انهن جا مواد ڇڏي ڏين.باڪس پڻ انهي ڳالهه کي يقيني بڻائن ٿيون ته اهي ڪڏهن به `isize::MAX` بائٽس کان وڌيڪ مختص نه ڪنديون آهن.
//!
//! # Examples
//!
//! [`Box`] ٺاھڻ سان اسٽيڪ مان ھڪڙي قدر منتقل ڪريو:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! ھڪڙي [`Box`] کان ھڪڙي قدر واپس منتقل ڪريو [dereferencing] ذريعي اسٽيڪ ڏانھن
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! ٻيهر ٽيڪنالاجي ڊيٽا جو خاڪو ٺاهڻ:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! اهو ڇاپيندو "Cons (1 ، Cons(2, Nil))`.
//!
//! اعصابي اڏاوتون لازمي طور تي باڪس وٺڻ گهرجن ، ڇاڪاڻ ته جيڪڏهن `Cons` جي تعريف هن طرح نظر اچي ها:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! اهو ڪم نه ڪندو.اهو ئي سبب آهي ته هڪ `List` جو اندازو ان انحصار تي آهي ته فهرست ۾ ڪيترا عنصر شامل آهن ، ۽ انهي جي ڪري اسان کي خبر ناهي ته ايڪسڪيڪس لاءِ ڪيتري يادگيري مختص ڪئي وڃي.هڪ [`Box<T>`] متعارف ڪرائڻ سان ، جنهن جو هڪ مخصوص طئه ٿيل آهي ، اسان knowاڻون ٿا ته ڪيترو وڏو `Cons` هجڻ ضروري آهي.
//!
//! # ياداشت جي ترتيب
//!
//! غير صفر وارين قدرن جي لاءِ ، [`Box`] پنهنجي ونڊوز لاءِ [`Global`] مختص ڪندڙ کي استعمال ڪندو.اهو [`Box`] ۽ [`Global`] مختص ڪيل مختص ڪيل خام پوائنٽر جي وچ ۾ ٻئي طريقن کي تبديل ڪرڻ صحيح آهي ، ڏنو ويو ته [`Layout`] مختص ڪندڙ سان استعمال ٿيل قسم جي لاءِ صحيح آهي.
//!
//! وڌيڪ صحيح طور تي ، هڪ `value:*mut T` جيڪو [`Global`] سان مختص ڪيو ويو آهي `Layout::for_value(&* value)` سان گڏ [`Box::<T>::from_raw(value)`] استعمال ڪندي دٻي ۾ تبديل ٿي سگهي ٿو.
//! ٻئي طرف ، [`Box::<T>::into_raw`] کان حاصل ڪيل `value: *mut T` جي يادگيري واري يادگيري X003 سان گڏ [`Global`] مختص ڪندڙ کي ختم ڪيو ويندو.
//!
//! صفر وارين قدرن جي لاء ، `Box` پوائنٽر اڃا تائين [valid] ٿيڻو آهي پڙهڻ ۽ لکڻ لاءِ ۽ ڪافي طور تي قطار ٿيل.
//! خاص طور تي ، ڪو سڌريل اڻ سڌريل صفر عددي انگ کي خام پوائنٽر ڏانهن اڇلائڻ هڪ صحيح پوائنٽر پيدا ڪندو آهي ، پر هڪ پوائنٽر جيڪو اڳ ۾ مختص ڪيل يادگيري ڏانهن اشارو ڪري ٿو جيڪو آزاد ٿيڻ کان پوءِ صحيح نه آهي.
//! ايڪس سي ٽي ايڪس تي باڪس ٺاهڻ جي تجويز ڪيل طريقي ۾ جيڪڏهن `Box::new` استعمال نٿو ڪري سگهجي ايڪس [`ptr::NonNull::dangling`] استعمال ڪرڻ آهي.
//!
//! ايستائين جيستائين `T: Sized` ، هڪ `Box<T>` واحد پوائنٽر طور نمائندگي ڪرڻ جي ضمانت آهي ۽ اي سي آئي سان پڻ اشارو آهي سي پوائنٽرن سان (يعني سي قسم `T*`).
//! ان جو مطلب آهي ته جيڪڏهن توهان جي ٻاهران "C" Rust افعال آهن جيڪي سي کان سڏيا ويندا ، توهان `Box<T>` قسم استعمال ڪندي انهن Rust افعال کي وضاحت ڪري سگھو ٿا ، ۽ سي طرف ساڳئي قسم جي طور تي `T*` استعمال ڪريو.
//! مثال طور ، هن سي هيڊر تي غور ڪيو جيڪو افعال جو اعلان ڪري ٿو جيڪو `Foo` قدر جي ڪجهه قسم کي ٺاهي ۽ تباهه ڪري ٿو:
//!
//! ```c
//! /* سي هيڊر */
//!
//! /* ڪالر کي اونرشپ موٽائيندو آهي */
//! struct Foo* foo_new(void);
//!
//! /* ڪالر کان ملڪيت ورتي وڃي ٿي.جڏهن توهان کي NULL سان سڏيو ويو */
//! void foo_delete(struct Foo*);
//! ```
//!
//! اهي ٻئي ڪم Rust ۾ هيٺيان طريقي سان عمل هيٺ ٿي سگهن ٿا.هتي ، `struct Foo*` قسم سي کان `Box<Foo>` ۾ ترجمو ٿيل آهي ، جيڪو ملڪيت جي رڪاوٽن کي پڪڙي ٿو.
//! اهو به ياد رکجو ته `foo_delete` کي رد ڪرڻ جي قابل دليل Rust ۾ `Option<Box<Foo>>` طور نمائندگي ڪئي وئي آهي ، ڇاڪاڻ ته `Box<Foo>` خالي نٿو ٿي سگهي.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! جيتوڻيڪ `Box<T>` وٽ ساڳي نمائندگي ۽ C ABI هڪ C پوائنٽر وانگر آهي ، انهي جو اهو مطلب ناهي ته توهان هڪ ثالث `T*` کي `Box<T>` ۾ تبديل ڪري سگهو ٿا ۽ شين کي ڪم ڪرڻ جي اميد رکي ٿو.
//! `Box<T>` قيمتون هميشه مڪمل طور تي موافق هونديون ، نون نه اشارو ڪندڙ.ان کان علاوه ، تباهي ڪندڙ `Box<T>` عالمي مختص ڪندڙ سان قدر کي آزاد ڪرڻ جي ڪوشش ڪندو.عام طور تي ، بهترين طريقو صرف اشارو ڏيندڙن لاءِ `Box<T>` استعمال ڪرڻ آهي جيڪو عالمي مختص ڪندڙ کان شروع ٿيو هجي.
//!
//! **اهم.** گهٽ ۾ گهٽ في الحال ، توهان کي `Box<T>` قسم جي افعال جي استعمال کان پاسو ڪرڻ گهرجي جيڪي سي ۾ وضاحت ٿيل آهن پر Rust کان سڏيل آهن.انهن حالتن ۾ ، توهان جئين ممڪن طور تي سڌو سنئون سي قسمن کي ظاهر ڪرڻ گهرجي.
//! `Box<T>` وانگر قسم استعمال ڪندي جتي سي تعريف صرف `T*` استعمال ڪري رهي آهي اڻ behaviorاتل رويي جي ڪري سگھي ٿي ، جئين [rust-lang/unsafe-code-guidelines#198][ucg#198] ۾ بيان ڪيل آهي.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// هيڪٽر مختص لاءِ پوائنٽر جو قسم.
///
/// وڌيڪ لاءِ [module-level documentation](../../std/boxed/index.html) ڏسو.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// هيڪ تي يادگيري مختص ڪري ٿو ۽ پوءِ `x` کي ان ۾ رکي ٿو.
    ///
    /// اهو اصل ۾ مختص نه ڪندو آهي جيڪڏهن `T` زيرو سائيز آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// هڪ نئين باڪس کي غير شروعاتي مواد سان اڏائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// نئون `Box` بنا ڪنهن گانڌي جي مواد سان گڏ ٺاهي ٿو ، ياداشت سان گڏ `0` بائٽس سان ڀريل.
    ///
    ///
    /// هن طريقي جي صحيح ۽ غلط استعمال جي مثالن لاءِ [`MaybeUninit::zeroed`][zeroed] ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// نئون `Pin<Box<T>>` ٺاهي ٿو.
    /// جيڪڏهن `T` ايڪسڪسيمڪس کي لاڳو نٿو ڪري ، `x` ميموري ۾ پئجي ويندو ۽ منتقل ڪرڻ جي قابل ناهي.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// ڳري تي ياداشت کي مختص ڪري ٿو ، `x` کي ھن ۾ رکي ٿو ، غلطي موٽائي ٿو جيڪڏھن مختص ناڪاميان
    ///
    ///
    /// اهو اصل ۾ مختص نه ڪندو آهي جيڪڏهن `T` زيرو سائيز آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// نئين باڪس کي اڏائي اڻ izedاڻيل مواد سان گڏ هپ تي ، واپس آڻيندي هڪ غلطي جيڪڏهن مختص ناڪامياب ٿيندي
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// نئون `Box` نئين ٺاهي وارو مواد تيار ڪري ٿو ، ميموري سان `0` بائٽس سان ڀريل ٿي رهيو آهي
    ///
    ///
    /// هن طريقي جي صحيح ۽ غلط استعمال جي مثالن لاءِ [`MaybeUninit::zeroed`][zeroed] ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// ڏنل مختص ڪيل ۾ يادگيري مختص ڪري ٿو پوءِ `x` کي هن ۾ رکي ٿو.
    ///
    /// اهو اصل ۾ مختص نه ڪندو آهي جيڪڏهن `T` زيرو سائيز آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// ڏنل مختص ڪيل ۾ يادگيري مختص ڪري ٿو ، پوءِ `x` کي هن ۾ رکي ٿو ، غلطي موٽائي ٿو جيڪڏهن مختص ناڪام ٿي وڃي
    ///
    ///
    /// اهو اصل ۾ مختص نه ڪندو آهي جيڪڏهن `T` زيرو سائيز آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// فراهم ٿيل مختص ڪيل ۾ اڻ شروع ٿيندڙ مواد سان هڪ نئون باڪس ٺاهيندو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: preferrap_or_else تي ميچ کي ترجيح ڏيو ڇو ته بندش ڪڏهن ڪڏهن قطار ۾ نه هوندي آهي.
        // اهو ڪوڊ سائيز وڏو ڪري سگهندو.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// هڪ نئين باڪس کي مڪمل ٿيل ڊيلمنٽ ۾ غير مشموله مواد سان گڏ ٺاهي ٿو ، هڪ غلطي موٽائي ٿو جيڪڏهن مختص ناڪام ٿي وڃي
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// هڪ نئون `Box` تعمير ٿيل غير معياري مواد سان ٺاهيل ، ياداشت مختص ڪيل ايڪس ويڪس XT بائٽس سان ڀريل ياداشت سان.
    ///
    ///
    /// هن طريقي جي صحيح ۽ غلط استعمال جي مثالن لاءِ [`MaybeUninit::zeroed`][zeroed] ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: preferrap_or_else تي ميچ کي ترجيح ڏيو ڇو ته بندش ڪڏهن ڪڏهن قطار ۾ نه هوندي آهي.
        // اهو ڪوڊ سائيز وڏو ڪري سگهندو.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// هڪ نئون `Box` تعمير ٿيل غير معياري مواد سان ٺاهيل ، فراهم ڪيل مختص ڪيل `0` بائٽس سان ميموري مڪمل ٿي رهيو آهي ، جيڪڏهن غلطي مختص ٿيندي ته غلطي کي واپس ڪندي ،
    ///
    ///
    /// هن طريقي جي صحيح ۽ غلط استعمال جي مثالن لاءِ [`MaybeUninit::zeroed`][zeroed] ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// نئون `Pin<Box<T, A>>` تعمير ڪندو آهي.
    /// جيڪڏهن `T` ايڪسڪسيمڪس کي لاڳو نٿو ڪري ، `x` ميموري ۾ پئجي ويندو ۽ منتقل ڪرڻ جي قابل ناهي.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// هڪ `Box<T>` هڪ `Box<[T]>` ۾ بدلائي ٿو
    ///
    /// هي ڪانٽريڪشن ڀريو نه ٿو پوي ۽ جڳ ۾ ٿئي ٿو.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// `Box` کي وساري ٿو ، واپسي واري قيمت ڏي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// نئين باڪس ٿيل سلائس کي غير شروعاتي مشمولن سان اڏائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// نئون باڪسس واري ننiceڙي سلائيٽ کي بنا ڪنهن مشڪول جي مواد سان اڏائي ٿو ، يادگيري سان `0` بائٽس سان ڀريل.
    ///
    ///
    /// هن طريقي جي صحيح ۽ غلط استعمال جي مثالن لاءِ [`MaybeUninit::zeroed`][zeroed] ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// هڪ نئين باڪسڊ سلائس کي اڻ izedاڻيل مواد ۾ فراهم ڪيل مختص ڪيل اڏاوت ۾ اڏائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// هڪ نئين باڪسس سلائس کي بناويل مختص ڪيل مواد ۾ بغير شروعاتي شقن جي تعمير ڪري ٿو ، ياداشت کي `0` بائٽس سان ڀرجي پيو.
    ///
    ///
    /// هن طريقي جي صحيح ۽ غلط استعمال جي مثالن لاءِ [`MaybeUninit::zeroed`][zeroed] ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// `Box<T, A>` ۾ تبديل ڪندو آهي.
    ///
    /// # Safety
    ///
    /// جيئن [`MaybeUninit::assume_init`] سان ، اهو ڪالر تي منحصر آهي ته ضمانت ڏي ته قيمت واقعي ابتدائي حالت ۾ آهي.
    ///
    /// انهي کي ڪال ڪندي جڏهن مواد اڃا مڪمل طور تي ابتدائي نه ڪيو وڃي فوري طور تي اڻ سڌريل رويو ٺاهيندي.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// `Box<[T], A>` ۾ تبديل ڪندو آهي.
    ///
    /// # Safety
    ///
    /// جيئن [`MaybeUninit::assume_init`] سان ، اهو ڪالر تي منحصر آهي انهي جي ضمانت ڏي ته اقدار واقعي ابتدائي حالت ۾ آهن.
    ///
    /// انهي کي ڪال ڪندي جڏهن مواد اڃا مڪمل طور تي ابتدائي نه ڪيو وڃي فوري طور تي اڻ سڌريل رويو ٺاهيندي.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// هڪ خام پوائنٽر کان باڪس ٺاهي ٿو.
    ///
    /// انهي فنڪشن کي ڪال ڪرڻ بعد ، خام پوائنٽر نتيجو `Box` جي ملڪيت آهي.
    /// خاص طور تي ، `Box` تباهي وارو `T` جي تباهي واري سڏ کي سڏيندو ۽ مختص ڪيل يادگيري کي آزاد ڪندو.
    /// انهي کي محفوظ رهڻ لاءِ ، ياداشت کي `Box` پاران استعمال ڪيل [memory layout] جي مطابق مختص ڪيو وڃي ها.
    ///
    ///
    /// # Safety
    ///
    /// اها فنڪشن غير محفوظ آهي ڇاڪاڻ ته غلط استعمال سان يادگيري جا مسئلا پيدا ٿي سگھن ٿا.
    /// مثال طور ، هڪ ٻه ڀيرا آزاد ٿي سگھي ٿو جيڪڏهن ساڳي ساڳئي پوائنٽر تي فنڪشن کي ٻه ڀيرا سڏيو وڃي.
    ///
    /// [memory layout] سيڪشن ۾ حفاظت جي حالت بيان ڪئي وئي آهي.
    ///
    /// # Examples
    ///
    /// اي `Box` ٻيهر ٺاهيو جنهن کي [`Box::into_raw`] استعمال ڪندي اڳ ۾ هڪ خام پوائنٽر ۾ تبديل ڪيو ويو:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// دستي طور تي ايڪس اوٽ ايڪس ٺاهيو ايڪس آرڪس کي مختص ڪرڻ سان ، عالمي مختص ڪندڙ استعمال ڪندي:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // عام طور تي .write کي X002 جي اڳوڻي مواد (uninitialized) کي خراب ڪرڻ جي ڪوشش کان پاسو ڪرڻ جي ضرورت آهي ، جيتوڻيڪ هن سادي نموني جي لاءِ `*ptr = 5` به ڪم ڪري ها.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// ڏنل مختص ڪيل خام پوائنٽر کان هڪ باڪس ٺاهي ٿو.
    ///
    /// انهي فنڪشن کي ڪال ڪرڻ بعد ، خام پوائنٽر نتيجو `Box` جي ملڪيت آهي.
    /// خاص طور تي ، `Box` تباهي وارو `T` جي تباهي واري سڏ کي سڏيندو ۽ مختص ڪيل يادگيري کي آزاد ڪندو.
    /// انهي کي محفوظ رهڻ لاءِ ، ياداشت کي `Box` پاران استعمال ڪيل [memory layout] جي مطابق مختص ڪيو وڃي ها.
    ///
    ///
    /// # Safety
    ///
    /// اها فنڪشن غير محفوظ آهي ڇاڪاڻ ته غلط استعمال سان يادگيري جا مسئلا پيدا ٿي سگھن ٿا.
    /// مثال طور ، هڪ ٻه ڀيرا آزاد ٿي سگھي ٿو جيڪڏهن ساڳي ساڳئي پوائنٽر تي فنڪشن کي ٻه ڀيرا سڏيو وڃي.
    ///
    /// # Examples
    ///
    /// اي `Box` ٻيهر ٺاهيو جنهن کي [`Box::into_raw_with_allocator`] استعمال ڪندي اڳ ۾ هڪ خام پوائنٽر ۾ تبديل ڪيو ويو:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// دستي طور تي سسٽم مختص ڪندي استعمال ڪندي هڪ `Box` خرچي کان ٺاهي:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // عام طور تي .write کي X002 جي اڳوڻي مواد (uninitialized) کي خراب ڪرڻ جي ڪوشش کان پاسو ڪرڻ جي ضرورت آهي ، جيتوڻيڪ هن سادي نموني جي لاءِ `*ptr = 5` به ڪم ڪري ها.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// `Box` کي کائيندو آھي ، ھڪڙي واپسي ٿيل خام پوائنٽر کي.
    ///
    /// پوائنٽر صحيح طرح سان هلي ويندي ۽ غير خالي.
    ///
    /// انهي فنڪشن کي ڪال ڪرڻ کان پوءِ ، ڪال ڪندڙ اڳيئي `Box` طرفان ياداشت لاءِ ذميوار آهي.
    /// خاص طور تي ، ڪال ڪندڙ کي `T` کي صحيح طور تي تباهه ڪرڻ گهرجي ۽ ياداشت کي آزاد ڪرڻ گهرجي ، [memory layout] کي استعمال ڪندي `Box` کي نظر ۾ رکڻ.
    /// انهي کي آسان ڪرڻ جو طريقو اهو آهي ته خام پوائنٽر کي واپس `Box` ۾ [`Box::from_raw`] فنڪشن سان تبديل ڪيو وڃي ، `Box` تباهي ڪندڙ کي صفائي جي اجازت ڏي.
    ///
    ///
    /// Note: اھو ھڪڙي ڳن functionيل فنڪشن آھي ، جنھن جو مطلب آھي توھان کي ان کي `Box::into_raw(b)` جي بدران `Box::into_raw(b)` سڏڻو آھي.
    /// اهو ائين آهي ته ان صورت ۾ اندروني قسم تي هڪ طريقي سان ڪو تڪرار ناهي.
    ///
    /// # Examples
    /// خودڪار صاف ڪرڻ لاءِ خام پوائنٽر کي `Box` [`Box::from_raw`] سان واپس ۾ تبديل ڪرڻ:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// دستي طور تي تباهه ڪندڙ واضح طور تي هلائيندڙ ۽ ياداشت کي ختم ڪرڻ سان:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// `Box` کي ضايع ڪري ٿو ، واپسي واري خام پوائنٽر ۽ مختص ڪندڙ کي واپس آڻيندي.
    ///
    /// پوائنٽر صحيح طرح سان هلي ويندي ۽ غير خالي.
    ///
    /// انهي فنڪشن کي ڪال ڪرڻ کان پوءِ ، ڪال ڪندڙ اڳيئي `Box` طرفان ياداشت لاءِ ذميوار آهي.
    /// خاص طور تي ، ڪال ڪندڙ کي `T` کي صحيح طور تي تباهه ڪرڻ گهرجي ۽ ياداشت کي آزاد ڪرڻ گهرجي ، [memory layout] کي استعمال ڪندي `Box` کي نظر ۾ رکڻ.
    /// انهي کي آسان ڪرڻ جو طريقو اهو آهي ته خام پوائنٽر کي واپس `Box` ۾ [`Box::from_raw_in`] فنڪشن سان تبديل ڪيو وڃي ، `Box` تباهه ڪندڙ کي صفائي جي اجازت ڏي.
    ///
    ///
    /// Note: اھو ھڪڙي ڳن functionيل فنڪشن آھي ، جنھن جو مطلب آھي توھان کي ان کي `Box::into_raw_with_allocator(b)` جي بدران `Box::into_raw_with_allocator(b)` سڏڻو آھي.
    /// اهو ائين آهي ته ان صورت ۾ اندروني قسم تي هڪ طريقي سان ڪو تڪرار ناهي.
    ///
    /// # Examples
    /// خودڪار صاف ڪرڻ لاءِ خام پوائنٽر کي `Box` [`Box::from_raw_in`] سان واپس ۾ تبديل ڪرڻ:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// دستي طور تي تباهه ڪندڙ واضح طور تي هلائيندڙ ۽ ياداشت کي ختم ڪرڻ سان:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // دٻو اسٽيڪ بورڊ طرفان "unique pointer" طور سڃاتو وڃي ٿو ، پر اندروني طور تي اھو نظام نظام لاءِ خام پوائنٽر آھي.
        // انهي کي سڌو طور تي هڪ خام پوائنٽر ۾ تبديل ڪرڻ ان کي تسليم نه ڪيو ويندو "releasing" ڌار پوائنٽر کي ڌار ٿيل خام رسائي جي اجازت ڏيڻ جي ڪري ، انهي ڪري سڀني خام پوائنٽر طريقن کي `Box::leak` ذريعي وڃڻو آهي.
        //
        // رخ *ته* ھڪڙي خام پوائنٽر ڏانھن صحيح طريقي سان ھلندو آھي.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// ھيٺ ڏنل مختص ڪندڙ جو حوالو ڏئي ٿو.
    ///
    /// Note: اھو ھڪڙي ڳن functionيل فنڪشن آھي ، جنھن جو مطلب آھي توھان کي ان کي `Box::allocator(&b)` جي بدران `Box::allocator(&b)` سڏڻو آھي.
    /// اهو ائين آهي ته ان صورت ۾ اندروني قسم تي هڪ طريقي سان ڪو تڪرار ناهي.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// ضايع ٿيل `Box` واپس ڪندي ، `Box` کي ختم ڪري ڇڏيندو ۽ لڪائي ٿو ، `&'a mut T`.
    /// ياد رکجو ته قسم `T` چونڊيل لائفائم `'a` کان اڳ رهڻ گھرجي.
    /// جيڪڏهن قسم کي صرف جامد حوالا آهن ، يا هر ڪنهن سان نه ، پوءِ اهو چونڊ ٿي سگھي ٿو ايڪسائيڪس.
    ///
    /// اهو فنڪشن گهڻو ڪري ڊيٽا لاءِ ڪارائتو آهي جيڪو پروگرام جي باقي زندگي تائين جيئرو آهي.
    /// واپسي ريفرنس کي ڇڏڻ هڪ ياداشت لڪي ٿو.
    /// جيڪڏهن اهو قابل قبول نه آهي ، حوالو پهريون ڀيرو [`Box::from_raw`] فنڪشن سان `Box` پيدا ڪندي wrappedڪيل هجڻ گهرجي.
    ///
    /// انهي `Box` کي پوءِ ڇڏي سگھجي ٿو جيڪو `T` کي صحيح طور تباهه ڪندو ۽ مختص ڪيل يادگيري کي آزاد ڪندو.
    ///
    /// Note: اھو ھڪڙي ڳن functionيل فنڪشن آھي ، جنھن جو مطلب آھي توھان کي ان کي `Box::leak(b)` جي بدران `Box::leak(b)` سڏڻو آھي.
    /// اهو ائين آهي ته ان صورت ۾ اندروني قسم تي هڪ طريقي سان ڪو تڪرار ناهي.
    ///
    /// # Examples
    ///
    /// سادو استعمال
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// اڻ سڌريل ڊيٽا:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// هڪ `Box<T>` هڪ `Pin<Box<T>>` ۾ بدلائي ٿو
    ///
    /// هي ڪانٽريڪشن ڀريو نه ٿو پوي ۽ جڳ ۾ ٿئي ٿو.
    ///
    /// اهو پڻ [`From`] ذريعي دستياب آهي.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // اهو `Pin<Box<T>>` جي پٺي کي مٽائڻ يا مٽائڻ ممڪن ناهي جڏهن `T: !Unpin` ، تنهنڪري اهو بغير ڪنهن اضافي گهرج کانسواءِ سڌو سنئون پن کي محفوظ ڪرڻ.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: ڪجھ به نه ڪر ، في الحال مرتب ڪندڙ انجام ڏنو آهي.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// `Box<T>` ٺاهي ٿو ، `Default` قدر سان ٽي لاءِ.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// ھن باڪس جي مواد واري `clone()` سان ھڪ نئون باڪس موٽائيندو آھي.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // ويليو ساڳيو آهي
    /// assert_eq!(x, y);
    ///
    /// // پر اهي منفرد شيون آهن
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // اڳ-مختص ٿيل ياداشت کي ڪلون ويل جي قيمت سڌي طرح لکڻ جي اجازت ڏي.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// `self` جي مواد کي نقل ڪري ٿو بغير نئون مختص ڪرڻ کان.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // ويليو ساڳيو آهي
    /// assert_eq!(x, y);
    ///
    /// // ۽ ڪوبه مختص ناهي ٿيو
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // هي ڊيٽا جي ڪاپي ڪندو آهي
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// هڪ عام قسم جي `T` کي `Box<T>` ۾ بدلائي ٿو
    ///
    /// theيرائڻ وارو ذخيرو مختص ڪري ٿو ۽ ايڪس اسٽي ايڪس کي اسٽيڪ کان ان ۾ منتقل ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// هڪ `Box<T>` هڪ `Pin<Box<T>>` ۾ بدلائي ٿو
    ///
    /// هي ڪانٽريڪشن ڀريو نه ٿو پوي ۽ جڳ ۾ ٿئي ٿو.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// هڪ `&[T]` هڪ `Box<[T]>` ۾ بدلائي ٿو
    ///
    /// اها تبديلي ڊيل تي مختص آهي ۽ ايڪس ايڪس ايڪس جي ڪاپي انجام ڏئي ٿي.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // ٺاھيو ھڪڙو&[u8] جيڪو باڪس ٺاھڻ ۾ استعمال ٿيندو <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// هڪ `&str` هڪ `Box<str>` ۾ بدلائي ٿو
    ///
    /// اها تبديلي ڊيل تي مختص ڪري ٿي ۽ ايڪس X00 ڪاپي کي انجام ڏئي ٿي.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// هڪ `Box<str>` هڪ `Box<[u8]>` ۾ بدلائي ٿو
    /// هي ڪانٽريڪشن ڀريو نه ٿو پوي ۽ جڳ ۾ ٿئي ٿو.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // دٻو ٺاهيو<str>جيڪو باڪس ٺاهڻ لاءِ استعمال ٿيندو <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // ٺاھيو ھڪڙو&[u8] جيڪو باڪس ٺاھڻ ۾ استعمال ٿيندو <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// هڪ `[T; N]` هڪ `Box<[T]>` ۾ بدلائي ٿو
    /// هي تبادلو صف کي نئين هٽائي ڇڏيل ياداشت ڏانهن منتقل ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// دٻي کي ڪنڪريٽ ڪرڻ واري قسم جي هيٺان ڇڏڻ جي ڪوشش ڪئي ويندي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// دٻي کي ڪنڪريٽ ڪرڻ واري قسم جي هيٺان ڇڏڻ جي ڪوشش ڪئي ويندي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// دٻي کي ڪنڪريٽ ڪرڻ واري قسم جي هيٺان ڇڏڻ جي ڪوشش ڪئي ويندي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // اهو ممڪن ناهي ته اندروني بڪ کي سڌو سنئون دٻي مان ڪ ،ي ، ان جي بدران اسان ان کي * ڪنسٽ ڏانهن اڇلائي ڇڏيون ٿا جيڪو انوکي کي غيرقانوني بڻائي ٿو
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// ڊيزرن لاء اسپيشلائزيشن جيڪا `last()` جو ڊفالٽ جي بدران آءِ جي لاڳو ٿيندي آهي.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}