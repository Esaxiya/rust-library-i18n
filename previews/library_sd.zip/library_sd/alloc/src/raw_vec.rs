#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// نئين يادگيري جو مواد غير ابتدائي آهي.
    Uninitialized,
    /// نئين يادگيري صفر ٿيڻ جي ضمانت آهي.
    Zeroed,
}

/// وڌيڪ ergonomically مختص ڪرڻ ، ٻيهر مختص ڪرڻ ، ۽ بفر جي ميموري کي ختم ڪرڻ لاءِ گهٽ سطح جي افاديت سڀني ڪنڊ ڪڙڇن جي معاملن بابت پريشان ٿيڻ کان سواءِ.
///
/// هي قسم پنهنجي ڊيٽا جي اڏاوتن وانگر Vec ۽ VecDeque تعمير ڪرڻ لاءِ بهترين آهي.
/// خاص طور تي:
///
/// * صفر سيز جي قسمن تي `Unique::dangling()` ٺاهي ٿو.
/// * زيرو ڊگري مختصن تي `Unique::dangling()` ٺاهي ٿو.
/// * ايڪسڪسيمڪس کي آزاد ڪرڻ کان بچائي ٿو.
/// * گنجائش جي حساب سان سڀ اوور فلوز پڪڙي ٿو (انهن کي "capacity overflow" panics تي ترقي ڏي ٿو).
/// * 32-bit نظام کان وڌيڪ isize::MAX بائٽس کي مختص ڪرڻ خلاف محافظ.
/// * توهان جي ڊيگھ کي وڌيڪ ختم ڪرڻ جي خلاف گارڊ.
/// * ناڪام مختص ڪيل `handle_alloc_error` کي سڏيندو آهي.
/// * `ptr::Unique` تي مشتمل آهي ۽ انهي ڪري صارف کي هر لاڳاپيل فائدا ڏئي ٿي.
/// * سڀ کان وڏي گنجائش استعمال ڪرڻ لاءِ مختص ڪيل کان واپس ورتل رقم استعمال ڪندو آهي.
///
/// اهو قسم ڪنهن به طرح يادداشت جو معائنو نٿو ڪري ته اهو منظم آهي.جڏهن ان کي ڇڏيو ـ *ان جي يادگيري کي آزاد ڪندو ، پر* اهو * پنهنجي مواد ڇڏڻ جي ڪوشش نه ڪندو.
/// اهو `RawVec` جي صارف تي منحصر آهي ، اصل شين کي سنڀالڻ * *`RawVec` جي اندر * ذخيرو.
///
/// نوٽ ڪريو ته صفر-سائز جا اضافي قسم هميشه لا محدود هوندا آهن ، تنهن ڪري `capacity()` هميشه `usize::MAX` موٽائي ٿو.
/// هن جو مطلب آهي ته توهان کي `Box<[T]>` سان هن قسم جي گول ٽرپنگ ڪرڻ وقت محتاط هجڻ جي ضرورت آهي ، ڇاڪاڻ ته `capacity()` ڊيگهه نه ڏيندو.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): اهو موجود آهي ڇاڪاڻ ته `#[unstable]` ڪنسٽن کي `min_const_fn` مطابق نه هجڻ گهرجي ۽ انهي ڪري انهن کي "من_ ڪنسٽ_فن" ۾ نٿو سڏيو وڃي.
    ///
    /// جيڪڏهن توهان `RawVec<T>::new` يا انحصار تبديل ڪيو ٿا ، مهرباني ڪري ڪنهن به شيءِ کي متعارف ڪرائڻ جو خيال رکجو جيڪو واقعي ۾ `min_const_fn` جي خلاف ورزي ڪندو.
    ///
    /// NOTE: اسان هاڪ کان بچي سگھون ٿا ۽ ڪجهه `#[rustc_force_min_const_fn]` وصف سان مطابقت کي جانچيون ٿا جيڪو `min_const_fn` سان مطابقت جي ضرورت آهي پر لازمي طور تي اهو `stable(...) const fn`/ڪال ڪوڊ ۾ ڪال ڪرڻ جي اجازت نٿو ڏي. `foo` کي فعال ڪرڻ نه جڏهن `#[rustc_const_unstable(feature = "foo", issue = "01234")]` موجود آهي.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// مختص ڪرڻ کان بغير سڀ کان وڏي ممڪن `RawVec` (سسٽم هيپ تي) ٺاهي ٿو.
    /// جيڪڏهن `T` وٽ صحيح سائز آهي ، ته اهو `RawVec` جي گنجائش رکي ٿو `0`.
    /// جيڪڏهن `T` زيرو سائيز آهي ، پوء اها گنجائش `usize::MAX` سان `RawVec` ٺاهي ٿي.
    /// دير واري مختص ڪرڻ کي لاڳو ڪرڻ لاءِ ڪارآمد.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `[T; capacity]` (سسٽم ڪوپ تي) بنائي ٿو بلڪل ھڪڙو `[T; capacity]` لاءِ ظرفيت ۽ ترتيب جي تقاضائن سان.
    /// اهو ڪال ڪرڻ برابر آهي `RawVec::new` جڏهن `capacity` `0` آهي يا `T` صفر آهي.
    /// ياد رکو ته جيڪڏهن `T` زيرو سائيز آهي ته ان جو مطلب آهي ته توهان *X* X حاصل نه ڪندا.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن درخواست ٿيل گنجائش `isize::MAX` بائٽس کان وڌي وڃي.
    ///
    /// # Aborts
    ///
    /// OOM تي خاتمو.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// ايڪسڪسيمڪس وانگر ، پر انهي جي ضمانت بفر صفر آهي.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// پوائنٽر ۽ گنجائش مان `RawVec` کي بحال ڪري ٿو.
    ///
    /// # Safety
    ///
    /// `ptr` لازمي مختص ڪيو وڃي (سسٽم جي ڪوپ تي) ، ۽ ڏنل `capacity` سان.
    /// ايڪس `capacity``isize::MAX` کان وڌيڪ نه ٿو وڌائي سگھي ٿو سائيز وارين قسمن لاء.(صرف 32 بٽ سسٽم تي هڪ پريشاني آهي).
    /// ZST vectors وٽ `usize::MAX` تائين گنجائش ٿي سگھي ٿي.
    /// جيڪڏهن `ptr` ۽ `capacity` هڪ `RawVec` کان اچن ٿا ، ته انهي جي ضمانت آهي.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // ٽئني ويڪس گونگا آهن.ڇڏي ڏيو
    // - 8 جيڪڏهن عنصر سائيز 1 آهي ، ڇاڪاڻ ته ڪو به تپش وارو مختصرن گهٽ ۾ گهٽ 8 بائٽس کان گهٽ 8 بائٽس جي درخواست کي گهمڻ جو امڪان آهي.
    //
    // - 4 جيڪڏهن عناصر وچولي قد وارا هوندا آهن (<=1 ڪي بي)
    // - 1 ٻي صورت ۾ ، تمام نن shortو Vecs لاءِ تمام گھڻو جڳھ ضايع ٿيڻ کان بچڻ لاءِ.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// پسند ڪريو `new` ، پر واپس موٽائي `RawVec` لاءِ مختص ڪندڙ جي چونڊ تي ڀروسو رکي ٿو.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` مطلب "unallocated".صفر واري قسم جي شين کي نظرانداز ڪيو ويو آهي.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// پسند ڪريو `with_capacity` ، پر واپس موٽائي `RawVec` لاءِ مختص ڪندڙ جي چونڊ تي ڀروسو رکي ٿو.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// پسند ڪريو `with_capacity_zeroed` ، پر واپس موٽائي `RawVec` لاءِ مختص ڪندڙ جي چونڊ تي ڀروسو رکي ٿو.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// هڪ `Box<[T]>` هڪ `RawVec<T>` ۾ بدلائي ٿو.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// تبديل ٿيل پوري بفر کي `Box<[MaybeUninit<T>]>` ۾ بيان ٿيل `len` سان.
    ///
    /// نوٽ ڪريو ته اهو ٺيڪ طريقي سان ٻيهر ايڪس سي ايڪس ايڪس تبديليون کي ٻيهر بحال ڪندو جيڪو شايد ڪيو ويو آهي.(تفصيل لاءِ قسم جي وضاحت ڏسو.)
    ///
    /// # Safety
    ///
    /// * `len` لازمي طور تي تمام گھڻي طلب جي صلاحيت کان وڌيڪ يا برابر هجڻ گھرجي ، ۽
    /// * `len` `self.capacity()` کان گھٽ يا برابر ھئڻ گھرجي.
    ///
    /// ياد رهي ، اها درخواست ڪيل گنجائش ۽ `self.capacity()` مختلف ٿي سگھن ٿا ، جئين هڪ مختص ڪندڙ مجموعي طور تي درخواست ڪري سگهي ٿو ۽ درخواست کان وڌيڪ ميموري بلاڪ واپس ڪري سگهي ٿو.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // سانت جانچ پڙتال جي حفاظت جي هڪ اڌ ضرورت (اسان ٻئي اڌ جي چڪاس نٿا ڪري سگھون).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // اسان `unwrap_or_else` کان پاسو ڪندا آهيون ڇاڪاڻ ته اهو ٺاهيل ايل ايل وي ايم آر جي رقم کي ڌڪايو آهي.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// پوائنٽر ، گنجائش ۽ مختص ڪرڻ واري اي `RawVec` جي بحالي.
    ///
    /// # Safety
    ///
    /// `ptr` لازمي مختص ڪيو وڃي (ڏنل مختص ڪيل `alloc` ذريعي) ، ۽ ڏنل `capacity` سان.
    /// ايڪس `capacity``isize::MAX` کان وڌيڪ نه ٿو وڌائي سگھي ٿو سائيز وارين قسمن لاء.
    /// (صرف 32 بٽ سسٽم تي هڪ پريشاني آهي).
    /// ZST vectors وٽ `usize::MAX` تائين گنجائش ٿي سگھي ٿي.
    /// جيڪڏهن `ptr` ۽ `capacity` `alloc` ذريعي ٺاهيل `RawVec` کان اچن ٿا ، انهي جي ضمانت آهي.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// مختص ٿيڻ جي شروعات ۾ هڪ خام پوائنٽر حاصل ڪري ٿو.
    /// نوٽ ڪريو ته ھي `Unique::dangling()` آھي جيڪڏھن `capacity == 0` يا `T` زيرو سائيز آھي.
    /// اڳوڻي صورت ۾ ، توهان کي محتاط هجڻ گهرجي.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// مختص ڪرڻ جي صلاحيت حاصل ڪري ٿو.
    ///
    /// اهو سدائين `usize::MAX` ٿيندو جيڪڏهن `T` زيرو سائيز آهي.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// هن `RawVec` جي پٺڀرائي ڪندڙ مختص ڪيل شيئر جي هڪ واپسي واري حوالي ڏانهن واپسي آهي.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // اسان وٽ ياداشت لاءِ مختص ٿيل حصو آهي ، تنهن ڪري اسان پنهنجو موجوده ترتيب حاصل ڪرڻ لاءِ رن ٽائيم چيڪن کي بائي پاس ڪري سگهون ٿا.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// انهي کي يقيني بڻائي ٿو ته بفر ۾ گهٽ ۾ گهٽ ڪافي جڳهه موجود آهي `len + additional` عناصر رکڻ.
    /// جيڪڏھن اھو اڳ ئي ڪافي جڳھ ڪونھي ، ڪافي جڳھ کي مختص ڪندو ۽ آرامده سھولت حاصل ڪرڻ لاءِ عمودي *O*(1) رويي.
    ///
    /// ھن رويي کي محدود ڪندو جيڪڏھن اھو پاڻ کي اڻ گهربل طور panic سبب ڪري ڇڏيندو.
    ///
    /// جيڪڏهن `len` `self.capacity()` کان وڌيڪ آهي ، اهو شايد اصل ۾ گهربل جاءِ مختص ڪرڻ ۾ ناڪام ٿي سگهي ٿو.
    /// هي واقعي محفوظ نه آهي ، پر غير محفوظ ڪوڊ *توهان* لکو ٿا جيڪو انهي فعل جي رويي تي ڀروسو ڪري سگهي ٿو.
    ///
    /// هي `extend` وانگر وڏي تعداد ۾ آپريشن لاڳو ڪرڻ لاءِ مثالي آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن نئين گنجائش `isize::MAX` بائٽس کان وڌي وڃي ٿي.
    ///
    /// # Aborts
    ///
    /// OOM تي خاتمو.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // رزرو ختم ڪيو وڃي ها يا ڊ ifي ها ته لين ايڪسڪسيمڪس کان وڌي چڪو هو تنهنڪري اهو محفوظ نه هاڻي محفوظ ڪرڻ جي ڪوشش ڪري ٿو.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// ساڳيو `reserve` ساڳيو ، پر ڇڪڻ يا ختم ٿيڻ بدران غلطيون موٽائي ٿو.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// انهي کي يقيني بڻائي ٿو ته بفر ۾ گهٽ ۾ گهٽ ڪافي جڳهه موجود آهي `len + additional` عناصر رکڻ.
    /// جيڪڏهن اهو پهريان ئي ناهي ، ياداشت جي گهٽ ۾ گهٽ ممڪن مقدار کي بحال ڪري سگهندو.
    /// عام طور تي اهو صحيح طور تي يادگيري جي مقدار جيترو هوندو ، پر اصول ۾ مختص ڪندڙ اسان کان جيڪو ڪجهه گھربل آهي اها واپس ڏيڻ لاءِ آزاد آهي.
    ///
    ///
    /// جيڪڏهن `len` `self.capacity()` کان وڌيڪ آهي ، اهو شايد اصل ۾ گهربل جاءِ مختص ڪرڻ ۾ ناڪام ٿي سگهي ٿو.
    /// هي واقعي محفوظ نه آهي ، پر غير محفوظ ڪوڊ *توهان* لکو ٿا جيڪو انهي فعل جي رويي تي ڀروسو ڪري سگهي ٿو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن نئين گنجائش `isize::MAX` بائٽس کان وڌي وڃي ٿي.
    ///
    /// # Aborts
    ///
    /// OOM تي خاتمو.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// ساڳيو `reserve_exact` ساڳيو ، پر ڇڪڻ يا ختم ٿيڻ بدران غلطيون موٽائي ٿو.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// مختص ڪيل رقم کي مختص ڪريو گھٽائي ٿو.
    /// جيڪڏهن ڏنل رقم 0 آهي ، ته اصل ۾ مڪمل طور ختم ڪري ڇڏي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن ڏنو ويو موجوده مقدار کان *وڏو* آهي.
    ///
    /// # Aborts
    ///
    /// OOM تي خاتمو.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// ورجائي ٿو جيڪڏھن بفر گھربل ضرورت پوڻ جي اضافي ضرورت کي پورو ڪرڻ لاءِ.
    /// بنيادي طور تي ايڪس آرڪس کي ان لائن ڪرڻ کان بغير ان لائننگ ريزرو ڪالز کي ممڪن بڻائي ٿو.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // اهو طريقو عام طور تي ڪيترن ئي دفعا شروع ڪيو ويو آهي.تنهنڪري اسين چاهيون ٿا ته اهو جيترو نن smallو هجي ، مرتب ٿيندڙ وقتن کي بهتر بنائي.
    // پر اسان پڻ چاهيندا آهيون ته انهي جو تمام گهڻو مواد جيترو ممڪن طور تي ڳڻتي جوڳو هجي ، پيدا ڪيل ڪوڊ کي گهڻي تيز هلائڻ جي لاءِ.
    // تنهن ڪري ، هي طريقو احتياط سان لکيو وڃي ٿو ته اهو س codeو ڪوڊ جيڪو `T` تي ڀاڙيندو آهي ان جي اندر آهي ، جڏهن ته جيترو ڪوڊ `T` تي ڀروسو نٿو رکي اهو افعال ۾ آهي جيڪي `T` کان وڌيڪ غير عام آهن.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // اهو ڪالوني حوالن سان يقيني آهي.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // جئين اسان `usize::MAX` جي گنجائش واپس آڻينداسين جڏهن `elem_size` آهي
            // 0 ، ھتي حاصل ڪرڻ لازمي طور تي `RawVec` ختم ٿيڻ وارو آھي.
            return Err(CapacityOverflow);
        }

        // ڪجھ به نه ته اسان انهن چيڪن بابت واقعي ڪري سگهون ٿا ، بدقسمتي سان.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // اهو غير معمولي ترقي جي ضمانت ڏئي ٿو.
        // ٻٻر ختم نه ٿي ڪري سگهي ، ڇاڪاڻ ته `cap <= isize::MAX` ۽ `cap` جو قسم `usize` آهي.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` کان وڌيڪ غير عام آهي.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // هن طريقي تي رڪاوٽون ساڳيون ئي آهن ، جيڪي `grow_amortized` تي آهن ، پر اهو طريقو عام طور تي گهٽ ۾ گهٽ استعمال ڪيو ويندو آهي ، تنهن ڪري اهو گهٽ نازڪ آهي.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // جئين اسان ايڪس ايڪسڪس جي گنجائش واپس آڻينداسين جڏهن قسم جي شڪل هوندي آهي
            // 0 ، ھتي حاصل ڪرڻ لازمي طور تي `RawVec` ختم ٿيڻ وارو آھي.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T` کان وڌيڪ غير عام آهي.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// اهو فنڪشن ايڪس آر ايڪس کان ٻاهر آهي وقت گهٽائڻ جو تعداد گھٽائڻ.تفصيل لاءِ `RawVec::grow_amortized` کان مٿي ڏنل تبصرو ڏسو.
// (`A` پيٽرولر اھم ناھي ، ڇاڪاڻ ته عملي طور ڏٺو ويو مختلف `A` قسمن جو تعداد `T` قسمن جي تعداد کان تمام گھٽ آھي.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // ايڪس ايڪس ايڪس جي قد کي گھٽ ڪرڻ جي لاءِ هتي غلطي جي چڪاس ڪريو.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // مختصار برابر ڪرڻ واري مساوات لاءِ چيڪ ڪندو آهي
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec`*جي ملڪيت کي ڇڏي ٿو بغير* ان جي مواد کي ڇڏڻ جي ڪوشش جي.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// رزرو جي غلطي کي هٿي ڏيڻ لاءِ مرڪزي ڪم.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// اسان کي ھيٺ ڏنل ضمانت ڏيڻ جي ضرورت آھي.
// * اسان ڪڏهن به `> isize::MAX` بائيٽ سائيز شين کي مختص نه ڪندا آهيون.
// * اسان `usize::MAX` کي اوور فلو نه ٿا ڪريون ۽ اصل ۾ تمام گهٽ مختص ڪريو.
//
// 64-bit تي اسان کي صرف اوور فلو کي چڪاسڻ جي ضرورت آهي جڏهن کان `> isize::MAX` بائٽس مختص ڪرڻ جي ڪوشش ٿيندي ضرور ناڪام ٿيندي.
// 32-bit ۽ 16-bit تي اسان کي انهي لاءِ اضافي گارڊ شامل ڪرڻ جي ضرورت آهي انهي صورت ۾ اسان هڪ پليٽ فارم تي هلون ٿا جيڪو صارف جي جڳهه تي سڀني 4GB استعمال ڪري سگهي ٿو ، مثال طور ، PAE يا x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// هڪ مرڪزي ڪم ذميواري جي رپورٽ جي ذميواري وڌيڪ گهڙي وئي.
// انهي کي يقيني بڻائي سگهندي ته انهن panics سان لاڳاپيل ڪوڊ پيدائش گهٽ ۾ گهٽ آهي ڇو ته هتي رڳو هڪ ئي جڳهه آهي جنهن س Zي ماڊل ۾ هڪ گولي بجاءِ panics.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}