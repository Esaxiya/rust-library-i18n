use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// عارضي طور تي ساڳي حد تائين هڪ ٻئي ، غير متغير مساوات کي ڪ takesي ٿو.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// وڻ ۾ مخصوص حد کي ڌار ڪندي الڳ پنن جا کنڀا لڀي ٿو.
    /// ساڳئي وڻ ۾ يا خالي اختيارن جو هڪ جوڙو موٽائي ٿو يا وري مختلف هٿن واري جوڙي کي واپس ڏئي ٿو.
    ///
    /// # Safety
    ///
    /// جيستائين `BorrowType` `Immut` هوندو ، ساڳيا ڪي وي کي ٻه دفعا ڏسڻ لاءِ ٻهراڙي وارو هٿ استعمال نٿا ڪريو.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge() ، root2.last_leaf_edge())` جي برابر پر پر وڌيڪ موثر.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// وڻ ۾ ھڪڙي حد تائين محدود حد بندي جو پاسو ٺاھي ٿو.
    ///
    /// نتيجو صرف معنيٰ وارو آهي جيڪڏهن وڻ کي ڪنڊ ذريعي آرڊر ڪيو ويو آهي ، جهڙوڪ ايڪس ايڪس ايڪس ۾ وڻ وانگر آهي.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // حفاظت: اسان جي قرضن جو قسم بي بدل آهي.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// پنن جي ڪنڊن جي جوڙي کي ڳولي ٿو هڪ مڪمل وڻ کي محدود ڪري ٿو.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// uniqueرج جي ڌار ڌار جڳهن کي جوڙي جي ڌار ڌار حدن ۾ ورهائي ڇڏڻ.
    /// نتيجو (some) ميوٽيشن کي اجازت ڏيڻ وارا غير منفرد حوالا آهن ، جن کي احتياط سان استعمال ڪرڻ گهرجي.
    ///
    /// نتيجو صرف معنيٰ وارو آهي جيڪڏهن وڻ کي ڪنڊ ذريعي آرڊر ڪيو ويو آهي ، جهڙوڪ ايڪس ايڪس ايڪس ۾ وڻ وانگر آهي.
    ///
    ///
    /// # Safety
    /// ساڳيو KV ٻه دفعا دورو ڪرڻ لاءِ نقل وارا هٿ استعمال نه ڪريو.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// وڻ جي پوري حد کي محدود ڪري ڇڏي پن جي جزن جي هڪ جوڙي کي ڌار ڌار حوالي ڪري ڇڏي.
    /// نتيجا ميويشنز جي اجازت ڏيڻ وارا غير منفرد حوالا آهن (صرف قدر جي) ، تنهنڪري احتياط سان استعمال ڪيو وڃي.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // اسان هتي روٽ نوڊ ريف کي ڊبل ڪيو ٿا-اسان ڪڏهن به ساڳئي ڪي وي جو دورو ڪونه ڪنداسين ، ۽ ڪڏهن به وڌيڪ چٽاڀيٽي وارن حوالن سان ختم نه ڪندا سين.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// وڻ جي پوري حد کي محدود ڪري ڇڏي پن جي جزن جي هڪ جوڙي کي ڌار ڌار حوالي ڪري ڇڏي.
    /// نتيجا غير منفرد حوالا آهن وڏي پيماني تي تباهي mutيرائڻ جي اجازت ، تنهنڪري ڏا ،ي احتياط سان استعمال ڪيو وڃي.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // اسان هتي روٽ نوڊ ريف کي نقل ڪندا آهيون-اسان ڪڏهن به انهي طريقي سان رسائي نه ڪنداسين جيڪو روٽ مان حاصل ٿيل حوالن مٿان چڙهيل آهي.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// ڏند ڪٿا edge سنڀاليو ، [`Result::Ok`] موڙي ٿو ويجهڙائي KV کي سا sideي طرف جي وي ڏانهن ، جيڪو يا ته ساڳئي پتي نوڊ ۾ يا اڳينٽي نوڊ ۾ آهي.
    ///
    /// جيڪڏهن پتي edge وڻ ۾ آخري ٽڪرو آهي ، روٽ نوڊ سان [`Result::Err`] موٽائي ٿو.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// ڏند ڪٿا edge سنڀاليو ، [`Result::Ok`] موڙي ٿو ويجهڙائي KV کي کاٻي پاسي ڏانهن ، جيڪو يا ته ساڳئي پتي نوڊ ۾ يا اڳينٽي نوڊ ۾ آهي.
    ///
    /// جيڪڏھن پتي edge وڻ ۾ پھريون آھي ، روٽ نوڊ سان [`Result::Err`] موٽائي ٿو.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// هڪ اندروني edge سنڀاليل ڏنو ، سا00ي پاسي KV کي سا handleي پاسي KV ڏانهن هارڊ سان [`Result::Ok`] موٽائي ٿو ، جيڪو يا ته ساڳيو اندروني نوڊ ۾ يا اڳينٽي نوڊ ۾ آهي.
    ///
    /// جيڪڏھن اندروني edge وڻ ۾ آخري ھڪڙو آھي ، روٽ نوڊ سان [`Result::Err`] موٽائي ٿو.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// هڪ پتي edge کي ختم ٿيندڙ مرڻ واري وڻ ۾ ڏنو ، ايندڙ پتي edge کي سا theي طرف موٽائي ٿو ، ۽ وچ ۾ مکيه قيمت جوڙو ، جيڪو يا ته هڪ ئي پتي نوڊ ۾ ، اڳينٽي نوڊ ۾ ، يا غير موجود آهي.
    ///
    ///
    /// اهو طريقو ڪنهن به node(s) کي ختم ڪري ٿو اهو آخر تائين پهچي ٿو.
    /// ان جو اهو مطلب آهي ته جيڪڏهن وڌيڪ اهم پئسي وارو جوڙو موجود نه آهي ، وڻ جي باقي بچيل پاڻ ساري ڇڏيل هوندي ۽ واپس ٿيڻ لاءِ ڪجهه به ناهي.
    ///
    /// # Safety
    /// ڏنل edge لازمي طور تي هم منصب `deallocating_next_back` کان واپس نه آيو هوندو.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// مرڻ واري وڻ ۾ هڪ پتي edge سنڀاليو ، ايندڙ پتي edge کي کاٻي پاسي موٽائي ٿو ، ۽ ڪيٻي ويليو جوڙي وچ ۾ ، جيڪو يا ته هڪ ئي پتي نوڊ ۾ ، اڳينٽي نوڊ ۾ ، يا غير موجود آهي.
    ///
    ///
    /// اهو طريقو ڪنهن به node(s) کي ختم ڪري ٿو اهو آخر تائين پهچي ٿو.
    /// ان جو اهو مطلب آهي ته جيڪڏهن وڌيڪ اهم پئسي وارو جوڙو موجود نه آهي ، وڻ جي باقي بچيل پاڻ ساري ڇڏيل هوندي ۽ واپس ٿيڻ لاءِ ڪجهه به ناهي.
    ///
    /// # Safety
    /// ڏنل edge لازمي طور تي هم منصب `deallocating_next` کان واپس نه آيو هوندو.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// پنن کان odesر تائين نڙ جو هڪ ذخيرو جڙي تائين ختم ڪري ٿو.
    /// هي هڪڙو ئي رستو آهي ته `deallocating_next` ۽ `deallocating_next_back` بعد ڪنهن وڻ جي باقي بچي ٻوٽو ڪ theي ڇڏيو آهي اهو وڻ جي ٻنهي طرفن کي بيٺو آهي ، ۽ ساڳيو edge کي ماريو آهي.
    /// جيئن اهو صرف ان کي سڏ ڪرڻ جو ارادو ڪيو ويو آهي جڏهن سڀ چاٻي ۽ قدر واپس ڪيا ويا ، ڪنهن به ڪنج يا قدر تي صفائي نه ڪئي وڃي.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ايندڙ پتي edge کي پتي edge سنڀاليو منتقل ڪري ٿو ۽ وچ ۾ چاٻي ۽ ويليو حوالي ڪري ٿو.
    ///
    ///
    /// # Safety
    /// سفر ۾ هدايت واري ۾ هڪ ٻيو KV هجڻ لازمي آهي.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// اڳوڻي پتي edge کي پتي edge سنڀاليو منتقل ڪري ٿو ۽ وچ ۾ چاٻي ۽ قيمت ڏانهن حوالا موٽائي ٿو.
    ///
    ///
    /// # Safety
    /// سفر ۾ هدايت واري ۾ هڪ ٻيو KV هجڻ لازمي آهي.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ايندڙ پتي edge کي پتي edge سنڀاليو منتقل ڪري ٿو ۽ وچ ۾ چاٻي ۽ ويليو حوالي ڪري ٿو.
    ///
    ///
    /// # Safety
    /// سفر ۾ هدايت واري ۾ هڪ ٻيو KV هجڻ لازمي آهي.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // انهي کي آخري ڪرڻ تيز آهي ، معيار مطابق.
        kv.into_kv_valmut()
    }

    /// پوش edge ھٿ کي اڳئين پتي ڏانھن منتقل ڪري ٿو ۽ وچ ۾ چاٻي ۽ قدر جي حوالي ڪري ٿو.
    ///
    ///
    /// # Safety
    /// سفر ۾ هدايت واري ۾ هڪ ٻيو KV هجڻ لازمي آهي.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // انهي کي آخري ڪرڻ تيز آهي ، معيار مطابق.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// ايندڙ پتي edge کي پتي edge سنڀاليو منتقل ڪري ٿو ۽ وچ ۾ چاٻي ۽ قيمت موٽائيندو آهي ، پوئتي ڇڏي ڪنهن به نوڊ کي خالي ڪرڻ جڏهن ته لاڳاپيل edge کي ان جي والدين نوڊ ۾ ڏڪڻ ڇڏي ٿو.
    ///
    /// # Safety
    /// - سفر ۾ هدايت واري ۾ هڪ ٻيو KV هجڻ لازمي آهي.
    /// - اھو ڪي وي اڳ ۾ ئي ھجيڪ جي ڪاپي تي پنھنجي جوابي `next_back_unchecked` کان واپس نھ موٽيو ويو.
    ///
    /// اپڊيٽ ٿيل هينڊل سان اڳتي وڌڻ جو واحد محفوظ طريقو ان جو مقابلو ڪرڻ ، dropٽڻ ، هن طريقي کي ٻيهر پنهنجي حفاظت جي حالتن سان مشروط ڪرڻ ، يا ان جي حفاظت جي حالتن جي تابع هم منصب `next_back_unchecked` کي ڪال ڪرڻ.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// پوئين edge واري پتي کي پوئين پتي edge ڏانهن منتقل ڪري ٿو ۽ وچ ۾ چاٻي ۽ قيمت واپس لائي ٿو ، پوئتي ڇڏي ڪنهن به نوڊ کي خالي ڪرڻ جڏهن ته لاڳاپيل edge کي ان جي والدين نوڊ ۾ ڌڪيندي.
    ///
    /// # Safety
    /// - سفر ۾ هدايت واري ۾ هڪ ٻيو KV هجڻ لازمي آهي.
    /// - اهو پتا edge اڳ ۾ ئي منصور `next_unchecked` تان واپس ڪونه ٿيو ته ھٿن جي ڪنھن ڪاپي تي وڻ کي ڇڪڻ لاءِ استعمال ڪيو پيو وڃي.
    ///
    /// اپڊيٽ ٿيل هينڊل سان اڳتي وڌڻ جو واحد محفوظ طريقو ان جو مقابلو ڪرڻ ، dropٽڻ ، هن طريقي کي ٻيهر پنهنجي حفاظت جي حالتن سان مشروط ڪرڻ ، يا ان جي حفاظت جي حالتن جي تابع هم منصب `next_unchecked` کي ڪال ڪرڻ.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// بائیں کاٻي پتي edge کي ھڪ نوڊ جي اندر يا ھيٺ لھي ٿو ، ٻين لفظن ۾ ، edge توھان کي ضرورت آھي پھريون جڏھن نيويگيٽ ڪرڻ تي (يا ھيٺئين پوئتي ھليو ويندو آھي).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// واپسي تي دائیں طرف واري جاءِ تي edge يا نوڊ جي هيٺيان ، ٻين لفظن ۾ ، edge توهان اڳتي وڌڻ جي ضرورت آهي جڏهن اڳتي وڌڻ (يا پهريون ڀيرو جڏهن نيويگيٽ ڪندو).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// چڙهندڙ چابن جي ترتيب ۾ پتي نوڊس ۽ اندروني ڪي وي جو دورو ڪن ٿا ۽ اندروني وارڊ کي به پهرين گهڙي ۾ گهڙي ٿو ، مطلب ته اندروني نوڊس انهن جي انفرادي ڪي وي ۽ انهن جي ٻارڙن جي اڳڀرن کان اڳ آهن.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// ڳڻپيوڪر آھي عنصرن جو تعداد ھڪ (سب) وڻ ۾.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// واپسي جي لاءِ ويجهڙائي واري ڪي وي لاءِ KV ويجهو edge ڇڏي ٿو.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// پٺتي پيل نيويگيشن لاءِ ڪي وي ويجھو edge ڇڏي ٿو.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}