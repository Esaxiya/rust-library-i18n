use core::intrinsics;
use core::mem;
use core::ptr;

/// اهو لاڳاپيل فنڪشن کي ڪال ڪندي `v` منفرد ريفرنس جي پويان قيمت ڏيکاري ٿو.
///
///
/// جيڪڏهن panic `change` بندش ۾ ٿئي ٿو ، اهو س processو عمل ختم ٿي ويندو.
#[allow(dead_code)] // مثال طور ۽ future استعمال لاءِ رکو
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// اهو لاڳاپيل فنڪشن کي ڪال ڪندي `v` منفرد ريفرنس جي قيمت کي تبديل ڪري ٿو ، ۽ رستي ۾ حاصل ٿيل نتيجو موٽائي ٿو.
///
///
/// جيڪڏهن panic `change` بندش ۾ ٿئي ٿو ، اهو س processو عمل ختم ٿي ويندو.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}