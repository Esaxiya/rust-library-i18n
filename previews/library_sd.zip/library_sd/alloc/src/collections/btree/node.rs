// اها مثالي جي پيروي ڪرڻ واري ڪوشش تي عمل آهي
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust کان وٺي اصل ۾ ڀروسي وارو قسم ۽ پوليمورفڪ وارو رجحان نه آهي ، اسان گهڻيون ئي غير محفوظ طريقي سان ڪندا آهيون.
//

// هن ماڊل جو هڪ وڏو مقصد وڻ کي عام (جيڪڏهن اڻ وڻندڙ شڪل واري) ڪنٽينر جي حيثيت سان علاج ڪرڻ ۽ بي-وڻ جي گهڻن سانشيارن سان معاملو ڪرڻ کان پاسو ڪرڻ کان پاسو ڪرڻ آهي.
//
// جيئن ، هن ماڊل جي پرواهه ناهي ته ڇا اندراج ترتيب ڏنل آهي ، ڪهڙا نوڊيا گهٽ هوندا آهن ، يا ان جو ڪهڙو مطلب به گهٽ آهي.تنهن هوندي ، اسان ڪجهه invariants تي ڀاڙين ٿا.
//
// - وڻن ۾ يونيفارم depth/height هجڻ لازمي آهي.مطلب ته ڏنل رستو کي هڪ نوڊ مان پتا تائين هيٺان ساڳي حد تائين آهي.
// - ڊيگهه `n` جي هڪ نوڊ ۾ `n` ڪيچيون ، `n` قدر ، ۽ `n + 1` ڪنڊون آهن.
//   هن جو مطلب اهو آهي ته خالي نوڊ ۾ گهٽ ۾ گهٽ هڪ edge هوندو آهي.
//   پتي نوڊ لاء ، "having an edge" صرف انهي جو مطلب آهي ته اسان نوڊ ۾ پوزيشن جي سڃاڻپ ڪري سگهون ٿا ، ڇاڪاڻ ته پتي جا ڪنارا خالي آهن ۽ ڊيٽا جي نمائندگي جي ضرورت ناهي.
// اندروني نوڊ ۾ ، edge ٻئي پوزيشن جي نشاندهي ڪن ٿا ۽ ٻار نوڊ ڏانهن پوائنٽر شامل آهي.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// پتي نوڊس جو بنيادي حصو ۽ اندروني جوڙيندڙن جي نمائندگي جو حصو.
struct LeafNode<K, V> {
    /// اسان `K` ۽ `V` ۾ همٿائڻ چاهيون ٿا.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// اهو نوڊ انڊيڪس والدين نوڊ جي `edges` صف ۾ انڊيڪس.
    /// `*node.parent.edges[node.parent_idx]` `node` وانگر ساڳيو شي ٿيڻ گهرجي.
    /// اهو صرف ان جي شروعاتي بڻجڻ جي ضمانت آهي جڏهن `parent` null آهي.
    parent_idx: MaybeUninit<u16>,

    /// هن نوڊ جي دڪانن جو تعداد ۽ قيمتون.
    len: u16,

    /// گرفتاريون نوڊ جي اصل ڊيٽا کي محفوظ ڪندي
    /// صرف هر صف جي پهرين `len` عناصر شروعاتي ۽ صحيح آهن.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// جڳھ تي ھڪڙو نئون `LeafNode` شروع ڪري ٿو.
    unsafe fn init(this: *mut Self) {
        // عام پاليسي جي طور تي ، اسان فيلڊ کي غير معياري ڇڏي ڏيون ٿا جيڪڏهن اهي ٿي سگھن ، جيئن ته اهو ٻنهي ٿورڙو تيز ۽ والگرائنڊ ۾ ٽريڪ ڪرڻ آسان آهي.
        //
        unsafe {
            // والدين_ آئيڊڪس ، ڪيچون ، ۽ واليون سڀ شايدUininit آهن
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// هڪ نئون باڪس `LeafNode` ٺاهي ٿو.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// اندروني جوڙيندڙن جي بنيادي نمائندگي.جيئن "ليف نوڊ" سان ، انهن کي غير ابتدائي چابن ۽ قدر کي گرائڻ کان روڪڻ لاءِ `باڪس نوڊ` جي پويان لڪايو وڃي.
/// `InternalNode` جو ڪوبه اشارو سڌو نوڊ جي بنيادي `LeafNode` حصي ڏانهن پوائنٽر ڏانهن اڇلائي سگهجي ٿو ، عام طور تي ڪوڊ کي لڀ ۽ اندروني نوڊس تي عام طور تي ڪم ڪرڻ جي اجازت ڏي ٿي به ته اها جانچ ڪرڻ کانسواءِ ته ٻن پنڙن مان ڪير اشارو ڪري رهيو آهي.
///
/// اها ملڪيت `repr(C)` جي استعمال سان فعال آهي.
///
#[repr(C)]
// gdb_providers.py introspection لاءِ هي قسم جو نالو استعمال ڪندو آهي.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// هن نوڊ جي ٻارن ڏانهن اشارو ڪيو آهي.
    /// `len + 1` انهن مان شروعاتي ۽ صحيح سمجهيو وڃي ٿو ، سواءِ ان جي ته آخر تائين ، جڏهن وڻ `Dying` واري قسم جي قرضن ذريعي منعقد ٿئي ٿو ، انهن مان ڪجهه اشارو ڏڪي رهيا آهن.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// هڪ نئون باڪس `InternalNode` ٺاهي ٿو.
    ///
    /// # Safety
    /// اندروني نوڊس جي هڪ ڌمڪي آهي ته اهي گهٽ ۾ گهٽ هڪ ابتدائي ۽ صحيح edge آهن.
    /// ھي فنڪشن اھڙي edge کي سيٽ نٿو ڪري.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // اسان کي صرف ڊيٽا جي شروعات ڪرڻ جي ضرورت آهي.ڪنڊون شايد متحده آھن.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// هڪ نوڊ تائين هڪ منظم ، غير نفيس پوائنٽر.اھو يا ته `LeafNode<K, V>` ڏانھن ھڪڙي ملڪيت جي پوائنٽر يا `InternalNode<K, V>` تائين ھڪڙي ملڪيت جي پوائنٽر.
///
/// تنهن هوندي ، `BoxedNode` وٽ ڪا containsاڻ ناهي ته ڪئين نوڊ جا اهي ٻه قسم اصل ۾ مشتمل آهن ، ۽ ، جزوي طور تي informationاڻ نه هئڻ جي ڪري ، هڪ الڳ قسم نه آهي ۽ ڪو تباهه ڪندڙ نه آهي.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// ملڪيت واري وڻ جو روٽ نوڊ.
///
/// نوٽ ڪريو ته ھن وٽ تباھھ ڪونھي ، ۽ دستي طور تي صاف ٿيل آھي.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// ھڪڙي نئين ملڪيت واري وڻ کي واپس ڏئي ٿو ، پنھنجي بنيادي ريڊ نوڊ سان جيڪو شروعاتي طور خالي آھي.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` صفر نه هجڻ گهرجي.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// گڏيل ملڪيت جي جوڙ کي جوڙيو.
    /// `reborrow_mut` جي برعڪس ، اهو محفوظ آھي ڇاڪاڻ ته واپسي جي قدر روٽ کي تباھ ڪرڻ لاءِ استعمال نه ٿي ڪري سگھجي ، ۽ وڻ تي ٻيا حوالا نه ٿي سگھي.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ٿوري دير سان ملڪيت واري روٽ نوڊ کي گھڙي ٿو.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// اڻ سڌريل منتقلي ڏانهن هڪ حوالہ ڏيڻ جي جيڪا اجازت ڏياري ۽ تباهي واري طريقن کي پيش ڪندي ۽ ٻيو ڪجهه.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// ھڪڙي ھڪڙي edge سان ھڪڙو اندروني اندروني نوڊ شامل ڪريو اڳوڻي روٽ نوڊ ڏانھن اشارو ڪندي ، اھو نئون نوڊ ٺاھيو روٽ نوڊ ، ۽ ان کي واپس ڪريو.
    /// هي 1 کان اوچائي وڌائيندو آهي ۽ ايڪس ويڪس ايڪس جي سامهون آهي.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, سواءِ ان جي ته اسان وساري چڪا آهيون ته اسان هاڻي اندروني آهيون:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// اندروني روٽ نوڊ کي ڪي ٿو ، ان جو پهريون ٻار نئون روٽ نوڊ طور استعمال ڪري ٿو.
    /// جيئن ته اهو صرف ان کي سڏ ڪرڻ جي لاءِ هوندو آهي جڏهن ته روٽ نوڊ جو هڪڙو ئي ٻار هجي ، ڪنهن به ڪنجي ، قدر ۽ ٻين ٻارن تي صفائي نه ڪئي وڃي.
    ///
    /// اهو قد 1 کي گهٽائي ٿو ۽ ايڪس 100 جي سامهون آهي.
    ///
    /// `Root` اعتراض تائين خاص رسائي جي ضرورت آهي پر روٽ نوڊ ڏانهن نه ؛
    /// اهو روٽ نوڊ جي ٻين حوالن ۽ حوالن کي باطل نه ڪندو.
    ///
    /// Panics جيڪڏهن ڪو اندروني سطح ناهي ، يعني ، جيڪڏهن ريڊ نوڊ پتي آهي.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // حفاظت: اسان اندروني هجڻ تي زور ڀريو.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // حفاظت: اسان `self` کي قرض طور ڏنو ۽ ان جو قرض خاص قسم سان آھي.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // حفاظت: پهرين edge هميشه شروعاتي ڪيو ويو آهي.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` `K` ۽ `V` ۾ هميشه متحرڪ آهي ، جڏهن ته `BorrowType` به `Mut` آهي.
// هي ٽيڪنالاجي طور غلط آهي ، پر `NodeRef` جي اندروني استعمال جي ڪري ڪنهن غير محفوظيت جو نتيجو نٿي وٺي سگهي ڇاڪاڻ ته اسان `K` ۽ `V` کان مڪمل طور تي عام رهندا آهيون.
//
// البت ، جڏهن به عوامي قسم ، ايڪس سيڪس کي لهي ٿي ، اهو پڪ ڪري وٺو ته اهو صحيح وار آهي.
//
/// هڪ نوڊ جو حوالو.
///
/// ھن قسم ۾ ھڪڙي پيٽرولر آھن جيڪي ڪنٽرول ڪن ٿا اھو ڪم ڪري ٿو:
/// - `BorrowType`: ڊيمن جو قسم جيڪو قرض جو قسم بيان ڪري ٿو ۽ سetimeي عمر گذاري ٿو.
///    - جڏهن هي `Immut<'a>` آهي ، `NodeRef` تقريبن `&'a Node` وانگر ڪم ڪري ٿو.
///    - جڏهن هي `ValMut<'a>` آهي ، `NodeRef` ڪيٺيون ۽ وڻ جي respectانچي جي حوالي سان تقريبن `&'a Node` ڪم ڪري ٿو ، پر اهو پڻ وڻن جي ڪيترن ئي متضاد حوالن کي اجازت ڏئي ٿو.
///    - جڏھن ھي `Mut<'a>` آھي ، `NodeRef` تقريبن `&'a mut Node` وانگر ڪم ڪري ٿو ، جيتوڻيڪ داخل ٿيندڙ طريقا ھڪ قابل قدر پوائنٽ کي ھڻائڻ جي قابل ڪرڻ جي اجازت ڏين ٿا.
///    - جڏهن هي `Owned` آهي ، `NodeRef` تقريبن `Box<Node>` وانگر ڪم ڪري ٿو ، پر تباهي وارو نه آهي ، ۽ دستي طور تي صاف ٿيڻ گهرجي.
///    - جڏهن هي `Dying` آهي ، `NodeRef` اڃان به تقريبن `Box<Node>` وانگر ڪم ڪري ٿو ، پر ان ۾ طريقن سان گهٽ طريقي سان وڻ کي تباهه ڪرڻ جا طريقا آهن ، ۽ عام طريقا ، جڏهن ته ڪال ڪرڻ لاءِ غير محفوظ طور نشان لڳل نه آهن ، کي غلط طور تي سڏيو وڃي ته يو بي کي سڏائي سگهجي ٿو.
///
///   ڪنهن به `NodeRef` وڻ ذريعي وڃڻ جي اجازت ڏئي ٿو ، تنهن ڪري `BorrowType` س treeي وڻ تي لاڳو ٿئي ٿو ، نه رڳو نوڊ پاڻ.
/// - `K` ۽ `V`: اهي نوڊس ۾ محفوظ ٿيل ڪيچ ۽ قدر جا قسم آهن.
/// - `Type`: اھو ٿي سگھي ٿو `Leaf` ، `Internal` ، يا `LeafOrInternal`.
/// اهو جڏهن `Leaf` آهي ، `NodeRef` هڪ پتي نوڊ ڏانهن اشارو ڪري ٿو ، جڏهن اهو `Internal` آهي `NodeRef` هڪ اندروني نوڊ ڏانهن اشارو ڪري ٿو ، ۽ جڏهن هي `LeafOrInternal` آهي ته `NodeRef` ٻئي قسم جي نوڊ ڏانهن اشارو ٿي سگهي ٿو.
///   `Type` `NodeType` کان ٻاهر استعمال ڪيو ويو آهي جڏهن `NodeRef` کان ٻاهر استعمال ڪيو ويندو آهي.
///
/// ٻئي `BorrowType` ۽ `NodeType` ڇا محدود طريقي سان عمل ڪن ٿا ، جامد قسم جي حفاظت جي استحصال ڪرڻ لاءِ.رستي ۾ اسان وٽ پابنديون لاڳو ٿيل حدون آهن:
/// - هر قسم جي پيراگراف لاءِ ، اسان صرف هڪ طريقو بيان ڪري سگهون ٿا عام طور تي يا هڪ خاص قسم لاءِ.
/// مثال طور ، اسان سڀني `BorrowType` جي لاءِ عام طور تي `into_kv` وانگر يا ڪنهن به قسم جي سموري طريقيڪار لاءِ وضاحت نٿا ڪري سگهون ، جيڪي هڪ حياتي ڏيان ٿو ، ڇو ته اسان اهو `&'a` حوالي ڪرڻ چاهيون ٿا.
///   ان ڪري ، اسان ان کي صرف گھٽ طاقتور قسم جي `Immut<'a>` لاءِ تعريف ڪندا آھيون.
/// - اسان `Mut<'a>` کان `Immut<'a>` تائين بي ترتيب زبردستي حاصل نٿا ڪري سگھون.
///   تنهن ڪري ، اسان کي `into_kv` وانگر هڪ طريقي سان پهچڻ لاءِ وڌيڪ طاقتور `NodeRef` تي واضح نموني ڪال ڪرڻو آهي.
///
/// `NodeRef` تي سڀ طريقا جيڪي ڪنهن قسم جي حوالن کي موٽائن ٿا ، يا ته:
/// - `self` ويليو کان وٺي ، ۽ `BorrowType` پاران هلندڙ لائفائم موٽيو.
///   ڪڏهن ، اهڙي طريقي کي سڏڻ جي لاءِ ، اسان کي `reborrow_mut` کي سڏڻ جي ضرورت آهي.
/// - وٺو `self` حوالو ، ۽ (implicitly) واپس ڪريو ان حوالي سان سetimeي حياتي ، بدران ان جي زندگي گذارڻ بدران `BorrowType`.
/// اهو رستو ، قرض وٺندڙ چڪاس ڪندڙ ضمانت ڏي ٿو ته `NodeRef` جيستائين قرض واپس ٿي رهيو آهي قرض کڻڻ جي صورت ۾.
///   طريقيڪار مدد ڪندڙ داخل ڪن ٿا اهو قاعدو واپس آڻيندي هڪ خام پوائنٽر ، يعني ، هڪ حوالو بغير ڪنهن حياتي جي.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// سطحن جو تعداد جيڪي نوڊ ۽ پنن جي سطح ڌار ڌار آهن ، نوڊ جو هڪ مستقل جيڪو مڪمل طور تي `Type` بيان نه ٿو ڪري سگهجي ، ۽ اهو نوڊ پاڻ ذخيرو نٿو ڪري.
    /// اسان کي صرف روٽ نوڊ جي قد کي محفوظ ڪرڻ جي ضرورت آهي ، ۽ هر ٻئي نوڊ جي قد کي ان کان ئي حاصل ڪرڻو آهي.
    /// جيڪڏهن `Type` `Leaf` هجي ۽ غير صفر هجڻ گهرجي جيڪڏهن `Type` `Internal` آهي.
    ///
    ///
    height: usize,
    /// پني کي پني يا اندروني نوڊ.
    /// ايڪسڪسيمڪس جي تعريف کي يقيني بڻائي ٿو ته پوائنٽر ٻئي طرح صحيح آهي.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// هڪ نوڊ حوالي کي کوليو جيڪو `NodeRef::parent` طور پيڪي ويو هو.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// اندروني نوڊ جي ڊيٽا کي اجاگر ڪري ٿو.
    ///
    /// هن نوڊ جي ٻين حوالن کي غلط ثابت ڪرڻ کان بچڻ لاءِ خام پيٽر واپس ڪئي آهي.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // حفاظت: جامد نوڊ جو قسم `Internal` آهي.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// هڪ داخلي نوڊ جي ڊيٽا تائين رسائي حاصل ڪري ٿو.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// نوڊ جي ڊيگهه ڳولي ٿو.اهو ڪيچ يا قدر جو تعداد آهي
    /// کنڊ جو تعداد `len() + 1` آھي.
    /// ياد رکجو ، محفوظ هجڻ جي باوجود ، انهي فنڪشن کي سڏڻ ۾ ٻرندڙ حوالن کي غلط ڪرڻ جو ضمني اثر ٿي سگھي ٿو جيڪو غير محفوظ ڪوڊ ٺاهيل آهي.
    ///
    pub fn len(&self) -> usize {
        // اصلي طور ، اسان هتي صرف `len` فيلڊ تائين رسائي حاصل ڪريون ٿا.
        // جيڪڏهن BorrowType marker::ValMut آهي ، اتي قابل قدر متغير حوالا آهن جيڪي اسان کي ناجائز بڻائڻ نه گهرجن.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// سطحن جي تعداد کي واپس ڏئي ٿو ته نوڊ ۽ پن ڌار ڌار آهن.
    /// زيرو اوچائي جو مطلب آهي نوڊ پاڻ هڪ پتي آهي.
    /// جيڪڏهن توهان وڻن کي پاڙن کي پاڙ سان ڇڪيندي ، نمبر ٻڌائيندو آهي ته اوچائي نوڊ ظاهر ٿئي ٿي.
    /// جيڪڏهن توهان وڻن کي پنن سان مٿي جا وارَ لڳندا آهيو ، نمبر چوندو آهي ته وڻ نوڊَ کان ڪيترو بلند ٿيندو.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// عارضي طور تي هڪ ئي نوڊ ۾ هڪ ٻيو ، نه بدلڻ وارو حوالو ڪ takesي ٿو.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ڪنهن به پتي جي اندروني حصي کي ظاهر ڪري ٿو يا اندروني نوڊ.
    ///
    /// هن نوڊ جي ٻين حوالن کي غلط ثابت ڪرڻ کان بچڻ لاءِ خام پيٽر واپس ڪئي آهي.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // نوڊ گهٽ ۾ گهٽ ليف نوڊ جي حصي لاءِ صحيح هجڻ گهرجي.
        // هي نوڊ ريف جي قسم ۾ هڪ حوالو ناهي ڇاڪاڻ ته اسان کي don'tاڻ ناهي ته اهو منفرد يا ونڊيل هجڻ گهرجي.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// موجوده نوڊ جي والدين کي ڳولهي ٿي.
    /// `Ok(handle)` کي واپس ڏئي ٿو جيڪڏھن موجوده نوڊ اصل ۾ ھڪ والدين آھي ، جتي `handle` والدين جي edge ڏانهن اشارو ڪري ٿو جيڪو موجوده نوڊ ڏانهن اشارو ڪري ٿو.
    ///
    /// `Err(self)` ورجائي ٿو جيڪڏھن موجوده نوڊ کي ڪوبه والدين ڪونھي ، اصل `NodeRef` کي واپس ڏي.
    ///
    /// طريقو جو نالو توهان کي تصوير لڳائي ٿو ته وڻ کي مٿان روٽ نوڊ سان.
    ///
    /// `edge.descend().ascend().unwrap()` ۽ `node.ascend().unwrap().descend()` ٻئي ، ڪاميابي تي ، ڪجھ به نه ڪرڻ گھرجي.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // اسان کي نوڊس لاءِ خام پوائنٽرس استعمال ڪرڻ گهرجن ، ڇاڪاڻ ته جيڪڏهن BorrowType marker::ValMut آهي ، اتي قدرن جو بقايا مٽائيندڙ حوالا ٿي سگھن ٿا جيڪي اسان کي غلط نه بڻجن.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// ياد رکو ته `self` لازمي طور تي بي لاڀ هجڻ گهرجي.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// ياد رکو ته `self` لازمي طور تي بي لاڀ هجڻ گهرجي.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// ڪنهن به پتي جي پتي واري حصي کي orمائيندي يا اندروني ڪوڙي ھڪ اڻ گھڻي وڻ ۾.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // حفاظت: هن وڻ ۾ ڪي `Immut` طور تي قرض ڏيندڙن جا ڪي متضاد حوالا نٿا ٿي سگهن.
        unsafe { &*ptr }
    }

    /// نوڊ ۾ محفوظ ڪيل ڪيچز ۾ هڪ منظر ڏسي ٿو.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` سان ملندڙ ، ھڪڙي نوڊ جي والدين نوڊ جو حوالو حاصل ڪري ٿو ، پر اھو عمل ۾ موجوده نوڊ کي به خارج ڪري ٿو.
    /// اهو غير محفوظ آهي ڇاڪاڻ ته هاڻوڪو نوڊس ڊگهو هجڻ جي باوجود اڃا تائين پهچندو.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// نااميد طور تي مرتب ڪندڙ کي جامد معلومات ٻڌائي ٿي ته هي نوڊ ايڪس ايڪس ايڪس آهي.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// نااميد طور تي مرتب ڪندڙ کي جامد معلومات ٻڌائي ٿي ته هي نوڊ ايڪس ايڪس ايڪس آهي.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// عارضي طور تي هڪ ئي نوڊ تائين هڪ ٻيو ، مٽ مائٽ وارو حوالو ڪ takesي ٿو.خبردار ، ڇاڪاڻ ته هي طريقو تمام خطرناڪ آهي ، ٻيڻو اهو ته جيئن اهو فوري طور خطرناڪ نه ٿي لڳي.
    ///
    /// ڇاڪاڻ ته مٽندڙ اشارو وڻ جي چوڌاري ڪٿي به roري سگهن ٿا ، موٽندڙ پوائنٽر آساني سان اصل پوينڊر کي ڊنگنگ ، حد کان ٻاهر ، يا اسٽيڪ ڪيل قرضن جا قاعدن هيٺ غلط ٺاهڻ لاءِ استعمال ڪري سگهجي ٿو.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) `NodeRef` ۾ اڃا تائين ٻيو قسم جو پيٽرولر شامل ڪرڻ تي غور ڪريو جيڪو ڪرنل پوينٽرز تي نيويگيشن جا طريقا استعمال ڪري ٿو ، غير محفوظ ڪرڻ کي روڪڻ.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ڪنهن به پتي جي اندروني حصي تائين رسائي حاصل ڪري ٿو يا داخلي نوڊ.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // حفاظت: اسان وٽ مڪمل نوڊ تائين خاص رسائي آهي.
        unsafe { &mut *ptr }
    }

    /// ڪنهن به پتي جي ڀا portionي يا اندروني نوڊ تائين خاص رسائي فراهم ڪري ٿي.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // حفاظت: اسان وٽ مڪمل نوڊ تائين خاص رسائي آهي.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// هڪ خاص ذخيري جي ايراضي تائين رسائي حاصل ڪن ٿا.
    ///
    /// # Safety
    /// `index` 0 حد ۾ آهي صلاحيت
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // حفاظت: سڏيندڙ نفس کان پاڻ کي وڌيڪ طريقا سڏڻ جي قابل نه هوندا
        // ايستائين جو سليس جو حوالو گهٽجي نه وڃي ، ڇونه اسان وٽ قرض جي حياتي لاءِ منفرد رسائي آهي.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// قرض جي خاص رسائي تائين پهچايو ويو آهي يا نوڊ جي قيمت واري ذخيري جي علائقي جو حصو.
    ///
    /// # Safety
    /// `index` 0 حد ۾ آهي صلاحيت
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // حفاظت: سڏيندڙ نفس کان پاڻ کي وڌيڪ طريقا سڏڻ جي قابل نه هوندا
        // جيستائين قيمت سلائس جو حوالو نه ڇڏيو وڃي ، جيستائين اسان قرض وٺڻ لاءِ س forي زندگي لاءِ منفرد رسائي رکون.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// قرض ڏيڻ واري عنصر کي خاص رسائي تائين پهچندي آهي يا نوڊ جي اسٽوريج جي ايراضي جي edge مواد لاءِ.
    ///
    /// # Safety
    /// `index` 0 حد ۾ آهي ڪيپسيٽي + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // حفاظت: سڏيندڙ نفس کان پاڻ کي وڌيڪ طريقا سڏڻ جي قابل نه هوندا
        // جيستائين edge سليس حواله ڪو نه ڪ isيو وڃي ، تيستائين اسان قرض وڃائي س uniqueي حياتي لاءِ منفرد رسائي حاصل ڪيو.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - نوڊ ۾ `idx` کان وڌيڪ ابتدائي عنصر آھن.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // اسان صرف هڪ عنصر جو حوالو ٺاهيندا آهيون جنهن ۾ اسان دلچسپي وٺندا آهيون ، ٻين عنصرن کي ٻاهرين حوالن سان الڳ ڪرڻ کان پاسو ڪرڻ گهرجي ، خاص طور تي ، جيڪي اڳئين ورثن ۾ ڪالر ڏانهن موٽي آيا.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // اسان کي Rust مسئلي جي #74679 جي ڪري سسائيڊ ترتيب وارن پوائنٽرن کي مجبور ڪرڻ گهرجي.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// نوڊ جي ڊيگهه تائين خاص رسائي حاصل ڪري ٿي.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// نوڊ جي ٻين لنڪ کي غلط طريقي سان بغير نوڊ جي لنڪ کي پنهنجي والدين edge ڏانهن سيٽ ڪريو.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// پنهنجي والدين edge سان ريٽ جي لنڪ کي صاف ڪري ٿو.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// نوڊ جي آخر ۾ چاٻي-قيمت واري جوڙي کي شامل ڪري ٿو.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` پاران واپس ڪيل هر شيڊ نوڊ لاءِ صحيح edge انڊيڪس آهي.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// انهي جوڙي جي سا toي ڏانهن وڃڻ ، نوڊ جي آخر تائين هڪ اهم قيمت وارو جوڙو شامل ڪيو ، ۽ edge.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// چيڪ ڪريو ته ڇا هڪ نوڊ `Internal` نوڊ آهي يا هڪ `Leaf` نوڊ آهي.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// هڪ خاص نوڊ-جوڙي جو اشارو يا edge هڪ نوڊ اندر.
/// `Node` پيٽرولر ھڪڙو `NodeRef` هجڻ گھرجي ، جڏھن ته `Type` به `KV` ٿي سگھي ٿو (ھڪ اھم قدر جوڙي تي ھینڈل جي نشاندھي ڪندي) يا `Edge` (ھڪ edge تي ھٿ جي نشاندھي ڪرڻ).
///
/// نوٽ ڪيو ته `Leaf` نوڊس وٽ `Edge` هينڊل به ٿي سگهن ٿيون.
/// ٻار نوڊ ڏانهن پوائنٽر جي نمائندگي ڪرڻ جي بدران ، اهي جڳهن جي نمائندگي ڪن ٿا جتي ٻار اشارو جي-قيمت جوڙن جي وچ ۾ ويندا.
/// مثال طور ، هڪ نوڊ ۾ ڊيگهه 2 ، اتي 3 ممڪن edge جڳھون ، هڪ نوڊ جي کاٻي پاسي ، هڪ ٻن جوڑوں جي وچ ۾ ۽ هڪ نوڊ جي سا theي طرف.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// اسان کي `#[derive(Clone)]` جي مڪمل سادگي جي ضرورت ناهي ، صرف هڪ ئي وقت `Node` هوندو `کلون` قابل هوندو جڏهن ته اهو هڪ ناقابل تبديل ٿيندڙ حوالو آهي ۽ تنهن ڪري `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// نوڊس حاصل ڪري ٿو جيڪا edge يا اهم ويليو جوڙي تي مشتمل آهي
    pub fn into_node(self) -> Node {
        self.node
    }

    /// نوڊ ۾ هن هينڊل جي پوزيشن واپس اچي ٿو.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node` ۾ هڪ نئين قيمت جي جوڙي کي نئون سنڀاليندو آهي.
    /// غير محفوظ ڇاڪاڻ ته ڪال ڪندڙ کي يقيني بڻائڻ گهرجي `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq جو عوامي عمل ٿي سگھي ٿو ، پر رڳو ھن ماڊل ۾ استعمال ڪيو ويو.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// عارضي طور تي هڪ ئي هنڌ تي ٻيو ، اڻ کٽ handleير ڪ takesي ٿو.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // اسان Handle::new_kv يا Handle::new_edge استعمال نٿا ڪري سگھو ڇاڪاڻ ته اسان کي پنھنجو قسم معلوم نه آھي
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// ناجائز طريقي سان مرتب ڪندڙ جامد معلومات کي ٻڌائي ٿو ته هٿيارن جو جوڙ ايڪس ايڪس ايڪس آهي.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// عارضي طور تي هڪ ٻي جاءِ تي عارضي طور تي ٻلڻ واري هٿ هيٺ کڻي ويندو آهي.
    /// خبردار ، ڇاڪاڻ ته هي طريقو تمام خطرناڪ آهي ، ٻيڻو اهو ته جيئن اهو فوري طور خطرناڪ نه ٿي لڳي.
    ///
    ///
    /// تفصيل لاءِ ، ڏسو `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // اسان Handle::new_kv يا Handle::new_edge استعمال نٿا ڪري سگھو ڇاڪاڻ ته اسان کي پنھنجو قسم معلوم نه آھي
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node` ۾ edge کي نئين سنڀال ٺاهي ٿو.
    /// غير محفوظ ڇاڪاڻ ته ڪال ڪندڙ کي يقيني بڻائڻ گهرجي `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// ھڪڙي edge انڊيڪس ڏنو جتي اسان گنجائش ڀريو ويو نوڊ ۾ داخل ڪرڻ چاھيو ٿا ، تقسيم پوائنٽ جي ھڪڙي سمجھدار ڪي وي انڊيڪس کي حساب ڏي ٿو ۽ ڪٿي داخل ڪرڻ لاءِ.
///
/// تقسيم پوائنٽ جو مقصد والدين جي نوڊ ۾ ختم ٿيڻ واري چاٻي ۽ قيمت لاءِ آهي.
/// ڌار پوائنٽ جي کاٻي پاسي جا نشان ، قدر ۽ ڪنڊون کاٻا ٻار بڻجي وڃن ٿا ؛
/// تقسيم واري پوائنٽ جي سا toي طرف اهم ، قدر ۽ ڪنڊيون صحيح ٻار بڻجي وڃن ٿيون.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust مسئلو #74834 انهن سمائيٽرڪ ضابطن جي وضاحت ڪرڻ جي ڪوشش ڪري ٿو.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// هن edge جي سا theي ۽ کاٻي پاسي کان ويل-ويلڊ جوئر جي وچ ۾ هڪ نئين چاٻي وارو جوڙو داخل ڪري ٿو.
    /// اهو طريقو فرض ڪري ٿو ته نئين جوڙي جي مقابلي لاءِ نوڊ ۾ ڪافي جڳهه آهي.
    ///
    /// واپس ٿيل پوائنٽر داخل ٿيل ويليو ڏانھن اشارو ڪري ٿو.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// هن edge جي سا theي ۽ کاٻي پاسي کان ويل-ويلڊ جوئر جي وچ ۾ هڪ نئين چاٻي وارو جوڙو داخل ڪري ٿو.
    /// اهو طريقو نوڊ کي ورهائي ٿو جيڪڏهن ڪافي جڳهه نه آهي.
    ///
    /// واپس ٿيل پوائنٽر داخل ٿيل ويليو ڏانھن اشارو ڪري ٿو.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ٻارن جي جوڙ ۾ والدين پوائنٽر ۽ انڊيڪس کي درست ڪري ٿو جيڪو هي edge سان ڳن linksجي ٿو.
    /// اهو ڪم ڪار آهي جڏهن ڪنڊن جي ترتيب کي تبديل ڪيو ويو آهي ،
    fn correct_parent_link(self) {
        // نوڊ ڏانهن ٻين حوالن کي غلط ڪرڻ کانسواءِ پٺاڻ ٺاهڻ ٺاهيو.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ھڪ نئون چاٻي-قيمت جوڙو ۽ ھڪڙي edge داخل ڪندو آھي جيڪو ھن edge ۽ Z-edge0Z جي سا toي طرف چاٻي ويليو جوڙي جي وچ ۾ ان نئين جوڙي جي سا willي طرف ويندو.
    /// اهو طريقو فرض ڪري ٿو ته نئين جوڙي جي مقابلي لاءِ نوڊ ۾ ڪافي جڳهه آهي.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// ھڪ نئون چاٻي-قيمت جوڙو ۽ ھڪڙي edge داخل ڪندو آھي جيڪو ھن edge ۽ Z-edge0Z جي سا toي طرف چاٻي ويليو جوڙي جي وچ ۾ ان نئين جوڙي جي سا willي طرف ويندو.
    /// اهو طريقو نوڊ کي ورهائي ٿو جيڪڏهن ڪافي جڳهه نه آهي.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// هن edge جي سا theي ۽ کاٻي پاسي کان ويل-ويلڊ جوئر جي وچ ۾ هڪ نئين چاٻي وارو جوڙو داخل ڪري ٿو.
    /// اهو طريقو نوڊ کي ورهايو جيڪڏهن ڪافي ڪمرو نه آهي ، ۽ ڌار ڌار حصي کي والدين نوڊ ۾ ٻيهر ورجائڻ جي ڪوشش ڪندو ، جيستائين روٽ پهچي نه وڃي.
    ///
    ///
    /// جيڪڏهن موٽڻ وارو نتيجو هڪ `Fit` آهي ، هن جي هينڊلس نوڊس اهو edge نوڊ ٿي سگهي ٿو يا اڳڪٿي.
    /// جيڪڏهن موٽڻ وارو نتيجو `Split` آهي ، `left` فيلڊ ريڊ نوڊ هوندو.
    /// واپس ٿيل پوائنٽر داخل ٿيل ويليو ڏانھن اشارو ڪري ٿو.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// هن edge پاران اشارو ڪيل نوڊ ڳوليو آهي.
    ///
    /// طريقو جو نالو توهان کي تصوير لڳائي ٿو ته وڻ کي مٿان روٽ نوڊ سان.
    ///
    /// `edge.descend().ascend().unwrap()` ۽ `node.ascend().unwrap().descend()` ٻئي ، ڪاميابي تي ، ڪجھ به نه ڪرڻ گھرجي.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // اسان کي نوڊس لاءِ خام پوائنٽرس استعمال ڪرڻ گهرجن ، ڇاڪاڻ ته جيڪڏهن BorrowType marker::ValMut آهي ، اتي قدرن جو بقايا مٽائيندڙ حوالا ٿي سگھن ٿا جيڪي اسان کي غلط نه بڻجن.
        // اونچائي جي فيلڊ تائين رسائي ڪرڻ ۾ ڪا به پريشاني ڪونهي ڇو ته قيمت ڪاپي ٿي وئي آهي.
        // خبردار ، هڪ ڀيرو نوڊ پوائنٽر جو حوالو ڏنو ويو آهي ، اسان ڪنڊن واري صف تائين هڪ ريفرنس سان پهچايو ٿا (Rust مسئلو #73987) ۽ صف جي اندر يا اندر ڪنهن ٻئي حوالي کي باطل ڪري ، ڪو به آس پاس هجڻ گهرجي.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // اسان جدا جدا چاٻي ۽ قدر جي طريقن کي نٿا سڏي سگهون ، ڇاڪاڻ ته ٻئين کي سڏڻ سان پهريون ڀيرو واپس ورتل حوالو باطل ٿي ويندو آهي.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// ڪيلي ۽ قدر کي تبديل ڪريو ، جيڪو ڪي وي هٿ سنڀالڻ وارو آهي.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// پتي جي ڊيٽا جو خيال رکڻ سان ، خاص `NodeType` لاءِ `split` جي پليپشنن کي لاڳو ڪرڻ ۾ مدد ڪري ٿو.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// هيٺيان نوڊ کي ٽن حصن ۾ ورهائي ٿو.
    ///
    /// - نوڊ کي ننatedڙي ڇڏيو ويو آهي صرف هن هارڊ جي کاٻي پاسي وارين قدرن جي جوڑوں تي.
    /// - ھن ھٿ پاران اشارو ڪيو ويو آھي اھم ۽ قدر ڪ areيا ويندا آھن.
    /// - هن هارڊ جي سا toي طرف سڀ اهم قيمت واريون جوڙي هڪ نئين مختص ٿيل نوڊ ۾ رکجن ٿيون.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// هن اهم طريقي سان ٺاهيل جوڙي جوڙي کي ڪ handleي ٿو ۽ هن کي واپس ڪري ٿو ، edge سان گڏ ، جنهن کي اهم وائيٽ جوڙي ڀ collي ويو.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// هيٺيان نوڊ کي ٽن حصن ۾ ورهائي ٿو.
    ///
    /// - نوڊ کي نن isڙي ڇڏيو ويو آهي صرف هن ڪنڊ جي کٻي پاسي واري ڪنڊ ۽ اهم ويليو جزن تي.
    /// - ھن ھٿ پاران اشارو ڪيو ويو آھي اھم ۽ قدر ڪ areيا ويندا آھن.
    /// - هن هارڊ جي سا toي طرف سڀئي ڪنج ۽ اهم ويليو جوڙ هڪ نئين مختص ٿيل نوڊ ۾ رکيا ويا آهن.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// اندروني چاٻي ويل ٻلي جي چوڌاري توازن واري ڪارروائي جي جائزي ۽ انجام ڏيڻ جي لاءِ هڪ سيشن جي نمائندگي ڪندو آهي.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ٻار وانگر نوڊ شامل ڪرڻ جي توازن وارو انتخاب چونڊيو آهي ، اهڙي طرح ڪي وي وچ ۾ فوري طور تي کاٻي يا مادي نوڊ ۾ سا toي طرف.
    /// جيڪڏهن ڪو والدين ناهي ته `Err` واپس ڪري ٿو.
    /// Panics جيڪڏهن والدين خالي آهي.
    ///
    /// کاٻي پاسي کي ترجيح ڏي ٿو ، بهتر هجڻ جي صورت ۾ جيڪڏهن ڏنو ويو نوڊ ڪنهن طرح هيٺ لهي وڃي ، مطلب هتي صرف اهو آهي ته ان ۾ هن جي کاٻي ڀاءُ ۽ ان جي سا sibي ڀاءُ کان گهٽ عنصر موجود آهن ، جيڪڏهن اهي موجود آهن.
    /// انهي صورت ۾ ، کاٻي ڀاءُ کي ضم ڪرڻ وڌيڪ تيز آهي ، ڇاڪاڻ ته اسان کي رڳو جوڙ جي اين عنصرن کي منتقل ڪرڻ جي ضرورت آهي ، بدران انهن کي سا theي طرف منتقل ڪرڻ ۽ اڳيان اڳيان اين عنصرن کان وڌيڪ حرڪت ڪرڻ.
    /// کاٻي سا sibي کان چوري ڪرڻ پڻ عام طور تي تيز آهي ، ڇاڪاڻ ته اسان کي صرف نوڊس جي اين عنصرن کي سا toي طرف منتقل ڪرڻ جي ضرورت آهي ، بدران سا sibي جي ٻين عنصرن کي کاٻي طرف منتقل ڪرڻ بدران.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// موٽندي ته ڇا ضم ٿيڻ ممڪن آهي ، يعني ، ڇا مرڪزي ڪي وي کي ٻنهي ڀرسان ٻارڙن جي جوڙ سان گڏ ڪرڻ لاءِ هڪ نوڊ ۾ ڪافي ڪمرو آهي.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// هڪ ميلاپ انجام ڏي ۽ هڪ بندش کي فيصلو ڪرڻ ڏي ته واپس ٿيڻ ڇا گهرجي.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // حفاظت: جوڙيل ڳڻن جي اوچائي اوچائي کان هيٺ هڪ آهي
                // هن edge جي نوڊ جو ، اهڙي طرح صفر کان مٿي ، تنهنڪري اهي اندروني آهن.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// والدين جي اهم قيمت واري جوڙي ۽ ٻئي ويجهي ٻار جي جوڙ کي ٻلي ٻار جي جوڙ ۾ ضم ڪري ٿو ۽ نن parentڙي پيرڊ نوڊ کي واپس ڪري ٿو.
    ///
    ///
    /// Panics جيستائين اسان `.can_merge()` نه.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// والدين جي اهم ويليو جوڙي ۽ ٻئي ويجهي ٻار جي جوڙ کي ٻلي ٻار جي جوڙ ۾ ضم ڪري ٿو ۽ ٻاراڻو جوڙ کي واپس ڪري ٿو.
    ///
    ///
    /// Panics جيستائين اسان `.can_merge()` نه.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// ميئر کي والدين جي اهم قيمت واري جوڙي ۽ ٻئي سان لاڳاپيل ٻارڙن کي باڊي ٻار جي نوڊ ۾ ضم ڪري ٿو ۽ ان ٻار نوڊ ۾ edge هينڊيل کي واپس ڪري ٿو جتي هيٺ ڏنل ٻار edge ختم ٿيو ،
    ///
    ///
    /// Panics جيستائين اسان `.can_merge()` نه.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// کاٻي ٻار کان هڪ اهم شيئر جوڙي ڪovesي ٿو ۽ ان کي والدين جي اهم قيمت واري ذخيري ۾ رکي ٿو ، جڏهن ته پراڻي والدين جي اهم قيمت واري جوڙي کي صحيح ٻار ۾ ڌڪي ٿو.
    ///
    /// edge کي صحيح ٻار ۾ هڪ هارڊ موٽائيندو آهي جتي اصل edge `track_right_edge_idx` طرفان بيان ڪيل ختم ٿئي ٿو.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// دائیں ٻار کان هڪ اهم قيمت واري جوڙي کي ڪ andي ٿو ۽ اهو والدين جي اهم قيمت واري ذخيري ۾ رکي ٿو ، جڏهن ته پراڻي ٻار جي اهم قيمت واري جوڙي کي کاٻي ٻار تي دٻايو.
    ///
    /// `track_left_edge_idx` پاران بيان ڪيل کاٻي ٻار ۾ edge کي هلائيندڙ موٽايو آهي ، جنهن منتقل نه ڪيو.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// هي ساڳيو طريقي سان `steal_left` تي چوري ڪري ٿو پر هڪ ئي وقت ڪيترائي عنصر چوري ڪري ٿو.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // صحيح ڪري وٺو ته اسان حفاظت سان چوري ڪري سگھون ٿا.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // پتي جي ڊيٽا منتقل ڪريو.
            {
                // صحيح ٻار ۾ چوري ڪيل عنصرن جي جاءِ رکو.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // عنصرن کي کاٻي ٻار کان سا theي طرف منتقل ڪريو.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // کاٻي کان وڌيڪ چوري ٿيل جوڙو والدين ڏانهن منتقل ڪريو.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // والدين جي اهم قيمت واري جوڙي کي صحيح ٻار ڏانهن منتقل ڪريو.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // چوري واري ڪنڊ کي جاءِ ڏيو.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // چوريون کنيون.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left` جو سميري کلون.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // صحيح ڪري وٺو ته اسان حفاظت سان چوري ڪري سگھون ٿا.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // پتي جي ڊيٽا منتقل ڪريو.
            {
                // والدين سان دائیں طرف وڌندڙ چوري واري جوڙي کي منتقل ڪيو.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // والدين جي اهم قيمت واري جوڙي کي کاٻي ٻار ڏانهن منتقل ڪريو.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // عنصرن کي صحيح ٻار کان کاٻي ڏانهن وڃڻ.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // خال ڀريو جتي چوري ڪيل عنصر ڪتب ايندا هئا.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // چوريون کنيون.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // خال ڀريو جتي چوري ڪنج استعمال ڪندا هئا.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// ڪنهن به جامد اڻ هٽايو ته اها تصديق ڪندي ته هي نوڊ ايڪس ايڪس اين ايڪس نوڊ آهي.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ڪنهن به جامد اڻ هٽايو انهي جي تصديق ڪندي ته هي نوڊ ايڪس ايڪس اين ايڪس نوڊ آهي.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// چيڪ ڪري ٿو ته ڇا هيٺيون نوڊ `Internal` نوڊ آهي يا `Leaf` نوڊ آهي.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` کان بعد ھڪڙي لاٿائين ھڪ نوڊ ڏانھن ٻئي ڏانھن.`right` کي خالي ڪرڻ گهرجي.
    /// `right` جو پهريون edge بدلايو رهي ٿو.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// داخلا جو نتيجو ، جڏهن هڪ نوڊ کي ان جي گنجائش کان وڌڻ جي ضرورت هجي.
pub struct SplitResult<'a, K, V, NodeType> {
    // موجوده وڻ ۾ عنصرن ۽ ڪنڊن سان nير thatار ڪئي وئي جيڪي `kv` جي کاٻي سان تعلق رکن ٿا.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // ڪي اهم ۽ قيمت جدا ٿي ويا ، ٻئي هنڌ داخل ٿيڻ لاءِ.
    pub kv: (K, V),
    // مالڪ ، ناچيز ٿيل ، نئون نوڊ عناصر ۽ ڪنڊن سان جيڪي `kv` جي سا toي سان تعلق رکن ٿيون.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // ڇا اهو قرض جي قسم جو نوڊس حوالو وڻ ۾ ٻين نوڊ ڏانهن منتقل ڪرڻ جي اجازت ڏين ٿا.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ٽريولر کي گهربل نه آهي ، اهو `borrow_mut` جو نتيجو استعمال ڪندي ٿئي ٿو.
        // ٽروسلر کي غير فعال ڪرڻ سان ، ۽ صرف روٽ جا نوان حوالا ٺاهڻ سان ، اسان knowاڻون ٿا ته `Owned` قسم جو هر حوالو روٽ نوڊ ڏانهن آهي.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// ابتدائي عنصرن جي سليس ۾ قدر داخل ڪري ٿو ان کان پوءِ هڪ ابتدائي عنصر.
///
/// # Safety
/// ٻلي ۾ `idx` کان وڌيڪ عنصر آھن.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// ختم ڪري ٿو ۽ ھڪڙي قيمت سڀني ابتدائي عنصرن جي ھڪڙي حصي کي واپس ڪري ٿو ، ھڪڙي ڇڏي اڳوڻي شروعات ٿيل عنصر کي ڇڏي ڏنو.
///
///
/// # Safety
/// ٻلي ۾ `idx` کان وڌيڪ عنصر آھن.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// عنصرن کي ھڪڙي سلائس `distance` پوزيشن کي کاٻي طرف منتقل ڪري ٿو.
///
/// # Safety
/// ٻلي ۾ گھٽ ۾ گھٽ `distance` عنصر نه آھن.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// هڪ سليس `distance` پوزيشن کي عناصر س toي طرف منتقل ڪري ٿو.
///
/// # Safety
/// ٻلي ۾ گھٽ ۾ گھٽ `distance` عنصر نه آھن.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// سڀني قدرن کي شروعاتي عنصرن جي هڪ سلائس کان غير شروعاتي عنصرن جي ٻلي ڏانهن منتقل ڪري ٿو ، `src` کي ڇڏي سڀني غير شروعات ٿيل وانگر ڇڏي ٿو.
///
/// ڪم ڪري ٿو `dst.copy_from_slice(src)` پر `T` کي `Copy` ٿيڻ جي ضرورت ناهي.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;