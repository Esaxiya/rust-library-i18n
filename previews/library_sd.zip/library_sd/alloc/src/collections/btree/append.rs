use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// ٻن اهم قدرن جوڙن کي ٻن چڙهندڙ ايٽرر جي اتحاد مان شامل ڪري ٿو ، رستي ۾ هڪ `length` متغير کي وڌائڻ.پوئين سڏيندڙ کي گهڻائي ڪرڻ آسان بڻائي ٿي جڏهن لهي وڃڻ کان پاسو ڪري جڏهن هڪ پاسو هلائيندڙ icksٽي ويو.
    ///
    /// جيڪڏهن ٻئي ورثا هڪ ئي ڪنڊي پيدا ڪندا ، اهو طريقو کاٻي جوڙي کي ٻاري ڇڏيو آهي ۽ ان جوڙي کي سا itي ايرير مان ڪ appي ٿو.
    ///
    /// جيڪڏھن توھان چاھيو ٿا ته وڻ ھڪڙي سخت چڙھي ترتيب ۾ ختم ٿئي ، اي `BTreeMap` وانگر ، ٻئي آئيٽرر کي سختي سان چڙھي ترتيب ۾ چابيون پيدا ڪرڻ گھرجي ، ھر ھڪ وڻ کان تمام گھڻيون وڻن کان وڌ
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // اسان تيار ڪريون ٿا `left` ۽ `right` ترتيب واري ترتيب ۾ ليڪن واري وقت ۾.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // ان دوران ، اسان سڌي وقت ۾ ترتيب وار ترتيب مان هڪ وڻ تعمير ڪريون ٿا.
        self.bulk_push(iter, length)
    }

    /// سڀني اهم قيمت واري جوڙن کي وڻ جي آخري حد تائين ڌڪ ڏئي ٿو ، رستي ۾ هڪ `length` متغير کي وڌائڻ.
    /// پوئين بعد سڏيندڙ جي لاءِ گهڻائي آسان بڻائي ٿي جڏهن لهياري کان پاسو ڪري.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // سڀني اهم قيمت جي جوڙن ذريعي يررايو ، انهن کي صحيح سطح تي نوڊس ۾ وڌو.
        for (key, value) in iter {
            // هاڻوڪو پني نوڊ ۾ چاٻي-قيمت واري جوڙي کي دٻائڻ جي ڪوشش ڪريو.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // ڪا به جڳهه نه ڇڏي ، مٿي وڃو ۽ اتي ڌڪيو.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // کاٻي پاسي کان هڪ نوڊ مليو ، هتان ڪلڪ ڪريو.
                                open_node = parent;
                                break;
                            } else {
                                // وري مٿي وڃو.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // اسان مٿي تي آهيون ، هڪ نئون روٽ نوڊ ٺاهيو ۽ اتي ڌڪ لڳايو.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // پچي ويل-ويلڊ جوڙي ۽ نئين ساreeي ذيلي شڪل.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // ٻيهر س-ي پاسي کان کاٻي پاسي وڃ.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // وڌندڙ ڊگهو هر ورثو ، انهي کي يقيني بڻائڻ لاءِ نقشو ملندڙ عناصر dropsٽي ڇڏيندي جيتوڻيڪ ايٽرر پينڪ کي اڳتي وڌائيندي.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// هڪ ترتيب ۾ ٻن ترتيب وار تسلسل کي ضم ڪرڻ لاءِ هڪ ورثو
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// جيڪڏهن ٻه ڪيچ برابر آهن ، صحيح ماخذ کان اهم ويليو جوڙي واپس آڻيندي.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}