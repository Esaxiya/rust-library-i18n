//! ٻٻر واري قطار هڪ وڌندڙ انگوزي واري بفر سان لاڳو ڪئي وئي.
//!
//! هن قطار ۾ *O*(1) ڪتب آڻيندڙ داخلائون ۽ هٽائڻ وارا ڪنٽينر جي ٻنهي پاسن کان آهن.
//! ان ۾ پڻ Z Ovector0Z وانگر *O*(1) انڊسٽنگ آهي.
//! گهربل عنصرن کي نقل ڪرڻ جي ضرورت ناھي ، ۽ قطار اندر موڪليل جيڪڏهن قابل اطمينان قسم قابل موڪل هجي.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3 ، 1
const MINIMUM_CAPACITY: usize = 1; // 2 ، 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // ٻن جي وڏي ممڪن طاقت

/// ٻٻر واري قطار هڪ وڌندڙ انگوزي واري بفر سان لاڳو ڪئي وئي.
///
/// قطار ۾ موجود "default" کي قطار ۾ شامل ڪرڻ لاءِ [`push_back`] استعمال ڪرڻ آهي ، ۽ قطار مان خارج ڪرڻ لاءِ [`pop_front`].
///
/// [`extend`] ۽ [`append`] هن طريقي سان پوئتي تي ڌڪايو ، ۽ `VecDeque` مٿان ٻيهر ورجائي پوئتي موڙ تي ٿيو.
///
/// `VecDeque` کان ھڪڙو رنگ بفر آھي ، ان جا عنصر ضروري طور تي ياداشت ۾ متضاد ناھن.
/// جيڪڏهن توهان عناصر کي هڪ سلائس وانگر رسائي حاصل ڪرڻ چاهيو ٿا ، جيئن ته موثر ترتيب ڏيڻ جي لاءِ ، توهان ايڪس ايڪس ايڪس استعمال ڪري سگهو ٿا.
/// اهو `VecDeque` کي گردش ڪري ٿو ، ان جا عنصر لفاف نٿا ڪن ، ۽ هاڻ متضاد عنصر واري ترتيب ڏانهن هڪ قابل ableير slار سلائس واپس آڻين ٿا.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // دم ۽ سر بفر ۾ اشارو آھن.
    // دم هميشه پهريون عنصر ڏانهن اشارو ڪيو جيڪو پڙهي سگهجي ٿو ، هيڊ هميشه هميشه ان طرف اشارو ڪندو آهي جتي ڊيٽا لکڻ گهرجي.
    //
    // جيڪڏھن دم==سر بفر خالي آھي.رنگ بفر جي ڊيگهه ٻنهي جي وچ ۾ فاصلو بيان ڪيو ويو آهي.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// هلائيندڙ جي تباهي واري شي کي سلائس ۾ هلندي آهي جڏهن اهو ٻڏي وڃي (عام طور تي يا اندر وڻڻ دوران).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // [T] لاءِ قطرو استعمال ڪريو
            ptr::drop_in_place(front);
        }
        // خام ويڪ نيڪال کي سنڀاليندو آهي
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// خالي `VecDeque<T>` ٺاهي ٿو.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// حاڪمه وڌيڪ آسان
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// حاڪمه وڌيڪ آسان
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // صفر وارين قسمن جي لاء ، اسان هميشه وڌ کان وڌ گنجائش تي آهيون
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// پيٽر کي سلائس ۾ تبديل ڪريو
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// پيٽر کي ميو سلائس ۾ تبديل ڪيو
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// ھڪڙي عنصر کي بفر مان ڪي ٿو
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// بفر ۾ هڪ عنصر لکندي ، ان کي منتقل ڪندي.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// ايڪس بيرڪس واپسي ڏئي ٿو جيڪڏھن بفر مڪمل ظرف آھي.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// ڏنل منطقي عنصر انڊيڪس لاءِ ھيٺ ڏنل بفر ۾ انڊيڪس ڏي ٿو.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// ڏنل منطقي عنصر انڊيڪس + شامل ڪرڻ لاءِ ھيٺ ڏنل بفر ۾ انڊيڪس واپس آڻيندي.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// ڏنل منطقي عنصر انڊيڪس ، ماتحت ، هيٺ ڏنل بفر ۾ انڊيڪس کي واپس آڻي ٿو.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src کان ڊي ايس ڊي تائين ميموري لين جو هڪ س blockو بلاڪ نقل ڪري ٿو
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src کان ڊي ايس ڊي تائين ميموري لين جو هڪ س blockو بلاڪ نقل ڪري ٿو
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// ميموري لين جي هڪ امڪاني طور تي لپڻ واري بلاڪ کي src کان ڊگهو ڪري ٿو.
    /// (abs(dst - src) لينڪس cap() کان وڏو نه ھئڻ گھرجي (src ۽ dest وچ ۾ ھڪڙي ھڪڙي لڳاتار ھڪڙي اوورلوپنگ علائقو ھئڻ گھرجي).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src لفاف نه ڪندو آهي ، ڊي ايس نه لڏندو
                //
                //        ڏکڻ...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] ڊي.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // src کان پهرين ڊي ايس ، src لپ نه ٿو ، ڊي ايس لفتا
                //
                //
                //    ڏکڻ...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. ڊي.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src ڊيسٽ کان اڳ ، src لڏپلاڻ نه ، ڊيسٽ لفاف
                //
                //
                //              ڏکڻ...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. ڊي.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // ڊي ٽي ايس src کان اڳ ، src لپائي ٿو ، ڊي ايس لپي نه ٿو
                //
                //
                //    .. ايس.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] ڊي...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src ڊيسٽ کان اڳ ، src لپيو ، ڊي ايس لپي نه ٿو
                //
                //
                //    .. ايس.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] ڊي...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // ڊي ٽي ايس src کان اڳ ، src لفٽ ، ڊي وي لفاف
                //
                //
                //    ... ايس.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. ڊي..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src ڊيسٽ کان اڳ ، src لفاف ، ڊي ايس لفٽ
                //
                //
                //    .. ايس..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... ڊي.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// حقيقت کي سنڀالڻ لاءِ سر ۽ دم جي حصن جي ڀرسان ري ٿو.
    /// غير محفوظ آهي ڇاڪاڻ ته اها پراڻي_ گنجائش تي ڀروسو رکي ٿي.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // انگوزي بفر TH جو ننestو نن contڙو حصو منتقل ڪريو
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] ايڇ
        //   [o o . o o o o o ]
        //          THB [...اويوو......
        //          ] ايڇ
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // هڪ نيپ
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// خالي `VecDeque` ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// گهٽ ۾ گهٽ `capacity` عناصر لاءِ خالي `VecDeque` جڳهه ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 کان وٺي رِنگ بفر هميشه هڪ جاءِ خالي ڇڏي ٿو
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// ڏنل انڊيڪس ۾ موجود عنصر کي حوالي مهيا ڪري ٿو.
    ///
    /// انڊيڪس 0 ۾ عنصر قطار ۾ اڳيان آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// ڏنل انڊيڪس ۾ عنصر کي aير mutار جو حوالو ڏئي ٿو.
    ///
    /// انڊيڪس 0 ۾ عنصر قطار ۾ اڳيان آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// ايڪس ڊيڪس `i` ۽ `j` تي عنصرن کي مٽايو.
    ///
    /// `i` ۽ `j` برابر ٿي سگھن ٿيون.
    ///
    /// انڊيڪس 0 ۾ عنصر قطار ۾ اڳيان آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن يا ته انڊيڪس حدن کان ٻاهر آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// عناصر جي تعداد کي واپس آڻي ٿو `VecDeque` بغير بيان ڪرڻ جي بغير.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// گهٽ ۾ گهٽ گنجائش مختص ڪري ٿو `additional` وڌيڪ عناصر ڏنل `VecDeque` ۾ داخل ٿيڻ جو.
    /// ڇا ڪندو ڪجھ به ناهي جيڪڏهن گنجائش اڳ ئي ڪافي آھي.
    ///
    /// ياد رکو ته مختص ڪندڙ ان کي موڪلڻ کان وڌيڪ جاءِ ڏئي سگهي ٿو.
    /// ان ڪري صلاحيت تي انحصار نه ٿو ڪري سگھجي ته بلڪل گھٽ ۾ گھٽ آھي.
    /// [`reserve`] کي ترجيح ڏيو جيڪڏهن future داخل ٿيڻ جي توقع ڪئي وڃي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن نئين گنجائش `usize` مٿان لڳندي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// ڏنل `VecDeque` ۾ داخل ٿيڻ جي گھٽ ۾ گھٽ `additional` وڌيڪ عنصر جي گنجائش محفوظ ڪري ٿو.
    /// اھو مجموعو وڌيڪ جڳھ رکي سگھي ٿو جيڪو بار بار منظرنامن کان بچڻ لاءِ.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن نئين گنجائش `usize` مٿان لڳندي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// ڏنل `VecDeque<T>` ۾ داخل ٿيڻ جي لاءِ وڌيڪ عناصر جي گھٽ ۾ گھٽ گنجائش رکڻ جي ڪوشش ڪندو آھي وڌيڪ `additional`.
    ///
    /// `try_reserve_exact` کي ڪال ڪرڻ کان پوءِ ، گنجائش `self.len() + additional` کان وڌيڪ يا برابر ٿي ويندي.
    /// ڇا ڪندو ڪجھ به ناهي جيڪڏهن گنجائش اڳ ئي ڪافي آھي.
    ///
    /// ياد رکو ته مختص ڪندڙ ان کي موڪلڻ کان وڌيڪ جاءِ ڏئي سگهي ٿو.
    /// انهي جي ڪري ، صلاحيت تي اعتبار نه ٿو ڪري سگھجي گھٽ بلڪل گھٽ هجڻ گهرجي.
    /// `reserve` کي ترجيح ڏيو جيڪڏهن future داخل ٿيڻ جي توقع ڪئي وڃي.
    ///
    /// # Errors
    ///
    /// جيڪڏهن گنجائش `usize` کي ختم ڪري ٿي ، يا مختصابه هڪ ناڪاميءَ جي رپورٽ ڪري ، ته هڪ غلطي واپس ڪئي وئي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // يادگيري کي اڳ ۾ محفوظ ڪريو ، ڪ ifي جيڪڏهن اسان نٿا ڪري سگهون
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // ھاڻي اسين knowاڻون ٿا ته ھي اسان جي پيچيده ڪم جي وچ ۾ OOM(Out-Of-Memory) نٿا ڪري سگھن
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // تمام پيچيده
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// ڏنل `VecDeque<T>` ۾ داخل ٿيڻ جي گھٽ ۾ گھٽ `additional` وڌيڪ عناصر جي گنجائش کي محفوظ ڪرڻ جي ڪوشش ڪندو آهي.
    /// اھو مجموعو وڌيڪ جڳھ رکي سگھي ٿو جيڪو بار بار منظرنامن کان بچڻ لاءِ.
    /// `try_reserve` کي ڪال ڪرڻ کان پوءِ ، گنجائش `self.len() + additional` کان وڌيڪ يا برابر ٿي ويندي.
    /// ڇا ڪجهه به ناهي ڪندو جيڪڏهن گنجائش اڳ ئي ڪافي آهي.
    ///
    /// # Errors
    ///
    /// جيڪڏهن گنجائش `usize` کي ختم ڪري ٿي ، يا مختصابه هڪ ناڪاميءَ جي رپورٽ ڪري ، ته هڪ غلطي واپس ڪئي وئي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // يادگيري کي اڳ ۾ محفوظ ڪريو ، ڪ ifي جيڪڏهن اسان نٿا ڪري سگهون
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ھاڻي اسين knowاڻون ٿا ته ھي OOM اسان جي پيچيده ڪم جي وچ ۾ نٿو ڪري سگھي
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // تمام پيچيده
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// `VecDeque` جي گنجائش کي جيترو ممڪن طور تي ڇڪايو وڃي.
    ///
    /// اهو جيترو ممڪن ٿي سگهي گهٽ ڊگهو ڇڏيندو پر butاڻائيندڙ اڃا تائين `VecDeque` کي آگاهي ڏئي سگهي ٿو ته هتي وڌيڪ ڪجهه عناصر لاءِ جڳهه آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// گھٽ حد سان `VecDeque` جي ظرفيت کي گھٽائي ٿو.
    ///
    /// گنجائش گهٽ ۾ گهٽ جيترو وڏو ٿيندو جيترو ڊگهو ۽ سپلائي قدر.
    ///
    ///
    /// جيڪڏهن موجوده گنجائش هيٺين حد کان گهٽ آهي ، اهو هڪ اوپي ناهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // اسان کي هڪ اوور فلو بابت پريشان ٿيڻ نه گهرجي ڇاڪاڻ ته `self.len()` ۽ `self.capacity()` ڪڏهن به `usize::MAX` نٿا ٿي سگهن.
        // +1 جيئن رنگ ٻرندڙ هميشه هڪ جاءِ کي خالي ڇڏي ڏيندو آهي.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // هتي دلچسپي جا ٽي ڪيس آهن:
            //   سڀئي عنصر مطلوب حدن کان ٻاهر آهن عناصر مفاصلي سان ، ۽ سر مطلوب حدن کان ٻاهر آهن عناصر غير متوقع آهن ، ۽ دم مطلوب حدن کان ٻاهر آهي
            //
            //
            // ٻين وقتن ۾ ، عنصر جڳھه متاثر نه ٿيندا آھن.
            //
            // ظاهر ڪري ٿو ته سر تي عنصرن کي منتقل ڪيو وڃي.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // عناصر کي حرڪت جي حد کان ٻاهر منتقل ڪريو (پوزيشن_ target_cap کان پوءِ)
            if self.tail >= target_cap && head_outside {
                // ايڇ
                //   [. . . . . . . . o o o o o o o . ]
                //    ايڇ
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // ايڇ
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // ايڇ ٽي
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// `VecDeque` کي مختصر ڪري ، پهريون `len` عناصر رکڻ ، باقي ڇڏڻ.
    ///
    ///
    /// جيڪڏهن `len` "وييڪ ڊيڪ" جي موجوده ڊيگهه کان وڌيڪ آهي ، انهي جو ڪوبه اثر ناهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// هلائيندڙ جي تباهي واري شي کي سلائس ۾ هلندي آهي جڏهن اهو ٻڏي وڃي (عام طور تي يا اندر وڻڻ دوران).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // محفوظ ، ڇاڪاڻ
        //
        // * `drop_in_place` ڏانهن منتقل ٿيل ڪو به حصو جائز آهي ؛ٻئي صورت ۾ `len <= front.len()` آهي ۽ `len > self.len()` تي واپسي پهرين ڪيس ۾ `begin <= back.len()` کي يقيني بنائي ٿو
        //
        // * `drop_in_place` کي فون ڪرڻ کان پھريائين VecDeque جي سربراھ کي منتقل ڪيو ويو آھي ، تنھنڪري ڪنھن قدر ٻيڻو ڪونه ڏبو آھي جيڪڏھن `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // پڪ ڪريو ته ٻئين اڌ کي ڇڏيو ويو آهي جڏهن هڪ پهرين تباهي panics ۾.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// اڳيان کان پوئتي موٽائيندڙ کي ڏياري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// واپسي جي سامهون ايندڙ پوئتي موٽائي ٿو
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // حفاظت: اندروني `IterMut` حفاظت انوائيٽري قائم ڪئي وئي آهي ڇاڪاڻ ته
        // `ring` اسان پيدا ڪريون ٿا حياتي لاءِ زنده رهڻ وارو سلائس.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// واپسي جي ھڪڙي ٻيڙي کي واپس ڏئي ٿو جنھن ۾ ، ترتيب ڏئي ، `VecDeque` جي مواد کي.
    ///
    /// جيڪڏهن [`make_contiguous`] اڳ ۾ سڏ ڪئي وئي هئي ، `VecDeque` جا سڀ عنصر پهرين سلائس ۾ هوندا ۽ ٻيو سلائس خالي هوندو.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// واپسي جي ھڪڙي ٻيڙي کي واپس ڏئي ٿو جنھن ۾ ، ترتيب ڏئي ، `VecDeque` جي مواد کي.
    ///
    /// جيڪڏهن [`make_contiguous`] اڳ ۾ سڏ ڪئي وئي هئي ، `VecDeque` جا سڀ عنصر پهرين سلائس ۾ هوندا ۽ ٻيو سلائس خالي هوندو.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque` ۾ عناصر جو تعداد واپس ڏئي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// ايڪس پي ايم ايڪس کي خالي ڪري ٿو جيڪڏهن `VecDeque` خالي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// ايريٽر ٺاهي ٿو جيڪا `VecDeque` ۾ مخصوص ٿيل حد کي coversڪي ٿي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن شروعاتي نقطي اختتام واري نقطي کان وڏي آهي يا جيڪڏهن آخري نقطو vector جي ڊيگهه کان وڌيڪ آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // هڪ مڪمل سلسلو سڀني مواد جو احاطو ڪري ٿو
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // &self ۾ اسان جيڪو حصيداري حوالو ڏنو ويو آهي ، ان کي Iter جي _ _ ۾ برقرار رکيو ويو آهي.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// ايريٽر ٺاهي ٿو جيڪا `VecDeque` ۾ مخصوص متغير حد تائين پکڙيل آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن شروعاتي نقطي اختتام واري نقطي کان وڏي آهي يا جيڪڏهن آخري نقطو vector جي ڊيگهه کان وڌيڪ آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // هڪ مڪمل سلسلو سڀني مواد جو احاطو ڪري ٿو
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // حفاظت: اندروني `IterMut` حفاظت انوائيٽري قائم ڪئي وئي آهي ڇاڪاڻ ته
        // `ring` اسان پيدا ڪريون ٿا حياتي لاءِ زنده رهڻ وارو سلائس.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// خشڪ ايراضي ٺاهي ٿو جيڪا ايڪس 100 ايڪس ۾ مخصوص حد کي ختم ڪري ٿي ۽ ختم ٿيل شيون حاصل ڪري ٿي.
    ///
    /// ياداشت 1: عنصر جي حد کي هٽايو ويندو آهي ايستائين ايٽرر ايتري تائين استعمال نه ڪيو وڃي.
    ///
    /// نوٽ 2: اهو اڻ pاڻيل آهي ته ڪيترا عنصر ڊيڪ مان ڪ areيا ويندا ، جيڪڏهن `Drain` ويليو کي نه ڇڏيو وڃي ، پر اهو جو قرض وٺندو آهي اهو ختم ٿي ويندو (مثال طور ، `mem::forget` سبب).
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن شروعاتي نقطي اختتام واري نقطي کان وڏي آهي يا جيڪڏهن آخري نقطو vector جي ڊيگهه کان وڌيڪ آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // هڪ مڪمل رينج سڀ مواد صاف ڪري ٿو
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // ياداشت جي حفاظت
        //
        // جڏهن Drain پهرين ٺاهي وئي آهي ، سورس ڊيڪ کي نن isڙو ڪري انهي کي يقيني بڻائي ڇڏيو ته ڪو ابتدائي يا منتقل ٿيل عنصر سڀني تائين رسائي وارو نه آهي جيڪڏهن Drain جي تباهي وارو ڪڏهن هلائڻ وارو ناهي.
        //
        //
        // Drain ختم ڪرڻ جي قيمت تي ptr::read ڪندو.
        // جڏهن پورو ٿيو ، باقي ڊيٽا ڪاپي ڪ backي واپس سوراخ کي ڇڪيندا ، ۽ ايڪس ايڪس ايڪس قدرن کي درست طور تي بحال ڪيو ويندو.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // ڊزيڪ جي عنصر ٽن حصن ۾ ورهايل آهن:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // ٽي= self.tail ؛ه=ايڪس 01 ؛t=ڊراين_ٽيٽل ؛ه=drain_head
        //
        // اسان drain_tail کي self.head طور ، ۽ drain_head ۽ self.head طور Z_Drain0Z تي ترتيب ڏيو.
        // اهو پڻ موثر صفائي ختم ڪري ٿو ته جيڪڏهن Drain ليڪ ٿي وڃي ٿو ، اسان drain جي شروعات کان پوءِ امڪاني طور تي منتقل ٿيندڙ قدرن بابت وساري ڇڏيو آهي.
        //
        //
        //        ايڇ ايڇ
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" بابت drain جي شروع ٿيڻ کان پوءِ drain مڪمل ٿيڻ کان پوءِ Drain تباهي ڪندڙ هليو وڃي ٿو.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // وڏي پئماني تي ، اسان هتي صرف `self` مان گڏيل حصا ٺاهيون ٿا ۽ انهي مان پڙهي.
                // اسان ايڪس نيڪس ايڪس کي نه لکندا آهيون ۽ نه ئي متغير حوالن ڏانهن پوئتي.
                // انهيء ڪري اسان مٿي پيدا ڪيل خام پوائنٽر `deque` لاءِ ، صحيح رهي ٿو.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// `VecDeque` کي صاف ڪريو ، سڀ قدر ڪ Cleڻ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// جيڪڏهن `VecDeque` ڏنل عنصر جي برابر عنصر تي مشتمل هجي تو واپسي ڏي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// اڳيان عنصر ، يا `None` کي هڪ حوالو فراهم ڪندو آهي جيڪڏهن `VecDeque` خالي آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// اڳيان عنصر ، يا `None` کي هڪ قابل تبديل ٿيندڙ حوالو فراهم ڪندو آهي جيڪڏهن `VecDeque` خالي آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// پوئتي عنصر ، يا `None` جو حوالو ڏيندو آھي جيڪڏھن `VecDeque` خالي آھي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// پٺتي عنصر ، يا `None` ڏانهن هڪ قابل تغير حوالو فراهم ڪندو آهي ، جيڪڏهن `VecDeque` خالي آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// پهرين عنصر کي ختم ڪري ٿو ۽ ان کي واپس ڏئي ٿو ، يا `None` جيڪڏهن `VecDeque` خالي آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque` کان آخري عنصر ڪي ٿو ۽ ان کي واپس ڏئي ٿو ، يا `None` جيڪڏھن اھو خالي آھي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// `VecDeque` تائين ھڪڙو عنصر تيار ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque` جي پٺ ڏانھن ھڪڙو عنصر شامل ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: ڇا اسان کي `head == 0` تي مطلب وٺڻ تي ڌيان ڏيڻ گھرجي
        // اهو `self` ويجھو آهي؟
        self.tail <= self.head
    }

    /// `VecDeque` ۾ ڪٿي به ھڪڙو عنصر ڪ andي ٿو ۽ ان کي واپس ڪري ، ان کي پھرين عنصر سان بدلائي ٿو.
    ///
    ///
    /// ھي آرڊر سنڀالي نه ٿو ڪري ، پر آھي *او*(1).
    ///
    /// جيڪڏهن `index` حد کان ٻاهر آهي `None` ڏي ٿو.
    ///
    /// انڊيڪس 0 ۾ عنصر قطار ۾ اڳيان آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// `VecDeque` ۾ ڪٿي به عنصر کي ختم ڪري ٿو ۽ ان کي واپس ڪري ، پوئين عنصر سان.
    ///
    ///
    /// ھي آرڊر سنڀالي نه ٿو ڪري ، پر آھي *او*(1).
    ///
    /// جيڪڏهن `index` حد کان ٻاهر آهي `None` ڏي ٿو.
    ///
    /// انڊيڪس 0 ۾ عنصر قطار ۾ اڳيان آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// `VecDeque` ۾ `index` تي ھڪڙو عنصر داخل ڪري ٿو ، س elementsي عنصر اشارن سان `index` کان وڌيڪ يا پوئتي ڏانھن منتقل ڪري ٿو.
    ///
    ///
    /// انڊيڪس 0 ۾ عنصر قطار ۾ اڳيان آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `index` "وييڪ ڊيڪ" جي ڊيگهه کان وڌيڪ آهي
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // رنگ بفر ۾ وڌ کان وڌ عنصرن کي منتقل ڪريو ۽ ڏنل اعتراض داخل ڪيو
        //
        // وڌيڪ len/2 تي ، 1 عنصرن کي منتقل ڪيو ويندو. O(min(n, n-i))
        //
        // ٽي اهم ڪيس آهن:
        //  عنصرن لاڳيتو آهن
        //      - خاص صورت جڏهن دم 0 عناصر نه ھجي ۽ داخل ٿيل دم حصي ۾ آھي عناصر متضاد آھن ۽ داخل ٿيل آھي سر حصي ۾
        //
        //
        // انهن مان هر هڪ ٻه وڌيڪ ڪيس آهن:
        //  داخل ڪنارو ويجھو آهي داخل ڪريو سر جي ويجهو آهي
        //
        // ڪچي: ايڇ ، ايڪسڪسيمڪس
        //      T ، self.tail o ، صحيح عنصر I ، شامل عنصر اي ، اهو عنصر جيڪو داخل ٿيڻ واري پوائنٽ M جي بعد ٿيڻ گهرجي ، اشارو عنصر منتقل ڪيو ويو
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       ٽي آءِ ايڇ
                //      [اڪو!......
                //      .
                //      .]
                //
                //                       ايڇ ٽي
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // ڀرسان ، دم جي ويجهو داخل ڪريو:
                    //
                    //             ٽي آءِ ايڇ
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           ايڇ
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // ويجھو ، دم ۽ دم جي ويجهو داخل ٿيو 0:
                    //
                    //
                    //       ٽي آءِ ايڇ
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       ايڇ ٽي
                    //      [o I A o o o o o . . . . . . . o]
                    //       ايم ايم

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // اڳ ۾ ئي دم منتقل ڪيو ويو ، تنهنڪري اسان صرف `index - 1` عناصر کي نقل ڪيو.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ڀرسان ، سر جي ويجهو داخل ڪريو:
                    //
                    //             ٽي آءِ ايڇ
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             ايڇ
                    //      [. . . o o o o I A o o . . . . .]
                    //                       ايم ڪيو ايم

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // غير متنازع ، دم ، دم حصي جي ويجهو داخل ڪريو:
                    //
                    //                   ايڇ ٽي آءِ
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   ايڇ ٽي
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // غير مطابقت ، سر جي ويجهو ، دم حصي کي داخل ڪريو:
                    //
                    //           ايڇ ٽي آءِ
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             ايڇ ٽي
                    //      [o o o . . . . . . o o o o o I A]
                    //       ايم ڪيو ايم

                    // نئين سر تائين عنصر نقل ڪريو
                    self.copy(1, 0, self.head);

                    // بفر جي تري ۾ آخري عنصر کي خالي جاءِ تي ڪاپي ڪيو
                    self.copy(0, self.cap() - 1, 1);

                    // عنصرن کي عنصرن کان وٺي اڳتي وڌايو جئين نه شامل آهي ^ عنصر
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // غير متنازع ، داخل ڪريو دم ، سر جي حصي جي ويجهو آهي ، ۽ اندروني بفر ۾ صفر صفر تي آهي:
                    //
                    //
                    //       ايڇ اي ٽي
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           ايڇ ٽي
                    //      [A o o o o o o o o o . . o o o I]
                    //                               ايم ڪيو ايم

                    // عنصر کي نقل ڪريو نئين دم تائين
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // بفر جي تري ۾ آخري عنصر کي خالي جاءِ تي ڪاپي ڪيو
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // غير متنازع ، دم جي ويجھو داخل ڪريو ، سر سيڪشن:
                    //
                    //             ايڇ اي ٽي
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           ايڇ ٽي
                    //      [o o I A o o o o o o . . o o o o]
                    //       ايم ڪيو ايم مي ايم ڪيو ايم

                    // عنصر کي نقل ڪريو نئين دم تائين
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // بفر جي تري ۾ آخري عنصر کي خالي جاءِ تي ڪاپي ڪيو
                    self.copy(self.cap() - 1, 0, 1);

                    // ايڪس اي ايم ايڪس کان عناصر منتقل ڪيو اڳتي وڌڻ جي لاءِ عنصر نه شامل آهن
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // غير مطابقت ، سر جي ويجهو ويجھو ، سر حصي:
                    //
                    //               ايڇ اي ٽي
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     ايڇ ٽي
                    //      [o o o o I A o o . . . . . o o o]
                    //                 ايم ڪيو ايم

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // پڇ شايد بدلجي چڪو ھو تنھنڪري اسان کي ٻيهر ڳڻپ ڪرڻ جي ضرورت آھي
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// `VecDeque` کان عنصر ختم ڪري ٿو ۽ واپسي ڪري ٿو `index`.
    /// جيڪو به پڇاڙي ختم ٿيڻ واري ويجهو ويجهو آهي ان کي ڪمرو ڪرڻ لاءِ منتقل ڪيو ويندو ، ۽ سڀني متاثر ٿيندڙ عنصرن کي نئين هنڌن ڏانهن منتقل ڪيو ويندو.
    ///
    /// جيڪڏهن `index` حد کان ٻاهر آهي `None` ڏي ٿو.
    ///
    /// انڊيڪس 0 ۾ عنصر قطار ۾ اڳيان آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // ٽي اهم ڪيس آهن:
        //  عناصر قابل اطمينان آھن عنصر متغير آھن ۽ ڪ theڻ ڪ tailڻ دم جي حصي ۾ آھي عناصر متضاد آھن ۽ ختم ڪرڻ سر حصي ۾ آھي
        //
        //      - خاص ڪيس جڏهن عناصر فني لحاظ سان مفاهمت سان گڏ هجن ، پر self.head =0
        //
        // انهن مان هر هڪ ٻه وڌيڪ ڪيس آهن:
        //  داخل ڪنارو ويجھو آهي داخل ڪريو سر جي ويجهو آهي
        //
        // ڪچي: ايڇ ، ايڪسڪسيمڪس
        //      T ، self.tail o ، صحيح عنصر x ، عنصر کي ختم ڪرڻ جي لاءِ نشان لڳل آر ، ان عنصر کي ظاهر ڪيو وڃي جيڪي ايم کي ختم ڪيو پيو وڃي ، اشارو عنصر منتقل ڪيو ويو
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // ڀرسان ، دم جي ويجهو هٽايو:
                    //
                    //             ايڇ
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               ايڇ
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ڀرسان ، سر جي ويجهو هٽايو:
                    //
                    //             ايڇ
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             ايڇ
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // غير مطابقت ، دم ، دم حصي جي ويجهو هٽايو:
                    //
                    //                   ايڇ ٽي آر
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   ايڇ ٽي
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // غير مطابقت ، سر جي ويجهو ويجھو ، سر سيڪشن:
                    //
                    //               آر ايڇ ٽي
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   ايڇ ٽي
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // غير مطابقت ، سر جي ويجهو ، دم جي حصي کي هٽايو:
                    //
                    //             ايڇ ٽي آر
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           ايڇ ٽي
                    //      [o o . . . . . . . o o o o o o o]
                    //       ايم ڪيو ايم
                    //
                    // يا تقريبن نامڪمل ، مٿو ، دم جي حصي تي هٽايو:
                    //
                    //       ايڇ ٽي آر
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         ايڇ
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // دم جي حصي ۾ عناصر ٺاھيو
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // انهي وهڪري کي روڪي ٿو.
                    if self.head != 0 {
                        // پهرين عنصر کي خالي جاءِ ۾ نقل ڪريو
                        self.copy(self.cap() - 1, 0, 1);

                        // سر جي حصي ۾ عناصر کي پوئتي وڌو
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // غير مطابقت ، tailاٽ جي ويجھو ختم ڪريو ، مٿو سيڪشن:
                    //
                    //           آر ايڇ ٽي
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           ايڇ ٽي
                    //      [o o o o o o o o o o . . . . o o]
                    //       ايم ڪيو ايم ڪيو ايم

                    // آئڪس تائين عناصر ۾ رخ ڪريو
                    self.copy(1, 0, idx);

                    // آخري عنصر کي خالي جاءِ تي نقل ڪريو
                    self.copy(0, self.cap() - 1, 1);

                    // عناصر کي پڇاڙيءَ کان وٺي اڳتي وڌايو ، پوئين ھڪڙي کي ختم ڪندي
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// ڏنل انڊيڪس ۾ `VecDeque` کي ٻن ۾ ورهائي ٿو.
    ///
    /// نئين مختص ڪيل `VecDeque` کي واپس آڻيندي.
    /// `self` عنصر `[0, at)` شامل آھن ، ۽ واپسي `VecDeque` عناصر `[at, len)` تي مشتمل آھي.
    ///
    /// نوٽ ڪريو ته `self` جي گنجائش تبديل نه ٿيندي.
    ///
    /// انڊيڪس 0 ۾ عنصر قطار ۾ اڳيان آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` پهرين اڌ ۾ ڪوڙ آهي.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // رڳو ٻئي اڌ کي وٺو.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` ٻئين اڌ ۾ ڪوڙ آهي ، اسان پهرين جزن ۾ جيڪو عناصر اسان ڇڏي ڏنو انهن جي عنصر کي عنصر ڏيڻ جي ضرورت آهي.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // صفائي جتي بفرن جا آخري پاڙا آهن
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other` جي سڀني عنصرن کي `self` ۾ منتقل ڪري ٿو ، `other` کي خالي ڪري ڇڏي ٿو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن پاڻ ۾ عنصر جا نوان انگ ايڪس ايڪس ايڪس تي وڌي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // غير معمولي نقشو
        self.extend(other.drain(..));
    }

    /// اڳڪٿيءَ طرفان مقرر ڪيل عنصرن کي برقرار رکيو ٿو وڃي.
    ///
    /// ٻين لفظن ۾ ، `e` سڀني عنصرن کي ختم ڪريو ته `f(&e)` غلط موٽائي ٿو.
    /// اهو طريقو جڳهه ۾ هلندو آهي ، هر عنصر کي اصل ۾ هڪ ڀيرو جي اصلي ترتيب ۾ ڏسي ٿو ، ۽ برقرار ڪيل عناصر جي ترتيب کي محفوظ ڪري ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// صحيح ترتيب ٻاهرئين حالت کي نظر ۾ رکڻ لاءِ ڪارائتو ٿي سگهي ٿي ، جهڙوڪ هڪ انڊيڪس.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // اهو ٿي سگهي ٿو panic يا ختم ڪريو
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // بفر سائيز کي ٻيڻو ڪريو.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` کي جڳهه ۾ تبديل ڪري ٿو ، تنھن ڪري `len()` `new_len` جي برابر آھي ، يا ته پوئتي کان وڌيڪ عناصر ختم ڪندي يا `generator` کي ڪال ڪري ٺاھيندڙ عناصر کي ڳن byڻ سان.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// ھن ديق جي اندروني ذخيري کي وري ترتيب ڏيو ته اھا ھڪڙي ويجھي ٻلي آھي ، جيڪا پوءِ واپس ڪئي ويندي آھي.
    ///
    /// اهو طريقو مختص نه ڪيو ويو آهي ۽ داخل ٿيل عناصر جي ترتيب کي تبديل نه ڪندو آهي.جئين اهو هڪ بدلي واري ٻلي کي موٽائيندو آهي ، اهو ڊيڪ کي ترتيب ڏيڻ لاءِ استعمال ٿي سگهي ٿو.
    ///
    /// اندروني اسٽوريج ويجهڙائي سان ، [`as_slices`] ۽ [`as_mut_slices`] طريقا `VecDeque` جي مڪمل مواد کي هڪ ئي سلائس ۾ واپس آڻيندي.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// ديدار جي مواد کي ترتيب ڏيڻ.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // ڊيڪ کي ترتيب ڏيڻ
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // ان کي ترتيب ڏيڻ سان ريورس ترتيب ۾
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// سنگتي سلائس تائين بي عيب رسائي حاصل ڪرڻ.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // اسان هاڻي اهو پڪ سان چئي سگهون ٿا ته `slice` ڊيڪ جي سڀني عنصرن تي مشتمل آهي ، جڏهن ته اڃا تائين `buf` جي مٽاسٽا واري رسائي آهي.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // هڪ طرف ۾ دم کي نقل ڪرڻ لاءِ ڪافي مفت جاءِ موجود آهي ، ان جو مطلب اهو آهي ته اسان پهرين تي سر کي پوئتي طرف وڃون ٿا ، ۽ پوءِ دُم کي صحيح جاءِ تي نقل ڪيو.
            //
            //
            // کان: ڊيفگ ايڇ .... اي بي سي
            // ڏانهن: اي بي سي ڊي ايف جي ايڇ ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: في الحال اسان غور نه ڪيو .... ABCDEFGH
            // ويجھڙائي جي ڇاڪاڻ ته `head` ھن صورت ۾ `0` ٿي ويندا.
            // جيتوڻيڪ اسان شايد هن کي تبديل ڪرڻ چاهيون ٿا ، اهو نن isn'tڙو نه هوندو آهي ڇاڪاڻ ته ڪجهه هنڌن تي `is_contiguous` جي توقع آهي ته اسان صرف `buf[tail..head]` کي سلائي ڪري سگهنداسين.
            //
            //

            // هڪ طرف ۾ سر کي نقل ڪرڻ لاءِ ڪافي مفت جڳھ موجود آھي ، ان جو مطلب اھو آھي ته اسان پھريائين ھڪڙو دم کي مٿي طرف منتقل ڪيو ، ۽ پوءِ سر کي نقل ڪيو صحيح جاءِ تي.
            //
            //
            // کان: ايف جي ايڇ .... اي بي سي ڊي اي
            // ڏانهن: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // ٻئي سر ۽ دم جي ڀيٽ ۾ نن isا نن isا آهن ، انهي جو مطلب آهي اسان کي سست ۽ سر کي "swap" سست ڪرڻو آهي.
            //
            //
            // مان: اي ايف گئي ... اي بي سي ڊي يا ايڪسڪسيمڪس
            // ڪرڻ: ABCDEFGHI ... يا ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // عام مسئلو اهو ڏسجي ٿو هن GHIJKLM ... ABCDEF ، ڪنهن به تبادلي جي ABCDEFM کان ... GHIJKL ، 1 پاسن جا مٽجڻ بعد ABCDEFGHIJM ... KL ، swap جيستائين کاٻي edge عارضي دڪان تي پهچي وڃي
                //                  - وري الگورڊيم کي ٻيهر نئون x00X اسٽور سان شروع ڪريو ڪڏهن ڪڏهن عارضي دڪان تي پهچي ويندو آهي جڏهن صحيح edge بفر جي آخر ۾ آهي ، انهي جو مطلب آهي ته اسان ٿورين ادل سان صحيح حڪم تي ڌڪايو آهي.
                //
                // E.g
                // اي ايف .. اي بي سي ڊي بي ڊي .. .. ، صرف چار ٺاھڻ بعد اسان مڪمل ڪيو آھي
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// دڙي ختم ٿيل قطار `mid` جڳهن کي کاٻي طرف گھمائي ٿو.
    ///
    /// Equivalently,
    /// - شھر `mid` کي پھرئين پوزيشن ۾ گھمائيندو.
    /// - پهرين `mid` شيون ڪيون آهن ۽ آخر تائين ڌڪيو.
    /// - `len() - mid` جڳھن کي سا toي طرف گھمائيندو.
    ///
    /// # Panics
    ///
    /// جيڪڏهن `mid` `len()` کان وڌيڪ آهي.
    /// ياد رکو ته `mid == len()` _not_ panic ڪندو آهي ۽ ڪو او پي گردش آهي.
    ///
    /// # Complexity
    ///
    /// `*O*(min(mid, len() - mid))` وقت وٺندو آهي ۽ اضافي جڳهه نه.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// دڙي ختم ٿيل قطار `k` جڳهين کي سا toي طرف گھمائيندو.
    ///
    /// Equivalently,
    /// - پهرين شيون کي پوزيشن `k` ۾ گھمائيندو.
    /// - پويون ايڪس ايڪس ايڪس شيون پوپ ڪري انهن کي اڳيان جي زور تي ڌڪي ٿو.
    /// - کاٻي پاسي `len() - k` جڳھيون گھمائيندو.
    ///
    /// # Panics
    ///
    /// جيڪڏهن `k` `len()` کان وڌيڪ آهي.
    /// ياد رکو ته `k == len()` _not_ panic ڪندو آهي ۽ ڪو او پي گردش آهي.
    ///
    /// # Complexity
    ///
    /// `*O*(min(k, len() - k))` وقت وٺندو آهي ۽ اضافي جڳهه نه.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // محفوظ: هيٺين ٻن طريقن جي ضرورت آهي جيڪي گردش جي رقم
    // ڏاڪڻ جي ڊيگهه کان به گھٽ آهي.
    //
    // `wrap_copy` جي ضرورت آهي `min(x, cap() - x) + copy_len <= cap()` ، پر `min` کان وڌيڪ ڪڏهن به اڌ جي گنجائش کان وڌيڪ ڪونهي ، البته x جي پرواهه ناهي ، انهي ڪري هتي فون ڪرڻ جو آواز آهي ڇو ته اسان اڌ شي کان ڪجهه گهٽ آهي ، جنهن جي اڌ گنجائش کان مٿي ڪڏهن به ناهي.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// بائنري ھڪڙي ڏنل عنصر لاء `VecDeque` ھن ترتيب ڏيو.
    ///
    /// جيڪڏهن ويليو ملي وڃي ته [`Result::Ok`] موٽيل آهي ، ملندڙ عنصر جي انڊيڪس تي مشتمل آهي.
    /// جيڪڏهن ڪيتريون ئي ميچون هجن ، ته ميچن مان ڪو به واپس ٿي سگهي ٿو.
    /// جيڪڏهن قدر نه ملي ته پوءِ [`Result::Err`] واپس اچي ويو ، انڊيڪس تي مشتمل آهي جتي هڪ مماثل عنصر داخل ٿي سگهيو آهي جڏهن ته ترتيب وار ترتيب برقرار رکيو وڃي.
    ///
    ///
    /// # Examples
    ///
    /// ڏسڻ ۾ اچي ٿو چئن عنصرن جي هڪ سيريز.
    /// پهريون مليو آهي ، هڪ منفرد طور تي طئي ٿيل مقام سان.ٻيو ۽ ٽيون نه مليو آهيچوٿون `[1, 4]` ۾ ڪنهن به پوزيشن سان مائل ٿي سگهي ٿو.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// جيڪڏهن توهان ترتيب وار ترتيب برقرار رکڻ دوران هڪ شيءَ کي ترتيب ڏنل `VecDeque` ۾ داخل ڪرڻ چاهيو ٿا:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// بائنري هڪ ترتيب ڏيندڙ فنڪشن سان ترتيب ڏنل `VecDeque` کي ڳوليندو آهي.
    ///
    /// تقابلي وارو فنڪشن ايڪس آرڪس جي ترتيب جي ترتيب سان مطابقت رکندڙ هڪ آرڊر کي لاڳو ڪرڻ گهرجي ، آرڊر ڪوڊ واپس ڏي ٿو جيڪو ظاهر ڪري ٿو ته انهي جو دليل مطلوبه هدف کان `Less` ، `Equal` يا `Greater` آهي.
    ///
    ///
    /// جيڪڏهن ويليو ملي وڃي ته [`Result::Ok`] موٽيل آهي ، ملندڙ عنصر جي انڊيڪس تي مشتمل آهي.جيڪڏهن ڪيتريون ئي ميچون هجن ، ته ميچن مان ڪو به واپس ٿي سگهي ٿو.
    /// جيڪڏهن قدر نه ملي ته پوءِ [`Result::Err`] واپس اچي ويو ، انڊيڪس تي مشتمل آهي جتي هڪ مماثل عنصر داخل ٿي سگهيو آهي جڏهن ته ترتيب وار ترتيب برقرار رکيو وڃي.
    ///
    /// # Examples
    ///
    /// ڏسڻ ۾ اچي ٿو چئن عنصرن جي هڪ سيريز.پهريون مليو آهي ، هڪ منفرد طور تي طئي ٿيل مقام سان.ٻيو ۽ ٽيون نه مليو آهيچوٿون `[1, 4]` ۾ ڪنهن به پوزيشن سان مائل ٿي سگهي ٿو.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// بائنري انهي طريقي سان ايڪس سوڪس ايڪس کي هڪ اهم نڪتل فنڪشن سان ڳولي ٿو.
    ///
    /// فرض ڪري ٿو ته `VecDeque` کي ترتيب سان چيڪ ڪيو ويو آهي ، مثال طور [`make_contiguous().sort_by_key()`](#method.make_contiguous) سان گڏ هڪ ئي اهم نڪتي فنڪشن کي استعمال ڪندي.
    ///
    ///
    /// جيڪڏهن ويليو ملي وڃي ته [`Result::Ok`] موٽيل آهي ، ملندڙ عنصر جي انڊيڪس تي مشتمل آهي.
    /// جيڪڏهن ڪيتريون ئي ميچون هجن ، ته ميچن مان ڪو به واپس ٿي سگهي ٿو.
    /// جيڪڏهن قدر نه ملي ته پوءِ [`Result::Err`] واپس اچي ويو ، انڊيڪس تي مشتمل آهي جتي هڪ مماثل عنصر داخل ٿي سگهيو آهي جڏهن ته ترتيب وار ترتيب برقرار رکيو وڃي.
    ///
    /// # Examples
    ///
    /// انهن جي ٻئي عنصرن طرفان ترتيب ڏنل جوڑوں جي هڪ سلي ۾ چئن عنصرن جي هڪ سيريز کي ڏسجي ٿي.
    /// پهريون مليو آهي ، هڪ منفرد طور تي طئي ٿيل مقام سان.ٻيو ۽ ٽيون نه مليو آهيچوٿون `[1, 4]` ۾ ڪنهن به پوزيشن سان مائل ٿي سگهي ٿو.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `VecDeque` کي جڳهه ۾ تبديل ڪري ٿو ته `len()` نئين_ لينن جي برابر آھي ، يا ته پوئتي کان وڌيڪ عناصر کي ختم ڪندي يا `value` جي ڪلون کي پوئتي کان واپس ڪندي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// ڏنل منطقي عنصر انڊيڪس لاءِ ھيٺ ڏنل بفر ۾ انڊيڪس ڏي ٿو.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // سائيز هميشه 2 جي طاقت آهي
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// بفر ۾ پڙهڻ لاءِ رکيل عناصر جي تعداد کي ڳڻيو
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // سائيز هميشه 2 جي طاقت آهي
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // هميشه ٽن حصن ۾ ورهائيندڙ ، مثال طور: خود: [a b c|d e f] ٻيا: [0 1 2 3|4 5] front=3 ، mid=1 ، [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // اهو ممڪن ناهي ته X_Hash::hash_slice سلائسز تي موٽيل ايس_سليس طريقي سان استعمال ڪن ڇاڪاڻ ته انهن جي ڊيگهه ٻي صورت ۾ هڪجهڙا واري ديوتا ۾ مختلف ٿي سگهي ٿي.
        //
        //
        // هشر صرف ان جي طريقن جي ڪالن جي ساڳي سيٽ جي برابر برابر جي ضمانت ڏئي ٿو.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// `VecDeque` کي ميسجورٽ کان واپس ايٽرر ۾ عناصر پيدا ڪري ٿو قدر کان.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // اهو ڪارڪردگي اخلاقي برابر هجڻ گهرجي:
        //
        //      ايڪس آرڪس ۾ شيءَ لاءِ {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// اي [`Vec<T>`] کي [`VecDeque<T>`] ۾ يرايو.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// اهو ممڪن طور تي هٽائي وڃڻ کان پاسو ڪري ٿو ، پر ان لاءِ حالتون سخت آهن ، ۽ تبديلي جي تابع آهن ، ۽ انهي تي انحصار نه ڪرڻ گهرجي جيستائين ايستائين `Vec<T>` `From<VecDeque<T>>` وٽان اچي ۽ ٻيهر نه هلايو وڃي.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // اصل ۾ ZSTs جي گنجائش جي باري ۾ پريشان ڪرڻ جي باري ۾ مختص ناهي ، پر `VecDeque` `Vec` جيترو ڊگهو نٿو ڪري سگهي.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // اسان کي ٻيهر سائيز جي ضرورت آهي جيڪڏهن گنجائش ٻه جي طاقت نه آهي تمام نن smallا آهن يا گهٽ ۾ گهٽ هڪ خالي جڳهه ناهي.
            // اسان اهو اڃا تائين ڪيو جڏهن ته اهو اڃا تائين `Vec` ۾ آهي تنهنڪري شيون panic تي ڇڏينداسين.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// اي [`VecDeque<T>`] کي [`Vec<T>`] ۾ يرايو.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// اهو ڪڏهن به ٻيهر مختص ڪرڻ جي ضرورت ناهي ، پر ڊيٽا O تحريڪ *O*(*n*) ڪرڻ جي ضرورت آهي جيڪڏهن سرڪيولر بفر مختص جي شروعات ۾ ٿيڻ نه گهرجي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // هي هڪ آهي *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // اھو ھڪڙي ڊيٽا کي ترتيب ڏيڻ جي ضرورت آھي.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}