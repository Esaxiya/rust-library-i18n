use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Vec::from_iter لاءِ استعمال ٿيل خصوصيزيشن trait
///
/// ## وفد جو گراف:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // هڪ عام ڪيس vector کي ڪم ۾ لڳائي رهيو آهي جيڪو فوري طور تي vector کي ٻيهر گڏ ڪري ٿو.
        // اسان ان کي شارٽ سرڪٽ ڪري سگھون ٿا جيڪڏھن انٽيٽر تمام ترقي نه ڪئي وئي آھي.
        // جڏھن اھو اڳيئي ٿي ويو آھي اسين ميموري کي وري استعمال ڪري ۽ ڊيٽا کي پھريائين ڏانھن منتقل ڪري سگھون ٿا.
        // پر اسان اهو صرف انهي وقت ڪريون ٿا جڏهن نتيجو ڪندڙ وييڪ جي عام طور تي ايٽرآئيٽر ايڏي تي عملدرآمد ڪرڻ کان وڌيڪ استعمال ٿيل گنجائش نه هوندي.
        //
        // انهي حد جي سختي سان ضروري ناهي ، جيئن ويڪ جي مختص ڪيل رويي ارادي طور تي اڻ ifiedاتل آهي.
        // پر اهو هڪ قدامت پسند انتخاب آهي.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // ايڪس ويڪس کان وٺي extend() ڏانهن موڪليل لازمي طور تي خالي Vecs لاءِ spec_from کان ڊيليگيٽ ڪرڻ لازمي آهي
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// اهو `iterator.as_slice().to_vec()` استعمال ڪندو آهي ڇاڪاڻ ته spec_extend حتمي صلاحيت + ڊيگهه بابت دليل ڏيڻ لاءِ وڌيڪ قدم کڻڻا پون ٿا ۽ انهي ڪري وڌيڪ ڪم ڪيو وڃي.
// `to_vec()` سڌو سنئون صحيح رقم مختص ڪري ٿو ۽ ان کي پوري طرح ڀريندو آهي.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) سان گڏ موروثي `[T]::to_vec` طريقو ، جيڪو ھن طريقي جي تعريف جي لاءِ گھربل آھي ، دستياب ناھي.
    // بدران `slice::to_vec` فنڪشن استعمال ڪريو جيڪو صرف cfg(test) NB سان دستياب آھي وڌيڪ slice.rs ۾ slice::hack ماڊل ڏسو وڌيڪ معلومات لاءِ
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}