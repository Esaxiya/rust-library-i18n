//! هجوم مختص ڪيل مواد سان گڏ ، هڪ س growو وڌندڙ وڌندڙ قسم جو قسم ، `Vec<T>` لکيل.
//!
//! Vectors وٽ `O(1)` indexing ، ڳري وئي `O(1)` پش (آخر تائين) ۽ `O(1)` پاپ (آخر کان).
//!
//!
//! Vectors يقيني بڻائين ته اهي ڪڏهن به `isize::MAX` بائٽس کان وڌيڪ مختص نٿا ڪن.
//!
//! # Examples
//!
//! توهان واضح طور تي [`Vec::new`] سان هڪ [`Vec`] ٺاهي سگهو ٿا:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! يا [`vec!`] ميڪرو استعمال ڪندي:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // ڏھ زيرو
//! ```
//!
//! توهان vector جي آخر تائين [`push`] قدرون ڪري سگهو ٿا (جيڪو ضرورت طور vector وڌائيندو):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! پاپنگ ويليو ساڳئي طريقي سان ڪم ڪن ٿا:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors پڻ انڪسنگ سپورٽ ڪندو آهي ([`Index`] ۽ [`IndexMut`] ٽيٽرز ذريعي):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// هڪ ويجهڙائي واري وڌندڙ صف واري قسم ، `Vec<T>` طور لکيو ۽ 'vector' ظاهر ڪيو ويو آهي.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`] ميڪرو مهيا ڪئي وئي آهي انهي جي شروعات کي وڌيڪ آسان بڻائڻ لاءِ.
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// اهو پڻ `Vec<T>` جي هر عنصر کي ڏنل قيمت سان گڏ شروع ڪري سگهي ٿو.
/// اهو حصو مختص ڪرڻ ۽ الڳ مرحلن ۾ شروعات ڪرڻ کان وڌيڪ ڪارائتو ٿي سگھي ٿو ، خاص طور تي جڏهن زيروز جي ويڪٽر کي شروعات ڪرڻ:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // هيٺيان برابر آھي ، پر ممڪن طور تي سست:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// وڌيڪ معلومات لاءِ ڏسو [Capacity and Reallocation](#capacity-and-reallocation).
///
/// ھڪڙي موثر اسٽيڪ جي طور تي `Vec<T>` استعمال ڪريو:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // پرنٽ 3 ، 2 ، 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec` قسم انڊيڪس پاران قدرن تائين رسائي جي اجازت ڏئي ٿو ، ڇاڪاڻ ته اهو [`Index`] trait لاڳو ڪري ٿو.ھڪڙو مثال وڌيڪ واضح ٿيندو:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // اهو '2' ڏيکاريندو
/// ```
///
/// تنهن هوندي به محتاط رهو: جيڪڏهن توهان هڪ انڊيڪس پهچائڻ جي ڪوشش ڪئي جيڪا `Vec` ۾ نه آهي ، توهان جو سافٽ ويئر panic هوندو!توهان اهو نٿا ڪري سگهو:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// جيڪڏهن توهان چڪاس ڪرڻ چاهيو ته آيا انڊيڪس `Vec` ۾ آهي ته [`get`] ۽ [`get_mut`] استعمال ڪريو.
///
/// # Slicing
///
/// هڪ `Vec` مٽائي سگهجي ٿو.ٻئي طرف ، سلائسون صرف پڙهيل شيون آهن.
/// هڪ [slice][prim@slice] حاصل ڪرڻ لاءِ ، [`&`] استعمال ڪريو.مثال ؛
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... ۽ اهو سڀ ڪجهه آهي!
/// // توهان اهو انهي وانگر ڪري سگهو ٿا.
/// let u: &[usize] = &v;
/// // يا هن وانگر:
/// let u: &[_] = &v;
/// ```
///
/// Rust ۾ ، عام طور تي vectors جي بدران سلائيز کي پاس ڪرڻ وڌيڪ عام آهي جڏهن توهان صرف پڙهڻ جي رسائي فراهم ڪرڻ چاهيو ٿا.[`String`] ۽ [`&str`] لاءِ به ساڳيو آهي.
///
/// # گنجائش ۽ بحالي جو ڪم
///
/// vector جي گنجائش ڪنهن future عناصر لاءِ مختص ڪيل جڳهه آهي جيڪا vector تي شامل ڪئي ويندي.اهو vector جي *لمبائي* سان خلل نه هجڻ جي برابر آهي ، جيڪو vector اندر حقيقي عناصر جو تعداد بيان ڪري ٿو.
/// جيڪڏهن هڪ vector جي ڊيگهه انهي جي گنجائش کان وڌي ٿي ، انهي جي گنجائش خودڪار طور وڌي ويندي ، پر ان جي عنصرن کي ٻيهر ترتيب ڏيڻو پوندو.
///
/// مثال طور ، ويڪٽر گنجائش 10 ۽ ڊيگهه 0 خالي ويڪٽر آهي 10 وڌيڪ عنصر لاءِ جاءِ.vector تي 10 يا گهٽ عناصر کي زور ڏيڻ سان ان جي گنجائش تبديل نه ٿيندي يا وري ريٽووليشن واقع ٿيڻ جو سبب ٿيندو.
/// تنهن هوندي ، جيڪڏهن vector جي ڊيگهه 11 تائين وڌي وڃي ، ان کي ٻيهر ورجائڻو پوندو ، جيڪو سستي ٿي سگهي ٿو.انهي سبب سان ، جڏهن به ممڪن ٿي سگھي ٿو اهو [`Vec::with_capacity`] استعمال ڪرڻ جي سفارش ڪئي وڃي ٿي ته vector ڪيترو وڏو حاصل ڪرڻ جي اميد هجي.
///
/// # Guarantees
///
/// ان جي غيرمعمولي طور تي بنيادي فطرت جي ڪري ، `Vec` هن جي ڊيزائن بابت تمام گهڻي ضمانت ڏي ٿو.انهي کي يقيني بڻائي ٿي ته اهو عام صورت ۾ جيترو ممڪن آهي گهٽ وڌ ۾ وڌ ، ۽ غير محفوظ ڪوڊ ذريعي ابتدائي طريقن سان صحيح طريقي سان هٿان رکي سگهجي.ياد رکجو ته اهي ضمانتون هڪ نا اهل `Vec<T>` جي حوالي ڪن ٿيون.
/// جيڪڏهن اضافي قسم جا پيراگراف شامل ڪيا ويا (مثال طور ، ڪسٽم مختص ڪندڙن کي سپورٽ ڪرڻ) ، انهن جي رٿا کي رد ڪرڻ شايد رويي کي تبديل ڪري.
///
/// سڀ کان بنيادي طور تي ، ايڪسڪسيمڪس آهي ۽ هميشه ٿيندو (پوائنٽر ، گنجائش ، لمبائي) ٽيللوٽ.وڌيڪ نه ، گهٽ ناهي.انهن شعبن جي ترتيب مڪمل طور تي لاقانوني آهي ، ۽ توهان کي انهن کي ترميم ڪرڻ لاءِ مناسب طريقا استعمال ڪرڻ گهرجن.
/// پوائنٽر ڪڏھن ھلڪو نه ٿيندو ، تنھنڪري ھيءَ قسم null-pointer-optimized.
///
/// تنهن هوندي ، پوائنٽر اصل ۾ مختص ڪيل يادگيري ڏانهن اشارو نٿو ڪري سگهي.
/// خاص طور تي ، جيڪڏهن توهان `Vec` ، [`vec![]`][`vec!`] ، [`Vec::with_capacity(0)`][`Vec::with_capacity`] ، يا [`shrink_to_fit`] کي خالي Vec تي ڪال ڪرڻ سان `Vec` گنجائش سان تعمير ڪريو ٿا ، اهو يادگيري مختص نه ڪندو.ساڳي طرح ، جيڪڏهن توهان `Vec` اندر صفر واري قسم جا دڪان رکندا آهيو ، اهو انهن لاءِ جڳهه مختص نه ڪندو.
/// *ياد رکجو ته ان صورت ۾ `Vec` 0* جي [`capacity`] رپورٽ نٿو ڪري سگھي.
/// `Vec` جيڪڏهن مختص ڪيا ويندا ته ۽ صرف جيڪڏهن ["ميم: : size_of::<T>"]() * capacity()> 0".
/// عام طور تي ، "وييڪ" جي مختص ڪيل تفصيل تمام نازڪ آهي-جيڪڏهن توهان `Vec` کي استعمال ڪندي ياداشت کي مختص ڪرڻ ۽ ڪنهن ٻئي شي جي لاءِ استعمال ڪرڻ جو ارادو ڪيو آهي (يا ته غير محفوظ ڪوڊ کي پاس ڪرڻ لاءِ ، يا توهان جي پنهنجي ميموري واري هڪ محفوظ ڪيل عمارت ٺاهڻ جي لاءِ) ، يقين رکو. X0 `from_raw_parts` کي بحال ڪرڻ ۽ `Vec` کي بحال ڪرڻ ذريعي استعمال ڪندي هن يادگيري کي رد ڪرڻ.
///
/// جيڪڏهن هڪ `Vec` * مختص ڪيل ميموري آهي ، ته ميموري انهي ڏانهن اشارو ڪري ٿي (جيئن مختص ڪيل Rust ترتيب ڏنل طور تي استعمال ڪرڻ لاءِ ترتيب ڏنل آهي) ، ۽ هن جو اشارو [`len`] شروعاتي ، متضاد عناصر ڏانهن اشارو ڪيو آهي (توهان ڇا ڪريو ها) ڏسو ته ڇا توهان ان کي هڪ ٻلي ۾ مجبور ڪيو) ، بعد ۾ ["صلاحيت"] ، "[" لين "] منطقي طور تي غير ابتدائي ، جڙيل عناصر.
///
///
/// هڪ vector جنهن ۾ عناصر `'a'` ۽ `'b'` موجود آهن 4 جي گنجائش هيٺ ڏجن ٿا.مٿين حصو `Vec` ساخت آهي ، ان ۾ هيڪ ، ڊيگهه ۽ گنجائش ۾ مختص جي سر جي پوائنٽر آهي.
/// هيٺيون حصو اسپيپ تي مختص آهي ، سموري يادگيري بلاڪ.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **انوٽ** ياداشت کي ظاھر ڪري ٿو جيڪو شروعاتي ڪونھي ، [`MaybeUninit`] کي ڏسو.
/// - Note: اي بي آئي مستحڪم ناهي ۽ ايڪس سيڪس پنهنجي ياداشت جي خاطري جي باري ۾ ڪا به ضمانت نه ٿو ڏئي (فيلڊ جي ترتيب سميت).
///
/// `Vec` ايڪس ايڪس ايڪس ڪڏهن به انجام نه ڏيندو ، جتي عناصر اصل ۾ ٻه سببن لاءِ اسٽيڪ تي ذخيرو ٿيل آهن.
///
/// * اهو `Vec` کي صحيح طريقي سان ترتيب ڏيڻ لاءِ غير محفوظ ڪوڊ لاءِ وڌيڪ ڏکيو ڪندو.هڪ `Vec` جو مواد مستحڪم پتو نه هوندو جيڪڏهن اهو صرف منتقل ڪيو وڃي ها ، ۽ اهو معلوم ڪرڻ وڌيڪ ڏکيو هوندو جيڪڏهن `Vec` اصل ۾ ميموري هوندي.
///
/// * اهو عام ڪيس کي ڏنڊ ڏيندو ، هر رسائي تي اضافي branch اضافي هوندو.
///
/// `Vec` پاڻ کي ڪڏهن به گھٽائڻ نه ڏيندو ، جيتوڻيڪ مڪمل طور تي خالي آهي.اهو يقيني بڻائي ٿو ته ڪو غير ضروري مختص يا نيڪالي واقع نه ٿيندي.`Vec` کي خالي ڪرڻ ۽ پوءِ انهي کي ٻيهر ڀرڻ ساڳيا [`len`] ڪم ڪرڻ گھرجي ڪو مختصڪار لاءِ ڪو ڪال.جيڪڏهن توهان اڻ استعمال ڪيل ميموري خالي ڪرڻ چاهيو ٿا ، [`shrink_to_fit`] يا [`shrink_to`] استعمال ڪريو.
///
/// [`push`] ۽ [`insert`] ڪڏهن به (ٻيهر) مختص نه ڪندو جيڪڏهن capacityاڻايل اطلاع ڪافي آهي.[`push`] ۽ [`insert`]*(*) مختص ڪندو جيڪڏھن ["لين"]=="[" صلاحيت "].اهو آهي ، capacityاڻايل گنجائش مڪمل طور تي صحيح آهي ، ۽ ڀروسو ڪري سگهجي ٿو.اهو پڻ استعمال ڪري سگهجي ٿو دستي طور تي خالي ڪيل ياداشت کي `Vec` پاران مختص ڪيل جيڪڏهن گهربل هجي.
/// گھڻي ويڙھڻ جا طريقا *شايد* ٻيهر ورجائي سگھن ٿا ، جيتوڻيڪ ضروري ناھي.
///
/// `Vec` جڏهن بحالي مڪمل ٿيندي ، ۽ نه ئي جڏهن [`reserve`] سڏيو ويندو آهي.موجوده حڪمت عملي بنيادي آهي ۽ اها غير مستقل واڌاري جي عنصر جي استعمال جي خواهش ثابت ٿي سگهي ٿي.جيڪو به حڪمت عملي جو استعمال ڪيو ويندو يقيني طور تي ضمانت ڏيندو *O*(1) [`push`] ختم ٿيل.
///
/// `vec![x; n]`, `vec![a, b, c, d]` ، ۽ [`Vec::with_capacity(n)`][`Vec::with_capacity`] ، سڀ ڪجهه مڪمل طور تي درخواست ڪيل ظرفيت سان `Vec` پيدا ڪندو.
/// جيڪڏهن ["لين"]=="[صلاحيت"] ، (جيئن [`vec!`] ميڪرو جي لاءِ آهي) ، ته پوءِ `Vec<T>` انهن عناصر کي ٻيهر ترتيب ڏيڻ يا منتقل ڪرڻ کانسواءِ [`Box<[T]>`][owned slice] ۾ ۽ بدلائي سگهجي ٿو.
///
/// `Vec` ڪنهن خاص ڊيٽا کي وڌيڪ نه لکندي جيڪا ان کي ڪ thatيو وڃي ، پر خاص طور تي ان کي محفوظ نه ڪندو.ان جي غير ابتدائي ميموري خرچي واري جاءِ آهي جيڪا ان کي استعمال ڪندي جيڪا چاهي ٿي ٿي سگهي ٿي.اهو عام طور تي صرف ڪري وٺندو جيڪو ڪجھ گهڻو ڪارائتو آهي يا ٻي صورت ۾ لاڳو ڪرڻ آسان آهي.سيڪيورٽي مقصدن لاءِ ختم ٿيل ڊيٽا تي ڀروسو نه ڪريو.
/// جيتوڻيڪ جيڪڏهن توهان `Vec` ڇڏي ڏيو ، اهو بفر ٻئي `Vec` کي ٻيهر استعمال ڪري سگهجي ٿو.
/// جيتوڻيڪ جيڪڏهن توهان پهرين هڪ `وييڪ` جي يادگيري کي صفر ڪيو ، شايد اهو اصل ۾ ڪونه ٿي سگهي ها ڇاڪاڻ ته انٽيليزر انهي پاسي واري اثر تي غور نٿو ڪري سگهي جيڪو ضرور محفوظ ٿيڻ گهرجي.
/// اتي هڪ صورت آهي ، جنهن کي اسان ٽوڙڻ نه ڏينداسين: اضافي گنجائش ڏانهن لکڻ لاءِ `unsafe` ڪوڊ استعمال ڪرڻ ، ۽ پوءِ ميچ کي لمبائي وڌائڻ هميشه صحيح آهي.
///
/// في الحال ، ايڪس آرڪس انهي حڪم جي گارنٽي نه ٿو ڏئي جنهن ۾ عناصر areٽي ويندا آهن.
/// ماضي ۾ ترتيب تبديل ٿي چڪو آھي ۽ ٻيهر تبديل ٿي سگھي ٿو.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// موروثي طريقو
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// هڪ نئين ، خالي `Vec<T>` جي تعمير تي.
    ///
    /// vector ايستائين مختص نه ڪندو جيستائين عناصر ان تي ڇڪي نه سگهجن.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// مخصوص گنجائش سان نئون ، خالي `Vec<T>` تعمير ڪندو آهي.
    ///
    /// vector واقعي بغير `capacity` عناصر کي برقرار رکڻ جي قابل هوندو.
    /// جيڪڏهن `capacity` 0 آهي ، vector مختص نه ڪندو.
    ///
    /// اهو نوٽ ڪرڻ ضروري آهي ته جيتوڻيڪ واپسي vector وٽ *گنجائش* مخصوص ٿيل آهي ، vector صفر *ڊگهو* آهي.
    ///
    /// لمبائي ۽ گنجائش جي فرق جي وضاحت لاءِ ، ڏسو *[ڪيپيسٽي ۽ وري اسٽائلشن]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector ڪوبه شيون ناهي ، جيتوڻيڪ هن ۾ وڌيڪ گنجائش آهي
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // هي سڀ ڪم هڻڻ کان سواءِ ڪيا ويندا آهن ۔۔۔
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... پر اهو شايد vector کي ٻيهر ترتيب ڏئي سگهي ٿو
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// هڪ `Vec<T>` سڌو vector جي خام حصن مان سڌو ٺاهيندي آهي.
    ///
    /// # Safety
    ///
    /// اهو انتهائي غير محفوظ آهي ، سببن جي تعداد جي ڪري جيڪي چڪاس نه ڪيا ويا آهن:
    ///
    /// * `ptr` [اسٽرنگ`]/`وييڪ ذريعي مختص ڪرڻ جي ضرورت آهي<T>"(گهٽ ۾ گهٽ ، اهو غلط هجڻ ممڪن آهي جيڪڏهن اهو نه هجي).
    /// * `T` `ptr` سان گڏ ساڳيو سائيز ۽ ترتيب رکڻ جي ضرورت آهي.
    ///   (`T` وٽ ھڪڙو سخت گھاٽو رکڻ ڪافي نه آھي ، ايڪس آرڪس واقعي کي پورو ڪرڻ جي لاءِ واقعي جي برابر ھجڻ لازمي آھي يادگيري کي لازمي طور تي ترتيب ڏيڻ ۽ ساڳي ترتيب سان ختم ٿيل آھي.)
    ///
    /// * `length` `capacity` کان گھٽ يا برابر جي ضرورت آھي.
    /// * `capacity` اهو ٿيئڻ جي ضرورت آهي جنهن جي پوائنٽر سان مختص ڪيا ويا.
    ///
    /// انهن جي ڀڃڪڙي ڪرڻ شايد ايلوڪيٽر جي داخلي ڊيٽا جي اڏاوتن کي بگاڙڻ وانگر مسئلا پيدا ڪري سگهي ٿو.مثال طور اهو **نا** محفوظ آهي ايڪس ايڪس ڊيڪس پوائنٽر کان سي `char` صف تائين `size_t` سان `Vec<u8>` ٺاهي.
    /// اهو `Vec<u16>` ۽ ان جي ڊيگهه مان هڪ ٺاهڻ به محفوظ نه آهي ، ڇو ته مختصرن انهي ترتيب ڏيڻ جي پرواهه ڪئي ، ۽ انهن ٻنهي قسمن ۾ هڪجهڙائي آهي.
    /// بفر الائننگ 2 (`u16` لاءِ) سان مختص ڪئي وئي ، پر ان کي `Vec<u8>` ۾ بدلائڻ کان پوءِ اھو صفائي 1 سان گڏ ختم ڪيو ويندو.
    ///
    /// `ptr` جي ملڪيت مؤثر طور تي `Vec<T>` ڏانهن منتقل ڪئي وئي آهي جيڪو شايد پوءِ پوائنٽ کي ختم ڪري ، مختص ڪري يا يادداشت جي مواد کي تبديل ڪري سگھي ٿو جيڪو پوائنٽر طرفان مرضي موجب اشارو ڪري ٿو.
    /// انهي کي يقيني بڻايو وڃي ته ٻيو ڪو پوائنٽر استعمال نه ڪندي انهي فنڪشن کي ڪال ڪرڻ کان پوءِ
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME هن کي تازه ڪاري ڪريو جڏهن vec_into_raw_parts مستحڪم ٿي آهي.
    ///     // هلائڻ جي روانگي کي `و` تباهه ڪندڙ اسان کي مڪمل ڪنٽرول ۾ آهن.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` بابت importantاڻ جا مختلف اهم ٽڪڙا ڪ Pو
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // ياداشت کي ختم ڪريو 4 ، 5 ، 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // وي سي ۾ سڀ ڪجهه گڏ ڪري واپس ڇڏيو
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// هڪ نئين ، خالي `Vec<T, A>` جي تعمير تي.
    ///
    /// vector ايستائين مختص نه ڪندو جيستائين عناصر ان تي ڇڪي نه سگهجن.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// مهيا ڪيل مختص ڪندڙن سان مخصوص گنجائش سان هڪ نئون ، خالي `Vec<T, A>` تعمير ڪندو آهي.
    ///
    /// vector واقعي بغير `capacity` عناصر کي برقرار رکڻ جي قابل هوندو.
    /// جيڪڏهن `capacity` 0 آهي ، vector مختص نه ڪندو.
    ///
    /// اهو نوٽ ڪرڻ ضروري آهي ته جيتوڻيڪ واپسي vector وٽ *گنجائش* مخصوص ٿيل آهي ، vector صفر *ڊگهو* آهي.
    ///
    /// لمبائي ۽ گنجائش جي فرق جي وضاحت لاءِ ، ڏسو *[ڪيپيسٽي ۽ وري اسٽائلشن]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector ڪوبه شيون ناهي ، جيتوڻيڪ هن ۾ وڌيڪ گنجائش آهي
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // هي سڀ ڪم هڻڻ کان سواءِ ڪيا ويندا آهن ۔۔۔
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... پر اهو شايد vector کي ٻيهر ترتيب ڏئي سگهي ٿو
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// هڪ `Vec<T, A>` سڌو vector جي خام حصن مان سڌو ٺاهيندي آهي.
    ///
    /// # Safety
    ///
    /// اهو انتهائي غير محفوظ آهي ، سببن جي تعداد جي ڪري جيڪي چڪاس نه ڪيا ويا آهن:
    ///
    /// * `ptr` [اسٽرنگ`]/`وييڪ ذريعي مختص ڪرڻ جي ضرورت آهي<T>"(گهٽ ۾ گهٽ ، اهو غلط هجڻ ممڪن آهي جيڪڏهن اهو نه هجي).
    /// * `T` `ptr` سان گڏ ساڳيو سائيز ۽ ترتيب رکڻ جي ضرورت آهي.
    ///   (`T` وٽ ھڪڙو سخت گھاٽو رکڻ ڪافي نه آھي ، ايڪس آرڪس واقعي کي پورو ڪرڻ جي لاءِ واقعي جي برابر ھجڻ لازمي آھي يادگيري کي لازمي طور تي ترتيب ڏيڻ ۽ ساڳي ترتيب سان ختم ٿيل آھي.)
    ///
    /// * `length` `capacity` کان گھٽ يا برابر جي ضرورت آھي.
    /// * `capacity` اهو ٿيئڻ جي ضرورت آهي جنهن جي پوائنٽر سان مختص ڪيا ويا.
    ///
    /// انهن جي ڀڃڪڙي ڪرڻ شايد ايلوڪيٽر جي داخلي ڊيٽا جي اڏاوتن کي بگاڙڻ وانگر مسئلا پيدا ڪري سگهي ٿو.مثال طور اهو **نا** محفوظ آهي ايڪس ايڪس ڊيڪس پوائنٽر کان سي `char` صف تائين `size_t` سان `Vec<u8>` ٺاهي.
    /// اهو `Vec<u16>` ۽ ان جي ڊيگهه مان هڪ ٺاهڻ به محفوظ نه آهي ، ڇو ته مختصرن انهي ترتيب ڏيڻ جي پرواهه ڪئي ، ۽ انهن ٻنهي قسمن ۾ هڪجهڙائي آهي.
    /// بفر الائننگ 2 (`u16` لاءِ) سان مختص ڪئي وئي ، پر ان کي `Vec<u8>` ۾ بدلائڻ کان پوءِ اھو صفائي 1 سان گڏ ختم ڪيو ويندو.
    ///
    /// `ptr` جي ملڪيت مؤثر طور تي `Vec<T>` ڏانهن منتقل ڪئي وئي آهي جيڪو شايد پوءِ پوائنٽ کي ختم ڪري ، مختص ڪري يا يادداشت جي مواد کي تبديل ڪري سگھي ٿو جيڪو پوائنٽر طرفان مرضي موجب اشارو ڪري ٿو.
    /// انهي کي يقيني بڻايو وڃي ته ٻيو ڪو پوائنٽر استعمال نه ڪندي انهي فنڪشن کي ڪال ڪرڻ کان پوءِ
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME هن کي تازه ڪاري ڪريو جڏهن vec_into_raw_parts مستحڪم ٿي آهي.
    ///     // هلائڻ جي روانگي کي `و` تباهه ڪندڙ اسان کي مڪمل ڪنٽرول ۾ آهن.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // `v` بابت importantاڻ جا مختلف اهم ٽڪڙا ڪ Pو
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // ياداشت کي ختم ڪريو 4 ، 5 ، 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // وي سي ۾ سڀ ڪجهه گڏ ڪري واپس ڇڏيو
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// ھڪڙي `Vec<T>` ان جي خام حصن ۾ تقسيم ڪري ٿو.
    ///
    /// خام پوائنٽر کي ھيٺئين ڊيٽا ڏانھن موٽندي آھي ، vector جي ڊگھائي (عناصر ۾) ، ۽ ڊيٽا جي مختص ڪيل ظرفيت (عنصرن ۾).
    /// اهي ساڳيون دليل ساڳيون ترتيب سان [`from_raw_parts`] ڏانهن دليل آهن.
    ///
    /// انهي فنڪشن کي ڪال ڪرڻ کان پوءِ ، ڪال ڪندڙ اڳيئي `Vec` طرفان ياداشت لاءِ ذميوار آهي.
    /// انهي کي ختم ڪرڻ جو واحد رستو اهو آهي ته خام پوائنٽر ، لمبائي ، ۽ گنجائش واپس `Vec` ۾ [`from_raw_parts`] فنڪشن کي تبديل ڪري ، تباهي ڪندڙ کي وا allowingي ڪرڻ جي اجازت ڏي.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // اسان هاڻي حصن ۾ تبديليون ڪري سگهون ٿا ، جهڙوڪ خام پوائنٽر کي مطابقت واري قسم ڏانهن منتقل ڪرڻ.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// ھڪڙي `Vec<T>` ان جي خام حصن ۾ تقسيم ڪري ٿو.
    ///
    /// خام پوائنٽر کي ھيٺئين ڊيٽا ڏانھن موٽندي آھي ، vector جي ڊگھائي (عناصر ۾) ، ڊيٽا جي مختص ڪيل صلاحيت (عناصر ۾) ، ۽ مختص ڪندڙ.
    /// اهي ساڳيون دليل ساڳيون ترتيب سان [`from_raw_parts_in`] ڏانهن دليل آهن.
    ///
    /// انهي فنڪشن کي ڪال ڪرڻ کان پوءِ ، ڪال ڪندڙ اڳيئي `Vec` طرفان ياداشت لاءِ ذميوار آهي.
    /// انهي کي ختم ڪرڻ جو واحد رستو اهو آهي ته خام پوائنٽر ، لمبائي ، ۽ گنجائش واپس `Vec` ۾ [`from_raw_parts_in`] فنڪشن کي تبديل ڪري ، تباهي ڪندڙ کي واڳ صاف ڪرڻ جي اجازت ڏي.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // اسان هاڻي حصن ۾ تبديليون ڪري سگهون ٿا ، جهڙوڪ خام پوائنٽر کي مطابقت واري قسم ڏانهن منتقل ڪرڻ.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// عناصر جو تعداد واپس ڏئي ٿو vector بغير ترتيب ڏيڻ جي بغير.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// ڏنل `Vec<T>` ۾ داخل ٿيڻ جي گھٽ ۾ گھٽ `additional` وڌيڪ عنصر جي گنجائش محفوظ ڪري ٿو.
    /// اھو مجموعو وڌيڪ جڳھ رکي سگھي ٿو جيڪو بار بار منظرنامن کان بچڻ لاءِ.
    /// `reserve` کي ڪال ڪرڻ کان پوءِ ، گنجائش `self.len() + additional` کان وڌيڪ يا برابر ٿي ويندي.
    /// ڇا ڪجهه به ناهي ڪندو جيڪڏهن گنجائش اڳ ئي ڪافي آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن نئين گنجائش `isize::MAX` بائٽس کان وڌي وڃي ٿي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// گهٽ ۾ گهٽ گنجائش مختص ڪري ٿو `additional` وڌيڪ عناصر ڏنل `Vec<T>` ۾ داخل ٿيڻ جو.
    ///
    /// `reserve_exact` کي ڪال ڪرڻ کان پوءِ ، گنجائش `self.len() + additional` کان وڌيڪ يا برابر ٿي ويندي.
    /// ڇا ڪندو ڪجھ به ناهي جيڪڏهن گنجائش اڳ ئي ڪافي آھي.
    ///
    /// ياد رکو ته مختص ڪندڙ ان کي موڪلڻ کان وڌيڪ جاءِ ڏئي سگهي ٿو.
    /// انهي جي ڪري ، صلاحيت تي اعتبار نه ٿو ڪري سگھجي گھٽ بلڪل گھٽ هجڻ گهرجي.
    /// `reserve` کي ترجيح ڏيو جيڪڏهن future داخل ٿيڻ جي توقع ڪئي وڃي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن نئين گنجائش `usize` مٿان لڳندي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// ڏنل `Vec<T>` ۾ داخل ٿيڻ جي گھٽ ۾ گھٽ `additional` وڌيڪ عناصر جي گنجائش کي محفوظ ڪرڻ جي ڪوشش ڪندو آهي.
    /// اھو مجموعو وڌيڪ جڳھ رکي سگھي ٿو جيڪو بار بار منظرنامن کان بچڻ لاءِ.
    /// `try_reserve` کي ڪال ڪرڻ کان پوءِ ، گنجائش `self.len() + additional` کان وڌيڪ يا برابر ٿي ويندي.
    /// ڇا ڪجهه به ناهي ڪندو جيڪڏهن گنجائش اڳ ئي ڪافي آهي.
    ///
    /// # Errors
    ///
    /// جيڪڏهن گنجائش وڌي وئي آهي ، يا مختص ڪندڙ ڪنهن ناڪامي جي رپورٽ ڪري ، ته هڪ غلطي واپس ڪئي وئي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // يادگيري کي اڳ ۾ محفوظ ڪريو ، ڪ ifي جيڪڏهن اسان نٿا ڪري سگهون
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ھاڻي اسين knowاڻون ٿا ته ھي OOM اسان جي پيچيده ڪم جي وچ ۾ نٿو ڪري سگھي
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // تمام پيچيده
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// ڏنل `Vec<T>` ۾ داخل ٿيڻ جي لاءِ بلڪل `additional` عناصر لاءِ گهٽ ۾ گهٽ گنجائش لاءِ رزرو ڪرڻ جي ڪوشش ڪندو آهي.
    /// `try_reserve_exact` کي ڪال ڪرڻ کان پوءِ جيڪڏهن `Ok(())` موٽي وڃي ته اها گنجائش `self.len() + additional` کان وڌيڪ يا برابر ٿي ويندي.
    ///
    /// ڇا ڪندو ڪجھ به ناهي جيڪڏهن گنجائش اڳ ئي ڪافي آھي.
    ///
    /// ياد رکو ته مختص ڪندڙ ان کي موڪلڻ کان وڌيڪ جاءِ ڏئي سگهي ٿو.
    /// انهي جي ڪري ، صلاحيت تي اعتبار نه ٿو ڪري سگھجي گھٽ بلڪل گھٽ هجڻ گهرجي.
    /// `reserve` کي ترجيح ڏيو جيڪڏهن future داخل ٿيڻ جي توقع ڪئي وڃي.
    ///
    /// # Errors
    ///
    /// جيڪڏهن گنجائش وڌي وئي آهي ، يا مختص ڪندڙ ڪنهن ناڪامي جي رپورٽ ڪري ، ته هڪ غلطي واپس ڪئي وئي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // يادگيري کي اڳ ۾ محفوظ ڪريو ، ڪ ifي جيڪڏهن اسان نٿا ڪري سگهون
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // ھاڻي اسين knowاڻون ٿا ته ھي OOM اسان جي پيچيده ڪم جي وچ ۾ نٿو ڪري سگھي
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // تمام پيچيده
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// vector جي گنجائش کي جيترو ممڪن طور تي ڇڪايو وڃي.
    ///
    /// اهو ذري جيترو ممڪن ٿي سگهي گهٽ ڪندو پر وراڻيندڙ اڃا vector کي آگاهي ڏئي سگهي ٿو ته هتي ڪجهه وڌيڪ عنصر لاءِ جڳهه آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // گنجائش ڪڏهن به ڊيگهه کان گهٽ ناهي ، ۽ جڏهن انهن جي برابر نه هجي ته هتي ڪرڻ جي ڪا شي نه آهي ، تنهن ڪري اسان صرف وڌيڪ وڏي صلاحيت سان فون ڪري `RawVec::shrink_to_fit` ۾ panic ڪيس کان پاسو ڪري سگهون ٿا.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// vector کي گھٽ حد سان گنجائش گھٽائي ٿو.
    ///
    /// گنجائش گهٽ ۾ گهٽ جيترو وڏو ٿيندو جيترو ڊگهو ۽ سپلائي قدر.
    ///
    ///
    /// جيڪڏهن موجوده گنجائش هيٺين حد کان گهٽ آهي ، اهو هڪ اوپي ناهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// vector کي [`Box<[T]>`][owned slice] ۾ بدلائي ٿو.
    ///
    /// ياد رکجو ته اهو ڪجھ وڌيڪ گنجائش ختم ڪري ڇڏيندو.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// وڌيڪ اضافو ختم ڪيو ويو آهي
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// vector کي ننڙو ڪري ، پهريون `len` عناصر رکڻ ، باقي ڇڏڻ.
    ///
    /// جيڪڏهن `len` vector جي موجوده ڊيگهه کان وڌيڪ آهي ، انهي جو ڪوبه اثر ناهي.
    ///
    /// [`drain`] طريقو ايڪسڪوڪسڪس کي ظاھر ڪري سگھي ٿو ، پر ان جي وڌندڙ عنصرن کي گرائڻ بدران واپس ورڻ جو سبب بڻجندو آھي.
    ///
    ///
    /// نوٽ ڪيو ته ھن طريقي سان vector جي مختص ڪيل ظرفيت تي ڪو اثر ڪونھي.
    ///
    /// # Examples
    ///
    /// هڪ ٻه عنصر ويڪٽر کي ختم ڪرڻ ٻن عنصرن کي:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// ڪو به خشڪ واقع ناهي جڏهن `len` vector جي موجوده ڊيگهه کان وڌيڪ آهي.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// ڇڪڻ جڏهن `len == 0` کي [`clear`] طريقي سان سڏڻ جي برابر آهي.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // هي محفوظ آهي ڇاڪاڻ ته:
        //
        // * ايڪس 100 ايڪس تائين منظور ٿيل سلائي صحيح آهي ؛`len > self.len` ڪيس هڪ غلط سلائس ٺاهڻ کان پاسو ڪري ٿو ، ۽
        // * vector جو `len` `drop_in_place` کي فون ڪرڻ کان پھريائين آھي ، اھڙي طرح `drop_in_place` ھڪ ڀيرو panic کي ٻيھر ڪا قيمت گھٽائي ڪو نه ٿي ويندي (جيڪڏھن اھو panics ٻه ڀيرا ، پروگرام ختم ٿي وڃي).
        //
        //
        //
        unsafe {
            // Note: اهو ارادو ٿيل آهي ته هي `>` آهي نه `>=` جو.
            //       ان کي `>=` ۾ تبديل ڪرڻ ڪجهه ڪيسن ۾ منفي ڪارڪردگي جا اثر ڇڏي ٿو.
            //       وڌيڪ لاءِ #78884 ڏسو.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// سليز ڪ Extي ٿو جنهن ۾ س Zو ويڪٽر آهي.
    ///
    /// `&s[..]` جي برابر.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// پوري vector جو هڪ بدلندڙ ٻلي ڪي ٿو.
    ///
    /// `&mut s[..]` جي برابر.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// vector جي بفر ڏانھن خام پوائنٽر ڏانھن واپسي آھي.
    ///
    /// ڪالر کي ان ڳالهه کي يقيني بڻائڻو آهي ته vector اشارو ڏيڻ واري بقا کان اهو ڪم موٽائي ٿو ، يا ٻي صورت ۾ اهو گندگي ڏانهن اشارو ڪرڻي پوندي.
    /// vector کي تبديل ڪرڻ جو سبب ٿي سگھي ٿو ان جو بفر ٻيهر مقرر ڪيو وڃي ، جيڪو پڻ انهي ڏانهن اشارو ڪن ٿو.
    ///
    /// ڪالر پڻ انهي ڳالهه کي يقيني بنائڻ گهرجي ته يادگيري پوائنٽر (non-transitively) ڏانهن اشارو ڪڏهن به ناهي لکيو ويو (سواءِ `UnsafeCell` جي) انهي پوائنٽر يا ان مان نڪتل ڪنهن به پوائنٽر کي استعمال ڪندي.
    /// جيڪڏهن توهان کي سلائس جي مواد کي متحرڪ ڪرڻ جي ضرورت آهي ، استعمال ڪريو [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // اسان nameاڻينداسين ساڳئي نالي جو سليس وارو طريقو `deref` کان ڀ toڻ کان پاسو ڪجي ، جيڪو وچولي حوالي سان ٺاهي ٿو.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// vector جي بفر ڏانھن ھڪڙو غير محفوظ مٽيل پوائنٽر ڏيکاري ٿو.
    ///
    /// ڪالر کي ان ڳالهه کي يقيني بڻائڻو آهي ته vector اشارو ڏيڻ واري بقا کان اهو ڪم موٽائي ٿو ، يا ٻي صورت ۾ اهو گندگي ڏانهن اشارو ڪرڻي پوندي.
    ///
    /// vector کي تبديل ڪرڻ جو سبب ٿي سگھي ٿو ان جو بفر ٻيهر مقرر ڪيو وڃي ، جيڪو پڻ انهي ڏانهن اشارو ڪن ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// // مختص ڪريو vector وڏو آھي 4 عنصرن لاءِ.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // خام پوائنٽر لکندڙن ذريعي عناصر کي شروعاتي شڪل ۾ ، لمبائي طئي ڪيو.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // اسان nameاڻينداسين ساڳئي نالي جو سليس وارو طريقو `deref_mut` کان ڀ toڻ کان پاسو ڪجي ، جيڪو وچولي حوالي سان ٺاهي ٿو.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// ھيٺ ڏنل مختص ڪندڙ جو حوالو ڏئي ٿو.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// vector کان `new_len` جي ڊيگهه کي مجبور ڪري ٿو.
    ///
    /// هي هڪ گهٽ سطح جو آپريشن آهي جيڪو هر قسم جي عام invariaries کي برقرار نٿو رکي.
    /// عام طور تي vector جي ڊيگهه تبديل ڪرڻ محفوظ عملن مان هڪ کي استعمال ڪيو وڃي ٿو ، جهڙوڪ [`truncate`] ، [`resize`] ، [`extend`] ، يا [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` [`capacity()`] کان گھٽ يا برابر ھئڻ گھرجي.
    /// - `old_len..new_len` تي عناصر لازمي طور تي شروعاتي بڻجن.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// اهو طريقو انهن حالتن لاءِ ڪارائتو ٿي سگهي ٿو جن ۾ vector ٻئي ڪوڊ لاءِ بفر طور ڪم ڪري رهيو آهي ، خاص طور تي FFI مٿان.
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // اهو صرف ڊاڪ مثال جي لاءِ گهٽ ۾ گهٽ سخي آهي.
    /// # // اصل لائبريري لاءِ ان کي شروعاتي پوائنٽ جي طور تي استعمال نه ڪيو.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // ايف اي ايف آئي جي طريقن جي دستاويز جي مطابق ، "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // حفاظت: جڏهن `deflateGetDictionary` `Z_OK` موٽائي ٿو ، اهو رکي ٿو:
    ///     // 1. `dict_length` عناصر شروع ٿي ويا.
    ///     // 2.
    ///     // `dict_length` <=گنجائش (32_768) جيڪو ڪال ڪرڻ لاءِ `set_len` محفوظ ڪري ٿو.
    ///     unsafe {
    ///         // ايف ايف آءِ ڪال ڪريو…
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... ۽ شروعات ڪئي وئي ته ڊيگهه کي جنهن کي شروعاتي بڻايو ويو آهي.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// جڏهن ته هيٺيون مثال آواز آهي ، يادگيري جي ٽڪري آهي جئين vectors اندروني `set_len` ڪال کان پهريان آزاد نه ڪيو ويو هو.
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` خالي آهي تنهن ڪري عنصرن کي شروعاتي بڻائڻ جي ضرورت ناهي.
    /// // 2. `0 <= capacity` هميشه جيڪو به `capacity` هوندو آهي روڪي ٿو.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// عام طور تي ، هتي ، ايڪس ايڪس کي استعمال ڪندي صحيح طور تي مواد ڪ dropڻ بدران ۽ انهي سان ياداشت نه ڇڏيندو.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// vector مان هڪ عنصر ختم ڪري ٿو ۽ ان کي واپس ڪري ٿو.
    ///
    /// ختم ٿيل عنصر vector جي آخري عنصر طرفان تبديل ڪيو ويو آهي.
    ///
    /// اهو آرڊر رکڻ جي حفاظت نٿو ڪري ، پر ايڪس ايڪس ايڪس آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `index` حد کان ٻاهر آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // اسين پنهنجو پاڻ کي تبديل ڪيو ٿا [انڊيڪس] آخري عنصر سان.
            // نوٽ ڪريو ته جيڪڏهن حدون چيڪ ڪامياب ٿي ويون آهن ته اتي هڪ آخري عنصر هجڻ گهرجي (جيڪو خود [انڊيڪس]] ٿي سگهي ٿو.
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// vector ۾ `index` پوزيشن تي هڪ عنصر داخل ڪري ٿو ، س allي عنصر ان کي س afterي طرف منتقل ڪندي.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // نئين عنصر لاءِ جاءِ
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // نئون قدر وجهڻ لاءِ جڳهه
            //
            {
                let p = self.as_mut_ptr().add(index);
                // جاءِ ٺاهڻ لاءِ هر شيءَ کي يرائي.
                // (انڊيڪس` عنصر کي ٻن مسلسل جڳهن ۾ نقل ڪندي.)
                ptr::copy(p, p.offset(1), len - index);
                // ان ۾ لکو ، `انڊيڪس` عنصر جي پهرين ڪاپي کي ختم ڪندي.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// vector اندر ايڪس آرڪس جي پوزيشن کي عنصر خارج ڪري ٿو ۽ واپس اچي ٿو ، هن کي کاٻي پاسي رهڻ کانپوءِ سڀني عنصرن کي shيرائي ٿو.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `index` حد کان ٻاهر آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // اسان جنهن جاءِ کان وٺي رهيا آهيون.
                let ptr = self.as_mut_ptr().add(index);
                // ان کي نقل ڪريو ، غير محفوظ طور تي ھڪڙي اسٽيڪ تي ويليو جي ڪاپي آھي ۽ ساڳئي وقت vector ۾.
                //
                ret = ptr::read(ptr);

                // ھيٺ ڀرڻ لاءِ ھر شيءِ ھيٺ منتقل ڪريو.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// اڳڪٿيءَ طرفان مقرر ڪيل عنصرن کي برقرار رکيو ٿو وڃي.
    ///
    /// ٻين لفظن ۾ ، سڀني عناصر `e` کي هٽائي ڇڏيو ته `f(&e)` `false` موٽائي ٿو.
    /// اهو طريقو جڳهه ۾ هلندو آهي ، هر عنصر کي اصل ۾ هڪ ڀيرو جي اصلي ترتيب ۾ ڏسي ٿو ، ۽ برقرار ڪيل عناصر جي ترتيب کي محفوظ ڪري ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// ڇاڪاڻ ته عنصرن جو دورو هڪ ڀيرو اصلي ترتيب سان ڪيو وڃي ٿو ، خارجي حالت استعمال ڪرڻ جو فيصلو ڪري سگهجي ٿي ته ڪهڙا عنصر رکيا وڃن.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // ٻيڙي ڇڏڻ کان پاسو ڪريو جيڪڏهن ڊراپ گارڊ جو عمل نه هجي ها ، جئين اسان پروسيس دوران ڪجهه سوراخ ڪري سگهون.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-پروسيس ٿيل لين-> |^-چيڪ ڪرڻ لاءِ اڳتي
        //                  | <-ختم ٿيل سي ٽي-> |
        //      | <-اصل_ لين-> |رکيو: عناصر جيڪي اڳڪٿي موٽندا آهن حقيقي.
        //
        // سوراخ: منتقل ڪيو ويو يا ڇڏي ويو عنصر سلاٽ.
        // غير چيڪ ڪيو ويو: اڻ چونڊيل صحيح عناصر.
        //
        // اهو ڊراپ گارڊ انلاڪ ڪيو ويندو جڏهن عنصر پکڙجي ويو يا `drop` ٿيندو.
        // اهو سوراخ ۽ ايڪسڪسيمڪس کي درست لمبائي کي chڪڻ لاءِ اڻ elementsاتل عناصر منتقل ڪري ٿو.
        // ڪيسن ۾ جڏهن اڳڪٿي ۽ ايڪسڪيڪس ڪڏهن نه ٿڪندو ، اهو بهتر ٿيندو.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // حفاظت: پيچرو ٿيل غير جانچيل شيون صحيح هجڻ گهرجن ڇاڪاڻ ته اسين ڪڏهن به انهن کي هٿ نه کڻون.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // حفاظت: سوراخ ڀرڻ کان پوء ، سڀ شيون ويٺل ياداشت ۾ آهن.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // حفاظت: غير منتخب ٿيل عنصر لازمي طور صحيح هجڻ گهرجي.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // ٻيڙي گرائڻ کان بچڻ لاءِ جلد اڳتي وڌو جيڪڏهن `drop_in_place` دٻاءُ ٿيو.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // حفاظت: اسان هن عنصر کي گهٽائڻ کانپوءِ ٻيهر نه ڇڪيو.
                unsafe { ptr::drop_in_place(cur) };
                // اسان اڳ ۾ ئي ڪرنٽ کي ترقي ڪئي.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SAFETY: `deleted_cnt`> 0 ، تنهن ڪري سوراخ واري سلاٽ کي موجوده عنصر سان چڙهائي نه وڃڻ گهرجي.
                // اسان نقل جي حرڪت لاءِ استعمال ڪندا آهيون ، ۽ هن عنصر کي ڪڏهن به ڪونه ڇڪيو
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // سڀ شيون پروسيس ٿيل آهن.اهو ايل ايل ايم ايم پاران ايڪس ايڪس ايڪس کي بهتر بڻائي سگهجي ٿو.
        drop(g);
    }

    /// vector ۾ لڳاتار پهريون عنصر ختم ڪري ٿو جيڪو ساڳي ڪيٻي کي حل ڪري ٿو.
    ///
    ///
    /// جيڪڏهن vector ترتيب ڏنل آهي ، اهو س allو نقل ختم ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// vector ۾ لڳاتار پهريون عنصر ختم ڪري ٿو پر ڏنل مساوات جي رشتي کي مطمئن ڪري ٿو.
    ///
    /// `same_bucket` فنڪشن vector مان ٻن عنصرن جي حوالي ڪئي وئي آهي ۽ طئي ڪرڻ گهرجي ته جيڪڏهن عنصر برابر هجن.
    /// عناصر سليس ۾ انهن جي ترتيب کان مخالف ترتيب ۾ پاس ڪيا ويا ، تنهن ڪري جيڪڏهن `same_bucket(a, b)` واپس اچي ٿو `true` ، `a` ڪ isيو وڃي ٿو.
    ///
    ///
    /// جيڪڏهن vector ترتيب ڏنل آهي ، اهو س allو نقل ختم ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// هڪ مجموعو جي پسمنظر ۾ ھڪڙو عنصر شامل ڪري ٿو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن نئين گنجائش `isize::MAX` بائٽس کان وڌي وڃي ٿي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // اھو panic ختم ڪندو يا ختم ڪري ڇڏيندو جيڪڏھن اسان مختص ڪنداسين> isize::MAX بائٽس يا جيڪڏهن طول وڌائڻ وارو صفر-سائز وارن قسمن جي لاء وڌي ويندو.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// vector کان آخري عنصر ڪي ٿو ۽ واپسي ، يا [`None`] جيڪڏهن اهو خالي آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// `other` جي سڀني عنصرن کي `Self` ۾ منتقل ڪري ٿو ، `other` کي خالي ڪري ڇڏي ٿو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن vector ۾ عناصر جو تعداد ايڪس ايڪس X مٿان چڙهائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// `Self` کي ٻين بفر مان عناصر ملندي آهي.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// خشڪ ايراضي ٺاهي ٿو جيڪا vector ۾ مخصوص ٿيل حد کي ختم ڪري ٿو ۽ ختم ٿيل شيون حاصل ڪري ٿي.
    ///
    /// جڏهن اهو ورثو ** droppedوڪيو وڃي ٿو ، رينج ۾ موجود سمورا عنصر vector مان ڪ areيا وڃن ، جيتوڻيڪ ايريٽر مڪمل طور تي استعمال نه ٿي ٿئي.
    /// جيڪڏهن ويتر ** نه ڇڏيو ويو آهي (مثال طور [`mem::forget`] سان) ، اهو اڻ howاڻيل آهي ته ڪيترا عنصر ڪ areيا وڃن ٿا.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن شروعاتي نقطي اختتام واري نقطي کان وڏي آهي يا جيڪڏهن آخري نقطو vector جي ڊيگهه کان وڌيڪ آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // ھڪڙي مڪمل حد vector صاف ڪري ٿي
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // ياداشت جي حفاظت
        //
        // جڏهن Drain پهرين ٺاهي وئي آهي ، اهو ذريعو vector جي ڊيگهه کي گهٽائي ٿو يقيني بڻايون ته ڪوبه ابتدائي يا منتقل ٿيل عنصر سڀني تائين رسائي وارو نه آهي جيڪڏهن Drain جي تباهي وارو ڪڏهن هلائڻ وارو ناهي.
        //
        //
        // Drain ختم ڪرڻ جي قيمت تي ptr::read ڪندو.
        // جڏهن پورو ٿي چڪو آهي ، ويچ جي باقي پائي واپس سوراخ کي toڪڻ لاءِ ڪاپي ڪئي وئي آهي ، ۽ vector جي ڊيگهه نئين ڊيگهه تي بحال ڪيو ويو آهي.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // سيٽ ڪريو self.vec جي ڊيگهه کي شروع ڪرڻ ، محفوظ ٿيڻ جي صورت ۾ Drain ليڪ ٿيڻ
            self.set_len(start);
            // IterMut ۾ قرض استعمال ڪريو پوري Drain ايٽررٽر (&mut T وانگر) جو قرض وٺڻ وارو رويو ظاهر ڪرڻ.
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// vector صاف ڪريو ، سڀني قدرن کي ختم ڪندي.
    ///
    /// نوٽ ڪيو ته ھن طريقي سان vector جي مختص ڪيل ظرفيت تي ڪو اثر ڪونھي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// vector ۾ عناصر جو تعداد واپس ڏئي ٿو ، ان جو 'length' پڻ حوالو ڏنو ويو آھي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// جيڪڏهن X0vector0Z ۾ ڪوبه عنصر شامل ناهي ، `true` ڏي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ڏنل انڊيڪس ۾ مجموعن کي ٻن ۾ ورهايو ويو آهي.
    ///
    /// ھڪڙي نئين مختص ٿيل vector کي واپسي ڏيکاري ٿو ھي عنصر شامل آھن ايڪسڪسيمڪس جي حد ۾.
    /// ڪال ڪرڻ کان پوء ، اصلي vector عناصر ڇڏي ويندي جنهن ۾ `[0, at)` اڳوڻي ڪم ڪار سان اڳوڻي تبديلي هوندي.
    ///
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // نئون vector اصل بفر وٺي سگھي ٿو ۽ نقل کان پاسو ڪري سگھي ٿو
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // غير محفوظ طور تي `set_len` ۽ ڪاپي شيون `other` ڏانهن.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// `Vec` جي جڳهه تي نظر ثاني ڪري ٿو ، انهي جي ڪري `len` `new_len` جي برابر آهي.
    ///
    /// جيڪڏهن `new_len` `len` کان وڏو آهي ، `Vec` فرق ذريعي وڌايو وڃي ٿو ، هر هڪ اضافي سلاٽ کي بند ڪري ڇڏيو `f` کي ڪال ڪرڻ جي نتيجي ۾.
    ///
    /// `f` کان واپسي جا قدر `Vec` ۾ ختم ٿي وينديون انھن جي حساب سان ٺاھيا ويا آھن.
    ///
    /// جيڪڏهن `new_len` `len` کان گهٽ آهي ، `Vec` صرف نن trي آهي.
    ///
    /// اھو طريقو ھر پيش تي نئين قدر ٺاھڻ لاءِ بند کي استعمال ڪندو آھي.جيڪڏهن توهان پسند ڪيو ٿا [`Clone`] ڏنل قيمت ، استعمال ڪريو [`Vec::resize`]
    /// جيڪڏهن توهان قدر پيدا ڪرڻ لاءِ [`Default`] trait استعمال ڪرڻ چاهيو ٿا ، توهان ٻئي دليل طور [`Default::default`] پاس ڪري سگهو ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// استعمال ڪيو ۽ `Vec` ليڪس ڪري ٿو ، مواد جي هڪ قابل تبديلي حوالو موٽڻ ، `&'a mut [T]`.
    /// ياد رکجو ته قسم `T` چونڊيل لائفائم `'a` کان اڳ رهڻ گھرجي.
    /// جيڪڏهن قسم کي صرف جامد حوالا آهن ، يا هر ڪنهن سان نه ، پوءِ اهو چونڊ ٿي سگھي ٿو ايڪسائيڪس.
    ///
    /// اهو فنڪشن ايڪسڪسيمڪس تي ايڪسڪسيمڪس فڪس وانگر ساڳيو آهي سواءِ ان جي ته انهي يادگيريءَ کي بحال ڪرڻ جو ڪو طريقو ناهي.
    ///
    ///
    /// اهو فنڪشن گهڻو ڪري ڊيٽا لاءِ ڪارائتو آهي جيڪو پروگرام جي باقي زندگي تائين جيئرو آهي.
    /// واپسي ريفرنس کي ڇڏڻ هڪ ياداشت لڪي ٿو.
    ///
    /// # Examples
    ///
    /// سادو استعمال
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// vector جي باقي بچائي گنجائش کي `MaybeUninit<T>` جي هڪ سلائس وانگر واپس آڻيندي.
    ///
    /// واپسي سلائس ڊيٽا سان vector ڀرڻ لاءِ استعمال ٿي سگھي ٿي (مثال طور
    /// فائل کان پڙهڻ سان) [`set_len`] طريقي سان شروعاتي طور تي ڊيٽا کي نشان لڳائڻ کان پهريان.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // مختص ڪريو vector وڏي پئماني تي 10 عناصر.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // ڀا 3و پهرين 3 عناصر کي ڀريو.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // vector جي پهرين 3 عناصر کي شروعاتي طور نشان لڳايو.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // اهو طريقو `split_at_spare_mut` جي لحاظ سان لاڳو نه ڪيو ويو آهي ، بفر کي اشارو جي غلط هجڻ کي روڪڻ.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// vector مواد کي `T` جي هڪ سلائس وانگر واپس آڻيندي ، vector جي باقي اضافي گنجائش سان گڏ `MaybeUninit<T>` جي هڪ ٽڪڙي وانگر.
    ///
    /// واپسي واري اسپري گنجائش سلائس vector کي ڊيٽا سان ڀرڻ لاءِ استعمال ڪري سگهجي ٿي (مثال طور هڪ فائل مان پڙهائي) [`set_len`] طريقو استعمال ڪندي شروعاتي طور تي ڊيٽا کي نشان لڳائڻ کان اڳ.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// ياد رکجي ته اهو ايڏي گهٽ سطح جو API آهي ، جيڪو بهتر نموني لاءِ احتياط سان استعمال ڪرڻ گهرجي.
    /// جيڪڏهن توهان کي `Vec` ڊيٽا شامل ڪرڻ جي ضرورت آهي توهان توهان جي صحيح ضرورتن تي منحصر ڪري [`push`] ، [`extend`] ، [`extend_from_slice`] ، [`extend_from_within`] ، [`insert`] ، [`append`] ، [`resize`] يا [`resize_with`] استعمال ڪري سگهو ٿا.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // 10 عنصرن لاءِ اضافي وڏي جڳهه محفوظ ڪريو
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // ايندڙ 4 عناصر کي ڀريو.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // vector جي 4 عناصر کي شروعاتي طور تي نشان لڳايو.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - لين نظرانداز ڪيو ويو آهي ۽ ائين ڪڏهن به تبديل ناهي ٿيو
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// حفاظت: تبديل ٿيل موٽيو .2 (&mut استعمال ڪريو) ساڳيو سمجهيو ويندو آهي ايڪس ايڪس ايڪس ڪالنگ.
    ///
    /// ھي طريقو استعمال ڪيو ويو آھي ھڪڙي ھڪڙي ھڪڙي `extend_from_within` ۾ ھڪڙي ھڪڙي ھڪڙي ھڪڙي ھڪڙي ھڪڙي ھڪڙي ھڪڙي حصي جي ھڪڙي حصي جي رسائي حاصل ڪري.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` `len` عناصر لاء صحيح هجڻ جي ضمانت آهي
        // - `spare_ptr` هڪ عنصر کي اڳ ۾ بفر ڏانهن اشارو ڪري رهيو آهي ، تنهن ڪري اهو `initialized` سان گڏ نٿو اچي
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// `Vec` جي جڳهه تي نظر ثاني ڪري ٿو ، انهي جي ڪري `len` `new_len` جي برابر آهي.
    ///
    /// جيڪڏهن `new_len` `len` کان وڌيڪ آهي ، `Vec` فرق ذريعي وڌايو ويو آهي ، هر هڪ اضافي سلاٽ سان `value` ڀريو وڃي ٿو.
    ///
    /// جيڪڏهن `new_len` `len` کان گهٽ آهي ، `Vec` صرف نن trي آهي.
    ///
    /// اهو طريقو `T` کي [`Clone`] کي لاڳو ڪرڻ جي ضرورت آهي ، منظور ٿيل ويل کي ڪلون ڪرڻ جي لاءِ.
    /// جيڪڏهن توهان کي وڌيڪ لچڪ جي ضرورت آهي (يا [`Clone`] جي بجاءِ [`Default`] تي ڀاڙڻ چاهيو) [`Vec::resize_with`] استعمال ڪريو.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// کلون ۽ سڀني عناصر کي `Vec` جي هڪ سلائس ۾ شامل ڪري ٿو.
    ///
    /// سلائس `other` تي ٻيهر ،ري ٿو ، هر عنصر کي ڪلون ڪري ٿو ، ۽ پوءِ هن کي `Vec` ۾ شامل ڪري ٿو.
    /// `other` vector طريقي سان ڀريل آهي.
    ///
    /// ياد رکجو ته اهو فنڪشن [`extend`] وانگر ساڳيو آهي سواءِ ان جي ته اهو سليس بدران ڪم ڪرڻ لاءِ مخصوص آهي.
    ///
    /// جيڪڏهن ۽ جڏهن Rust اسپيشلائيزيشن حاصل ٿئي ٿي اهو فنڪشن ممڪن طور تي تباهه ڪيو ويندو (پر اڃا تائين دستياب آهي).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// `src` رينج کان vector جي آخر تائين عناصر نقل ڪري ٿو.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` اهو ضمانت ڏئي ٿو ته ڏنل حد خود جي لاءِ درست آهي
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// هي ڪوڊ `extend_with_{element,default}` کي عام ڪري ٿو.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// ڏنل جنريٽر استعمال ڪندي ، `n` قدرن جي طرفان vector کي وڌايو.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // سيٽ جي استعمال ڪرڻ لاءِ SetLenOnDrop استعمال ڪريو جتي کمپائلر `ptr` ذريعي اسٽور کي محسوس نٿو ڪري سگھي self.set_len() جي نالي سان نه ٻڌو.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // آخري سڀني کان سواءِ سڀ عنصر لکو
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // ڪيس ۾ هر قدم جي ڊيگهه کي وڌايو next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // اسان آخري عنصر کي سڌي طرح لکڻ جي ضرورت کانسواءِ بغير ڪلون لکي سگھون ٿا
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // لين اسڪوپ گارڊ طرفان مقرر ڪيل
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// [`PartialEq`] trait عمل جي مطابق vector ۾ لڳاتار بار بار عنصر ڪي ٿو.
    ///
    ///
    /// جيڪڏهن vector ترتيب ڏنل آهي ، اهو س allو نقل ختم ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// اندروني طريقا ۽ افعال
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` صحيح انڊيڪس جي ضرورت آهي
    /// - `self.capacity() - self.len()` `>= src.len()` هجڻ ضروري آهي
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - لين عنصرن کي شروع ڪرڻ بعد ئي وڌي ويندو آهي
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - ڪالر گارنٽيز جيڪا src هڪ صحيح انڊيڪس آهي
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - عنصر صرف `MaybeUninit::write` سان شروع ڪيو ويو ، تنهن ڪري لين کي وڌائڻ لاءِ ٺيڪ آهي
            // - لينن کي روڪڻ لاءِ هر عنصر بعد وڌيو ويندو آهي (ڏسو مسئلو #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - ڪالر گارنٽس ٻڌائي ٿو ته `src` هڪ صحيح انڊيڪس آهي
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - ٻئي اشارو منفرد سلائي جي حوالن مان ٺاهيا ويا آهن (&mut [_] `) تنهنڪري اهي جائز آهن ۽ وڌيڪ چڙهندڙ نه آهن.
            //
            // - عناصر آهن: ڪاپي ڪري پوءِ ٺيڪ آهي انهن کي ڪاپي ڪرڻ کان سواءِ ، اصل شيءَ سان ڪجهه ڪرڻ کانسواءِ
            // - `count` لينڪس `source` جي برابر آهي ، تنهن ڪري ماخذ `count` پڙهائي لاءِ صحيح آهي
            // - `.reserve(count)` اهو ضمانت ڏي ٿو ته `spare.len() >= count` تنهنڪري اسپيئر صحيح آهي `count` لکي ٿو
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - عناصر صرف شروعاتي طور تي `copy_nonoverlapping` پاران ڪيا ويا
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// عام trait لاڳو ڪيل وييڪ لاء
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): cfg(test) سان گڏ موروثي `[T]::to_vec` طريقو ، جيڪو ھن طريقي جي تعريف جي لاءِ گھربل آھي ، دستياب ناھي.
    // بدران `slice::to_vec` فنڪشن استعمال ڪريو جيڪو صرف cfg(test) NB سان دستياب آھي وڌيڪ slice.rs ۾ slice::hack ماڊل ڏسو وڌيڪ معلومات لاءِ
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // ڪنهن به شيءِ ڇڏيو جنهن کي اوورٽيوپ نه ڪيو ويندو
        self.truncate(other.len());

        // self.len <= other.len مٿي ٽڪنڊي جي ڪري ، تنهن ڪري هتي سلائسون هميشه حد ۾ ڇڏينديون آهن.
        //
        let (init, tail) = other.split_at(self.len());

        // استعمال ٿيل قدرن کي allocations/resources استعمال ڪريو.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// ھڪڙي صارف خريد ڪندڙ کي ٺاھيندو آھي ، اھو آھي ، جيڪو ھر قيمت vector مان نڪرندو آھي (شروعات کان آخر تائين).
    /// vector هن کي سڏڻ کان پوءِ استعمال نه ٿو ڪري سگهجي.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s قسم ڏجي ٿي ، نه &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // پتي جو طريقو جنهن تي SpecFrom/SpecExtend لاڳو ڪندا آهن اهي اختيار ڪن ٿا جڏهن انهن کي لاڳو ڪرڻ لاءِ وڌيڪ واڌارو ناهي
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // اهو عام ائيٽرٽر لاءِ صورت آهي.
        //
        // اهو ڪارڪردگي اخلاقي برابر هجڻ گهرجي:
        //
        //      آئي ٽيٽر ۾ آئٽم لاءِ
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // اين بي وڏي حد کان مٿي نه ٿي سگهيس ڇو ته اسان کي ايڊريس جي جڳهه مختص ڪرڻ گهرجي ها
                self.set_len(len + 1);
            }
        }
    }

    /// هڪ splicing iterator ٺاهي ٿو جيڪا vector ۾ ڏنل رينج کي ڏنل `replace_with` iterator سان تبديل ڪري ٿو ۽ ختم ٿيل شيون ڪ yieldي ٿو.
    ///
    /// `replace_with` `range` وانگر ساڳئي ڊيگهه جي ضرورت ناهي.
    ///
    /// `range` هٽايو وڃي ٿو جيتوڻيڪ اهو ايٽررٽر آخر تائين استعمال نه ڪيو ويو آهي.
    ///
    /// اهو اهو طئي ٿيل آهي ته جيڪڏهن `Splice` قدر لڪي پيو وڃي ته vector مان ڪيترا عنصر ڪ areيا وڃن ٿا.
    ///
    /// انپٽ آئيٽرر `replace_with` صرف ان وقت ڀٽايو ويندو آهي ، جڏهن `Splice` قدر گھٽائي ويندي آهي.
    ///
    /// اھو بھترين آھي جيڪڏھن:
    ///
    /// * دم (`range` کان پوءِ vector ۾ عناصر) خالي آھي ،
    /// * يا `replace_with` رينج جي ڊيگهه کان گهٽ يا برابر عنصر پيدا ڪري ٿو
    /// * يا ان جي `size_hint()` جي هيٺين حد ساڳي آھي.
    ///
    /// ٻي صورت ۾ ، هڪ عارضي vector مختص ڪيو ويو آهي ۽ دم ٻه ڀيرا هليو ويو آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن شروعاتي نقطي اختتام واري نقطي کان وڏي آهي يا جيڪڏهن آخري نقطو vector جي ڊيگهه کان وڌيڪ آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// اهو هڪ ايٽرير بڻائي ٿو جيڪو هڪ بندش استعمال ڪري ٿو اهو طئي ڪرڻ جي لاءِ ته ڇا هڪ عنصر ختم ڪيو وڃي.
    ///
    /// جيڪڏهن بندش صحيح واپس ٿي وڃي ، ته اهو عنصر ختم ۽ پيدا ٿي وڃي ٿو.
    /// جيڪڏهن بندش غلط موٽائي ٿي ، عنصر vector ۾ رهندو ۽ ويتر طرفان پيدا نه ٿيندو.
    ///
    /// اهو طريقو استعمال ڪرڻ هيٺ ڏنل ڪوڊ جي برابر آهي.
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // توهان جو ڪوڊ هتي
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// پر ايڪسڪسڪس استعمال ڪرڻ آسان آهي.
    /// `drain_filter` پڻ وڌيڪ موثر آهي ، ڇاڪاڻ ته اهو آرڪ جي عناصر کي وڏي تعداد ۾ واپس ڪري سگھي ٿو.
    ///
    /// نوٽ ڪيو ته `drain_filter` توھان کي پڻ اجازت ڏئي ٿو توھان کي ھر عنصر فلٽر بندش ۾ ، قطع نظر ته توھان رکڻ يا ختم ڪرڻ جو انتخاب ڪندا آھيو.
    ///
    ///
    /// # Examples
    ///
    /// صفن ۾ evاٿل ۽ خرابين ۾ اٿل ، اصل مختص کي ٻيهر استعمال ڪرڻ.
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // اسان جي لڪڻ تي اسان جي حفاظت ڪريو (لیک امپريشن)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// عمل کي وڌايو جيڪو عناصر کي ريفرنس مان ڪ copiesڻ کان اڳ Vec تي ڌڪ ڏيڻ کان اڳ.
///
/// هي پليشن سليس ايٽيرئزز جي لاءِ خاص آهي ، جتي هن هڪ ڀيرو س slي سلائس کي ضم ڪرڻ لاءِ [`copy_from_slice`] استعمال ڪيو.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// vectors جو نقشو ٺاھڻ ، [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// vectors جو حڪم لاڳو ڪندي ، [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // استعمال ڪريو [T] لاءِ ڊرايو استعمال ڪريو هڪ خام سلائس استعمال ڪريو vector جا عنصر جيئن جو ضروري ڪمزور قسم وانگر ؛
            //
            // خاص ڪيسن ۾ صحيحن جي سوالن کان پاسو ڪري سگھيو
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // خام ويڪ نيڪال کي سنڀاليندو آهي
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// خالي `Vec<T>` ٺاهي ٿو.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: لسٽسٽ ۾ ٽيسٽ ڇڪي ٿي ، جنهن جي ڪري غلطيون هتي اچن ٿيون
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: لسٽسٽ ۾ ٽيسٽ ڇڪي ٿي ، جنهن جي ڪري غلطيون هتي اچن ٿيون
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// `Vec<T>` جي مڪمل مواد کي صف جي طور تي حاصل ڪري ٿي ، جيڪڏهن هن جو اندازو صحيح طور تي درخواست ٿيل صف سان ملي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// جيڪڏهن ڊيگهه مماثل نه آهي ، ان پٽ `Err` ۾ واپس اچي ٿي:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// جيڪڏھن توھان ٺيڪ آھيو صرف `Vec<T>` جي ھڪڙي اڳين کي حاصل ڪرڻ سان ، توھان ڪال ڪري سگھوٿا [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // حفاظت: `.set_len(0)` هميشه آواز آهي.
        unsafe { vec.set_len(0) };

        // حفاظت: هڪ `وييڪ 'جو اشارو هميشه چ properlyيءَ طرح ترتيب ڏنل آهي ، ۽
        // ترتيب ڏيڻ وارن صفن جي گھربل آھي جيتري آھي.
        // اسان اڳ ئي چيڪ ڪيو ته اسان وٽ ڪافي شيون آهن.
        // شيون ٻٽي نه ڇڏينديون جيئن `set_len` `Vec` کي ٻڌائي ٿو ته انهن کي به نه ڇڏيو.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}