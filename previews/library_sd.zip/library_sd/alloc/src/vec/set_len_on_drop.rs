// وي سي جي ڊيگهه کي سيٽ ڪريو جڏهن `SetLenOnDrop` قدر کان ٻاهر نڪري وڃي.
//
// خيال اهو آهي: سيٽ لينڊن ڊروپ ۾ ڊگري وارو ميدان هڪ مقامي ڪيبل آهي جيڪو بهتر ڪندڙ ڏسندي وييڪ جي ڊيٽا پوائنٽر جي ذريعي ڪنهن اسٽور سان عرف نه ڪندو آهي.
// اهو عرفان تجزيي مسئلي #32155 جي لاءِ هڪ حل آهي
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}