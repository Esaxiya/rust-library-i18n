use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// ايٽرر پائپ لائن کي وي سي ۾ گڏ ڪرڻ لاءِ خاص ماسٽر ذري گهٽ مختص ڪيل ذريعن ، يعني
/// جڳهه تي پائپ لائن تي عمل ڪرڻ
///
/// SourceIter والدين trait اسپيشلائيزيشن فنڪشن لاءِ مختص ٿيڻ تائين رسائي ضروري آهي جيڪا ٻيهر استعمال ڪرڻ لاءِ آهي.
/// پر اها تصديق ٺيڪ ناهي ته خاص اسپيشلائيزيشن صحيح هجڻ گهرجي.
/// نقل تي اضافي حدون ڏسو.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-اندروني SourceIter/InPlaceIterable traits صرف اڊاپٽر جي زنجيرن ذريعي لاڳو ٿيل آهن <Adapter<Adapter<IntoIter>>> (سڀ core/std جي ملڪيت).
// اڊاپٽر جي نفاذ تي اضافي حدون (`impl<I: Trait> Trait for Adapter<I>` کان وڌيڪ) صرف ٻين traits تي منحصر آهن اڳ ۾ ئي خاص طور تي traits (ڪاپي ، TrustedRandomAccess، FusedIterator) طور نشان لڳل
//
// I.e. نشانن جي استعمال ڪندڙ قسم جي استعمال جي حياتي تي منحصر ناهي.ڪاپي سوراخ کي مايولو ، جنهن تي اڳ ۾ ئي ٻيون خاص مهارتون منحصر آهن.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // اضافي گهرجون جيڪي trait bounds ذريعي ظاهر نه ٿي ڪري سگھجن.اسان انحصار ڪن تي بي بنياد آهي.
        // الف) ڪوبه ايس ايس ٽي ايس نه هوندو جيئن ٻيهر استعمال ڪرڻ لاءِ مختص نه هوندو ۽ پوائنٽر رياضي به هوندو panic b) سائيز ميچ جيترو الوڪ معاهدي جي مطابق گهربل
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // وڌيڪ عام عمل درآمد ڏانهن واپسي
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // ڪتب آڻڻ جي ڪوشش ڪريو
        // - اهو ڪجهه ايرايٽر ايڊاپٽرز کي بهتر بڻائي ٿو
        // - اڪثر اندروني تڪرار واري طريقن جي برعڪس ، اهو صرف هڪ &mut پاڻ وٺندو آهي
        // - اهو اسان کي انجيئرز ذريعي لکڻ جو اشارو ڏياريندو آهي ۽ ان کي آخر ۾ واپس حاصل ڪرڻ ڏيندو آهي
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // اهو ڪامياب ٿيو ، سر نه ڇڏ
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // چيڪ ڪريو جيڪڏهن SourceIter معاهدو برقرار رکيو ويو آھي: جيڪڏھن اھي نه ھجن ھا ته شايد اسان کي ھن زماني تائين به نہ آڻي سگھون
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // چيڪ ڪريو ايپلائيبل ايبل معاهدو.اهو تڏهن ئي ممڪن آهي جيڪڏهن انٽرٽر ماخذ پوائنٽر کي تمام گهڻو اڳتي وڌائي.
        // جيڪڏهن اهو TrustedRandomAccess ذريعي غير معقول رسائي استعمال ڪري ٿو ته پوءِ ماخذ پوائنٽر پنهنجي شروعاتي حيثيت ۾ رهندو ۽ اسان ان کي حواله جي طور تي استعمال نٿا ڪري سگهون.
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ماخذ جي چوٽي تي بقايا قدر ڇڏيندا آهن پر وراڻيو پاڻ کي preventهلائڻ کان بچاء هڪ دفعي اندر وڃي وڃي اگر panics theوٽو ته پوءِ اسان پڻ جمع ٿيندڙ ڪنهن عنصر کي dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable معاهدي جي هتي صحيح نموني تصديق نه ٿي ڪري سگهجي ، ڇاڪاڻ ته try_fold کي ماخذ پوائنٽر جو هڪ خاص حوالو آهي ، اسان اهو سڀ ڪجهه ڪري سگهون ٿا ته اهو چيڪ ڪيو وڃي ته ڇا اهو اڃا تائين حد ۾ آهي
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}