//! ھڪڙي متحرڪ viewڪيل ڏسڻ وارو تسلسل ۾ ، `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! سلائس ياداشت جي بلاڪ ۾ هڪ نظارو آهن جيئن پوائنٽر ۽ ڊيگهه جي نمائندگي ڪئي وئي آهي.
//!
//! ```
//! // وييڪ کي سلائس ڪرڻ
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // ٻلي کي ترتيب ڏيڻ لاءِ
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! سلائسون يا ته تبديل ٿيل آهن يا ونڊيل آهن.
//! حصيداري سلائس جو قسم `&[T]` آھي ، جڏھن ته مٽائڻ واري سليس جو قسم `&mut [T]` آھي ، جتي `T` عنصر قسم جي نمائندگي ڪري ٿو.
//! مثال طور ، توهان ياداشت جي بلاڪ کي تبديل ڪري سگهو ٿا جيڪي هڪ قابل تبديل سلائس اشارو ڪن ٿا:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! هي ڪجھ شيون آهن جيڪي هن ماڊل تي مشتمل آهن:
//!
//! ## Structs
//!
//! اتي ڪيترائي ساختون آھن جيڪي سلائسس لاءِ مفيد آھن ، جيئن [`Iter`] ، جيڪو ھڪڙي سلائس تي وھڪريشن جي نمائندگي ڪري ٿو.
//!
//! ## Z0 ٽريٽ0 زيور پختو
//!
//! عام سلطنت جي لاءِ traits ڪيترائي عملدرآمد آھن.ڪجھ مثال شامل آھن:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`] ، سلائسس جي لاءِ جن جي عنصر قسم [`Eq`] يا [`Ord`] آهن.
//! * [`Hash`] - سلائسز جي لاءِ جن جي عنصر قسم [`Hash`] آھي.
//!
//! ## Iteration
//!
//! سلائسز `IntoIterator` تي عمل ڪن ٿيون.ايريرٽر سليس عناصر کي حوالو ڏي ٿو.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! بدلندڙ سليس عنصرن کي تبديل ٿيندڙ حوالن ڏي ٿو.
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! اهو ايٽرر سلائسس جي عنصرن کي بدلائيندڙ حوالا ڏي ٿو ، تنهن ڪري جڏهن ته ٻليءَ جي عنصر جو قسم `i32` هوندو آهي ، ايٽرر جو عنصر قسم `&mut i32` آهي.
//!
//!
//! * [`.iter`] ۽ [`.iter_mut`] واضح طريقا آهن ته ريفالٽ آئيٽرر کي واپس ڪرڻ لاءِ.
//! * وڌيڪ طريقا جيڪي موٽائيندڙ واپس ڪن ٿا [`.split`] ، [`.splitn`] ، [`.chunks`] ، [`.windows`] ۽ وڌيڪ.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// ھن ماڊل ۾ گھڻيون استعمال صرف ٽيسٽ جي تشڪيل ۾ استعمال ٿيل آھن.
// اھو انھن کي ٺيڪ ڪرڻ جي بدران غير استعمال ٿيل_امپورٽس وارننگ کي بند ڪرڻ صاف آھي.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// بنيادي سلائس توسيع جا طريقا
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) اين بي کي جاچ جي دوران `vec!` ميڪرو جي نفاذ جي ضرورت آهي ، انهي فائل ۾ `hack` ماڊل ڏسو وڌيڪ تفصيل لاءِ.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) اين بي ٽيسٽ ڪرڻ دوران ايڪس اين ايم ايڪس جي لاڳو ٿيڻ جي ضرورت آهي ، انهي فائل ۾ `hack` ماڊل ڏسو وڌيڪ تفصيل لاءِ.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` سان دستياب ناهي ، اهي ٽي افعال اصل ۾ طريقا آهن جيڪي `impl [T]` ۾ آهن پر `core::slice::SliceExt` ۾ نه آهن ، اسان کي انهن فنڪشنز کي فراهم ڪرڻ جي ضرورت آهي `test_permutations` ٽيسٽ
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // اسان کي ان ۾ ان لائن خاصيت شامل نه ڪرڻ گهرجي ڇاڪاڻ ته اهو گهڻو ڪري `vec!` ميڪرو ۾ استعمال ٿيندو آهي ۽ پرف رجريشن جو سبب بڻجندو آهي.
    // بحث ۽ پرفارم نتيجا لاءِ #71204 ڏسو.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // هيٺيان لوپ ۾ شين کي شروعاتي نشان لڳايو ويو هو
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) حدفن جي چيڪن کي ختم ڪرڻ لاءِ ايل ايل وي ايم لاءِ ضروري آهي ۽ ان کي زپ کان بهتر ڪوڊينجين آهي.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // وي سي مختص ڪيو ويو هو ۽ گهٽ ۾ گهٽ هن ڊيگهه کان مٿي شروع ڪيو ويو.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` جي ظرفيت جي مٿان مختص ڪيل ، ۽ هيٺ ڏنل ptr::copy_to_non_overlapping ۾ `s.len()` جي شروعات ڪئي وئي.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// سلائس کي ترتيب ڏيندو آھي.
    ///
    /// اهو قسم مستحڪم آهي (يعني برابر عنصرن کي ٻيهر ترتيب نه ڏيندو آهي) ۽ *O*(*n*\*log(* n*)) بدترين صورت آهي.
    ///
    /// جڏهن قابل اطلاق ، غير مستحڪم ترتيب ڏيڻ کي ترجيح ڏني ويندي آهي ڇاڪاڻ ته اهو عام طور تي مستحڪم ترتيب ڏيڻ کان وڌيڪ تيز آهي ۽ اهو معاون ميموري مختص نه ڪندو آهي.
    /// [`sort_unstable`](slice::sort_unstable) ڏسو.
    ///
    /// # موجوده عمل درآمد
    ///
    /// موجوده الگورتھم [timsort](https://en.wikipedia.org/wiki/Timsort) پاران ھڪ انپيپٽ ، جھاز انگيز ترتيب آھي.
    /// اهو ڪيسن ۾ تمام گهڻو تيز ڪرڻ لاءِ ڊزائين ڪيو ويو آهي جتي سلائسس تقريبن چedي ترتيب سان ترتيب ڏنل آهي ، يا هڪ ٻئي جي پٺيان ٻئي يا وڌيڪ ترتيب ڏنل تڪن تي مشتمل آهي.
    ///
    ///
    /// ان کان علاوه ، اهو عارضي ذخيرو مختص ڪري ٿو `self` جو اڌ حصو ، پر نن slن سلائسن لاءِ بدران مختص ٿيل داخل ٿيل قسم بدران استعمال ڪيو ويندو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// سليٽر کي تقابلي فنڪشن سان ترتيب ڏيندو آهي.
    ///
    /// اهو قسم مستحڪم آهي (يعني برابر عنصرن کي ٻيهر ترتيب نه ڏيندو آهي) ۽ *O*(*n*\*log(* n*)) بدترين صورت آهي.
    ///
    /// تقابلي فنڪشن سليس ۾ موجود عنصرن جي ڪل ترتيب ڏيڻ لازمي آهي.جيڪڏهن ترتيب مڪمل نه آهي ، عنصرن جي ترتيب اڻ ecاڻايل آهي.
    /// هڪ آرڊر ڪل آرڊر آهي جيڪڏهن اهو آهي (سڀ `a` ، `b` ۽ `c` لاءِ):
    ///
    /// * ڪل ۽ antimymmetric: ھڪڙو بلڪل `a < b` ، `a == b` يا `a > b` سچ آھي ، ۽
    /// * منتقلي ، `a < b` ۽ `b < c` مطلب `a < c`.ٻئي `==` ۽ `>` لاءِ ساڳيو ئي هئڻ لازمي آهي
    ///
    /// مثال طور ، جڏهن [`f64`] [`Ord`] تي عمل نٿو ڪري ، ڇاڪاڻ ته `NaN != NaN` ، اسان `partial_cmp` استعمال ڪري سگھوٿا اسان جي ترتيب ڏيڻ واري فنڪشن جي طور تي جڏهن اسان knowاڻون ٿا ته سلائس `NaN` تي مشتمل ناهي.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// جڏهن قابل اطلاق ، غير مستحڪم ترتيب ڏيڻ کي ترجيح ڏني ويندي آهي ڇاڪاڻ ته اهو عام طور تي مستحڪم ترتيب ڏيڻ کان وڌيڪ تيز آهي ۽ اهو معاون ميموري مختص نه ڪندو آهي.
    /// [`sort_unstable_by`](slice::sort_unstable_by) ڏسو.
    ///
    /// # موجوده عمل درآمد
    ///
    /// موجوده الگورتھم [timsort](https://en.wikipedia.org/wiki/Timsort) پاران ھڪ انپيپٽ ، جھاز انگيز ترتيب آھي.
    /// اهو ڪيسن ۾ تمام گهڻو تيز ڪرڻ لاءِ ڊزائين ڪيو ويو آهي جتي سلائسس تقريبن چedي ترتيب سان ترتيب ڏنل آهي ، يا هڪ ٻئي جي پٺيان ٻئي يا وڌيڪ ترتيب ڏنل تڪن تي مشتمل آهي.
    ///
    /// ان کان علاوه ، اهو عارضي ذخيرو مختص ڪري ٿو `self` جو اڌ حصو ، پر نن slن سلائسن لاءِ بدران مختص ٿيل داخل ٿيل قسم بدران استعمال ڪيو ويندو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // ريورس ترتيب ڏيڻ
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// سلائس کي ڪ extrڻ واري نيڪالي جي فنڪشن سان ترتيب ڏيو.
    ///
    /// اها قسم مستحڪم آهي (يعني برابر عنصرن کي ٻيهر ترتيب نه ڏني وئي آهي) ۽ *O*(*m*\* * n *\* log(*n*)) بدترين حالت ، جتي ڪيلي فنڪشن *O*(*m*) آهي.
    ///
    /// قيمتي مکيه ڪمن لاءِ (مثال طور
    /// فنڪشنل جيڪي سادي ملڪيت جي رسائي يا بنيادي آپريشنون نه آهن) ، ايڪس ايڪس اين ايڪس امڪاني طور تي تيزيء سان وڌڻ جو امڪان آهي ، ڇاڪاڻ ته اهو عنصر چاٻي کي ڳڻپ ناهي.
    ///
    ///
    /// جڏهن قابل اطلاق ، غير مستحڪم ترتيب ڏيڻ کي ترجيح ڏني ويندي آهي ڇاڪاڻ ته اهو عام طور تي مستحڪم ترتيب ڏيڻ کان وڌيڪ تيز آهي ۽ اهو معاون ميموري مختص نه ڪندو آهي.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) ڏسو.
    ///
    /// # موجوده عمل درآمد
    ///
    /// موجوده الگورتھم [timsort](https://en.wikipedia.org/wiki/Timsort) پاران ھڪ انپيپٽ ، جھاز انگيز ترتيب آھي.
    /// اهو ڪيسن ۾ تمام گهڻو تيز ڪرڻ لاءِ ڊزائين ڪيو ويو آهي جتي سلائسس تقريبن چedي ترتيب سان ترتيب ڏنل آهي ، يا هڪ ٻئي جي پٺيان ٻئي يا وڌيڪ ترتيب ڏنل تڪن تي مشتمل آهي.
    ///
    /// ان کان علاوه ، اهو عارضي ذخيرو مختص ڪري ٿو `self` جو اڌ حصو ، پر نن slن سلائسن لاءِ بدران مختص ٿيل داخل ٿيل قسم بدران استعمال ڪيو ويندو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// سلائس کي ڪ extrڻ واري نيڪالي جي فنڪشن سان ترتيب ڏيو.
    ///
    /// ڇڪڻ دوران ، اهم فنڪشن صرف هڪ ڀيرو هر عنصر کي سڏيو ويندو آهي.
    ///
    /// اها قسم مستحڪم آهي (يعني برابر عنصرن کي ٻيهر ترتيب نه ڏني وئي آهي) ۽ *O*(*m*\* * n *+* n *\* log(*n*)) بدترين حالت ، جتي ڪيلي فنڪشن آهي *O*(*m*) .
    ///
    /// سادي مکيه افعال جي لاءِ (مثال طور ، جيڪي ڪم ملڪيت جي پهچ يا بنيادي ڪارروائي) آهن ، [`sort_by_key`](slice::sort_by_key) تيزيءَ سان وڌڻ جو امڪان آهي.
    ///
    /// # موجوده عمل درآمد
    ///
    /// موجوده الورورٿم [pattern-defeating quicksort][pdqsort] تي آرسن پيٽرس تي ٻڌل آهي ، جيڪا هاپسورٽ جي تيز ترين بدترين ڪيس سان بي ترتيب واري تيز رفتار واري اوسط ڪيس کي گڏ ڪري ٿي ، جڏهن خاص نمونن سان سلائسس تي لڪير وارو وقت حاصل ڪندي.
    /// اهو انحصار ڪندڙ ڪيسن کان بچڻ لاءِ ڪجهه بي ترتيب استعمال ڪندو آهي ، پر هڪ مقرر ٿيل seed سان هميشه طئي ٿيل رويي کي مهيا ڪرڻ لاءِ.
    ///
    /// بدترين حالت ۾ ، الگورتھم ھڪڙي نن00ڙي ڊيگهه جي ايڪس آرڪس ۾ عارضي ذخيرو مختص ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // اسان جي vector ترتيب ڏيڻ لاءِ مددگار ميڪرو نن possibleي نن typeي قسم پاران ، مختص گهٽائڻ لاءِ.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices` جا عنصر ڌار آهن ، جيئن ته اهي ترتيب ڏنل آهن ، اهڙي طرح اصل سلائس جي حوالي سان ڪو به قسم مستحڪم ٿيندو.
                // اسان `sort_unstable` هتي استعمال ڪريون ٿا ڇاڪاڻ ته اها گھٽ يادگيري مختص ڪرڻ جي ضرورت آهي.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` کي نئون `Vec` ۾ نقل ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // هتي ، `s` ۽ `x` کي آزاد طور تبديل ڪري سگھجي ٿو.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self` نئين `Vec` ۾ الٽوائيٽ سان نقل ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // هتي ، `s` ۽ `x` کي آزاد طور تبديل ڪري سگھجي ٿو.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // اين بي ، ھن تفصيل ۾ `hack` ماڊل ڏسو.
        hack::to_vec(self, alloc)
    }

    /// `self` کي vector ۾ ڪلونز يا مختص ڪرڻ کان بغير بدلائي ٿو.
    ///
    /// نتيجو ڪندڙ vector کي واپس آڻي سگهجي ٿو باڪس ذريعي `وييڪ` ذريعي<T>`into_boxed_slice` طريقو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` وڌيڪ استعمال نه ٿو ڪري سگھجي ڇاڪاڻ ته ان کي `x` ۾ تبديل ڪيو ويو آهي.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // اين بي ، ھن تفصيل ۾ `hack` ماڊل ڏسو.
        hack::into_vec(self)
    }

    /// هڪ vector ٺاهي ٿو هڪ slice `n` دفعا ٻيهر ورجائڻ سان.
    ///
    /// # Panics
    ///
    /// انهي ڪارڪردگي وڌو panic جيڪڏهن گنجائش وڌيڪ ٿيندو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// هڪ panic اوور فلوڊ مٿان:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // جيڪڏهن `n` صفر کان وڏو آهي ، ان کي `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` طور ورهائي سگهجي ٿو.
        // `2^expn` ڇا `n` جي کاٻي پاسي کان وڌيڪ '1' نمائندگي ڪيل نمبر آھي ، ۽ `rem` `n` جو باقي حصو آھي.
        //
        //

        // ايڪسڪسيمڪس کي رسائي ڪرڻ لاءِ `Vec` استعمال ڪري رهيو آهي.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` دہرائي `buf` کي ٻيڻ ڪندي ڪيو ويندو آهي
        buf.extend(self);
        {
            let mut m = n >> 1;
            // جيڪڏهن `m > 0` ، باقي کاٻي پاسي '1' تائين باقي بٽ آهن.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` جي گنجائش آهي.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` ("=n ، 2 ^ expn") ريپريزينٽيشن `buf` پاڻ کان پھرين `rem` دہرائي نقل ڪندي ڪئي آھي.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // هي `2^expn > rem` کان اڳ غير ڀرپاسي آهي.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` برابر `buf.capacity()` ("= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// ھڪڙي ھڪڙي قيمت `Self::Output` ۾ ھڪڙي ھڪڙي `T` جي ھڪڙي سلائيٽ ڀريندو آھي.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// هڪ واحد قدر `Self::Output` ۾ `T` جي هڪ سلائيٽ کي فليٽ ڪري ٿو ، هر هڪ جي وچ ۾ ڏنل الڳ رکڻ وارو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// هڪ واحد قدر `Self::Output` ۾ `T` جي هڪ سلائيٽ کي فليٽ ڪري ٿو ، هر هڪ جي وچ ۾ ڏنل الڳ رکڻ وارو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// انهي سلائس جي ڪاپي تي مشتمل vector ورجائي ٿو جتي هر بائيٽ ان جي ASCII اپر ڪيس جي برابر نقشه ڪيل آهي.
    ///
    ///
    /// ASCII خط 'a' کان 'z' 'A' کان 'Z' ڏانهن نقشه ڏنل آهن ، پر غير ASCII خط بدلايو نٿا وڃن.
    ///
    /// قيمت کي جڳائي ۾ وڏو ڪرڻ لاءِ ، ايڪس ايڪس ايڪس استعمال ڪريو.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// انهي سلائس جي ڪاپي تي مشتمل vector ورجائي ٿو جتي هر بائيٽ ان جي ASCII نن caseي صورت جي برابر برابر نقشه ٺاهيل آهي.
    ///
    ///
    /// ASCII خط 'A' کان 'Z' 'a' کان 'z' ڏانهن نقشه ڏنل آهن ، پر غير ASCII خط بدلايو نٿا وڃن.
    ///
    /// قيمت کي گھٽائڻ واري جڳهه ۾ ، [`make_ascii_lowercase`] استعمال ڪريو.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// خاص قسمن جي ڊيٽا تي سلائسز لاءِ واڌ traits
////////////////////////////////////////////////////////////////////////////////

/// مددگار trait لاءِ [`[T]: : concat`](سلائس::concat).
///
/// Note: `Item` قسم پيمٽرٽر trait ۾ استعمال نه ڪيو ويو آهي ، پر اهو نقش وڌيڪ عام ڪرڻ جي اجازت ڏئي ٿو.
/// بغير بغير ، اسان هي غلطي حاصل ڪريون ٿا:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// اهو ئي سبب آهي ته ڪيترن ئي `Borrow<[_]>` نقلن سان `V` قسم موجود رهي سگهن ٿيون ، جهڙوڪ ڪيترن ئي `T` قسم لاڳو ٿي سگهندا:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// نتيجو ٺهڻ کان پوءِ نتيجو ڪندڙ قسم
    type Output;

    /// ["[T]: : Concat"] جو عمل درآمد (slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// مددگار trait لاء ["[ٽي]: : شامل ٿيو"](سلائس::شامل)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// نتيجو ٺهڻ کان پوءِ نتيجو ڪندڙ قسم
    type Output;

    /// ["[T]: : شامل" جي عملدرآمد (سلائس::شامل)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// معياري نموني trait پليز
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // ٽارگيٽ ۾ ڪا به شيءِ ورجائي نه ويندي
        target.truncate(self.len());

        // target.len <= self.len مٿي ٽڪنڊي جي ڪري ، تنهن ڪري هتي سلائسون هميشه حد ۾ ڇڏينديون آهن.
        //
        let (init, tail) = self.split_at(target.len());

        // استعمال ٿيل قدرن کي allocations/resources استعمال ڪريو.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` کي اڳئين ترتيب واري ترتيب `v[1..]` ۾ داخل ڪري ٿو ته س wholeو `v[..]` ترتيب وار ٿي وڃي.
///
/// اهو آهي ضمني قسم جو لازمي سبروين.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // هتي داخل ڪرڻ جا ٽي طريقا آهن:
            //
            // 1. ويجهڙائي وارن عناصر کي مٽايو جيستائين پهرين پنهنجي آخري منزل تائين پهچي نه وڃي.
            //    بهرحال ، انهي طريقي سان اسان ڊيٽا جي ڪاپي ضروري هوندي کان وڌيڪ ضروري آهي.
            //    جيڪڏهن عناصر وڏي اڏاوتون آهن (ڪاپي ڪرڻ لاءِ قيمتي) ، اهو طريقو سست ٿي ويندو.
            //
            // 2. ايٽرٽ ڪيو جيستائين پهرين عنصر جو صحيح هنڌ نه مليو.
            // پوءِ ان کي ڪامياب ڪرڻ واري عنصرن کي منتقل ڪيو ته ان لاءِ جاءِ ٺاهيو ۽ آخر ۾ اهو رکيل سوراخ ۾ رکجي.
            // اھو ھڪڙو سٺو طريقو آھي.
            //
            // 3. پھرين عنصر کي عارضي ڪيفيت ۾ نقل ڪريو.ايستائين صحيح ڪريو جيستائين ان جي صحيح جڳهه نه ملي وڃي.
            // جئين اسان هلون ٿا ، هر پيچرايل عنصر کي هن کان اڳ واري سلاٽ ۾ ڪاپي ڪريو.
            // آخرڪار ، عارضي متغير کان ڊيٽا نقل ڪري باقي سوراخ ۾.
            // اهو طريقو تمام سٺو آهي.
            // ٻئي طريقا جي مقابلي ۾ ، بينچ مارڪ ٿورڙي بهتر ڪارڪردگي جو مظاهرو ڪيو.
            //
            // سڀني طريقن جي معياري معيار مقرر ڪئي وئي ، ۽ 3rd بهترين نتيجا ڏيکاري.تنهنڪري اسان اهو چونڊيو.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // داخل ڪرڻ جي عمل جي وچولي رياست هميشه `hole` سان ٽريڪ ڪندي آهي ، جيڪا ٻن مقصدن جي خدمت ڪندي آهي.
            // 1. `is_less` ۾ panics کان `v` جي سالميت کي بچائيندو آهي.
            // 2. باقي سوراخ `v` ۾ ختم ڪري ٿو آخر ۾.
            //
            // Panic حفاظت:
            //
            // جيڪڏهن پروسيس دوران ڪنھن به وقت `is_less` panics ، `hole` ڊراپ ٿي ويندا ۽ `v` ۾ سوراخ `tmp` سان ڀريندا ، انهي کي يقيني بڻائي ته `v` اڃا به ھي ھر شي کي رھي ٿو جيڪو شروعاتي طور تي اھو ھڪڙي ئي بار رکي ٿو.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` گريو وڃي ٿو ۽ انهي ڪري `tmp` `v` ۾ باقي سوراخ ۾ نقل ڪري ٿو.
        }
    }

    // جڏهن ڇڏيو ويو ، `src` کان `dest` تان ڪاپي.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// ضم ٿيل نمي گهٽائڻ واريون `v[..mid]` ۽ `v[mid..]` استعمال ڪن ٿا `buf` عارضي اسٽوريج جي طور تي ، ۽ نتيجو کي `v[..]` ۾ ذخيرو ڪري ٿو.
///
/// # Safety
///
/// ٻن سلائسون خالي نه هونديون ۽ `mid` ضرور حدن ۾ هجڻ گهرجن.
/// نن slو سلائس جي ڪاپي رکڻ لاءِ بفر `buf` ڊگهو هجڻ گھرجي.
/// ان کان علاوه ، `T` صفر جي قسم وارو قسم نه هجڻ گهرجي.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // ضم ٿيڻ جي عمل پهرين نن copiesي ايڪسپيٽ `buf` ۾ نقل ڪيو.
    // ان کان پوء اها نئين ڪاپي ٿيل ڊوڙ تي رڌل هوندي آهي ۽ ڊگهي هلائي اڳتي (يا پوئتي) ، انهن جي اڳتي هلي اڻ elementsاتل عنصرن جو مقابلو ڪندي ۽ `v` ۾ گهٽ (يا وڌيڪ) هڪ کي نقل ڪندي.
    //
    // جيترو نن runڙو نن runڙو رن fully مڪمل طور تي کائي ويندو آهي ، اهو عمل مڪمل ٿي ويندو آهي.جيڪڏهن گهڻي عرصي کان پهرين ڊوڙجي وڃي ٿي ، ته پوءِ اسان کي x00X جي باقي سوراخ ۾ نن runي هلائڻ واري ڪا شي کي نقل ڪرڻ گهرجي.
    //
    // پروسيس جي وچولي رياست هميشه `hole` طرفان ٽريڪ ڪندي آهي ، جيڪو ٻن مقصدن جي خدمت ڪندو آهي.
    // 1. `is_less` ۾ panics کان `v` جي سالميت کي بچائيندو آهي.
    // 2. باقي سوراخ `v` تي ڀاڙيندو آهي جيڪڏهن ڊگهي وقت اڳ ئي ڀ getsي وڃي.
    //
    // Panic حفاظت:
    //
    // جيڪڏهن پروسيس دوران ڪنھن به مرحلي تي `is_less` panics ، `hole` ڊراپ ٿي ويندا ۽ `v` ۾ غير استعمال ٿيل رينج سان سوراخ ڀريندو `buf` ، اھڙي طرح ھن ڳالھ کي يقيني بڻايو ته `v` اڃا به ھر ھڪڙي شي کي رھي ٿو جيڪو اھو ابتدائي طور تي ھڪڙي ئي وقت ۾ رکيل آھي.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // کاٻي پاسي نن isو آهي.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // شروعات ۾ ، اهي نقطو پنهنجي آيتن جي شروعات ڏانهن اشارو ڪندا آهن.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // گهٽ طرفن کي ڀاڙي وٺو.
            // جيڪڏهن برابر هجي ، استحڪام کي برقرار رکڻ لاءِ کاٻي ڌر کي ترجيح ڏيو.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // صحيح رائيٽ نن isڙو آهي.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // شروعات ۾ ، اهي نقطا پنهنجي آ arrرين جي ختمين جي طرف اشارو ڪندا آهن.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // وڏي طرف کي گھٽيو.
            // جيڪڏهن برابر ، استحڪام برقرار رکڻ لاءِ س runي هل کي ترجيح ڏيو.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // آخرڪار ، `hole` گر ٿي وڃي ٿو.
    // جيڪڏهن نن runو هلندڙ رستو مڪمل طور تي استعمال نه ڪيو ويو ، جو باقي رهيل هاڻ `v` ۾ سوراخ ۾ نقل ڪيو ويندو.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // جڏهن ٻڏي وئي ، `dest..` ۾ حد `start..end` ڪاپي ڪندو.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` صفر-سائيز وارو قسم نه آهي ، تنهنڪري اهو صحيح آهي ته ان جي ماپ سان ورهايو وڃي.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// هن ميلاپ جي ترتيب TimSort مان ڪجهه (پر سڀ نه) مان قرض وٺن ٿا ، جو [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) تفصيل سان بيان ڪيو ويو آهي.
///
///
/// الگورٿم سختي سان نزول ۽ غير ترتيب واري تحريرن جي نشاندهي ڪري ٿو ، جيڪي قدرتي رليون سڏجن ٿيون.انتظار جي رنن جو هڪ اسٽور آهي اڃا به ضم ٿيڻ نه آهي.
/// هر نئون مليل ڊوڙ اسٽيڪ ڏانهن وڌي ويو آهي ، ۽ پوءِ ڀرپاسي وارا ڪجهه جوڙا گڏ ڪيا ويا آهن ، جيستائين اهي ٻه ويڙهاڪ مطمئن نه ٿين:
///
/// 1. هر `i` لاءِ `1..runs.len()` ۾: `runs[i - 1].len > runs[i].len`
/// 2. هر `i` لاءِ `2..runs.len()` ۾: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// دعوت ڏيندڙن کي پڪ آهي ته هلندڙ کل وقتي *O*(*n*\*log(* n*)) بدترين صورت آهي.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // هن ڊيگهه تائين سلائسون ترتيب ڏيندي ترتيب ڏيندي ترتيب ڏي.
    const MAX_INSERTION: usize = 20;
    // تمام نن runsا رستا وڌايل قسم جي استعمال سان وڌايل آهن گهٽ ۾ گهٽ هن ڪيترن ئي عنصرن کي toهلائڻ لاءِ.
    const MIN_RUN: usize = 10;

    // صفر وارين قسمن تي ترتيب ڏيڻ سان ڪو به معنوي رويو نه آهي.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // نن arrيون وڏيون ترتيبون جڳهن ذريعي ترتيب وار ترتيب سان ترتيب ڏيڻ کان بچڻ لاءِ.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // خرچي ياداشت جي طور تي استعمال ڪرڻ لاءِ هڪ بفر مختص ڪريو.اسان ڊيگهه 0 رکو تنهن ڪري اسان انهي ۾ `v` جي مواد جون نن copiesيون ڪاپيون رکون ٿا بغير ڊيٽرز جي ڪاپي تي هلندي جيڪڏهن `is_less` panics.
    //
    // جڏهن ٻن ترتيب وارن رنن کي گڏ ڪرڻ سان ، اهو بفر نن runي رن جي ڪاپي رکي ٿو ، جنهن جي سدائين `len / 2` تي هميشه هوندي.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v` ۾ قدرتي هلائيندڙن جي نشاندهي ڪرڻ لاءِ ، اسان ان کي اڳتي پوئتي ڪريون ٿا.
    // اهو لڳي سگهي ٿو هڪ عجيب فيصلو آهي ، پر حقيقت تي غور ڪريو ته گڏجاڻي وڌيڪ اڪثر مخالف سمت ۾ وڃي ٿي (forwards).
    // معيار مطابق ، اڳتي وڌڻ سان گڏ پوئتي موٽڻ جي ڀيٽ ۾ ٿورو تيز آهي.
    // آخرڪار ، پيچرو ڊوڙندو ڊوڙندو پوئتي هلڻ سان ڪارڪردگي بهتر ٿي ويندي آهي.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // ايندڙ قدرتي رستو ڳوليو ، ۽ ان کي reverseيرايو جيڪڏهن اهو سختي سان هيٺ اچي رهيو آهي.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // ڊوڙ ۾ ڪجهه وڌيڪ عنصر داخل ڪريو جيڪڏھن اھو تمام نن shortڙو ھجي.
        // مختصر ترتيب تي ضم ٿيل ترتيب کان وڌيڪ داخل ٿيڻ تيز آهي ، تنهن ڪري اهو خاص طور تي ڪارڪردگي بهتر ڪري ٿو.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // هن ڊوڙ کي پائڻ کي دٻايو.
        runs.push(Run { start, len: end - start });
        end = start;

        // ڀريندڙ ڊوڙن کي ڪجهه تسلي بخشيندڙن کي راضي ڪرڻ لاءِ ضم ڪريو.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // آخرڪار ، واقعي هڪ ڊور اسٽيڪ ۾ ئي رهڻ گهرجي.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // رنز جي اسٽيڪ کي جانچ ڪري ٿو ۽ رننگ جو ايندڙ جوڙو ملائڻ کي سڃاڻپ ڪري ٿو.
    // خاص طور تي ، جيڪڏهن `Some(r)` موٽي وئي آهي ، ان جو مطلب `runs[r]` ۽ `runs[r + 1]` اڳ ۾ ضم ٿيڻ گهرجي.
    // جيڪڏهن الگورتھم نئين رن کي تعمير ڪرڻ جاري رکي ، ان جي `None` موٽي وئي آهي.
    //
    // ٽمسورٽ هن جي بگلي عمل درآمد جي ڪري بدنام آهي ، جيئن هتي بيان ڪيو ويو آهي:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // ڪهاڻي جو خلاصو هي آهي: اسان کي اسٽاپ تي چوڏهن چئن رڪنن تي چوڪيدار ضرور لاڳو ڪرڻ گهرجن.
    // صرف مٿين ٽن تي انهن کي لاڳو ڪرڻ انهي ڳالهه کي يقيني بڻائڻ لاءِ ڪافي نه آهي ته حملي ڪندڙ اڃا تائين *سڀ* ڊوڙندا رهندا.
    //
    // اهو فنڪشن صحيح طور تي چوڏهن رنز جي مقابلي ۾ پهاڙين کي چيڪ ڪري ٿو.
    // اضافي طور تي ، جيڪڏهن مٿيون رڻ انڊيڪس 0 تي شروع ٿئي ٿي ، اهو هميشه هڪ آپريشن جو مطالبو ڪندو جيستائين اسٽڪ مڪمل طور تي ختم ٿي ويندو ، ترتيب مڪمل ڪرڻ لاءِ.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}