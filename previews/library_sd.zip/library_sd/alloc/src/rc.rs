//! واحد ڌڪيل حوالي واري ڳڻپيندڙ اشارو.'Rc' جو مطلب آھي حوالي لاءِ
//! Counted'.
//!
//! قسم [`Rc<T>`][`Rc`] قسم `T` جي قيمت جي گڏيل ملڪيت فراهم ڪندو آهي ، هپ ۾ مختص ٿيل.
//! [`Rc`] تي [`clone`][clone] کي سڏڻ ھڪڙي نئين پوائنٽر کي اسپيڊ ۾ ساڳيو مختص ڪري ٿو.
//! جڏهن هڪ ڏنل مختص ڪيل آخري [`Rc`] پوائنٽر کي تباهه ڪيو وڃي ، ان ويليوشن ۾ ذخيرو ٿيل قدر (اڪثر ڪري "inner value" جو حوالو ڏنو ويندو) پڻ ختم ڪيو ويو آهي.
//!
//! Rust ۾ گڏيل حوالن ڊفالٽ ذريعي ميوٽيشن کي رد ڪن ٿا ، ۽ [`Rc`] ڪا استثنا نه آهي: توهان عام طور تي [`Rc`] اندر ڪنهن به شيءَ جي لاءِ قابل تبديل حوالا حاصل نٿا ڪري سگهو.
//! جيڪڏهن توهان کي مطابقت جي ضرورت آهي ، هڪ X012 اندر [`Cell`] يا [`RefCell`] رک ؛[an example of mutability inside an `Rc`][mutability] ڏسو.
//!
//! [`Rc`] غير ايٽمي ريفرنس ڳڻپ جو استعمال ڪندو آهي.
//! ان جو مطلب اهو آهي ته اوور ويڊ تمام گهٽ آهي ، پر هڪ [`Rc`] سلسلا جي وچ ۾ موڪلي نٿو سگهجي ، ۽ نتيجي طور [`Rc`] [`Send`][send] تي عمل نٿو ڪري.
//! نتيجي طور ، Rust ترتيب ڏيڻ وارا *انٽيليجنس وقت تي چيڪ ڪنديون ته* توهان موضوعن جي وچ ۾ ["Rc" نه موڪلي رهيا آهيو.
//! جيڪڏهن توهان کي گھڻ ڌاڳو ، ائٽومي ريفرنس ڳڻپ جي ضرورت آهي ، استعمال ڪريو [`sync::Arc`][arc]
//!
//! [`downgrade`][downgrade] طريقو غير مالڪ [`Weak`] پوائنٽر ٺاھڻ لاءِ استعمال ڪري سگھجي ٿو.
//! ايڪسڪسيمڪس پوائنٽر ھڪڙو [اپڊيٽ]][اپڊيٽ] ڊي ڏانھن [`Rc`] ٿي سگھي ٿو ، پر اھو واپس ريٽ ڪندو [`None`] جيڪڏهن قدر ۾ ذخيرو ٿيل قدر اڳ ۾ گھٽجي چڪو آھي.
//! ٻين لفظن ۾ ، `Weak` پوائنٽر مختص ٿيل قدر اندر نٿو رکي ؛تنهن هوندي ، اهي *رکندا* مختص رکندا (اندر جي قيمت لاءِ مدد ڏيندڙ دڪان) زنده آهن.
//!
//! [`Rc`] پوائنٽرن جي وچ وارو چڪر ڪڏهن به ختم نه ٿيندو.
//! انهي جي لاء ، ايڪسڪسيمڪس سائيڪلن کي ٽوڙڻ لاءِ استعمال ٿيندو آهي.
//! مثال طور ، هڪ وڻ مضبوط [`Rc`] پوائنٽرن کي والدين نوڊس کان ٻارن ڏانهن ، ۽ [`Weak`] اشارو ٻارن کان انهن جي والدين ڏانهن موٽي سگهي ٿو.
//!
//! `Rc<T>` پاڻمرادو `T` ڏانهن حوالو ڏيو ([`Deref`] trait ذريعي) ، تنهن ڪري توهان قسم جي [`Rc<T>`][`Rc`] جي قيمت تي ٽيو جي طريقن کي ڪال ڪري سگھو ٿا.
//! نالو T تصادم کان بچڻ لاء ، T جي طريقن سان ، [`Rc<T>`][`Rc`] جا طريقا پاڻ ۾ جڙيل هوندا آهن ، [fully qualified syntax] استعمال ٿيل سڏجن ٿا.
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! آر سي<T>traits وانگر `Clone` جو نفاذ شايد مڪمل طور تي قابل نحو استعمال ڪيو وڃي سگھي ٿو.
//! ڪجهه ماڻهو مڪمل طور تي قابل نحو استعمال ڪرڻ پسند ڪندا آهن ، جڏهن ته ٻيا طريقا استعمال ڪرڻ پسند ڪن ٿا نحو.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // طريقو ڪال نحو
//! let rc2 = rc.clone();
//! // مڪمل طور تي قابل تعليم نحو
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T` ڏانهن خودمختياري نٿو ڏئي ، ڇاڪاڻ ته اندروني قدر اڳ ۾ ئي گھٽجي چڪو آهي.
//!
//! # ڪلوننگ وارو حوالو
//!
//! اڳئين ڳڻپيوٽي جي ڳڻپيل پوائنٽر وانگر ساڳئي الائينسي جي لاءِ نئون ريفرنس ٺاهڻ [`Rc<T>`][`Rc`] ۽ [`Weak<T>`][`Weak`] لاءِ لاڳو ڪيل `Clone` trait استعمال ڪيو وڃي ٿو.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // هيٺ ڏنل ٻه نحو برابر آهن.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // الف ۽ ب ٻئي فوٽو طور ساڳي يادگيري جي جڳهه ڏانهن اشارو ڪيو آهي.
//! ```
//!
//! `Rc::clone(&from)` نحو تمام گھڻي ڳالھائيندڙ آھي ڇو تھ اھو ظاھر ڪري ظاھر ڪري ٿو ڪوڊ جو مطلب.
//! مٿي theاڻايل مثال ۾ ، اها نحو ڏسڻ آسان ٿي وڃي ٿي ته هي ڪوڊ فوو جي سموري مواد کي نقل ڪرڻ جي بدران نئون حوالو ٺاهي رهيو آهي.
//!
//! # Examples
//!
//! ھڪڙي منظر تي غور ڪريو جتي ھڪڙي گڊس جي سيٽ ڏنل `Owner` جي ملڪيت آھي.
//! اسان چاهيون ٿا اسان جي اسٽيج کي انهن جو `Owner` ڏانهن اشارو ڪيو وڃي.اسان اهو منفرد ملڪيت سان نٿا ڪري سگهون ، ڇاڪاڻ ته هڪ کان وڌيڪ گيجٽ ساڳئي `Owner` سان واسطو رکن ٿا.
//! [`Rc`] اسان کي اجازت ڏيو ته `Owner` گھڻن Gadgets جي وچ ۾ ، ۽ ڇا `Owner` مڪمل طور تي مختص ٿيل آهي جيستائين انهي تي `Gadget` پوائنٽ.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... ٻيا ميدان
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... ٻيا ميدان
//! }
//!
//! fn main() {
//!     // هڪ حوالو شمار ٿيل `Owner` ٺاهيو.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner` سان تعلق رکندڙ "گيجٽ" ٺاهيو.
//!     // ڪل `Rc<Owner>` اسان کي هڪ نئين پوائنٽر ڏيندو آهي ساڳي `Owner` مختص ، پروسيس ۾ ريفرنس جي تعداد ۾ اضافو ڪندي.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // اسان جي مقامي متغير ايڪسڪسيمڪس کي رد ڪريو.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` ڇڏڻ جي باوجود ، اسان اڃا تائين "گيجٽ" جي `Owner` جو نالو ڇپائي سگھون ٿا.
//!     // اهو ڇو ته اسان صرف هڪ `Rc<Owner>` کي ڇڏيو آهي نه ته `Owner` اهو ان ڏانهن اشارو ڪري ٿو.
//!     // جيستائين ساڳئي `Owner` مختص تي ٻيا `Rc<Owner>` اشارا آهن ، اهو زنده رهندو.
//!     // فيلڊ پروجئشن `gadget1.owner.name` ڪم ڪري ٿو ڇاڪاڻ ته `Rc<Owner>` `Owner` ڏانهن خودبخود حوالو ڏين ٿا.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // فنڪشن جي آخر ۾ ، `gadget1` ۽ `gadget2` تباهه ٿي ويا آهن ، ۽ انهن سان اسان جي `Owner` جي آخري ڳڻپيو حوالي ڪيو ويو آهي.
//!     // گيجٽ ماڻھو ھاڻي پڻ تباھ ٿي وڃي ٿو.
//!     //
//! }
//! ```
//!
//! جيڪڏهن اسان جون گهرجون تبديل ٿي وينديون آهن ، ۽ اسان کي پڻ `Owner` کان `Gadget` ڏانهن پار ڪرڻ جي ضرورت آهي ، اسان مسئلن ۾ هلنداسين.
//! `Owner` کان `Gadget` تائين [`Rc`] پوائنٽر هڪ چڪر متعارف ڪرايو آهي.
//! ان جو مطلب آهي ته انهن جو حوالو ڳڻپ ڪڏهن به پهچي نه سگهندو آهي ، ۽ مختص ڪڏهن به تباهه نه ٿيندا.
//! هڪ يادگيري ليڪانهي جي چوڌاري حاصل ڪرڻ لاءِ اسان ايڪس ايڪس ايڪس پوائنٽرس استعمال ڪري سگهون ٿا.
//!
//! Rust اصل ۾ انهي لوپ کي پهرين جڳهه تي پيدا ڪرڻ ڏکيو بڻائي ٿو.ٻن قدرن کي ختم ڪرڻ جي لاءِ جيڪي هڪ ٻئي ڏانهن اشارو ڪن انهن مان هڪ کي مٽائڻ جي ضرورت آهي.
//! اهو مشڪل آهي ڇاڪاڻ ته [`Rc`] ياداشت جي حفاظت کي لاڳو ڪري ٿو صرف ان جي قيمت تي شيئر ڪيل حوالو ڏيڻ ، ۽ اهي سڌي ميوٽيشن جي اجازت نٿا ڏين.
//! اسان کي قيمت جي حصي کي لپيڻ جي ضرورت آهي اسان جيڪو [`RefCell`] ۾ ميوٽي ڪرڻ چاهيون ٿا ، جيڪو *داخلي مطابقت* مهيا ڪري ٿو: هڪ گڏيل حوالي سان مطابقت حاصل ڪرڻ جو هڪ طريقو.
//! [`RefCell`] رن ٽائيم تي Rust جي قرضن واري ضابطن کي لاڳو ڪيو.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... ٻيا ميدان
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... ٻيا ميدان
//! }
//!
//! fn main() {
//!     // هڪ حوالو شمار ٿيل `Owner` ٺاهيو.
//!     // نوٽ ڪيو ته اسان `RefCell` اندر "مالڪ" جي vector کي "Gadget" رکيا آهيون ته جيئن ان کي گڏيل حوالن جي ذريعي بدلائي سگھون.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // `gadget_owner` سان تعلق رکندڙ "گيجٽ" ٺاهيو ، جيئن اڳ ۾ هوندو.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // انهن جي `Owner` ۾ گيجٽ کي شامل ڪريو.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` متحرڪ قرض هتي ختم ٿي.
//!     }
//!
//!     // اسان جي "گيجٽ" تي ٻيهر ترتيب ڏيو ، انهن جا تفصيل پرنٽ ڪندي.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` هڪ `Weak<Gadget>` آهي.
//!         // کان وٺي `Weak` پوائنٽر مختص ڪرڻ جي ضمانت نٿا ڏئي سگھن ، اسان کي `upgrade` سڏڻ جي ضرورت آهي ، جيڪو `Option<Rc<Gadget>>` واپس ڪري ٿو.
//!         //
//!         //
//!         // انهي صورت ۾ اسان knowاڻون ٿا ته مختص اڃا تائين موجود آهي ، تنهنڪري اسان صرف `unwrap` `Option`.
//!         // هڪ وڌيڪ پيچيده پروگرام ۾ ، توهان کي `None` نتيجو لاءِ فلاحي غلطي هٿ ڪرڻ جي ضرورت آهي.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // فنڪشن جي آخر ۾ ، `gadget_owner` ، `gadget1` ، ۽ `gadget2` تباهه ٿي ويا آهن.
//!     // گجٽ وٽ اڃا تائين مضبوط (`Rc`) اشارو نه آهن ، تنهن ڪري اهي تباهه ٿي ويا.
//!     // هي زيڊ گيٽ مان حوالي جي حوالي سان زيرو ٿئي ٿو ، ائين ئي هو تباهه ٿي وڃي ٿو.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// اهو repr(C) کان future آهي ثبوت فيلڊ ٻيهر ترتيب ڏيڻ جي خلاف ، جيڪو مداخلت ڪري سگهندو آهي ٻي صورت ۾ محفوظ [into|from]_raw() منتقلي واري اندرين قسمن جي.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// ھڪڙي ھڪڙي ترتيب واري حوالي سان ، ڳڻپيندڙ پوائنٽر.'Rc' جو مطلب آھي حوالي لاءِ
/// Counted'.
///
/// وڌيڪ تفصيل لاءِ [module-level documentation](./index.html) ڏسو.
///
/// `Rc` جا موروثي طريقا سڀ جڙيل ڪم آهن ، جنهن جو مطلب آهي توهان کي انهن کي ڪال ڪرڻ گهرجي مثال طور ، [`Rc::get_mut(&mut value)`][get_mut] جي بدران [`Rc::get_mut(&mut value)`][get_mut].
/// اهو اندروني قسم `T` جي طريقن سان تضاد کان بچائي ٿو.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // هي غير محفوظ آهي ٺيڪ آهي ڇاڪاڻ ته جڏهن هي آر سي زنده آهي اسان گارنٽي آهيون ته اندروني پوائنٽر صحيح آهي.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// نئون `Rc<T>` تعمير ڪندو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // هڪ مضبوط اشارو ڏيندڙ تمام مضبوط اشارن جي مالڪ آهي ، انهي کي يقيني بڻائي ٿو ته ڪمزور تباهه ڪندڙ ڪڏهن به مختص نه ڇڏيندو آهي جڏهن ته مضبوط تباهه ڪندڙ ڊوڙي رهيو آهي ، ايستائين جو ڪمزور پوائنٽر مضبوط اندر اندر ذخيرو ٿيل آهي.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// پنهنجي پاڻ تي هڪ ڪمزور حوالو استعمال ڪندي هڪ نئون `Rc<T>` تعمير ڪري ٿو.
    /// انهي فنڪشن جي واپسي کان پهريان ضعيف ريفرنس کي اپڊيٽ ڪرڻ جي ڪوشش ڪئي ويندي جنهن جي نتيجي ۾ `None` ويليو ٿيندي.
    ///
    /// تنهن هوندي ، ضعيف حواله شايد کلون ۽ آزادي سان کلندي استعمال لاءِ محفوظ ڪيل هجي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... وڌيڪ شعبا
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // اندروني کي "uninitialized" رياست ۾ ھڪڙو ڪمزور حوالن سان تعمير ڪريو.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // اهو ضروري آهي ته اسان ڪمزور پوائنٽر جي ملڪيت ڇڏي نه ڏيون ، ٻي صورت ۾ يادداشت `data_fn` موٽڻ واري وقت کان آزاد ٿي سگهي ٿي.
        // جيڪڏھن اسان واقعي ملڪيت جي منتقلي ڪرڻ چاھيو ٿا ، اسان پنھنجو پاڻ لاءِ ھڪ اضافي ڪمزور پوائنٽر ٺاھي رھياسين ، پر اھو ضعيف جي حوالي سان ضعيف جي واڌاري جي نتيجي ۾ ٿيندو ، جيڪو شايد ٻي صورت ۾ ضروري ناھي.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // مضبوط حوالن کي گڏيل طور تي حصيداري واري ڪمزور حوالي جو هئڻ گهرجي ، تنهنڪري اسان جي پراڻي ڪمزور ريفرنس کي تباهي وارو نه هلائڻو.
        //
        mem::forget(weak);
        strong
    }

    /// نئون `Rc` نئين شي ۾ بغير مواد جي ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// نئون `Rc` بنا ڪنهن گانڌي جي مواد سان گڏ ٺاهي ٿو ، ياداشت سان گڏ `0` بائٽس سان ڀريل.
    ///
    ///
    /// هن طريقي جي صحيح ۽ غلط استعمال جي مثالن لاءِ [`MaybeUninit::zeroed`][zeroed] ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// نئون `Rc<T>` ٺاهي ٿو ، غلطي موٽڻ آهي جيڪڏهن مختص ڪرڻ ناڪام ٿي وڃي
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // هڪ مضبوط اشارو ڏيندڙ تمام مضبوط اشارن جي مالڪ آهي ، انهي کي يقيني بڻائي ٿو ته ڪمزور تباهه ڪندڙ ڪڏهن به مختص نه ڇڏيندو آهي جڏهن ته مضبوط تباهه ڪندڙ ڊوڙي رهيو آهي ، ايستائين جو ڪمزور پوائنٽر مضبوط اندر اندر ذخيرو ٿيل آهي.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// نئين `Rc` کي بغير ڪنهن گائيڊ وارن ايجادن سان اڏائي ٿو ، هڪ غلطي موٽائي ٿو جيڪڏهن مختص ناڪام ٿي وڃي
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// نئون `Rc` بنا ڪنهن شروعاتي غيبي مواد سان اڏائي ٿو ، ياداشت سان `0` بائٽس ڀرجي رهيو آهي ، هڪ غلطي موٽائي رهيو آهي جيڪڏهن مختص ناڪامياب ٿئي
    ///
    ///
    /// هن طريقي جي صحيح ۽ غلط استعمال جي مثالن لاءِ [`MaybeUninit::zeroed`][zeroed] ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// نئون `Pin<Rc<T>>` تعمير ڪندو آهي.
    /// جيڪڏهن `T` ايڪسڪسيمڪس کي لاڳو نٿو ڪري ، `value` ميموري ۾ پئجي ويندو ۽ منتقل ڪرڻ جي قابل ناهي.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// اندروني قيمت ڏي ٿو ، جيڪڏهن `Rc` وٽ ھڪڙو مضبوط ريفرنس آھي.
    ///
    /// ٻي صورت ۾ ، هڪ [`Err`] ساڳئي `Rc` سان واپس ڪئي وئي جنهن ۾ گذري ويو.
    ///
    ///
    /// اها ڪامياب هوندي به انهي جي باوجود موجود آهن ڪمزور حوالو
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // موجود شي کي نقل ڪريو

                // ڪمزورين ڏانهن اشارو ڪيو ته اهي مضبوط ڳڻپ کي گهٽائڻ ذريعي واڌاري نٿا ڪري سگهن ، ۽ پوءِ جعلي ڪمزور هٿ ڪرڻ سان dropڪيل منطق کي هٿ ڪرڻ سان به بي نقاب "strong weak" پوائنٽر هٽايو.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// نئين اڻ izedاڻيل قسط کي اڻ izedاڻيل مواد سان اڏائي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// هڪ نئون حوالو شمار ٿيل سلائس بنا ڪنهن شروعاتي شده مواد سان گڏ ٺاهي ٿو ، ياداشت سان `0` بائٽس سان ڀريل.
    ///
    ///
    /// هن طريقي جي صحيح ۽ غلط استعمال جي مثالن لاءِ [`MaybeUninit::zeroed`][zeroed] ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` ۾ تبديل ڪندو آهي.
    ///
    /// # Safety
    ///
    /// جيئن [`MaybeUninit::assume_init`] سان ، اهو ڪالڪر تي منحصر هوندو آهي ته اها ضمانت ڏيان ته اندروني قدر واقعي ابتدائي حالت ۾ آهي.
    ///
    /// انهي کي ڪال ڪندي جڏهن مواد اڃا مڪمل طور تي ابتدائي نه ڪيو وڃي فوري طور تي اڻ سڌريل رويو ٺاهيندي.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` ۾ تبديل ڪندو آهي.
    ///
    /// # Safety
    ///
    /// جيئن [`MaybeUninit::assume_init`] سان ، اهو ڪالڪر تي منحصر هوندو آهي ته اها ضمانت ڏيان ته اندروني قدر واقعي ابتدائي حالت ۾ آهي.
    ///
    /// انهي کي ڪال ڪندي جڏهن مواد اڃا مڪمل طور تي ابتدائي نه ڪيو وڃي فوري طور تي اڻ سڌريل رويو ٺاهيندي.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `Rc` کي کائيندو آھي ، واپسي وارين پوائنٽ کي واپس ڪندي.
    ///
    /// هڪ ياداشت جي رسائي کان بچڻ لاءِ پوائنٽر [`Rc::from_raw`][from_raw] کي واپس `Rc` ۾ واپس ڪرڻ گهرجي.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ڊيٽا کي خام پوائنٽر فراهم ڪندو آهي.
    ///
    /// ڳڻپ ڪنهن به طريقي سان متاثر نه ٿيون آهن ۽ ايڪس ايڪس اين ايڪس استعمال نه ڪيو ويو آهي.
    /// پوائنٽر درست آھي جيستائين `Rc` ۾ مضبوط ڳڻپ آھن.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // حفاظت: اهو ايڪسسيڪس يا ايڪس 0 X ذريعي نٿو وڃي سگهي ڇاڪاڻ ته
        // اهو raw/mut ثابت ڪرڻ کي برقرار رکڻ جي ضرورت آهي ، مثال طور
        // `get_mut` ايڪس آرڪس ذريعي آر سي کي وصولي کانپوءِ پوائنٽر ذريعي لکي سگھي ٿو.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// هڪ خام پوائنٽر کان `Rc<T>` ٺاهي ٿو.
    ///
    /// خام پوائنٽر [`Rc<U>::into_raw`][into_raw] کي ڪال کان اڳ ۾ واپس ڪيو وڃي ها جتي `U` وٽ `T` وانگر ساڳيو سائيز ۽ هڪجهڙائي هئڻ لازمي آهي.
    /// اهو خاص طور تي صحيح آهي جيڪڏهن `U` `T` آهي.
    /// ياد رکو ته جيڪڏهن `U` `T` نه آهي پر ساڳئي سائيز ۽ ترتيب آهي ، اهو بنيادي طور تي مختلف قسمن جي حوالن جي منتقلي وانگر آهي.
    /// هن معاملي ۾ ڪهڙي پابنديون لاڳو آهن ان بابت وڌيڪ معلومات لاءِ [`mem::transmute`][transmute] ڏسو.
    ///
    /// `from_raw` جي استعمال ڪندڙ کي ان ڳالهه کي يقيني بڻائڻو آهي ته `T` جي هڪ خاص قيمت صرف هڪ ڀيرو droppedري وئي آهي.
    ///
    /// اهو فنڪشن غير محفوظ آهي ڇاڪاڻ ته غلط استعمال ميموري غير محفوظ ٿي سگھي ٿو ، ايستائين جيڪڏهن واپس ڪيل `Rc<T>` کي ڪڏهن به رسائي نه ڏني وئي آهي.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // لڪي کي روڪڻ لاءِ `Rc` ڏانهن واپس تبديل ڪريو.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` ڏانهن وڌيڪ ڪال ياداشت غير محفوظ هوندي
    /// }
    ///
    /// // ياداشت کي آزاد ڪيو ويو جڏهن `x` مٿي ڏنل حد کان ٻاهر ٿي ويو ، تنهن ڪري `x_ptr` هاڻي نچائي رهي آهي!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // اصل آر سي بوڪس ڳولڻ لاءِ آفسيٽ ريورس ڪريو.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// هن مختص ڪرڻ ۾ هڪ نئون [`Weak`] پوائنٽر ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // پڪ ڪريو ته اسان هڪ ڊنگنگو ڪمزور نه بڻايون ٿا
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// انهي مختص ڪرڻ لاءِ [`Weak`] پوائنٽرن جو تعداد حاصل ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// انهي مختص ڪرڻ ۾ مضبوط (`Rc`) پوائنٽرن جو تعداد حاصل ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// `true` کي واپسي ڏئي ٿو جيڪڏهن ٻيا `Rc` يا [`Weak`] ٽائونڊر هن مختص نه آهن.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// ڏنل `Rc` ۾ هڪ متغير حوالو ڏئي ٿو ، جيڪڏهن ٻئي `Rc` يا [`Weak`] ٻئي ساڳيا مختص ڪرڻ وارا نه آهن.
    ///
    ///
    /// [`None`] ٻي صورت ڏي ٿو ، ڇاڪاڻ ته اھو ھڪڙي مشترڪ قدر کي مٽائڻ لاءِ محفوظ ناھي.
    ///
    /// [`make_mut`][make_mut] پڻ ڏسو ، جيڪو [`clone`][clone] اندروني قدر ڪندو جڏهن ٻيا اشارو ڪندڙ آهن.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// ڏنل چيڪ `Rc` ۾ ھڪ قابل تبديل ريفرنس واپس ڏئي ٿو ، بغير ڪنھن چڪاس جي.
    ///
    /// [`get_mut`] پڻ ڏسندا ، جيڪو محفوظ آهي ۽ مناسب چيڪ ڪندو آهي.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// ڪنهن ٻئي `Rc` يا [`Weak`] ساڳين مختصرن ڏانهن اشارو موٽائي قرض جي مدت لاءِ ان کي رد نه ڪيو وڃي.
    ///
    /// اهو عام طور تي ڪيس آهي جيڪڏهن اهڙا اشارو نه موجود آهن ، مثال طور فوري طور تي `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // اسان محتاط آهيون *نه* حوالو ٺاهي "count" فيلڊ کي ، جئين ته اهو حوالن جي ڳڻپين تائين رسائي سان متضاد هجي (مثال طور
        // `Weak` کان).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// ايڪس آرڪس کي واپسي ڏئي ٿو جيڪڏهن ٻن "آر سيز" ساڳين مختصرن ڏانهن اشارو ڪيو آهي (هڪ رگ ۾ [`ptr::eq`] وانگر آهي)
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// ڏنل `Rc` ۾ هڪ قابل تبديلي حوالو ڏئي ٿو.
    ///
    /// جيڪڏهن ٻئي `Rc` ساڳيا مختص ڪيل نقطا آهن ، ته پوءِ `make_mut` [`clone`] نئين وراثت ۾ اندروني قدر کي يقيني بڻائڻ لاءِ منفرد ملڪيت حاصل ڪندو.
    /// انهي کي ڪلون آن لکڻ جو پڻ حوالو ڏنو ويندو آهي.
    ///
    /// جيڪڏهن ٻئي هنڌن ۾ `Rc` پوائنٽر موجود نه آهن ، ته هن مختص ڪرڻ لاءِ [`Weak`] پوائنٽر ڌار ڪيا ويندا.
    ///
    /// [`get_mut`] کي به ڏسندا ، جيڪو ڪلون ڪرڻ بدران ناڪام ٿي ويندا.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // ڪجھ به کلون نه ٿيندس
    /// let mut other_data = Rc::clone(&data);    // اندروني ڊيٽا کلون نه ٿيندو
    /// *Rc::make_mut(&mut data) += 1;        // کلون اندروني ڊيٽا کي
    /// *Rc::make_mut(&mut data) += 1;        // ڪجھ به کلون نه ٿيندس
    /// *Rc::make_mut(&mut other_data) *= 2;  // ڪجھ به کلون نه ٿيندس
    ///
    /// // هاڻي `data` ۽ `other_data` مختلف مختصن ڏانهن اشارو ڪن ٿا.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] اشارو الڳ ڪيو ويندو:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // ڊيٽا کي کلون ٿا ، ٻيا آر سي آهن.
            // اڳ-مختص ٿيل ياداشت کي ڪلون ويل جي قيمت سڌي طرح لکڻ جي اجازت ڏي.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // صرف ڊيٽا چوري ڪري سگهندو آهي ، اهو سڀ ڪجهه ڇڏي ويو وڪي ٿو
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // بي مثال مضبوط ڪمزور ريفريش کي هٽائي ڇڏيو (هتي جعلي ڪمزور بڻائڻ جي ضرورت ناهي-اسان knowاڻون ٿا ته ٻيون ڪمزوريون اسان لاءِ صاف ڪري سگهن ٿيون)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // هي غير محفوظ آهي ٺيڪ آهي ڇاڪاڻ ته اسان جي ضمانت آهي ته واپس ڪيل نشان *صرف* پوائنٽر آهي جيڪو ڪڏهن به ٽي کي واپس ڪيو ويندو.
        // اسان جو حوالو نمبر 1 تائين ان جي گارنٽي هجڻ جي گارنٽي آهي ، ۽ اسان کي `Rc<T>` پاڻ `mut` گهرائڻ جي ضرورت آهي ، تنهنڪري اسان مختص ڪرڻ جو واحد ممڪن حوالو ڏئي رهيا آهيون.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` کي ڪنڪريٽ قسم مان ختم ڪرڻ جي ڪوشش ڪئي وئي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// ھڪڙي `RcBox<T>` کي ڪافي جڳھ سان ممڪن جڳھ جي غير معين ٿيل قيمت جي لاءِ مختص ڪري ٿو جتي ويليو کي ترتيب ڏنل آھي.
    ///
    /// فنڪشن `mem_to_rcbox` ڊيٽا پوائنٽر سان سڏيو ويندو آهي ۽ `RcBox<T>` لاءِ (ممڪن طور تي ٿڌي) پوينٽر واپس موٽڻ لازمي آهي.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // حساب سان حساب لڳايو حساب سان ڏنل ڏنل ترتيب استعمال ڪندي.
        // اڳيئي ، ترتيب `&*(ptr as* const RcBox<T>)` ايڪسپريس تي ڳڻيو ويو ، پر هن غلط ترتيب ڏنل ريفرنس تيار ڪيو (#54908 ڏسو).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// ھڪڙي ايڪس 100 ايڪس ھڪڙي ممڪن جڳھ لاءِ مناسب جڳھ سان مختص ڪري ٿو جتي ويليو کي ترتيب ڏنل آھي ، ھڪ خرابي واپس آڻيندي جيڪڏھن مختص ناڪامياب ٿئي۔
    ///
    ///
    /// فنڪشن `mem_to_rcbox` ڊيٽا پوائنٽر سان سڏيو ويندو آهي ۽ `RcBox<T>` لاءِ (ممڪن طور تي ٿڌي) پوينٽر واپس موٽڻ لازمي آهي.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // حساب سان حساب لڳايو حساب سان ڏنل ڏنل ترتيب استعمال ڪندي.
        // اڳيئي ، ترتيب `&*(ptr as* const RcBox<T>)` ايڪسپريس تي ڳڻيو ويو ، پر هن غلط ترتيب ڏنل ريفرنس تيار ڪيو (#54908 ڏسو).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // لي آئوٽ لاءِ مختص ڪريو.
        let ptr = allocate(layout)?;

        // آر سي بوڪس شروع ڪريو
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// ھڪڙي `RcBox<T>` ھڪڙي جڳھ واري وسعت جي لاءِ مناسب جڳھ کي مختص ڪري ٿو
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // ڏنل قيمت استعمال ڪندي `RcBox<T>` لاءِ مختص ڪريو.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // بائيٽ وانگر قدر نقل ڪريو
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // ان جي مواد کي ڇڏي ڏيڻ کانسواءِ مختص خالي ڪيو
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// ڏنل ايڪسائيٽ سان هڪ `RcBox<[T]>` مختص ڪري ٿو.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// سلائس کان عنصرن نقل ڪيو نئين مختص ٿيل آر سي <\[T\]>
    ///
    /// غير محفوظ آهي ڇاڪاڻ ته ڪال ڪندڙ کي لازمي طور تي ملڪيت رکڻ گهرجي يا `T: Copy` کي پابند ڪرڻ گهرجي
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// ايٽرٽر کان `Rc<[T]>` ٺاهي ٿو ھڪڙي خاص سائز جي ڪري سڃاتو وڃي ٿو.
    ///
    /// رويي غلط بيان ڪيو وڃي سائيز کي غلط ٿيڻ گھرجي.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic گارڊ ٽي عناصر تي کلون ڪندي.
        // panic جي صورت ۾ ، اهي عناصر جيڪي نئين آر سي بوڪس ۾ لکيا ويا هوندا ، ڇڏيو ويندو ، پوءِ يادگيري آزاد ٿي وئي.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // پهرين عنصر ڏانهن اشارو ڪندڙ
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // سڀ صاف.محافظ کي وساريو ڇڏجي ته اهو نئون RcBox آزاد نٿو ٿئي.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` لاءِ استعمال ٿيل خصوصيزيشن trait.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` کي ڊراپس ٿو.
    ///
    /// اھو مضبوط ريفرنس ڳڻپ کي ختم ڪندو.
    /// جيڪڏهن مضبوط ريفرنس ڳڻپ صفر تائين پهچي ٿي ته صرف واحد حوالو (جيڪڏهن ڪو به) [`Weak`] آهي ته پوءِ اسان `drop` اندرئين قيمت.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // ڇا نه ڇا ڇپجي؟
    /// drop(foo2);   // "dropped!" پرنٽ ڪري ٿو
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // موجود شيون کي تباهه ڪريو
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // بيحد "strong weak" پوائنٽر ھٽائي ڇڏيو ھاڻي اسان مواد ختم ڪري ڇڏيو.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` پوائنٽر جي ڪلون ٺاهيندو آهي.
    ///
    /// اهو هڪ ٻئي پوائنٽ کي ساڳيو مختص ڪري ٿو ، مضبوط حوالو ڳڻپ کي وڌائيندي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// نئون `Rc<T>` ٺاهي ٿو ، `Default` قدر لاءِ `T` لاءِ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// ايڪس `Eq` کي خاص ڪرڻ جي اجازت ڏيڻ هيڪ ڪريو جيتوڻيڪ `Eq` وٽ هڪ طريقو آهي.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// اسان اهو خاصيت هتي ڪري رهيا آهيون ، ۽ نه `&T` تي وڌيڪ عام واڌاري جي طور تي ، ڇو ته ٻي صورت ۾ اهو سڀني مساوات جي چيڪ تي ريففش تي قيمت شامل ڪندو.
/// اسان اهو سمجهيو آهي ته "آر سيز" وڏي قدرن کي ذخيرو ڪرڻ لاءِ استعمال ڪيا ويندا آهن ، جيڪي کلون کان سست هوندا آهن ، پر مساوات جي جاچ لاءِ پڻ وڏي هوندا آهن ، انهي جي قيمت ادا ڪرڻ سان وڌيڪ آساني سان ٿيندي
///
/// اهو پڻ ممڪن آهي ته ٻه `Rc` ڪلونون ، ساڳيا قدر ڏانهن اشارو ڪن ، ٻن ۽ ٽي جي ڀيٽ ۾.
///
/// اسان اهو صرف انهي وقت ڪري سگهون ٿا جڏهن `T: Eq` هڪ `PartialEq` طور تي شايد اڻ fاڻين طور تي.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// ٻن "آر سي" جي هڪجهڙائي.
    ///
    /// ٻه `آر سي برابر آهن جيڪڏهن انهن جي اندروني قدر برابر آهن ، جيتوڻيڪ اهي مختلف مختص ۾ محفوظ ٿيل آهن.
    ///
    /// جيڪڏهن `T` `Eq` پڻ لاڳو ڪري ٿو (مساوات جي موافقت جو اظهار) ، ٻه "آر سي" جيڪي هڪ ئي مختص ڪرڻ ڏانهن اشارو ڪن ٿا هميشه برابر آهن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// ٻن "آر سي" لاء عدم مساوات.
    ///
    /// ٻه `آر سي` اڻ برابري وارا آهن جيڪڏهن انهن جي اندروني قدرون نه برابر هونديون آهن.
    ///
    /// جيڪڏهن `T` پڻ `Eq` لاڳو ڪري ٿو (مساوات جي موافقت وارو جواب ڏيڻ) ، ٻه "آر سي" جيڪي هڪ ئي ايبليوشن ڏانهن اشارو ڪن ٿا اهي ڪڏهن به هڪجهڙا نه هوندا آهن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// ٻن "آر سيز" جو جزوي مقابلو.
    ///
    /// انهن ٻنهي جي اندروني قدرن تي `partial_cmp()` سڏ ڪندي مقابلو ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// ٻه "آر سيز" جي مقابلي ۾ گهٽ.
    ///
    /// انهن ٻنهي جي اندروني قدرن تي `<` سڏ ڪندي مقابلو ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'آر سي ايس' جي مقابلي ۾ 'مقابلي کان گهٽ يا برابر.
    ///
    /// انهن ٻنهي جي اندروني قدرن تي `<=` سڏ ڪندي مقابلو ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// ٻن "آر سيز" جي مقابلي کان وڌيڪ وڏو.
    ///
    /// انهن ٻنهي جي اندروني قدرن تي `>` سڏ ڪندي مقابلو ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'آر سي کان وڌيڪ' جي نسبت کان وڏو يا برابر.
    ///
    /// انهن ٻنهي جي اندروني قدرن تي `>=` سڏ ڪندي مقابلو ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// ٻن "آر سي" جي مقابلي ۾.
    ///
    /// انهن ٻنهي جي اندروني قدرن تي `cmp()` سڏ ڪندي مقابلو ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// هڪ حوالي ٿيل ڳڻپ ٿيل سلائس مختص ڪريو ۽ ان کي ڪل ڪريو `v` جون شيون کلڻ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// هڪ حوالي واري ڳڻتي واري اسٽرنگ سلائس کي مختص ڪريو ۽ ان ۾ `v` کي ڪاپي ڪريو.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// هڪ حوالي واري ڳڻتي واري اسٽرنگ سلائس کي مختص ڪريو ۽ ان ۾ `v` کي ڪاپي ڪريو.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// باڪس ٿيل شئي کي نئين ، ريفرنس ڳڻتي ، الاٽمينٽ تي منتقل ڪريو.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// هڪ حوالي ڪيل ڳڻتي سلائس مختص ڪريو ۽ ان ۾ "وي" جون شيون منتقل ڪريو.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // وييڪ کي ان جي يادگيري کي آزاد ڪرڻ جي اجازت ڏيو ، پر ان جي مواد کي تباهه نه ڪريو
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator` ۾ هر عنصر گڏ ڪري ٿو ۽ ان کي `Rc<[T]>` ۾ گڏ ڪري ٿو.
    ///
    /// # ڪارڪردگي جون خاصيتون
    ///
    /// ## عام ڪيس
    ///
    /// عام حالتن ۾ ، `Rc<[T]>` ۾ گڏ ڪرڻ پهرين `Vec<T>` ۾ گڏ ڪرڻ سان ڪيو ويندو آهي.اھو آھي ، جڏھن ھيٺين لکڻ کي:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// اھو رويي ڪري ٿو weڻ اسان لکيو آھي:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // مختص ڪرڻ جو پهريون سيٽ هتي اچي ٿو.
    ///     .into(); // `Rc<[T]>` لاء هڪ ٻيو مختص هتي ٿيندو آهي.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// اهو `Vec<T>` تعمير ڪرڻ جي لاءِ جيترو وقت گهربل هجي مختص ڪندو ۽ پوءِ اهو `Vec<T>` کي `Rc<[T]>` ۾ بدلائڻ لاءِ هڪ ڀيرو مختص ڪندو.
    ///
    ///
    /// ## lengthاتل سڃاتل ڊيگهه
    ///
    /// جڏهن توهان جو `Iterator` `TrustedLen` لاڳو ڪندو ۽ صحيح سائيز جو آهي ، `Rc<[T]>` لاءِ هڪ واحد مختص ڪيو ويندو.مثال طور:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // صرف هڪ واحد مختص هتي ٿئي ٿو.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// `Rc<[T]>` ۾ گڏ ڪرڻ لاءِ اسپيشلائيزيشن trait استعمال ڪيو.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // اهو `TrustedLen` ايٽررٽر جي صورت آهي.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // حفاظت: اسان کي انهي ڳالهه کي يقيني بڻائڻ جي ضرورت آهي ته آئيرٽر جي صحيح ڊيگهه آهي ۽ اسان وٽ آهي.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // عام عمل درآمد ڏانھن واپس وڃو.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` [`Rc`] جو هڪ نسخو آهي جيڪو منظم ڪيل مختص جي غير مالڪ جو حوالو رکي ٿو.مختص ڪيل آهي [`upgrade`] کي `Weak` پوائنٽر تي ڪال ڪندي ، جيڪو هڪ ["اختيار"] "<" ["Rc"] موٽائي ٿو.<T>> ".
///
/// جئين `Weak` حوالو ملڪيت جي لحاظ کان نه ڳڻيندو آهي ، اهو مختص ٿيل قيمت کي گهٽائڻ کان روڪي نه سگهندو ، ۽ `Weak` پاڻ اڃا تائين موجود قدر جي باري ۾ ڪا به ضمانت نه ٿو ڏئي.
/// ان ڪري اهو شايد [`None`] موٽائي سگھي ٿو جڏهن [`اپ گريڊ`] ڊي.
/// جيتوڻيڪ نوٽ ڪريو ته `Weak` ريفرنس * ختم ڪرڻ کان پاڻ کي بچائي ٿو (پسمانده اسٽور) کي ختم نه ٿيڻ ڏنو وڃي.
///
/// هڪ `Weak` پوائنٽر [`Rc`] پاران مختص ڪيل عارضي جي حوالي سان عارضي حوالو رکڻ لاءِ ڪارائتو آهي ان جي اندروني قيمت وڃائڻ کان بغير.
/// اهو [`Rc`] پوائنٽرن جي وچ ۾ گردڪ حوالن کي روڪڻ لاءِ پڻ استعمال ڪيو ويو آهي ، ڇاڪاڻ ته باقائدگي سان حوالا ڏيڻ وارا ڪڏهن به [`Rc`] ڇڏڻ جي اجازت نٿا ڏين.
/// مثال طور ، هڪ وڻ مضبوط [`Rc`] پوائنٽرن کي والدين نوڊس کان ٻارن ڏانهن ، ۽ `Weak` اشارو ٻارن کان انهن جي والدين ڏانهن موٽي سگهي ٿو.
///
/// `Weak` پوائنٽر حاصل ڪرڻ جو عام طريقو [`Rc::downgrade`] کي سڏ ڪرڻ آهي.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // اھو ھڪڙو `NonNull` آھي ان قسم جي سائيز کي سڌارڻ جي اجازت ڏيڻ جي اجازت ڏي ، پر اھو لازمي طور تي صحيح پوائنٽر نه آھي.
    //
    // `Weak::new` انهي کي `usize::MAX` تي سيٽ ڪريو ته انهي کي هيڪ تي جڳهه مختص ڪرڻ جي ضرورت نه آهي.
    // اهو هڪ قيمت ناهي حقيقي رئيلٽر ڪڏهن به هوندو ، ڇاڪاڻ ته آر سي بوڪس وٽ گهٽ ۾ گهٽ 2 جي ترتيب آهي.
    // اهو صرف تڏهن ممڪن آهي جڏهن `T: Sized`؛اڻ سڌريل `T` ڪڏهن به جڙي نه سگهندو.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// نئين يادداشت کي مختص ڪرڻ کان بغير نئون `Weak<T>` ٺاهي ٿو.
    /// واپسي جي قيمت تي [`upgrade`] کي ڪال ڪري هميشه [`None`] ڏئي ٿي.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// ڊيٽا جي فيلڊ بابت ڪا به makingاڻ ڏيڻ کان بغير حوالن جي ڳڻپ تائين رسائي جي اجازت ڏيڻ ۾ مددگار قسم.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// انهي کي `Weak<T>` ڏانهن اشارو ڪيو ويو x01X ڏانهن خام پوائنٽر واپس ڏئي ٿو.
    ///
    /// پوائنٽر صرف انهي صورت ۾ صحيح آهي جڏهن ڪجهه مضبوط حوالا آهن.
    /// پوائنٽر ڊنگنگ ، غير قطار يا ايستائين [`null`] ٻي صورت ۾ ٿي سگھي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // ٻئي ساڳئي اعتراض ڏانهن اشارو ڪن ٿا
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // مضبوط هتي ئي ان کي زنده رکندو آهي ، تنهن ڪري اسان اعتراض تائين اڃا تائين رسائي ڪري سگهون ٿا.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // پر وڌيڪ نه.
    /// // اسان weak.as_ptr() ڪري سگھو ٿا ، پر پوائنٽر تائين پھچندي اڻ inedاتل رويي جي طرف ايندي.
    /// // assert_eq! ("هيلو" ، غير محفوظ {&*weak.as_ptr() }) ؛
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // جيڪڏھن اشارو ڪري رھيو آھي ، اسان رئيس کي سڌو سنئون موٽون ٿا.
            // اهو هڪ صحيح پيلو لوڊ پتي نه ٿو ٿي سگهي ، جئين پيڪ لوڊ گهٽ ۾ گهٽ آر سي بوڪس ايڪسڪسيمڪس جي مطابق مطابق هوندو آهي.
            ptr as *const T
        } else {
            // حفاظتي: جيڪڏهن آهي_ڏڻ غلط returnsري ٿو ، ته پوائنٽر قابل قابل آهي.
            // پائو لوڊ هن نقطي ۾ گهٽجي سگهي ٿو ، ۽ اسان کي ثابتگي قائم رکڻي آهي ، انهي ڪري خام پوائنٽر جي چرپر جو استعمال ڪريو.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` کي کائيندو آھي ۽ ان کي خام پوائنٽر ۾ تبديل ڪري ٿو.
    ///
    /// اهو ڪمزور پوائنٽر کي خام پوائنٽر ۾ تبديل ڪري ٿو ، جڏهن ته اڃا تائين هڪڙي ڪمزور حوالي جي ملڪيت کي محفوظ ڪري ٿو (ڪمزور ڳڻتي هن آپريشن ذريعي تبديل ٿيل نه آهي).
    /// ان کي `Weak<T>` سان `Weak<T>` ۾ واپس ڪري سگهجي ٿو.
    ///
    /// پوائنٽر جي ھدف تائين پھچڻ تي جيتري پابنديون آھن [`as_ptr`] سان لاڳو ٿين ٿيون.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// اڳ ۾ ئي [`into_raw`] ٺاهيل هڪ خام پوائنٽر کي `Weak<T>` ۾ بدلائي ٿو.
    ///
    /// اهو محفوظ طور تي مضبوط حوالو حاصل ڪرڻ لاءِ ([`upgrade`] سڏڻ بعد) استعمال ڪري سگهجي ٿو يا `Weak<T>` کي byٽو ڪندي ضعيف ڳڻپ کي ختم ڪرڻ لاءِ.
    ///
    /// اهو هڪ ڪمزور ريفرنس جي ملڪيت وٺندو آهي ([`new`] ٺاهيل پوائنٽرن جي استثنا سان ، جيئن ته اهي ڪجهه به نٿا رکن ؛ اهو طريقو اڃا تائين انهن تي ڪم ڪري ٿو).
    ///
    /// # Safety
    ///
    /// پوائنٽر [`into_raw`] کان وٺي پيدا ٿيڻ گھرجي ۽ اڃا تائين ان جي امڪاني ڪمزور ريفريش جو ضرور هجڻ گھرجي.
    ///
    /// انهي جي ڪال ڪرڻ وقت مضبوط ڳڻپ جي 0 هجڻ جي اجازت آهي.
    /// بهرحال ، هي هڪ ڪمزور ريفرنس جي ملڪيت هن وقت خام پوائنٽر جي نمائندگي ڪري ٿو (ضعيف شمار هن آپريشن سان تبديل ٿيل نه آهي) ۽ تنهن ڪري ان کي [`into_raw`] ڏانهن هڪ پوئين ڪال سان ضرور جوڙيو وڃي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // آخري ڪمزور ڳڻتي کي ختم ڪرڻ.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ايڪس پي ايڪس ڏسو تناظر لاءِ ته ڪيئن انپٽ پوائنٽر نڪتل آهي.

        let ptr = if is_dangling(ptr as *mut T) {
            // ھي ھڪڙو ٻرندڙ ڪمزور آھي.
            ptr as *mut RcBox<T>
        } else {
            // ٻي صورت ۾ ، اسان پڪ ڪيون ٿا پوائنٽر نانگنگيل ڪمزور کان آيو آهي.
            // SAFETY: ڊيٽا_ آف سيٽ ڪال ڪرڻ لاءِ محفوظ آهي ، جيئن پيٽر اصل جو حوالو ڏيندو آهي (ممڪن طور تي ڪٽيل) ٽي.
            let offset = unsafe { data_offset(ptr) };
            // ان ڪري ، اسان کي مڪمل آر سي بوڪس حاصل ڪرڻ لاءِ آفسيٽ رد ڪريو ٿا.
            // حفاظت: پوائنٽر ڪمزور طور تي پيدا ٿيو آهي ، تنهنڪري هي آف سيٽ محفوظ آهي.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // حفاظت: اسان هاڻ اصل ڪمزور پوائنٽر کي بحال ڪيو آهي ، تنهنڪري ڪمزور پيدا ڪري سگهون ٿا.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` پوائنٽر کي [`Rc`] کي اپ گريڊ ڪرڻ جي ڪوشش ، اندرون ويل قيمت وڃائڻ ۾ دير ٿيڻ جي صورت ۾.
    ///
    ///
    /// [`None`] جي واپسي ڏي ٿو جيڪڏھن اندرين قدر کان وٺي وئي ھجي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // تمام مضبوط اشارو ڏيندڙ کي تباهه ڪيو.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// انهي مختص ڪرڻ ڏانهن اشارو ڪندڙ مضبوط (`Rc`) پوائنٽرن جو تعداد حاصل ڪري ٿو.
    ///
    /// جيڪڏهن `self` استعمال ڪيو ويو [`Weak::new`] ، اهو 0 واپس ڪندو.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// انهي مختص ڏانهن اشارو ڪندي `Weak` پوائنٽرن جو تعداد حاصل ڪري ٿو.
    ///
    /// جيڪڏهن ڪو مضبوط اشارو ڏيندڙ ناهي رهي ، اهو صفر موٽندو.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // اڻ weakاتل ڪمزور پي ايٽ کي گھٽايو
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// واپسي ڏئي `None` جڏهن پوائنٽر کي ڌڪڻ لڳي ٿو ۽ مختص ناهي `RcBox` ، (يعني ، جڏهن هي `Weak` ٺاهي ويو `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // اسان محتاط آهيون *نه*"data" فيلڊ کي coveringڪڻ واري ريفرنس ٺاهڻ جي طور تي ، جئين فيلڊ کي گڏيل طور تي مٽايو وڃي (مثال طور ، جيڪڏهن آخري `Rc` کٽي ويندو ، ڊيٽا فيلڊ کي جڳهه ۾ ڇڏي ويندو).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `true` جي واپسي ڏي ٿو جيڪڏهن ٻن "ڪمزور" ساڳئي ايليگيشن ڏانهن اشارو ڪريو (جهڙوڪ [`ptr::eq`] وانگر) ، يا جيڪڏهن ٻئي ڪنهن مختص ڏانهن اشارو نه ٿا ڪن (ڇاڪاڻ ته اهي `Weak::new()`) سان ٺاهي رهيا آهن)
    ///
    ///
    /// # Notes
    ///
    /// جيئن ته هن پوائنٽرن جو مقابلو ڪيو ته ان جو مطلب اهو آهي ته `Weak::new()` هڪ ٻئي جي برابر ڪندو ، جيتوڻيڪ اهي ڪنهن به مختص جي نشاندهي نه ڪندا آهن.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` جي ڀيٽ ۾.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` پوائنٽر کي ٽو ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ڇا نه ڇا ڇپجي؟
    /// drop(foo);        // "dropped!" پرنٽ ڪري ٿو
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // ڪمزور ڳڻپ 1 کان شروع ٿئي ٿي ، ۽ صرف صفر ڏانهن وڃي ٿي جيڪڏهن تمام سخت اشارو ڪندڙ غائب ٿي ويا هجن.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` پوائنٽر جو کلون ٺاھيندو آھي جيڪي ھڪٻئي جي مختص ڪيل نقطي ڏانھن اشارو ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// هڪ نئون `Weak<T>` ٺاهي ٿو ، `T` جي يادگيري مختص ڪرڻ بغير ان کي شروع ڪرڻ جي.
    /// واپسي جي قيمت تي [`upgrade`] کي ڪال ڪري هميشه [`None`] ڏئي ٿي.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: اسان mem::forget کي محفوظ طور ڊيل ڪرڻ لاءِ هتي چيڪ ڪيو.خاص طور تي
// جيڪڏهن توهان mem::forget آر سي ايس (يا واڪ) ، ريفري ڳڻپ گهڻو ڪري سگهي ٿي ، ۽ پوءِ توهان مختص ڪيل آزادين کي آزاد ڪري سگهو ٿا جڏهن ته موجود آر سي سي (يا ڪمزوريون) موجود آهن.
//
// اسان ختم ڪيو ڇو ته هي هڪ مايوس ڪندڙ منظر آهي جنهن جي اسان پرواهه نٿا ڪريون ته ڇا ٿئي ٿو-ڪوبه اصل پروگرام ڪڏهن به هن کي تجربو نه ڪرڻ گهرجي.
//
// اهو غفلت وارو مٿي هئڻ گهرجي ڇاڪاڻ ته توهان اصل ۾ ملڪيت جي منتقلي ۽ حرڪت جي مهرباني Rust ۾ گهڻو ڪجهه ڪرڻ جي ضرورت ناهي.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // اسان قدر ختم ڪرڻ بدران اوور فلو تي خاتمو ڪرڻ چاهيندا آهيون.
        // انهي جو حوالو ڪڏهن به صفر نه ڪيو ويندو جڏهن هن کي سڏيو ويندو آهي؛
        // پر ان جي باوجود ، اسان ٻي صورت ۾ ھليو ويو ھڪڙو ايل ايل وي ايم کي اشارو ڏيڻ لاءِ ٻي صورت ۾ ياد ٿيل اصلاح جي۔
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // اسان قدر ختم ڪرڻ بدران اوور فلو تي خاتمو ڪرڻ چاهيندا آهيون.
        // انهي جو حوالو ڪڏهن به صفر نه ڪيو ويندو جڏهن هن کي سڏيو ويندو آهي؛
        // پر ان جي باوجود ، اسان ٻي صورت ۾ ھليو ويو ھڪڙو ايل ايل وي ايم کي اشارو ڏيڻ لاءِ ٻي صورت ۾ ياد ٿيل اصلاح جي۔
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// ھڪڙي پوائنٽر جي پويان پائي لوڊ ڪرڻ لاء `RcBox` اندر آفسيٽ حاصل ڪريو.
///
/// # Safety
///
/// پوائنٽر کي T جي اڳئين صحيح مثال جي لاءِ (۽ صحيح ميٽا ڊيٽا) ڏانهن اشارو ڪرڻ گهرجي ، پر T کي ڇڏڻ جي اجازت آهي.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // آر سي بوڪس جي آخر تائين غير ترتيب واري قيمت يرايو.
    // ڇاڪاڻ ته آر سي بوڪس ايڪس آرڪس آهي ، اهو ياد ۾ هميشه آخري فيلڊ هوندو.
    // حفاظت: ڇاڪاڻ ته صرف ممڪن طور تي اڻ typesاتل قسم سلائسون ، trait شيون ،
    // ۽ ٻاهرين قسمن ، انٽ حفاظت جي ضرورت موجوده وقت لاءِ ڪافي آهيهن ٻولي جي عمل درآمد جي تفصيل آهي جيڪا std کان ٻاهر انحصار نه ڪئي وڃي.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}