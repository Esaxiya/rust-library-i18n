//! # Rust ڪور مختص ۽ مجموعن جي لائبريري
//!
//! اها لائبريري سمارٽ پوائنٽرن ۽ مجموعن کي ڊاهيندڙ الاٽ ڪيل قدرن جي انتظام لاءِ مهيا ڪندي آهي.
//!
//! هي لائبريري ، لائبرير وانگر ، عام طور تي سڌو سنئون استعمال ٿيڻ جي ضرورت ناهي ڇاڪاڻ ته ان جا مواد [`std` crate](../std/index.html) ۾ ٻيهر برآمد ڪيا ويا آهن.
//! Crates جيڪي `#![no_std]` وصف استعمال ڪن ٿا پر عام طور تي `std` تي ڀاڙين نه ٿا ، تنھنڪري اھي بدران crate استعمال ڪندا.
//!
//! ## دٻيل قدر
//!
//! ايڪس01ڪس قسم هڪ بهترين پوائنٽر قسم آهي.ھڪڙو ئي ھڪڙو [`Box`] ھڪڙي مالڪ ٿي سگھي ٿو ، ۽ مالڪ اھو مواد تبديل ڪرڻ جو فيصلو ڪري سگھي ٿو ، جيڪي ھجوم تي رھي آھن.
//!
//! اهو قسم بهتر طريقي سان موضوعن جي وچ ۾ موڪلي سگهجي ٿو ڇاڪاڻ ته ايڪس ايڪس ايڪس ويل ويل جي ماپ جيترو پوائنٽر جيترو ئي هوندو آهي.
//! وڻن وانگر ڊيٽا جا نمونا اڪثر ڪري خانن سان ٺاهيا ويندا آهن ڇاڪاڻ ته هر نوڊ ۾ اڪثر هڪ ئي مالڪ هوندو آهي ، جيڪو والدين.
//!
//! ## حوالو ڳڻپيندڙ اشارو
//!
//! [`Rc`] قسم ھڪڙي غير-سلسسيف جي حوالي سان ڳڻيندڙ پوائنٽر جو قسم آھي جيڪو ھڪڙي سلسلي ۾ ميموري کي حصيداري ڪرڻ لاءِ آھي.
//! هڪ [`Rc`] پوائنٽر هڪ قسم ، `T` لفاف ڪري ٿو ، ۽ صرف هڪ حصيداري ڪيل حوالو ، `&T` تائين رسائي جي اجازت ڏئي ٿو.
//!
//! اها قسم مفيد آهي جڏهن وراثت واري متانت (جهڙوڪ [`Box`] استعمال ڪرڻ) ايپليڪيشن لاءِ تمام سخت هوندي آهي ، ۽ اڪثر ڪري ميوٽيشن جي اجازت ڏيڻ جي لاءِ [`Cell`] يا [`RefCell`] قسمن سان جوڙي ويندي آهي.
//!
//!
//! ## ايٽمي طور تي حوالو ڏنل اشارو ڪندڙن سان
//!
//! [`Arc`] قسم [`Rc`] قسم جي برابر آھي محفوظ آھي.اهو [`Rc`] جي سڀني ساڳين ڪارڪردگي فراهم ڪري ٿو ، ان کان سواء ضرورت آهي ته `T` موجود قسم وارو شيئر هوندو.
//! ان کان علاوه ، [`Arc<T>`][`Arc`] پاڻ ۾ موڪليل آهي جڏهن ته [`Rc<T>`][`Rc`] ناهي.
//!
//! اهو قسم شامل ڪيل ڊيٽا جي حصيداري جي رسائي جي اجازت ڏئي ٿو ، ۽ اڪثر وقتن سان هم وقت سازي جي چئلينج سان گڏ هوندو آهي جهڙوڪ گونگي ذريعن جي گڏيل ذريعن جي ميوٽيشن کي اجازت ڏيڻ لاءِ.
//!
//! ## Collections
//!
//! عام لائبريري جي ڊيٽا جي اڏاوتن بابت عمل درآمد هن لائبريري ۾ وضاحت ڪئي ويندي آهي.اهي [standard collections library](../std/collections/index.html) ذريعي ٻيهر برآمد ڪيا ويا آهن.
//!
//! ## هاش انٽرفيس
//!
//! [`alloc`](alloc/index.html) ماڊل ڊفالٽ عالمي مختص ڪندڙ کي گھٽ-سطح انٽرفيس کي بيان ڪري ٿو.اهو لبرڪ مختص ڪندڙ اي پي آئي سان مطابقت ناهي.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// تخنيقي طور تي ، هي رسٽڊوڊ ۾ هڪ بگ آهي: رسٽڊوڪ `#[lang = slice_alloc]` بلاڪ تي دستاويز ڏسي ٿو `&[T]` لاءِ ، جنهن وٽ `core` ۾ به هن فيچر کي استعمال ڪري دستاويزي دستاويز آهي ، ۽ چريو ٿيو ته فيچر گيٽ فعال ناهي.
// مثالي طور ، اهو ٻين crates مان دستاويزن جي فيچر گيٽ جي چڪاس نه ڪندو ، پر جيئن ته اهو صرف لانگ آئٽم لاءِ ظاهر ٿي سگهي ٿو ، انهي کي درست ڪرڻ لڳي نٿو.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// ھن لائبريري کي جانچڻ جي اجازت ڏيو

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// ماڊل ٻين ماڊلز پاران استعمال ٿيل اندروني ميڪروز سان (ٻين ماڊلز کان پهريان شامل ٿيڻ جي ضرورت آهي).
#[macro_use]
mod macros;

// هيٺين سطح جي مختص ڪيل حڪمت عملين لاءِ مهيا ڪيل ذخيرا

pub mod alloc;

// مٿين قسمن کي استعمال ڪري هيٺ مٿي جا هاڪ

// حالت cfg ۾ عمارت ٺاهڻ دوران لين شين کي نقل مان بچائڻ لاءِ `boxed.rs` کان موڊ کي مشروط طور تي وضاحت ڪرڻ جي ضرورت آهي.پر ڪوڊ کي `use boxed::Box;` بيان ڏيڻ جي اجازت ڏيڻ جي پڻ ضرورت آهي.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}