//! يو يو ايف 8 ـ انڪوڊ ٿيل ، وڌندڙ ۽ بندو آهي.
//!
//! ھن ماڊل ۾ [`String`] قسم ، [`ToString`] trait شامل آھن جنھن کي اسٽرنگس ۾ تبديل ڪرڻ لاءِ ، ۽ ڪيترائي غلط قسمَ جيڪي [`اسٽرنگ`] سان ڪم ڪرڻ جي نتيجي ۾ ٿي سگھي ٿي.
//!
//!
//! # Examples
//!
//! ھڪڙي اسٽرنگ لفظي کان نئون [`String`] ٺاھڻ جا ڪيترائي طريقا آھن:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! توهان سان گڏ ٺاهه سان هاڻ هڪ نئين کان [`String`] ٺاهي سگهو ٿا
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! جيڪڏهن توهان وٽ صحيح UTF-8 بائٽس جي vector آهي ، توهان انهي مان [`String`] ٺاهي سگهو ٿا.توهان ريورس پڻ ڪري سگهو ٿا.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // اسان knowاڻون ٿا ته بائٽس صحيح آهن ، تنهن ڪري اسين `unwrap()` استعمال ڪنداسين.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// يو يو ايف 8 ـ انڪوڊ ٿيل ، وڌندڙ ۽ بندو آهي.
///
/// `String` قسم هڪ عام قسم جو سوراخ آهي ، جنهن ۾ تار جي مواد تي ملڪيت آهي.اهو پنهنجو قرضدار هم منصب ، ابتدائي [`str`] سان ويجهو تعلق رکي ٿو.
///
/// # Examples
///
/// توهان [a literal string][`str`] کان [`String::from`] سان `String` ٺاهي سگھو ٿا:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// توهان [`push`] طريقي سان [`char`] کي `String` سان ضم ڪري سگھو ٿا ، ۽ [`push_str`] طريقي سان [`&str`] کي ضم ڪري سگھو ٿا.
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// جيڪڏهن توهان وٽ UTF-8 بائٽس جي vector آهي ، توهان [`from_utf8`] طريقي سان ان سان `String` ٺاهي سگهو ٿا:
///
/// ```
/// // ڪجهه بائٽس ، vector ۾
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // اسان knowاڻون ٿا ته بائٽس صحيح آهن ، تنهن ڪري اسين `unwrap()` استعمال ڪنداسين.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// "اسٽرنگ" هميشه صحيح آهي UTF-8.انهي جا ڪجهه اثر هوندا ، پهريون اهو ته جيڪڏهن توهان کي ڪنهن UTF-8 واري اسٽرنگ جي ضرورت آهي ، غور ڪريو [`OsString`] اهو هڪ جيترو آهي ، پر UTF-8 جي رڪاوٽ کان سواء.ٻيو مفهوم اهو آهي ته توهان ايڪس ايڪس ايڪس ايڪسز ۾ انڪس نٿا ڪري سگهو:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// انڊيڪسنگ مسلسل وقت واري آپريشن جو ارادو رکي ٿي ، پر ايڪسڪرنڪس انڪوڊنگ اسان کي ان جي اجازت نه ڏيندا.وڌيڪ ، اهو واضح ناهي ته انڊيڪس کي ڪهڙي شيءِ واپس اچڻ گهرجي: هڪ بائيٽ ، ڪوڊ پوائنٽ ، يا گرافم ڪلٽر.
/// [`bytes`] ۽ [`chars`] طريقا پهرين ٻن کان بعد ۾ ورتا آهن.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// "اسٽرنگ لاڳو" ["Deref"] "<Target=str>۽ ، [[اسٽٽر]] جي سڀني طريقن جا وارث ٿين ٿا.ان کان علاوه ، انهي جو مطلب اهو آهي ته توهان هڪ `String` هڪ فنڪشن تي پاس ڪري سگهو ٿا جيڪو ايڪسپيڪس ۽ (`&`) استعمال ڪندي [`&str`] وٺي ٿو:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// اهو `String` کان [`&str`] ٺاهي ۽ ان کي پاس ڪندو. هي تبادلو تمام سستا آهي ، ۽ تنهن ڪري عام طور تي ، فنڪشن دليلن جي طور تي قبول ڪندا جيستائين ان کي ڪنهن خاص سبب جي لاءِ `String` جي ضرورت نه هوندي.
///
/// ڪجهه حالتن ۾ Rust وٽ اها informationاڻ ڪونه آهي ته اها تبديلي آڻي سگهي ، [`Deref`] جبر جي نالي سان.هيٺين مثال ۾ هڪ اسٽرنگ سلائس [`&'a str`][`&str`] trait `TraitExample` تي عمل ڪري ٿي ، ۽ فنڪشن `example_func` ڪجھ به وٺي ٿو جيڪو trait کي لاڳو ڪري ٿو.
/// انهي صورت ۾ Rust کي ٻه بيضر ٿيندڙ مباحثا ڪرڻا پوندا ، جنهن ڪري Rust کي ڪرڻ جو مطلب نه آهي.
/// انهي لاءِ ، هيٺيون مثال ترتيب نه ڏيندس.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// هتي ٻه اختيار آهن جيڪي بدران ڪم ڪندا.پهرين ڇا ٿيندو ايڪسريڪس `example_func(example_string.as_str());` ڏانهن لڪير ، [`as_str()`] جو طريقو استعمال ڪندي هن تار کي سلائي سلائس کي واضح طور تي ڪ extractڻ لاءِ.
/// ٻيو رستو `example_func(&example_string);` کي `example_func(&*example_string);` ڏانهن تبديل ڪري ٿو.
/// ان صورت ۾ اسان `String` کي [`str`][`&str`] ڏانهن واپس ڪري رهيا آهيون ، پوءِ [`str`][`&str`] کي [`&str`] ڏانهن واپس ڪن ٿا.
/// ٻيو طريقو وڌيڪ جامد آهي ، جڏهن ته ٻئي نقلي طور تي صحيح تبديلي تي ڀروسو ڪرڻ جي بجاءِ ڪم ڪرڻ صحيح ڪم ڪن ٿا.
///
/// # Representation
///
/// هڪ `String` ٽن حصن مان ٺهيل آهي: پوائنٽر کان ڪجهه بائٽس ، ڊيگهه ۽ گنجائش.پوائنٽر اندروني بفر `String` ڏانهن اشارو ڪندي پنهنجي ڊيٽا کي ذخيرو ڪرڻ جي لاءِ استعمال ڪري ٿو.ڊگهائي بائٽ ۾ محفوظ ڪيل بائٽس جو تعداد آهي ، ۽ گنجائش بٽ ۾ بفر جي ماپ آهي.
///
/// انهي جي ڪري ، ڊيگهه هميشه ظرف کان گھٽ يا برابر هوندي.
///
/// ھي بفر ھميشه تي ذخيرو ڪيل آھي.
///
/// توھان انھن کي ڏسي سگھوٿا [`as_ptr`] ، [`len`] ، ۽ [`capacity`] طريقن سان.
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME هن کي تازه ڪاري ڪريو جڏهن vec_into_raw_parts مستحڪم ٿي آهي.
/// // اسٽرنگ جي ڊيٽا کي خودڪار طور ڇڏڻ جو روڪيو
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // ڪهاڻي جون اڻويهه بائٽس آهن
/// assert_eq!(19, len);
///
/// // اسان پيٽرنگ ، لين ، ۽ گنجائش کان ٻاهر هڪ اسٽرنگ ٻيهر تعمير ڪري سگهون ٿا.
/// // اهو سڀ غير محفوظ آهي ڇاڪاڻ ته اسان انهن حصن جي تصديق کي يقيني بنائڻ جا ذميوار آهيون:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// جيڪڏهن هڪ `String` وٽ ڪافي گنجائش آهي ، ان ۾ عناصر شامل ڪرڻ کي ٻيهر مختص نه ڪيا ويندا.مثال طور ، هن پروگرام تي غور ڪريو.
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// هي ٻاھر ڪ willندو.
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// پهرين ۾ ، اسان وٽ ڪا سموري يادگيري مختص نه ڪئي وئي آهي ، پر جيئن ته اسان تار تي لڳايو ٿا ، اهو انهي جي صلاحيت کي چ increasesي ريت وڌائيندو آهي.جيڪڏهن اسان شروعاتي طور تي صحيح صلاحيت مختص ڪرڻ لاءِ [`with_capacity`] طريقو استعمال ڪريو:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// اسان ختم ڪيو هڪ مختلف پيداوار سان.
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// هتي ، لوپ اندر وڌيڪ يادگيري مختص ڪرڻ جي ضرورت ناهي.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// ھڪڙي ممڪن غلطي قيمت جڏھن ھڪڙي `String` کان ھڪڙي UTF-8 بائيٽ vector مان تبديل ڪندي.
///
/// اهو قسم [`String`] طريقي سان [`String`] طريقي جي غلطي جو قسم آهي.
/// اهو اهڙي طريقي سان ٺهيل آهي ته احتياط سان والڪوشن کان بچڻ لاءِ: [`into_bytes`] طريقي سان بائيٽ vector واپس ڏيان ٿو جيڪو تبديلي جي ڪوشش ۾ استعمال ٿي رهيو هو.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`Utf8Error`] قسم [`std::str`] پاران مهيا ڪيل هڪ غلطي جي نمائندگي ڪري ٿو جيڪا شايد [و u8] جي سليس کي [`&str`] ۾ بدلائي ٿي.
/// هن لحاظ کان ، اهو هڪ `FromUtf8Error` تي هڪ تحليل آهي ، ۽ توهان [`utf8_error`] طريقي سان `FromUtf8Error` کان ھڪڙو حاصل ڪري سگھو ٿا.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// // ڪجهه غلط بائيٽ ، vector ۾
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// ھڪڙي ممڪن غلطي قيمت جڏھن ھڪڙي UTF-16 ھڪ UTF-16 بائيٽ سلائس کان تبديل ڪري.
///
/// اهو قسم [`String`] طريقي سان [`String`] طريقي جي غلطي جو قسم آهي.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// بنيادي استعمال
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// هڪ نئون خالي `String` ٺاهي ٿو.
    ///
    /// ڏنو ويو ته `String` خالي آهي ، اهو ابتدائي بفر مختص نه ڪندو.جڏهن ته انهي جو مطلب آهي ته هي ابتدائي آپريشن تمام سستو آهي ، اهو شايد بعد ۾ وڌيڪ مختص ڪري سگهي ٿو جڏهن توهان ڊيٽا شامل ڪريو ٿا.
    ///
    /// جيڪڏهن توهان کي اندازو آهي ته `String` جي ڪيتري ڊيٽا رکيل هوندي ، [`with_capacity`] جي طريقيڪار تي غور ڪريو ته جيئن وڌيڪ ورڇائي کي روڪيو وڃي.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// هڪ خاص ظرفيت سان نئون خالي `String` ٺاهي ٿو.
    ///
    /// "اسٽرنگ" وٽ اندروني بفر آهي انهن جو ڊيٽا رکڻ لاءِ.
    /// گنجائش انهي بفر جي ڊيگهه آهي ، ۽ ايڪس ڪيوڪس جي طريقي سان سوال ڪري سگهجي ٿو.
    /// اھو طريقو ھڪڙو خالي `String` ٺاھي ٿو ، پر ھڪڙي ھڪڙي ھڪڙي اڳئين بفر سان جيڪو `capacity` بائٽ رکي سگھي ٿو.
    /// اهو مفيد آهي جڏهن توهان شايد `String` جي ڊيٽا جي گولي کي هٽائي رهيا هوندا ، هائيرالوڪيشن جي تعداد کي گهٽائڻ جي لاءِ انهي کي ڪرڻ جي ضرورت آهي.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// جيڪڏهن ڏنل گنجائش `0` آهي ، ڪوبه مختص ناهي ٿيندو ، ۽ اهو طريقو [`new`] طريقي سان ساڳيو آهي.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // اسٽرنگ ۾ ڪوبه ڪردار نه آهي ، جيتوڻيڪ اهو وڌيڪ لاءِ گنجائش آهي
    /// assert_eq!(s.len(), 0);
    ///
    /// // هي سڀ ڪم هڻڻ کان سواءِ ڪيا ويندا آهن ۔۔۔
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... پر اهو شايد اسٽرنگ کي ٻيهر ترتيب ڏئي سگهي ٿو
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) سان گڏ موروثي `[T]::to_vec` طريقو ، جيڪو ھن طريقي جي تعريف جي لاءِ گھربل آھي ، دستياب ناھي.
    // جيستائين اسان چڪاس جي مقصد لاءِ هن طريقي جي ضرورت نه آهي ، آئون انهي کي صرف اسٽروب ڪندس NB وڌيڪ معلومات لاءِ slice.rs ماڊل slice::hack ماڊل ڏسو.
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// vector bytes کي `String` ۾ تبديل ڪري ٿو.
    ///
    /// ھڪڙو اسٽرنگ ([`String`]) بائٽس ([`u8`]) مان ٺهيل آھي ، ۽ vector آف بائٽس ([`Vec<u8>`]) بائيٽ مان ٺهيل آھي ، تنھنڪري ھي فنڪشن ٻنھي جي وچ ۾ تبديل ٿي وڃي ٿو.
    /// بائيٽ جي تمام سليٽس صحيح نه آهن "اسٽرنگ" ، تنهن هوندي: `String` انهي جي ضرورت آهي ته اهو UTF-8 صحيح آهي.
    /// `from_utf8()` انهي ڳالهه کي يقيني بڻائڻ جي لاءِ ته بائٽس درست UTF-8 آهن ، ۽ انهي کان پوءِ ڪنورپشن ٿئي ٿي.
    ///
    /// جيڪڏھن توھان کي پڪ آھي ته بائيٽ سلائس صحيح UTF-8 آھي ، ۽ توھان صحيح چڪاس جي مٿي کي برداشت ڪرڻ نٿا چاھيو ، ھن فنڪشن جو غير محفوظ ورزن ، [`from_utf8_unchecked`] آھي ، جيڪو ساڳيو رويو آھي پر چيڪ کي ڇڏي ڏئي ٿو.
    ///
    ///
    /// اهو طريقو ، ڪارڪردگي جي خاطر vector کي نقل نه ڪرڻ جو خيال رکندو.
    ///
    /// جيڪڏهن توهان کي `String` جي بدران [`&str`] جي ضرورت آهي ، [`str::from_utf8`] تي غور ڪريو.
    ///
    /// هن طريقي جو منوب [`into_bytes`] آهي.
    ///
    /// # Errors
    ///
    /// [`Err`] جي واپسي ڏي ٿو جيڪڏهن سليس UTF-8 سان گڏ وضاحت نه آهي ته ڇو مهيا ڪيل بائيٽ UTF-8 ناهي.vector توهان جنهن ۾ منتقل ڪيو ويو به شامل آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// // ڪجهه بائٽس ، vector ۾
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // اسان knowاڻون ٿا ته بائٽس صحيح آهن ، تنهن ڪري اسين `unwrap()` استعمال ڪنداسين.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// غلط بائٽس:
    ///
    /// ```
    /// // ڪجهه غلط بائيٽ ، vector ۾
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// وڌيڪ تفصيل لاءِ ڊاڪيومينٽس [`FromUtf8Error`] ڏانهن ڏسو ڏسو توهان هن غلطي سان ڇا ڪري سگهو ٿا.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// بائيٽ جي هڪ سلائيٽ کي هڪ اسٽرنگ ۾ تبديل ڪري ٿو ، غلط اکرن سميت.
    ///
    /// بائيٽ ([`u8`]) طرفان اسٽرنگس مان ٺهيل آهن ، ۽ bytes ([`&[u8]`][byteslice]) هڪ سلائيٽ بائيٽ مان ٺهيل آهي ، تنهن ڪري اهو فنڪشن ٻنهي جي وچ ۾ تبديل ٿي وڃي ٿو.نه ئي سڀني بائيٽ سلائسن جي صحيح تارون آهن ، تنهن هوندي: اسٽرنگس کي UTF-8 صحيح ڪرڻ گهرجن.
    /// هن تبديلي جي دوران ، `from_utf8_lossy()` [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] سان ڪو به غلط UTF-8 تسلسل مٽائيندو ، جيڪو هن طرح نظر اچي ٿو:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// جيڪڏھن توھان کي پڪ آھي ته بائٽ سلائس صحيح UTF-8 آھي ، ۽ توھان تبديلي جي زيادتي برداشت ڪرڻ نٿا چاھيو ، ھن فنڪشن جو غير محفوظ ورزن ، [`from_utf8_unchecked`] آھي ، جيڪو ساڳيو رويو آھي پر چيڪ کي ڇڏي ڏئي ٿو.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// ھي فنڪشن ھڪڙي [`Cow<'a, str>`] موٽائي ٿو.جيڪڏهن اسان جو بائيٽ سلائس غلط UTF-8 آهي ، ته پوءِ اسان کي متبادل جي ڪردار داخل ڪرڻ جي ضرورت آهي ، جيڪي تار جي شڪل کي تبديل ڪندا ، ۽ تنهن ڪري ، ايڪس ايڪس ايڪس جي ضرورت آهي.
    /// پر جيڪڏهن اهو پهريان کان درست UTF-8 آهي ، اسان کي نئين مختص جي ضرورت ناهي.
    /// هي واپسي وارو قسم اسان کي ٻنهي ڪيسن کي سنڀالڻ جي اجازت ڏيندو آهي.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// // ڪجهه بائٽس ، vector ۾
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// غلط بائٽس:
    ///
    /// ```
    /// // ڪجهه غلط بائيٽ
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// يوٽ ايف-16 - انڪوڊ ٿيل vector `v` ڊبليو `String` ۾ ، [`Err`] واپس ڪر جيڪڏهن `v` ڪا غلط ڊيٽا شامل آهي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // اهو گڏ ڪرڻ جي ذريعي نه ڪيو ويو آهي: : <Result<_, _>> () ڪارڪردگي سببن جي ڪري.
        // FIXME: ايڪس00ڪس بند ٿيڻ سان فنڪشن ٻيهر آسان بڻائي سگهجي ٿي.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// يو ٽي ايف 16 ـ انڪوڊ ٿيل سلائس `v` `String` ۾ Decode ڪريو ، [the replacement character (`U+FFFD`)][U+FFFD] سان غلط ڊيٽا بدلائڻ.
    ///
    /// [`from_utf8_lossy`] جي بدران جيڪو [`Cow<'a, str>`] موٽائي ٿو ، `from_utf16_lossy` هڪ `String` موٽائيندو آهي ڇاڪاڻ ته UTF-16 کان UTF-8 تبادلي هڪ يادگيري مختص ڪرڻ جي ضرورت آهي.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// ھڪڙي `String` ان جي خام حصن ۾ تقسيم ڪري ٿو.
    ///
    /// خام پوائنٽر کي بنيادي ڊيٽا ڏانھن موٽائيندو آھي ، تار جي ڊيگهه (بائٽس ۾) ، ۽ ڊيٽا جي مختص ڪيل گنجائش (بائٽس ۾).
    /// اهي ساڳيون دليل ساڳيون ترتيب سان [`from_raw_parts`] ڏانهن دليل آهن.
    ///
    /// انهي فنڪشن کي ڪال ڪرڻ کان پوءِ ، ڪال ڪندڙ اڳيئي `String` طرفان ياداشت لاءِ ذميوار آهي.
    /// انهي کي ختم ڪرڻ جو واحد رستو اهو آهي ته خام پوائنٽر ، لمبائي ، ۽ گنجائش واپس `String` ۾ [`from_raw_parts`] فنڪشن کي تبديل ڪري ، تباهي ڪندڙ کي وا allowingي ڪرڻ جي اجازت ڏي.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// ڊيگهه ، گنجائش ۽ پوائنٽر کان `String` نئون ٺاهي ٿو.
    ///
    /// # Safety
    ///
    /// اهو انتهائي غير محفوظ آهي ، سببن جي تعداد جي ڪري جيڪي چڪاس نه ڪيا ويا آهن:
    ///
    /// * `buf` تي يادگيري پهريان ئي ساڳيو مختص ڪيل مختص ڪيل ڪرڻ گهرجي جيڪي معياري لائبريري استعمال ڪن ٿيون ، گهربل 1 جي گهربل ترتيب سان.
    /// * `length` `capacity` کان گھٽ يا برابر جي ضرورت آھي.
    /// * `capacity` صحيح قيمت جي ضرورت آهي.
    /// * `buf` تي پهرين `length` بائٽس درست UTF-8 هجڻ جي ضرورت آهي.
    ///
    /// انهن جي ڀڃڪڙي ڪرڻ شايد ايلوڪيٽر جي داخلي ڊيٽا جي اڏاوتن کي بگاڙڻ وانگر مسئلا پيدا ڪري سگهي ٿو.
    ///
    /// `buf` جي ملڪيت مؤثر طور تي `String` ڏانهن منتقل ڪئي وئي آهي جيڪو شايد پوءِ پوائنٽ کي ختم ڪري ، مختص ڪري يا يادداشت جي مواد کي تبديل ڪري سگھي ٿو جيڪو پوائنٽر طرفان مرضي موجب اشارو ڪري ٿو.
    /// انهي کي يقيني بڻايو وڃي ته ٻيو ڪو پوائنٽر استعمال نه ڪندي انهي فنڪشن کي ڪال ڪرڻ کان پوءِ
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME هن کي تازه ڪاري ڪريو جڏهن vec_into_raw_parts مستحڪم ٿي آهي.
    ///     // اسٽرنگ جي ڊيٽا کي خودڪار طور ڇڏڻ جو روڪيو
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// هڪ vector بائٽ کي `String` ۾ تبديل ڪري ٿو ته بغير اسٽرنگ ۾ صحيح UTF-8 شامل آهن.
    ///
    /// وڌيڪ تفصيل لاءِ محفوظ نسخو ، [`from_utf8`] ڏسو.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// اهو فنڪشن غير محفوظ آهي ڇاڪاڻ ته اهو چڪاس نٿو ڪري ته بائٽس ان ڏانهن منتقل ٿيل آهن صحيح UTF-8.
    /// جيڪڏهن هن رڪاوٽ جي ڀڃڪڙي ٿئي ٿي ، اهو شايد `String` جي future استعمال ڪندڙن سان يادداشت جي غير محفوظ مسئلن جو سبب بڻجندي ، ڇاڪاڻ ته باقي معياري لائبريري اهو مڃي ٿو ته "اسٽرنگز درست UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// // ڪجهه بائٽس ، vector ۾
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// هڪ `String` هڪ بائيٽ vector ۾ بدلائي ٿو.
    ///
    /// اهو `String` کي ڀاڙي ٿو ، تنهنڪري اسان کي هن جي مواد کي نقل ڪرڻ جي ضرورت ناهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// ھڪڙي سٽرنگ سلائس کي ڪ entireي ٿو جيڪو پوري `String` تي مشتمل آھي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// هڪ `String` مٽائيل اسٽرنگ سلائس ۾ تبديل ڪري ٿي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// هن `String` جي آخر ۾ ڏنل تار واري سلائس منظور ڪري ٿي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// بائٽ ۾ ھن "اسٽرنگ" جي صلاحيت کي واپس ڏئي ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// انهي کي يقيني بڻائي ٿو ته "اسٽرنگ" جي گنجائش هن جي ڊيگهه کان گهٽ ۾ گهٽ `additional` بائيٽ آهي.
    ///
    /// جيڪڏهن اهو چونڊيندو ته گنجائش وڌيڪ کان وڌيڪ ٿي سگهي ٿي `additional` بائٽس کان ، بار بار ٻيهر منظوري کي روڪڻ لاءِ.
    ///
    ///
    /// جيڪڏهن توهان هن "at least" رويي نٿا چاهيو ، [`reserve_exact`] طريقو ڏسو.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن نئين گنجائش [`usize`] مٿان لڳندي آهي.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// اھو شايد اصل ۾ ظرفيت ۾ واڌارو نٿو ڪري سگھي:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s هاڻي 2 جي ڊيگهه آهي ۽ 10 جي گنجائش آهي
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // اسان وٽ اڳ ۾ ئي اضافي 8 گنجائش آهي ، ان کي سڏ ڪندي ...
    /// s.reserve(8);
    ///
    /// // ... اصل ۾ وڌي ڪونه ٿو.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// انهي کي يقيني بڻائي ٿو ته هن "اسٽرنگ" جي گنجائش `additional` بائٽس ان جي ڊيگهه کان وڏي آهي.
    ///
    /// [`reserve`] طريقو استعمال ڪرڻ تي غور ڪريو جيستائين جيستائين توهان مختصرن کان بهتر نه knowاڻو.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن نئين گنجائش `usize` مٿان لڳندي آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// اھو شايد اصل ۾ ظرفيت ۾ واڌارو نٿو ڪري سگھي:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s هاڻي 2 جي ڊيگهه آهي ۽ 10 جي گنجائش آهي
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // اسان وٽ اڳ ۾ ئي اضافي 8 گنجائش آهي ، ان کي سڏ ڪندي ...
    /// s.reserve_exact(8);
    ///
    /// // ... اصل ۾ وڌي ڪونه ٿو.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// ڏنل `String` ۾ داخل ٿيڻ جي گھٽ ۾ گھٽ `additional` وڌيڪ عناصر جي گنجائش کي محفوظ ڪرڻ جي ڪوشش ڪندو آهي.
    /// اھو مجموعو وڌيڪ جڳھ رکي سگھي ٿو جيڪو بار بار منظرنامن کان بچڻ لاءِ.
    /// `reserve` کي ڪال ڪرڻ کان پوءِ ، گنجائش `self.len() + additional` کان وڌيڪ يا برابر ٿي ويندي.
    /// ڇا ڪجهه به ناهي ڪندو جيڪڏهن گنجائش اڳ ئي ڪافي آهي.
    ///
    /// # Errors
    ///
    /// جيڪڏهن گنجائش وڌي وئي آهي ، يا مختص ڪندڙ ڪنهن ناڪامي جي رپورٽ ڪري ، ته هڪ غلطي واپس ڪئي وئي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // يادگيري کي اڳ ۾ محفوظ ڪريو ، ڪ ifي جيڪڏهن اسان نٿا ڪري سگهون
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ھاڻي اسين knowاڻون ٿا ته ھي OOM اسان جي پيچيده ڪم جي وچ ۾ نٿو ڪري سگھي
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// ڏنل `String` ۾ داخل ٿيڻ جي لاءِ وڌيڪ عناصر جي گھٽ ۾ گھٽ گنجائش رکڻ جي ڪوشش ڪندو آھي وڌيڪ `additional`.
    ///
    /// `reserve_exact` کي ڪال ڪرڻ کان پوءِ ، گنجائش `self.len() + additional` کان وڌيڪ يا برابر ٿي ويندي.
    /// ڇا ڪندو ڪجھ به ناهي جيڪڏهن گنجائش اڳ ئي ڪافي آھي.
    ///
    /// ياد رکو ته مختص ڪندڙ ان کي موڪلڻ کان وڌيڪ جاءِ ڏئي سگهي ٿو.
    /// انهي جي ڪري ، صلاحيت تي اعتبار نه ٿو ڪري سگھجي گھٽ بلڪل گھٽ هجڻ گهرجي.
    /// `reserve` کي ترجيح ڏيو جيڪڏهن future داخل ٿيڻ جي توقع ڪئي وڃي.
    ///
    /// # Errors
    ///
    /// جيڪڏهن گنجائش وڌي وئي آهي ، يا مختص ڪندڙ ڪنهن ناڪامي جي رپورٽ ڪري ، ته هڪ غلطي واپس ڪئي وئي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // يادگيري کي اڳ ۾ محفوظ ڪريو ، ڪ ifي جيڪڏهن اسان نٿا ڪري سگهون
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ھاڻي اسين knowاڻون ٿا ته ھي OOM اسان جي پيچيده ڪم جي وچ ۾ نٿو ڪري سگھي
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// `String` جي ڊيگهه کي انهي جي ڊيگهه سان ملائڻ جي صلاحيت کي سڏي ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// هن `String` جي گهٽتائي کي گھٽ حد سان گھٽائي ٿو.
    ///
    /// گنجائش گهٽ ۾ گهٽ جيترو وڏو ٿيندو جيترو ڊگهو ۽ سپلائي قدر.
    ///
    ///
    /// جيڪڏهن موجوده گنجائش هيٺين حد کان گهٽ آهي ، اهو هڪ اوپي ناهي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// ڏنو ويو [`char`] هن `String` جي آخر ۾ شامل ڪريو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// ھن "اسٽرنگ" جي مواد جو بائيٽ سلائس کي واپس ڪري ٿو.
    ///
    /// هن طريقي جو منوب [`from_utf8`] آهي.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// ھن ايڪس پي ايم ايڪس کي مقرر ڪيل ڊيگهه ڏانھن گھٽائي ٿو.
    ///
    /// جيڪڏهن `new_len` تار جي موجوده ڊيگهه کان وڌيڪ آهي ، انهي جو ڪوبه اثر ناهي.
    ///
    ///
    /// ياد رهي ته هن طريقي سان تار جي مختص ڪيل گنجائش تي ڪو اثر ناهي
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `new_len` ڪو [`char`] حد تي ڪوڙ ناهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// اسٽرنگ بفر مان آخري ڪردار ڪي ٿو ۽ ان کي واپس ڪري ٿو.
    ///
    /// ايڪس پي ايم ايڪس ڏي ٿو جيڪڏهن هي `String` خالي آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// [`char`] کان ھڪڙو [`char`] ھڪڙي بائيٽ پوزيشن تي ختم ڪري ٿو ۽ ان کي واپس ڪري ٿو.
    ///
    /// هي هڪ *او*(*اين*) آپريشن آهي ، ڇاڪاڻ ته انهي کي بفر ۾ هر عنصر کي نقل ڪرڻ جي ضرورت آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `idx` "اسٽرنگ" جي ڊيگهه کان وڏي يا برابر آهي ، يا جيڪڏهن اهو [`char`] جي حد تي ڪوڙ ناهي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String` ۾ پيٽرڪس `pat` جي سڀني ميچن کي هٽايو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// ماچس کي ڳولڻ ۽ ان جي ترتيب کي ختم ڪيو ويندو ، تنهن ڪري ڪيسن ۾ جتي نمونا ختم ٿين ٿا ، صرف پهرين نمونو ئي ختم ٿي ويندو.
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // حفاظت: شروعات ۽ آخرڪار utf8 بائيٽ جي حدن تي ٿيندو
        // ڳوليندڙ دستاويز
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// اڳڪٿيءَ طرفان مخصوص ڪيل ڪردارن کي برقرار رکي ٿو.
    ///
    /// ٻين لفظن ۾ ، سڀني اکرن کي خارج ڪريو `c` جنهن جي ڪري `f(c)` `false` موٽائي ٿو.
    /// اهو طريقو جڳهه تي هلندو آهي ، هر هڪ ڪردار کي اصلي ترتيب ۾ هڪ ڀيرو ڏسڻ ، ۽ برقرار رکيل ڪردارن جي ترتيب کي محفوظ ڪري ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// صحيح ترتيب ٻاهرئين حالت کي نظر ۾ رکڻ لاءِ ڪارائتو ٿي سگهي ٿي ، جهڙوڪ هڪ انڊيڪس.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // ايندڙ چار کي آئي ايڪس ڏانهن اشارو ڪيو
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// `String` ۾ ھڪڙو ڪردار داخل ڪريو بائيٽ پوزيشن تي.
    ///
    /// هي هڪ *او*(*اين*) آپريشن آهي ڇاڪاڻ ته اها بفر ۾ هر عنصر کي نقل ڪرڻ جي ضرورت آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `idx` "اسٽرنگ" جي ڊيگهه کان وڏي آهي ، يا جيڪڏهن اهو [`char`] جي حد تي ڪوڙ ناهي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// `String` ۾ ھڪڙي اسٽرنگ سلائس کي ھڪ بائيٽ جي پوزيشن تي داخل ڪري ٿو.
    ///
    /// هي هڪ *او*(*اين*) آپريشن آهي ڇاڪاڻ ته اها بفر ۾ هر عنصر کي نقل ڪرڻ جي ضرورت آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن `idx` "اسٽرنگ" جي ڊيگهه کان وڏي آهي ، يا جيڪڏهن اهو [`char`] جي حد تي ڪوڙ ناهي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// ھن `String` جي مواد کي قابل تبديل ٿيندڙ ريٽ ڏئي ٿو.
    ///
    /// # Safety
    ///
    /// اهو فنڪشن غير محفوظ آهي ڇاڪاڻ ته اهو چڪاس نٿو ڪري ته بائٽس ان ڏانهن منتقل ٿيل آهن صحيح UTF-8.
    /// جيڪڏهن هن رڪاوٽ جي ڀڃڪڙي ٿئي ٿي ، اهو شايد `String` جي future استعمال ڪندڙن سان يادداشت جي غير محفوظ مسئلن جو سبب بڻجندي ، ڇاڪاڻ ته باقي معياري لائبريري اهو مڃي ٿو ته "اسٽرنگز درست UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// `String` جي ڊيگهه ڏيکاري ٿو ، بائٽس ۾ ، نه ["چار"] يا گرافڪس.
    /// ٻين لفظن ۾ ، اهو شايد نه ٿي سگهي ٿو ته هڪ انسان تار جي ڊيگهه کي سمجهي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// جيڪڏهن `String` صفر جي ڊيگهه آهي ، ۽ `false` ٻي صورت ۾ `true` واپس ڪري ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// string کي ٻن ۾ ڏنل بائيٽ انڊيڪس ۾ ورهايو.
    ///
    /// نئين مختص ڪيل `String` کي واپس آڻيندي.
    /// `self` بائٽس `[0, at)` تي مشتمل آھي ، ۽ واپس ڪيل `String` بائٽس `[at, len)` تي مشتمل آھي.
    /// `at` UTF-8 ڪوڊ پوائنٽ جي حد تي ھجڻ لازمي آھي.
    ///
    /// نوٽ ڪريو ته `self` جي گنجائش تبديل نه ٿيندي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن ايڪسڪسيمڪس `UTF-8` ڪوڊ پوائنٽ جي حد تي نه آهي ، يا جيڪڏهن اهو اسٽرنگ جي آخري ڪوڊ پوائنٽ کان ٻاهر آهي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// هن `String` کي ختم ڪري ٿو ، سڀني مواد کي ڪ ،ي ٿو.
    ///
    /// جڏهن ته انهي جو مطلب آهي `String` ۾ صفر جي ڊيگهه هوندي ، انهي جي گنجائش تي ڪوبه رابطو نه آهي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// خشڪ خشڪ ايراٽر ٺاهي ٿو جيڪو `String` ۾ طئه ٿيل رينج کي ختم ڪري ٿو ۽ ختم ٿيل `chars` کي پيدا ڪري ٿو.
    ///
    ///
    /// Note: عنصر جي حد ڪ isيو وڃي ٿو جيتوڻيڪ آخرڪار ايتري تائين ختم نه ٿيندي آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن شروعاتي نقطي يا آخري پوائنٽ [`char`] جي حد تي ڪوڙ ناهي ، يا جيڪڏهن اهي حد کان ٻاهر آهن.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // تان تان بي تائين تار کي هٽايو
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // هڪ مڪمل سلسلو ، تار صاف ڪري ٿو
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // ياداشت جي حفاظت
        //
        // Drain جو اسٽرنگ ورزن vector ورزن جي ميموري حفاظت وارن مسئلن جو حامل ناهي.
        // ڊيٽا صرف سادي بائيٽ آهي.
        // ڇاڪاڻ ته رينج ڪ removalڻ ڊراپ ۾ ٿئي ٿي ، جيڪڏهن Drain iterator لڪي وڃي ها ، ڪ theڻ نه ٿي ٿئي.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // ٻه پاڻمرادو قرض کڻي ڪ outو.
        // &mut اسٽرنگ تيستائين رسائي نه ڪئي ويندي جيستائين اهو ختم نه ٿئي ، ڊراپ ۾.
        let self_ptr = self as *mut _;
        // حفاظت: `slice::range` ۽ `is_char_boundary` مناسب حدون چيڪ ڪريو.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// تار ۾ مقرر ڪيل حد کي ختم ڪري ٿو ، ۽ ڏنل واري اسٽرنگ سان ان کي بدلائي ٿو.
    /// ڏنل اسٽرنگ کي حد جيتري جيتري نه هجڻ جي ضرورت آهي.
    ///
    /// # Panics
    ///
    /// Panics جيڪڏهن شروعاتي نقطي يا آخري پوائنٽ [`char`] جي حد تي ڪوڙ ناهي ، يا جيڪڏهن اهي حد کان ٻاهر آهن.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // β کان سٽرنگ تائين حد تائين تبديل ڪريو
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // ياداشت جي حفاظت
        //
        // Replace_range وٽ vector Splice جي ميموري حفاظت جا مسئلا نه آهن.
        // vector ورزن جو.ڊيٽا صرف سادي بائيٽ آهي.

        // خبردار: هن متغير کي طئي ڪرڻ (#81138) بي ترتيب ٿي سگهندو
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // خبردار: هن متغير کي طئي ڪرڻ (#81138) بي ترتيب ٿي سگهندو
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // ٻيهر `range` استعمال ڪندي بي جوڙ (#81138) اسان سمجهندا هئاسين ته `range` پاران ٻڌايو ويو حدون ساڳيو ئي رهنديون ، پر هڪ مخالف نفاذ ڪال جي وچ ۾ تبديل ٿي سگهي ٿي
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// اس `String` کي هڪ ["باڪس"] <"[" str "]" ۾ تبديل ڪري ٿو.
    ///
    /// اهو وڌيڪ اضافي گنجائش ختم ڪندو.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// [س uي_8] بائٽس جو سِلايل واپسي ڏي جيڪا ايڪس ايڪس ايڪس ۾ بدلائڻ جي ڪوشش ڪئي وئي هئي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// // ڪجهه غلط بائيٽ ، vector ۾
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// بائٽس واپس ڪري ٿو جيڪي ايڪس آرڪس ۾ تبديل ٿيڻ جي ڪوشش ڪئي وئي.
    ///
    /// اهو طريقو احتياط سان مختص ڪرڻ کان بچڻ جي لاءِ تيار ڪيو ويو آهي.
    /// اهو غلطي کي استعمال ڪندي ، بائٽس کي ٻاهر منتقل ڪندي ، انهي ڪري بائٽس جي ڪاپي ٺاهڻ جي ضرورت نه آهي.
    ///
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// // ڪجهه غلط بائيٽ ، vector ۾
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// تبديلي جي ناڪامي بابت وڌيڪ تفصيل حاصل ڪرڻ جي لاءِ `Utf8Error` کي گڏ ڪريو.
    ///
    /// [`Utf8Error`] قسم [`std::str`] پاران مهيا ڪيل هڪ غلطي جي نمائندگي ڪري ٿو جيڪا شايد [و u8] جي سليس کي [`&str`] ۾ بدلائي ٿي.
    /// هن لحاظ سان ، اهو ايڪسڪسيمڪس جو هڪ اينالاگ آهي.
    /// ڏسو وڌيڪ تفصيل لاءِ ان جو دستاويز انهي کي استعمال ڪرڻ بابت.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// // ڪجهه غلط بائيٽ ، vector ۾
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // پهرين بائيٽ هتي غلط آهي
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // ڇاڪاڻ ته اسان "اسٽرنگز" تي ٻيهر غور ڪري رهيا آهيون ، اسين ايٽررٽر کان پهرين اسٽرنگ حاصل ڪندي گهٽ ۾ گهٽ هڪ اي ميلوشن کان پاسو ڪري سگهون ٿا ۽ ان کي بعد ۾ آيل سڀني اسٽرنگز کي شامل ڪري سگهون ٿا.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // ڇاڪاڻ ته اسين CoWs کي وڌيڪ مٿان ورهائي رهيا آهيون ، اسان (potentially) کان پهرين شي کي حاصل ڪرڻ کان گهٽ ۾ گهٽ هڪ مختص ڪرڻ کان پاسو ڪري سگهندا آهيون ۽ انهي جي پٺيان ايندڙ سڀ شيون شامل ڪري سگهون ٿا.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// هڪ سهولت جو مطلب آهي ايڪس پيڪس آرڪس جو لاڳو ڪندڙ نمائندو.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// خالي `String` ٺاهي ٿو.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// ايڪس اسٽرنگ کي ٻن تارن کي ملائڻ لاءِ لاڳو ڪري ٿو.
///
/// اهو `String` کاٻي پاسي واري پاسي کي ڪتب آڻيندو آهي ۽ پنهنجي بفر کي ٻيهر استعمال ڪندو آهي (جيڪڏهن ضروري هجي ته اڳتي وڌائي).
/// اهو نئون `String` مختص ڪرڻ ۽ هر آپريشن تي سموري مواد نقل ڪرڻ کان بچڻ لاءِ ڪيو ويو آهي ، جيڪو *O*(*n*^ 2) هلائڻ وقت هلندو رهيو جڏهن بار بار گڏجاڻي ڪندي هڪ *اين* بائيٽ اسٽرنگ ٺاهيندي.
///
///
/// سا-ي هٿ تي تار صرف قرض ڏيندڙ آهي ؛ان جا مواد واپس ڪيل `String` ۾ نقل ٿيل آهن.
///
/// # Examples
///
/// ملندڙ ٻه "اسٽرنگس" پهرين قيمت سان وٺندي آهي ۽ ٻئي کي قرض ڏيندي آهي:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ھليو ويو آھي ۽ ھاڻي استعمال نه ٿو ڪري سگھجي.
/// ```
///
/// جيڪڏهن توهان پهريون `String` استعمال ڪرڻ چاهيندا هجو ، توهان ان کي ڪلون ڪري سگهو ٿا ۽ ان جي بدران ڪلون جو اضافو ڪريو:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` هتي اڃا تائين صحيح آهي.
/// ```
///
/// سموري `&str` سلائسز پهرين `String` ۾ تبديل ڪندي ڪري سگهجي ٿو.
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// `+=` آپريٽر کي `String` ۾ شامل ڪرڻ جي اپنائي ٿو.
///
/// اهو ساڳيو رويو [`push_str`][String::push_str] جو طريقو آهي.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// ايڪس قسم ايڪس ايڪس لاء هڪ قسم عرف.
///
/// اهو عرف پٺتي مطابقت لاءِ موجود آهي ، ۽ ٿي سگهي ٿو آخرڪار نااهل هجي.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// ايڪسڪسيمڪس ۾ قيمت بدلائڻ جي لاءِ trait.
///
/// اهو trait پاڻمرادو ڪنهن به قسم لاءِ لاڳو ٿئي ٿي جيڪا [`Display`] trait کي لاڳو ڪري ٿي.
/// جيئن ، `ToString` سڌو سنئون لاڳو نه ڪيو وڃي:
/// [`Display`] انهي جي بدران لاڳو ٿيڻ گهرجي ، ۽ توهان حاصل ڪيو ايڪس اوڪسڪس مفت.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// ڏنل قيمت کي `String` ۾ بدلائي ٿو.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// انهي عملدرآمد ۾ ، `to_string` طريقو panics جيڪڏهن `Display` عمل درآمد هڪ غلطي آڻيندي.
/// اهو اشارو غلط `Display` عمل درآمد ڏانهن اشارو آهي ڇاڪاڻ ته `fmt::Write for String` ڪڏهن به پاڻ کي غلطي واپس نه آڻي.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // هڪ عام هدايت عام افعال کي قطعي نه ڏيڻ جي آهي.
    // بهرحال ، ھن طريقي مان `#[inline]` کي ڪ removingڻ غير غفلت واري ريگريشن جو سبب بڻجي ٿو.
    // <https://github.com/rust-lang/rust/pull/74852> کي ڏسو ، ان کي ختم ڪرڻ جي آخري ڪوشش ڪرڻ.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// هڪ `&mut str` هڪ `String` ۾ بدلائي ٿو.
    ///
    /// نتيجو theاڻي واڻي تي مختص ڪيو ويو آهي.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: لسٽسٽ ۾ ٽيسٽ ڇڪي ٿي ، جنهن جي ڪري غلطيون هتي اچن ٿيون
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// ڏنل دٻي واري `str` سلائس کي `String` ڏانهن بدلائي ٿو.
    /// اهو قابل ذڪر آهي ته `str` سلائسس ملڪيت آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// ڏنل `String` دٻي کي `str` سلائس ۾ بدلائي ٿو جيڪا ملڪيت آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// هڪ اسٽرنگس سلائس کي قرض ڏيندڙ ورانٽ ۾ بدلائي ٿو.
    /// ڪوبه هپ مختص نه ڪيو ويو آهي ، ۽ تار کي نقل نه ڪيو ويو آهي.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// ھڪڙو اسٽرنگ کي ھڪڙو مالڪ قسم ۾ تبديل ڪري ٿو.
    /// ڪوبه هپ مختص نه ڪيو ويو آهي ، ۽ تار کي نقل نه ڪيو ويو آهي.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// هڪ اسٽرنگنگ حواله کي قرض ڏيندڙ ورژن ۾ بدلائي ٿو.
    /// ڪوبه هپ مختص نه ڪيو ويو آهي ، ۽ تار کي نقل نه ڪيو ويو آهي.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// ڏنل `String` هڪ vector `Vec` ۾ تبديل ڪري ٿو جيڪو ايڪس ايڪس ايڪس قسم جا قدر سنڀاليندو آهي.
    ///
    /// # Examples
    ///
    /// بنيادي استعمال
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String` لاءِ هڪ خشڪ انٽريٽر.
///
/// هي جوڙ [`String`] تي [`drain`] طريقي سان ٺهيل آهي.
/// وڌيڪ لاءِ ان جي دستاويز ڏسو.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// تباهي ۾ آڻيندي&amp ؛ هڪ String طور استعمال ٿيندو
    string: *mut String,
    /// هٽائڻ واري حصي جي شروعات
    start: usize,
    /// ختم ڪرڻ لاءِ ٽيون حصو
    end: usize,
    /// هٽائڻ لاءِ موجوده رهيل حد
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain استعمال ڪريو.
            // "Reaffirm" حدون چيڪ ڪندي آھي panic ڪوڊ ٻيهر داخل ٿيڻ کان.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// واپسي جي باقي باقي (ذيلي) تار کي هڪ سلائس وانگر واپس ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: عدم استحڪام ايس آرف هيٺ هوندو آهي استحڪام جڏهن.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` کي مستحڪم ڪرڻ وقت ناڪامياب.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> ايس ريف<str>لاءِ Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> لاءِ Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}