use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // ٽئين پارٽي جي مختص ڪندڙن ۽ `RawVec` جي وچ ۾ انضمام جي ٽيسٽ لکڻ هڪ نن trickڙو مشڪل آهي ڇاڪاڻ ته `RawVec` API غلط الوقت طريقن کي ظاهر نه ڪندو آهي ، تنهنڪري اسان جاچ نٿا ڪري سگهون ته مختصرن کي ختم ڪيو ويو (panic کي ڳولڻ کان ٻاهر).
    //
    //
    // بدران ، اهو صرف چيڪ ڪري ٿو ته `RawVec` طريقو گهٽ ۾ گهٽ Allocator API جي ذريعي وڃي ٿو جڏهن اهو اسٽوريج کي محفوظ ڪري ٿي.
    //
    //
    //
    //
    //

    // هڪ گونگا مختص ڪندڙ جيڪو مختص ڪرڻ کان پهريان فيول مقدار جي فيول استعمال ڪري ٿو ناڪام ٿيڻ شروع ٿي ويو آهي.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (هڪ ريلوڪو جو سبب بڻجندو آهي ، اهڙي طرح 50 + 150=200 يونٽ ايندڻ)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // پهريون ، `reserve` ايڪس ريڪس وانگر مختص ڪري ٿو.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 7 جي ڊبل کان وڌيڪ آهي ، تنهنڪري `reserve` کي `reserve_exact` وانگر ڪم ڪرڻ گهرجي.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 12 جي اڌ کان گهٽ آهي ، تنهن ڪري `reserve` کي لازمي طور تي اڳتي وڌڻ گھرجي.
        // لکڻ جي وقت تي اهو ٽيسٽ وڌندڙ عنصر 2 آهي ، تنهن ڪري نئين گنجائش 24 آهي ، البته ، ايڪس ايڪس ايڪس جي واڌ فيڪٽر پڻ ٺيڪ آهي.
        //
        // انهي تي `>= 18` زور ڀريو.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}