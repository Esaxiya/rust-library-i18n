#![stable(feature = "rust1", since = "1.0.0")]

//! سلسلي وارا محفوظ حوالا ڳڻيندڙ اشارو.
//!
//! وڌيڪ تفصيل لاءِ [`Arc<T>`][Arc] دستاويز ڏسو.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// حوالن جي مقدار تي نرم حد جيڪا شايد ايڪس اين ايڪس ايڪس تائين ٿي سگهي ٿي.
///
/// انهي حد کان مٿي وڃڻ توهان جي پروگرام کي ختم ڪري ڇڏيو (جيتوڻيڪ ضروري نه) _exactly_ `MAX_REFCOUNT + 1` حوالن تي.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer يادگيري باڙن کي سپورٽ نٿو ڪري.
// آرڪ/ڪمزور جي عمل ۾ غلط مثبت رپورٽن کان بچڻ لاءِ استعمال ڪيو ويو آهي ته هم وقت سازي لاءِ ايٽمي لوڊ استعمال ڪريو.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// سلسلي جو محفوظ حوالو-ڳڻپيندڙ پوائنٽر 'Arc' جو مطلب آھي 'ايٽمي طور تي حوالو ڳڻپ'.
///
/// قسم `Arc<T>` قسم `T` جي قيمت جي گڏيل ملڪيت مهيا ڪندو آهي ، هيڪ ۾ مختص ٿيل.`Arc` تي [`clone`][clone] کي شامل ڪرڻ ھڪڙو نئون `Arc` مثال پيدا ڪري ٿو ، جيڪو ھڪڙو XOX کي ماخذ طور تي ھڪڙي ئي مختص کي ظاھر ڪري ٿو ، جڏھن ھڪڙي حوالن جي ڳڻپ ۾ اضافو ڪري رھيا آھن.
/// جڏهن هڪ ڏنل مختص ڪيل آخري `Arc` پوائنٽر کي تباهه ڪيو وڃي ، ان ويليوشن ۾ ذخيرو ٿيل قدر (اڪثر ڪري "inner value" جو حوالو ڏنو ويندو) پڻ ختم ڪيو ويو آهي.
///
/// Rust ۾ گڏيل حوالن ڊفالٽ ذريعي ميوٽيشن کي رد ڪن ٿا ، ۽ `Arc` ڪا استثنا نه آهي: توهان عام طور تي `Arc` اندر ڪنهن به شيءَ جي لاءِ قابل تبديل حوالا حاصل نٿا ڪري سگهو.جيڪڏهن توهان کي `Arc` ذريعي خاموش ڪرڻ جي ضرورت آهي ، استعمال ڪريو [`Mutex`][mutex] ، [`RwLock`][rwlock] ، يا هڪ [`Atomic`][atomic] قسمن مان.
///
/// ## سلسلي جو تحفظ
///
/// [`Rc<T>`] جي نسبت ، `Arc<T>` ان جو حوالو ڳڻپڻ لاءِ ائٽمي آپريشن استعمال ڪري ٿو.انهي جو مطلب اهو آهي ته اهو موضوع کان محفوظ آهي.نقصان اهو آهي ته ايٽمي آپريشن عام يادداشت جي پهچ کان وڌيڪ قيمتي آهن.جيڪڏهن توهان موضوعن جي وچ ۾ حوالن جي ڳڻپ ٿيل مختصون نه شيئر ڪري رهيا آهيو ، هيٺ اوچي ويل لاءِ [`Rc<T>`] استعمال ڪرڻ تي غور ڪريو.
/// [`Rc<T>`] هڪ محفوظ ڊفالٽ آهي ، ڇاڪاڻ ته مرتب ڪندڙ ڪنهن به ڪوشش کي پڪڙي ڇڏيندو آهي انهي جي وچ ۾ [`Rc<T>`] موڪليندا آهن.
/// جيتوڻيڪ ، لائبريري `Arc<T>` چونڊي سگھي ٿي لائبريري جي صارفين کي وڌيڪ لچڪ ڏيڻ لاءِ.
///
/// `Arc<T>` [`Send`] ۽ [`Sync`] تي عمل ڪندو جيستائين جيستائين `T` [`Send`] ۽ [`Sync`] تي عمل ڪري ٿو.
/// توھان ان کي محفوظ ڪري ٺاھڻ لاءِ `Arc<T>` ۾ ھڪڙي موضوع واري محفوظ قسم `T` ڇو نٿا رکي سگھو؟شايد اهو پهريون ڀيرو ٿورڙي بدقسمتي آهي: سڀ کان پوء ، ڇا `Arc<T>` واري موضوع جي حفاظت جو نقطو ناهي؟ڪيڏ اهو آهي: ايڪسڪسيمڪس انهي کي محفوظ رکي ٿو انهي ساڳي ڊيٽا جي ڪيترن ئي ملڪيت تي ، پر اهو انهي جي ڊيٽا ۾ حفاظت جي حفاظت کي شامل نٿو ڪري.
///
/// غور ڪريو `آرڪ <` [`ريفيڪل<T>"]" ".
/// [`RefCell<T>`] [`Sync`] ناهي ، ۽ جيڪڏهن `Arc<T>` هميشه [`Send`] هوندو ، آرڪ <"[" RefCell. "<T>پڻ].
/// پر پوء اسان کي مسئلو هوندو.
/// [`RefCell<T>`] سلسلي محفوظ ناهياهو غير ائٽمي آپريشن کي استعمال ڪندي قرض وٺڻ واري ڳڻپ جي خبر رکندي آهي.
///
/// آخر ۾ ، هن جو مطلب اهو آهي ته توهان کي شايد X012 کي ڪنهن قسم جي [`std::sync`] قسم سان ڳن needڻ جي ضرورت آهي ، عام طور تي [`Mutex<T>`][mutex].
///
/// ## `Weak` سان ٽوڙڻ وارا چڪر
///
/// [`downgrade`][downgrade] طريقو غير مالڪ [`Weak`] پوائنٽر ٺاھڻ لاءِ استعمال ڪري سگھجي ٿو.ھڪڙي [`Weak`] پوائنٽر ٿي سگھي ٿو ["اپ گريڊ"][اپڊيٽ] ڊي کي `Arc` ، پر اھو واپس ڪندو [`None`] جيڪڏهن قدر ۾ ذخيرو ٿيل قدر اڳ ۾ ئي گھٽجي چڪو آھي.
/// ٻين لفظن ۾ ، `Weak` پوائنٽر مختص ٿيل قدر اندر نٿو رکي ؛تنهن هوندي ، اهي *رکندا* مختص رکندا (قيمت لاءِ مددگار ذخيرو) زنده آهن.
///
/// `Arc` پوائنٽرن جي وچ وارو چڪر ڪڏهن به ختم نه ٿيندو.
/// انهي جي لاء ، ايڪسڪسيمڪس سائيڪلن کي ٽوڙڻ لاءِ استعمال ٿيندو آهي.مثال طور ، هڪ وڻ مضبوط `Arc` پوائنٽرن کي والدين نوڊس کان ٻارن ڏانهن ، ۽ [`Weak`] اشارو ڏيندڙن ٻارن کي انهن جي والدين کان واپس وٺي سگھن ٿا.
///
/// # ڪلوننگ وارو حوالو
///
/// موجوده ريفرنس شمار ٿيل پوائنٽر مان نئون حوالو ٺاهڻ سان [`Arc<T>`][Arc] ۽ [`Weak<T>`][Weak] لاءِ لاڳو ڪيل `Clone` trait استعمال ڪيو وڃي ٿو.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // هيٺ ڏنل ٻه نحو برابر آهن.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a ، b ، ۽ foo سڀئي آرڪ آهن جيڪي هڪ ئي يادگيري جي جڳهه ڏانهن اشارو ڪن ٿا
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` پاڻمرادو `T` ڏانهن حوالو ڏيو ([`Deref`][deref] trait ذريعي) ، تنهنڪري توهان قسم `Arc<T>` جي قيمت تي "T" جا طريقا سڏ ڪري سگهو ٿا.نالي جي ڀڃڪڙي کان بچڻ لاء "ٽي" جي طريقن سان ، `Arc<T>` جا طريقا پاڻ ۾ جڙيل هوندا آهن ، ايڪس ايڪسڪس استعمال ڪندي سڏيو ويندو آهي:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// آرڪ<T>traits وانگر `Clone` جو نفاذ شايد مڪمل طور تي قابل نحو استعمال ڪيو وڃي سگھي ٿو.
/// ڪجهه ماڻهو مڪمل طور تي قابل نحو استعمال ڪرڻ پسند ڪندا آهن ، جڏهن ته ٻيا طريقا استعمال ڪرڻ پسند ڪن ٿا نحو.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // طريقو ڪال نحو
/// let arc2 = arc.clone();
/// // مڪمل طور تي قابل تعليم نحو
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T` ڏانهن خودمختياري نٿو ڏئي ، ڇاڪاڻ ته اندروني قدر اڳ ۾ ئي گھٽجي چڪو آهي.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// سلسلا جي وچ ۾ ڪجھ تبديل ٿيندڙ ڊيٽا حصيداري ڪرڻ
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// نوٽ ڪيو ته اسان ** آزمائشي نه هلائيندا آهيون.
// اي windows ٺاهيندڙن کي وڏي ناخوش ٿي ويندي آهي جيڪڏهن هڪ موضوع کڻي بنيادي ڌارا کان بچيل آهي ۽ پوءِ ساڳي ئي وقت ٻاهر نڪري وڃي ٿو (ڪجهه چالو) تنهن ڪري اسان صرف انهي آزمائش کي نه هلڻ سان مڪمل طور پاسو ڪندا سين.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// هڪ تبديلي لائق [`AtomicUsize`] ورهائيندي:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// عام طور تي حوالن جي ڳڻپ جي وڌيڪ مثالن لاءِ [`rc` documentation][rc_examples] ڏسو.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` [`Arc`] جو هڪ نسخو آهي جيڪو منظم ڪيل مختص جي غير مالڪ جو حوالو رکي ٿو.
/// مختص ڪيل [`upgrade`] کي `Weak` پوائنٽر تي ڪال ڪندي رسائي حاصل ڪئي وئي آهي ، جيڪا هڪ ["اختيار"] "<" ["آرڪ"] کي واپس ڪري ٿي.<T>> ".
///
/// جئين `Weak` حوالو ملڪيت جي لحاظ کان نه ڳڻيندو آهي ، اهو مختص ٿيل قيمت کي گهٽائڻ کان روڪي نه سگهندو ، ۽ `Weak` پاڻ اڃا تائين موجود قدر جي باري ۾ ڪا به ضمانت نه ٿو ڏئي.
///
/// ان ڪري اهو شايد [`None`] موٽائي سگھي ٿو جڏهن [`اپ گريڊ`] ڊي.
/// جيتوڻيڪ نوٽ ڪريو ته `Weak` ريفرنس * ختم ڪرڻ کان پاڻ کي بچائي ٿو (پسمانده اسٽور) کي ختم نه ٿيڻ ڏنو وڃي.
///
/// هڪ `Weak` پوائنٽر [`Arc`] پاران مختص ڪيل عارضي جي حوالي سان عارضي حوالو رکڻ لاءِ ڪارائتو آهي ان جي اندروني قيمت وڃائڻ کان بغير.
/// اهو [`Arc`] پوائنٽرن جي وچ ۾ گردڪ حوالن کي روڪڻ لاءِ پڻ استعمال ڪيو ويو آهي ، ڇاڪاڻ ته باقائدگي سان حوالا ڏيڻ وارا ڪڏهن به [`Arc`] ڇڏڻ جي اجازت نٿا ڏين.
/// مثال طور ، هڪ وڻ مضبوط [`Arc`] پوائنٽرن کي والدين نوڊس کان ٻارن ڏانهن ، ۽ `Weak` اشارو ٻارن کان انهن جي والدين ڏانهن موٽي سگهي ٿو.
///
/// `Weak` پوائنٽر حاصل ڪرڻ جو عام طريقو [`Arc::downgrade`] کي سڏ ڪرڻ آهي.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // اھو ھڪڙو `NonNull` آھي ان قسم جي سائيز کي سڌارڻ جي اجازت ڏيڻ جي اجازت ڏي ، پر اھو لازمي طور تي صحيح پوائنٽر نه آھي.
    //
    // `Weak::new` انهي کي `usize::MAX` تي سيٽ ڪريو ته انهي کي هيڪ تي جڳهه مختص ڪرڻ جي ضرورت نه آهي.
    // اهو هڪ قيمت ناهي حقيقي رئيلٽر ڪڏهن به هوندو ، ڇاڪاڻ ته آر سي بوڪس وٽ گهٽ ۾ گهٽ 2 جي ترتيب آهي.
    // اهو صرف تڏهن ممڪن آهي جڏهن `T: Sized`؛اڻ سڌريل `T` ڪڏهن به جڙي نه سگهندو.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// اهو repr(C) کان future آهي ثبوت فيلڊ ٻيهر ترتيب ڏيڻ جي خلاف ، جيڪو مداخلت ڪري سگهندو آهي ٻي صورت ۾ محفوظ [into|from]_raw() منتقلي واري اندرين قسمن جي.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // قدر usize::MAX عارضي طور تي "locking" طور موڪليو موڪليل طور تي ڪمزور پوائنٽرن کي اپ گريڊ ڪرڻ يا مضبوط پوائنٽ کي هيٺ ڪرڻ جي صلاحيت رکي ٿو.اهو `make_mut` ۽ `get_mut` ۾ ريسز کان بچڻ لاءِ استعمال ڪيو ويندو آهي.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// نئون `Arc<T>` تعمير ڪندو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // ڪمزور پوائنٽر جي ڳڻپ شروع ڪريو 1 جي طور تي جيڪو ڪمزور پوائنٽر آھي جيڪو تمام مضبوط پوائنٽرس (kinda) جي طرفان رکيل آھي ، وڌيڪ forاڻ لاءِ std/rc.rs ڏسو
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// پنهنجي پاڻ تي هڪ ڪمزور حوالو استعمال ڪندي هڪ نئون `Arc<T>` تعمير ڪري ٿو.
    /// انهي فنڪشن جي واپسي کان پهريان ضعيف ريفرنس کي اپڊيٽ ڪرڻ جي ڪوشش ڪئي ويندي جنهن جي نتيجي ۾ `None` ويليو ٿيندي.
    /// تنهن هوندي ، ضعيف حواله شايد کلون ۽ آزادي سان کلندي استعمال لاءِ محفوظ ڪيل هجي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // اندروني کي "uninitialized" رياست ۾ ھڪڙو ڪمزور حوالن سان تعمير ڪريو.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // اهو ضروري آهي ته اسان ڪمزور پوائنٽر جي ملڪيت ڇڏي نه ڏيون ، ٻي صورت ۾ يادداشت `data_fn` موٽڻ واري وقت کان آزاد ٿي سگهي ٿي.
        // جيڪڏھن اسان واقعي ملڪيت جي منتقلي ڪرڻ چاھيو ٿا ، اسان پنھنجو پاڻ لاءِ ھڪ اضافي ڪمزور پوائنٽر ٺاھي رھياسين ، پر اھو ضعيف جي حوالي سان ضعيف جي واڌاري جي نتيجي ۾ ٿيندو ، جيڪو شايد ٻي صورت ۾ ضروري ناھي.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // ھاڻي اسان صحيح طور تي اندروني قدر کي شروعاتي طور پيش ڪري سگھون ٿا ۽ پنھنجي ڪمزور حوالي کي مضبوط حوالن ۾ بدلائي سگھون ٿا.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // ڊيٽا فيلڊ ڏانهن مٿين لکڻ لازمي طور تي ڪنهن به موضوعن کي ظاهر ڪرڻ گهرجي جيڪي غير صفر مضبوط ڳڻپ جو مشاهدو ڪن.
            // تنهن ڪري اسان کي `compare_exchange_weak` کي `Weak::upgrade` سان هم وقت سازي ڪرڻ لاءِ گهٽ ۾ گهٽ "Release" آرڊر جي ضرورت آهي.
            //
            // "Acquire" آرڊر جي ضرورت ناھي.
            // جڏهن اسان `data_fn` جي ممڪن روين تي غور ڪندا ته اسان کي صرف اهو ڏسڻ جي ضرورت آهي ته اهو ڇا ٿي سگھي ٿو غير ترقي يافته `Weak` جي حوالي سان.
            //
            // - اهو *کلون* ايڪس ايڪس ايڪس ڪري سگهي ٿو ، ڪمزور حوالي جي ڳڻپ کي وڌائيندي.
            // - اهو ڪلون ڇڏائي سگھي ٿو ، ڪمزور حوالي واري انگ کي گهٽائيندي (پر صفر کي ڪڏهن به نه).
            //
            // اهي ضمني اثرات اسان تي ڪنهن به طرح اثر نٿا ڪن ، ۽ اڪيلو محفوظ اثرات اڪيلو محفوظ ڪوڊ سان ممڪن ناهن.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // مضبوط حوالن کي گڏيل طور تي حصيداري واري ڪمزور حوالي جو هئڻ گهرجي ، تنهنڪري اسان جي پراڻي ڪمزور ريفرنس کي تباهي وارو نه هلائڻو.
        //
        mem::forget(weak);
        strong
    }

    /// نئون `Arc` نئين شي ۾ بغير مواد جي ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// نئون `Arc` بنا ڪنهن گانڌي جي مواد سان گڏ ٺاهي ٿو ، ياداشت سان گڏ `0` بائٽس سان ڀريل.
    ///
    ///
    /// هن طريقي جي صحيح ۽ غلط استعمال جي مثالن لاءِ [`MaybeUninit::zeroed`][zeroed] ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// نئون `Pin<Arc<T>>` تعمير ڪندو آهي.
    /// جيڪڏهن `T` ايڪسڪسيمڪس کي لاڳو نٿو ڪري ، `data` ميموري ۾ پئجي ويندو ۽ منتقل ڪرڻ جي قابل ناهي.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// نئون `Arc<T>` تعمير ڪندو ، غلطي کي واپس آڻيندي جيڪڏهن مختص ناڪام ٿي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // ڪمزور پوائنٽر جي ڳڻپ شروع ڪريو 1 جي طور تي جيڪو ڪمزور پوائنٽر آھي جيڪو تمام مضبوط پوائنٽرس (kinda) جي طرفان رکيل آھي ، وڌيڪ forاڻ لاءِ std/rc.rs ڏسو
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// نئين `Arc` کي بغير ڪنهن شديد مواد سان گڏ ٺاهي ٿو ، هڪ غلطي موٽائي ٿو جيڪڏهن مختص ڪرڻ ناڪام ٿي وڃي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// نئين `Arc` کي بغير ڪنهن شديد ڪنٽينز سان تعمير ڪري ٿو ، ياداشت کي `0` بائٽس سان ڀريو پيو وڃي ، جيڪڏهن مختص ناڪام ٿي ته هڪ غلطي موٽائي ٿي.
    ///
    ///
    /// هن طريقي جي صحيح ۽ غلط استعمال جي مثالن لاءِ [`MaybeUninit::zeroed`][zeroed] ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// اندروني قيمت ڏي ٿو ، جيڪڏهن `Arc` وٽ ھڪڙو مضبوط ريفرنس آھي.
    ///
    /// ٻي صورت ۾ ، هڪ [`Err`] ساڳئي `Arc` سان واپس ڪئي وئي جنهن ۾ گذري ويو.
    ///
    ///
    /// اها ڪامياب هوندي به انهي جي باوجود موجود آهن ڪمزور حوالو
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // معتبر مضبوط-ڪمزور حوالي کي صاف ڪرڻ لاءِ ڪمزور پوائنٽر ٺاهيو
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// اڻ ترتيب ٿيل مواد سان گڏ هڪ نئين ايٽمي حوالي سان ڳڻپيل سليڪس ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// نئون ايٽمڪ حوالو شمار ٿيل ٽُڪ بنا ڪنهن اڻٿڪ مواد سان گڏ ٺاهي ٿو ، ياداشت کي `0` بائٽس سان ڀرجي پيو.
    ///
    ///
    /// هن طريقي جي صحيح ۽ غلط استعمال جي مثالن لاءِ [`MaybeUninit::zeroed`][zeroed] ڏسو.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` ۾ تبديل ڪندو آهي.
    ///
    /// # Safety
    ///
    /// جيئن [`MaybeUninit::assume_init`] سان ، اهو ڪالڪر تي منحصر هوندو آهي ته اها ضمانت ڏيان ته اندروني قدر واقعي ابتدائي حالت ۾ آهي.
    ///
    /// انهي کي ڪال ڪندي جڏهن مواد اڃا مڪمل طور تي ابتدائي نه ڪيو وڃي فوري طور تي اڻ سڌريل رويو ٺاهيندي.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` ۾ تبديل ڪندو آهي.
    ///
    /// # Safety
    ///
    /// جيئن [`MaybeUninit::assume_init`] سان ، اهو ڪالڪر تي منحصر هوندو آهي ته اها ضمانت ڏيان ته اندروني قدر واقعي ابتدائي حالت ۾ آهي.
    ///
    /// انهي کي ڪال ڪندي جڏهن مواد اڃا مڪمل طور تي ابتدائي نه ڪيو وڃي فوري طور تي اڻ سڌريل رويو ٺاهيندي.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // شروع ٿيل شروعات:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// `Arc` کي کائيندو آھي ، واپسي وارين پوائنٽ کي واپس ڪندي.
    ///
    /// هڪ ياداشت جي رسائي کان بچڻ لاءِ پوائنٽر [`Arc::from_raw`] کي واپس `Arc` ۾ واپس ڪرڻ گهرجي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ڊيٽا کي خام پوائنٽر فراهم ڪندو آهي.
    ///
    /// ڳڻپ ڪنهن به طريقي سان متاثر نه ٿيون آهن ۽ ايڪس ايڪس اين ايڪس استعمال نه ڪيو ويو آهي.
    /// پوائنٽر صحيح آھي جيستائين ايستائين `Arc` ۾ مضبوط ڳڻپ آھن.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // حفاظت: اهو ايڪسسيڪس يا ايڪس 0 X ذريعي نٿو وڃي سگهي ڇاڪاڻ ته
        // اهو raw/mut ثابت ڪرڻ کي برقرار رکڻ جي ضرورت آهي ، مثال طور
        // `get_mut` ايڪس آرڪس ذريعي آر سي کي وصولي کانپوءِ پوائنٽر ذريعي لکي سگھي ٿو.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// هڪ خام پوائنٽر کان `Arc<T>` ٺاهي ٿو.
    ///
    /// خام پوائنٽر [`Arc<U>::into_raw`][into_raw] کي ڪال کان اڳ ۾ واپس ڪيو ويو هجي جتي `U` وٽ `T` وانگر ساڳيو سائيز ۽ ترتيب هجڻ لازمي آهي.
    /// اهو خاص طور تي صحيح آهي جيڪڏهن `U` `T` آهي.
    /// ياد رکو ته جيڪڏهن `U` `T` نه آهي پر ساڳئي سائيز ۽ ترتيب آهي ، اهو بنيادي طور تي مختلف قسمن جي حوالن جي منتقلي وانگر آهي.
    /// هن معاملي ۾ ڪهڙي پابنديون لاڳو آهن ان بابت وڌيڪ معلومات لاءِ [`mem::transmute`][transmute] ڏسو.
    ///
    /// `from_raw` جي استعمال ڪندڙ کي ان ڳالهه کي يقيني بڻائڻو آهي ته `T` جي هڪ خاص قيمت صرف هڪ ڀيرو droppedري وئي آهي.
    ///
    /// اهو فنڪشن غير محفوظ آهي ڇاڪاڻ ته غلط استعمال ميموري غير محفوظ ٿي سگھي ٿو ، ايستائين جيڪڏهن واپس ڪيل `Arc<T>` کي ڪڏهن به رسائي نه ڏني وئي آهي.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // لڪي کي روڪڻ لاءِ `Arc` ڏانهن واپس تبديل ڪريو.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` ڏانهن وڌيڪ ڪال ياداشت غير محفوظ هوندي
    /// }
    ///
    /// // ياداشت کي آزاد ڪيو ويو جڏهن `x` مٿي ڏنل حد کان ٻاهر ٿي ويو ، تنهن ڪري `x_ptr` هاڻي نچائي رهي آهي!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // اصل ArcInner کي ڳولھڻ لاءِ آفسيٽ کي ريورس ڪريو.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// هن مختص ڪرڻ ۾ هڪ نئون [`Weak`] پوائنٽر ٺاهي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // اهو آرام سان ٺيڪ آهي ڇاڪاڻ ته اسان هيٺ ڏنل CAS ۾ قيمت چيڪ ڪري رهيا آهيون.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // چڪاس ڪريو ته ضعيف انسداد في الحال "locked" آھي ؛جيڪڏهن ائين آهي ، سپن.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: اهو ڪوڊ في الحال اوور فلو جي امڪان کي نظرانداز ڪري ٿو
            // usize::MAX ۾؛عام طور تي آر سي ۽ آرڪ ٻنهي کي اوور فلو سان منهن ڏيڻ لاءِ ترتيب ڏيڻ جي ضرورت آهي.
            //

            // Clone() سان گڏ ، اسان کي ايڪسڪسيمڪس کان اچڻ واري لکڻين سان هم وقت سازي لاءِ هڪ درست پڙهيو ٿيڻ جي ضرورت آهي ، انهي لکڻ کان پهريان جا واقعا انهي پڙهڻ کان اڳ ۾ ٿين ٿا.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // پڪ ڪريو ته اسان هڪ ڊنگنگو ڪمزور نه بڻايون ٿا
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// انهي مختص ڪرڻ لاءِ [`Weak`] پوائنٽرن جو تعداد حاصل ڪري ٿو.
    ///
    /// # Safety
    ///
    /// اهو طريقو پنهنجو پاڻ کي محفوظ آهي ، پر ان کي صحيح طور تي استعمال ڪرڻ اضافي خيال جي ضرورت آهي.
    /// ٻيو سلسلو ڪنهن به وقت ڪمزور ڳڻپ کي تبديل ڪري سگهي ٿو ، امڪاني طور تي هن طريقي کي سڏڻ ۽ نتيجي تي عمل ڪرڻ جي وچ ۾.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // اهو جزا يقيناتي آهي ڇاڪاڻ ته اسان موضوعن جي وچ ۾ `Arc` يا `Weak` حصيداري نه ڪيو آهي.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // جيڪڏھن ضعيف ڳڻپ ھن وقت بند آھي ، لاڪ کڻڻ کان صرف ڳڻپ جي قيمت 0 ھئي.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// انهي مختص ڪرڻ ۾ مضبوط (`Arc`) پوائنٽرن جو تعداد حاصل ڪري ٿو.
    ///
    /// # Safety
    ///
    /// اهو طريقو پنهنجو پاڻ کي محفوظ آهي ، پر ان کي صحيح طور تي استعمال ڪرڻ اضافي خيال جي ضرورت آهي.
    /// ٻيو ڪنارو مضبوط ڳڻپ کي ڪنهن به وقت تبديل ڪري سگهي ٿو ، جنهن ۾ ممڪن آهي ته انهي طريقي کي سڏڻ ۽ نتيجي تي عمل ڪرڻ جي وچ ۾.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // اهو جزا يقيناتي آهي ڇاڪاڻ ته اسان موضوعن جي وچ ۾ `Arc` حصيداري نه ڪيو آهي.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// ھڪڙي پاران فراهم ڪيل پوائنٽر سان ڳن theيل `Arc<T>` تي مضبوط ريفرنس ڳڻپ کي وڌائيندو آھي.
    ///
    /// # Safety
    ///
    /// پوائنٽر `Arc::into_raw` ذريعي حاصل ڪرڻ گھرجي ، ۽ لاڳاپيل `Arc` مثال صحيح هجڻ گھرجي (يعني
    /// هن طريقي جي عرصي لاءِ مضبوط ڳڻپ گهٽ ۾ گهٽ 1 هجڻ گهرجي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // اهو جزا يقيناتي آهي ڇاڪاڻ ته اسان موضوعن جي وچ ۾ `Arc` حصيداري نه ڪيو آهي.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // آرڪ کي برقرار رکو ، پر دستي طور تي ڊراپ ۾ لفٽ ڪندي ٻيهر ڳڻتي کي نه ڇهو
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // ھاڻي ريفنڪوٽ وڌايو ، پر نئون ريفرنڪ به نه ڇڏيو
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// ھڪڙي پاران فراهم ڪيل پوائنٽر سان لاڳاپيل `Arc<T>` تي مضبوط ريفرنس ڳڻپ کي رد ڪري ٿو.
    ///
    /// # Safety
    ///
    /// پوائنٽر `Arc::into_raw` ذريعي حاصل ڪرڻ گھرجي ، ۽ لاڳاپيل `Arc` مثال صحيح هجڻ گھرجي (يعني
    /// انهي طاقت کي گهٽ ۾ گهٽ 1 ٿيڻ گهرجي.
    /// هن طريقي سان استعمال ٿي سگهي ٿي فائنل `Arc` کي ڇڏڻ ۽ اسٽوري جي ڪوششن کي ، پر **کي** نه سڏڻ گهرجي کان پوءِ فائنل `Arc` جاري ٿيڻ کان پوءِ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // اهي جزا يقيناتي آهن ڇو ته اسان موضوعن جي وچ ۾ `Arc` حصيداري نه ڪيو آهي.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // هي غير محفوظ آهي ٺيڪ آهي ڇاڪاڻ ته جڏهن اها آرڪ زنده آهي اسان گارنٽي آهيون ته اندروني پوائنٽر صحيح آهي.
        // وڌيڪ ، اسان thatاڻون ٿا ته `ArcInner` itselfانچي خود `Sync` آھي ڇو ته اندريون ڊيٽا `Sync` پڻ آھي ، تنھنڪري اسان ان مواد تي ھڪڙي غير منقول پوائنٽر کي قرض ڏيڻ وارا آھيون.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop` جو غير منقسم حصو.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // ھن وقت ڊيٽا کي برباد ڪريو ، جيتوڻيڪ اسين شايد باڪس کي مختص ڪري آزاد نه ڪري سگھون (اتي اڃا تائين ھيٺيون ڪمزور اشارو ڪندڙ آھن).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // سڀني مضبوط حوالن سان اجتماعي طور تي ڪمزور کي رد ڪريو
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// ايڪس آرڪس کي واپسي ڏئي ٿوجيڪڏهن "آرڪ" هڪ ئي الاٽمنٽ ڏانهن اشارو ڪيو آهي ([`ptr::eq`] وانگر هڪ رٻ ۾).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// ھڪڙي `ArcInner<T>` کي ڪافي جڳھ سان ممڪن جڳھ جي غير معين ٿيل قيمت جي لاءِ مختص ڪري ٿو جتي ويليو کي ترتيب ڏنل آھي.
    ///
    /// فنڪشن `mem_to_arcinner` ڊيٽا پوائنٽر سان سڏيو ويندو آهي ۽ `ArcInner<T>` لاءِ (ممڪن طور تي ٿڌي) پوينٽر واپس موٽڻ لازمي آهي.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // حساب سان حساب لڳايو حساب سان ڏنل ڏنل ترتيب استعمال ڪندي.
        // اڳيئي ، ترتيب `&*(ptr as* const ArcInner<T>)` ايڪسپريس تي ڳڻيو ويو ، پر هن غلط ترتيب ڏنل ريفرنس تيار ڪيو (#54908 ڏسو).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// ھڪڙي `ArcInner<T>` کي ڪافي جڳھ سان ممڪن طور تي غير محفوظ ٿيل اندروني قدر جي برابر ڪري ٿو جتي قدر کي ترتيب ڏنل آھي ، ھڪڙي خرابي واپس ڪندي جيڪڏھن مختص ناڪاميء۔
    ///
    ///
    /// فنڪشن `mem_to_arcinner` ڊيٽا پوائنٽر سان سڏيو ويندو آهي ۽ `ArcInner<T>` لاءِ (ممڪن طور تي ٿڌي) پوينٽر واپس موٽڻ لازمي آهي.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // حساب سان حساب لڳايو حساب سان ڏنل ڏنل ترتيب استعمال ڪندي.
        // اڳيئي ، ترتيب `&*(ptr as* const ArcInner<T>)` ايڪسپريس تي ڳڻيو ويو ، پر هن غلط ترتيب ڏنل ريفرنس تيار ڪيو (#54908 ڏسو).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner کي شروعاتي ڪريو
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// ھڪڙي `ArcInner<T>` ھڪڙي جڳھ واري وسعت جي لاءِ مناسب جڳھ کي مختص ڪري ٿو.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // ڏنل قيمت استعمال ڪندي `ArcInner<T>` لاءِ مختص ڪريو.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // بائيٽ وانگر قدر نقل ڪريو
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // ان جي مواد کي ڇڏي ڏيڻ کانسواءِ مختص خالي ڪيو
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// ڏنل ايڪسائيٽ سان هڪ `ArcInner<[T]>` مختص ڪري ٿو.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// سلائس کان عناصر کي نقل ڪيو ويو مختص ٿيل آرڪ <\[T\]> ۾
    ///
    /// غير محفوظ آهي ڇاڪاڻ ته ڪال ڪندڙ کي لازمي طور تي ملڪيت رکڻ گهرجي يا `T: Copy` کي پابند ڪرڻ گهرجي.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// ايٽرٽر کان `Arc<[T]>` ٺاهي ٿو ھڪڙي خاص سائز جي ڪري سڃاتو وڃي ٿو.
    ///
    /// رويي غلط بيان ڪيو وڃي سائيز کي غلط ٿيڻ گھرجي.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic گارڊ ٽي عناصر تي کلون ڪندي.
        // panic جي صورت ۾ ، اهي عناصر جيڪي نئين آرڪ اندرينر ۾ لکيا ويا آهن ، ڇڏيو ويندو ، پوءِ يادگيري آزاد ٿي وئي.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // پهرين عنصر ڏانهن اشارو ڪندڙ
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // سڀ صاف.محافظ کي وساري ڇڏجو اهو نئون آرڪInner کي آزاد نٿو ڪري.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// `From<&[T]>` لاءِ استعمال ٿيل خصوصيزيشن trait.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` پوائنٽر جي ڪلون ٺاهيندو آهي.
    ///
    /// اهو هڪ ٻئي پوائنٽ کي ساڳيو مختص ڪري ٿو ، مضبوط حوالو ڳڻپ کي وڌائيندي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // آرام واري ترتيب استعمال ڪرڻ هتي ٺيڪ آهي ، جيئن اصل حوالن جو علم ٻين تحريرن کي غلط طريقي سان شي کي ختم ڪرڻ کان روڪي.
        //
        // جيئن [Boost documentation][1] ۾ وضاحت ڪئي وئي آهي ، حوالو جي ڪڙي کي وڌائڻ ميموري_ آرڊر_ رليڪسڊ سان هميشه ڪري سگهجي ٿو: هڪ اعتراض جا نوان حوالا صرف هڪ موجوده ريفرنس مان ٺهي سگهجن ٿا ، ۽ موجوده ريفرنس کي هڪ ڪنڊي کان ٻئي ڏانهن منتقل ڪرڻ کان پهريان ئي ڪنهن گهربل گهربل هم وقت سازي فراهم ڪرڻ لازمي آهي.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // تنهن هوندي اسان کي وڏي تعداد ۾ محافظن جي حفاظت ڪرڻ جي ضرورت آهي جيڪڏهن ڪنهن کي ياد آهي آرڪ کي وسارڻ.
        // جيڪڏهن اسان اهو نٿا ڪريون ته ڳڻپ وڌي سگهي ٿي ۽ صارف مفت استعمال ڪندا.
        // اسان نسل تي `isize::MAX` کي انهي تصور تي يقين رکيو ٿا ته ~2 بلين سلسلا نه آهن هڪ ئي وقت حوالن جي ڳڻپ ۾ اضافو ڪرڻ.
        //
        // اهو branch ڪڏهن به ڪنهن حقيقي پروگرام ۾ ورتو ويندو.
        //
        // اسان ختم ڪيو ٿا ڇاڪاڻ ته اهڙو پروگرام ناقابل يقين حد تائين خراب آهي ، ۽ اسان ان کي سهارو ڏيڻ جي پرواهه نٿا ڪريون.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// ڏنل `Arc` ۾ هڪ قابل تبديلي حوالو ڏئي ٿو.
    ///
    /// جيڪڏهن ٻئي `Arc` يا [`Weak`] ساڳيا مختص ڪيل اشارو آهن ، ته پوءِ `make_mut` نئين مختص ٺاهيندو ۽ انوکي مالڪ کي يقيني بڻائڻ لاءِ اندرئين قيمت تي [`clone`][clone] کي سڏيندو.
    /// انهي کي ڪلون آن لکڻ جو پڻ حوالو ڏنو ويندو آهي.
    ///
    /// ياد رکجو ته اهو [`Rc::make_mut`] جي رويي کان مختلف آهي جيڪو باقي بچيل `Weak` پوائنٽرن کي ڌار ڪري ٿو.
    ///
    /// [`get_mut`][get_mut] کي به ڏسندا ، جيڪو ڪلون ڪرڻ بدران ناڪام ٿي ويندا.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // ڪجھ به کلون نه ٿيندس
    /// let mut other_data = Arc::clone(&data); // اندروني ڊيٽا کلون نه ٿيندو
    /// *Arc::make_mut(&mut data) += 1;         // کلون اندروني ڊيٽا کي
    /// *Arc::make_mut(&mut data) += 1;         // ڪجھ به کلون نه ٿيندس
    /// *Arc::make_mut(&mut other_data) *= 2;   // ڪجھ به کلون نه ٿيندس
    ///
    /// // هاڻي `data` ۽ `other_data` مختلف مختصن ڏانهن اشارو ڪن ٿا.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // نوٽ ڪريو ته اسان ٻنهي جو مضبوط حوالو ۽ هڪ ڪمزور حوالو رکون ٿا.
        // اهڙيءَ طرح ، اسان جو مضبوط حوالو ڇڏڻ صرف نه ، پاڻ نه ڇڏيندي ، يادداشت کي خالي ڪرڻ جو سبب بڻجندا.
        //
        // استعمال ڪرڻ کي يقيني بڻائڻ لاءِ ايڪڪ استعمال ڪريو ته اسان ڏسو `weak` ڏانهن جيڪو به رائٽس لکڻ کان اڳ ۾ ٿئي ٿو (يعني ، ايڪسچينج) `strong`.
        // جئين اسان ڪمزور ڳڻتي ڪئي آهي ، ڪو به موقعو ڪونه آهي ته آرڪ اندر پاڻ ان کي نيڪالي نه ڏئي سگهيو آهي.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // هڪ ٻيو مضبوط اشارو ڏيندڙ موجود آهي ، تنهن ڪري اسان کي کلون ڪرڻ گهرجن.
            // اڳ-مختص ٿيل ياداشت کي ڪلون ويل جي قيمت سڌي طرح لکڻ جي اجازت ڏي.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // مٿي ڏنل آرام سان ڪافي آهي ڇو ته بنيادي طور تي هڪ اصلاح آهي: اسان هميشه ڪمزور پوائنٽن سان بيهڻ جي ڊوڙ ڪري رهيا آهيون.
            // بدترين ڪيس ، اسان آخرڪار هڪ نئون آرڪ مختص ڪيو.
            //

            // اسان آخري مضبوط ريفورٽ کي ڪ removedي ڇڏيو ، پر هتي اضافي ڪمزور ريفورڊ موجود آهن.
            // اسان مواد کي نئين آرڪ ڏانهن منتقل ڪنداسين ، ۽ ٻين ڪمزور ريفريجز کي باطل ڪري ڇڏينداسين.
            //

            // ياد رکجو ته `weak` پڙھڻ ممڪن ناهي usize::MAX پيدا ڪرڻ (يعني ، لاڪ ڪريو) ، ڇاڪاڻ ته ڪمزور ڳڻپ فقط مضبوط حوالي سان ڏنڊ سان بند ڪري سگھجي ٿي.
            //
            //

            // اسان جي وجهندڙ ڪمزور پوائنٽر کي مواد ڏيو ، ته جيئن هو ضرورتن مطابق ArcInner کي صاف ڪري سگهي.
            //
            let _weak = Weak { ptr: this.ptr };

            // صرف ڊيٽا چوري ڪري سگهندو آهي ، اهو سڀ ڪجهه ڇڏي ويو وڪي ٿو
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // اسان ٻنهي قسمن جو واحد حوالو هو ؛مضبوط ريفري ڳڻپ کي واپس وٺو.
            //
            this.inner().strong.store(1, Release);
        }

        // جئين `get_mut()` سان ، غير محفوظيت ٺيڪ آهي ڇاڪاڻ ته اسان جو حوالو يا تو شروع کان منفرد هو ، يا مواد کي ڪلون ڪرڻ تي هڪ ٿيو.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// ڏنل `Arc` ۾ هڪ متغير حوالو ڏئي ٿو ، جيڪڏهن ٻئي `Arc` يا [`Weak`] ٻئي ساڳيا مختص ڪرڻ وارا نه آهن.
    ///
    ///
    /// [`None`] ٻي صورت ڏي ٿو ، ڇاڪاڻ ته اھو ھڪڙي مشترڪ قدر کي مٽائڻ لاءِ محفوظ ناھي.
    ///
    /// [`make_mut`][make_mut] پڻ ڏسو ، جيڪو [`clone`][clone] اندروني قدر ڪندو جڏهن ٻيا اشارو ڪندڙ آهن.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // هي غير محفوظ آهي ٺيڪ آهي ڇاڪاڻ ته اسان جي ضمانت آهي ته واپس ڪيل نشان *صرف* پوائنٽر آهي جيڪو ڪڏهن به ٽي کي واپس ڪيو ويندو.
            // اسان جو حوالو نمبر 1 تائين محفوظ ٿيڻ جي گارنٽي آهي ، ۽ اسان کي آرڪ جي پاڻ کي `mut` ٿيڻ جي ضرورت آهي ، تنهن ڪري اسان اندروني ڊيٽا جو واحد ممڪن حوالو واپس ڪري رهيا آهيون.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// ڏنل چيڪ `Arc` ۾ ھڪ قابل تبديل ريفرنس واپس ڏئي ٿو ، بغير ڪنھن چڪاس جي.
    ///
    /// [`get_mut`] پڻ ڏسندا ، جيڪو محفوظ آهي ۽ مناسب چيڪ ڪندو آهي.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// ڪنهن ٻئي `Arc` يا [`Weak`] ساڳين مختصرن ڏانهن اشارو موٽائي قرض جي مدت لاءِ ان کي رد نه ڪيو وڃي.
    ///
    /// اهو عام طور تي ڪيس آهي جيڪڏهن اهڙا اشارو نه موجود آهن ، مثال طور فوري طور تي `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // اسان محتاط آھيون *نه*"count" فيلڊ کي coveringڪڻ واري حوالي سان ، جئين اھو عرفي حوالن جي ڳڻپ تائين ھلندڙ رسائي سان (مثال طور)
        // `Weak` کان).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// اهو معلوم ڪريو ته ڇا اهو بي خانداني ڊيٽا جو منفرد حوالو آهي.
    ///
    ///
    /// نوٽ ڪيو ته ھيءَ ضرورت آھي ڪمزور ريف جي ڳڻپ کي بند ڪرڻ.
    fn is_unique(&mut self) -> bool {
        // ڪمزور پوائنٽر جي ڳڻپ کي لاڪ ڪريو جيڪڏهن اسان اڪيلو ڪمزور پوائنٽر هولڊر ڏسندا.
        //
        // حاصل ڪرڻ وارو ليبل هتي `strong` (خاص طور تي `Weak::upgrade`) جي ڪنهن به لکن سان واقع ٿيڻ کان اڳ واري تعلق کي يقيني بڻائي ٿو. `weak` ڳڻپ کان اڳ (`Weak::drop` ذريعي ، جيڪو رليز استعمال ڪري ٿو).
        // جيڪڏهن اپ گريڊ جو ڪمزور ريف ڪڏهن به نه ڇڏيو ويو ، هتي سي اي ايس ناڪام ٿي ويندو تنهن ڪري اسان کي هم وقت سازي جي پرواهه ناهي.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // ھن کي `drop` ۾ `strong` جي مقابلي جي گھٽتائي سان هم وقت سازي جي ضرورت آھي `drop`-ھڪڙو واحد رسائي جيڪو ٿئي ٿو ، پر ڪنھن جو به آخري حوالو ڇڏيو پيو وڃي.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // جاري ٿيل لکڻ هتي `downgrade` ۾ هڪ پڙهڻ سان هم وقت سازي ڪري ٿو ، مؤثر طور تي `strong` جي مٿين پڙهڻ کي لکڻ کانپوءِ روانگي ٿيڻ کان روڪيو.
            //
            //
            self.inner().weak.store(1, Release); // لاڪ کي ڇڏيو
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` کي ڊراپس ٿو.
    ///
    /// اھو مضبوط ريفرنس ڳڻپ کي ختم ڪندو.
    /// جيڪڏهن مضبوط ريفرنس ڳڻپ صفر تائين پهچي ٿي ته صرف واحد حوالو (جيڪڏهن ڪو به) [`Weak`] آهي ته پوءِ اسان `drop` اندرئين قيمت.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // ڇا نه ڇا ڇپجي؟
    /// drop(foo2);   // "dropped!" پرنٽ ڪري ٿو
    /// ```
    #[inline]
    fn drop(&mut self) {
        // ڇاڪاڻ ته `fetch_sub` اڳ ۾ ئي ايٽمي آهي ، اسان کي ٻين موضوعن سان هم وقت سازي ڪرڻ جي ضرورت ناهي ، جيستائين اسان اعتراض کي ختم ڪرڻ وارا نه آهيون.
        // اهو ئي منطق `fetch_sub` جي هيٺ ڏنل نمبر `fetch_sub` تي لاڳو ٿئي ٿو.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // انهي باءِ کي استعمال جي بحالي ۽ ڊيٽا جي خارج ٿيڻ کي روڪڻ جي ضرورت آهي.
        // ڇاڪاڻ ته اهو `Release` سان نشان لڳل آهي ، حوالن جي گهٽتائي جي گهٽتائي هن `Acquire` باءِ سان.
        // هن جو مطلب آهي ته ڊيٽا جو استعمال ريفرنس جي ڳڻپ کي گهٽائڻ کان اڳ ٿئي ٿو ، جيڪو هن باهه جي اڳيان ٿيندو آهي ، جيڪو ڊيٽا جي خارج ٿيڻ کان اڳ ٿيندو آهي.
        //
        // جيئن [Boost documentation][1] ۾ بيان ڪيو ويو آهي ،
        //
        // > هڪڙي ۾ اعتراض جي هر ممڪن رسائي کي لاڳو ڪرڻ ضروري آهي
        // > سلسلي کي (هڪ موجوده ريفرنس ذريعي)*ختم ٿيڻ کان اڳ* ٿيڻ لاءِ
        // > شيءِ کي مختلف سلسلي ۾.اهو حاصل ڪري ٿو "release"
        // > آپريشن هڪ ريفرنس ڪ dropڻ کان پوءِ (ڪا به شيءَ تائين رسائي
        // > انهي حوالي سان واضح طور تي اڳ ۾ ٿيڻ ضروري آهي) ، ۽ هڪ
        // > "acquire" اعتراض ختم ڪرڻ کان پهريان آپريشن.
        //
        // خاص طور تي ، جڏهن ته هڪ آرڪ جي مواد عام طور تي بي نقاب هوندي آهي ، اهو ممڪن آهي ته ڪجهه اندرين بابت ڪجهه اهو ب ا<T>.
        // کان وٺي هڪ ميٽڪس حاصل نه ڪيو ويو آهي جڏهن اهو حذف ٿي ويو آهي ، اسان ان جي هم وقت سازي واري منطق تي ڀروسو نٿا ڪري سگهون ته انهي سلسلي ۾ لکڻ جي لاءِ اي جي سلسلي بي ۾ هلندڙ تباهي ڏانهن ڏٺو ويو آهي.
        //
        //
        // اهو به ياد رهو ته هتي پهاڪي وارو باهه شايد هڪ ايڪيويڊ لوڊ سان مٽائي سگهجي ، جيڪو انتهائي متضاد حالتن ۾ ڪارڪردگي بهتر ڪري سگهي.[2] ڏسو.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` کي ڪنڪريٽ قسم مان ختم ڪرڻ جي ڪوشش ڪئي وئي آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// نئين يادداشت کي مختص ڪرڻ کان بغير نئون `Weak<T>` ٺاهي ٿو.
    /// واپسي جي قيمت تي [`upgrade`] کي ڪال ڪري هميشه [`None`] ڏئي ٿي.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// ڊيٽا جي فيلڊ بابت ڪا به makingاڻ ڏيڻ کان بغير حوالن جي ڳڻپ تائين رسائي جي اجازت ڏيڻ ۾ مددگار قسم.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// انهي کي `Weak<T>` ڏانهن اشارو ڪيو ويو x01X ڏانهن خام پوائنٽر واپس ڏئي ٿو.
    ///
    /// پوائنٽر صرف انهي صورت ۾ صحيح آهي جڏهن ڪجهه مضبوط حوالا آهن.
    /// پوائنٽر ڊنگنگ ، غير قطار يا ايستائين [`null`] ٻي صورت ۾ ٿي سگھي ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // ٻئي ساڳئي اعتراض ڏانهن اشارو ڪن ٿا
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // مضبوط هتي ئي ان کي زنده رکندو آهي ، تنهن ڪري اسان اعتراض تائين اڃا تائين رسائي ڪري سگهون ٿا.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // پر وڌيڪ نه.
    /// // اسان weak.as_ptr() ڪري سگھو ٿا ، پر پوائنٽر تائين پھچندي اڻ inedاتل رويي جي طرف ايندي.
    /// // assert_eq! ("هيلو" ، غير محفوظ {&*weak.as_ptr() }) ؛
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // جيڪڏھن اشارو ڪري رھيو آھي ، اسان رئيس کي سڌو سنئون موٽون ٿا.
            // اهو صحيح پيلو لوڊ پتي نه ٿو ٿي سگهي ، جئين پيڪ لوڊ گهٽ ۾ گهٽ آرڪينر (usize) جي مطابق مطابق آهي.
            ptr as *const T
        } else {
            // حفاظتي: جيڪڏهن آهي_ڏڻ غلط returnsري ٿو ، ته پوائنٽر قابل قابل آهي.
            // پائو لوڊ هن نقطي ۾ گهٽجي سگهي ٿو ، ۽ اسان کي ثابتگي قائم رکڻي آهي ، انهي ڪري خام پوائنٽر جي چرپر جو استعمال ڪريو.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` کي کائيندو آھي ۽ ان کي خام پوائنٽر ۾ تبديل ڪري ٿو.
    ///
    /// اهو ڪمزور پوائنٽر کي خام پوائنٽر ۾ تبديل ڪري ٿو ، جڏهن ته اڃا تائين هڪڙي ڪمزور حوالي جي ملڪيت کي محفوظ ڪري ٿو (ڪمزور ڳڻتي هن آپريشن ذريعي تبديل ٿيل نه آهي).
    /// ان کي `Weak<T>` سان `Weak<T>` ۾ واپس ڪري سگهجي ٿو.
    ///
    /// پوائنٽر جي ھدف تائين پھچڻ تي جيتري پابنديون آھن [`as_ptr`] سان لاڳو ٿين ٿيون.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// اڳ ۾ ئي [`into_raw`] ٺاهيل هڪ خام پوائنٽر کي `Weak<T>` ۾ بدلائي ٿو.
    ///
    /// اهو محفوظ طور تي مضبوط حوالو حاصل ڪرڻ لاءِ ([`upgrade`] سڏڻ بعد) استعمال ڪري سگهجي ٿو يا `Weak<T>` کي byٽو ڪندي ضعيف ڳڻپ کي ختم ڪرڻ لاءِ.
    ///
    /// اهو هڪ ڪمزور ريفرنس جي ملڪيت وٺندو آهي ([`new`] ٺاهيل پوائنٽرن جي استثنا سان ، جيئن ته اهي ڪجهه به نٿا رکن ؛ اهو طريقو اڃا تائين انهن تي ڪم ڪري ٿو).
    ///
    /// # Safety
    ///
    /// پوائنٽر [`into_raw`] کان وٺي پيدا ٿيڻ گھرجي ۽ اڃا تائين ان جي امڪاني ڪمزور ريفريش جو ضرور هجڻ گھرجي.
    ///
    /// انهي جي ڪال ڪرڻ وقت مضبوط ڳڻپ جي 0 هجڻ جي اجازت آهي.
    /// بهرحال ، هي هڪ ڪمزور ريفرنس جي ملڪيت هن وقت خام پوائنٽر جي نمائندگي ڪري ٿو (ضعيف شمار هن آپريشن سان تبديل ٿيل نه آهي) ۽ تنهن ڪري ان کي [`into_raw`] ڏانهن هڪ پوئين ڪال سان ضرور جوڙيو وڃي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // آخري ڪمزور ڳڻتي کي ختم ڪرڻ.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ايڪس پي ايڪس ڏسو تناظر لاءِ ته ڪيئن انپٽ پوائنٽر نڪتل آهي.

        let ptr = if is_dangling(ptr as *mut T) {
            // ھي ھڪڙو ٻرندڙ ڪمزور آھي.
            ptr as *mut ArcInner<T>
        } else {
            // ٻي صورت ۾ ، اسان پڪ ڪيون ٿا پوائنٽر نانگنگيل ڪمزور کان آيو آهي.
            // SAFETY: ڊيٽا_ آف سيٽ ڪال ڪرڻ لاءِ محفوظ آهي ، جيئن پيٽر اصل جو حوالو ڏيندو آهي (ممڪن طور تي ڪٽيل) ٽي.
            let offset = unsafe { data_offset(ptr) };
            // ان ڪري ، اسان کي مڪمل آر سي بوڪس حاصل ڪرڻ لاءِ آفسيٽ رد ڪريو ٿا.
            // حفاظت: پوائنٽر ڪمزور طور تي پيدا ٿيو آهي ، تنهنڪري هي آف سيٽ محفوظ آهي.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // حفاظت: اسان هاڻ اصل ڪمزور پوائنٽر کي بحال ڪيو آهي ، تنهنڪري ڪمزور پيدا ڪري سگهون ٿا.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` پوائنٽر کي [`Arc`] کي اپ گريڊ ڪرڻ جي ڪوشش ، اندرون ويل قيمت وڃائڻ ۾ دير ٿيڻ جي صورت ۾.
    ///
    ///
    /// [`None`] جي واپسي ڏي ٿو جيڪڏھن اندرين قدر کان وٺي وئي ھجي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // تمام مضبوط اشارو ڏيندڙ کي تباهه ڪيو.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // اسين فيچ_اڊ ڊي بدران مضبوط ڳڻپ وڌائڻ لاءِ سي اي ايس لوپ استعمال ڪريون ٿا ڇاڪاڻ ته انهي فنڪشن کي ريفرنس جي ڳڻپ صفر کان ڪڏهن به وٺڻ نه گهرجي.
        //
        //
        let inner = self.inner()?;

        // آرام وارو لوڊ ڇاڪاڻ ته 0 جو ڪو به لکيو جيڪو اسان مشاهدو ڪري سگھو ٿا فيلڊ کي مستقل طور صفر حالت ۾ ڇڏي ٿو (تنهنڪري "stale" جو 0 پڙهو صحيح آهي) ، ۽ ڪنهن ٻئي جي قيمت هيٺ ڏنل سي اي ايس ذريعي تصديق ڪئي وڃي ٿي.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // `Arc::clone` ۾ تبصرا ڏسو ڇو اسين ائين ڪريون ٿا (`mem::forget` لاءِ).
            if n > MAX_REFCOUNT {
                abort();
            }

            // آرام ناڪامي جي ڪيس لاءِ ٺيڪ آهي ڇاڪاڻ ته اسان کي نئين رياست بابت ڪا اميد ناهي.
            // ڪاميابي جي ڪيس لاءِ ايڪس آرڪس سان هم وقت سازي لاءِ حاصل ڪرڻ ضروري آهي ، جڏهن `Weak` ريفرنس اڳيئي پيدا ٿيڻ کان پوءِ اندروني قدر شروع ٿي سگهي ٿي.
            // انهي صورت ۾ ، اسان توقع ڪئي ته مڪمل طور تي ابتدائي قدر جو مشاهدو ڪنداسين.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // خالي مٿي چيڪ ڪيو ويو
                Err(old) => n = old,
            }
        }
    }

    /// انهي مختص ڪرڻ ڏانهن اشارو ڪندڙ مضبوط (`Arc`) پوائنٽرن جو تعداد حاصل ڪري ٿو.
    ///
    /// جيڪڏهن `self` استعمال ڪيو ويو [`Weak::new`] ، اهو 0 واپس ڪندو.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// هن مختص ڏانهن اشارو ڪندي `Weak` پوائنٽرن جي تعداد جو اندازو لڳايو آهي.
    ///
    /// جيڪڏهن `self` استعمال ڪندي ٺاهي وئي [`Weak::new`] ، يا جيڪڏهن باقي ڪو مضبوط اشارو ڏيندڙ نه آهي ، اهو 0 موٽندو.
    ///
    /// # Accuracy
    ///
    /// عمل درآمد جي تفصيل جي ڪري ، واپسي قيمت ٻئي طرف کان 1 تائين بند ٿي سگهي ٿي جڏهن ٻيون سلسلا ساڳي ورهائڻ ڏانهن اشارو ڪندي ڪنهن به آرڪ يا `ڪمزور` جي هٿان کنيا ويندا آهن.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // جتان اسان ڏٺو آهي ته ڪمزور ڳڻپ پڙهڻ کان پوءِ گهٽ ۾ گهٽ هڪ مضبوط پوائنٽر هوندو هو ، اسان knowاڻون ٿا ته ڪمزور ظاهري حوالو (جڏهن به ڪو مضبوط حوالو زنده آهي) اڃا تڏهن به هو جڏهن اسان ڪمزور ڳڻپ جو مشاهدو ڪيو هو ، ۽ تنهن ڪري حفاظت سان ان کي گهٽائي سگهون ٿا.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// واپسي ڏئي `None` جڏهن پوائنٽر کي ڌڪڻ لڳي ٿو ۽ مختص ناهي `ArcInner` ، (يعني ، جڏهن هي `Weak` ٺاهي ويو `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // اسان محتاط آهيون *نه*"data" فيلڊ کي coveringڪڻ واري ريفرنس ٺاهڻ جي طور تي ، جئين فيلڊ کي گڏيل طور تي مٽايو وڃي (مثال طور ، جيڪڏهن آخري `Arc` کٽي ويندو ، ڊيٽا فيلڊ کي جڳهه ۾ ڇڏي ويندو).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `true` جي واپسي ڏي ٿو جيڪڏهن ٻن "ڪمزور" ساڳئي ايليگيشن ڏانهن اشارو ڪريو (جهڙوڪ [`ptr::eq`] وانگر) ، يا جيڪڏهن ٻئي ڪنهن مختص ڏانهن اشارو نه ٿا ڪن (ڇاڪاڻ ته اهي `Weak::new()`) سان ٺاهي رهيا آهن)
    ///
    ///
    /// # Notes
    ///
    /// جيئن ته هن پوائنٽرن جو مقابلو ڪيو ته ان جو مطلب اهو آهي ته `Weak::new()` هڪ ٻئي جي برابر ڪندو ، جيتوڻيڪ اهي ڪنهن به مختص جي نشاندهي نه ڪندا آهن.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` جي ڀيٽ ۾.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// `Weak` پوائنٽر جو کلون ٺاھيندو آھي جيڪي ھڪٻئي جي مختص ڪيل نقطي ڏانھن اشارو ڪن ٿا.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Arc::clone() ۾ تبصرا ڏسو ھن کي آرام ڇو آھي.
        // اهو fetch_add استعمال ڪري سگھي ٿو (لاڪ کي نظرانداز ڪرڻ) ڇاڪاڻ ته ڪمزور ڳڻپ صرف ان ۾ بند ٿيل آهي جتي *ٻي ڪا* ڪمزور وجود ۾ نه آهن.
        //
        // (انهي ڪري اسان انهي صورت ۾ هي ڪوڊ هلائي نٿا سگھون).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Arc::clone() ۾ تبصرا ڏسو ڇو اسين ائين ڪريون ٿا (mem::forget لاءِ).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// ياداشت کي مختص ڪرڻ کان بغير هڪ نئون `Weak<T>` تعمير ڪري ٿو.
    /// واپسي جي قيمت تي [`upgrade`] کي ڪال ڪري هميشه [`None`] ڏئي ٿي.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` پوائنٽر کي ٽو ڪري ٿو.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ڇا نه ڇا ڇپجي؟
    /// drop(foo);        // "dropped!" پرنٽ ڪري ٿو
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // جيڪڏهن اسان اهو معلوم ڪيو ته اسان آخري ڪمزور پوئينٽر هئا ، پوءِ هي وقت پوري طرح ڊيٽا کي نيڪالي ڪرڻ جو آهي.ڏسو يادگيري آرڊر بابت Arc::drop() ۾
        //
        // هتي لوڪل حالت کي جانچڻ ضروري ناهي ، ڇاڪاڻ ته ڪمزور ڳڻپ صرف تڏهن بند ٿي سگهي ٿي جيڪڏهن اڳ ۾ ئي هڪ ڪمزور ريفري رهي ٿي ، مطلب ته بوند بعد ۾ صرف انهي ضعيف ڪمزور ريف کي هلائي سگهي ٿي ، جيڪا صرف تالا ڇڏڻ جي بعد ٿي سگهي ٿي.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// اسان اهو خاصيت هتي ڪري رهيا آهيون ، ۽ نه `&T` تي وڌيڪ عام واڌاري جي طور تي ، ڇو ته ٻي صورت ۾ اهو سڀني مساوات جي چيڪ تي ريففش تي قيمت شامل ڪندو.
/// اسان اهو سمجهون ٿا ته آرڪ آرز وڏي قدر کي اسٽور ڪرڻ لاءِ استعمال ڪئي ويندي آهي ، جيڪي کلون کان سست آهن ، پر مساوات جي جاچ لاءِ پڻ وڏي آهن ، انهي جي قيمت وڌيڪ آساني سان ادا ڪرڻ جو سبب بڻيا آهن.
///
/// اهو پڻ ممڪن آهي ته ٻه `Arc` ڪلونون ، ساڳيا قدر ڏانهن اشارو ڪن ، ٻن ۽ ٽي جي ڀيٽ ۾.
///
/// اسان اهو صرف انهي وقت ڪري سگهون ٿا جڏهن `T: Eq` هڪ `PartialEq` طور تي شايد اڻ fاڻين طور تي.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// ٻن `آرڪ` لاءِ هڪجهڙائي.
    ///
    /// ٻه آرڪ برابر آهن جيڪڏهن انهن جي اندروني قيمتون برابر آهن ، جيتوڻيڪ اهي مختلف مختص ۾ محفوظ ٿيل آهن.
    ///
    /// جيڪڏهن `T` پڻ `Eq` لاڳو ڪري ٿو (مساوات جي اضطراب جو اظهار) ، ٻه "آرڪ" جيڪي هڪ ئي مختص ڪرڻ ڏانهن اشارو ڪن ٿا هميشه برابر آهن.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// ٻن "آرڪ" لاء عدم مساوات.
    ///
    /// ٻه `آرڪ` اڻ برابري وارا آهن جيڪڏهن انهن جي اندروني قدرون نه برابر هونديون آهن.
    ///
    /// جيڪڏهن `T` پڻ `Eq` لاڳو ڪري ٿو (مساوات جي اضطراب جو اظهار) ، ٻه "آرڪ" جيڪي ساڳئي قدر ڏانهن اشارو ڪن ٿا اهي ڪڏهن به غير مساوات نه هوندا.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// ٻن "آرڪ" جو جزوي مقابلو.
    ///
    /// انهن ٻنهي جي اندروني قدرن تي `partial_cmp()` سڏ ڪندي مقابلو ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// ٻه "آرڪ" لاء مقابلي کان گهٽ.
    ///
    /// انهن ٻنهي جي اندروني قدرن تي `<` سڏ ڪندي مقابلو ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'آرڪي` کان ٻه کان وڌيڪ' مقابلي کان گهٽ يا برابر.
    ///
    /// انهن ٻنهي جي اندروني قدرن تي `<=` سڏ ڪندي مقابلو ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// ٻن "آرڪز" جي مقابلي کان وڌيڪ وڏو.
    ///
    /// انهن ٻنهي جي اندروني قدرن تي `>` سڏ ڪندي مقابلو ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'آرڪ` کان ٻه کان وڌيڪ' مقابلي کان وڏي يا برابر.
    ///
    /// انهن ٻنهي جي اندروني قدرن تي `>=` سڏ ڪندي مقابلو ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// ٻن `آرڪ` لاءِ مقابلو.
    ///
    /// انهن ٻنهي جي اندروني قدرن تي `cmp()` سڏ ڪندي مقابلو ڪيو ويو آهي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// نئون `Arc<T>` ٺاهي ٿو ، `Default` قدر لاءِ `T` لاءِ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// هڪ حوالي ٿيل ڳڻپ ٿيل سلائس مختص ڪريو ۽ ان کي ڪل ڪريو `v` جون شيون کلڻ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// هڪ حوالي ڪيل ڳڻپيوڪر `str` مختص ڪريو ۽ ان ۾ `v` ڪاپي ڪريو.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// هڪ حوالي ڪيل ڳڻپيوڪر `str` مختص ڪريو ۽ ان ۾ `v` ڪاپي ڪريو.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// دٻي واري اعتراض کي نئين ، حوالي سان ڳڻتي واري ترتيب تي منتقل ڪيو.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// هڪ حوالي ڪيل ڳڻتي سلائس مختص ڪريو ۽ ان ۾ "وي" جون شيون منتقل ڪريو.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // وييڪ کي ان جي يادگيري کي آزاد ڪرڻ جي اجازت ڏيو ، پر ان جي مواد کي تباهه نه ڪريو
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator` ۾ هر عنصر گڏ ڪري ٿو ۽ ان کي `Arc<[T]>` ۾ گڏ ڪري ٿو.
    ///
    /// # ڪارڪردگي جون خاصيتون
    ///
    /// ## عام ڪيس
    ///
    /// عام حالتن ۾ ، `Arc<[T]>` ۾ گڏ ڪرڻ پهرين `Vec<T>` ۾ گڏ ڪرڻ سان ڪيو ويندو آهي.اھو آھي ، جڏھن ھيٺين لکڻ کي:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// اھو رويي ڪري ٿو weڻ اسان لکيو آھي:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // مختص ڪرڻ جو پهريون سيٽ هتي اچي ٿو.
    ///     .into(); // `Arc<[T]>` لاء هڪ ٻيو مختص هتي ٿيندو آهي.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// اهو `Vec<T>` تعمير ڪرڻ جي لاءِ جيترو وقت گهربل هجي مختص ڪندو ۽ پوءِ اهو `Vec<T>` کي `Arc<[T]>` ۾ بدلائڻ لاءِ هڪ ڀيرو مختص ڪندو.
    ///
    ///
    /// ## lengthاتل سڃاتل ڊيگهه
    ///
    /// جڏهن توهان جو `Iterator` `TrustedLen` لاڳو ڪندو ۽ صحيح سائيز جو آهي ، `Arc<[T]>` لاءِ هڪ واحد مختص ڪيو ويندو.مثال طور:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // صرف هڪ واحد مختص هتي ٿئي ٿو.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// `Arc<[T]>` ۾ گڏ ڪرڻ لاءِ اسپيشلائيزيشن trait استعمال ڪيو.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // اهو `TrustedLen` ايٽررٽر جي صورت آهي.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // حفاظت: اسان کي انهي ڳالهه کي يقيني بڻائڻ جي ضرورت آهي ته آئيرٽر جي صحيح ڊيگهه آهي ۽ اسان وٽ آهي.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // عام عمل درآمد ڏانھن واپس وڃو.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// ھڪڙي پوائنٽر جي پويان پائي لوڊ ڪرڻ لاء `ArcInner` اندر آفسيٽ حاصل ڪريو.
///
/// # Safety
///
/// پوائنٽر کي T جي اڳئين صحيح مثال جي لاءِ (۽ صحيح ميٽا ڊيٽا) ڏانهن اشارو ڪرڻ گهرجي ، پر T کي ڇڏڻ جي اجازت آهي.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // آرس انرر جي خاتمي تائين بغير ترتيب ڏنل قدر کي ترتيب ڏيو.
    // ڇاڪاڻ ته آر سي بوڪس ايڪس آرڪس آهي ، اهو ياد ۾ هميشه آخري فيلڊ هوندو.
    // حفاظت: ڇاڪاڻ ته صرف ممڪن طور تي اڻ typesاتل قسم سلائسون ، trait شيون ،
    // ۽ ٻاهرين قسمن ، انٽ حفاظت جي ضرورت موجوده وقت لاءِ ڪافي آهيهن ٻولي جي عمل درآمد جي تفصيل آهي جيڪا std کان ٻاهر انحصار نه ڪئي وڃي.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}