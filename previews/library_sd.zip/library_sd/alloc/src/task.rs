#![stable(feature = "wake_trait", since = "1.51.0")]
//! غير مطابقت وارا ڪم ڪرڻ لاءِ قسمون ۽ Z0 ٽڪريون 0 ز.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// هڪ جلاد تي ڪم جاڳڻ جو عمل.
///
/// هي trait ايڪس اين ايڪس ايڪس ٺاهڻ لاءِ استعمال ٿي سگهي ٿي.
/// هڪ عملدار هن trait تي عمل درآمد جو تعين ڪري سگهي ٿو ، ۽ هن کي استعمال ڪرڻ جي لاءِ واڪر جي تعمير ڪرڻ لاءِ استعمال ڪري سگهي ٿو جيڪي انهي جلاد تي عمل ڪيو وڃي ٿو.
///
/// ھي trait ھڪڙو ياداشت محفوظ ۽ ergonomic متبادل آھي ھڪڙو [`RawWaker`] تعمير ڪرڻ لاء.
/// اهو عام عملدار ڊزائين جي حمايت ڪري ٿو جنهن ۾ ڪم کي جاڳڻ لاءِ استعمال ڪيل ڊيٽا ايڪس اين ايڪس ايڪس ۾ ذخيرو ٿيل آهي.
/// ڪجهه عملدار (خاص طور تي انهن لاءِ جيڪو سرايت ٿيل سسٽم آهي) اهو API استعمال نٿا ڪري سگھن ، جنهن جي ڪري [`RawWaker`] انهن نظامن جي هڪ متبادل جي طور تي موجود آهي.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// هڪ بنيادي `block_on` فعل جيڪو future وٺندو آهي ۽ ان کي موجوده ڪنڊو تائين مڪمل ٿيڻ تي هلائي ٿو.
///
/// **Note:** اهو مثال سادگي لاءِ صحيح جي واپار ڪندو آهي.
/// بندن کي روڪڻ لاءِ ، پيداوار لاءِ اسٽيڊ پليس کي `thread::unpark` جي وچولي ڪالن سان گڏوگڏ جوڙيل ڌاڳن کي سنڀالڻ جي به ضرورت پوندي.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// هڪ ويڪر جيڪو موجوده ٺڳين کي جاڳائي ٿو جڏهن سڏيو وڃي ٿو.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// موجوده سلسلي تي مڪمل ڪرڻ لاءِ future هلايو.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future کي پن ڪيو جئين ان کي پول ڪيو وڃي.
///     let mut fut = Box::pin(fut);
///
///     // future ڏانهن پاس ٿيڻ لاءِ نئون حوالو ٺاهيو.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // هلائڻ لاء future هليو.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// هن ڪم کي کڻو.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// واڪر کي خرچ ڪرڻ کان بغير اهو ڪم ورجايو.
    ///
    /// جيڪڏهن ايگزيڪيوٽو ويکر کي استعمال ڪرڻ کان بغير جاڳڻ جي سستا طريقي جي مدد ڪري ٿو ، اهو هن طريقي کي ختم ڪرڻ گهرجي.
    /// ڊفالٽ طور ، اھو [`Arc`] کي کلون ٿو ۽ کلون تي [`wake`] سڏين ٿا.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // حفاظت: اهو محفوظ آهي ڇاڪاڻ ته خام_وار کي محفوظ طريقي سان تعمير ڪري ٿو
        // هڪ آر ويڪ آرڪ کان<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: اهو خانگي فنڪشن RawWaker تعمير ڪرڻ بدران استعمال ڪيو ويو آهي ، بجاءِ
// هن کي `From<Arc<W>> for RawWaker` impling ۾ داخل ڪرڻ ، يقيني بڻائڻ جي لاءِ `From<Arc<W>> for Waker` حفاظت trait صحيح تي ڀاڙين ٿا ، ان جي بدران ، ٻئي نقاط هن ڪم کي سڌو ۽ واضح طور تي ڪال ڪن ٿا.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // انهي کي کلائڻ لاءِ آرڪ جي ريفرنس جي ڳڻپ ۾ اضافو ٿيو.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // قيمت سان جاڳايو ، آرڪ کي Wake::wake فنڪشن ۾ منتقل ڪري رهيو آهي
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // حوالي سان جاڳايو ، اڇلائڻ کان بچڻ لاءِ ويڪر کي هٿرادو انداز ۾ و wrايو
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // بٽڻ تي آرڪ جي حوالي واري ڳڻپ کي گھٽائڻ
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}