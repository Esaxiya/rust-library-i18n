//! ميڪرو ليکڪ لاءِ هڪ سپورٽ لائبريري جڏهن نئين ميڪروز جي وضاحت ڪئي وڃي.
//!
//! معياري مواد ، معياري لائبريري طرفان مهيا ڪيل لائبريري ، طريقيڪار ـ ترتيب ڏنل ميڪرو بيانن جي انٽرفيس ۾ استعمال ٿيندڙ قسمن کي مهيا ڪن ٿيون ، جهڙوڪ فنڪشن جهڙو ميڪس `#[proc_macro]` ، ميڪرو خاصيتون `#[proc_macro_attribute]` ۽ ڪسٽم ڊريٽائيٽ وصفون##[proc_macro_derive] ".
//!
//!
//! وڌيڪ لاءِ [the book] ڏسو.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// اهو معلوم ڪري ٿو ته ڇا پروسي_ ماڪرو موجوده هلائيندڙ پروگرام تائين رسائي حاصل ڪئي وئي آهي.
///
/// proc_macro crate صرف ان طريقيڪار جي ميڪرو عملدرآمد جي اندر استعمال ڪرڻ جي مقصد آهي.crate panic ۾ سڀني ڪم جيڪڏهن پروسيٽيڪل ميڪرو کان ٻاهر سڏيا وڃن ، جهڙوڪ هڪ تعمير اسڪرپٽ يا يونٽ ٽيسٽ يا عام Rust بائنري.
///
/// Rust لائبريري جي غور سان ، جيڪي ميڪرو ۽ غير ميڪرو استعمال ٻنهي ڪيسن کي سپورٽ ڪرڻ لاءِ تيار ڪيون ويون آهن ، `proc_macro::is_available()` اهو پائڻ واري طريقي سان نه معلوم ڪرڻ لاءِ مهيا ڪري ٿو ته ڇا پراک_ مئڪرو جي اي پي آئي استعمال ڪرڻ لاءِ انفراسٽرڪچر في الحال موجود آهي.
/// صحيح واپسي واپس ڏئي ٿي جيڪڏهن پروسيسيڪل ميڪرو جي اندر کان سڏ ڪيو ويو هجي ، غلط جيڪڏهن ڪنهن ٻئي بائنري کان سڏيا وڃن.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// ھن crate پاران مهيا ڪيل اھم قسم ، tokens جي ھڪڙي خلاصي وهڪري جي نمائندگي ڪري ٿي ، يا ، خاص طور تي ، token وڻن جي تسلسل.
/// قسم انهن token وڻن جي ٻيهر ورڇ لاءِ انٽرنيٽ مهيا ڪندو آهي ۽ ، ٻئي طرف ، هڪ وهڪرو ۾ token وڻن جي تعداد گڏ ڪندي.
///
///
/// اهو ٻنهي `#[proc_macro]` ، `#[proc_macro_attribute]` ۽ `#[proc_macro_derive]` وصفن جي ان پٽ ۽ آئوٽ آهي.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` کان غلطي موٽي وئي.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// خالي `TokenStream` موٽائي ٿو جنھن ۾ ڪوبه token وڻ نه آھن.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// ڇا اهو `TokenStream` خالي آهي چيڪ ڪريو.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// اسسٽنٽ کي tokens ۾ پار ڪرڻ جي ڪوشش ڪئي ۽ tokens کي token وهڪرو ۾ پار ڪيو.
/// ڪيترن ئي سببن جي ڪري ناڪام ٿي سگھي ٿو ، مثال طور ، جيڪڏهن تار ٻولي ۾ غير متوازن حد بندي يا حرف موجود نه آهي.
///
/// بيان ڪيل وهڪرو ۾ سڀني tokens ايڪس اين ايم ايڪس اسپين حاصل ڪريو.
///
/// NOTE: ڪجهه غلطيون `LexError` موٽڻ بدران panics سبب ڪري سگھن ٿيون.اسان انهن غلطين کي بعد ۾ `LexError` ۾ تبديل ڪرڻ جو حق محفوظ رکون ٿا.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// اين بي ، پل صرف `to_string` مهيا ڪندو آهي ، ان تي ٻڌل `fmt::Display` لاڳو ڪريو (ٻنهي جي وچ ۾ معمولي تعلقن جي پٺڀرائي).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token وهڪرو کي هڪ اسٽرنگ جي طور تي پرنٽ ڪري ٿو جنهن لاءِ اهو ساڳيو ئي token وهڪرو (ماڊلولو اسپينس) ۾ تبديل ٿيندڙ طور تي واپس آڻڻ جي قابل سمجهيو وڃي ٿو ، سواء ممڪن طور تي "TokenTree: : گروپ" جي `Delimiter::None` حد ۽ منفي عددي لفظن سان.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ڊيبگ ڪرڻ لاءِ آسان فارم ۾ token پرنٽ ڪري ٿو.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// ھڪڙي token وڻ تي مشتمل token وهڪرو ٺاھي ٿو.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// ھڪڙي وهڪري ۾ ھڪڙي تعداد ۾ token وڻ گڏ ڪري رھيا آھن.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// هڪ "flattening" token وهڪرو تي ، ڪيترن ئي token وهڪرن کان token وڻ گڏ ڪري هڪ وهڪرو ۾.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) ھڪڙو ممڪن عمل درآمد if/when استعمال ڪريو ممڪن ڪريو.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// `TokenStream` قسم لاءِ عوامي عمل درآمد جا تفصيل ، جهڙوڪ ايٽررٽر.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// هڪ ٽوڪن اسٽريم جي ٽوڪن ٽيريز تي.
    /// انٽيشن "shallow" آهي ، مثال طور ، اهو ايٽريٽر ممنوع گروپن ۾ نه ورجائيندو آهي ، ۽ س groupsي گروهه کي token وڻ ڏئي ٿو.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` ثالث tokens کي قبول ڪري ٿو ۽ انڪس کي بيان ڪندي `TokenStream` تائين وڌايو.
/// مثال طور ، `quote!(a + b)` هڪ اظهار پيدا ڪندو ، اهو ، جڏهن جائزو ورتو ويو ، `TokenStream` `[Ident("a") ، Punct('+', Alone) تعمير ڪندو ، Ident("b")]`.
///
///
/// نڪتو جاري ڪرڻ `$` سان ڪيو ويو آهي ، ۽ واحد ايندڙ شناخت کي ڪم ڪندڙ اصطلاح جي طور تي ڪم ڪري ٿو.
/// `$` پاڻ کي چوڻي ڏيڻ لاءِ ، ايڪس ايڪس ايڪس استعمال ڪريو.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// ماخذ ڪوڊ جي هڪ علائقي ، ميڪرو وسعت جي alongاڻ سان گڏ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// اسپان ايڪس `self` تي ڏنل `message` سان نئون `Diagnostic` ٺاھيندو آھي.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// هڪ دائرو جيڪو حل ڪري ٿو ميڪرو جي تعريف واري سائيٽ تي.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// موجوده طريقيڪار وارين ميڪرو جي درخواست جو دائرو.
    /// ھن اسپان سان ٺاھيل سڃاڻيندڙ حل ڪيا ويندا ifڻ ته اھي سڌو ميڪو ڪال مقام تي لکيا وڃن (ڪال سائيٽ ھائيگان) ۽ ميڪو ڪال سائيٽ تي ٻيا ڪوڊ پڻ انھن جو حوالو ڏئي سگھندا.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// هڪ دائرو جيڪو `macro_rules` حفظان صحت جي نمائندگي ڪندو آهي ، ۽ ڪڏهن ڪڏهن ميڪرو ڊيفينيشن سائيٽ (مقامي ڪيبليوز ، ليبلز ، `$crate`) ۽ ڪڏهن ڪڏهن ميڪرو ڪال سائيٽ تي (سڀ ڪجهه سڀ).
    ///
    /// اسپان مقام ڪال واري سائيٽ کان ورتو ويو آهي.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// اصلي ماخذ فائل جنهن ۾ هي نشان ڏي.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// ھن `Span` لاءِ tokens پوئين ميڪرو توسيع کان جنھن جي ذريعي `self` ٺاھيو ويو ، جيڪڏھن ڪو.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// اصل ماخذ ڪوڊ لاءِ اسپان جيڪو `self` ٺاهيو ويو هو.
    /// جيڪڏهن اهو `Span` ٻين ميڪرو وسعتن مان پيدا نه ٿيو هو ، ته واپسي جي قيمت `*self` وانگر ئي آهي.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// ھن اسپين جي منڊل فائل ۾ شروعاتي line/column حاصل ڪري ٿي.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// ھن اسپين لاءِ ماخذ فائل ۾ ختم ڪندڙ line/column حاصل ڪري ٿو.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` ۽ `other` تي مشتمل هڪ نئون اسپين ٺاهي ٿو.
    ///
    /// `None` کي واپسي ڏئي ٿو جيڪڏھن `self` ۽ `other` مختلف فائلن کان آھن.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` سان گڏ ساڳي line/column informationاڻ سان گڏ هڪ نئون اسپان ٺاهي ٿو پر اهو نشان حل ڪندو آهي thoughڻ ته اهو `other` تي هو.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// ھڪڙو نئون اسپان ٺاھي ٿو ھڪڙي ساڳي نالي ريڪارڊ جي رويي سان `self` پر line/column معلومات جي `other` سان گڏ.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// اسپين جي نسبت ڏسڻ لاءِ ته اهي برابر آهن.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// ماخذ وارو متن واپسيءَ جي پويان ڏيکاري ٿو.
    /// اهو اصل ماخذ ڪوڊ بچائيندو آهي ، بشمول جڳهن ۽ تبصرا.
    /// صرف اهو نتيجو موٽندو آهي جيڪڏهن اسپان واقعي سورس ڪوڊ سان ملندو آهي.
    ///
    /// Note: ميڪرو جو مشاهدو نتيجو فقط tokens تي ڀروسو ڪرڻ گهرجي ۽ نه هن ماخذ متن تي.
    ///
    /// انهي فنڪشن جو نتيجو بهتر ڪوشش آهي صرف استعمال ڪيل تشخيص لاءِ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// ڊيبگ ڪرڻ لاءِ آسان فارم ۾ ھڪڙو مادو پرنٽ ڪندو آھي.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// ھڪڙي لڪير وارو جوڙو ھڪڙي `Span` جي شروعات يا آخر جي نمائندگي ڪري ٿو.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// سورس فائل ۾ 1 انڊيڪس لائين جنهن تي اسپان (inclusive) شروع ٿئي ٿي يا ختم ٿئي ٿي.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// 0-انڊيڪس ڪالم (UTF-8 اکرن ۾) سورس فائل ۾ جنهن تي اسپان (inclusive) شروع ٿئي ٿي يا ختم ٿئي ٿي.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// ڏنل `Span` جو ذريعو فائيل.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// ھن ذريعن واري فائيل ڏانھن رستو حاصل ڪري ٿو.
    ///
    /// ### Note
    /// جيڪڏهن هن `SourceFile` سان لاڳاپيل ڪوڊ اسپين خارجي ميڪرو ذريعي ٺاهيا ويا ، هي ميڪرو ، هي شايد جئين فائيل سسٽم تي حقيقي رستو نه هوندو.
    /// چيڪ ڪرڻ لاءِ [`is_real`] استعمال ڪريو.
    ///
    /// اهو به ياد رکجو ته جيتوڻيڪ `is_real` `true` موٽائي ٿو ، جيڪڏهن `--remap-path-prefix` ڪمانڊ لائن تي پاس ٿئي ها ، ڏنل رستو اصل ۾ صحيح ناهي.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// `true` جي واپسي ڏي ٿو جيڪڏهن هي ماخذ فائل هڪ حقيقي ماخذ فائل آهي ، ۽ نه ٻاهرين ميڪرو جي توسيع طرفان.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // هي هيڪ آهي جيستائين بينڪ اسپرن تي عملدرآمد نه ڪيو وڃي ۽ اسان وٽ ٻاهرين ميڪروز ۾ پيدا ڪيل اسپانن لاءِ حقيقي ذريعا فائلون هجن.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// ھڪڙي token يا ھڪڙي token وڻ جي محدود تسلسل (مثال طور ، `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// هڪ token وهڪرو بریکٹ جي حدن جي چوڌاري گهيرو ڪيو.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// هڪ سڃاڻيندڙ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// هڪ واحد نقطي وارو ڪردار ("+" ، `,` ، `$` ، وغيره).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// هڪ لفظي ڪردار (`'a'`) ، اسٽرنگ (`"hello"`) ، نمبر (`2.3`) ، وغيره.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// ھن وڻ جي دائري واپس آڻيندي ، موجود token يا X محدود ٿيل وهڪرو جي `span` طريقي جي ترتيب ڏي.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// صرف ھن token * لاءِ span کي کنيل ڪري ٿو.
    ///
    /// نوٽ ڪريو ته جيڪڏهن هي token هڪ `Group` آهي ته اهو طريقو اندروني tokens جي هر هڪ کي ترتيب نه ڏيندو ، اهو صرف هر قسم جي `set_span` طريقي سان ترتيب ڏيندو.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// ڊيبگ ڪرڻ لاءِ آسان فارم ۾ token وڻ ڇپائي ٿو.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // انهن مان هر هڪ نڪتل ڊيبگ ۾ ساخت واري قسم جو نالو آهي ، تنهنڪري هدايت جي اضافي پرت سان تنگ نه ڪيو
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// اين بي ، پل صرف `to_string` مهيا ڪندو آهي ، ان تي ٻڌل `fmt::Display` لاڳو ڪريو (ٻنهي جي وچ ۾ معمولي تعلقن جي پٺڀرائي).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token وڻ کي تار جي طور تي پرنٽ ڪري ٿو جئين اهو ساڳيو token وڻ ۾ موٽيل convertيرائڻ وارو آهي (ماڊلو اسپينس) ، ممڪن طور تي "ٽوڪن ٽيٽ": `Delimiter::None` حد بندي ۽ منفي عددي اکرن سان.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ختم ٿيل token وهڪرو.
///
/// هڪ `Group` اندروني طور تي هڪ `TokenStream` شامل آهي جيڪو `ڊيلميٽر` جي چوڌاري آهي.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// وضاحت ڪري ٿو ته token وڻ جي تسلسل کي ڪيئن محدود ڪيو ويو آهي.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// هڪ بي مثال حد بندي ڪندڙ ، جيڪو شايد ، مثال طور ، X01Tokens0Z جي ڀرسان ظاهر ٿئي ٿو "macro variable" `$var`.
    /// ايڪس01ڪس وانگر ڪيسن ۾ آپريٽر جي ترجيحن کي محفوظ ڪرڻ ضروري آهي جتي `$var` `1 + 2` آهي.
    /// بي ترتيب حد بندي ڪندڙ token وهڪرو جي هڪ تار ذريعي گاري واريون نه بچي سگهندا آهن.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// ڏنل حد بندي ۽ token وهڪرو سان نئون `Group` ٺاهي ٿو.
    ///
    /// اهو ٺاهيندڙ هن گروپ جي لاءِ ايڪس ويڪس ايڪس تائين مقرر ڪندو.
    /// اسپين کي تبديل ڪرڻ لاءِ توهان هيٺ ڏنل `set_span` طريقو استعمال ڪري سگهو ٿا.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// هن `Group` جي حد بندي کي واپس ڏئي ٿو
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// tokens جو `TokenStream` واپسي ڏيندو آھي جيڪي ھن `Group` ۾ محدود ٿيل آھن.
    ///
    /// نوٽ ڪيو ته موٽي token وهڪرو شامل ناهي ختم ٿيل حد مٿي.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// هن token وهڪرو جي حد بندي ڪرڻ وارن لاءِ واپسي ڏيکاري ٿو ، پوري `Group` تي.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ھن گروپ جي افتتاحي حد کي اشارو ڪندي واپس موٽائي ٿو۔
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// ھن گروپ کي ختم ڪرڻ واري حد کي اشارو ڪندي واپس موٽائي ٿو۔
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// ھن گروپ جي حد بندي ڪرڻ وارن کي ختم ڪري ٿو ، پر ان جي اندروني tokens نه.
    ///
    /// اھو طريقو ** ھن گروپ جي طرفان وھندڙ سڀني اندروني tokens جي اسپين کي بيان نه ڪندو ، بلڪ اھو صرف `Group` جي سطح تي حد بندي tokens کي مقرر ڪندو.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// اين بي ، پل صرف `to_string` مهيا ڪندو آهي ، ان تي ٻڌل `fmt::Display` لاڳو ڪريو (ٻنهي جي وچ ۾ معمولي تعلقن جي پٺڀرائي).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// گروپ کي اسٽرنگ وانگر پرنٽ ڪري ٿو جيڪو نقصان جي بغير ساڳيو گروپ ۾ تبديل ٿيڻ گهرجي (ماڊلو اسپانس) ، سواء ممڪن طور تي "ٽوڪن ٽريڪ: : گروپ" جي `Delimiter::None` ڊيلميٽرن سان.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// ھڪڙي `Punct` ھڪڙي ھڪڙي صفائي وارو ڪردار آھي `+` ، `-` يا `#`.
///
/// `+=` وانگر گهڻن ڪردارن جا آپريٽر `Punct` جي ٻن مثالن جي طور تي نمائندگي ڪيا ويا آهن `Spacing` جي مختلف شڪلن سان واپس ايندا آهن.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// آيا هڪ `Punct` ٻئي `Punct` جي پٺيان فوري طور تي يا ٻئي token يا وائيٽ اسپيس جي پٺيان آهي.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// مثال طور ، `+` `+ =` ، `+ident` يا `+()` ۾ `Alone` آهي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// مثال طور ، `+` `+=` يا `'#` ۾ `Joint` آهي.
    /// اضافي طور تي ، هڪڙو اقتباس `'` سڃاڻپ ڪندڙ سان گڏ شامل ڪري سگهي ٿو ايڪس بيڪس `'ident` ٺاهڻ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// ڏنل ڪردار ۽ اسپيڊنگ تان نئون `Punct` ٺاهي ٿو.
    /// `ch` دليل لازمي طور تي ٻولي طرفان اجازت ڏنل صحيح اوقاف واري ڪردار هجڻ گهرجي ، ٻي صورت ۾ اهو ڪم panic هوندو.
    ///
    /// واپس ڪيل `Punct` ۾ `Span::call_site()` جو ڊفالٽ اسپان هوندو جيڪو `set_span` هيٺ ڏنل طريقي سان وڌيڪ ترتيب ڏئي سگھجي ٿو.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// هن پنڪچر واري ڪردار جي قيمت کي `char` طور ڏيکاري ٿو.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// انهي پنڪچر جي ڪردار جي جاءِ کي واپسي ڏي ٿي ، انهي ڳالهه جو اشارو ڏئي ٿو ته ڇا اهو فوري طور تي token وهڪرو ۾ ٻئي `Punct` جي پٺيان آهي ، تنهن ڪري اهي امڪاني طور تي گھڻائي ڪردار آپريٽر (`Joint`) ۾ گڏ ڪري سگهجن ٿيون ، يا اهو ڪنهن ٻئي token يا وائيٽ اسپيس (`Alone`) جي پٺيان آهي ، تنهن ڪري آپريٽر کي يقيناَ ختم ٿي ويو.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// ھن پنڪچر واري ڪردار لاءِ اسپان کي واپس ڪري ٿو.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ھن پنڪچر واري ڪردار لاءِ اسپان کي ترتيب ڏيو.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// اين بي ، پل صرف `to_string` مهيا ڪندو آهي ، ان تي ٻڌل `fmt::Display` لاڳو ڪريو (ٻنهي جي وچ ۾ معمولي تعلقن جي پٺڀرائي).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// پرنٽ جي ڪردار کي ھڪڙي تار وانگر پرنٽ ڪري ٿو جيڪا نقصان جي بغير ھڪ ئي ڪردار ۾ تبديل ٿيڻ گھرجي.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// هڪ سڃاڻيندڙ (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// ڏنل `string` سان گڏ ڏنل `span` سان گڏ ھڪ نئون `Ident` ٺاھيندو آھي.
    /// `string` دليل لازمي طور تي ٻولي طرفان اجازت ڏنل صحيح سڃاڻپ ڪندڙ هجڻ گهرجي (بشمول ڪيٻي لفظ ، مثال طور `self` يا `fn`).ٻي صورت ۾ ، فنڪشن panic هوندو.
    ///
    /// نوٽ ڪريو `span` ، ھن وقت rustc ۾ ، ھن سڃاڻڻ واري جي حفظان صحت جي معلومات کي ترتيب ڏئي ٿو.
    ///
    /// ھن وقت تائين `Span::call_site()` واضح طور تي "call-site" حفظ ۾ شامل ٿيو مطلب ته ھن اسپان سان ٺاھيل سڃاڻ ڪندڙ حل ڪيا ويندا ifڻ ته اهي ميڪو ڪال جي مقام تي سڌو سنئون لکيا ويا ھجن ، ۽ ميڪرو ڪال سائيٽ تي ٻيا ڪوڊ حوالي ڪري سگھندا. انهن پڻ
    ///
    ///
    /// بعد ۾ اسپان وانگر `Span::def_site()` "definition-site" حفظان صحت کي آپٽ ڪرڻ جي اجازت ڏين ٿا مطلب ته هن span سان ٺاهيل شناخت وارا ميڪرو ڊيفنس جي جڳهه تي حل ڪيا ويندا ۽ ميڪو ڪال سائيٽ تي ٻيا ڪوڊ انهن جي حوالي ڪرڻ جي قابل نه هوندا.
    ///
    /// حفظان صحت جي موجوده اهميت جي ڪري ، هن تعمير ڪندڙ ، ٻين tokens جي برعڪس ، تعمير تي مخصوص ٿيڻ جي لاءِ `Span` جي ضرورت هوندي آهي.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// ساڳيو `Ident::new` ، پر خام شناخت ڪندڙ (`r#ident`) ٺاهي ٿو.
    /// `string` دليل ٻولي طرفان اجازت ڏنل هڪ صحيح سڃاڻيندڙ (الفاظ سميت ، مثال طور `fn`).
    /// لفظ جيڪي رستن جي ڀا segن ۾ قابل استعمال هوندا آهن (مثال طور
    /// `self`, "سپر" سپورٽ ناھي ، ۽ ھڪڙو panic سبب ڪندو.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// ھن `Ident` جي مدت کي واپسي ڏئي ٿي ، [`to_string`](Self::to_string) پاران واپس ڪيل پوري س stringڻ کي گھمائيندي.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ھن `Ident` جي عرصي کي ترتيب ڏئي ٿو ، ممڪن طور تي پنھنجي حفظان صحت واري نقطي کي تبديل ڪندي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// اين بي ، پل صرف `to_string` مهيا ڪندو آهي ، ان تي ٻڌل `fmt::Display` لاڳو ڪريو (ٻنهي جي وچ ۾ معمولي تعلقن جي پٺڀرائي).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ھڪڙي شناخت ڪندڙ کي ھڪڙي تار وانگر پرنٽ ڪري ٿو جيڪو نقصان جي بغير ٻئي کي ھڪ ئي سڃاڻيندڙ ۾ تبديل ڪرڻ گھرجي.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// هڪ لفظي اسٽرنگ (`"hello"`) ، بائيٽ اسٽرنگ (`b"hello"`) ، ڪردار (`'a'`) ، بائيٽ جي ڪردار (`b'a'`) ، هڪ انٽيگر يا سچل پوائنٽ نمبر سان بغير يا فيڪسڪس ("1" ، `1u8` ، `2.3` ، `2.3f32`)
///
/// بولين جو لفظ جهڙو `true` ۽ `false` هتي سان واسطو نٿو رکن ، اهي آهن 'شناخت'.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// valueاڻيل قدر سان گڏ هڪ نئين ڪافي انجيڪر لفظ ٺاهي ٿو.
        ///
        /// اهو فنڪشن ايڪس ري وانگر هڪ عدد ٺاهيندو جتي بيان ڪيل انوگر قدر token جو پهريون حصو آهي ۽ انضمام به آخر ۾ لافاني آهي.
        /// منفي انگ مان ٺاهيل ادب شايد `TokenStream` يا سٽرنگ ذريعي گول دورو نه بچن ۽ ٻن tokens (`-` ۽ مثبت لفظي) ۾ ٽٽي وڃن.
        ///
        ///
        /// هن طريقي ذريعي ٺاهيل لکتون `Span::call_site()` اسپين کي ڊفالٽ سان ترتيب ڏين ٿيون ، جيڪي هيٺ ڏنل `set_span` طريقي سان ترتيب ڏئي سگهجن ٿيون.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// valueاڻيل قدر سان هڪ نئون اڻ مڪمل انٽيگرل لفاظي ٺاهي ٿو.
        ///
        /// اهو فنڪشن `1` وانگر انٽيگر ٺاهيندو جتي بيان ڪيل انوگر قدر token جو پهريون حصو آهي.
        /// هن token تي ڪو حتمي بيان نه ڪيو ويو آهي ، مطلب ته `Literal::i8_unsuffixed(1)` وانگر دعوت ناما `Literal::u32_unsuffixed(1)` جي برابر آهن.
        /// منفي انگن اکرن مان ٺهيل لکتون R00rips کان بچيل نه رهن ٿيون `TokenStream` يا اسٽرنگز ۽ شايد ٽٽي سگهجي ٿو tokens (`-` ۽ مثبت لفظي).
        ///
        ///
        /// هن طريقي ذريعي ٺاهيل لکتون `Span::call_site()` اسپين کي ڊفالٽ سان ترتيب ڏين ٿيون ، جيڪي هيٺ ڏنل `set_span` طريقي سان ترتيب ڏئي سگهجن ٿيون.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// هڪ نئون اڻixedاتل سچل نقطي معنيٰ ٺاهي ٿو.
    ///
    /// اهو تعمير ڪندڙ ساڳيو آهي `Literal::i8_unsuffixed` جتي فليٽ جي ويليو سڌو token ۾ خارج ٿيل آهي پر ڪو به لافانيه استعمال نه ٿيو آهي ، تنهن ڪري ان کي بعد ۾ مرتب ڪندڙ `f64` سمجهيو وڃي ٿو.
    ///
    /// منفي انگن اکرن مان ٺهيل لکتون R00rips کان بچيل نه رهن ٿيون `TokenStream` يا اسٽرنگز ۽ شايد ٽٽي سگهجي ٿو tokens (`-` ۽ مثبت لفظي).
    ///
    /// # Panics
    ///
    /// انهي فنڪشن جي ضرورت هوندي آهي ته مقرر ٿيل فلوٽ فني آهي ، مثال طور جيڪڏهن اها لامحدود آهي يا اين جي اها فنڪشن panic ٿي ويندي.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// هڪ نئون ڪافي سچل سچل پوائنٽ ٺاهي ٿو.
    ///
    /// اهو ٺاهيندڙ ، ايڪس ويڪس وانگر لفظي ٺاهي ٿو جتي بيان ڪيل قدر token جو اڳيون حصو آهي ۽ `f32` token جو لاحقہ آهي.
    /// اهو token هميشه ترتيب ڏني ويندي ، `f32` مرتب ڪندڙ ۾.
    /// منفي انگن اکرن مان ٺهيل لکتون R00rips کان بچيل نه رهن ٿيون `TokenStream` يا اسٽرنگز ۽ شايد ٽٽي سگهجي ٿو tokens (`-` ۽ مثبت لفظي).
    ///
    ///
    /// # Panics
    ///
    /// انهي فنڪشن جي ضرورت هوندي آهي ته مقرر ٿيل فلوٽ فني آهي ، مثال طور جيڪڏهن اها لامحدود آهي يا اين جي اها فنڪشن panic ٿي ويندي.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// هڪ نئون اڻixedاتل سچل نقطي معنيٰ ٺاهي ٿو.
    ///
    /// اهو تعمير ڪندڙ ساڳيو آهي `Literal::i8_unsuffixed` جتي فليٽ جي ويليو سڌو token ۾ خارج ٿيل آهي پر ڪو به لافانيه استعمال نه ٿيو آهي ، تنهن ڪري ان کي بعد ۾ مرتب ڪندڙ `f64` سمجهيو وڃي ٿو.
    ///
    /// منفي انگن اکرن مان ٺهيل لکتون R00rips کان بچيل نه رهن ٿيون `TokenStream` يا اسٽرنگز ۽ شايد ٽٽي سگهجي ٿو tokens (`-` ۽ مثبت لفظي).
    ///
    /// # Panics
    ///
    /// انهي فنڪشن جي ضرورت هوندي آهي ته مقرر ٿيل فلوٽ فني آهي ، مثال طور جيڪڏهن اها لامحدود آهي يا اين جي اها فنڪشن panic ٿي ويندي.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// هڪ نئون ڪافي سچل سچل پوائنٽ ٺاهي ٿو.
    ///
    /// اهو ٺاهيندڙ ، ايڪس ويڪس وانگر لفظي ٺاهي ٿو جتي بيان ڪيل قدر token جو اڳيون حصو آهي ۽ `f64` token جو لاحقہ آهي.
    /// اهو token هميشه ترتيب ڏني ويندي ، `f64` مرتب ڪندڙ ۾.
    /// منفي انگن اکرن مان ٺهيل لکتون R00rips کان بچيل نه رهن ٿيون `TokenStream` يا اسٽرنگز ۽ شايد ٽٽي سگهجي ٿو tokens (`-` ۽ مثبت لفظي).
    ///
    ///
    /// # Panics
    ///
    /// انهي فنڪشن جي ضرورت هوندي آهي ته مقرر ٿيل فلوٽ فني آهي ، مثال طور جيڪڏهن اها لامحدود آهي يا اين جي اها فنڪشن panic ٿي ويندي.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// اسٽرنگ لفظي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// حرفي لفظي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// بائيٽ اسٽرنگ لفظي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// انهي لفظي کي شامل ڪندي اسپان واپس ڏئي ٿو.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ھن لفظي سان لاڳاپيل مھرباني کي ترتيب ڏيو.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `Span` ھڪڙي واپسي آھي جيڪا `self.span()` جو ھڪڙو ذيلي حصو آھي ، صرف `range` رينج ۾ صرف بائيٽ بٽس شامل آھن.
    /// جيڪڏهن `self` جي حد کان ٻاهر هجي ها ته نن beا ننmedا دورا ٿين ها.
    ///
    // FIXME(SergioBenitez): چيڪ ڪريو ته بائيٽ رينج سورس جي UTF-8 حد تي شروع ۽ ختم ٿئي ٿي.
    // ٻي صورت ۾ ، اهو ممڪن آهي ته panic ٻئي هنڌ تي واقع ٿيندو جڏهن ماخذ متن ڇپيل هجي.
    // FIXME(SergioBenitez): هتي صارف لاءِ اهو toاڻڻ جو ڪو رستو ناهي ته `self.span()` اصل ۾ ڇا نقشا ڪندو آهي ، تنهنڪري اهو طريقو في الحال صرف انڌي پن کي سڏيو وڃي ٿو.
    // مثال طور ، `to_string()` ڪردار لاءِ 'c' واپسي "'\u{63}'" ؛هتي صارف کي wayاڻڻ جو ڪو طريقو ناهي ته ڇا ذريعو وارو متن 'c' هوندو هو يا ڇا اهو '\u{63}' هو.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) ڪا شيءِ `Option::cloned` جهڙي آهي ، پر `Bound<&T>` لاءِ.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// اين بي ، پل صرف `to_string` مهيا ڪندو آهي ، ان تي ٻڌل `fmt::Display` لاڳو ڪريو (ٻنهي جي وچ ۾ معمولي تعلقن جي پٺڀرائي).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ھڪڙي طرح ھڪڙي جڳھ جي طور تي پرنٽ ڪري ٿو جنھن کي بغير نقصان جي sameيرائڻ واري ساڳي ئي لفظي ۾ واپس ھئڻ گھرجي (سواءِ فلوٽنگ پوائنٽ جي لفظي گول جي ممڪن)
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// ماحول جي متغيرات تائين پهچيل رستو.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// ماحول واري ڪيفيت حاصل ڪريو ۽ ان کي شامل ڪريو انحصار جي buildاڻ ٺاهڻ.
    /// بلڊ سسٽم کي مرتب ڪندڙ اهو willاڻيندو ته تغير پذير جي عرصي دوران رسائي ڪئي وئي ، ۽ ان عمارت کي ٻيهر هلائڻ جي قابل ٿي ويندا جڏهن ان متغير جي قدر بدلجي ويندي.
    ///
    /// ڀروسي کي باخبر رکڻ سان گڏ اهو ڪم معياري لائبريري کان `env::var` جي برابر هجڻ گهرجي ، انهي کان سواء دليل ضرور UTF-8 هجڻ گهرجي.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}