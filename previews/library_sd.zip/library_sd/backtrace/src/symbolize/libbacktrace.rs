//! libbacktrace ۾ DWARF-parsing code استعمال ڪندي علامتي حڪمت عملي.
//!
//! لائيبٽ سي سي لائبريري ، خاص طور تي gcc سان ورهائبو آهي ، نه رڳو پٺتي ٺاهڻ (جيڪو اسان اصل ۾ استعمال نه ڪندا آهيون) جي سپورٽ ڪندا آهيون ، پر ان بشمول شين ۽ انهن بابت شين بابت بونا ڊيبگ ڊيبگ معلومات کي ڪنٽرول ڪرڻ ۽ ان کي ڪنٽرول ڪرڻ جي سگهه ڪندا آهن.
//!
//!
//! اهو هتي ڪيترن ئي خدشات جي ڪري نسبتاً پيچيده آهي ، پر بنيادي خيال اهو آهي:
//!
//! * پهرين اسان `backtrace_syminfo` کي سڏ ڪريون ٿا.هي متحرڪ علامت جي جدول مان علامت جي معلومات حاصل ڪري ٿو جيڪڏهن اسان ڪري سگهون ٿا.
//! * اڳيون اسان `backtrace_pcinfo` کي سڏ ڪيو.اهو ڊيبگينفو جدولن جي وضاحت ڪندو جيڪڏهن اهي موجود آهن ۽ اسان کي ان لائن فريم ، فائلن جا نالا ، لائن نمبر وغيره بابت معلومات بحال ڪرڻ جي اجازت ڏين ٿا.
//!
//! بونڊ ٽيبل کي لائيبريري ٽرڪس ۾ آڻڻ بابت تمام گهڻي ڇڪتاڻ آهي ، پر اميد آهي ته اها دنيا جي پڇاڙي ناهي ۽ جڏهن پڙهي هيٺ ڪافي واضح آهي.
//!
//! اهو غير ايم ايس وي سي ۽ غير او ايس ايڪس پليٽ فارمن جي ڊفالٽ علامتي حڪمت عملي آهي.لبرڊ ۾ جيتوڻيڪ او ايس ايڪس لاءِ اها رٿيل حڪمت عملي آهي.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // جيڪڏهن ممڪن هجي ته `function` نالي کي ترجيح ڏين جيڪو ڊيبگينفو کان اچي ٿو ۽ خاص طور تي ان لائن فريمز لاءِ وڌيڪ صحيح ٿي سگهي ٿو.
                // جيڪڏھن اھو موجود نہ ھجي جيتوڻيڪ `symname` ۾ بيان ڪيل علامتي ٽيبل جو نالو واپس اچو.
                //
                // نوٽ ڪريو ته ڪڏهن ڪڏهن `function` ڪجهه گهٽ صحيح محسوس ڪري سگھن ٿا ، مثال طور `try<i32,closure>` isntead طور `std::panicking::try::do_call` طور تي درج ٿيڻ.
                //
                // اهو واقعي واضح ناهي ، پر مجموعي طور تي `function` نالو وڌيڪ صحيح لڳي ٿو.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // هاڻي جي لاءِ ڪجهه نه ڪر
}

/// `data` پوائنٽر جو قسم `syminfo_cb` ۾ گذري ويو
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // هڪ ڀيرو جڏهن اهو حل ڪرڻ شروع ٿئي ته اسان `backtrace_syminfo` کي اڳتي وڌائڻ لاءِ هڪ ڀيرو ڪال ڪال ڪئي وئي آهي.
    // `backtrace_pcinfo` فنڪشن ڊيبگ consultاڻ جي صلاح ڪندو ۽ شين کي ڪرڻ جي ڪوشش ڪندو ، جهڙوڪ file/line recoverاڻ حاصل ڪرڻ ۽ ان لائين فريم وانگر.
    // ياد رکو جيتوڻيڪ `backtrace_pcinfo` ناڪام ٿي سگھي ٿو يا گهڻو ڪري نٿو سگھي ، جيڪڏهن ڊيبگ جي there'sاڻ ناهي ته پوءِ جيڪڏهن اهو ٿئي ته اسان کي پڪ آهي ته ايڪس بيڪس کان گهٽ ۾ گهٽ هڪ نشان ته ڪال بیک کي ڪال ڪندي.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` پوائنٽر جو قسم `pcinfo_cb` ۾ گذري ويو
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// لائيببريڪس اي پي اي هڪ رياست ٺاهڻ جي حمايت ڪندي آهي ، پر اهو ڪنهن رياست کي تباهه ڪرڻ جي حمايت نٿو ڪري.
// آئون ذاتي طور تي انهي جو مطلب وٺان ٿو ته هڪ رياست ٺاهي وڃڻ لاءِ آهي ۽ پوءِ سدائين رهڻ.
//
// آئون اي at_exit() هينڊلر کي رجسٽر ڪرڻ پسند ڪندس جيڪا هن اسٽيٽ کي صاف ڪري ٿي ، پر ليب بيڪ ٽرسٽ انهي لاءِ اهڙو رستو ڪونه مهيا ڪري.
//
// انهن رڪاوٽن سان ، هن فنڪشنل هڪ جامد ڪيش ٿيل حالت آهي جيڪا انهي وقت حساب ڪئي وئي آهي جڏهن اها درخواست ڪئي وئي.
//
// ياد رک ته س allي طرف پوئتي هٽڻ پويان (هڪ گلوبل لاڪ) هوندو آهي.
//
// هتي نوٽ ڪرڻ جي هم وقت سازي جي گهٽتائي جي گهرج آهي ڇو ته `resolve` خارجي طور تي هم وقت سازي جي ضرورت آهي.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // لائيبريري جي قابليت استعمال نه ڪريو ڇاڪاڻ ته اسان ان کي هميشه هم وقت سازي واري انداز ۾ سڏيندا آهيون.
        //
        0,
        error_cb,
        ptr::null_mut(), // وڌيڪ ڊيٽا نه
    );

    return STATE;

    // ياد رکو ته libbacktrace کي انهي تي هلائڻ لاءِ هي موجوده ڊيٽابيس لاءِ DWARF ڊيبگ findاڻ ڳولڻ جي ضرورت آهي.اهو عام طور تي ڪيترائي ميڪانيزم جي ذريعي ڪري ٿو ، پر محدود نه آهي:
    //
    // * /proc/self/exe حمايت ٿيل پليٽفارم تي
    // * فائيل نام رياست ۾ ٺاھڻ تي واضح طور تي گذري وئي
    //
    // لائيبڪچريري جي لائبريري سي ڪوڊ جو هڪ وڏو واڊ آهي.هي قدرتي طور تي انهي جو مطلب آهي يادگيري جي حفاظت واريون رڪاوٽون ، خاص طور تي جڏهن ڊيگيوجنٽ کي غلط ترتيب ڏيڻ.
    // لبرڊ انهن تاريخي طور تي ڪافي مقدار ۾ هليو آهي.
    //
    // جيڪڏهن /proc/self/exe استعمال ڪيو ويندو ته پوءِ اسين عام طور تي انهن کي نظرانداز ڪري سگھون ٿا جئين اسان اهو فرض ڪريون ٿا ته libbacktrace "mostly correct" آهي ۽ ٻي صورت ۾ "attempted to be correct" dwarf debug info سان عجيب شيون نه ڪندو آهي.
    //
    //
    // جيڪڏهن اسان هڪ فائل نالي ۾ پاس ڪريون ٿا ، البت ، اهو ممڪن آهي ڪجهه پليٽفارم تي (بي ايس ڊيز وانگر) جتي ڪو بدنيتي وارو عملدار جاءِ جي جاءِ تي ثالث فائل رکڻ جو سبب بڻجي سگهي.
    // ان جو مطلب اهو ٿيو ته جيڪڏهن اسان هڪ فائيل نالي جي باري ۾ لائببري ٽرسٽ کي ٻڌايون ته اهو ڀلجي فائل استعمال ڪري رهيو آهي ، ممڪن طور تي ڀاfaي جو سبب بڻجندو.
    // جيڪڏهن اسان لائب بيڪري کي ڪجھ به نٿا ٻڌون ، جيتوڻيڪ اهو پليٽفارم تي ڪجهه به نه ٿو ڪري سگهندو جيڪي /proc/self/exe وانگر رستن کي سپورٽ نٿا ڪن.
    //
    // اسان سڀ ڏين پيا ڪوشش ڪريو ته فائل جي نالي مان گذريو *نه*، پر اسان کي لازمي طور تي پليٽ فارمز تي جيڪي /proc/self/exe جي سپورٽ نٿا ڪن.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // ياد رکو ته مثالي طور اسان `std::env::current_exe` استعمال ڪنداسين ، پر اسان هتي `std` جي ضرورت نٿا ڪري سگهون.
            //
            // `_NSGetExecutablePath` استعمال ڪريو موجوده عملدرآمد واري رستي کي جامد علائقي ۾ لوڊ ڪرڻ لاءِ (جيڪو جيڪڏھن اھو تمام نن smallڙو آھي تھ ڇڏي ڏيو).
            //
            //
            // ياد رکو ته اسان هتي انتهائي سنجيدگي سان لبربڪچاس تي ڀروسو ڪري رهيا آهيون ته مرڻ وارا ڪرپٽ عملدارن تي نه مرندا ، پر اهو ضرور ڪندو
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows هن فائلن کي کولڻ جو طريقو آهي جتي کولڻ کان پوءِ ان کي ختم نه ڪيو وڃي.
            // اھو عام طور تي آھي جيڪو اسان ھتي چاھيو ٿا ڇو ته اسان اھو يقيني بڻائڻ چاھيون ٿا ته اسان جو عملدار اسان ھيٺان تبديل نه ٿيندو اسان جي لبيباري ٽريڪ کي ھٿ ڪرڻ کان پوءِ ، اميد آھي ته لابيڪ ٽرسٽي ۾ صوابدیدي ڊيٽا کي منتقل ڪرڻ جي صلاحيت کي گھٽائي سگھون (جيڪو شايد غلط ھجي)
            //
            //
            // ڏنو ويو آهي ته اسين هتي ڪجهه ناچ ڪندا آهيون اسان جي پنهنجي تصوير تي هڪ قسم جو لاڪ حاصل ڪرڻ جي ڪوشش ڪرڻ.
            //
            // * موجوده عمل کي هينڊي وٺو ، ان جو فائل نام لوڊ ڪريو.
            // * ان فائل کي فائل کي صحيح پرچم سان کوليو.
            // * موجوده عمل جي نالي واري فائيل کي ٻيهر لوڊ ڪريو ، پڪ ڪريو ته اها ساڳي آهي
            //
            // جيڪڏهن اهو سڀ ڪجهه گذري ويا ته اسان نظرياتي طور تي اسان جي پروسيس جي فائل کوليون ٿا ۽ اسان گارنٽي آهيون اها تبديل نه ٿيندي.FWIW انهي جو هڪ ٽڪرو لبرسٽ تاريخي طور تي نقل ڪيو ويو آهي ، تنهن ڪري اهو منهنجو بهترين تشريح آهي جيڪو ڇا ٿي رهيو هو.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // هي جامد يادداشت ۾ رهي ٿو ان جي ڪري اسان ان کي واپس ڪري سگهون ٿا ..
                static mut BUF: [i8; N] = [0; N];
                // ... ۽ اهو زنده رهڻ واري اسٽيڪ تي رهي آهي جئين اهو عارضي آهي
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ارادي طور تي `handle` هتي ٽوڙيو ڇو ته اهو کليل انهي فائل جي نالي تي اسان جو تالا محفوظ ڪرڻ گهرجي.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // اسان هڪ سلائس واپس آڻڻ چاهيون ٿا جيڪو مڪمل ختم ٿيل آهي ، تنهن ڪري جيڪڏهن سڀ ڪجهه ڀرجي ويو ۽ ان جي ڪل ڊيگهه جي برابر آهي ته پوءِ اها ناڪامي جي برابر آهي.
                //
                //
                // ٻي صورت ۾ جڏهن ڪاميابي واپس ڪندي پڪ هجو ته نل بائيٽ کي سلائس ۾ شامل ڪيو ويو آهي.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // پٺاڻن جي غلطين هن وقت قالين هيٺ وڙهي وئي آهي
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API کي ڪال ڪريو جنھن کي (ڪوڊ پڙھڻ کان) `syminfo_cb` کي ھڪڙي ئي وقت سڏڻ گھرجي (يا ھڪڙي غلطي سان ناڪامي ٿي).
    // اسان پوءِ `syminfo_cb` کان وڌيڪ سنڀاليو.
    //
    // ياد رکو ته اسان اهو ڪريون ٿا جئين ايڪس آرڪس سمبل ٽيبل جي صلاح مشوري ڪندو ، نشانين جي نالن کي ڳوليندو جيتوڻيڪ بائنري ۾ ڊيبگ debاڻ نه هجي.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}