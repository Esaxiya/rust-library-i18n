//! ايڪسڪسيمڪس تي `gimli` crate استعمال ڪندي علامتي لاءِ مدد
//!
//! اهو Rust لاء ڊفالٽ علامتي نفاذ آهي.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'جامد لائف ٽائيم پنهنجي پاڻ کي حوالي ڪرڻ واري جوڙجڪ جي حمايت جي کوٽ جي ڀرسان ڇڪڻ لاءِ ڪوڙ آهي.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // جامد لائف ۾ تبديل ڪريو ڇو ته نشانن کي صرف `map` ۽ `stash` قرض وٺڻ گهرجي ۽ اسان انهن کي هيٺ محفوظ ڪري رهيا آهيون.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows تي ڏيهي لائبريري کي لوڊ ڪرڻ لاءِ ، هتي مختلف حڪمت عملي لاءِ rust-lang/rust#71060 تي ڪجهه بحث ڏسو.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW لائبريري هن وقت اي ايس ايل آر ايڪسڪسيمڪس کي سپورٽ نٿا ڪن ، پر DLL اڃا تائين ايڊريس جي جڳھ ۾ واپس منتقل ٿي سگھن ٿا.
            // اهو ظاهر ٿئي ٿو ته ڊيبگ معلومات ۾ پتا سڀئي asڻ ته اها لائبريري پنهنجي "image base" تي لوڊ ٿيل هجي ، جيڪا هن جي COFF فائل هيڊرن ۾ هڪ ميدان آهي.
            // جتان هي اهو آهي جيڪو ڊيبگينفو لسٽ ۾ لڳي ٿو اسان علامت جي ٽيبل کي پارڪ ڪريو ۽ اسٽور ايڊريس asڻ ته لائبريري "image base" تي به لوڊ ٿيل هجي.
            //
            // جيتوڻيڪ لائبريري "image base" تي لوڊ نه ٿي سگھي ،.
            // (شايد ڪجهه ٻيو اتي لوڊ ٿي سگهي ٿو؟) هي جڳهه آهي جتي `bias` ميدان راند ۾ اچي ٿو ، ۽ اسان کي هتي `bias` جي قدر needاڻڻ جي ضرورت آهي.بدقسمتي سان جيتوڻيڪ اهو واضح ناهي ته انهي کي پورو ٿيل ماڊل مان ڪئين حاصل ڪجي.
            // جيڪو اسان وٽ آهي ، تنهن هوندي به ، اصلي لوڊ پتي (`modBaseAddr`) آهي.
            //
            // ھاڻي اسان لاءِ ڪاپي آئوٽ جي طور تي اسان فائل کي ميمپ ڪيو ، فائل ھيڊر واري معلومات کي پڙھو ، پوءِ ايم ايم پي کي ڇڏيو.هي فضول آهي ڇو ته اسان ممڪن طور تي ايم ايم پي ٻيهر ٻيهر کوليون ٿا ، پر اهو هينئر تائين ڪافي ڪم ڪرڻ گهرجي.
            //
            // هڪ دفعو اسان وٽ `image_base` (گهربل لوڊ مقام) ۽ `base_addr` (اصل لوڊ مقام) اسين `bias` ڀرجي سگهون ٿا (اصل ۽ مطلوب جي وچ ۾ فرق) ۽ پوءِ هر حصي جو بيان ڪيل پتو `image_base` آهي ڇو ته اهو ئي آهي فائل.
            //
            //
            // هينئر تائين اهو ظاهر ٿئي ٿو ته ELF/MachO جي برعڪس اسان هڪ سيڪشن سان لائبريري سان ٺاهي سگھون ٿا ، مڪمل طور تي `modBaseSize` استعمال ڪندي.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS Mach-O فائل فارميٽ استعمال ڪندو آهي ۽ DYLD-مخصوص APIs استعمال ڪندو آهي انهن کي ڏيهي لائبريرين جي فهرست لوڊ ڪرڻ لاءِ جيڪا درخواست جو حصو هوندي آهي.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // هن لائبريري جو نالو کڻي وڃو جيڪو انهي رستي جي برابر هوندو آهي جتي ان سان گڏ لوڊ ٿئي ٿو.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // هن لائبريري جو تصويري هيڊر لوڊ ڪريو ۽ سڀني لوڊ ڪمانڊ کي ترتيب ڏيڻ جي لاءِ `object` ڏانهن مختص ڪريو ته جيئن اسان هتي شامل سڀني حصن کي سڃاڻي سگهون.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // ڀا segن جي مٿان ورجاءُ ڪريو ۽ جن حصن کي ڳوليندا آھيو اتي knownاڻايل علائقن کي رجسٽر ڪريو.
            // اضافي طور تي رڪارڊ بابت معلومات واري متن جي حصن بعد جي پروسيسنگ لاءِ ، هيٺ ڏنل تبصرا ڏسو.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // هن لائبريري لاءِ "slide" کي طئي ڪيو وڃي جيڪو ختم ٿي رهيو آهي اسان سمجهون ٿا ته يادگيري شين ۾ ڪٿي لوڊ ٿيل آهن.
            // هي هڪ ڪمزور بي ترتيب آهي جيتوڻيڪ ڪجهه جهنگلن ۾ ڪجهه شيون ڪوشش ڪرڻ ۽ ڏسو ته ڪهڙو به لٺ آهي.
            //
            // عام خيال اهو آهي ته `bias` پلس هڪ حصي جو `stated_virtual_memory_address` وڃي رهيو آهي جتي اصل پتي جي جڳهه ۾ ڀا theو رهندو آهي.
            // ٻي ڳالهه جيڪا اسان انحصار ڪيو آهي اها آهي ته هڪ اصل پتو مائنس `bias` اشاري جدول ۽ ڊيبگينفو ۾ ڏسڻ لاءِ انڊيڪس آهي.
            //
            // اهو ٻاهر نڪتو ، جيتوڻيڪ ، سسٽم لوڊ لوڊ ڪيل لائبريرين لاءِ اهي حساب غلط آهن.اصلي عملدار لاءِ ، جڏهن ته ، اهو صحيح ظاهر ٿئي ٿو.
            // ايل ايل ڊي بي جي منبع مان ڪجهه منطق کڻڻ اهو ان ۾ پهريون ايڪسڪسيمڪس سيڪشن لاءِ ڪجھ خاص ڪيسنگ آھي غير آفيرو سائيز سان فائل آفسيٽ 0 کان لوڊ ٿيل.
            // ڪنهن به سبب جي ڪري جڏهن اهو موجود آهي اهو ظاهر ٿيڻ لڳي ٿو ته علامت جي ٽيبل سان صرف لائبريري جي لاءِ ويڊرڊ سلائيڊ جو لاڳاپو آهي.
            // جيڪڏهن اهو *نه* موجود آهي ته پوءِ نشان جي ٽيبل وابستر سلائيڊ سان واسطو رکي ٿي ۽ حصي جو بيان ڪيل پتو.
            //
            // هن صورتحال کي سنڀالڻ جي لاءِ جيڪڏهن اسان *نٿا ڳولها* فائل آفسيٽ صفر تي ٽيڪسٽ سيڪشن ڳوليو ته پوءِ اسان پهرين متن جي سيڪشن جي بيان ڪيل ايڊريس جي تعصب وڌائي ڇڏيو ۽ ان رقم سان سڀني بيان ڪيل پتي کي پڻ گهٽائي ڇڏيو.
            //
            // انهي طريقي سان علامت جي ميز هميشه لائبريري جي تعصب جي مقدار سان ظاهر ٿيندي آهي.
            // اهو ظاهر ٿئي ٿو ته صحيح نتيجا نشاني لاءِ ٽيبل جي معرفت ترتيب ڏيندو آهي.
            //
            // ايمانداري طور تي مان مڪمل طور تي پڪ ناهي ته هي صحيح آهي يا ٻيو ڪجهه آهي جيڪو انهي کي ظاهر ڪرڻ گهرجي.
            // اڃا تائين جيتوڻيڪ اهو ايڪس اين ايڪس ايڪس ڪافي ڪم ڪرڻ لڳي ٿو ۽ جيڪڏهن ضروري هجي ته اسان هميشه اهو وقت وڌائڻ جي قابل هئڻ گهرجي.
            //
            // وڌيڪ معلومات لاءِ #318 کي ڏسو
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // ٻيا Unix (مثال طور
        // لينڪس) پليٽ فارم اي ايل ايف کي آبجسٽ فائيل فارميٽ جي طور تي استعمال ڪندا آهن ۽ عام طور تي اي پي وائي کي `dl_iterate_phdr` سڏيندا آهن جئين لائبريريون لوڊ ڪرڻ لاءِ
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` هڪ صحيح اشارو هئڻ گهرجي.
        // `vec` `std::Vec` ڏانهن صحيح پوائنٽر هجڻ گهرجي.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ڊيبگ معلومات کي اصلي طور تي سهڪار نه ٿو ڏئي ، پر بلڊ سسٽم ڊي `romfs:/debug_info.elf` وٽ ڊيبگ معلومات رکي ٿو.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // ٻيو سڀ ڪجهه اي ايل ايف استعمال ڪرڻ گهرجي ، پر اهو نٿو nativeاڻي ته اصلي لائبريري کي ڪيئن لوڊ ڪجي.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// تمام سڃاتل گڏيل لائبريريون جيڪي لوڊ ڪيون ويون آهن.
    libraries: Vec<Library>,

    /// نقشي جو خاڪو جتي اسان کي ختم ٿيل ٻرندڙ معلومات کي برقرار رکون ٿا.
    ///
    /// ھن لسٽ ۾ ھڪڙي پوري گنجائش آھي ھڪڙي پوري لفٽ لاءِ جيڪا ھرگز نه وڌائي.
    /// هر جوڙي جو `usize` عنصر هڪ انڊيڪس `libraries` کان مٿي آهي جتي `usize::max_value()` موجوده قابل عمل جي نمائندگي ڪري ٿو.
    ///
    /// `Mapping` برابر ٿيل ٻٻر جي isاڻ آهي.
    ///
    /// ياد رکو ته هي بنيادي طور تي ايل آر يو ڪيش آهي ۽ اسان هتي آس پاس جي شين کي beيرائي رهيا آهيون جئين اسين پتي جي علامت ڪندا آهيون.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// هن لائبريري جا حصا ميموري ۾ لوڊ ڪيا ويا آهن ، ۽ اهي لوڊ ٿيل ڪٿي آهن.
    segments: Vec<LibrarySegment>,
    /// ھن لائبريري جو "bias" ، خاص طور تي جتي اھو ياداشت ۾ لوڊ ٿيل آھي.
    /// اهو قدر هر حصي جي بيان ڪيل ايڊريس ۾ شامل ڪيو ويندو آهي اصل مجازي ميموري پتو حاصل ڪرڻ لاءِ ته ڀا segmentي ۾ لوڊ ٿيل آهي.
    /// اضافي طور تي هي تعصب حقيقي مجازي ميموري پتي مان خارج ٿي ويو آهي انڊيڪس ۾ ڊيبگينفو ۽ سمبل ٽيبل ۾.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// اعتراض واري فائل ۾ هن حصي جو بيان ٿيل پتو.
    /// هي اصل ۾ ناهي جتي اهو حصو لوڊ ٿيل آهي ، بلڪه اهو پتو ۽ لائبريري جي ايڪس سيڪس تي مشتمل آهي جتي اها ڳولهڻ آهي.
    ///
    stated_virtual_memory_address: usize,
    /// ياداشت ۾ ايس ايس ايس جو حصو.
    len: usize,
}

// غير محفوظ آهي ڇاڪاڻ ته اها خارجي طور تي هم وقت سازي جي ضرورت آهي
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // غير محفوظ آهي ڇاڪاڻ ته اها خارجي طور تي هم وقت سازي جي ضرورت آهي
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // ھڪڙو تمام نن ،ڙو ، بلڪل سادو LRU ڪيب ڊيبگ infoاڻ ٺاھڻ لاءِ.
        //
        // هٽ جي شرح تمام گھڻي هئڻ گهرجي ، جئين عام اسٽيڪ ڪيترن ئي گڏيل لائبريرين جي وچ ۾ پار نه ٿيندو آهي.
        //
        // `addr2line::Context` اڏاوتون تمام گهڻيون قيمتي آهن.
        // ان جي قيمت جي توقع ڪئي وڃي بعد ۾ `locate` سوالن جو پاڻ مرڪوز ڪيو وڃي ، جيڪي سٺن اسپيڊ اپ حاصل ڪرڻ لاءِ `addr2line: : Contexts` ٺاهڻ وقت ٺاهيل اڏاوتن کي استعمال ڪن ٿا.
        //
        // جيڪڏهن اسان وٽ اها ڪيش نه هجي ، ته شفاعت ڪڏهن به نه ٿئي ها ، ۽ علامتن جي پسمنظر ssssllllooooowwww هوندي.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // پهرين اپ ، ٽيسٽ ڪريو ته ڇا هي `lib` ڪنهن به ڀا segmentي تي مشتمل آهي `addr` (منتقلي جي بحالي).جيڪڏهن اهو چيڪ گذري ٿو ته پوءِ اسان هيٺ جاري رکي سگهون ٿا ۽ اصل ۾ ايڊريس ترجمو ڪري سگهون ٿا.
                //
                // نوٽ ڪريو ته اسان ايڪس فيڪس چيڪ استعمال ڪرڻ لاءِ هتي استعمال ڪري رهيا آهيون.اهو جهنگ ۾ ڏٺو ويو آهي ته SVMA + تعصب وارو حساب گهڻو ڪري ٿو.
                // اهو ٿورو عجب لڳي ٿو ، جيڪو ٿئي ها پر اسان وٽ ان بابت وڏي پئماني تي ڪا شي نه آهي جيترو شايد انهن حصن کي نظرانداز ڪرڻ کان پوءِ شايد اهي خلا ۾ نشاندهي ڪري رهيا هجن.
                //
                // هي اصل rust-lang/backtrace-rs#329 ۾ اڳيان آيو.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // هاڻي ته اسان knowاڻون ٿا ته `lib` `addr` شامل آهي ، اسان بيان ٿيل وائرلل ياداشت جي پتو ڳولڻ لاءِ تعصب سان هلي سگھون ٿا.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invarant: ھن مشروط جلدي جي موٽڻ کان پھريائين
        // هڪ غلطي کان ، هن رستي لاءِ ڪيش جو داخلا انڊيڪس 0 تي آهي.

        if let Some(idx) = idx {
            // جڏهن نقشي اڳئين ئي ڪئش ۾ آهي ، انهي کي اڳيان وڌايو.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // جڏهن نقشي ڪيش ۾ نه هجي ، نئون نقشه ٺاھيو ، ان کي ڪيش جي سامهون داخل ڪيو ۽ جيڪڏهن ضروري هجي ته وڏي پراڻي ڪش اندراج کي ڪ evي.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` پوري زندگي کي ليڪ نه ڏيو ، پڪ makeاڻو ته اهو صرف اسان کي پاڻ ڏانهن مائل آهي
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // `sym` کان وڌيڪ 01اڻ `'static` ڪريو ڇو ته اسان کي بدقسمتي سان هتي گهربل آهي ، پر اهو ڪڏهن حوالي طور نڪرڻ وارو آهي انهي ڪري ڪو به حوالو انهي فريم کان ٻاهر جاري رهڻ نه گهرجي.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // آخرڪار ، ھن فائل لاءِ ڪيشڊ ميپنگ حاصل ڪريو يا نئين ٺاھڻ کي ٺاھيو ، ۽ ڊي او آر ايف جي معلومات جو جائزو وٺو file/line/name ھن پتي کي ڳولڻ لاءِ.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// اسان هن نشاني جي فريم toاڻ ڳولڻ جي قابل هئاسين ، ۽ "addr2line" جو فريم اندروني طور تي تمام سٺي نموني تفصيل آهي.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// ڊيبگ جي findاڻ نه لڌي ، پر اسان اهو ايلف کي قابل عمل جي علامتي ٽيبل ۾ ڏٺا.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}