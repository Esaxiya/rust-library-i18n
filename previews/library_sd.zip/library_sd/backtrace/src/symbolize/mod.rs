use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// هڪ ايڊريس کي هڪ حل ته حل ڪريو ، نشان کي مخصوص بندش ڏانهن روانو ڪيو.
///
/// هن فنڪشن کي علائقن ۾ ڏنل ايڊريس نظر ايندو جئين ته مقامي نشان جدول ، متحرڪ علامت ٽيبل ، يا ڊي ڊبليو ايف ڊيبگ معلومات (فعال عمل تي منحصر آهي) پيدا ڪرڻ لاءِ نشانيون ڳولڻ لاءِ.
///
///
/// بندش شايد نه چئجي جيڪڏهن حل نه ٿي سگهي ، ۽ اهو ان لائن ٿيل افعال جي صورت ۾ هڪ کان وڌيڪ ڀيرا به ٿي سگهي ٿو.
///
/// علامتن مان حاصل ڪيل بيان `addr` تي عملدرآمد جي نمائندگي ڪن ٿا ، انهي ايڊريس لاءِ file/line جوڙا واپس آڻيندي (جيڪڏهن موجود هجي).
///
/// ياد رکو ته جيڪڏهن توهان وٽ `Frame` آهي ته انهي جي بدران `resolve_frame` فنڪشن استعمال ڪرڻ جي سفارش ڪئي وئي آهي.
///
/// # گهربل خاصيتون
///
/// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
///
/// # Panics
///
/// اهو فنڪشن panic کي ڪڏهن به ناڪام ڪرڻ جي ڪوشش ڪندو آهي ، پر جيڪڏهن ايڪس سيڪس panics مهيا ڪئي ته پوءِ ڪجهه پليٽ فارم هڪ دوئي panic کي مجبور ڪندا ته ان عمل کي ختم ڪري.
/// ڪي پليٽ فارم سي لائبريري استعمال ڪن ٿا جيڪي اندروني طور تي ڪال بيڪ استعمال ڪن ٿا جن کي بغير ختم نٿو ڪري سگهجي ، تنهن ڪري `cb` کان ڇڪڻ هڪ عمل ختم ڪري سگھي ٿو.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // صرف مٿين فريم ڏسو
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// ھڪڙي پڪڙندڙ فريم کي ھڪ علامت کي حل ڪريو ، نشان کي مخصوص بندش ڏانھن روانو ڪيو.
///
/// اهو فنڪشنل `resolve` وانگر ساڳيو ڪم ڪندو آهي ان کان سواء اهو `Frame` هڪ ايڊريس جي بدران دليل طور وٺندو آهي.
/// اهو پٺتي پيل بابت ڪجهه پليٽفارم لاڳو ڪرڻ جي اجازت ڏئي سگهي ٿو مثال طور ان لائن فريم بابت وڌيڪ صحيح علامتي orاڻ يا معلومات.
///
/// اهو توهان کي استعمال ڪرڻ جي سفارش ڪئي وئي آهي جيڪڏهن توهان ڪري سگهو ٿا.
///
/// # گهربل خاصيتون
///
/// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
///
/// # Panics
///
/// اهو فنڪشن panic کي ڪڏهن به ناڪام ڪرڻ جي ڪوشش ڪندو آهي ، پر جيڪڏهن ايڪس سيڪس panics مهيا ڪئي ته پوءِ ڪجهه پليٽ فارم هڪ دوئي panic کي مجبور ڪندا ته ان عمل کي ختم ڪري.
/// ڪي پليٽ فارم سي لائبريري استعمال ڪن ٿا جيڪي اندروني طور تي ڪال بيڪ استعمال ڪن ٿا جن کي بغير ختم نٿو ڪري سگهجي ، تنهن ڪري `cb` کان ڇڪڻ هڪ عمل ختم ڪري سگھي ٿو.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // صرف مٿين فريم ڏسو
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// اسٽيڪ فريمز کان پي پي قدر عام طور تي (always?) هدايتون آهن *ڪال کان پوءِ* اها اصل اسٽيڪ ٽريس آهي.
// ان کي علامتي ڪرڻ جو سبب اهو آهي filename/line نمبر هڪ اڳيان ۽ شايد باطل ۾ جيڪڏهن اهو فنڪشن جي خاتمي تائين آهي.
//
// اهو بنيادي طور تي هميشه سڀني پليٽ فارمنز ۾ هميشه وانگر ڏسڻ ۾ اچي ٿو ، تنهن ڪري اسان هميشه هڪ حل ٿيل آئي پي تان لاٿو ته ان کي واپس ڪرڻ جي هدايت جي بدران پوئين ڪال هدايت تي حل ڪيو وڃي.
//
//
// مثالي طور اسان ائين نه ڪنداسين.
// مثالي طور تي اسان -1 APIs جي ڪاليندڙن کي دستي طور تي -1 ۽ اڪائونٽ ٺاهڻ جي ضرورت پوندي ها ته اهي *اڳوڻي* هدايت واري هنڌ جي wantاڻ چاهيندا ، هاڻوڪي نه.
// مثالي طور تي اسان ايڪس ايڪس ايڪس تي پڻ بي نقاب ڪري ها جيڪڏهن اسان واقعي واري هدايت يا موجوده جو پتو آهيون.
//
// هينئر تائين ، جيتوڻيڪ اهو هڪ خوبصورت جڳهه تشويش آهي ، تنهنڪري اسان صرف اندروني طور تي هميشه هڪ کي ختم ڪيو.
// صارفين کي ڪم ڪرڻ ۽ خوبصورت نتيجا حاصل ڪرڻ گهرجي ، تنهنڪري اسان کي ڪافي سٺو هجڻ گهرجي.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// ساڳيو `resolve` وانگر ، صرف غير محفوظ آهي جيئن اهو غير مطابقت پذير آهي.
///
/// ھن فنڪشن کي هم وقت سازي جي گارنٽيز نھ آھي پر دستياب آھي جڏھن ھن crate جي `std` خصوصيت مرتب ٿيل ناھي.
/// وڌيڪ دستاويزن ۽ مثالن لاءِ `resolve` وارو فنڪشن ڏسو.
///
/// # Panics
///
/// `cb` کان ڇڪڻ تي ڪنورات وارن لاءِ `resolve` تي معلومات ڏسو.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// ساڳيو `resolve_frame` وانگر ، صرف غير محفوظ آهي جيئن اهو غير مطابقت پذير آهي.
///
/// ھن فنڪشن کي هم وقت سازي جي گارنٽيز نھ آھي پر دستياب آھي جڏھن ھن crate جي `std` خصوصيت مرتب ٿيل ناھي.
/// وڌيڪ دستاويزن ۽ مثالن لاءِ `resolve_frame` وارو فنڪشن ڏسو.
///
/// # Panics
///
/// `cb` کان ڇڪڻ تي ڪنورات وارن لاءِ `resolve_frame` تي معلومات ڏسو.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// ھڪ trait ھڪڙي فائل ۾ علامت جي قرارداد جي نمائندگي ڪري ٿو.
///
/// ھي trait ھڪڙي trait اعتراض جي طور تي پيدا ڪيو ويو آھي `backtrace::resolve` ڪم کي ڏنو ويو آھي ، ۽ اھو عمدي طور موڪليو ويو آھي جئين اھو نامعلوم آھي ان جي پويان عمل درآمد.
///
///
/// هڪ علامت ڪنهن ڪم جي متعلق مددي معلومات ڏئي سگهي ٿي ، مثال طور نالو ، فائل نام ، لائن نمبر ، صحيح پتو وغيره.
/// نه سموري معلومات هميشه هڪ علامت ۾ موجود آهي ، تنهن ڪري ، سڀئي طريقا هڪ `Option` واپس ڪن ٿا.
///
///
pub struct Symbol {
    // TODO: هن حياتياتي پابند کي آخرڪار `Symbol` تي برقرار رکڻ جي ضرورت آهي ،
    // پر اها في الحال هڪ بريڪنگ تبديلي آهي.
    // في الحال هي محفوظ آهي جئين `Symbol` صرف حواله کان ئي هٿ ڪ handedيو وڃي ٿو ۽ ڪلون ڪري نٿو سگهجي.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// انهي فنڪشن جو نالو واپس ڏئي ٿو.
    ///
    /// واپسي جي جوڙجڪ علامت جي نالي بابت مختلف ملڪيت بابت سوال ڪرڻ ۾ استعمال ٿي سگهي ٿي.
    ///
    ///
    /// * `Display` عملدرآمد مسمار ٿيل نشان پرنٽ ڪندو.
    /// * علامت جي خام `str` قيمت تائين پھچائي سگھجي ٿي (جيڪڏھن اھو درست آھي utf-8).
    /// * علامت جي نالي لاءِ خام بائيٽ رسائي سگھجن ٿيون.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// هن فنڪشن جي شروعاتي ايڊريس کي واپس ڏئي ٿو۔
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// خام فائل جو نالو سلائس وانگر واپس ڏئي ٿو.
    /// هي بنيادي طور تي `no_std` ماحول لاءِ مفيد آهي.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// ڪالم نمبر واپس ڪندو آھي جتي ھن علامت تي عمل ڪيو پيو وڃي.
    ///
    /// صرف گيمي صرف هن وقت هتي قيمت فراهم ڪري ٿي ۽ ان جي باوجود جيڪڏهن `filename` `Some` موٽائي ٿو ، ۽ انهي جي نتيجي ۾ اهو ساڳيو جزن جي تابع آهي.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// لڪير وارو نمبر واپس آڻي ٿو جتان ھي علامت ھاڻي اھو عمل ڪندڙ آھي۔
    ///
    /// هي واپسي قيمت عام طور تي `Some` آهي جيڪڏهن `filename` `Some` واپس اچي ٿي ، ۽ ان جي نتيجي ۾ ساڳي خبرداري جي تابع آهي.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// فائل جو نالو واپس ڏئي ٿو جتي هن فنڪشن کي بيان ڪيو ويو هو.
    ///
    /// اهو في الحال دستياب هوندو جڏهن لائيبڪ ٽريس يا گولي استعمال ڪئي ويندي (مثال طور
    /// unix پليٽ فارم ٻيا) ۽ جڏهن هڪ بائنري ڊيبگينفو سان ترتيب ڏنل آهي.
    /// جيڪڏهن انهن مان ڪنهن شرطن کي پورا نه ڪيو ويندو ته اهو ممڪن آهي ايڪس ايڪس ايڪس موٽڻ.
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // ٿي سگهي ٿو ھڪڙو ٺاھيل C++ نشان ، جيڪڏھن ٺاھيو ويو نشان وارو نشان جئين Rust ناڪامي ٿي.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // ھي صفر سائز رکڻ کي يقيني بڻايون ، ته ان صورت ۾ `cpp_demangle` خصوصيت جي ڪابه قيمت ناھي.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// خالي نشان جي ergonomic رسائي فراهم ڪرڻ جي نالي جي علامت جي چوڌاري هڪ ريپر ، خام بائيٽ ، خام تار وغيره.
///
// جڏهن `cpp_demangle` فيچر کي فعال نه ڪيو ويو آهي مئل ڪوڊ جي اجازت ڏيو.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// خام بنيادي بائٽس مان ھڪ نئين علامت نالو ٺاھي ٿو.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// خام (mangled) علامت نالو `str` طور ڏئي ٿو جيڪڏھن علامت صحيح utf-8 آھي.
    ///
    /// جيڪڏهن توهان خراب ٿيل ورزن چاهيو ٿا `Display` عمل درآمد ڪريو.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// خام علامت جو نالو بائيٽ جي فهرست طور واپس ڏيکاري ٿو
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // اهو ڇپائي شايد جيڪڏهن مسمار ڪرڻ واري علامت اصل ۾ صحيح نه هجي ، تنهن ڪري غلطيءَ کي هن جي اڳيان پروپيگنڊا ڪري پيش نه ڪريو.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// ٻيهر ڪوشش ڪرڻ جي ڪوشش ڪئي وئي ڪشميري يادداشت کي پتي جي علامتي طور استعمال ڪيو.
///
/// اهو طريقو ڪنهن به عالمي ڊيٽا اسٽرڪچر کي جاري ڪرڻ جي ڪوشش ڪندو جيڪو ٻي صورت ۾ عالمي سطح تي يا انهي سلسلي ۾ جيڪا خاص طور تي پيرس DWARF orاڻ وارن خيالن جي نمائندگي ڪن.
///
///
/// # Caveats
///
/// جيتوڻيڪ اهو فنڪشن هميشه موجود هوندو آهي اهو اصل ۾ اڪثر عمل درآمد تي ڪجهه به ناهي ڪندو.
/// dbghelp يا libbacktrace جھڙيون لائبريريون رياست کي نيڪال ڪرڻ ۽ مختص ڪيل يادگيري کي منظم ڪرڻ جي سهولت فراهم نه ٿيون ڪن.
/// ھاڻي لاءِ ھن crate جي `gimli-symbolize` خاصيت آھي صرف ھڪڙو ڪم آھي جتي ھن فنڪشن جو ڪو اثر آھي.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}