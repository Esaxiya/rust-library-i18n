// صرف Linux تي صرف استعمال ٿيل آهن ، تنهنڪري مئل ڪوڊ ٻئي هنڌ تي ڏيو
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// بٽ بفرز جي هڪ سادي ميدان گهمڻ وارو.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// مخصوص سائيز جو بفر مختص ڪري ٿو ۽ ان ۾ قابل بدل حوالو ڏئي ٿو.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // حفاظت: اهو واحد فنڪشن آهي جيڪو ڪڏهن به هڪ قابل ميوٽ ٺاهي ٿو
        // `self.buffers` جي حوالي سان.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // حفاظت: اسان ايڪسٽڪس کان عنصر ڪڏهن به ختم نه ڪيو ، تنهن ڪري هڪ حوالو
        // ڪنهن به بفر ۾ ڊيٽا تائين جيئرو رهندو جيستائين جيستائين `self` رهندو.
        &mut buffers[i]
    }
}