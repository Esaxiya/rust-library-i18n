//! Windows تي ڊيگل ايل بائننگ کي منظم ڪرڻ ۾ مدد ڏيڻ جو هڪ ماڊل
//!
//! Windows تي گهٽين طرف (گھٽ ۾ گھٽ MSVC لاءِ) گهڻو ڪري `dbghelp.dll` ۽ ان تي مشتمل مختلف افعال ذريعي هليا ويندا آهن.
//! اهي افعال هن وقت *متحرڪ* لوڊ ٿيل آهن بلڪه بجاءِ `dbghelp.dll` سان ڳن linkڻ جي.
//! اهو في الحال معياري لائبريري ڪري چڪو آهي (۽ اتي جو نظرياتي طور تي گهربل آهي) ، پر هڪ لائبريري جي جامد ڊي ايل انحصارن کي گهٽائڻ ۾ مدد لاءِ ڪوشش آهي ڇو ته پٺاڻ خاص طور تي ڪافي اختياري هوندا آهن.
//!
//! اھو چئي رھيو آھي ، `dbghelp.dll` لڳ ڀڳ ڪاميابي سان Windows تي لوڊ ڪندو آھي.
//!
//! جيتوڻيڪ نوٽ ڪريو ته جئين اسان انهي سپورٽ کي متحرڪ طور لوڊ ڪري رهيا آهيون اسان اصل ۾ `winapi` ۾ خام تعريف استعمال نٿا ڪري سگهون ، بلڪه اسان کي ڪم ڪرڻ واري پوائنٽ جي وضاحت ڪرڻ گهرجي.
//! اسان واقعي ونپي جي نقل واري ڪاروبار ۾ نٿا چاهيون ، تنهن ڪري اسان وٽ هڪ Cargo خصوصيت `verify-winapi` آهي ، جيڪو انهي ڳالهه جي وضاحت ڪري ٿو ته سڀ پابنديون انهن وينپي سان ملن ٿيون ۽ اها خاصيت سي آئي تي فعال آهي.
//!
//! آخرڪار ، توهان هتي اهو نوٽ ڪيو ته `dbghelp.dll` لاءِ وغيره ڪڏهن به ختم نه ٿيندي آهي ، ۽ اهو في الحال ارادي آهي.
//! سوچ اها آهي ته اسان عالمي سطح تي ان کي ڪيش ڪري سگهون ۽ ان کي اين اي ڪالز جي وچ ۾ استعمال ڪري ، قيمتي loads/unloads کان پاسو ڪري.
//! جيڪڏهن اهو لیک جهٽندڙن لاءِ مسئلو هجي يا ڪا اهڙي شيءَ هجي ته اسان پل canيرائي سگهون جڏهن اسان اتي پهچون.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// ڪم تقريبن `SymGetOptions` ۽ `SymSetOptions` پاڻ ۾ موجود نه هجڻ ڪري ويناپي ۾.
// ٻي صورت ۾ اهو صرف تڏهن استعمال ٿيندو آهي جڏهن اسان ونپي جي خلاف ٻه ڀيرا جانچ ڪري رهيا آهيون.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // ونپيپي ۾ اڃا تائين بيان ناهي ڪيو ويو
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // اهو بيان ڪيو ويو وائيپي ۾ ، پر اهو غلط آهي (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // ونپيپي ۾ اڃا تائين بيان ناهي ڪيو ويو
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// اهو ميڪرو `Dbghelp` toانچي کي بيان ڪرڻ لاءِ استعمال ڪيو ويو آهي جيڪو اندروني طور تي سڀني فنڪشن پوائنٽرن تي مشتمل آهي جنهن کي اسين شايد لوڊ ڪريون ٿا.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` لاءِ لوڊ ٿيل ڊي ايل
            dll: HMODULE,

            // هر فنڪشن کي هر فنڪشن لاءِ پوائنٽر جيڪو اسان استعمال ڪري سگهون ٿا
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // شروعات ۾ اسان ڊي ايل ايل لوڊ نه ڪيا آهيون
            dll: 0 as *mut _,
            // شروعاتي طور سڀني افعال کي صفر تي سيٽ ڪيو ويو آهي چوڻ لاءِ انهن کي متحرڪ طور لوڊ ڪرڻ جي ضرورت آهي.
            //
            $($name: 0,)*
        };

        // هر فنڪشن جي قسم لاءِ سهولت typedef
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// ايڪس ايڪس ويڪس کولڻ جي ڪوشش ڪئي وئي آهي.
            /// جيڪڏهن `LoadLibraryW` ناڪامي ٿئي ته اهو ڪم ڪندو آهي يا غلطي واپس ٿي ويندي آهي.
            ///
            /// جيڪڏهن لائبريري اڳ ئي لوڊ ٿي وئي آهي ، Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // هر طريقن جي فنڪشن جنهن کي اسين استعمال ڪرڻ چاهينداسين.
            // جڏهن ان کي سڏيو ويندو يا ته اها ڪئش ٿيل فنڪشن پوائنٽر پڙهي يا ان کي لوڊ ڪندي ۽ لوڊ ٿيل قيمت کي واپس ڪندي.
            // ڪاميابيءَ لاءِ زور ڀريو ويو آهي.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // dbghelp افعال کي حوالي ڪرڻ جي لاءِ صفائي لاڪ استعمال ڪرڻ جي لاءِ سهولت.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// ھن crate مان `dbghelp` API افعال تائين رسائي لاءِ تمام سپورٽ ضروري آھي.
///
///
/// نوٽ ڪيو ته هي فنڪشن **محفوظ** آهي ، اهو اندروني طور تي پنهنجي هم وقت سازي آهي.
/// اهو به ياد ڪريو ته اهو محفوظ طور تي بار بار ڪال ڪرڻ لاءِ محفوظ آهي.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // پهرين شي اسان کي ڪرڻ گهرجي هن فنڪشن کي هم وقت سازي ڪرڻ.اهو س otherي سلسلي ۾ ٻين موضوعن سان گڏ ورجائي سگهجي ٿو.
        // ياد رکو ته اهو انهي کان وڌيڪ ڏکيو آهي ، ڇاڪاڻ ته اسان هتي ڇا استعمال ڪري رهيا آهيون ، `dbghelp` ،*پڻ* هن پروسيس ۾ `dbghelp` ڏانهن ٻين سڀني ڪالرن سان هم وقت سازي ڪرڻ جي ضرورت آهي.
        //
        // عام طور تي واقعي ائين نه آهن ته ساڳئي عمل جي اندر `dbghelp` کان ڪيترائي ڪالون ۽ اسان شايد اهو محفوظ طور تي فرض ڪري سگهون ٿا ته اسان صرف ان مان رسائي وارا آهيون.
        // اتي موجود آهي ، هڪڙي بنيادي پرائمري وارو صارف اسان کي انهي جي باري ۾ اسان کي پريشان ڪرڻ گهرجي ، جيڪو لوهي طور تي اسان پاڻ آهي ، پر معياري لائبريري ۾.
        // Rust معياري لائبريري انهي crate تي انحصار ڪيو آهي backtrace جي سپورٽ لاءِ ، ۽ اهو crate پڻ crates.io تي موجود آهي.
        // ان جو مطلب اهو آهي ته جيڪڏهن معياري لائبريري هڪ panic پرنٽ ڪري رهي آهي ته اهو crates.io کان اچي crate سان ريس ٿي سگهي ٿو ، سيففلٽس سبب.
        //
        // انهي هم وقت سازي جي مسئلي کي حل ڪرڻ ۾ مدد لاءِ اسان هتي ونڊوز جي خاص چال استعمال ڪندا آهيون (اهو آخرڪار هڪ هم وقت سازي بابت ونڊوز جي مخصوص پابندي آهي).
        // اسان هن ڪال کي بچائڻ لاءِ ميٽڪس نالي هڪ *سيشن-لوڪل* ٺاهيو.
        // هتي جو ارادو هي آهي ته معياري لائبريري ۽ crate کي هتي هم وقت سازي لاءِ Rust-level APIs کي حصيداري نه ڪرڻو آهي پر انهي جي پٺيان اهي پراڻا ڪم ڪري سگهندا انهي کي يقيني بڻائڻ لاءِ ته اهي هڪٻئي سان هم وقت سازي ڪري رهيا آهن.
        //
        // انهي طريقي سان جڏهن هن فنڪشن کي معياري لائبريري ذريعي سڏيو وڃي يا crates.io ذريعي اسان کي يقين ڏياريو وڃي ته اهو ساڳيو ميٽسڪس حاصل ڪيو پيو وڃي.
        //
        // تنهن ڪري اهو سڀ ڪجهه ٻڌائڻ آهي ته هتي جيڪو پهريون اسان هتي ڪيو اهو اسان کي ايٽمي طور تي `HANDLE` ٺاهي ٿو جيڪو Windows تي نالي وارو موتيڪس آهي.
        // اسان هن ڪم کي خاص طور تي شيئر ڪرڻ لاءِ ٻين موضوعن سان ٿورڙي هم وقت سازي ڪيون ٿا ۽ انهي ڳالهه کي يقيني بڻايو ته هن فنڪشن جي هر عرصي دوران هڪ هٿ سنڀاليل ئي آهي.
        // ياد رکو ته جڏهن گلوبل اسٽور ڪيو ويو آهي ته ڪڏهن به هينڊل بند ناهي ٿيو.
        //
        // جڏهن اسان اصل ۾ تالا هڻي چڪا آهيون اسان صرف انهي کي حاصل ڪريون ، ۽ اسان جو هٿ `Init` جيڪو اسان هٿ ڪيو اهو آخرڪار ان کي ڇڏڻ جو ذميوار هوندو.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // چ ،و ، فويو!هاڻي ته اسان سڀني کي محفوظ طور تي هم وقت سازي ۾ اچي ويو آهي ، اچو ته اصل ۾ هر شي تي عمل شروع ڪريون.
        // پهرين کي اسان کي يقيني بڻائڻ جي ضرورت آهي ته ايڪس پيڪس اصل ۾ انهي پروسيس تي لوڊ ٿيل آهي.
        // اسان اهو متحرڪ طور تي جامد انحصار کان بچڻ لاءِ ڪندا آهيون.
        // اهو تاريخي طور تي عجيب ڳنingيل مسئلن جي چوڌاري ڪم ڪرڻ جي لاءِ ڪيو ويو آهي ۽ انهي کي بائنريز کي ٿورڙو وڌيڪ پورٽبل بڻائڻ جو ارادو آهي ڇاڪاڻ ته هي گهڻو ڪري صرف ڊيبگنگ افاديت آهي.
        //
        //
        // هڪ دفعو اسان ايڪس ڪيوڪس کي کوليو آهي اسان کي ان ۾ ڪجهه شروعاتي افقن کي سڏڻ جي ضرورت آهي ، ۽ اهو وڌيڪ هيٺ ڏنل آهي.
        // اسان اهو صرف هڪ ڀيرو ، هڪ ٿي سگهي ٿو ، تنهن ڪري اسان کي هڪ گلوبل بولين اشارو آهي جيڪو اسان اڃا تائين ڪيو يا نه.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // انهي کي يقيني بڻايو وڃي ته `SYMOPT_DEFERRED_LOADS` جھنڊو مقرر ٿيل آهي ، ڇاڪاڻ ته انهي بابت ايم ايس وي سي جي پنهنجي دستاويزن مطابق: "This is the fastest, most efficient way to use the symbol handler." ، انهي ڪري اچو ته ائين ڪريون!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // اصل ۾ MSVC سان علامتن جي شروعات ڪريو.نوٽ ڪيو ته هي ناڪام ٿي سگهي ٿو ، پر اسان ان کي نظرانداز ڪريون ٿا.
        // انهي جي لاءِ اڳئين فن جو هڪ ٽن نه آهي ، پر ايل ايل وي ايم اندروني طور تي هتي واپسي جي قيمت کي نظرانداز ڪرڻ لڳي ٿو ۽ ايل ايل وي ايم ۾ صفائي ڪندڙ لائبريري هڪ خوفناڪ انتباہ ڇڪيندي آهي جيڪڏهن اهو ناڪام ٿئي پر بنيادي طور تي انهي کي ڊگهي عرصي ۾ نظرانداز ڪري ٿو.
        //
        //
        // هڪ ڪيس Rust لاءِ گهڻو ڪجهه اچي ٿو ته معياري لائبريري ۽ crates.io تي اهو crate ٻئي `SymInitializeW` لاءِ مقابلو ڪرڻ چاهين ٿا.
        // معياري لائبريري تاريخي طور تي شروعات ڪرڻ چاهي ٿي اڪثر وقت جي صفائي ، پر هاڻي ته اهو crate استعمال ڪري رهيو آهي ان جو مطلب اهو آهي ته ڪنهن شخص کي پهريان شروعات شروع ٿيندي ۽ ٻئي ماڻهو ان شروعات کي ئي کڻندا.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}