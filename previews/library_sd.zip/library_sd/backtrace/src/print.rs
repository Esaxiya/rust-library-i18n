#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// پٺاڻن لاءِ هڪ فارمولو.
///
/// اهو قسم ڪنهن به پس منظر کي پرنٽ ڪرڻ لاءِ استعمال ڪري سگهجي ٿو قطع نظر ته انهي جو اهو پس منظر ڪٿان آيو آهي.
/// جيڪڏهن توهان وٽ `Backtrace` قسم آهي ته انهي جي `Debug` عمل درآمد اڳ ۾ ئي انهي پرنٽنگ فارميٽ کي ڪري ٿو.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// پرنٽنگ جا انداز جيڪي اسين پرنٽ ڪري سگھون ٿا
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// هڪ نن backڙي پٺاڻ واري پيچري کي پرنٽ ڪندو آهي جيڪو مثالي طور تي صرف لاڳاپيل معلومات تي مشتمل هوندو
    Short,
    /// ھڪڙي پوئتي رستو ڇپائي جيڪا ھر ممڪن معلومات تي مشتمل ھجي
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// ھڪڙو نئون `BacktraceFmt` ٺاھيو جيڪو مهيا ڪيل `fmt` ڏانھن ٻاھران لکندو.
    ///
    /// `format` دليل ان انداز تي ڪنٽرول ڪندو جنهن ۾ پس منظر ڇپيل هجي ، ۽ `print_path` دليل فائلن جي `BytesOrWideString` مثالن کي پرنٽ ڪرڻ لاءِ استعمال ڪئي ويندي.
    /// اهو قسم پنهنجو نالو فائلن جي ڪنهن به پرنٽنگ کي نه ڪندو آهي ، پر اهو ڪال ڪرڻ لازمي آهي.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// پرنٽ ڪرڻ جي لاءِ اڳڀرائي واري جاءِ کي اڳ ۾ ئي آڻي ٿو.
    ///
    /// اهو ڪجهه پليٽ فارمن تي لازمي طور تي مڪمل نشاني طور تي پوءِ نشر ٿيڻ جي ضرورت آهي ، ٻي صورت ۾ اهو صرف پهريون طريقو هئڻ گهرجي جيڪو توهان `BacktraceFmt` ٺاهڻ بعد ڪال ڪريو.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// پسمانده محصول ۾ هڪ فريم شامل ڪندو.
    ///
    /// اهو بنا `BacktraceFrameFmt` جي هڪ RAII مثال موٽائي ٿو جيڪو اصل ۾ هڪ فريم پرنٽ ڪرڻ لاءِ استعمال ٿي سگهي ٿو ، ۽ تباهي تي اهو فريم ڪائونٽر کي وڌائيندو.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// پٺتي پيل ٻا output کي مڪمل ڪرڻ.
    ///
    /// اهو في الحال او پي او آهي پر future مطابقت لاءِ وڌايو ويو آهي backtrace فارميٽس سان.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // في الحال ڪوبه او پي ايس-hook سميت future اضافو کي اجازت ڏيڻ شامل ناهي.
        Ok(())
    }
}

/// ھڪڙي پسمنظر جي ھڪڙي فريم لاءِ ھڪڙي فارميٽر.
///
/// هي قسم `BacktraceFmt::frame` فنڪشن پاران ٺهيل آهي.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// فريم فارميٽر سان `BacktraceFrame` پرنٽ ڪري ٿو.
    ///
    /// اهو `BacktraceFrame` اندر سڀني `BacktraceSymbol` مثالن کي ٻيهر ورجائيندو.
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// ھڪڙي `BacktraceSymbol` اندر `BacktraceSymbol` پرنٽ ڪري ٿو.
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: هي زبردست ناهي ته اسان ڪا شي ڇپائي ختم نه ڪريون
            // غير utf8 فائلن جي نالن سان.
            // مهرباني ڪري تقريبا هر شي ايڪس ايمڪس آهي ، تنهنڪري اهو تمام خراب به نه هجڻ گهرجي.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// خام پيچرو ٿيل `Frame` ۽ `Symbol` ڇاپيو ، خاص طور تي انهي crate جي خام ڪال بڪ اندر.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// واپسي جي محصول ۾ خام فريم شامل ڪريو.
    ///
    /// اهو طريقو ، پوئين طرح جي برعڪس ، ڪيسن ۾ اهي خام جڳھون وٺن ٿيون جيڪڏهن اهي مختلف جڳهن مان حاصل ڪيا وڃن
    /// ياد رکجو ته اھو شايد ھڪڙي فريم لاءِ ڪيترائي ڀيرا سڏيو وڃي ٿو.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// پسمنظر جي محصول ۾ خام فريم شامل ڪريو ، ڪالمن جي includingاڻ سميت.
    ///
    /// اھو طريقو ، پوئين وانگر ، خام دليل کڻي ٿو جيڪڏھن اھي مختلف جڳھن مان ماخذ ٿي وڃن.
    /// ياد رکجو ته اھو شايد ھڪڙي فريم لاءِ ڪيترائي ڀيرا سڏيو وڃي ٿو.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // فوڪسيا هڪ عمل جي اندر علامت ڏيڻ کان قاصر آهي انهي ڪري ان جو هڪ خاص شڪل آهي جيڪو بعد ۾ علامت لاءِ استعمال ٿي سگهي ٿو.
        // پرنٽ ڪيو هتي بدران اسان جي پنهنجي فارميٽ ۾ پتي ڇپائڻ.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" فريم پرنٽ ڪرڻ جي ضرورت ناهي ، اهو بنيادي طور تي صرف اهو آهي ته سسٽم جي پٺتي پيل گهڻي پري کان پوئتي ڏسڻ جو ڏا eagerو شوق هو.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx انڪلي ۾ ٽي سي بي جو سائز گهٽائڻ لاءِ ، اسان علامت ريزيوشن فعاليت تي عمل ڪرائڻ نٿا چاهيون.
        // بلڪ ، اسان هتي پتي جي اوٽ پرنٽ ڪري سگهون ٿا ، جيڪا بعد ۾ فليپ ٿي سگهي ٿي صحيح ڪم ڪرڻ لاءِ.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // ڇپائي فريم جي انڊيڪس ۽ گڏوگڏ فريم جي اختياري هدايت واري پوائنٽر.
        // جيڪڏهن اسان انهي فريم جي پهرين علامتي کان ٻاهر آهيون جيتوڻيڪ اسان صرف مناسب اسپيس واري جڳهه کي پرنٽ ڪريون ٿا.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // اڳتي هلي علامت جو نالو لکو ، وڌيڪ معلومات لاءِ متبادل فارميٽنگ استعمال ڪندي جيڪڏهن اسان مڪمل پٺيون پيل آهيون.
        // هتي اسان پڻ نشانيون سنڀاليون ٿا جنهن جو نالو ناهي ،
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // ۽ آخري مٿي ، filename/line نمبر پرنٽ ڪريو جيڪڏھن اھي موجود ھجن.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line علامت جي نالي هيٺ لڪيل تي ڇپيل آهن ، تنهن ڪري پاڻ کي درست ڪرڻ لاءِ ڪجهه مناسب جاءِ خالي ڪريو.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // فائيل نالي کي پرنٽ ڪرڻ لاءِ اسان جي اندروني ڪاليڪ بڪ تي پهچايو ۽ پوءِ لائن نمبر تي ڇپايو.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // جيڪڏهن دستياب هجي ڪالم نمبر شامل ڪريو.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // اسان صرف هڪ فريم جي پهرين علامت جي پرواهه ڪندا آهيون
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}