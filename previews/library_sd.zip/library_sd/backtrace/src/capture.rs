use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// ملڪيت ۽ نفس تي مشتمل پٺاڻن جي نمائندگي.
///
/// اها canانچي ڪنهن پروگرام ۾ مختلف نقطن تي پٺاڻ پڪڙڻ لاءِ استعمال ڪري سگهجي ٿي ۽ بعد ۾ ان تي چڪاس ڪئي وئي ته انهي وقت جي پوئتي موٽ ڪهڙي وقت ۾ هئي.
///
///
/// `Backtrace` ان جي `Debug` عمل جي ذريعي پٺاڻن جي خوبصورت ڇپائي جي حمايت ڪندو آهي.
///
/// # گهربل خاصيتون
///
/// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // هتان جي چوٽي کان مٿين طرف کان هيٺ فريم درج ٿيل آهن
    frames: Vec<BacktraceFrame>,
    // انڊيڪس جنهن تي اسان يقين رکون ٿا پوئتي موٽڻ جي اصل شروعات ، `Backtrace::new` ۽ `backtrace::trace` وانگر فريم ختم ڪرڻ.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// هڪ پسمنظر ۾ فريم جو گرفتار ڪيل نسخو.
///
/// اهو قسم `Backtrace::frames` کان لسٽ جي طور تي واپس آيو آهي ۽ هڪ اسٽيڪ فريم ظاهر ٿيل پٺتي پيل ۾ ظاهر ٿئي ٿو.
///
/// # گهربل خاصيتون
///
/// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// هڪ پسمنظر ۾ هڪ علامه جو قبضو ڪيل نسخو.
///
/// اهو قسم `BacktraceFrame::symbols` کان لسٽ جي طور تي واپس آيو آهي ۽ پوئتي رستو ۾ علامت لاءِ ميٽا ڊيٽا کي نمائندگي ڪري ٿو.
///
/// # گهربل خاصيتون
///
/// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// هن فنڪشن جي ڪال سائيٽ تي هڪ پٺاڻ قبضو ڪيو آهي ، ملڪيت واري نمائندگي واپس ڪندي.
    ///
    /// اهو ڪم Rust ۾ اعتراض جي طور تي پٺتي پيل جي نمائندگي لاءِ مفيد آهي.اها واپسي قيمت موڪلي وڃي ٿي ٻين موضوعن تي ۽ ڇپيل ٻئي هنڌ تي ، ۽ انهي قيمت جو مقصد مڪمل طور تي پنهنجي ذات ۾ هجڻ آهي.
    ///
    /// ياد رهي ته ڪجهه پليٽ فارم تي مڪمل پسمنظر حاصل ڪرڻ ۽ ان کي حل ڪرڻ تمام وڏي مهانگي ٿي سگهي ٿي.
    /// جيڪڏهن قيمت توهان جي ايپليڪيشن لاءِ تمام گهڻي آهي ان جي بدران ايڪس سي ايڪس ايڪس استعمال ڪرڻ جي سفارش ڪئي وئي آهي جيڪو علامت جي حل واري قدم کان پاسو ڪري ٿو (جيڪو عام طور تي تمام گهڻو ڊگهو وٺندو آهي) ۽ بعد ۾ ان کي دير سان آڻڻ جي اجازت ڏئي ٿو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // پڪ ڪرڻ چاهيان ٿو ته هتي هٽائڻ وارو فريم آهي
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new` سان ساڳي طرح بغير هي ڪنهن به علامتن کي حل نٿو ڪري ، اهو رڳو پتي جي فهرستن جي فهرست طور قبضو ڪري ٿو.
    ///
    /// بعد ۾ `resolve` فنڪشن کي سڏيو وڃي ٿو ته هن پسمنظر جي علامن کي پڙهڻ جي نالن ۾ حل ڪرڻ لاء.
    /// اها فنڪشن موجود آهي ڇاڪاڻ ته ريزوليوشن وارو عمل ڪڏهن ڪڏهن اهم وقت وٺي سگهندو آهي جڏهن ته ڪو به پوئتي وارو رستو صرف گهٽ ئي ڇپجي سگهندو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // نالي وارا نالا ناھن
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // نالن جا نالا هاڻي موجود آهن
    /// ```
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    ///
    ///
    #[inline(never)] // پڪ ڪرڻ چاهيان ٿو ته هتي هٽائڻ وارو فريم آهي
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// فريم لوٹائيندو آهي جتان جڏهن اهو پٺاڻ پڪڙيو ويو هو.
    ///
    /// هن سلائس جي پهرين داخلا ممڪن آهي فنڪشن `Backtrace::new` ، ۽ آخري فريم ممڪن آهي ته ڪجهه هن باري ۾ يا هي بنيادي ڪم ڪيئن شروع ٿيو.
    ///
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// جيڪڏهن `new_unresolved` کان انهي پس منظر ٺاهيو ويو ته اهو ڪم سڀني پتي کي انهن جي علامتي نالن ۾ حل ڪندو.
    ///
    ///
    /// جيڪڏهن اهو پٺاڻ اڳ ۾ حل ٿي ويو آهي يا `new` ذريعي ٺاهي وئي هئي ، اهو فنڪشن ڪجهه به نٿو ڪري.
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` وانگر ساڳيو
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` وانگر ساڳيو
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` وانگر ساڳيو
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// علامتن جي فهرست واپس ڏئي ٿو جيڪا هن فريم سان مشابهت رکي ٿي.
    ///
    /// عام طور تي في فريم ۾ صرف هڪ علامت هوندي آهي ، پر ڪڏهن ڪڏهن جيڪڏهن هڪ فريم ۾ ڪيترن ئي ڪمن جي انگ وڌي وئي آهي ته ڪيترن ئي نشانن کي موٽايو ويندو.
    /// پهرين علامت درج ٿيل آھي "innermost function" ، جڏھن ته آخري نشاني ٻاھر آھي سڀ کان وڌيڪ (آخري ڪالر).
    ///
    /// ياد رکجو ته جيڪڏهن اهو فريم اڻ حل ٿيل ٽٽل مان آيو آهي ته پوءِ هي خالي فهرست موٽائيندو.
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` وانگر ساڳيو
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` وانگر ساڳيو
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` وانگر ساڳيو
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` وانگر ساڳيو
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` وانگر ساڳيو
    ///
    /// # گهربل خاصيتون
    ///
    /// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // جڏهن رستا ڇپائي ته اسان موجود آهيون ڪي وي ڊي کي اڇلائڻ جي ڪوشش ڪريون ، ٻي صورت ۾ اسان صرف رستي کي پرنٽ ڪريون ٿا.
        // ياد رکو ته اسان به انهي مختصر فارميٽ لاءِ ئي ڪريون ، ڇاڪاڻ ته جيڪڏهن اها مڪمل ٿي وڃي ته اسان شايد هر شيءَ کي پرنٽ ڪرڻ چاهيون ٿا.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}