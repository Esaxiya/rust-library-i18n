use core::ffi::c_void;
use core::fmt;

/// موجوده ڪال-اسٽيڪ جو معائنو ڪريو ، اسٽيڪ ٽريس جو حساب ڏيڻ لاءِ مهيا ڪيل سموري فريم کي مڪمل بندش ۾ داخل ڪرڻ.
///
/// اهو ڪم هن لائبريري جي ڪم ڪار آهي ، هڪ پروگرام لاءِ اسٽيڪ نشان جي حساب سان.ڏنل بندش `cb` ھڪڙي `Frame` جا مثال آھن جيڪي اسٽيڪ تي انهي ڪال فريم بابت معلومات جي نمائندگي ڪن ٿا.
/// بند ٿيل قيمت کان مٿي هڪ هيٺئين حصي ۾ پيدا ڪئي وئي آهي (سڀ کان پهريان نئين ڪارڪردگي واري نالي سان).
///
/// بندش جي واپسي جي قيمت ان ڳالهه جو اشارو آهي ته ڇا پٺاڻ هلڻ جاري آهي؟`false` جي واپسي قيمت واپسي جي رستي کي ختم ڪندي ۽ فوري طور تي واپسي.
///
/// هڪ دفعو `Frame` حاصل ڪيو ويو توهان کي شايد `backtrace::resolve` کي فون ڪرڻ چاهين ها `ip` (هدايت ڏيندڙ پوائنٽر) يا ايڪس ايڊ ايڊريس کي `Symbol` ڏانهن جنهن جي ذريعي نالو ۽/يا فائيل نام/لائن نمبر سکيو وڃي.
///
///
/// ياد رکو ته اهو نسبتا گهٽ درجه بندي وارو ڪم آهي ۽ جيڪڏهن توهان چاهيو ٿا ، مثال طور ، بعد ۾ معائنو ڪرڻ لاءِ هڪ پٺتي پيل پيچري تي قبضو ڪيو وڃي ، پوءِ `Backtrace` قسم وڌيڪ مناسب ٿي سگهي ٿو.
///
/// # گهربل خاصيتون
///
/// هن فنڪشن کي فعال ڪرڻ جي لاءِ `backtrace` crate جي `std` خصوصيت جي ضرورت آهي ، ۽ `std` خصوصيت پهريان کان ترتيب ڏنل آهي.
///
/// # Panics
///
/// اهو فنڪشن panic کي ڪڏهن به ناڪام ڪرڻ جي ڪوشش ڪندو آهي ، پر جيڪڏهن ايڪس سيڪس panics مهيا ڪئي ته پوءِ ڪجهه پليٽ فارم هڪ دوئي panic کي مجبور ڪندا ته ان عمل کي ختم ڪري.
/// ڪي پليٽ فارم سي لائبريري استعمال ڪن ٿا جيڪي اندروني طور تي ڪال بيڪ استعمال ڪن ٿا جن کي بغير ختم نٿو ڪري سگهجي ، تنهن ڪري `cb` کان ڇڪڻ هڪ عمل ختم ڪري سگھي ٿو.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // پوئتي رستو جاري رکو
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// ساڳيو `trace` وانگر ، صرف غير محفوظ آهي جيئن اهو غير مطابقت پذير آهي.
///
/// ھن فنڪشن کي هم وقت سازي جي گارنٽيز نھ آھي پر دستياب آھي جڏھن ھن crate جي `std` خصوصيت مرتب ٿيل ناھي.
/// وڌيڪ دستاويزن ۽ مثالن لاءِ `trace` وارو فنڪشن ڏسو.
///
/// # Panics
///
/// `cb` کان ڇڪڻ تي ڪنورات وارن لاءِ `trace` تي معلومات ڏسو.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// ھڪڙي trait ھڪڙي رستي واري ھڪڙي فريم جي نمائندگي ڪري ٿو ، هن crate جي `trace` ڪارڪردگي ڏانھن ڏني.
///
/// ٽريشنگ جي فنڪشن جي بندش پيدا ٿي ويندي فريم ، ۽ فريم پوري طور تي موڪلي وئي آهي جئين رن ٽائيم تائين بنيادي نفاذ هميشه معلوم ناهي.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// ھن فريم جي موجوده هدايت ڏيندڙ کي ورجائي ٿو۔
    ///
    /// اهو عام طور تي فريم ۾ عملدرآمد لاءِ ايندڙ هدايتون آهن ، پر س implementي عملدرآمد هن کي 100 سيڪڙو درستگي سان لسٽ نه ڪندو آهي (پر اهو عام طور تي گهڻو ويجهو هوندو آهي).
    ///
    ///
    /// اهو قيمت ايڪس آرڪس ۾ منتقل ڪرڻ جي سفارش ڪئي وئي آهي ته ان کي سمبل نالي ۾ تبديل ڪيو وڃي.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// ھن فريم جي موجوده اسٽيڪ پوائنٽر کي ورجائي ٿو.
    ///
    /// ان صورت ۾ ته هڪ پسمنظر هن فريم لاءِ اسٽيڪ پوائنٽر کي واپس نٿو وٺي سگھي ، هڪ نيور پوائنٽر واپس ڪيو ويندو آهي.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// هن فنڪشن جي فريم جو شروعاتي علامت ڏيکاري ٿو.
    ///
    /// اهو هدايتڪار پوائنٽ کي واپس ڪرڻ جي ڪوشش ڪندو `ip` پاران ڪم جي شروعات ڏانهن واپس ، انهي قيمت کي واپس ڪندي.
    ///
    /// ڪجهه حالتن ۾ ، جڏهن ته ، انهي پس منظر مان صرف `ip` واپس آڻيندا.
    ///
    /// واپسي وارو قدر ڪڏهن ڪڏهن استعمال ڪري سگھجي ٿو جيڪڏهن `backtrace::resolve` مٿي ڏنل `ip` تي ناڪام ٿيو.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// جنهن ماڊل جي فريم سان تعلق رکي ٿو انهي جو بنيادي پتو موٽائي ٿو.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // انهي کي پهرين اچڻ جي ضرورت آهي ، انهي کي يقيني بڻائڻ لاءِ ته ميئر ميزبان پليٽفارم تي اوليت وٺندي آهي
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // صرف dbghelp ۾ استعمال ٿيل علامت
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}