use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr هڪ ڪال ڪ takesي ٿو جيڪو هر ڊي ايس او کي dl_phdr_info پوائنٽر وصول ڪندو جيڪو عمل ۾ ڳن hasيل هوندو.
    // dl_iterate_phdr پڻ انهي ڳالهه کي يقيني بڻائي ٿو ته متحرڪ ڳنerيندڙ بند ٿي چڪو آهي شروع کان ختم ٿيڻ تائين.
    // جيڪڏهن ڪال ڪليڪ واپس غير صفر جي قيمت ڏياري وڃي ته ورجائي جلد ختم ڪئي ويندي آهي.
    // 'data' هر ڪال تي ڪال بيڪ لاءِ ٽئين دليل طور پاس ڪيو ويندو.
    // 'size' dl_phdr_info جي ماپ ڏي ٿو.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// اسان کي تعمير ID ۽ ڪجهه بنيادي پروگرام جي هيڊر ڊيٽا جو جائزو وٺڻ جي ضرورت آهي جنهن جو مطلب آهي ته اسان کي اي ايل ايف جي چشمي مان ٿورڙو به سامان گهرجي.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// هاڻي اسان کي نقل ڪرڻي پوندي ، ڪجهه دير لاءِ فارڪسيا جي موجوده متحرڪ ڳنerيندڙ پاران استعمال ڪيل ڊبل_ phdr_info قسم جي ساخت.
// Chromium وٽ هي اي بي آئي جي حد آهي ۽ انهي سان گڏ ڪيش پيڊ پڻ.
// آخرڪار اسين ايفي تلاش کي استعمال ڪرڻ لاءِ انهن ڪيسن کي منتقل ڪرڻ چاهيندا هئاسين پر اسان کي انهي کي فراهم ڪرڻ جي ضرورت آهي SDK ۾ ۽ اهو اڃا تائين نه ٿيو آهي.
//
// اهڙيءَ طرح اسين (۽ اهي) هن طريقي کي استعمال ڪرڻ جي ڪري چڙهي پيا آهيون جنهن کي فوڪسيا ليبڪ سان تنگ ڪڙي آڻڻ سان گڏ.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // اسان کي ofاڻڻ جو ڪو طريقو ناهي ته ايڪس_فوف ۽ اي_فنم جائز آهن.
    // انهي لاءِ اسان کي انهي جي حفاظت ڪرڻ گهرجي ، انهي ڪري اهو هتي سلائس ٺاهڻ محفوظ آهي.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// ايلف_ پي ايڇ ڊي هڪ ٽارگيٽ فن تعمير جي پ inاڻي ۾ 64 بٽ اي ايل ايف پروگرام جو هيڊر ظاهر ڪري ٿو.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr ھڪڙي صحيح اي ايل ايف پروگرام جي هيڊر ۽ ان جي مواد کي ظاھر ڪري ٿو.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // اسان وٽ پيڇو جو رستو ناهي ته ڇا p_addr يا p_memsz صحيح آهن.
    // فوسيشيا جو لائب پهرين نوٽس کي بيان ڪري ٿو تنهن ڪري هتي هجڻ جي ڪري هنن هيڊرن کي صحيح هجڻ گهرجي.
    //
    // نوٽ آئيٽر کي ھيٺئين beاڻ واري صحيح ڊيٽا جي ضرورت نه آھي پر اھو اھو صحيح ڪندو آھي ته حدون صحيح آھن.
    // اسان ڀروسو ڪيو آهي ته لبنڪ اهو يقين ڏياريو آهي ته هي اسان هتي هتي آهي.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// تعمير IDs لاءِ نوٽ جو قسم.
const NT_GNU_BUILD_ID: u32 = 3;

// ايلف اين ايڇ ڊي آر جي هدف جي پڇاڙيء ۾ اي ايل ايف نوٽ هيڊر جي نمائندگي ڪري ٿي.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// نوٽ اي ايل ايف نوٽ (هيڊر + مواد) کي ظاهر ڪري ٿو.
// نالو u8 سليس وانگر ڇڏي ويو آهي ڇاڪاڻ ته اهو هميشه خالي ختم نه ٿيو آهي ۽ rust اهو ڪافي آسان بڻائي ٿو ته اهو بائيٽ جو ڪنهن به طرح سان ملندڙ هجي.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter توهان کي محفوظ طور تي نوٽ جي ڀا segmentي جي مٿان وڃڻ جي اجازت ڏي ٿو.
// اهو جلدي ختم ٿئي ٿو جئين غلطي ٿئي ٿي يا ڪوبه وڌيڪ ياداشت ناهي.
// جيڪڏهن توهان غلط ڊيٽا مٿان ورهايو ٿا ، اهو ائين ڪم ڪندو thoughڻ ته ڪو نوٽس ڪونه مليو.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // اهو هڪ فعل جو تڪرار آهي ته پوائنٽر ۽ سائيز ڏنل بائيٽ جي صحيح رينج جي وضاحت ڪن ٿا جيڪي سڀئي پڙهي سگهندا آهن.
    // انهن بائٽس جي مواد ڪجهه به ٿي سگهي ٿو پر ان جي محفوظ هجڻ جي لاءِ رينج صحيح هجڻ لازمي آهي.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to align=x00X to `byte-byte alignment=x01X فرض ڪريو 2 جي طاقت.
// اهو سي/سي ++ اي ايل ايف جي ترتيب واري ڪوڊ ۾ هڪ معياري نمونو هيٺ ڏنل آهي جتي (x + کان ، 1)&-to استعمال ٿئي ٿو.
// Rust توهان کي استعمال ڪرڻ جي اجازت نٿو ڏي ته آئون استعمال ڪريان ٿو
// انهي کي ٻيهر بڻائڻ لاءِ 2 جي مڪمل تبديلي.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 سليس کان نمبر بائٽس خرچ ڪري ٿو (جيڪڏھن موجود آھي) ۽ اضافي سان يقيني بڻائي ٿو ته آخري سليس صحيح طرح سان ٺاھيو ويو آھي.
// جيڪڏهن يا ته ڏنل بائٽس جي تعداد تمام وڏي آهي يا سلائس بعد ۾ نٿي رکي سگهجي ته ڪافي بائٽس موجود نه هجڻ جي ڪري ، ڪو به واپس نه آيو ۽ سلائس تبديل ٿيل نه آهي.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// ھن فنڪشن جي ھڪڙي حقيقي invariants نه آھي ڪال ڪري ٻين کان مٿي برقرار رکي تہ شايد 'bytes' ڪارڪردگي لاءِ جڙيل ھئڻ گھرجي (۽ ڪجهه معمارن جي درستگي تي).
// ايلف_نڇر جي شعبن ۾ قدرون بيڪار ٿي سگھن ٿيون پر اهو فنڪشن انهي ۾ يقيني ڪونه ٿو رکي.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // اهو محفوظ آهي جيستائين ڪافي جڳهه آهي ۽ اسان صرف اهو صحيح ڪيو ته جيڪڏهن بيان ۾ مٿي بيان ڪيو ويو آهي تنهنڪري اهو غير محفوظ نه هجڻ گهرجي.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // ياد رکجو سس_ف: :<Elf_Nhdr>() هميشه 4-بائيٽ سان لاڳاپيل آهي.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // چيڪ ڪريو ته اسان آخرڪار پهچي ويا آھيون.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // اسان هڪ اين ايڇ ڊي کي منتقل ڪيو پر اسان احتياط سان نتيجو ٺاهيندا آهيون.
        // اسان نالن يا ڊسڪز تي ڀروسو نٿا ڪريون ۽ اسان قسم جي بنياد تي ڪي غير محفوظ فيصلا نٿا ڪريون.
        //
        // تنھنڪري اسان جيڪڏھن مڪمل رٻڙ مان نڪتاسين ته پوءِ به اسان کي محفوظ رھڻ گھرجي.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// ظاهر ڪري ٿو ته هڪ ڀا isو عملدار آهي.
const PERM_X: u32 = 0b00000001;
/// ظاهر ڪري ٿو ته هڪ حصو قابل لکڻ آهي.
const PERM_W: u32 = 0b00000010;
/// ظاهر ڪري ٿو ته هڪ ڀا segmentو پڙهي سگھجي ٿو.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// رن ٽائيم تي اي ايل ايف حصي کي نمائندگي ڪندو آهي.
struct Segment {
    /// هن ڀا'sي جي مواد جي رن ٽائيم مجازي پتي ڏئي ٿو.
    addr: usize,
    /// ھن ڀا segmentي جي مواد جي ميموري وارو سائز ڏئي ٿو.
    size: usize,
    /// اي ايل ايف فائل سان گڏ هن حصي جو ماڊل مجازي خطاب ڏئي ٿو.
    mod_rel_addr: usize,
    /// اي ايل ايف فائل ۾ ملندڙ اجازتون ڏئي ٿو.
    /// ضروري طور تي اهي اجازتون وقت نه پر موجود آهن.
    flags: Perm,
}

/// هڪ DSO کان ڀا Segن جي تهذيب جي اجازت ڏئي ٿو.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// اي ايل ايف ڊي ايس او (متحرڪ شيئر ٿيل آبجیکٹ) جي نمائندگي ڪندو آهي.
/// اهو قسم پنهنجي ڪاپي ٺاهڻ بجاءِ حقيقي ڊي ايس او ۾ محفوظ ٿيل ڊيٽا جي حوالي ڪري ٿو.
struct Dso<'a> {
    /// متحرڪ ڳن linkيندڙ اسان کي هميشه هڪ نالو ڏئي ٿو ، جيتوڻيڪ اهو نالو خالي هجي.
    /// مکيه عملدار جي صورت ۾ اهو نالو خالي ٿيندو.
    /// ھڪڙي حصيداري ڪيل اعتراض جي صورت ۾ ، اھو ان جو نالو هوندو (DT_SONAME ڏسو).
    name: &'a str,
    /// فوڪسيا تي لڳ ڀڳ سڀني بائنريز آئي ڊيز ٺاهيون آهن پر اها سخت گهرج ناهي.
    /// هتي ڊي ايل او جي معلومات کي اصل اي ايل ايف فائل سان ملائڻ جو ڪو طريقو ناهي ته جيڪڏهن ڪو تعمير نه آهي.ته اسان جي گهرج آهي ته هر ڊي ايس او کي هتي هجي.
    ///
    /// ڊي ايس او جي بغير بلڊ_ڊ کي نظرانداز ڪيو ويو آهي.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// ھن DSO ۾ ٽڪرن تي مھرباني ڪندڙ کي واپس ڏئي ٿو.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// اهي غلطيون مسئلا encاڻينديون آهن جيڪي هر ڊي ايس او جي باري ۾ معلومات جي وضاحت ڪندي پيدا ٿينديون آهن.
///
enum Error {
    /// نالو ايرر جو مطلب آھي ھڪڙي غلطي ٿي ڪري آھي جڏھن سي اسٽائل اسٽرنگ کي rust اسٽرنگ ۾ تبديل ڪندي.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError جو مطلب اهو آهي ته اسان کي بلڊنگ آءِ ڊي نه ملي.
    /// اهو ٿي سگهي ٿو ڇاڪاڻ ته ڊي ايس او وٽ بلڊ ID نه هئي يا ڇاڪاڻ ته اهو حصو جنهن ۾ ڊي ڊي ID شامل هئي بدنامي هئي.
    ///
    BuildIDError,
}

/// متحرڪ لنڪٽر طرفان پروسيس ۾ ڳن eachيل هر ڊي ايس او لاءِ يا ته 'dso' يا 'error' يا وري ڪال ڪري ٿو.
///
///
/// # Arguments
///
/// * `visitor` - هڪ ڊي او پرسنٽر جنهن وٽ هوندو هر کائڻ جو طريقو ڊي ايس او جي اڳڪٿي آهي.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr يقيني بڻائي ٿو ته info.name صحيح جڳھ ڏانھن اشارو ڪندو.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// اهو فنڪشن DSO ۾ موجود سڀني معلومات لاءِ فوڪسيا سمبلائزر مارڪ اپ پرنٽ ڪندو آهي.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}