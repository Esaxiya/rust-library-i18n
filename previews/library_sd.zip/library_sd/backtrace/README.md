# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust لاء رنٽ ٽائمز حاصل ڪرڻ لاءِ لائبريري.
هن لائبريري سان ڪم ڪرڻ لاءِ پروگراماتي انٽرفيس فراهم ڪندي معياري لائبريري جي سهڪار وڌائڻ جو مقصد آهي ، پر اهو پڻ آسان طور تي موجوده پٺاڻن کي پرنٽ ڪرڻ جي اجازت ڏئي ٿو جهڙوڪ libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

صرف پوئتي موٽ تي قبضو ڪرڻ ۽ ان کي هلندڙ دير تائين دير ڪرڻ لاءِ دير ڪرڻ جي لاءِ ، توهان مٿئين سطح جي `Backtrace` قسم استعمال ڪري سگهو ٿا.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

پر ، بهرحال ، توهان حقيقي ٽريڪنگ ڪارڪردگي تي وڌيڪ خام رسائي چاهيو ٿا ، توهان سڌو سنئون `trace` ۽ `resolve` استعمال ڪري سگهو ٿا.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // هن هدايت نامو کي علامتي نالي ۾ حل ڪريو
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // ايندڙ فريم تي وڃو
    });
}
```

# License

هن منصوبي تحت ڪنهن به يا تحت لائسنس ڏنل آهي

 * Apache لائسنس ، نسخو 2.0 ، ([LICENSE-APACHE](LICENSE-APACHE) يا http://www.apache.org/licenses/LICENSE-2.0)
 * ايمٽ لائسنس ([LICENSE-MIT](LICENSE-MIT) يا http://opensource.org/licenses/MIT)

توهان جي اختيار تي.

### Contribution

ايستائين جيستائين توهان واضح طور تي ٻي صورت ۾ بيان نه ڪريو ، توهان جي طرفان بڪ ٽرانس رائونس ۾ شموليت لاءِ ارادو پيش ڪيو ويو ، جئين Apache-2.0 لائسنس ۾ وضاحت ڪئي وئي آهي ، مٿي ڏنل ڊبل لائسنس ڪيو ويندو ، اضافي شرطن ۽ شرطن کانسواءِ.







