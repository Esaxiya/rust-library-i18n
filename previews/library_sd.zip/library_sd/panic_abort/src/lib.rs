//! پروسيس ختم ٿيڻ جي ذريعي Rust panics تي عمل درآمد
//!
//! جڏهن بغير اچڻ جي عمل درآمد جي مقابلي ۾ ، اهو crate *تمام* سادو آهي!اھو چيو وڃي ٿو ، اھو ڪافي طور تي ھڪڙو لچڪدار نھ آھي ، پر ھتي وڃي ٿو!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" سوال ۾ پليٽ فارم تي ممنوع ادا ۽ ادائيگي شيم.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // ڪال std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Windows تي ، پروسيسر جي خاص __ فاسٽ فيل ميڪزم کي استعمال ڪريو.Windows 8 ۽ بعد ۾ ، اهو بغير ڪنهن پروسيس استثنا سنڀاليندڙن کي هلائڻ کان بغير فوري طور تي پروسيس ختم ڪري ڇڏيندو.
            // Windows جي اڳوڻي نسخن ۾ ، هدايتن جو اهو تسلسل هڪ رسائي جي خلاف ورزي جي طور تي علاج ڪيو ويندو ، عمل کي ختم ڪرڻ ، پر لازمي طور تي سڀني استثنا سنڀاليندڙن کي رد ڪندي.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: اهو ساڳيو ئي نفاذ آهي جيترو لبيا ڊي `abort_internal` ۾
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// هي ... ڪجهه عجيب آهي.ٽي ؛ ڊاڪٽر ؛ڇا اهو لازمي طور تي ڳن toڻ جي ضرورت آهي ، ڊگهي وضاحت هيٺ ڏنل آهي.
//
// هينئر libcore/libstd جي ڊائنرون جيڪي اسان شپ ڪيون آهن `-C panic=unwind` سان گڏ سڀ گڏ ٿيل آهن.اهو يقيني بڻائڻ لاءِ ڪيو ويو آهي ته بائنريز وڌ کان وڌ ممڪن طور تي گهڻن حالتن سان مطابقت رکندڙ آهن.
// تنهن هوندي به ترتيب ڏيندڙ ، `-C panic=unwind` سان گڏ سڀني ڪم ڪارن لاءِ هڪ "personality function" جي ضرورت هوندي آهي.اهو شخصيت ڪم کي `rust_eh_personality` نشان ڏانهن سخت آهي ۽ `eh_personality` لانگ شيون بيان ڪيو ويو آهي.
//
// So...
// هتي رڳو لينگ شيءَ جي وضاحت ڇو نه ڪئي وئي آهي؟سٺو سوال!panic رنٽ ٽائمز سان ڳن areيل آهي اصل ۾ اهو ٿورو ننtleڙو آهي ته اهي مرتب ڪندڙ crate اسٽور ۾ "sort of" آهن ، پر صرف هڪ ٻئي سان اصل ۾ ڳن isn'tيل نه آهي جڏهن ته اصل ۾ ڳن linkedيل آهن.
//
// آخر ۾ اهو مطلب آهي ته ٻئي crate ۽ panic_unwind crate مرتب ڪندڙ crate اسٽور ۾ ظاهر ٿي سگهن ٿا ، ۽ جيڪڏهن ٻئي `eh_personality` لانگ شيون بيان ڪندا ته پوءِ اهو غلطي ماريندو.
//
// انهي کي سنڀالڻ لاء ، صرف ان صورت ۾ `eh_personality` بيان ڪيو ويندو آهي جيڪڏهن panic رن ٽائيم ڳن linkedيل ٿيڻ وارو نه هو هلڻ وارو وقت ، ۽ ٻي صورت ۾ اهو بيان ڪرڻ جي ضرورت ناهي (صحيح طور تي ائين).
// انهي صورت ۾ ، جيتوڻيڪ ، هي لائبريري صرف هن علامت جي وضاحت ڪري ٿي ، تنهن ڪري اتي گهٽ ۾ گهٽ ڪجهه شخصيت موجود آهي.
//
// بنيادي طور تي اهو نشان صرف libcore/libstd بائنريز تائين وائرڊ ٿيل هئڻ جي لاءِ بيان ڪيو ويو آهي ، پر اهو ڪڏهن به نه سڏبو جئين اسان مڪمل طور تي ڪنهن بيزاري واري وقت ۾ لنڪ نه ڪندا هجون.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // x86_64-pc-windows-gnu تي اسان اسان پنهنجي ذاتي فنڪشن استعمال ڪريون ٿا جيڪو `ExceptionContinueSearch` کي واپس ڪرڻ جي ضرورت آهي جيئن اسان اسان جي سڀني فريم تي گذري رهيا آهيون.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // مٿي جهڙيون ، انهي لاءِ `eh_catch_typeinfo` لانگ واريون شيون سان ملندڙ آهن جيڪي صرف هن وقت صرف ايمپسسن تي استعمال ٿيل آهن.
    //
    // جئين panics استثناء پيدا نٿا ڪن ۽ غير ملڪي استثنا هن وقت UB آهن -C panic=ختم ڪريو (جيتوڻيڪ هي تبديلي جي تابع ٿي سگهي ٿي) ، ڪي به catch_unwind ڪالون هن قسم جي معلومات کي ڪڏهن به استعمال نه ڪنديون.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // اهي ٻئي I686-pc-windows-gnu تي اسان جي شروعاتي شين طرفان سڏيا ويندا آهن ، پر انهن کي ڪجهه ڪرڻ جي ضرورت نه هوندي آهي تنهن ڪري لاشون بي نقاب ٿي وينديون آهن.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}