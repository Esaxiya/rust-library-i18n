//! క్రొత్త మాక్రోలను నిర్వచించేటప్పుడు స్థూల రచయితలకు మద్దతు లైబ్రరీ.
//!
//! ప్రామాణిక పంపిణీ ద్వారా అందించబడిన ఈ లైబ్రరీ, ఫంక్షన్-లాంటి మాక్రోస్ `#[proc_macro]`, మాక్రో గుణాలు `#[proc_macro_attribute]` మరియు కస్టమ్ డెరివ్ గుణాలు`#[proc_macro_derive]`వంటి విధానపరంగా నిర్వచించిన స్థూల నిర్వచనాల ఇంటర్‌ఫేస్‌లలో వినియోగించే రకాలను అందిస్తుంది.
//!
//!
//! మరిన్ని కోసం [the book] చూడండి.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// ప్రస్తుతం నడుస్తున్న ప్రోగ్రామ్‌కు proc_macro ప్రాప్యత చేయబడిందా అని నిర్ణయిస్తుంది.
///
/// Proc_macro crate అనేది విధానపరమైన మాక్రోల అమలులో ఉపయోగం కోసం మాత్రమే ఉద్దేశించబడింది.ఈ crate panic లోని అన్ని విధులు బిల్డ్ స్క్రిప్ట్ లేదా యూనిట్ టెస్ట్ లేదా సాధారణ Rust బైనరీ వంటి విధానపరమైన స్థూల వెలుపల నుండి ప్రారంభిస్తే.
///
/// స్థూల మరియు స్థూల రహిత వినియోగ కేసులకు మద్దతు ఇవ్వడానికి రూపొందించబడిన Rust లైబ్రరీల పరిశీలనతో, proc_macro యొక్క API ని ఉపయోగించడానికి అవసరమైన మౌలిక సదుపాయాలు ప్రస్తుతం అందుబాటులో ఉన్నాయో లేదో తెలుసుకోవడానికి `proc_macro::is_available()` భయాందోళన లేని మార్గాన్ని అందిస్తుంది.
/// ఒక విధానపరమైన స్థూల లోపలి నుండి ఇన్వోక్ చేయబడితే నిజం, ఇతర బైనరీ నుండి ఆరంభించినట్లయితే తప్పు.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// ఈ crate చేత అందించబడిన ప్రధాన రకం, tokens యొక్క నైరూప్య ప్రవాహాన్ని సూచిస్తుంది లేదా మరింత ప్రత్యేకంగా token చెట్ల శ్రేణిని సూచిస్తుంది.
/// ఈ రకం ఆ token చెట్లపై మళ్ళించడానికి ఇంటర్‌ఫేస్‌లను అందిస్తుంది మరియు దీనికి విరుద్ధంగా, అనేక token చెట్లను ఒకే ప్రవాహంలో సేకరిస్తుంది.
///
///
/// ఇది `#[proc_macro]`, `#[proc_macro_attribute]` మరియు `#[proc_macro_derive]` నిర్వచనాల ఇన్పుట్ మరియు అవుట్పుట్ రెండూ.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str` నుండి లోపం తిరిగి వచ్చింది.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token చెట్లు లేని ఖాళీ `TokenStream` ని అందిస్తుంది.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// ఈ `TokenStream` ఖాళీగా ఉందో లేదో తనిఖీ చేస్తుంది.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// స్ట్రింగ్‌ను tokens గా విచ్ఛిన్నం చేయడానికి మరియు ఆ tokens ను token స్ట్రీమ్‌లోకి అన్వయించడానికి ప్రయత్నిస్తుంది.
/// అనేక కారణాల వల్ల విఫలం కావచ్చు, ఉదాహరణకు, స్ట్రింగ్‌లో అసమతుల్య డీలిమిటర్లు లేదా భాషలో లేని అక్షరాలు ఉంటే.
///
/// అన్వయించిన స్ట్రీమ్‌లోని అన్ని tokens `Span::call_site()` పరిధులను పొందుతుంది.
///
/// NOTE: కొన్ని లోపాలు `LexError` ను తిరిగి ఇవ్వడానికి బదులుగా panics కి కారణం కావచ్చు.ఈ లోపాలను తరువాత `లెక్స్‌రర్'గా మార్చడానికి మాకు హక్కు ఉంది.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, వంతెన `to_string` ను మాత్రమే అందిస్తుంది, దాని ఆధారంగా `fmt::Display` ను అమలు చేయండి (రెండింటి మధ్య సాధారణ సంబంధం యొక్క రివర్స్).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// token స్ట్రీమ్‌ను స్ట్రింగ్‌గా ప్రింట్ చేస్తుంది, ఇది తిరిగి అదే token స్ట్రీమ్ (మాడ్యులో స్పాన్స్) లోకి మార్చబడుతుంది, బహుశా `Delimiter::None` డీలిమిటర్లు మరియు ప్రతికూల సంఖ్యా సాహిత్యాలతో `టోకెన్‌ట్రీ: : గ్రూప్` తప్ప.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// డీబగ్గింగ్‌కు అనుకూలమైన రూపంలో token ను ప్రింట్ చేస్తుంది.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// ఒకే token చెట్టును కలిగి ఉన్న token స్ట్రీమ్‌ను సృష్టిస్తుంది.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// ఒకే స్ట్రీమ్‌లోకి అనేక token చెట్లను సేకరిస్తుంది.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token స్ట్రీమ్‌లపై "flattening" ఆపరేషన్, బహుళ token స్ట్రీమ్‌ల నుండి token చెట్లను ఒకే స్ట్రీమ్‌లోకి సేకరిస్తుంది.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) ఆప్టిమైజ్ చేసిన అమలు if/when ను ఉపయోగించండి.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// ఇరేటర్స్ వంటి `TokenStream` రకం కోసం పబ్లిక్ ఇంప్లిమెంటేషన్ వివరాలు.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `టోకెన్‌స్ట్రీమ్` యొక్క` టోకెన్‌ట్రీ'పై ఇటరేటర్.
    /// పునరావృతం "shallow", ఉదా., మళ్ళి వేరు చేయబడిన సమూహాలలోకి ప్రవేశించదు మరియు మొత్తం సమూహాలను token చెట్లుగా తిరిగి ఇస్తుంది.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` ఏకపక్ష tokens ను అంగీకరిస్తుంది మరియు ఇన్‌పుట్‌ను వివరించే `TokenStream` లోకి విస్తరిస్తుంది.
/// ఉదాహరణకు, `quote!(a + b)` ఒక వ్యక్తీకరణను ఉత్పత్తి చేస్తుంది, ఇది మూల్యాంకనం చేసినప్పుడు, `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// అన్‌కోటింగ్ `$` తో జరుగుతుంది మరియు సింగిల్ నెక్స్ట్ ఐడెంటిటీని అన్‌కోటెడ్ పదాన్ని తీసుకొని పనిచేస్తుంది.
/// `$` ను కోట్ చేయడానికి, `$$` ను ఉపయోగించండి.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// స్థూల విస్తరణ సమాచారంతో పాటు సోర్స్ కోడ్ యొక్క ప్రాంతం.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// `self` span వద్ద ఇచ్చిన `message` తో కొత్త `Diagnostic` ను సృష్టిస్తుంది.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// స్థూల నిర్వచనం సైట్ వద్ద పరిష్కరించే వ్యవధి.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// ప్రస్తుత విధాన స్థూల యొక్క ఆహ్వానం యొక్క వ్యవధి.
    /// ఈ స్పాన్‌తో సృష్టించబడిన ఐడెంటిఫైయర్‌లు మాక్రో కాల్ లొకేషన్ (కాల్-సైట్ పరిశుభ్రత) వద్ద నేరుగా వ్రాసినట్లుగా పరిష్కరించబడతాయి మరియు స్థూల కాల్ సైట్‌లోని ఇతర కోడ్ వాటిని కూడా సూచించగలదు.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` పరిశుభ్రతను సూచించే మరియు కొన్నిసార్లు స్థూల నిర్వచనం సైట్ (స్థానిక వేరియబుల్స్, లేబుల్స్, `$crate`) వద్ద మరియు కొన్నిసార్లు స్థూల కాల్ సైట్ వద్ద (మిగతావన్నీ) పరిష్కరిస్తుంది.
    ///
    /// స్పాన్ స్థానం కాల్-సైట్ నుండి తీసుకోబడింది.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// ఈ స్పాన్ సూచించే అసలు సోర్స్ ఫైల్.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// మునుపటి స్థూల విస్తరణలో tokens కోసం `Span`, దీని నుండి `self` ఉత్పత్తి చేయబడి ఉంటే.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` నుండి ఉత్పత్తి చేయబడిన మూలం సోర్స్ కోడ్ యొక్క వ్యవధి.
    /// ఈ `Span` ఇతర స్థూల విస్తరణల నుండి ఉత్పత్తి చేయకపోతే, తిరిగి వచ్చే విలువ `*self` వలె ఉంటుంది.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// ఈ వ్యవధి కోసం సోర్స్ ఫైల్‌లో ప్రారంభ line/column ను పొందుతుంది.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// ఈ వ్యవధి కోసం మూలం ఫైల్‌లో ముగింపు line/column ను పొందుతుంది.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self` మరియు `other` లను కలిగి ఉన్న క్రొత్త స్పాన్‌ను సృష్టిస్తుంది.
    ///
    /// `self` మరియు `other` వేర్వేరు ఫైళ్ళ నుండి వచ్చినట్లయితే `None` ను అందిస్తుంది.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self` వలె అదే line/column సమాచారంతో క్రొత్త స్పాన్‌ను సృష్టిస్తుంది, అయితే ఇది `other` వద్ద ఉన్నట్లుగా చిహ్నాలను పరిష్కరిస్తుంది.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self` వలె అదే పేరు రిజల్యూషన్ ప్రవర్తనతో కానీ `other` యొక్క line/column సమాచారంతో కొత్త స్పాన్‌ను సృష్టిస్తుంది.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// వారు సమానంగా ఉన్నారో లేదో చూడటానికి పరిధులతో పోలుస్తుంది.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// వ్యవధి వెనుక మూల వచనాన్ని అందిస్తుంది.
    /// ఇది ఖాళీలు మరియు వ్యాఖ్యలతో సహా అసలు సోర్స్ కోడ్‌ను సంరక్షిస్తుంది.
    /// స్పాన్ నిజమైన సోర్స్ కోడ్‌కు అనుగుణంగా ఉంటేనే ఇది ఫలితాన్ని ఇస్తుంది.
    ///
    /// Note: స్థూల యొక్క గమనించదగ్గ ఫలితం tokens పై మాత్రమే ఆధారపడాలి మరియు ఈ మూల వచనంపై కాదు.
    ///
    /// ఈ ఫంక్షన్ ఫలితం డయాగ్నస్టిక్స్ కోసం మాత్రమే ఉపయోగించటానికి ఉత్తమ ప్రయత్నం.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// డీబగ్గింగ్‌కు అనుకూలమైన రూపంలో స్పాన్‌ను ప్రింట్ చేస్తుంది.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// `Span` ప్రారంభం లేదా ముగింపును సూచించే పంక్తి-కాలమ్ జత.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// (inclusive) ప్రారంభమయ్యే లేదా ముగుస్తున్న మూల ఫైల్‌లోని 1-సూచిక పంక్తి.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// (inclusive) ప్రారంభమయ్యే లేదా ముగుస్తున్న మూల ఫైల్‌లోని 0-సూచిక కాలమ్ (UTF-8 అక్షరాలలో).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// ఇచ్చిన `Span` యొక్క మూల ఫైల్.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// ఈ మూల ఫైల్‌కు మార్గాన్ని పొందుతుంది.
    ///
    /// ### Note
    /// ఈ `SourceFile` తో అనుబంధించబడిన కోడ్ స్పాన్ బాహ్య స్థూల, ఈ స్థూల ద్వారా ఉత్పత్తి చేయబడితే, ఇది ఫైల్‌సిస్టమ్‌లో వాస్తవ మార్గం కాకపోవచ్చు.
    /// తనిఖీ చేయడానికి [`is_real`] ఉపయోగించండి.
    ///
    /// `is_real` `true` ను తిరిగి ఇచ్చినప్పటికీ, `--remap-path-prefix` కమాండ్ లైన్‌లో పాస్ అయినట్లయితే, ఇచ్చిన మార్గం వాస్తవానికి చెల్లుబాటు కాకపోవచ్చు.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// ఈ సోర్స్ ఫైల్ నిజమైన సోర్స్ ఫైల్ అయితే `true` ను అందిస్తుంది మరియు బాహ్య స్థూల విస్తరణ ద్వారా ఉత్పత్తి చేయబడదు.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // ఇంటర్‌క్రాట్ పరిధులను అమలు చేసే వరకు ఇది ఒక హాక్ మరియు బాహ్య మాక్రోల్లో ఉత్పత్తి చేయబడిన స్పాన్‌ల కోసం మేము నిజమైన సోర్స్ ఫైల్‌లను కలిగి ఉండవచ్చు.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// ఒకే token లేదా token చెట్ల యొక్క వేరు చేయబడిన క్రమం (ఉదా., `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// బ్రాకెట్ డీలిమిటర్లతో చుట్టుముట్టబడిన token స్ట్రీమ్.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// ఒక ఐడెంటిఫైయర్.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// ఒకే విరామచిహ్న అక్షరం (`+`, `,`, `$`, మొదలైనవి).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// అక్షర అక్షరం (`'a'`), స్ట్రింగ్ (`"hello"`), సంఖ్య (`2.3`), మొదలైనవి.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// ఈ చెట్టు యొక్క వ్యవధిని అందిస్తుంది, ఇది కలిగి ఉన్న token లేదా వేరు చేయబడిన స్ట్రీమ్ యొక్క `span` పద్ధతికి అప్పగిస్తుంది.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *ఈ token* కోసం మాత్రమే స్పాన్‌ను కాన్ఫిగర్ చేస్తుంది.
    ///
    /// ఈ token ఒక `Group` అయితే, ఈ పద్ధతి ప్రతి అంతర్గత tokens యొక్క వ్యవధిని కాన్ఫిగర్ చేయదు, ఇది ప్రతి వేరియంట్ యొక్క `set_span` పద్ధతికి అప్పగించబడుతుంది.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// డీబగ్గింగ్‌కు అనుకూలమైన రూపంలో token చెట్టును ముద్రిస్తుంది.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // వీటిలో ప్రతి ఒక్కటి ఉత్పన్నమైన డీబగ్‌లోని స్ట్రక్ట్ రకంలో పేరును కలిగి ఉంది, కాబట్టి అదనపు పొరల ఇండెక్షన్‌తో బాధపడకండి
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, వంతెన `to_string` ను మాత్రమే అందిస్తుంది, దాని ఆధారంగా `fmt::Display` ను అమలు చేయండి (రెండింటి మధ్య సాధారణ సంబంధం యొక్క రివర్స్).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// token చెట్టును స్ట్రింగ్ వలె ప్రింట్ చేస్తుంది, ఇది తిరిగి అదే token చెట్టు (మాడ్యులో స్పాన్స్) లోకి మార్చబడుతుంది, బహుశా `Delimiter::None` డీలిమిటర్లు మరియు ప్రతికూల సంఖ్యా సాహిత్యాలతో `టోకెన్‌ట్రీ: : గ్రూప్` తప్ప.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// వేరు చేయబడిన token స్ట్రీమ్.
///
/// `Group` అంతర్గతంగా `TokenStream` ను కలిగి ఉంది, దీని చుట్టూ `డీలిమిటర్` ఉంది.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token చెట్ల క్రమం ఎలా వేరు చేయబడిందో వివరిస్తుంది.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// ఒక అవ్యక్త డీలిమిటర్, ఉదాహరణకు, "macro variable" `$var` నుండి వచ్చే tokens చుట్టూ కనిపిస్తుంది.
    /// `$var` `1 + 2` ఉన్న సందర్భాలలో `$var * 3` వంటి సందర్భాల్లో ఆపరేటర్ ప్రాధాన్యతలను సంరక్షించడం చాలా ముఖ్యం.
    /// అవ్యక్త డీలిమిటర్లు token స్ట్రీమ్ యొక్క రౌండ్‌ట్రిప్‌ను స్ట్రింగ్ ద్వారా మనుగడ సాగించకపోవచ్చు.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// ఇచ్చిన డీలిమిటర్ మరియు token స్ట్రీమ్‌తో కొత్త `Group` ను సృష్టిస్తుంది.
    ///
    /// ఈ కన్స్ట్రక్టర్ ఈ సమూహం కోసం `Span::call_site()` కు వ్యవధిని సెట్ చేస్తుంది.
    /// వ్యవధిని మార్చడానికి మీరు క్రింద ఉన్న `set_span` పద్ధతిని ఉపయోగించవచ్చు.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// ఈ `Group` యొక్క డీలిమిటర్‌ను అందిస్తుంది
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// ఈ `Group` లో వేరు చేయబడిన tokens యొక్క `TokenStream` ను అందిస్తుంది.
    ///
    /// తిరిగి వచ్చిన token స్ట్రీమ్‌లో పైన తిరిగి వచ్చిన డీలిమిటర్ ఉండదని గమనించండి.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// ఈ token స్ట్రీమ్ యొక్క డీలిమిటర్స్ కోసం స్పాన్‌ను అందిస్తుంది, మొత్తం `Group` ని విస్తరించి ఉంటుంది.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ఈ గుంపు యొక్క ప్రారంభ డీలిమిటర్‌ను సూచించే స్పాన్‌ను చూపుతుంది.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// ఈ గుంపు యొక్క ముగింపు డీలిమిటర్‌కు సూచించే స్పాన్‌ను చూపుతుంది.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// ఈ `గ్రూప్` యొక్క డీలిమిటర్‌ల కోసం స్పాన్‌ను కాన్ఫిగర్ చేస్తుంది, కానీ దాని అంతర్గత tokens కాదు.
    ///
    /// ఈ పద్ధతి ఈ సమూహం విస్తరించిన అన్ని అంతర్గత tokens యొక్క పరిధిని ** సెట్ చేయదు, కానీ ఇది `Group` స్థాయిలో డీలిమిటర్ tokens యొక్క పరిధిని మాత్రమే సెట్ చేస్తుంది.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, వంతెన `to_string` ను మాత్రమే అందిస్తుంది, దాని ఆధారంగా `fmt::Display` ను అమలు చేయండి (రెండింటి మధ్య సాధారణ సంబంధం యొక్క రివర్స్).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// `Delimiter::None` డీలిమిటర్లతో `టోకెన్‌ట్రీ: : గ్రూప్`లను మినహాయించి, సమూహాన్ని తిరిగి అదే సమూహంలోకి (మాడ్యులో స్పాన్స్) మార్చగల స్ట్రింగ్‌గా ప్రింట్ చేస్తుంది.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` అనేది `+`, `-` లేదా `#` వంటి ఒకే విరామచిహ్న పాత్ర.
///
/// `+=` వంటి మల్టీ-క్యారెక్టర్ ఆపరేటర్లు `Punct` యొక్క రెండు ఉదాహరణలుగా ప్రాతినిధ్యం వహిస్తారు.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// ఒక `Punct` ను వెంటనే మరొక `Punct` అనుసరిస్తుందా లేదా మరొక token లేదా వైట్‌స్పేస్ అనుసరిస్తుందా.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ఉదా., `+` అనేది `+ =`, `+ident` లేదా `+()` లో `Alone`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ఉదా., `+` అనేది `+=` లేదా `'#` లో `Joint`.
    /// అదనంగా, సింగిల్ కోట్ `'` జీవితకాల `'ident` ను రూపొందించడానికి ఐడెంటిఫైయర్‌లతో చేరవచ్చు.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// ఇచ్చిన అక్షరం మరియు అంతరం నుండి క్రొత్త `Punct` ను సృష్టిస్తుంది.
    /// `ch` ఆర్గ్యుమెంట్ తప్పనిసరిగా భాషచే అనుమతించబడిన చెల్లుబాటు అయ్యే విరామచిహ్న అక్షరం అయి ఉండాలి, లేకపోతే ఫంక్షన్ panic అవుతుంది.
    ///
    /// తిరిగి వచ్చిన `Punct` `Span::call_site()` యొక్క డిఫాల్ట్ వ్యవధిని కలిగి ఉంటుంది, ఇది దిగువ `set_span` పద్ధతిలో మరింత కాన్ఫిగర్ చేయవచ్చు.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// ఈ విరామచిహ్న అక్షరం యొక్క విలువను `char` గా అందిస్తుంది.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// ఈ విరామచిహ్న అక్షరం యొక్క అంతరాన్ని తిరిగి ఇస్తుంది, ఇది వెంటనే token స్ట్రీమ్‌లో మరొక `Punct` ను అనుసరిస్తుందో లేదో సూచిస్తుంది, కాబట్టి వాటిని బహుళ-అక్షర ఆపరేటర్ (`Joint`) లోకి మిళితం చేయవచ్చు, లేదా దాని తరువాత కొన్ని ఇతర token లేదా వైట్‌స్పేస్ (`Alone`) ను అనుసరిస్తారు కాబట్టి ఆపరేటర్ ఖచ్చితంగా ఉంది ముగిసింది.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// ఈ విరామచిహ్న అక్షరం కోసం వ్యవధిని చూపుతుంది.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ఈ విరామచిహ్న అక్షరం కోసం వ్యవధిని కాన్ఫిగర్ చేయండి.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, వంతెన `to_string` ను మాత్రమే అందిస్తుంది, దాని ఆధారంగా `fmt::Display` ను అమలు చేయండి (రెండింటి మధ్య సాధారణ సంబంధం యొక్క రివర్స్).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// విరామ చిహ్నాన్ని స్ట్రింగ్‌గా ప్రింట్ చేస్తుంది, అది తిరిగి అదే అక్షరంలోకి మార్చబడుతుంది.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// ఒక ఐడెంటిఫైయర్ (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// ఇచ్చిన `string` తో పాటు పేర్కొన్న `span` తో కొత్త `Ident` ను సృష్టిస్తుంది.
    /// `string` ఆర్గ్యుమెంట్ తప్పనిసరిగా భాషచే అనుమతించబడిన చెల్లుబాటు అయ్యే ఐడెంటిఫైయర్ అయి ఉండాలి (కీలకపదాలతో సహా, ఉదా. `self` లేదా `fn`).లేకపోతే, ఫంక్షన్ panic అవుతుంది.
    ///
    /// `span`, ప్రస్తుతం rustc లో ఉంది, ఈ ఐడెంటిఫైయర్ కోసం పరిశుభ్రత సమాచారాన్ని కాన్ఫిగర్ చేస్తుంది.
    ///
    /// ఈ సమయానికి `Span::call_site()` స్పష్టంగా "call-site" పరిశుభ్రతను ఎంచుకుంటుంది అంటే ఈ వ్యవధితో సృష్టించబడిన ఐడెంటిఫైయర్‌లు మాక్రో కాల్ ఉన్న ప్రదేశంలో నేరుగా వ్రాసినట్లుగా పరిష్కరించబడతాయి మరియు స్థూల కాల్ సైట్‌లోని ఇతర కోడ్‌ను సూచించగలుగుతారు. వాటిని కూడా.
    ///
    ///
    /// `Span::def_site()` వంటి తరువాతి పరిమితులు "definition-site" పరిశుభ్రతను ఎంచుకోవడానికి అనుమతిస్తుంది, అంటే ఈ స్పాన్‌తో సృష్టించబడిన ఐడెంటిఫైయర్‌లు స్థూల నిర్వచనం ఉన్న ప్రదేశంలో పరిష్కరించబడతాయి మరియు మాక్రో కాల్ సైట్‌లోని ఇతర కోడ్ వాటిని సూచించలేవు.
    ///
    /// పరిశుభ్రత యొక్క ప్రస్తుత ప్రాముఖ్యత కారణంగా, ఈ కన్స్ట్రక్టర్, ఇతర tokens మాదిరిగా కాకుండా, నిర్మాణంలో `Span` ను పేర్కొనడం అవసరం.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` వలె ఉంటుంది, కానీ ముడి ఐడెంటిఫైయర్ (`r#ident`) ను సృష్టిస్తుంది.
    /// `string` ఆర్గ్యుమెంట్ భాషచే అనుమతించబడిన చెల్లుబాటు అయ్యే ఐడెంటిఫైయర్ (కీలకపదాలతో సహా, ఉదా. `fn`).
    /// మార్గం విభాగాలలో ఉపయోగపడే కీలకపదాలు (ఉదా
    /// `self`, `సూపర్`) మద్దతు లేదు మరియు ఇది panic కి కారణమవుతుంది.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// ఈ `Ident` యొక్క వ్యవధిని అందిస్తుంది, [`to_string`](Self::to_string) ద్వారా తిరిగి వచ్చిన మొత్తం స్ట్రింగ్‌ను కలిగి ఉంటుంది.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ఈ `Ident` యొక్క పరిధిని కాన్ఫిగర్ చేస్తుంది, బహుశా దాని పరిశుభ్రత సందర్భాన్ని మారుస్తుంది.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, వంతెన `to_string` ను మాత్రమే అందిస్తుంది, దాని ఆధారంగా `fmt::Display` ను అమలు చేయండి (రెండింటి మధ్య సాధారణ సంబంధం యొక్క రివర్స్).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ఐడెంటిఫైయర్‌ను స్ట్రింగ్‌గా ప్రింట్ చేస్తుంది, అది తిరిగి అదే ఐడెంటిఫైయర్‌లోకి మార్చబడుతుంది.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// అక్షర స్ట్రింగ్ (`"hello"`), బైట్ స్ట్రింగ్ (`b"hello"`), అక్షరం (`'a'`), బైట్ అక్షరం (`b'a'`), ప్రత్యయం లేదా లేకుండా (`1`, `1u8`, `2.3`, `2.3f32`) పూర్ణాంకం లేదా తేలియాడే పాయింట్ సంఖ్య.
///
/// `true` మరియు `false` వంటి బూలియన్ అక్షరాస్యతలు ఇక్కడకు చెందినవి కావు, అవి `గుర్తింపు`.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// పేర్కొన్న విలువతో కొత్త ప్రత్యయం పూర్ణాంక అక్షరాన్ని సృష్టిస్తుంది.
        ///
        /// ఈ ఫంక్షన్ `1u32` వంటి పూర్ణాంకాన్ని సృష్టిస్తుంది, ఇక్కడ పేర్కొన్న పూర్ణాంక విలువ token యొక్క మొదటి భాగం మరియు సమగ్ర కూడా చివరిలో ప్రత్యయం అవుతుంది.
        /// ప్రతికూల సంఖ్యల నుండి సృష్టించబడిన సాహిత్యాలు `TokenStream` లేదా తీగల ద్వారా రౌండ్-ట్రిప్పులను తట్టుకోలేకపోవచ్చు మరియు రెండు tokens (`-` మరియు పాజిటివ్ లిటరల్) గా విభజించబడవచ్చు.
        ///
        ///
        /// ఈ పద్ధతి ద్వారా సృష్టించబడిన సాహిత్యాలు డిఫాల్ట్‌గా `Span::call_site()` స్పాన్‌ను కలిగి ఉంటాయి, వీటిని దిగువ `set_span` పద్ధతిలో కాన్ఫిగర్ చేయవచ్చు.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// పేర్కొన్న విలువతో కొత్త అసంపూర్తి పూర్ణాంక అక్షరాన్ని సృష్టిస్తుంది.
        ///
        /// ఈ ఫంక్షన్ `1` వంటి పూర్ణాంకాన్ని సృష్టిస్తుంది, ఇక్కడ పేర్కొన్న పూర్ణాంక విలువ token యొక్క మొదటి భాగం.
        /// ఈ token లో ఎటువంటి ప్రత్యయం పేర్కొనబడలేదు, అంటే `Literal::i8_unsuffixed(1)` వంటి ఆహ్వానాలు `Literal::u32_unsuffixed(1)` కి సమానం.
        /// ప్రతికూల సంఖ్యల నుండి సృష్టించబడిన సాహిత్యాలు `TokenStream` లేదా తీగల ద్వారా రౌన్‌ట్రిప్స్‌ను మనుగడ సాగించకపోవచ్చు మరియు రెండు tokens (`-` మరియు పాజిటివ్ లిటరల్) గా విభజించబడవచ్చు.
        ///
        ///
        /// ఈ పద్ధతి ద్వారా సృష్టించబడిన సాహిత్యాలు డిఫాల్ట్‌గా `Span::call_site()` స్పాన్‌ను కలిగి ఉంటాయి, వీటిని దిగువ `set_span` పద్ధతిలో కాన్ఫిగర్ చేయవచ్చు.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// క్రొత్త అసంపూర్తిగా ఉన్న ఫ్లోటింగ్ పాయింట్ అక్షరాలా సృష్టిస్తుంది.
    ///
    /// ఈ కన్స్ట్రక్టర్ `Literal::i8_unsuffixed` వంటి వాటితో సమానంగా ఉంటుంది, ఇక్కడ ఫ్లోట్ యొక్క విలువ నేరుగా token లోకి విడుదల అవుతుంది, కానీ ప్రత్యయం ఉపయోగించబడదు, కాబట్టి ఇది కంపైలర్‌లో `f64` అని er హించవచ్చు.
    ///
    /// ప్రతికూల సంఖ్యల నుండి సృష్టించబడిన సాహిత్యాలు `TokenStream` లేదా తీగల ద్వారా రౌన్‌ట్రిప్స్‌ను మనుగడ సాగించకపోవచ్చు మరియు రెండు tokens (`-` మరియు పాజిటివ్ లిటరల్) గా విభజించబడవచ్చు.
    ///
    /// # Panics
    ///
    /// ఈ ఫంక్షన్‌కు పేర్కొన్న ఫ్లోట్ పరిమితంగా ఉండాలి, ఉదాహరణకు ఇది అనంతం లేదా NaN అయితే ఈ ఫంక్షన్ panic అవుతుంది.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// కొత్త ప్రత్యయం ఫ్లోటింగ్ పాయింట్ అక్షరాలా సృష్టిస్తుంది.
    ///
    /// ఈ కన్స్ట్రక్టర్ `1.0f32` వంటి అక్షరాలా సృష్టిస్తుంది, ఇక్కడ పేర్కొన్న విలువ token యొక్క మునుపటి భాగం మరియు `f32` అనేది token యొక్క ప్రత్యయం.
    /// ఈ token ఎల్లప్పుడూ కంపైలర్‌లో `f32` గా er హించబడుతుంది.
    /// ప్రతికూల సంఖ్యల నుండి సృష్టించబడిన సాహిత్యాలు `TokenStream` లేదా తీగల ద్వారా రౌన్‌ట్రిప్స్‌ను మనుగడ సాగించకపోవచ్చు మరియు రెండు tokens (`-` మరియు పాజిటివ్ లిటరల్) గా విభజించబడవచ్చు.
    ///
    ///
    /// # Panics
    ///
    /// ఈ ఫంక్షన్‌కు పేర్కొన్న ఫ్లోట్ పరిమితంగా ఉండాలి, ఉదాహరణకు ఇది అనంతం లేదా NaN అయితే ఈ ఫంక్షన్ panic అవుతుంది.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// క్రొత్త అసంపూర్తిగా ఉన్న ఫ్లోటింగ్ పాయింట్ అక్షరాలా సృష్టిస్తుంది.
    ///
    /// ఈ కన్స్ట్రక్టర్ `Literal::i8_unsuffixed` వంటి వాటితో సమానంగా ఉంటుంది, ఇక్కడ ఫ్లోట్ యొక్క విలువ నేరుగా token లోకి విడుదల అవుతుంది, కానీ ప్రత్యయం ఉపయోగించబడదు, కాబట్టి ఇది కంపైలర్‌లో `f64` అని er హించవచ్చు.
    ///
    /// ప్రతికూల సంఖ్యల నుండి సృష్టించబడిన సాహిత్యాలు `TokenStream` లేదా తీగల ద్వారా రౌన్‌ట్రిప్స్‌ను మనుగడ సాగించకపోవచ్చు మరియు రెండు tokens (`-` మరియు పాజిటివ్ లిటరల్) గా విభజించబడవచ్చు.
    ///
    /// # Panics
    ///
    /// ఈ ఫంక్షన్‌కు పేర్కొన్న ఫ్లోట్ పరిమితంగా ఉండాలి, ఉదాహరణకు ఇది అనంతం లేదా NaN అయితే ఈ ఫంక్షన్ panic అవుతుంది.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// కొత్త ప్రత్యయం ఫ్లోటింగ్ పాయింట్ అక్షరాలా సృష్టిస్తుంది.
    ///
    /// ఈ కన్స్ట్రక్టర్ `1.0f64` వంటి అక్షరాలా సృష్టిస్తుంది, ఇక్కడ పేర్కొన్న విలువ token యొక్క మునుపటి భాగం మరియు `f64` అనేది token యొక్క ప్రత్యయం.
    /// ఈ token ఎల్లప్పుడూ కంపైలర్‌లో `f64` గా er హించబడుతుంది.
    /// ప్రతికూల సంఖ్యల నుండి సృష్టించబడిన సాహిత్యాలు `TokenStream` లేదా తీగల ద్వారా రౌన్‌ట్రిప్స్‌ను మనుగడ సాగించకపోవచ్చు మరియు రెండు tokens (`-` మరియు పాజిటివ్ లిటరల్) గా విభజించబడవచ్చు.
    ///
    ///
    /// # Panics
    ///
    /// ఈ ఫంక్షన్‌కు పేర్కొన్న ఫ్లోట్ పరిమితంగా ఉండాలి, ఉదాహరణకు ఇది అనంతం లేదా NaN అయితే ఈ ఫంక్షన్ panic అవుతుంది.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// స్ట్రింగ్ అక్షరాలా.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// అక్షర సాహిత్యం.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// బైట్ స్ట్రింగ్ అక్షరాలా.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// ఈ సాహిత్యాన్ని కలిగి ఉన్న వ్యవధిని అందిస్తుంది.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ఈ సాహిత్యానికి సంబంధించిన స్పాన్‌ను కాన్ఫిగర్ చేస్తుంది.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `Span` పరిధిలోని సోర్స్ బైట్‌లను మాత్రమే కలిగి ఉన్న `self.span()` యొక్క ఉపసమితి అయిన `Span` ను అందిస్తుంది.
    /// కత్తిరించబడిన వ్యవధి `self` యొక్క హద్దులకు వెలుపల ఉంటే `None` ను అందిస్తుంది.
    ///
    // FIXME(SergioBenitez): బైట్ పరిధి మూలం యొక్క UTF-8 సరిహద్దు వద్ద ప్రారంభమై ముగుస్తుందో లేదో తనిఖీ చేయండి.
    // లేకపోతే, మూల వచనం ముద్రించినప్పుడు panic మరెక్కడా సంభవించే అవకాశం ఉంది.
    // FIXME(SergioBenitez): `self.span()` వాస్తవానికి ఏమి మ్యాప్ చేస్తుందో వినియోగదారుకు తెలుసుకోవడానికి మార్గం లేదు, కాబట్టి ఈ పద్ధతిని ప్రస్తుతం గుడ్డిగా మాత్రమే పిలుస్తారు.
    // ఉదాహరణకు, 'c' అక్షరానికి `to_string()` "'\u{63}'" ను అందిస్తుంది;సోర్స్ టెక్స్ట్ 'c' కాదా లేదా అది '\u{63}' కాదా అని వినియోగదారుకు తెలుసుకోవడానికి మార్గం లేదు.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned` కి సమానమైనది, కానీ `Bound<&T>` కోసం.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, వంతెన `to_string` ను మాత్రమే అందిస్తుంది, దాని ఆధారంగా `fmt::Display` ను అమలు చేయండి (రెండింటి మధ్య సాధారణ సంబంధం యొక్క రివర్స్).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// అక్షరాలా ఒక స్ట్రింగ్ వలె ప్రింట్ చేస్తుంది, అది తిరిగి అదే అక్షరంలోకి మార్చబడుతుంది (ఫ్లోటింగ్ పాయింట్ అక్షరాస్యులకు సాధ్యమైన రౌండింగ్ తప్ప).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// ఎన్విరాన్మెంట్ వేరియబుల్స్కు ట్రాక్ చేయబడిన యాక్సెస్.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// ఎన్విరాన్మెంట్ వేరియబుల్ను తిరిగి పొందండి మరియు డిపెండెన్సీ సమాచారాన్ని రూపొందించడానికి దాన్ని జోడించండి.
    /// కంపైలర్ను అమలు చేసే బిల్డ్ సిస్టమ్, సంకలనం సమయంలో వేరియబుల్ యాక్సెస్ చేయబడిందని తెలుస్తుంది మరియు ఆ వేరియబుల్ యొక్క విలువ మారినప్పుడు బిల్డ్ను తిరిగి అమలు చేయగలదు.
    ///
    /// డిపెండెన్సీ ట్రాకింగ్‌తో పాటు, ఈ ఫంక్షన్ ప్రామాణిక లైబ్రరీ నుండి `env::var` కి సమానంగా ఉండాలి, తప్ప వాదన UTF-8 గా ఉండాలి.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}