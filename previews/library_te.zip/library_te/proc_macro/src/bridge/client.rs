//! క్లయింట్ వైపు రకాలు.

use super::*;

macro_rules! define_handles {
    (
        'owned: $($oty:ident,)*
        'interned: $($ity:ident,)*
    ) => {
        #[repr(C)]
        #[allow(non_snake_case)]
        pub struct HandleCounters {
            $($oty: AtomicUsize,)*
            $($ity: AtomicUsize,)*
        }

        impl HandleCounters {
            // FIXME(eddyb) రేపర్ `fn` పాయింటర్‌కు బదులుగా, `static COUNTERS` కు సూచనను ఉపయోగించండి, ఒకసారి `const fn` `స్టాటిక్'లను సూచించగలదు.
            //
            extern "C" fn get() -> &'static Self {
                static COUNTERS: HandleCounters = HandleCounters {
                    $($oty: AtomicUsize::new(1),)*
                    $($ity: AtomicUsize::new(1),)*
                };
                &COUNTERS
            }
        }

        // FIXME(eddyb) `server.rs` లో `HandleStore` యొక్క నిర్వచనాన్ని రూపొందించండి.
        #[repr(C)]
        #[allow(non_snake_case)]
        pub(super) struct HandleStore<S: server::Types> {
            $($oty: handle::OwnedStore<S::$oty>,)*
            $($ity: handle::InternedStore<S::$ity>,)*
        }

        impl<S: server::Types> HandleStore<S> {
            pub(super) fn new(handle_counters: &'static HandleCounters) -> Self {
                HandleStore {
                    $($oty: handle::OwnedStore::new(&handle_counters.$oty),)*
                    $($ity: handle::InternedStore::new(&handle_counters.$ity),)*
                }
            }
        }

        $(
            #[repr(C)]
            pub(crate) struct $oty(handle::Handle);
            impl !Send for $oty {}
            impl !Sync for $oty {}

            // `Drop::drop` ను స్వాభావిక `drop` పద్ధతికి ఫార్వార్డ్ చేయండి.
            impl Drop for $oty {
                fn drop(&mut self) {
                    $oty(self.0).drop();
                }
            }

            impl<S> Encode<S> for $oty {
                fn encode(self, w: &mut Writer, s: &mut S) {
                    let handle = self.0;
                    mem::forget(self);
                    handle.encode(w, s);
                }
            }

            impl<S: server::Types> DecodeMut<'_, '_, HandleStore<server::MarkedTypes<S>>>
                for Marked<S::$oty, $oty>
            {
                fn decode(r: &mut Reader<'_>, s: &mut HandleStore<server::MarkedTypes<S>>) -> Self {
                    s.$oty.take(handle::Handle::decode(r, &mut ()))
                }
            }

            impl<S> Encode<S> for &$oty {
                fn encode(self, w: &mut Writer, s: &mut S) {
                    self.0.encode(w, s);
                }
            }

            impl<S: server::Types> Decode<'_, 's, HandleStore<server::MarkedTypes<S>>>
                for &'s Marked<S::$oty, $oty>
            {
                fn decode(r: &mut Reader<'_>, s: &'s HandleStore<server::MarkedTypes<S>>) -> Self {
                    &s.$oty[handle::Handle::decode(r, &mut ())]
                }
            }

            impl<S> Encode<S> for &mut $oty {
                fn encode(self, w: &mut Writer, s: &mut S) {
                    self.0.encode(w, s);
                }
            }

            impl<S: server::Types> DecodeMut<'_, 's, HandleStore<server::MarkedTypes<S>>>
                for &'s mut Marked<S::$oty, $oty>
            {
                fn decode(
                    r: &mut Reader<'_>,
                    s: &'s mut HandleStore<server::MarkedTypes<S>>
                ) -> Self {
                    &mut s.$oty[handle::Handle::decode(r, &mut ())]
                }
            }

            impl<S: server::Types> Encode<HandleStore<server::MarkedTypes<S>>>
                for Marked<S::$oty, $oty>
            {
                fn encode(self, w: &mut Writer, s: &mut HandleStore<server::MarkedTypes<S>>) {
                    s.$oty.alloc(self).encode(w, s);
                }
            }

            impl<S> DecodeMut<'_, '_, S> for $oty {
                fn decode(r: &mut Reader<'_>, s: &mut S) -> Self {
                    $oty(handle::Handle::decode(r, s))
                }
            }
        )*

        $(
            #[repr(C)]
            #[derive(Copy, Clone, PartialEq, Eq, Hash)]
            pub(crate) struct $ity(handle::Handle);
            impl !Send for $ity {}
            impl !Sync for $ity {}

            impl<S> Encode<S> for $ity {
                fn encode(self, w: &mut Writer, s: &mut S) {
                    self.0.encode(w, s);
                }
            }

            impl<S: server::Types> DecodeMut<'_, '_, HandleStore<server::MarkedTypes<S>>>
                for Marked<S::$ity, $ity>
            {
                fn decode(r: &mut Reader<'_>, s: &mut HandleStore<server::MarkedTypes<S>>) -> Self {
                    s.$ity.copy(handle::Handle::decode(r, &mut ()))
                }
            }

            impl<S: server::Types> Encode<HandleStore<server::MarkedTypes<S>>>
                for Marked<S::$ity, $ity>
            {
                fn encode(self, w: &mut Writer, s: &mut HandleStore<server::MarkedTypes<S>>) {
                    s.$ity.alloc(self).encode(w, s);
                }
            }

            impl<S> DecodeMut<'_, '_, S> for $ity {
                fn decode(r: &mut Reader<'_>, s: &mut S) -> Self {
                    $ity(handle::Handle::decode(r, s))
                }
            }
        )*
    }
}
define_handles! {
    'owned:
    FreeFunctions,
    TokenStream,
    TokenStreamBuilder,
    TokenStreamIter,
    Group,
    Literal,
    SourceFile,
    MultiSpan,
    Diagnostic,

    'interned:
    Punct,
    Ident,
    Span,
}

// FIXME(eddyb) పద్ధతుల పేర్లతో నమూనా-సరిపోలిక ద్వారా ఈ ఇంప్ల్స్‌ను ఉత్పత్తి చేయండి, పైన 'యాజమాన్యంలోని మరియు' ఇంటర్న్‌ల మధ్య తేడాను గుర్తించడానికి `fn drop` ఉనికిని కూడా ఉపయోగించవచ్చు.
//
// ప్రత్యామ్నాయంగా, ప్రత్యేకమైన 'మోడ్‌లు' పద్ధతులపై నమూనా సరిపోలికకు బదులుగా with_api లో రకాలను జాబితా చేయవచ్చు, ఇక్కడ మరియు సర్వర్ క్షీణతలో.
//
//

impl Clone for TokenStream {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl Clone for TokenStreamIter {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl Clone for Group {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl Clone for Literal {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Literal")
            // `kind: Float` లో వలె కోట్స్ లేకుండా రకాన్ని ఫార్మాట్ చేయండి
            .field("kind", &format_args!("{}", &self.debug_kind()))
            .field("symbol", &self.symbol())
            // {:#?} మోడ్‌లో కూడా `Some("...")` ను ఒక లైన్‌లో ఫార్మాట్ చేయండి
            .field("suffix", &format_args!("{:?}", &self.suffix()))
            .field("span", &self.span())
            .finish()
    }
}

impl Clone for SourceFile {
    fn clone(&self) -> Self {
        self.clone()
    }
}

impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.debug())
    }
}

macro_rules! define_client_side {
    ($($name:ident {
        $(fn $method:ident($($arg:ident: $arg_ty:ty),* $(,)?) $(-> $ret_ty:ty)*;)*
    }),* $(,)?) => {
        $(impl $name {
            $(pub(crate) fn $method($($arg: $arg_ty),*) $(-> $ret_ty)* {
                Bridge::with(|bridge| {
                    let mut b = bridge.cached_buffer.take();

                    b.clear();
                    api_tags::Method::$name(api_tags::$name::$method).encode(&mut b, &mut ());
                    reverse_encode!(b; $($arg),*);

                    b = bridge.dispatch.call(b);

                    let r = Result::<_, PanicMessage>::decode(&mut &b[..], &mut ());

                    bridge.cached_buffer = b;

                    r.unwrap_or_else(|e| panic::resume_unwind(e.into()))
                })
            })*
        })*
    }
}
with_api!(self, self, define_client_side);

enum BridgeState<'a> {
    /// ఈ క్లయింట్‌కు ప్రస్తుతం సర్వర్ కనెక్ట్ కాలేదు.
    NotConnected,

    /// సర్వర్ కనెక్ట్ చేయబడింది మరియు అభ్యర్థనల కోసం అందుబాటులో ఉంది.
    Connected(Bridge<'a>),

    /// వంతెనకు ప్రాప్యత ప్రత్యేకంగా పొందబడింది (ఉదా., `BridgeState::with` సమయంలో).
    ///
    InUse,
}

enum BridgeStateL {}

impl<'a> scoped_cell::ApplyL<'a> for BridgeStateL {
    type Out = BridgeState<'a>;
}

thread_local! {
    static BRIDGE_STATE: scoped_cell::ScopedCell<BridgeStateL> =
        scoped_cell::ScopedCell::new(BridgeState::NotConnected);
}

impl BridgeState<'_> {
    /// థ్రెడ్-లోకల్ `BridgeState` యొక్క ప్రత్యేక నియంత్రణను తీసుకోండి మరియు దానిని `f` కి మార్చండి.
    /// `f` నిష్క్రమణల తరువాత, panic ద్వారా కూడా, `f` చేత చేసిన మార్పులతో సహా రాష్ట్రం పునరుద్ధరించబడుతుంది.
    ///
    ///
    /// NB, `f` నడుస్తున్నప్పుడు, థ్రెడ్-లోకల్ స్టేట్ `BridgeState::InUse`.
    ///
    ///
    fn with<R>(f: impl FnOnce(&mut BridgeState<'_>) -> R) -> R {
        BRIDGE_STATE.with(|state| {
            state.replace(BridgeState::InUse, |mut state| {
                // FIXME(#52812) `RefMutL` పోయినప్పుడు `f` ను నేరుగా `replace` కి పాస్ చేయండి
                f(&mut *state)
            })
        })
    }
}

impl Bridge<'_> {
    pub(crate) fn is_available() -> bool {
        BridgeState::with(|state| match state {
            BridgeState::Connected(_) | BridgeState::InUse => true,
            BridgeState::NotConnected => false,
        })
    }

    fn enter<R>(self, f: impl FnOnce() -> R) -> R {
        let force_show_panics = self.force_show_panics;
        // `proc_macro` విస్తరణలలో డిఫాల్ట్ panic అవుట్పుట్ను దాచండి.
        // ఎన్బి.సర్వర్ దీన్ని చేయలేము ఎందుకంటే ఇది వేరే libstd ని ఉపయోగించవచ్చు.
        static HIDE_PANICS_DURING_EXPANSION: Once = Once::new();
        HIDE_PANICS_DURING_EXPANSION.call_once(|| {
            let prev = panic::take_hook();
            panic::set_hook(Box::new(move |info| {
                let show = BridgeState::with(|state| match state {
                    BridgeState::NotConnected => true,
                    BridgeState::Connected(_) | BridgeState::InUse => force_show_panics,
                });
                if show {
                    prev(info)
                }
            }));
        });

        BRIDGE_STATE.with(|state| state.set(BridgeState::Connected(self), f))
    }

    fn with<R>(f: impl FnOnce(&mut Bridge<'_>) -> R) -> R {
        BridgeState::with(|state| match state {
            BridgeState::NotConnected => {
                panic!("procedural macro API is used outside of a procedural macro");
            }
            BridgeState::InUse => {
                panic!("procedural macro API is used while it's already in use");
            }
            BridgeState::Connected(bridge) => f(bridge),
        })
    }
}

/// క్లయింట్-సైడ్ "global object" (సాధారణంగా ఫంక్షన్ పాయింటర్), ఇది సర్వర్ ఉపయోగించే వేరే `proc_macro` ను ఉపయోగిస్తుంది, కానీ అనుకూలంగా సంకర్షణ చెందుతుంది.
///
///
/// NB, `F` లో FFI-స్నేహపూర్వక మెమరీ లేఅవుట్ ఉండాలి (ఉదా., ఒక పాయింటర్).
/// `F` కోసం ఉపయోగించిన ఫంక్షన్ పాయింటర్ల యొక్క కాల్ ABI సర్వర్ మరియు క్లయింట్ మధ్య సరిపోలడం అవసరం లేదు, ఎందుకంటే ఇది వాటి మధ్య మరియు క్లయింట్ పిలిచే (eventually) మధ్య మాత్రమే దాటింది.
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
pub struct Client<F> {
    // FIXME(eddyb) రేపర్ `fn` పాయింటర్‌కు బదులుగా, `static COUNTERS` కు సూచనను ఉపయోగించండి, ఒకసారి `const fn` `స్టాటిక్'లను సూచించగలదు.
    //
    pub(super) get_handle_counters: extern "C" fn() -> &'static HandleCounters,
    pub(super) run: extern "C" fn(Bridge<'_>, F) -> Buffer<u8>,
    pub(super) f: F,
}

/// క్లయింట్ panics ను నిర్వహించడానికి, వంతెనలోకి ప్రవేశించడానికి, ఇన్పుట్‌ను డీసలైజింగ్ చేయడానికి మరియు అవుట్పుట్‌ను సీరియలైజ్ చేయడానికి క్లయింట్-సైడ్ హెల్పర్.
///
// FIXME(eddyb) `Bridge::enter` ను దీనితో భర్తీ చేయవచ్చా?
fn run_client<A: for<'a, 's> DecodeMut<'a, 's, ()>, R: Encode<()>>(
    mut bridge: Bridge<'_>,
    f: impl FnOnce(A) -> R,
) -> Buffer<u8> {
    // ప్రారంభ `cached_buffer` ఇన్పుట్ కలిగి ఉంది.
    let mut b = bridge.cached_buffer.take();

    panic::catch_unwind(panic::AssertUnwindSafe(|| {
        bridge.enter(|| {
            let reader = &mut &b[..];
            let input = A::decode(reader, &mut ());

            // అభ్యర్థనల కోసం `cached_buffer` ను `Bridge` లో తిరిగి ఉంచండి.
            Bridge::with(|bridge| bridge.cached_buffer = b.take());

            let output = f(input);

            // అవుట్పుట్ విలువ కోసం, `cached_buffer` ను తిరిగి తీసుకోండి.
            b = Bridge::with(|bridge| bridge.cached_buffer.take());

            // HACK(eddyb) `bridge.enter(|| ...)` స్కోప్ వెలుపల హ్యాండిల్స్ ఉండకుండా ఉండటానికి మరియు విజయాన్ని ఎన్కోడింగ్ చేసేటప్పుడు జరిగే panics ను పట్టుకోవటానికి panic (`Err(e: PanicMessage)`) ను ఎన్కోడింగ్ చేయకుండా సక్సెస్ విలువ (`Ok(output)`) ను ఎన్కోడింగ్ చేయండి.
            //
            // panics ఈ దశకు మించి అసాధ్యమని గమనించండి, అయితే ఇది `extern "C"` కి చేరే ప్రమాదవశాత్తు భయాందోళనలను నివారించడానికి రక్షణాత్మకంగా ప్రయత్నిస్తోంది (ఇది `abort` ఉండాలి కానీ ప్రస్తుతానికి కాకపోవచ్చు, కాబట్టి ఇది UB ని కూడా నిరోధించగలదు).
            //
            //
            //
            //
            //
            //
            b.clear();
            Ok::<_, ()>(output).encode(&mut b, &mut ());
        })
    }))
    .map_err(PanicMessage::from)
    .unwrap_or_else(|e| {
        b.clear();
        Err::<(), _>(e).encode(&mut b, &mut ());
    });
    b
}

impl Client<fn(crate::TokenStream) -> crate::TokenStream> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn expand1(f: fn(crate::TokenStream) -> crate::TokenStream) -> Self {
        extern "C" fn run(
            bridge: Bridge<'_>,
            f: impl FnOnce(crate::TokenStream) -> crate::TokenStream,
        ) -> Buffer<u8> {
            run_client(bridge, |input| f(crate::TokenStream(input)).0)
        }
        Client { get_handle_counters: HandleCounters::get, run, f }
    }
}

impl Client<fn(crate::TokenStream, crate::TokenStream) -> crate::TokenStream> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn expand2(
        f: fn(crate::TokenStream, crate::TokenStream) -> crate::TokenStream,
    ) -> Self {
        extern "C" fn run(
            bridge: Bridge<'_>,
            f: impl FnOnce(crate::TokenStream, crate::TokenStream) -> crate::TokenStream,
        ) -> Buffer<u8> {
            run_client(bridge, |(input, input2)| {
                f(crate::TokenStream(input), crate::TokenStream(input2)).0
            })
        }
        Client { get_handle_counters: HandleCounters::get, run, f }
    }
}

#[repr(C)]
#[derive(Copy, Clone)]
pub enum ProcMacro {
    CustomDerive {
        trait_name: &'static str,
        attributes: &'static [&'static str],
        client: Client<fn(crate::TokenStream) -> crate::TokenStream>,
    },

    Attr {
        name: &'static str,
        client: Client<fn(crate::TokenStream, crate::TokenStream) -> crate::TokenStream>,
    },

    Bang {
        name: &'static str,
        client: Client<fn(crate::TokenStream) -> crate::TokenStream>,
    },
}

impl ProcMacro {
    pub fn name(&self) -> &'static str {
        match self {
            ProcMacro::CustomDerive { trait_name, .. } => trait_name,
            ProcMacro::Attr { name, .. } => name,
            ProcMacro::Bang { name, .. } => name,
        }
    }

    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn custom_derive(
        trait_name: &'static str,
        attributes: &'static [&'static str],
        expand: fn(crate::TokenStream) -> crate::TokenStream,
    ) -> Self {
        ProcMacro::CustomDerive { trait_name, attributes, client: Client::expand1(expand) }
    }

    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn attr(
        name: &'static str,
        expand: fn(crate::TokenStream, crate::TokenStream) -> crate::TokenStream,
    ) -> Self {
        ProcMacro::Attr { name, client: Client::expand2(expand) }
    }

    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn bang(
        name: &'static str,
        expand: fn(crate::TokenStream) -> crate::TokenStream,
    ) -> Self {
        ProcMacro::Bang { name, client: Client::expand1(expand) }
    }
}