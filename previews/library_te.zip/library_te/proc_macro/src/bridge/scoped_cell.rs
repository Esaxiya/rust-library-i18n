//! `Cell` (scoped) అస్తిత్వ జీవితకాల కోసం వేరియంట్.

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// జీవితకాలంతో లాంబ్డా అప్లికేషన్‌ను టైప్ చేయండి.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// జీవితకాలం తీసుకునే లాంబ్డా టైప్ చేయండి, అనగా, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) `&'a mut <T as ApplyL<'b>>::Out` తో భర్తీ చేసే newtype FIXME(#52812) తో ప్రొజెక్షన్ పరిమితుల చుట్టూ పని చేయండి
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// `f` ను నడుపుతున్నప్పుడు `self` నుండి `replacement` వరకు విలువను సెట్ చేస్తుంది, ఇది పాత విలువను పరస్పరం పొందుతుంది.
    /// `f` నిష్క్రమించిన తర్వాత పాత విలువ పునరుద్ధరించబడుతుంది, panic ద్వారా కూడా, `f` చేత చేసిన మార్పులతో సహా.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// `f` భయాందోళనకు గురైనప్పటికీ, సెల్ ఎల్లప్పుడూ నిండినట్లు నిర్ధారించే రేపర్ (అసలు స్థితితో, ఐచ్ఛికంగా `f` చే మార్చబడింది).
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// `f` నడుస్తున్నప్పుడు విలువను `self` నుండి `value` వరకు సెట్ చేస్తుంది.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}