# Stdarch కు సహకరిస్తుంది

`stdarch` crate రచనలను అంగీకరించడానికి సిద్ధంగా ఉంది!మొదట మీరు రిపోజిటరీని తనిఖీ చేసి, మీ కోసం పరీక్షలు పాస్ అయ్యేలా చూసుకోవాలి:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

`rustup` ఉపయోగించినట్లుగా `<your-target-arch>` అనేది లక్ష్య ట్రిపుల్, ఉదా. `x86_x64-unknown-linux-gnu` (మునుపటి `nightly-` లేదా ఇలాంటివి లేకుండా).
ఈ రిపోజిటరీకి రాత్రిపూట Rust ఛానెల్ అవసరమని గుర్తుంచుకోండి!
పై పరీక్షలకు వాస్తవానికి రాత్రిపూట rust మీ సిస్టమ్‌లో డిఫాల్ట్‌గా ఉండాలి, `rustup default nightly` (మరియు తిరిగి మార్చడానికి `rustup default stable`) వాడకాన్ని సెట్ చేస్తుంది.

పై దశల్లో ఏదైనా పని చేయకపోతే, [please let us know][new]!

తదుపరి మీరు సహాయం చేయడానికి [find an issue][issues] చేయవచ్చు, మేము కొన్ని సహాయాన్ని ప్రత్యేకంగా ఉపయోగించగల [`help wanted`][help] మరియు [`impl-period`][impl] ట్యాగ్‌లతో కొన్నింటిని ఎంచుకున్నాము. 
మీరు [#40][vendor] పై ఎక్కువ ఆసక్తి కలిగి ఉండవచ్చు, x86 లో అన్ని అమ్మకందారుల అంతర్గతాలను అమలు చేస్తుంది.ఆ సమస్య ఎక్కడ ప్రారంభించాలో కొన్ని మంచి పాయింటర్లను కలిగి ఉంది!

మీకు సాధారణ ప్రశ్నలు ఉంటే [join us on gitter][gitter] కి సంకోచించకండి మరియు చుట్టూ అడగండి!ప్రశ్నలతో urburntSushi లేదా@alexcrichton ను పింగ్ చేయడానికి సంకోచించకండి.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Stdarch అంతర్గత కోసం ఉదాహరణలు ఎలా వ్రాయాలి

ఇచ్చిన అంతర్గతంగా సరిగ్గా పనిచేయడానికి కొన్ని లక్షణాలు తప్పనిసరిగా ప్రారంభించబడాలి మరియు ఈ లక్షణం CPU చేత మద్దతు ఇవ్వబడినప్పుడు మాత్రమే `cargo test --doc` చేత అమలు చేయబడాలి.

ఫలితంగా, `rustdoc` చేత ఉత్పత్తి చేయబడిన డిఫాల్ట్ `fn main` పనిచేయదు (చాలా సందర్భాలలో).
మీ ఉదాహరణ .హించిన విధంగా పనిచేస్తుందని నిర్ధారించడానికి కిందివాటిని గైడ్‌గా ఉపయోగించడాన్ని పరిగణించండి.

```rust
/// # // ఉదాహరణ మాత్రమే అని నిర్ధారించడానికి మాకు cfg_target_feature అవసరం
/// # // CPU లక్షణానికి మద్దతు ఇచ్చినప్పుడు `cargo test --doc` చేత అమలు చేయబడుతుంది
/// # #![feature(cfg_target_feature)]
/// # // అంతర్గతంగా పనిచేయడానికి మాకు టార్గెట్_ ఫీచర్ అవసరం
/// # #![feature(target_feature)]
/// #
/// # // డిఫాల్ట్‌గా రస్ట్‌డాక్ `extern crate stdarch` ని ఉపయోగిస్తుంది, కాని మనకు ఇది అవసరం
/// # // `#[macro_use]`
/// # # [మాక్రో_యూస్] బాహ్య crate stdarch;
/// #
/// # // నిజమైన ప్రధాన విధి
/// # fn main() {
/// #     // `<target feature>` కి మద్దతు ఉంటే మాత్రమే దీన్ని అమలు చేయండి
/// #     cfg_feature_enabled ఉంటే! ("<target feature>"){
/// #         // లక్ష్య లక్షణం ఉంటే మాత్రమే అమలు చేయబడే `worker` ఫంక్షన్‌ను సృష్టించండి
/// #         // మద్దతు ఉంది మరియు మీ కార్మికుడి కోసం `target_feature` ప్రారంభించబడిందని నిర్ధారించుకోండి
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         అసురక్షిత fn worker() {
/// // మీ ఉదాహరణ ఇక్కడ రాయండి.ఫీచర్ నిర్దిష్ట అంతర్గతాలు ఇక్కడ పని చేస్తాయి!అడవికి వెళ్ళు!
///
/// #         }
///
/// #         అసురక్షిత { worker(); }
/// #     }
/// # }
```

పై కొన్ని వాక్యనిర్మాణం తెలిసి ఉండకపోతే, [Rust Book] యొక్క [Documentation as tests] విభాగం `rustdoc` వాక్యనిర్మాణాన్ని బాగా వివరిస్తుంది.
ఎప్పటిలాగే, [join us on gitter][gitter] కి సంకోచించకండి మరియు మీరు ఏదైనా స్నాగ్స్ కొట్టారా అని మమ్మల్ని అడగండి మరియు `stdarch` యొక్క డాక్యుమెంటేషన్ మెరుగుపరచడంలో సహాయపడినందుకు ధన్యవాదాలు!

# ప్రత్యామ్నాయ పరీక్ష సూచనలు

పరీక్షలను అమలు చేయడానికి మీరు `ci/run.sh` ను ఉపయోగించాలని సాధారణంగా సిఫార్సు చేయబడింది.
అయితే ఇది మీ కోసం పని చేయకపోవచ్చు, ఉదా. మీరు Windows లో ఉంటే.

అలాంటప్పుడు మీరు కోడ్ ఉత్పత్తిని పరీక్షించడానికి `cargo +nightly test` మరియు `cargo +nightly test --release -p core_arch` ను అమలు చేయడానికి తిరిగి వస్తారు.
వీటికి రాత్రిపూట టూల్‌చెయిన్ వ్యవస్థాపించాల్సిన అవసరం ఉందని మరియు మీ టార్గెట్ ట్రిపుల్ మరియు దాని CPU గురించి `rustc` తెలుసుకోవాలి.
ముఖ్యంగా మీరు `ci/run.sh` కోసం `TARGET` ఎన్విరాన్మెంట్ వేరియబుల్ ను సెట్ చేయాలి.
అదనంగా మీరు లక్ష్య లక్షణాలను సూచించడానికి `RUSTCFLAGS` (`C` అవసరం) ను సెట్ చేయాలి, ఉదా `RUSTCFLAGS="-C -target-features=+avx2"`.
మీరు మీ ప్రస్తుత CPU కి వ్యతిరేకంగా "just" అభివృద్ధి చెందుతుంటే మీరు `-C -target-cpu=native` ను కూడా సెట్ చేయవచ్చు.

మీరు ఈ ప్రత్యామ్నాయ సూచనలను ఉపయోగించినప్పుడు, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], ఉదా
బోధన తరం పరీక్షలు విఫలం కావచ్చు ఎందుకంటే విడదీయువాడు వాటికి భిన్నంగా పేరు పెట్టాడు, ఉదా
అదే విధంగా ప్రవర్తించినప్పటికీ ఇది `aesenc` సూచనలకు బదులుగా `vaesenc` ను ఉత్పత్తి చేస్తుంది.
ఈ సూచనలు సాధారణంగా చేసినదానికంటే తక్కువ పరీక్షలను అమలు చేస్తాయి, కాబట్టి మీరు చివరికి లాగండి-అభ్యర్థించినప్పుడు ఇక్కడ లోపాలు లేని పరీక్షల కోసం కొన్ని లోపాలు కనిపిస్తాయని ఆశ్చర్యపోకండి.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






