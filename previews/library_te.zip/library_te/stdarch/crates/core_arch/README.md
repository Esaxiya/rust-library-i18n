`core::arch` - Rust యొక్క కోర్ లైబ్రరీ ఆర్కిటెక్చర్-నిర్దిష్ట అంతర్గత
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` మాడ్యూల్ ఆర్కిటెక్చర్-ఆధారిత అంతర్గతాలను (ఉదా. SIMD) అమలు చేస్తుంది.

# Usage 

`core::arch` `libcore` లో భాగంగా అందుబాటులో ఉంది మరియు ఇది `libstd` చే తిరిగి ఎగుమతి చేయబడుతుంది.ఈ crate ద్వారా కాకుండా `core::arch` లేదా `std::arch` ద్వారా ఉపయోగించడానికి ఇష్టపడండి.
అస్థిర లక్షణాలు తరచుగా రాత్రి Rust లో `feature(stdsimd)` ద్వారా లభిస్తాయి.

ఈ crate ద్వారా `core::arch` ను ఉపయోగించటానికి రాత్రిపూట Rust అవసరం, మరియు ఇది తరచుగా విచ్ఛిన్నమవుతుంది (మరియు చేస్తుంది).ఈ crate ద్వారా మీరు దీన్ని ఉపయోగించాల్సిన సందర్భాలు:

* మీరు `core::arch` ను మీరే తిరిగి కంపైల్ చేయవలసి వస్తే, ఉదా., `libcore`/`libstd` కోసం ప్రారంభించబడని నిర్దిష్ట లక్ష్య-లక్షణాలతో ప్రారంభించబడింది.
Note: మీరు ప్రామాణికం కాని లక్ష్యం కోసం దాన్ని తిరిగి కంపైల్ చేయవలసి వస్తే, దయచేసి ఈ crate ను ఉపయోగించటానికి బదులుగా `xargo` ను ఉపయోగించడం మరియు `libcore`/`libstd` ను తిరిగి కంపైల్ చేయడం ఇష్టపడండి.
  
* అస్థిర Rust లక్షణాల వెనుక కూడా అందుబాటులో లేని కొన్ని లక్షణాలను ఉపయోగించడం.మేము వీటిని కనిష్టంగా ఉంచడానికి ప్రయత్నిస్తాము.
మీరు ఈ లక్షణాలలో కొన్నింటిని ఉపయోగించాల్సిన అవసరం ఉంటే, దయచేసి ఒక సమస్యను తెరవండి, తద్వారా మేము వాటిని రాత్రిపూట Rust లో బహిర్గతం చేయవచ్చు మరియు మీరు వాటిని అక్కడి నుండి ఉపయోగించవచ్చు.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` ప్రధానంగా MIT లైసెన్స్ మరియు Apache లైసెన్స్ (వెర్షన్ 2.0) రెండింటి నిబంధనల క్రింద పంపిణీ చేయబడుతుంది, వివిధ BSD-లాంటి లైసెన్సుల ద్వారా కవర్ చేయబడిన భాగాలతో.

వివరాల కోసం LICENSE-APACHE మరియు LICENSE-MIT చూడండి.

# Contribution

మీరు స్పష్టంగా పేర్కొనకపోతే, Apache-2.0 లైసెన్స్‌లో నిర్వచించిన విధంగా మీరు `core_arch` లో చేర్చడానికి ఉద్దేశపూర్వకంగా సమర్పించిన ఏదైనా సహకారం అదనపు నిబంధనలు లేదా షరతులు లేకుండా పైన పేర్కొన్న విధంగా ద్వంద్వ లైసెన్స్ పొందబడుతుంది.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












