#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) చూడండి.
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) చూడండి.
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) చూడండి.
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) చూడండి.
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) చూడండి.
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) చూడండి.
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// ఇచ్చిన `rw` మరియు `locality` ఉపయోగించి `p` చిరునామాను కలిగి ఉన్న కాష్ లైన్‌ను పొందండి.
///
/// `rw` వీటిలో ఒకటిగా ఉండాలి:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): ప్రిఫెట్ చదవడానికి సిద్ధమవుతోంది.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): ప్రిఫెట్ రాయడానికి సిద్ధమవుతోంది.
///
/// `locality` వీటిలో ఒకటిగా ఉండాలి:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): ఒక్కసారి మాత్రమే ఉపయోగించే డేటా కోసం స్ట్రీమింగ్ లేదా నాన్-టెంపోరల్ ప్రిఫెచ్.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): స్థాయి 3 కాష్‌లోకి ప్రవేశించండి.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): స్థాయి 2 కాష్‌లోకి ప్రవేశించండి.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): స్థాయి 1 కాష్‌లోకి ప్రవేశించండి.
///
/// పేర్కొన్న చిరునామా నుండి మెమరీ యాక్సెస్ చేసే మెమరీ సిస్టమ్‌కు ప్రీఫెట్ మెమరీ సూచనలు సిగ్నల్ సమీప future లో సంభవించే అవకాశం ఉంది.
/// పేర్కొన్న చిరునామాను ఒకటి లేదా అంతకంటే ఎక్కువ కాష్లలో ప్రీలోడ్ చేయడం వంటి జ్ఞాపకశక్తి ప్రాప్యత వేగవంతం అవుతుందని భావించే చర్యలు తీసుకోవడం ద్వారా మెమరీ సిస్టమ్ ప్రతిస్పందించగలదు.
///
/// ఈ సంకేతాలు సూచనలు మాత్రమే కనుక, ఏదైనా లేదా అన్ని ముందస్తు సూచనలను NOP గా పరిగణించడం ఒక నిర్దిష్ట CPU కి చెల్లుతుంది.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // మేము `cache type` =1 (డేటా కాష్) తో `llvm.prefetch` అంతర్గత ఉపయోగిస్తాము.
    // `rw` మరియు `strategy` ఫంక్షన్ పారామితులపై ఆధారపడి ఉంటాయి.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}