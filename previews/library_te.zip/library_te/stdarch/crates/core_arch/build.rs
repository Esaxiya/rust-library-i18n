use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // మా `#[assert_instr]` ఉల్లేఖనాలను చెప్పడానికి వాడతారు, అన్ని సిమ్డ్ అంతర్గతాలు వారి కోడజన్‌ను పరీక్షించడానికి అందుబాటులో ఉన్నాయి, ఎందుకంటే కొన్ని అదనపు `-Ctarget-feature=+unimplemented-simd128` వెనుక ఉన్నాయి, అవి ప్రస్తుతం `#[target_feature]` లో సమానమైనవి లేవు.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}