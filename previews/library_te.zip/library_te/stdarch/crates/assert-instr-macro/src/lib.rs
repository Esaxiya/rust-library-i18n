//! `#[assert_instr]` స్థూల అమలు
//!
//! ఈ స్థూలత `stdarch` crate ను పరీక్షించేటప్పుడు ఉపయోగించబడుతుంది మరియు పరీక్షా కేసులను రూపొందించడానికి ఉపయోగించబడుతుంది, అవి విధులు కలిగి ఉండాలని మేము ఆశించే సూచనలను కలిగి ఉన్నాయని నిర్ధారించడానికి.
//!
//! ఇక్కడ విధానపరమైన స్థూలత చాలా సులభం, ఇది అసలు token స్ట్రీమ్‌కు `#[test]` ఫంక్షన్‌ను జోడిస్తుంది, ఇది ఫంక్షన్‌లో సంబంధిత సూచనలను కలిగి ఉందని నొక్కి చెబుతుంది.
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // Avx ప్రారంభించబడిన x86 లక్ష్యాల కోసం assert_instr ని నిలిపివేయండి, దీనివల్ల LLVM మేము పరీక్షిస్తున్న వివిధ అంతర్గతాలను ఉత్పత్తి చేస్తుంది.
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // బోధనా పరీక్షలు నిలిపివేయబడితే, ఈ షిమ్‌ను విడుదల చేయకుండా ఉండండి, మా లక్షణం లేకుండా అసలు అంశాన్ని తిరిగి ఇవ్వండి.
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // ఈ పేరు తరువాత వేరుచేయడం లో కనుగొనటానికి మాకు ప్రత్యేకంగా ఉండాలి:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // డిఫాల్ట్‌గా Unix (నేను అనుకుంటున్నాను?) లో ఏమి జరుగుతుందో వంటి రిజిస్టర్లలో SIMD విలువలను దాటిన Windows లో ABI ని ఉపయోగించండి.
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // ఆప్టిమైజ్ మోడ్‌లోని కంపైలర్ డిఫాల్ట్‌గా "mergefunc" అని పిలువబడే పాస్‌ను నడుపుతుంది, ఇక్కడ ఇది ఒకేలా కనిపించే ఫంక్షన్లను విలీనం చేస్తుంది.
            // కొన్ని అంతర్భాగాలు ఒకేలాంటి కోడ్‌ను ఉత్పత్తి చేస్తాయి మరియు అవి కలిసి ముడుచుకుంటాయి, అంటే ఒకటి మరొకదానికి దూకుతుంది.
            // ఇది ఈ ఫంక్షన్ యొక్క వేరుచేయడం యొక్క మా తనిఖీని గందరగోళానికి గురి చేస్తుంది మరియు మేము దాని యొక్క పెద్ద అభిమాని కాదు.
            //
            // ఈ పాస్‌ను అడ్డుకోవటానికి మరియు ఫంక్షన్‌లు విలీనం కాకుండా నిరోధించడానికి మేము కోడ్‌జెన్ పరంగా చాలా గట్టిగా ఉండే కొన్ని కోడ్‌ను ఉత్పత్తి చేస్తాము కాని కోడ్ మడవకుండా నిరోధించడానికి ప్రత్యేకంగా ఉంటుంది.
            //
            //
            // ఈ ఫంక్షన్లు ఇన్లైన్ చేయబడనందున ఇది ప్రస్తుతం Wasm32 లో నివారించబడింది, ఇది మా పరీక్షలను విచ్ఛిన్నం చేస్తుంది, ఎందుకంటే ప్రతి అంతర్గత ఫంక్షన్లను పిలుస్తున్నట్లు కనిపిస్తుంది.
            // ఏమైనప్పటికీ wasm32 లో విలీనం కావడానికి ఫంక్షన్లు సరిపోవు.
            // ఈ బగ్ rust-lang/rust#74320 వద్ద ట్రాక్ చేయబడింది.
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}