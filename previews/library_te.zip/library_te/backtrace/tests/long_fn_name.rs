use backtrace::Backtrace;

// 50-అక్షరాల మాడ్యూల్ పేరు
mod _234567890_234567890_234567890_234567890_234567890 {
    // 50-అక్షరాల నిర్మాణ పేరు
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// దీర్ఘ ఫంక్షన్ పేర్లను (MAX_SYM_NAME, 1) అక్షరాలకు కత్తిరించాలి.
// gnu అన్ని ఫ్రేమ్‌ల కోసం "<no info>" ను ప్రింట్ చేస్తుంది కాబట్టి, ఈ పరీక్షను msvc కోసం మాత్రమే అమలు చేయండి.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // స్ట్రక్ట్ పేరు యొక్క 10 పునరావృత్తులు, కాబట్టి పూర్తి అర్హత కలిగిన ఫంక్షన్ పేరు కనీసం 10 *(50 + 50)* 2=2000 అక్షరాల పొడవు.
    //
    // ఇది `::`, `<>` మరియు ప్రస్తుత మాడ్యూల్ పేరును కలిగి ఉన్నందున ఇది వాస్తవానికి ఎక్కువ
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}