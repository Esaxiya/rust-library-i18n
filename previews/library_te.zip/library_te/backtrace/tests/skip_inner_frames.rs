use backtrace::Backtrace;

// ఈ పరీక్ష చిహ్నాల ప్రారంభ చిరునామాను నివేదించే ఫ్రేమ్‌ల కోసం పనిచేసే `symbol_address` ఫంక్షన్‌ను కలిగి ఉన్న ప్లాట్‌ఫారమ్‌లలో మాత్రమే పనిచేస్తుంది.
// ఫలితంగా ఇది కొన్ని ప్లాట్‌ఫామ్‌లలో మాత్రమే ప్రారంభించబడుతుంది.
//
const ENABLED: bool = cfg!(all(
    // Windows నిజంగా పరీక్షించబడలేదు మరియు వాస్తవానికి పరివేష్టిత ఫ్రేమ్‌ను కనుగొనడంలో OSX మద్దతు ఇవ్వదు, కాబట్టి దీన్ని నిలిపివేయండి
    //
    target_os = "linux",
    // ARM లో ఎన్‌క్లోజింగ్ ఫంక్షన్‌ను కనుగొనడం కేవలం ip ను తిరిగి ఇస్తుంది.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}