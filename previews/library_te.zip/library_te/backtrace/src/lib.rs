//! రన్‌టైమ్‌లో బ్యాక్‌ట్రేస్‌ను సంపాదించడానికి లైబ్రరీ
//!
//! ఈ లైబ్రరీ ప్రామాణిక లైబ్రరీ యొక్క `RUST_BACKTRACE=1` మద్దతును ప్రోగ్రామ్ టైమ్‌లో రన్‌టైమ్‌లో బ్యాక్‌ట్రేస్‌ను పొందటానికి అనుమతించడం ద్వారా ఉద్దేశించబడింది.
//! ఈ లైబ్రరీ ద్వారా ఉత్పత్తి చేయబడిన బ్యాక్‌ట్రేస్‌లను అన్వయించాల్సిన అవసరం లేదు, ఉదాహరణకు, బహుళ బ్యాకెండ్ అమలుల యొక్క కార్యాచరణను బహిర్గతం చేస్తుంది.
//!
//! # Usage
//!
//! మొదట, దీన్ని మీ Cargo.toml కు జోడించండి
//!
//! ```toml
//! [dependencies]
//! backtrace = "0.3"
//! ```
//!
//! Next:
//!
//! ```
//! fn main() {
//! # // ఇక్కడ సురక్షితం కాదు కాబట్టి no_std లో పరీక్ష పాస్ అవుతుంది.
//! # #[cfg(feature = "std")] {
//!     backtrace::trace(|frame| {
//!         let ip = frame.ip();
//!         let symbol_address = frame.symbol_address();
//!
//!         // ఈ సూచన పాయింటర్‌ను గుర్తు పేరుకు పరిష్కరించండి
//!         backtrace::resolve_frame(frame, |symbol| {
//!             if let Some(name) = symbol.name() {
//!                 // ...
//!             }
//!             if let Some(filename) = symbol.filename() {
//!                 // ...
//!             }
//!         });
//!
//!         true // తదుపరి ఫ్రేమ్‌కు వెళ్లండి
//!     });
//! }
//! # }
//! ```
//!
//!
//!

#![doc(html_root_url = "https://docs.rs/backtrace")]
#![deny(missing_docs)]
#![no_std]
#![cfg_attr(
    all(feature = "std", target_env = "sgx", target_vendor = "fortanix"),
    feature(sgx_platform)
)]
#![warn(rust_2018_idioms)]
// మేము libstd లో భాగంగా నిర్మిస్తున్నప్పుడు, ఈ crate చెట్టు వెలుపల అభివృద్ధి చేయబడినందున అన్ని హెచ్చరికలు అసంబద్ధం కాబట్టి వాటిని నిశ్శబ్దం చేయండి.
//
#![cfg_attr(backtrace_in_libstd, allow(warnings))]
#![cfg_attr(not(feature = "std"), allow(dead_code))]

#[cfg(feature = "std")]
#[macro_use]
extern crate std;

// ఇది ప్రస్తుతం గిమ్లీ కోసం మాత్రమే ఉపయోగించబడుతుంది, ఇది కొన్ని ప్లాట్‌ఫామ్‌లలో మాత్రమే ఉపయోగించబడుతుంది, కాబట్టి ఇది ఇతర కాన్ఫిగరేషన్‌లలో ఉపయోగించబడకపోతే చింతించకండి.
//
#[allow(unused_extern_crates)]
extern crate alloc;

pub use self::backtrace::{trace_unsynchronized, Frame};
mod backtrace;

pub use self::symbolize::resolve_frame_unsynchronized;
pub use self::symbolize::{resolve_unsynchronized, Symbol, SymbolName};
mod symbolize;

pub use self::types::BytesOrWideString;
mod types;

#[cfg(feature = "std")]
pub use self::symbolize::clear_symbol_cache;

mod print;
pub use print::{BacktraceFmt, BacktraceFrameFmt, PrintFmt};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        pub use self::backtrace::trace;
        pub use self::symbolize::{resolve, resolve_frame};
        pub use self::capture::{Backtrace, BacktraceFrame, BacktraceSymbol};
        mod capture;
    }
}

#[allow(dead_code)]
struct Bomb {
    enabled: bool,
}

#[allow(dead_code)]
impl Drop for Bomb {
    fn drop(&mut self) {
        if self.enabled {
            panic!("cannot panic during the backtrace function");
        }
    }
}

#[allow(dead_code)]
#[cfg(feature = "std")]
mod lock {
    use std::boxed::Box;
    use std::cell::Cell;
    use std::sync::{Mutex, MutexGuard, Once};

    pub struct LockGuard(Option<MutexGuard<'static, ()>>);

    static mut LOCK: *mut Mutex<()> = 0 as *mut _;
    static INIT: Once = Once::new();
    thread_local!(static LOCK_HELD: Cell<bool> = Cell::new(false));

    impl Drop for LockGuard {
        fn drop(&mut self) {
            if self.0.is_some() {
                LOCK_HELD.with(|slot| {
                    assert!(slot.get());
                    slot.set(false);
                });
            }
        }
    }

    pub fn lock() -> LockGuard {
        if LOCK_HELD.with(|l| l.get()) {
            return LockGuard(None);
        }
        LOCK_HELD.with(|s| s.set(true));
        unsafe {
            INIT.call_once(|| {
                LOCK = Box::into_raw(Box::new(Mutex::new(())));
            });
            LockGuard(Some((*LOCK).lock().unwrap()))
        }
    }
}

#[cfg(all(windows, not(target_vendor = "uwp")))]
mod dbghelp;
#[cfg(windows)]
mod windows;