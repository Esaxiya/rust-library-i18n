use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// చిరునామాను గుర్తుకు పరిష్కరించండి, చిహ్నాన్ని పేర్కొన్న మూసివేతకు పంపండి.
///
/// ఈ ఫంక్షన్ స్థానిక సింబల్ టేబుల్, డైనమిక్ సింబల్ టేబుల్ లేదా DWARF డీబగ్ సమాచారం (సక్రియం చేయబడిన అమలును బట్టి) వంటి ప్రాంతాలలో ఇచ్చిన చిరునామాను చూస్తుంది.
///
///
/// రిజల్యూషన్ చేయలేకపోతే మూసివేతను పిలవలేరు మరియు ఇన్లైన్డ్ ఫంక్షన్ల విషయంలో దీనిని ఒకటి కంటే ఎక్కువసార్లు పిలుస్తారు.
///
/// ఇచ్చిన చిహ్నాలు పేర్కొన్న `addr` వద్ద అమలును సూచిస్తాయి, ఆ చిరునామా కోసం file/line జతలను తిరిగి ఇస్తాయి (అందుబాటులో ఉంటే).
///
/// మీకు `Frame` ఉంటే, దీనికి బదులుగా `resolve_frame` ఫంక్షన్‌ను ఉపయోగించమని సిఫార్సు చేయబడింది.
///
/// # అవసరమైన లక్షణాలు
///
/// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
///
/// # Panics
///
/// ఈ ఫంక్షన్ ఎప్పుడూ panic కు ప్రయత్నిస్తుంది, కానీ `cb` panics ను అందించినట్లయితే, కొన్ని ప్లాట్‌ఫారమ్‌లు ఈ ప్రక్రియను నిలిపివేయడానికి డబుల్ panic ను బలవంతం చేస్తాయి.
/// కొన్ని ప్లాట్‌ఫారమ్‌లు సి లైబ్రరీని ఉపయోగిస్తాయి, ఇది అంతర్గతంగా కాల్‌బ్యాక్‌లను ఉపయోగించుకోలేనిది, కాబట్టి `cb` నుండి భయాందోళన చెందడం ప్రక్రియను నిలిపివేయవచ్చు.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // ఎగువ ఫ్రేమ్‌ను మాత్రమే చూడండి
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// గతంలో సంగ్రహించిన ఫ్రేమ్‌ను గుర్తుకు పరిష్కరించండి, చిహ్నాన్ని పేర్కొన్న మూసివేతకు పంపుతుంది.
///
/// ఈ ఫంక్టిన్ `resolve` వలె అదే పనితీరును చేస్తుంది తప్ప అది చిరునామాకు బదులుగా `Frame` ను ఆర్గ్యుమెంట్‌గా తీసుకుంటుంది.
/// ఇది బ్యాక్‌ట్రేసింగ్ యొక్క కొన్ని ప్లాట్‌ఫారమ్ అమలులను మరింత ఖచ్చితమైన చిహ్న సమాచారం లేదా ఇన్లైన్ ఫ్రేమ్‌ల గురించి సమాచారాన్ని అందించడానికి అనుమతిస్తుంది.
///
/// మీకు వీలైతే దీన్ని ఉపయోగించమని సిఫార్సు చేయబడింది.
///
/// # అవసరమైన లక్షణాలు
///
/// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
///
/// # Panics
///
/// ఈ ఫంక్షన్ ఎప్పుడూ panic కు ప్రయత్నిస్తుంది, కానీ `cb` panics ను అందించినట్లయితే, కొన్ని ప్లాట్‌ఫారమ్‌లు ఈ ప్రక్రియను నిలిపివేయడానికి డబుల్ panic ను బలవంతం చేస్తాయి.
/// కొన్ని ప్లాట్‌ఫారమ్‌లు సి లైబ్రరీని ఉపయోగిస్తాయి, ఇది అంతర్గతంగా కాల్‌బ్యాక్‌లను ఉపయోగించుకోలేనిది, కాబట్టి `cb` నుండి భయాందోళన చెందడం ప్రక్రియను నిలిపివేయవచ్చు.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // ఎగువ ఫ్రేమ్‌ను మాత్రమే చూడండి
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// స్టాక్ ఫ్రేమ్‌ల నుండి IP విలువలు సాధారణంగా (always?) ఇన్స్ట్రక్షన్ *తర్వాత* కాల్ అసలు స్టాక్ ట్రేస్.
// దీన్ని సింబాలింగ్ చేయడం వలన filename/line సంఖ్య ఫంక్షన్ ముగింపులో ఉంటే అది ముందుకు మరియు బహుశా శూన్యంగా మారుతుంది.
//
// ఇది ప్రాథమికంగా అన్ని ప్లాట్‌ఫారమ్‌లలో ఎల్లప్పుడూ కనిపిస్తుంది, కాబట్టి మేము సూచనలను తిరిగి ఇవ్వడానికి బదులుగా మునుపటి కాల్ సూచనలకు పరిష్కరించడానికి పరిష్కరించబడిన ఐపి నుండి ఒకదాన్ని తీసివేస్తాము.
//
//
// ఆదర్శవంతంగా మేము దీన్ని చేయలేము.
// ఆదర్శవంతంగా, ఇక్కడ `resolve` API ల యొక్క కాలర్లు మానవీయంగా -1 మరియు ఖాతాకు *మునుపటి* సూచనల కోసం స్థాన సమాచారం కావాలి, ప్రస్తుతానికి కాదు.
// మేము తరువాతి సూచన లేదా ప్రస్తుత చిరునామా అయితే ఆదర్శవంతంగా మేము `Frame` లో కూడా బహిర్గతం చేస్తాము.
//
// ప్రస్తుతానికి ఇది చాలా సముచితమైన ఆందోళన అయినప్పటికీ మేము అంతర్గతంగా ఎల్లప్పుడూ ఒకదాన్ని తీసివేస్తాము.
// వినియోగదారులు పని చేస్తూనే ఉండాలి మరియు మంచి ఫలితాలను పొందుతారు, కాబట్టి మనం తగినంతగా ఉండాలి.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` వలె ఉంటుంది, ఇది సమకాలీకరించబడనందున మాత్రమే సురక్షితం కాదు.
///
/// ఈ ఫంక్షన్ సింక్రొనైజేషన్ గ్యారెంటీలను కలిగి లేదు, కానీ ఈ crate యొక్క `std` ఫీచర్ కంపైల్ చేయనప్పుడు అందుబాటులో ఉంటుంది.
/// మరిన్ని డాక్యుమెంటేషన్ మరియు ఉదాహరణల కోసం `resolve` ఫంక్షన్ చూడండి.
///
/// # Panics
///
/// `cb` పానికింగ్ పై మినహాయింపుల కోసం `resolve` పై సమాచారాన్ని చూడండి.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` వలె ఉంటుంది, ఇది సమకాలీకరించబడనందున మాత్రమే సురక్షితం కాదు.
///
/// ఈ ఫంక్షన్ సింక్రొనైజేషన్ గ్యారెంటీలను కలిగి లేదు, కానీ ఈ crate యొక్క `std` ఫీచర్ కంపైల్ చేయనప్పుడు అందుబాటులో ఉంటుంది.
/// మరిన్ని డాక్యుమెంటేషన్ మరియు ఉదాహరణల కోసం `resolve_frame` ఫంక్షన్ చూడండి.
///
/// # Panics
///
/// `cb` పానికింగ్ పై మినహాయింపుల కోసం `resolve_frame` పై సమాచారాన్ని చూడండి.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// ఒక ఫైల్‌లోని చిహ్నం యొక్క తీర్మానాన్ని సూచించే trait.
///
/// ఈ trait `backtrace::resolve` ఫంక్షన్‌కు ఇచ్చిన మూసివేతకు trait ఆబ్జెక్ట్‌గా ఇవ్వబడుతుంది మరియు దాని వెనుక ఏ అమలు ఉందో తెలియదు కాబట్టి ఇది వాస్తవంగా పంపబడుతుంది.
///
///
/// ఒక చిహ్నం ఒక ఫంక్షన్ గురించి సందర్భోచిత సమాచారాన్ని ఇవ్వగలదు, ఉదాహరణకు పేరు, ఫైల్ పేరు, పంక్తి సంఖ్య, ఖచ్చితమైన చిరునామా మొదలైనవి.
/// అన్ని సమాచారం ఎల్లప్పుడూ చిహ్నంలో అందుబాటులో ఉండదు, అయితే, అన్ని పద్ధతులు `Option` ను తిరిగి ఇస్తాయి.
///
///
pub struct Symbol {
    // TODO: ఈ జీవితకాల బంధం చివరికి `Symbol` కు కొనసాగాలి,
    // కానీ ప్రస్తుతం ఇది బ్రేకింగ్ మార్పు.
    // ప్రస్తుతానికి ఇది సురక్షితం ఎందుకంటే `Symbol` ఎప్పుడూ సూచన ద్వారా మాత్రమే ఇవ్వబడుతుంది మరియు క్లోన్ చేయబడదు.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// ఈ ఫంక్షన్ పేరును అందిస్తుంది.
    ///
    /// గుర్తు పేరు గురించి వివిధ లక్షణాలను ప్రశ్నించడానికి తిరిగి వచ్చిన నిర్మాణాన్ని ఉపయోగించవచ్చు:
    ///
    ///
    /// * `Display` అమలు డీమంగల్డ్ చిహ్నాన్ని ముద్రిస్తుంది.
    /// * గుర్తు యొక్క ముడి `str` విలువను యాక్సెస్ చేయవచ్చు (ఇది చెల్లుబాటు అయ్యే utf-8 అయితే).
    /// * గుర్తు పేరు కోసం ముడి బైట్‌లను యాక్సెస్ చేయవచ్చు.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// ఈ ఫంక్షన్ యొక్క ప్రారంభ చిరునామాను చూపుతుంది.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// ముడి ఫైల్ పేరును స్లైస్‌గా అందిస్తుంది.
    /// ఇది ప్రధానంగా `no_std` వాతావరణాలకు ఉపయోగపడుతుంది.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// ఈ చిహ్నం ప్రస్తుతం అమలు చేస్తున్న కాలమ్ సంఖ్యను అందిస్తుంది.
    ///
    /// గిమ్లి మాత్రమే ప్రస్తుతం ఇక్కడ విలువను అందిస్తుంది మరియు అప్పుడు కూడా `filename` `Some` ను తిరిగి ఇస్తేనే, మరియు అది సారూప్య హెచ్చరికలకు లోబడి ఉంటుంది.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// ఈ గుర్తు ప్రస్తుతం అమలు చేస్తున్న చోట పంక్తి సంఖ్యను చూపుతుంది.
    ///
    /// `filename` `Some` ను తిరిగి ఇస్తే ఈ రిటర్న్ విలువ సాధారణంగా `Some` అవుతుంది మరియు తత్ఫలితంగా ఇలాంటి మినహాయింపులకు లోబడి ఉంటుంది.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// ఈ ఫంక్షన్ నిర్వచించబడిన ఫైల్ పేరును అందిస్తుంది.
    ///
    /// ఇది ప్రస్తుతం లిబ్‌బ్యాక్‌ట్రేస్ లేదా గిమ్లిని ఉపయోగిస్తున్నప్పుడు మాత్రమే అందుబాటులో ఉంటుంది (ఉదా
    /// unix ప్లాట్‌ఫారమ్‌లు ఇతరవి) మరియు బైనరీ డీబగిన్‌ఫోతో కంపైల్ చేయబడినప్పుడు.
    /// ఈ షరతులు ఏవీ నెరవేర్చకపోతే, ఇది `None` ను తిరిగి ఇస్తుంది.
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Rust గా మ్యాంగిల్ చేసిన చిహ్నాన్ని అన్వయించడం విఫలమైతే, పార్స్ చేసిన C++ గుర్తు.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // ఈ సున్నా-పరిమాణంలో ఉండేలా చూసుకోండి, తద్వారా `cpp_demangle` ఫీచర్ నిలిపివేయబడినప్పుడు ఖర్చు ఉండదు.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// డీమంగల్డ్ పేరు, ముడి బైట్లు, ముడి స్ట్రింగ్ మొదలైన వాటికి ఎర్గోనామిక్ యాక్సెసర్లను అందించడానికి గుర్తు పేరు చుట్టూ ఒక రేపర్.
///
// `cpp_demangle` ఫీచర్ ప్రారంభించబడనప్పుడు డెడ్ కోడ్‌ను అనుమతించండి.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// ముడి అంతర్లీన బైట్‌ల నుండి క్రొత్త గుర్తు పేరును సృష్టిస్తుంది.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// గుర్తు చెల్లుబాటు అయ్యే utf-8 అయితే ముడి (mangled) గుర్తు పేరును `str` గా అందిస్తుంది.
    ///
    /// మీరు డీమంగల్డ్ వెర్షన్ కావాలంటే `Display` అమలు ఉపయోగించండి.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// ముడి గుర్తు పేరును బైట్‌ల జాబితాగా అందిస్తుంది
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // డీమంగల్డ్ సింబల్ వాస్తవానికి చెల్లుబాటు కాకపోతే ఇది ముద్రించవచ్చు, కాబట్టి లోపాన్ని బాహ్యంగా ప్రచారం చేయకుండా ఇక్కడ సరసముగా నిర్వహించండి.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// చిరునామాలను సూచించడానికి ఉపయోగించిన కాష్ చేసిన మెమరీని తిరిగి పొందే ప్రయత్నం.
///
/// ఈ పద్ధతి ప్రపంచవ్యాప్తంగా లేదా కాష్ చేయబడిన గ్లోబల్ డేటా స్ట్రక్చర్లను విడుదల చేయడానికి ప్రయత్నిస్తుంది, ఇది సాధారణంగా పార్స్ చేసిన DWARF సమాచారాన్ని సూచిస్తుంది లేదా ఇలాంటిది.
///
///
/// # Caveats
///
/// ఈ ఫంక్షన్ ఎల్లప్పుడూ అందుబాటులో ఉన్నప్పటికీ, ఇది చాలా అమలులలో వాస్తవంగా ఏమీ చేయదు.
/// Dbghelp లేదా libbacktrace వంటి గ్రంథాలయాలు రాష్ట్రాన్ని డీలోకేట్ చేయడానికి మరియు కేటాయించిన మెమరీని నిర్వహించడానికి సౌకర్యాలను అందించవు.
/// ప్రస్తుతానికి ఈ crate యొక్క `gimli-symbolize` లక్షణం ఈ ఫంక్షన్ ఏదైనా ప్రభావాన్ని కలిగి ఉన్న ఏకైక లక్షణం.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}