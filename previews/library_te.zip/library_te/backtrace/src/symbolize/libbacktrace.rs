//! లిబ్‌బ్యాక్‌ట్రేస్‌లో DWARF-పార్సింగ్ కోడ్‌ను ఉపయోగించి సింబాలికేషన్ స్ట్రాటజీ.
//!
//! లిబ్‌బ్యాక్‌ట్రేస్ సి లైబ్రరీ, సాధారణంగా gcc తో పంపిణీ చేయబడుతుంది, ఇది బ్యాక్‌ట్రేస్‌ను ఉత్పత్తి చేయడమే కాకుండా (ఇది మేము నిజంగా ఉపయోగించము) బ్యాక్‌ట్రేస్‌ను సూచిస్తుంది మరియు ఇన్లైన్ చేసిన ఫ్రేమ్‌లు మరియు వాట్నోట్ వంటి వాటి గురించి మరగుజ్జు డీబగ్ సమాచారాన్ని నిర్వహించడానికి మద్దతు ఇస్తుంది.
//!
//!
//! ఇక్కడ చాలా ఆందోళనల కారణంగా ఇది చాలా క్లిష్టంగా ఉంటుంది, కానీ ప్రాథమిక ఆలోచన:
//!
//! * మొదట మనం `backtrace_syminfo` అని పిలుస్తాము.ఇది మనకు వీలైతే డైనమిక్ సింబల్ టేబుల్ నుండి సింబల్ సమాచారాన్ని పొందుతుంది.
//! * తరువాత మనం `backtrace_pcinfo` అని పిలుస్తాము.ఇది డీబగ్‌ఇన్‌ఫో పట్టికలు అందుబాటులో ఉంటే వాటిని అన్వయించి, ఇన్లైన్ ఫ్రేమ్‌లు, ఫైల్ పేర్లు, లైన్ నంబర్లు మొదలైన వాటి గురించి సమాచారాన్ని తిరిగి పొందటానికి అనుమతిస్తుంది.
//!
//! మరగుజ్జు పట్టికలను లిబ్‌బ్యాక్‌ట్రేస్‌లోకి తీసుకురావడం గురించి చాలా ఉపాయాలు ఉన్నాయి, కానీ ఆశాజనక ఇది ప్రపంచం అంతం కాదు మరియు క్రింద చదివేటప్పుడు తగినంత స్పష్టంగా ఉంటుంది.
//!
//! ఇది MSVC కాని మరియు OSX కాని ప్లాట్‌ఫారమ్‌ల కోసం డిఫాల్ట్ సింబాలికేషన్ స్ట్రాటజీ.లిబ్‌స్టడ్‌లో ఇది OSX కోసం డిఫాల్ట్ వ్యూహం.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // వీలైతే డీబగిన్ఫో నుండి వచ్చిన `function` పేరును ఇష్టపడండి మరియు ఉదాహరణకు ఇన్లైన్ ఫ్రేమ్‌ల కోసం మరింత ఖచ్చితమైనది.
                // అది లేనట్లయితే `symname` లో పేర్కొన్న గుర్తు పట్టిక పేరుకు తిరిగి వస్తాయి.
                //
                // కొన్నిసార్లు `function` కొంత తక్కువ ఖచ్చితమైన అనుభూతిని కలిగిస్తుందని గమనించండి, ఉదాహరణకు X002 యొక్క `try<i32,closure>` isntead గా జాబితా చేయబడింది.
                //
                // ఇది నిజంగా ఎందుకు స్పష్టంగా లేదు, కానీ మొత్తంగా `function` పేరు మరింత ఖచ్చితమైనదిగా అనిపిస్తుంది.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ప్రస్తుతానికి ఏమీ చేయవద్దు
}

/// `data` పాయింటర్ యొక్క రకం `syminfo_cb` లోకి పంపబడింది
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // మేము పరిష్కరించడం ప్రారంభించినప్పుడు `backtrace_syminfo` నుండి ఈ బ్యాక్‌బ్యాక్ ప్రారంభించిన తర్వాత మేము `backtrace_pcinfo` కి కాల్ చేయడానికి మరింత ముందుకు వెళ్తాము.
    // `backtrace_pcinfo` ఫంక్షన్ డీబగ్ సమాచారాన్ని సంప్రదిస్తుంది మరియు file/line సమాచారంతో పాటు ఇన్లైన్ చేసిన ఫ్రేమ్‌లను తిరిగి పొందడం వంటి పనులను చేస్తుంది.
    // డీబగ్ సమాచారం లేకపోతే `backtrace_pcinfo` విఫలం కావచ్చు లేదా ఎక్కువ చేయలేదని గమనించండి, కనుక ఇది జరిగితే మేము `syminfo_cb` నుండి కనీసం ఒక గుర్తుతో కాల్‌బ్యాక్‌కు కాల్ చేస్తాం.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` పాయింటర్ యొక్క రకం `pcinfo_cb` లోకి పంపబడింది
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// లిబ్‌బ్యాక్‌ట్రేస్ API ఒక రాష్ట్రాన్ని సృష్టించడానికి మద్దతు ఇస్తుంది, కానీ ఇది ఒక రాష్ట్రాన్ని నాశనం చేయడానికి మద్దతు ఇవ్వదు.
// నేను వ్యక్తిగతంగా దీనిని తీసుకుంటాను అంటే ఒక రాష్ట్రం సృష్టించబడాలి మరియు శాశ్వతంగా జీవించాలి.
//
// ఈ స్థితిని శుభ్రపరిచే at_exit() హ్యాండ్లర్‌ను నమోదు చేయడానికి నేను ఇష్టపడతాను, కాని లిబ్‌బ్యాక్‌ట్రేస్ అలా చేయటానికి మార్గం ఇవ్వదు.
//
// ఈ పరిమితులతో, ఈ ఫంక్షన్ స్థిరంగా కాష్ చేసిన స్థితిని కలిగి ఉంది, ఇది మొదటిసారి అభ్యర్థించినప్పుడు లెక్కించబడుతుంది.
//
// బ్యాక్‌ట్రాసింగ్ అన్నీ సీరియల్‌గా జరుగుతాయని గుర్తుంచుకోండి (ఒక గ్లోబల్ లాక్).
//
// `resolve` బాహ్యంగా సమకాలీకరించాల్సిన అవసరం ఉన్నందున ఇక్కడ సమకాలీకరణ లేకపోవడం గమనించండి.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // లిబ్‌బ్యాక్‌ట్రేస్ యొక్క థ్రెడ్‌సేఫ్ సామర్థ్యాలను మేము ఎల్లప్పుడూ సమకాలీకరించిన పద్ధతిలో పిలుస్తున్నాము.
        //
        0,
        error_cb,
        ptr::null_mut(), // అదనపు డేటా లేదు
    );

    return STATE;

    // లిబ్‌బ్యాక్‌ట్రేస్ పనిచేయడానికి ప్రస్తుత ఎక్జిక్యూటబుల్ కోసం DWARF డీబగ్ సమాచారాన్ని కనుగొనడం అవసరం.ఇది సాధారణంగా వీటితో సహా అనేక యంత్రాంగాల ద్వారా చేస్తుంది:
    //
    // * /proc/self/exe మద్దతు ఉన్న ప్లాట్‌ఫామ్‌లపై
    // * స్థితిని సృష్టించేటప్పుడు ఫైల్ పేరు స్పష్టంగా పాస్ అవుతుంది
    //
    // లిబ్‌బ్యాక్‌ట్రేస్ లైబ్రరీ సి కోడ్ యొక్క పెద్ద వాడ్.సహజంగానే దీని అర్థం మెమరీ భద్రతా లోపాలు, ముఖ్యంగా చెడ్డ డీబగిన్‌ఫోను నిర్వహించేటప్పుడు.
    // లిబ్‌స్టెడ్ చారిత్రాత్మకంగా వీటిలో పుష్కలంగా ఉంది.
    //
    // /proc/self/exe ఉపయోగించినట్లయితే, మేము సాధారణంగా లిబ్‌బ్యాక్‌ట్రేస్ "mostly correct" అని అనుకుంటాము మరియు "attempted to be correct" మరగుజ్జు డీబగ్ సమాచారంతో విచిత్రమైన పనులను చేయము.
    //
    //
    // మేము ఒక ఫైల్ పేరులో ఉత్తీర్ణత సాధించినట్లయితే, కొన్ని ప్లాట్‌ఫారమ్‌లలో (BSD లు వంటివి) ఒక హానికరమైన నటుడు ఆ ప్రదేశంలో ఏకపక్ష ఫైల్‌ను ఉంచడానికి కారణమవుతుంది.
    // దీని అర్థం మనం ఫైల్ పేరు గురించి లిబ్‌బ్యాక్‌ట్రేస్‌కు చెబితే అది ఏకపక్ష ఫైల్‌ను ఉపయోగిస్తూ ఉండవచ్చు, బహుశా సెగ్‌ఫాల్ట్‌లకు కారణం కావచ్చు.
    // మేము లిబ్‌బ్యాక్‌ట్రేస్‌కు ఏదైనా చెప్పకపోతే, అది /proc/self/exe వంటి మార్గాలకు మద్దతు ఇవ్వని ప్లాట్‌ఫామ్‌లలో ఏమీ చేయదు!
    //
    // ఫైల్ పేరులో * పాస్ చేయకుండా ఉండటానికి మేము వీలైనంతగా ప్రయత్నిస్తాము, కాని మేము /proc/self/exe కి మద్దతు ఇవ్వని ప్లాట్‌ఫామ్‌లపై ఉండాలి.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // మేము `std::env::current_exe` ను ఆదర్శంగా ఉపయోగిస్తాము, కాని మనకు ఇక్కడ `std` అవసరం లేదు.
            //
            // ప్రస్తుత ఎక్జిక్యూటబుల్ మార్గాన్ని స్టాటిక్ ఏరియాలోకి లోడ్ చేయడానికి `_NSGetExecutablePath` ని ఉపయోగించండి (ఇది చాలా చిన్నది అయితే వదిలివేయండి).
            //
            //
            // అవినీతి ఎక్జిక్యూటబుల్స్ పై చనిపోకుండా ఉండటానికి మేము ఇక్కడ లిబ్‌బ్యాక్‌ట్రేస్‌ను తీవ్రంగా విశ్వసిస్తున్నామని గమనించండి, అయితే ఇది ఖచ్చితంగా చేస్తుంది ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ఫైళ్ళను తెరిచే మోడ్ ఉంది, అది తెరిచిన తర్వాత దాన్ని తొలగించలేము.
            // సాధారణంగా ఇక్కడ మనకు కావలసినది ఏమిటంటే, మేము లిబ్‌బ్యాక్‌ట్రేస్‌కు అప్పగించిన తర్వాత మా ఎక్జిక్యూటబుల్ మన క్రింద నుండి మారడం లేదని నిర్ధారించుకోవాలనుకుంటున్నాము, ఏకపక్ష డేటాను లిబ్యాక్‌ట్రేస్‌లోకి పంపే సామర్థ్యాన్ని ఆశాజనకంగా తగ్గిస్తుంది (ఇది తప్పుగా నిర్వహించబడవచ్చు).
            //
            //
            // మన స్వంత చిత్రంపై ఒక విధమైన లాక్ పొందడానికి ప్రయత్నించడానికి మేము ఇక్కడ కొంచెం నృత్యం చేస్తాము:
            //
            // * ప్రస్తుత ప్రక్రియకు హ్యాండిల్ పొందండి, దాని ఫైల్ పేరును లోడ్ చేయండి.
            // * కుడి జెండాలతో ఆ ఫైల్ పేరుకు ఫైల్‌ను తెరవండి.
            // * ప్రస్తుత ప్రాసెస్ యొక్క ఫైల్ పేరును మళ్లీ లోడ్ చేయండి, ఇది ఒకేలా ఉందని నిర్ధారించుకోండి
            //
            // అన్ని పాస్లు ఉంటే మేము సిద్ధాంతపరంగా మా ప్రాసెస్ యొక్క ఫైల్ను తెరిచాము మరియు అది మారదని మేము హామీ ఇస్తున్నాము.FWIW దీని యొక్క సమూహం చారిత్రాత్మకంగా libstd నుండి కాపీ చేయబడింది, కాబట్టి ఇది ఏమి జరుగుతుందో నా ఉత్తమ వివరణ.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // ఇది స్టాటిక్ మెమరీలో నివసిస్తుంది కాబట్టి మనం దానిని తిరిగి ఇవ్వగలం ..
                static mut BUF: [i8; N] = [0; N];
                // ... మరియు ఇది తాత్కాలికమైనందున ఇది స్టాక్‌లో నివసిస్తుంది
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ఉద్దేశపూర్వకంగా ఇక్కడ `handle` ను లీక్ చేయండి ఎందుకంటే ఓపెన్ కలిగి ఉండటం వల్ల ఈ ఫైల్ పేరు మీద మన లాక్ సంరక్షించబడుతుంది.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // మేము నల్-టెర్మినేట్ చేయబడిన ఒక స్లైస్‌ని తిరిగి ఇవ్వాలనుకుంటున్నాము, కాబట్టి ప్రతిదీ నిండి ఉంటే మరియు అది మొత్తం పొడవుకు సమానం అయితే దాన్ని వైఫల్యానికి సమానం.
                //
                //
                // లేకపోతే విజయం తిరిగి వచ్చేటప్పుడు నల్ బైట్ స్లైస్‌లో చేర్చబడిందని నిర్ధారించుకోండి.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // బ్యాక్‌ట్రేస్ లోపాలు ప్రస్తుతం రగ్గు కింద తుడిచిపెట్టుకుపోయాయి
    let state = init_state();
    if state.is_null() {
        return;
    }

    // `backtrace_syminfo` API కి కాల్ చేయండి (కోడ్ చదవడం నుండి) `syminfo_cb` ని సరిగ్గా ఒకసారి కాల్ చేయాలి (లేదా లోపంతో విఫలమవుతుంది).
    // మేము అప్పుడు `syminfo_cb` లోనే ఎక్కువ నిర్వహిస్తాము.
    //
    // `syminfo` సింబల్ టేబుల్‌ను సంప్రదిస్తుంది కాబట్టి, బైనరీలో డీబగ్ సమాచారం లేనప్పటికీ గుర్తు పేర్లను కనుగొంటుంది.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}