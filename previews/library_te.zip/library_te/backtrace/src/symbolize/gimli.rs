//! crates.io లో `gimli` crate ను ఉపయోగించి సింబాలికేషన్ కోసం మద్దతు
//!
//! ఇది Rust కోసం డిఫాల్ట్ సింబాలికేషన్ అమలు.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'స్టాటిక్ లైఫ్‌టైమ్ అనేది స్వీయ-రెఫరెన్షియల్ స్ట్రక్ట్‌లకు మద్దతు లేకపోవడం చుట్టూ హ్యాక్ చేయడం అబద్ధం.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // చిహ్నాలు `map` మరియు `stash` లను మాత్రమే తీసుకోవాలి కాబట్టి మేము వాటిని స్టాటిక్ లైఫ్ టైమ్స్ గా మార్చండి మరియు మేము వాటిని క్రింద భద్రపరుస్తున్నాము.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows లో స్థానిక లైబ్రరీలను లోడ్ చేయడానికి, ఇక్కడ ఉన్న వివిధ వ్యూహాల కోసం rust-lang/rust#71060 పై కొంత చర్చ చూడండి.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW లైబ్రరీలు ప్రస్తుతం ASLR (rust-lang/rust#16514) కి మద్దతు ఇవ్వవు, కాని DLL లను ఇప్పటికీ చిరునామా స్థలంలో మార్చవచ్చు.
            // డీబగ్ సమాచారంలోని చిరునామాలు అన్నీ ఈ లైబ్రరీని దాని "image base" వద్ద లోడ్ చేసినట్లుగా కనిపిస్తాయి, ఇది దాని COFF ఫైల్ హెడర్‌లలోని ఫీల్డ్.
            // డీబగ్ఇన్ఫో జాబితా చేసినట్లు కనబడుతున్నందున, మేము సింబల్ టేబుల్ మరియు స్టోర్ చిరునామాలను అన్వయించాము, లైబ్రరీ "image base" వద్ద కూడా లోడ్ అయినట్లుగా.
            //
            // అయితే, లైబ్రరీ "image base" వద్ద లోడ్ కాకపోవచ్చు.
            // (బహుశా అక్కడ వేరే ఏదో లోడ్ చేయబడవచ్చు?) ఇక్కడే `bias` ఫీల్డ్ అమలులోకి వస్తుంది మరియు ఇక్కడ `bias` విలువను మనం గుర్తించాలి.దురదృష్టవశాత్తు లోడ్ చేసిన మాడ్యూల్ నుండి దీన్ని ఎలా పొందాలో స్పష్టంగా లేదు.
            // మన వద్ద ఉన్నది అసలు లోడ్ చిరునామా (`modBaseAddr`).
            //
            // ప్రస్తుతానికి కాప్-అవుట్ యొక్క బిట్గా, మేము ఫైల్ను ఎమ్మాప్ చేస్తాము, ఫైల్ హెడర్ సమాచారాన్ని చదివి, ఆపై ఎమ్ఎమ్ఎప్ ను వదలండి.ఇది వ్యర్థం ఎందుకంటే మేము తరువాత ఎమ్మాప్‌ను తిరిగి తెరుస్తాము, కానీ ఇది ప్రస్తుతానికి బాగా పని చేస్తుంది.
            //
            // ఒకసారి మేము `image_base` (కావలసిన లోడ్ స్థానం) మరియు `base_addr` (వాస్తవ లోడ్ స్థానం) కలిగి ఉంటే, మేము `bias` ని పూరించవచ్చు (వాస్తవమైన మరియు కావలసిన వాటి మధ్య వ్యత్యాసం), ఆపై ప్రతి సెగ్మెంట్ యొక్క పేర్కొన్న చిరునామా `image_base` ఎందుకంటే ఫైల్ ఏమి చెబుతుంది.
            //
            //
            // ప్రస్తుతానికి ELF/MachO మాదిరిగా కాకుండా, లైబ్రరీకి ఒక సెగ్మెంట్‌తో, `modBaseSize` ను మొత్తం పరిమాణంగా ఉపయోగించుకోవచ్చు.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS Mac-O ఫైల్ ఆకృతిని ఉపయోగిస్తుంది మరియు అనువర్తనంలో భాగమైన స్థానిక లైబ్రరీల జాబితాను లోడ్ చేయడానికి DYLD-నిర్దిష్ట API లను ఉపయోగిస్తుంది.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // ఈ లైబ్రరీ పేరును ఎక్కడ లోడ్ చేయాలో మార్గానికి అనుగుణంగా పొందండి.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // ఈ లైబ్రరీ యొక్క ఇమేజ్ హెడర్‌ను లోడ్ చేసి, అన్ని లోడ్ ఆదేశాలను అన్వయించడానికి `object` కి అప్పగించండి, అందువల్ల ఇక్కడ ఉన్న అన్ని విభాగాలను మేము గుర్తించగలము.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // విభాగాలపై మళ్ళించండి మరియు మేము కనుగొన్న విభాగాల కోసం తెలిసిన ప్రాంతాలను నమోదు చేయండి.
            // తరువాత ప్రాసెస్ చేయడానికి సమాచారం బౌట్ టెక్స్ట్ విభాగాలను రికార్డ్ చేయండి, క్రింద వ్యాఖ్యలను చూడండి.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // ఈ లైబ్రరీ కోసం "slide" ని నిర్ణయించండి, ఇది మెమరీ వస్తువులు ఎక్కడ లోడ్ అవుతాయో గుర్తించడానికి మేము ఉపయోగించే పక్షపాతం.
            // ఇది కాస్త విచిత్రమైన గణన మరియు అడవిలో కొన్ని విషయాలను ప్రయత్నించడం మరియు కర్రలు చూడటం యొక్క ఫలితం.
            //
            // సాధారణ ఆలోచన ఏమిటంటే, `bias` ప్లస్ ఒక సెగ్మెంట్ యొక్క `stated_virtual_memory_address` అసలు చిరునామా స్థలంలో సెగ్మెంట్ నివసించే చోట ఉంటుంది.
            // మేము ఆధారపడే మరో విషయం ఏమిటంటే, నిజమైన చిరునామా మైనస్ `bias` అనేది సింబల్ టేబుల్ మరియు డీబగిన్ఫోలో చూసే సూచిక.
            //
            // సిస్టమ్ లోడ్ చేసిన లైబ్రరీల కోసం ఈ లెక్కలు తప్పు అని తేలింది.స్థానిక ఎక్జిక్యూటబుల్స్ కోసం, ఇది సరైనదిగా కనిపిస్తుంది.
            // ఎల్‌ఎల్‌డిబి యొక్క మూలం నుండి కొంత తర్కాన్ని ఎత్తివేస్తే, ఫైల్ ఆఫ్‌సెట్ 0 నుండి నాన్‌జెరో పరిమాణంతో లోడ్ చేయబడిన మొదటి `__TEXT` విభాగానికి కొన్ని ప్రత్యేక కేసింగ్ ఉంది.
            // ఇది ఉన్నప్పుడు ఏ కారణం చేతనైనా గుర్తు పట్టిక లైబ్రరీ కోసం కేవలం vmaddr స్లైడ్‌కు సాపేక్షంగా ఉంటుంది.
            // ఇది *లేనట్లయితే* గుర్తు పట్టిక vmaddr స్లైడ్‌తో పాటు సెగ్మెంట్ పేర్కొన్న చిరునామాకు సంబంధించి ఉంటుంది.
            //
            // ఫైల్ ఆఫ్‌సెట్ సున్నా వద్ద వచన విభాగాన్ని మేము కనుగొనలేకపోతే ఈ పరిస్థితిని పరిష్కరించడానికి, అప్పుడు మేము మొదటి వచన విభాగాల పేర్కొన్న చిరునామా ద్వారా పక్షపాతాన్ని పెంచుతాము మరియు పేర్కొన్న మొత్తం చిరునామాలను కూడా ఆ మొత్తంతో తగ్గిస్తాము.
            //
            // ఆ విధంగా లైబ్రరీ యొక్క బయాస్ మొత్తానికి సంబంధించి గుర్తు పట్టిక ఎల్లప్పుడూ కనిపిస్తుంది.
            // సింబల్ టేబుల్ ద్వారా సింబలైజ్ చేయడానికి ఇది సరైన ఫలితాలను కలిగి ఉన్నట్లు కనిపిస్తుంది.
            //
            // నిజాయితీగా ఇది సరైనదేనా లేదా దీన్ని ఎలా చేయాలో సూచించే మరేదైనా ఉంటే నాకు పూర్తిగా తెలియదు.
            // ప్రస్తుతానికి ఇది తగినంతగా (?) బాగా పనిచేస్తున్నట్లు అనిపిస్తున్నప్పటికీ, అవసరమైతే మనం దీన్ని కాలక్రమేణా సర్దుబాటు చేయగలగాలి.
            //
            // మరికొన్ని సమాచారం కోసం #318 చూడండి
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // ఇతర Unix (ఉదా
        // లైనక్స్) ప్లాట్‌ఫారమ్‌లు ELF ని ఆబ్జెక్ట్ ఫైల్ ఫార్మాట్‌గా ఉపయోగిస్తాయి మరియు స్థానిక లైబ్రరీలను లోడ్ చేయడానికి `dl_iterate_phdr` అనే API ని అమలు చేస్తాయి.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` చెల్లుబాటు అయ్యే పాయింటర్లుగా ఉండాలి.
        // `vec` `std::Vec` కు చెల్లుబాటు అయ్యే పాయింటర్ అయి ఉండాలి.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 డీబగ్ సమాచారానికి స్థానికంగా మద్దతు ఇవ్వదు, కానీ బిల్డ్ సిస్టమ్ `romfs:/debug_info.elf` మార్గంలో డీబగ్ సమాచారాన్ని ఉంచుతుంది.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // మిగతావన్నీ ELF ను ఉపయోగించాలి, కాని స్థానిక లైబ్రరీలను ఎలా లోడ్ చేయాలో తెలియదు.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// లోడ్ చేయబడిన అన్ని తెలిసిన భాగస్వామ్య లైబ్రరీలు.
    libraries: Vec<Library>,

    /// మేము పార్స్ చేసిన మరగుజ్జు సమాచారాన్ని కలిగి ఉన్న మ్యాపింగ్ కాష్.
    ///
    /// ఈ జాబితా దాని మొత్తం లిఫ్టైమ్ కోసం స్థిర సామర్థ్యాన్ని కలిగి ఉంటుంది, అది ఎప్పటికీ పెరగదు.
    /// ప్రతి జత యొక్క `usize` మూలకం `libraries` పై సూచిక, ఇక్కడ `usize::max_value()` ప్రస్తుత ఎక్జిక్యూటబుల్‌ను సూచిస్తుంది.
    ///
    /// `Mapping` అనేది పార్స్ చేసిన మరగుజ్జు సమాచారం.
    ///
    /// ఇది ప్రాథమికంగా ఒక LRU కాష్ అని గమనించండి మరియు మేము చిరునామాలకు ప్రతీకగా ఇక్కడ విషయాలను బదిలీ చేస్తాము.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// ఈ లైబ్రరీ యొక్క విభాగాలు మెమరీలోకి లోడ్ చేయబడతాయి మరియు అవి ఎక్కడ లోడ్ చేయబడతాయి.
    segments: Vec<LibrarySegment>,
    /// ఈ లైబ్రరీ యొక్క "bias", సాధారణంగా ఇది మెమరీలోకి లోడ్ అవుతుంది.
    /// సెగ్మెంట్ లోడ్ చేయబడిన వాస్తవ వర్చువల్ మెమరీ చిరునామాను పొందడానికి ప్రతి సెగ్మెంట్ పేర్కొన్న చిరునామాకు ఈ విలువ జోడించబడుతుంది.
    /// అదనంగా, ఈ పక్షపాతం రియల్ వర్చువల్ మెమరీ చిరునామాల నుండి ఇండెక్స్ నుండి డీబగిన్ఫో మరియు సింబల్ టేబుల్ లోకి తీసివేయబడుతుంది.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// ఆబ్జెక్ట్ ఫైల్‌లో ఈ విభాగం యొక్క పేర్కొన్న చిరునామా.
    /// ఇది సెగ్మెంట్ లోడ్ చేయబడిన చోట కాదు, కానీ ఈ చిరునామాతో పాటు లైబ్రరీ యొక్క `bias` ఉన్న చోట దాన్ని కనుగొనవచ్చు.
    ///
    stated_virtual_memory_address: usize,
    /// మెమరీలో ths సెగ్మెంట్ పరిమాణం.
    len: usize,
}

// సురక్షితం కాదు ఎందుకంటే ఇది బాహ్యంగా సమకాలీకరించాల్సిన అవసరం ఉంది
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // సురక్షితం కాదు ఎందుకంటే ఇది బాహ్యంగా సమకాలీకరించాల్సిన అవసరం ఉంది
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // డీబగ్ సమాచారం మ్యాపింగ్ కోసం చాలా చిన్న, చాలా సరళమైన LRU కాష్.
        //
        // హిట్ రేటు చాలా ఎక్కువగా ఉండాలి, ఎందుకంటే సాధారణ స్టాక్ చాలా షేర్డ్ లైబ్రరీల మధ్య దాటదు.
        //
        // `addr2line::Context` నిర్మాణాలు సృష్టించడానికి చాలా ఖరీదైనవి.
        // దీని వ్యయం తరువాతి `locate` ప్రశ్నల ద్వారా రుణమాఫీ చేయబడుతుందని భావిస్తున్నారు, ఇది మంచి స్పీడ్‌అప్‌లను పొందడానికి `addr2line: : కాంటెక్స్ట్`లను నిర్మించేటప్పుడు నిర్మించిన నిర్మాణాలను ప్రభావితం చేస్తుంది.
        //
        // మాకు ఈ కాష్ లేకపోతే, ఆ రుణమాఫీ ఎప్పటికీ జరగదు, మరియు బ్యాక్‌ట్రేస్‌లను ప్రతీకగా చెప్పడం ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // మొదట, ఈ `lib` లో `addr` (పున oc స్థాపన నిర్వహణ) ఉన్న ఏదైనా విభాగం ఉందో లేదో పరీక్షించండి.ఈ చెక్ పాస్ అయినట్లయితే, మేము క్రింద కొనసాగవచ్చు మరియు వాస్తవానికి చిరునామాను అనువదించవచ్చు.
                //
                // ఓవర్ఫ్లో తనిఖీలను నివారించడానికి మేము ఇక్కడ `wrapping_add` ను ఉపయోగిస్తున్నామని గమనించండి.SVMA + బయాస్ గణన పొంగిపొర్లుతున్నట్లు ఇది అడవిలో కనిపిస్తుంది.
                // ఇది జరగడం కొంచెం విచిత్రంగా అనిపిస్తుంది, కాని అంతరిక్షంలోకి సూచించే అవకాశం ఉన్నందున ఆ విభాగాలను విస్మరించడం మినహా మనం దాని గురించి పెద్ద మొత్తంలో చేయలేము.
                //
                // ఇది మొదట rust-lang/backtrace-rs#329 లో వచ్చింది.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // ఇప్పుడు `lib` లో `addr` ఉందని మనకు తెలుసు, పేర్కొన్న వైరల్ మెమరీ చిరునామాను కనుగొనడానికి మేము పక్షపాతంతో ఆఫ్‌సెట్ చేయవచ్చు.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // మార్పులేనిది: ఈ షరతులతో ప్రారంభ తిరిగి రాకుండా పూర్తయిన తర్వాత
        // లోపం నుండి, ఈ మార్గం కోసం కాష్ ఎంట్రీ సూచిక 0 వద్ద ఉంది.

        if let Some(idx) = idx {
            // మ్యాపింగ్ ఇప్పటికే కాష్‌లో ఉన్నప్పుడు, దానిని ముందు వైపుకు తరలించండి.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // మ్యాపింగ్ కాష్‌లో లేనప్పుడు, క్రొత్త మ్యాపింగ్‌ను సృష్టించండి, కాష్ ముందు భాగంలో చొప్పించండి మరియు అవసరమైతే పురాతన కాష్ ఎంట్రీని తొలగించండి.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` జీవితకాలం లీక్ చేయవద్దు, అది మనకు మాత్రమే స్కోప్ చేయబడిందని నిర్ధారించుకోండి
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // దురదృష్టవశాత్తు మేము ఇక్కడకు అవసరం కాబట్టి `sym` యొక్క జీవితకాలం `'static` కు విస్తరించండి, కానీ ఇది ఎప్పుడైనా ఒక సూచనగా బయటకు వెళుతుంది కాబట్టి ఈ ఫ్రేమ్‌కు మించి ఏ సూచనను కొనసాగించకూడదు.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // చివరగా, కాష్ చేసిన మ్యాపింగ్ పొందండి లేదా ఈ ఫైల్ కోసం క్రొత్త మ్యాపింగ్‌ను సృష్టించండి మరియు ఈ చిరునామా కోసం file/line/name ను కనుగొనడానికి DWARF సమాచారాన్ని అంచనా వేయండి.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// మేము ఈ చిహ్నం కోసం ఫ్రేమ్ సమాచారాన్ని గుర్తించగలిగాము, మరియు `addr2line` యొక్క ఫ్రేమ్ అంతర్గతంగా అన్ని ఇబ్బందికరమైన వివరాలను కలిగి ఉంది.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// డీబగ్ సమాచారాన్ని కనుగొనలేకపోయాము, కాని మేము దానిని elf ఎక్జిక్యూటబుల్ యొక్క సింబల్ టేబుల్‌లో కనుగొన్నాము.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}