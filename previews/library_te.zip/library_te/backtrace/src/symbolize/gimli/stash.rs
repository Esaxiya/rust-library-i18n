// ప్రస్తుతం Linux లో మాత్రమే ఉపయోగించబడుతుంది, కాబట్టి డెడ్ కోడ్‌ను మరెక్కడా అనుమతించండి
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// బైట్ బఫర్‌ల కోసం ఒక సాధారణ అరేనా కేటాయింపు.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// పేర్కొన్న పరిమాణం యొక్క బఫర్‌ను కేటాయిస్తుంది మరియు దానికి మార్చగల సూచనను అందిస్తుంది.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // భద్రత: ఇది ఒక మ్యూటబుల్‌ను నిర్మించే ఏకైక ఫంక్షన్
        // `self.buffers` కు సూచన.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // భద్రత: మేము `self.buffers` నుండి మూలకాలను ఎప్పటికీ తీసివేయము, కాబట్టి సూచన
        // ఏదైనా బఫర్ లోపల ఉన్న డేటాకు `self` ఉన్నంత కాలం జీవిస్తుంది.
        &mut buffers[i]
    }
}