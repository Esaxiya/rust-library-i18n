use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// యాజమాన్యంలోని మరియు స్వీయ-నియంత్రణ బ్యాక్‌ట్రేస్ యొక్క ప్రాతినిధ్యం.
///
/// ఈ నిర్మాణాన్ని ఒక ప్రోగ్రామ్‌లోని వివిధ పాయింట్ల వద్ద బ్యాక్‌ట్రేస్‌ను సంగ్రహించడానికి ఉపయోగించవచ్చు మరియు తరువాత ఆ సమయంలో బ్యాక్‌ట్రేస్ ఏమిటో పరిశీలించడానికి ఉపయోగించవచ్చు.
///
///
/// `Backtrace` దాని `Debug` అమలు ద్వారా బ్యాక్‌ట్రేస్‌ల అందంగా ముద్రించడానికి మద్దతు ఇస్తుంది.
///
/// # అవసరమైన లక్షణాలు
///
/// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // ఇక్కడ ఫ్రేమ్‌లు స్టాక్ పై నుండి క్రిందికి ఇవ్వబడ్డాయి
    frames: Vec<BacktraceFrame>,
    // `Backtrace::new` మరియు `backtrace::trace` వంటి ఫ్రేమ్‌లను వదిలివేసి, బ్యాక్‌ట్రేస్ యొక్క వాస్తవ ప్రారంభం అని మేము నమ్ముతున్న సూచిక.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// బ్యాక్‌ట్రేస్‌లో ఫ్రేమ్ యొక్క సంగ్రహించిన సంస్కరణ.
///
/// ఈ రకం `Backtrace::frames` నుండి జాబితాగా తిరిగి ఇవ్వబడుతుంది మరియు సంగ్రహించిన బ్యాక్‌ట్రేస్‌లో ఒక స్టాక్ ఫ్రేమ్‌ను సూచిస్తుంది.
///
/// # అవసరమైన లక్షణాలు
///
/// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// బ్యాక్‌ట్రేస్‌లో గుర్తు యొక్క సంగ్రహించిన సంస్కరణ.
///
/// ఈ రకం `BacktraceFrame::symbols` నుండి జాబితాగా తిరిగి ఇవ్వబడుతుంది మరియు బ్యాక్‌ట్రేస్‌లోని చిహ్నం కోసం మెటాడేటాను సూచిస్తుంది.
///
/// # అవసరమైన లక్షణాలు
///
/// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// ఈ ఫంక్షన్ యొక్క కాల్‌సైట్ వద్ద బ్యాక్‌ట్రేస్‌ను సంగ్రహిస్తుంది, యాజమాన్యంలోని ప్రాతినిధ్యాన్ని అందిస్తుంది.
    ///
    /// Rust లో బ్యాక్‌ట్రేస్‌ను ఒక వస్తువుగా సూచించడానికి ఈ ఫంక్షన్ ఉపయోగపడుతుంది.ఈ తిరిగి వచ్చిన విలువను థ్రెడ్‌లలో పంపవచ్చు మరియు మరెక్కడా ముద్రించవచ్చు మరియు ఈ విలువ యొక్క ఉద్దేశ్యం పూర్తిగా స్వీయ కలిగి ఉండాలి.
    ///
    /// కొన్ని ప్లాట్‌ఫామ్‌లలో పూర్తి బ్యాక్‌ట్రేస్‌ను సంపాదించి, దాన్ని పరిష్కరించడం చాలా ఖరీదైనదని గమనించండి.
    /// మీ అనువర్తనానికి ఖర్చు చాలా ఎక్కువగా ఉంటే, బదులుగా `Backtrace::new_unresolved()` ను ఉపయోగించమని సిఫార్సు చేయబడింది, ఇది గుర్తు రిజల్యూషన్ దశను తప్పిస్తుంది (ఇది సాధారణంగా ఎక్కువ సమయం పడుతుంది) మరియు తరువాత తేదీకి వాయిదా వేయడానికి అనుమతిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // తొలగించడానికి ఇక్కడ ఒక ఫ్రేమ్ ఉందని నిర్ధారించుకోవాలనుకుంటున్నాను
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new` మాదిరిగానే ఇది ఏ చిహ్నాలను పరిష్కరించదు తప్ప, ఇది బ్యాక్‌ట్రేస్‌ను చిరునామాల జాబితాగా సంగ్రహిస్తుంది.
    ///
    /// తరువాతి సమయంలో `resolve` ఫంక్షన్‌ను ఈ బ్యాక్‌ట్రేస్ చిహ్నాలను చదవగలిగే పేర్లలో పరిష్కరించడానికి పిలుస్తారు.
    /// ఈ ఫంక్షన్ ఉనికిలో ఉంది, ఎందుకంటే రిజల్యూషన్ ప్రాసెస్ కొన్నిసార్లు గణనీయమైన సమయాన్ని తీసుకుంటుంది, అయితే ఏదైనా ఒక బ్యాక్‌ట్రేస్ చాలా అరుదుగా ముద్రించబడుతుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // గుర్తు పేర్లు లేవు
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // గుర్తు పేర్లు ఇప్పుడు ఉన్నాయి
    /// ```
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    ///
    ///
    #[inline(never)] // తొలగించడానికి ఇక్కడ ఒక ఫ్రేమ్ ఉందని నిర్ధారించుకోవాలనుకుంటున్నాను
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// ఈ బ్యాక్‌ట్రేస్ సంగ్రహించబడినప్పటి నుండి ఫ్రేమ్‌లను అందిస్తుంది.
    ///
    /// ఈ స్లైస్ యొక్క మొదటి ఎంట్రీ ఫంక్షన్ `Backtrace::new`, మరియు చివరి ఫ్రేమ్ ఈ థ్రెడ్ లేదా ప్రధాన ఫంక్షన్ ఎలా ప్రారంభమైంది అనే దాని గురించి చెప్పవచ్చు.
    ///
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// ఈ బ్యాక్‌ట్రేస్ `new_unresolved` నుండి సృష్టించబడితే, ఈ ఫంక్షన్ బ్యాక్‌ట్రేస్‌లోని అన్ని చిరునామాలను వాటి సింబాలిక్ పేర్లకు పరిష్కరిస్తుంది.
    ///
    ///
    /// ఈ బ్యాక్‌ట్రేస్ గతంలో పరిష్కరించబడితే లేదా `new` ద్వారా సృష్టించబడితే, ఈ ఫంక్షన్ ఏమీ చేయదు.
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` వలె ఉంటుంది
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` వలె ఉంటుంది
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` వలె ఉంటుంది
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// ఈ ఫ్రేమ్‌కు అనుగుణమైన చిహ్నాల జాబితాను అందిస్తుంది.
    ///
    /// సాధారణంగా ప్రతి ఫ్రేమ్‌కు ఒక గుర్తు మాత్రమే ఉంటుంది, కానీ కొన్నిసార్లు అనేక ఫంక్షన్లు ఒక ఫ్రేమ్‌లోకి ఇన్లైన్ చేయబడితే బహుళ చిహ్నాలు తిరిగి ఇవ్వబడతాయి.
    /// జాబితా చేయబడిన మొదటి చిహ్నం "innermost function", చివరి చిహ్నం బయటిది (చివరి కాలర్).
    ///
    /// ఈ ఫ్రేమ్ పరిష్కరించబడని బ్యాక్‌ట్రేస్ నుండి వచ్చినట్లయితే ఇది ఖాళీ జాబితాను అందిస్తుంది.
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` వలె ఉంటుంది
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` వలె ఉంటుంది
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` వలె ఉంటుంది
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` వలె ఉంటుంది
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` వలె ఉంటుంది
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // మార్గాలను ముద్రించేటప్పుడు మేము cwd ఉన్నట్లయితే దాన్ని తొలగించడానికి ప్రయత్నిస్తాము, లేకుంటే మనం ఉన్న విధంగానే ప్రింట్ చేస్తాము.
        // మేము దీన్ని చిన్న ఫార్మాట్ కోసం మాత్రమే చేస్తామని గమనించండి, ఎందుకంటే అది నిండి ఉంటే మనం ప్రతిదీ ప్రింట్ చేయాలనుకుంటున్నాము.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}