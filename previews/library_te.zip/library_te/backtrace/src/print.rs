#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// బ్యాక్‌ట్రేస్‌ల కోసం ఒక ఫార్మాటర్.
///
/// బ్యాక్‌ట్రేస్ ఎక్కడ నుండి వచ్చినా బ్యాక్‌ట్రేస్‌ను ముద్రించడానికి ఈ రకాన్ని ఉపయోగించవచ్చు.
/// మీకు `Backtrace` రకం ఉంటే, దాని `Debug` అమలు ఇప్పటికే ఈ ప్రింటింగ్ ఆకృతిని ఉపయోగిస్తుంది.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// మేము ముద్రించగల ముద్రణ శైలులు
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// సంబంధిత సమాచారాన్ని మాత్రమే కలిగి ఉన్న టెర్సర్ బ్యాక్‌ట్రేస్‌ను ముద్రిస్తుంది
    Short,
    /// సాధ్యమయ్యే అన్ని సమాచారాన్ని కలిగి ఉన్న బ్యాక్‌ట్రేస్‌ను ప్రింట్ చేస్తుంది
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// క్రొత్త `BacktraceFmt` ను సృష్టించండి, ఇది అందించిన `fmt` కు అవుట్పుట్ను వ్రాస్తుంది.
    ///
    /// `format` ఆర్గ్యుమెంట్ బ్యాక్‌ట్రేస్ ముద్రించిన శైలిని నియంత్రిస్తుంది మరియు `print_path` ఆర్గ్యుమెంట్ ఫైల్ పేర్ల యొక్క `BytesOrWideString` ఉదంతాలను ముద్రించడానికి ఉపయోగించబడుతుంది.
    /// ఈ రకం ఫైల్ పేర్ల ముద్రణను చేయదు, కానీ అలా చేయడానికి ఈ బ్యాక్ అవసరం.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// బ్యాక్‌ట్రేస్ ముద్రించబోయే ముందుమాటను ముద్రిస్తుంది.
    ///
    /// బ్యాక్‌ట్రేస్‌లను తరువాత పూర్తిగా సింబాలిక్ చేయడానికి కొన్ని ప్లాట్‌ఫామ్‌లలో ఇది అవసరం, లేకపోతే ఇది `BacktraceFmt` ను సృష్టించిన తర్వాత మీరు పిలిచే మొదటి పద్ధతి.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// బ్యాక్‌ట్రేస్ అవుట్‌పుట్‌కు ఫ్రేమ్‌ను జోడిస్తుంది.
    ///
    /// ఈ నిబద్ధత `BacktraceFrameFmt` యొక్క RAII ఉదాహరణను తిరిగి ఇస్తుంది, ఇది వాస్తవానికి ఒక ఫ్రేమ్‌ను ముద్రించడానికి ఉపయోగించబడుతుంది మరియు విధ్వంసం చేసినప్పుడు ఇది ఫ్రేమ్ కౌంటర్‌ను పెంచుతుంది.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// బ్యాక్‌ట్రేస్ అవుట్‌పుట్‌ను పూర్తి చేస్తుంది.
    ///
    /// ఇది ప్రస్తుతం నో-ఆప్ అయితే బ్యాక్‌ట్రేస్ ఫార్మాట్‌లతో future అనుకూలత కోసం జోడించబడింది.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // future చేర్పులను అనుమతించడానికి ఈ hook తో సహా ప్రస్తుతం నో-ఆప్.
        Ok(())
    }
}

/// బ్యాక్‌ట్రేస్ యొక్క ఒక ఫ్రేమ్ కోసం ఫార్మాటర్.
///
/// ఈ రకం `BacktraceFmt::frame` ఫంక్షన్ ద్వారా సృష్టించబడుతుంది.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// ఈ ఫ్రేమ్ ఫార్మాటర్‌తో `BacktraceFrame` ను ప్రింట్ చేస్తుంది.
    ///
    /// ఇది `BacktraceFrame` లోని అన్ని `BacktraceSymbol` ఉదంతాలను పునరావృతంగా ముద్రిస్తుంది.
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceFrame` లోపల `BacktraceSymbol` ను ప్రింట్ చేస్తుంది.
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ఇది మనం ముద్రించటం గొప్పది కాదు
            // utf8 కాని ఫైల్ పేర్లతో.
            // కృతజ్ఞతగా దాదాపు ప్రతిదీ utf8 కాబట్టి ఇది చాలా చెడ్డది కాదు.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// ముడి ట్రేస్డ్ `Frame` మరియు `Symbol` ను ప్రింట్ చేస్తుంది, సాధారణంగా ఈ crate యొక్క ముడి కాల్‌బ్యాక్‌ల నుండి.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// బ్యాక్‌ట్రేస్ అవుట్‌పుట్‌కు ముడి ఫ్రేమ్‌ను జోడిస్తుంది.
    ///
    /// ఈ పద్ధతి మునుపటిలా కాకుండా, వారు వేర్వేరు ప్రదేశాల నుండి మూలంగా ఉన్నట్లయితే ముడి వాదనలు తీసుకుంటారు.
    /// ఒక ఫ్రేమ్ కోసం దీనిని చాలాసార్లు పిలుస్తారు.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// కాలమ్ సమాచారంతో సహా బ్యాక్‌ట్రేస్ అవుట్‌పుట్‌కు ముడి ఫ్రేమ్‌ను జోడిస్తుంది.
    ///
    /// ఈ పద్ధతి మునుపటి మాదిరిగానే ముడి వాదనలు వేర్వేరు ప్రదేశాల నుండి మూలంగా ఉన్నట్లయితే వాటిని తీసుకుంటుంది.
    /// ఒక ఫ్రేమ్ కోసం దీనిని చాలాసార్లు పిలుస్తారు.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // ఫుచ్సియా ఒక ప్రక్రియలో ప్రతీకగా ఉండలేకపోతుంది, కనుక ఇది ప్రత్యేక ఆకృతిని కలిగి ఉంది, ఇది తరువాత ప్రతీకగా ఉపయోగపడుతుంది.
        // చిరునామాలను మా స్వంత ఫార్మాట్‌లో ముద్రించడానికి బదులుగా ఇక్కడ ప్రింట్ చేయండి.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" ఫ్రేమ్‌లను ముద్రించాల్సిన అవసరం లేదు, దీని అర్థం ప్రాథమికంగా సిస్టమ్ బ్యాక్‌ట్రేస్ చాలా దూరం వెనుకకు వెళ్ళడానికి కొంచెం ఆసక్తిగా ఉందని అర్థం.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Sgx ఎన్క్లేవ్‌లో TCB పరిమాణాన్ని తగ్గించడానికి, సింబల్ రిజల్యూషన్ కార్యాచరణను అమలు చేయడానికి మేము ఇష్టపడము.
        // బదులుగా, మేము ఇక్కడ చిరునామా యొక్క ఆఫ్‌సెట్‌ను ప్రింట్ చేయవచ్చు, తరువాత ఫంక్షన్‌ను సరిచేయడానికి మ్యాప్ చేయవచ్చు.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // ఫ్రేమ్ యొక్క సూచికతో పాటు ఫ్రేమ్ యొక్క ఐచ్ఛిక సూచన పాయింటర్‌ను ముద్రించండి.
        // మేము ఈ ఫ్రేమ్ యొక్క మొదటి చిహ్నానికి మించి ఉంటే, తగిన వైట్‌స్పేస్‌ను ముద్రించాము.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // మేము పూర్తి బ్యాక్‌ట్రేస్ అయితే మరింత సమాచారం కోసం ప్రత్యామ్నాయ ఆకృతీకరణను ఉపయోగించి చిహ్నం పేరును వ్రాయండి.
        // ఇక్కడ మేము పేరు లేని చిహ్నాలను కూడా నిర్వహిస్తాము,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // చివరగా, అవి అందుబాటులో ఉంటే filename/line నంబర్‌ను ప్రింట్ చేయండి.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line గుర్తు పేరుతో పంక్తులలో ముద్రించబడతాయి, కాబట్టి మనల్ని కుడి-సమలేఖనం చేయడానికి తగిన ప్రదేశాలను ముద్రించండి.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // ఫైల్ పేరును ముద్రించడానికి మా అంతర్గత బ్యాక్‌బ్యాక్‌కు ప్రాతినిధ్యం వహించి, ఆపై పంక్తి సంఖ్యను ముద్రించండి.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // అందుబాటులో ఉంటే కాలమ్ సంఖ్యను జోడించండి.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // మేము ఫ్రేమ్ యొక్క మొదటి చిహ్నం గురించి మాత్రమే శ్రద్ధ వహిస్తాము
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}