//! Windows లో dbghelp బైండింగ్స్‌ను నిర్వహించడానికి సహాయపడే మాడ్యూల్
//!
//! Windows (కనీసం MSVC కోసం) లోని బ్యాక్‌ట్రేస్‌లు ఎక్కువగా `dbghelp.dll` మరియు దానిలోని వివిధ ఫంక్షన్ల ద్వారా శక్తిని పొందుతాయి.
//! ఈ విధులు ప్రస్తుతం `dbghelp.dll` కు స్థిరంగా లింక్ చేయకుండా *డైనమిక్‌గా* లోడ్ అవుతున్నాయి.
//! ఇది ప్రస్తుతం ప్రామాణిక లైబ్రరీ చేత చేయబడుతుంది (మరియు అక్కడ సిద్ధాంతంలో ఇది అవసరం), అయితే బ్యాక్‌ట్రేస్‌లు సాధారణంగా చాలా ఐచ్ఛికం కాబట్టి లైబ్రరీ యొక్క స్టాటిక్ డిఎల్ డిపెండెన్సీలను తగ్గించడంలో సహాయపడే ప్రయత్నం.
//!
//! ఇలా చెప్పుకుంటూ పోతే, `dbghelp.dll` దాదాపు ఎల్లప్పుడూ Windows లో విజయవంతంగా లోడ్ అవుతుంది.
//!
//! మేము ఈ మద్దతును డైనమిక్‌గా లోడ్ చేస్తున్నందున మనం వాస్తవానికి `winapi` లో ముడి నిర్వచనాలను ఉపయోగించలేము, అయితే ఫంక్షన్ పాయింటర్ రకాలను మనమే నిర్వచించి, దాన్ని ఉపయోగించాలి.
//! మేము నిజంగా వినాపీని నకిలీ చేసే వ్యాపారంలో ఉండటానికి ఇష్టపడము, కాబట్టి మనకు Cargo ఫీచర్ `verify-winapi` ఉంది, ఇది అన్ని బైండింగ్‌లు వినాపిలో ఉన్న వాటికి సరిపోలాయని మరియు ఈ లక్షణం CI లో ప్రారంభించబడిందని పేర్కొంది.
//!
//! చివరగా, `dbghelp.dll` కోసం dll ఎన్నడూ అన్‌లోడ్ చేయబడదని మీరు ఇక్కడ గమనించవచ్చు మరియు ఇది ప్రస్తుతం ఉద్దేశపూర్వకంగా ఉంది.
//! ఆలోచన ఏమిటంటే, మేము దీన్ని ప్రపంచవ్యాప్తంగా క్యాష్ చేయవచ్చు మరియు API కి కాల్‌ల మధ్య ఉపయోగించుకోవచ్చు, ఖరీదైన loads/unloads ని తప్పించవచ్చు.
//! ఇది లీక్ డిటెక్టర్లకు సమస్య అయితే లేదా అలాంటిదే మనం అక్కడికి చేరుకున్నప్పుడు వంతెనను దాటవచ్చు.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// `SymGetOptions` మరియు `SymSetOptions` చుట్టూ పని వినపిలోనే లేదు.
// లేకపోతే ఇది మేము వినోపికి వ్యతిరేకంగా రెండుసార్లు తనిఖీ చేస్తున్నప్పుడు మాత్రమే ఉపయోగించబడుతుంది.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // వినాపిలో ఇంకా నిర్వచించబడలేదు
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // ఇది వినాపిలో నిర్వచించబడింది, కానీ ఇది తప్పు (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // వినాపిలో ఇంకా నిర్వచించబడలేదు
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// ఈ మాక్రో ఒక `Dbghelp` నిర్మాణాన్ని నిర్వచించడానికి ఉపయోగించబడుతుంది, ఇది అంతర్గతంగా మనం లోడ్ చేయగల అన్ని ఫంక్షన్ పాయింటర్లను కలిగి ఉంటుంది.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll` కోసం లోడ్ చేయబడిన DLL
            dll: HMODULE,

            // మేము ఉపయోగించగల ప్రతి ఫంక్షన్ కోసం ప్రతి ఫంక్షన్ పాయింటర్
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // ప్రారంభంలో మేము DLL ని లోడ్ చేయలేదు
            dll: 0 as *mut _,
            // ప్రారంభంలో అన్ని విధులు డైనమిక్‌గా లోడ్ కావాలని చెప్పడానికి సున్నాకి సెట్ చేయబడతాయి.
            //
            $($name: 0,)*
        };

        // ప్రతి ఫంక్షన్ రకానికి సౌలభ్యం టైప్‌డెఫ్.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` తెరవడానికి ప్రయత్నాలు.
            /// `LoadLibraryW` విఫలమైతే అది పనిచేస్తే విజయం లేదా లోపం ఇస్తుంది.
            ///
            /// లైబ్రరీ ఇప్పటికే లోడ్ చేయబడి ఉంటే Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // మేము ఉపయోగించాలనుకుంటున్న ప్రతి పద్ధతికి ఫంక్షన్.
            // పిలిచినప్పుడు అది కాష్ చేసిన ఫంక్షన్ పాయింటర్‌ను చదువుతుంది లేదా లోడ్ చేస్తుంది మరియు లోడ్ చేసిన విలువను తిరిగి ఇస్తుంది.
            // లోడ్లు విజయవంతం కావాలని నొక్కిచెప్పారు.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp ఫంక్షన్లను సూచించడానికి క్లీనప్ లాక్‌లను ఉపయోగించడానికి అనుకూలమైన ప్రాక్సీ.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// ఈ crate నుండి `dbghelp` API ఫంక్షన్లను యాక్సెస్ చేయడానికి అవసరమైన అన్ని మద్దతును ప్రారంభించండి.
///
///
/// ఈ ఫంక్షన్ **సురక్షితం** అని గమనించండి, ఇది అంతర్గతంగా దాని స్వంత సమకాలీకరణను కలిగి ఉంటుంది.
/// ఈ ఫంక్షన్‌ను పలుసార్లు పునరావృతంగా పిలవడం సురక్షితం అని కూడా గమనించండి.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // ఈ ఫంక్షన్‌ను సమకాలీకరించడం మనం చేయవలసిన మొదటి విషయం.దీనిని ఇతర థ్రెడ్ల నుండి ఏకకాలంలో లేదా ఒక థ్రెడ్‌లో పునరావృతంగా పిలుస్తారు.
        // దాని కంటే ఇది చాలా ఉపాయమని గమనించండి ఎందుకంటే మనం ఇక్కడ ఉపయోగిస్తున్నది, `dbghelp`,*కూడా* ఈ ప్రక్రియలో అన్ని ఇతర కాలర్లతో `dbghelp` కు సమకాలీకరించాల్సిన అవసరం ఉంది.
        //
        // సాధారణంగా ఒకే ప్రక్రియలో `dbghelp` కి చాలా కాల్‌లు ఉండవు మరియు మేము మాత్రమే దీన్ని యాక్సెస్ చేస్తున్నామని సురక్షితంగా ass హించవచ్చు.
        // ఏదేమైనా, ఒక ప్రాధమిక ఇతర వినియోగదారుడు మనం ఆందోళన చెందాల్సిన అవసరం ఉంది, ఇది వ్యంగ్యంగా మనమే, కాని ప్రామాణిక లైబ్రరీలో.
        // Rust ప్రామాణిక లైబ్రరీ బ్యాక్‌ట్రేస్ మద్దతు కోసం ఈ crate పై ఆధారపడి ఉంటుంది మరియు ఈ crate కూడా crates.io లో ఉంది.
        // దీని అర్థం ప్రామాణిక లైబ్రరీ panic బ్యాక్‌ట్రేస్‌ను ప్రింట్ చేస్తుంటే, ఇది crates.io నుండి వచ్చే ఈ crate తో పందెం వేయవచ్చు, దీనివల్ల సెగ్‌ఫాల్ట్‌లు ఏర్పడతాయి.
        //
        // ఈ సమకాలీకరణ సమస్యను పరిష్కరించడంలో సహాయపడటానికి మేము ఇక్కడ విండోస్-నిర్దిష్ట ట్రిక్‌ను ఉపయోగిస్తాము (ఇది సమకాలీకరణ గురించి విండోస్-నిర్దిష్ట పరిమితి).
        // ఈ కాల్‌ను రక్షించడానికి మేము మ్యూటెక్స్ అనే *సెషన్-లోకల్* ను సృష్టిస్తాము.
        // ఇక్కడ ఉద్దేశ్యం ఏమిటంటే ప్రామాణిక లైబ్రరీ మరియు ఈ crate ఇక్కడ సమకాలీకరించడానికి Rust-స్థాయి API లను భాగస్వామ్యం చేయనవసరం లేదు, కానీ అవి ఒకదానితో ఒకటి సమకాలీకరిస్తున్నాయని నిర్ధారించుకోవడానికి తెర వెనుక పని చేయవచ్చు.
        //
        // ఈ ఫంక్షన్‌ను ప్రామాణిక లైబ్రరీ ద్వారా లేదా crates.io ద్వారా పిలిచినప్పుడు అదే మ్యూటెక్స్ సంపాదించబడుతుందని మనం అనుకోవచ్చు.
        //
        // కాబట్టి ఇవన్నీ ఏమిటంటే, మనం ఇక్కడ చేసే మొదటి పని ఏమిటంటే, Windows లో పేరున్న మ్యూటెక్స్ అయిన `HANDLE` ను అణుపరంగా సృష్టించాము.
        // ఈ ఫంక్షన్‌ను ప్రత్యేకంగా పంచుకునే ఇతర థ్రెడ్‌లతో మేము కొంచెం సమకాలీకరిస్తాము మరియు ఈ ఫంక్షన్ యొక్క ఉదాహరణకి ఒక హ్యాండిల్ మాత్రమే సృష్టించబడిందని నిర్ధారించుకోండి.
        // గ్లోబల్‌లో నిల్వ చేసిన తర్వాత హ్యాండిల్ ఎప్పుడూ మూసివేయబడదని గమనించండి.
        //
        // మేము నిజంగా లాక్‌కి వెళ్ళిన తర్వాత దాన్ని సంపాదించుకుంటాము మరియు చివరికి మేము దానిని వదిలివేసే బాధ్యత మా `Init` హ్యాండిల్‌కు ఉంటుంది.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // సరే, ఓహ్!ఇప్పుడు మనమందరం సురక్షితంగా సమకాలీకరించాము, వాస్తవానికి ప్రతిదీ ప్రాసెస్ చేయడం ప్రారంభిద్దాం.
        // మొదట ఈ ప్రక్రియలో `dbghelp.dll` వాస్తవానికి లోడ్ అయ్యిందని మేము నిర్ధారించుకోవాలి.
        // స్టాటిక్ డిపెండెన్సీని నివారించడానికి మేము దీన్ని డైనమిక్‌గా చేస్తాము.
        // ఇది చారిత్రాత్మకంగా విచిత్రమైన అనుసంధాన సమస్యల చుట్టూ పనిచేయడానికి జరిగింది మరియు ఇది బైనరీలను కొంచెం పోర్టబుల్ చేయడానికి ఉద్దేశించబడింది, ఎందుకంటే ఇది చాలావరకు డీబగ్గింగ్ యుటిలిటీ.
        //
        //
        // మేము `dbghelp.dll` ను తెరిచిన తర్వాత దానిలో కొన్ని ప్రారంభ ఫంక్షన్లను పిలవాలి మరియు అది మరింత క్రింద వివరించబడింది.
        // మేము దీన్ని ఒక్కసారి మాత్రమే చేస్తాము, కాబట్టి మేము ఇంకా పూర్తి చేశామా లేదా అనేదానిని సూచించే గ్లోబల్ బూలియన్ వచ్చింది.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` ఫ్లాగ్ సెట్ చేయబడిందని నిర్ధారించుకోండి, ఎందుకంటే దీని గురించి MSVC యొక్క సొంత డాక్స్ ప్రకారం: "This is the fastest, most efficient way to use the symbol handler.", కాబట్టి అలా చేద్దాం!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // వాస్తవానికి MSVC తో చిహ్నాలను ప్రారంభించండి.ఇది విఫలమవుతుందని గమనించండి, కాని మేము దానిని విస్మరిస్తాము.
        // దీనికి ప్రతి టన్ను ముందస్తు కళ లేదు, కానీ ఎల్‌ఎల్‌విఎం అంతర్గతంగా ఇక్కడ తిరిగి వచ్చే విలువను విస్మరించినట్లు అనిపిస్తుంది మరియు ఎల్‌ఎల్‌విఎమ్‌లోని శానిటైజర్ లైబ్రరీలలో ఒకటి విఫలమైతే భయానక హెచ్చరికను ముద్రిస్తుంది, అయితే ఇది దీర్ఘకాలంలో విస్మరిస్తుంది.
        //
        //
        // Rust కోసం ఇది చాలా వరకు వస్తుంది, ప్రామాణిక లైబ్రరీ మరియు crates.io లోని ఈ crate రెండూ `SymInitializeW` కోసం పోటీపడాలని కోరుకుంటాయి.
        // ప్రామాణిక లైబ్రరీ చారిత్రాత్మకంగా ఎక్కువ సమయం శుభ్రపరచాలని కోరుకుంది, కానీ ఇప్పుడు అది ఈ crate ను ఉపయోగిస్తున్నందున ఎవరైనా మొదట ప్రారంభానికి వస్తారని మరియు మరొకరు ఆ ప్రారంభాన్ని ఎంచుకుంటారని అర్థం.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}