use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr ఒక బ్యాక్‌బ్యాక్ తీసుకుంటుంది, ఇది ప్రక్రియలో అనుసంధానించబడిన ప్రతి DSO కోసం dl_phdr_info పాయింటర్‌ను అందుకుంటుంది.
    // dl_iterate_phdr డైనమిక్ లింకర్ పునరావృతం ప్రారంభం నుండి ముగింపు వరకు లాక్ చేయబడిందని నిర్ధారిస్తుంది.
    // బ్యాక్ బ్యాక్ సున్నా కాని విలువను తిరిగి ఇస్తే, పునరావృతం ప్రారంభంలోనే ముగుస్తుంది.
    // 'data' ప్రతి కాల్‌లోని బ్యాక్‌బ్యాక్‌కు మూడవ వాదనగా పంపబడుతుంది.
    // 'size' dl_phdr_info యొక్క పరిమాణాన్ని ఇస్తుంది.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// మేము బిల్డ్ ఐడి మరియు కొన్ని ప్రాథమిక ప్రోగ్రామ్ హెడర్ డేటాను అన్వయించాల్సిన అవసరం ఉంది, అంటే మనకు ELF స్పెక్ నుండి కొంచెం అంశాలు అవసరం.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// ఇప్పుడు మనం ఫుచ్సియా యొక్క ప్రస్తుత డైనమిక్ లింకర్ ఉపయోగించే dl_phdr_info రకం యొక్క నిర్మాణాన్ని ప్రతిబింబించాలి.
// క్రోమియంలో ఈ ఎబిఐ సరిహద్దుతో పాటు క్రాష్‌ప్యాడ్ కూడా ఉంది.
// చివరికి మేము ఈ కేసులను elf-search ను ఉపయోగించాలనుకుంటున్నాము, కాని మేము దానిని SDK లో అందించాలి మరియు అది ఇంకా పూర్తి కాలేదు.
//
// అందువల్ల మేము (మరియు వారు) ఈ పద్ధతిని ఉపయోగించాల్సిన అవసరం ఉంది, ఇది ఫుచ్సియా లిబ్‌సితో గట్టిగా కలపడం జరుగుతుంది.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // E_phoff మరియు e_phnum చెల్లుబాటు అవుతుందో లేదో తెలుసుకోవడానికి మాకు మార్గం లేదు.
    // అయితే లిబ్‌సి దీన్ని మాకు నిర్ధారించాలి కాబట్టి ఇక్కడ స్లైస్‌ని ఏర్పాటు చేయడం సురక్షితం.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// లక్ష్య నిర్మాణం యొక్క ముగింపులో Elf_Phdr 64-బిట్ ELF ప్రోగ్రామ్ హెడర్‌ను సూచిస్తుంది.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr చెల్లుబాటు అయ్యే ELF ప్రోగ్రామ్ హెడర్ మరియు దాని విషయాలను సూచిస్తుంది.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // P_addr లేదా p_memsz చెల్లుబాటు అవుతుందో లేదో తనిఖీ చేయడానికి మాకు మార్గం లేదు.
    // ఫుచ్సియా యొక్క లిబ్సి మొదట గమనికలను అన్వయించింది, అయితే ఇక్కడ ఉండటం వల్ల ఈ శీర్షికలు చెల్లుబాటులో ఉండాలి.
    //
    // నోట్‌ఇటర్‌కు అంతర్లీన డేటా చెల్లుబాటు అయ్యే అవసరం లేదు, కానీ దానికి హద్దులు చెల్లుబాటు కావాలి.
    // ఇక్కడ మనకు ఇదే పరిస్థితి ఉందని లిబ్‌సి నిర్ధారిస్తుందని మేము విశ్వసిస్తున్నాము.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// బిల్డ్ ఐడిల కోసం గమనిక రకం.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr లక్ష్యం యొక్క ముగింపులో ELF గమనిక శీర్షికను సూచిస్తుంది.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// గమనిక ELF గమనికను సూచిస్తుంది (హెడర్ + విషయాలు).
// ఈ పేరు u8 స్లైస్‌గా మిగిలిపోయింది ఎందుకంటే ఇది ఎల్లప్పుడూ శూన్యంగా ముగియదు మరియు rust బైట్‌లు ఏమైనా సరిపోతుందో లేదో తనిఖీ చేయడానికి సరిపోతుంది.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// నోట్ఇటర్ నోట్ విభాగంలో సురక్షితంగా మళ్ళించటానికి మిమ్మల్ని అనుమతిస్తుంది.
// లోపం సంభవించిన వెంటనే ఇది ముగుస్తుంది లేదా ఎక్కువ గమనికలు లేవు.
// మీరు చెల్లని డేటాపై మళ్ళిస్తే అది గమనికలు కనుగొనబడనట్లు పనిచేస్తుంది.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // ఇది ఫంక్షన్ యొక్క మార్పు, ఇచ్చిన పాయింటర్ మరియు పరిమాణం అన్నీ చదవగలిగే చెల్లుబాటు అయ్యే బైట్‌ల పరిధిని సూచిస్తాయి.
    // ఈ బైట్‌ల యొక్క విషయాలు ఏదైనా కావచ్చు, కానీ ఇది సురక్షితంగా ఉండటానికి పరిధి చెల్లుబాటులో ఉండాలి.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to 'x' ను 'to'-బైట్ అమరికకు సమలేఖనం చేస్తుంది 'to' 2 యొక్క శక్తి అని uming హిస్తుంది.
// ఇది C/C ++ ELF పార్సింగ్ కోడ్‌లో ప్రామాణిక నమూనాను అనుసరిస్తుంది (x + to, 1)&-to ఉపయోగించబడుతుంది.
// Rust మిమ్మల్ని ఉపయోగించడాన్ని తిరస్కరించడానికి అనుమతించదు కాబట్టి నేను ఉపయోగిస్తాను
// దానిని పున ate సృష్టి చేయడానికి 2 యొక్క పూరక మార్పిడి.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 స్లైస్ నుండి సంఖ్యా బైట్‌లను వినియోగిస్తుంది (ఉన్నట్లయితే) మరియు అదనంగా తుది స్లైస్ సరిగ్గా సమలేఖనం చేయబడిందని నిర్ధారిస్తుంది.
// ఒకవేళ అభ్యర్థించిన బైట్ల సంఖ్య చాలా పెద్దది లేదా తగినంత బైట్లు లేనందున స్లైస్ తరువాత గుర్తించలేకపోతే, ఏదీ తిరిగి ఇవ్వబడదు మరియు స్లైస్ సవరించబడదు.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// ఈ ఫంక్షన్‌కు 'bytes' పనితీరు కోసం సమలేఖనం చేయబడాలి (మరియు కొన్ని నిర్మాణాలపై సరైనది) కాకుండా కాలర్ తప్పక సమర్థించాల్సిన అవసరం లేదు.
// Elf_Nhdr ఫీల్డ్‌లలోని విలువలు అర్ధంలేనివి కావచ్చు కాని ఈ ఫంక్షన్ అలాంటిదేమీ లేదని నిర్ధారిస్తుంది.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // తగినంత స్థలం ఉన్నంతవరకు ఇది సురక్షితం మరియు పైన పేర్కొన్న స్టేట్మెంట్లో ఇది సురక్షితం కాదని మేము ధృవీకరించాము.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Sice_of: : గమనించండి<Elf_Nhdr>() ఎల్లప్పుడూ 4-బైట్ సమలేఖనం చేయబడుతుంది.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // మేము చివరికి చేరుకున్నామో లేదో తనిఖీ చేయండి.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // మేము ఒక nhdr ను ప్రసారం చేస్తాము కాని ఫలిత నిర్మాణాన్ని జాగ్రత్తగా పరిశీలిస్తాము.
        // మేము నేమ్‌జ్ లేదా డెస్క్‌జ్‌ను విశ్వసించము మరియు రకం ఆధారంగా మేము అసురక్షిత నిర్ణయాలు తీసుకోము.
        //
        // కాబట్టి మనం పూర్తి చెత్తను బయటకు తీసినా మనం ఇంకా సురక్షితంగా ఉండాలి.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// ఒక విభాగం ఎక్జిక్యూటబుల్ అని సూచిస్తుంది.
const PERM_X: u32 = 0b00000001;
/// ఒక విభాగం వ్రాయదగినదని సూచిస్తుంది.
const PERM_W: u32 = 0b00000010;
/// ఒక విభాగం చదవగలిగేదని సూచిస్తుంది.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// రన్‌టైమ్‌లో ELF విభాగాన్ని సూచిస్తుంది.
struct Segment {
    /// ఈ విభాగం యొక్క విషయాల యొక్క రన్‌టైమ్ వర్చువల్ చిరునామాను ఇస్తుంది.
    addr: usize,
    /// ఈ విభాగం యొక్క విషయాల మెమరీ పరిమాణాన్ని ఇస్తుంది.
    size: usize,
    /// ఈ విభాగం యొక్క మాడ్యూల్ వర్చువల్ చిరునామాను ELF ఫైల్‌తో ఇస్తుంది.
    mod_rel_addr: usize,
    /// ELF ఫైల్‌లో కనిపించే అనుమతులను ఇస్తుంది.
    /// అయితే ఈ అనుమతులు తప్పనిసరిగా రన్‌టైమ్‌లో ఉన్న అనుమతులు కావు.
    flags: Perm,
}

/// DSO నుండి విభాగాలపై ఒక మళ్ళా అనుమతిస్తుంది.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO (డైనమిక్ షేర్డ్ ఆబ్జెక్ట్) ను సూచిస్తుంది.
/// ఈ రకం దాని స్వంత కాపీని తయారు చేయకుండా వాస్తవ DSO లో నిల్వ చేసిన డేటాను సూచిస్తుంది.
struct Dso<'a> {
    /// పేరు ఖాళీగా ఉన్నప్పటికీ, డైనమిక్ లింకర్ ఎల్లప్పుడూ మాకు ఒక పేరును ఇస్తుంది.
    /// ప్రధాన ఎక్జిక్యూటబుల్ విషయంలో ఈ పేరు ఖాళీగా ఉంటుంది.
    /// భాగస్వామ్య వస్తువు విషయంలో ఇది సోనామ్ అవుతుంది (DT_SONAME చూడండి).
    name: &'a str,
    /// ఫుచ్‌సియాలో వాస్తవంగా అన్ని బైనరీలు బిల్డ్ ఐడిలను కలిగి ఉన్నాయి కాని ఇది కఠినమైన అవసరం కాదు.
    /// బిల్డ్_ఐడి లేకపోతే DSO సమాచారాన్ని నిజమైన ELF ఫైల్‌తో సరిపోల్చడానికి మార్గం లేదు, కాబట్టి ప్రతి DSO కి ఇక్కడ ఒకటి ఉండాలి.
    ///
    /// బిల్డ్_ఐడి లేని DSO లు విస్మరించబడతాయి.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// ఈ DSO లోని విభాగాలపై ఇటరేటర్‌ను అందిస్తుంది.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// ఈ లోపాలు ప్రతి DSO గురించి సమాచారాన్ని అన్వయించేటప్పుడు తలెత్తే సమస్యలను ఎన్కోడ్ చేస్తాయి.
///
enum Error {
    /// నేమ్‌ఎర్రర్ అంటే సి స్టైల్ స్ట్రింగ్‌ను rust స్ట్రింగ్‌గా మార్చేటప్పుడు లోపం సంభవించింది.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError అంటే మేము బిల్డ్ ID ని కనుగొనలేదు.
    /// DSO కి బిల్డ్ ఐడి లేనందున లేదా బిల్డ్ ఐడిని కలిగి ఉన్న సెగ్మెంట్ తప్పుగా ఉన్నందున దీనికి కారణం కావచ్చు.
    ///
    BuildIDError,
}

/// డైనమిక్ లింకర్ చేత ప్రాసెస్ చేయబడిన ప్రతి DSO కోసం 'dso' లేదా 'error' కాల్స్.
///
///
/// # Arguments
///
/// * `visitor` - ఫోర్సాచ్ DSO అని పిలువబడే ఈట్స్ పద్ధతుల్లో ఒకదాన్ని కలిగి ఉన్న DsoPrinter.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr info.name చెల్లుబాటు అయ్యే స్థానానికి సూచిస్తుందని నిర్ధారిస్తుంది.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// ఈ ఫంక్షన్ DSO లో ఉన్న అన్ని సమాచారం కోసం ఫుచ్సియా సింబలైజర్ మార్కప్‌ను ప్రింట్ చేస్తుంది.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}