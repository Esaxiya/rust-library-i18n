//! MSVC ప్లాట్‌ఫారమ్‌ల కోసం బ్యాక్‌ట్రేస్ వ్యూహం.
//!
//! ఈ మాడ్యూల్ రెండు సాధ్యం పద్ధతుల్లో ఒకదాన్ని ఉపయోగించి MSVC లో బ్యాక్‌ట్రేస్‌ను ఉత్పత్తి చేసే సామర్థ్యాన్ని కలిగి ఉంది.
//! `StackWalkEx` ఫంక్షన్ ప్రధానంగా వీలైతే ఉపయోగించబడుతుంది, కానీ అన్ని వ్యవస్థలు దానిని కలిగి ఉండవు.
//! బదులుగా `StackWalk64` ఫంక్షన్ ఉపయోగించడంలో విఫలమైంది.
//! `StackWalkEx` అనుకూలంగా ఉందని గమనించండి ఎందుకంటే ఇది డీబగ్ఇన్ఫోను అంతర్గతంగా నిర్వహిస్తుంది మరియు ఇన్లైన్ ఫ్రేమ్ సమాచారాన్ని అందిస్తుంది.
//!
//!
//! అన్ని dbghelp మద్దతు డైనమిక్‌గా లోడ్ అవుతుందని గమనించండి, దాని గురించి మరింత సమాచారం కోసం `src/dbghelp.rs` చూడండి.
//!

#![allow(bad_style)]

use super::super::{dbghelp, windows::*};
use core::ffi::c_void;
use core::mem;

#[derive(Clone, Copy)]
pub enum StackFrame {
    New(STACKFRAME_EX),
    Old(STACKFRAME64),
}

#[derive(Clone, Copy)]
pub struct Frame {
    pub(crate) stack_frame: StackFrame,
    base_address: *mut c_void,
}

// మేము ముడి పాయింటర్ల చుట్టూ పంపుతున్నాము మరియు వాటిని చదువుతున్నాము, వాటిని ఎప్పుడూ అర్థం చేసుకోలేము కాబట్టి ఇది థ్రెడ్‌లలో పంపడం మరియు పంచుకోవడం రెండింటికీ సురక్షితంగా ఉండాలి.
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        self.addr_pc().Offset as *mut _
    }

    pub fn sp(&self) -> *mut c_void {
        self.addr_stack().Offset as *mut _
    }

    pub fn symbol_address(&self) -> *mut c_void {
        self.ip()
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        Some(self.base_address)
    }

    fn addr_pc(&self) -> &ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref new) => &new.AddrPC,
            StackFrame::Old(ref old) => &old.AddrPC,
        }
    }

    fn addr_pc_mut(&mut self) -> &mut ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref mut new) => &mut new.AddrPC,
            StackFrame::Old(ref mut old) => &mut old.AddrPC,
        }
    }

    fn addr_frame_mut(&mut self) -> &mut ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref mut new) => &mut new.AddrFrame,
            StackFrame::Old(ref mut old) => &mut old.AddrFrame,
        }
    }

    fn addr_stack(&self) -> &ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref new) => &new.AddrStack,
            StackFrame::Old(ref old) => &old.AddrStack,
        }
    }

    fn addr_stack_mut(&mut self) -> &mut ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref mut new) => &mut new.AddrStack,
            StackFrame::Old(ref mut old) => &mut old.AddrStack,
        }
    }
}

#[repr(C, align(16))] // `CONTEXT` ద్వారా అవసరం, ప్రస్తుతం వినాపిలో ఒక FIXME
struct MyContext(CONTEXT);

#[inline(always)]
pub unsafe fn trace(cb: &mut dyn FnMut(&super::Frame) -> bool) {
    // స్టాక్ నడక చేయడానికి అవసరమైన నిర్మాణాలను కేటాయించండి
    let process = GetCurrentProcess();
    let thread = GetCurrentThread();

    let mut context = mem::zeroed::<MyContext>();
    RtlCaptureContext(&mut context.0);

    // ఈ ప్రక్రియ యొక్క చిహ్నాలు ప్రారంభించబడ్డాయని నిర్ధారించుకోండి
    let dbghelp = match dbghelp::init() {
        Ok(dbghelp) => dbghelp,
        Err(()) => return, // ఓహ్! మంచిది...
    };

    // x86_64 మరియు ARM64 లలో ఫంక్షన్ టేబుల్ మరియు మాడ్యూల్ బేస్ పొందడానికి dbghelp నుండి డిఫాల్ట్ `Sym*` ఫంక్షన్లను ఉపయోగించకూడదని మేము ఎంచుకుంటాము.
    // బదులుగా మేము kernel32 లో `RtlLookupFunctionEntry` ఫంక్షన్‌ను ఉపయోగిస్తాము, ఇది JIT కంపైలర్ ఫ్రేమ్‌లకు కూడా కారణమవుతుంది.
    // ఇవి సమానంగా ఉండాలి, కానీ `Rtl*` ను ఉపయోగించడం వలన JIT ఫ్రేమ్‌ల ద్వారా బ్యాక్‌ట్రేస్ చేయడానికి అనుమతిస్తుంది.
    //
    // `RtlLookupFunctionEntry` ప్రాసెస్‌లోని బ్యాక్‌ట్రేస్‌ల కోసం మాత్రమే పనిచేస్తుందని గమనించండి, అయితే మేము ఏమైనప్పటికీ మద్దతు ఇస్తాము, కాబట్టి ఇది అన్ని పంక్తులు బాగా పైకి ఉంటుంది.
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(target_pointer_width = "64")] {
            use core::ptr;

            unsafe extern "system" fn function_table_access(_process: HANDLE, addr: DWORD64) -> PVOID {
                let mut base = 0;
                RtlLookupFunctionEntry(addr, &mut base, ptr::null_mut()).cast()
            }

            unsafe extern "system" fn get_module_base(_process: HANDLE, addr: DWORD64) -> DWORD64 {
                let mut base = 0;
                RtlLookupFunctionEntry(addr, &mut base, ptr::null_mut());
                base
            }
        } else {
            let function_table_access = dbghelp.SymFunctionTableAccess64();
            let get_module_base = dbghelp.SymGetModuleBase64();
        }
    }

    let process_handle = GetCurrentProcess();

    // మనకు వీలైతే `StackWalkEx` ను ఉపయోగించుకునే ప్రయత్నం, కానీ `StackWalk64` కు తిరిగి వస్తాయి ఎందుకంటే ఇది సిద్ధాంతంలో ఎక్కువ సిస్టమ్‌లకు మద్దతు ఇస్తుంది.
    //
    match (*dbghelp.dbghelp()).StackWalkEx() {
        Some(StackWalkEx) => {
            let mut frame = super::Frame {
                inner: Frame {
                    stack_frame: StackFrame::New(mem::zeroed()),
                    base_address: 0 as _,
                },
            };
            let image = init_frame(&mut frame.inner, &context.0);
            let frame_ptr = match &mut frame.inner.stack_frame {
                StackFrame::New(ptr) => ptr as *mut STACKFRAME_EX,
                _ => unreachable!(),
            };

            while StackWalkEx(
                image as DWORD,
                process,
                thread,
                frame_ptr,
                &mut context.0 as *mut CONTEXT as *mut _,
                None,
                Some(function_table_access),
                Some(get_module_base),
                None,
                0,
            ) == TRUE
            {
                frame.inner.base_address = get_module_base(process_handle, frame.ip() as _) as _;

                if !cb(&frame) {
                    break;
                }
            }
        }
        None => {
            let mut frame = super::Frame {
                inner: Frame {
                    stack_frame: StackFrame::Old(mem::zeroed()),
                    base_address: 0 as _,
                },
            };
            let image = init_frame(&mut frame.inner, &context.0);
            let frame_ptr = match &mut frame.inner.stack_frame {
                StackFrame::Old(ptr) => ptr as *mut STACKFRAME64,
                _ => unreachable!(),
            };

            while dbghelp.StackWalk64()(
                image as DWORD,
                process,
                thread,
                frame_ptr,
                &mut context.0 as *mut CONTEXT as *mut _,
                None,
                Some(function_table_access),
                Some(get_module_base),
                None,
            ) == TRUE
            {
                frame.inner.base_address = get_module_base(process_handle, frame.ip() as _) as _;

                if !cb(&frame) {
                    break;
                }
            }
        }
    }
}

#[cfg(target_arch = "x86_64")]
fn init_frame(frame: &mut Frame, ctx: &CONTEXT) -> WORD {
    frame.addr_pc_mut().Offset = ctx.Rip as u64;
    frame.addr_pc_mut().Mode = AddrModeFlat;
    frame.addr_stack_mut().Offset = ctx.Rsp as u64;
    frame.addr_stack_mut().Mode = AddrModeFlat;
    frame.addr_frame_mut().Offset = ctx.Rbp as u64;
    frame.addr_frame_mut().Mode = AddrModeFlat;

    IMAGE_FILE_MACHINE_AMD64
}

#[cfg(target_arch = "x86")]
fn init_frame(frame: &mut Frame, ctx: &CONTEXT) -> WORD {
    frame.addr_pc_mut().Offset = ctx.Eip as u64;
    frame.addr_pc_mut().Mode = AddrModeFlat;
    frame.addr_stack_mut().Offset = ctx.Esp as u64;
    frame.addr_stack_mut().Mode = AddrModeFlat;
    frame.addr_frame_mut().Offset = ctx.Ebp as u64;
    frame.addr_frame_mut().Mode = AddrModeFlat;

    IMAGE_FILE_MACHINE_I386
}

#[cfg(target_arch = "aarch64")]
fn init_frame(frame: &mut Frame, ctx: &CONTEXT) -> WORD {
    frame.addr_pc_mut().Offset = ctx.Pc as u64;
    frame.addr_pc_mut().Mode = AddrModeFlat;
    frame.addr_stack_mut().Offset = ctx.Sp as u64;
    frame.addr_stack_mut().Mode = AddrModeFlat;
    unsafe {
        frame.addr_frame_mut().Offset = ctx.u.s().Fp as u64;
    }
    frame.addr_frame_mut().Mode = AddrModeFlat;
    IMAGE_FILE_MACHINE_ARM64
}

#[cfg(target_arch = "arm")]
fn init_frame(frame: &mut Frame, ctx: &CONTEXT) -> WORD {
    frame.addr_pc_mut().Offset = ctx.Pc as u64;
    frame.addr_pc_mut().Mode = AddrModeFlat;
    frame.addr_stack_mut().Offset = ctx.Sp as u64;
    frame.addr_stack_mut().Mode = AddrModeFlat;
    unsafe {
        frame.addr_frame_mut().Offset = ctx.R11 as u64;
    }
    frame.addr_frame_mut().Mode = AddrModeFlat;
    IMAGE_FILE_MACHINE_ARMNT
}