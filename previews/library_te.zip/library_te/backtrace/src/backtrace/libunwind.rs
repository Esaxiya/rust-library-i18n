//! libunwind/gcc_s/etc API లను ఉపయోగించి బ్యాక్‌ట్రేస్ మద్దతు.
//!
//! ఈ మాడ్యూల్ లిబన్‌వైండ్-శైలి API లను ఉపయోగించి స్టాక్‌ను నిలిపివేసే సామర్థ్యాన్ని కలిగి ఉంటుంది.
//! లిబన్‌విండ్-లాంటి API యొక్క మొత్తం అమలులో ఉందని గమనించండి మరియు ఇది పిక్కీగా కాకుండా ఒకేసారి అన్నింటికీ అనుకూలంగా ఉండటానికి ప్రయత్నిస్తుంది.
//!
//!
//! లిబన్‌విండ్ API `_Unwind_Backtrace` చేత ఆధారితం మరియు బ్యాక్‌ట్రేస్‌ను ఉత్పత్తి చేయడంలో ఆచరణలో చాలా నమ్మదగినది.
//! ఇది ఎలా చేస్తుందో పూర్తిగా స్పష్టంగా లేదు (ఫ్రేమ్ పాయింటర్లు? ఇహ్_ఫ్రేమ్ సమాచారం? రెండూ?) కానీ ఇది పని చేస్తున్నట్లు అనిపిస్తుంది!
//!
//! ఈ మాడ్యూల్ యొక్క సంక్లిష్టత చాలావరకు లిబన్‌వైండ్ అమలులో వివిధ ప్లాట్‌ఫారమ్ తేడాలను నిర్వహిస్తుంది.
//! లేకపోతే ఇది లిబన్‌వైండ్ API లకు అందంగా సూటిగా ఉండే Rust బైండింగ్.
//!
//! ప్రస్తుతం అన్ని విండోస్ కాని ప్లాట్‌ఫారమ్‌ల కోసం ఇది డిఫాల్ట్ అన్‌వైండింగ్ API.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// ముడి లిబన్‌వైండ్ పాయింటర్‌తో ఇది ఎప్పుడైనా చదవడానికి మాత్రమే థ్రెడ్‌సేఫ్ పద్ధతిలో మాత్రమే ప్రాప్యత ఉండాలి, కాబట్టి ఇది `Sync`.
// `Clone` ద్వారా ఇతర థ్రెడ్‌లకు పంపేటప్పుడు మేము ఎల్లప్పుడూ ఇంటీరియర్ పాయింటర్లను నిలుపుకోని సంస్కరణకు మారుతాము, కాబట్టి మనం కూడా `Send` గా ఉండాలి.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // OSX `_Unwind_FindEnclosingFunction` లో ఒక పాయింటర్‌ను తిరిగి ఇస్తున్నట్లు అనిపిస్తుంది ... అస్పష్టంగా ఉన్నది.
        // ఏ కారణం చేతనైనా ఇది ఎల్లప్పుడూ పరివేష్టిత పని కాదు.
        // ఇక్కడ ఏమి జరుగుతుందో నాకు పూర్తిగా స్పష్టంగా లేదు, కాబట్టి ఇప్పుడే దీన్ని నిరాశాజనకంగా మార్చండి మరియు ఎల్లప్పుడూ ఐపిని తిరిగి ఇవ్వండి.
        //
        // ఈ నిబంధన కారణంగా `skip_inner_frames.rs` పరీక్ష OSX లో దాటవేయబడిందని గమనించండి మరియు ఇది పరిష్కరించబడితే సిద్ధాంతంలో పరీక్షను OSX లో అమలు చేయవచ్చు!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// బ్యాక్‌ట్రేస్‌ల కోసం ఉపయోగించే లైబ్రరీ ఇంటర్‌ఫేస్‌ను నిలిపివేయండి
///
/// ఇక్కడ కేవలం బైండింగ్‌లు ఉన్నందున డెడ్ కోడ్ అనుమతించబడుతుందని గమనించండి, iOS ఇవన్నీ ఉపయోగించదు కాని ఎక్కువ ప్లాట్‌ఫాం-నిర్దిష్ట కాన్ఫిగ్‌లను జోడించడం వల్ల కోడ్‌ను ఎక్కువగా కలుషితం చేస్తుంది
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // ARM EABI ద్వారా మాత్రమే ఉపయోగించబడుతుంది
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // IOS లో స్థానిక _అన్‌వైండ్_బ్యాక్‌ట్రేస్ లేదు
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0 నుండి అందుబాటులో ఉంది, మా ప్రయోజనం కోసం బాగా ఉండాలి
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // ఈ ఫంక్షన్ ఒక తప్పుడు పేరు: ఈ ఫ్రేమ్ యొక్క కానానికల్ ఫ్రేమ్ చిరునామాను (కాలర్ ఫ్రేమ్ యొక్క SP) పొందడం కంటే ఇది ఈ ఫ్రేమ్ యొక్క SP ని తిరిగి ఇస్తుంది.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x పక్షపాత CFA విలువను ఉపయోగిస్తుంది, కాబట్టి _Unwind_GetCFA పై ఆధారపడకుండా స్టాక్ పాయింటర్ రిజిస్టర్ (%r15) ను పొందడానికి _Unwind_GetGR ను ఉపయోగించాలి.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android మరియు చేతిలో, ఫంక్షన్ `_Unwind_GetIP` మరియు ఇతరుల సమూహం మాక్రోలు, కాబట్టి మేము మాక్రోల విస్తరణను కలిగి ఉన్న ఫంక్షన్లను నిర్వచించాము.
    //
    //
    // TODO: మీరు కనుగొనగలిగితే, ఈ మాక్రోలను నిర్వచించే హెడర్ ఫైల్‌కు లింక్ చేయండి.
    // (నేను, ఫిట్జ్‌జెన్, ఈ స్థూల విస్తరణలలో కొన్ని మొదట అరువు తెచ్చుకున్న హెడర్ ఫైల్‌ను కనుగొనలేకపోయాను.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 చేతిలో స్టాక్ పాయింటర్.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // ఈ ఫంక్షన్ Android లేదా ARM/Linux లో కూడా లేదు, కాబట్టి దీన్ని నో-ఆప్ చేయండి.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}