//! ప్లాట్‌ఫాం ఆధారిత రకాలు.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// స్ట్రింగ్ యొక్క వేదిక స్వతంత్ర ప్రాతినిధ్యం.
/// `std` ఎనేబుల్ చేయబడినప్పుడు పనిచేసేటప్పుడు `std` రకాలకు మార్పిడులను అందించే సౌలభ్యం పద్ధతులకు ఇది సిఫార్సు చేయబడింది.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// ఒక స్లైస్, సాధారణంగా Unix ప్లాట్‌ఫామ్‌లలో అందించబడుతుంది.
    Bytes(&'a [u8]),
    /// విస్తృత తీగలను సాధారణంగా Windows నుండి.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// లాసీ `Cow<str>` గా మారుతుంది, `Bytes` చెల్లుబాటు అయ్యే UTF-8 కాకపోతే లేదా `BytesOrWideString` `Wide` అయితే కేటాయిస్తుంది.
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// `BytesOrWideString` యొక్క `Path` ప్రాతినిధ్యాన్ని అందిస్తుంది.
    ///
    /// # అవసరమైన లక్షణాలు
    ///
    /// ఈ ఫంక్షన్‌కు `backtrace` crate యొక్క `std` ఫీచర్ ప్రారంభించబడాలి మరియు `std` ఫీచర్ అప్రమేయంగా ప్రారంభించబడుతుంది.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}