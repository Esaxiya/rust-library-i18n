# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust కోసం రన్‌టైమ్‌లో బ్యాక్‌ట్రేస్‌లను పొందటానికి లైబ్రరీ.
ఈ లైబ్రరీ పని చేయడానికి ప్రోగ్రామాటిక్ ఇంటర్‌ఫేస్‌ను అందించడం ద్వారా ప్రామాణిక లైబ్రరీ యొక్క మద్దతును మెరుగుపరచడం లక్ష్యంగా పెట్టుకుంది, అయితే ఇది ప్రస్తుత బ్యాక్‌ట్రేస్‌ను libstd యొక్క panics వంటి సులభంగా ముద్రించడానికి కూడా మద్దతు ఇస్తుంది.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

బ్యాక్‌ట్రేస్‌ను సంగ్రహించడానికి మరియు తరువాతి సమయం వరకు దానితో వ్యవహరించడాన్ని వాయిదా వేయడానికి, మీరు ఉన్నత-స్థాయి `Backtrace` రకాన్ని ఉపయోగించవచ్చు.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

అయితే, మీరు వాస్తవ ట్రేసింగ్ కార్యాచరణకు మరింత ముడి ప్రాప్యతను కోరుకుంటే, మీరు నేరుగా `trace` మరియు `resolve` ఫంక్షన్లను ఉపయోగించవచ్చు.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // ఈ సూచన పాయింటర్‌ను గుర్తు పేరుకు పరిష్కరించండి
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // తదుపరి ఫ్రేమ్‌కు వెళ్లండి
    });
}
```

# License

ఈ ప్రాజెక్ట్ రెండింటిలోనూ లైసెన్స్ పొందింది

 * Apache లైసెన్స్, వెర్షన్ 2.0, ([LICENSE-APACHE](LICENSE-APACHE) లేదా http://www.apache.org/licenses/LICENSE-2.0)
 * MIT లైసెన్స్ ([LICENSE-MIT](LICENSE-MIT) లేదా http://opensource.org/licenses/MIT)

మీ ఎంపిక వద్ద.

### Contribution

మీరు స్పష్టంగా పేర్కొనకపోతే, Apache-2.0 లైసెన్స్‌లో నిర్వచించిన విధంగా మీరు బ్యాక్‌ట్రేస్-rs లో చేర్చడానికి ఉద్దేశపూర్వకంగా సమర్పించిన ఏదైనా సహకారం అదనపు నిబంధనలు లేదా షరతులు లేకుండా పైన పేర్కొన్న విధంగా ద్వంద్వ లైసెన్స్ పొందబడుతుంది.







