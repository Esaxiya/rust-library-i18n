//! మిరి కోసం panics ను నిలిపివేయడం.
use alloc::boxed::Box;
use core::any::Any;

// మిరి ఇంజిన్ మన కోసం విడదీయడం ద్వారా ప్రచారం చేసే పేలోడ్ రకం.
// పాయింటర్-పరిమాణంగా ఉండాలి.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// నిలిపివేయడం ప్రారంభించడానికి మిరి అందించిన బాహ్య ఫంక్షన్.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // మేము `miri_start_panic` కి పంపే పేలోడ్ ఖచ్చితంగా దిగువ `cleanup` లో మనకు లభించే వాదన.
    // కాబట్టి పాయింటర్-పరిమాణంలో ఏదైనా పొందడానికి మేము దాన్ని ఒక్కసారి బాక్స్ చేస్తాము.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // అంతర్లీన `Box` ను తిరిగి పొందండి.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}