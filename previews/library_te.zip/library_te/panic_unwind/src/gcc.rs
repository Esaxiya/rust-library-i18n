//! libgcc/libunwind (కొన్ని రూపంలో) మద్దతుతో panics అమలు.
//!
//! మినహాయింపు నిర్వహణ మరియు స్టాక్ అన్‌వైండింగ్ నేపథ్యం కోసం దయచేసి "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) మరియు దాని నుండి లింక్ చేయబడిన పత్రాలను చూడండి.
//! ఇవి కూడా మంచి రీడ్‌లు:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## సంక్షిప్త సారాంశం
//!
//! మినహాయింపు నిర్వహణ రెండు దశల్లో జరుగుతుంది: శోధన దశ మరియు శుభ్రపరిచే దశ.
//!
//! రెండు దశలలో, అన్వైండర్ స్టాక్ ఫ్రేమ్ నుండి సమాచారాన్ని ఉపయోగించి స్టాక్ ఫ్రేమ్‌లను పై నుండి క్రిందికి నడుస్తుంది ప్రస్తుత ప్రాసెస్ యొక్క మాడ్యూళ్ల విభాగాలను విడదీస్తుంది (ఇక్కడ "module" ఒక OS మాడ్యూల్‌ను సూచిస్తుంది, అనగా, ఎక్జిక్యూటబుల్ లేదా డైనమిక్ లైబ్రరీ).
//!
//!
//! ప్రతి స్టాక్ ఫ్రేమ్ కోసం, ఇది అనుబంధిత "personality routine" ను ప్రారంభిస్తుంది, దీని చిరునామా కూడా నిలిపివేసిన సమాచార విభాగంలో నిల్వ చేయబడుతుంది.
//!
//! శోధన దశలో, వ్యక్తిత్వ దినచర్య యొక్క పని ఏమిటంటే, మినహాయింపు వస్తువు విసిరివేయబడటం మరియు ఆ స్టాక్ ఫ్రేమ్‌లో పట్టుకోవాలో లేదో నిర్ణయించడం.హ్యాండ్లర్ ఫ్రేమ్ గుర్తించబడిన తర్వాత, శుభ్రపరిచే దశ ప్రారంభమవుతుంది.
//!
//! శుభ్రపరిచే దశలో, అన్‌వైండర్ ప్రతి వ్యక్తిత్వ దినచర్యను మళ్లీ ప్రారంభిస్తుంది.
//! ప్రస్తుత స్టాక్ ఫ్రేమ్ కోసం ఏ (ఏదైనా ఉంటే) క్లీనప్ కోడ్‌ను అమలు చేయాల్సిన అవసరం ఉందని ఈసారి నిర్ణయిస్తుంది.అలా అయితే, నియంత్రణ ఫంక్షన్ బాడీలోని ప్రత్యేక branch కు బదిలీ చేయబడుతుంది, ఇది "landing pad", ఇది డిస్ట్రక్టర్లను పిలుస్తుంది, మెమరీని విడుదల చేస్తుంది.
//! ల్యాండింగ్ ప్యాడ్ చివరిలో, నియంత్రణ అన్‌వైండర్ మరియు అన్‌వైండింగ్ రెజ్యూమెలకు తిరిగి బదిలీ చేయబడుతుంది.
//!
//! స్టాక్‌ను హ్యాండ్లర్ ఫ్రేమ్ స్థాయికి తగ్గించిన తర్వాత, నిలిపివేయడం ఆగిపోతుంది మరియు చివరి వ్యక్తిత్వ దినచర్య నియంత్రణను క్యాచ్ బ్లాక్‌కు బదిలీ చేస్తుంది.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust యొక్క మినహాయింపు తరగతి ఐడెంటిఫైయర్.
// మినహాయింపు వారి స్వంత రన్‌టైమ్ ద్వారా విసిరివేయబడిందో లేదో తెలుసుకోవడానికి ఇది వ్యక్తిత్వ దినచర్యల ద్వారా ఉపయోగించబడుతుంది.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-విక్రేత, భాష
    0x4d4f5a_00_52555354
}

// ప్రతి ఆర్కిటెక్చర్ కోసం LLVM యొక్క TargetLowering::getExceptionPointerRegister() మరియు TargetLowering::getExceptionSelectorRegister() నుండి రిజిస్టర్ ఐడిలు ఎత్తివేయబడ్డాయి, తరువాత రిజిస్టర్ డెఫినిషన్ టేబుల్స్ ద్వారా DWARF రిజిస్టర్ నంబర్లకు మ్యాప్ చేయబడ్డాయి (సాధారణంగా<arch>రిజిస్టర్ఇన్ఫో.టిడి, "DwarfRegNum" కోసం శోధించండి).
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register కూడా చూడండి.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// కింది కోడ్ GCC యొక్క C మరియు C++ వ్యక్తిత్వ నిత్యకృత్యాలపై ఆధారపడి ఉంటుంది.సూచన కోసం, చూడండి:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI వ్యక్తిత్వ దినచర్య.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS ఇది SjLj నిలిపివేయడాన్ని ఉపయోగిస్తున్నందున బదులుగా డిఫాల్ట్ దినచర్యను ఉపయోగిస్తుంది.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM లోని బ్యాక్‌ట్రేస్‌లు వ్యక్తిత్వ దినచర్యను స్థితి==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // ఆ సందర్భాలలో మేము స్టాక్‌ను నిలిపివేయడం కొనసాగించాలనుకుంటున్నాము, లేకపోతే మా బ్యాక్‌ట్రేస్‌లన్నీ __rust_try వద్ద ముగుస్తాయి
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // _Wnwind_Context ఫంక్షన్ మరియు LSDA పాయింటర్ల వంటి వాటిని కలిగి ఉందని DWARF అన్‌వైండర్ umes హిస్తుంది, అయితే ARM EHABI వాటిని మినహాయింపు వస్తువులో ఉంచుతుంది.
            // కాంటెక్స్ట్ పాయింటర్‌ను మాత్రమే తీసుకునే _Unwind_GetLanguageSpecificData() వంటి ఫంక్షన్ల సంతకాలను భద్రపరచడానికి, AR0 యొక్క "scratch register" (r12) కోసం రిజర్వు చేయబడిన స్థానాన్ని ఉపయోగించి, GCC వ్యక్తిత్వ నిత్యకృత్యాలు సందర్భానుసారం మినహాయింపు_ఆబ్జెక్ట్‌కు పాయింటర్‌ను నిలుస్తాయి.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... మరింత సూత్రప్రాయమైన విధానం ఏమిటంటే, మా లిబన్‌వైండ్ బైండింగ్స్‌లో ARM యొక్క _అన్‌వైండ్_కాంటెక్స్ట్ యొక్క పూర్తి నిర్వచనాన్ని అందించడం మరియు అవసరమైన డేటాను అక్కడి నుండి నేరుగా పొందడం, DWARF అనుకూలత విధులను దాటవేయడం.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // మినహాయింపు వస్తువు యొక్క అవరోధ కాష్‌లో SP విలువను నవీకరించడానికి EHABI కి వ్యక్తిత్వ దినచర్య అవసరం.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // ARM EHABI లో, తిరిగి రాకముందు ఒకే స్టాక్ ఫ్రేమ్‌ను విడదీయడానికి వ్యక్తిత్వ దినచర్య బాధ్యత వహిస్తుంది (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc లో నిర్వచించబడింది
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // డిఫాల్ట్ వ్యక్తిత్వ దినచర్య, ఇది చాలా లక్ష్యాలపై నేరుగా మరియు పరోక్షంగా SEH ద్వారా Windows x86_64 లో ఉపయోగించబడుతుంది.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW లక్ష్యాలలో, నిలిపివేసే విధానం SEH అయితే అన్‌వైండ్ హ్యాండ్లర్ డేటా (అకా LSDA) GCC-అనుకూల ఎన్‌కోడింగ్‌ను ఉపయోగిస్తుంది.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // మా లక్ష్యాలలో చాలా వరకు వ్యక్తిత్వ దినచర్య.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // రిటర్న్ అడ్రస్ కాల్ ఇన్స్ట్రక్షన్ గత 1 బైట్‌ను సూచిస్తుంది, ఇది ఎల్‌ఎస్‌డిఎ పరిధి పట్టికలోని తదుపరి ఐపి పరిధిలో ఉండవచ్చు.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// ఫ్రేమ్ సమాచారం నమోదును నిలిపివేయండి
//
// ప్రతి మాడ్యూల్ యొక్క చిత్రం ఫ్రేమ్ నిలిపివేసే సమాచార విభాగాన్ని కలిగి ఉంటుంది (సాధారణంగా ".eh_frame").మాడ్యూల్ ప్రాసెస్‌లోకి loaded/unloaded అయినప్పుడు, మెమరీలో ఈ విభాగం యొక్క స్థానం గురించి అన్‌వైండర్కు తెలియజేయాలి.దాన్ని సాధించే పద్ధతులు వేదిక ద్వారా మారుతూ ఉంటాయి.
// కొన్నింటిలో (ఉదా., Linux), విడదీయని సమాచారం విభాగాలను దాని స్వంతంగా కనుగొనవచ్చు (ప్రస్తుతం లోడ్ చేయబడిన మాడ్యూళ్ళను dl_iterate_phdr() API and finding their ".eh_frame" sections) ద్వారా డైనమిక్‌గా లెక్కించడం ద్వారా; Windows వంటి ఇతరులు, అన్‌వైండర్ API ద్వారా వారి నిలిపివేసిన సమాచార విభాగాలను చురుకుగా నమోదు చేయడానికి గుణకాలు అవసరం.
//
//
// ఈ మాడ్యూల్ GCC రన్‌టైమ్‌తో మా సమాచారాన్ని నమోదు చేయడానికి rsbegin.rs నుండి సూచించబడిన మరియు సూచించబడిన రెండు చిహ్నాలను నిర్వచిస్తుంది.
// స్టాక్ అన్‌వైండింగ్ యొక్క అమలు (ప్రస్తుతానికి) libgcc_eh కు వాయిదా వేయబడింది, అయితే Rust crates ఏదైనా GCC రన్‌టైమ్‌తో సంభావ్య ఘర్షణలను నివారించడానికి ఈ Rust-నిర్దిష్ట ఎంట్రీ పాయింట్లను ఉపయోగిస్తుంది.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}