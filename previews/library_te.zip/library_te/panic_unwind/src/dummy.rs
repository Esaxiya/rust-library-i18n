//! *Wasm32* లక్ష్యం కోసం నిలిపివేయడం.
//!
//! ప్రస్తుతం మేము దీనికి మద్దతు ఇవ్వము, కాబట్టి ఇది కేవలం స్టబ్స్.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}