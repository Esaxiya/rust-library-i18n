//! *Emscripten* లక్ష్యం కోసం నిలిపివేయడం.
//!
//! Unix ప్లాట్‌ఫారమ్‌ల కోసం Rust యొక్క సాధారణ అన్‌వైండింగ్ అమలు నేరుగా లిబన్‌వైండ్ API లకు పిలుస్తుంది, ఎమ్స్క్రిప్టెన్‌లో మేము బదులుగా C++ అన్‌వైండింగ్ API లలో పిలుస్తాము.
//! ఎమ్స్‌స్క్రిప్టెన్ యొక్క రన్‌టైమ్ ఎల్లప్పుడూ ఆ API లను అమలు చేస్తుంది మరియు లిబన్‌వైండ్‌ను అమలు చేయనందున ఇది కేవలం ఒక ప్రయోజనం మాత్రమే.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// ఇది C++ లోని std::type_info యొక్క లేఅవుట్‌తో సరిపోతుంది
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // ఇక్కడ ప్రముఖ `\x01` బైట్ వాస్తవానికి LLVM కు ఒక మాయా సంకేతం, ఇది `_` అక్షరంతో ఉపసర్గ వంటి ఇతర మంగ్లింగ్‌ను వర్తించదు.
    //
    //
    // ఈ చిహ్నం C++ యొక్క `std::type_info` ఉపయోగించే vtable.
    // రకం `std::type_info` యొక్క వస్తువులు, రకం వివరణలు, ఈ పట్టికకు పాయింటర్ కలిగి ఉంటాయి.
    // టైప్ డిస్క్రిప్టర్లను పైన నిర్వచించిన C++ EH నిర్మాణాల ద్వారా సూచిస్తారు మరియు మేము క్రింద నిర్మిస్తాము.
    //
    // నిజమైన పరిమాణం 3 వినియోగం కంటే పెద్దదని గమనించండి, కాని మూడవ మూలకానికి సూచించడానికి మన vtable మాత్రమే అవసరం.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info రస్ట్_పానిక్ క్లాస్ కోసం
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // సాధారణంగా మేము .as_ptr().add(2) ను ఉపయోగిస్తాము కాని ఇది స్థిరమైన సందర్భంలో పనిచేయదు.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // ఇది ఉద్దేశపూర్వకంగా సాధారణ పేరు మాంగ్లింగ్ పథకాన్ని ఉపయోగించదు ఎందుకంటే C++ Rust panics ను ఉత్పత్తి చేయగలదు లేదా పట్టుకోగలదు.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // ఇది అవసరం ఎందుకంటే C++ కోడ్ మా అమలును std::exception_ptr తో సంగ్రహించి, దాన్ని అనేకసార్లు పున th పరిశీలించగలదు, బహుశా మరొక థ్రెడ్‌లో కూడా.
    //
    //
    caught: AtomicBool,

    // ఇది ఒక ఎంపికగా ఉండాలి ఎందుకంటే ఆబ్జెక్ట్ యొక్క జీవితకాలం C++ సెమాంటిక్స్ను అనుసరిస్తుంది: క్యాచ్_అన్‌వైండ్ బాక్స్‌ను మినహాయింపు నుండి తరలించినప్పుడు అది మినహాయింపు వస్తువును చెల్లుబాటు అయ్యే స్థితిలో వదిలివేయాలి ఎందుకంటే దాని డిస్ట్రక్టర్ ఇప్పటికీ __cxa_end_catch చేత పిలువబడుతుంది.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try వాస్తవానికి ఈ నిర్మాణానికి పాయింటర్ ఇస్తుంది.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // cleanup() ను panic కు అనుమతించనందున, మేము బదులుగా ఆపివేస్తాము.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}