//! DWARF-ఎన్కోడ్ చేసిన డేటా స్ట్రీమ్‌లను అన్వయించడం కోసం యుటిలిటీస్.
//! <http://www.dwarfstd.org>, DWARF-4 ప్రమాణం, విభాగం 7, "Data Representation" చూడండి
//!

// ఈ మాడ్యూల్ ప్రస్తుతానికి x86_64-pc-windows-gnu ద్వారా మాత్రమే ఉపయోగించబడుతుంది, కాని రిగ్రెషన్లను నివారించడానికి మేము దీన్ని ప్రతిచోటా కంపైల్ చేస్తున్నాము.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF స్ట్రీమ్‌లు ప్యాక్ చేయబడ్డాయి, కాబట్టి ఉదా., u32 తప్పనిసరిగా 4-బైట్ సరిహద్దులో సమలేఖనం చేయబడదు.
    // ఇది కఠినమైన అమరిక అవసరాలతో ప్లాట్‌ఫారమ్‌లలో సమస్యలను కలిగిస్తుంది.
    // "packed" struct లో డేటాను చుట్టడం ద్వారా, మేము "misalignment-safe" కోడ్‌ను రూపొందించమని బ్యాకెండ్‌కు చెబుతున్నాము.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128 మరియు SLEB128 ఎన్కోడింగ్‌లు సెక్షన్ 7.6, "Variable Length Data" లో నిర్వచించబడ్డాయి.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}