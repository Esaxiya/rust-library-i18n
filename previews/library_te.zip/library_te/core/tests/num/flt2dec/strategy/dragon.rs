use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // మిరి చాలా నెమ్మదిగా ఉంది
fn exact_sanity_test() {
    // ఈ పరీక్ష `exp2` లైబ్రరీ ఫంక్షన్ యొక్క కొన్ని కార్నర్-ఇష్ కేసు అని నేను can హించగలిగేదాన్ని నడుపుతున్నాను, మనం ఉపయోగిస్తున్న సి రన్‌టైమ్‌లో ఇది నిర్వచించబడింది.
    // VS 2013 లో లింక్ చేయబడినప్పుడు ఈ పరీక్ష విఫలమైనందున ఈ ఫంక్షన్‌కు బగ్ ఉంది, కాని VS 2015 తో పరీక్ష బాగా నడుస్తున్నందున బగ్ పరిష్కరించబడింది.
    //
    // బగ్ `exp2(-1057)` యొక్క రిటర్న్ విలువలో తేడా ఉన్నట్లు అనిపిస్తుంది, ఇక్కడ VS 2013 లో ఇది బిట్ నమూనా 0x2 తో డబుల్ మరియు VS 2015 లో 0x20000 ను అందిస్తుంది.
    //
    //
    // ప్రస్తుతానికి ఈ పరీక్షను MSVC లో పూర్తిగా విస్మరించండి, ఎందుకంటే ఇది వేరే చోట పరీక్షించబడింది మరియు ప్రతి ప్లాట్‌ఫాం యొక్క exp2 అమలును పరీక్షించడానికి మాకు అంతగా ఆసక్తి లేదు.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}