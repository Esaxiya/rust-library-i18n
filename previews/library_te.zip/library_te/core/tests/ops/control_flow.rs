use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // ఇది స్థిరమైన ఉపరితల వైశాల్యం కాదు, అయితే ఎల్‌ఎల్‌విఎం ఎల్లప్పుడూ దాని ప్రయోజనాన్ని పొందలేక పోయినప్పటికీ, వాటి మధ్య `?` చౌకగా ఉంచడానికి సహాయపడుతుంది.
    //
    // (పాపం ఫలితం మరియు ఎంపిక అస్థిరంగా ఉన్నాయి, కాబట్టి కంట్రోల్ఫ్లో రెండింటికీ సరిపోలలేదు.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}