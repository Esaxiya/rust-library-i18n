//! కంపైలర్ అంతర్గత.
//!
//! సంబంధిత నిర్వచనాలు `compiler/rustc_codegen_llvm/src/intrinsic.rs` లో ఉన్నాయి.
//! సంబంధిత కాన్స్ట్ అమలులు `compiler/rustc_mir/src/interpret/intrinsics.rs` లో ఉన్నాయి
//!
//! # కాన్స్ట్ అంతర్గత
//!
//! Note: అంతర్గత యొక్క స్థిరత్వానికి ఏవైనా మార్పులు భాషా బృందంతో చర్చించబడాలి.
//! ఇది స్థిరత్వం యొక్క స్థిరత్వంలో మార్పులను కలిగి ఉంటుంది.
//!
//! కంపైల్-టైమ్‌లో అంతర్గతంగా ఉపయోగపడేలా చేయడానికి, అమలును <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> నుండి `compiler/rustc_mir/src/interpret/intrinsics.rs` కు కాపీ చేసి, అంతర్గతంగా `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ను జోడించాలి.
//!
//!
//! `rustc_const_stable` లక్షణంతో `const fn` నుండి అంతర్గత ఉపయోగించబడుతుంటే, అంతర్గత లక్షణం `rustc_const_stable` కూడా ఉండాలి.
//! టి-లాంగ్ సంప్రదింపులు లేకుండా ఇటువంటి మార్పు చేయకూడదు, ఎందుకంటే ఇది కంపైలర్ మద్దతు లేకుండా యూజర్ కోడ్‌లో ప్రతిరూపం చేయలేని భాషలోకి ఒక లక్షణాన్ని బేక్ చేస్తుంది.
//!
//! # Volatiles
//!
//! అస్థిర అంతర్గతాలు I/O మెమరీపై పనిచేయడానికి ఉద్దేశించిన ఆపరేషన్లను అందిస్తాయి, ఇవి ఇతర అస్థిర అంతర్గతాలలో కంపైలర్ చేత క్రమాన్ని మార్చబడవని హామీ ఇవ్వబడింది.[[volatile]] లో LLVM డాక్యుమెంటేషన్ చూడండి.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! పరమాణు అంతర్గత యంత్ర పదాలపై సాధారణ అణు కార్యకలాపాలను అందిస్తుంది, బహుళ మెమరీ ఆర్డరింగ్‌లతో.వారు C++ 11 వలె అదే అర్థాలను పాటిస్తారు.[[atomics]] లో LLVM డాక్యుమెంటేషన్ చూడండి.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! మెమరీ ఆర్డరింగ్‌పై శీఘ్ర రిఫ్రెషర్:
//!
//! * స్వాధీనం చేసుకోండి, తాళాన్ని సంపాదించడానికి అవరోధం.తదుపరి చదవడం మరియు వ్రాయడం అవరోధం తరువాత జరుగుతుంది.
//! * విడుదల, తాళాన్ని విడుదల చేయడానికి అవరోధం.ముందు చదవడం మరియు వ్రాయడం అవరోధం ముందు జరుగుతుంది.
//! * వరుసగా స్థిరంగా, వరుసగా స్థిరమైన కార్యకలాపాలు క్రమంలో జరుగుతాయని హామీ ఇవ్వబడింది.ఇది అణు రకాలతో పనిచేయడానికి ప్రామాణిక మోడ్ మరియు ఇది Java యొక్క `volatile` కు సమానం.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// ఇంట్రా-డాక్ లింక్‌లను సరళీకృతం చేయడానికి ఈ దిగుమతులు ఉపయోగించబడతాయి
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // భద్రత: `ptr::drop_in_place` చూడండి
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, ఈ అంతర్గత ముడి పాయింటర్లను తీసుకుంటుంది ఎందుకంటే అవి మారుపేరు మెమరీని మారుస్తాయి, ఇది `&` లేదా `&mut` లకు చెల్లుబాటు కాదు.
    //

    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `success` మరియు `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    ///
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `success` మరియు `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    ///
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange` పద్ధతి ద్వారా [`Ordering::Release`] ను `success` గా మరియు [`Ordering::Relaxed`] ను `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `success` గా మరియు [`Ordering::Acquire`] ను `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `success` మరియు `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    ///
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `success` గా మరియు [`Ordering::Relaxed`] ను `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `success` గా మరియు [`Ordering::Acquire`] ను `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `success` గా మరియు [`Ordering::Relaxed`] ను `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `success` గా మరియు [`Ordering::Relaxed`] ను `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange_weak` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `success` మరియు `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    ///
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange_weak` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `success` మరియు `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    ///
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange_weak` పద్ధతి ద్వారా [`Ordering::Release`] ను `success` గా మరియు [`Ordering::Relaxed`] ను `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange_weak` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `success` గా మరియు [`Ordering::Acquire`] ను `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// [`Ordering::Relaxed`] ను `success` మరియు `failure` పారామితులు రెండింటిలోనూ [`Ordering::Relaxed`] ను దాటడం ద్వారా `compare_exchange_weak` పద్ధతి ద్వారా [`atomic`] రకాల్లో [`atomic`] రకాల్లో లభిస్తుంది.
    ///
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange_weak` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `success` గా మరియు [`Ordering::Relaxed`] ను `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange_weak` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `success` గా మరియు [`Ordering::Acquire`] ను `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange_weak` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `success` గా మరియు [`Ordering::Relaxed`] ను `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// ప్రస్తుత విలువ `old` విలువకు సమానంగా ఉంటే విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `compare_exchange_weak` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `success` గా మరియు [`Ordering::Relaxed`] ను `failure` పారామితులుగా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// పాయింటర్ యొక్క ప్రస్తుత విలువను లోడ్ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `load` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// పాయింటర్ యొక్క ప్రస్తుత విలువను లోడ్ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `load` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// పాయింటర్ యొక్క ప్రస్తుత విలువను లోడ్ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `load` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// పేర్కొన్న మెమరీ స్థానంలో విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `store` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// పేర్కొన్న మెమరీ స్థానంలో విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `store` పద్ధతి ద్వారా [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// పేర్కొన్న మెమరీ స్థానంలో విలువను నిల్వ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `store` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// పేర్కొన్న విలువను మెమరీ స్థానంలో నిల్వ చేసి, పాత విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `swap` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// పేర్కొన్న విలువను మెమరీ స్థానంలో నిల్వ చేసి, పాత విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `swap` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// పేర్కొన్న విలువను మెమరీ స్థానంలో నిల్వ చేసి, పాత విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `swap` పద్ధతి ద్వారా [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// పేర్కొన్న విలువను మెమరీ స్థానంలో నిల్వ చేసి, పాత విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `swap` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// పేర్కొన్న విలువను మెమరీ స్థానంలో నిల్వ చేసి, పాత విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `swap` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// మునుపటి విలువను తిరిగి ఇచ్చి ప్రస్తుత విలువకు జోడిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_add` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// మునుపటి విలువను తిరిగి ఇచ్చి ప్రస్తుత విలువకు జోడిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_add` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// మునుపటి విలువను తిరిగి ఇచ్చి ప్రస్తుత విలువకు జోడిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_add` పద్ధతి ద్వారా [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// మునుపటి విలువను తిరిగి ఇచ్చి ప్రస్తుత విలువకు జోడిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_add` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// మునుపటి విలువను తిరిగి ఇచ్చి ప్రస్తుత విలువకు జోడిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_add` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// మునుపటి విలువను తిరిగి ఇచ్చి ప్రస్తుత విలువ నుండి తీసివేయండి.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_sub` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// మునుపటి విలువను తిరిగి ఇచ్చి ప్రస్తుత విలువ నుండి తీసివేయండి.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_sub` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// మునుపటి విలువను తిరిగి ఇచ్చి ప్రస్తుత విలువ నుండి తీసివేయండి.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_sub` పద్ధతి ద్వారా [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// మునుపటి విలువను తిరిగి ఇచ్చి ప్రస్తుత విలువ నుండి తీసివేయండి.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_sub` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// మునుపటి విలువను తిరిగి ఇచ్చి ప్రస్తుత విలువ నుండి తీసివేయండి.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_sub` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// బిట్వైస్ మరియు ప్రస్తుత విలువతో, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_and` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// బిట్వైస్ మరియు ప్రస్తుత విలువతో, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_and` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// బిట్వైస్ మరియు ప్రస్తుత విలువతో, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_and` పద్ధతి ద్వారా [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// బిట్వైస్ మరియు ప్రస్తుత విలువతో, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_and` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// బిట్వైస్ మరియు ప్రస్తుత విలువతో, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_and` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ప్రస్తుత విలువతో బిట్‌వైస్ నాండ్, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`AtomicBool`] రకంలో `fetch_nand` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// ప్రస్తుత విలువతో బిట్‌వైస్ నాండ్, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`AtomicBool`] రకంలో `fetch_nand` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ప్రస్తుత విలువతో బిట్‌వైస్ నాండ్, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`AtomicBool`] రకంలో `fetch_nand` పద్ధతి ద్వారా [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ప్రస్తుత విలువతో బిట్‌వైస్ నాండ్, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`AtomicBool`] రకంలో `fetch_nand` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ప్రస్తుత విలువతో బిట్‌వైస్ నాండ్, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`AtomicBool`] రకంలో `fetch_nand` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// బిట్వైస్ లేదా ప్రస్తుత విలువతో, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_or` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// బిట్వైస్ లేదా ప్రస్తుత విలువతో, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_or` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// బిట్వైస్ లేదా ప్రస్తుత విలువతో, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_or` పద్ధతి ద్వారా [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// బిట్వైస్ లేదా ప్రస్తుత విలువతో, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_or` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// బిట్వైస్ లేదా ప్రస్తుత విలువతో, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_or` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// ప్రస్తుత విలువతో బిట్‌వైస్ xor, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_xor` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// ప్రస్తుత విలువతో బిట్‌వైస్ xor, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_xor` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// ప్రస్తుత విలువతో బిట్‌వైస్ xor, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_xor` పద్ధతి ద్వారా [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ప్రస్తుత విలువతో బిట్‌వైస్ xor, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_xor` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ప్రస్తుత విలువతో బిట్‌వైస్ xor, మునుపటి విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] రకాల్లో `fetch_xor` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// సంతకం చేసిన పోలికను ఉపయోగించి ప్రస్తుత విలువతో గరిష్టంగా.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేసిన పూర్ణాంక రకాల్లో `fetch_max` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేసిన పోలికను ఉపయోగించి ప్రస్తుత విలువతో గరిష్టంగా.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేసిన పూర్ణాంక రకాల్లో `fetch_max` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేసిన పోలికను ఉపయోగించి ప్రస్తుత విలువతో గరిష్టంగా.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేసిన పూర్ణాంక రకాల్లో `fetch_max` పద్ధతి ద్వారా [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేసిన పోలికను ఉపయోగించి ప్రస్తుత విలువతో గరిష్టంగా.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేసిన పూర్ణాంక రకాల్లో `fetch_max` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// ప్రస్తుత విలువతో గరిష్టంగా.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేసిన పూర్ణాంక రకాల్లో `fetch_max` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// సంతకం చేసిన పోలికను ఉపయోగించి ప్రస్తుత విలువతో కనిష్టం.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేసిన పూర్ణాంక రకాల్లో `fetch_min` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేసిన పోలికను ఉపయోగించి ప్రస్తుత విలువతో కనిష్టం.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేసిన పూర్ణాంక రకాల్లో `fetch_min` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేసిన పోలికను ఉపయోగించి ప్రస్తుత విలువతో కనిష్టం.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేసిన పూర్ణాంక రకాల్లో `fetch_min` పద్ధతి ద్వారా [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేసిన పోలికను ఉపయోగించి ప్రస్తుత విలువతో కనిష్టం.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేసిన పూర్ణాంక రకాల్లో `fetch_min` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేసిన పోలికను ఉపయోగించి ప్రస్తుత విలువతో కనిష్టం.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేసిన పూర్ణాంక రకాల్లో `fetch_min` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// సంతకం చేయని పోలికను ఉపయోగించి ప్రస్తుత విలువతో కనిష్టం.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేయని పూర్ణాంక రకాల్లో `fetch_min` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేయని పోలికను ఉపయోగించి ప్రస్తుత విలువతో కనిష్టం.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేయని పూర్ణాంక రకాల్లో `fetch_min` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేయని పోలికను ఉపయోగించి ప్రస్తుత విలువతో కనిష్టం.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేయని పూర్ణాంక రకాల్లో `fetch_min` పద్ధతి ద్వారా [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేయని పోలికను ఉపయోగించి ప్రస్తుత విలువతో కనిష్టం.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేయని పూర్ణాంక రకాల్లో `fetch_min` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేయని పోలికను ఉపయోగించి ప్రస్తుత విలువతో కనిష్టం.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేయని పూర్ణాంక రకాల్లో `fetch_min` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// సంతకం చేయని పోలికను ఉపయోగించి ప్రస్తుత విలువతో గరిష్టంగా.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేయని పూర్ణాంక రకాల్లో `fetch_max` పద్ధతి ద్వారా [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేయని పోలికను ఉపయోగించి ప్రస్తుత విలువతో గరిష్టంగా.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేయని పూర్ణాంక రకాల్లో `fetch_max` పద్ధతి ద్వారా [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేయని పోలికను ఉపయోగించి ప్రస్తుత విలువతో గరిష్టంగా.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేయని పూర్ణాంక రకాల్లో `fetch_max` పద్ధతి ద్వారా [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేయని పోలికను ఉపయోగించి ప్రస్తుత విలువతో గరిష్టంగా.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేయని పూర్ణాంక రకాల్లో `fetch_max` పద్ధతి ద్వారా [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// సంతకం చేయని పోలికను ఉపయోగించి ప్రస్తుత విలువతో గరిష్టంగా.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`atomic`] సంతకం చేయని పూర్ణాంక రకాల్లో `fetch_max` పద్ధతి ద్వారా [`Ordering::Relaxed`] ను `order` గా పాస్ చేయడం ద్వారా లభిస్తుంది.
    /// ఉదాహరణకి, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` అంతర్గత అనేది మద్దతు ఉంటే ప్రీఫెట్ సూచనను చొప్పించడానికి కోడ్ జెనరేటర్‌కు సూచన;లేకపోతే, ఇది నో-ఆప్.
    /// ప్రోగ్రామ్ యొక్క ప్రవర్తనపై ప్రిఫెట్స్ ప్రభావం చూపవు కాని దాని పనితీరు లక్షణాలను మార్చగలవు.
    ///
    /// `locality` ఆర్గ్యుమెంట్ స్థిరమైన పూర్ణాంకం అయి ఉండాలి మరియు ఇది (0) నుండి, స్థానికత లేకుండా, (3) వరకు ఉన్న తాత్కాలిక లోకాలిటీ స్పెసిఫైయర్, చాలా స్థానికంగా కాష్‌లో ఉంచండి.
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` అంతర్గత అనేది మద్దతు ఉంటే ప్రీఫెట్ సూచనను చొప్పించడానికి కోడ్ జెనరేటర్‌కు సూచన;లేకపోతే, ఇది నో-ఆప్.
    /// ప్రోగ్రామ్ యొక్క ప్రవర్తనపై ప్రిఫెట్స్ ప్రభావం చూపవు కాని దాని పనితీరు లక్షణాలను మార్చగలవు.
    ///
    /// `locality` ఆర్గ్యుమెంట్ స్థిరమైన పూర్ణాంకం అయి ఉండాలి మరియు ఇది (0) నుండి, స్థానికత లేకుండా, (3) వరకు ఉన్న తాత్కాలిక లోకాలిటీ స్పెసిఫైయర్, చాలా స్థానికంగా కాష్‌లో ఉంచండి.
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` అంతర్గత అనేది మద్దతు ఉంటే ప్రీఫెట్ సూచనను చొప్పించడానికి కోడ్ జెనరేటర్‌కు సూచన;లేకపోతే, ఇది నో-ఆప్.
    /// ప్రోగ్రామ్ యొక్క ప్రవర్తనపై ప్రిఫెట్స్ ప్రభావం చూపవు కాని దాని పనితీరు లక్షణాలను మార్చగలవు.
    ///
    /// `locality` ఆర్గ్యుమెంట్ స్థిరమైన పూర్ణాంకం అయి ఉండాలి మరియు ఇది (0) నుండి, స్థానికత లేకుండా, (3) వరకు ఉన్న తాత్కాలిక లోకాలిటీ స్పెసిఫైయర్, చాలా స్థానికంగా కాష్‌లో ఉంచండి.
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` అంతర్గత అనేది మద్దతు ఉంటే ప్రీఫెట్ సూచనను చొప్పించడానికి కోడ్ జెనరేటర్‌కు సూచన;లేకపోతే, ఇది నో-ఆప్.
    /// ప్రోగ్రామ్ యొక్క ప్రవర్తనపై ప్రిఫెట్స్ ప్రభావం చూపవు కాని దాని పనితీరు లక్షణాలను మార్చగలవు.
    ///
    /// `locality` ఆర్గ్యుమెంట్ స్థిరమైన పూర్ణాంకం అయి ఉండాలి మరియు ఇది (0) నుండి, స్థానికత లేకుండా, (3) వరకు ఉన్న తాత్కాలిక లోకాలిటీ స్పెసిఫైయర్, చాలా స్థానికంగా కాష్‌లో ఉంచండి.
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// అణు కంచె.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా [`atomic::fence`] లో లభిస్తుంది.
    ///
    ///
    pub fn atomic_fence();
    /// అణు కంచె.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా [`atomic::fence`] లో లభిస్తుంది.
    ///
    ///
    pub fn atomic_fence_acq();
    /// అణు కంచె.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా [`atomic::fence`] లో లభిస్తుంది.
    ///
    ///
    pub fn atomic_fence_rel();
    /// అణు కంచె.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా [`atomic::fence`] లో లభిస్తుంది.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// కంపైలర్-మాత్రమే మెమరీ అవరోధం.
    ///
    /// కంపైలర్ ఈ అవరోధం అంతటా మెమరీ ప్రాప్యతలను క్రమాన్ని మార్చదు, కానీ దాని కోసం సూచనలు విడుదల చేయబడవు.
    /// సిగ్నల్ హ్యాండ్లర్లతో సంభాషించేటప్పుడు ముందస్తుగా నిర్ణయించబడే అదే థ్రెడ్‌లోని కార్యకలాపాలకు ఇది తగినది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`Ordering::SeqCst`] ను `order` గా పాస్ చేయడం ద్వారా [`atomic::compiler_fence`] లో లభిస్తుంది.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// కంపైలర్-మాత్రమే మెమరీ అవరోధం.
    ///
    /// కంపైలర్ ఈ అవరోధం అంతటా మెమరీ ప్రాప్యతలను క్రమాన్ని మార్చదు, కానీ దాని కోసం సూచనలు విడుదల చేయబడవు.
    /// సిగ్నల్ హ్యాండ్లర్లతో సంభాషించేటప్పుడు ముందస్తుగా నిర్ణయించబడే అదే థ్రెడ్‌లోని కార్యకలాపాలకు ఇది తగినది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`Ordering::Acquire`] ను `order` గా పాస్ చేయడం ద్వారా [`atomic::compiler_fence`] లో లభిస్తుంది.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// కంపైలర్-మాత్రమే మెమరీ అవరోధం.
    ///
    /// కంపైలర్ ఈ అవరోధం అంతటా మెమరీ ప్రాప్యతలను క్రమాన్ని మార్చదు, కానీ దాని కోసం సూచనలు విడుదల చేయబడవు.
    /// సిగ్నల్ హ్యాండ్లర్లతో సంభాషించేటప్పుడు ముందస్తుగా నిర్ణయించబడే అదే థ్రెడ్‌లోని కార్యకలాపాలకు ఇది తగినది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`Ordering::Release`] ను `order` గా పాస్ చేయడం ద్వారా [`atomic::compiler_fence`] లో లభిస్తుంది.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// కంపైలర్-మాత్రమే మెమరీ అవరోధం.
    ///
    /// కంపైలర్ ఈ అవరోధం అంతటా మెమరీ ప్రాప్యతలను క్రమాన్ని మార్చదు, కానీ దాని కోసం సూచనలు విడుదల చేయబడవు.
    /// సిగ్నల్ హ్యాండ్లర్లతో సంభాషించేటప్పుడు ముందస్తుగా నిర్ణయించబడే అదే థ్రెడ్‌లోని కార్యకలాపాలకు ఇది తగినది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ [`Ordering::AcqRel`] ను `order` గా పాస్ చేయడం ద్వారా [`atomic::compiler_fence`] లో లభిస్తుంది.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// ఫంక్షన్‌కు అనుసంధానించబడిన లక్షణాల నుండి దాని అర్ధాన్ని పొందిన మేజిక్ అంతర్గత.
    ///
    /// ఉదాహరణకు, స్టాటిక్ వాదనలను ఇంజెక్ట్ చేయడానికి డేటాఫ్లో దీనిని ఉపయోగిస్తుంది, తద్వారా `rustc_peek(potentially_uninitialized)` వాస్తవానికి డేటాఫ్లో నియంత్రణ ప్రవాహంలో ఆ సమయంలో ప్రారంభించబడలేదని లెక్కించినట్లు డబుల్-చెక్ చేస్తుంది.
    ///
    ///
    /// ఈ అంతర్గత కంపైలర్ వెలుపల ఉపయోగించరాదు.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// ప్రక్రియ అమలును ఆపివేస్తుంది.
    ///
    /// ఈ ఆపరేషన్ యొక్క మరింత యూజర్ ఫ్రెండ్లీ మరియు స్థిరమైన వెర్షన్ [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// కోడ్‌లోని ఈ పాయింట్‌ను చేరుకోలేమని ఆప్టిమైజర్‌కు తెలియజేస్తుంది, ఇది మరింత ఆప్టిమైజేషన్లను ప్రారంభిస్తుంది.
    ///
    /// NB, ఇది `unreachable!()` స్థూల నుండి చాలా భిన్నంగా ఉంటుంది: ఇది అమలు చేయబడినప్పుడు panics అయిన స్థూల మాదిరిగా కాకుండా, ఈ ఫంక్షన్‌తో గుర్తించబడిన కోడ్‌ను చేరుకోవడం *నిర్వచించబడని ప్రవర్తన*.
    ///
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// ఒక షరతు ఎల్లప్పుడూ నిజమని ఆప్టిమైజర్‌కు తెలియజేస్తుంది.
    /// పరిస్థితి తప్పు అయితే, ప్రవర్తన నిర్వచించబడదు.
    ///
    /// ఈ అంతర్గత కోసం కోడ్ ఏదీ ఉత్పత్తి చేయబడదు, కానీ ఆప్టిమైజర్ పాస్‌ల మధ్య దాన్ని (మరియు దాని పరిస్థితి) సంరక్షించడానికి ప్రయత్నిస్తుంది, ఇది పరిసర కోడ్ యొక్క ఆప్టిమైజేషన్‌కు ఆటంకం కలిగిస్తుంది మరియు పనితీరును తగ్గిస్తుంది.
    /// ఆప్టిమైజర్ చేత మార్పును సొంతంగా కనుగొనగలిగితే లేదా ఏదైనా ముఖ్యమైన ఆప్టిమైజేషన్లను ప్రారంభించకపోతే ఇది ఉపయోగించరాదు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// branch కండిషన్ నిజమని కంపైలర్‌కు సూచనలు.
    /// దానికి పంపిన విలువను చూపుతుంది.
    ///
    /// `if` స్టేట్‌మెంట్‌లతో కాకుండా ఏదైనా ఉపయోగం బహుశా ప్రభావం చూపదు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// branch పరిస్థితి తప్పు అని కంపైలర్‌కు సూచనలు.
    /// దానికి పంపిన విలువను చూపుతుంది.
    ///
    /// `if` స్టేట్‌మెంట్‌లతో కాకుండా ఏదైనా ఉపయోగం బహుశా ప్రభావం చూపదు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// డీబగ్గర్ తనిఖీ కోసం బ్రేక్ పాయింట్ ఉచ్చును అమలు చేస్తుంది.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn breakpoint();

    /// బైట్లలో ఒక రకం పరిమాణం.
    ///
    /// మరింత ప్రత్యేకంగా, అలైన్‌మెంట్ పాడింగ్‌తో సహా ఒకే రకమైన వరుస వస్తువుల మధ్య బైట్‌లలో ఇది ఆఫ్‌సెట్.
    ///
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// ఒక రకం కనీస అమరిక.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// ఒక రకం యొక్క ఇష్టపడే అమరిక.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// బైట్లలో సూచించబడిన విలువ యొక్క పరిమాణం.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// సూచించిన విలువ యొక్క అవసరమైన అమరిక.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// ఒక రకం పేరును కలిగి ఉన్న స్టాటిక్ స్ట్రింగ్ స్లైస్‌ని పొందుతుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// పేర్కొన్న రకానికి ప్రపంచవ్యాప్తంగా ప్రత్యేకమైన ఐడెంటిఫైయర్‌ను పొందుతుంది.
    /// ఈ ఫంక్షన్ ఏ రకమైన crate తో సంబంధం లేకుండా ఒక రకానికి అదే విలువను అందిస్తుంది.
    ///
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// `T` జనావాసాలు లేనట్లయితే ఎప్పటికీ అమలు చేయలేని అసురక్షిత ఫంక్షన్ల కోసం ఒక గార్డు:
    /// ఇది స్థిరంగా panic గాని, లేదా ఏమీ చేయదు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// `T` సున్నా-ప్రారంభాన్ని అనుమతించకపోతే ఎప్పటికీ అమలు చేయలేని అసురక్షిత ఫంక్షన్ల కోసం ఒక గార్డు: ఇది స్థిరంగా panic గాని, లేదా ఏమీ చేయదు.
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn assert_zero_valid<T>();

    /// `T` చెల్లని బిట్ నమూనాలను కలిగి ఉంటే ఎప్పటికీ అమలు చేయలేని అసురక్షిత ఫంక్షన్ల కోసం ఒక గార్డు: ఇది స్థిరంగా panic గాని, లేదా ఏమీ చేయదు.
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn assert_uninit_valid<T>();

    /// స్టాటిక్ `Location` ను ఎక్కడ పిలిచారో సూచించే సూచనను పొందుతుంది.
    ///
    /// బదులుగా [`core::panic::Location::caller`](crate::panic::Location::caller) ఉపయోగించడాన్ని పరిగణించండి.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// డ్రాప్ జిగురును అమలు చేయకుండా విలువను స్కోప్ నుండి కదిలిస్తుంది.
    ///
    /// ఇది [`mem::forget_unsized`] కోసం మాత్రమే ఉంది;సాధారణ `forget` బదులుగా `ManuallyDrop` ను ఉపయోగిస్తుంది.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// ఒక రకం విలువ యొక్క బిట్లను మరొక రకంగా తిరిగి అర్థం చేసుకుంటుంది.
    ///
    /// రెండు రకాలు ఒకే పరిమాణాన్ని కలిగి ఉండాలి.
    /// అసలు, లేదా ఫలితం [invalid value](../../nomicon/what-unsafe-does.html) కాకపోవచ్చు.
    ///
    /// `transmute` అర్థపరంగా ఒక రకాన్ని మరొక రకానికి తరలించడానికి సమానం.ఇది మూల విలువ నుండి బిట్‌లను గమ్యం విలువలోకి కాపీ చేస్తుంది, ఆపై అసలుదాన్ని మరచిపోతుంది.
    /// ఇది `transmute_copy` మాదిరిగానే హుడ్ కింద C యొక్క `memcpy` కు సమానం.
    ///
    /// `transmute` అనేది ఉప-విలువ ఆపరేషన్ అయినందున,*పరివర్తన చెందిన విలువలను అమర్చడం* ఆందోళన కలిగించదు.
    /// ఏ ఇతర ఫంక్షన్ మాదిరిగానే, కంపైలర్ ఇప్పటికే `T` మరియు `U` రెండూ సరిగ్గా సమలేఖనం చేయబడిందని నిర్ధారిస్తుంది.
    /// ఏదేమైనా, * మరెక్కడా సూచించే విలువలను (పాయింటర్లు, సూచనలు, పెట్టెలు…) ప్రసారం చేసేటప్పుడు, కాలర్ సూచించిన విలువలకు సరైన అమరికను నిర్ధారించాలి.
    ///
    /// `transmute` **చాలా** సురక్షితం కాదు.ఈ ఫంక్షన్‌తో [undefined behavior][ub] కి కారణమయ్యే అనేక మార్గాలు ఉన్నాయి.`transmute` సంపూర్ణ చివరి రిసార్ట్ అయి ఉండాలి.
    ///
    /// [nomicon](../../nomicon/transmutes.html) అదనపు డాక్యుమెంటేషన్ కలిగి ఉంది.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// `transmute` నిజంగా ఉపయోగపడే కొన్ని విషయాలు ఉన్నాయి.
    ///
    /// పాయింటర్‌ను ఫంక్షన్ పాయింటర్‌గా మార్చడం.ఫంక్షన్ పాయింటర్లు మరియు డేటా పాయింటర్లు వేర్వేరు పరిమాణాలను కలిగి ఉన్న యంత్రాలకు ఇది * పోర్టబుల్ కాదు.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// జీవితకాలం పొడిగించడం లేదా మార్పులేని జీవితకాలం తగ్గించడం.ఇది అధునాతనమైనది, చాలా అసురక్షితమైన Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// నిరాశ చెందకండి: `transmute` యొక్క అనేక ఉపయోగాలు ఇతర మార్గాల ద్వారా సాధించవచ్చు.
    /// `transmute` యొక్క సాధారణ అనువర్తనాలు క్రింద ఉన్నాయి, వీటిని సురక్షితమైన నిర్మాణాలతో భర్తీ చేయవచ్చు.
    ///
    /// ముడి bytes(`&[u8]`) ను `u32`, `f64`, మొదలైన వాటికి మారుస్తుంది.
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // బదులుగా `u32::from_ne_bytes` ఉపయోగించండి
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // లేదా అంతం పేర్కొనడానికి `u32::from_le_bytes` లేదా `u32::from_be_bytes` ఉపయోగించండి
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// పాయింటర్‌ను `usize` గా మార్చడం:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // బదులుగా `as` తారాగణం ఉపయోగించండి
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// `*mut T` ను `&mut T` గా మారుస్తుంది:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // బదులుగా రెబ్రోను ఉపయోగించండి
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// `&mut T` ను `&mut U` గా మారుస్తుంది:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // ఇప్పుడు, `as` మరియు రీబ్రోయింగ్లను కలిపి, `as` `as` యొక్క గొలుసు సక్రియం కాదని గమనించండి
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// `&str` ను `&[u8]` గా మారుస్తుంది:
    ///
    /// ```
    /// // దీన్ని చేయడానికి ఇది మంచి మార్గం కాదు.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // మీరు `str::as_bytes` ను ఉపయోగించవచ్చు
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // లేదా, మీకు స్ట్రింగ్ అక్షరాలా నియంత్రణ ఉంటే, బైట్ స్ట్రింగ్‌ను ఉపయోగించండి
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// `Vec<&T>` ను `Vec<Option<&T>>` గా మారుస్తుంది.
    ///
    /// కంటైనర్ యొక్క లోపలి రకాన్ని మార్చడానికి, మీరు కంటైనర్ యొక్క మార్పులను ఉల్లంఘించకుండా చూసుకోవాలి.
    /// `Vec` కోసం, లోపలి రకాల పరిమాణం *మరియు అమరిక* రెండూ సరిపోలాలి.
    /// ఇతర కంటైనర్లు రకం, అమరిక లేదా `TypeId` పరిమాణంపై ఆధారపడవచ్చు, ఈ సందర్భంలో కంటైనర్ మార్పులను ఉల్లంఘించకుండా ప్రసారం చేయడం సాధ్యం కాదు.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector ను క్లోన్ చేయండి, ఎందుకంటే మేము వాటిని తరువాత తిరిగి ఉపయోగిస్తాము
    /// let v_clone = v_orig.clone();
    ///
    /// // పరివర్తనను ఉపయోగించడం: ఇది `Vec` యొక్క పేర్కొనబడని డేటా లేఅవుట్ మీద ఆధారపడుతుంది, ఇది చెడ్డ ఆలోచన మరియు నిర్వచించబడని ప్రవర్తనకు కారణం కావచ్చు.
    /////
    /// // అయితే, ఇది కాపీ కాదు.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // ఇది సూచించిన, సురక్షితమైన మార్గం.
    /// // ఇది మొత్తం vector ను కొత్త శ్రేణిలోకి కాపీ చేస్తుంది.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // డేటా లేఅవుట్‌పై ఆధారపడకుండా, "transmuting" a `Vec` యొక్క సరైన నో-కాపీ, అసురక్షిత మార్గం ఇది.
    /// // అక్షరాలా `transmute` అని పిలవడానికి బదులుగా, మేము పాయింటర్ తారాగణం చేస్తాము, కాని అసలు లోపలి రకం (`&i32`) ను క్రొత్తది (`Option<&i32>`) గా మార్చే పరంగా, దీనికి ఒకే విధమైన మినహాయింపులు ఉన్నాయి.
    /////
    /// // పైన అందించిన సమాచారంతో పాటు, [`from_raw_parts`] డాక్యుమెంటేషన్‌ను కూడా సంప్రదించండి.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME vec_into_raw_parts స్థిరీకరించబడినప్పుడు దీన్ని నవీకరించండి.
    ///     // అసలు vector పడిపోకుండా చూసుకోండి.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// `split_at_mut` అమలు చేస్తోంది:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // దీన్ని చేయడానికి అనేక మార్గాలు ఉన్నాయి మరియు క్రింది (transmute) మార్గంలో బహుళ సమస్యలు ఉన్నాయి.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // మొదటిది: పరివర్తన రకం సురక్షితం కాదు;ఇది తనిఖీ చేస్తుంది T మరియు
    ///         // U ఒకే పరిమాణంలో ఉంటాయి.
    ///         // రెండవది, ఇక్కడే, మీకు ఒకే జ్ఞాపకశక్తిని సూచించే రెండు మ్యూటబుల్ సూచనలు ఉన్నాయి.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // ఇది రకం భద్రతా సమస్యల నుండి బయటపడుతుంది;`&mut *` మీకు `&mut T` లేదా `* mut T` నుండి `&mut T` ఇస్తుంది.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // ఏదేమైనా, మీకు ఇప్పటికీ ఒకే జ్ఞాపకశక్తిని సూచించే రెండు మ్యూటబుల్ సూచనలు ఉన్నాయి.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // ప్రామాణిక లైబ్రరీ ఈ విధంగా చేస్తుంది.
    /// // మీరు ఇలాంటి పని చేయవలసి వస్తే ఇది ఉత్తమ పద్ధతి
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // ఇది ఇప్పుడు ఒకే జ్ఞాపకశక్తిని సూచించే మూడు మ్యూటబుల్ రిఫరెన్స్‌లను కలిగి ఉంది.`slice`, rvalue ret.0 మరియు rvalue ret.1.
    ///         // `slice` `let ptr = ...` తర్వాత ఎప్పుడూ ఉపయోగించబడదు, కాబట్టి దీనిని "dead" గా పరిగణించవచ్చు మరియు అందువల్ల, మీకు రెండు నిజమైన మ్యూటబుల్ ముక్కలు మాత్రమే ఉన్నాయి.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: ఇది అంతర్గత స్థిరాంకం స్థిరంగా ఉన్నప్పటికీ, మనకు const fn లో కొన్ని కస్టమ్ కోడ్ ఉంది
    // `const fn` లో దాని ఉపయోగాన్ని నిరోధించే తనిఖీలు.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// `T` గా ఇచ్చిన అసలు రకానికి డ్రాప్ గ్లూ అవసరమైతే `true` ను అందిస్తుంది;`T` కోసం అందించిన అసలు రకం `Copy` ను అమలు చేస్తే `false` ను అందిస్తుంది.
    ///
    ///
    /// అసలు రకానికి డ్రాప్ జిగురు అవసరం లేదా `Copy` ను అమలు చేయకపోతే, ఈ ఫంక్షన్ యొక్క తిరిగి విలువ పేర్కొనబడదు.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// పాయింటర్ నుండి ఆఫ్‌సెట్‌ను లెక్కిస్తుంది.
    ///
    /// ఒక పూర్ణాంకానికి మరియు నుండి మారకుండా ఉండటానికి ఇది అంతర్గతంగా అమలు చేయబడుతుంది, ఎందుకంటే మార్పిడి మారుపేరు సమాచారాన్ని విసిరివేస్తుంది.
    ///
    /// # Safety
    ///
    /// ప్రారంభ మరియు ఫలిత పాయింటర్ రెండూ హద్దులు లేదా కేటాయించిన వస్తువు చివర ఒక బైట్ ఉండాలి.
    /// పాయింటర్ హద్దులు దాటి ఉంటే లేదా అంకగణిత ఓవర్ఫ్లో సంభవిస్తే, తిరిగి వచ్చిన విలువను మరింతగా ఉపయోగించడం వలన నిర్వచించబడని ప్రవర్తన ఏర్పడుతుంది.
    ///
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// పాయింటర్ నుండి ఆఫ్‌సెట్‌ను లెక్కిస్తుంది, సంభావ్యంగా చుట్టడం.
    ///
    /// మార్పిడి కొన్ని ఆప్టిమైజేషన్లను నిరోధిస్తుంది కాబట్టి, పూర్ణాంకానికి మరియు నుండి మారకుండా ఉండటానికి ఇది అంతర్గతంగా అమలు చేయబడుతుంది.
    ///
    /// # Safety
    ///
    /// `offset` అంతర్గత మాదిరిగా కాకుండా, ఈ అంతర్గత ఫలిత పాయింటర్‌ను సూచించడానికి లేదా కేటాయించిన వస్తువు చివర ఒక బైట్‌లోకి పరిమితం చేయదు మరియు ఇది రెండు యొక్క పూరక అంకగణితంతో చుట్టబడుతుంది.
    /// ఫలిత విలువ వాస్తవానికి మెమరీని ప్రాప్యత చేయడానికి ఉపయోగించబడదు.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// `count`*`size_of::<T>()` పరిమాణం మరియు అమరికతో తగిన `llvm.memcpy.p0i8.0i8.*` అంతర్గతానికి సమానం
    ///
    /// `min_align_of::<T>()`
    ///
    /// అస్థిర పరామితి `true` కు సెట్ చేయబడింది, కాబట్టి పరిమాణం సున్నాకి సమానంగా ఉంటే తప్ప ఇది ఆప్టిమైజ్ చేయబడదు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` పరిమాణం మరియు అమరికతో తగిన `llvm.memmove.p0i8.0i8.*` అంతర్గతానికి సమానం
    ///
    /// `min_align_of::<T>()`
    ///
    /// అస్థిర పరామితి `true` కు సెట్ చేయబడింది, కాబట్టి పరిమాణం సున్నాకి సమానంగా ఉంటే తప్ప ఇది ఆప్టిమైజ్ చేయబడదు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// `count *size_of::<T>()` పరిమాణం మరియు `min_align_of::<T>()` యొక్క అమరికతో తగిన `llvm.memset.p0i8.*` అంతర్గతానికి సమానం.
    ///
    ///
    /// అస్థిర పరామితి `true` కు సెట్ చేయబడింది, కాబట్టి పరిమాణం సున్నాకి సమానంగా ఉంటే తప్ప ఇది ఆప్టిమైజ్ చేయబడదు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// `src` పాయింటర్ నుండి అస్థిర లోడ్ను చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// `dst` పాయింటర్‌కు అస్థిర దుకాణాన్ని చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// `src` పాయింటర్ నుండి అస్థిర లోడ్ చేస్తుంది పాయింటర్ సమలేఖనం చేయవలసిన అవసరం లేదు.
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// `dst` పాయింటర్‌కు అస్థిర దుకాణాన్ని చేస్తుంది.
    /// పాయింటర్ సమలేఖనం చేయవలసిన అవసరం లేదు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// `f32` యొక్క వర్గమూలాన్ని అందిస్తుంది
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// `f64` యొక్క వర్గమూలాన్ని అందిస్తుంది
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// ఒక పూర్ణాంక శక్తికి `f32` ను పెంచుతుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// ఒక పూర్ణాంక శక్తికి `f64` ను పెంచుతుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// `f32` యొక్క సైన్‌ను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// `f64` యొక్క సైన్‌ను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// `f32` యొక్క కొసైన్ను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// `f64` యొక్క కొసైన్ను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` ను `f32` శక్తికి పెంచుతుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64` ను `f64` శక్తికి పెంచుతుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// `f32` యొక్క ఘాతాంకాన్ని అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// `f64` యొక్క ఘాతాంకాన్ని అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// `f32` యొక్క శక్తికి పెంచిన 2 ని అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// `f64` యొక్క శక్తికి పెంచిన 2 ని అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// `f32` యొక్క సహజ లాగరిథమ్‌ను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// `f64` యొక్క సహజ లాగరిథమ్‌ను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// `f32` యొక్క బేస్ 10 లోగరిథమ్‌ను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// `f64` యొక్క బేస్ 10 లోగరిథమ్‌ను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// `f32` యొక్క బేస్ 2 లాగరిథంను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// `f64` యొక్క బేస్ 2 లాగరిథంను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `f32` విలువల కోసం `a * b + c` ను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `f64` విలువల కోసం `a * b + c` ను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// `f32` యొక్క సంపూర్ణ విలువను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// `f64` యొక్క సంపూర్ణ విలువను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// కనిష్టంగా రెండు `f32` విలువలను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// కనిష్టంగా రెండు `f64` విలువలను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// గరిష్టంగా రెండు `f32` విలువలను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// గరిష్టంగా రెండు `f64` విలువలను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// `f32` విలువలకు `y` నుండి `x` కు గుర్తును కాపీ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// `f64` విలువలకు `y` నుండి `x` కు గుర్తును కాపీ చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// `f32` కన్నా తక్కువ లేదా సమానమైన అతిపెద్ద పూర్ణాంకాన్ని అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// `f64` కన్నా తక్కువ లేదా సమానమైన అతిపెద్ద పూర్ణాంకాన్ని అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// `f32` కన్నా ఎక్కువ లేదా సమానమైన అతిచిన్న పూర్ణాంకాన్ని అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// `f64` కన్నా ఎక్కువ లేదా సమానమైన అతిచిన్న పూర్ణాంకాన్ని అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// `f32` యొక్క పూర్ణాంక భాగాన్ని చూపుతుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// `f64` యొక్క పూర్ణాంక భాగాన్ని చూపుతుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// సమీప పూర్ణాంకాన్ని `f32` కి చూపుతుంది.
    /// వాదన పూర్ణాంకం కాకపోతే సరికాని ఫ్లోటింగ్ పాయింట్ మినహాయింపును పెంచవచ్చు.
    pub fn rintf32(x: f32) -> f32;
    /// సమీప పూర్ణాంకాన్ని `f64` కి చూపుతుంది.
    /// వాదన పూర్ణాంకం కాకపోతే సరికాని ఫ్లోటింగ్ పాయింట్ మినహాయింపును పెంచవచ్చు.
    pub fn rintf64(x: f64) -> f64;

    /// సమీప పూర్ణాంకాన్ని `f32` కి చూపుతుంది.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn nearbyintf32(x: f32) -> f32;
    /// సమీప పూర్ణాంకాన్ని `f64` కి చూపుతుంది.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn nearbyintf64(x: f64) -> f64;

    /// సమీప పూర్ణాంకాన్ని `f32` కి చూపుతుంది.సగం మార్గం కేసులు సున్నాకి దూరంగా ఉంటాయి.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// సమీప పూర్ణాంకాన్ని `f64` కి చూపుతుంది.సగం మార్గం కేసులు సున్నాకి దూరంగా ఉంటాయి.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణ
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// బీజగణిత నియమాల ఆధారంగా ఆప్టిమైజేషన్లను అనుమతించే ఫ్లోట్ అదనంగా.
    /// ఇన్‌పుట్‌లు పరిమితమైనవని అనుకోవచ్చు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// బీజగణిత నియమాల ఆధారంగా ఆప్టిమైజేషన్లను అనుమతించే ఫ్లోట్ వ్యవకలనం.
    /// ఇన్‌పుట్‌లు పరిమితమైనవని అనుకోవచ్చు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// బీజగణిత నియమాల ఆధారంగా ఆప్టిమైజేషన్లను అనుమతించే ఫ్లోట్ గుణకారం.
    /// ఇన్‌పుట్‌లు పరిమితమైనవని అనుకోవచ్చు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// బీజగణిత నియమాల ఆధారంగా ఆప్టిమైజేషన్లను అనుమతించే ఫ్లోట్ డివిజన్.
    /// ఇన్‌పుట్‌లు పరిమితమైనవని అనుకోవచ్చు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// బీజగణిత నియమాల ఆధారంగా ఆప్టిమైజేషన్లను అనుమతించే మిగిలిన ఫ్లోట్.
    /// ఇన్‌పుట్‌లు పరిమితమైనవని అనుకోవచ్చు.
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// LLVM యొక్క fptoui/fptosi తో మార్చండి, ఇది విలువలకు పరిమితికి మించి తిరిగి రావచ్చు
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// [`f32::to_int_unchecked`] మరియు [`f64::to_int_unchecked`] గా స్థిరీకరించబడింది.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// పూర్ణాంక రకం `T` లో సెట్ చేసిన బిట్ల సంఖ్యను చూపుతుంది
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `count_ones` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// పూర్ణాంక రకం `T` లో ప్రముఖ సెట్ చేయని బిట్స్ (zeroes) సంఖ్యను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `leading_zeros` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `0` విలువ కలిగిన `x` `T` యొక్క బిట్ వెడల్పును తిరిగి ఇస్తుంది.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// `ctlz` లాగా, కానీ అదనపు అసురక్షితమైనది `0` ను `0` విలువతో `x` ఇచ్చినప్పుడు `undef` ను తిరిగి ఇస్తుంది.
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// పూర్ణాంక రకం `T` లో వెనుకంజలో లేని సెట్ బిట్స్ (zeroes) సంఖ్యను అందిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `trailing_zeros` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `0` విలువ కలిగిన `x` `T` యొక్క బిట్ వెడల్పును అందిస్తుంది:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// `cttz` లాగా, కానీ అదనపు అసురక్షితమైనది `0` ను `0` విలువతో `x` ఇచ్చినప్పుడు `undef` ను తిరిగి ఇస్తుంది.
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// పూర్ణాంక రకం `T` లో బైట్‌లను తిరగరాస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `swap_bytes` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// పూర్ణాంక రకం `T` లో బిట్‌లను తిరగరాస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `reverse_bits` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// తనిఖీ చేసిన పూర్ణాంక చేరికను నిర్వహిస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `overflowing_add` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// తనిఖీ చేసిన పూర్ణాంక వ్యవకలనాన్ని నిర్వహిస్తుంది
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `overflowing_sub` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// తనిఖీ చేసిన పూర్ణాంక గుణకారం చేస్తుంది
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `overflowing_mul` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// `x % y != 0` లేదా `y == 0` లేదా `x == T::MIN && y == -1` ఉన్న నిర్వచించబడని ప్రవర్తన ఫలితంగా ఖచ్చితమైన విభజన జరుగుతుంది
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// తనిఖీ చేయని విభజనను నిర్వహిస్తుంది, దీని ఫలితంగా `y == 0` లేదా `x == T::MIN && y == -1` ఉన్న నిర్వచించబడని ప్రవర్తన ఉంటుంది
    ///
    ///
    /// ఈ అంతర్గత కోసం సురక్షితమైన రేపర్లు `checked_div` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// `y == 0` లేదా `x == T::MIN && y == -1` ఉన్నప్పుడు నిర్వచించబడని ప్రవర్తన ఫలితంగా తనిఖీ చేయని విభజన యొక్క మిగిలిన భాగాన్ని అందిస్తుంది
    ///
    ///
    /// ఈ అంతర్గత కోసం సురక్షితమైన రేపర్లు `checked_rem` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// తనిఖీ చేయని ఎడమ షిఫ్ట్‌ను నిర్వహిస్తుంది, దీని ఫలితంగా `y < 0` లేదా `y >= N` ఉన్నప్పుడు నిర్వచించబడని ప్రవర్తన ఉంటుంది, ఇక్కడ N అనేది బిట్స్‌లో T యొక్క వెడల్పు.
    ///
    ///
    /// ఈ అంతర్గత కోసం సురక్షితమైన రేపర్లు `checked_shl` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// తనిఖీ చేయని కుడి షిఫ్ట్‌ను నిర్వహిస్తుంది, దీని ఫలితంగా `y < 0` లేదా `y >= N` ఉన్నప్పుడు నిర్వచించబడని ప్రవర్తన ఉంటుంది, ఇక్కడ N అనేది బిట్స్‌లో T యొక్క వెడల్పు.
    ///
    ///
    /// ఈ అంతర్గత కోసం సురక్షితమైన రేపర్లు `checked_shr` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// తనిఖీ చేయని అదనంగా ఫలితాన్ని అందిస్తుంది, దీని ఫలితంగా `x + y > T::MAX` లేదా `x + y < T::MIN` ఉన్నప్పుడు నిర్వచించబడని ప్రవర్తన ఉంటుంది.
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// తనిఖీ చేయని వ్యవకలనం యొక్క ఫలితాన్ని అందిస్తుంది, దీని ఫలితంగా `x - y > T::MAX` లేదా `x - y < T::MIN` ఉన్నప్పుడు నిర్వచించబడని ప్రవర్తన ఉంటుంది.
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// తనిఖీ చేయని గుణకారం యొక్క ఫలితాన్ని అందిస్తుంది, దీని ఫలితంగా `x *y > T::MAX` లేదా `x* y < T::MIN` ఉన్నప్పుడు నిర్వచించబడని ప్రవర్తన ఉంటుంది.
    ///
    ///
    /// ఈ అంతర్గత స్థిరమైన ప్రతిరూపం లేదు.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// ఎడమవైపు తిప్పండి.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `rotate_left` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// కుడివైపు తిరిగేలా చేస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `rotate_right` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// రిటర్న్స్ (a + b) mod 2 <sup>N</sup>, ఇక్కడ N అనేది బిట్స్‌లో T యొక్క వెడల్పు.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `wrapping_add` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// రిటర్న్స్ (a, b) mod 2 <sup>N</sup>, ఇక్కడ N అనేది బిట్స్‌లో T యొక్క వెడల్పు.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `wrapping_sub` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// రిటర్న్స్ (a * b) mod 2 <sup>N</sup>, ఇక్కడ N అనేది బిట్స్‌లో T యొక్క వెడల్పు.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `wrapping_mul` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// `a + b` ను లెక్కిస్తుంది, సంఖ్యా సరిహద్దులలో సంతృప్తమవుతుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `saturating_add` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// `a - b` ను లెక్కిస్తుంది, సంఖ్యా సరిహద్దులలో సంతృప్తమవుతుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించిన సంస్కరణలు `saturating_sub` పద్ధతి ద్వారా పూర్ణాంక ఆదిమవాసులలో లభిస్తాయి.
    /// ఉదాహరణకి,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// 'v' లోని వేరియంట్ కోసం వివక్షత యొక్క విలువను అందిస్తుంది;
    /// `T` కి వివక్షత లేకపోతే, `0` ను తిరిగి ఇస్తుంది.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరమైన వెర్షన్ [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// `T` తారాగణం యొక్క వేరియంట్ల సంఖ్యను `usize` కు చూపుతుంది;
    /// `T` కి వేరియంట్లు లేకపోతే, `0` ను తిరిగి ఇస్తుంది.జనావాసాలు లేని వేరియంట్లు లెక్కించబడతాయి.
    ///
    /// ఈ అంతర్గత యొక్క స్థిరీకరించబడిన సంస్కరణ [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust యొక్క "try catch" నిర్మాణం డేటా పాయింటర్ `data` తో ఫంక్షన్ పాయింటర్ `try_fn` ను పిలుస్తుంది.
    ///
    /// మూడవ వాదన panic సంభవిస్తే పిలువబడే ఫంక్షన్.
    /// ఈ ఫంక్షన్ డేటా పాయింటర్ మరియు పాయింటర్‌ను పట్టుకున్న లక్ష్య-నిర్దిష్ట మినహాయింపు వస్తువుకు తీసుకువెళుతుంది.
    ///
    /// మరింత సమాచారం కోసం కంపైలర్ యొక్క మూలాన్ని అలాగే std యొక్క క్యాచ్ అమలు చూడండి.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// LLVM ప్రకారం `!nontemporal` స్టోర్‌ను విడుదల చేస్తుంది (వారి డాక్స్ చూడండి).
    /// బహుశా ఎప్పుడూ స్థిరంగా మారదు.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// వివరాల కోసం `<*const T>::offset_from` యొక్క డాక్యుమెంటేషన్ చూడండి.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// వివరాల కోసం `<*const T>::guaranteed_eq` యొక్క డాక్యుమెంటేషన్ చూడండి.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// వివరాల కోసం `<*const T>::guaranteed_ne` యొక్క డాక్యుమెంటేషన్ చూడండి.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// కంపైల్ సమయంలో కేటాయించండి.రన్‌టైమ్‌లో పిలవకూడదు.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// కొన్ని విధులు ఇక్కడ నిర్వచించబడ్డాయి ఎందుకంటే అవి అనుకోకుండా ఈ మాడ్యూల్‌లో స్థిరంగా అందుబాటులో ఉన్నాయి.
// <https://github.com/rust-lang/rust/issues/15702> చూడండి.
// (`transmute` కూడా ఈ వర్గంలోకి వస్తుంది, అయితే `T` మరియు `U` ఒకే పరిమాణాన్ని కలిగి ఉన్నాయో లేదో తనిఖీ చేయలేము.)
//

/// `align_of::<T>()` కు సంబంధించి `ptr` సరిగ్గా సమలేఖనం చేయబడిందో లేదో తనిఖీ చేస్తుంది.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` బైట్‌లను `src` నుండి `dst` వరకు కాపీ చేస్తుంది.మూలం మరియు గమ్యం* అతివ్యాప్తి చెందకూడదు.
///
/// అతివ్యాప్తి చెందగల మెమరీ ప్రాంతాల కోసం, బదులుగా [`copy`] ఉపయోగించండి.
///
/// `copy_nonoverlapping` సి యొక్క [`memcpy`] కు అర్థవంతంగా సమానం, కానీ ఆర్గ్యుమెంట్ ఆర్డర్ మార్పిడితో.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// కింది షరతులు ఏవైనా ఉల్లంఘించినట్లయితే ప్రవర్తన నిర్వచించబడదు:
///
/// * `src` `count * size_of::<T>()` బైట్‌ల రీడ్‌ల కోసం [valid] ఉండాలి.
///
/// * `dst` `count * size_of::<T>()` బైట్ల రచనల కోసం [valid] ఉండాలి.
///
/// * `src` మరియు `dst` రెండూ సరిగ్గా సమలేఖనం చేయబడాలి.
///
/// * `src` వద్ద ప్రారంభమయ్యే మెమరీ ప్రాంతం `కౌంట్ పరిమాణంతో *
///   size_of: :<T>() `బైట్లు `dst` వద్ద ప్రారంభమయ్యే మెమరీ ప్రాంతంతో ఒకే పరిమాణంతో అతివ్యాప్తి చెందకూడదు.
///
/// [`read`] మాదిరిగా, `copy_nonoverlapping` `T` యొక్క బిట్‌వైస్ కాపీని సృష్టిస్తుంది, `T` [`Copy`] కాదా అనే దానితో సంబంధం లేకుండా.
/// `T` [`Copy`] కాకపోతే, `*src` నుండి ప్రారంభమయ్యే ప్రాంతంలోని విలువలు మరియు `* dst` వద్ద ప్రారంభమయ్యే ప్రాంతం [violate memory safety][read-ownership] ను * రెండింటినీ ఉపయోగించి.
///
///
/// పరిమాణాన్ని సమర్థవంతంగా కాపీ చేసినప్పటికీ (`కౌంట్ * సైజు_ఆఫ్: :<T>()`) `0`, పాయింటర్లు NULL కానివిగా ఉండాలి మరియు సరిగ్గా సమలేఖనం చేయబడతాయి.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] ను మాన్యువల్‌గా అమలు చేయండి:
///
/// ```
/// use std::ptr;
///
/// /// `src` యొక్క అన్ని మూలకాలను `dst` లోకి కదిలిస్తుంది, `src` ఖాళీగా ఉంటుంది.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // `dst` అన్ని `src` ని పట్టుకునేంత సామర్థ్యాన్ని కలిగి ఉందని నిర్ధారించుకోండి.
///     dst.reserve(src_len);
///
///     unsafe {
///         // ఆఫ్‌సెట్‌కు కాల్ ఎల్లప్పుడూ సురక్షితం ఎందుకంటే `Vec` ఎప్పటికీ `isize::MAX` బైట్‌ల కంటే ఎక్కువ కేటాయించదు.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // `src` దాని కంటెంట్లను వదలకుండా కత్తిరించండి.
///         // panics లో ఇంకొకటి తక్కువగా ఉంటే సమస్యలను నివారించడానికి మేము మొదట దీన్ని చేస్తాము.
///         src.set_len(0);
///
///         // మార్చగల సూచనలు మారుపేరు కానందున రెండు ప్రాంతాలు అతివ్యాప్తి చెందవు మరియు రెండు వేర్వేరు vectors ఒకే మెమరీని కలిగి ఉండవు.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // `dst` ఇప్పుడు `src` యొక్క కంటెంట్లను కలిగి ఉందని తెలియజేయండి.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: ఈ తనిఖీలను రన్ టైమ్‌లో మాత్రమే చేయండి
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // కోడెజెన్ ప్రభావాన్ని చిన్నగా ఉంచడానికి భయపడటం లేదు.
        abort();
    }*/

    // భద్రత: `copy_nonoverlapping` కోసం భద్రతా ఒప్పందం తప్పనిసరిగా ఉండాలి
    // కాలర్ చేత సమర్థించబడింది.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` బైట్‌లను `src` నుండి `dst` వరకు కాపీ చేస్తుంది.మూలం మరియు గమ్యం అతివ్యాప్తి చెందుతాయి.
///
/// మూలం మరియు గమ్యం *ఎప్పటికీ* అతివ్యాప్తి చెందకపోతే, బదులుగా [`copy_nonoverlapping`] ఉపయోగించవచ్చు.
///
/// `copy` సి యొక్క [`memmove`] కి అర్థవంతంగా సమానం, కానీ ఆర్గ్యుమెంట్ ఆర్డర్ మార్పిడితో.
/// `src` నుండి తాత్కాలిక శ్రేణికి బైట్లు కాపీ చేయబడి, శ్రేణి నుండి `dst` కు కాపీ చేయబడినట్లుగా కాపీ చేయడం జరుగుతుంది.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// కింది షరతులు ఏవైనా ఉల్లంఘించినట్లయితే ప్రవర్తన నిర్వచించబడదు:
///
/// * `src` `count * size_of::<T>()` బైట్‌ల రీడ్‌ల కోసం [valid] ఉండాలి.
///
/// * `dst` `count * size_of::<T>()` బైట్ల రచనల కోసం [valid] ఉండాలి.
///
/// * `src` మరియు `dst` రెండూ సరిగ్గా సమలేఖనం చేయబడాలి.
///
/// [`read`] మాదిరిగా, `copy` `T` యొక్క బిట్‌వైస్ కాపీని సృష్టిస్తుంది, `T` [`Copy`] కాదా అనే దానితో సంబంధం లేకుండా.
/// `T` [`Copy`] కాకపోతే, `*src` నుండి ప్రారంభమయ్యే ప్రాంతంలోని రెండు విలువలను మరియు `* dst` వద్ద ప్రారంభమయ్యే ప్రాంతం [violate memory safety][read-ownership] చేయగలదు.
///
///
/// పరిమాణాన్ని సమర్థవంతంగా కాపీ చేసినప్పటికీ (`కౌంట్ * సైజు_ఆఫ్: :<T>()`) `0`, పాయింటర్లు NULL కానివిగా ఉండాలి మరియు సరిగ్గా సమలేఖనం చేయబడతాయి.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// అసురక్షిత బఫర్ నుండి Rust vector ను సమర్ధవంతంగా సృష్టించండి:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` దాని రకం మరియు సున్నా కాని వాటి కోసం సరిగ్గా సమలేఖనం చేయాలి.
/// /// * `ptr` `T` రకం `elts` పరస్పర మూలకాల రీడ్‌ల కోసం చెల్లుబాటులో ఉండాలి.
/// /// * `T: Copy` తప్ప ఈ ఫంక్షన్‌ను పిలిచిన తర్వాత ఆ మూలకాలను ఉపయోగించకూడదు.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // భద్రత: మా ముందస్తు షరతు మూలం సమలేఖనం చేయబడిందని మరియు చెల్లుబాటు అవుతుందని నిర్ధారిస్తుంది,
///     // మరియు `Vec::with_capacity` వాటిని వ్రాయడానికి మాకు ఉపయోగపడే స్థలం ఉందని నిర్ధారిస్తుంది.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // భద్రత: ఇంతకు ముందు మేము దీన్ని చాలా సామర్థ్యంతో సృష్టించాము,
///     // మరియు మునుపటి `copy` ఈ అంశాలను ప్రారంభించింది.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: ఈ తనిఖీలను రన్ టైమ్‌లో మాత్రమే చేయండి
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // కోడెజెన్ ప్రభావాన్ని చిన్నగా ఉంచడానికి భయపడటం లేదు.
        abort();
    }*/

    // భద్రత: `copy` కోసం భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి.
    unsafe { copy(src, dst, count) }
}

/// `dst` నుండి `val` వరకు ప్రారంభమయ్యే `count * size_of::<T>()` బైట్ల మెమరీని సెట్ చేస్తుంది.
///
/// `write_bytes` C యొక్క [`memset`] ను పోలి ఉంటుంది, కానీ `count * size_of::<T>()` బైట్‌లను `val` కు సెట్ చేస్తుంది.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// కింది షరతులు ఏవైనా ఉల్లంఘించినట్లయితే ప్రవర్తన నిర్వచించబడదు:
///
/// * `dst` `count * size_of::<T>()` బైట్ల రచనల కోసం [valid] ఉండాలి.
///
/// * `dst` సరిగ్గా సమలేఖనం చేయాలి.
///
/// అదనంగా, కాలర్ తప్పనిసరిగా ఇచ్చిన మెమరీ ప్రాంతానికి `count * size_of::<T>()` బైట్లు రాయడం వలన `T` యొక్క చెల్లుబాటు అయ్యే విలువ వస్తుంది.
/// `T` యొక్క చెల్లని విలువను కలిగి ఉన్న `T` గా టైప్ చేసిన మెమరీ ప్రాంతాన్ని ఉపయోగించడం నిర్వచించబడని ప్రవర్తన.
///
/// పరిమాణాన్ని సమర్థవంతంగా కాపీ చేసినప్పటికీ (`కౌంట్ * సైజు_ఆఫ్: :<T>()`) `0`, పాయింటర్ NULL కానిది మరియు సరిగ్గా సమలేఖనం చేయబడాలి.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// చెల్లని విలువను సృష్టిస్తోంది:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // `Box<T>` ను శూన్య పాయింటర్‌తో ఓవర్రైట్ చేయడం ద్వారా గతంలో ఉంచిన విలువను లీక్ చేస్తుంది.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // ఈ సమయంలో, `v` ను ఉపయోగించడం లేదా వదలడం వలన నిర్వచించబడని ప్రవర్తన వస్తుంది.
/// // drop(v); // ERROR
///
/// // `v` "uses" ను కూడా లీక్ చేయడం మరియు నిర్వచించబడని ప్రవర్తన.
/// // mem::forget(v); // ERROR
///
/// // వాస్తవానికి, ప్రాథమిక రకం లేఅవుట్ మార్పుల ప్రకారం `v` చెల్లదు, కాబట్టి *ఏదైనా* ఆపరేషన్ దానిని తాకితే నిర్వచించబడని ప్రవర్తన.
/////
/// // v2 =v;//లోపం
///
/// unsafe {
///     // బదులుగా చెల్లుబాటు అయ్యే విలువను ఉంచండి
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // ఇప్పుడు బాక్స్ బాగానే ఉంది
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // భద్రత: `write_bytes` కోసం భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి.
    unsafe { write_bytes(dst, val, count) }
}