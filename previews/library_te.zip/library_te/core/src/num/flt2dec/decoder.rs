//! ఫ్లోటింగ్ పాయింట్ విలువను వ్యక్తిగత భాగాలు మరియు లోపం పరిధులుగా డీకోడ్ చేస్తుంది.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// డీకోడ్ చేయని పరిమిత విలువ, అంటే:
///
/// - అసలు విలువ `mant * 2^exp` కి సమానం.
///
/// - `(mant - minus)*2^exp` నుండి `(mant + plus)* 2^exp` వరకు ఏదైనా సంఖ్య అసలు విలువకు రౌండ్ అవుతుంది.
/// `inclusive` `true` అయినప్పుడు మాత్రమే పరిధి కలుపుతుంది.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// స్కేల్డ్ మాంటిస్సా.
    pub mant: u64,
    /// తక్కువ లోపం పరిధి.
    pub minus: u64,
    /// ఎగువ లోపం పరిధి.
    pub plus: u64,
    /// బేస్ 2 లో షేర్డ్ ఎక్స్‌పోనెంట్.
    pub exp: i16,
    /// లోపం పరిధి కలుపుకొని ఉన్నప్పుడు నిజం.
    ///
    /// IEEE 754 లో, అసలు మాంటిస్సా సమానంగా ఉన్నప్పుడు ఇది నిజం.
    pub inclusive: bool,
}

/// డీకోడ్ చేయని విలువ.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// అనంతాలు, సానుకూలంగా లేదా ప్రతికూలంగా ఉంటాయి.
    Infinite,
    /// జీరో, పాజిటివ్ లేదా నెగటివ్.
    Zero,
    /// మరింత డీకోడ్ చేసిన ఫీల్డ్‌లతో పరిమిత సంఖ్యలు.
    Finite(Decoded),
}

/// ఫ్లోటింగ్ పాయింట్ రకం `డీకోడ్`.
pub trait DecodableFloat: RawFloat + Copy {
    /// కనీస సానుకూల సాధారణ విలువ.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// ఇచ్చిన ఫ్లోటింగ్ పాయింట్ సంఖ్య నుండి ఒక సంకేతం (ప్రతికూలంగా ఉన్నప్పుడు నిజం) మరియు `FullDecoded` విలువను అందిస్తుంది.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // పొరుగువారు: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode ఎల్లప్పుడూ ఘాతాంకాన్ని సంరక్షిస్తుంది, కాబట్టి మాంటిస్సా సబ్‌నార్మల్స్ కోసం స్కేల్ చేయబడుతుంది.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // పొరుగువారు: (గరిష్ట, ఎక్స్, 1)-(మిన్నర్మాంట్, ఎక్స్)-(మిన్నర్మాంట్ + 1, ఎక్స్)
                // ఇక్కడ maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // పొరుగువారు: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}