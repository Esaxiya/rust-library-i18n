//! `f64` డబుల్-ప్రెసిషన్ ఫ్లోటింగ్ పాయింట్ రకానికి ప్రత్యేకమైన స్థిరాంకాలు.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! `consts` ఉప మాడ్యూల్‌లో గణితశాస్త్రపరంగా ముఖ్యమైన సంఖ్యలు అందించబడ్డాయి.
//!
//! ఈ మాడ్యూల్‌లో నేరుగా నిర్వచించిన స్థిరాంకాల కోసం (`consts` ఉప-మాడ్యూల్‌లో నిర్వచించిన వాటికి భిన్నంగా), కొత్త కోడ్ బదులుగా `f64` రకంపై నేరుగా నిర్వచించిన అనుబంధ స్థిరాంకాలను ఉపయోగించాలి.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f64` యొక్క అంతర్గత ప్రాతినిధ్యం యొక్క రాడిక్స్ లేదా బేస్.
/// బదులుగా [`f64::RADIX`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // ఉద్దేశించిన మార్గం
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// బేస్ 2 లోని ముఖ్యమైన అంకెల సంఖ్య.
/// బదులుగా [`f64::MANTISSA_DIGITS`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // ఉద్దేశించిన మార్గం
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// బేస్ 10 లో గణనీయమైన అంకెలు సుమారు.
/// బదులుగా [`f64::DIGITS`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // ఉద్దేశించిన మార్గం
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] `f64` కోసం విలువ.
/// బదులుగా [`f64::EPSILON`] ఉపయోగించండి.
///
/// ఇది `1.0` మరియు తదుపరి పెద్ద ప్రాతినిధ్య సంఖ్య మధ్య వ్యత్యాసం.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // ఉద్దేశించిన మార్గం
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// చిన్న పరిమిత `f64` విలువ.
/// బదులుగా [`f64::MIN`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // ఉద్దేశించిన మార్గం
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// చిన్న సానుకూల సాధారణ `f64` విలువ.
/// బదులుగా [`f64::MIN_POSITIVE`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // ఉద్దేశించిన మార్గం
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// అతిపెద్ద పరిమిత `f64` విలువ.
/// బదులుగా [`f64::MAX`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // ఉద్దేశించిన మార్గం
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// 2 ఘాతాంకం యొక్క కనీస సాధారణ శక్తి కంటే ఒకటి.
/// బదులుగా [`f64::MIN_EXP`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // ఉద్దేశించిన మార్గం
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// 2 ఘాతాంకం యొక్క గరిష్ట శక్తి.
/// బదులుగా [`f64::MAX_EXP`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // ఉద్దేశించిన మార్గం
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// 10 ఘాతాంకం యొక్క కనీస సాధారణ శక్తి.
/// బదులుగా [`f64::MIN_10_EXP`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // ఉద్దేశించిన మార్గం
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// 10 ఘాతాంకం యొక్క గరిష్ట శక్తి.
/// బదులుగా [`f64::MAX_10_EXP`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // ఉద్దేశించిన మార్గం
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// సంఖ్య (NaN) కాదు.
/// బదులుగా [`f64::NAN`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // ఉద్దేశించిన మార్గం
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// అనంతం (∞).
/// బదులుగా [`f64::INFINITY`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // ఉద్దేశించిన మార్గం
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// ప్రతికూల అనంతం (−∞).
/// బదులుగా [`f64::NEG_INFINITY`] ఉపయోగించండి.
///
/// # Examples
///
/// ```rust
/// // డీప్రికేటెడ్ మార్గం
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // ఉద్దేశించిన మార్గం
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// ప్రాథమిక గణిత స్థిరాంకాలు.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cmath నుండి గణిత స్థిరాంకాలతో భర్తీ చేయండి.

    /// ఆర్కిమెడిస్ యొక్క స్థిరమైన (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// పూర్తి సర్కిల్ స్థిరాంకం (τ)
    ///
    /// 2π కు సమానం.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// ఐలర్ యొక్క సంఖ్య (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// `f64` యొక్క అంతర్గత ప్రాతినిధ్యం యొక్క రాడిక్స్ లేదా బేస్.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// బేస్ 2 లోని ముఖ్యమైన అంకెల సంఖ్య.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// బేస్ 10 లో గణనీయమైన అంకెలు సుమారు.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] `f64` కోసం విలువ.
    ///
    /// ఇది `1.0` మరియు తదుపరి పెద్ద ప్రాతినిధ్య సంఖ్య మధ్య వ్యత్యాసం.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// చిన్న పరిమిత `f64` విలువ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// చిన్న సానుకూల సాధారణ `f64` విలువ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// అతిపెద్ద పరిమిత `f64` విలువ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// 2 ఘాతాంకం యొక్క కనీస సాధారణ శక్తి కంటే ఒకటి.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// 2 ఘాతాంకం యొక్క గరిష్ట శక్తి.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// 10 ఘాతాంకం యొక్క కనీస సాధారణ శక్తి.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// 10 ఘాతాంకం యొక్క గరిష్ట శక్తి.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// సంఖ్య (NaN) కాదు.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// అనంతం (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// ప్రతికూల అనంతం (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// ఈ విలువ `NaN` అయితే `true` ని అందిస్తుంది.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): పోర్టబిలిటీ గురించి ఆందోళనల కారణంగా `abs` బహిరంగంగా లిబ్‌కోర్‌లో అందుబాటులో లేదు, కాబట్టి ఈ అమలు అంతర్గతంగా ప్రైవేట్ ఉపయోగం కోసం.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// ఈ విలువ సానుకూల అనంతం లేదా ప్రతికూల అనంతం అయితే `true` ను అందిస్తుంది, లేకపోతే `false`.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// ఈ సంఖ్య అనంతం లేదా `NaN` కాకపోతే `true` ని అందిస్తుంది.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN ను విడిగా నిర్వహించాల్సిన అవసరం లేదు: స్వీయ NaN అయితే, పోలిక నిజం కాదు, సరిగ్గా కోరుకున్నట్లు.
        //
        self.abs_private() < Self::INFINITY
    }

    /// సంఖ్య [subnormal] అయితే `true` ని అందిస్తుంది.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // `0` మరియు `min` మధ్య విలువలు సబ్‌నార్మల్.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// సంఖ్య సున్నా, అనంతం, [subnormal] లేదా `NaN` కాకపోతే `true` ని అందిస్తుంది.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // `0` మరియు `min` మధ్య విలువలు సబ్‌నార్మల్.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// సంఖ్య యొక్క ఫ్లోటింగ్ పాయింట్ వర్గాన్ని అందిస్తుంది.
    /// ఒక ఆస్తి మాత్రమే పరీక్షించబడుతుంటే, బదులుగా నిర్దిష్ట ప్రిడికేట్‌ను ఉపయోగించడం సాధారణంగా వేగంగా ఉంటుంది.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// X002, పాజిటివ్ సైన్ బిట్ మరియు పాజిటివ్ ఇన్ఫినిటీతో `NaN` లతో సహా `self` కి సానుకూల సంకేతం ఉంటే `true` ను అందిస్తుంది.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// `self` కి ప్రతికూల సంకేతం ఉంటే, `-0.0`, నెగటివ్ సైన్ బిట్ మరియు నెగటివ్ అనంతంతో `NaN` లు ఉంటే `true` ను అందిస్తుంది.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// సంఖ్య యొక్క పరస్పర (inverse) తీసుకుంటుంది, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// రేడియన్లను డిగ్రీలుగా మారుస్తుంది.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // 180/of యొక్క నిజమైన విలువకు సంబంధించి ఇక్కడ విభజన సరిగ్గా గుండ్రంగా ఉంటుంది.
        // (ఇది f32 కి భిన్నంగా ఉంటుంది, ఇక్కడ సరిగ్గా గుండ్రని ఫలితాన్ని నిర్ధారించడానికి స్థిరంగా ఉపయోగించాలి.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// డిగ్రీలను రేడియన్లుగా మారుస్తుంది.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// రెండు సంఖ్యల గరిష్టాన్ని అందిస్తుంది.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// వాదనలలో ఒకటి NaN అయితే, మరొక వాదన తిరిగి ఇవ్వబడుతుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// రెండు సంఖ్యల కనిష్టాన్ని చూపుతుంది.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// వాదనలలో ఒకటి NaN అయితే, మరొక వాదన తిరిగి ఇవ్వబడుతుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// విలువ పరిమితమైనదని మరియు ఆ రకానికి సరిపోతుందని uming హిస్తూ, సున్నా వైపు రౌండ్లు మరియు ఏదైనా ఆదిమ పూర్ణాంక రకానికి మారుతుంది.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// విలువ తప్పక:
    ///
    /// * `NaN` గా ఉండకూడదు
    /// * అనంతం కాదు
    /// * దాని భిన్న భాగాన్ని కత్తిరించిన తరువాత, రిటర్న్ రకం `Int` లో ప్రాతినిధ్యం వహించండి
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // భద్రత: కాలర్ `FloatToInt::to_int_unchecked` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u64` కు ముడి పరివర్తన.
    ///
    /// ఇది ప్రస్తుతం అన్ని ప్లాట్‌ఫామ్‌లలో `transmute::<f64, u64>(self)` కి సమానంగా ఉంటుంది.
    ///
    /// ఈ ఆపరేషన్ యొక్క పోర్టబిలిటీ గురించి కొంత చర్చ కోసం `from_bits` చూడండి (దాదాపు సమస్యలు లేవు).
    ///
    /// ఈ ఫంక్షన్ `as` కాస్టింగ్ నుండి భిన్నంగా ఉందని గమనించండి, ఇది *సంఖ్యా* విలువను సంరక్షించడానికి ప్రయత్నిస్తుంది మరియు బిట్‌వైస్ విలువను కాదు.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() ప్రసారం చేయడం లేదు!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // భద్రత: `u64` అనేది సాదా పాత డేటాటైప్ కాబట్టి మేము దీనికి ఎల్లప్పుడూ రూపాంతరం చెందుతాము
        unsafe { mem::transmute(self) }
    }

    /// `u64` నుండి ముడి పరివర్తన.
    ///
    /// ఇది ప్రస్తుతం అన్ని ప్లాట్‌ఫామ్‌లలో `transmute::<u64, f64>(v)` కి సమానంగా ఉంటుంది.
    /// ఇది రెండు కారణాల వల్ల ఇది చాలా పోర్టబుల్ అని తేలుతుంది:
    ///
    /// * అన్ని మద్దతు ఉన్న ప్లాట్‌ఫారమ్‌లలో ఫ్లోట్‌లు మరియు ఇంట్‌లు ఒకే అంతం కలిగి ఉంటాయి.
    /// * IEEE-754 చాలా ఖచ్చితంగా ఫ్లోట్ల బిట్ లేఅవుట్ను నిర్దేశిస్తుంది.
    ///
    /// అయితే ఒక మినహాయింపు ఉంది: IEEE-754 యొక్క 2008 సంస్కరణకు ముందు, NaN సిగ్నలింగ్ బిట్‌ను ఎలా అర్థం చేసుకోవాలో వాస్తవానికి పేర్కొనబడలేదు.
    /// చాలా ప్లాట్‌ఫారమ్‌లు (ముఖ్యంగా x86 మరియు ARM) 2008 లో చివరికి ప్రామాణికమైన వ్యాఖ్యానాన్ని ఎంచుకున్నాయి, కాని కొన్ని చేయలేదు (ముఖ్యంగా MIPS).
    /// తత్ఫలితంగా, MIPS లోని అన్ని సిగ్నలింగ్ NaN లు x86 లో నిశ్శబ్ద NaN లు, మరియు దీనికి విరుద్ధంగా.
    ///
    /// సిగ్నలింగ్-నెస్ క్రాస్-ప్లాట్‌ఫామ్‌ను సంరక్షించడానికి ప్రయత్నించే బదులు, ఈ అమలు ఖచ్చితమైన బిట్‌లను సంరక్షించడానికి అనుకూలంగా ఉంటుంది.
    /// ఈ పద్ధతి యొక్క ఫలితం నెట్‌వర్క్ ద్వారా x86 మెషీన్ నుండి MIPS వన్‌కు పంపినప్పటికీ NaN లలో ఎన్‌కోడ్ చేయబడిన ఏదైనా పేలోడ్‌లు భద్రపరచబడతాయి.
    ///
    ///
    /// ఈ పద్ధతి యొక్క ఫలితాలు వాటిని ఉత్పత్తి చేసిన అదే నిర్మాణం ద్వారా మాత్రమే మార్చబడితే, అప్పుడు పోర్టబిలిటీ ఆందోళన లేదు.
    ///
    /// ఇన్పుట్ NaN కాకపోతే, పోర్టబిలిటీ ఆందోళన లేదు.
    ///
    /// మీరు సిగ్నలింగ్-నెస్ గురించి పట్టించుకోకపోతే (చాలా అవకాశం), అప్పుడు పోర్టబిలిటీ ఆందోళన లేదు.
    ///
    /// ఈ ఫంక్షన్ `as` కాస్టింగ్ నుండి భిన్నంగా ఉందని గమనించండి, ఇది *సంఖ్యా* విలువను సంరక్షించడానికి ప్రయత్నిస్తుంది మరియు బిట్‌వైస్ విలువను కాదు.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // భద్రత: `u64` అనేది సాదా పాత డేటాటైప్ కాబట్టి మేము దాని నుండి ఎల్లప్పుడూ ప్రసారం చేయవచ్చు
        // SNaN తో భద్రతా సమస్యలు అధికంగా ఎగిరిపోయాయి!హుర్రే!
        unsafe { mem::transmute(v) }
    }

    /// ఈ ఫ్లోటింగ్ పాయింట్ నంబర్ యొక్క మెమరీ ప్రాతినిధ్యాన్ని బిగ్-ఎండియన్ (network) బైట్ క్రమంలో బైట్ శ్రేణిగా తిరిగి ఇవ్వండి.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// ఈ ఫ్లోటింగ్ పాయింట్ సంఖ్య యొక్క మెమరీ ప్రాతినిధ్యాన్ని చిన్న-ఎండియన్ బైట్ క్రమంలో బైట్ శ్రేణిగా తిరిగి ఇవ్వండి.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// ఈ ఫ్లోటింగ్ పాయింట్ సంఖ్య యొక్క మెమరీ ప్రాతినిధ్యాన్ని స్థానిక బైట్ క్రమంలో బైట్ శ్రేణిగా తిరిగి ఇవ్వండి.
    ///
    /// టార్గెట్ ప్లాట్‌ఫాం యొక్క స్థానిక ఎండియెన్స్ ఉపయోగించబడుతున్నందున, పోర్టబుల్ కోడ్ బదులుగా, తగినట్లుగా, [`to_be_bytes`] లేదా [`to_le_bytes`] ను ఉపయోగించాలి.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// ఈ ఫ్లోటింగ్ పాయింట్ సంఖ్య యొక్క మెమరీ ప్రాతినిధ్యాన్ని స్థానిక బైట్ క్రమంలో బైట్ శ్రేణిగా తిరిగి ఇవ్వండి.
    ///
    ///
    /// [`to_ne_bytes`] వీలైనప్పుడల్లా దీనికి ప్రాధాన్యత ఇవ్వాలి.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // భద్రత: `f64` అనేది సాదా పాత డేటాటైప్ కాబట్టి మేము దీనికి ఎల్లప్పుడూ రూపాంతరం చెందుతాము
        unsafe { &*(self as *const Self as *const _) }
    }

    /// పెద్ద ఎండియన్‌లో బైట్ శ్రేణిగా దాని ప్రాతినిధ్యం నుండి ఫ్లోటింగ్ పాయింట్ విలువను సృష్టించండి.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// చిన్న ఎండియన్‌లో బైట్ శ్రేణిగా దాని ప్రాతినిధ్యం నుండి ఫ్లోటింగ్ పాయింట్ విలువను సృష్టించండి.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// స్థానిక ఎండియన్‌లో బైట్ శ్రేణిగా దాని ప్రాతినిధ్యం నుండి ఫ్లోటింగ్ పాయింట్ విలువను సృష్టించండి.
    ///
    /// టార్గెట్ ప్లాట్‌ఫాం యొక్క స్థానిక ఎండియెన్స్ ఉపయోగించబడుతున్నందున, పోర్టబుల్ కోడ్ బదులుగా తగినట్లుగా [`from_be_bytes`] లేదా [`from_le_bytes`] ను ఉపయోగించాలనుకుంటుంది.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// స్వీయ మరియు ఇతర విలువల మధ్య క్రమాన్ని అందిస్తుంది.
    /// ఫ్లోటింగ్ పాయింట్ సంఖ్యల మధ్య ప్రామాణిక పాక్షిక పోలిక వలె కాకుండా, ఈ పోలిక ఎల్లప్పుడూ IEEE 754 (2008 రివిజన్) ఫ్లోటింగ్ పాయింట్ స్టాండర్డ్‌లో నిర్వచించిన టోటల్‌ఆర్డర్ ప్రిడికేట్‌కు అనుగుణంగా ఆర్డరింగ్‌ను ఉత్పత్తి చేస్తుంది.
    /// విలువలు క్రింది క్రమంలో క్రమం చేయబడతాయి:
    /// - ప్రతికూల నిశ్శబ్ద NaN
    /// - ప్రతికూల సిగ్నలింగ్ NaN
    /// - ప్రతికూల అనంతం
    /// - ప్రతికూల సంఖ్యలు
    /// - ప్రతికూల సబ్‌నార్మల్ సంఖ్యలు
    /// - ప్రతికూల సున్నా
    /// - సానుకూల సున్నా
    /// - సానుకూల సబ్‌నార్మల్ సంఖ్యలు
    /// - సానుకూల సంఖ్యలు
    /// - సానుకూల అనంతం
    /// - పాజిటివ్ సిగ్నలింగ్ NaN
    /// - సానుకూల నిశ్శబ్ద NaN
    ///
    /// ఈ ఫంక్షన్ ఎల్లప్పుడూ `f64` యొక్క [`PartialOrd`] మరియు [`PartialEq`] అమలులతో ఏకీభవించదని గమనించండి.ముఖ్యంగా, వారు ప్రతికూల మరియు సానుకూల సున్నాను సమానంగా భావిస్తారు, అయితే `total_cmp` అలా చేయదు.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // ప్రతికూలతల విషయంలో, రెండు యొక్క పూరక పూర్ణాంకాల వలె సారూప్య లేఅవుట్‌ను సాధించడానికి గుర్తు మినహా అన్ని బిట్‌లను తిప్పండి
        //
        // ఇది ఎందుకు పని చేస్తుంది?IEEE 754 ఫ్లోట్లు మూడు ఫీల్డ్‌లను కలిగి ఉంటాయి:
        // సైన్ బిట్, ఎక్స్‌పోనెంట్ మరియు మాంటిస్సా.ఘాతాంకం మరియు మాంటిస్సా క్షేత్రాల సమితి వారి బిట్‌వైజ్ క్రమం మాగ్నిట్యూడ్ నిర్వచించబడిన సంఖ్యా పరిమాణానికి సమానమైన ఆస్తిని కలిగి ఉంటుంది.
        // మాగ్నిట్యూడ్ సాధారణంగా NaN విలువలపై నిర్వచించబడదు, కాని IEEE 754 టోటల్ఆర్డర్ NaN విలువలను కూడా బిట్‌వైస్ క్రమాన్ని అనుసరించడానికి నిర్వచిస్తుంది.ఇది డాక్ వ్యాఖ్యలో వివరించిన క్రమానికి దారితీస్తుంది.
        // అయినప్పటికీ, మాగ్నిట్యూడ్ యొక్క ప్రాతినిధ్యం ప్రతికూల మరియు సానుకూల సంఖ్యలకు సమానం-సైన్ బిట్ మాత్రమే భిన్నంగా ఉంటుంది.
        // ఫ్లోట్‌లను సంతకం చేసిన పూర్ణాంకాలుగా సులభంగా పోల్చడానికి, ప్రతికూల సంఖ్యల విషయంలో మేము ఘాతాంకం మరియు మాంటిస్సా బిట్‌లను తిప్పాలి.
        // మేము సంఖ్యలను "two's complement" రూపంలోకి సమర్థవంతంగా మారుస్తాము.
        //
        // ఫ్లిప్పింగ్ చేయడానికి, మేము దానికి వ్యతిరేకంగా ముసుగు మరియు XOR ను నిర్మిస్తాము.
        // ప్రతికూల-సంతకం చేసిన విలువల నుండి మేము "all-ones except for the sign bit" ముసుగును శాఖ లేకుండా లెక్కిస్తాము: కుడి బదిలీ పూర్ణాంకానికి సైన్-విస్తరిస్తుంది, కాబట్టి మేము ముసుగును సైన్ బిట్స్‌తో "fill" చేస్తాము, ఆపై మరో సున్నా బిట్‌ను నెట్టడానికి సంతకం చేయనిదిగా మారుస్తాము.
        //
        // సానుకూల విలువలపై, ముసుగు అన్ని సున్నాలు, కాబట్టి ఇది నో-ఆప్.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// NaN కాకపోతే విలువను ఒక నిర్దిష్ట విరామానికి పరిమితం చేయండి.
    ///
    /// `self` `max` కన్నా ఎక్కువ ఉంటే `max` మరియు `self` `min` కన్నా తక్కువ ఉంటే `min` ను అందిస్తుంది.
    /// లేకపోతే ఇది `self` ను అందిస్తుంది.
    ///
    /// ప్రారంభ విలువ NaN అయితే ఈ ఫంక్షన్ NaN ను తిరిగి ఇస్తుందని గమనించండి.
    ///
    /// # Panics
    ///
    /// `min > max`, `min` NaN, లేదా `max` NaN అయితే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}