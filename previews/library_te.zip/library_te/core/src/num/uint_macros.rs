macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// ఈ పూర్ణాంక రకం ద్వారా సూచించబడే అతిచిన్న విలువ.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// ఈ పూర్ణాంక రకం ద్వారా సూచించబడే అతిపెద్ద విలువ.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// బిట్స్‌లో ఈ పూర్ణాంక రకం పరిమాణం.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// ఇచ్చిన బేస్‌లోని స్ట్రింగ్ స్లైస్‌ను పూర్ణాంకానికి మారుస్తుంది.
        ///
        /// స్ట్రింగ్ అంకెలు తరువాత ఐచ్ఛిక `+` గుర్తుగా భావిస్తున్నారు.
        ///
        /// వైట్‌స్పేస్‌ను నడిపించడం మరియు వెనుకంజ వేయడం లోపాన్ని సూచిస్తుంది.
        /// `radix` ను బట్టి అంకెలు ఈ అక్షరాల ఉపసమితి:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// `radix` 2 నుండి 36 వరకు ఉండకపోతే ఈ ఫంక్షన్ panics.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self` యొక్క బైనరీ ప్రాతినిధ్యంలో ఉన్న వాటి సంఖ్యను చూపుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// `self` యొక్క బైనరీ ప్రాతినిధ్యంలో సున్నాల సంఖ్యను అందిస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self` యొక్క బైనరీ ప్రాతినిధ్యంలో ప్రముఖ సున్నాల సంఖ్యను అందిస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// `self` యొక్క బైనరీ ప్రాతినిధ్యంలో వెనుకంజలో ఉన్న సున్నాల సంఖ్యను అందిస్తుంది.
        ///
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// `self` యొక్క బైనరీ ప్రాతినిధ్యంలో ప్రముఖుల సంఖ్యను అందిస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// `self` యొక్క బైనరీ ప్రాతినిధ్యంలో వెనుకంజలో ఉన్నవారి సంఖ్యను చూపుతుంది.
        ///
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// కత్తిరించిన బిట్‌లను ఫలిత పూర్ణాంకం చివరికి చుట్టి, పేర్కొన్న మొత్తమైన `n` ద్వారా బిట్‌లను ఎడమ వైపుకు మారుస్తుంది.
        ///
        ///
        /// దయచేసి ఇది `<<` షిఫ్టింగ్ ఆపరేటర్ యొక్క అదే ఆపరేషన్ కాదని గమనించండి!
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// కత్తిరించిన బిట్‌లను ఫలిత పూర్ణాంకం ప్రారంభానికి చుట్టి, పేర్కొన్న మొత్తమైన `n` ద్వారా బిట్‌లను కుడి వైపుకు మారుస్తుంది.
        ///
        ///
        /// దయచేసి ఇది `>>` షిఫ్టింగ్ ఆపరేటర్ యొక్క అదే ఆపరేషన్ కాదని గమనించండి!
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// పూర్ణాంకం యొక్క బైట్ క్రమాన్ని తిరగరాస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.swap_bytes() లెట్;
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// పూర్ణాంకంలో బిట్ల క్రమాన్ని తిరగరాస్తుంది.
        /// తక్కువ ముఖ్యమైన బిట్ చాలా ముఖ్యమైన బిట్ అవుతుంది, రెండవ తక్కువ-ముఖ్యమైన బిట్ రెండవ అత్యంత ముఖ్యమైన బిట్ అవుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.reverse_bits() లెట్;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// పెద్ద పూర్ణాంకం నుండి లక్ష్యం యొక్క అంత్యక్రియకు పూర్ణాంకాన్ని మారుస్తుంది.
        ///
        /// బిగ్ ఎండియన్‌లో ఇది నో-ఆప్.
        /// చిన్న ఎండియన్‌లో బైట్లు మార్చుకుంటారు.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } లేకపోతే {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// పూర్ణాంకాన్ని చిన్న ఎండియన్ నుండి లక్ష్యం యొక్క అంతం వరకు మారుస్తుంది.
        ///
        /// చిన్న ఎండియన్‌లో ఇది నో-ఆప్.
        /// పెద్ద ఎండియన్‌లో బైట్లు మార్చుకోబడతాయి.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } లేకపోతే {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// లక్ష్యం యొక్క అంతం నుండి `self` ను పెద్ద ఎండియన్‌గా మారుస్తుంది.
        ///
        /// బిగ్ ఎండియన్‌లో ఇది నో-ఆప్.
        /// చిన్న ఎండియన్‌లో బైట్లు మార్చుకుంటారు.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // లేదా ఉండకూడదా?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// లక్ష్యం యొక్క అంతం నుండి `self` ను చిన్న ఎండియన్‌గా మారుస్తుంది.
        ///
        /// చిన్న ఎండియన్‌లో ఇది నో-ఆప్.
        /// పెద్ద ఎండియన్‌లో బైట్లు మార్చుకోబడతాయి.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// if cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// పూర్ణాంక అదనంగా తనిఖీ చేయబడింది.
        /// `self + rhs` ను లెక్కిస్తుంది, ఓవర్ఫ్లో సంభవించినట్లయితే `None` ను తిరిగి ఇస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// తనిఖీ చేయని పూర్ణాంక అదనంగా.`self + rhs` ను లెక్కిస్తుంది, ఓవర్ఫ్లో జరగదని uming హిస్తూ.
        /// ఇది ఎప్పుడు నిర్వచించబడని ప్రవర్తనకు దారితీస్తుంది
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // భద్రత: కాలర్ `unchecked_add` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// పూర్ణాంక వ్యవకలనం తనిఖీ చేయబడింది.
        /// `self - rhs` ను లెక్కిస్తుంది, ఓవర్ఫ్లో సంభవించినట్లయితే `None` ను తిరిగి ఇస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// తనిఖీ చేయని పూర్ణాంక వ్యవకలనం.`self - rhs` ను లెక్కిస్తుంది, ఓవర్ఫ్లో జరగదని uming హిస్తూ.
        /// ఇది ఎప్పుడు నిర్వచించబడని ప్రవర్తనకు దారితీస్తుంది
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // భద్రత: కాలర్ `unchecked_sub` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// పూర్ణాంక గుణకారం తనిఖీ చేయబడింది.
        /// `self * rhs` ను లెక్కిస్తుంది, ఓవర్ఫ్లో సంభవించినట్లయితే `None` ను తిరిగి ఇస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// తనిఖీ చేయని పూర్ణాంక గుణకారం.`self * rhs` ను లెక్కిస్తుంది, ఓవర్ఫ్లో జరగదని uming హిస్తూ.
        /// ఇది ఎప్పుడు నిర్వచించబడని ప్రవర్తనకు దారితీస్తుంది
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // భద్రత: కాలర్ `unchecked_mul` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// పూర్ణాంక విభజన తనిఖీ చేయబడింది.
        /// `self / rhs` ను లెక్కిస్తుంది, `rhs == 0` ఉంటే `None` ను తిరిగి ఇస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // భద్రత: సున్నా ద్వారా డివి పైన తనిఖీ చేయబడింది మరియు సంతకం చేయని రకాలు మరొకటి లేవు
                // విభజన కోసం వైఫల్య రీతులు
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// యూక్లిడియన్ విభాగాన్ని తనిఖీ చేశారు.
        /// `self.div_euclid(rhs)` ను లెక్కిస్తుంది, `rhs == 0` ఉంటే `None` ను తిరిగి ఇస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// మిగిలిన పూర్ణాంకం తనిఖీ చేయబడింది.
        /// `self % rhs` ను లెక్కిస్తుంది, `rhs == 0` ఉంటే `None` ను తిరిగి ఇస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // భద్రత: సున్నా ద్వారా డివి పైన తనిఖీ చేయబడింది మరియు సంతకం చేయని రకాలు మరొకటి లేవు
                // విభజన కోసం వైఫల్య రీతులు
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// యూక్లిడియన్ మాడ్యులో తనిఖీ చేయబడింది.
        /// `self.rem_euclid(rhs)` ను లెక్కిస్తుంది, `rhs == 0` ఉంటే `None` ను తిరిగి ఇస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// తనిఖీ చేసిన నిరాకరణ.`-self` ను లెక్కిస్తుంది, `సెల్ఫ్==తప్ప `None` ను తిరిగి ఇస్తుంది
        /// 0`.
        ///
        /// ఏదైనా సానుకూల పూర్ణాంకాన్ని తిరస్కరించడం పొంగిపొర్లుతుందని గమనించండి.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// తనిఖీ చేసిన షిఫ్ట్ ఎడమ.
        /// `self << rhs` ను లెక్కిస్తుంది, `rhs` `self` లోని బిట్ల సంఖ్య కంటే పెద్దది లేదా సమానంగా ఉంటే `None` ను తిరిగి ఇస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// షిఫ్ట్ కుడివైపు తనిఖీ చేయబడింది.
        /// `self >> rhs` ను లెక్కిస్తుంది, `rhs` `self` లోని బిట్ల సంఖ్య కంటే పెద్దది లేదా సమానంగా ఉంటే `None` ను తిరిగి ఇస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ఎక్స్పోనెన్షియేషన్ తనిఖీ చేయబడింది.
        /// `self.pow(exp)` ను లెక్కిస్తుంది, ఓవర్ఫ్లో సంభవించినట్లయితే `None` ను తిరిగి ఇస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // exp!=0 నుండి, చివరకు exp 1 ఉండాలి.
            // ఘాతాంకం యొక్క చివరి బిట్‌తో విడిగా వ్యవహరించండి, ఎందుకంటే బేస్ తరువాత స్క్వేర్ చేయడం అవసరం లేదు మరియు అనవసరమైన ఓవర్‌ఫ్లో కారణం కావచ్చు.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// పూర్ణాంక అదనంగా సంతృప్తమవుతుంది.
        /// `self + rhs` ను లెక్కిస్తుంది, పొంగి ప్రవహించే బదులు సంఖ్యా సరిహద్దుల వద్ద సంతృప్తమవుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// సంతృప్త పూర్ణాంక వ్యవకలనం.
        /// `self - rhs` ను లెక్కిస్తుంది, పొంగి ప్రవహించే బదులు సంఖ్యా సరిహద్దుల వద్ద సంతృప్తమవుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// సంతృప్త పూర్ణాంక గుణకారం.
        /// `self * rhs` ను లెక్కిస్తుంది, పొంగి ప్రవహించే బదులు సంఖ్యా సరిహద్దుల వద్ద సంతృప్తమవుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// సంతృప్త పూర్ణాంక ఘాతాంకం.
        /// `self.pow(exp)` ను లెక్కిస్తుంది, పొంగి ప్రవహించే బదులు సంఖ్యా సరిహద్దుల వద్ద సంతృప్తమవుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// (modular) అదనంగా చుట్టడం.
        /// `self + rhs` ను లెక్కిస్తుంది, రకం యొక్క సరిహద్దు వద్ద చుట్టబడుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) వ్యవకలనం చుట్టడం.
        /// `self - rhs` ను లెక్కిస్తుంది, రకం యొక్క సరిహద్దు వద్ద చుట్టబడుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) గుణకారం చుట్టడం.
        /// `self * rhs` ను లెక్కిస్తుంది, రకం యొక్క సరిహద్దు వద్ద చుట్టబడుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ఈ ఉదాహరణ పూర్ణాంక రకాల మధ్య భాగస్వామ్యం చేయబడిందని దయచేసి గమనించండి.
        /// `u8` ఇక్కడ ఎందుకు ఉపయోగించబడుతుందో ఇది వివరిస్తుంది.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) విభాగాన్ని చుట్టడం.`self / rhs` లెక్కిస్తుంది.
        /// సంతకం చేయని రకాల్లో చుట్టబడిన విభజన కేవలం సాధారణ విభజన.
        /// చుట్టడం ఎప్పుడూ జరగడానికి మార్గం లేదు.
        /// ఈ ఫంక్షన్ ఉనికిలో ఉంది, తద్వారా అన్ని ఆపరేషన్లు చుట్టడం ఆపరేషన్లలో లెక్కించబడతాయి.
        ///
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// యూక్లిడియన్ విభాగాన్ని చుట్టడం.`self.div_euclid(rhs)` లెక్కిస్తుంది.
        /// సంతకం చేయని రకాల్లో చుట్టబడిన విభజన కేవలం సాధారణ విభజన.
        /// చుట్టడం ఎప్పుడూ జరగడానికి మార్గం లేదు.
        /// ఈ ఫంక్షన్ ఉనికిలో ఉంది, తద్వారా అన్ని ఆపరేషన్లు చుట్టడం ఆపరేషన్లలో లెక్కించబడతాయి.
        /// సానుకూల పూర్ణాంకాల కోసం, విభజన యొక్క అన్ని సాధారణ నిర్వచనాలు సమానంగా ఉంటాయి కాబట్టి, ఇది ఖచ్చితంగా `self.wrapping_div(rhs)` కి సమానం.
        ///
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// (modular) మిగిలిన వాటిని చుట్టడం.`self % rhs` లెక్కిస్తుంది.
        /// సంతకం చేయని రకాల్లో మిగిలిన గణన సాధారణ మిగిలిన గణన.
        ///
        /// చుట్టడం ఎప్పుడూ జరగడానికి మార్గం లేదు.
        /// ఈ ఫంక్షన్ ఉనికిలో ఉంది, తద్వారా అన్ని ఆపరేషన్లు చుట్టడం ఆపరేషన్లలో లెక్కించబడతాయి.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// యూక్లిడియన్ మాడ్యులో చుట్టడం.`self.rem_euclid(rhs)` లెక్కిస్తుంది.
        /// సంతకం చేయని రకాల్లో చుట్టబడిన మాడ్యులో లెక్కింపు సాధారణ మిగిలిన గణన.
        /// చుట్టడం ఎప్పుడూ జరగడానికి మార్గం లేదు.
        /// ఈ ఫంక్షన్ ఉనికిలో ఉంది, తద్వారా అన్ని ఆపరేషన్లు చుట్టడం ఆపరేషన్లలో లెక్కించబడతాయి.
        /// సానుకూల పూర్ణాంకాల కోసం, విభజన యొక్క అన్ని సాధారణ నిర్వచనాలు సమానంగా ఉంటాయి కాబట్టి, ఇది ఖచ్చితంగా `self.wrapping_rem(rhs)` కి సమానం.
        ///
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// (modular) నిరాకరణను చుట్టడం.
        /// `-self` ను లెక్కిస్తుంది, రకం యొక్క సరిహద్దు వద్ద చుట్టబడుతుంది.
        ///
        /// సంతకం చేయని రకాలు ప్రతికూల సమానమైనవి కానందున, ఈ ఫంక్షన్ యొక్క అన్ని అనువర్తనాలు చుట్టబడతాయి (`-0` మినహా).
        /// సంబంధిత సంతకం చేసిన రకం గరిష్టం కంటే చిన్న విలువలకు, ఫలితం సంబంధిత సంతకం చేసిన విలువను ప్రసారం చేయడానికి సమానం.
        ///
        /// ఏదైనా పెద్ద విలువలు `MAX + 1 - (val - MAX - 1)` కి సమానం, ఇక్కడ `MAX` అనేది సంతకం చేసిన రకం యొక్క గరిష్టం.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ఈ ఉదాహరణ పూర్ణాంక రకాల మధ్య భాగస్వామ్యం చేయబడిందని దయచేసి గమనించండి.
        /// `i8` ఇక్కడ ఎందుకు ఉపయోగించబడుతుందో ఇది వివరిస్తుంది.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-ఉచిత బిట్‌వైస్ షిఫ్ట్-ఎడమ;
        /// `self << mask(rhs)` ను ఇస్తుంది, ఇక్కడ `mask` `rhs` యొక్క ఏదైనా హై-ఆర్డర్ బిట్‌లను తొలగిస్తుంది, ఇది షిఫ్ట్ రకం యొక్క బిట్‌విడ్త్‌ను మించిపోయేలా చేస్తుంది.
        ///
        /// ఇది తిరిగే-ఎడమకు సమానం కాదని గమనించండి;చుట్టే షిఫ్ట్-లెఫ్ట్ యొక్క RHS రకం పరిధికి పరిమితం చేయబడింది, LHS నుండి మార్చబడిన బిట్స్ మరొక చివరకి తిరిగి ఇవ్వబడవు.
        /// ఆదిమ పూర్ణాంక రకాలు అన్నీ [`rotate_left`](Self::rotate_left) ఫంక్షన్‌ను అమలు చేస్తాయి, బదులుగా మీకు కావలసినది కావచ్చు.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // భద్రత: రకం యొక్క బిట్‌సైజ్ ద్వారా మాస్కింగ్ మేము మారకుండా చూస్తుంది
            // హద్దులు దాటింది
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-ఉచిత బిట్‌వైస్ షిఫ్ట్-కుడి;
        /// `self >> mask(rhs)` ను ఇస్తుంది, ఇక్కడ `mask` `rhs` యొక్క ఏదైనా హై-ఆర్డర్ బిట్‌లను తొలగిస్తుంది, ఇది షిఫ్ట్ రకం యొక్క బిట్‌విడ్త్‌ను మించిపోయేలా చేస్తుంది.
        ///
        /// ఇది రొటేట్-రైట్ వలె *కాదు* అని గమనించండి;చుట్టడం షిఫ్ట్-రైట్ యొక్క RHS రకం యొక్క పరిధికి పరిమితం చేయబడింది, LHS నుండి మార్చబడిన బిట్స్ మరొక చివరకి తిరిగి ఇవ్వబడవు.
        /// ఆదిమ పూర్ణాంక రకాలు అన్నీ [`rotate_right`](Self::rotate_right) ఫంక్షన్‌ను అమలు చేస్తాయి, బదులుగా మీకు కావలసినది కావచ్చు.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // భద్రత: రకం యొక్క బిట్‌సైజ్ ద్వారా మాస్కింగ్ మేము మారకుండా చూస్తుంది
            // హద్దులు దాటింది
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) ఎక్స్పోనెన్షియేషన్ చుట్టడం.
        /// `self.pow(exp)` ను లెక్కిస్తుంది, రకం యొక్క సరిహద్దు వద్ద చుట్టబడుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp!=0 నుండి, చివరకు exp 1 ఉండాలి.
            // ఘాతాంకం యొక్క చివరి బిట్‌తో విడిగా వ్యవహరించండి, ఎందుకంటే బేస్ తరువాత స్క్వేర్ చేయడం అవసరం లేదు మరియు అనవసరమైన ఓవర్‌ఫ్లో కారణం కావచ్చు.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` ను లెక్కిస్తుంది
        ///
        /// అంకగణిత ఓవర్ఫ్లో సంభవిస్తుందో లేదో సూచించే బూలియన్‌తో పాటు అదనంగా ఒక రెట్టింపును అందిస్తుంది.
        /// ఒక ఓవర్ఫ్లో జరిగి ఉంటే అప్పుడు చుట్టిన విలువ తిరిగి ఇవ్వబడుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` ను లెక్కిస్తుంది
        ///
        /// అంకగణిత ఓవర్ఫ్లో సంభవిస్తుందో లేదో సూచించే బూలియన్‌తో పాటు వ్యవకలనం యొక్క టుపుల్‌ను అందిస్తుంది.
        /// ఒక ఓవర్ఫ్లో జరిగి ఉంటే అప్పుడు చుట్టిన విలువ తిరిగి ఇవ్వబడుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` మరియు `rhs` యొక్క గుణకారం లెక్కిస్తుంది.
        ///
        /// అంకగణిత ఓవర్ఫ్లో సంభవిస్తుందో లేదో సూచించే బూలియన్‌తో పాటు గుణకారం యొక్క టుపుల్‌ను అందిస్తుంది.
        /// ఒక ఓవర్ఫ్లో జరిగి ఉంటే అప్పుడు చుట్టిన విలువ తిరిగి ఇవ్వబడుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ఈ ఉదాహరణ పూర్ణాంక రకాల మధ్య భాగస్వామ్యం చేయబడిందని దయచేసి గమనించండి.
        /// `u32` ఇక్కడ ఎందుకు ఉపయోగించబడుతుందో ఇది వివరిస్తుంది.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` ను `rhs` ద్వారా విభజించినప్పుడు విభజనను లెక్కిస్తుంది.
        ///
        /// అంకగణిత ఓవర్ఫ్లో సంభవిస్తుందో లేదో సూచించే బూలియన్‌తో పాటు డివైజర్ యొక్క టుపుల్‌ను అందిస్తుంది.
        /// సంతకం చేయని పూర్ణాంకాల కోసం ఓవర్ఫ్లో ఎప్పుడూ జరగదు, కాబట్టి రెండవ విలువ ఎల్లప్పుడూ `false`.
        ///
        /// # Panics
        ///
        /// `rhs` 0 అయితే ఈ ఫంక్షన్ panic అవుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// యూక్లిడియన్ డివిజన్ `self.div_euclid(rhs)` యొక్క పరిమాణాన్ని లెక్కిస్తుంది.
        ///
        /// అంకగణిత ఓవర్ఫ్లో సంభవిస్తుందో లేదో సూచించే బూలియన్‌తో పాటు డివైజర్ యొక్క టుపుల్‌ను అందిస్తుంది.
        /// సంతకం చేయని పూర్ణాంకాల కోసం ఓవర్ఫ్లో ఎప్పుడూ జరగదు, కాబట్టి రెండవ విలువ ఎల్లప్పుడూ `false`.
        /// సానుకూల పూర్ణాంకాల కోసం, విభజన యొక్క అన్ని సాధారణ నిర్వచనాలు సమానంగా ఉంటాయి కాబట్టి, ఇది ఖచ్చితంగా `self.overflowing_div(rhs)` కి సమానం.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 అయితే ఈ ఫంక్షన్ panic అవుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// `self` ను `rhs` చే విభజించినప్పుడు మిగిలినదాన్ని లెక్కిస్తుంది.
        ///
        /// అంకగణిత ఓవర్ఫ్లో సంభవిస్తుందో లేదో సూచించే బూలియన్తో పాటు విభజించిన తరువాత మిగిలిన మొత్తాన్ని అందిస్తుంది.
        /// సంతకం చేయని పూర్ణాంకాల కోసం ఓవర్ఫ్లో ఎప్పుడూ జరగదు, కాబట్టి రెండవ విలువ ఎల్లప్పుడూ `false`.
        ///
        /// # Panics
        ///
        /// `rhs` 0 అయితే ఈ ఫంక్షన్ panic అవుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// మిగిలిన `self.rem_euclid(rhs)` ను యూక్లిడియన్ డివిజన్ ద్వారా లెక్కిస్తుంది.
        ///
        /// అంకగణిత ఓవర్ఫ్లో సంభవిస్తుందో లేదో సూచించే బూలియన్తో పాటు విభజించిన తరువాత మాడ్యులో యొక్క టుపుల్ను అందిస్తుంది.
        /// సంతకం చేయని పూర్ణాంకాల కోసం ఓవర్ఫ్లో ఎప్పుడూ జరగదు, కాబట్టి రెండవ విలువ ఎల్లప్పుడూ `false`.
        /// సానుకూల పూర్ణాంకాల కోసం, విభజన యొక్క అన్ని సాధారణ నిర్వచనాలు సమానంగా ఉంటాయి కాబట్టి, ఈ ఆపరేషన్ ఖచ్చితంగా `self.overflowing_rem(rhs)` కి సమానం.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 అయితే ఈ ఫంక్షన్ panic అవుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// పొంగిపొర్లుతున్న పద్ధతిలో నేనే నెగెట్స్.
        ///
        /// ఈ సంతకం చేయని విలువ యొక్క తిరస్కరణను సూచించే విలువను తిరిగి ఇవ్వడానికి చుట్టడం ఆపరేషన్లను ఉపయోగించి `!self + 1` ను అందిస్తుంది.
        /// సానుకూల సంతకం చేయని విలువల కోసం ఓవర్‌ఫ్లో ఎల్లప్పుడూ సంభవిస్తుందని గమనించండి, కానీ 0 ని తిరస్కరించడం పొంగి ప్రవహించదు.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// `rhs` బిట్స్ ద్వారా ఎడమవైపుకు మారుతుంది.
        ///
        /// షిఫ్ట్ విలువ బిట్స్ సంఖ్య కంటే పెద్దదా లేదా సమానంగా ఉందో సూచించే బూలియన్‌తో పాటు స్వీయ యొక్క షిఫ్ట్ వెర్షన్ యొక్క టుపుల్‌ను అందిస్తుంది.
        /// షిఫ్ట్ విలువ చాలా పెద్దది అయితే, విలువ (N-1) ను ముసుగు చేస్తుంది, ఇక్కడ N అనేది బిట్ల సంఖ్య, మరియు ఈ విలువ షిఫ్ట్ చేయడానికి ఉపయోగించబడుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// `rhs` బిట్స్ ద్వారా స్వీయ హక్కును మారుస్తుంది.
        ///
        /// షిఫ్ట్ విలువ బిట్స్ సంఖ్య కంటే పెద్దదా లేదా సమానంగా ఉందో సూచించే బూలియన్‌తో పాటు స్వీయ యొక్క షిఫ్ట్ వెర్షన్ యొక్క టుపుల్‌ను అందిస్తుంది.
        /// షిఫ్ట్ విలువ చాలా పెద్దది అయితే, విలువ (N-1) ను ముసుగు చేస్తుంది, ఇక్కడ N అనేది బిట్ల సంఖ్య, మరియు ఈ విలువ షిఫ్ట్ చేయడానికి ఉపయోగించబడుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// స్క్వేర్ చేయడం ద్వారా ఘాతాంకాన్ని ఉపయోగించి, `exp` యొక్క శక్తికి స్వీయతను పెంచుతుంది.
        ///
        /// ఓవర్‌ఫ్లో జరిగిందో లేదో సూచించే bool తో పాటు ఎక్స్‌పోనెన్షియేషన్ యొక్క టుపుల్‌ను అందిస్తుంది.
        ///
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, నిజం));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // ఓవర్ఫ్లోయింగ్_ముల్ ఫలితాలను నిల్వ చేయడానికి స్థలాన్ని స్క్రాచ్ చేయండి.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp!=0 నుండి, చివరకు exp 1 ఉండాలి.
            // ఘాతాంకం యొక్క చివరి బిట్‌తో విడిగా వ్యవహరించండి, ఎందుకంటే బేస్ తరువాత స్క్వేర్ చేయడం అవసరం లేదు మరియు అనవసరమైన ఓవర్‌ఫ్లో కారణం కావచ్చు.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// స్క్వేర్ చేయడం ద్వారా ఘాతాంకాన్ని ఉపయోగించి, `exp` యొక్క శక్తికి స్వీయతను పెంచుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp!=0 నుండి, చివరకు exp 1 ఉండాలి.
            // ఘాతాంకం యొక్క చివరి బిట్‌తో విడిగా వ్యవహరించండి, ఎందుకంటే బేస్ తరువాత స్క్వేర్ చేయడం అవసరం లేదు మరియు అనవసరమైన ఓవర్‌ఫ్లో కారణం కావచ్చు.
            //
            //
            acc * base
        }

        /// యూక్లిడియన్ విభాగాన్ని నిర్వహిస్తుంది.
        ///
        /// సానుకూల పూర్ణాంకాల కోసం, విభజన యొక్క అన్ని సాధారణ నిర్వచనాలు సమానంగా ఉంటాయి కాబట్టి, ఇది ఖచ్చితంగా `self / rhs` కి సమానం.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 అయితే ఈ ఫంక్షన్ panic అవుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// `self (mod rhs)` యొక్క మిగిలిన భాగాన్ని లెక్కిస్తుంది.
        ///
        /// సానుకూల పూర్ణాంకాల కోసం, విభజన యొక్క అన్ని సాధారణ నిర్వచనాలు సమానంగా ఉంటాయి కాబట్టి, ఇది ఖచ్చితంగా `self % rhs` కి సమానం.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 అయితే ఈ ఫంక్షన్ panic అవుతుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// కొన్ని `k` కోసం `self == 2^k` ఉంటే మాత్రమే `true` ను అందిస్తుంది.
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // రెండు తదుపరి శక్తి కంటే ఒకటి తక్కువ అందిస్తుంది.
        // (8u8 కోసం రెండు యొక్క తదుపరి శక్తి 8u8 మరియు 6u8 కి ఇది 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // ఈ పద్ధతి ఓవర్‌ఫ్లో కాదు, `next_power_of_two` ఓవర్‌ఫ్లో సందర్భాల్లో ఇది బదులుగా రకం యొక్క గరిష్ట విలువను తిరిగి ఇస్తుంది మరియు 0 కి 0 తిరిగి ఇవ్వగలదు.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // భద్రత: ఎందుకంటే `p > 0`, ఇది పూర్తిగా ప్రముఖ సున్నాలను కలిగి ఉండదు.
            // అంటే షిఫ్ట్ ఎల్లప్పుడూ సరిహద్దులో ఉంటుంది మరియు వాదన సున్నా కానిప్పుడు కొన్ని ప్రాసెసర్లు (ఇంటెల్ ప్రీ-హాస్‌వెల్ వంటివి) మరింత సమర్థవంతమైన ctlz అంతర్గతాలను కలిగి ఉంటాయి.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// `self` కంటే ఎక్కువ లేదా సమానమైన రెండు యొక్క చిన్న శక్తిని అందిస్తుంది.
        ///
        /// రిటర్న్ వాల్యూ ఓవర్ఫ్లోస్ (అనగా, టైప్ `uN` కోసం `self > (1 << (N-1))`), ఇది డీబగ్ మోడ్‌లో panics మరియు రిటర్న్ వాల్యూ రిలీజ్ మోడ్‌లో 0 కి చుట్టబడి ఉంటుంది (పద్ధతి 0 ను తిరిగి ఇవ్వగల ఏకైక పరిస్థితి).
        ///
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// `n` కంటే ఎక్కువ లేదా సమానమైన రెండు యొక్క చిన్న శక్తిని అందిస్తుంది.
        /// రెండు యొక్క తదుపరి శక్తి రకం యొక్క గరిష్ట విలువ కంటే ఎక్కువగా ఉంటే, `None` తిరిగి ఇవ్వబడుతుంది, లేకపోతే రెండు యొక్క శక్తి `Some` లో చుట్టబడుతుంది.
        ///
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// `n` కంటే ఎక్కువ లేదా సమానమైన రెండు యొక్క చిన్న శక్తిని అందిస్తుంది.
        /// రెండు యొక్క తదుపరి శక్తి రకం యొక్క గరిష్ట విలువ కంటే ఎక్కువగా ఉంటే, తిరిగి వచ్చే విలువ `0` కు చుట్టబడుతుంది.
        ///
        ///
        /// # Examples
        ///
        /// ప్రాథమిక వినియోగం:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// బిగ్-ఎండియన్ (network) బైట్ క్రమంలో ఈ పూర్ణాంకం యొక్క మెమరీ ప్రాతినిధ్యాన్ని బైట్ శ్రేణిగా తిరిగి ఇవ్వండి.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// ఈ పూర్ణాంకం యొక్క మెమరీ ప్రాతినిధ్యాన్ని చిన్న-ఎండియన్ బైట్ క్రమంలో బైట్ శ్రేణిగా తిరిగి ఇవ్వండి.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// ఈ పూర్ణాంకం యొక్క మెమరీ ప్రాతినిధ్యాన్ని స్థానిక బైట్ క్రమంలో బైట్ శ్రేణిగా తిరిగి ఇవ్వండి.
        ///
        /// టార్గెట్ ప్లాట్‌ఫాం యొక్క స్థానిక ఎండియెన్స్ ఉపయోగించబడుతున్నందున, పోర్టబుల్ కోడ్ బదులుగా, తగినట్లుగా, [`to_be_bytes`] లేదా [`to_le_bytes`] ను ఉపయోగించాలి.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     బైట్లు, ఉంటే cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } లేకపోతే {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // భద్రత: పూర్ణాంకాలు సాదా పాత డేటాటైప్‌లు కాబట్టి మనం ఎల్లప్పుడూ చేయగలము
        // వాటిని బైట్ల శ్రేణులకు మార్చండి
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // భద్రత: పూర్ణాంకాలు సాదా పాత డేటాటైప్‌లు కాబట్టి మేము వాటిని ఎల్లప్పుడూ మార్చగలము
            // బైట్ల శ్రేణులు
            unsafe { mem::transmute(self) }
        }

        /// ఈ పూర్ణాంకం యొక్క మెమరీ ప్రాతినిధ్యాన్ని స్థానిక బైట్ క్రమంలో బైట్ శ్రేణిగా తిరిగి ఇవ్వండి.
        ///
        ///
        /// [`to_ne_bytes`] వీలైనప్పుడల్లా దీనికి ప్రాధాన్యత ఇవ్వాలి.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// బైట్లు= num.as_ne_bytes();
        /// assert_eq!(
        ///     బైట్లు, ఉంటే cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } లేకపోతే {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // భద్రత: పూర్ణాంకాలు సాదా పాత డేటాటైప్‌లు కాబట్టి మేము వాటిని ఎల్లప్పుడూ మార్చగలము
            // బైట్ల శ్రేణులు
            unsafe { &*(self as *const Self as *const _) }
        }

        /// పెద్ద ఎండియన్‌లో బైట్ శ్రేణిగా దాని ప్రాతినిధ్యం నుండి స్థానిక ఎండియన్ పూర్ణాంక విలువను సృష్టించండి.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ఉపయోగించండి;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ఇన్పుట్=విశ్రాంతి;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// చిన్న ఎండియన్‌లో బైట్ శ్రేణిగా దాని ప్రాతినిధ్యం నుండి స్థానిక ఎండియన్ పూర్ణాంక విలువను సృష్టించండి.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ఉపయోగించండి;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ఇన్పుట్=విశ్రాంతి;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// స్థానిక ఎండియన్నెస్‌లో బైట్ అర్రేగా దాని మెమరీ ప్రాతినిధ్యం నుండి స్థానిక ఎండియన్ పూర్ణాంక విలువను సృష్టించండి.
        ///
        /// టార్గెట్ ప్లాట్‌ఫాం యొక్క స్థానిక ఎండియెన్స్ ఉపయోగించబడుతున్నందున, పోర్టబుల్ కోడ్ బదులుగా తగినట్లుగా [`from_be_bytes`] లేదా [`from_le_bytes`] ను ఉపయోగించాలనుకుంటుంది.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } లేకపోతే {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ఉపయోగించండి;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ఇన్పుట్=విశ్రాంతి;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // భద్రత: పూర్ణాంకాలు సాదా పాత డేటాటైప్‌లు కాబట్టి మనం ఎల్లప్పుడూ చేయగలము
        // వారికి రూపాంతరం చెందండి
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // భద్రత: పూర్ణాంకాలు సాదా పాత డేటాటైప్‌లు కాబట్టి మేము వాటికి ఎల్లప్పుడూ రూపాంతరం చెందుతాము
            unsafe { mem::transmute(bytes) }
        }

        /// క్రొత్త కోడ్ ఉపయోగించడానికి ఇష్టపడాలి
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// ఈ పూర్ణాంక రకం ద్వారా సూచించబడే అతిచిన్న విలువను చూపుతుంది.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// క్రొత్త కోడ్ ఉపయోగించడానికి ఇష్టపడాలి
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// ఈ పూర్ణాంక రకం ద్వారా సూచించబడే అతిపెద్ద విలువను చూపుతుంది.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}