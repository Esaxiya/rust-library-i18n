//! సమగ్ర రకాలుగా మార్చడానికి లోపం రకాలు.

use crate::convert::Infallible;
use crate::fmt;

/// తనిఖీ చేసిన సమగ్ర రకం మార్పిడి విఫలమైనప్పుడు లోపం రకం తిరిగి వచ్చింది.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // `Infallible` `!` కు మారుపేరుగా మారినప్పుడు పైన ఉన్న `From<Infallible> for TryFromIntError` వంటి కోడ్ పని చేస్తూనే ఉందని నిర్ధారించుకోవడానికి బలవంతం కాకుండా మ్యాచ్ చేయండి.
        //
        //
        match never {}
    }
}

/// పూర్ణాంకాన్ని అన్వయించేటప్పుడు తిరిగి ఇవ్వగల లోపం.
///
/// ఈ లోపం [`i8::from_str_radix`] వంటి ఆదిమ పూర్ణాంక రకాల్లోని `from_str_radix()` ఫంక్షన్లకు లోపం రకంగా ఉపయోగించబడుతుంది.
///
/// # సంభావ్య కారణాలు
///
/// ఇతర కారణాలలో, `ParseIntError` స్ట్రింగ్‌లో వైట్‌స్పేస్‌ను ప్రముఖంగా లేదా వెనుకంజలో ఉంచడం వలన విసిరివేయవచ్చు, ఉదా., ప్రామాణిక ఇన్‌పుట్ నుండి పొందినప్పుడు.
///
/// [`str::trim()`] పద్ధతిని ఉపయోగించడం వలన పార్సింగ్ చేయడానికి ముందు ఖాళీ స్థలం ఉండదని నిర్ధారిస్తుంది.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// పూర్ణాంకం అన్వయించడం విఫలమయ్యే వివిధ రకాల లోపాలను నిల్వ చేయడానికి ఎనుమ్.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// అన్వయించబడిన విలువ ఖాళీగా ఉంది.
    ///
    /// ఇతర కారణాలలో, ఖాళీ స్ట్రింగ్‌ను అన్వయించేటప్పుడు ఈ వేరియంట్ నిర్మించబడుతుంది.
    Empty,
    /// దాని సందర్భంలో చెల్లని అంకెను కలిగి ఉంటుంది.
    ///
    /// ఇతర కారణాలలో, ASCII కాని చార్‌ను కలిగి ఉన్న స్ట్రింగ్‌ను పార్స్ చేసేటప్పుడు ఈ వేరియంట్ నిర్మించబడుతుంది.
    ///
    /// ఒక `+` లేదా `-` ఒక స్ట్రింగ్‌లో దాని స్వంతంగా లేదా సంఖ్య మధ్యలో తప్పుగా ఉంచినప్పుడు కూడా ఈ వేరియంట్ నిర్మించబడుతుంది.
    ///
    ///
    InvalidDigit,
    /// లక్ష్య పూర్ణాంక రకంలో నిల్వ చేయడానికి పూర్ణాంకం చాలా పెద్దది.
    PosOverflow,
    /// లక్ష్య పూర్ణాంక రకంలో నిల్వ చేయడానికి పూర్ణాంకం చాలా చిన్నది.
    NegOverflow,
    /// విలువ జీరో
    ///
    /// పార్సింగ్ స్ట్రింగ్ సున్నా విలువను కలిగి ఉన్నప్పుడు ఈ వేరియంట్ విడుదల అవుతుంది, ఇది సున్నా కాని రకానికి చట్టవిరుద్ధం.
    ///
    Zero,
}

impl ParseIntError {
    /// పూర్ణాంకం పార్స్ అవ్వడానికి వివరణాత్మక కారణాన్ని అందిస్తుంది.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}