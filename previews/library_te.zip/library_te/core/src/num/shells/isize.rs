//! పాయింటర్-పరిమాణ సంతకం చేసిన పూర్ణాంక రకం కోసం స్థిరాంకాలు.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! క్రొత్త కోడ్ అనుబంధ స్థిరాంకాలను నేరుగా ఆదిమ రకంలో ఉపయోగించాలి.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }