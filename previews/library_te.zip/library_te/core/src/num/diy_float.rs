//! అంతర్గత ఉపయోగం కోసం మాత్రమే విస్తరించిన ఖచ్చితత్వం "soft float".

// ఈ మాడ్యూల్ dec2flt మరియు flt2dec లకు మాత్రమే, మరియు కోరెట్టెస్ కారణంగా మాత్రమే పబ్లిక్.
// ఇది ఎప్పుడూ స్థిరీకరించబడటానికి ఉద్దేశించినది కాదు.
#![doc(hidden)]
#![unstable(
    feature = "core_private_diy_float",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

/// కస్టమ్ 64-బిట్ ఫ్లోటింగ్ పాయింట్ రకం, ఇది `f * 2^e` ను సూచిస్తుంది.
#[derive(Copy, Clone, Debug)]
#[doc(hidden)]
pub struct Fp {
    /// పూర్ణాంక మాంటిస్సా.
    pub f: u64,
    /// బేస్ 2 లోని ఘాతాంకం.
    pub e: i16,
}

impl Fp {
    /// సరిగ్గా మరియు `other` యొక్క సరిగ్గా గుండ్రని ఉత్పత్తిని అందిస్తుంది.
    pub fn mul(&self, other: &Fp) -> Fp {
        const MASK: u64 = 0xffffffff;
        let a = self.f >> 32;
        let b = self.f & MASK;
        let c = other.f >> 32;
        let d = other.f & MASK;
        let ac = a * c;
        let bc = b * c;
        let ad = a * d;
        let bd = b * d;
        let tmp = (bd >> 32) + (ad & MASK) + (bc & MASK) + (1 << 31) /* round */;
        let f = ac + (ad >> 32) + (bc >> 32) + (tmp >> 32);
        let e = self.e + other.e + 64;
        Fp { f, e }
    }

    /// ఫలితంగా మాంటిస్సా కనీసం `2^63` గా ఉంటుంది.
    pub fn normalize(&self) -> Fp {
        let mut f = self.f;
        let mut e = self.e;
        if f >> (64 - 32) == 0 {
            f <<= 32;
            e -= 32;
        }
        if f >> (64 - 16) == 0 {
            f <<= 16;
            e -= 16;
        }
        if f >> (64 - 8) == 0 {
            f <<= 8;
            e -= 8;
        }
        if f >> (64 - 4) == 0 {
            f <<= 4;
            e -= 4;
        }
        if f >> (64 - 2) == 0 {
            f <<= 2;
            e -= 2;
        }
        if f >> (64 - 1) == 0 {
            f <<= 1;
            e -= 1;
        }
        debug_assert!(f >= (1 >> 63));
        Fp { f, e }
    }

    /// షేర్డ్ ఎక్స్‌పోనెంట్‌ను కలిగి ఉండటానికి సాధారణీకరిస్తుంది.
    /// ఇది ఘాతాంకాన్ని మాత్రమే తగ్గిస్తుంది (అందువలన మాంటిస్సాను పెంచుతుంది).
    pub fn normalize_to(&self, e: i16) -> Fp {
        let edelta = self.e - e;
        assert!(edelta >= 0);
        let edelta = edelta as usize;
        assert_eq!(self.f << edelta >> edelta, self.f);
        Fp { f: self.f << edelta, e }
    }
}