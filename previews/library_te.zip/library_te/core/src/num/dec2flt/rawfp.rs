//! సానుకూల IEEE 754 ఫ్లోట్లలో బిట్ ఫిడ్లింగ్.ప్రతికూల సంఖ్యలు లేవు మరియు నిర్వహించాల్సిన అవసరం లేదు.
//! సాధారణ ఫ్లోటింగ్ పాయింట్ సంఖ్యలు కానానికల్ ప్రాతినిధ్యాన్ని (frac, exp) కలిగి ఉంటాయి, అంటే విలువ 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), ఇక్కడ N అనేది బిట్ల సంఖ్య.
//!
//! సబ్‌నార్మల్స్ కొద్దిగా భిన్నంగా మరియు విచిత్రంగా ఉంటాయి, కానీ అదే సూత్రం వర్తిస్తుంది.
//!
//! అయితే, ఇక్కడ మనం వాటిని f పాజిటివ్‌తో (సిగ్, కె) సూచిస్తాము, అంటే విలువ f *
//! 2 <sup>ఇ</sup> ."hidden bit" ను స్పష్టంగా తయారు చేయడంతో పాటు, ఇది మాంటిస్సా షిఫ్ట్ అని పిలవబడే ఘాతాంకాన్ని మారుస్తుంది.
//!
//! మరొక మార్గం చెప్పండి, సాధారణంగా ఫ్లోట్లు (1) గా వ్రాయబడతాయి కాని ఇక్కడ అవి (2) గా వ్రాయబడతాయి:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! మేము (1) ని **పాక్షిక ప్రాతినిధ్యం** మరియు (2) ను **సమగ్ర ప్రాతినిధ్యం** అని పిలుస్తాము.
//!
//! ఈ మాడ్యూల్‌లోని చాలా విధులు సాధారణ సంఖ్యలను మాత్రమే నిర్వహిస్తాయి.Dec2flt నిత్యకృత్యాలు సాంప్రదాయికంగా చాలా తక్కువ మరియు చాలా పెద్ద సంఖ్యలో సార్వత్రికంగా సరైన నెమ్మదిగా (అల్గోరిథం M) తీసుకుంటాయి.
//! ఆ అల్గోరిథంకు next_float() మాత్రమే అవసరం, ఇది సబ్‌నార్మల్స్ మరియు సున్నాలను నిర్వహిస్తుంది.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32` మరియు `f64` కోసం అన్ని మార్పిడి కోడ్లను ప్రాథమికంగా నకిలీ చేయకుండా ఉండటానికి ఒక సహాయకుడు trait.
///
/// ఇది ఎందుకు అవసరమో పేరెంట్ మాడ్యూల్ యొక్క డాక్ వ్యాఖ్య చూడండి.
///
/// **ఎప్పుడూ** ఇతర రకాల కోసం అమలు చేయకూడదు లేదా dec2flt మాడ్యూల్ వెలుపల ఉపయోగించాలి.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits` మరియు `from_bits` ఉపయోగించే రకం.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// పూర్ణాంకానికి ముడి రూపాంతరం చేస్తుంది.
    fn to_bits(self) -> Self::Bits;

    /// పూర్ణాంకం నుండి ముడి పరివర్తనను చేస్తుంది.
    fn from_bits(v: Self::Bits) -> Self;

    /// ఈ సంఖ్య పరిధిలోకి వచ్చే వర్గాన్ని చూపుతుంది.
    fn classify(self) -> FpCategory;

    /// మాంటిస్సా, ఘాతాంకం మరియు పూర్ణాంకాలగా సంతకం చేస్తుంది.
    fn integer_decode(self) -> (u64, i16, i8);

    /// ఫ్లోట్ డీకోడ్.
    fn unpack(self) -> Unpacked;

    /// ఖచ్చితంగా సూచించగల చిన్న పూర్ణాంకం నుండి ప్రసారం.
    /// Panic పూర్ణాంకానికి ప్రాతినిధ్యం వహించలేకపోతే, ఈ మాడ్యూల్‌లోని ఇతర కోడ్ ఎప్పుడూ అలా జరగకుండా చూస్తుంది.
    fn from_int(x: u64) -> Self;

    /// ప్రీ-కంప్యూటెడ్ టేబుల్ నుండి 10 <sup>ఇ</sup> విలువను పొందుతుంది.
    /// `e >= CEIL_LOG5_OF_MAX_SIG` కోసం Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// పేరు ఏమి చెబుతుంది.
    /// అంతర్గత విషయాలను గారడీ చేయడం మరియు LLVM స్థిరంగా మడవటం ఆశించడం కంటే హార్డ్ కోడ్ చేయడం సులభం.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // ఓవర్ఫ్లో లేదా సున్నా లేదా ఉత్పత్తి చేయలేని ఇన్పుట్ల దశాంశ అంకెలపై సంప్రదాయవాది
    /// subnormals.బహుశా గరిష్ట సాధారణ విలువ యొక్క దశాంశ ఘాతాంకం, అందుకే పేరు.
    const MAX_NORMAL_DIGITS: usize;

    /// చాలా ముఖ్యమైన దశాంశ అంకె కంటే ఎక్కువ స్థల విలువ ఉన్నప్పుడు, ఈ సంఖ్య ఖచ్చితంగా అనంతం వరకు గుండ్రంగా ఉంటుంది.
    ///
    const INF_CUTOFF: i64;

    /// చాలా ముఖ్యమైన దశాంశ అంకెకు దీని కంటే తక్కువ స్థల విలువ ఉన్నప్పుడు, సంఖ్య ఖచ్చితంగా సున్నాకి గుండ్రంగా ఉంటుంది.
    ///
    const ZERO_CUTOFF: i64;

    /// ఘాతాంకంలో బిట్ల సంఖ్య.
    const EXP_BITS: u8;

    /// ముఖ్యమైన బిట్స్ సంఖ్య, దాచిన బిట్‌తో సహా * సహా.
    const SIG_BITS: u8;

    /// ముఖ్యమైన బిట్స్ సంఖ్య, దాచిన బిట్‌ను మినహాయించి *.
    const EXPLICIT_SIG_BITS: u8;

    /// పాక్షిక ప్రాతినిధ్యంలో గరిష్ట చట్టపరమైన ఘాతాంకం.
    const MAX_EXP: i16;

    /// పాక్షిక ప్రాతినిధ్యంలో కనీస చట్టపరమైన ఘాతాంకం, సబ్‌నార్మల్స్‌ను మినహాయించి.
    const MIN_EXP: i16;

    /// `MAX_EXP` సమగ్ర ప్రాతినిధ్యం కోసం, అనగా, షిఫ్ట్ వర్తించబడుతుంది.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` ఎన్కోడ్ చేయబడింది (అనగా, ఆఫ్‌సెట్ పక్షపాతంతో)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` సమగ్ర ప్రాతినిధ్యం కోసం, అనగా, షిఫ్ట్ వర్తించబడుతుంది.
    const MIN_EXP_INT: i16;

    /// సమగ్ర ప్రాతినిధ్యంలో గరిష్ట సాధారణీకరణ ప్రాముఖ్యత.
    const MAX_SIG: u64;

    /// సమగ్ర ప్రాతినిధ్యంలో కనీస సాధారణీకరించిన ప్రాముఖ్యత.
    const MIN_SIG: u64;
}

// ఎక్కువగా #34344 కోసం ఒక ప్రత్యామ్నాయం.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// మాంటిస్సా, ఘాతాంకం మరియు పూర్ణాంకాలగా సంతకం చేస్తుంది.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // ఘాతాంక పక్షపాతం + మాంటిస్సా షిఫ్ట్
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // అన్ని ప్లాట్‌ఫామ్‌లలో `as` రౌండ్లు సరిగ్గా ఉన్నాయా అని rkruppe అనిశ్చితంగా ఉంది.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// మాంటిస్సా, ఘాతాంకం మరియు పూర్ణాంకాలగా సంతకం చేస్తుంది.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // ఘాతాంక పక్షపాతం + మాంటిస్సా షిఫ్ట్
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // అన్ని ప్లాట్‌ఫామ్‌లలో `as` రౌండ్లు సరిగ్గా ఉన్నాయా అని rkruppe అనిశ్చితంగా ఉంది.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` ను సమీప మెషిన్ ఫ్లోట్ రకానికి మారుస్తుంది.
/// అసాధారణ ఫలితాలను నిర్వహించదు.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 బిట్, కాబట్టి xe కి 63 యొక్క మాంటిస్సా షిఫ్ట్ ఉంది
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64-బిట్ ప్రాముఖ్యతను T::SIG_BITS బిట్‌లకు సగం నుండి సమానంగా రౌండ్ చేయండి.
/// ఘాతాంక ఓవర్‌ఫ్లోను నిర్వహించదు.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // మాంటిస్సా షిఫ్ట్ సర్దుబాటు చేయండి
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// సాధారణ సంఖ్యల కోసం `RawFloat::unpack()` యొక్క విలోమం.
/// ప్రాముఖ్యత లేదా ఘాతాంకం సాధారణీకరించిన సంఖ్యలకు చెల్లుబాటు కాకపోతే Panics.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // దాచిన బిట్‌ను తొలగించండి
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // ఘాతాంక పక్షపాతం మరియు మాంటిస్సా షిఫ్ట్ కోసం ఘాతాంకాన్ని సర్దుబాటు చేయండి
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // సైన్ బిట్‌ను 0 ("+") వద్ద వదిలివేయండి, మా సంఖ్యలు అన్నీ సానుకూలంగా ఉంటాయి
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// సబ్‌నార్మల్‌ను నిర్మించండి.0 యొక్క మాంటిస్సా అనుమతించబడుతుంది మరియు సున్నాని నిర్మిస్తుంది.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // ఎన్కోడ్ చేసిన ఘాతాంకం 0, సైన్ బిట్ 0, కాబట్టి మనం బిట్లను తిరిగి అర్థం చేసుకోవాలి.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Fp తో బిగ్నమ్ను సుమారుగా అంచనా వేయండి.0.5 ULP లో సగం నుండి సమానమైన రౌండ్లు.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // మేము `start` సూచికకు ముందు అన్ని బిట్లను కత్తిరించాము, అనగా, మేము `start` మొత్తంతో సమర్థవంతంగా కుడి-షిఫ్ట్ చేస్తాము, కాబట్టి ఇది మనకు అవసరమైన ఘాతాంకం కూడా.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // కత్తిరించిన బిట్‌లను బట్టి రౌండ్ (half-to-even).
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// అతిపెద్ద ఫ్లోటింగ్ పాయింట్ సంఖ్యను ఆర్గ్యుమెంట్ కంటే ఖచ్చితంగా చిన్నదిగా కనుగొంటుంది.
/// సబ్‌నార్మల్స్, సున్నా లేదా ఎక్స్‌పోనెంట్ అండర్ ఫ్లోను నిర్వహించదు.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// వాదన కంటే ఖచ్చితంగా పెద్దదైన తేలియాడే పాయింట్ సంఖ్యను కనుగొనండి.
// ఈ ఆపరేషన్ సంతృప్తమవుతుంది, అనగా, next_float(inf) ==inf.
// ఈ మాడ్యూల్‌లోని చాలా కోడ్ మాదిరిగా కాకుండా, ఈ ఫంక్షన్ సున్నా, సబ్‌నార్మల్స్ మరియు అనంతాలను నిర్వహిస్తుంది.
// అయితే, ఇక్కడ ఉన్న అన్ని ఇతర కోడ్ల మాదిరిగా, ఇది NaN మరియు ప్రతికూల సంఖ్యలతో వ్యవహరించదు.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // ఇది నిజమని చాలా మంచిది అనిపిస్తుంది, కానీ ఇది పనిచేస్తుంది.
        // 0.0 ఆల్-జీరో పదంగా ఎన్కోడ్ చేయబడింది.సబ్‌నార్మల్స్ 0x000 మీ ... m ఇక్కడ m అనేది మాంటిస్సా.
        // ముఖ్యంగా, అతి చిన్న సబ్‌నార్మల్ 0x0 ... 01 మరియు అతిపెద్దది 0x000F ... F.
        // అతి చిన్న సాధారణ సంఖ్య 0x0010 ... 0, కాబట్టి ఈ మూలలో కేసు కూడా పనిచేస్తుంది.
        // ఇంక్రిమెంట్ మాంటిస్సాను పొంగిపొర్లుతుంటే, క్యారీ బిట్ మనకు కావలసిన విధంగా ఘాతాంకాన్ని పెంచుతుంది మరియు మాంటిస్సా బిట్స్ సున్నా అవుతాయి.
        // దాచిన బిట్ సమావేశం కారణంగా, ఇది కూడా మనకు కావాల్సినది!
        // చివరగా, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}