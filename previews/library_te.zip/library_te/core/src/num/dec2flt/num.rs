//! బిగ్నమ్‌ల కోసం యుటిలిటీ ఫంక్షన్‌లు పద్ధతులుగా మారడానికి ఎక్కువ అర్ధమే లేదు.

// పరిష్కరించండి ఈ మాడ్యూల్ పేరు కొంచెం దురదృష్టకరం, ఎందుకంటే ఇతర గుణకాలు కూడా `core::num` ను దిగుమతి చేస్తాయి.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// `ones_place` కన్నా తక్కువ ప్రాముఖ్యత కలిగిన అన్ని బిట్‌లను కత్తిరించడం సాపేక్ష దోషాన్ని 0.5 ULP కన్నా తక్కువ, సమానమైన లేదా అంతకంటే ఎక్కువ పరిచయం చేస్తుందో లేదో పరీక్షించండి.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // మిగిలిన అన్ని బిట్స్ సున్నా అయితే, అది= 0.5 ULP, లేకపోతే> 0.5 ఎక్కువ బిట్స్ లేకపోతే (సగం_బిట్==0), దిగువ కూడా సరిగ్గా సమానంగా తిరిగి వస్తుంది.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// దశాంశ అంకెలను మాత్రమే కలిగి ఉన్న ASCII స్ట్రింగ్‌ను `u64` గా మారుస్తుంది.
///
/// ఓవర్‌ఫ్లో లేదా చెల్లని అక్షరాల కోసం తనిఖీలు చేయదు, కాబట్టి కాలర్ జాగ్రత్తగా లేకపోతే, ఫలితం బోగస్ మరియు panic (ఇది `unsafe` కానప్పటికీ) చేయవచ్చు.
/// అదనంగా, ఖాళీ తీగలను సున్నాగా పరిగణిస్తారు.
/// ఎందుకంటే ఈ ఫంక్షన్ ఉంది
///
/// 1. `&[u8]` లో `FromStr` ను ఉపయోగించటానికి `from_utf8_unchecked` అవసరం, ఇది చెడ్డది మరియు
/// 2. `integral.parse()` మరియు `fractional.parse()` ఫలితాలను కలిపి ఈ మొత్తం ఫంక్షన్ కంటే క్లిష్టంగా ఉంటుంది.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// ASCII అంకెల స్ట్రింగ్‌ను బిగ్నమ్‌గా మారుస్తుంది.
///
/// `from_str_unchecked` వలె, ఈ ఫంక్షన్ అంకెలు కాని వాటిని కలుపుకోవడానికి పార్సర్‌పై ఆధారపడుతుంది.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// ఒక బిగ్నమ్‌ను 64 బిట్ పూర్ణాంకంగా విప్పండి.సంఖ్య చాలా పెద్దదిగా ఉంటే Panics.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// బిట్స్ పరిధిని సంగ్రహిస్తుంది.

/// ఇండెక్స్ 0 తక్కువ ముఖ్యమైన బిట్ మరియు పరిధి యథావిధిగా సగం తెరిచి ఉంటుంది.
/// రిటర్న్ రకానికి సరిపోయే దానికంటే ఎక్కువ బిట్‌లను తీయమని అడిగితే Panics.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}