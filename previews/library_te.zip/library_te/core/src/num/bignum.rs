//! అనుకూల ఏకపక్ష-ఖచ్చితమైన సంఖ్య (bignum) అమలు.
//!
//! స్టాక్ మెమరీ ఖర్చుతో కుప్ప కేటాయింపును నివారించడానికి ఇది రూపొందించబడింది.
//! ఎక్కువగా ఉపయోగించిన బిగ్నమ్ రకం, `Big32x40`, 32 × 40=1,280 బిట్స్ ద్వారా పరిమితం చేయబడింది మరియు స్టాక్ మెమరీ యొక్క 160 బైట్ల వద్ద పడుతుంది.
//! అన్ని పరిమిత `f64` విలువలను రౌండ్-ట్రిప్పింగ్ చేయడానికి ఇది సరిపోతుంది.
//!
//! సూత్రప్రాయంగా వేర్వేరు ఇన్‌పుట్‌ల కోసం బహుళ బిగ్నమ్ రకాలను కలిగి ఉండటం సాధ్యమే, కాని కోడ్ ఉబ్బరాన్ని నివారించడానికి మేము అలా చేయము.
//!
//! ప్రతి బిగ్నమ్ వాస్తవ ఉపయోగాల కోసం ఇప్పటికీ ట్రాక్ చేయబడుతుంది, కాబట్టి ఇది సాధారణంగా పట్టింపు లేదు.
//!

// ఈ మాడ్యూల్ dec2flt మరియు flt2dec లకు మాత్రమే, మరియు కోరెట్టెస్ కారణంగా మాత్రమే పబ్లిక్.
// ఇది ఎప్పుడూ స్థిరీకరించబడటానికి ఉద్దేశించినది కాదు.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// బిగ్నమ్స్ అవసరమైన అంకగణిత ఆపరేషన్లు.
pub trait FullOps: Sized {
    /// `(carry', v')` అంటే `carry' * 2^W + v' = self + other + carry` ను అందిస్తుంది, ఇక్కడ `W` అనేది `Self` లోని బిట్ల సంఖ్య.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `(carry', v')` అంటే `carry'*2^W + v' = self* other + carry` ను అందిస్తుంది, ఇక్కడ `W` అనేది `Self` లోని బిట్ల సంఖ్య.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(carry', v')` అంటే `carry'*2^W + v' = self* other + other2 + carry` ను అందిస్తుంది, ఇక్కడ `W` అనేది `Self` లోని బిట్ల సంఖ్య.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `borrow *2^W + self = quo* other + rem` మరియు `0 <= rem < other` వంటి `(quo, rem)` ను అందిస్తుంది, ఇక్కడ `W` అనేది `Self` లోని బిట్ల సంఖ్య.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // ఇది పొంగి ప్రవహించదు;అవుట్పుట్ `0` మరియు `2 * 2^nbits - 1` మధ్య ఉంటుంది.
                    // FIXME: ఎల్‌ఎల్‌విఎం దీన్ని ఎడిసి లేదా ఆప్టిమైజ్ చేస్తుందా?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // ఇది పొంగి ప్రవహించదు;
                    // అవుట్పుట్ `0` మరియు `2^nbits * (2^nbits - 1)` మధ్య ఉంటుంది.
                    // FIXME: ఎల్‌ఎల్‌విఎం దీన్ని ఎడిసి లేదా ఆప్టిమైజ్ చేస్తుందా?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // ఇది పొంగి ప్రవహించదు;
                    // అవుట్పుట్ `0` మరియు `2^nbits * (2^nbits - 1)` మధ్య ఉంటుంది.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // ఇది పొంగి ప్రవహించదు;అవుట్పుట్ `0` మరియు `other * (2^nbits - 1)` మధ్య ఉంటుంది.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // దీన్ని ప్రారంభించడానికి RFC #521 చూడండి.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// అంకెలలో ప్రాతినిధ్యం వహించే 5 శక్తుల పట్టిక.ప్రత్యేకంగా, అతిపెద్ద {u8, u16, u32} విలువ ఐదు శక్తితో పాటు సంబంధిత ఘాతాంకం.
/// `mul_pow5` లో వాడతారు.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// స్టాక్-కేటాయించిన ఏకపక్ష-ఖచ్చితత్వం (నిర్దిష్ట పరిమితి వరకు) పూర్ణాంకం.
        ///
        /// ఇచ్చిన రకం ("digit") యొక్క స్థిర-పరిమాణ శ్రేణి దీనికి మద్దతు ఇస్తుంది.
        /// శ్రేణి చాలా పెద్దది కానప్పటికీ (సాధారణంగా కొన్ని వందల బైట్లు), నిర్లక్ష్యంగా కాపీ చేయడం వల్ల పనితీరు దెబ్బతింటుంది.
        ///
        /// అందువలన ఇది ఉద్దేశపూర్వకంగా `Copy` కాదు.
        ///
        /// ఓవర్ఫ్లోస్ విషయంలో బిగ్నమ్స్ panic కు అన్ని ఆపరేషన్లు అందుబాటులో ఉన్నాయి.
        /// తగినంత పెద్ద బిగ్నమ్ రకాలను ఉపయోగించడానికి కాలర్ బాధ్యత వహిస్తాడు.
        pub struct $name {
            /// వాన్ ప్లస్ వాడుకలో ఉన్న గరిష్ట "digit" కు ఆఫ్‌సెట్.
            /// ఇది తగ్గదు, కాబట్టి గణన క్రమం గురించి తెలుసుకోండి.
            /// `base[size..]` సున్నాగా ఉండాలి.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` `a + b *2^W + c* 2^(2W) + ...` ను సూచిస్తుంది, ఇక్కడ `W` అనేది అంకెల రకంలోని బిట్ల సంఖ్య.
            base: [$ty; $n],
        }

        impl $name {
            /// ఒక అంకె నుండి బిగ్నమ్ చేస్తుంది.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// `u64` విలువ నుండి బిగ్నమ్ చేస్తుంది.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// అంతర్గత అంకెలను స్లైస్ `[a, b, c, ...]` గా అందిస్తుంది, అంటే సంఖ్యా విలువ `a + b *2^W + c* 2^(2W) + ...`, ఇక్కడ `W` అనేది అంకెల రకంలోని బిట్ల సంఖ్య.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// `I`-th బిట్‌ను అందిస్తుంది, ఇక్కడ బిట్ 0 తక్కువ ముఖ్యమైనది.
            /// మరో మాటలో చెప్పాలంటే, బరువు `2^i` తో బిట్.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// బిగ్నమ్ సున్నా అయితే `true` ని అందిస్తుంది.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// ఈ విలువను సూచించడానికి అవసరమైన బిట్ల సంఖ్యను చూపుతుంది.
            /// సున్నాకి 0 బిట్స్ అవసరమని గమనించండి.
            pub fn bit_length(&self) -> usize {
                // సున్నా అయిన చాలా ముఖ్యమైన అంకెలను దాటవేయండి.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // సున్నా కాని అంకెలు లేవు, అనగా సంఖ్య సున్నా.
                    return 0;
                }
                // ఇది leading_zeros() మరియు బిట్ షిఫ్ట్‌లతో ఆప్టిమైజ్ చేయబడవచ్చు, కాని అది బహుశా ఇబ్బందికి విలువైనది కాదు.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// `other` ను స్వయంగా జోడిస్తుంది మరియు దాని స్వంత మ్యూటబుల్ రిఫరెన్స్‌ను అందిస్తుంది.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// `other` ను దాని నుండి తీసివేసి, దాని స్వంత మ్యూటబుల్ రిఫరెన్స్‌ను తిరిగి ఇస్తుంది.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// అంకెల-పరిమాణ `other` ద్వారా గుణించాలి మరియు దాని స్వంత మ్యూటబుల్ రిఫరెన్స్‌ను అందిస్తుంది.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// `2^bits` చేత గుణించబడుతుంది మరియు దాని స్వంత మ్యూటబుల్ రిఫరెన్స్‌ను అందిస్తుంది.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // `digits * digitbits` బిట్స్ ద్వారా మార్చండి
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // `bits` బిట్స్ ద్వారా మార్చండి
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. అంకెలు] సున్నా, మారవలసిన అవసరం లేదు
                }

                self.size = sz;
                self
            }

            /// `5^e` చేత గుణించబడుతుంది మరియు దాని స్వంత మ్యూటబుల్ రిఫరెన్స్‌ను అందిస్తుంది.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // 2 ^ n లో సరిగ్గా n వెనుకంజలో ఉన్న సున్నాలు ఉన్నాయి, మరియు సంబంధిత అంకెల పరిమాణాలు వరుసగా రెండు శక్తులు మాత్రమే, కాబట్టి ఇది పట్టికకు బాగా సరిపోయే సూచిక.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // సాధ్యమైనంత ఎక్కువ అతిపెద్ద సింగిల్ డిజిట్ శక్తితో గుణించండి ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... ఆపై మిగిలినవి పూర్తి చేయండి.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` వివరించిన సంఖ్యతో స్వయంగా గుణించాలి (ఇక్కడ `W` అనేది అంకెల రకంలోని బిట్ల సంఖ్య) మరియు దాని స్వంత మ్యూటబుల్ రిఫరెన్స్‌ను అందిస్తుంది.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // అంతర్గత దినచర్య.aa.len() <= bb.len() ఉన్నప్పుడు ఉత్తమంగా పనిచేస్తుంది.
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// అంకెల-పరిమాణ `other` ద్వారా విభజించి, దాని స్వంత మ్యూటబుల్ రిఫరెన్స్‌ను తిరిగి ఇస్తుంది *మరియు* మిగిలినది.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// మరొక బిగ్నమ్ ద్వారా సెల్ఫ్‌ను విభజించండి, `q` ను కోటియెంట్‌తో మరియు `r` ను మిగిలిన వాటితో ఓవర్రైట్ చేస్తుంది.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // స్టుపిడ్ స్లో base-2 లాంగ్ డివిజన్ నుండి తీసుకోబడింది
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME లాంగ్ డివిజన్ కోసం ఎక్కువ బేస్ ($ty) ను ఉపయోగిస్తుంది.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Q యొక్క బిట్ `i` ను 1 కు సెట్ చేయండి.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// `Big32x40` కోసం అంకెల రకం.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// ఇది పరీక్ష కోసం మాత్రమే ఉపయోగించబడుతుంది.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}