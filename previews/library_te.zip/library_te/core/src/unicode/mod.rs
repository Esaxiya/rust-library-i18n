#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// [Unicode](http://www.unicode.org/) యొక్క సంస్కరణ `char` మరియు `str` పద్ధతుల యొక్క యూనికోడ్ భాగాలపై ఆధారపడి ఉంటుంది.
///
/// యూనికోడ్ యొక్క క్రొత్త సంస్కరణలు క్రమం తప్పకుండా విడుదల చేయబడతాయి మరియు తరువాత యూనికోడ్‌ను బట్టి ప్రామాణిక లైబ్రరీలోని అన్ని పద్ధతులు నవీకరించబడతాయి.
/// అందువల్ల కొన్ని `char` మరియు `str` పద్ధతుల ప్రవర్తన మరియు ఈ స్థిరమైన విలువ కాలక్రమేణా మారుతుంది.
/// ఇది బ్రేకింగ్ మార్పుగా పరిగణించబడదు.
///
/// వెర్షన్ నంబరింగ్ పథకం [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) లో వివరించబడింది.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Liballoc లో ఉపయోగం కోసం, libstd లో తిరిగి ఎగుమతి చేయబడలేదు.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;