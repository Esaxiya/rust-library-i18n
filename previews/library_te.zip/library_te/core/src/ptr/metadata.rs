#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// ఏదైనా పాయింటెడ్-టు రకం యొక్క పాయింటర్ మెటాడేటా రకాన్ని అందిస్తుంది.
///
/// # పాయింటర్ మెటాడేటా
///
/// Rust లోని రా పాయింటర్ రకాలు మరియు రిఫరెన్స్ రకాలను రెండు భాగాలుగా చేసినట్లు భావించవచ్చు:
/// విలువ యొక్క మెమరీ చిరునామా మరియు కొన్ని మెటాడేటాను కలిగి ఉన్న డేటా పాయింటర్.
///
/// గణాంక-పరిమాణ రకాలు (`Sized` traits ను అమలు చేసేవి) మరియు `extern` రకాలు కోసం, పాయింటర్లు `సన్నని` అని చెబుతారు: మెటాడేటా సున్నా-పరిమాణం మరియు దాని రకం `()`.
///
///
/// [dynamically-sized types][dst] కు పాయింటర్లు `విస్తృత` లేదా `కొవ్వు` అని చెబుతారు, అవి సున్నా-పరిమాణ మెటాడేటాను కలిగి ఉంటాయి:
///
/// * చివరి ఫీల్డ్ DST అయిన స్ట్రక్ట్‌ల కోసం, మెటాడేటా చివరి ఫీల్డ్‌కు మెటాడేటా
/// * `str` రకం కోసం, మెటాడేటా `usize` గా బైట్లలో పొడవు
/// * `[T]` వంటి స్లైస్ రకాల కోసం, మెటాడేటా అనేది `usize` వంటి అంశాల పొడవు
/// * `dyn SomeTrait` వంటి trait వస్తువులకు, మెటాడేటా [`DynMetadata<Self>`][DynMetadata] (ఉదా. `DynMetadata<dyn SomeTrait>`)
///
/// future లో, Rust భాష వేర్వేరు పాయింటర్ మెటాడేటాను కలిగి ఉన్న కొత్త రకాల రకాలను పొందవచ్చు.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// ఈ trait యొక్క పాయింట్ దాని `Metadata` అనుబంధ రకం, ఇది పైన వివరించిన విధంగా `()` లేదా `usize` లేదా `DynMetadata<_>`.
/// ఇది ప్రతి రకానికి స్వయంచాలకంగా అమలు చేయబడుతుంది.
/// సంబంధిత పరిమితి లేకుండా కూడా ఇది సాధారణ సందర్భంలో అమలు చేయబడుతుందని భావించవచ్చు.
///
/// # Usage
///
/// ముడి పాయింటర్లను వాటి [`to_raw_parts`] పద్ధతిలో డేటా చిరునామా మరియు మెటాడేటా భాగాలుగా కుళ్ళిపోవచ్చు.
///
/// ప్రత్యామ్నాయంగా, [`metadata`] ఫంక్షన్‌తో మెటాడేటాను మాత్రమే సేకరించవచ్చు.
/// ఒక సూచనను [`metadata`] కు పంపవచ్చు మరియు అవ్యక్తంగా బలవంతం చేయవచ్చు.
///
/// (possibly-wide) పాయింటర్‌ను దాని చిరునామా మరియు మెటాడేటా నుండి [`from_raw_parts`] లేదా [`from_raw_parts_mut`] తో తిరిగి ఉంచవచ్చు.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// పాయింటర్లలో మెటాడేటా కోసం రకం మరియు `Self` కు సూచనలు.
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata` లో trait bounds ను ఉంచండి
    //
    // `library/core/src/ptr/metadata.rs` లో ఇక్కడ ఉన్న వారితో సమకాలీకరించండి:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// ఈ trait అలియాస్‌ను అమలు చేసే రకాలను సూచించేవారు `సన్నగా` ఉంటారు.
///
/// ఇందులో స్టాటిక్‌లీ-సైజ్డ్` రకాలు మరియు ఎక్స్‌00 ఎక్స్ రకాలు ఉన్నాయి.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait మారుపేర్లు భాషలో స్థిరంగా ఉండటానికి ముందు దీన్ని స్థిరీకరించవద్దు?
pub trait Thin = Pointee<Metadata = ()>;

/// పాయింటర్ యొక్క మెటాడేటా భాగాన్ని సంగ్రహించండి.
///
/// `*mut T`, `&T`, లేదా `&mut T` రకం విలువలు ఈ ఫంక్షన్‌కు నేరుగా `* const T` కు బలవంతం అవుతాయి.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // భద్రత: `PtrRepr` యూనియన్ నుండి విలువను యాక్సెస్ చేయడం * const T నుండి సురక్షితం
    // మరియు PtrComponents<T>ఒకే మెమరీ లేఅవుట్‌లను కలిగి ఉంటాయి.
    // std మాత్రమే ఈ హామీని ఇవ్వగలదు.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// డేటా చిరునామా మరియు మెటాడేటా నుండి (possibly-wide) ముడి పాయింటర్‌ను రూపొందిస్తుంది.
///
/// ఈ ఫంక్షన్ సురక్షితం కాని తిరిగి వచ్చిన పాయింటర్ డీరెఫరెన్స్‌కు సురక్షితం కాదు.
/// ముక్కల కోసం, భద్రతా అవసరాల కోసం [`slice::from_raw_parts`] యొక్క డాక్యుమెంటేషన్ చూడండి.
/// trait వస్తువుల కోసం, మెటాడేటా ఒక పాయింటర్ నుండి అదే అంతర్లీన ఎరేజ్డ్ రకానికి రావాలి.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // భద్రత: `PtrRepr` యూనియన్ నుండి విలువను యాక్సెస్ చేయడం * const T నుండి సురక్షితం
    // మరియు PtrComponents<T>ఒకే మెమరీ లేఅవుట్‌లను కలిగి ఉంటాయి.
    // std మాత్రమే ఈ హామీని ఇవ్వగలదు.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// ముడి `*const` పాయింటర్‌కు విరుద్ధంగా, ముడి `* mut` పాయింటర్ తిరిగి ఇవ్వబడితే తప్ప, [`from_raw_parts`] వలె అదే కార్యాచరణను చేస్తుంది.
///
///
/// మరిన్ని వివరాల కోసం [`from_raw_parts`] యొక్క డాక్యుమెంటేషన్ చూడండి.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // భద్రత: `PtrRepr` యూనియన్ నుండి విలువను యాక్సెస్ చేయడం * const T నుండి సురక్షితం
    // మరియు PtrComponents<T>ఒకే మెమరీ లేఅవుట్‌లను కలిగి ఉంటాయి.
    // std మాత్రమే ఈ హామీని ఇవ్వగలదు.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` బౌండ్‌ను నివారించడానికి మాన్యువల్ ఇంప్ల్ అవసరం.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` బౌండ్‌ను నివారించడానికి మాన్యువల్ ఇంప్ల్ అవసరం.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait ఆబ్జెక్ట్ రకం కోసం మెటాడేటా.
///
/// ఇది trait ఆబ్జెక్ట్ లోపల నిల్వ చేయబడిన కాంక్రీట్ రకాన్ని మార్చటానికి అవసరమైన అన్ని సమాచారాన్ని సూచించే vtable (వర్చువల్ కాల్ టేబుల్) కు పాయింటర్.
/// Vtable ముఖ్యంగా ఇందులో ఉంది:
///
/// * రకం పరిమాణం
/// * టైప్ అలైన్‌మెంట్
/// * రకం యొక్క `drop_in_place` impl కు పాయింటర్ (సాదా-పాత-డేటాకు నో-ఆప్ కావచ్చు)
/// * trait యొక్క రకాన్ని అమలు చేయడానికి అన్ని పద్ధతులకు పాయింటర్లు
///
/// మొదటి మూడు ప్రత్యేకమైనవి అని గమనించండి ఎందుకంటే అవి ఏదైనా trait వస్తువును కేటాయించడం, వదలడం మరియు డీలోకేట్ చేయడం అవసరం.
///
/// `dyn` trait ఆబ్జెక్ట్ (ఉదాహరణకు `DynMetadata<u64>`) కాని టైప్ పరామితితో ఈ స్ట్రక్ట్‌కు పేరు పెట్టడం సాధ్యమే కాని ఆ struct యొక్క అర్ధవంతమైన విలువను పొందలేము.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// అన్ని vtables యొక్క సాధారణ ఉపసర్గ.ఇది trait పద్ధతుల కోసం ఫంక్షన్ పాయింటర్లను అనుసరిస్తుంది.
///
/// `DynMetadata::size_of` మొదలైనవి యొక్క ప్రైవేట్ అమలు వివరాలు.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// ఈ vtable తో అనుబంధించబడిన రకం పరిమాణాన్ని చూపుతుంది.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// ఈ vtable తో అనుబంధించబడిన రకం యొక్క అమరికను అందిస్తుంది.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// పరిమాణం మరియు అమరికను కలిసి `Layout` గా అందిస్తుంది
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // భద్రత: కంపైలర్ కాంక్రీట్ Rust రకం కోసం ఈ vtable ను విడుదల చేస్తుంది
        // చెల్లుబాటు అయ్యే లేఅవుట్ ఉన్నట్లు తెలిసింది.`Layout::for_value` లో వలె అదే హేతుబద్ధత.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` హద్దులను నివారించడానికి మాన్యువల్ ఇంప్ల్స్ అవసరం.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}