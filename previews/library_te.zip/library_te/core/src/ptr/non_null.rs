use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` కాని సున్నా కాని మరియు కోవిరియంట్.
///
/// ముడి పాయింటర్లను ఉపయోగించి డేటా నిర్మాణాలను నిర్మించేటప్పుడు ఇది తరచుగా సరైన విషయం, కానీ చివరికి దాని అదనపు లక్షణాల కారణంగా ఉపయోగించడం మరింత ప్రమాదకరం.మీరు `NonNull<T>` ను ఉపయోగించాలో మీకు తెలియకపోతే, `*mut T` ను ఉపయోగించండి!
///
/// `*mut T` మాదిరిగా కాకుండా, పాయింటర్ ఎప్పుడూ డీఫరెన్స్‌చేయకపోయినా, పాయింటర్ ఎల్లప్పుడూ శూన్యంగా ఉండాలి.ఎనుమ్స్ ఈ నిషేధించబడిన విలువను వివక్షతగా ఉపయోగించుకోవచ్చు-`Option<NonNull<T>>` `* mut T` వలె ఉంటుంది.
/// అయినప్పటికీ, పాయింటర్ నిర్దేశించబడకపోతే ఇంకా చిక్కుకోవచ్చు.
///
/// `*mut T` కాకుండా, `NonNull<T>` ను `T` కన్నా కోవిరియంట్‌గా ఎంచుకున్నారు.ఇది కోవిరియంట్ రకాలను నిర్మించేటప్పుడు `NonNull<T>` ను ఉపయోగించడం సాధ్యం చేస్తుంది, అయితే వాస్తవానికి కోవియారిట్ కాకూడని రకంలో ఉపయోగించినట్లయితే అస్పష్టత యొక్క ప్రమాదాన్ని పరిచయం చేస్తుంది.
/// (సాంకేతికంగా అసురక్షితత అసురక్షిత ఫంక్షన్లను పిలవడం ద్వారా మాత్రమే సంభవించినప్పటికీ, `*mut T` కోసం వ్యతిరేక ఎంపిక జరిగింది.)
///
/// `Box`, `Rc`, `Arc`, `Vec` మరియు `LinkedList` వంటి చాలా సురక్షితమైన సంగ్రహణలకు కోవియారిన్స్ సరైనది.Rust యొక్క సాధారణ భాగస్వామ్య XOR మ్యూటబుల్ నియమాలను అనుసరించే పబ్లిక్ API ని వారు అందిస్తున్నందున ఇది జరుగుతుంది.
///
/// మీ రకం సురక్షితంగా సమైక్యంగా ఉండలేకపోతే, మార్పును అందించడానికి ఇది కొన్ని అదనపు ఫీల్డ్‌ను కలిగి ఉందని మీరు నిర్ధారించుకోవాలి.తరచుగా ఈ ఫీల్డ్ `PhantomData<Cell<T>>` లేదా `PhantomData<&'a mut T>` వంటి [`PhantomData`] రకం అవుతుంది.
///
/// X002 కోసం `NonNull<T>` కి `From` ఉదాహరణ ఉందని గమనించండి.ఏది ఏమయినప్పటికీ, [`UnsafeCell<T>`] లోపల మ్యుటేషన్ జరగకపోతే తప్ప, (ఎ నుండి పొందిన పాయింటర్) షేర్డ్ రిఫరెన్స్ ద్వారా మార్చడం నిర్వచించబడని ప్రవర్తన.భాగస్వామ్య సూచన నుండి మార్చగల సూచనను సృష్టించడానికి అదే జరుగుతుంది.
///
/// `UnsafeCell<T>` లేకుండా ఈ `From` ఉదాహరణను ఉపయోగిస్తున్నప్పుడు, `as_mut` ఎప్పటికీ పిలువబడదని మరియు `as_ptr` మ్యుటేషన్ కోసం ఉపయోగించబడదని నిర్ధారించుకోవడం మీ బాధ్యత.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` పాయింటర్లు `Send` కాదు ఎందుకంటే అవి సూచించే డేటా మారుపేరు కావచ్చు.
// NB, ఈ impl అనవసరం, కానీ మంచి దోష సందేశాలను అందించాలి.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` పాయింటర్లు `Sync` కాదు ఎందుకంటే అవి సూచించే డేటా మారుపేరు కావచ్చు.
// NB, ఈ impl అనవసరం, కానీ మంచి దోష సందేశాలను అందించాలి.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// క్రొత్త `NonNull` ను సృష్టిస్తుంది, అది డాంగ్లింగ్, కానీ బాగా సమలేఖనం చేయబడింది.
    ///
    /// `Vec::new` మాదిరిగా సోమరితనం కేటాయించే రకాలను ప్రారంభించడానికి ఇది ఉపయోగపడుతుంది.
    ///
    /// పాయింటర్ విలువ `T` కు చెల్లుబాటు అయ్యే పాయింటర్‌ను సూచించవచ్చని గమనించండి, అంటే ఇది "not yet initialized" సెంటినెల్ విలువగా ఉపయోగించరాదు.
    /// సోమరితనం కేటాయించే రకాలు కొన్ని ఇతర మార్గాల ద్వారా ప్రారంభాన్ని ట్రాక్ చేయాలి.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // భద్రత: mem::align_of() సున్నా కాని వినియోగాన్ని తిరిగి ఇస్తుంది, తరువాత అది ప్రసారం చేయబడుతుంది
        // to a * mut T.
        // అందువల్ల, `ptr` శూన్యమైనది కాదు మరియు new_unchecked() కి కాల్ చేయడానికి షరతులు గౌరవించబడతాయి.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// విలువకు భాగస్వామ్య సూచనలను అందిస్తుంది.[`as_ref`] కి విరుద్ధంగా, విలువను ప్రారంభించాల్సిన అవసరం లేదు.
    ///
    /// మ్యూటబుల్ కౌంటర్ కోసం [`as_uninit_mut`] చూడండి.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// ఈ పద్ధతిని పిలిచేటప్పుడు, కిందివన్నీ నిజమని మీరు నిర్ధారించుకోవాలి:
    ///
    /// * పాయింటర్ సరిగ్గా సమలేఖనం చేయాలి.
    ///
    /// * ఇది [the module documentation] లో నిర్వచించిన అర్థంలో "dereferencable" అయి ఉండాలి.
    ///
    /// * మీరు తిరిగి Rust యొక్క మారుపేరు నియమాలను అమలు చేయాలి, ఎందుకంటే తిరిగి వచ్చిన జీవితకాలం `'a` ఏకపక్షంగా ఎన్నుకోబడుతుంది మరియు డేటా యొక్క వాస్తవ జీవితకాలం ప్రతిబింబించదు.
    ///
    ///   ప్రత్యేకించి, ఈ జీవితకాలం కోసం, పాయింటర్ సూచించే మెమరీ పరివర్తన చెందకూడదు (`UnsafeCell` లోపల తప్ప).
    ///
    /// ఈ పద్ధతి యొక్క ఫలితం ఉపయోగించబడనప్పటికీ ఇది వర్తిస్తుంది!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // భద్రత: `self` అన్నింటినీ కలుస్తుందని కాలర్ హామీ ఇవ్వాలి
        // సూచన కోసం అవసరాలు.
        unsafe { &*self.cast().as_ptr() }
    }

    /// విలువకు ప్రత్యేకమైన సూచనలను అందిస్తుంది.[`as_mut`] కి విరుద్ధంగా, విలువను ప్రారంభించాల్సిన అవసరం లేదు.
    ///
    /// భాగస్వామ్య ప్రతిరూపం కోసం [`as_uninit_ref`] చూడండి.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// ఈ పద్ధతిని పిలిచేటప్పుడు, కిందివన్నీ నిజమని మీరు నిర్ధారించుకోవాలి:
    ///
    /// * పాయింటర్ సరిగ్గా సమలేఖనం చేయాలి.
    ///
    /// * ఇది [the module documentation] లో నిర్వచించిన అర్థంలో "dereferencable" అయి ఉండాలి.
    ///
    /// * మీరు తిరిగి Rust యొక్క మారుపేరు నియమాలను అమలు చేయాలి, ఎందుకంటే తిరిగి వచ్చిన జీవితకాలం `'a` ఏకపక్షంగా ఎన్నుకోబడుతుంది మరియు డేటా యొక్క వాస్తవ జీవితకాలం ప్రతిబింబించదు.
    ///
    ///   ప్రత్యేకించి, ఈ జీవితకాలం కోసం, పాయింటర్ సూచించే మెమరీ ఏ ఇతర పాయింటర్ ద్వారా అయినా యాక్సెస్ చేయకూడదు (చదవడం లేదా వ్రాయడం).
    ///
    /// ఈ పద్ధతి యొక్క ఫలితం ఉపయోగించబడనప్పటికీ ఇది వర్తిస్తుంది!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // భద్రత: `self` అన్నింటినీ కలుస్తుందని కాలర్ హామీ ఇవ్వాలి
        // సూచన కోసం అవసరాలు.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// క్రొత్త `NonNull` ను సృష్టిస్తుంది.
    ///
    /// # Safety
    ///
    /// `ptr` శూన్యంగా ఉండాలి.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // భద్రత: కాలర్ `ptr` శూన్యమైనది కాదని హామీ ఇవ్వాలి.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` శూన్యంగా లేకపోతే కొత్త `NonNull` ను సృష్టిస్తుంది.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // భద్రత: పాయింటర్ ఇప్పటికే తనిఖీ చేయబడింది మరియు శూన్యంగా లేదు
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// ముడి `*const` పాయింటర్‌కు విరుద్ధంగా, `NonNull` పాయింటర్ తిరిగి ఇవ్వబడితే తప్ప, [`std::ptr::from_raw_parts`] వలె అదే కార్యాచరణను చేస్తుంది.
    ///
    ///
    /// మరిన్ని వివరాల కోసం [`std::ptr::from_raw_parts`] యొక్క డాక్యుమెంటేషన్ చూడండి.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // భద్రత: `ptr::from::raw_parts_mut` యొక్క ఫలితం శూన్యమైనది ఎందుకంటే `data_address`.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// చిరునామా మరియు మెటాడేటా భాగాలుగా (బహుశా విస్తృత) పాయింటర్‌ను విడదీయండి.
    ///
    /// పాయింటర్ తరువాత [`NonNull::from_raw_parts`] తో పునర్నిర్మించవచ్చు.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// అంతర్లీన `*mut` పాయింటర్‌ను పొందుతుంది.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// విలువకు భాగస్వామ్య సూచనను అందిస్తుంది.విలువ ప్రారంభించబడకపోతే, బదులుగా [`as_uninit_ref`] ఉపయోగించాలి.
    ///
    /// మ్యూటబుల్ కౌంటర్ కోసం [`as_mut`] చూడండి.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// ఈ పద్ధతిని పిలిచేటప్పుడు, కిందివన్నీ నిజమని మీరు నిర్ధారించుకోవాలి:
    ///
    /// * పాయింటర్ సరిగ్గా సమలేఖనం చేయాలి.
    ///
    /// * ఇది [the module documentation] లో నిర్వచించిన అర్థంలో "dereferencable" అయి ఉండాలి.
    ///
    /// * పాయింటర్ `T` యొక్క ప్రారంభించిన ఉదాహరణకి సూచించాలి.
    ///
    /// * మీరు తిరిగి Rust యొక్క మారుపేరు నియమాలను అమలు చేయాలి, ఎందుకంటే తిరిగి వచ్చిన జీవితకాలం `'a` ఏకపక్షంగా ఎన్నుకోబడుతుంది మరియు డేటా యొక్క వాస్తవ జీవితకాలం ప్రతిబింబించదు.
    ///
    ///   ప్రత్యేకించి, ఈ జీవితకాలం కోసం, పాయింటర్ సూచించే మెమరీ పరివర్తన చెందకూడదు (`UnsafeCell` లోపల తప్ప).
    ///
    /// ఈ పద్ధతి యొక్క ఫలితం ఉపయోగించబడనప్పటికీ ఇది వర్తిస్తుంది!
    /// (ప్రారంభించబడటం గురించి భాగం ఇంకా పూర్తిగా నిర్ణయించబడలేదు, కానీ అది అయ్యేవరకు, అవి నిజంగా ప్రారంభించబడిందని నిర్ధారించుకోవడం మాత్రమే సురక్షితమైన విధానం.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // భద్రత: `self` అన్నింటినీ కలుస్తుందని కాలర్ హామీ ఇవ్వాలి
        // సూచన కోసం అవసరాలు.
        unsafe { &*self.as_ptr() }
    }

    /// విలువకు ప్రత్యేకమైన సూచనను అందిస్తుంది.విలువ ప్రారంభించబడకపోతే, బదులుగా [`as_uninit_mut`] ఉపయోగించాలి.
    ///
    /// భాగస్వామ్య ప్రతిరూపం కోసం [`as_ref`] చూడండి.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// ఈ పద్ధతిని పిలిచేటప్పుడు, కిందివన్నీ నిజమని మీరు నిర్ధారించుకోవాలి:
    ///
    /// * పాయింటర్ సరిగ్గా సమలేఖనం చేయాలి.
    ///
    /// * ఇది [the module documentation] లో నిర్వచించిన అర్థంలో "dereferencable" అయి ఉండాలి.
    ///
    /// * పాయింటర్ `T` యొక్క ప్రారంభించిన ఉదాహరణకి సూచించాలి.
    ///
    /// * మీరు తిరిగి Rust యొక్క మారుపేరు నియమాలను అమలు చేయాలి, ఎందుకంటే తిరిగి వచ్చిన జీవితకాలం `'a` ఏకపక్షంగా ఎన్నుకోబడుతుంది మరియు డేటా యొక్క వాస్తవ జీవితకాలం ప్రతిబింబించదు.
    ///
    ///   ప్రత్యేకించి, ఈ జీవితకాలం కోసం, పాయింటర్ సూచించే మెమరీ ఏ ఇతర పాయింటర్ ద్వారా అయినా యాక్సెస్ చేయకూడదు (చదవడం లేదా వ్రాయడం).
    ///
    /// ఈ పద్ధతి యొక్క ఫలితం ఉపయోగించబడనప్పటికీ ఇది వర్తిస్తుంది!
    /// (ప్రారంభించబడటం గురించి భాగం ఇంకా పూర్తిగా నిర్ణయించబడలేదు, కానీ అది అయ్యేవరకు, అవి నిజంగా ప్రారంభించబడిందని నిర్ధారించుకోవడం మాత్రమే సురక్షితమైన విధానం.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // భద్రత: `self` అన్నింటినీ కలుస్తుందని కాలర్ హామీ ఇవ్వాలి
        // మార్చగల సూచన కోసం అవసరాలు.
        unsafe { &mut *self.as_ptr() }
    }

    /// మరొక రకమైన పాయింటర్‌కు ప్రసారం చేస్తుంది.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // భద్రత: `self` అనేది `NonNull` పాయింటర్, ఇది తప్పనిసరిగా శూన్యమైనది కాదు
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// సన్నని పాయింటర్ మరియు పొడవు నుండి శూన్య రహిత ముడి ముక్కను సృష్టిస్తుంది.
    ///
    /// `len` ఆర్గ్యుమెంట్ **మూలకాల సంఖ్య**, బైట్ల సంఖ్య కాదు.
    ///
    /// ఈ ఫంక్షన్ సురక్షితం, కానీ తిరిగి వచ్చే విలువను తగ్గించడం సురక్షితం కాదు.
    /// స్లైస్ భద్రతా అవసరాల కోసం [`slice::from_raw_parts`] యొక్క డాక్యుమెంటేషన్ చూడండి.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // మొదటి మూలకానికి పాయింటర్‌తో ప్రారంభించేటప్పుడు స్లైస్ పాయింటర్‌ను సృష్టించండి
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (ఈ ఉదాహరణ కృత్రిమంగా ఈ పద్ధతి యొక్క ఉపయోగాన్ని ప్రదర్శిస్తుందని గమనించండి, కానీ `స్లైస్= NonNull::from(&x[..]);` would be a better way to write code like this.) లెట్
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // భద్రత: `data` అనేది `NonNull` పాయింటర్, ఇది తప్పనిసరిగా శూన్యమైనది కాదు
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// శూన్యమైన ముడి స్లైస్ యొక్క పొడవును అందిస్తుంది.
    ///
    /// తిరిగి వచ్చిన విలువ **మూలకాల సంఖ్య**, బైట్ల సంఖ్య కాదు.
    ///
    /// పాయింటర్‌కు చెల్లుబాటు అయ్యే చిరునామా లేనందున శూన్యత లేని ముడి స్లైస్‌ని స్లైస్‌కు విడదీయలేనప్పుడు కూడా ఈ ఫంక్షన్ సురక్షితం.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// స్లైస్ బఫర్‌కు శూన్యమైన పాయింటర్‌ను చూపుతుంది.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // భద్రత: `self` శూన్యమైనది కాదని మాకు తెలుసు.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// స్లైస్ బఫర్‌కు ముడి పాయింటర్‌ను చూపుతుంది.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// ప్రారంభించని విలువల స్లైస్‌కు భాగస్వామ్య సూచనను అందిస్తుంది.[`as_ref`] కి విరుద్ధంగా, విలువను ప్రారంభించాల్సిన అవసరం లేదు.
    ///
    /// మ్యూటబుల్ కౌంటర్ కోసం [`as_uninit_slice_mut`] చూడండి.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// ఈ పద్ధతిని పిలిచేటప్పుడు, కిందివన్నీ నిజమని మీరు నిర్ధారించుకోవాలి:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` అనేక బైట్‌ల కోసం రీడర్ల కోసం పాయింటర్ [valid] అయి ఉండాలి మరియు అది సరిగ్గా సమలేఖనం చేయబడాలి.దీని అర్థం ముఖ్యంగా:
    ///
    ///     * ఈ స్లైస్ యొక్క మొత్తం మెమరీ పరిధి ఒకే కేటాయించిన వస్తువులో ఉండాలి!
    ///       ముక్కలు బహుళ కేటాయించిన వస్తువులలో ఎప్పుడూ ఉండవు.
    ///
    ///     * పాయింటర్ సున్నా-పొడవు ముక్కల కోసం కూడా సమలేఖనం చేయబడాలి.
    ///     దీనికి ఒక కారణం ఏమిటంటే, ఎన్యూమ్ లేఅవుట్ ఆప్టిమైజేషన్లు ఇతర డేటా నుండి వేరు చేయడానికి సూచనలు (ఏదైనా పొడవు ముక్కలతో సహా) సమలేఖనం చేయబడి, శూన్యంగా ఉండవు.
    ///
    ///     మీరు [`NonNull::dangling()`] ఉపయోగించి సున్నా-పొడవు ముక్కల కోసం `data` వలె ఉపయోగపడే పాయింటర్‌ను పొందవచ్చు.
    ///
    /// * స్లైస్ యొక్క మొత్తం పరిమాణం `ptr.len() * mem::size_of::<T>()` తప్పనిసరిగా `isize::MAX` కంటే పెద్దదిగా ఉండకూడదు.
    ///   [`pointer::offset`] యొక్క భద్రతా డాక్యుమెంటేషన్ చూడండి.
    ///
    /// * మీరు తిరిగి Rust యొక్క మారుపేరు నియమాలను అమలు చేయాలి, ఎందుకంటే తిరిగి వచ్చిన జీవితకాలం `'a` ఏకపక్షంగా ఎన్నుకోబడుతుంది మరియు డేటా యొక్క వాస్తవ జీవితకాలం ప్రతిబింబించదు.
    ///   ప్రత్యేకించి, ఈ జీవితకాలం కోసం, పాయింటర్ సూచించే మెమరీ పరివర్తన చెందకూడదు (`UnsafeCell` లోపల తప్ప).
    ///
    /// ఈ పద్ధతి యొక్క ఫలితం ఉపయోగించబడనప్పటికీ ఇది వర్తిస్తుంది!
    ///
    /// [`slice::from_raw_parts`] కూడా చూడండి.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // భద్రత: కాలర్ `as_uninit_slice` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// ప్రారంభించని విలువల స్లైస్‌కు ప్రత్యేకమైన సూచనను అందిస్తుంది.[`as_mut`] కి విరుద్ధంగా, విలువను ప్రారంభించాల్సిన అవసరం లేదు.
    ///
    /// భాగస్వామ్య ప్రతిరూపం కోసం [`as_uninit_slice`] చూడండి.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// ఈ పద్ధతిని పిలిచేటప్పుడు, కిందివన్నీ నిజమని మీరు నిర్ధారించుకోవాలి:
    ///
    /// * పాయింటర్ `ptr.len() * mem::size_of::<T>()` చాలా బైట్‌ల కోసం చదవడానికి మరియు వ్రాయడానికి [valid] అయి ఉండాలి మరియు అది సరిగ్గా సమలేఖనం చేయబడాలి.దీని అర్థం ముఖ్యంగా:
    ///
    ///     * ఈ స్లైస్ యొక్క మొత్తం మెమరీ పరిధి ఒకే కేటాయించిన వస్తువులో ఉండాలి!
    ///       ముక్కలు బహుళ కేటాయించిన వస్తువులలో ఎప్పుడూ ఉండవు.
    ///
    ///     * పాయింటర్ సున్నా-పొడవు ముక్కల కోసం కూడా సమలేఖనం చేయబడాలి.
    ///     దీనికి ఒక కారణం ఏమిటంటే, ఎన్యూమ్ లేఅవుట్ ఆప్టిమైజేషన్లు ఇతర డేటా నుండి వేరు చేయడానికి సూచనలు (ఏదైనా పొడవు ముక్కలతో సహా) సమలేఖనం చేయబడి, శూన్యంగా ఉండవు.
    ///
    ///     మీరు [`NonNull::dangling()`] ఉపయోగించి సున్నా-పొడవు ముక్కల కోసం `data` వలె ఉపయోగపడే పాయింటర్‌ను పొందవచ్చు.
    ///
    /// * స్లైస్ యొక్క మొత్తం పరిమాణం `ptr.len() * mem::size_of::<T>()` తప్పనిసరిగా `isize::MAX` కంటే పెద్దదిగా ఉండకూడదు.
    ///   [`pointer::offset`] యొక్క భద్రతా డాక్యుమెంటేషన్ చూడండి.
    ///
    /// * మీరు తిరిగి Rust యొక్క మారుపేరు నియమాలను అమలు చేయాలి, ఎందుకంటే తిరిగి వచ్చిన జీవితకాలం `'a` ఏకపక్షంగా ఎన్నుకోబడుతుంది మరియు డేటా యొక్క వాస్తవ జీవితకాలం ప్రతిబింబించదు.
    ///   ప్రత్యేకించి, ఈ జీవితకాలం కోసం, పాయింటర్ సూచించే మెమరీ ఏ ఇతర పాయింటర్ ద్వారా అయినా యాక్సెస్ చేయకూడదు (చదవడం లేదా వ్రాయడం).
    ///
    /// ఈ పద్ధతి యొక్క ఫలితం ఉపయోగించబడనప్పటికీ ఇది వర్తిస్తుంది!
    ///
    /// [`slice::from_raw_parts_mut`] కూడా చూడండి.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // `memory` చదవడానికి చెల్లుతుంది మరియు `memory.len()` చాలా బైట్‌ల కోసం వ్రాస్తుంది కాబట్టి ఇది సురక్షితం.
    /// // `memory.as_mut()` కి కాల్ చేయడం ఇక్కడ అనుమతించబడదని గమనించండి, ఎందుకంటే కంటెంట్ ప్రారంభించబడదు.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // భద్రత: కాలర్ `as_uninit_slice_mut` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// హద్దులు తనిఖీ చేయకుండా, ముడి పాయింటర్‌ను మూలకం లేదా సబ్‌లైస్‌కు అందిస్తుంది.
    ///
    /// ఈ పద్ధతిని వెలుపల సూచికతో పిలవడం లేదా `self` డీరెఫరెన్సిబుల్ కానప్పుడు *[నిర్వచించబడని ప్రవర్తన]* ఫలిత పాయింటర్ ఉపయోగించకపోయినా.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // భద్రత: కాలర్ `self` డీరెఫరెన్సబుల్ మరియు `index` ఇన్-బౌండ్స్ అని నిర్ధారిస్తుంది.
        // పర్యవసానంగా, ఫలిత పాయింటర్ NULL గా ఉండకూడదు.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // భద్రత: ప్రత్యేకమైన పాయింటర్ శూన్యంగా ఉండకూడదు, కాబట్టి దీనికి పరిస్థితులు
        // new_unchecked() గౌరవించబడతాయి.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // భద్రత: మార్చగల సూచన శూన్యంగా ఉండకూడదు.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // భద్రత: సూచన శూన్యంగా ఉండకూడదు, కాబట్టి దీనికి పరిస్థితులు
        // new_unchecked() గౌరవించబడతాయి.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}