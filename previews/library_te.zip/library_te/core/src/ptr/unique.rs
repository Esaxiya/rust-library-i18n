use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// ముడి కాని శూన్యమైన `*mut T` చుట్టూ ఒక రేపర్ ఈ రేపర్ యొక్క యజమాని సూచనను కలిగి ఉందని సూచిస్తుంది.
/// `Box<T>`, `Vec<T>`, `String` మరియు `HashMap<K, V>` వంటి సంగ్రహణలను నిర్మించడానికి ఉపయోగపడుతుంది.
///
/// `*mut T` కాకుండా, `Unique<T>` "as if" ప్రవర్తిస్తుంది, ఇది `T` యొక్క ఉదాహరణ.
/// `T` `Send`/`Sync` అయితే ఇది `Send`/`Sync` ను అమలు చేస్తుంది.
/// ఇది `T` యొక్క ఉదాహరణ ఆశించే బలమైన అలియాసింగ్ హామీలని కూడా సూచిస్తుంది:
/// పాయింటర్ యొక్క ప్రస్తావన దాని స్వంత ప్రత్యేకతకు ప్రత్యేకమైన మార్గం లేకుండా సవరించకూడదు.
///
/// మీ ప్రయోజనాల కోసం `Unique` ను ఉపయోగించడం సరైనదా అని మీకు అనిశ్చితంగా ఉంటే, బలహీనమైన అర్థాలను కలిగి ఉన్న `NonNull` ను ఉపయోగించడాన్ని పరిగణించండి.
///
///
/// `*mut T` మాదిరిగా కాకుండా, పాయింటర్ ఎప్పుడూ డీఫరెన్స్‌చేయకపోయినా, పాయింటర్ ఎల్లప్పుడూ శూన్యంగా ఉండాలి.
/// ఎనుమ్స్ ఈ నిషేధించబడిన విలువను వివక్షతగా ఉపయోగించుకోవచ్చు-`Option<Unique<T>>` `Unique<T>` వలె ఉంటుంది.
/// అయినప్పటికీ, పాయింటర్ నిర్దేశించబడకపోతే ఇంకా చిక్కుకోవచ్చు.
///
/// `*mut T` కాకుండా, `Unique<T>` `T` కన్నా కోవిరియంట్.
/// ప్రత్యేకమైన మారుపేరు అవసరాలను సమర్థించే ఏ రకానికి అయినా ఇది ఎల్లప్పుడూ సరైనదిగా ఉండాలి.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ఈ మార్కర్ వ్యత్యాసానికి ఎటువంటి పరిణామాలను కలిగి లేదు, కానీ అవసరం
    // మేము తార్కికంగా `T` ను కలిగి ఉన్నామని డ్రాప్‌క్ అర్థం చేసుకోవడానికి.
    //
    // వివరాల కోసం, చూడండి:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` `T` `Send` అయితే పాయింటర్లు `Send` ఎందుకంటే అవి సూచించే డేటా అవాంఛనీయమైనది.
/// ఈ మారుపేరు మార్పు అనేది టైప్ సిస్టమ్ చేత అమలు చేయబడదని గమనించండి;`Unique` ను ఉపయోగించి సంగ్రహణ తప్పనిసరిగా దాన్ని అమలు చేయాలి.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` `T` `Sync` అయితే పాయింటర్లు `Sync` ఎందుకంటే అవి సూచించే డేటా అవాంఛనీయమైనది.
/// ఈ మారుపేరు మార్పు అనేది టైప్ సిస్టమ్ చేత అమలు చేయబడదని గమనించండి;`Unique` ను ఉపయోగించి సంగ్రహణ తప్పనిసరిగా దాన్ని అమలు చేయాలి.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// క్రొత్త `Unique` ను సృష్టిస్తుంది, అది డాంగ్లింగ్, కానీ బాగా సమలేఖనం చేయబడింది.
    ///
    /// `Vec::new` మాదిరిగా సోమరితనం కేటాయించే రకాలను ప్రారంభించడానికి ఇది ఉపయోగపడుతుంది.
    ///
    /// పాయింటర్ విలువ `T` కు చెల్లుబాటు అయ్యే పాయింటర్‌ను సూచించవచ్చని గమనించండి, అంటే ఇది "not yet initialized" సెంటినెల్ విలువగా ఉపయోగించరాదు.
    /// సోమరితనం కేటాయించే రకాలు కొన్ని ఇతర మార్గాల ద్వారా ప్రారంభాన్ని ట్రాక్ చేయాలి.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // భద్రత: mem::align_of() చెల్లుబాటు అయ్యే, శూన్యమైన పాయింటర్‌ను అందిస్తుంది.ది
        // new_unchecked() కి కాల్ చేసే పరిస్థితులు గౌరవించబడతాయి.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// క్రొత్త `Unique` ను సృష్టిస్తుంది.
    ///
    /// # Safety
    ///
    /// `ptr` శూన్యంగా ఉండాలి.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // భద్రత: కాలర్ `ptr` శూన్యమైనది కాదని హామీ ఇవ్వాలి.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` శూన్యంగా లేకపోతే కొత్త `Unique` ను సృష్టిస్తుంది.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // భద్రత: పాయింటర్ ఇప్పటికే తనిఖీ చేయబడింది మరియు శూన్యంగా లేదు.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// అంతర్లీన `*mut` పాయింటర్‌ను పొందుతుంది.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// కంటెంట్‌ను తొలగిస్తుంది.
    ///
    /// ఫలిత జీవితకాలం స్వీయానికి కట్టుబడి ఉంటుంది, కాబట్టి ఇది "as if" గా ప్రవర్తిస్తుంది, ఇది వాస్తవానికి T యొక్క ఉదాహరణ.
    /// ఎక్కువ (unbound) జీవితకాలం అవసరమైతే, `&*my_ptr.as_ptr()` ఉపయోగించండి.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // భద్రత: `self` అన్నింటినీ కలుస్తుందని కాలర్ హామీ ఇవ్వాలి
        // సూచన కోసం అవసరాలు.
        unsafe { &*self.as_ptr() }
    }

    /// కంటెంట్‌ను పరస్పరం డీరెఫరెన్స్ చేస్తుంది.
    ///
    /// ఫలిత జీవితకాలం స్వీయానికి కట్టుబడి ఉంటుంది, కాబట్టి ఇది "as if" గా ప్రవర్తిస్తుంది, ఇది వాస్తవానికి T యొక్క ఉదాహరణ.
    /// ఎక్కువ (unbound) జీవితకాలం అవసరమైతే, `&mut *my_ptr.as_ptr()` ఉపయోగించండి.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // భద్రత: `self` అన్నింటినీ కలుస్తుందని కాలర్ హామీ ఇవ్వాలి
        // మార్చగల సూచన కోసం అవసరాలు.
        unsafe { &mut *self.as_ptr() }
    }

    /// మరొక రకమైన పాయింటర్‌కు ప్రసారం చేస్తుంది.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // భద్రత: Unique::new_unchecked() కొత్త ప్రత్యేకతను మరియు అవసరాలను సృష్టిస్తుంది
        // ఇచ్చిన పాయింటర్ శూన్యంగా ఉండకూడదు.
        // మనం ఒక పాయింటర్‌గా స్వీయ ప్రయాణిస్తున్నందున, అది శూన్యంగా ఉండకూడదు.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // భద్రత: మార్చగల సూచన శూన్యంగా ఉండకూడదు
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}