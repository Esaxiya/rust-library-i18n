//! ప్రామాణిక లైబ్రరీలో Panic మద్దతు.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// panic గురించి సమాచారాన్ని అందించే ఒక నిర్మాణం.
///
/// `PanicInfo` నిర్మాణం [`set_hook`] ఫంక్షన్ ద్వారా సెట్ చేయబడిన panic hook కు పంపబడుతుంది.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic తో అనుబంధించబడిన పేలోడ్‌ను అందిస్తుంది.
    ///
    /// ఇది సాధారణంగా, కానీ ఎల్లప్పుడూ కాదు, `&'static str` లేదా [`String`] అవుతుంది.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// `core` crate (`std` నుండి కాదు) నుండి `panic!` స్థూల ఆకృతీకరణ స్ట్రింగ్ మరియు కొన్ని అదనపు వాదనలతో ఉపయోగించబడితే, ఆ సందేశాన్ని [`fmt::write`] తో ఉపయోగించడానికి సిద్ధంగా ఉంది
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// అందుబాటులో ఉంటే, panic ఉద్భవించిన స్థానం గురించి సమాచారాన్ని అందిస్తుంది.
    ///
    /// ఈ పద్ధతి ప్రస్తుతం ఎల్లప్పుడూ [`Some`] ను తిరిగి ఇస్తుంది, కానీ ఇది future సంస్కరణల్లో మారవచ్చు.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: ఇది కొన్నిసార్లు తిరిగి రావడానికి మార్చబడితే,
        // std::panicking::default_hook మరియు std::panicking::begin_panic_fmt లలో ఆ కేసుతో వ్యవహరించండి.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: మేము downcast_ref: : ని ఉపయోగించలేము<String>() ఇక్కడ
        // లిబ్‌కోర్‌లో స్ట్రింగ్ అందుబాటులో లేదు కాబట్టి!
        // బహుళ వాదనలతో `std::panic!` అని పిలిచినప్పుడు పేలోడ్ ఒక స్ట్రింగ్, కానీ ఆ సందర్భంలో సందేశం కూడా అందుబాటులో ఉంటుంది.
        //

        self.location.fmt(formatter)
    }
}

/// panic యొక్క స్థానం గురించి సమాచారాన్ని కలిగి ఉన్న ఒక struct.
///
/// ఈ నిర్మాణం [`PanicInfo::location()`] చే సృష్టించబడింది.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// సమానత్వం మరియు క్రమం కోసం పోలికలు ఫైల్, లైన్, ఆపై కాలమ్ ప్రాధాన్యతలో చేయబడతాయి.
/// ఫైళ్ళను తీగలుగా పోల్చారు, `Path` కాదు, ఇది .హించనిది కావచ్చు.
/// మరింత చర్చ కోసం [`స్థానం: : ఫైల్`] యొక్క డాక్యుమెంటేషన్ చూడండి.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// ఈ ఫంక్షన్ యొక్క కాలర్ యొక్క మూల స్థానాన్ని అందిస్తుంది.
    /// ఆ ఫంక్షన్ యొక్క కాలర్ ఉల్లేఖించబడితే, దాని కాల్ స్థానం తిరిగి ఇవ్వబడుతుంది మరియు ట్రాక్ చేయని ఫంక్షన్ బాడీలోని మొదటి కాల్ వరకు స్టాక్ పైకి ఉంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// [`Location`] అని పిలువబడే దాన్ని అందిస్తుంది.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// ఈ ఫంక్షన్ యొక్క నిర్వచనం నుండి [`Location`] ను అందిస్తుంది.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // అదే అన్‌ట్రాక్డ్ ఫంక్షన్‌ను వేరే ప్రదేశంలో నడపడం మాకు అదే ఫలితాన్ని ఇస్తుంది
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ట్రాక్ చేయబడిన ఫంక్షన్‌ను వేరే ప్రదేశంలో అమలు చేయడం వేరే విలువను ఉత్పత్తి చేస్తుంది
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic ఉద్భవించిన సోర్స్ ఫైల్ పేరును అందిస్తుంది.
    ///
    /// # `&str`, `&Path` కాదు
    ///
    /// తిరిగి వచ్చిన పేరు కంపైలింగ్ సిస్టమ్‌లోని మూల మార్గాన్ని సూచిస్తుంది, అయితే దీన్ని నేరుగా `&Path` గా సూచించడం చెల్లదు.
    /// కంపైల్డ్ కోడ్ విషయాలను అందించే సిస్టమ్ కంటే వేరే `Path` అమలుతో వేరే సిస్టమ్‌లో నడుస్తుంది మరియు ఈ లైబ్రరీకి ప్రస్తుతం వేరే "host path" రకం లేదు.
    ///
    /// మాడ్యూల్ సిస్టమ్‌లోని బహుళ మార్గాల ద్వారా (సాధారణంగా `#[path = "..."]` లక్షణాన్ని ఉపయోగించడం లేదా ఇలాంటివి) "the same" ఫైల్ చేరుకోగలిగినప్పుడు చాలా ఆశ్చర్యకరమైన ప్రవర్తన సంభవిస్తుంది, ఇది ఈ ఫంక్షన్ నుండి విభిన్న విలువలను తిరిగి ఇవ్వడానికి ఒకేలాంటి కోడ్ వలె కనిపిస్తుంది.
    ///
    ///
    /// # Cross-compilation
    ///
    /// హోస్ట్ ప్లాట్‌ఫాం మరియు టార్గెట్ ప్లాట్‌ఫాం విభిన్నంగా ఉన్నప్పుడు `Path::new` లేదా ఇలాంటి కన్స్ట్రక్టర్లకు వెళ్లడానికి ఈ విలువ తగినది కాదు.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic ఉద్భవించిన పంక్తి సంఖ్యను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic ఉద్భవించిన కాలమ్‌ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// డేటాను libstd నుండి `panic_unwind` మరియు ఇతర panic రన్‌టైమ్‌లకు పంపించడానికి libstd ఉపయోగించే అంతర్గత trait.
/// ఎప్పుడైనా స్థిరీకరించడానికి ఉద్దేశించినది కాదు, ఉపయోగించవద్దు.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// విషయాల పూర్తి యాజమాన్యాన్ని తీసుకోండి.
    /// రిటర్న్ రకం వాస్తవానికి `Box<dyn Any + Send>`, కానీ మేము లిబ్‌కోర్‌లో `Box` ను ఉపయోగించలేము.
    ///
    /// ఈ పద్ధతి పిలిచిన తరువాత, `self` లో కొన్ని డమ్మీ డిఫాల్ట్ విలువ మాత్రమే మిగిలి ఉంది.
    /// ఈ పద్ధతిని రెండుసార్లు కాల్ చేయడం లేదా ఈ పద్ధతిని పిలిచిన తర్వాత `get` కి కాల్ చేయడం లోపం.
    ///
    /// panic రన్‌టైమ్ (`__rust_start_panic`) అరువు తెచ్చుకున్న `dyn BoxMeUp` ను మాత్రమే పొందుతుంది కాబట్టి వాదన తీసుకోబడింది.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// విషయాలను అరువుగా తీసుకోండి.
    fn get(&mut self) -> &(dyn Any + Send);
}