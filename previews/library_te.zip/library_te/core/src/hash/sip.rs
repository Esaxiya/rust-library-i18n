//! సిప్ హాష్ అమలు.

#![allow(deprecated)] // ఈ మాడ్యూల్‌లోని రకాలు తీసివేయబడతాయి

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// సిప్ హాష్ 1-3 యొక్క అమలు.
///
/// ఇది ప్రస్తుతం ప్రామాణిక లైబ్రరీ ఉపయోగించే డిఫాల్ట్ హాషింగ్ ఫంక్షన్ (ఉదా., `collections::HashMap` దీన్ని అప్రమేయంగా ఉపయోగిస్తుంది).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// సిప్ హాష్ 2-4 యొక్క అమలు.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// సిప్ హాష్ 2-4 యొక్క అమలు.
///
/// See: <https://131002.net/siphash/>
///
/// సిప్ హాష్ అనేది సాధారణ-ప్రయోజన హాషింగ్ ఫంక్షన్: ఇది మంచి వేగంతో నడుస్తుంది (స్పూకీ మరియు సిటీతో పోటీపడుతుంది) మరియు బలమైన _keyed_ హాషింగ్‌ను అనుమతిస్తుంది.
///
/// ఇది [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) వంటి బలమైన RNG నుండి మీ హాష్ పట్టికలను కీ చేయడానికి మిమ్మల్ని అనుమతిస్తుంది.
///
/// సిప్ హాష్ అల్గోరిథం సాధారణంగా బలంగా పరిగణించబడుతున్నప్పటికీ, ఇది క్రిప్టోగ్రాఫిక్ ప్రయోజనాల కోసం ఉద్దేశించబడలేదు.
/// అందుకని, ఈ అమలు యొక్క అన్ని క్రిప్టోగ్రాఫిక్ ఉపయోగాలు _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // మేము ఎన్ని బైట్లు ప్రాసెస్ చేసాము
    state: State,  // హాష్ స్టేట్
    tail: u64,     // ప్రాసెస్ చేయని బైట్లు లే
    ntail: usize,  // తోకలో ఎన్ని బైట్లు చెల్లుతాయి
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 మరియు v1, v3 అల్గోరిథంలో జతగా కనిపిస్తాయి మరియు సిప్ హాష్ యొక్క సిమ్డ్ అమలులు v02 మరియు v13 యొక్క vectors ను ఉపయోగిస్తాయి.
    //
    // వాటిని ఈ క్రమంలో struct లో ఉంచడం ద్వారా, కంపైలర్ స్వయంగా కొన్ని సిమ్డ్ ఆప్టిమైజేషన్లను ఎంచుకోవచ్చు.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// LE క్రమంలో, బైట్ స్ట్రీమ్ నుండి కావలసిన రకం యొక్క పూర్ణాంకాన్ని లోడ్ చేస్తుంది.
/// కంపైలర్ అన్‌లైన్ చేయని చిరునామా నుండి లోడ్ చేయడానికి అత్యంత సమర్థవంతమైన మార్గాన్ని రూపొందించడానికి `copy_nonoverlapping` ను ఉపయోగిస్తుంది.
///
///
/// సురక్షితం కాదు ఎందుకంటే: i..i+size_of(int_ty) వద్ద తనిఖీ చేయని ఇండెక్సింగ్
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// బైట్ స్లైస్ యొక్క 7 బైట్ల వరకు ఉపయోగించి u64 ని లోడ్ చేస్తుంది.
/// ఇది వికృతమైనదిగా కనిపిస్తుంది, అయితే సంభవించే `copy_nonoverlapping` కాల్స్ (`load_int_le!` ద్వారా) అన్నీ స్థిర పరిమాణాలను కలిగి ఉంటాయి మరియు `memcpy` కి కాల్ చేయకుండా ఉండండి, ఇది వేగానికి మంచిది.
///
///
/// సురక్షితం కాదు ఎందుకంటే: ప్రారంభంలో తనిఖీ చేయని ఇండెక్సింగ్..స్టార్ట్ + లెన్
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // అవుట్పుట్ u64 లో ప్రస్తుత బైట్ సూచిక (LSB నుండి)
    let mut out = 0;
    if i + 3 < len {
        // భద్రత: `i` `len` కన్నా ఎక్కువ ఉండకూడదు మరియు కాలర్ హామీ ఇవ్వాలి
        // ఇండెక్స్ ప్రారంభం..స్టార్ట్ + లెన్ హద్దులో ఉంది.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // భద్రత: పైన చెప్పినట్లే.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // భద్రత: పైన చెప్పినట్లే.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// 0 కి సెట్ చేయబడిన రెండు ప్రారంభ కీలతో కొత్త `SipHasher` ను సృష్టిస్తుంది.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// అందించిన కీల నుండి కీ చేయబడిన `SipHasher` ను సృష్టిస్తుంది.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// 0 కి సెట్ చేయబడిన రెండు ప్రారంభ కీలతో కొత్త `SipHasher13` ను సృష్టిస్తుంది.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// అందించిన కీల నుండి కీ చేయబడిన `SipHasher13` ను సృష్టిస్తుంది.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: పూర్ణాంక హాషింగ్ పద్ధతులు (`write_u *`, `write_i*`) నిర్వచించబడలేదు
    // ఈ రకం కోసం.
    // మేము వాటిని జోడించవచ్చు, librustc_data_structures/sip128.rs లో `short_write` అమలును కాపీ చేయవచ్చు మరియు `SipHasher`, `SipHasher13` మరియు `DefaultHasher` కు `write_u *`/`write_i*` పద్ధతులను జోడించవచ్చు.
    //
    // కొన్ని బెంచ్‌మార్క్‌లపై కంపైల్ వేగాన్ని కొద్దిగా తగ్గించే ఖర్చుతో, ఆ హాషర్‌ల ద్వారా పూర్ణాంక హాషింగ్‌ను ఇది చాలా వేగవంతం చేస్తుంది.
    // వివరాల కోసం #69152 చూడండి.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // భద్రత: `cmp::min(length, needed)` `length` కంటే ఎక్కువ ఉండదని హామీ ఇవ్వబడింది
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // బఫర్డ్ తోక ఇప్పుడు ఫ్లష్ చేయబడింది, కొత్త ఇన్‌పుట్‌ను ప్రాసెస్ చేయండి.
        let len = length - needed;
        let left = len & 0x7; // లెన్% 8

        let mut i = needed;
        while i < len - left {
            // భద్రత: ఎందుకంటే `len - left` 8 లోపు అతిపెద్ద గుణకం
            // `len`, మరియు `i` `needed` వద్ద మొదలవుతుంది, ఇక్కడ `len` `length - needed`, `i + 8` `length` కన్నా తక్కువ లేదా సమానంగా ఉంటుందని హామీ ఇవ్వబడింది.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // భద్రత: `i` ఇప్పుడు `needed + len.div_euclid(8) * 8`,
        // కాబట్టి `i + left` = `needed + len` = `length`, ఇది నిర్వచనం ప్రకారం `msg.len()` కి సమానం.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// 0 కి సెట్ చేయబడిన రెండు ప్రారంభ కీలతో `Hasher<S>` ను సృష్టిస్తుంది.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}