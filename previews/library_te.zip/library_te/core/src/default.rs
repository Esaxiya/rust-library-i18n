//! అర్ధవంతమైన డిఫాల్ట్ విలువలను కలిగి ఉన్న రకాల కోసం `Default` trait.

#![stable(feature = "rust1", since = "1.0.0")]

/// ఒక రకానికి ఉపయోగకరమైన డిఫాల్ట్ విలువను ఇవ్వడానికి trait.
///
/// కొన్నిసార్లు, మీరు ఒక రకమైన డిఫాల్ట్ విలువకు తిరిగి రావాలని కోరుకుంటారు మరియు ఇది ఏమిటో ప్రత్యేకంగా పట్టించుకోరు.
/// ఇది ఎంపికల సమితిని నిర్వచించే `struct` లతో తరచుగా వస్తుంది:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// మేము కొన్ని డిఫాల్ట్ విలువలను ఎలా నిర్వచించగలం?మీరు `Default` ను ఉపయోగించవచ్చు:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// ఇప్పుడు, మీరు అన్ని డిఫాల్ట్ విలువలను పొందుతారు.Rust వివిధ ఆదిమ రకాల కోసం `Default` ను అమలు చేస్తుంది.
///
/// మీరు ఒక నిర్దిష్ట ఎంపికను భర్తీ చేయాలనుకుంటే, ఇతర డిఫాల్ట్‌లను అలాగే ఉంచండి:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// అన్ని రకాల ఫీల్డ్‌లు `Default` ను అమలు చేస్తే ఈ trait ను `#[derive]` తో ఉపయోగించవచ్చు.
/// `ఉత్పన్నం` చేసినప్పుడు, ఇది ప్రతి ఫీల్డ్ రకానికి డిఫాల్ట్ విలువను ఉపయోగిస్తుంది.
///
/// ## నేను `Default` ను ఎలా అమలు చేయగలను?
///
/// మీ రకం విలువను డిఫాల్ట్‌గా ఇచ్చే `default()` పద్ధతి కోసం అమలును అందించండి:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// ఒక రకం కోసం "default value" ని అందిస్తుంది.
    ///
    /// డిఫాల్ట్ విలువలు తరచుగా ఒక రకమైన ప్రారంభ విలువ, గుర్తింపు విలువ లేదా డిఫాల్ట్‌గా అర్ధమయ్యే ఏదైనా.
    ///
    ///
    /// # Examples
    ///
    /// అంతర్నిర్మిత డిఫాల్ట్ విలువలను ఉపయోగించడం:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// మీ స్వంతం చేసుకోవడం:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait ప్రకారం ఒక రకం డిఫాల్ట్ విలువను తిరిగి ఇవ్వండి.
///
/// తిరిగి వచ్చే రకం సందర్భం నుండి er హించబడుతుంది;ఇది `Default::default()` కి సమానం కాని టైప్ చేయడానికి తక్కువ.
///
/// ఉదాహరణకి:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default` యొక్క impl ను ఉత్పత్తి చేసే స్థూల ఉత్పన్నం.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }