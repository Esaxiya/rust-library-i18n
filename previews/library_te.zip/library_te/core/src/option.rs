//! ఐచ్ఛిక విలువలు.
//!
//! రకం [`Option`] ఒక ఐచ్ఛిక విలువను సూచిస్తుంది: ప్రతి [`Option`] [`Some`] గా ఉంటుంది మరియు విలువ లేదా [`None`] ను కలిగి ఉంటుంది మరియు లేదు.
//! [`Option`] Rust కోడ్‌లో రకాలు చాలా సాధారణం, ఎందుకంటే వాటికి అనేక ఉపయోగాలు ఉన్నాయి:
//!
//! * ప్రారంభ విలువలు
//! * మొత్తం ఇన్పుట్ పరిధిలో (పాక్షిక విధులు) నిర్వచించబడని ఫంక్షన్ల కోసం తిరిగి విలువలు
//! * సరళమైన లోపాలను నివేదించడానికి విలువ తిరిగి ఇవ్వండి, ఇక్కడ [`None`] లోపం మీద తిరిగి వస్తుంది
//! * ఐచ్ఛిక నిర్మాణ క్షేత్రాలు
//! * రుణం తీసుకోగల లేదా "taken" ఫీల్డ్‌లను నిర్మించండి
//! * ఐచ్ఛిక ఫంక్షన్ వాదనలు
//! * శూన్యమైన పాయింటర్లు
//! * క్లిష్ట పరిస్థితుల నుండి విషయాలను మార్చుకోవడం
//!
//! [`ఎంపిక`] లు సాధారణంగా విలువ యొక్క ఉనికిని ప్రశ్నించడానికి మరియు చర్య తీసుకోవడానికి నమూనా సరిపోలికతో జత చేయబడతాయి, ఇది ఎల్లప్పుడూ [`None`] కేసుకు కారణమవుతుంది.
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // ఫంక్షన్ యొక్క తిరిగి విలువ ఒక ఎంపిక
//! let result = divide(2.0, 3.0);
//!
//! // విలువను తిరిగి పొందడానికి నమూనా సరిపోలిక
//! match result {
//!     // విభజన చెల్లుబాటు అయ్యింది
//!     Some(x) => println!("Result: {}", x),
//!     // విభజన చెల్లదు
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: `Option` ఆచరణలో, చాలా పద్ధతులతో ఎలా ఉపయోగించబడుతుందో చూపించు
//
//! # ఎంపికలు మరియు పాయింటర్లు ("nullable" పాయింటర్లు)
//!
//! Rust యొక్క పాయింటర్ రకాలు ఎల్లప్పుడూ చెల్లుబాటు అయ్యే స్థానానికి సూచించాలి;"null" సూచనలు లేవు.బదులుగా, Rust ఐచ్ఛిక యాజమాన్యంలోని పెట్టె వంటి *ఐచ్ఛిక* పాయింటర్లను కలిగి ఉంది, [`ఎంపిక`]`<`[`బాక్స్<T>`]`>`.
//!
//! కింది ఉదాహరణ [`i32`] యొక్క ఐచ్ఛిక పెట్టెను సృష్టించడానికి [`Option`] ను ఉపయోగిస్తుంది.
//! మొదట లోపలి [`i32`] విలువను ఉపయోగించడానికి, `check_optional` ఫంక్షన్ బాక్స్ విలువ కలిగి ఉందో లేదో తెలుసుకోవడానికి నమూనా సరిపోలికను ఉపయోగించాల్సిన అవసరం ఉందని గమనించండి (అనగా, ఇది [`Some(...)`][`Some`]) లేదా ([`None`]) కాదు.
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! [`Option<T>`] కింది రకాలను `T` ను ఆప్టిమైజ్ చేయడానికి Rust హామీ ఇస్తుంది, అంటే [`Option<T>`] `T` మాదిరిగానే ఉంటుంది:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` ఈ జాబితాలోని రకాల్లో ఒకదాని చుట్టూ.
//!
//! పైన పేర్కొన్న సందర్భాల్లో, `T` యొక్క అన్ని చెల్లుబాటు అయ్యే విలువల నుండి మరియు `Some::<T>(_)` నుండి `T` వరకు [`mem::transmute`] చేయగలదని మరింత హామీ ఇవ్వబడింది (కాని `None::<T>` నుండి `T` కు బదిలీ చేయడం నిర్వచించబడని ప్రవర్తన).
//!
//! # Examples
//!
//! [`Option`] లో ప్రాథమిక నమూనా సరిపోలిక:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // ఉన్న స్ట్రింగ్‌కు సూచన తీసుకోండి
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // ఉన్న స్ట్రింగ్‌ను తీసివేసి, ఎంపికను నాశనం చేస్తుంది
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! లూప్‌కు ముందు ఫలితాన్ని [`None`] కి ప్రారంభించండి:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // శోధించడానికి డేటా జాబితా.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // మేము అతిపెద్ద జంతువు పేరు కోసం శోధించబోతున్నాము, కాని ప్రారంభించడానికి మనకు ఇప్పుడే `None` వచ్చింది.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // ఇప్పుడు మేము కొన్ని పెద్ద జంతువుల పేరును కనుగొన్నాము
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` రకం.మరిన్ని కోసం [the module level documentation](self) చూడండి.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// విలువ లేదు
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// కొంత విలువ `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// రకం అమలు
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // ఉన్న విలువలను ప్రశ్నిస్తోంది
    /////////////////////////////////////////////////////////////////////////

    /// ఎంపిక [`Some`] విలువ అయితే `true` ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// ఎంపిక [`None`] విలువ అయితే `true` ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// ఇచ్చిన విలువను కలిగి ఉన్న [`Some`] విలువ ఐచ్ఛికం అయితే `true` ని అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // సూచనలతో పనిచేయడానికి అడాప్టర్
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>` నుండి `Option<&T>` కి మారుస్తుంది.
    ///
    /// # Examples
    ///
    /// `ఆప్షన్ <` [`స్ట్రింగ్`]`>`ను`ఆప్షన్ <`[`యూజ్`] `>` గా మారుస్తుంది, అసలైనదాన్ని సంరక్షిస్తుంది.
    /// [`map`] పద్ధతి `self` ఆర్గ్యుమెంట్‌ను విలువ ద్వారా తీసుకుంటుంది, అసలైనదాన్ని తీసుకుంటుంది, కాబట్టి ఈ టెక్నిక్ `as_ref` ను మొదట `Option` ను అసలు లోపల ఉన్న విలువకు సూచనగా తీసుకుంటుంది.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // మొదట, `as_ref` తో `Option<String>` కు `Option<&String>` కు ప్రసారం చేయండి, ఆపై `map` తో *ఆ* ను తినండి, `text` ను స్టాక్‌లో వదిలివేయండి.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>` నుండి `Option<&mut T>` కి మారుస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`పిన్`]`<&ఎంపిక నుండి మారుస్తుంది<T>>`నుండి`ఎంపిక <`[`పిన్`] `<&టి>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // భద్రత: `x` `self` నుండి వచ్చినందున పిన్ చేయబడుతుందని హామీ ఇవ్వబడింది
        // ఇది పిన్ చేయబడింది.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`పిన్`]`<&మ్యూట్ ఎంపిక నుండి మారుస్తుంది<T>>`నుండి`ఎంపిక <`[`పిన్`] `<&మ్యూట్ టి>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // భద్రత: X002 లోపల `Option` ను తరలించడానికి `get_unchecked_mut` ఎప్పుడూ ఉపయోగించబడదు.
        // `x` పిన్ చేయబడుతుందని హామీ ఇవ్వబడింది ఎందుకంటే ఇది పిన్ చేయబడిన `self` నుండి వస్తుంది.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // ఉన్న విలువలను పొందడం
    /////////////////////////////////////////////////////////////////////////

    /// `self` విలువను వినియోగించే కలిగి ఉన్న [`Some`] విలువను చూపుతుంది.
    ///
    /// # Panics
    ///
    /// `msg` అందించిన కస్టమ్ panic సందేశంతో విలువ [`None`] అయితే Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// `self` విలువను వినియోగించే కలిగి ఉన్న [`Some`] విలువను చూపుతుంది.
    ///
    /// ఈ ఫంక్షన్ panic కావచ్చు కాబట్టి, దీని ఉపయోగం సాధారణంగా నిరుత్సాహపడుతుంది.
    /// బదులుగా, నమూనా సరిపోలికను ఉపయోగించడానికి ఇష్టపడండి మరియు [`None`] కేసును స్పష్టంగా నిర్వహించడానికి లేదా [`unwrap_or`], [`unwrap_or_else`] లేదా [`unwrap_or_default`] కు కాల్ చేయండి.
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// స్వీయ విలువ [`None`] కి సమానం అయితే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// ఉన్న [`Some`] విలువ లేదా అందించిన డిఫాల్ట్‌ను అందిస్తుంది.
    ///
    /// `unwrap_or` కు పంపిన వాదనలు ఆసక్తిగా అంచనా వేయబడతాయి;మీరు ఫంక్షన్ కాల్ ఫలితాన్ని దాటితే, [`unwrap_or_else`] ను ఉపయోగించమని సిఫార్సు చేయబడింది, ఇది సోమరితనం అంచనా వేయబడుతుంది.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// ఉన్న [`Some`] విలువను చూపుతుంది లేదా మూసివేత నుండి లెక్కిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// విలువ [`None`] కాదని తనిఖీ చేయకుండా, `self` విలువను వినియోగించే, కలిగి ఉన్న [`Some`] విలువను అందిస్తుంది.
    ///
    ///
    /// # Safety
    ///
    /// [`None`] లో ఈ పద్ధతిని పిలవడం *[నిర్వచించబడని ప్రవర్తన]*.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // నిర్వచించబడని ప్రవర్తన!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // భద్రత: భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // కలిగి ఉన్న విలువలను మార్చడం
    /////////////////////////////////////////////////////////////////////////

    /// ఉన్న విలువకు ఫంక్షన్‌ను వర్తింపజేయడం ద్వారా `Option<T>` నుండి `Option<U>` వరకు మ్యాప్ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// `ఆప్షన్ <` [`స్ట్రింగ్`]`>`ను`ఆప్షన్ <`[`యూజ్`] `>` గా మారుస్తుంది, అసలైనదాన్ని వినియోగిస్తుంది:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` `maybe_some_string` ను వినియోగిస్తూ, విలువ ద్వారా స్వీయ * తీసుకుంటుంది
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// ఉన్న విలువకు (ఏదైనా ఉంటే) ఒక ఫంక్షన్‌ను వర్తింపజేస్తుంది లేదా అందించిన డిఫాల్ట్‌ను తిరిగి ఇస్తుంది (కాకపోతే).
    ///
    /// `map_or` కు పంపిన వాదనలు ఆసక్తిగా అంచనా వేయబడతాయి;మీరు ఫంక్షన్ కాల్ ఫలితాన్ని దాటితే, [`map_or_else`] ను ఉపయోగించమని సిఫార్సు చేయబడింది, ఇది సోమరితనం అంచనా వేయబడుతుంది.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// ఉన్న విలువకు (ఏదైనా ఉంటే) ఒక ఫంక్షన్‌ను వర్తింపజేస్తుంది లేదా డిఫాల్ట్‌ను లెక్కిస్తుంది (కాకపోతే).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` ను [`Result<T, E>`] గా మారుస్తుంది, [`Some(v)`] నుండి [`Ok(v)`] మరియు [`None`] నుండి [`Err(err)`] వరకు మ్యాపింగ్ చేస్తుంది.
    ///
    /// `ok_or` కు పంపిన వాదనలు ఆసక్తిగా అంచనా వేయబడతాయి;మీరు ఫంక్షన్ కాల్ ఫలితాన్ని దాటితే, [`ok_or_else`] ను ఉపయోగించమని సిఫార్సు చేయబడింది, ఇది సోమరితనం అంచనా వేయబడుతుంది.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` ను [`Result<T, E>`] గా మారుస్తుంది, [`Some(v)`] నుండి [`Ok(v)`] మరియు [`None`] నుండి [`Err(err())`] వరకు మ్యాపింగ్ చేస్తుంది.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// `value` ఎంపికలో చొప్పించి, దానికి మ్యూటబుల్ రిఫరెన్స్‌ను తిరిగి ఇస్తుంది.
    ///
    /// ఎంపిక ఇప్పటికే విలువను కలిగి ఉంటే, పాత విలువ పడిపోతుంది.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // భద్రత: పై కోడ్ ఎంపికను నింపింది
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ఇటరేటర్ కన్స్ట్రక్టర్లు
    /////////////////////////////////////////////////////////////////////////

    /// బహుశా కలిగి ఉన్న విలువపై ఇటరేటర్‌ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// బహుశా కలిగి ఉన్న విలువపై మార్చగల ఇటరేటర్‌ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // విలువలపై బూలియన్ కార్యకలాపాలు, ఆసక్తిగా మరియు సోమరితనం
    /////////////////////////////////////////////////////////////////////////

    /// ఎంపిక [`None`] అయితే [`None`] ను అందిస్తుంది, లేకపోతే `optb` ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// ఎంపిక [`None`] అయితే [`None`] ను అందిస్తుంది, లేకపోతే చుట్టిన విలువతో `f` కి కాల్ చేసి ఫలితాన్ని ఇస్తుంది.
    ///
    ///
    /// కొన్ని భాషలు ఈ ఆపరేషన్‌ను ఫ్లాట్‌మ్యాప్ అని పిలుస్తాయి.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// ఎంపిక [`None`] అయితే [`None`] ను అందిస్తుంది, లేకపోతే చుట్టిన విలువతో `predicate` కి కాల్ చేసి తిరిగి వస్తుంది:
    ///
    ///
    /// - [`Some(t)`] `predicate` `true` ను తిరిగి ఇస్తే (ఇక్కడ `t` చుట్టిన విలువ), మరియు
    /// - [`None`] `predicate` `false` ను తిరిగి ఇస్తే.
    ///
    /// ఈ ఫంక్షన్ [`Iterator::filter()`] మాదిరిగానే పనిచేస్తుంది.
    /// `Option<T>` ఒకటి లేదా సున్నా మూలకాలపై మళ్ళిగా ఉంటుందని మీరు can హించవచ్చు.
    /// `filter()` ఏ అంశాలను ఉంచాలో నిర్ణయించడానికి మిమ్మల్ని అనుమతిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// ఇది విలువను కలిగి ఉంటే ఎంపికను అందిస్తుంది, లేకపోతే `optb` ను అందిస్తుంది.
    ///
    /// `or` కు పంపిన వాదనలు ఆసక్తిగా అంచనా వేయబడతాయి;మీరు ఫంక్షన్ కాల్ ఫలితాన్ని దాటితే, [`or_else`] ను ఉపయోగించమని సిఫార్సు చేయబడింది, ఇది సోమరితనం అంచనా వేయబడుతుంది.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// ఆప్షన్ విలువను కలిగి ఉంటే దాన్ని అందిస్తుంది, లేకపోతే `f` కి కాల్ చేసి ఫలితాన్ని ఇస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// `self` లో సరిగ్గా ఒకటి ఉంటే [`Some`] ను అందిస్తుంది, `optb` [`Some`], లేకపోతే [`None`] ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ఏదీ లేకపోతే చొప్పించడానికి మరియు సూచనను తిరిగి ఇవ్వడానికి ఎంట్రీ లాంటి ఆపరేషన్లు
    /////////////////////////////////////////////////////////////////////////

    /// [`None`] ఉంటే `value` ఎంపికలోకి చొప్పించి, ఆపై ఉన్న విలువకు మార్చగల సూచనను అందిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// [`None`] అయితే డిఫాల్ట్ విలువను ఆప్షన్‌లోకి చొప్పించి, ఆపై ఉన్న విలువకు మార్చగల సూచనను తిరిగి ఇస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// [`None`] అయితే `f` నుండి లెక్కించిన విలువను ఆప్షన్‌లోకి చొప్పించి, ఆపై ఉన్న విలువకు మార్చగల సూచనను అందిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // భద్రత: `self` కోసం `None` వేరియంట్ స్థానంలో `Some` ఉండేది
            // పై కోడ్‌లోని వేరియంట్.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// ఎంపిక నుండి విలువను తీసుకుంటుంది, దాని స్థానంలో [`None`] ను వదిలివేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// పారామితిలో ఇచ్చిన విలువ ద్వారా ఆప్షన్‌లోని వాస్తవ విలువను భర్తీ చేస్తుంది, పాత విలువను కలిగి ఉంటే తిరిగి ఇస్తుంది, ఒక [`Some`] ను దాని స్థానంలో ఒకదానిని విడదీయకుండా వదిలివేస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// మరొక `Option` తో జిప్స్ `self`.
    ///
    /// `self` `Some(s)` మరియు `other` `Some(o)` అయితే, ఈ పద్ధతి `Some((s, o))` ను అందిస్తుంది.
    /// లేకపోతే, `None` తిరిగి ఇవ్వబడుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// జిప్స్ `self` మరియు మరొక `Option` ఫంక్షన్ `f` తో.
    ///
    /// `self` `Some(s)` మరియు `other` `Some(o)` అయితే, ఈ పద్ధతి `Some(f(s, o))` ను అందిస్తుంది.
    /// లేకపోతే, `None` తిరిగి ఇవ్వబడుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// ఎంపిక యొక్క విషయాలను కాపీ చేయడం ద్వారా `Option<&T>` ను `Option<T>` కు మ్యాప్ చేస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// ఎంపిక యొక్క విషయాలను కాపీ చేయడం ద్వారా `Option<&mut T>` ను `Option<T>` కు మ్యాప్ చేస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// ఆప్షన్ యొక్క విషయాలను క్లోన్ చేయడం ద్వారా `Option<&T>` ను `Option<T>` కు మ్యాప్ చేస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// ఆప్షన్ యొక్క విషయాలను క్లోన్ చేయడం ద్వారా `Option<&mut T>` ను `Option<T>` కు మ్యాప్ చేస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// [`None`] ను ఆశించేటప్పుడు మరియు ఏమీ ఇవ్వనప్పుడు `self` ను వినియోగిస్తుంది.
    ///
    /// # Panics
    ///
    /// Panics విలువ [`Some`] అయితే, ఆమోదించిన సందేశంతో సహా panic సందేశంతో మరియు [`Some`] యొక్క కంటెంట్‌తో.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // ఇది panic కాదు, ఎందుకంటే అన్ని కీలు ప్రత్యేకమైనవి.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// [`None`] ను ఆశించేటప్పుడు మరియు ఏమీ ఇవ్వనప్పుడు `self` ను వినియోగిస్తుంది.
    ///
    /// # Panics
    ///
    /// Panics విలువ [`Some`] అయితే, [`కొన్ని`] విలువ అందించిన కస్టమ్ panic సందేశంతో.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // ఇది panic కాదు, ఎందుకంటే అన్ని కీలు ప్రత్యేకమైనవి.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// ఉన్న [`Some`] విలువ లేదా డిఫాల్ట్‌ను అందిస్తుంది
    ///
    /// `self` ఆర్గ్యుమెంట్‌ను వినియోగిస్తుంది, [`Some`] ఉంటే, ఉన్న విలువను తిరిగి ఇస్తుంది, లేకపోతే [`None`] అయితే, ఆ రకానికి [default value] ను తిరిగి ఇస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// స్ట్రింగ్‌ను పూర్ణాంకంగా మారుస్తుంది, పేలవంగా ఏర్పడిన తీగలను 0 గా మారుస్తుంది (పూర్ణాంకాలకు డిఫాల్ట్ విలువ).
    /// [`parse`] [`FromStr`] ను అమలు చేసే స్ట్రింగ్‌ను మరే ఇతర రకానికి మారుస్తుంది, [`None`] ను లోపం మీద తిరిగి ఇస్తుంది.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>` (లేదా `&Option<T>`) నుండి `Option<&T::Target>` కి మారుస్తుంది.
    ///
    /// అసలు ఎంపికను స్థలంలోనే వదిలివేసి, అసలుదానికి సూచనతో క్రొత్తదాన్ని సృష్టిస్తుంది, అదనంగా [`Deref`] ద్వారా విషయాలను బలవంతం చేస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>` (లేదా `&mut Option<T>`) నుండి `Option<&mut T::Target>` కి మారుస్తుంది.
    ///
    /// అసలు `Option` ను ఆ స్థలంలో వదిలివేసి, లోపలి రకం `Deref::Target` రకానికి మార్చగల సూచనను కలిగి ఉన్న క్రొత్తదాన్ని సృష్టిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// [`Result`] యొక్క `Option` ను `Option` యొక్క [`Result`] గా మారుస్తుంది.
    ///
    /// [`None`] [`సరే`]`(`[`ఏదీ`] `)` కు మ్యాప్ చేయబడుతుంది.
    /// [`కొన్ని`]`(`[`సరే`] `(_))` మరియు [`కొన్ని`]`(`[`లోపం`] `(_))` [`సరే`]`(`[`కొన్ని`] `(_))` మరియు [`లోపం`]`(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// .expect() యొక్క కోడ్ పరిమాణాన్ని తగ్గించడానికి ఇది ఒక ప్రత్యేక ఫంక్షన్.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// .expect_none() యొక్క కోడ్ పరిమాణాన్ని తగ్గించడానికి ఇది ఒక ప్రత్యేక ఫంక్షన్.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait అమలు
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// బహుశా కలిగి ఉన్న విలువ కంటే వినియోగించే ఇరేటర్‌ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// `val` ను కొత్త `Some` లోకి కాపీ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>` నుండి `Option<&T>` కి మారుస్తుంది.
    ///
    /// # Examples
    ///
    /// `ఆప్షన్ <` [`స్ట్రింగ్`]`>`ను`ఆప్షన్ <`[`యూజ్`] `>` గా మారుస్తుంది, అసలైనదాన్ని సంరక్షిస్తుంది.
    /// [`map`] పద్ధతి `self` ఆర్గ్యుమెంట్‌ను విలువ ద్వారా తీసుకుంటుంది, అసలైనదాన్ని తీసుకుంటుంది, కాబట్టి ఈ టెక్నిక్ `as_ref` ను మొదట `Option` ను అసలు లోపల ఉన్న విలువకు సూచనగా తీసుకుంటుంది.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>` నుండి `Option<&mut T>` కి మారుస్తుంది
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// ఎంపిక ఇటిరేటర్లు
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// [`Option`] యొక్క [`Some`] వేరియంట్‌కు సూచనగా ఒక ఇరేటర్.
///
/// [`Option`] ఒక [`Some`] అయితే ఇరేటర్ ఒక విలువను ఇస్తుంది, లేకపోతే ఏదీ లేదు.
///
/// ఈ `struct` [`Option::iter`] ఫంక్షన్ ద్వారా సృష్టించబడుతుంది.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// [`Option`] యొక్క [`Some`] వేరియంట్‌కు మార్చగల సూచనపై ఇటరేటర్.
///
/// [`Option`] ఒక [`Some`] అయితే ఇరేటర్ ఒక విలువను ఇస్తుంది, లేకపోతే ఏదీ లేదు.
///
/// ఈ `struct` [`Option::iter_mut`] ఫంక్షన్ ద్వారా సృష్టించబడుతుంది.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// [`Option`] యొక్క [`Some`] వేరియంట్‌లోని విలువపై ఇటరేటర్.
///
/// [`Option`] ఒక [`Some`] అయితే ఇరేటర్ ఒక విలువను ఇస్తుంది, లేకపోతే ఏదీ లేదు.
///
/// ఈ `struct` [`Option::into_iter`] ఫంక్షన్ ద్వారా సృష్టించబడుతుంది.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// [`Iterator`] లోని ప్రతి మూలకాన్ని తీసుకుంటుంది: ఇది [`None`][Option::None] అయితే, మరిన్ని అంశాలు తీసుకోబడవు మరియు [`None`][Option::None] తిరిగి ఇవ్వబడుతుంది.
    /// [`None`][Option::None] సంభవించకపోతే, ప్రతి [`Option`] విలువలతో కూడిన కంటైనర్ తిరిగి ఇవ్వబడుతుంది.
    ///
    /// # Examples
    ///
    /// vector లోని ప్రతి పూర్ణాంకాన్ని పెంచే ఉదాహరణ ఇక్కడ ఉంది.
    /// మేము `add` యొక్క తనిఖీ చేసిన వేరియంట్‌ను ఉపయోగిస్తాము, అది `None` ను తిరిగి ఇస్తుంది.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// మీరు గమనిస్తే, ఇది expected హించిన, చెల్లుబాటు అయ్యే అంశాలను తిరిగి ఇస్తుంది.
    ///
    /// పూర్ణాంకాల యొక్క మరొక జాబితా నుండి ఒకదాన్ని తీసివేయడానికి ప్రయత్నించే మరొక ఉదాహరణ ఇక్కడ ఉంది, ఈసారి అండర్ ఫ్లో కోసం తనిఖీ చేస్తుంది:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// చివరి మూలకం సున్నా కాబట్టి, అది పొంగిపోతుంది.అందువలన, ఫలిత విలువ `None`.
    ///
    /// మునుపటి ఉదాహరణపై ఒక వైవిధ్యం ఇక్కడ ఉంది, మొదటి `None` తరువాత `iter` నుండి మరిన్ని అంశాలు తీసుకోబడలేదని చూపిస్తుంది.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// మూడవ మూలకం అండర్ ఫ్లోకు కారణమైనందున, తదుపరి అంశాలు ఏవీ తీసుకోబడలేదు, కాబట్టి `shared` యొక్క తుది విలువ 6 (= `3 + 2 + 1`), 16 కాదు.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): ఈ పనితీరు బగ్ మూసివేయబడినప్పుడు దీన్ని Iterator::scan తో భర్తీ చేయవచ్చు.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// ప్రయత్నించండి ఆపరేటర్ (`?`) ను `None` విలువకు వర్తింపజేయడం వల్ల వచ్చే లోపం రకం.
/// మీరు `x?` (ఇక్కడ `x` ఒక `Option<T>`) ను మీ లోపం రకంగా మార్చడానికి అనుమతించాలనుకుంటే, మీరు `YourErrorType` కోసం `impl From<NoneError>` ను అమలు చేయవచ్చు.
///
/// అలాంటప్పుడు, `Result<_, YourErrorType>` ను తిరిగి ఇచ్చే ఫంక్షన్‌లోని `x?` ఒక `None` విలువను `Err` ఫలితంలోకి అనువదిస్తుంది.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>` నుండి `Option<T>` కి మారుస్తుంది
    ///
    /// # Examples
    ///
    /// ప్రాథమిక వినియోగం:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// చదును చేయడం ఒక సమయంలో ఒక స్థాయి గూడును మాత్రమే తొలగిస్తుంది:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}