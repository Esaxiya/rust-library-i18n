//! అణు రకాలు
//!
//! పరమాణు రకాలు థ్రెడ్ల మధ్య ఆదిమ షేర్డ్-మెమరీ కమ్యూనికేషన్‌ను అందిస్తాయి మరియు ఇతర ఏకకాలిక రకాలను బిల్డింగ్ బ్లాక్‌లు.
//!
//! ఈ మాడ్యూల్ [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], మొదలైన వాటితో సహా ఎంచుకున్న ఆదిమ రకాల యొక్క పరమాణు సంస్కరణలను నిర్వచిస్తుంది.
//! అణు రకాలు ఆపరేషన్లను ప్రదర్శిస్తాయి, అవి సరిగ్గా ఉపయోగించినప్పుడు, థ్రెడ్ల మధ్య నవీకరణలను సమకాలీకరిస్తాయి.
//!
//! ప్రతి పద్ధతి [`Ordering`] ను తీసుకుంటుంది, ఇది ఆ ఆపరేషన్ కోసం మెమరీ అవరోధం యొక్క బలాన్ని సూచిస్తుంది.ఈ ఆర్డరింగ్‌లు [C++20 atomic orderings][1] వలె ఉంటాయి.మరింత సమాచారం కోసం [nomicon][2] చూడండి.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! పరమాణు వేరియబుల్స్ థ్రెడ్ల మధ్య భాగస్వామ్యం చేయడానికి సురక్షితం (అవి [`Sync`] ను అమలు చేస్తాయి) కాని అవి Rust యొక్క [threading model](../../../std/thread/index.html#the-threading-model) ను పంచుకోవడానికి మరియు అనుసరించడానికి యంత్రాంగాన్ని అందించవు.
//!
//! అణు వేరియబుల్‌ను పంచుకోవడానికి అత్యంత సాధారణ మార్గం ఏమిటంటే దానిని [`Arc`][arc] (అణు-సూచన-లెక్కించిన షేర్డ్ పాయింటర్) లో ఉంచడం.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! అణు రకాలను స్టాటిక్ వేరియబుల్స్‌లో నిల్వ చేయవచ్చు, [`AtomicBool::new`] వంటి స్థిరమైన ఇనిషియేజర్‌లను ఉపయోగించి ప్రారంభించబడుతుంది.సోమరితనం ప్రపంచ ప్రారంభానికి అణు గణాంకాలు తరచుగా ఉపయోగించబడతాయి.
//!
//! # Portability
//!
//! ఈ మాడ్యూల్‌లోని అన్ని అణు రకాలు అవి అందుబాటులో ఉంటే [lock-free] అని హామీ ఇవ్వబడతాయి.దీని అర్థం వారు అంతర్గతంగా గ్లోబల్ మ్యూటెక్స్‌ను పొందలేరు.అణు రకాలు మరియు కార్యకలాపాలు వేచి ఉండకుండా హామీ ఇవ్వబడవు.
//! అంటే `fetch_or` వంటి కార్యకలాపాలు పోలిక-మరియు-స్వాప్ లూప్‌తో అమలు చేయబడవచ్చు.
//!
//! పెద్ద-పరిమాణ అణువులతో బోధనా పొర వద్ద అణు కార్యకలాపాలను అమలు చేయవచ్చు.ఉదాహరణకు, కొన్ని ప్లాట్‌ఫారమ్‌లు `AtomicI8` ను అమలు చేయడానికి 4-బైట్ అణు సూచనలను ఉపయోగిస్తాయి.
//! ఈ ఎమ్యులేషన్ కోడ్ యొక్క ఖచ్చితత్వంపై ప్రభావం చూపకూడదని గమనించండి, ఇది తెలుసుకోవలసిన విషయం.
//!
//! ఈ మాడ్యూల్‌లోని అణు రకాలు అన్ని ప్లాట్‌ఫామ్‌లలో అందుబాటులో ఉండకపోవచ్చు.ఇక్కడ అణు రకాలు అన్నీ విస్తృతంగా అందుబాటులో ఉన్నాయి, అయితే సాధారణంగా ఉన్న వాటిపై ఆధారపడవచ్చు.కొన్ని ముఖ్యమైన మినహాయింపులు:
//!
//! * PowerPC మరియు 32-బిట్ పాయింటర్లతో MIPS ప్లాట్‌ఫారమ్‌లకు `AtomicU64` లేదా `AtomicI64` రకాలు లేవు.
//! * ARM Linux కోసం లేని `armv5te` వంటి ప్లాట్‌ఫారమ్‌లు `load` మరియు `store` ఆపరేషన్లను మాత్రమే అందిస్తాయి మరియు `swap`, `fetch_add`, వంటి (CAS) ఆపరేషన్‌లను పోల్చండి మరియు స్వాప్ చేయవద్దు.
//! అదనంగా Linux లో, ఈ CAS ఆపరేషన్లు [operating system support] ద్వారా అమలు చేయబడతాయి, ఇది పనితీరు పెనాల్టీతో రావచ్చు.
//! * ARM `thumbv6m` తో లక్ష్యాలు `load` మరియు `store` ఆపరేషన్లను మాత్రమే అందిస్తాయి మరియు `swap`, `fetch_add`, వంటి (CAS) ఆపరేషన్లను పోల్చండి మరియు స్వాప్ చేయవద్దు.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! కొన్ని అణు కార్యకలాపాలకు మద్దతు లేని future ప్లాట్‌ఫారమ్‌లు జోడించబడతాయని గమనించండి.గరిష్టంగా పోర్టబుల్ కోడ్ ఏ అణు రకాలను ఉపయోగిస్తుందో జాగ్రత్తగా ఉండాలని కోరుకుంటుంది.
//! `AtomicUsize` మరియు `AtomicIsize` సాధారణంగా చాలా పోర్టబుల్, కానీ అప్పుడు కూడా అవి ప్రతిచోటా అందుబాటులో ఉండవు.
//! సూచన కోసం, `std` లైబ్రరీకి పాయింటర్-సైజ్ అటామిక్స్ అవసరం, అయినప్పటికీ `core` అవసరం లేదు.
//!
//! ప్రస్తుతం మీరు అణువులతో కోడ్‌లో షరతులతో కంపైల్ చేయడానికి `#[cfg(target_arch)]` ను ఉపయోగించాలి.అస్థిర `#[cfg(target_has_atomic)]` అలాగే future లో స్థిరీకరించబడవచ్చు.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! సాధారణ స్పిన్‌లాక్:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // లాక్ విడుదల చేయడానికి ఇతర థ్రెడ్ కోసం వేచి ఉండండి
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! ప్రత్యక్ష థ్రెడ్ల యొక్క ప్రపంచ గణనను ఉంచండి:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// థ్రెడ్ల మధ్య సురక్షితంగా భాగస్వామ్యం చేయగల బూలియన్ రకం.
///
/// ఈ రకానికి [`bool`] వలె అదే ఇన్-మెమరీ ప్రాతినిధ్యం ఉంది.
///
/// **గమనిక**: ఈ రకం `u8` యొక్క అణు లోడ్లు మరియు దుకాణాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` కు ప్రారంభించిన `AtomicBool` ను సృష్టిస్తుంది.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// అటామిక్బూల్ కోసం పంపు అవ్యక్తంగా అమలు చేయబడుతుంది.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// ముడి పాయింటర్ రకం, ఇది థ్రెడ్ల మధ్య సురక్షితంగా పంచుకోవచ్చు.
///
/// ఈ రకానికి `*mut T` వలె అదే ఇన్-మెమరీ ప్రాతినిధ్యం ఉంది.
///
/// **గమనిక**: ఈ రకం అణు లోడ్లు మరియు పాయింటర్ల దుకాణాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
/// దీని పరిమాణం లక్ష్య పాయింటర్ పరిమాణంపై ఆధారపడి ఉంటుంది.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// శూన్య `AtomicPtr<T>` ను సృష్టిస్తుంది.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// అటామిక్ మెమరీ ఆర్డరింగ్స్
///
/// మెమరీ ఆర్డరింగ్‌లు పరమాణు కార్యకలాపాలు మెమరీని సమకాలీకరించే విధానాన్ని తెలుపుతాయి.
/// దాని బలహీనమైన [`Ordering::Relaxed`] లో, ఆపరేషన్ ద్వారా నేరుగా తాకిన మెమరీ మాత్రమే సమకాలీకరించబడుతుంది.
/// మరోవైపు, [`Ordering::SeqCst`] ఆపరేషన్ల యొక్క స్టోర్-లోడ్ జత ఇతర మెమరీని సమకాలీకరిస్తుంది, అదనంగా అన్ని థ్రెడ్‌లలో ఇటువంటి ఆపరేషన్ల యొక్క మొత్తం క్రమాన్ని సంరక్షిస్తుంది.
///
///
/// Rust యొక్క మెమరీ ఆర్డరింగ్‌లు [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// మరింత సమాచారం కోసం [nomicon] చూడండి.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// ఆర్డరింగ్ అడ్డంకులు లేవు, అణు కార్యకలాపాలు మాత్రమే.
    ///
    /// C ++ 20 లోని [`memory_order_relaxed`] కి అనుగుణంగా ఉంటుంది.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// దుకాణంతో జతచేయబడినప్పుడు, మునుపటి విలువలు [`Acquire`] (లేదా బలమైన) ఆర్డరింగ్‌తో ఈ విలువ యొక్క ఏదైనా లోడ్‌కు ముందు ఆర్డర్ చేయబడతాయి.
    ///
    /// ముఖ్యంగా, మునుపటి విలువలు ఈ విలువ యొక్క [`Acquire`] (లేదా బలమైన) లోడ్‌ను చేసే అన్ని థ్రెడ్‌లకు కనిపిస్తాయి.
    ///
    /// లోడ్లు మరియు దుకాణాలను కలిపే ఆపరేషన్ కోసం ఈ ఆర్డరింగ్ ఉపయోగించడం [`Relaxed`] లోడ్ ఆపరేషన్‌కు దారితీస్తుందని గమనించండి!
    ///
    /// ఈ ఆర్డరింగ్ స్టోర్ చేయగల ఆపరేషన్లకు మాత్రమే వర్తిస్తుంది.
    ///
    /// C ++ 20 లోని [`memory_order_release`] కి అనుగుణంగా ఉంటుంది.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// లోడ్‌తో కలిసి ఉన్నప్పుడు, లోడ్ చేసిన విలువ [`Release`] (లేదా బలమైన) ఆర్డరింగ్‌తో స్టోర్ ఆపరేషన్ ద్వారా వ్రాయబడితే, ఆ తరువాత అన్ని ఆపరేషన్లు ఆ స్టోర్ తర్వాత ఆర్డర్ అవుతాయి.
    /// ముఖ్యంగా, అన్ని తదుపరి లోడ్లు స్టోర్ ముందు వ్రాసిన డేటాను చూస్తాయి.
    ///
    /// లోడ్లు మరియు దుకాణాలను కలిపే ఆపరేషన్ కోసం ఈ ఆర్డరింగ్ ఉపయోగించడం [`Relaxed`] స్టోర్ ఆపరేషన్‌కు దారితీస్తుందని గమనించండి!
    ///
    /// ఈ ఆర్డరింగ్ లోడ్ చేయగల ఆపరేషన్లకు మాత్రమే వర్తిస్తుంది.
    ///
    /// C ++ 20 లోని [`memory_order_acquire`] కి అనుగుణంగా ఉంటుంది.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// [`Acquire`] మరియు [`Release`] రెండింటి ప్రభావాలను కలిపి కలిగి ఉంది:
    /// లోడ్ల కోసం ఇది [`Acquire`] ఆర్డరింగ్ ఉపయోగిస్తుంది.దుకాణాల కోసం ఇది [`Release`] ఆర్డరింగ్‌ను ఉపయోగిస్తుంది.
    ///
    /// `compare_and_swap` విషయంలో, ఆపరేషన్ ఏ దుకాణాన్ని ప్రదర్శించకుండా ముగుస్తుందని మరియు అందువల్ల ఇది కేవలం [`Acquire`] ఆర్డరింగ్ కలిగి ఉందని గమనించండి.
    ///
    /// అయినప్పటికీ, `AcqRel` [`Relaxed`] యాక్సెస్‌లను ఎప్పటికీ చేయదు.
    ///
    /// లోడ్లు మరియు దుకాణాలు రెండింటినీ కలిపే కార్యకలాపాలకు మాత్రమే ఈ ఆర్డరింగ్ వర్తిస్తుంది.
    ///
    /// C ++ 20 లోని [`memory_order_acq_rel`] కి అనుగుణంగా ఉంటుంది.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// అన్ని థ్రెడ్‌లు ఒకే క్రమంలో అన్ని స్థిరమైన ఆపరేషన్‌లను ఒకే క్రమంలో చూస్తాయనే అదనపు హామీతో [`స్వాధీనం`]/[`విడుదల`]/[`అక్క్రెల్`](వరుసగా లోడ్, స్టోర్ మరియు స్టోర్-విత్-స్టోర్ ఆపరేషన్ల కోసం) లాగా. .
    ///
    ///
    /// C ++ 20 లోని [`memory_order_seq_cst`] కి అనుగుణంగా ఉంటుంది.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] `false` కు ప్రారంభించబడింది.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// క్రొత్త `AtomicBool` ను సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// అంతర్లీన [`bool`] కు మార్చగల సూచనను అందిస్తుంది.
    ///
    /// ఇది సురక్షితం ఎందుకంటే మ్యుటబుల్ రిఫరెన్స్ ఏ ఇతర థ్రెడ్‌లు ఏకకాలంలో అణు డేటాను యాక్సెస్ చేయలేదని హామీ ఇస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // భద్రత: మార్చగల సూచన ప్రత్యేక యాజమాన్యానికి హామీ ఇస్తుంది.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// `&mut bool` కు అణు ప్రాప్యతను పొందండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // భద్రత: మార్చగల సూచన ప్రత్యేక యాజమాన్యానికి హామీ ఇస్తుంది మరియు
        // `bool` మరియు `Self` రెండింటి అమరిక 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// పరమాణువును వినియోగిస్తుంది మరియు ఉన్న విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఇది సురక్షితం ఎందుకంటే `self` ను విలువ ద్వారా పాస్ చేస్తే ఇతర థ్రెడ్‌లు ఏకకాలంలో అణు డేటాను యాక్సెస్ చేయలేవని హామీ ఇస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool నుండి విలువను లోడ్ చేస్తుంది.
    ///
    /// `load` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.
    /// సాధ్యమయ్యే విలువలు [`SeqCst`], [`Acquire`] మరియు [`Relaxed`].
    ///
    /// # Panics
    ///
    /// `order` [`Release`] లేదా [`AcqRel`] అయితే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // భద్రత: ఏదైనా డేటా రేసులు అణు అంతర్గత మరియు ముడి ద్వారా నిరోధించబడతాయి
        // పంపిన పాయింటర్ చెల్లుతుంది ఎందుకంటే మేము దానిని సూచన నుండి పొందాము.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool లోకి విలువను నిల్వ చేస్తుంది.
    ///
    /// `store` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.
    /// సాధ్యమయ్యే విలువలు [`SeqCst`], [`Release`] మరియు [`Relaxed`].
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] లేదా [`AcqRel`] అయితే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // భద్రత: ఏదైనా డేటా రేసులు అణు అంతర్గత మరియు ముడి ద్వారా నిరోధించబడతాయి
        // పంపిన పాయింటర్ చెల్లుతుంది ఎందుకంటే మేము దానిని సూచన నుండి పొందాము.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// మునుపటి విలువను తిరిగి ఇచ్చే విలువను bool లోకి నిల్వ చేస్తుంది.
    ///
    /// `swap` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
    /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
    ///
    ///
    /// **Note:** ఈ పద్ధతి `u8` లో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// ప్రస్తుత విలువ `current` విలువకు సమానంగా ఉంటే విలువను [`bool`] లోకి నిల్వ చేస్తుంది.
    ///
    /// తిరిగి వచ్చే విలువ ఎల్లప్పుడూ మునుపటి విలువ.ఇది `current` కి సమానం అయితే, అప్పుడు విలువ నవీకరించబడింది.
    ///
    /// `compare_and_swap` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ కూడా తీసుకుంటుంది.
    /// [`AcqRel`] ను ఉపయోగిస్తున్నప్పుడు కూడా, ఆపరేషన్ విఫలం కావచ్చు మరియు అందువల్ల కేవలం `Acquire` లోడ్ చేయగలదు, కానీ `Release` సెమాంటిక్స్ లేదు.
    /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో స్టోర్ జరిగితే, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
    ///
    /// **Note:** ఈ పద్ధతి `u8` లో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # `compare_exchange` మరియు `compare_exchange_weak` కు వలసపోతోంది
    ///
    /// `compare_and_swap` మెమరీ ఆర్డరింగ్ కోసం కింది మ్యాపింగ్ తో `compare_exchange` కి సమానం:
    ///
    /// అసలు |విజయం |వైఫల్యం
    /// -------- | ------- | -------
    /// రిలాక్స్డ్ |రిలాక్స్డ్ |రిలాక్స్డ్ అక్వైర్ |సంపాదించండి |విడుదలను పొందండి |విడుదల |రిలాక్స్డ్ అక్క్రెల్ |అక్క్రెల్ |SeqCst ని పొందండి |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` పోలిక విజయవంతం అయినప్పుడు కూడా విఫలం కావడానికి అనుమతించబడుతుంది, ఇది లూప్‌లో పోలిక మరియు స్వాప్ ఉపయోగించినప్పుడు కంపైలర్ మెరుగైన అసెంబ్లీ కోడ్‌ను రూపొందించడానికి అనుమతిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// ప్రస్తుత విలువ `current` విలువకు సమానంగా ఉంటే విలువను [`bool`] లోకి నిల్వ చేస్తుంది.
    ///
    /// రిటర్న్ వాల్యూ అనేది క్రొత్త విలువ వ్రాయబడిందా లేదా మునుపటి విలువను కలిగి ఉందా అని సూచించే ఫలితం.
    /// విజయవంతం అయినప్పుడు ఈ విలువ `current` కి సమానంగా ఉంటుందని హామీ ఇవ్వబడింది.
    ///
    /// `compare_exchange` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించడానికి రెండు [`Ordering`] వాదనలు పడుతుంది.
    /// `success` `current` తో పోలిక విజయవంతమైతే జరిగే రీడ్-మోడిఫై-రైట్ ఆపరేషన్ కోసం అవసరమైన ఆర్డరింగ్‌ను వివరిస్తుంది.
    /// `failure` పోలిక విఫలమైనప్పుడు జరిగే లోడ్ ఆపరేషన్ కోసం అవసరమైన క్రమాన్ని వివరిస్తుంది.
    /// [`Acquire`] ను సక్సెస్ ఆర్డరింగ్‌గా ఉపయోగించడం వలన స్టోర్ ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వల్ల విజయవంతమైన లోడ్ [`Relaxed`] అవుతుంది.
    ///
    /// వైఫల్యం క్రమం [`SeqCst`], [`Acquire`] లేదా [`Relaxed`] మాత్రమే కావచ్చు మరియు విజయ క్రమం కంటే సమానంగా లేదా బలహీనంగా ఉండాలి.
    ///
    /// **Note:** ఈ పద్ధతి `u8` లో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// ప్రస్తుత విలువ `current` విలువకు సమానంగా ఉంటే విలువను [`bool`] లోకి నిల్వ చేస్తుంది.
    ///
    /// [`AtomicBool::compare_exchange`] మాదిరిగా కాకుండా, పోలిక విజయవంతం అయినప్పుడు కూడా ఈ ఫంక్షన్ నకిలీగా విఫలమవుతుంది, ఇది కొన్ని ప్లాట్‌ఫామ్‌లపై మరింత సమర్థవంతమైన కోడ్‌కు దారితీస్తుంది.
    ///
    /// రిటర్న్ వాల్యూ అనేది క్రొత్త విలువ వ్రాయబడిందా లేదా మునుపటి విలువను కలిగి ఉందా అని సూచించే ఫలితం.
    ///
    /// `compare_exchange_weak` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించడానికి రెండు [`Ordering`] వాదనలు పడుతుంది.
    /// `success` `current` తో పోలిక విజయవంతమైతే జరిగే రీడ్-మోడిఫై-రైట్ ఆపరేషన్ కోసం అవసరమైన ఆర్డరింగ్‌ను వివరిస్తుంది.
    /// `failure` పోలిక విఫలమైనప్పుడు జరిగే లోడ్ ఆపరేషన్ కోసం అవసరమైన క్రమాన్ని వివరిస్తుంది.
    /// [`Acquire`] ను సక్సెస్ ఆర్డరింగ్‌గా ఉపయోగించడం వలన స్టోర్ ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వల్ల విజయవంతమైన లోడ్ [`Relaxed`] అవుతుంది.
    /// వైఫల్యం క్రమం [`SeqCst`], [`Acquire`] లేదా [`Relaxed`] మాత్రమే కావచ్చు మరియు విజయ క్రమం కంటే సమానంగా లేదా బలహీనంగా ఉండాలి.
    ///
    /// **Note:** ఈ పద్ధతి `u8` లో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// బూలియన్ విలువతో లాజికల్ "and".
    ///
    /// ప్రస్తుత విలువ మరియు ఆర్గ్యుమెంట్ `val` పై తార్కిక "and" ఆపరేషన్ చేస్తుంది మరియు ఫలితానికి కొత్త విలువను సెట్ చేస్తుంది.
    ///
    /// మునుపటి విలువను అందిస్తుంది.
    ///
    /// `fetch_and` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
    /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
    ///
    ///
    /// **Note:** ఈ పద్ధతి `u8` లో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// బూలియన్ విలువతో లాజికల్ "nand".
    ///
    /// ప్రస్తుత విలువ మరియు ఆర్గ్యుమెంట్ `val` పై తార్కిక "nand" ఆపరేషన్ చేస్తుంది మరియు ఫలితానికి కొత్త విలువను సెట్ చేస్తుంది.
    ///
    /// మునుపటి విలువను అందిస్తుంది.
    ///
    /// `fetch_nand` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
    /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
    ///
    ///
    /// **Note:** ఈ పద్ధతి `u8` లో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // మేము ఇక్కడ atomic_nand ను ఉపయోగించలేము ఎందుకంటే ఇది చెల్లని విలువతో bool కు దారితీస్తుంది.
        // అణు ఆపరేషన్ అంతర్గతంగా 8-బిట్ పూర్ణాంకంతో జరుగుతుంది, ఇది ఎగువ 7 బిట్‌లను సెట్ చేస్తుంది.
        //
        // కాబట్టి మేము బదులుగా fetch_xor లేదా swap ని ఉపయోగిస్తాము.
        if val {
            // ! (x&true)== !x మనం bool ను విలోమం చేయాలి.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true మనం bool ని ఒప్పుకు సెట్ చేయాలి.
            //
            self.swap(true, order)
        }
    }

    /// బూలియన్ విలువతో లాజికల్ "or".
    ///
    /// ప్రస్తుత విలువ మరియు ఆర్గ్యుమెంట్ `val` పై తార్కిక "or" ఆపరేషన్ చేస్తుంది మరియు ఫలితానికి కొత్త విలువను సెట్ చేస్తుంది.
    ///
    /// మునుపటి విలువను అందిస్తుంది.
    ///
    /// `fetch_or` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
    /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
    ///
    ///
    /// **Note:** ఈ పద్ధతి `u8` లో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// బూలియన్ విలువతో లాజికల్ "xor".
    ///
    /// ప్రస్తుత విలువ మరియు ఆర్గ్యుమెంట్ `val` పై తార్కిక "xor" ఆపరేషన్ చేస్తుంది మరియు ఫలితానికి కొత్త విలువను సెట్ చేస్తుంది.
    ///
    /// మునుపటి విలువను అందిస్తుంది.
    ///
    /// `fetch_xor` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
    /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
    ///
    ///
    /// **Note:** ఈ పద్ధతి `u8` లో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// మార్చగల పాయింటర్‌ను అంతర్లీన [`bool`] కు చూపుతుంది.
    ///
    /// ఫలిత పూర్ణాంకంపై అణు రహిత రీడ్‌లు మరియు వ్రాతలు చేయడం డేటా రేసు.
    /// ఈ పద్ధతి FFI కి ఎక్కువగా ఉపయోగపడుతుంది, ఇక్కడ ఫంక్షన్ సంతకం `&AtomicBool` కు బదులుగా `*mut bool` ను ఉపయోగించవచ్చు.
    ///
    /// ఈ పరమాణువుకు భాగస్వామ్య సూచన నుండి `*mut` పాయింటర్‌ను తిరిగి ఇవ్వడం సురక్షితం ఎందుకంటే అణు రకాలు అంతర్గత ఉత్పరివర్తనంతో పనిచేస్తాయి.
    /// అణు యొక్క అన్ని మార్పులు షేర్డ్ రిఫరెన్స్ ద్వారా విలువను మారుస్తాయి మరియు అవి అణు కార్యకలాపాలను ఉపయోగించేంతవరకు సురక్షితంగా చేయగలవు.
    /// తిరిగి వచ్చిన ముడి పాయింటర్ యొక్క ఏదైనా ఉపయోగం కోసం `unsafe` బ్లాక్ అవసరం మరియు ఇప్పటికీ అదే పరిమితిని సమర్థించాలి: దానిపై కార్యకలాపాలు పరమాణువుగా ఉండాలి.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// విలువను పొందుతుంది మరియు ఐచ్ఛిక క్రొత్త విలువను ఇచ్చే ఫంక్షన్‌ను దీనికి వర్తిస్తుంది.ఫంక్షన్ `Some(_)` ను తిరిగి ఇస్తే `Ok(previous_value)` యొక్క `Result` ను అందిస్తుంది, లేకపోతే `Err(previous_value)`.
    ///
    /// Note: ఫంక్షన్ `Some(_)` ను తిరిగి ఇచ్చేంతవరకు, ఇతర థ్రెడ్ల నుండి విలువ మార్చబడితే ఇది ఫంక్షన్‌ను చాలాసార్లు పిలుస్తుంది, అయితే ఫంక్షన్ నిల్వ చేసిన విలువకు ఒక్కసారి మాత్రమే వర్తించబడుతుంది.
    ///
    ///
    /// `fetch_update` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించడానికి రెండు [`Ordering`] వాదనలు పడుతుంది.
    /// మొదటిది ఆపరేషన్ చివరకు విజయవంతం కావడానికి అవసరమైన ఆర్డరింగ్‌ను వివరిస్తుంది, రెండవది లోడ్‌లకు అవసరమైన ఆర్డరింగ్‌ను వివరిస్తుంది.
    /// ఇవి వరుసగా [`AtomicBool::compare_exchange`] యొక్క విజయం మరియు వైఫల్య క్రమాన్ని సూచిస్తాయి.
    ///
    /// [`Acquire`] ను సక్సెస్ ఆర్డరింగ్‌గా ఉపయోగించడం వలన స్టోర్ ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన తుది విజయవంతమైన లోడ్ [`Relaxed`] అవుతుంది.
    /// (failed) లోడ్ ఆర్డరింగ్ [`SeqCst`], [`Acquire`] లేదా [`Relaxed`] మాత్రమే కావచ్చు మరియు సక్సెస్ ఆర్డరింగ్ కంటే సమానం లేదా బలహీనంగా ఉండాలి.
    ///
    /// **Note:** ఈ పద్ధతి `u8` లో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// క్రొత్త `AtomicPtr` ను సృష్టిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// అంతర్లీన పాయింటర్‌కు మార్చగల సూచనను అందిస్తుంది.
    ///
    /// ఇది సురక్షితం ఎందుకంటే మ్యుటబుల్ రిఫరెన్స్ ఏ ఇతర థ్రెడ్‌లు ఏకకాలంలో అణు డేటాను యాక్సెస్ చేయలేదని హామీ ఇస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// పాయింటర్‌కు అణు ప్రాప్యతను పొందండి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - మార్చగల సూచన ప్రత్యేక యాజమాన్యానికి హామీ ఇస్తుంది.
        //  - పైన ధృవీకరించినట్లుగా, rust చేత మద్దతిచ్చే అన్ని ప్లాట్‌ఫామ్‌లలో `*mut T` మరియు `Self` యొక్క అమరిక సమానంగా ఉంటుంది.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// పరమాణువును వినియోగిస్తుంది మరియు ఉన్న విలువను తిరిగి ఇస్తుంది.
    ///
    /// ఇది సురక్షితం ఎందుకంటే `self` ను విలువ ద్వారా పాస్ చేస్తే ఇతర థ్రెడ్‌లు ఏకకాలంలో అణు డేటాను యాక్సెస్ చేయలేవని హామీ ఇస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// పాయింటర్ నుండి విలువను లోడ్ చేస్తుంది.
    ///
    /// `load` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.
    /// సాధ్యమయ్యే విలువలు [`SeqCst`], [`Acquire`] మరియు [`Relaxed`].
    ///
    /// # Panics
    ///
    /// `order` [`Release`] లేదా [`AcqRel`] అయితే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// పాయింటర్‌లో విలువను నిల్వ చేస్తుంది.
    ///
    /// `store` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.
    /// సాధ్యమయ్యే విలువలు [`SeqCst`], [`Release`] మరియు [`Relaxed`].
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] లేదా [`AcqRel`] అయితే Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// మునుపటి విలువను తిరిగి ఇచ్చి, పాయింటర్‌లో విలువను నిల్వ చేస్తుంది.
    ///
    /// `swap` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
    /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
    ///
    ///
    /// **Note:** ఈ పద్ధతి పాయింటర్లలో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// ప్రస్తుత విలువ `current` విలువకు సమానంగా ఉంటే విలువను పాయింటర్‌లో నిల్వ చేస్తుంది.
    ///
    /// తిరిగి వచ్చే విలువ ఎల్లప్పుడూ మునుపటి విలువ.ఇది `current` కి సమానం అయితే, అప్పుడు విలువ నవీకరించబడింది.
    ///
    /// `compare_and_swap` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ కూడా తీసుకుంటుంది.
    /// [`AcqRel`] ను ఉపయోగిస్తున్నప్పుడు కూడా, ఆపరేషన్ విఫలం కావచ్చు మరియు అందువల్ల కేవలం `Acquire` లోడ్ చేయగలదు, కానీ `Release` సెమాంటిక్స్ లేదు.
    /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో స్టోర్ జరిగితే, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
    ///
    /// **Note:** ఈ పద్ధతి పాయింటర్లలో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # `compare_exchange` మరియు `compare_exchange_weak` కు వలసపోతోంది
    ///
    /// `compare_and_swap` మెమరీ ఆర్డరింగ్ కోసం కింది మ్యాపింగ్ తో `compare_exchange` కి సమానం:
    ///
    /// అసలు |విజయం |వైఫల్యం
    /// -------- | ------- | -------
    /// రిలాక్స్డ్ |రిలాక్స్డ్ |రిలాక్స్డ్ అక్వైర్ |సంపాదించండి |విడుదలను పొందండి |విడుదల |రిలాక్స్డ్ అక్క్రెల్ |అక్క్రెల్ |SeqCst ని పొందండి |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` పోలిక విజయవంతం అయినప్పుడు కూడా విఫలం కావడానికి అనుమతించబడుతుంది, ఇది లూప్‌లో పోలిక మరియు స్వాప్ ఉపయోగించినప్పుడు కంపైలర్ మెరుగైన అసెంబ్లీ కోడ్‌ను రూపొందించడానికి అనుమతిస్తుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// ప్రస్తుత విలువ `current` విలువకు సమానంగా ఉంటే విలువను పాయింటర్‌లో నిల్వ చేస్తుంది.
    ///
    /// రిటర్న్ వాల్యూ అనేది క్రొత్త విలువ వ్రాయబడిందా లేదా మునుపటి విలువను కలిగి ఉందా అని సూచించే ఫలితం.
    /// విజయవంతం అయినప్పుడు ఈ విలువ `current` కి సమానంగా ఉంటుందని హామీ ఇవ్వబడింది.
    ///
    /// `compare_exchange` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించడానికి రెండు [`Ordering`] వాదనలు పడుతుంది.
    /// `success` `current` తో పోలిక విజయవంతమైతే జరిగే రీడ్-మోడిఫై-రైట్ ఆపరేషన్ కోసం అవసరమైన ఆర్డరింగ్‌ను వివరిస్తుంది.
    /// `failure` పోలిక విఫలమైనప్పుడు జరిగే లోడ్ ఆపరేషన్ కోసం అవసరమైన క్రమాన్ని వివరిస్తుంది.
    /// [`Acquire`] ను సక్సెస్ ఆర్డరింగ్‌గా ఉపయోగించడం వలన స్టోర్ ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వల్ల విజయవంతమైన లోడ్ [`Relaxed`] అవుతుంది.
    ///
    /// వైఫల్యం క్రమం [`SeqCst`], [`Acquire`] లేదా [`Relaxed`] మాత్రమే కావచ్చు మరియు విజయ క్రమం కంటే సమానంగా లేదా బలహీనంగా ఉండాలి.
    ///
    /// **Note:** ఈ పద్ధతి పాయింటర్లలో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// ప్రస్తుత విలువ `current` విలువకు సమానంగా ఉంటే విలువను పాయింటర్‌లో నిల్వ చేస్తుంది.
    ///
    /// [`AtomicPtr::compare_exchange`] మాదిరిగా కాకుండా, పోలిక విజయవంతం అయినప్పుడు కూడా ఈ ఫంక్షన్ నకిలీగా విఫలమవుతుంది, ఇది కొన్ని ప్లాట్‌ఫామ్‌లపై మరింత సమర్థవంతమైన కోడ్‌కు దారితీస్తుంది.
    ///
    /// రిటర్న్ వాల్యూ అనేది క్రొత్త విలువ వ్రాయబడిందా లేదా మునుపటి విలువను కలిగి ఉందా అని సూచించే ఫలితం.
    ///
    /// `compare_exchange_weak` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించడానికి రెండు [`Ordering`] వాదనలు పడుతుంది.
    /// `success` `current` తో పోలిక విజయవంతమైతే జరిగే రీడ్-మోడిఫై-రైట్ ఆపరేషన్ కోసం అవసరమైన ఆర్డరింగ్‌ను వివరిస్తుంది.
    /// `failure` పోలిక విఫలమైనప్పుడు జరిగే లోడ్ ఆపరేషన్ కోసం అవసరమైన క్రమాన్ని వివరిస్తుంది.
    /// [`Acquire`] ను సక్సెస్ ఆర్డరింగ్‌గా ఉపయోగించడం వలన స్టోర్ ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వల్ల విజయవంతమైన లోడ్ [`Relaxed`] అవుతుంది.
    /// వైఫల్యం క్రమం [`SeqCst`], [`Acquire`] లేదా [`Relaxed`] మాత్రమే కావచ్చు మరియు విజయ క్రమం కంటే సమానంగా లేదా బలహీనంగా ఉండాలి.
    ///
    /// **Note:** ఈ పద్ధతి పాయింటర్లలో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // భద్రత: ముడి పాయింటర్‌లో పనిచేసేందున ఈ అంతర్గత సురక్షితం కాదు
        // కానీ పాయింటర్ చెల్లుబాటు అవుతుందని మాకు ఖచ్చితంగా తెలుసు (మేము దానిని సూచనల ద్వారా కలిగి ఉన్న `UnsafeCell` నుండి పొందాము) మరియు అణు ఆపరేషన్ కూడా `UnsafeCell` విషయాలను సురక్షితంగా మార్చడానికి అనుమతిస్తుంది.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// విలువను పొందుతుంది మరియు ఐచ్ఛిక క్రొత్త విలువను ఇచ్చే ఫంక్షన్‌ను దీనికి వర్తిస్తుంది.ఫంక్షన్ `Some(_)` ను తిరిగి ఇస్తే `Ok(previous_value)` యొక్క `Result` ను అందిస్తుంది, లేకపోతే `Err(previous_value)`.
    ///
    /// Note: ఫంక్షన్ `Some(_)` ను తిరిగి ఇచ్చేంతవరకు, ఇతర థ్రెడ్ల నుండి విలువ మార్చబడితే ఇది ఫంక్షన్‌ను చాలాసార్లు పిలుస్తుంది, అయితే ఫంక్షన్ నిల్వ చేసిన విలువకు ఒక్కసారి మాత్రమే వర్తించబడుతుంది.
    ///
    ///
    /// `fetch_update` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించడానికి రెండు [`Ordering`] వాదనలు పడుతుంది.
    /// మొదటిది ఆపరేషన్ చివరకు విజయవంతం కావడానికి అవసరమైన ఆర్డరింగ్‌ను వివరిస్తుంది, రెండవది లోడ్‌లకు అవసరమైన ఆర్డరింగ్‌ను వివరిస్తుంది.
    /// ఇవి వరుసగా [`AtomicPtr::compare_exchange`] యొక్క విజయం మరియు వైఫల్య క్రమాన్ని సూచిస్తాయి.
    ///
    /// [`Acquire`] ను సక్సెస్ ఆర్డరింగ్‌గా ఉపయోగించడం వలన స్టోర్ ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన తుది విజయవంతమైన లోడ్ [`Relaxed`] అవుతుంది.
    /// (failed) లోడ్ ఆర్డరింగ్ [`SeqCst`], [`Acquire`] లేదా [`Relaxed`] మాత్రమే కావచ్చు మరియు సక్సెస్ ఆర్డరింగ్ కంటే సమానం లేదా బలహీనంగా ఉండాలి.
    ///
    /// **Note:** ఈ పద్ధతి పాయింటర్లలో అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// `bool` ను `AtomicBool` గా మారుస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // ఈ స్థూలత కొన్ని నిర్మాణాలపై ఉపయోగించబడదు.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// థ్రెడ్ల మధ్య సురక్షితంగా భాగస్వామ్యం చేయగల పూర్ణాంక రకం.
        ///
        /// ఈ రకానికి అంతర్లీన పూర్ణాంక రకానికి సమానమైన ఇన్-మెమరీ ప్రాతినిధ్యం ఉంది, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// అణు రకాలు మరియు అణు రకాలు మధ్య వ్యత్యాసాల గురించి మరియు ఈ రకమైన పోర్టబిలిటీ గురించి సమాచారం కోసం, దయచేసి [module-level documentation] చూడండి.
        ///
        ///
        /// **Note:** ఈ రకం అణు లోడ్లు మరియు [`యొక్క దుకాణాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// ఒక అణు పూర్ణాంకం `0` కు ప్రారంభించబడింది.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // పంపడం అవ్యక్తంగా అమలు చేయబడుతుంది.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// క్రొత్త పరమాణు పూర్ణాంకాన్ని సృష్టిస్తుంది.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// అంతర్లీన పూర్ణాంకానికి మార్చగల సూచనను అందిస్తుంది.
            ///
            /// ఇది సురక్షితం ఎందుకంటే మ్యుటబుల్ రిఫరెన్స్ ఏ ఇతర థ్రెడ్‌లు ఏకకాలంలో అణు డేటాను యాక్సెస్ చేయలేదని హామీ ఇస్తుంది.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// మ్యూట్ some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - మార్చగల సూచన ప్రత్యేక యాజమాన్యానికి హామీ ఇస్తుంది.
                //  - `$int_type` మరియు `Self` యొక్క అమరిక $cfg_align ద్వారా వాగ్దానం చేయబడినది మరియు పైన ధృవీకరించబడినది.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// పరమాణువును వినియోగిస్తుంది మరియు ఉన్న విలువను తిరిగి ఇస్తుంది.
            ///
            /// ఇది సురక్షితం ఎందుకంటే `self` ను విలువ ద్వారా పాస్ చేస్తే ఇతర థ్రెడ్‌లు ఏకకాలంలో అణు డేటాను యాక్సెస్ చేయలేవని హామీ ఇస్తుంది.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// పరమాణు పూర్ణాంకం నుండి విలువను లోడ్ చేస్తుంది.
            ///
            /// `load` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.
            /// సాధ్యమయ్యే విలువలు [`SeqCst`], [`Acquire`] మరియు [`Relaxed`].
            ///
            /// # Panics
            ///
            /// `order` [`Release`] లేదా [`AcqRel`] అయితే Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// విలువను పరమాణు పూర్ణాంకంలో నిల్వ చేస్తుంది.
            ///
            /// `store` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.
            ///  సాధ్యమయ్యే విలువలు [`SeqCst`], [`Release`] మరియు [`Relaxed`].
            ///
            /// # Panics
            ///
            /// `order` [`Acquire`] లేదా [`AcqRel`] అయితే Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// విలువను అటామిక్ పూర్ణాంకంలో నిల్వ చేస్తుంది, మునుపటి విలువను తిరిగి ఇస్తుంది.
            ///
            /// `swap` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
            /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
            ///
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// ప్రస్తుత విలువ `current` విలువకు సమానంగా ఉంటే విలువను అణు పూర్ణాంకంలో నిల్వ చేస్తుంది.
            ///
            /// తిరిగి వచ్చే విలువ ఎల్లప్పుడూ మునుపటి విలువ.ఇది `current` కి సమానం అయితే, అప్పుడు విలువ నవీకరించబడింది.
            ///
            /// `compare_and_swap` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ కూడా తీసుకుంటుంది.
            /// [`AcqRel`] ను ఉపయోగిస్తున్నప్పుడు కూడా, ఆపరేషన్ విఫలం కావచ్చు మరియు అందువల్ల కేవలం `Acquire` లోడ్ చేయగలదు, కానీ `Release` సెమాంటిక్స్ లేదు.
            ///
            /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో స్టోర్ జరిగితే, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange` మరియు `compare_exchange_weak` కు వలసపోతోంది
            ///
            /// `compare_and_swap` మెమరీ ఆర్డరింగ్ కోసం కింది మ్యాపింగ్ తో `compare_exchange` కి సమానం:
            ///
            /// అసలు |విజయం |వైఫల్యం
            /// -------- | ------- | -------
            /// రిలాక్స్డ్ |రిలాక్స్డ్ |రిలాక్స్డ్ అక్వైర్ |సంపాదించండి |విడుదలను పొందండి |విడుదల |రిలాక్స్డ్ అక్క్రెల్ |అక్క్రెల్ |SeqCst ని పొందండి |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` పోలిక విజయవంతం అయినప్పుడు కూడా విఫలం కావడానికి అనుమతించబడుతుంది, ఇది లూప్‌లో పోలిక మరియు స్వాప్ ఉపయోగించినప్పుడు కంపైలర్ మెరుగైన అసెంబ్లీ కోడ్‌ను రూపొందించడానికి అనుమతిస్తుంది.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// ప్రస్తుత విలువ `current` విలువకు సమానంగా ఉంటే విలువను అణు పూర్ణాంకంలో నిల్వ చేస్తుంది.
            ///
            /// రిటర్న్ వాల్యూ అనేది క్రొత్త విలువ వ్రాయబడిందా లేదా మునుపటి విలువను కలిగి ఉందా అని సూచించే ఫలితం.
            /// విజయవంతం అయినప్పుడు ఈ విలువ `current` కి సమానంగా ఉంటుందని హామీ ఇవ్వబడింది.
            ///
            /// `compare_exchange` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించడానికి రెండు [`Ordering`] వాదనలు పడుతుంది.
            /// `success` `current` తో పోలిక విజయవంతమైతే జరిగే రీడ్-మోడిఫై-రైట్ ఆపరేషన్ కోసం అవసరమైన ఆర్డరింగ్‌ను వివరిస్తుంది.
            /// `failure` పోలిక విఫలమైనప్పుడు జరిగే లోడ్ ఆపరేషన్ కోసం అవసరమైన క్రమాన్ని వివరిస్తుంది.
            /// [`Acquire`] ను సక్సెస్ ఆర్డరింగ్‌గా ఉపయోగించడం వలన స్టోర్ ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వల్ల విజయవంతమైన లోడ్ [`Relaxed`] అవుతుంది.
            ///
            /// వైఫల్యం క్రమం [`SeqCst`], [`Acquire`] లేదా [`Relaxed`] మాత్రమే కావచ్చు మరియు విజయ క్రమం కంటే సమానంగా లేదా బలహీనంగా ఉండాలి.
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// ప్రస్తుత విలువ `current` విలువకు సమానంగా ఉంటే విలువను అణు పూర్ణాంకంలో నిల్వ చేస్తుంది.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// పోలిక విజయవంతం అయినప్పుడు కూడా ఈ ఫంక్షన్ నకిలీగా విఫలమవుతుంది, ఇది కొన్ని ప్లాట్‌ఫామ్‌లపై మరింత సమర్థవంతమైన కోడ్‌కు దారితీస్తుంది.
            /// రిటర్న్ వాల్యూ అనేది క్రొత్త విలువ వ్రాయబడిందా లేదా మునుపటి విలువను కలిగి ఉందా అని సూచించే ఫలితం.
            ///
            /// `compare_exchange_weak` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించడానికి రెండు [`Ordering`] వాదనలు పడుతుంది.
            /// `success` `current` తో పోలిక విజయవంతమైతే జరిగే రీడ్-మోడిఫై-రైట్ ఆపరేషన్ కోసం అవసరమైన ఆర్డరింగ్‌ను వివరిస్తుంది.
            /// `failure` పోలిక విఫలమైనప్పుడు జరిగే లోడ్ ఆపరేషన్ కోసం అవసరమైన క్రమాన్ని వివరిస్తుంది.
            /// [`Acquire`] ను సక్సెస్ ఆర్డరింగ్‌గా ఉపయోగించడం వలన స్టోర్ ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వల్ల విజయవంతమైన లోడ్ [`Relaxed`] అవుతుంది.
            ///
            /// వైఫల్యం క్రమం [`SeqCst`], [`Acquire`] లేదా [`Relaxed`] మాత్రమే కావచ్చు మరియు విజయ క్రమం కంటే సమానంగా లేదా బలహీనంగా ఉండాలి.
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// mut old= val.load(Ordering::Relaxed);
            /// లూప్ new క్రొత్తది=పాతది * 2;
            ///     మ్యాచ్ val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// మునుపటి విలువను తిరిగి ఇచ్చి ప్రస్తుత విలువకు జోడిస్తుంది.
            ///
            /// ఈ ఆపరేషన్ ఓవర్ఫ్లో చుట్టుముడుతుంది.
            ///
            /// `fetch_add` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
            /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
            ///
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// ప్రస్తుత విలువ నుండి తీసివేస్తుంది, మునుపటి విలువను తిరిగి ఇస్తుంది.
            ///
            /// ఈ ఆపరేషన్ ఓవర్ఫ్లో చుట్టుముడుతుంది.
            ///
            /// `fetch_sub` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
            /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
            ///
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// ప్రస్తుత విలువతో బిట్‌వైస్ "and".
            ///
            /// ప్రస్తుత విలువ మరియు ఆర్గ్యుమెంట్ `val` పై బిట్‌వైస్ "and" ఆపరేషన్ చేస్తుంది మరియు ఫలితానికి కొత్త విలువను సెట్ చేస్తుంది.
            ///
            /// మునుపటి విలువను అందిస్తుంది.
            ///
            /// `fetch_and` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
            /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
            ///
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// ప్రస్తుత విలువతో బిట్‌వైస్ "nand".
            ///
            /// ప్రస్తుత విలువ మరియు ఆర్గ్యుమెంట్ `val` పై బిట్‌వైస్ "nand" ఆపరేషన్ చేస్తుంది మరియు ఫలితానికి కొత్త విలువను సెట్ చేస్తుంది.
            ///
            /// మునుపటి విలువను అందిస్తుంది.
            ///
            /// `fetch_nand` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
            /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
            ///
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// ప్రస్తుత విలువతో బిట్‌వైస్ "or".
            ///
            /// ప్రస్తుత విలువ మరియు ఆర్గ్యుమెంట్ `val` పై బిట్‌వైస్ "or" ఆపరేషన్ చేస్తుంది మరియు ఫలితానికి కొత్త విలువను సెట్ చేస్తుంది.
            ///
            /// మునుపటి విలువను అందిస్తుంది.
            ///
            /// `fetch_or` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
            /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
            ///
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// ప్రస్తుత విలువతో బిట్‌వైస్ "xor".
            ///
            /// ప్రస్తుత విలువ మరియు ఆర్గ్యుమెంట్ `val` పై బిట్‌వైస్ "xor" ఆపరేషన్ చేస్తుంది మరియు ఫలితానికి కొత్త విలువను సెట్ చేస్తుంది.
            ///
            /// మునుపటి విలువను అందిస్తుంది.
            ///
            /// `fetch_xor` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
            /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
            ///
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// విలువను పొందుతుంది మరియు ఐచ్ఛిక క్రొత్త విలువను ఇచ్చే ఫంక్షన్‌ను దీనికి వర్తిస్తుంది.ఫంక్షన్ `Some(_)` ను తిరిగి ఇస్తే `Ok(previous_value)` యొక్క `Result` ను అందిస్తుంది, లేకపోతే `Err(previous_value)`.
            ///
            /// Note: ఫంక్షన్ `Some(_)` ను తిరిగి ఇచ్చేంతవరకు, ఇతర థ్రెడ్ల నుండి విలువ మార్చబడితే ఇది ఫంక్షన్‌ను చాలాసార్లు పిలుస్తుంది, అయితే ఫంక్షన్ నిల్వ చేసిన విలువకు ఒక్కసారి మాత్రమే వర్తించబడుతుంది.
            ///
            ///
            /// `fetch_update` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించడానికి రెండు [`Ordering`] వాదనలు పడుతుంది.
            /// మొదటిది ఆపరేషన్ చివరకు విజయవంతం కావడానికి అవసరమైన ఆర్డరింగ్‌ను వివరిస్తుంది, రెండవది లోడ్‌లకు అవసరమైన ఆర్డరింగ్‌ను వివరిస్తుంది.ఇవి విజయం మరియు వైఫల్య క్రమాన్ని సూచిస్తాయి
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] ను సక్సెస్ ఆర్డరింగ్‌గా ఉపయోగించడం వలన స్టోర్ ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన తుది విజయవంతమైన లోడ్ [`Relaxed`] అవుతుంది.
            /// (failed) లోడ్ ఆర్డరింగ్ [`SeqCst`], [`Acquire`] లేదా [`Relaxed`] మాత్రమే కావచ్చు మరియు సక్సెస్ ఆర్డరింగ్ కంటే సమానం లేదా బలహీనంగా ఉండాలి.
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (ఆర్డరింగ్: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (ఆర్డరింగ్: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// ప్రస్తుత విలువతో గరిష్టంగా.
            ///
            /// ప్రస్తుత విలువ మరియు ఆర్గ్యుమెంట్ `val` యొక్క గరిష్టాన్ని కనుగొంటుంది మరియు ఫలితానికి క్రొత్త విలువను సెట్ చేస్తుంది.
            ///
            /// మునుపటి విలువను అందిస్తుంది.
            ///
            /// `fetch_max` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
            /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
            ///
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// లెట్ బార్=42;
            /// max_foo=foo.fetch_max (బార్, Ordering::SeqCst).max(bar);
            /// నిశ్చయించు! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// ప్రస్తుత విలువతో కనిష్టం.
            ///
            /// ప్రస్తుత విలువ మరియు ఆర్గ్యుమెంట్ `val` యొక్క కనిష్టాన్ని కనుగొంటుంది మరియు ఫలితానికి క్రొత్త విలువను సెట్ చేస్తుంది.
            ///
            /// మునుపటి విలువను అందిస్తుంది.
            ///
            /// `fetch_min` ఈ ఆపరేషన్ యొక్క మెమరీ క్రమాన్ని వివరించే [`Ordering`] ఆర్గ్యుమెంట్ తీసుకుంటుంది.అన్ని ఆర్డరింగ్ మోడ్‌లు సాధ్యమే.
            /// [`Acquire`] ను ఉపయోగించడం వలన ఈ ఆపరేషన్ [`Relaxed`] లో భాగం అవుతుంది, మరియు [`Release`] ను ఉపయోగించడం వలన లోడ్ భాగం [`Relaxed`] అవుతుంది.
            ///
            ///
            /// **గమనిక**: ఈ పద్ధతి అణు కార్యకలాపాలకు మద్దతు ఇచ్చే ప్లాట్‌ఫామ్‌లలో మాత్రమే అందుబాటులో ఉంటుంది
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// లెట్ బార్=12;
            /// min_foo=foo.fetch_min (బార్, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // భద్రత: అణు అంతర్గత ద్వారా డేటా రేసులు నిరోధించబడతాయి.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// మార్చగల పాయింటర్‌ను అంతర్లీన పూర్ణాంకానికి చూపుతుంది.
            ///
            /// ఫలిత పూర్ణాంకంపై అణు రహిత రీడ్‌లు మరియు వ్రాతలు చేయడం డేటా రేసు.
            /// ఈ పద్ధతి ఎఫ్‌ఎఫ్‌ఐకి ఎక్కువగా ఉపయోగపడుతుంది, ఇక్కడ ఫంక్షన్ సంతకం ఉపయోగించవచ్చు
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// ఈ పరమాణువుకు భాగస్వామ్య సూచన నుండి `*mut` పాయింటర్‌ను తిరిగి ఇవ్వడం సురక్షితం ఎందుకంటే అణు రకాలు అంతర్గత ఉత్పరివర్తనంతో పనిచేస్తాయి.
            /// అణు యొక్క అన్ని మార్పులు షేర్డ్ రిఫరెన్స్ ద్వారా విలువను మారుస్తాయి మరియు అవి అణు కార్యకలాపాలను ఉపయోగించేంతవరకు సురక్షితంగా చేయగలవు.
            /// తిరిగి వచ్చిన ముడి పాయింటర్ యొక్క ఏదైనా ఉపయోగం కోసం `unsafe` బ్లాక్ అవసరం మరియు ఇప్పటికీ అదే పరిమితిని సమర్థించాలి: దానిపై కార్యకలాపాలు పరమాణువుగా ఉండాలి.
            ///
            ///
            /// # Examples
            ///
            /// `` (extern-declaration) ను విస్మరించండి
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// బాహ్య "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // భద్రత: `my_atomic_op` అణు ఉన్నంత వరకు సురక్షితం.
            /// అసురక్షిత {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // భద్రత: కాలర్ `atomic_store` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // భద్రత: కాలర్ `atomic_load` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // భద్రత: కాలర్ `atomic_swap` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// మునుపటి విలువను అందిస్తుంది (__sync_fetch_and_add వంటివి).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // భద్రత: కాలర్ `atomic_add` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// మునుపటి విలువను అందిస్తుంది (__sync_fetch_and_sub వంటివి).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // భద్రత: కాలర్ `atomic_sub` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // భద్రత: కాలర్ `atomic_compare_exchange` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // భద్రత: కాలర్ `atomic_compare_exchange_weak` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // భద్రత: కాలర్ `atomic_and` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // భద్రత: కాలర్ `atomic_nand` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // భద్రత: కాలర్ `atomic_or` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // భద్రత: కాలర్ `atomic_xor` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// గరిష్ట విలువను అందిస్తుంది (సంతకం చేసిన పోలిక)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // భద్రత: కాలర్ `atomic_max` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// కనిష్ట విలువను అందిస్తుంది (సంతకం చేసిన పోలిక)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // భద్రత: కాలర్ `atomic_min` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// గరిష్ట విలువను అందిస్తుంది (సంతకం చేయని పోలిక)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // భద్రత: కాలర్ `atomic_umax` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// కనిష్ట విలువను అందిస్తుంది (సంతకం చేయని పోలిక)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // భద్రత: కాలర్ `atomic_umin` కోసం భద్రతా ఒప్పందాన్ని సమర్థించాలి
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// అణు కంచె.
///
/// పేర్కొన్న క్రమాన్ని బట్టి, కంపైలర్ మరియు సిపియు చుట్టూ కొన్ని రకాల మెమరీ ఆపరేషన్లను క్రమం చేయకుండా ఒక కంచె నిరోధిస్తుంది.
/// ఇది సమకాలీకరణలను సృష్టిస్తుంది-దాని మధ్య సంబంధాలు మరియు అణు కార్యకలాపాలు లేదా ఇతర థ్రెడ్లలో కంచెలు.
///
/// (కనీసం) [`Release`] ఆర్డరింగ్ సెమాంటిక్స్ కలిగి ఉన్న కంచె 'A', కంచె 'B' తో (కనీసం) [`Acquire`] సెమాంటిక్స్‌తో సమకాలీకరిస్తుంది, ఒకవేళ X మరియు Y ఆపరేషన్లు ఉంటే మాత్రమే, రెండూ కొన్ని అణు వస్తువు 'M' పై పనిచేస్తాయి, ఇవి A కి ముందు క్రమం చేయబడతాయి B మరియు Y M కు మార్పును గమనించే ముందు X, Y సమకాలీకరించబడుతుంది.
/// ఇది A మరియు B ల మధ్య ఆధారపడటానికి ముందు జరుగుతుంది.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] లేదా [`Acquire`] సెమాంటిక్స్‌తో అణు కార్యకలాపాలు కూడా కంచెతో సమకాలీకరించబడతాయి.
///
/// [`Acquire`] మరియు [`Release`] సెమాంటిక్స్ రెండింటినీ కలిగి ఉండటంతో పాటు, [`SeqCst`] ఆర్డరింగ్ కలిగి ఉన్న కంచె, ఇతర [`SeqCst`] కార్యకలాపాలు మరియు/లేదా కంచెల యొక్క గ్లోబల్ ప్రోగ్రామ్ ఆర్డర్‌లో పాల్గొంటుంది.
///
/// [`Acquire`], [`Release`], [`AcqRel`] మరియు [`SeqCst`] ఆర్డరింగ్‌లను అంగీకరిస్తుంది.
///
/// # Panics
///
/// `order` [`Relaxed`] అయితే Panics.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // స్పిన్‌లాక్ ఆధారంగా పరస్పర మినహాయింపు ఆదిమ.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // పాత విలువ `false` వరకు వేచి ఉండండి.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // ఈ కంచె `unlock` లో స్టోర్‌తో సమకాలీకరిస్తుంది.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // భద్రత: అణు కంచెను ఉపయోగించడం సురక్షితం.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// కంపైలర్ మెమరీ కంచె.
///
/// `compiler_fence` ఏ మెషీన్ కోడ్‌ను విడుదల చేయదు, కాని కంపైలర్ చేయడానికి అనుమతించబడే మెమరీని తిరిగి ఆర్డర్ చేయడాన్ని పరిమితం చేస్తుంది.ప్రత్యేకంగా, ఇచ్చిన [`Ordering`] సెమాంటిక్స్‌పై ఆధారపడి, కంపైలర్ `compiler_fence` కి కాల్ యొక్క మరొక వైపుకు కాల్ చేయడానికి ముందు లేదా తరువాత నుండి చదవడానికి లేదా వ్రాయడానికి కంపైలర్ అనుమతించబడదు.అటువంటి రీ-ఆర్డరింగ్ చేయకుండా *హార్డ్‌వేర్* ని ఇది ** నిరోధించదని గమనించండి.
///
/// సింగిల్-థ్రెడ్, ఎగ్జిక్యూషన్ సందర్భంలో ఇది సమస్య కాదు, కానీ ఇతర థ్రెడ్‌లు ఒకే సమయంలో మెమరీని సవరించినప్పుడు, [`fence`] వంటి బలమైన సింక్రొనైజేషన్ ఆదిమాలు అవసరం.
///
/// విభిన్న ఆర్డరింగ్ సెమాంటిక్స్ ద్వారా నిరోధించబడిన రీ-ఆర్డరింగ్:
///
///  - [`SeqCst`] తో, ఈ దశలో చదివే మరియు వ్రాసే రీ-ఆర్డరింగ్ అనుమతించబడదు.
///  - [`Release`] తో, మునుపటి రీడ్‌లు మరియు వ్రాతలను గత తదుపరి రచనలను తరలించలేము.
///  - [`Acquire`] తో, తదుపరి రీడ్‌లు మరియు వ్రాతలను మునుపటి రీడ్‌ల కంటే ముందుకు తరలించలేము.
///  - [`AcqRel`] తో, పై రెండు నియమాలు అమలు చేయబడతాయి.
///
/// `compiler_fence` సాధారణంగా థ్రెడ్‌ను రేసింగ్ నుండి నిరోధించడానికి మాత్రమే ఉపయోగపడుతుంది *.అంటే, ఇచ్చిన థ్రెడ్ ఒక కోడ్ భాగాన్ని అమలు చేస్తుంటే, ఆపై అంతరాయం కలిగి, మరియు వేరే చోట కోడ్‌ను అమలు చేయడం ప్రారంభిస్తే (ఇప్పటికీ అదే థ్రెడ్‌లో ఉన్నప్పుడు, మరియు సంభావితంగా ఇప్పటికీ అదే కోర్‌లో ఉంటుంది).సాంప్రదాయ కార్యక్రమాలలో, సిగ్నల్ హ్యాండ్లర్ నమోదు చేయబడినప్పుడు మాత్రమే ఇది జరుగుతుంది.
/// మరింత తక్కువ-స్థాయి కోడ్‌లో, అంతరాయాలను నిర్వహించేటప్పుడు, ప్రీ-ఎమ్ప్షన్‌తో ఆకుపచ్చ దారాలను అమలు చేసేటప్పుడు కూడా ఇటువంటి పరిస్థితులు తలెత్తుతాయి.
/// ఆసక్తిగల పాఠకులు [memory barriers] యొక్క Linux కెర్నల్ యొక్క చర్చను చదవమని ప్రోత్సహిస్తారు.
///
/// # Panics
///
/// `order` [`Relaxed`] అయితే Panics.
///
/// # Examples
///
/// `compiler_fence` లేకుండా, ఒకే థ్రెడ్‌లో ప్రతిదీ జరుగుతున్నప్పటికీ, కింది కోడ్‌లోని `assert_eq!` విజయవంతం కావడానికి * హామీ ఇవ్వబడదు.
/// ఎందుకు చూడటానికి, కంపైలర్ `IMPORTANT_VARIABLE` మరియు `IS_READ` లకు దుకాణాలను మార్పిడి చేయడానికి ఉచితం అని గుర్తుంచుకోండి ఎందుకంటే అవి రెండూ `Ordering::Relaxed`.అది జరిగితే, మరియు `IS_READY` నవీకరించబడిన వెంటనే సిగ్నల్ హ్యాండ్లర్ ప్రారంభించబడితే, అప్పుడు సిగ్నల్ హ్యాండ్లర్ `IS_READY=1` ను చూస్తాడు, కానీ `IMPORTANT_VARIABLE=0`.
/// `compiler_fence` నివారణలను ఉపయోగించడం ఈ పరిస్థితిని పరిష్కరిస్తుంది.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // మునుపటి వ్రాతలను ఈ పాయింట్ దాటి తరలించకుండా నిరోధించండి
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // భద్రత: అణు కంచెను ఉపయోగించడం సురక్షితం.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// ప్రాసెసర్ బిజీ-వెయిట్ స్పిన్-లూప్ ("స్పిన్ లాక్") లోపల ఉందని సిగ్నల్ చేస్తుంది.
///
/// ఈ ఫంక్షన్ [`hint::spin_loop`] కు అనుకూలంగా తీసివేయబడింది.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}