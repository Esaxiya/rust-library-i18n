//! ఈ మాడ్యూల్ ఇతర డిక్లేర్డ్ రకాలు నీడ లేని వాడకాన్ని అనుమతించడానికి ఆదిమ రకాలను తిరిగి ఎగుమతి చేస్తుంది.
//!
//! ఇది సాధారణంగా స్థూల ఉత్పత్తి కోడ్‌లో మాత్రమే ఉపయోగపడుతుంది.
//!
//! క్రొత్త స్ట్రక్ట్ మరియు దాని కోసం ఒక impl ను ఉత్పత్తి చేసేటప్పుడు దీనికి ఉదాహరణ:
//!
//! ```rust,compile_fail
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!
//! `SOME_PROPERTY` అనుబంధ స్థిరాంకం కంపైల్ చేయదని గమనించండి, ఎందుకంటే దాని రకం `bool` ఆదిమ bool రకానికి బదులుగా struct ను సూచిస్తుంది.
//!
//!
//! సరైన అమలు ఇలా ఉంటుంది:
//!
//! ```rust
//! # #[allow(non_camel_case_types)]
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: core::primitive::bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!

#[stable(feature = "core_primitive", since = "1.43.0")]
pub use bool;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use char;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use isize;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use str;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use usize;