use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T` యొక్క ప్రారంభించని సందర్భాలను నిర్మించడానికి ఒక రేపర్ రకం.
///
/// # ప్రారంభ మార్పు
///
/// కంపైలర్, సాధారణంగా, వేరియబుల్ రకం యొక్క అవసరాలకు అనుగుణంగా వేరియబుల్ సరిగ్గా ప్రారంభించబడిందని umes హిస్తుంది.ఉదాహరణకు, రిఫరెన్స్ రకం యొక్క వేరియబుల్ తప్పనిసరిగా సమలేఖనం చేయబడాలి మరియు NULL కానిది.
/// ఇది అసురక్షితమైన కోడ్‌లో కూడా *ఎల్లప్పుడూ* సమర్థించబడాలి.
/// పర్యవసానంగా, రిఫరెన్స్ రకం యొక్క వేరియబుల్‌ను సున్నా-ప్రారంభించడం తక్షణ [undefined behavior][ub] కి కారణమవుతుంది, ఆ సూచన ఎప్పుడైనా మెమరీని యాక్సెస్ చేయడానికి ఉపయోగించబడుతుందా అనే దానితో సంబంధం లేకుండా:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // నిర్వచించబడని ప్రవర్తన!⚠️
/// // `MaybeUninit<&i32>` తో సమానమైన కోడ్:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // నిర్వచించబడని ప్రవర్తన!⚠️
/// ```
///
/// రన్-టైమ్ తనిఖీలను తొలగించడం మరియు `enum` లేఅవుట్ను ఆప్టిమైజ్ చేయడం వంటి వివిధ ఆప్టిమైజేషన్ల కోసం కంపైలర్ దీనిని ఉపయోగించుకుంటుంది.
///
/// అదేవిధంగా, పూర్తిగా ప్రారంభించని మెమరీకి ఏదైనా కంటెంట్ ఉండవచ్చు, అయితే `bool` ఎల్లప్పుడూ `true` లేదా `false` అయి ఉండాలి.అందువల్ల, ప్రారంభించని `bool` ను సృష్టించడం నిర్వచించబడని ప్రవర్తన:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // నిర్వచించబడని ప్రవర్తన!⚠️
/// // `MaybeUninit<bool>` తో సమానమైన కోడ్:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // నిర్వచించబడని ప్రవర్తన!⚠️
/// ```
///
/// అంతేకాక, ప్రారంభించని మెమరీ ప్రత్యేకమైనది, దీనికి స్థిర విలువ లేదు ("fixed" అంటే "it won't change without being written to").ఒకే ప్రారంభించని బైట్‌ను పలుసార్లు చదవడం వల్ల వేర్వేరు ఫలితాలు వస్తాయి.
/// ఇది వేరియబుల్‌లో పూర్ణాంక రకాన్ని కలిగి ఉన్నప్పటికీ, వేరియబుల్‌లో ప్రారంభించని డేటాను కలిగి ఉండటానికి ఇది నిర్వచించబడని ప్రవర్తనను చేస్తుంది, లేకపోతే ఏదైనా *స్థిర* బిట్ నమూనాను కలిగి ఉంటుంది:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // నిర్వచించబడని ప్రవర్తన!⚠️
/// // `MaybeUninit<i32>` తో సమానమైన కోడ్:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // నిర్వచించబడని ప్రవర్తన!⚠️
/// ```
/// (ప్రారంభించని పూర్ణాంకాల చుట్టూ ఉన్న నియమాలు ఇంకా ఖరారు కాలేదని గమనించండి, కానీ అవి వచ్చే వరకు వాటిని నివారించడం మంచిది.)
///
/// ఆ పైన, చాలా రకాలు అదనపు స్థాయిలో మార్పులను కలిగి ఉన్నాయని గుర్తుంచుకోండి.
/// ఉదాహరణకు, `1`-ప్రారంభించిన [`Vec<T>`] ప్రారంభించబడినదిగా పరిగణించబడుతుంది (ప్రస్తుత అమలులో; ఇది స్థిరమైన హామీ ఇవ్వదు) ఎందుకంటే కంపైలర్‌కు దాని గురించి తెలిసిన ఏకైక అవసరం ఏమిటంటే డేటా పాయింటర్ శూన్యంగా ఉండాలి.
/// అటువంటి `Vec<T>` ను సృష్టించడం *తక్షణ* నిర్వచించబడని ప్రవర్తనకు కారణం కాదు, కానీ చాలా సురక్షితమైన ఆపరేషన్లతో (దానిని వదలడంతో సహా) నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` ప్రారంభించని డేటాతో వ్యవహరించడానికి అసురక్షిత కోడ్‌ను ప్రారంభించడానికి ఉపయోగపడుతుంది.
/// ఇది కంపైలర్‌కు సిగ్నల్, ఇక్కడ డేటా * ప్రారంభించబడదని సూచిస్తుంది:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // స్పష్టంగా ప్రారంభించని సూచనను సృష్టించండి.
/// // `MaybeUninit<T>` లోపల డేటా చెల్లదని కంపైలర్‌కు తెలుసు, అందువల్ల ఇది UB కాదు:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // దీన్ని చెల్లుబాటు అయ్యే విలువకు సెట్ చేయండి.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // ప్రారంభించిన డేటాను సంగ్రహించండి-ఇది `x` ను సరిగ్గా ప్రారంభించిన తర్వాత మాత్రమే * అనుమతించబడుతుంది!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// ఈ కోడ్‌లో తప్పు ump హలు లేదా ఆప్టిమైజేషన్‌లు చేయవద్దని కంపైలర్‌కు తెలుసు.
///
/// మీరు `MaybeUninit<T>` ను `Option<T>` లాగా భావిస్తారు, కానీ రన్-టైమ్ ట్రాకింగ్ లేకుండా మరియు భద్రతా తనిఖీలు లేకుండా.
///
/// ## out-pointers
///
/// "out-pointers" ను అమలు చేయడానికి మీరు `MaybeUninit<T>` ను ఉపయోగించవచ్చు: ఒక ఫంక్షన్ నుండి డేటాను తిరిగి ఇచ్చే బదులు, ఫలితాన్ని ఉంచడానికి కొన్ని (uninitialized) మెమరీకి పాయింటర్ పంపండి.
/// ఫలితం నిల్వ చేయబడిన జ్ఞాపకశక్తి ఎలా కేటాయించబడుతుందో నియంత్రించడం కాలర్‌కు ముఖ్యమైనది అయినప్పుడు ఇది ఉపయోగపడుతుంది మరియు మీరు అనవసరమైన కదలికలను నివారించాలనుకుంటున్నారు.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` పాత విషయాలను వదలదు, ఇది ముఖ్యమైనది.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // ఇప్పుడు `v` ప్రారంభించబడిందని మాకు తెలుసు!ఇది vector సరిగ్గా పడిపోయేలా చేస్తుంది.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## మూలకం-ద్వారా-మూలకం యొక్క శ్రేణిని ప్రారంభిస్తోంది
///
/// `MaybeUninit<T>` ఎలిమెంట్-బై-ఎలిమెంట్ ద్వారా పెద్ద శ్రేణిని ప్రారంభించడానికి ఉపయోగించవచ్చు:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // `MaybeUninit` యొక్క ప్రారంభించని శ్రేణిని సృష్టించండి.
///     // `assume_init` సురక్షితం ఎందుకంటే మేము ఇక్కడ ప్రారంభించినట్లు చెప్పుకునే రకం `బహుశా యునినిట్` యొక్క సమూహం, దీనికి ప్రారంభ అవసరం లేదు.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // `MaybeUninit` ను వదలడం ఏమీ చేయదు.
///     // అందువల్ల `ptr::write` కు బదులుగా ముడి పాయింటర్ అసైన్‌మెంట్‌ను ఉపయోగించడం వల్ల పాత ప్రారంభించని విలువ పడిపోదు.
/////
///     // ఈ లూప్ సమయంలో panic ఉంటే, మనకు మెమరీ లీక్ ఉంది, కానీ మెమరీ భద్రతా సమస్య లేదు.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // ప్రతిదీ ప్రారంభించబడింది.
///     // ప్రారంభించిన రకానికి శ్రేణిని మార్చండి.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// మీరు పాక్షికంగా ప్రారంభించిన శ్రేణులతో కూడా పని చేయవచ్చు, ఇది తక్కువ-స్థాయి డేటాస్ట్రక్చర్లలో కనుగొనబడుతుంది.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // `MaybeUninit` యొక్క ప్రారంభించని శ్రేణిని సృష్టించండి.
/// // `assume_init` సురక్షితం ఎందుకంటే మేము ఇక్కడ ప్రారంభించినట్లు చెప్పుకునే రకం `బహుశా యునినిట్` యొక్క సమూహం, దీనికి ప్రారంభ అవసరం లేదు.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // మేము కేటాయించిన మూలకాల సంఖ్యను లెక్కించండి.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // శ్రేణిలోని ప్రతి అంశం కోసం, మేము దానిని కేటాయించినట్లయితే డ్రాప్ చేయండి.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## ఒక ఫీల్డ్ ఫీల్డ్-బై-ఫీల్డ్‌ను ప్రారంభిస్తోంది
///
/// ఫీల్డ్ ద్వారా స్ట్రక్ట్స్ ఫీల్డ్‌ను ప్రారంభించడానికి మీరు `MaybeUninit<T>` మరియు [`std::ptr::addr_of_mut`] మాక్రోలను ఉపయోగించవచ్చు:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` ఫీల్డ్‌ను ప్రారంభిస్తోంది
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` ఫీల్డ్‌ను ప్రారంభించడం ఇక్కడ panic ఉంటే, అప్పుడు `name` ఫీల్డ్‌లోని `String` లీక్ అవుతుంది.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // అన్ని ఫీల్డ్‌లు ప్రారంభించబడ్డాయి, కాబట్టి మేము ప్రారంభించిన ఫూని పొందడానికి `assume_init` అని పిలుస్తాము.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T` వలె ఒకే పరిమాణం, అమరిక మరియు ABI కలిగి ఉంటుందని హామీ ఇవ్వబడింది:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// అయితే *`MaybeUninit<T>` కలిగి ఉన్న రకం* ఒకే లేఅవుట్ కాదని గుర్తుంచుకోండి;`T` మరియు `U` ఒకే పరిమాణం మరియు అమరికను కలిగి ఉన్నప్పటికీ, `Foo<T>` యొక్క ఫీల్డ్‌లు `Foo<U>` వలె ఒకే క్రమాన్ని కలిగి ఉన్నాయని Rust సాధారణంగా హామీ ఇవ్వదు.
///
/// ఇంకా ఏదైనా బిట్ విలువ `MaybeUninit<T>` కి చెల్లుతుంది కాబట్టి కంపైలర్ non-zero/niche-filling ఆప్టిమైజేషన్లను వర్తించదు, దీని ఫలితంగా పెద్ద పరిమాణం వస్తుంది:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// `T` FFI-సురక్షితం అయితే, `MaybeUninit<T>` కూడా అలానే ఉంటుంది.
///
/// `MaybeUninit` `#[repr(transparent)]` అయితే (ఇది ఒకే పరిమాణం, అమరిక మరియు ABI ని `T` గా హామీ ఇస్తుంది), ఇది మునుపటి మినహాయింపులలో దేనినీ మార్చదు.
/// `Option<T>` మరియు `Option<MaybeUninit<T>>` ఇప్పటికీ వేర్వేరు పరిమాణాలను కలిగి ఉండవచ్చు, మరియు `T` రకం ఫీల్డ్‌ను కలిగి ఉన్న రకాలు ఆ ఫీల్డ్ `MaybeUninit<T>` కంటే భిన్నంగా వేయవచ్చు (మరియు పరిమాణం).
/// `MaybeUninit` యూనియన్ రకం, మరియు యూనియన్లపై `#[repr(transparent)]` అస్థిరంగా ఉంటుంది ([the tracking issue](https://github.com/rust-lang/rust/issues/60405)) చూడండి.
/// కాలక్రమేణా, యూనియన్లపై `#[repr(transparent)]` యొక్క ఖచ్చితమైన హామీలు అభివృద్ధి చెందుతాయి మరియు `MaybeUninit` `#[repr(transparent)]` గా ఉండవచ్చు లేదా ఉండకపోవచ్చు.
/// `MaybeUninit<T>` `T` వలె ఒకే పరిమాణం, అమరిక మరియు ABI కలిగి ఉందని *ఎల్లప్పుడూ* హామీ ఇస్తుంది;`MaybeUninit` హామీ ఇచ్చే విధానం అభివృద్ధి చెందుతుంది.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// లాంగ్ ఐటెమ్ కాబట్టి మనం దానిలో ఇతర రకాలను చుట్టవచ్చు.జనరేటర్లకు ఇది ఉపయోగపడుతుంది.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()` కి కాల్ చేయడం లేదు, దాని కోసం మనం తగినంతగా ప్రారంభించబడ్డామో లేదో మాకు తెలియదు.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// ఇచ్చిన విలువతో ప్రారంభించిన కొత్త `MaybeUninit<T>` ను సృష్టిస్తుంది.
    /// ఈ ఫంక్షన్ యొక్క తిరిగి విలువపై [`assume_init`] కి కాల్ చేయడం సురక్షితం.
    ///
    /// `MaybeUninit<T>` ను వదలడం `T` యొక్క డ్రాప్ కోడ్‌ను ఎప్పటికీ పిలవదని గమనించండి.
    /// `T` ప్రారంభించబడితే అది పడిపోతుందని నిర్ధారించుకోవడం మీ బాధ్యత.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// ప్రారంభించని స్థితిలో కొత్త `MaybeUninit<T>` ను సృష్టిస్తుంది.
    ///
    /// `MaybeUninit<T>` ను వదలడం `T` యొక్క డ్రాప్ కోడ్‌ను ఎప్పటికీ పిలవదని గమనించండి.
    /// `T` ప్రారంభించబడితే అది పడిపోతుందని నిర్ధారించుకోవడం మీ బాధ్యత.
    ///
    /// కొన్ని ఉదాహరణల కోసం [type-level documentation][MaybeUninit] చూడండి.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// ప్రారంభించని స్థితిలో, `MaybeUninit<T>` అంశాల కొత్త శ్రేణిని సృష్టించండి.
    ///
    /// Note: future Rust సంస్కరణలో శ్రేణి సాహిత్య వాక్యనిర్మాణం [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) ను అనుమతించినప్పుడు ఈ పద్ధతి అనవసరంగా మారవచ్చు.
    ///
    /// దిగువ ఉదాహరణ అప్పుడు `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` ను ఉపయోగించవచ్చు.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// వాస్తవానికి చదివిన డేటా యొక్క (బహుశా చిన్న) స్లైస్‌ని అందిస్తుంది
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // భద్రత: ప్రారంభించని `[MaybeUninit<_>; LEN]` చెల్లుతుంది.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// `0` బైట్‌లతో మెమరీ నింపడంతో, ప్రారంభించని స్థితిలో కొత్త `MaybeUninit<T>` ను సృష్టిస్తుంది.ఇది ఇప్పటికే సరైన ప్రారంభానికి కారణమవుతుందా అనేది `T` పై ఆధారపడి ఉంటుంది.
    ///
    /// ఉదాహరణకు, `MaybeUninit<usize>::zeroed()` ప్రారంభించబడింది, కానీ `MaybeUninit<&'static i32>::zeroed()` కాదు ఎందుకంటే సూచనలు శూన్యంగా ఉండకూడదు.
    ///
    /// `MaybeUninit<T>` ను వదలడం `T` యొక్క డ్రాప్ కోడ్‌ను ఎప్పటికీ పిలవదని గమనించండి.
    /// `T` ప్రారంభించబడితే అది పడిపోతుందని నిర్ధారించుకోవడం మీ బాధ్యత.
    ///
    /// # Example
    ///
    /// ఈ ఫంక్షన్ యొక్క సరైన ఉపయోగం: సున్నాతో ఒక struct ను ప్రారంభించడం, ఇక్కడ struct యొక్క అన్ని ఫీల్డ్‌లు బిట్-నమూనా 0 ను చెల్లుబాటు అయ్యే విలువగా కలిగి ఉంటాయి.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// ఈ ఫంక్షన్ యొక్క *తప్పు* వాడకం: `0` రకానికి చెల్లుబాటు అయ్యే బిట్-నమూనా కానప్పుడు `x.zeroed().assume_init()` కి కాల్ చేయడం:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // ఒక జత లోపల, చెల్లుబాటు అయ్యే వివక్షత లేని `NotZero` ను మేము సృష్టిస్తాము.
    /// // ఇది నిర్వచించబడని ప్రవర్తన.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // భద్రత: కేటాయించిన మెమరీకి `u.as_mut_ptr()` పాయింట్లు.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>` విలువను సెట్ చేస్తుంది.
    /// ఇది మునుపటి విలువను వదలకుండా తిరిగి రాస్తుంది, కాబట్టి మీరు డిస్ట్రక్టర్‌ను అమలు చేయడాన్ని దాటవేయాలనుకుంటే తప్ప దీన్ని రెండుసార్లు ఉపయోగించకుండా జాగ్రత్త వహించండి.
    ///
    /// మీ సౌలభ్యం కోసం, ఇది `self` యొక్క (ఇప్పుడు సురక్షితంగా ప్రారంభించబడిన) విషయాలకు మార్చగల సూచనను కూడా అందిస్తుంది.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // భద్రత: మేము ఈ విలువను ప్రారంభించాము.
        unsafe { self.assume_init_mut() }
    }

    /// ఉన్న విలువకు పాయింటర్ పొందుతుంది.
    /// `MaybeUninit<T>` ప్రారంభించకపోతే ఈ పాయింటర్ నుండి చదవడం లేదా దానిని సూచనగా మార్చడం నిర్వచించబడని ప్రవర్తన.
    /// ఈ పాయింటర్ (non-transitively) సూచించే జ్ఞాపకశక్తికి వ్రాయడం నిర్వచించబడని ప్రవర్తన (`UnsafeCell<T>` లోపల తప్ప).
    ///
    /// # Examples
    ///
    /// ఈ పద్ధతి యొక్క సరైన ఉపయోగం:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>` లోకి సూచనను సృష్టించండి.మేము దీన్ని ప్రారంభించినందున ఇది సరే.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// ఈ పద్ధతి యొక్క *తప్పు* వాడకం:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // మేము ప్రారంభించని vector కు సూచనను సృష్టించాము!ఇది నిర్వచించబడని ప్రవర్తన.⚠️
    /// ```
    ///
    /// (ప్రారంభించని డేటాకు సంబంధించిన సూచనల చుట్టూ ఉన్న నియమాలు ఇంకా ఖరారు కాలేదని గమనించండి, కానీ అవి వచ్చే వరకు వాటిని నివారించడం మంచిది.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` మరియు `ManuallyDrop` రెండూ `repr(transparent)` కాబట్టి మేము పాయింటర్‌ను ప్రసారం చేయవచ్చు.
        self as *const _ as *const T
    }

    /// ఉన్న విలువకు మార్చగల పాయింటర్‌ను పొందుతుంది.
    /// `MaybeUninit<T>` ప్రారంభించకపోతే ఈ పాయింటర్ నుండి చదవడం లేదా దానిని సూచనగా మార్చడం నిర్వచించబడని ప్రవర్తన.
    ///
    /// # Examples
    ///
    /// ఈ పద్ధతి యొక్క సరైన ఉపయోగం:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>` లోకి సూచనను సృష్టించండి.
    /// // మేము దీన్ని ప్రారంభించినందున ఇది సరే.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// ఈ పద్ధతి యొక్క *తప్పు* వాడకం:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // మేము ప్రారంభించని vector కు సూచనను సృష్టించాము!ఇది నిర్వచించబడని ప్రవర్తన.⚠️
    /// ```
    ///
    /// (ప్రారంభించని డేటాకు సంబంధించిన సూచనల చుట్టూ ఉన్న నియమాలు ఇంకా ఖరారు కాలేదని గమనించండి, కానీ అవి వచ్చే వరకు వాటిని నివారించడం మంచిది.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` మరియు `ManuallyDrop` రెండూ `repr(transparent)` కాబట్టి మేము పాయింటర్‌ను ప్రసారం చేయవచ్చు.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` కంటైనర్ నుండి విలువను సంగ్రహిస్తుంది.డేటా పడిపోతుందని నిర్ధారించడానికి ఇది ఒక గొప్ప మార్గం, ఎందుకంటే ఫలితంగా వచ్చే `T` సాధారణ డ్రాప్ నిర్వహణకు లోబడి ఉంటుంది.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` నిజంగా ప్రారంభ స్థితిలో ఉందని హామీ ఇవ్వడం కాలర్ వరకు ఉంది.కంటెంట్ ఇంకా పూర్తిగా ప్రారంభించబడనప్పుడు దీన్ని పిలవడం తక్షణం నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
    /// [type-level documentation][inv] ఈ ప్రారంభ మార్పు గురించి మరింత సమాచారాన్ని కలిగి ఉంది.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// ఆ పైన, చాలా రకాలు అదనపు స్థాయిలో మార్పులను కలిగి ఉన్నాయని గుర్తుంచుకోండి.
    /// ఉదాహరణకు, `1`-ప్రారంభించిన [`Vec<T>`] ప్రారంభించబడినదిగా పరిగణించబడుతుంది (ప్రస్తుత అమలులో; ఇది స్థిరమైన హామీ ఇవ్వదు) ఎందుకంటే కంపైలర్‌కు దాని గురించి తెలిసిన ఏకైక అవసరం ఏమిటంటే డేటా పాయింటర్ శూన్యంగా ఉండాలి.
    ///
    /// అటువంటి `Vec<T>` ను సృష్టించడం *తక్షణ* నిర్వచించబడని ప్రవర్తనకు కారణం కాదు, కానీ చాలా సురక్షితమైన ఆపరేషన్లతో (దానిని వదలడంతో సహా) నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// ఈ పద్ధతి యొక్క సరైన ఉపయోగం:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// ఈ పద్ధతి యొక్క *తప్పు* వాడకం:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ఇంకా ప్రారంభించబడలేదు, కాబట్టి ఈ చివరి పంక్తి నిర్వచించబడని ప్రవర్తనకు కారణమైంది.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // భద్రత: `self` ప్రారంభించబడిందని కాలర్ హామీ ఇవ్వాలి.
        // దీని అర్థం `self` తప్పనిసరిగా `value` వేరియంట్ అయి ఉండాలి.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` కంటైనర్ నుండి విలువను చదువుతుంది.ఫలితంగా వచ్చే `T` సాధారణ డ్రాప్ నిర్వహణకు లోబడి ఉంటుంది.
    ///
    /// సాధ్యమైనప్పుడల్లా, బదులుగా [`assume_init`] ను ఉపయోగించడం మంచిది, ఇది `MaybeUninit<T>` యొక్క కంటెంట్‌ను నకిలీ చేయడాన్ని నిరోధిస్తుంది.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` నిజంగా ప్రారంభ స్థితిలో ఉందని హామీ ఇవ్వడం కాలర్ వరకు ఉంది.కంటెంట్ ఇంకా పూర్తిగా ప్రారంభించబడనప్పుడు దీన్ని కాల్ చేయడం నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
    /// [type-level documentation][inv] ఈ ప్రారంభ మార్పు గురించి మరింత సమాచారాన్ని కలిగి ఉంది.
    ///
    /// అంతేకాక, ఇది `MaybeUninit<T>` లో అదే డేటా యొక్క కాపీని వదిలివేస్తుంది.
    /// డేటా యొక్క బహుళ కాపీలను ఉపయోగిస్తున్నప్పుడు (`assume_init_read` ను పలుసార్లు కాల్ చేయడం ద్వారా లేదా మొదట `assume_init_read` మరియు తరువాత [`assume_init`] కి కాల్ చేయడం ద్వారా), ఆ డేటా వాస్తవానికి నకిలీ అయ్యేలా చూడటం మీ బాధ్యత.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ఈ పద్ధతి యొక్క సరైన ఉపయోగం:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy`, కాబట్టి మనం చాలాసార్లు చదవవచ్చు.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `None` విలువను నకిలీ చేయడం సరే, కాబట్టి మనం చాలాసార్లు చదవవచ్చు.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// ఈ పద్ధతి యొక్క *తప్పు* వాడకం:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // మేము ఇప్పుడు ఒకే vector యొక్క రెండు కాపీలను సృష్టించాము, ఇవి రెండూ పడిపోయినప్పుడు డబుల్-ఫ్రీకి దారితీస్తాయి!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // భద్రత: `self` ప్రారంభించబడిందని కాలర్ హామీ ఇవ్వాలి.
        // `self` ప్రారంభించబడాలి కాబట్టి `self.as_ptr()` నుండి చదవడం సురక్షితం.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// ఉన్న విలువను పడిపోతుంది.
    ///
    /// మీకు `MaybeUninit` యాజమాన్యం ఉంటే, మీరు బదులుగా [`assume_init`] ను ఉపయోగించవచ్చు.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` నిజంగా ప్రారంభ స్థితిలో ఉందని హామీ ఇవ్వడం కాలర్ వరకు ఉంది.కంటెంట్ ఇంకా పూర్తిగా ప్రారంభించబడనప్పుడు దీన్ని కాల్ చేయడం నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
    ///
    /// ఆ పైన, `T` రకం యొక్క అన్ని అదనపు మార్పులను సంతృప్తి పరచాలి, ఎందుకంటే `T` (లేదా దాని సభ్యులు) యొక్క `Drop` అమలు దీనిపై ఆధారపడవచ్చు.
    /// ఉదాహరణకు, `1`-ప్రారంభించిన [`Vec<T>`] ప్రారంభించబడినదిగా పరిగణించబడుతుంది (ప్రస్తుత అమలులో; ఇది స్థిరమైన హామీ ఇవ్వదు) ఎందుకంటే కంపైలర్‌కు దాని గురించి తెలిసిన ఏకైక అవసరం ఏమిటంటే డేటా పాయింటర్ శూన్యంగా ఉండాలి.
    ///
    /// అటువంటి `Vec<T>` ను వదలడం వలన నిర్వచించబడని ప్రవర్తనకు కారణం అవుతుంది.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // భద్రత: కాలర్ `self` ప్రారంభించబడిందని హామీ ఇవ్వాలి మరియు
        // `T` యొక్క అన్ని మార్పులను సంతృప్తిపరుస్తుంది.
        // ఒకవేళ ఆ స్థానంలో విలువను వదలడం సురక్షితం.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// ఉన్న విలువకు భాగస్వామ్య సూచనను పొందుతుంది.
    ///
    /// మేము ప్రారంభించిన `MaybeUninit` ని యాక్సెస్ చేయాలనుకున్నప్పుడు ఇది ఉపయోగపడుతుంది కాని `MaybeUninit` యొక్క యాజమాన్యం లేదు (`.assume_init()`) వాడకాన్ని నిరోధిస్తుంది.
    ///
    /// # Safety
    ///
    /// కంటెంట్ ఇంకా పూర్తిగా ప్రారంభించబడనప్పుడు దీన్ని కాల్ చేయడం నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది: `MaybeUninit<T>` నిజంగా ప్రారంభ స్థితిలో ఉందని హామీ ఇవ్వడం కాలర్ వరకు ఉంటుంది.
    ///
    ///
    /// # Examples
    ///
    /// ### ఈ పద్ధతి యొక్క సరైన ఉపయోగం:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` ను ప్రారంభించండి:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // ఇప్పుడు మా `MaybeUninit<_>` ప్రారంభించబడిందని తెలిసింది, దీనికి భాగస్వామ్య సూచనను సృష్టించడం సరైందే:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // భద్రత: `x` ప్రారంభించబడింది.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### ఈ పద్ధతి యొక్క *తప్పు* ఉపయోగాలు:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // మేము ప్రారంభించని vector కు సూచనను సృష్టించాము!ఇది నిర్వచించబడని ప్రవర్తన.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` ఉపయోగించి `MaybeUninit` ను ప్రారంభించండి:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // ప్రారంభించని `Cell<bool>` కు సూచన: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // భద్రత: `self` ప్రారంభించబడిందని కాలర్ హామీ ఇవ్వాలి.
        // దీని అర్థం `self` తప్పనిసరిగా `value` వేరియంట్ అయి ఉండాలి.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// ఉన్న విలువకు మార్చగల (unique) సూచనను పొందుతుంది.
    ///
    /// మేము ప్రారంభించిన `MaybeUninit` ని యాక్సెస్ చేయాలనుకున్నప్పుడు ఇది ఉపయోగపడుతుంది కాని `MaybeUninit` యొక్క యాజమాన్యం లేదు (`.assume_init()`) వాడకాన్ని నిరోధిస్తుంది.
    ///
    /// # Safety
    ///
    /// కంటెంట్ ఇంకా పూర్తిగా ప్రారంభించబడనప్పుడు దీన్ని కాల్ చేయడం నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది: `MaybeUninit<T>` నిజంగా ప్రారంభ స్థితిలో ఉందని హామీ ఇవ్వడం కాలర్ వరకు ఉంటుంది.
    /// ఉదాహరణకు, `MaybeUninit` ను ప్రారంభించడానికి `.assume_init_mut()` ఉపయోగించబడదు.
    ///
    /// # Examples
    ///
    /// ### ఈ పద్ధతి యొక్క సరైన ఉపయోగం:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// ఇన్పుట్ బఫర్ యొక్క *అన్ని* బైట్లను ప్రారంభిస్తుంది.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` ను ప్రారంభించండి:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // `buf` ప్రారంభించబడిందని ఇప్పుడు మనకు తెలుసు, కాబట్టి మేము దానిని `.assume_init()` చేయగలము.
    /// // అయినప్పటికీ, `.assume_init()` ను ఉపయోగించడం ద్వారా 2048 బైట్లలో `memcpy` ను ప్రేరేపించవచ్చు.
    /// // మా బఫర్ కాపీ చేయకుండా ప్రారంభించబడిందని నిర్ధారించడానికి, మేము `&mut MaybeUninit<[u8; 2048]>` ను `&mut [u8; 2048]` కి అప్‌గ్రేడ్ చేస్తాము:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // భద్రత: `buf` ప్రారంభించబడింది.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // ఇప్పుడు మనం `buf` ను సాధారణ స్లైస్‌గా ఉపయోగించవచ్చు:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### ఈ పద్ధతి యొక్క *తప్పు* ఉపయోగాలు:
    ///
    /// విలువను ప్రారంభించడానికి మీరు `.assume_init_mut()` ను ఉపయోగించలేరు:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // మేము ప్రారంభించని `bool` కు (mutable) సూచనను సృష్టించాము!
    ///     // ఇది నిర్వచించబడని ప్రవర్తన.⚠️
    /// }
    /// ```
    ///
    /// ఉదాహరణకు, మీరు ప్రారంభించని బఫర్‌లోకి [`Read`] చేయలేరు:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ప్రారంభించని మెమరీకి సూచన!
    ///                             // ఇది నిర్వచించబడని ప్రవర్తన.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// ఫీల్డ్-బై-ఫీల్డ్ క్రమంగా ప్రారంభించడానికి మీరు ప్రత్యక్ష ఫీల్డ్ యాక్సెస్‌ను ఉపయోగించలేరు:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ప్రారంభించని మెమరీకి సూచన!
    ///                  // ఇది నిర్వచించబడని ప్రవర్తన.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ప్రారంభించని మెమరీకి సూచన!
    ///                  // ఇది నిర్వచించబడని ప్రవర్తన.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): మేము ప్రస్తుతం పైవి తప్పు అని ఆధారపడ్డాము, అనగా, ప్రారంభించని డేటాకు సూచనలు ఉన్నాయి (ఉదా., `libcore/fmt/float.rs` లో).
    // స్థిరీకరణకు ముందు మేము నియమాల గురించి తుది నిర్ణయం తీసుకోవాలి.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // భద్రత: `self` ప్రారంభించబడిందని కాలర్ హామీ ఇవ్వాలి.
        // దీని అర్థం `self` తప్పనిసరిగా `value` వేరియంట్ అయి ఉండాలి.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` కంటైనర్ల శ్రేణి నుండి విలువలను సంగ్రహిస్తుంది.
    ///
    /// # Safety
    ///
    /// శ్రేణి యొక్క అన్ని అంశాలు ప్రారంభ స్థితిలో ఉన్నాయని హామీ ఇవ్వడం కాలర్ వరకు ఉంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // భద్రత: మేము అన్ని అంశాలను ప్రారంభించినందున ఇప్పుడు సురక్షితం
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * శ్రేణి యొక్క అన్ని అంశాలు ప్రారంభించబడతాయని కాలర్ హామీ ఇస్తుంది
        // * `MaybeUninit<T>` మరియు T ఒకే లేఅవుట్ కలిగివుంటాయి
        // * బహుశా యునింట్ పడిపోదు, కాబట్టి డబుల్ ఫ్రీలు లేవు మరియు అందువల్ల మార్పిడి సురక్షితం
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// అన్ని అంశాలు ప్రారంభించబడిందని uming హిస్తే, వాటికి ఒక స్లైస్ పొందండి.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` మూలకాలు నిజంగా ప్రారంభ స్థితిలో ఉన్నాయని హామీ ఇవ్వడం కాలర్ వరకు ఉంది.
    ///
    /// కంటెంట్ ఇంకా పూర్తిగా ప్రారంభించబడనప్పుడు దీన్ని కాల్ చేయడం నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
    ///
    /// మరిన్ని వివరాలు మరియు ఉదాహరణల కోసం [`assume_init_ref`] చూడండి.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // భద్రత: కాలర్ హామీ ఇచ్చినందున `*const [T]` కు స్లైస్ వేయడం సురక్షితం
        // `slice` ప్రారంభించబడింది, మరియు `మేబ్యూనినిట్` `T` వలె అదే లేఅవుట్ కలిగి ఉంటుందని హామీ ఇవ్వబడింది.
        // పొందిన పాయింటర్ చెల్లుతుంది ఎందుకంటే ఇది `slice` యాజమాన్యంలోని మెమరీని సూచిస్తుంది, ఇది సూచన మరియు అందువల్ల రీడ్‌లకు చెల్లుబాటు అవుతుంది.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// అన్ని అంశాలు ప్రారంభించబడిందని uming హిస్తే, వాటికి మ్యూటబుల్ స్లైస్ పొందండి.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` మూలకాలు నిజంగా ప్రారంభ స్థితిలో ఉన్నాయని హామీ ఇవ్వడం కాలర్ వరకు ఉంది.
    ///
    /// కంటెంట్ ఇంకా పూర్తిగా ప్రారంభించబడనప్పుడు దీన్ని కాల్ చేయడం నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
    ///
    /// మరిన్ని వివరాలు మరియు ఉదాహరణల కోసం [`assume_init_mut`] చూడండి.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // భద్రత: `slice_get_ref` కోసం భద్రతా గమనికల మాదిరిగానే, కానీ మాకు a
        // మ్యూటబుల్ రిఫరెన్స్, ఇది వ్రాతలకు చెల్లుబాటు అవుతుందని కూడా హామీ ఇవ్వబడింది.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// శ్రేణి యొక్క మొదటి మూలకానికి పాయింటర్ పొందుతుంది.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// శ్రేణి యొక్క మొదటి మూలకానికి మార్చగల పాయింటర్‌ను పొందుతుంది.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` నుండి `this` వరకు మూలకాలను కాపీ చేస్తుంది, `this` యొక్క ఇప్పుడు ప్రారంభించని విషయాలకు మార్చగల సూచనను అందిస్తుంది.
    ///
    /// `T` `Copy` ను అమలు చేయకపోతే, [`write_slice_cloned`] ను ఉపయోగించండి
    ///
    /// ఇది [`slice::copy_from_slice`] ను పోలి ఉంటుంది.
    ///
    /// # Panics
    ///
    /// రెండు ముక్కలు వేర్వేరు పొడవులను కలిగి ఉంటే ఈ ఫంక్షన్ panic అవుతుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // భద్రత: మేము లెన్ యొక్క అన్ని అంశాలను విడి సామర్థ్యంలోకి కాపీ చేసాము
    /// // వెక్ యొక్క మొదటి src.len() అంశాలు ఇప్పుడు చెల్లుతాయి.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // భద్రత: &[T] మరియు&[బహుశా యునినిట్<T>] ఒకే లేఅవుట్ కలిగి ఉంటాయి
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // భద్రత: చెల్లుబాటు అయ్యే అంశాలు ఇప్పుడే `this` లోకి కాపీ చేయబడ్డాయి కాబట్టి ఇది ప్రారంభించబడలేదు
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` నుండి `this` వరకు మూలకాలను క్లోన్ చేస్తుంది, `this` యొక్క ఇప్పుడు ప్రారంభించని విషయాలకు మార్చగల సూచనను అందిస్తుంది.
    /// ఇప్పటికే ప్రారంభించని అంశాలు ఏవీ వదలబడవు.
    ///
    /// `T` `Copy` ను అమలు చేస్తే, [`write_slice`] ఉపయోగించండి
    ///
    /// ఇది [`slice::clone_from_slice`] ను పోలి ఉంటుంది కాని ఇప్పటికే ఉన్న అంశాలను వదలదు.
    ///
    /// # Panics
    ///
    /// రెండు ముక్కలు వేర్వేరు పొడవు కలిగి ఉంటే లేదా `Clone` panics అమలు చేస్తే ఈ ఫంక్షన్ panic అవుతుంది.
    ///
    /// panic ఉంటే, ఇప్పటికే క్లోన్ చేసిన అంశాలు తొలగించబడతాయి.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // భద్రత: మేము లెన్ యొక్క అన్ని అంశాలను విడి సామర్థ్యంలోకి క్లోన్ చేసాము
    /// // వెక్ యొక్క మొదటి src.len() అంశాలు ఇప్పుడు చెల్లుతాయి.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Copy_from_slice కాకుండా ఇది స్లైస్‌లో క్లోన్_ఫ్రోమ్_స్లైస్ అని పిలవదు ఎందుకంటే `MaybeUninit<T: Clone>` క్లోన్‌ను అమలు చేయదు.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // భద్రత: ఈ ముడి ముక్కలో ప్రారంభించిన వస్తువులు మాత్రమే ఉంటాయి
                // అందుకే, దానిని వదలడానికి అనుమతి ఉంది.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: మేము వాటిని ఒకే పొడవుకు స్పష్టంగా ముక్కలు చేయాలి
        // హద్దులు తనిఖీ చేయటానికి, మరియు ఆప్టిమైజర్ సాధారణ సందర్భాల్లో మెమ్‌క్పీని ఉత్పత్తి చేస్తుంది (ఉదాహరణకు T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // గార్డు అవసరం b/c panic క్లోన్ సమయంలో జరగవచ్చు
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // భద్రత: చెల్లుబాటు అయ్యే అంశాలు ఇప్పుడే `this` లోకి వ్రాయబడ్డాయి కాబట్టి ఇది ప్రారంభించబడలేదు
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}