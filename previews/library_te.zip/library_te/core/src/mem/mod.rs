//! మెమరీతో వ్యవహరించడానికి ప్రాథమిక విధులు.
//!
//! ఈ మాడ్యూల్ రకాలను పరిమాణం మరియు అమరికను ప్రశ్నించడం, మెమరీని ప్రారంభించడం మరియు మార్చడం వంటి విధులను కలిగి ఉంటుంది.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// దాని డిస్ట్రక్టర్ **ను అమలు చేయకుండా** విలువ గురించి యాజమాన్యం మరియు "forgets" తీసుకుంటుంది.
///
/// కుప్ప మెమరీ లేదా ఫైల్ హ్యాండిల్ వంటి విలువ నిర్వహించే ఏవైనా వనరులు ఎప్పటికీ చేరుకోలేని స్థితిలో ఉంటాయి.అయితే, ఈ మెమరీకి సూచికలు చెల్లుబాటులో ఉంటాయని ఇది హామీ ఇవ్వదు.
///
/// * మీరు మెమరీని లీక్ చేయాలనుకుంటే, [`Box::leak`] చూడండి.
/// * మీరు మెమరీకి ముడి పాయింటర్ పొందాలనుకుంటే, [`Box::into_raw`] చూడండి.
/// * మీరు విలువను సరిగ్గా పారవేయాలనుకుంటే, దాని డిస్ట్రక్టర్‌ను నడుపుతూ, [`mem::drop`] చూడండి.
///
/// # Safety
///
/// `forget` `unsafe` గా గుర్తించబడలేదు, ఎందుకంటే Rust యొక్క భద్రతా హామీలు డిస్ట్రక్టర్లు ఎల్లప్పుడూ నడుస్తాయనే హామీని కలిగి ఉండవు.
/// ఉదాహరణకు, ఒక ప్రోగ్రామ్ [`Rc`][rc] ను ఉపయోగించి రిఫరెన్స్ సైకిల్‌ని సృష్టించగలదు లేదా డిస్ట్రక్టర్లను అమలు చేయకుండా నిష్క్రమించడానికి [`process::exit`][exit] కి కాల్ చేయవచ్చు.
/// అందువల్ల, `mem::forget` ను సురక్షిత కోడ్ నుండి అనుమతించడం ప్రాథమికంగా Rust యొక్క భద్రతా హామీలను మార్చదు.
///
/// మెమరీ లేదా I/O ఆబ్జెక్ట్స్ వంటి వనరులను లీక్ చేయడం సాధారణంగా అవాంఛనీయమైనది.
/// FFI లేదా అసురక్షిత కోడ్ కోసం కొన్ని ప్రత్యేకమైన ఉపయోగ సందర్భాలలో అవసరం వస్తుంది, అయితే అప్పుడు కూడా, [`ManuallyDrop`] సాధారణంగా ప్రాధాన్యత ఇవ్వబడుతుంది.
///
/// విలువను మరచిపోవటం అనుమతించబడినందున, మీరు వ్రాసే ఏదైనా `unsafe` కోడ్ ఈ అవకాశాన్ని అనుమతించాలి.మీరు విలువను తిరిగి ఇవ్వలేరు మరియు కాలర్ తప్పనిసరిగా విలువ యొక్క డిస్ట్రక్టర్‌ను అమలు చేస్తుందని ఆశించవచ్చు.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// `mem::forget` యొక్క కానానికల్ సురక్షిత ఉపయోగం `Drop` trait చే అమలు చేయబడిన విలువ యొక్క డిస్ట్రక్టర్‌ను తప్పించడం.ఉదాహరణకు, ఇది `File` ను లీక్ చేస్తుంది, అనగా
/// వేరియబుల్ తీసుకున్న స్థలాన్ని తిరిగి పొందండి కాని అంతర్లీన సిస్టమ్ వనరును ఎప్పుడూ మూసివేయవద్దు:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// అంతర్లీన వనరు యొక్క యాజమాన్యం గతంలో Rust వెలుపల కోడ్‌కు బదిలీ చేయబడినప్పుడు ఇది ఉపయోగపడుతుంది, ఉదాహరణకు ముడి ఫైల్ డిస్క్రిప్టర్‌ను C కోడ్‌కు ప్రసారం చేయడం ద్వారా.
///
/// # `ManuallyDrop` తో సంబంధం
///
/// `mem::forget`*మెమరీ* యాజమాన్యాన్ని బదిలీ చేయడానికి కూడా ఉపయోగించవచ్చు, అలా చేయడం లోపం సంభవిస్తుంది.
/// [`ManuallyDrop`] బదులుగా ఉపయోగించాలి.ఉదాహరణకు, ఈ కోడ్‌ను పరిగణించండి:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // `v` యొక్క కంటెంట్లను ఉపయోగించి `String` ను నిర్మించండి
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // లీక్ `v` ఎందుకంటే దాని మెమరీ ఇప్పుడు `s` చే నిర్వహించబడుతుంది
/// mem::forget(v);  // లోపం, v చెల్లదు మరియు ఒక ఫంక్షన్‌కు పంపించకూడదు
/// assert_eq!(s, "Az");
/// // `s` అవ్యక్తంగా పడిపోయింది మరియు దాని జ్ఞాపకశక్తి విడదీయబడుతుంది.
/// ```
///
/// పై ఉదాహరణతో రెండు సమస్యలు ఉన్నాయి:
///
/// * `String` నిర్మాణం మరియు `mem::forget()` యొక్క ఆహ్వానం మధ్య ఎక్కువ కోడ్ జోడించబడితే, దానిలోని panic డబుల్ ఫ్రీకి కారణమవుతుంది ఎందుకంటే అదే మెమరీని `v` మరియు `s` రెండూ నిర్వహిస్తాయి.
/// * `v.as_mut_ptr()` కి కాల్ చేసి, డేటా యాజమాన్యాన్ని `s` కి ప్రసారం చేసిన తరువాత, `v` విలువ చెల్లదు.
/// ఒక విలువ కేవలం `mem::forget` కి తరలించబడినప్పటికీ (అది పరిశీలించదు), కొన్ని రకాలు వాటి విలువలపై కఠినమైన అవసరాలను కలిగి ఉంటాయి, అవి డాంగ్లింగ్ చేసేటప్పుడు లేదా ఇకపై స్వంతం కానప్పుడు అవి చెల్లవు.
/// చెల్లని విలువలను ఏ విధంగానైనా ఉపయోగించడం, వాటిని ఫంక్షన్లకు పంపించడం లేదా వాటిని తిరిగి ఇవ్వడం వంటివి నిర్వచించబడని ప్రవర్తనను కలిగి ఉంటాయి మరియు కంపైలర్ చేసిన ump హలను విచ్ఛిన్నం చేయవచ్చు.
///
/// `ManuallyDrop` కి మారడం రెండు సమస్యలను నివారిస్తుంది:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // మేము `v` ను దాని ముడి భాగాలలో విడదీసే ముందు, అది పడిపోకుండా చూసుకోండి!
/////
/// let mut v = ManuallyDrop::new(v);
/// // ఇప్పుడు `v` ను విడదీయండి.ఈ కార్యకలాపాలు panic కాదు, కాబట్టి లీక్ ఉండకూడదు.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // చివరగా, `String` ను నిర్మించండి.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` అవ్యక్తంగా పడిపోయింది మరియు దాని జ్ఞాపకశక్తి విడదీయబడుతుంది.
/// ```
///
/// `ManuallyDrop` మరేదైనా చేసే ముందు `v` యొక్క డిస్ట్రక్టర్‌ను డిసేబుల్ చేస్తున్నందున డబుల్ ఫ్రీని గట్టిగా నిరోధిస్తుంది.
/// `mem::forget()` దీన్ని అనుమతించదు ఎందుకంటే ఇది దాని వాదనను వినియోగిస్తుంది, `v` నుండి మనకు అవసరమైన ఏదైనా సంగ్రహించిన తర్వాత మాత్రమే కాల్ చేయమని బలవంతం చేస్తుంది.
/// `ManuallyDrop` నిర్మాణం మరియు స్ట్రింగ్‌ను నిర్మించడం మధ్య panic ప్రవేశపెట్టినప్పటికీ (ఇది చూపిన విధంగా కోడ్‌లో జరగదు), ఇది లీక్‌కు దారితీస్తుంది మరియు డబుల్ ఫ్రీ కాదు.
/// మరో మాటలో చెప్పాలంటే, (డబుల్-) పడిపోవటం వైపు తప్పు చేయకుండా బదులుగా లీక్ చేసే వైపు `ManuallyDrop` తప్పుతుంది.
///
/// అలాగే, యాజమాన్యాన్ని `s` కి బదిలీ చేసిన తర్వాత X001 X 01X `v` కు రాకుండా నిరోధిస్తుంది-`v` తో దాని డిస్ట్రక్టర్‌ను అమలు చేయకుండా పారవేసేందుకు `v` తో పరస్పర చర్య చేసే చివరి దశ పూర్తిగా నివారించబడుతుంది.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// [`forget`] వలె, కానీ పరిమాణీకరించని విలువలను కూడా అంగీకరిస్తుంది.
///
/// ఈ ఫంక్షన్ `unsized_locals` ఫీచర్ స్థిరీకరించబడినప్పుడు తొలగించడానికి ఉద్దేశించిన షిమ్ మాత్రమే.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// బైట్‌లలో ఒక రకం పరిమాణాన్ని చూపుతుంది.
///
/// మరింత ప్రత్యేకంగా, అమరిక పాడింగ్‌తో సహా ఆ ఐటెమ్ రకంతో శ్రేణిలోని వరుస మూలకాల మధ్య బైట్‌లలో ఇది ఆఫ్‌సెట్.
///
/// అందువల్ల, ఏదైనా రకం `T` మరియు పొడవు `n` కోసం, `[T; n]` `n * size_of::<T>()` పరిమాణాన్ని కలిగి ఉంటుంది.
///
/// సాధారణంగా, ఒక రకం పరిమాణం సంకలనాలలో స్థిరంగా ఉండదు, కానీ ఆదిమ వంటి నిర్దిష్ట రకాలు.
///
/// కింది పట్టిక ఆదిమవాసుల పరిమాణాన్ని ఇస్తుంది.
///
/// రకం |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 చార్ |4
///
/// ఇంకా, `usize` మరియు `isize` ఒకే పరిమాణాన్ని కలిగి ఉంటాయి.
///
/// `*const T`, `&T`, `Box<T>`, `Option<&T>` మరియు `Option<Box<T>>` రకాలు ఒకే పరిమాణాన్ని కలిగి ఉంటాయి.
/// `T` పరిమాణంలో ఉంటే, ఆ రకాలు అన్నింటికీ `usize` పరిమాణాన్ని కలిగి ఉంటాయి.
///
/// పాయింటర్ యొక్క మ్యుటబిలిటీ దాని పరిమాణాన్ని మార్చదు.అలాగే, `&T` మరియు `&mut T` ఒకే పరిమాణాన్ని కలిగి ఉంటాయి.
/// అదేవిధంగా `*const T` మరియు `* mut T` కోసం.
///
/// # `#[repr(C)]` అంశాల పరిమాణం
///
/// అంశాల కోసం `C` ప్రాతినిధ్యం నిర్వచించిన లేఅవుట్ను కలిగి ఉంది.
/// ఈ లేఅవుట్‌తో, అన్ని ఫీల్డ్‌లు స్థిరమైన పరిమాణాన్ని కలిగి ఉన్నంత వరకు వస్తువుల పరిమాణం కూడా స్థిరంగా ఉంటుంది.
///
/// ## నిర్మాణాల పరిమాణం
///
/// `structs` కోసం, పరిమాణం క్రింది అల్గోరిథం ద్వారా నిర్ణయించబడుతుంది.
///
/// డిక్లరేషన్ ఆర్డర్ ద్వారా ఆదేశించిన struct లోని ప్రతి ఫీల్డ్ కోసం:
///
/// 1. ఫీల్డ్ యొక్క పరిమాణాన్ని జోడించండి.
/// 2. ప్రస్తుత పరిమాణాన్ని తదుపరి ఫీల్డ్ యొక్క [alignment] యొక్క సమీప గుణకారానికి రౌండ్ చేయండి.
///
/// చివరగా, struct యొక్క పరిమాణాన్ని దాని [alignment] యొక్క సమీప గుణకారానికి రౌండ్ చేయండి.
/// స్ట్రక్ట్ యొక్క అమరిక సాధారణంగా దాని అన్ని రంగాలలో అతిపెద్ద అమరిక;`repr(align(N))` వాడకంతో దీనిని మార్చవచ్చు.
///
/// `C` మాదిరిగా కాకుండా, సున్నా పరిమాణ నిర్మాణాలు ఒక బైట్ పరిమాణంలో గుండ్రంగా ఉండవు.
///
/// ## ఎనుమ్స్ పరిమాణం
///
/// వివక్షత తప్ప వేరే డేటాను కలిగి లేని ఎనుమ్స్ వారు సంకలనం చేసిన ప్లాట్‌ఫారమ్‌లో సి ఎనుమ్‌ల పరిమాణాన్ని కలిగి ఉంటాయి.
///
/// ## యూనియన్ల పరిమాణం
///
/// యూనియన్ యొక్క పరిమాణం దాని అతిపెద్ద క్షేత్రం యొక్క పరిమాణం.
///
/// `C` మాదిరిగా కాకుండా, సున్నా పరిమాణ యూనియన్లు ఒక బైట్ పరిమాణంలో గుండ్రంగా ఉండవు.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // కొన్ని ఆదిమ
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // కొన్ని శ్రేణులు
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // పాయింటర్ పరిమాణం సమానత్వం
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// `#[repr(C)]` ఉపయోగిస్తోంది.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // మొదటి ఫీల్డ్ యొక్క పరిమాణం 1, కాబట్టి పరిమాణానికి 1 జోడించండి.పరిమాణం 1.
/// // రెండవ ఫీల్డ్ యొక్క అమరిక 2, కాబట్టి పాడింగ్ కోసం పరిమాణానికి 1 జోడించండి.పరిమాణం 2.
/// // రెండవ ఫీల్డ్ యొక్క పరిమాణం 2, కాబట్టి పరిమాణానికి 2 జోడించండి.పరిమాణం 4.
/// // మూడవ ఫీల్డ్ యొక్క అమరిక 1, కాబట్టి పాడింగ్ కోసం పరిమాణానికి 0 జోడించండి.పరిమాణం 4.
/// // మూడవ ఫీల్డ్ యొక్క పరిమాణం 1, కాబట్టి పరిమాణానికి 1 జోడించండి.పరిమాణం 5.
/// // చివరగా, struct యొక్క అమరిక 2 (ఎందుకంటే దాని క్షేత్రాలలో అతిపెద్ద అమరిక 2), కాబట్టి పాడింగ్ కోసం పరిమాణానికి 1 జోడించండి.
/// // పరిమాణం 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // టుపుల్ స్ట్రక్ట్స్ అదే నియమాలను అనుసరిస్తాయి.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // ఫీల్డ్‌లను క్రమాన్ని మార్చడం పరిమాణాన్ని తగ్గిస్తుందని గమనించండి.
/// // `second` కి ముందు `third` ను ఉంచడం ద్వారా మేము రెండు పాడింగ్ బైట్‌లను తొలగించవచ్చు.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // యూనియన్ పరిమాణం అతిపెద్ద ఫీల్డ్ యొక్క పరిమాణం.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// సూచించిన విలువ యొక్క పరిమాణాన్ని బైట్‌లలో అందిస్తుంది.
///
/// ఇది సాధారణంగా `size_of::<T>()` వలె ఉంటుంది.
/// అయినప్పటికీ, `T`*కు* స్థిరంగా తెలిసిన పరిమాణం లేనప్పుడు, ఉదా., స్లైస్ [`[T]`][slice] లేదా [trait object], అప్పుడు డైనమిక్‌గా తెలిసిన పరిమాణాన్ని పొందడానికి `size_of_val` ను ఉపయోగించవచ్చు.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // భద్రత: `val` ఒక సూచన, కాబట్టి ఇది చెల్లుబాటు అయ్యే ముడి పాయింటర్
    unsafe { intrinsics::size_of_val(val) }
}

/// సూచించిన విలువ యొక్క పరిమాణాన్ని బైట్‌లలో అందిస్తుంది.
///
/// ఇది సాధారణంగా `size_of::<T>()` వలె ఉంటుంది.అయినప్పటికీ, `T`*కు* స్థిరంగా తెలిసిన పరిమాణం లేనప్పుడు, ఉదా., స్లైస్ [`[T]`][slice] లేదా [trait object], అప్పుడు డైనమిక్‌గా తెలిసిన పరిమాణాన్ని పొందడానికి `size_of_val_raw` ను ఉపయోగించవచ్చు.
///
/// # Safety
///
/// కింది షరతులు ఉంటే ఈ ఫంక్షన్ కాల్ చేయడం మాత్రమే సురక్షితం:
///
/// - `T` `Sized` అయితే, ఈ ఫంక్షన్ కాల్ చేయడానికి ఎల్లప్పుడూ సురక్షితం.
/// - `T` యొక్క పరిమాణం లేని తోక ఉంటే:
///     - ఒక [slice], అప్పుడు స్లైస్ తోక యొక్క పొడవు తప్పనిసరిగా ప్రారంభించబడిన పూర్ణాంకం, మరియు *మొత్తం విలువ*(డైనమిక్ తోక పొడవు + గణాంక పరిమాణ ఉపసర్గ) యొక్క పరిమాణం `isize` లో సరిపోతుంది.
///     - ఒక [trait object], అప్పుడు పాయింటర్ యొక్క vtable భాగం తప్పనిసరిగా బలవంతపు బలవంతం ద్వారా పొందిన చెల్లుబాటు అయ్యే vtable ని సూచించాలి మరియు *మొత్తం విలువ*(డైనమిక్ తోక పొడవు + స్థిరంగా పరిమాణ ఉపసర్గ) యొక్క పరిమాణం `isize` లో సరిపోతుంది.
///
///     - (unstable) [extern type], అప్పుడు ఈ ఫంక్షన్ కాల్ చేయడం ఎల్లప్పుడూ సురక్షితం, కానీ బాహ్య రకం యొక్క లేఅవుట్ తెలియకపోవడంతో panic లేదా తప్పు విలువను తిరిగి ఇవ్వవచ్చు.
///     బాహ్య రకం తోకతో ఉన్న రకానికి సూచనగా ఇది [`size_of_val`] వలె ఉంటుంది.
///     - లేకపోతే, సంప్రదాయబద్ధంగా ఈ ఫంక్షన్‌ను పిలవడానికి అనుమతించబడదు.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // భద్రత: కాలర్ తప్పనిసరిగా చెల్లుబాటు అయ్యే ముడి పాయింటర్‌ను అందించాలి
    unsafe { intrinsics::size_of_val(val) }
}

/// [ABI]-ఒక రకం కనీస అమరికను అందిస్తుంది.
///
/// `T` రకం విలువకు ప్రతి సూచన ఈ సంఖ్య యొక్క గుణకం అయి ఉండాలి.
///
/// ఇది struct ఫీల్డ్‌ల కోసం ఉపయోగించే అమరిక.ఇది ఇష్టపడే అమరిక కంటే చిన్నదిగా ఉండవచ్చు.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` సూచించే విలువ యొక్క [ABI] కోరిన కనీస అమరికను అందిస్తుంది.
///
/// `T` రకం విలువకు ప్రతి సూచన ఈ సంఖ్య యొక్క గుణకం అయి ఉండాలి.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // భద్రత: వాల్ ఒక సూచన, కాబట్టి ఇది చెల్లుబాటు అయ్యే ముడి పాయింటర్
    unsafe { intrinsics::min_align_of_val(val) }
}

/// [ABI]-ఒక రకం కనీస అమరికను అందిస్తుంది.
///
/// `T` రకం విలువకు ప్రతి సూచన ఈ సంఖ్య యొక్క గుణకం అయి ఉండాలి.
///
/// ఇది struct ఫీల్డ్‌ల కోసం ఉపయోగించే అమరిక.ఇది ఇష్టపడే అమరిక కంటే చిన్నదిగా ఉండవచ్చు.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// `val` సూచించే విలువ యొక్క [ABI] కోరిన కనీస అమరికను అందిస్తుంది.
///
/// `T` రకం విలువకు ప్రతి సూచన ఈ సంఖ్య యొక్క గుణకం అయి ఉండాలి.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // భద్రత: వాల్ ఒక సూచన, కాబట్టి ఇది చెల్లుబాటు అయ్యే ముడి పాయింటర్
    unsafe { intrinsics::min_align_of_val(val) }
}

/// `val` సూచించే విలువ యొక్క [ABI] కోరిన కనీస అమరికను అందిస్తుంది.
///
/// `T` రకం విలువకు ప్రతి సూచన ఈ సంఖ్య యొక్క గుణకం అయి ఉండాలి.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// కింది షరతులు ఉంటే ఈ ఫంక్షన్ కాల్ చేయడం మాత్రమే సురక్షితం:
///
/// - `T` `Sized` అయితే, ఈ ఫంక్షన్ కాల్ చేయడానికి ఎల్లప్పుడూ సురక్షితం.
/// - `T` యొక్క పరిమాణం లేని తోక ఉంటే:
///     - ఒక [slice], అప్పుడు స్లైస్ తోక యొక్క పొడవు తప్పనిసరిగా ప్రారంభించబడిన పూర్ణాంకం, మరియు *మొత్తం విలువ*(డైనమిక్ తోక పొడవు + గణాంక పరిమాణ ఉపసర్గ) యొక్క పరిమాణం `isize` లో సరిపోతుంది.
///     - ఒక [trait object], అప్పుడు పాయింటర్ యొక్క vtable భాగం తప్పనిసరిగా బలవంతపు బలవంతం ద్వారా పొందిన చెల్లుబాటు అయ్యే vtable ని సూచించాలి మరియు *మొత్తం విలువ*(డైనమిక్ తోక పొడవు + స్థిరంగా పరిమాణ ఉపసర్గ) యొక్క పరిమాణం `isize` లో సరిపోతుంది.
///
///     - (unstable) [extern type], అప్పుడు ఈ ఫంక్షన్ కాల్ చేయడం ఎల్లప్పుడూ సురక్షితం, కానీ బాహ్య రకం యొక్క లేఅవుట్ తెలియకపోవడంతో panic లేదా తప్పు విలువను తిరిగి ఇవ్వవచ్చు.
///     బాహ్య రకం తోకతో ఉన్న రకానికి సూచనగా ఇది [`align_of_val`] వలె ఉంటుంది.
///     - లేకపోతే, సంప్రదాయబద్ధంగా ఈ ఫంక్షన్‌ను పిలవడానికి అనుమతించబడదు.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // భద్రత: కాలర్ తప్పనిసరిగా చెల్లుబాటు అయ్యే ముడి పాయింటర్‌ను అందించాలి
    unsafe { intrinsics::min_align_of_val(val) }
}

/// రకం `T` విషయాల విలువలను వదిలివేస్తే `true` ని అందిస్తుంది.
///
/// ఇది పూర్తిగా ఆప్టిమైజేషన్ సూచన, మరియు సంప్రదాయబద్ధంగా అమలు చేయవచ్చు:
/// వాస్తవానికి వదిలివేయవలసిన అవసరం లేని రకాల కోసం ఇది `true` ను తిరిగి ఇవ్వవచ్చు.
/// అందువల్ల ఎల్లప్పుడూ `true` ను తిరిగి ఇవ్వడం ఈ ఫంక్షన్ యొక్క చెల్లుబాటు అయ్యే అమలు అవుతుంది.అయితే ఈ ఫంక్షన్ వాస్తవానికి `false` ను తిరిగి ఇస్తే, `T` ను వదలడం వల్ల దుష్ప్రభావం ఉండదు.
///
/// సేకరణలు వంటి వాటి యొక్క తక్కువ స్థాయి అమలులు, వాటి డేటాను మాన్యువల్‌గా డ్రాప్ చేయాల్సిన అవసరం ఉంది, అవి నాశనం అయినప్పుడు అనవసరంగా వాటి విషయాలన్నింటినీ వదలడానికి ప్రయత్నించకుండా ఉండటానికి ఈ ఫంక్షన్‌ను ఉపయోగించాలి.
///
/// ఇది విడుదల నిర్మాణాలలో తేడాను కలిగించకపోవచ్చు (ఇక్కడ దుష్ప్రభావాలు లేని లూప్ సులభంగా గుర్తించబడుతుంది మరియు తొలగించబడుతుంది), కానీ డీబగ్ నిర్మాణాలకు ఇది తరచుగా పెద్ద విజయం.
///
/// [`drop_in_place`] ఇప్పటికే ఈ చెక్‌ను చేస్తుందని గమనించండి, కాబట్టి మీ పనిభారాన్ని కొన్ని తక్కువ సంఖ్యలో [`drop_in_place`] కాల్‌లకు తగ్గించగలిగితే, దీన్ని ఉపయోగించడం అనవసరం.
/// ప్రత్యేకంగా మీరు ఒక స్లైస్‌ని [`drop_in_place`] చేయగలరని గమనించండి మరియు అది అన్ని విలువలకు ఒకే అవసరాలు_డ్రోప్ చెక్ చేస్తుంది.
///
/// Vec వంటి రకాలు `needs_drop` ను స్పష్టంగా ఉపయోగించకుండా కేవలం `drop_in_place(&mut self[..])`.
/// [`HashMap`] వంటి రకాలు, మరోవైపు, విలువలను ఒకదానికొకటి వదలాలి మరియు ఈ API ని ఉపయోగించాలి.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// సేకరణ `needs_drop` ను ఎలా ఉపయోగించవచ్చో ఇక్కడ ఒక ఉదాహరణ ఉంది:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // డేటాను వదలండి
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// ఆల్-జీరో బైట్-నమూనా ద్వారా ప్రాతినిధ్యం వహిస్తున్న రకం `T` విలువను అందిస్తుంది.
///
/// దీని అర్థం, ఉదాహరణకు, `(u8, u16)` లోని పాడింగ్ బైట్ తప్పనిసరిగా సున్నా కాదు.
///
/// అన్ని-సున్నా బైట్-నమూనా కొన్ని రకం `T` యొక్క చెల్లుబాటు అయ్యే విలువను సూచిస్తుందనే గ్యారెంటీ లేదు.
/// ఉదాహరణకు, ఆల్-జీరో బైట్-నమూనా రిఫరెన్స్ రకాలు (`&T`, `&mut T`) మరియు ఫంక్షన్ పాయింటర్లకు చెల్లుబాటు అయ్యే విలువ కాదు.
/// అటువంటి రకాల్లో `zeroed` ను ఉపయోగించడం వల్ల వెంటనే [undefined behavior][ub] వస్తుంది, ఎందుకంటే [the Rust compiler assumes][inv] ఎల్లప్పుడూ వేరియబుల్‌లో చెల్లుబాటు అయ్యే విలువ ఉంటుంది.
///
///
/// ఇది [`MaybeUninit::zeroed().assume_init()`][zeroed] మాదిరిగానే ఉంటుంది.
/// ఇది కొన్నిసార్లు FFI కి ఉపయోగపడుతుంది, కాని సాధారణంగా దీనిని నివారించాలి.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// ఈ ఫంక్షన్ యొక్క సరైన ఉపయోగం: సున్నాతో పూర్ణాంకాన్ని ప్రారంభించడం.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// ఈ ఫంక్షన్ యొక్క *తప్పు* వాడకం: సున్నాతో సూచనను ప్రారంభించడం.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // నిర్వచించబడని ప్రవర్తన!
/// let _y: fn() = unsafe { mem::zeroed() }; // మరలా!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // భద్రత: అన్ని సున్నా విలువ `T` కోసం చెల్లుతుందని కాలర్ హామీ ఇవ్వాలి.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// `T` రకం విలువను ఉత్పత్తి చేస్తున్నట్లు నటించడం ద్వారా Rust యొక్క సాధారణ మెమరీ-ప్రారంభ తనిఖీలను దాటవేస్తుంది, అదే సమయంలో ఏమీ చేయదు.
///
/// **ఈ ఫంక్షన్ తీసివేయబడింది.** బదులుగా [`MaybeUninit<T>`] ఉపయోగించండి.
///
/// తరుగుదలకి కారణం ఫంక్షన్ ప్రాథమికంగా సరిగ్గా ఉపయోగించబడదు: ఇది [`MaybeUninit::uninit().assume_init()`][uninit] మాదిరిగానే ఉంటుంది.
///
/// [`assume_init` documentation][assume_init] వివరించినట్లుగా, విలువలు సరిగ్గా ప్రారంభించబడిన [the Rust compiler assumes][inv].
/// పర్యవసానంగా, ఉదా
/// `mem::uninitialized::<bool>()` `bool` ను తిరిగి ఇవ్వడానికి తక్షణమే నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది, అది ఖచ్చితంగా `true` లేదా `false` కాదు.
/// అధ్వాన్నంగా, నిజంగా ప్రారంభించబడని మెమరీ ఇక్కడ తిరిగి రావడం వంటిది ప్రత్యేకమైనది, ఎందుకంటే కంపైలర్‌కు స్థిర విలువ లేదని తెలుసు.
/// ఇది వేరియబుల్‌లో పూర్ణాంక రకాన్ని కలిగి ఉన్నప్పటికీ వేరియబుల్‌లో ప్రారంభించని డేటాను కలిగి ఉండటానికి ఇది నిర్వచించబడని ప్రవర్తనను చేస్తుంది.
/// (ప్రారంభించని పూర్ణాంకాల చుట్టూ ఉన్న నియమాలు ఇంకా ఖరారు కాలేదని గమనించండి, కానీ అవి వచ్చే వరకు వాటిని నివారించడం మంచిది.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // భద్రత: `T` కోసం యూనిటైలైజ్డ్ విలువ చెల్లుతుందని కాలర్ హామీ ఇవ్వాలి.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// ఒకదానిని నిర్వీర్యం చేయకుండా, రెండు మార్చగల ప్రదేశాలలో విలువలను మార్పిడి చేస్తుంది.
///
/// * మీరు డిఫాల్ట్ లేదా డమ్మీ విలువతో మార్పిడి చేయాలనుకుంటే, [`take`] చూడండి.
/// * మీరు ఆమోదించిన విలువతో స్వాప్ చేయాలనుకుంటే, పాత విలువను తిరిగి ఇస్తే, [`replace`] చూడండి.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // భద్రత: ముడి పాయింటర్లు సురక్షితమైన మ్యూటబుల్ రిఫరెన్సుల నుండి సృష్టించబడ్డాయి
    // `ptr::swap_nonoverlapping_one` పై పరిమితులు
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` ను `T` యొక్క డిఫాల్ట్ విలువతో భర్తీ చేస్తుంది, మునుపటి `dest` విలువను తిరిగి ఇస్తుంది.
///
/// * మీరు రెండు వేరియబుల్స్ యొక్క విలువలను భర్తీ చేయాలనుకుంటే, [`swap`] చూడండి.
/// * మీరు డిఫాల్ట్ విలువకు బదులుగా ఆమోదించిన విలువతో భర్తీ చేయాలనుకుంటే, [`replace`] చూడండి.
///
/// # Examples
///
/// ఒక సాధారణ ఉదాహరణ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` "empty" విలువతో భర్తీ చేయడం ద్వారా స్ట్రక్ట్ ఫీల్డ్ యొక్క యాజమాన్యాన్ని తీసుకోవడానికి అనుమతిస్తుంది.
/// `take` లేకుండా మీరు ఇలాంటి సమస్యలను ఎదుర్కొంటారు:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// `T` తప్పనిసరిగా [`Clone`] ను అమలు చేయదని గమనించండి, కాబట్టి ఇది `self.buf` ను క్లోన్ చేసి రీసెట్ చేయలేము.
/// కానీ `self` యొక్క అసలు విలువను `self` నుండి విడదీయడానికి `take` ను ఉపయోగించవచ్చు, దానిని తిరిగి ఇవ్వడానికి అనుమతిస్తుంది:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` ను ప్రస్తావించిన `dest` లోకి కదిలి, మునుపటి `dest` విలువను తిరిగి ఇస్తుంది.
///
/// విలువ కూడా పడిపోదు.
///
/// * మీరు రెండు వేరియబుల్స్ యొక్క విలువలను భర్తీ చేయాలనుకుంటే, [`swap`] చూడండి.
/// * మీరు డిఫాల్ట్ విలువతో భర్తీ చేయాలనుకుంటే, [`take`] చూడండి.
///
/// # Examples
///
/// ఒక సాధారణ ఉదాహరణ:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` ఒక నిర్మాణ క్షేత్రాన్ని మరొక విలువతో భర్తీ చేయడం ద్వారా వినియోగించటానికి అనుమతిస్తుంది.
/// `replace` లేకుండా మీరు ఇలాంటి సమస్యలను ఎదుర్కొంటారు:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// `T` తప్పనిసరిగా [`Clone`] ను అమలు చేయదని గమనించండి, కాబట్టి మేము కదలికను నివారించడానికి `self.buf[i]` ను కూడా క్లోన్ చేయలేము.
/// కానీ `self` ను ఆ సూచిక వద్ద అసలు విలువను `self` నుండి విడదీయడానికి ఉపయోగించవచ్చు, దానిని తిరిగి ఇవ్వడానికి అనుమతిస్తుంది:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // భద్రత: మేము `dest` నుండి చదివాము కాని తరువాత నేరుగా `src` ను వ్రాస్తాము,
    // పాత విలువ నకిలీ చేయబడదు.
    // ఏదీ తొలగించబడలేదు మరియు ఇక్కడ ఏమీ panic చేయలేము.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// విలువను తొలగిస్తుంది.
///
/// [`Drop`][drop] యొక్క వాదన అమలుకు కాల్ చేయడం ద్వారా ఇది జరుగుతుంది.
///
/// ఇది `Copy` ను అమలు చేసే రకాలు కోసం సమర్థవంతంగా ఏమీ చేయదు, ఉదా
/// integers.
/// ఇటువంటి విలువలు కాపీ చేయబడతాయి మరియు _then_ ఫంక్షన్‌లోకి తరలించబడతాయి, కాబట్టి ఈ ఫంక్షన్ కాల్ తర్వాత విలువ కొనసాగుతుంది.
///
///
/// ఈ ఫంక్షన్ మేజిక్ కాదు;ఇది అక్షరాలా నిర్వచించబడింది
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// `_x` ఫంక్షన్‌లోకి తరలించబడినందున, ఫంక్షన్ తిరిగి రాకముందే అది స్వయంచాలకంగా పడిపోతుంది.
///
/// [drop]: Drop
///
/// # Examples
///
/// ప్రాథమిక వినియోగం:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // vector ను స్పష్టంగా వదలండి
/// ```
///
/// [`RefCell`] రన్టైమ్‌లో రుణ నిబంధనలను అమలు చేస్తుంది కాబట్టి, `drop` [`RefCell`] రుణాన్ని విడుదల చేస్తుంది:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // ఈ స్లాట్‌లో మార్చగల రుణాన్ని వదిలివేయండి
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// [`Copy`] ను అమలు చేసే పూర్ణాంకాలు మరియు ఇతర రకాలు `drop` చేత ప్రభావితం కావు.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // `x` యొక్క నకలు తరలించబడింది మరియు వదలబడుతుంది
/// drop(y); // `y` యొక్క కాపీ తరలించబడింది మరియు పడిపోతుంది
///
/// println!("x: {}, y: {}", x, y.0); // ఇప్పటికీ అందుబాటులో
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` ను `&U` రకం ఉన్నట్లు వివరిస్తుంది, ఆపై ఉన్న విలువను తరలించకుండా `src` ను చదువుతుంది.
///
/// ఈ ఫంక్షన్ `&T` ను `&U` కు ట్రాన్స్మిట్ చేసి `&U` ను చదవడం ద్వారా [`size_of::<U>`][size_of] బైట్లకు చెల్లుబాటు అవుతుందని ume హిస్తుంది (`&U` `&T` కన్నా కఠినమైన అమరిక అవసరాలను చేసినప్పుడు కూడా ఇది సరైన విధంగా జరుగుతుంది తప్ప).
/// ఇది `src` నుండి బయటికి వెళ్లడానికి బదులుగా ఉన్న విలువ యొక్క కాపీని కూడా సురక్షితంగా సృష్టిస్తుంది.
///
/// `T` మరియు `U` వేర్వేరు పరిమాణాలను కలిగి ఉంటే ఇది కంపైల్-టైమ్ లోపం కాదు, కానీ `T` మరియు `U` ఒకే పరిమాణాన్ని కలిగి ఉన్న ఈ ఫంక్షన్‌ను మాత్రమే ప్రారంభించమని ప్రోత్సహిస్తుంది.`U` `T` కన్నా పెద్దదిగా ఉంటే ఈ ఫంక్షన్ [undefined behavior][ub] ను ప్రేరేపిస్తుంది.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // 'foo_array' నుండి డేటాను కాపీ చేసి 'Foo' గా పరిగణించండి
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // కాపీ చేసిన డేటాను సవరించండి
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // 'foo_array' యొక్క విషయాలు మారకూడదు
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // U కి అధిక అమరిక అవసరం ఉంటే, src తగిన విధంగా సమలేఖనం చేయబడదు.
    if align_of::<U>() > align_of::<T>() {
        // భద్రత: `src` అనేది ఒక సూచన, ఇది చదవడానికి చెల్లుబాటు అవుతుంది.
        // అసలు పరివర్తన సురక్షితమని కాలర్ హామీ ఇవ్వాలి.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // భద్రత: `src` అనేది ఒక సూచన, ఇది చదవడానికి చెల్లుబాటు అవుతుంది.
        // `src as *const U` సరిగ్గా సమలేఖనం చేయబడిందని మేము తనిఖీ చేసాము.
        // అసలు పరివర్తన సురక్షితమని కాలర్ హామీ ఇవ్వాలి.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// ఎనుమ్ యొక్క వివక్షతను సూచించే అపారదర్శక రకం.
///
/// మరింత సమాచారం కోసం ఈ మాడ్యూల్‌లోని [`discriminant`] ఫంక్షన్ చూడండి.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. ఈ trait అమలులు T నుండి ఎటువంటి హద్దులు కోరుకోనందున పొందలేము.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// `v` లో ఎనుమ్ వేరియంట్‌ను ప్రత్యేకంగా గుర్తించే విలువను అందిస్తుంది.
///
/// `T` ఒక ఎన్యూమ్ కాకపోతే, ఈ ఫంక్షన్‌ను పిలవడం వలన నిర్వచించబడని ప్రవర్తన ఉండదు, కానీ తిరిగి వచ్చే విలువ పేర్కొనబడదు.
///
///
/// # Stability
///
/// ఎనుమ్ నిర్వచనం మారితే ఎనుమ్ వేరియంట్ యొక్క వివక్షత మారవచ్చు.
/// కొన్ని వేరియంట్ యొక్క వివక్షత ఒకే కంపైలర్‌తో సంకలనాల మధ్య మారదు.
///
/// # Examples
///
/// వాస్తవ డేటాను విస్మరిస్తూ డేటాను తీసుకువెళ్ళే ఎన్యూమ్‌లను పోల్చడానికి ఇది ఉపయోగపడుతుంది:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// ఎనుమ్ రకం `T` లోని వేరియంట్ల సంఖ్యను చూపుతుంది.
///
/// `T` ఒక ఎన్యూమ్ కాకపోతే, ఈ ఫంక్షన్‌ను పిలవడం వలన నిర్వచించబడని ప్రవర్తన ఉండదు, కానీ తిరిగి వచ్చే విలువ పేర్కొనబడదు.
/// అదేవిధంగా, `T` అనేది `usize::MAX` కన్నా ఎక్కువ వేరియంట్‌లతో కూడిన ఎనుమ్ అయితే తిరిగి విలువ పేర్కొనబడదు.
/// జనావాసాలు లేని వేరియంట్లు లెక్కించబడతాయి.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}