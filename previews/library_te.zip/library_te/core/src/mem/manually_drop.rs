use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// `T` యొక్క డిస్ట్రక్టర్‌ను స్వయంచాలకంగా కాల్ చేయకుండా కంపైలర్‌ను నిరోధించే రేపర్.
/// ఈ రేపర్ 0-ఖర్చు.
///
/// `ManuallyDrop<T>` `T` వలె అదే లేఅవుట్ ఆప్టిమైజేషన్లకు లోబడి ఉంటుంది.
/// పర్యవసానంగా, కంపైలర్ దాని విషయాల గురించి చేసే on హలపై ఇది * ప్రభావం చూపదు.
/// ఉదాహరణకు, [`mem::zeroed`] తో `ManuallyDrop<&mut T>` ను ప్రారంభించడం నిర్వచించబడని ప్రవర్తన.
/// మీరు ప్రారంభించని డేటాను నిర్వహించాల్సిన అవసరం ఉంటే, బదులుగా [`MaybeUninit<T>`] ను ఉపయోగించండి.
///
/// `ManuallyDrop<T>` లోపల విలువను యాక్సెస్ చేయడం సురక్షితం అని గమనించండి.
/// దీని అర్థం `ManuallyDrop<T>` కంటెంట్ తొలగించబడినది పబ్లిక్ సేఫ్ API ద్వారా బహిర్గతం కాకూడదు.
/// తదనుగుణంగా, `ManuallyDrop::drop` సురక్షితం కాదు.
///
/// # `ManuallyDrop` మరియు డ్రాప్ ఆర్డర్.
///
/// Rust బాగా నిర్వచించిన [drop order] విలువలను కలిగి ఉంది.
/// క్షేత్రాలు లేదా స్థానికులు ఒక నిర్దిష్ట క్రమంలో పడిపోయాయని నిర్ధారించుకోవడానికి, అవ్యక్త డ్రాప్ ఆర్డర్ సరైనది అని ప్రకటనలను క్రమాన్ని మార్చండి.
///
/// డ్రాప్ క్రమాన్ని నియంత్రించడానికి `ManuallyDrop` ను ఉపయోగించడం సాధ్యమే, కాని దీనికి అసురక్షిత కోడ్ అవసరం మరియు అన్‌వైండింగ్ సమక్షంలో సరిగ్గా చేయడం కష్టం.
///
///
/// ఉదాహరణకు, ఒక నిర్దిష్ట ఫీల్డ్ ఇతరుల తర్వాత పడిపోయిందని మీరు నిర్ధారించుకోవాలనుకుంటే, దాన్ని ఒక struct యొక్క చివరి ఫీల్డ్‌గా చేయండి:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` తర్వాత తొలగించబడుతుంది.
///     // Rust డిక్లరేషన్ క్రమంలో ఫీల్డ్‌లు పడిపోతాయని హామీ ఇస్తుంది.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// మానవీయంగా తొలగించాల్సిన విలువను చుట్టండి.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // మీరు ఇప్పటికీ విలువపై సురక్షితంగా పనిచేయగలరు
    /// assert_eq!(*x, "Hello");
    /// // కానీ `Drop` ఇక్కడ అమలు చేయబడదు
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` కంటైనర్ నుండి విలువను సంగ్రహిస్తుంది.
    ///
    /// ఇది విలువను మళ్ళీ వదలడానికి అనుమతిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // ఇది `Box` పడిపోతుంది.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` కంటైనర్ నుండి విలువను తీసుకుంటుంది.
    ///
    /// ఈ పద్ధతి ప్రధానంగా డ్రాప్‌లో విలువలను తరలించడానికి ఉద్దేశించబడింది.
    /// విలువను మాన్యువల్‌గా వదలడానికి [`ManuallyDrop::drop`] ను ఉపయోగించటానికి బదులుగా, మీరు ఈ పద్ధతిని ఉపయోగించి విలువను తీసుకొని దానిని కోరుకున్న విధంగా ఉపయోగించవచ్చు.
    ///
    /// సాధ్యమైనప్పుడల్లా, బదులుగా [`into_inner`][`ManuallyDrop::into_inner`] ను ఉపయోగించడం మంచిది, ఇది `ManuallyDrop<T>` యొక్క కంటెంట్‌ను నకిలీ చేయడాన్ని నిరోధిస్తుంది.
    ///
    ///
    /// # Safety
    ///
    /// ఈ ఫంక్షన్ మరింత వినియోగాన్ని నిరోధించకుండా ఉన్న విలువను అర్థవంతంగా కదిలిస్తుంది, ఈ కంటైనర్ యొక్క స్థితి మారదు.
    /// ఈ `ManuallyDrop` మళ్లీ ఉపయోగించబడకుండా చూసుకోవడం మీ బాధ్యత.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // భద్రత: మేము ఒక సూచన నుండి చదువుతున్నాము, ఇది హామీ
        // చదవడానికి చెల్లుబాటు అవుతుంది.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// ఉన్న విలువను మాన్యువల్‌గా పడిపోతుంది.ఇది కలిగి ఉన్న విలువకు పాయింటర్‌తో [`ptr::drop_in_place`] ని కాల్ చేయడానికి సమానం.
    /// అందువల్ల, కలిగి ఉన్న విలువ ప్యాక్ చేసిన స్ట్రక్ట్ కాకపోతే, విలువను తరలించకుండా డిస్ట్రక్టర్‌ను స్థలంలో పిలుస్తారు మరియు తద్వారా [pinned] డేటాను సురక్షితంగా వదలడానికి ఉపయోగించవచ్చు.
    ///
    /// మీకు విలువ యొక్క యాజమాన్యం ఉంటే, మీరు బదులుగా [`ManuallyDrop::into_inner`] ను ఉపయోగించవచ్చు.
    ///
    /// # Safety
    ///
    /// ఈ ఫంక్షన్ కలిగి ఉన్న విలువ యొక్క డిస్ట్రక్టర్‌ను నడుపుతుంది.
    /// డిస్ట్రక్టర్ చేసిన మార్పులు కాకుండా, మెమరీ మారదు, మరియు కంపైలర్ విషయానికొస్తే, `T` రకానికి చెల్లుబాటు అయ్యే బిట్-నమూనాను కలిగి ఉంది.
    ///
    ///
    /// అయితే, ఈ "zombie" విలువ సురక్షిత కోడ్‌కు గురికాకూడదు మరియు ఈ ఫంక్షన్‌ను ఒకటి కంటే ఎక్కువసార్లు పిలవకూడదు.
    /// విలువను వదిలివేసిన తర్వాత దాన్ని ఉపయోగించడం లేదా విలువను అనేకసార్లు వదలడం, నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది (`drop` ఏమి చేస్తుందో దానిపై ఆధారపడి).
    /// ఇది సాధారణంగా టైప్ సిస్టమ్ ద్వారా నిరోధించబడుతుంది, అయితే `ManuallyDrop` యొక్క వినియోగదారులు కంపైలర్ సహాయం లేకుండా ఆ హామీలను సమర్థించాలి.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // భద్రత: మేము మార్చగల సూచన ద్వారా సూచించిన విలువను వదిలివేస్తున్నాము
        // ఇది వ్రాతలకు చెల్లుబాటు అవుతుందని హామీ ఇవ్వబడింది.
        // `slot` మళ్లీ పడిపోకుండా చూసుకోవడం కాలర్ వరకు ఉంది.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}