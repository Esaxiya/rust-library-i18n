//! 'అవ్యక్తంగా కాపీ చేయలేని' రకాలు కోసం `Clone` trait.
//!
//! Rust లో, కొన్ని సాధారణ రకాలు "implicitly copyable" మరియు మీరు వాటిని కేటాయించినప్పుడు లేదా వాటిని వాదనలుగా పంపినప్పుడు, రిసీవర్‌కు ఒక కాపీ లభిస్తుంది, అసలు విలువను వదిలివేస్తుంది.
//! ఈ రకాలను కాపీ చేయడానికి కేటాయింపు అవసరం లేదు మరియు ఫైనలైజర్లు లేవు (అనగా, అవి యాజమాన్యంలోని పెట్టెలను కలిగి ఉండవు లేదా [`Drop`] ను అమలు చేస్తాయి), కాబట్టి కంపైలర్ వాటిని చౌకగా మరియు కాపీ చేయడానికి సురక్షితంగా భావిస్తుంది.
//!
//! [`Clone`] trait ను అమలు చేయడం ద్వారా మరియు [`clone`] పద్ధతిని పిలవడం ద్వారా ఇతర రకాల కాపీలు స్పష్టంగా తయారు చేయబడాలి.
//!
//! [`clone`]: Clone::clone
//!
//! ప్రాథమిక వినియోగ ఉదాహరణ:
//!
//! ```
//! let s = String::new(); // స్ట్రింగ్ రకం క్లోన్‌ను అమలు చేస్తుంది
//! let copy = s.clone(); // కాబట్టి మేము దానిని క్లోన్ చేయవచ్చు
//! ```
//!
//! క్లోన్ trait ను సులభంగా అమలు చేయడానికి, మీరు `#[derive(Clone)]` ను కూడా ఉపయోగించవచ్చు.ఉదాహరణ:
//!
//! ```
//! #[derive(Clone)] // మేము క్లోన్ trait ను మార్ఫియస్ స్ట్రక్ట్‌కు జోడిస్తాము
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ఇప్పుడు మనం దాన్ని క్లోన్ చేయవచ్చు!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// ఒక వస్తువును స్పష్టంగా నకిలీ చేసే సామర్థ్యం కోసం ఒక సాధారణ trait.
///
/// ఆ [`Copy`] లో [`Copy`] నుండి భిన్నంగా ఉంటుంది మరియు చాలా చవకైనది, అయితే `Clone` ఎల్లప్పుడూ స్పష్టంగా ఉంటుంది మరియు ఖరీదైనది కాకపోవచ్చు.
/// ఈ లక్షణాలను అమలు చేయడానికి,[`Copy`] ను తిరిగి అమర్చడానికి Rust మిమ్మల్ని అనుమతించదు, కానీ మీరు `Clone` ని తిరిగి అమర్చవచ్చు మరియు ఏకపక్ష కోడ్‌ను అమలు చేయవచ్చు.
///
/// [`Copy`] కంటే `Clone` చాలా సాధారణం కాబట్టి, మీరు స్వయంచాలకంగా [`Copy`] ను `Clone` గా కూడా చేయవచ్చు.
///
/// ## Derivable
///
/// అన్ని ఫీల్డ్‌లు `Clone` అయితే ఈ trait ను `#[derive]` తో ఉపయోగించవచ్చు.[`Clone`] యొక్క `ఉత్పన్నం` అమలు ప్రతి ఫీల్డ్‌లో [`clone`] కాల్స్.
///
/// [`clone`]: Clone::clone
///
/// జెనరిక్ స్ట్రక్ట్ కోసం, జెనరిక్ పారామితులపై కట్టుబడి ఉన్న `Clone` ని జోడించడం ద్వారా `#[derive]` `Clone` ని షరతులతో అమలు చేస్తుంది.
///
/// ```
/// // `derive` పఠనం కోసం క్లోన్‌ను అమలు చేస్తుంది<T>T క్లోన్ అయినప్పుడు.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## నేను `Clone` ను ఎలా అమలు చేయగలను?
///
/// [`Copy`] రకాలు `Clone` యొక్క చిన్నవిషయ అమలును కలిగి ఉండాలి.మరింత అధికారికంగా:
/// `T: Copy`, `x: T` మరియు `y: &T` అయితే, `let x = y.clone();` `let x = *y;` కి సమానం.
/// మాన్యువల్ అమలులు ఈ మార్పును సమర్థించడానికి జాగ్రత్తగా ఉండాలి;అయినప్పటికీ, మెమరీ భద్రతను నిర్ధారించడానికి అసురక్షిత కోడ్ దానిపై ఆధారపడకూడదు.
///
/// ఫంక్షన్ పాయింటర్‌ను కలిగి ఉన్న సాధారణ నిర్మాణం దీనికి ఉదాహరణ.ఈ సందర్భంలో, `Clone` అమలు `ఉత్పన్నం 'కాదు, కానీ ఇలా అమలు చేయవచ్చు:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## అదనపు అమలుదారులు
///
/// [implementors listed below][impls] తో పాటు, కింది రకాలు కూడా `Clone` ను అమలు చేస్తాయి:
///
/// * ఫంక్షన్ అంశం రకాలు (అనగా, ప్రతి ఫంక్షన్ కోసం నిర్వచించిన విభిన్న రకాలు)
/// * ఫంక్షన్ పాయింటర్ రకాలు (ఉదా., `fn() -> i32`)
/// * ఐటెమ్ రకం కూడా `Clone` (ఉదా., `[i32; 123456]`) ను అమలు చేస్తే, అన్ని పరిమాణాల కోసం అర్రే రకాలు
/// * ప్రతి భాగం `Clone` (ఉదా., `()`, `(i32, bool)`) ను అమలు చేస్తే టుపుల్ రకాలు
/// * మూసివేత రకాలు, అవి పర్యావరణం నుండి ఎటువంటి విలువను సంగ్రహించకపోతే లేదా అలాంటి అన్ని సంగ్రహించిన విలువలు `Clone` ను అమలు చేస్తే.
///   షేర్డ్ రిఫరెన్స్ ద్వారా సంగ్రహించబడిన వేరియబుల్స్ ఎల్లప్పుడూ `Clone` ను అమలు చేస్తాయని గమనించండి (రిఫరెన్స్ చేయకపోయినా), అయితే మ్యూటబుల్ రిఫరెన్స్ ద్వారా సంగ్రహించిన వేరియబుల్స్ `Clone` ను ఎప్పుడూ అమలు చేయవు.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// విలువ యొక్క కాపీని అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str క్లోన్ అమలు చేస్తుంది
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source` నుండి కాపీ-అసైన్‌మెంట్‌ను నిర్వహిస్తుంది.
    ///
    /// `a.clone_from(&b)` కార్యాచరణలో `a = b.clone()` కి సమానం, కానీ అనవసరమైన కేటాయింపులను నివారించడానికి `a` యొక్క వనరులను తిరిగి ఉపయోగించటానికి భర్తీ చేయవచ్చు.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone` యొక్క impl ను ఉత్పత్తి చేసే స్థూల ఉత్పన్నం.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ఒక రకంలోని ప్రతి భాగం క్లోన్ లేదా కాపీని అమలు చేస్తుందని నొక్కి చెప్పడానికి ఈ నిర్మాణాలు కేవలం#[ఉత్పన్నం] ద్వారా ఉపయోగించబడతాయి.
//
//
// ఈ నిర్మాణాలు యూజర్ కోడ్‌లో ఎప్పుడూ కనిపించకూడదు.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// ఆదిమ రకాల కోసం `Clone` అమలు.
///
/// Rust లో వివరించలేని అమలులు `rustc_trait_selection` లో `traits::SelectionContext::copy_clone_conditions()` లో అమలు చేయబడతాయి.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// భాగస్వామ్య సూచనలను క్లోన్ చేయవచ్చు, కాని మార్చగల సూచనలు *చేయలేవు*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// భాగస్వామ్య సూచనలను క్లోన్ చేయవచ్చు, కాని మార్చగల సూచనలు *చేయలేవు*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}