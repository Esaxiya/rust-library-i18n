//! శ్రేణుల కోసం `IntoIter` యాజమాన్యంలోని ఇటరేటర్‌ను నిర్వచిస్తుంది.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// ఉప-విలువ [array] ఇరేటర్.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// ఇది మేము పునరావృతం చేస్తున్న శ్రేణి.
    ///
    /// `alive.start <= i < alive.end` ఇండెక్స్ `i` తో ఉన్న అంశాలు ఇంకా `alive.start <= i < alive.end` ఇంకా ఇవ్వబడలేదు మరియు చెల్లుబాటు అయ్యే శ్రేణి ఎంట్రీలు.
    /// `i < alive.start` లేదా `i >= alive.end` సూచికలతో ఉన్న అంశాలు ఇప్పటికే ఇవ్వబడ్డాయి మరియు ఇకపై యాక్సెస్ చేయకూడదు!ఆ చనిపోయిన అంశాలు పూర్తిగా ప్రారంభించని స్థితిలో ఉండవచ్చు!
    ///
    ///
    /// కాబట్టి మార్పులేనివి:
    /// - `data[alive]` సజీవంగా ఉంది (అనగా చెల్లుబాటు అయ్యే అంశాలు ఉన్నాయి)
    /// - `data[..alive.start]` మరియు `data[alive.end..]` చనిపోయాయి (అనగా అంశాలు ఇప్పటికే చదవబడ్డాయి మరియు ఇకపై తాకకూడదు!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data` లోని అంశాలు ఇంకా ఇవ్వబడలేదు.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// ఇచ్చిన `array` పై కొత్త ఇటరేటర్‌ను సృష్టిస్తుంది.
    ///
    /// *గమనిక*: ఈ పద్ధతి [`IntoIterator` is implemented for arrays][array-into-iter] తరువాత, future లో తీసివేయబడుతుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `value` రకం `&i32` కు బదులుగా ఇక్కడ `i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // భద్రత: ఇక్కడ పరివర్తన వాస్తవానికి సురక్షితం.`MaybeUninit` యొక్క డాక్స్
        // promise:
        //
        // > `MaybeUninit<T>` ఒకే పరిమాణం మరియు అమరిక కలిగి ఉంటుందని హామీ ఇవ్వబడింది
        // > `T` గా.
        //
        // డాక్స్ `MaybeUninit<T>` యొక్క శ్రేణి నుండి `T` యొక్క శ్రేణికి పరివర్తనను కూడా చూపిస్తుంది.
        //
        //
        // దానితో, ఈ ప్రారంభించడం మార్పులను సంతృప్తిపరుస్తుంది.

        // FIXME(LukasKalbertodt): వాస్తవానికి ఇక్కడ `mem::transmute` ను వాడండి, ఇది const generics తో పనిచేసిన తర్వాత:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // అప్పటి వరకు, మేము బిట్‌వైస్ కాపీని వేరే రకంగా సృష్టించడానికి `mem::transmute_copy` ను ఉపయోగించవచ్చు, ఆపై `array` ను మరచిపోండి, తద్వారా అది పడిపోదు.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// ఇంకా దిగుబడి ఇవ్వని అన్ని మూలకాల యొక్క మార్పులేని స్లైస్‌ని అందిస్తుంది.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // భద్రత: `alive` లోని అన్ని అంశాలు సరిగ్గా ప్రారంభించబడతాయని మాకు తెలుసు.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// ఇంకా దిగుబడి ఇవ్వని అన్ని మూలకాల యొక్క మార్చగల స్లైస్‌ని అందిస్తుంది.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // భద్రత: `alive` లోని అన్ని అంశాలు సరిగ్గా ప్రారంభించబడతాయని మాకు తెలుసు.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // ముందు నుండి తదుపరి సూచికను పొందండి.
        //
        // `alive.start` ను 1 ద్వారా పెంచడం `alive` కు సంబంధించి మార్పును నిర్వహిస్తుంది.
        // అయితే, ఈ మార్పు కారణంగా, కొద్దికాలం, సజీవ జోన్ ఇకపై `data[alive]` కాదు, కానీ `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // శ్రేణి నుండి మూలకాన్ని చదవండి.
            // భద్రత: `idx` అనేది పూర్వపు "alive" ప్రాంతానికి సూచిక
            // అమరిక.ఈ మూలకాన్ని చదవడం అంటే `data[idx]` ఇప్పుడు చనిపోయినట్లుగా పరిగణించబడుతుంది (అంటే తాకవద్దు).
            // `idx` సజీవ-జోన్ యొక్క ప్రారంభం కావడంతో, సజీవ జోన్ ఇప్పుడు మళ్ళీ `data[alive]` గా ఉంది, అన్ని మార్పులను పునరుద్ధరిస్తుంది.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // తదుపరి సూచికను వెనుక నుండి పొందండి.
        //
        // `alive.end` ను 1 ద్వారా తగ్గించడం `alive` కు సంబంధించి మార్పును నిర్వహిస్తుంది.
        // అయితే, ఈ మార్పు కారణంగా, కొద్దికాలం, సజీవ జోన్ ఇకపై `data[alive]` కాదు, కానీ `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // శ్రేణి నుండి మూలకాన్ని చదవండి.
            // భద్రత: `idx` అనేది పూర్వపు "alive" ప్రాంతానికి సూచిక
            // అమరిక.ఈ మూలకాన్ని చదవడం అంటే `data[idx]` ఇప్పుడు చనిపోయినట్లుగా పరిగణించబడుతుంది (అంటే తాకవద్దు).
            // `idx` సజీవ-జోన్ యొక్క ముగింపు కాబట్టి, సజీవ జోన్ ఇప్పుడు మళ్ళీ `data[alive]` గా ఉంది, అన్ని మార్పులను పునరుద్ధరిస్తుంది.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // భద్రత: ఇది సురక్షితం: `as_mut_slice` సరిగ్గా ఉప-స్లైస్‌ని అందిస్తుంది
        // ఇంకా తరలించబడని మరియు వదిలివేయబడని మూలకాల.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // మార్పులేని `సజీవంగా ఉన్నందున ఎప్పటికీ ప్రవహించదు. స్టార్ట్ <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// మళ్ళి సరైన పొడవును నివేదిస్తుంది.
// "alive" మూలకాల సంఖ్య (అది ఇప్పటికీ ఇవ్వబడుతుంది) `alive` పరిధి యొక్క పొడవు.
// ఈ పరిధి `next` లేదా `next_back` లో పొడవులో తగ్గుతుంది.
// ఇది ఎల్లప్పుడూ ఆ పద్ధతుల్లో 1 తగ్గుతుంది, కానీ `Some(_)` తిరిగి ఇస్తేనే.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // గమనిక, మేము నిజంగా అదే సజీవ పరిధితో సరిపోలవలసిన అవసరం లేదు, కాబట్టి `self` ఎక్కడ ఉన్నా మేము ఆఫ్‌సెట్ 0 లోకి క్లోన్ చేయవచ్చు.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // అన్ని సజీవ మూలకాలను క్లోన్ చేయండి.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // క్రొత్త శ్రేణిలో క్లోన్ వ్రాసి, ఆపై దాని సజీవ పరిధిని నవీకరించండి.
            // panics క్లోనింగ్ చేస్తే, మేము మునుపటి అంశాలను సరిగ్గా వదులుతాము.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ఇంకా దిగుబడి ఇవ్వని మూలకాలను మాత్రమే ముద్రించండి: దిగుబడినిచ్చిన మూలకాలను మేము ఇకపై యాక్సెస్ చేయలేము.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}