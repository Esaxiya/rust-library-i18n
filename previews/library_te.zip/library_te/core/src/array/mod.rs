//! స్థిర-పొడవు శ్రేణుల కోసం `Eq` వంటి వాటి యొక్క నిర్దిష్ట పొడవు వరకు అమలు.
//! చివరికి, మేము అన్ని పొడవులకు సాధారణీకరించగలగాలి.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T` కు సూచనను పొడవు 1 శ్రేణికి సూచనగా మారుస్తుంది (కాపీ చేయకుండా).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // భద్రత: `&T` ను `&[T; 1]` గా మార్చడం ధ్వని.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// `T` కు మార్చగల సూచనను పొడవు 1 యొక్క శ్రేణికి (కాపీ చేయకుండా) మార్చగల సూచనగా మారుస్తుంది.
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // భద్రత: `&mut T` ను `&mut [T; 1]` గా మార్చడం ధ్వని.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// యుటిలిటీ trait స్థిర పరిమాణం యొక్క శ్రేణులపై మాత్రమే అమలు చేయబడుతుంది
///
/// ఈ trait చాలా మెటాడేటా ఉబ్బరం కలిగించకుండా స్థిర-పరిమాణ శ్రేణులపై ఇతర traits ను అమలు చేయడానికి ఉపయోగించవచ్చు.
///
/// స్థిర-పరిమాణ శ్రేణులకు అమలు చేసేవారిని పరిమితం చేయడానికి trait సురక్షితం కాదు.
/// ఈ trait యొక్క వినియోగదారు స్థిర పరిమాణ శ్రేణి యొక్క జ్ఞాపకార్థం అమలు చేసేవారికి ఖచ్చితమైన లేఅవుట్ ఉందని అనుకోవచ్చు (ఉదాహరణకు, అసురక్షిత ప్రారంభానికి).
///
///
/// traits [`AsRef`] మరియు [`AsMut`] స్థిర-పరిమాణ శ్రేణుల లేని రకానికి సారూప్య పద్ధతులను అందిస్తాయని గమనించండి.
/// అమలు చేసేవారు బదులుగా ఆ traits ను ఇష్టపడాలి.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// శ్రేణిని మార్పులేని స్లైస్‌గా మారుస్తుంది
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// శ్రేణిని మార్చగల స్లైస్‌గా మారుస్తుంది
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// స్లైస్ నుండి శ్రేణికి మార్పిడి విఫలమైనప్పుడు లోపం రకం తిరిగి వచ్చింది.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // భద్రత: సరే, ఎందుకంటే పొడవు సరిపోతుందో లేదో మేము తనిఖీ చేసాము
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // భద్రత: సరే, ఎందుకంటే పొడవు సరిపోతుందో లేదో మేము తనిఖీ చేసాము
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: కోడ్ ఉబ్బరాన్ని తగ్గించడానికి కొన్ని తక్కువ ముఖ్యమైన ఇంప్ల్స్ తొలగించబడ్డాయి
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// శ్రేణుల [lexicographically](Ord#lexicographical-comparison) పోలికను అమలు చేస్తుంది.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// `[T; 0]` కి డిఫాల్ట్ అమలు చేయవలసిన అవసరం లేదు, మరియు వేర్వేరు సంఖ్యల కోసం వేర్వేరు ఇంప్ల్ బ్లాక్‌లను కలిగి ఉండటం ఇంకా మద్దతు ఇవ్వనందున డిఫాల్ట్ ఇంప్ల్స్‌ను కాన్స్ట్ జెనెరిక్స్‌తో చేయలేము.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// `self` వలె అదే పరిమాణంలో ఉన్న శ్రేణిని అందిస్తుంది, ఫంక్షన్ `f` ప్రతి మూలకానికి క్రమంలో వర్తించబడుతుంది.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // భద్రత: ఈ ఇరేటర్ ఖచ్చితంగా `N` ను ఇస్తుందని మాకు తెలుసు
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// ఒకే శ్రేణి జతలలో రెండు శ్రేణులను 'జిప్స్ అప్' చేయండి.
    ///
    /// `zip()` క్రొత్త మూలకాన్ని తిరిగి ఇస్తుంది, ఇక్కడ ప్రతి మూలకం మొదటి శ్రేణి నుండి మొదటి మూలకం వస్తుంది, మరియు రెండవ మూలకం రెండవ శ్రేణి నుండి వస్తుంది.
    ///
    /// మరో మాటలో చెప్పాలంటే, ఇది రెండు శ్రేణులను ఒకదానితో ఒకటి జిప్ చేస్తుంది.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // భద్రత: ఈ ఇరేటర్ ఖచ్చితంగా `N` ను ఇస్తుందని మాకు తెలుసు
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// మొత్తం శ్రేణిని కలిగి ఉన్న స్లైస్‌ని అందిస్తుంది.`&s[..]` కి సమానం.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// మొత్తం శ్రేణిని కలిగి ఉన్న మ్యూటబుల్ స్లైస్‌ని అందిస్తుంది.
    /// `&mut s[..]` కి సమానం.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// ప్రతి మూలకాన్ని రుణం తీసుకుంటుంది మరియు `self` వలె అదే పరిమాణంతో సూచనల శ్రేణిని అందిస్తుంది.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// [`map`](#method.map) వంటి ఇతర పద్ధతులతో కలిపి ఉంటే ఈ పద్ధతి ముఖ్యంగా ఉపయోగపడుతుంది.
    /// ఈ విధంగా, అసలు మూలకాలు దాని మూలకాలు `Copy` కాకపోతే మీరు దానిని తరలించలేరు.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // మేము ఇప్పటికీ అసలు శ్రేణిని యాక్సెస్ చేయవచ్చు: ఇది తరలించబడలేదు.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // భద్రత: ఈ ఇరేటర్ ఖచ్చితంగా `N` ను ఇస్తుందని మాకు తెలుసు
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// ప్రతి మూలకాన్ని పరస్పరం రుణం తీసుకుంటుంది మరియు `self` వలె అదే పరిమాణంతో మార్చగల సూచనల శ్రేణిని అందిస్తుంది.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // భద్రత: ఈ ఇరేటర్ ఖచ్చితంగా `N` ను ఇస్తుందని మాకు తెలుసు
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `iter` నుండి `N` అంశాలను లాగి వాటిని శ్రేణిగా తిరిగి ఇస్తుంది.
/// ఇరేటర్ `N` అంశాల కంటే తక్కువ దిగుబడిని ఇస్తే, ఈ ఫంక్షన్ నిర్వచించబడని ప్రవర్తనను ప్రదర్శిస్తుంది.
///
///
/// మరింత సమాచారం కోసం [`collect_into_array`] చూడండి.
///
/// # Safety
///
/// `iter` కనీసం `N` వస్తువులను ఇస్తుందని హామీ ఇవ్వడం కాలర్ వరకు ఉంది.
/// ఈ పరిస్థితిని ఉల్లంఘించడం వలన నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: ఇక్కడ `TrustedLen` కొంతవరకు ఒక ప్రయోగం.ఇది కేవలం ఒక
    // అంతర్గత ఫంక్షన్, కాబట్టి ఈ కట్టుబడి చెడ్డ ఆలోచనగా మారితే తొలగించడానికి సంకోచించకండి.
    // అలాంటప్పుడు, దిగువ బౌండ్ `debug_assert!` ను కూడా తొలగించాలని గుర్తుంచుకోండి!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // భద్రత: ఫంక్షన్ కాంట్రాక్టు పరిధిలోకి వస్తుంది.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `iter` నుండి `N` అంశాలను లాగి వాటిని శ్రేణిగా తిరిగి ఇస్తుంది.ఇరేటర్ `N` ఐటెమ్‌ల కంటే తక్కువ దిగుబడిని ఇస్తే, `None` తిరిగి ఇవ్వబడుతుంది మరియు ఇప్పటికే దిగుబడి పొందిన అన్ని అంశాలు తొలగించబడతాయి.
///
/// ఇటెరేటర్ మ్యూటబుల్ రిఫరెన్స్‌గా పాస్ చేయబడినందున మరియు ఈ ఫంక్షన్ `next` ను చాలా `N` సార్లు పిలుస్తుంది కాబట్టి, మిగిలిన వస్తువులను తిరిగి పొందడానికి ఇరేటర్‌ను ఇప్పటికీ ఉపయోగించవచ్చు.
///
///
/// `iter.next()` భయపడితే, ఇరేటర్ ద్వారా ఇప్పటికే లభించిన అన్ని వస్తువులు తొలగించబడతాయి.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // భద్రత: ఖాళీ శ్రేణి ఎల్లప్పుడూ నివసించేది మరియు చెల్లుబాటు అయ్యే మార్పులను కలిగి ఉండదు.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // భద్రత: ఈ ముడి ముక్కలో ప్రారంభించిన వస్తువులు మాత్రమే ఉంటాయి.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // భద్రత: `guard.initialized` 0 వద్ద మొదలవుతుంది, దీనిలో ఒకటి పెరుగుతుంది
        // లూప్ మరియు లూప్ N కి చేరుకున్న తర్వాత అది రద్దు చేయబడుతుంది (ఇది `array.len()`).
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // మొత్తం శ్రేణి ప్రారంభించబడిందో లేదో తనిఖీ చేయండి.
        if guard.initialized == N {
            mem::forget(guard);

            // భద్రత: పైన పేర్కొన్న పరిస్థితి అన్ని అంశాలు అని నొక్కి చెబుతుంది
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // `guard.initialized` `N` కి చేరుకునే ముందు ఇరేటర్ అయిపోయినట్లయితే మాత్రమే ఇది చేరుతుంది.
    //
    // `guard` ఇక్కడ పడిపోయిందని గమనించండి, ఇప్పటికే ప్రారంభించిన అన్ని అంశాలను వదిలివేస్తుంది.
    None
}