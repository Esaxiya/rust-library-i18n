#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! కంపైలర్ అంతర్నిర్మిత రకాల లేఅవుట్ కోసం నిర్మాణ నిర్వచనాలను కలిగి ఉంటుంది.
//!
//! ముడి ప్రాతినిధ్యాలను నేరుగా మార్చటానికి వాటిని అసురక్షిత కోడ్‌లో ప్రసారాల లక్ష్యంగా ఉపయోగించవచ్చు.
//!
//!
//! వారి నిర్వచనం ఎల్లప్పుడూ `rustc_middle::ty::layout` లో నిర్వచించిన ABI తో సరిపోలాలి.
//!

/// `&dyn SomeTrait` వంటి trait వస్తువు యొక్క ప్రాతినిధ్యం.
///
/// ఈ స్ట్రక్ట్ `&dyn SomeTrait` మరియు `Box<dyn AnotherTrait>` వంటి రకాలను కలిగి ఉంటుంది.
///
/// `TraitObject` లేఅవుట్‌లను సరిపోల్చడానికి హామీ ఇవ్వబడింది, కానీ ఇది trait వస్తువుల రకం కాదు (ఉదా., ఫీల్డ్‌లు `&dyn SomeTrait` లో నేరుగా ప్రాప్యత చేయబడవు) లేదా ఆ లేఅవుట్‌ను నియంత్రించదు (నిర్వచనాన్ని మార్చడం `&dyn SomeTrait` యొక్క లేఅవుట్‌ను మార్చదు).
///
/// ఇది తక్కువ-స్థాయి వివరాలను మార్చటానికి అవసరమైన అసురక్షిత కోడ్ ద్వారా మాత్రమే రూపొందించబడింది.
///
/// అన్ని trait వస్తువులను సాధారణంగా సూచించడానికి మార్గం లేదు, కాబట్టి ఈ రకమైన విలువలను సృష్టించే ఏకైక మార్గం [`std::mem::transmute`][transmute] వంటి ఫంక్షన్లతో.
/// అదేవిధంగా, `TraitObject` విలువ నుండి నిజమైన trait వస్తువును సృష్టించే ఏకైక మార్గం `transmute` తో ఉంటుంది.
///
/// [transmute]: crate::intrinsics::transmute
///
/// సరిపోలని రకములతో trait వస్తువును సింథసైజ్ చేయడం-డేటా పాయింటర్ పాయింట్ల విలువ యొక్క రకానికి vtable సరిపోలడం లేదు-నిర్వచించబడని ప్రవర్తనకు దారితీసే అవకాశం ఉంది.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ఒక ఉదాహరణ trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // కంపైలర్ ఒక trait వస్తువును తయారు చేయనివ్వండి
/// let object: &dyn Foo = &value;
///
/// // ముడి ప్రాతినిధ్యం చూడండి
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // డేటా పాయింటర్ `value` యొక్క చిరునామా
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // `object` నుండి `i32` vtable ను ఉపయోగించడంలో జాగ్రత్తగా ఉండడం ద్వారా, వేరే `i32` ను సూచిస్తూ క్రొత్త వస్తువును నిర్మించండి
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // మేము `other_value` నుండి నేరుగా trait వస్తువును నిర్మించినట్లే పని చేయాలి
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}