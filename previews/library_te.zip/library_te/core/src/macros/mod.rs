#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // కాలర్ యొక్క ఎడిషన్‌ను బట్టి `$crate::panic::panic_2015` లేదా `$crate::panic::panic_2021` కు విస్తరిస్తుంది.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// రెండు వ్యక్తీకరణలు ఒకదానికొకటి సమానమని ([`PartialEq`] ఉపయోగించి) నొక్కి చెబుతుంది.
///
/// panic లో, ఈ స్థూల వ్యక్తీకరణల విలువలను వాటి డీబగ్ ప్రాతినిధ్యాలతో ముద్రిస్తుంది.
///
///
/// [`assert!`] మాదిరిగా, ఈ స్థూలానికి రెండవ రూపం ఉంది, ఇక్కడ అనుకూల panic సందేశాన్ని అందించవచ్చు.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // క్రింద ఉన్న రెబ్రోలు ఉద్దేశపూర్వకంగా ఉంటాయి.
                    // అవి లేకుండా, విలువలను పోల్చడానికి ముందే రుణం కోసం స్టాక్ స్లాట్ ప్రారంభించబడుతుంది, ఇది గుర్తించదగిన మందగింపుకు దారితీస్తుంది.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // క్రింద ఉన్న రెబ్రోలు ఉద్దేశపూర్వకంగా ఉంటాయి.
                    // అవి లేకుండా, విలువలను పోల్చడానికి ముందే రుణం కోసం స్టాక్ స్లాట్ ప్రారంభించబడుతుంది, ఇది గుర్తించదగిన మందగింపుకు దారితీస్తుంది.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// రెండు వ్యక్తీకరణలు ఒకదానికొకటి సమానం కాదని పేర్కొంది ([`PartialEq`] ఉపయోగించి).
///
/// panic లో, ఈ స్థూల వ్యక్తీకరణల విలువలను వాటి డీబగ్ ప్రాతినిధ్యాలతో ముద్రిస్తుంది.
///
///
/// [`assert!`] మాదిరిగా, ఈ స్థూలానికి రెండవ రూపం ఉంది, ఇక్కడ అనుకూల panic సందేశాన్ని అందించవచ్చు.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // క్రింద ఉన్న రెబ్రోలు ఉద్దేశపూర్వకంగా ఉంటాయి.
                    // అవి లేకుండా, విలువలను పోల్చడానికి ముందే రుణం కోసం స్టాక్ స్లాట్ ప్రారంభించబడుతుంది, ఇది గుర్తించదగిన మందగింపుకు దారితీస్తుంది.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // క్రింద ఉన్న రెబ్రోలు ఉద్దేశపూర్వకంగా ఉంటాయి.
                    // అవి లేకుండా, విలువలను పోల్చడానికి ముందే రుణం కోసం స్టాక్ స్లాట్ ప్రారంభించబడుతుంది, ఇది గుర్తించదగిన మందగింపుకు దారితీస్తుంది.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// రన్‌టైమ్‌లో బూలియన్ వ్యక్తీకరణ `true` అని నొక్కి చెబుతుంది.
///
/// అందించిన వ్యక్తీకరణను రన్‌టైమ్‌లో `true` కు అంచనా వేయలేకపోతే ఇది [`panic!`] స్థూలతను ప్రారంభిస్తుంది.
///
/// [`assert!`] వలె, ఈ స్థూలానికి రెండవ సంస్కరణ కూడా ఉంది, ఇక్కడ అనుకూల panic సందేశాన్ని అందించవచ్చు.
///
/// # Uses
///
/// [`assert!`] కాకుండా, `debug_assert!` స్టేట్‌మెంట్‌లు అప్రమేయంగా ఆప్టిమైజ్ కాని నిర్మాణాలలో మాత్రమే ప్రారంభించబడతాయి.
/// కంపైలర్‌కు `-C debug-assertions` పాస్ చేయకపోతే ఆప్టిమైజ్డ్ బిల్డ్ `debug_assert!` స్టేట్‌మెంట్‌లను అమలు చేయదు.
/// ఇది విడుదల నిర్మాణంలో ఉండటానికి చాలా ఖరీదైన చెక్కులకు `debug_assert!` ఉపయోగపడుతుంది కాని అభివృద్ధి సమయంలో సహాయపడుతుంది.
/// `debug_assert!` ను విస్తరించే ఫలితం ఎల్లప్పుడూ టైప్ చెక్ చేయబడింది.
///
/// తనిఖీ చేయని వాదన అస్థిరమైన స్థితిలో ఉన్న ప్రోగ్రామ్‌ను అమలులో ఉంచడానికి అనుమతిస్తుంది, ఇది unexpected హించని పరిణామాలను కలిగి ఉంటుంది, అయితే ఇది సురక్షిత కోడ్‌లో మాత్రమే జరిగేంతవరకు అసురక్షితతను పరిచయం చేయదు.
///
/// అయితే, వాదనల పనితీరు వ్యయం సాధారణంగా కొలవబడదు.
/// [`assert!`] ను `debug_assert!` తో మార్చడం పూర్తి ప్రొఫైలింగ్ తర్వాత మాత్రమే ప్రోత్సహించబడుతుంది మరియు మరీ ముఖ్యంగా సురక్షితమైన కోడ్‌లో మాత్రమే!
///
/// # Examples
///
/// ```
/// // ఈ వాదనలకు panic సందేశం ఇచ్చిన వ్యక్తీకరణ యొక్క కఠినమైన విలువ.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // చాలా సులభమైన ఫంక్షన్
/// debug_assert!(some_expensive_computation());
///
/// // అనుకూల సందేశంతో నొక్కి చెప్పండి
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// రెండు వ్యక్తీకరణలు ఒకదానికొకటి సమానమని నొక్కి చెబుతుంది.
///
/// panic లో, ఈ స్థూల వ్యక్తీకరణల విలువలను వాటి డీబగ్ ప్రాతినిధ్యాలతో ముద్రిస్తుంది.
///
/// [`assert_eq!`] కాకుండా, `debug_assert_eq!` స్టేట్‌మెంట్‌లు అప్రమేయంగా ఆప్టిమైజ్ కాని నిర్మాణాలలో మాత్రమే ప్రారంభించబడతాయి.
/// కంపైలర్‌కు `-C debug-assertions` పాస్ చేయకపోతే ఆప్టిమైజ్డ్ బిల్డ్ `debug_assert_eq!` స్టేట్‌మెంట్‌లను అమలు చేయదు.
/// ఇది విడుదల నిర్మాణంలో ఉండటానికి చాలా ఖరీదైన చెక్కులకు `debug_assert_eq!` ఉపయోగపడుతుంది కాని అభివృద్ధి సమయంలో సహాయపడుతుంది.
///
/// `debug_assert_eq!` ను విస్తరించే ఫలితం ఎల్లప్పుడూ టైప్ చెక్ చేయబడింది.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// రెండు వ్యక్తీకరణలు ఒకదానికొకటి సమానం కాదని నొక్కి చెబుతుంది.
///
/// panic లో, ఈ స్థూల వ్యక్తీకరణల విలువలను వాటి డీబగ్ ప్రాతినిధ్యాలతో ముద్రిస్తుంది.
///
/// [`assert_ne!`] కాకుండా, `debug_assert_ne!` స్టేట్‌మెంట్‌లు అప్రమేయంగా ఆప్టిమైజ్ కాని నిర్మాణాలలో మాత్రమే ప్రారంభించబడతాయి.
/// కంపైలర్‌కు `-C debug-assertions` పాస్ చేయకపోతే ఆప్టిమైజ్డ్ బిల్డ్ `debug_assert_ne!` స్టేట్‌మెంట్‌లను అమలు చేయదు.
/// ఇది విడుదల నిర్మాణంలో ఉండటానికి చాలా ఖరీదైన చెక్కులకు `debug_assert_ne!` ఉపయోగపడుతుంది కాని అభివృద్ధి సమయంలో సహాయపడుతుంది.
///
/// `debug_assert_ne!` ను విస్తరించే ఫలితం ఎల్లప్పుడూ టైప్ చెక్ చేయబడింది.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// ఇచ్చిన వ్యక్తీకరణ ఇచ్చిన నమూనాలతో సరిపోతుందో లేదో చూపుతుంది.
///
/// `match` వ్యక్తీకరణలో వలె, నమూనాను ఐచ్ఛికంగా `if` మరియు నమూనాతో కట్టుబడి ఉన్న పేర్లకు ప్రాప్యత కలిగిన గార్డ్ వ్యక్తీకరణను అనుసరించవచ్చు.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// ఫలితాన్ని విప్పండి లేదా దాని లోపాన్ని ప్రచారం చేస్తుంది.
///
/// `try!` స్థానంలో `?` ఆపరేటర్ జోడించబడింది మరియు బదులుగా ఉపయోగించాలి.
/// ఇంకా, `try` అనేది Rust 2018 లో రిజర్వు చేయబడిన పదం, కాబట్టి మీరు దీన్ని తప్పనిసరిగా ఉపయోగించాలంటే, మీరు [raw-identifier syntax][ris] ను ఉపయోగించాల్సి ఉంటుంది: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ఇచ్చిన [`Result`] తో సరిపోలుతుంది.`Ok` వేరియంట్ విషయంలో, వ్యక్తీకరణ చుట్టిన విలువ యొక్క విలువను కలిగి ఉంటుంది.
///
/// `Err` వేరియంట్ విషయంలో, ఇది లోపలి లోపాన్ని తిరిగి పొందుతుంది.`try!` అప్పుడు `From` ఉపయోగించి మార్పిడిని చేస్తుంది.
/// ఇది ప్రత్యేకమైన లోపాలు మరియు మరింత సాధారణమైన వాటి మధ్య స్వయంచాలక మార్పిడిని అందిస్తుంది.
/// ఫలిత లోపం వెంటనే తిరిగి వస్తుంది.
///
/// ప్రారంభ రాబడి కారణంగా, X001 ను తిరిగి ఇచ్చే ఫంక్షన్లలో మాత్రమే `try!` ఉపయోగించబడుతుంది.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // త్వరగా తిరిగి వచ్చే లోపాల యొక్క ఇష్టపడే పద్ధతి
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // శీఘ్రంగా తిరిగి వచ్చే లోపాల యొక్క మునుపటి పద్ధతి
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // ఇది దీనికి సమానం:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// ఆకృతీకరించిన డేటాను బఫర్‌లో వ్రాస్తుంది.
///
/// ఈ స్థూల 'writer', ఫార్మాట్ స్ట్రింగ్ మరియు వాదనల జాబితాను అంగీకరిస్తుంది.
/// పేర్కొన్న ఫార్మాట్ స్ట్రింగ్ ప్రకారం వాదనలు ఫార్మాట్ చేయబడతాయి మరియు ఫలితం రచయితకు పంపబడుతుంది.
/// రచయిత `write_fmt` పద్ధతిలో ఏదైనా విలువ కావచ్చు;సాధారణంగా ఇది [`fmt::Write`] లేదా [`io::Write`] trait యొక్క అమలు నుండి వస్తుంది.
/// మాక్రో `write_fmt` పద్ధతి తిరిగి వచ్చిన దాన్ని తిరిగి ఇస్తుంది;సాధారణంగా [`fmt::Result`], లేదా [`io::Result`].
///
/// ఫార్మాట్ స్ట్రింగ్ సింటాక్స్ గురించి మరింత సమాచారం కోసం [`std::fmt`] చూడండి.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// మాడ్యూల్ `std::fmt::Write` మరియు `std::io::Write` రెండింటినీ దిగుమతి చేసుకోవచ్చు మరియు వస్తువులు రెండింటినీ అమలు చేయనందున, అమలు చేసే వస్తువులపై `write!` కి కాల్ చేయవచ్చు.
///
/// అయినప్పటికీ, మాడ్యూల్ తప్పనిసరిగా traits అర్హతను దిగుమతి చేసుకోవాలి కాబట్టి వారి పేర్లు విభేదించవు:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt ఉపయోగిస్తుంది
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt ఉపయోగిస్తుంది
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: ఈ స్థూలతను `no_std` సెటప్‌లలో కూడా ఉపయోగించవచ్చు.
/// `no_std` సెటప్‌లో మీరు భాగాల అమలు వివరాలకు బాధ్యత వహిస్తారు.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// ఫార్మాట్ చేసిన డేటాను బఫర్‌లో వ్రాసి, కొత్త లైన్ జోడించబడింది.
///
/// అన్ని ప్లాట్‌ఫామ్‌లలో, క్రొత్త లైన్ LINE FEED అక్షరం (`\n`/`U+000A`) మాత్రమే (అదనపు CARRIAGE RETURN (`\r`/`U+000D`) లేదు.
///
/// మరింత సమాచారం కోసం, [`write!`] చూడండి.ఫార్మాట్ స్ట్రింగ్ సింటాక్స్ సమాచారం కోసం, [`std::fmt`] చూడండి.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// మాడ్యూల్ `std::fmt::Write` మరియు `std::io::Write` రెండింటినీ దిగుమతి చేసుకోవచ్చు మరియు వస్తువులు రెండింటినీ అమలు చేయనందున, అమలు చేసే వస్తువులపై `write!` కి కాల్ చేయవచ్చు.
/// అయినప్పటికీ, మాడ్యూల్ తప్పనిసరిగా traits అర్హతను దిగుమతి చేసుకోవాలి కాబట్టి వారి పేర్లు విభేదించవు:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt ఉపయోగిస్తుంది
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt ఉపయోగిస్తుంది
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// చేరుకోలేని కోడ్‌ను సూచిస్తుంది.
///
/// కొన్ని కోడ్‌ను చేరుకోలేమని కంపైలర్ నిర్ణయించలేని ఎప్పుడైనా ఇది ఉపయోగపడుతుంది.ఉదాహరణకి:
///
/// * గార్డు పరిస్థితులతో ఆయుధాలను సరిపోల్చండి.
/// * డైనమిక్‌గా ముగించే ఉచ్చులు.
/// * డైనమిక్‌గా ముగించే ఇటరేటర్లు.
///
/// కోడ్ చేరుకోలేదనే నిర్ణయం తప్పు అని నిరూపిస్తే, ప్రోగ్రామ్ వెంటనే [`panic!`] తో ముగుస్తుంది.
///
/// ఈ స్థూల యొక్క అసురక్షిత ప్రతిరూపం [`unreachable_unchecked`] ఫంక్షన్, ఇది కోడ్ చేరుకున్నట్లయితే నిర్వచించబడని ప్రవర్తనకు కారణమవుతుంది.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// ఇది ఎల్లప్పుడూ [`panic!`] అవుతుంది.
///
/// # Examples
///
/// మ్యాచ్ ఆయుధాలు:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // వ్యాఖ్యానించినట్లయితే కంపైల్ లోపం
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3 యొక్క పేద అమలులలో ఒకటి
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" సందేశంతో భయపడటం ద్వారా అమలు చేయని కోడ్‌ను సూచిస్తుంది.
///
/// ఇది మీ కోడ్‌ను టైప్-చెక్ చేయడానికి అనుమతిస్తుంది, మీరు trait ను ప్రోటోటైప్ చేస్తుంటే లేదా అమలు చేస్తుంటే ఇది ఉపయోగపడుతుంది, దీనికి మీరు అన్నింటినీ ఉపయోగించాలని ప్లాన్ చేయని బహుళ పద్ధతులు అవసరం.
///
/// `unimplemented!` మరియు [`todo!`] మధ్య వ్యత్యాసం ఏమిటంటే, `todo!` తరువాత కార్యాచరణను అమలు చేయాలనే ఉద్దేశ్యాన్ని తెలియజేస్తుంది మరియు సందేశం "not yet implemented" అయితే, `unimplemented!` అటువంటి వాదనలు ఇవ్వదు.
/// దీని సందేశం "not implemented".
/// కొన్ని IDE లు `టోడో! 'అని గుర్తు చేస్తాయి.
///
/// # Panics
///
/// ఇది ఎల్లప్పుడూ [`panic!`] అవుతుంది ఎందుకంటే `unimplemented!` అనేది స్థిరమైన, నిర్దిష్ట సందేశంతో `panic!` కోసం సంక్షిప్తలిపి.
///
/// `panic!` వలె, ఈ స్థూల అనుకూల విలువలను ప్రదర్శించడానికి రెండవ రూపాన్ని కలిగి ఉంది.
///
/// # Examples
///
/// మాకు trait `Foo` ఉందని చెప్పండి:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// మేము 'MyStruct' కోసం `Foo` ను అమలు చేయాలనుకుంటున్నాము, కానీ కొన్ని కారణాల వలన ఇది `bar()` ఫంక్షన్‌ను అమలు చేయడానికి మాత్రమే అర్ధమే.
/// `baz()` మరియు `Foo` యొక్క మా అమలులో `qux()` ఇంకా నిర్వచించాల్సిన అవసరం ఉంది, కాని మన కోడ్‌ను కంపైల్ చేయడానికి అనుమతించడానికి మేము `unimplemented!` ను వాటి నిర్వచనాలలో ఉపయోగించవచ్చు.
///
/// అమలు చేయని పద్ధతులు చేరుకున్నట్లయితే మా ప్రోగ్రామ్ రన్ అవ్వాలని మేము ఇంకా కోరుకుంటున్నాము.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // ఇది `baz` ఒక `MyStruct` కి అర్ధమే లేదు, కాబట్టి మనకు ఇక్కడ ఎటువంటి తర్కం లేదు.
/////
///         // ఇది "thread 'main' panicked at 'not implemented'" ను ప్రదర్శిస్తుంది.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // మాకు ఇక్కడ కొంత తర్కం ఉంది, మేము అమలు చేయని సందేశాన్ని జోడించవచ్చు!మా మినహాయింపును ప్రదర్శించడానికి.
///         // ఇది ప్రదర్శిస్తుంది: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// అసంపూర్తిగా ఉన్న కోడ్‌ను సూచిస్తుంది.
///
/// మీరు ప్రోటోటైప్ చేస్తుంటే మరియు మీ కోడ్ టైప్ చెక్ కలిగి ఉండాలని చూస్తున్నట్లయితే ఇది ఉపయోగపడుతుంది.
///
/// [`unimplemented!`] మరియు `todo!` మధ్య వ్యత్యాసం ఏమిటంటే, `todo!` తరువాత కార్యాచరణను అమలు చేయాలనే ఉద్దేశ్యాన్ని తెలియజేస్తుంది మరియు సందేశం "not yet implemented" అయితే, `unimplemented!` అటువంటి వాదనలు ఇవ్వదు.
/// దీని సందేశం "not implemented".
/// కొన్ని IDE లు `టోడో! 'అని గుర్తు చేస్తాయి.
///
/// # Panics
///
/// ఇది ఎల్లప్పుడూ [`panic!`] అవుతుంది.
///
/// # Examples
///
/// కొన్ని ప్రోగ్రెస్ కోడ్ యొక్క ఉదాహరణ ఇక్కడ ఉంది.మాకు trait `Foo` ఉంది:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// మేము మా రకాల్లో ఒకదానిపై `Foo` ను అమలు చేయాలనుకుంటున్నాము, కాని మేము మొదట `bar()` లో కూడా పని చేయాలనుకుంటున్నాము.మా కోడ్ కంపైల్ చేయడానికి, మేము `baz()` ను అమలు చేయాలి, కాబట్టి మేము `todo!` ను ఉపయోగించవచ్చు:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // అమలు ఇక్కడకు వెళుతుంది
///     }
///
///     fn baz(&self) {
///         // ప్రస్తుతానికి baz() ను అమలు చేయడం గురించి చింతించకండి
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // మేము baz() ను కూడా ఉపయోగించడం లేదు, కాబట్టి ఇది మంచిది.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// అంతర్నిర్మిత మాక్రోస్ యొక్క నిర్వచనాలు.
///
/// స్థూల లక్షణాలను (స్థిరత్వం, దృశ్యమానత మొదలైనవి) ఇక్కడ సోర్స్ కోడ్ నుండి తీసుకుంటారు, విస్తరణ విధులు మినహా స్థూల ఇన్‌పుట్లను అవుట్‌పుట్‌లుగా మారుస్తాయి, ఆ విధులు కంపైలర్ చేత అందించబడతాయి.
///
///
pub(crate) mod builtin {

    /// ఎదురైనప్పుడు ఇచ్చిన దోష సందేశంతో సంకలనం విఫలం కావడానికి కారణమవుతుంది.
    ///
    /// తప్పుడు పరిస్థితులకు మెరుగైన దోష సందేశాలను అందించడానికి crate షరతులతో కూడిన సంకలన వ్యూహాన్ని ఉపయోగించినప్పుడు ఈ స్థూల వాడాలి.
    ///
    /// ఇది [`panic!`] యొక్క కంపైలర్-స్థాయి రూపం, కానీ *రన్‌టైమ్* వద్ద కాకుండా *సంకలనం* సమయంలో లోపం విడుదల చేస్తుంది.
    ///
    /// # Examples
    ///
    /// అలాంటి రెండు ఉదాహరణలు మాక్రోలు మరియు `#[cfg]` పరిసరాలు.
    ///
    /// స్థూల చెల్లని విలువలను దాటితే మంచి కంపైలర్ లోపాన్ని విడుదల చేయండి.
    /// చివరి branch లేకుండా, కంపైలర్ ఇప్పటికీ లోపాన్ని విడుదల చేస్తుంది, కానీ లోపం యొక్క సందేశం రెండు చెల్లుబాటు అయ్యే విలువలను పేర్కొనదు.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// అనేక లక్షణాలలో ఒకటి అందుబాటులో లేకపోతే కంపైలర్ లోపాన్ని విడుదల చేయండి.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ఇతర స్ట్రింగ్-ఫార్మాటింగ్ మాక్రోల కోసం పారామితులను నిర్మిస్తుంది.
    ///
    /// ఆమోదించిన ప్రతి అదనపు వాదనకు `{}` కలిగిన ఫార్మాటింగ్ స్ట్రింగ్ అక్షరాలా తీసుకోవడం ద్వారా ఈ స్థూల పనితీరు.
    /// `format_args!` అవుట్‌పుట్‌ను స్ట్రింగ్‌గా అర్థం చేసుకోగలరని నిర్ధారించడానికి అదనపు పారామితులను సిద్ధం చేస్తుంది మరియు వాదనలను ఒకే రకంగా కానానికలైజ్ చేస్తుంది.
    /// [`Display`] trait ను అమలు చేసే ఏదైనా విలువ `format_args!` కు పంపబడుతుంది, అదే విధంగా ఏదైనా [`Debug`] అమలును ఫార్మాటింగ్ స్ట్రింగ్‌లోని `{:?}` కి పంపవచ్చు.
    ///
    ///
    /// ఈ స్థూల రకం [`fmt::Arguments`] విలువను ఉత్పత్తి చేస్తుంది.ఉపయోగకరమైన దారి మళ్లింపు కోసం ఈ విలువను [`std::fmt`] లోని మాక్రోలకు పంపవచ్చు.
    /// అన్ని ఇతర ఆకృతీకరణ మాక్రోలు ([`ఫార్మాట్!`], [`write!`], [`println!`], మొదలైనవి) దీని ద్వారా ప్రాక్సీ చేయబడతాయి.
    /// `format_args!`, దాని ఉత్పన్నమైన మాక్రోల మాదిరిగా కాకుండా, కుప్ప కేటాయింపులను నివారిస్తుంది.
    ///
    /// క్రింద చూసినట్లుగా మీరు `Debug` మరియు `Display` సందర్భాలలో `format_args!` తిరిగి ఇచ్చే [`fmt::Arguments`] విలువను ఉపయోగించవచ్చు.
    /// ఉదాహరణ కూడా `Debug` మరియు `Display` ఆకృతిని ఒకే విషయానికి చూపిస్తుంది: `format_args!` లో ఇంటర్పోలేటెడ్ ఫార్మాట్ స్ట్రింగ్.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// మరింత సమాచారం కోసం, [`std::fmt`] లోని డాక్యుమెంటేషన్ చూడండి.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` వలె ఉంటుంది, కానీ చివరికి కొత్త లైన్‌ను జోడిస్తుంది.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// కంపైల్ సమయంలో ఎన్విరాన్మెంట్ వేరియబుల్ ను తనిఖీ చేస్తుంది.
    ///
    /// ఈ స్థూల కంపైల్ సమయంలో పేరు పెట్టబడిన ఎన్విరాన్మెంట్ వేరియబుల్ యొక్క విలువకు విస్తరిస్తుంది, ఇది `&'static str` రకం యొక్క వ్యక్తీకరణను ఇస్తుంది.
    ///
    ///
    /// ఎన్విరాన్మెంట్ వేరియబుల్ నిర్వచించబడకపోతే, అప్పుడు సంకలన లోపం విడుదల అవుతుంది.
    /// కంపైల్ లోపాన్ని విడుదల చేయకుండా, బదులుగా [`option_env!`] స్థూలని ఉపయోగించండి.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// రెండవ పరామితిగా స్ట్రింగ్‌ను పంపడం ద్వారా మీరు దోష సందేశాన్ని అనుకూలీకరించవచ్చు:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// `documentation` ఎన్విరాన్మెంట్ వేరియబుల్ నిర్వచించబడకపోతే, మీరు ఈ క్రింది లోపాన్ని పొందుతారు:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// కంపైల్ సమయంలో ఎన్విరాన్మెంట్ వేరియబుల్ను ఐచ్ఛికంగా తనిఖీ చేస్తుంది.
    ///
    /// కంపైల్ సమయంలో పేరు పెట్టబడిన ఎన్విరాన్మెంట్ వేరియబుల్ ఉంటే, ఇది రకం `Option<&'static str>` యొక్క వ్యక్తీకరణగా విస్తరిస్తుంది, దీని విలువ ఎన్విరాన్మెంట్ వేరియబుల్ విలువ యొక్క `Some`.
    /// ఎన్విరాన్మెంట్ వేరియబుల్ లేకపోతే, ఇది `None` కి విస్తరిస్తుంది.
    /// ఈ రకంపై మరింత సమాచారం కోసం [`Option<T>`][Option] చూడండి.
    ///
    /// ఎన్విరాన్మెంట్ వేరియబుల్ ఉందా లేదా అనేదానితో సంబంధం లేకుండా ఈ స్థూలతను ఉపయోగిస్తున్నప్పుడు కంపైల్ టైమ్ లోపం ఎప్పుడూ విడుదల చేయబడదు.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ఐడెంటిఫైయర్‌లను ఒక ఐడెంటిఫైయర్‌గా కలుస్తుంది.
    ///
    /// ఈ స్థూల కామాతో వేరు చేయబడిన ఐడెంటిఫైయర్‌లను తీసుకుంటుంది మరియు వాటిని అన్నింటినీ ఒకదానితో ఒకటి కలుపుతుంది, ఇది కొత్త ఐడెంటిఫైయర్ అయిన వ్యక్తీకరణను ఇస్తుంది.
    /// ఈ స్థూల స్థానిక వేరియబుల్స్‌ను సంగ్రహించలేని విధంగా పరిశుభ్రత చేస్తుంది.
    /// అలాగే, సాధారణ నియమం ప్రకారం, మాక్రోలు అంశం, ప్రకటన లేదా వ్యక్తీకరణ స్థితిలో మాత్రమే అనుమతించబడతాయి.
    /// అంటే మీరు ఇప్పటికే ఉన్న వేరియబుల్స్, ఫంక్షన్లు లేదా మాడ్యూల్స్ మొదలైనవాటిని సూచించడానికి ఈ స్థూలని ఉపయోగిస్తున్నప్పుడు, మీరు దానితో క్రొత్తదాన్ని నిర్వచించలేరు.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (కొత్త, సరదా, పేరు) { }//ఈ విధంగా ఉపయోగించబడదు!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// అక్షరాస్యతను స్టాటిక్ స్ట్రింగ్ స్లైస్‌గా కలుపుతుంది.
    ///
    /// ఈ స్థూల కామాతో వేరు చేయబడిన అక్షరాస్యుల సంఖ్యను తీసుకుంటుంది, ఇది `&'static str` రకం యొక్క వ్యక్తీకరణను ఇస్తుంది, ఇది ఎడమ నుండి కుడికి అనుసంధానించబడిన అన్ని అక్షరాస్యతలను సూచిస్తుంది.
    ///
    ///
    /// పూర్ణాంకం మరియు తేలియాడే పాయింట్ అక్షరాస్యతలు సంగ్రహించటానికి క్రమబద్ధీకరించబడతాయి.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ఇది ప్రారంభించిన పంక్తి సంఖ్యకు విస్తరిస్తుంది.
    ///
    /// [`column!`] మరియు [`file!`] తో, ఈ మాక్రోలు డెవలపర్‌లకు మూలం లోపల ఉన్న స్థానం గురించి డీబగ్గింగ్ సమాచారాన్ని అందిస్తాయి.
    ///
    /// విస్తరించిన వ్యక్తీకరణ `u32` రకం మరియు 1-ఆధారితమైనది, కాబట్టి ప్రతి ఫైల్‌లోని మొదటి పంక్తి 1 కు, రెండవది 2 నుండి 2 వరకు అంచనా వేస్తుంది.
    /// ఇది సాధారణ కంపైలర్లు లేదా జనాదరణ పొందిన సంపాదకుల దోష సందేశాలకు అనుగుణంగా ఉంటుంది.
    /// తిరిగి వచ్చిన పంక్తి `line!` ఆహ్వానం యొక్క పంక్తి * అవసరం లేదు, కానీ `line!` స్థూల యొక్క ఆహ్వానానికి దారితీసే మొదటి స్థూల ఆహ్వానం.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// ఇది ప్రారంభించిన కాలమ్ సంఖ్యకు విస్తరిస్తుంది.
    ///
    /// [`line!`] మరియు [`file!`] తో, ఈ మాక్రోలు డెవలపర్‌లకు మూలం లోపల ఉన్న స్థానం గురించి డీబగ్గింగ్ సమాచారాన్ని అందిస్తాయి.
    ///
    /// విస్తరించిన వ్యక్తీకరణ `u32` రకం మరియు 1-ఆధారితమైనది, కాబట్టి ప్రతి పంక్తిలోని మొదటి కాలమ్ 1 కు, రెండవది 2 నుండి 2 వరకు అంచనా వేస్తుంది.
    /// ఇది సాధారణ కంపైలర్లు లేదా జనాదరణ పొందిన సంపాదకుల దోష సందేశాలకు అనుగుణంగా ఉంటుంది.
    /// తిరిగి వచ్చిన కాలమ్ `column!` ఇన్వొకేషన్ యొక్క పంక్తి * అవసరం లేదు, కానీ `column!` స్థూల ఆహ్వానానికి దారితీసే మొదటి స్థూల ఆహ్వానం.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// ఇది అమలు చేయబడిన ఫైల్ పేరుకు విస్తరిస్తుంది.
    ///
    /// [`line!`] మరియు [`column!`] తో, ఈ మాక్రోలు డెవలపర్‌లకు మూలం లోపల ఉన్న స్థానం గురించి డీబగ్గింగ్ సమాచారాన్ని అందిస్తాయి.
    ///
    /// విస్తరించిన వ్యక్తీకరణకు `&'static str` రకం ఉంది, మరియు తిరిగి వచ్చిన ఫైల్ `file!` స్థూల యొక్క ఆహ్వానం కాదు, కానీ `file!` స్థూల యొక్క ఆహ్వానానికి దారితీసే మొదటి స్థూల ఆహ్వానం.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// దాని వాదనలను కఠినతరం చేస్తుంది.
    ///
    /// ఈ స్థూల రకం `&'static str` యొక్క వ్యక్తీకరణను ఇస్తుంది, ఇది స్థూలానికి పంపిన అన్ని tokens యొక్క స్ట్రిఫికేషన్.
    /// స్థూల ఆహ్వానం యొక్క వాక్యనిర్మాణంపై ఎటువంటి పరిమితులు ఉంచబడవు.
    ///
    /// tokens ఇన్పుట్ యొక్క విస్తరించిన ఫలితాలు future లో మారవచ్చని గమనించండి.మీరు అవుట్పుట్ మీద ఆధారపడినట్లయితే మీరు జాగ్రత్తగా ఉండాలి.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// UTF-8 ఎన్కోడ్ చేసిన ఫైల్‌ను స్ట్రింగ్‌గా కలిగి ఉంటుంది.
    ///
    /// ఫైల్ ప్రస్తుత ఫైల్‌కు సంబంధించి ఉంది (మాడ్యూల్స్ ఎలా దొరుకుతాయో అదేవిధంగా).
    /// అందించిన మార్గం కంపైల్ సమయంలో ప్లాట్‌ఫాం-నిర్దిష్ట మార్గంలో వివరించబడుతుంది.
    /// కాబట్టి, ఉదాహరణకు, Windows బ్యాక్‌స్లాష్‌లను కలిగి ఉన్న Windows మార్గంతో ఒక ఆహ్వానం Unix లో సరిగ్గా కంపైల్ చేయదు.
    ///
    ///
    /// ఈ స్థూల ఫైలు యొక్క కంటెంట్ అయిన `&'static str` రకం యొక్క వ్యక్తీకరణను ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// కింది విషయాలతో ఒకే డైరెక్టరీలో రెండు ఫైళ్లు ఉన్నాయని అనుకోండి:
    ///
    /// ఫైల్ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ఫైల్ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' ను కంపైల్ చేసి, ఫలిత బైనరీని అమలు చేస్తే "adiós" ముద్రించబడుతుంది.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// బైట్ శ్రేణికి సూచనగా ఫైల్‌ను కలిగి ఉంటుంది.
    ///
    /// ఫైల్ ప్రస్తుత ఫైల్‌కు సంబంధించి ఉంది (మాడ్యూల్స్ ఎలా దొరుకుతాయో అదేవిధంగా).
    /// అందించిన మార్గం కంపైల్ సమయంలో ప్లాట్‌ఫాం-నిర్దిష్ట మార్గంలో వివరించబడుతుంది.
    /// కాబట్టి, ఉదాహరణకు, Windows బ్యాక్‌స్లాష్‌లను కలిగి ఉన్న Windows మార్గంతో ఒక ఆహ్వానం Unix లో సరిగ్గా కంపైల్ చేయదు.
    ///
    ///
    /// ఈ స్థూల ఫైలు యొక్క కంటెంట్ అయిన `&'static [u8; N]` రకం యొక్క వ్యక్తీకరణను ఇస్తుంది.
    ///
    /// # Examples
    ///
    /// కింది విషయాలతో ఒకే డైరెక్టరీలో రెండు ఫైళ్లు ఉన్నాయని అనుకోండి:
    ///
    /// ఫైల్ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ఫైల్ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' ను కంపైల్ చేసి, ఫలిత బైనరీని అమలు చేస్తే "adiós" ముద్రించబడుతుంది.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ప్రస్తుత మాడ్యూల్ మార్గాన్ని సూచించే స్ట్రింగ్‌కు విస్తరిస్తుంది.
    ///
    /// ప్రస్తుత మాడ్యూల్ మార్గం crate root వరకు తిరిగి వెళ్ళే మాడ్యూళ్ల సోపానక్రమం అని భావించవచ్చు.
    /// తిరిగి వచ్చిన మార్గం యొక్క మొదటి భాగం ప్రస్తుతం సంకలనం చేయబడిన crate పేరు.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// కంపైల్ సమయంలో కాన్ఫిగరేషన్ జెండాల బూలియన్ కలయికలను అంచనా వేస్తుంది.
    ///
    /// `#[cfg]` లక్షణంతో పాటు, కాన్ఫిగరేషన్ జెండాల బూలియన్ వ్యక్తీకరణ మూల్యాంకనాన్ని అనుమతించడానికి ఈ స్థూలత అందించబడుతుంది.
    /// ఇది తరచుగా తక్కువ నకిలీ కోడ్‌కు దారితీస్తుంది.
    ///
    /// ఈ స్థూలానికి ఇచ్చిన వాక్యనిర్మాణం [`cfg`] లక్షణం వలె అదే వాక్యనిర్మాణం.
    ///
    /// `cfg!`, `#[cfg]` మాదిరిగా కాకుండా, ఏ కోడ్‌ను తీసివేయదు మరియు ఒప్పు లేదా తప్పు అని మాత్రమే అంచనా వేస్తుంది.
    /// ఉదాహరణకు, `cfg!` మూల్యాంకనం చేస్తున్నదానితో సంబంధం లేకుండా, if/else వ్యక్తీకరణలోని అన్ని బ్లాక్‌లు షరతు కోసం `cfg!` ఉపయోగించినప్పుడు చెల్లుబాటు కావాలి.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// సందర్భాన్ని బట్టి ఫైల్‌ను వ్యక్తీకరణగా లేదా అంశంగా అన్వయించడం.
    ///
    /// ఫైల్ ప్రస్తుత ఫైల్‌కు సంబంధించి ఉంది (మాడ్యూల్స్ ఎలా దొరుకుతాయో అదేవిధంగా).అందించిన మార్గం కంపైల్ సమయంలో ప్లాట్‌ఫాం-నిర్దిష్ట మార్గంలో వివరించబడుతుంది.
    /// కాబట్టి, ఉదాహరణకు, Windows బ్యాక్‌స్లాష్‌లను కలిగి ఉన్న Windows మార్గంతో ఒక ఆహ్వానం Unix లో సరిగ్గా కంపైల్ చేయదు.
    ///
    /// ఈ స్థూలని ఉపయోగించడం చాలా తరచుగా చెడ్డ ఆలోచన, ఎందుకంటే ఫైల్ వ్యక్తీకరణగా అన్వయించబడితే, అది చుట్టుపక్కల కోడ్‌లో అపరిశుభ్రంగా ఉంచబడుతుంది.
    /// ప్రస్తుత ఫైల్‌లో ఒకే పేరు ఉన్న వేరియబుల్స్ లేదా ఫంక్షన్‌లు ఉంటే ఫైల్ expected హించిన దాని కంటే వేరియబుల్స్ లేదా ఫంక్షన్లు భిన్నంగా ఉంటాయి.
    ///
    ///
    /// # Examples
    ///
    /// కింది విషయాలతో ఒకే డైరెక్టరీలో రెండు ఫైళ్లు ఉన్నాయని అనుకోండి:
    ///
    /// ఫైల్ 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// ఫైల్ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' కంపైల్ చేసి, ఫలిత బైనరీని అమలు చేస్తే "🙈🙊🙉🙈🙊🙉" ముద్రించబడుతుంది.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// రన్‌టైమ్‌లో బూలియన్ వ్యక్తీకరణ `true` అని నొక్కి చెబుతుంది.
    ///
    /// అందించిన వ్యక్తీకరణను రన్‌టైమ్‌లో `true` కు అంచనా వేయలేకపోతే ఇది [`panic!`] స్థూలతను ప్రారంభిస్తుంది.
    ///
    /// # Uses
    ///
    /// డీబగ్ మరియు రిలీజ్ బిల్డ్స్ రెండింటిలోనూ వాదనలు ఎల్లప్పుడూ తనిఖీ చేయబడతాయి మరియు నిలిపివేయబడవు.
    /// డిఫాల్ట్‌గా విడుదల నిర్మాణాలలో ప్రారంభించబడని వాదనల కోసం [`debug_assert!`] చూడండి.
    ///
    /// రన్-టైమ్ మార్పులను అమలు చేయడానికి అసురక్షిత కోడ్ `assert!` పై ఆధారపడవచ్చు, ఉల్లంఘిస్తే అసురక్షితతకు దారితీస్తుంది.
    ///
    /// `assert!` యొక్క ఇతర ఉపయోగ సందర్భాలలో సురక్షితమైన కోడ్‌లో రన్-టైమ్ మార్పులను పరీక్షించడం మరియు అమలు చేయడం (దీని ఉల్లంఘన అసురక్షితతకు దారితీయదు).
    ///
    ///
    /// # అనుకూల సందేశాలు
    ///
    /// ఈ స్థూలానికి రెండవ రూపం ఉంది, ఇక్కడ అనుకూల panic సందేశాన్ని ఆకృతీకరణ కోసం వాదనలు లేకుండా లేదా లేకుండా అందించవచ్చు.
    /// ఈ ఫారం కోసం సింటాక్స్ కోసం [`std::fmt`] చూడండి.
    /// ఫార్మాట్ ఆర్గ్యుమెంట్లుగా ఉపయోగించబడే వ్యక్తీకరణలు వాదన విఫలమైతే మాత్రమే మూల్యాంకనం చేయబడతాయి.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ఈ వాదనలకు panic సందేశం ఇచ్చిన వ్యక్తీకరణ యొక్క కఠినమైన విలువ.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // చాలా సులభమైన ఫంక్షన్
    ///
    /// assert!(some_computation());
    ///
    /// // అనుకూల సందేశంతో నొక్కి చెప్పండి
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// ఇన్లైన్ అసెంబ్లీ.
    ///
    /// ఉపయోగం కోసం [unstable book] చదవండి.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-శైలి ఇన్లైన్ అసెంబ్లీ.
    ///
    /// ఉపయోగం కోసం [unstable book] చదవండి.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// మాడ్యూల్-స్థాయి ఇన్లైన్ అసెంబ్లీ.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// ప్రింట్లు tokens ను ప్రామాణిక అవుట్‌పుట్‌లోకి పంపించాయి.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ఇతర మాక్రోలను డీబగ్ చేయడానికి ఉపయోగించే ట్రేసింగ్ కార్యాచరణను ప్రారంభిస్తుంది లేదా నిలిపివేస్తుంది.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// ఉత్పన్న మాక్రోలను వర్తింపజేయడానికి ఉపయోగించే లక్షణం స్థూల.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// ఫంక్షన్‌ను యూనిట్ పరీక్షగా మార్చడానికి లక్షణ స్థూలత వర్తించబడుతుంది.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// ఒక ఫంక్షన్‌ను బెంచ్‌మార్క్ పరీక్షగా మార్చడానికి లక్షణ స్థూలత వర్తించబడుతుంది.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]` మరియు `#[bench]` మాక్రోల అమలు వివరాలు.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// గ్లోబల్ కేటాయింపుగా నమోదు చేయడానికి స్టాటిక్కు లక్షణ స్థూలత వర్తించబడుతుంది.
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) కూడా చూడండి.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// ఆమోదించిన మార్గం ప్రాప్యత చేయగలిగితే అది వర్తించే అంశాన్ని ఉంచుతుంది మరియు లేకపోతే దాన్ని తొలగిస్తుంది.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// ఇది వర్తించే కోడ్ శకంలో అన్ని `#[cfg]` మరియు `#[cfg_attr]` లక్షణాలను విస్తరిస్తుంది.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` కంపైలర్ యొక్క అస్థిర అమలు వివరాలు, ఉపయోగించవద్దు.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` కంపైలర్ యొక్క అస్థిర అమలు వివరాలు, ఉపయోగించవద్దు.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}