Panics ప్రస్తుత థ్రెడ్.

ఇది ప్రోగ్రామ్‌ను వెంటనే ముగించడానికి మరియు ప్రోగ్రామ్ యొక్క కాలర్‌కు అభిప్రాయాన్ని అందించడానికి అనుమతిస్తుంది.
`panic!` ప్రోగ్రామ్ తిరిగి పొందలేని స్థితికి చేరుకున్నప్పుడు ఉపయోగించాలి.

ఉదాహరణ కోడ్ మరియు పరీక్షలలో పరిస్థితులను నొక్కి చెప్పడానికి ఈ స్థూల సరైన మార్గం.
`panic!` [`Option`][ounwrap] మరియు [`Result`][runwrap] enums రెండింటి యొక్క `unwrap` పద్ధతిలో దగ్గరగా ముడిపడి ఉంది.
రెండు అమలులు X001 ను [`None`] లేదా [`Err`] వేరియంట్‌లకు సెట్ చేసినప్పుడు పిలుస్తారు.

`panic!()` ను ఉపయోగిస్తున్నప్పుడు మీరు స్ట్రింగ్ పేలోడ్‌ను పేర్కొనవచ్చు, ఇది [`format!`] సింటాక్స్ ఉపయోగించి నిర్మించబడింది.
Panic ను కాలింగ్ Rust థ్రెడ్‌లోకి ఇంజెక్ట్ చేసేటప్పుడు ఆ పేలోడ్ ఉపయోగించబడుతుంది, తద్వారా థ్రెడ్ పూర్తిగా panic కు వస్తుంది.

డిఫాల్ట్ `std` hook యొక్క ప్రవర్తన, అనగా
panic ప్రారంభించిన తర్వాత నేరుగా నడుస్తున్న కోడ్, `panic!()` కాల్ యొక్క file/line/column సమాచారంతో పాటు `stderr` కు సందేశ పేలోడ్‌ను ముద్రించడం.

మీరు [`std::panic::set_hook()`] ఉపయోగించి panic hook ను భర్తీ చేయవచ్చు.
hook లోపల ఒక panic ను `&dyn Any + Send` గా యాక్సెస్ చేయవచ్చు, ఇది సాధారణ `panic!()` ఇన్వొకేషన్ల కోసం `&str` లేదా `String` ను కలిగి ఉంటుంది.
మరొక రకమైన విలువతో panic కు, [`panic_any`] ను ఉపయోగించవచ్చు.

[`Result`] `panic!` స్థూల వాడకం కంటే లోపాల నుండి కోలుకోవడానికి ఎనుమ్ తరచుగా మంచి పరిష్కారం.
బాహ్య వనరుల వంటి తప్పు విలువలను ఉపయోగించి కొనసాగకుండా ఉండటానికి ఈ స్థూల వాడాలి.
లోపం నిర్వహణ గురించి వివరణాత్మక సమాచారం [book] లో కనుగొనబడింది.

సంకలనం సమయంలో లోపాలను పెంచడానికి స్థూల [`compile_error!`] కూడా చూడండి.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# ప్రస్తుత అమలు

ప్రధాన థ్రెడ్ panics అయితే అది మీ అన్ని థ్రెడ్‌లను ముగించి, `101` కోడ్‌తో మీ ప్రోగ్రామ్‌ను ముగుస్తుంది.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





