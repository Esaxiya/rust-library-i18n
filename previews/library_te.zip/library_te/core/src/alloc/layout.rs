use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// ఈ ఫంక్షన్ ఒకే చోట ఉపయోగించబడుతుంది మరియు దాని అమలును ఇన్లైన్ చేయవచ్చు, అలా చేయడానికి మునుపటి ప్రయత్నాలు rustc ని నెమ్మదిగా చేశాయి:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// మెమరీ బ్లాక్ యొక్క లేఅవుట్.
///
/// `Layout` యొక్క ఉదాహరణ మెమరీ యొక్క నిర్దిష్ట లేఅవుట్ను వివరిస్తుంది.
/// కేటాయింపుదారునికి ఇవ్వడానికి మీరు `Layout` ను ఇన్‌పుట్‌గా నిర్మిస్తారు.
///
/// అన్ని లేఅవుట్‌లకు అనుబంధ పరిమాణం మరియు శక్తి యొక్క రెండు అమరిక ఉంటుంది.
///
/// (అన్ని మెమరీ అభ్యర్థనలు సున్నా కాని పరిమాణంలో ఉండాలని `GlobalAlloc` అవసరం అయినప్పటికీ, లేఅవుట్‌లు సున్నా కాని పరిమాణాన్ని కలిగి ఉండటానికి * అవసరం లేదని గమనించండి.
/// ఒక కాలర్ తప్పనిసరిగా ఇలాంటి పరిస్థితులు నెరవేర్చినట్లు నిర్ధారించుకోవాలి, వదులుగా ఉండే అవసరాలతో నిర్దిష్ట కేటాయింపులను ఉపయోగించాలి లేదా మరింత తేలికైన `Allocator` ఇంటర్‌ఫేస్‌ను ఉపయోగించాలి.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // అభ్యర్థించిన మెమరీ బ్లాక్ పరిమాణం, బైట్‌లలో కొలుస్తారు.
    size_: usize,

    // అభ్యర్థించిన మెమరీ బ్లాక్ యొక్క అమరిక, బైట్లలో కొలుస్తారు.
    // ఇది ఎల్లప్పుడూ రెండు-శక్తి అని మేము నిర్ధారిస్తాము, ఎందుకంటే `posix_memalign` వంటి API కి ఇది అవసరం మరియు లేఅవుట్ కన్స్ట్రక్టర్లపై విధించడం సహేతుకమైన అడ్డంకి.
    //
    //
    // (అయితే, మాకు సమానంగా `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) అవసరం లేదు
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// ఇచ్చిన `size` మరియు `align` నుండి `Layout` ను నిర్మిస్తుంది లేదా ఈ క్రింది షరతులు ఏవైనా నెరవేర్చకపోతే `LayoutError` ను తిరిగి ఇస్తుంది:
    ///
    /// * `align` సున్నాగా ఉండకూడదు,
    ///
    /// * `align` రెండు శక్తి ఉండాలి,
    ///
    /// * `size`, `align` యొక్క సమీప గుణకం వరకు గుండ్రంగా ఉన్నప్పుడు, పొంగిపోకూడదు (అనగా, గుండ్రని విలువ `usize::MAX` కన్నా తక్కువ లేదా సమానంగా ఉండాలి).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (పవర్-ఆఫ్-రెండు అమరికను సూచిస్తుంది!=0.)

        // గుండ్రని పరిమాణం:
        //   size_rounded_up=(పరిమాణం + సమలేఖనం, 1)&! (సమలేఖనం, 1);
        //
        // ఆ సమలేఖనం పై నుండి మనకు తెలుసు!=0.
        // జోడిస్తే (సమలేఖనం, 1) పొంగిపోకపోతే, అప్పుడు చుట్టుముట్టడం మంచిది.
        //
        // దీనికి విరుద్ధంగా,&-మాస్కింగ్! (సమలేఖనం, 1) తక్కువ-ఆర్డర్-బిట్‌లను మాత్రమే తీసివేస్తుంది.
        // మొత్తంతో ఓవర్‌ఫ్లో సంభవిస్తే,&-మాస్క్ ఆ ఓవర్‌ఫ్లోను అన్డు చేయడానికి తగినంతగా తీసివేయదు.
        //
        //
        // సమ్మషన్ ఓవర్ఫ్లో కోసం తనిఖీ చేయడం అవసరం మరియు సరిపోతుందని పైన సూచిస్తుంది.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // భద్రత: `from_size_align_unchecked` కోసం పరిస్థితులు ఉన్నాయి
        // పైన తనిఖీ చేయబడింది.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// అన్ని తనిఖీలను దాటవేస్తూ, లేఅవుట్ను సృష్టిస్తుంది.
    ///
    /// # Safety
    ///
    /// [`Layout::from_size_align`] నుండి ముందస్తు షరతులను ధృవీకరించనందున ఈ ఫంక్షన్ సురక్షితం కాదు.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // భద్రత: కాలర్ `align` సున్నా కంటే ఎక్కువగా ఉందని నిర్ధారించుకోవాలి.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// ఈ లేఅవుట్ యొక్క మెమరీ బ్లాక్ కోసం బైట్లలో కనీస పరిమాణం.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// ఈ లేఅవుట్ యొక్క మెమరీ బ్లాక్ కోసం కనీస బైట్ అమరిక.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// రకం `T` విలువను కలిగి ఉండటానికి అనువైన `Layout` ను నిర్మిస్తుంది.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // భద్రత: సమలేఖనం రెండు శక్తిగా Rust చేత హామీ ఇవ్వబడుతుంది
        // పరిమాణం + సమలేఖన కాంబో మా చిరునామా స్థలానికి సరిపోయేలా హామీ ఇవ్వబడింది.
        // ఫలితంగా panics తగినంతగా ఆప్టిమైజ్ చేయకపోతే కోడ్‌ను చొప్పించకుండా ఉండటానికి ఇక్కడ తనిఖీ చేయని కన్స్ట్రక్టర్‌ను ఉపయోగించండి.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` కోసం బ్యాకింగ్ నిర్మాణాన్ని కేటాయించడానికి ఉపయోగించే రికార్డును వివరించే లేఅవుట్ను ఉత్పత్తి చేస్తుంది (ఇది trait లేదా స్లైస్ వంటి ఇతర పరిమాణం లేని రకం కావచ్చు).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // భద్రత: ఇది ఎందుకు అసురక్షిత వేరియంట్‌ను ఉపయోగిస్తుందో `new` లో హేతుబద్ధతను చూడండి
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T` కోసం బ్యాకింగ్ నిర్మాణాన్ని కేటాయించడానికి ఉపయోగించే రికార్డును వివరించే లేఅవుట్ను ఉత్పత్తి చేస్తుంది (ఇది trait లేదా స్లైస్ వంటి ఇతర పరిమాణం లేని రకం కావచ్చు).
    ///
    /// # Safety
    ///
    /// కింది షరతులు ఉంటే ఈ ఫంక్షన్ కాల్ చేయడం మాత్రమే సురక్షితం:
    ///
    /// - `T` `Sized` అయితే, ఈ ఫంక్షన్ కాల్ చేయడానికి ఎల్లప్పుడూ సురక్షితం.
    /// - `T` యొక్క పరిమాణం లేని తోక ఉంటే:
    ///     - ఒక [slice], అప్పుడు స్లైస్ తోక యొక్క పొడవు తప్పనిసరిగా పూర్ణాంకం అయి ఉండాలి మరియు *మొత్తం విలువ*(డైనమిక్ తోక పొడవు + స్థిరంగా పరిమాణ ఉపసర్గ) యొక్క పరిమాణం `isize` లో సరిపోతుంది.
    ///     - ఒక [trait object], అప్పుడు పాయింటర్ యొక్క vtable భాగం తప్పనిసరిగా పరిమాణరహిత సంయోగం ద్వారా పొందిన `T` రకానికి చెల్లుబాటు అయ్యే vtable ని సూచించాలి మరియు *మొత్తం విలువ*(డైనమిక్ తోక పొడవు + స్థిరంగా పరిమాణ ఉపసర్గ) యొక్క పరిమాణం `isize` లో సరిపోతుంది.
    ///
    ///     - (unstable) [extern type], అప్పుడు ఈ ఫంక్షన్ కాల్ చేయడం ఎల్లప్పుడూ సురక్షితం, కానీ బాహ్య రకం యొక్క లేఅవుట్ తెలియకపోవడంతో panic లేదా తప్పు విలువను తిరిగి ఇవ్వవచ్చు.
    ///     ఇది బాహ్య రకం తోకకు సూచనగా [`Layout::for_value`] వలె ఉంటుంది.
    ///     - లేకపోతే, సంప్రదాయబద్ధంగా ఈ ఫంక్షన్‌ను పిలవడానికి అనుమతించబడదు.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // భద్రత: మేము ఈ ఫంక్షన్ల యొక్క అవసరాలను కాలర్‌కు పంపుతాము
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // భద్రత: ఇది ఎందుకు అసురక్షిత వేరియంట్‌ను ఉపయోగిస్తుందో `new` లో హేతుబద్ధతను చూడండి
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `NonNull` ను సృష్టిస్తుంది, కానీ ఈ లేఅవుట్ కోసం బాగా సమలేఖనం చేయబడింది.
    ///
    /// పాయింటర్ విలువ చెల్లుబాటు అయ్యే పాయింటర్‌ను సూచించవచ్చని గమనించండి, అంటే ఇది "not yet initialized" సెంటినెల్ విలువగా ఉపయోగించరాదు.
    /// సోమరితనం కేటాయించే రకాలు కొన్ని ఇతర మార్గాల ద్వారా ప్రారంభాన్ని ట్రాక్ చేయాలి.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // భద్రత: సమలేఖనం సున్నా కానిదని హామీ ఇవ్వబడుతుంది
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self` వలె అదే లేఅవుట్ యొక్క విలువను కలిగి ఉండే రికార్డ్‌ను వివరించే లేఅవుట్‌ను సృష్టిస్తుంది, కానీ అది కూడా అమరిక `align` (బైట్లలో కొలుస్తారు) కు సమలేఖనం చేయబడింది.
    ///
    ///
    /// `self` ఇప్పటికే సూచించిన అమరికకు అనుగుణంగా ఉంటే, అప్పుడు `self` ను తిరిగి ఇస్తుంది.
    ///
    /// తిరిగి వచ్చిన లేఅవుట్‌కు వేరే అమరిక ఉందా అనే దానితో సంబంధం లేకుండా, ఈ పద్ధతి మొత్తం పరిమాణానికి ఎటువంటి పాడింగ్‌ను జోడించదని గమనించండి.
    /// మరో మాటలో చెప్పాలంటే, `K` పరిమాణం 16 కలిగి ఉంటే, `K.align_to(32)`*ఇప్పటికీ* పరిమాణం 16 కలిగి ఉంటుంది.
    ///
    /// `self.size()` మరియు ఇచ్చిన `align` కలయిక [`Layout::from_size_align`] లో జాబితా చేయబడిన షరతులను ఉల్లంఘిస్తే లోపం తిరిగి వస్తుంది.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// కింది చిరునామా `align` (బైట్లలో కొలుస్తారు) ను సంతృప్తిపరుస్తుందని నిర్ధారించడానికి మేము `self` తరువాత చొప్పించాల్సిన పాడింగ్ మొత్తాన్ని అందిస్తుంది.
    ///
    /// ఉదా., `self.size()` 9 అయితే, `self.padding_needed_for(4)` 3 ని తిరిగి ఇస్తుంది, ఎందుకంటే ఇది 4-సమలేఖన చిరునామాను పొందడానికి అవసరమైన పాడింగ్ యొక్క కనీస సంఖ్యల సంఖ్య (సంబంధిత మెమరీ బ్లాక్ 4-సమలేఖన చిరునామాతో మొదలవుతుందని uming హిస్తూ).
    ///
    ///
    /// `align` పవర్-ఆఫ్-టు కాకపోతే ఈ ఫంక్షన్ యొక్క తిరిగి విలువకు అర్థం లేదు.
    ///
    /// తిరిగి ఇచ్చిన విలువ యొక్క యుటిలిటీకి మొత్తం కేటాయించిన మెమరీ బ్లాక్ కోసం `align` ప్రారంభ చిరునామా యొక్క అమరిక కంటే తక్కువ లేదా సమానంగా ఉండాలి.ఈ అడ్డంకిని తీర్చడానికి ఒక మార్గం `align <= self.align()` ని నిర్ధారించడం.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // వృత్తాకార విలువ:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // ఆపై మేము పాడింగ్ వ్యత్యాసాన్ని తిరిగి ఇస్తాము: `len_rounded_up - len`.
        //
        // మేము అంతటా మాడ్యులర్ అంకగణితాన్ని ఉపయోగిస్తాము:
        //
        // 1. align> 0 అని హామీ ఇవ్వబడింది, కాబట్టి సమలేఖనం చేయండి, 1 ఎల్లప్పుడూ చెల్లుతుంది.
        //
        // 2.
        // `len + align - 1` గరిష్టంగా `align - 1` ద్వారా పొంగిపొర్లుతుంది, కాబట్టి `!(align - 1)` తో&-మాస్క్ ఓవర్ఫ్లో విషయంలో, `len_rounded_up` కూడా 0 గా ఉంటుందని నిర్ధారిస్తుంది.
        //
        //    ఆ విధంగా తిరిగి వచ్చిన పాడింగ్, `len` కు జోడించినప్పుడు, 0 దిగుబడిని ఇస్తుంది, ఇది `align` అమరికను చిన్నగా సంతృప్తిపరుస్తుంది.
        //
        // (వాస్తవానికి, పైన పేర్కొన్న పద్ధతిలో పరిమాణం మరియు పాడింగ్ ఓవర్‌ఫ్లో మెమరీ బ్లాక్‌లను కేటాయించే ప్రయత్నాలు కేటాయింపుదారు ఏమైనప్పటికీ లోపం కలిగించేలా చేస్తుంది.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// ఈ లేఅవుట్ యొక్క పరిమాణాన్ని లేఅవుట్ యొక్క అమరిక యొక్క బహుళ వరకు రౌండ్ చేయడం ద్వారా లేఅవుట్ను సృష్టిస్తుంది.
    ///
    ///
    /// ఇది `padding_needed_for` ఫలితాన్ని లేఅవుట్ యొక్క ప్రస్తుత పరిమాణానికి జోడించడానికి సమానం.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // ఇది పొంగిపొర్లుతుంది.లేఅవుట్ యొక్క మార్పు నుండి కోటింగ్:
        // > `size`, `align` యొక్క సమీప గుణకం వరకు గుండ్రంగా ఉన్నప్పుడు,
        // > పొంగిపోకూడదు (అనగా, గుండ్రని విలువ కంటే తక్కువగా ఉండాలి
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self` యొక్క `n` ఉదంతాల రికార్డును వివరించే లేఅవుట్‌ను సృష్టిస్తుంది, ప్రతి సందర్భానికి దాని అభ్యర్థించిన పరిమాణం మరియు అమరిక ఇవ్వబడిందని నిర్ధారించడానికి ప్రతి మధ్య తగిన మొత్తంలో పాడింగ్ ఉంటుంది.
    /// విజయవంతం అయినప్పుడు, `(k, offs)` ను తిరిగి ఇస్తుంది, ఇక్కడ `k` శ్రేణి యొక్క లేఅవుట్ మరియు `offs` అనేది శ్రేణిలోని ప్రతి మూలకం ప్రారంభానికి మధ్య దూరం.
    ///
    /// అంకగణిత ఓవర్ఫ్లో, `LayoutError` ను అందిస్తుంది.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // ఇది పొంగిపొర్లుతుంది.లేఅవుట్ యొక్క మార్పు నుండి కోటింగ్:
        // > `size`, `align` యొక్క సమీప గుణకం వరకు గుండ్రంగా ఉన్నప్పుడు,
        // > పొంగిపోకూడదు (అనగా, గుండ్రని విలువ కంటే తక్కువగా ఉండాలి
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // భద్రత: self.align ఇప్పటికే చెల్లుబాటు అయ్యేది మరియు కేటాయింపు_ పరిమాణం ఉంది
        // ఇప్పటికే మందంగా ఉంది.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `self` కోసం రికార్డ్‌ను వివరించే లేఅవుట్‌ను సృష్టిస్తుంది, `next` తరువాత, `next` సరిగ్గా సమలేఖనం చేయబడిందని నిర్ధారించడానికి అవసరమైన పాడింగ్‌తో సహా, కానీ *వెనుకంజలో ఉన్న పాడింగ్ లేదు*.
    ///
    /// సి ప్రాతినిధ్య లేఅవుట్ `repr(C)` తో సరిపోలడానికి, మీరు అన్ని ఫీల్డ్‌లతో లేఅవుట్‌ను విస్తరించిన తర్వాత `pad_to_align` కి కాల్ చేయాలి.
    /// (డిఫాల్ట్ Rust ప్రాతినిధ్య లేఅవుట్ `repr(Rust)`, as it is unspecified.) తో సరిపోలడానికి మార్గం లేదు
    ///
    /// రెండు భాగాల అమరికను నిర్ధారించడానికి, ఫలిత లేఅవుట్ యొక్క అమరిక `self` మరియు `next` లలో గరిష్టంగా ఉంటుందని గమనించండి.
    ///
    /// `Ok((k, offset))` ను తిరిగి ఇస్తుంది, ఇక్కడ `k` అనేది సంగ్రహించిన రికార్డ్ యొక్క లేఅవుట్ మరియు `offset` అనేది బైట్‌లలో, సంక్షిప్త రికార్డులో పొందుపరిచిన `next` యొక్క ప్రారంభ స్థానం (రికార్డు ఆఫ్‌సెట్ 0 వద్ద ప్రారంభమవుతుందని uming హిస్తూ).
    ///
    ///
    /// అంకగణిత ఓవర్ఫ్లో, `LayoutError` ను అందిస్తుంది.
    ///
    /// # Examples
    ///
    /// `#[repr(C)]` నిర్మాణం యొక్క లేఅవుట్ మరియు దాని ఫీల్డ్‌ల లేఅవుట్ల నుండి ఫీల్డ్‌ల ఆఫ్‌సెట్లను లెక్కించడానికి:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` తో ఖరారు చేయడం గుర్తుంచుకోండి!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // ఇది పనిచేస్తుందని పరీక్షించండి
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// `self` యొక్క `n` ఉదంతాల రికార్డును వివరించే లేఅవుట్ను సృష్టిస్తుంది, ప్రతి సందర్భం మధ్య పాడింగ్ లేకుండా.
    ///
    /// `repeat` మాదిరిగా కాకుండా, `repeat_packed` యొక్క పునరావృత సందర్భాలు సరిగ్గా సమలేఖనం చేయబడతాయని `repeat_packed` హామీ ఇవ్వదు, ఇచ్చిన `self` యొక్క ఉదాహరణ సరిగ్గా సమలేఖనం అయినప్పటికీ.
    /// మరో మాటలో చెప్పాలంటే, శ్రేణిని కేటాయించడానికి `repeat_packed` ద్వారా తిరిగి వచ్చిన లేఅవుట్ ఉపయోగించబడితే, శ్రేణిలోని అన్ని అంశాలు సరిగ్గా సమలేఖనం అవుతాయని హామీ లేదు.
    ///
    /// అంకగణిత ఓవర్ఫ్లో, `LayoutError` ను అందిస్తుంది.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// రెండింటి మధ్య అదనపు పాడింగ్ లేకుండా `self` కోసం రికార్డ్‌ను వివరించే లేఅవుట్‌ను సృష్టిస్తుంది.
    /// పాడింగ్ చేర్చబడనందున, `next` యొక్క అమరిక అసంబద్ధం, మరియు ఫలిత లేఅవుట్‌లో *అస్సలు* చేర్చబడదు.
    ///
    ///
    /// అంకగణిత ఓవర్ఫ్లో, `LayoutError` ను అందిస్తుంది.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// `[T; n]` కోసం రికార్డును వివరించే లేఅవుట్ను సృష్టిస్తుంది.
    ///
    /// అంకగణిత ఓవర్ఫ్లో, `LayoutError` ను అందిస్తుంది.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` లేదా కొన్ని ఇతర `Layout` కన్స్ట్రక్టర్‌కు ఇచ్చిన పారామితులు దాని డాక్యుమెంట్ అడ్డంకులను సంతృప్తిపరచవు.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (trait లోపం యొక్క దిగువ impl కోసం మాకు ఇది అవసరం)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}