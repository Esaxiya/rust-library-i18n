//! మెమరీ కేటాయింపు API లు

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError` లోపం కేటాయింపు వైఫల్యాన్ని సూచిస్తుంది, ఇది వనరుల అలసట వల్ల లేదా ఇచ్చిన కేటాయింపు ఇన్పుట్ ఆర్గ్యుమెంట్‌లను ఈ కేటాయింపుతో కలిపేటప్పుడు ఏదైనా తప్పు కావచ్చు.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (trait లోపం యొక్క దిగువ impl కోసం మాకు ఇది అవసరం)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// `Allocator` యొక్క అమలు [`Layout`][] ద్వారా వివరించిన డేటా యొక్క ఏకపక్ష బ్లాక్‌లను కేటాయించవచ్చు, పెరుగుతుంది, కుదించవచ్చు మరియు డీలోకేట్ చేస్తుంది.
///
/// `Allocator` కేటాయించిన మెమరీకి పాయింటర్లను నవీకరించకుండా, `MyAlloc([u8; N])` వంటి కేటాయింపు కలిగి ఉండడం సాధ్యం కానందున, ZST లు, సూచనలు లేదా స్మార్ట్ పాయింటర్లలో అమలు చేయడానికి రూపొందించబడింది.
///
/// [`GlobalAlloc`][] కాకుండా, `Allocator` లో సున్నా-పరిమాణ కేటాయింపులు అనుమతించబడతాయి.
/// అంతర్లీన కేటాయింపు దీనికి మద్దతు ఇవ్వకపోతే (జెమాలోక్ వంటివి) లేదా శూన్య పాయింటర్‌ను (`libc::malloc` వంటివి) తిరిగి ఇవ్వకపోతే, ఇది అమలు ద్వారా పట్టుబడాలి.
///
/// ### ప్రస్తుతం మెమరీని కేటాయించారు
///
/// కొన్ని పద్ధతులకు ఒక కేటాయింపు ద్వారా మెమరీ బ్లాక్ *ప్రస్తుతం కేటాయించబడాలి*.దీని అర్థం:
///
/// * ఆ మెమరీ బ్లాక్ యొక్క ప్రారంభ చిరునామా గతంలో [`allocate`], [`grow`], లేదా [`shrink`] ద్వారా తిరిగి ఇవ్వబడింది మరియు
///
/// * మెమరీ బ్లాక్ తరువాత డీలోకేట్ చేయబడలేదు, ఇక్కడ బ్లాక్స్ నేరుగా [`deallocate`] కి పంపడం ద్వారా డీలోకేట్ చేయబడతాయి లేదా X002 ను తిరిగి ఇచ్చే [`grow`] లేదా [`shrink`] కు పంపించడం ద్వారా మార్చబడతాయి.
///
/// `grow` లేదా `shrink` `Err` ను తిరిగి ఇస్తే, పాస్ చేసిన పాయింటర్ చెల్లుబాటులో ఉంటుంది.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### మెమరీ ఫిట్టింగ్
///
/// కొన్ని పద్ధతులకు లేఅవుట్ * మెమరీ బ్లాక్‌కు సరిపోతుంది.
/// "fit" కు లేఅవుట్ అంటే మెమరీ బ్లాక్ అంటే (లేదా సమానంగా, మెమరీ బ్లాక్ "fit" కి లేఅవుట్ కోసం) అంటే ఈ క్రింది షరతులు తప్పనిసరిగా ఉండాలి:
///
/// * [`layout.align()`] వలె అదే అమరికతో బ్లాక్‌ను కేటాయించాలి మరియు
///
/// * అందించిన [`layout.size()`] తప్పనిసరిగా `min ..= max` పరిధిలో ఉండాలి, ఇక్కడ:
///   - `min` బ్లాక్‌ను కేటాయించడానికి ఇటీవల ఉపయోగించిన లేఅవుట్ యొక్క పరిమాణం, మరియు
///   - `max` ఇది [`allocate`], [`grow`] లేదా [`shrink`] నుండి తిరిగి వచ్చిన తాజా వాస్తవ పరిమాణం.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * కేటాయింపుదారు నుండి తిరిగి వచ్చిన మెమరీ బ్లాక్‌లు చెల్లుబాటు అయ్యే మెమరీని సూచించాలి మరియు ఉదాహరణ మరియు దాని క్లోన్‌లన్నీ తొలగించబడే వరకు వాటి ప్రామాణికతను నిలుపుకోవాలి,
///
/// * కేటాయింపును క్లోనింగ్ చేయడం లేదా తరలించడం ఈ కేటాయింపు నుండి తిరిగి వచ్చిన మెమరీ బ్లాక్‌లను చెల్లదు.క్లోన్ చేసిన కేటాయింపుదారుడు అదే కేటాయింపుదారుడిలా ప్రవర్తించాలి మరియు
///
/// * [*currently allocated*] అయిన మెమరీ బ్లాక్‌కు ఏదైనా పాయింటర్ కేటాయింపు యొక్క ఇతర పద్ధతులకు పంపబడుతుంది.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// మెమరీ బ్లాక్‌ను కేటాయించే ప్రయత్నం.
    ///
    /// విజయవంతం అయినప్పుడు, `layout` యొక్క పరిమాణం మరియు అమరిక హామీలను కలుసుకునే [`NonNull<[u8]>`][NonNull] ను అందిస్తుంది.
    ///
    /// తిరిగి వచ్చిన బ్లాక్ `layout.size()` పేర్కొన్న దానికంటే పెద్ద పరిమాణాన్ని కలిగి ఉండవచ్చు మరియు దాని విషయాలు ప్రారంభించబడవచ్చు లేదా కలిగి ఉండకపోవచ్చు.
    ///
    /// # Errors
    ///
    /// `Err` ని తిరిగి ఇవ్వడం మెమరీ అయిపోయినట్లు లేదా `layout` కేటాయింపు యొక్క పరిమాణం లేదా అమరిక అడ్డంకులను తీర్చలేదని సూచిస్తుంది.
    ///
    /// భయాందోళనలు లేదా గర్భస్రావం కాకుండా మెమరీ అలసటపై `Err` ను తిరిగి ఇవ్వమని అమలులను ప్రోత్సహిస్తారు, కానీ ఇది కఠినమైన అవసరం కాదు.
    /// (ప్రత్యేకంగా: మెమరీ అలసటను నిలిపివేసే అంతర్లీన స్థానిక కేటాయింపు లైబ్రరీ పైన ఈ trait ను అమలు చేయడం * చట్టబద్ధం.)
    ///
    /// కేటాయింపు లోపానికి ప్రతిస్పందనగా గణనను నిలిపివేయాలనుకునే క్లయింట్లు నేరుగా `panic!` లేదా ఇలాంటి వాటికి బదులుగా [`handle_alloc_error`] ఫంక్షన్‌కు కాల్ చేయమని ప్రోత్సహిస్తారు.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// `allocate` వంటి ప్రవర్తనలు, కానీ తిరిగి వచ్చిన మెమరీ సున్నా-ప్రారంభించబడిందని కూడా నిర్ధారిస్తుంది.
    ///
    /// # Errors
    ///
    /// `Err` ని తిరిగి ఇవ్వడం మెమరీ అయిపోయినట్లు లేదా `layout` కేటాయింపు యొక్క పరిమాణం లేదా అమరిక అడ్డంకులను తీర్చలేదని సూచిస్తుంది.
    ///
    /// భయాందోళనలు లేదా గర్భస్రావం కాకుండా మెమరీ అలసటపై `Err` ను తిరిగి ఇవ్వమని అమలులను ప్రోత్సహిస్తారు, కానీ ఇది కఠినమైన అవసరం కాదు.
    /// (ప్రత్యేకంగా: మెమరీ అలసటను నిలిపివేసే అంతర్లీన స్థానిక కేటాయింపు లైబ్రరీ పైన ఈ trait ను అమలు చేయడం * చట్టబద్ధం.)
    ///
    /// కేటాయింపు లోపానికి ప్రతిస్పందనగా గణనను నిలిపివేయాలనుకునే క్లయింట్లు నేరుగా `panic!` లేదా ఇలాంటి వాటికి బదులుగా [`handle_alloc_error`] ఫంక్షన్‌కు కాల్ చేయమని ప్రోత్సహిస్తారు.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // భద్రత: `alloc` చెల్లుబాటు అయ్యే మెమరీ బ్లాక్‌ను అందిస్తుంది
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// `ptr` చే సూచించబడిన మెమరీని డీలోకేట్ చేస్తుంది.
    ///
    /// # Safety
    ///
    /// * `ptr` ఈ కేటాయింపు ద్వారా మెమరీ [*currently allocated*] యొక్క బ్లాక్‌ను సూచించాలి మరియు
    /// * `layout` మెమరీ బ్లాక్ అయిన [*fit*] ఉండాలి.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// మెమరీ బ్లాక్‌ను విస్తరించే ప్రయత్నం.
    ///
    /// పాయింటర్ మరియు కేటాయించిన మెమరీ యొక్క వాస్తవ పరిమాణాన్ని కలిగి ఉన్న క్రొత్త [`NonNull<[u8]>`][NonNull] ను అందిస్తుంది.`new_layout` వివరించిన డేటాను పట్టుకోవటానికి పాయింటర్ అనుకూలంగా ఉంటుంది.
    /// దీన్ని నెరవేర్చడానికి, కేటాయింపుదారుడు కొత్త లేఅవుట్‌కు సరిపోయేలా `ptr` చే సూచించబడిన కేటాయింపును పొడిగించవచ్చు.
    ///
    /// ఇది `Ok` ను తిరిగి ఇస్తే, `ptr` చే సూచించబడిన మెమరీ బ్లాక్ యొక్క యాజమాన్యం ఈ కేటాయింపుకు బదిలీ చేయబడుతుంది.
    /// జ్ఞాపకశక్తి విముక్తి పొందవచ్చు లేదా ఉండకపోవచ్చు మరియు ఈ పద్ధతి యొక్క తిరిగి విలువ ద్వారా తిరిగి కాలర్‌కు తిరిగి బదిలీ చేయకపోతే అది నిరుపయోగంగా పరిగణించబడుతుంది.
    ///
    /// ఈ పద్ధతి `Err` ను తిరిగి ఇస్తే, అప్పుడు మెమరీ బ్లాక్ యొక్క యాజమాన్యం ఈ కేటాయింపుకు బదిలీ చేయబడదు మరియు మెమరీ బ్లాక్ యొక్క విషయాలు మారవు.
    ///
    /// # Safety
    ///
    /// * `ptr` ఈ కేటాయింపు ద్వారా మెమరీ [*currently allocated*] యొక్క బ్లాక్‌ను సూచించాలి.
    /// * `old_layout` మెమొరీ బ్లాక్ అయిన [*fit*] తప్పక (`new_layout` ఆర్గ్యుమెంట్ దానికి సరిపోయే అవసరం లేదు.).
    /// * `new_layout.size()` `old_layout.size()` కంటే ఎక్కువ లేదా సమానంగా ఉండాలి.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// క్రొత్త లేఅవుట్ కేటాయింపు యొక్క పరిమాణం మరియు కేటాయింపు యొక్క అమరిక అడ్డంకులను తీర్చకపోతే లేదా పెరుగుతున్నట్లయితే విఫలమైతే `Err` ని అందిస్తుంది.
    ///
    /// భయాందోళనలు లేదా గర్భస్రావం కాకుండా మెమరీ అలసటపై `Err` ను తిరిగి ఇవ్వమని అమలులను ప్రోత్సహిస్తారు, కానీ ఇది కఠినమైన అవసరం కాదు.
    /// (ప్రత్యేకంగా: మెమరీ అలసటను నిలిపివేసే అంతర్లీన స్థానిక కేటాయింపు లైబ్రరీ పైన ఈ trait ను అమలు చేయడం * చట్టబద్ధం.)
    ///
    /// కేటాయింపు లోపానికి ప్రతిస్పందనగా గణనను నిలిపివేయాలనుకునే క్లయింట్లు నేరుగా `panic!` లేదా ఇలాంటి వాటికి బదులుగా [`handle_alloc_error`] ఫంక్షన్‌కు కాల్ చేయమని ప్రోత్సహిస్తారు.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // భద్రత: ఎందుకంటే `new_layout.size()` కంటే ఎక్కువ లేదా సమానంగా ఉండాలి
        // `old_layout.size()`, పాత మరియు క్రొత్త మెమరీ కేటాయింపు రెండూ `old_layout.size()` బైట్‌ల కోసం చదవడానికి మరియు వ్రాయడానికి చెల్లుతాయి.
        // అలాగే, పాత కేటాయింపు ఇంకా విడదీయబడలేదు కాబట్టి, ఇది `new_ptr` ను అతివ్యాప్తి చేయదు.
        // అందువలన, `copy_nonoverlapping` కు కాల్ సురక్షితం.
        // `dealloc` కోసం భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `grow` వంటి ప్రవర్తనలు, కానీ క్రొత్త విషయాలు తిరిగి రాకముందు సున్నాకి సెట్ చేయబడిందని కూడా నిర్ధారిస్తుంది.
    ///
    /// విజయవంతమైన కాల్ తర్వాత మెమరీ బ్లాక్ కింది విషయాలను కలిగి ఉంటుంది
    /// `grow_zeroed`:
    ///   * బైట్స్ `0..old_layout.size()` అసలు కేటాయింపు నుండి భద్రపరచబడింది.
    ///   * కేటాయింపు అమలును బట్టి బైట్స్ `old_layout.size()..old_size` సంరక్షించబడుతుంది లేదా సున్నా అవుతుంది.
    ///   `old_size` `grow_zeroed` కాల్‌కు ముందు మెమరీ బ్లాక్ యొక్క పరిమాణాన్ని సూచిస్తుంది, ఇది కేటాయించినప్పుడు మొదట అభ్యర్థించిన పరిమాణం కంటే పెద్దదిగా ఉండవచ్చు.
    ///   * `old_size..new_size` బైట్లు సున్నా.`new_size` అనేది `grow_zeroed` కాల్ ద్వారా తిరిగి వచ్చిన మెమరీ బ్లాక్ పరిమాణాన్ని సూచిస్తుంది.
    ///
    /// # Safety
    ///
    /// * `ptr` ఈ కేటాయింపు ద్వారా మెమరీ [*currently allocated*] యొక్క బ్లాక్‌ను సూచించాలి.
    /// * `old_layout` మెమొరీ బ్లాక్ అయిన [*fit*] తప్పక (`new_layout` ఆర్గ్యుమెంట్ దానికి సరిపోయే అవసరం లేదు.).
    /// * `new_layout.size()` `old_layout.size()` కంటే ఎక్కువ లేదా సమానంగా ఉండాలి.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// క్రొత్త లేఅవుట్ కేటాయింపు యొక్క పరిమాణం మరియు కేటాయింపు యొక్క అమరిక అడ్డంకులను తీర్చకపోతే లేదా పెరుగుతున్నట్లయితే విఫలమైతే `Err` ని అందిస్తుంది.
    ///
    /// భయాందోళనలు లేదా గర్భస్రావం కాకుండా మెమరీ అలసటపై `Err` ను తిరిగి ఇవ్వమని అమలులను ప్రోత్సహిస్తారు, కానీ ఇది కఠినమైన అవసరం కాదు.
    /// (ప్రత్యేకంగా: మెమరీ అలసటను నిలిపివేసే అంతర్లీన స్థానిక కేటాయింపు లైబ్రరీ పైన ఈ trait ను అమలు చేయడం * చట్టబద్ధం.)
    ///
    /// కేటాయింపు లోపానికి ప్రతిస్పందనగా గణనను నిలిపివేయాలనుకునే క్లయింట్లు నేరుగా `panic!` లేదా ఇలాంటి వాటికి బదులుగా [`handle_alloc_error`] ఫంక్షన్‌కు కాల్ చేయమని ప్రోత్సహిస్తారు.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // భద్రత: ఎందుకంటే `new_layout.size()` కంటే ఎక్కువ లేదా సమానంగా ఉండాలి
        // `old_layout.size()`, పాత మరియు క్రొత్త మెమరీ కేటాయింపు రెండూ `old_layout.size()` బైట్‌ల కోసం చదవడానికి మరియు వ్రాయడానికి చెల్లుతాయి.
        // అలాగే, పాత కేటాయింపు ఇంకా విడదీయబడలేదు కాబట్టి, ఇది `new_ptr` ను అతివ్యాప్తి చేయదు.
        // అందువలన, `copy_nonoverlapping` కు కాల్ సురక్షితం.
        // `dealloc` కోసం భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// మెమరీ బ్లాక్‌ను కుదించే ప్రయత్నం.
    ///
    /// పాయింటర్ మరియు కేటాయించిన మెమరీ యొక్క వాస్తవ పరిమాణాన్ని కలిగి ఉన్న క్రొత్త [`NonNull<[u8]>`][NonNull] ను అందిస్తుంది.`new_layout` వివరించిన డేటాను పట్టుకోవటానికి పాయింటర్ అనుకూలంగా ఉంటుంది.
    /// దీన్ని నెరవేర్చడానికి, కొత్త లేఅవుట్‌కు సరిపోయేలా కేటాయింపుదారుడు `ptr` చే సూచించబడిన కేటాయింపును కుదించవచ్చు.
    ///
    /// ఇది `Ok` ను తిరిగి ఇస్తే, `ptr` చే సూచించబడిన మెమరీ బ్లాక్ యొక్క యాజమాన్యం ఈ కేటాయింపుకు బదిలీ చేయబడుతుంది.
    /// జ్ఞాపకశక్తి విముక్తి పొందవచ్చు లేదా ఉండకపోవచ్చు మరియు ఈ పద్ధతి యొక్క తిరిగి విలువ ద్వారా తిరిగి కాలర్‌కు తిరిగి బదిలీ చేయకపోతే అది నిరుపయోగంగా పరిగణించబడుతుంది.
    ///
    /// ఈ పద్ధతి `Err` ను తిరిగి ఇస్తే, అప్పుడు మెమరీ బ్లాక్ యొక్క యాజమాన్యం ఈ కేటాయింపుకు బదిలీ చేయబడదు మరియు మెమరీ బ్లాక్ యొక్క విషయాలు మారవు.
    ///
    /// # Safety
    ///
    /// * `ptr` ఈ కేటాయింపు ద్వారా మెమరీ [*currently allocated*] యొక్క బ్లాక్‌ను సూచించాలి.
    /// * `old_layout` మెమొరీ బ్లాక్ అయిన [*fit*] తప్పక (`new_layout` ఆర్గ్యుమెంట్ దానికి సరిపోయే అవసరం లేదు.).
    /// * `new_layout.size()` `old_layout.size()` కన్నా చిన్నదిగా లేదా సమానంగా ఉండాలి.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// క్రొత్త లేఅవుట్ కేటాయింపు యొక్క పరిమాణం మరియు కేటాయింపు యొక్క అమరిక పరిమితులను తీర్చకపోతే లేదా కుదించడం విఫలమైతే `Err` ని అందిస్తుంది.
    ///
    /// భయాందోళనలు లేదా గర్భస్రావం కాకుండా మెమరీ అలసటపై `Err` ను తిరిగి ఇవ్వమని అమలులను ప్రోత్సహిస్తారు, కానీ ఇది కఠినమైన అవసరం కాదు.
    /// (ప్రత్యేకంగా: మెమరీ అలసటను నిలిపివేసే అంతర్లీన స్థానిక కేటాయింపు లైబ్రరీ పైన ఈ trait ను అమలు చేయడం * చట్టబద్ధం.)
    ///
    /// కేటాయింపు లోపానికి ప్రతిస్పందనగా గణనను నిలిపివేయాలనుకునే క్లయింట్లు నేరుగా `panic!` లేదా ఇలాంటి వాటికి బదులుగా [`handle_alloc_error`] ఫంక్షన్‌కు కాల్ చేయమని ప్రోత్సహిస్తారు.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // భద్రత: ఎందుకంటే `new_layout.size()` కంటే తక్కువ లేదా సమానంగా ఉండాలి
        // `old_layout.size()`, పాత మరియు క్రొత్త మెమరీ కేటాయింపు రెండూ `new_layout.size()` బైట్‌ల కోసం చదవడానికి మరియు వ్రాయడానికి చెల్లుతాయి.
        // అలాగే, పాత కేటాయింపు ఇంకా విడదీయబడలేదు కాబట్టి, ఇది `new_ptr` ను అతివ్యాప్తి చేయదు.
        // అందువలన, `copy_nonoverlapping` కు కాల్ సురక్షితం.
        // `dealloc` కోసం భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// `Allocator` యొక్క ఈ ఉదాహరణ కోసం "by reference" అడాప్టర్‌ను సృష్టిస్తుంది.
    ///
    /// తిరిగి వచ్చిన అడాప్టర్ కూడా `Allocator` ను అమలు చేస్తుంది మరియు దీనిని రుణం తీసుకుంటుంది.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // భద్రత: భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // భద్రత: భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // భద్రత: భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // భద్రత: భద్రతా ఒప్పందాన్ని కాలర్ సమర్థించాలి
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}